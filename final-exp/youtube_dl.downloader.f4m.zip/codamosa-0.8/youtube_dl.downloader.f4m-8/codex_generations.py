

# Generated at 2022-06-12 16:34:57.115080
# Unit test for function get_base_url

# Generated at 2022-06-12 16:35:07.817076
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:35:18.676270
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    afrt = FlvReader(b'\x00\x00\x00d\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01')

# Generated at 2022-06-12 16:35:29.342542
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from .testutils import read_fixture_text
    flv_data = compat_b64decode(read_fixture_text('flv_reader_input.txt'))
    bootstrap_info = FlvReader(flv_data).read_bootstrap_info()
    assert len(bootstrap_info['segments']) == 1
    assert len(bootstrap_info['fragments'][0]['fragments']) == 3
    assert bootstrap_info['fragments'][0]['fragments'][0] == {
        'first': 1,
        'ts': 0,
        'duration': 782,
        'discontinuity_indicator': None,
    }


# Utility functions for reading numbers and strings

# Generated at 2022-06-12 16:35:39.451356
# Unit test for function get_base_url
def test_get_base_url():
    assert get_base_url(
        compat_etree_fromstring(
            b'<manifest xmlns="http://ns.adobe.com/f4m/1.0"><baseURL>THE BASE URL</baseURL></manifest>')) == 'THE BASE URL'
    assert get_base_url(
        compat_etree_fromstring(
            b'<manifest xmlns="http://ns.adobe.com/f4m/2.0"><baseURL>THE BASE URL</baseURL></manifest>')) == 'THE BASE URL'
    assert get_base_url(
        compat_etree_fromstring(
            b'<manifest xmlns="http://ns.adobe.com/f4m/2.0"></manifest>'))==None


# Generated at 2022-06-12 16:35:47.330183
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader import get_suitable_downloader
    from collections import namedtuple
    from tempfile import mkdtemp
    from contextlib import contextmanager
    import shutil
    import os
    import sys
    import hashlib
    import gzip
    import logging

    @contextmanager
    def tmp_work_dir():
        # Make a temp directory to save the data
        # The temp directory is deleted at the end of the test
        tmp_dir = mkdtemp()
        print(tmp_dir)
        try:
            yield tmp_dir
        finally:
            shutil.rmtree(tmp_dir)


# Generated at 2022-06-12 16:35:53.197149
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from .extractor.common import InfoExtractor
    from .utils import _setenv
    from functools import partial

    ie = InfoExtractor(downloader=object)
    f4m_fd = F4mFD(partial(ie._request_webpage,
                           ie=ie,
                           url_basepath='http://example.com',
                           video_id='test_video_id'), ie.params)


# Generated at 2022-06-12 16:36:00.826455
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:36:08.482636
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    """
    Test method read_bootstrap_info of class FlvReader
    """
    from .adaptive_test import read_test_data
    test_data = read_test_data()
    f = FlvReader(test_data['bootstrap_info'])
    info = f.read_bootstrap_info()
    assert info == test_data['bootstrap_info_parsed']



# Generated at 2022-06-12 16:36:18.094150
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<?xml version="1.0" encoding="utf-8"?>'
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://some_url</baseURL>'
        '</manifest>')
    assert 'http://some_url' == get_base_url(manifest)
    manifest = compat_etree_fromstring(
        '<?xml version="1.0" encoding="utf-8"?>'
        '<manifest xmlns="http://ns.adobe.com/f4m/2.0">'
        '<baseURL>http://some_url</baseURL>'
        '</manifest>')
    assert 'http://some_url' == get_base_url

# Generated at 2022-06-12 16:36:46.880492
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    b = compat_struct_pack(
        '!I4s5s7sI4sI5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s5s', *(0x64,) * 21)
    b = compat_struct_pack('!I4s', len(b), b'bstt') + b
    b += compat_struct_pack('!I4s', len(b), b'boot')
    reader = FlvReader(b)

# Generated at 2022-06-12 16:36:59.137320
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from .common import InAdvancePagedList
    from .extractor.youtube import YoutubeIE
    from .postprocessor.ffmpeg import FFmpegExtractAudioPP
    from .downloader import FileDownloader
    from .utils import sanitize_open
    import tempfile
    import os
    import shutil
    import random
    import string
    output_file = tempfile.NamedTemporaryFile(mode='wb')
    tmp_dir = tempfile.mkdtemp(prefix='youtube-dl-unittest')

# Generated at 2022-06-12 16:37:03.017045
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-12 16:37:15.021835
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    import unittest
    import pprint
    from .test_fragment import FlvReaderTestCase


# Generated at 2022-06-12 16:37:25.890774
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-12 16:37:31.859787
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    assert remove_encrypted_media([]) == []
    assert remove_encrypted_media([
        compat_etree_fromstring(b'<media d="url"/>'),
        compat_etree_fromstring(
            u'<media d="url" drmAdditionalHeaderId="foo" '
            u'drmAdditionalHeaderSetId="bar"/>')]) == [
        compat_etree_fromstring(b'<media d="url"/>'),
    ]



# Generated at 2022-06-12 16:37:43.525132
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from .common import VideoInfo
    from .common import _add_ns
    from .smil import _extract_video_info_smil

    # unit test on TV.com video

# Generated at 2022-06-12 16:37:53.502210
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-12 16:38:06.747366
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-12 16:38:16.741730
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-12 16:38:41.281802
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    e1 = b'\x00\x00\x00\xA1\x61\x62\x73\x74\x00\x00\x00\x00\x00'
    e1 += b'\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-12 16:38:51.497955
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    example_abst_hex = '00000038 61627374 0000000C 00000000 00000000 6C776171 706F6E65 00000000 00000001 62746E6F 6F740000 00000000 01000000 00000000 00000000 01000000 FF000000 FF000000 FF00000000 00010001'
    example_abst_hex += '73656E67 65727300 0001026C 61766554 65737400 00000174486C75 2F6D696E 6F757400 0004656E 69626F6F 74756C61 6E7400'
    example_abst_hex += '0000000000000000 01000000 00000000 00000000 01000000 00000000 00000000 03000000 02000000'
    example_abst_hex += '66697273746F7279 00000000 00000000 23000000'
    example_abst = bytes.fromhex(example_abst_hex)

# Generated at 2022-06-12 16:38:56.283390
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    reader = FlvReader(flv)
    assert reader.read_bootstrap_info() == {
        'fragments': [],
        'segments': [],
        'live': False,
    }



# Generated at 2022-06-12 16:39:01.704715
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    # test empty string
    assert FlvReader(b'\x00').read_string() == b''
    # test normal string
    assert FlvReader(b'abc\x00').read_string() == b'abc'
    assert FlvReader(b'abc').read_string() == b''
    assert FlvReader(b'\x00abc').read_string() == b'\x00abc'


# Generated at 2022-06-12 16:39:13.168754
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:39:23.605310
# Unit test for function build_fragments_list
def test_build_fragments_list():
    bootstrap = read_bootstrap_info(open(
        'tests/files/hds_bootstrap', 'rb').read())
    assert build_fragments_list(bootstrap) == [(0, 0), (0, 1)]
    bootstrap = read_bootstrap_info(open(
        'tests/files/hds_bootstrap_vod', 'rb').read())
    assert build_fragments_list(bootstrap) == [
        (0, 0), (0, 1), (0, 2), (0, 3), (0, 4), (0, 5)]
    bootstrap = read_bootstrap_info(open(
        'tests/files/hds_bootstrap_live', 'rb').read())

# Generated at 2022-06-12 16:39:34.198314
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:39:41.144246
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:39:53.199058
# Unit test for function build_fragments_list
def test_build_fragments_list():
    import pytest
    boot_info = {
        'segments': [{
            'segment_run': [
                (25, 2),
                (28, 1),
            ],
        }],
        'fragments': [{
            'fragments': [
                {'first': 0, 'ts': 0, 'duration': 0},
                {'first': 1, 'ts': 0, 'duration': 10},
                {'first': 2, 'ts': 10, 'duration': 10},
                {'first': 3, 'ts': 20, 'duration': 10},
                {'first': 4, 'ts': 30, 'duration': 10},
            ],
        }],
        'live': False,
    }

# Generated at 2022-06-12 16:40:04.247852
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:41:11.981928
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = io.BytesIO(
        b'\x00\x00\x00\x0c\x61\x73\x72\x74\x01\x00\x00\x00\x01'
        b'\x00\x00\x00\x02\x00\x00\x00\x1b\x00\x00\x00\x02'
        b'\x00\x00\x00\x0f\x00\x00\x00\x0e\x00\x00\x00\x1b'
        b'\x00\x00\x00\x00\x00\x00\x00\x0f'
    )
    result = FlvReader(data).read_asrt()

# Generated at 2022-06-12 16:41:18.216634
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import encode_data_uri
    with open('tests/data/bootstrapinfo') as f:
        data = FlvReader(f.read()).read_bootstrap_info()
    # pprint.pprint(data)

# Generated at 2022-06-12 16:41:28.332742
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..extractor import (
        decode_packed_codes,
        intlist_to_bytes,
    )
    from ..compat import compat_struct_pack, compat_struct_unpack

    xml_data = open(
        'tests/data/bootstrap_info.xml', 'rb').read()
    xml_data = fix_xml_ampersands(xml_data)
    root = compat_etree_fromstring(xml_data)
    base_url = xpath_text(root, './baseURL', 'baseURL')
    if base_url:
        base_url = base_url.strip()

    bootstrap_info = xpath_text(root, './bootstrapInfo', 'bootstrapInfo')

# Generated at 2022-06-12 16:41:40.173903
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:41:46.584554
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    url = 'http://www.dailymotion.com/cdn/manifest/video/xk41he.m3u8'
    ydl = YoutubeDL()
    ydl.params['test'] = True
    ydl.params['simulate'] = True
    
    info_dict = {}
    info_dict['url'] = url 
    f4mFD = F4mFD(ydl)
    f4mFD.real_download(None, info_dict)
    f4mFD.real_download('m_300.flv', info_dict)

if __name__ == '__main__':
    test_F4mFD_real_download()


# Generated at 2022-06-12 16:41:57.591764
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():

    box_data = """
    00000024afrt 00000001000000000400000001000000
    00010000                                       
    00000000000000000002000000030000000000000004
    00000005                                       
    00000000
    """
    t = FlvReader(box_data.encode('ascii')).read_afrt()
    assert t == {
        'fragments': [
            {'first': 0, 'ts': 0, 'duration': 1, 'discontinuity_indicator': None},
            {'first': 2, 'ts': 0, 'duration': 3, 'discontinuity_indicator': None},
            {'first': 4, 'ts': 0, 'duration': 5, 'discontinuity_indicator': 0},
        ]
    }

# Generated at 2022-06-12 16:42:05.806697
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    from ..utils import ensure_bytes

    def _test_box(box_type, box_data):
        box = FlvReader(ensure_bytes(box_type) + compat_struct_pack('!I', len(box_data) + 8) + box_data)
        assert box.read_box_info() == (len(box_data) + 8, box_type, box_data)

    _test_box('aaaa', ensure_bytes('bbbb'))
    _test_box('aaaa', ensure_bytes('bbbb') * (1 << 16))
    _test_box('aaaa', ensure_bytes('bbbb') * (1 << 32))



# Generated at 2022-06-12 16:42:16.460625
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:42:25.570106
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-12 16:42:33.386158
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    segment_run = [
        (0, 1),
    ]
    data = b'\x00\x00\x00+\x61\x73\x72\x74\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x01'
    assert FlvReader(data).read_asrt() == {
        'segment_run': segment_run,
    }
    segment_run = [
        (0, 1),
        (1, 1),
    ]