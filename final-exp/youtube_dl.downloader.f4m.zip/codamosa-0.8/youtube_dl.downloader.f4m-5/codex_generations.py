

# Generated at 2022-06-12 16:35:11.116663
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:35:22.201803
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = compat_etree_fromstring(
        '<media url="https://example.com/frag1.f4f?foo=bar" '
        'bootstrapInfoId="bootstrap1" '
        'drmAdditionalHeaderId="header1" '
        'drmAdditionalHeaderSetId="headers1" />'
        '<media url="https://example.com/frag2.f4f?foo=bar" '
        'bootstrapInfoId="bootstrap2" '
        'drmAdditionalHeaderId="header2" '
        'drmAdditionalHeaderSetId="headers2" />')
    assert len(remove_encrypted_media(media)) == 0


# Generated at 2022-06-12 16:35:33.729933
# Unit test for function build_fragments_list
def test_build_fragments_list():
    """
    Test for function build_fragments_list
    """
    def test_bad_fragments_count(info_str, fragments_count, expected_fragments_count):
        """
        Test with bad fragments_count (4294967295) in
        SegmentRunTableBox:SegmentRunEntry
        """
        boot_info = read_bootstrap_info(info_str)
        segment_run_table = boot_info['segments'][0]
        segment_run_table['segment_run'][0] = (
            segment_run_table['segment_run'][0][0],
            fragments_count,
        )
        assert len(build_fragments_list(boot_info)) == expected_fragments_count


# Generated at 2022-06-12 16:35:43.170308
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:35:54.519285
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    # Smallest possible f4m file
    f4m_data = b'<manifest xmlns="http://ns.adobe.com/f4m/1.0"/>'
    bootstrap_data = b'''
        <bootstrapInfo profile="named" id="Bootstrap1"
            url="http%3A%2F%2Frtmp.example.com%2FmyApp%2FmyInstance.bootstrap"/>
        '''
    manifest = compat_etree_fromstring(f4m_data)
    bootstrap_elem = xpath_text(manifest, './bootstrapInfo', None, fatal=False)
    if bootstrap_elem:
        bootstrap_info = compat_b64decode(fix_xml_ampersands(bootstrap_elem))

# Generated at 2022-06-12 16:36:01.566562
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    from datetime import timedelta
    from pprint import pprint

    # Dump from a livestream of animalplanet

# Generated at 2022-06-12 16:36:12.840741
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import unittest

    import tempfile

    from .common import FakeYDL

    class TestF4mFD(unittest.TestCase):
        def test_real_download(self):
            # Test that we can download f4m manifest
            base_url = 'http://download.tsi.telecom-paristech.fr/gpac/DASH_CONFORMANCE/TelecomParisTech/mp4-main-multi-mpd-AV-NBS.mpd'
            (fd, filename) = tempfile.mkstemp(suffix='.f4m')
            os.close(fd)
            ydl = FakeYDL()
            fd = F4mFD(ydl, {'url': base_url, 'prefer_free_formats': False})

# Generated at 2022-06-12 16:36:17.513963
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Some test variables
    filename = "filename"
    info_dict = {"url": "https://domain/file"}
    # Make a new instance of F4mFD
    fmfd = F4mFD()
    # Call real_download method
    fmfd.real_download(filename, info_dict)


# Generated at 2022-06-12 16:36:24.283710
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    data = b'\x00\x00\x01\x1c' + b'abst' + 4 * b'\x00' + b'\x00\x00\x00\x01' + b'\x00\x00\x00\x01'
    data += b'\x00\x00\x00\x00\x00\x00\x04\x80\x00\x00\x00\x00\x00\x00\x04\x80' + b'\x00\x00\x00\x00'

# Generated at 2022-06-12 16:36:25.823763
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # TODO
    raise NotImplementedError

# Generated at 2022-06-12 16:36:46.102083
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:36:58.889043
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    test_string = (
        b'\x00\x00\x00\x1c\x61\x62\x73\x74\x03\x00\x00\x00'
        b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
        b'\x00\x00\x00\x01\x40\x00\x00\x00\x00\x00\x00\x00'
        b'\x00\x00\x00\x01\x40\x00\x00\x00\x00\x00\x00\x00')
    reader = FlvReader(test_string)

# Generated at 2022-06-12 16:37:11.240839
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    m = FlvReader(b'\x00\x00\x0a\x00abcd12345678')
    assert m.read_box_info() == (10, b'abcd', b'12345678')
    m = FlvReader(b'\x00\x00\x00\x00' + b'\x00\x00\x00\x00')
    assert m.read_box_info() == (0, b'\x00\x00\x00\x00', b'')
    m = FlvReader(b'\x00\x00\x00\x01' + b'abcd\x00\x00\x00\x00')

# Generated at 2022-06-12 16:37:23.116192
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.extractor import YoutubeIE, get_info_extractor

    import sys
    sys.setrecursionlimit(10000)

    if True:
        # Testing this test
        return


# Generated at 2022-06-12 16:37:25.888785
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    try:
        F4mFD.real_download(None, "filename", { "url": "url", "tbr": "10" })
    except:
        raise AssertionError("Exception thrown")


# Generated at 2022-06-12 16:37:26.464593
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    pass


# Generated at 2022-06-12 16:37:37.531882
# Unit test for function build_fragments_list
def test_build_fragments_list():
    def read_fdata(box_data):
        """ Read box_data as if it was a fragment run table box """
        fdata = {}
        fdata['version'] = compat_struct_unpack('!B', box_data[0:1])[0]
        fdata['flags'] = compat_struct_unpack('!I', b'\x00' + box_data[1:4])[0]
        fdata['time_scale'] = compat_struct_unpack('!I', box_data[4:8])[0]
        fdata['quality_entry_count'] = compat_struct_unpack('!B', box_data[8:9])[0]

# Generated at 2022-06-12 16:37:49.534744
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Test 1
    fd = F4mFD({'url': 'http://localhost/test1.f4m', 'tbr': 100})
    assert fd.real_download('filename', {'url': 'http://localhost/test1.f4m', 'tbr': 100}) == True
    # Test 2
    fd = F4mFD({'url': 'http://localhost/test2.f4m', 'tbr': 100})
    assert fd.real_download('filename', {'url': 'http://localhost/test2.f4m', 'tbr': 100}) == True
    # Test 3
    fd = F4mFD({'url': 'http://localhost/test3.f4m', 'tbr': 100})

# Generated at 2022-06-12 16:38:01.921465
# Unit test for method read_box_info of class FlvReader

# Generated at 2022-06-12 16:38:11.155521
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    ydl = YoutubeDL()
    ydl.params.update({'noplaylist': 'True', 'prefer_free_formats': 'True', 'logtostderr': 'True'})
    inf = ydl.extract_info('http://tv.mgoon.com/play/gplayer.swf?v=4485&c1=0x000000&c2=0xE0E0E0&h=360&w=640&s=1&p=0', download=False)
    return ydl.prepare_filename(inf)


# Generated at 2022-06-12 16:38:37.548530
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv_reader = FlvReader(open('../tests/data/example_bootstrap.abst', 'rb').read())
    flv_reader.read_bootstrap_info()



# Generated at 2022-06-12 16:38:48.164947
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv = io.open('test/test.bootstrap', 'rb')
    abst = FlvReader(flv.read()).read_bootstrap_info()
    assert abst['segments'][0]['segment_run'] == [(1, 10)]
    assert abst['segments'][1]['segment_run'] == [
        (1, 10), (11, 10), (21, 10), (31, 10), (41, 10),
        (51, 10), (61, 10), (71, 10), (81, 10), (91, 10)]
    assert abst['fragments'][0]['fragments'][0] == {
        'first': 1, 'ts': 0, 'duration': 10000, 'discontinuity_indicator': None}

# Generated at 2022-06-12 16:38:55.358235
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    from ..utils import (
        xpath_element,
    )

# Generated at 2022-06-12 16:39:06.353020
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:39:12.614993
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    try:
        import youtube_dl.downloader.external.rtmpdump as rtmpdump
    except ImportError:
        return

# Generated at 2022-06-12 16:39:23.071942
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:39:33.486500
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:39:40.865641
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = read_bootstrap_info(b'''
        <bootstrapInfo
            profile="named"
            id="bootstrap0"
            url="bootstrap0.bootstrap"
            />
    ''')
    assert build_fragments_list(boot_info) == []


# Generated at 2022-06-12 16:39:53.050987
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:40:03.990117
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b"\x00\x00\x00"
        b"\x00\x10"
        b"\x41\x53\x52\x54\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
        b"\x01"
        b"\x00\x00\x00\x00\x01\x00\x00\x00"
        b"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
    )
    expect = {
        'segment_run': [
            (0, 1),
        ],
    }

# Generated at 2022-06-12 16:40:44.938152
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    unit_test('test/test.f4m', 'f4m')
    tmp_log_file = tempfile.NamedTemporaryFile('w+b', prefix='test-log', suffix='.txt')
    tmp_output_file = tempfile.NamedTemporaryFile('w+b', prefix='test-output-', suffix='.flv')
    def get_format_dict(url, info, ie_key):
        m = re.match('(.+)_[0-9]+_[0-9]+', ie_key)
        if m:
            ie_key = m.group(1)
        return {'url': url, 'ext': 'flv', 'format_id': ie_key}
    # Setup f4m downloader
    f4mdl = F4mFD(None)
    f4md

# Generated at 2022-06-12 16:40:52.234792
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    flv_reader = FlvReader(
        b'\x00\x00\x00\x20asrt\x00\x00\x00\x00\x00\x00\x00\x01\x00'
        b'\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01')
    assert flv_reader.read_asrt() == {
        'segment_run': [(1, 1)],
    }

# Generated at 2022-06-12 16:41:00.372772
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    print("[Unit Test]: Start FlvReader test_read_bootstrap_info")
    with open("test.bootstrap", "rb") as f:
        # read bootstrap info
        bootstrap = FlvReader(f.read()).read_bootstrap_info()

        # print
        print("BOOTSTRAP INFO:")
        print("Segments:", bootstrap["segments"])
        print("Fragments:", bootstrap["fragments"])
    print("[Unit Test]: Finish FlvReader test_read_bootstrap_info")



# Generated at 2022-06-12 16:41:02.694514
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import youtube_dl.extractor.test
    youtube_dl.extractor.test.test_FD_real_download(F4mFD)

# Generated at 2022-06-12 16:41:12.242080
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    data = (
        b'\x00'  # version
        b'\x00\x00\x00'  # flags
        b'\x00\x00\x07\xd0'  # time scale
        b'\x01\x00\x00\x00'  # QualityEntryCount
        b'\x00\x00\x00\x00'  # FragmentsCount
        b'\x00\x00\x00\x00\x00\x02\x00\x18'  # First, FirstTimestamp
        b'\x00\x00\x00\x00\x00\x01\x00\x18'  # First, FirstTimestamp
    )
    ret = FlvReader(data).read_afrt()

# Generated at 2022-06-12 16:41:16.883148
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from .extractor.common import InfoExtractor
    from .downloader.external import ExternalFD
    from .compat import getproxies
    from .utils import DEFAULT_OUTTMPL
    from .downloader import Downloader
    from .postprocessor.ffmpeg import FFmpegPostProcessor
    url = input("url: ")
    proxies = getproxies()
    if url[0:2] == '//':
        url = 'https:' + url
    d = Downloader(params={'noprogress': True, 'proxy': None, 'forcetitle': True, 'nooverwrites':True, 'outtmpl': DEFAULT_OUTTMPL})
    info_dict = d.url_result(url, 'F4mFD')
    info_dict['proxy'] = proxies
    dl = F4m

# Generated at 2022-06-12 16:41:17.858953
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # test for real_download method with parameters filename,info_dict
    return None

# Generated at 2022-06-12 16:41:22.967912
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = b'\x00\x00\x00(\x61\x73\x72\x74\x00\x00\x00\x01' \
           b'\x66\x6c\x76\x33\x00\x00\x00\x02\x00\x00\x00\x0eI' \
           b'\x00\x00\x00\x03\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'
    bootstrap_info = FlvReader(data).read_asrt()
    assert len(bootstrap_info['segment_run']) == 2
    assert bootstrap_info['segment_run'][0] == (0, 14)

# Generated at 2022-06-12 16:41:34.907412
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:41:43.479943
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    from .fragment import parse_fragment_url

# Generated at 2022-06-12 16:43:04.081981
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:43:14.193918
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    test_data = (
        b'\x00\x00\x00\x80\x61\x73\x72\x74\x01\x00\x00\x00 '
        b'\x63\x6f\x6d\x6d\x6f\x6e\x20\x6c\x6f\x6f\x6b\x00\x00\x00\x00\x01\x00'
        b'\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01')

    expected = {
        'segment_run': [
            (0, 1),
        ],
    }
    assert FlvReader(test_data).read_asrt() == expected



# Generated at 2022-06-12 16:43:21.638191
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    import zlib

# Generated at 2022-06-12 16:43:32.584978
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    # the real_download test for F4mFD could be run with a real youtube-dl
    # object but currently, this is never instanciated
    ydl = YoutubeDL({})

# Generated at 2022-06-12 16:43:41.738204
# Unit test for function build_fragments_list