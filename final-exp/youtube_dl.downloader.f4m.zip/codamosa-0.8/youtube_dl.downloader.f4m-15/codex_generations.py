

# Generated at 2022-06-12 16:34:18.020310
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-12 16:34:29.239518
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    import base64
    # Example:

# Generated at 2022-06-12 16:34:41.336568
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import make_HTTPServer
    from .f4m import (F4mAdobeDRM, F4mAdobeHDS, F4mPPDS, DASHEncryption, DASHEncryptionMethod,
                      Mp4Encryption, Mp4EncryptionMethod)
    from .dash import (DASHManifest, DASHManifestSegment)

# Generated at 2022-06-12 16:34:53.318185
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = FlvReader(test_bootstrap_info).read_bootstrap_info()
    boot_info['live'] = False
    assert build_fragments_list(boot_info) == [
        (0, 0),
        (0, 1),
        (0, 2),
        (0, 3),
        (0, 4),
    ]

    boot_info['live'] = True
    assert build_fragments_list(boot_info) == [
        (0, 4),
        (0, 5),
    ]



# Generated at 2022-06-12 16:35:01.851494
# Unit test for constructor of class F4mFD
def test_F4mFD():
    from .extractor.common import InfoExtractor

    class FakeInfo(object):
        def __init__(self, real_url):
            self.url = real_url

    class FakeYdl(object):
        def __init__(self):
            self.params = {}

        def prepare_filename(self, info_dict):
            return 'filename'

        def report_warning(self, msg):
            print('WARNING: %s' % msg)

    fake_ydl = FakeYdl()
    fake_ydl.params['test'] = True
    fake_ydl.params['proxy'] = 'fake'


# Generated at 2022-06-12 16:35:07.039118
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    test_string = (
        '<media href="Seg1-Frag3" mediaByteRange="1548-1323231" '
        'drmAdditionalHeaderSetId="0" drmAdditionalHeaderId="0"/>'
    )
    tree = compat_etree_fromstring(test_string)
    assert len(remove_encrypted_media(tree)) == 0



# Generated at 2022-06-12 16:35:16.718346
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    sample = (
        b'\x00\x00\x00\x31\x61\x73\x72\x74\x01\x00\x00\x00\x01\x00\x00\x00\x01'
        b'\x33\x32\x37\x33\x38\x00\x00\x00\x01\x00\x00\x00\x02\x00\x00\x00\x02'
    )
    fp = FlvReader(sample)
    fp.read_unsigned_int()
    assert fp.read_asrt() == {
        'segment_run': [(0, 2)],
    }

# Generated at 2022-06-12 16:35:28.188389
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # largest complete box
    data = b'\x00\x00\x00\x14' + b'test' + b'12345678'
    reader = FlvReader(data)
    size, box_type, box_data = reader.read_box_info()
    assert size == 20
    assert box_type == b'test'
    assert box_data == b'12345678'

    # smallest complete box
    data = b'\x00\x00\x00\x09' + b'test' + b'1234'
    reader = FlvReader(data)
    size, box_type, box_data = reader.read_box_info()
    assert size == 9
    assert box_type == b'test'
    assert box_data == b'1234'

    # largest complete box with 8

# Generated at 2022-06-12 16:35:38.943216
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:35:49.451717
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = b'\x00\x00\x00t\x61\x73\x72\x74\x01\x68\x65\x6c\x6c\x6f\x77\x6f\x72\x6c\x64\x05\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x05\x00\x00\x00\x08\x00\x00\x00\x0b\x00\x00\x00\x0e'
    assert FlvReader(data).read_asrt() == {
        'segment_run': [
            (0,5),
            (2,3),
        ]
    }


# Generated at 2022-06-12 16:37:20.005486
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    # no exception is raised
    test_str = "Hello\x00 World"
    FlvReader(test_str).read_string()


# Generated at 2022-06-12 16:37:28.670943
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    test_input = b'\x00\x00\x00\x24\x61\x73\x72\x74\x00\x00\x00\x00\x00\x00\x00\x02' \
        b'\x66\x6C\x76\x33\x65\x6E\x67\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00' \
        b'\x00\x00\x00\x00\x00\x00'
    test_output = {
        'segment_run': [
            (0, 0)
        ],
    }
    result = FlvReader(test_input).read_asrt()
    assert result == test_output

# Generated at 2022-06-12 16:37:39.708562
# Unit test for constructor of class F4mFD
def test_F4mFD():
    """test constructor of class F4mFD"""
    # pylint: disable=R0902
    class YDL:
        def __init__(self):
            self.params = {'test': True}
            self.to_screen = lambda *args, **kargs: None
            self.urlopen = lambda *args, **kargs: None
            self.report_error = lambda *args, **kargs: None
    ydl = YDL()
    info_dict = {'url': '', 'tbr': None}
    f4mfd = F4mFD(ydl, info_dict)
    assert f4mfd.params is ydl.params
    assert f4mfd.ydl is ydl
    assert f4mfd.info_dict is info_dict

# Generated at 2022-06-12 16:37:46.536319
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    f = io.BytesIO(b'\x07AB\x00CD\x00\x05E\x00\x00\x00\x00\x00')
    reader = FlvReader(f)
    assert reader.read_string() == b'AB'
    assert reader.read_string() == b'CD'
    assert reader.read_string() == b'E'



# Generated at 2022-06-12 16:37:54.724804
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-12 16:38:08.340702
# Unit test for constructor of class F4mFD
def test_F4mFD():
    from tests.test_utils import FakeYDL
    from youtube_dl.utils import sanitize_open
    f4m_manifest = u_str(
u"""\
<manifest xmlns="http://ns.adobe.com/f4m/2.0">
<id>1</id>
<media baseURL="http://lenka.allmyvideos.net/d/mmjn5m5n5m2f" bitrate="451" bootstrapInfoId="bootstrap451" height="240" url="Seg1-Frag7" width="320">
<metadata>AAAAAAAAAAA</metadata>
</media>
</manifest>
""")
    info_dict = {
        'url': 'http://example.com',
    }

    ydl = FakeYDL()
    f4m_fd = F4mFD

# Generated at 2022-06-12 16:38:14.453253
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    box_type = 'abst'
    box_data = b'\x00abdefg'
    header_data = compat_struct_pack(
        '!I4s', 9 + len(box_data), box_type.encode('ascii'))
    assert FlvReader(header_data + box_data).read_box_info() == (
        9 + len(box_data), box_type.encode('ascii'), box_data)



# Generated at 2022-06-12 16:38:27.662290
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    # Sample file got from aliexpress.com
    data = compat_b64decode('''
AgAKb2JvdHN0cmFwcwgAAABoZWxwX3Rlc3RfVm1wMjRfV2dwMS5mcwAAAAAAANmzQAAAAAA
ANmzQAAAAAAANmzQAAAAAAANmzQAAAAAAANmzQAAAAAAANmzQAAAAAAANmzQAAAAAAANmz
QAAAAAAANmzQAAAAAAANmzQAAAAAAANmzQAAAAAAANmzQAAAAAAANmzQAAAAAAANmzQAAA
AAAAANmzQAAAAAAAAAAAAAAAUxJfgBAZm5v/wYBdG9rZW4=-
    ''')
    asrt = Fl

# Generated at 2022-06-12 16:38:37.309630
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    def test_read_box_info(f, pos, size, box_type, data):
        f.seek(pos)
        real_size, real_box_type, real_data = FlvReader(f).read_box_info()
        assert real_size == size
        assert real_box_type == box_type
        assert real_data == data


# Generated at 2022-06-12 16:38:46.246596
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    test_input = b'\x00\x00\x00\x0a\x61\x73\x72\x74\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x02\x00\x00\x00\x01'
    res = FlvReader(test_input).read_asrt()
    assert res == {'segment_run': [(1, 1), (2, 1)]}


# Generated at 2022-06-12 16:40:11.302844
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    assert FlvReader(b'abc\x00defg\x00hijk\x00lmn\x00\x00').read_string() == b'abc'
    assert FlvReader(b'abc\x00defg\x00hijk\x00lmn\x00\x00').read_string() == b'defg'
    assert FlvReader(b'abc\x00defg\x00hijk\x00lmn\x00\x00').read_string() == b'hijk'
    assert FlvReader(b'abc\x00defg\x00hijk\x00lmn\x00\x00').read_string() == b'lmn'
    assert FlvReader(b'abc\x00defg\x00hijk\x00lmn\x00\x00').read

# Generated at 2022-06-12 16:40:23.547202
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:40:34.284544
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    metadata = b'<?xml version="1.0" encoding="UTF-8"?>\n<root></root>'
    stream = io.BytesIO()
    write_metadata_tag(stream, metadata)
    stream.seek(0)
    # Skip first byte
    assert stream.read(1) == b'\x12'
    assert stream.read(3) == (b'\x00' * 3)
    assert stream.read(4) == b'\x00\x00\x00\x00'
    assert stream.read(8) == b'\x00\x00\x00\x00'
    assert stream.read(len(metadata)) == metadata
    assert stream.read(4) == (b'\x00' * 4)



# Generated at 2022-06-12 16:40:41.003893
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:40:51.316348
# Unit test for function build_fragments_list
def test_build_fragments_list():
    bootstrap_info = {
        'fragments': [
            {
                'fragments': [
                    {'first': 0, 'ts': 0, 'duration': None, 'discontinuity_indicator': 0},
                    {'first': 1, 'ts': 0, 'duration': None, 'discontinuity_indicator': 0},
                    {'first': 2, 'ts': 0, 'duration': None, 'discontinuity_indicator': 0},
                ]
            }
        ],
        'segments': [
            {
                'segment_run': [
                    (0, 3),
                ],
            }
        ],
    }

    assert build_fragments_list(bootstrap_info) == [(0, 0), (0, 1), (0, 2)]

# Generated at 2022-06-12 16:41:02.829310
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from ..test import read_test_data
    abst = FlvReader(read_test_data('hds/vip.abst')).read_abst()

# Generated at 2022-06-12 16:41:08.978627
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    f = FlvReader(b'\x00\x03abc\x00\x04def\x00\x05ijk\x00\x06lmn\x00')
    assert f.read_string() == b'abc'
    assert f.read_string() == b'def'
    assert f.read_string() == b'ijk'
    assert f.read_string() == b'lmn'

# Generated at 2022-06-12 16:41:13.641759
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Fixture:
    #   create a F4mFD object
    #   set the method urlopen to return stub data
    #   invoke real_download
    # Assert:
    #   - the stub data is correctly parsed
    #   - the output file (the one specified by the filename argument of real_download)
    #     contains the parsed stub data

    # Create a F4mFD object
    f4mfd = F4mFD()

    # Set the method urlopen to return stub data
    # We need to set the method youtubedl.YoutubeDL._download_webpage because
    # the method F4mFD.urlopen calls it
    # We need to set the method F4mFD.report_error because the method urlopen
    # raises an error, so we need to supress it

# Generated at 2022-06-12 16:41:23.160479
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:41:28.228469
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    FD_NAME = 'f4m'

    def get_test_desc(self, *args, **kwargs):
        """Return the test description"""
        return 'Test f4m downloader'

    def get_test_instance(self, *args, **kwargs):
        """Return instance of test downloader"""
        class TestFD(F4mFD):

            def report_warning(self, msg):
                self._out.write('WARNING: ' + msg + '\n')

            def to_screen(self, msg):
                self._out.write(msg + '\n')

            def report_error(self, msg, *args, **kwargs):
                self._error_message = msg
                raise Exception(msg)

            def __init__(self, *args, **kwargs):
                self._out = io.String

# Generated at 2022-06-12 16:42:49.875084
# Unit test for function build_fragments_list
def test_build_fragments_list():
    def check_list(lst, expected):
        if len(lst) != len(expected):
            return False
        for i, j in zip(lst, expected):
            if i != j:
                return False
        return True

# Generated at 2022-06-12 16:43:00.533477
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:43:08.980748
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    # This is an example of box asrt
    box_data = b'\x00\x00\x00\x15\x61\x73\x72\x74\x01\x00\x00\x00\x63\x68\x72\x6f\x6d\x65\x00\x04\x00\x00\x00\x02\x00\x00\x00\x05\x00\x00\x00\x02\x00\x00\x00\x02'
    assert FlvReader(box_data).read_asrt() == {'segment_run': [(2, 5), (2, 2)]}

# Generated at 2022-06-12 16:43:18.589489
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..downloader.common import DownloadContext
    from .smil import SMIL
    from .test_fragment import _real_extract_f4m_formats
    import os
    path = os.path.join(os.path.dirname(__file__), 'test', 'smil.xml')
    smil = SMIL(_real_extract_f4m_formats(DownloadContext, path), path)
    bootstrap_info = FlvReader(smil.bootstrap_info).read_bootstrap_info()
    # Check the result
    segments = bootstrap_info['segments']
    assert len(segments) == 1
    segment = segments[0]
    assert len(segment['segment_run']) == 11
    assert segment['segment_run'][0] == (0, 1)

# Generated at 2022-06-12 16:43:30.800294
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    data = compat_b64decode('''
          AAIABQAAAAAAAAAAAAIAAAAAAAAAAAAVABAAAEUAAAKoAlQEgASABwAFAAAFkAAABH
          Q3ljbGUAgABAAEAAABOAGcAaQB0AGgAdwBhAHIAbwAgAGQAbwBidXNpbmVzc0Jhc2UA
          AAAABw0AbABpAG4AawBvAGwAAAAAAAEAAABoAAAAQABkAG8AYnVzaW5lc3NCYXNlAAA=
    '''.encode('ascii'))
    info = FlvReader(data).read_bootstrap_info()
    print(info)



# Generated at 2022-06-12 16:43:33.345570
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    data = b'\x08abcd\x00efgh'
    assert FlvReader(data).read_string() == b'abcd'
    assert FlvReader(data).read_string() == b'efgh'


# Generated at 2022-06-12 16:43:38.679438
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    example = 'AAAAIGZ0eXBtcDQyAAAAAG1wNDFpc29tAAAAXN0b3JlSGFzaAAAAc2hhMgAAAC4AAAB/4gLgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB0ZXN0AAAABAABAAEAAgABAAAA'
    data = compat_b64decode(example.encode('ascii'))

# Generated at 2022-06-12 16:43:48.078051
# Unit test for method read_bootstrap_info of class FlvReader