

# Generated at 2022-06-12 16:34:14.037261
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    r = FlvReader(b'\x04\x00\x00\x00abcd\x00efg\x00hij\x00\x00')
    assert r.read_string() == b'abcd'
    assert r.read_string() == b'efg'
    assert r.read_string() == b'hij'
test_FlvReader_read_string()



# Generated at 2022-06-12 16:34:21.911792
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = [
        {'systemId:': 'D68AF1E8E98C0ACE', 'encrypted': 'true'},
        {'systemId:': 'D68AF1E8E98C0ACE', 'encrypted': 'false'},
        {'systemId:': 'D68AF1E8E98C0ACE', 'encrypted': 'false'},
        {'systemId:': 'D68AF1E8E98C0ACE', 'encrypted': 'false'},
        {'systemId:': 'D68AF1E8E98C0ACE', 'encrypted': 'false'},
    ]

# Generated at 2022-06-12 16:34:29.063971
# Unit test for function build_fragments_list
def test_build_fragments_list():
    assert build_fragments_list({
        'fragments': [{
            'fragments': [
                {'first': 5, 'ts': 0, 'duration': 100},
                {'first': 6, 'ts': 100, 'duration': 200},
            ]
        }],
        'segments': [{
            'segment_run': [(1, 2), (3, 4)]
        }]
    }) == [(1, 5), (1, 6), (3, 7), (3, 8), (3, 9), (3, 10)]



# Generated at 2022-06-12 16:34:41.196979
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-12 16:34:53.207210
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media1 = '<mediaUrl mediaId="2" bitrate="300" height="270" width="480" url="http://example.com/1.f4f"/>'
    media2 = '<mediaUrl mediaId="3" bitrate="300" height="270" width="480" drmAdditionalHeaderId="1" url="http://example.com/2.f4f"/>'
    media3 = '<mediaUrl mediaId="4" bitrate="300" height="270" width="480" drmAdditionalHeaderSetId="2" url="http://example.com/3.f4f"/>'
    media_list = [compat_etree_fromstring(m) for m in [media1, media2, media3]]

    res = remove_encrypted_media(media_list)

# Generated at 2022-06-12 16:35:01.789388
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:35:11.271389
# Unit test for function write_metadata_tag

# Generated at 2022-06-12 16:35:22.355521
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-12 16:35:33.950967
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    xml = """
    <Media xmlns="http://ns.adobe.com/f4m/1.0">
    <Partition>
        <Media id="video" url="https://example.com/video" bitrate="5000" drmAdditionalHeaderId="0" drmAdditionalHeaderSetId="1"/>
        <Media id="video" url="https://example.com/video" bitrate="5000" />
        <Media id="video" url="https://example.com/video" bitrate="5000"/>
        <Media id="video" url="https://example.com/video" bitrate="5000" drmAdditionalHeaderId="0"/>
        <Media id="video" url="https://example.com/video" bitrate="5000" drmAdditionalHeaderSetId="1"/>
    </Partition>
    </Media>
    """
   

# Generated at 2022-06-12 16:35:43.326922
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring('<manifest xmlns="http://ns.adobe.com/f4m/1.0"><baseURL>http://example.com</baseURL></manifest>')
    base_url = get_base_url(manifest)
    assert base_url == 'http://example.com'
    manifest = compat_etree_fromstring('<manifest xmlns="http://ns.adobe.com/f4m/2.0"><baseURL>http://example.com</baseURL></manifest>')
    base_url = get_base_url(manifest)
    assert base_url == 'http://example.com'

# Generated at 2022-06-12 16:36:11.708026
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    """
    Test for write_metadata_tag
    """
    from ..utils import encode_data_uri
    from .fragment import TAG_TYPE_META
    from .smoothstreams import SmoothStreamsFD
    from .common import (
        HEADER_EXT_BYTE, HEADER_SEQ_MASK, HEADER_SEQ_OFFSET,
        HEADER_FRAG_MASK, HEADER_FRAG_OFFSET, HEADER_LEN_MASK,
        HEADER_LEN_OFFSET)

    URL = 'https://playertest.longtailvideo.com/adaptive/wowzaid3/playlist.m3u8'

    class MockStream(object):
        def __init__(self):
            self.data = b''

        def write(self, buf):
            self.data

# Generated at 2022-06-12 16:36:15.512745
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    txt = open('test/test.bootstrap', 'rb').read()
    flvreader = FlvReader(txt)
    info = flvreader.read_bootstrap_info()
    assert info['segments'][0]['segment_run'][0] == (0, 0)
    assert info['segments'][0]['segment_run'][1] == (1, 4)
    assert info['segments'][0]['segment_run'][2] == (5, 0)
    assert info['segments'][0]['segment_run'][3] == (5, 4)
    assert info['segments'][1]['segment_run'][0] == (0, 0)

# Generated at 2022-06-12 16:36:23.270052
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    # this is a self-contained test that reads abst data from a flv file
    # and then prints the parsed data
    assert DataTruncatedError

# Generated at 2022-06-12 16:36:35.124404
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv_reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    r = flv_reader.read_bootstrap_info()
    assert r == None

    flv_reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    r = flv_reader.read_bootstrap_info()
    assert r == None


# Generated at 2022-06-12 16:36:45.157220
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    def read_afrt(b):
        return FlvReader(b).read_afrt()


# Generated at 2022-06-12 16:36:58.201303
# Unit test for function build_fragments_list
def test_build_fragments_list():
    from .fragment import FragmentFD
    boot_info_asrt_1_afrt_1 = {
        'segments': [
            {
                'segment_run': [
                    (0, 1),
                    (1, 2),
                ]
            }
        ],
        'fragments': [
            {
                'fragments': [
                    {'first': 1, 'ts': 1000, 'duration': 3000},
                    {'first': 2, 'ts': 4000, 'duration': 3000},
                    {'first': 3, 'ts': 7000, 'duration': 3000},
                ]
            }
        ],
        'live': False,
    }

# Generated at 2022-06-12 16:37:10.834982
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:37:22.734597
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    from io import BytesIO
    buf = BytesIO()
    write_metadata_tag(buf, b'''
        <?xml version="1.0" encoding="utf-8" ?>
        <data>
            <displayWidth>640</displayWidth>
            <displayHeight>360</displayHeight>
        </data>
    ''')

# Generated at 2022-06-12 16:37:30.098474
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-12 16:37:41.977745
# Unit test for function remove_encrypted_media

# Generated at 2022-06-12 16:38:09.656962
# Unit test for function remove_encrypted_media

# Generated at 2022-06-12 16:38:17.730770
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    f = open('tests/data/bootstrapinfo.bin', 'rb')
    abst_info = FlvReader(f.read()).read_abst()
    assert abst_info['live']
    assert len(abst_info['segments']) == 1
    assert len(abst_info['fragments']) == 1

# Generated at 2022-06-12 16:38:29.768472
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():

    def get_fragments(afrt):
        return [
            {
                'first': fragment['first'],
                'ts': fragment['ts'],
                'duration': fragment['duration'],
            }
            for fragment in afrt['fragments']
            if not fragment['discontinuity_indicator']
        ]


# Generated at 2022-06-12 16:38:37.741738
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    root = (
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<media url="media1.f4f" />'
        '<media url="media2.f4f" drmAdditionalHeaderId="1234" />'
        '<media url="media3.f4f" drmAdditionalHeaderSetId="1234" />'
        '<media url="media4.f4f" />'
        '</manifest>'
    )
    assert len(remove_encrypted_media(compat_etree_fromstring(root))) == 3



# Generated at 2022-06-12 16:38:48.387127
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from binascii import unhexlify
    from json import loads
    from pprint import pprint
    from collections import OrderedDict
    from .fragment import FragmentFD

    CIPHER_STRING = 'https://example.com'

# Generated at 2022-06-12 16:38:57.307449
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    class FakeReader(FlvReader):
        def read_bytes(self, n):
            return self._data[:n]

    def fake_reader_factory(data):
        f = FakeReader(data)
        f._data = data
        return f
    assert fake_reader_factory(b'\x00\x01\x02').read_string() == b'\x01\x02'
    assert fake_reader_factory(b'\x02\x00').read_string() == b'\x02'
    assert fake_reader_factory(b'\x04\x01\x02\x03\x00').read_string() == b'\x01\x02\x03'



# Generated at 2022-06-12 16:39:08.506389
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    # Test data is produced by FLVChecker.exe
    test_data = (0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 1, 0, 0, 0,
                 2, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0,
                 0, 0, 0, 0, 0, 2, 0, 0, 0, 3, 0, 0, 0, 1, 0, 0, 0, 0, 0,
                 0, 0)

    # Test data is put into a bytearray
    data = bytearray(compat_struct_pack('%dB' % len(test_data), *test_data))
    data = FlvReader(data).read_as

# Generated at 2022-06-12 16:39:18.247394
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    class FlvReaderMock(FlvReader):
        def __init__(self, data):
            self._data = data
            self._offset = 0
        def read(self, n):
            res = self._data[self._offset:self._offset+n]
            self._offset += n
            return res
        def read_bytes(self, n):
            res = self._data[self._offset:self._offset+n]
            self._offset += n
            return res
        def read_unsigned_long_long(self):
            res = compat_struct_unpack(b'!Q', self.read_bytes(8))[0]
            return res
        def read_unsigned_int(self):
            res = compat_struct_unpack(b'!I', self.read_bytes(4))[0]
           

# Generated at 2022-06-12 16:39:28.635406
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:39:33.443711
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    bootstrap = FlvReader(open('tests/files/bootstrap.flv', 'rb').read()).read_bootstrap_info()
    assert not bootstrap['live']
    assert not bootstrap['fragments'][0]['fragments'][0]['discontinuity_indicator']



# Generated at 2022-06-12 16:41:54.016769
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    reader = FlvReader(b'\x00\x00\x00\x1A\x61\x62\x73\x74\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00\x01\x00\x00\x00\x01hello')
    bootstrap_info = reader.read_bootstrap_info()
    assert len(bootstrap_info['segments']) == 1
    assert len(bootstrap_info['fragments']) == 3
    assert bootstrap_info['fragments'][0]['fragments'][0]['duration'] == 0
    assert bootstrap_info['fragments'][1]['fragments'][0]['duration'] == 1

# Generated at 2022-06-12 16:42:04.228750
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:42:14.487627
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:42:24.666348
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:42:28.565731
# Unit test for function build_fragments_list
def test_build_fragments_list():
    bootstrap_info = read_bootstrap_info(open('test/bootstrap', 'rb').read())
    assert build_fragments_list(bootstrap_info) == [
        (0, 0), (0, 1), (0, 2), (0, 3), (0, 4), (0, 5), (0, 6)]
    

# Generated at 2022-06-12 16:42:38.777598
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    for case in (
            (b'\x00\x00\x00\x14moov', 20),
            (b'\x00\x00\x00\x01ftyp', 17179869185),
            (b'\x00\x00\x00\x08free', 8),
            (b'\x00\x00\x01\xc6mdat', 1920),
            ):
        box_type = case[0]
        box_size = case[1]
        if box_size < 4294967296:
            reader = FlvReader(box_type + compat_struct_pack('!I', box_size))

# Generated at 2022-06-12 16:42:43.178753
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    mdl = downloader.YoutubeDL()
    # Test with live streams
    # Test with aes encrypted stream
    url = 'http://uk-live.hls.adaptive.level3.net/intl/bbc_sixx_q3_mf.m3u8?e=1456002658&h=0e4e971a8b81d3c3eee4bf4c7d6b8da6'
    manifest = mdl._TEST_download_webpage(url, None)
    F4mFD._TEST_parse_manifest(mdl, url, manifest)


# Generated at 2022-06-12 16:42:51.999861
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:42:55.884196
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    buf = io.BytesIO(b'abc\x00\x00')
    flv = FlvReader(buf)
    assert flv.read_string() == b'abc'


# Generated at 2022-06-12 16:43:06.461629
# Unit test for method read_box_info of class FlvReader