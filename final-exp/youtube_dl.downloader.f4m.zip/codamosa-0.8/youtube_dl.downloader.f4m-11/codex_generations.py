

# Generated at 2022-06-12 16:34:32.706391
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from .extractor import gen_extractors
    from .downloader.common import FileDownloader
    from .compat import compat_urllib_request
    from .compat import compat_urllib_parse

    # Create a fake FileDownloader using method _prepare_url of i.e. F4mFD
    class _FakeFileDownloader(F4mFD, FileDownloader):
        def real_download(self, *args, **kargs):
            raise NotImplementedError

        def _prepare_url(self, *args, **kargs):
            return self.url

    # Prepare test
    downloader = _FakeFileDownloader({})
    downloader.params['test'] = True
    #url = 'http://example.org/test.f4m'

# Generated at 2022-06-12 16:34:36.876647
# Unit test for function get_base_url
def test_get_base_url():
    manifest = '<manifest><baseURL>http://example.com</baseURL></manifest>'
    assert get_base_url(fix_xml_ampersands(manifest)) == 'http://example.com'



# Generated at 2022-06-12 16:34:44.318542
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # A sample Flv file contains two boxes,
    # which are both of size 12
    with io.open('tests/data/test.flv', 'rb') as flvfile:
        fr = FlvReader(flvfile.read())
        # The first box
        assert fr.read_box_info() == (12, b'abcd', b'efgh')
        # The second box
        assert fr.read_box_info() == (12, b'ijkl', b'mnop')



# Generated at 2022-06-12 16:34:55.627347
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    test_cases = {
        b'\x00\x00\x00\x00': (0, b'', b''),
        b'\x00\x00\x00\x0Cflv\xde\xad\xbe\xef': (12, b'flv\xde', b'\xad\xbe\xef'),
        b'\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x0Cflv\xde\xad\xbe\xef':
        (12, b'flv\xde', b'\xad\xbe\xef'),
    }
    for content, expectation in test_cases.items():
        reader = FlvReader(content)

# Generated at 2022-06-12 16:34:59.535753
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    import sys
    import binascii
    stream = io.BytesIO()
    write_metadata_tag(stream, b'1234')
    stream.seek(0)
    assert stream.read() == binascii.unhexlify(
        b'12000000d70000000100000000003433323132000000')



# Generated at 2022-06-12 16:35:07.006937
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    test_file = 'test/test.mp4'
    f = open(test_file, 'rb')
    flv = FlvReader(f.read())
    assert flv.read_box_info() == (1836, b'ftyp', b'mp42\x00\x00\x00\x00mp42\x00\x00\x00\x00isom\x00\x00\x02\x00')

# Generated at 2022-06-12 16:35:14.969501
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    with open('tests/testdata/bootstrap_info', 'rb') as f:
        fdata = f.read()
    assert FlvReader(fdata).read_bootstrap_info() == {
        'segments': [{
            'segment_run': [(0, 2)],
        }],
        'fragments': [{
            'fragments': [{
                'ts': 7260250,
                'first': 0,
                'duration': 504358,
                'discontinuity_indicator': None,
            }, {
                'ts': 12026608,
                'first': 1,
                'duration': 504414,
                'discontinuity_indicator': None,
            }],
        }],
        'live': False,
    }



# Generated at 2022-06-12 16:35:26.654491
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    # Import here to avoid creating problems if pyamf is not installed
    from pyamf import remoting

    def read_amf_string(data):
        """Read a AMF string from data"""
        res = b''
        length = compat_struct_unpack('!H', data.read_bytes(2))[0]
        if length > 0:
            res = data.read_bytes(length)
        return res

    def read_amf_object(data):
        """Read a AMF object from data"""
        res = b''
        while True:
            key = read_amf_string(data)
            if not key:
                break
            key = key.decode('utf-8')
            type_char = data.read_bytes(1)

# Generated at 2022-06-12 16:35:37.583787
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    from io import BytesIO
    import json
    import hashlib
    test_string = b"Hello World!"
    test_stream = BytesIO()
    write_flv_header(test_stream)
    metadata_stream = BytesIO()
    metadata_stream.write(b'\x02\x00\x0a\x6f\x6e\x4d\x65\x74\x61\x44\x61\x74\x61')
    metadata_stream.write(b'\x08\x00\x00\x00')
    metadata_stream.write(b'\x0c\x00\x0b\x63\x6f\x6e\x6e\x65\x63\x74\x69\x6f\x6e')
    metadata_stream

# Generated at 2022-06-12 16:35:45.965423
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:36:35.776739
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    for path in [
            'test1.abst',
            'test2.abst',
            'test3.abst',
            'test4.abst',
            'test5.abst',
            'test6.abst',
            'test7.abst',
            'test8.abst',
            'test9.abst',
            'test10.abst',
    ]:
        with io.open('test/%s' % path, 'rb') as f:
            abst = FlvReader(f.read()).read_bootstrap_info()
        print(path, abst)



# Generated at 2022-06-12 16:36:45.533494
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:36:48.802224
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    assert F4mFD.real_download(filename='test_filename', info_dict=test_info_dict) == True



# Generated at 2022-06-12 16:37:00.647391
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:37:13.089435
# Unit test for function get_base_url
def test_get_base_url():
    # Base url for a given namespace (1.0)
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com/base_url_1/</baseURL>'
        '</manifest>')
    base_url = get_base_url(manifest)
    assert base_url == 'http://example.com/base_url_1/', (
        'The base url should be http://example.com/base_url_1/')

    # Base url for a given namespace (2.0)

# Generated at 2022-06-12 16:37:20.113921
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    test_data = (b'\x00', b'\x00\x00', b'\x00\x00\x00', b'a\x00',
        b'abc\x00', b'abc\x00\x00', b'abc\x00\x00\x00')
    for test_string in test_data:
        fr = FlvReader(test_string)
        assert fr.read_string() == test_string[:-1]


# Generated at 2022-06-12 16:37:22.785919
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    f = FlvReader(b'Test\x00String')
    assert f.read_string() == b'Test'
    assert f.read_string() == b'String'



# Generated at 2022-06-12 16:37:30.124643
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:37:42.028876
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    class FakeFlvReader(FlvReader):
        def __init__(self, data):
            self.data = data
            self.i = 0
        def read_bytes(self, n):
            res = self.data[self.i : self.i + n]
            self.i += n
            return res

# Generated at 2022-06-12 16:37:52.638504
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from ..utils import (
        encode_base_n,
    )


# Generated at 2022-06-12 16:38:16.828157
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    # https://download.tsi.telecom-paristech.fr/gpac/DASH_CONFORMANCE/TelecomParisTech/mp4-live-frag-consec-AV-NBS.mpd
    from .common import read_fixtures_bytes
    data = read_fixtures_bytes('flv_reader_test_1.abst')
    info = FlvReader(data).read_bootstrap_info()

    # Test if the content of the dictionary 'info' is correct
    assert len(info['segments']) == 2
    assert len(info['fragments']) == 2

    # Test if the values of the first segment are correct
    assert len(info['segments'][0]['segment_run']) == 1

# Generated at 2022-06-12 16:38:29.248697
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-12 16:38:38.718072
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:38:40.625965
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Setup
    F4mFD.real_download(...)
    # Test
    assert True


# Generated at 2022-06-12 16:38:50.912805
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    test_data = (
        b'\x00\x00\x00\x12'  # BoxSize
        b'asrt'  # BoxType
        b'\x00'  # Version
        b'\x00\x00\x00'  # Flags
        b'\x00'  # QualityEntryCount
        b'\x00\x00\x00\x01'  # SegmentRunTableCount
        b'\x00\x00\x00\x01'  # FirstSegment
        b'\x00\x00\x00\x02'  # FragmentsPerSegment
        )
    reader = FlvReader(test_data)
    res = reader.read_asrt()
    assert res == {
        'segment_run': [(1, 2)],
    }



# Generated at 2022-06-12 16:39:00.405714
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:39:11.922824
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:39:21.839359
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:39:32.158519
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from ..test import _download_f4m

    data = open(_download_f4m('test_FlvReader_read_abst'), 'rb').read()
    info = FlvReader(data).read_bootstrap_info()

# Generated at 2022-06-12 16:39:40.468635
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from ..utils import make_csv_headers
    from io import BytesIO
    from .fragment import FragmentFD
    import os
    import shutil

    def test_method():
        reader = FlvReader(test_file)
        box_data = reader.read_bootstrap_info()
        segments = box_data['segments']
        fragments = box_data['fragments']
        print('segments:', segments)
        for i, s in enumerate(segments[0]['segment_run']):
            print('segment_run[%d]: %s' % (i, s))
        print('fragments:', fragments)

        # Analyze the content of segments and fragments
        assert len(segments) == 1
        assert len(fragments) == 1

# Generated at 2022-06-12 16:41:42.861613
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:41:54.214455
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-12 16:42:03.947406
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-12 16:42:10.708260
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from .common import (
        BaseFragmentsFD,
    )

    url_base = 'http://example.com/%(video_id)s'
    video_id = 'abcd1234'

    class MockFragmentsFD(BaseFragmentsFD):
        def __init__(self, metadata):
            self.metadata = metadata

        def real_download(self, filename, info_dict):
            fd = io.BytesIO()
            fd.write(metadata)
            fd.seek(0)
            return fd

    # Fake fragment
    b = io.BytesIO()
    b.write(compat_struct_pack(
            '!BBHI', 9, 0, 0, 9))
    b.write(b'\x08')

# Generated at 2022-06-12 16:42:21.450019
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    input_media = [
        compat_etree_fromstring(
            '<media url="http://test.org/test.mp4" bootstrapInfoId="urn:test" '
            'drmAdditionalHeaderId="urn:testheader"/>'),
        compat_etree_fromstring(
            '<media url="http://test.org/test.mp4" bootstrapInfoId="urn:test" '
            'drmAdditionalHeaderSetId="urn:testsetheader"/>'),
        compat_etree_fromstring(
            '<media url="http://test.org/test.mp4" bootstrapInfoId="urn:test"/>'),
    ]

# Generated at 2022-06-12 16:42:29.134935
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = b'\x00\x00\x00\xA0\x41\x73\x72\x74\x00\x00\x00\x00\x00\x00\x00\x01'\
           b'\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x04\x00\x00\x00\x01'\
           b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01'\
           b'\x00\x00\x00\x02\x00\x00\x00\x08'
    abst = Flv

# Generated at 2022-06-12 16:42:39.318694
# Unit test for function remove_encrypted_media

# Generated at 2022-06-12 16:42:49.876193
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'segments': [{
            'segment_run': [
                (5, 1),  # 5 segments with 1 fragment each
                (234, 2),  # 234 segments with 2 fragments each
                (0, 1),  # 0 segments with 1 fragment each (remember, segment numbers start at 1)
            ],
        }],
        'fragments': [{
            'fragments': [{
                'first': 3,
                'ts': 0,
                'duration': 4000,
                'discontinuity_indicator': None,
            }],
        }],
        'live': False,
    }
    assert ([(5, 3), (234, 4), (234, 5), (0, 6)] ==
            build_fragments_list(boot_info))



# Generated at 2022-06-12 16:43:00.578603
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    xml = (
        "<media "
        "url=\"https://example.com/encrypted\" "
        "drmAdditionalHeaderId=\"9\" "
        "drmAdditionalHeaderSetId=\"3\"/>"
        "<media url=\"https://example.com/not_encrypted\"/>"
        "<media url=\"https://example.com/not_encrypted\"/>"
        "<media "
        "url=\"https://example.com/encrypted\" "
        "drmAdditionalHeaderId=\"9\" "
        "drmAdditionalHeaderSetId=\"3\"/>")

    xml = compat_etree_fromstring(xml)
    remove_encrypted_media(xml)
    assert compat_etree_fromstring(
        "<media url=\"https://example.com/not_encrypted\"/>"
        "<media url=\"https://example.com/not_encrypted\"/>") == xml

# Generated at 2022-06-12 16:43:10.249148
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv = FlvReader(b'\x00\x00\x00&\x08\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')

# Generated at 2022-06-12 16:43:51.783980
# Unit test for method read_afrt of class FlvReader