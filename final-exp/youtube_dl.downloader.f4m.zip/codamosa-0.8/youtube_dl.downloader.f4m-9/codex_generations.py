

# Generated at 2022-06-12 16:34:20.331217
# Unit test for function get_base_url
def test_get_base_url():
    base_url = 'http://a.com/media/'
    f = io.BytesIO(fix_xml_ampersands(
        b'<manifest xmlns="http://ns.adobe.com/f4m/1.0">' +
        ('<baseURL>%s</baseURL>' % base_url).encode('utf-8') +
        b'</manifest>'))
    manifest = compat_etree_fromstring(f.read())
    assert get_base_url(manifest) == base_url

    base_url = 'https://a.com/media/'

# Generated at 2022-06-12 16:34:30.510822
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'live': True,
        'fragments': [
            {'fragments': [
                {
                    'first': 0,
                    'duration': 5,
                    'ts': 0,
                    'discontinuity_indicator': 0
                },
                {
                    'first': 1,
                    'duration': 5,
                    'ts': 5,
                    'discontinuity_indicator': 0
                }
            ]}
        ],
        'segments': [
            {'segment_run': [
                (0, 2)
            ]}
        ]
    }
    assert build_fragments_list(boot_info) == [
        (0, 0), (0, 1)
    ]

    # Test for a live stream
    boot_info['live'] = True

# Generated at 2022-06-12 16:34:42.717426
# Unit test for function build_fragments_list
def test_build_fragments_list():
    test_data = b'''
          <?xml version="1.0"?>
          <manifest xmlns="http://ns.adobe.com/f4m/1.0">
          <bootstrapInfo profile="named" url="bootstrap.abst"/>
          </manifest>
        '''
    root = fix_xml_ampersands(compat_etree_fromstring(test_data))
    root_url = 'http://example.com/'
    # Dummy bootstrap info

# Generated at 2022-06-12 16:34:54.385710
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    def dt(s):
        return time.strptime(s, '%Y-%m-%dT%H:%M:%SZ')

    # sample data

# Generated at 2022-06-12 16:35:00.067056
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = compat_etree_fromstring(
        '<media><mediaFile xml:id="1"/>'
        '<mediaFile>'
        '<mediaFile xml:id="2" drmAdditionalHeaderId="3" drmAdditionalHeaderSetId="4"/>'
        '</media>')
    media = remove_encrypted_media(media)
    assert len(media) == 1
    assert media[0].attrib['xml:id'] == '1'
test_remove_encrypted_media()



# Generated at 2022-06-12 16:35:07.575786
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:35:18.379516
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    data = compat_struct_pack('!QQQQQQQQQ', 1, 2, 3, 4, 5, 6, 7, 8, 9)
    # Test normal read
    reader = FlvReader(data)
    assert reader.read_bytes(8) == compat_struct_pack('!Q', 1)
    assert reader.read_bytes(8) == compat_struct_pack('!Q', 2)
    assert reader.read_bytes(8) == compat_struct_pack('!Q', 3)
    # Test short read
    reader = FlvReader(data)
    assert reader.read_bytes(9) == compat_struct_pack('!Q', 1) + b'\x00'
    assert reader.read_bytes(9) == compat_struct_pack('!Q', 2) + b'\x00'

# Generated at 2022-06-12 16:35:30.008740
# Unit test for function build_fragments_list
def test_build_fragments_list():
    # Two fragments, each of them in a different segment
    boot_info = {
        'live': False,
        'segments': [
            {'segment_run': [(1, 1), (2, 1)]}
        ],
        'fragments': [
            {'fragments': [{'first': 0, 'ts': 0, 'duration': 10, 'discontinuity_indicator': None},
                           {'first': 1, 'ts': 10, 'duration': 10, 'discontinuity_indicator': None}]}
        ]
    }
    res = build_fragments_list(boot_info)
    assert res == [(1, 0), (2, 1)]

    # Three fragments, each of them in a different segment

# Generated at 2022-06-12 16:35:40.215621
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '</manifest>'
    )
    assert get_base_url(manifest) is None

    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        ' <baseURL>http://example.com</baseURL>'
        '</manifest>'
    )
    assert get_base_url(manifest) == 'http://example.com'

    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/2.0">'
        '</manifest>'
    )
   

# Generated at 2022-06-12 16:35:43.316320
# Unit test for constructor of class F4mFD
def test_F4mFD():
    class FakeYDL:
        def __init__(self):
            self.params = {}
            self.dirname = lambda _ : None
            self.param = lambda _, __ : None

    class FakeInfoDict:
        def __init__(self):
            self.params = {'http_chunk_size': 1024 * 1024}
            self.url = 'fake_url'
            self.report_warning = lambda _: None

    # This test should not raise any exception
    F4mFD(FakeYDL()).real_download('fake_filename', FakeInfoDict())

# Generated at 2022-06-12 16:36:22.035858
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    url = 'http://example.com/manifest.f4m'

# Generated at 2022-06-12 16:36:33.689994
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    test_data = '0a0000010000000400000001d4f8d4f94000000000000000000000000000001000000780000000a00000000000001000000f40100000001000000f4010000000000000000000000000000000000000000000000010000000000000000000000010000000000000000000000000000000000000001000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000001000001000fa1f9a7d80000000a00000001000000'
    obj_data = FlvReader(bytes.fromhex(test_data))
    assert obj_data.read_afrt() == {
        'fragments': [
            {
                'first': 1,
                'ts': 1556317742200000000,
                'duration': 1556,
                'discontinuity_indicator': None,
            },
        ],
    }


# Generated at 2022-06-12 16:36:44.011325
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import encode_data_uri
    from ..extractor.common import InfoExtractor
    from ..compat import compat_urllib_request
    # Test 1
    data_b64 = 'AAABHQIyD3ZtbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tbW1tb'
    data = compat_b64decode(data_b64)
    s = FlvReader(data)
    res = s.read_bootstrap_info()

    assert res['live'] is True
    assert len(res['segments']) == 1

# Generated at 2022-06-12 16:36:54.780871
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    f = open('test/fixtures/flash/afrt.bin', 'rb')
    afrt = FlvReader(f.read()).read_afrt()
    assert afrt['fragments'][0] == {
        'first': 0,
        'ts': 85,
        'duration': 5000,
        'discontinuity_indicator': None,
    }
    assert afrt['fragments'][-1] == {
        'first': 180,
        'ts': 890500,
        'duration': 0,
        'discontinuity_indicator': 2,
    }
    f.close()

# Generated at 2022-06-12 16:37:04.087374
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:37:15.292580
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    s = b'\x00\x00\x00\x1c\x61\x73\x72\x74\x00\x00\x00\x00\x00\x01\x61\x00\x00\x00\x01\x00\x00\x03\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x02\x00\x00\x00'
    reader = FlvReader(s)
    res = reader.read_asrt()
    assert res == {
        'segment_run': [
            (1, 1),
            (2, 2),
        ],
    }

# Generated at 2022-06-12 16:37:26.136267
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:37:37.053652
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    assert FlvReader(b'\x00\x00\x00\x0e\xab\xcd\xef\x01\x23\x45\x67\x89\xab').read_box_info() == (14, b'\xab\xcd\xef', b'\x01\x23\x45\x67\x89\xab')
    assert FlvReader(b'\x00\x00\x01\x00\xab\xcd\xef\x01\x23\x45\x67\x89\xab\x00\x00\x00\x00').read_box_info() == (65536, b'\xab\xcd\xef', b'\x01\x23\x45\x67\x89\xab')
   

# Generated at 2022-06-12 16:37:45.381965
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    segment_run_table = ('\x00\x00\x00\x18'
                         '\x00\x00\x00\x01'
                         '\x00\x00\x00\x04'
                         '\x00\x00\x00\x02'
                         '\x00\x00\x00\x01')
    info = FlvReader(segment_run_table).read_asrt()
    assert info['segment_run'] == [[2, 1]]


# Generated at 2022-06-12 16:37:50.363406
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    fd = F4mFD("", "", "")
    # TODO:
    # 1. Write a unit test
    # 2. Replace the call to real_download with method's invocation
    # 3. Remove the code below
    print("\nERROR: Unit test for real_download method of class F4mFD has not been implemented yet.\n")
    pass


# Generated at 2022-06-12 16:39:14.928695
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Create mock objects
    def __init__(self, params):
        pass
    def read(self):
        return 'F4M data'
    def geturl(self):
        return 'URL of F4M data'
    urlh = Mock(side_effect=__init__)
    urlh.read = Mock(side_effect=read)
    urlh.geturl = Mock(side_effect=geturl)
    ydl = Mock(side_effect=__init__)
    ydl.urlopen = Mock(side_effect=urlh)
    f4mfd = F4mFD(ydl, params)
    filename = 'filename'
    info_dict = {
        'url': 'URL of F4M data',
        'tbr': None
    }

# Generated at 2022-06-12 16:39:17.777839
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    assert FlvReader(b'string\x00\x00').read_string() == b'string'
    assert FlvReader(b'another_string\x00').read_string() == b'another_string'



# Generated at 2022-06-12 16:39:28.404814
# Unit test for function remove_encrypted_media

# Generated at 2022-06-12 16:39:33.446903
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:39:40.848517
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-12 16:39:53.051438
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    def check_output_file(filename, filesize):
        assert os.path.exists(filename)
        assert os.path.getsize(filename) == filesize
        os.remove(filename)

    filename = 'output.flv'

    # Suppress messages
    import logging
    logging.basicConfig(level=logging.CRITICAL)
    ydl = YoutubeDL({'outtmpl': filename, 'quiet': 'true'})

    # F4m manifest for video "Testing f4f/f4m manifest + fragments download"
    # https://www.youtube.com/watch?v=X_h1eCmPMm8

# Generated at 2022-06-12 16:40:04.038842
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    data = bytes.fromhex(
        '00000029'  # size
        '6166 7274'  # type
        '00000001'  # version
        '00000000'  # flags
        '00000080'  # time scale
        '0000'  # QualityEntryCount
        '00000000'  # FragmentsAcount
        '0000'
        '00000000'
        '00000000'
        '00000000'
        '00000001'
        '3e8'
        '00000000'
        '00000000'
    )

    abst = FlvReader(data).read_afrt()
    assert abst['fragments'] == [
        {
            'first': 1,
            'ts': 1000,
            'duration': 0,
            'discontinuity_indicator': None,
        },
    ]

# Generated at 2022-06-12 16:40:11.637363
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import youtube_dl.YoutubeDL
    url = "http://link.theplatform.com/s/HNK2IC/media/guid/2410887629/1393871969821?mbr=true&manifest=m3u"
    ydl = youtube_dl.YoutubeDL()
    ydl.params['format'] = 'best'
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(F4mIE())
    info_dict = ydl.extract_info(url, download=False)

    F4mFD().real_download(info_dict['id'] + '.f4m', info_dict)

# Generated at 2022-06-12 16:40:23.449999
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    f = io.BytesIO(
        compat_struct_pack('!I4s', 16, b'abst') +
        compat_struct_pack('!I4s', 8, b'asrt') +
        b'\x00' +
        b'\x00\x00\x00' +
        b'\x01' +
        b'\x02\x00\x00\x00'
    )
    abst = FlvReader(f.read()).read_abst()
    assert abst == {
        'segments': [{
            'segment_run': [(2, 0)],
        }],
        'fragments': [],
        'live': False,
    }
    assert f.read() == b''



# Generated at 2022-06-12 16:40:34.576365
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    import unittest
    class TestFlvReader_read_afrt(unittest.TestCase):
        def read_fixture_file(self, name):
            s = io.open(
                os.path.join(os.path.dirname(os.path.realpath(__file__)), 'fixtures', name), encoding='latin-1').read()
            # Fix the XML to be compatible with ElementTree
            s = fix_xml_ampersands(s)
            # Return the parsed XML
            return s


# Generated at 2022-06-12 16:41:45.037255
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    #   Given
    #   When
    #   Then
    assert True



# Generated at 2022-06-12 16:41:55.989560
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    path = u'f4mmanifest.f4m'
    url = u'https://download.tsi.telecom-paristech.fr/gpac/mp4box.js'
    video_id = u'someid'
    downloader = get_suitable_downloader(
        {'url': url, 'http_chunk_size': 1024, 'test': True, 'path': path},
        info_dict={'id': video_id})
    assert(type(downloader) is F4mFD)
    success = downloader.real_download(path, {'url': url, 'http_chunk_size': 1024, 'test': True, 'path': path})
    assert(success)
    f = open(path, 'rb')
    assert(f.read(3) == b"FLV")


# Generated at 2022-06-12 16:42:00.297296
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    with open('./test.abst', 'rb') as f:
        abst_data = f.read()
    abst = FlvReader(abst_data).read_asrt()
    assert abst == {
        'segment_run': [(0, 4)],
    }


# Generated at 2022-06-12 16:42:08.637873
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    abc_afrt = b'\x00\x00\x00\x35\x61\x66\x72\x74\x00\x00\x00\x00\x00\x01\x5F\xC3\x00\x00\x00\x01\x61\x61\x61\x00\x00\x00\x00\x00\x00\x00\x00\x00\x03\xE8\x00\x04\x00\x00\x00\x00\x00\x01\x90\x00\x00\x01\x90\x00\x00\x01\x90'

# Generated at 2022-06-12 16:42:19.819659
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    """
    Example file:
    <?xml version="1.0" encoding="utf-8"?>
    <manifest xmlns="http://ns.adobe.com/f4m/1.0">
      <id>dummy_id</id>
      <mimeType>dummy_mime_type</mimeType>
      <streamType>recorded</streamType>
      <duration>60.0</duration>
      <media streamId="stream_id" bootstrapInfoId="bootstrap_id"
             url="media_url" bitrate="bitrate"
             duration="duration"
             url="url" />
    </manifest>
    """

# Generated at 2022-06-12 16:42:27.925315
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:42:32.714694
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    def check(input, expected):
        assert remove_encrypted_media(input) == expected

# Generated at 2022-06-12 16:42:43.395137
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-12 16:42:48.322511
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    f = io.BytesIO(b'f\x00o\x00o\x00\x00')
    r = FlvReader(f)
    assert r.read_string() == b'f'
    assert r.read_string() == b'o'
    assert r.read_string() == b'o'

# Generated at 2022-06-12 16:42:53.904536
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from .test_fragment import load_fixture
    bootstrap_info = FlvReader(load_fixture('bootstrap')).read_bootstrap_info()
    assert bootstrap_info['fragments'][0]['fragments'][0]['first'] == 0
    assert bootstrap_info['fragments'][0]['fragments'][0]['ts'] == 0
    assert bootstrap_info['fragments'][0]['fragments'][0]['duration'] == 58180
    assert bootstrap_info['fragments'][0]['fragments'][0]['discontinuity_indicator'] == 0
    assert bootstrap_info['fragments'][0]['fragments'][1]['first'] == 1