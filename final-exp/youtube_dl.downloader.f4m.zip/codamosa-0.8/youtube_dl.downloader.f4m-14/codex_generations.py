

# Generated at 2022-06-12 16:34:31.195772
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    import os
    from ..compat import (
        compat_chr,
        compat_json_loads,
    )
    from ..utils import (
        str_to_bytes,
    )

    abst_file = os.path.join(os.path.dirname(__file__), 'files', 'abst.dat')
    with io.open(abst_file, 'rb') as f:
        content = f.read()

    def unpack_binary(binary):
        return [
            compat_json_loads(str_to_bytes(x))
            for x in binary.split(compat_chr(0)) if x
        ]

    abst = FlvReader(content).read_abst()

# Generated at 2022-06-12 16:34:43.607934
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # arrange
    import io, os
    from .YoutubeDL import YoutubeDL

    # arrange: create streams
    # - real_download writes FLV header and metadata to dest_stream
    dest_stream = io.BytesIO()
    # - create a memory stream
    ydl_stream = io.BytesIO()
    # - get current directory
    cwd = os.getcwd()

    # arrange: set up file "youtube-dl.py" to be a HDS manifest
    dest_stream.write(open("test_data/test_F4mFD_real_download/youtube-dl.py", "rb").read())
    dest_stream.seek(0)

    # arrange: get manifest and convert to bytes
    manifest = open("test_data/test_F4mFD_real_download/manifest.xml").read()


# Generated at 2022-06-12 16:34:55.130625
# Unit test for constructor of class F4mFD
def test_F4mFD():
    from youtube_dl.downloader.f4m import F4mFD
    from .extractor.common import InfoExtractor
    from .utils import DownloadError


# Generated at 2022-06-12 16:35:05.786734
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    import os
    import sys
    from .common import TempDirManager
    from .http import HttpRequest
    from .http import HttpDownloader
    from .http import HEADRequest

    # Download the test file
    url = 'https://s3.amazonaws.com/yjlive-us-east/yjlive-us-east-1/elatest/bootstrap.bootstrap'
    status_code, headers, content = HEADRequest(url).request()
    length = int(headers['Content-Length'])

    with HttpRequest(url, range=('bytes=0-9', b'')) as request:
        data = request.read(length)
    # Save to a temporary file
    path = os.path.join(TempDirManager.name, 'bootstrap.bootstrap')

# Generated at 2022-06-12 16:35:14.366355
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:35:25.807762
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:35:36.970335
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    def check(p, d):
        assert FlvReader(p).read_abst() == d

# Generated at 2022-06-12 16:35:45.538400
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # Test no-compat_struct_unpack data
    data = (b'\x00\x00\x00\x18f\xcd\xb2\x9c?'
            b'\x00\x00\x00\x00\x00\x00\x00\x01'
            b't\x00\x00\x00')
    fr = FlvReader(data)
    assert fr.read_box_info() == (24, b'f\xcd\xb2\x9c?', b'\x00\x00\x00\x01t\x00\x00\x00')
    # Test read_box_info in real use

# Generated at 2022-06-12 16:35:56.054756
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # test for reading a simple box
    test_data = b'\x00\x00\x00\n' + \
                b'test' + \
                b'content'
    flv_reader = FlvReader(test_data)
    assert flv_reader.read_box_info() == (10, b'test', b'content')

    # test for box size = 1
    test_data = b'\x00\x00\x00\x01' + \
                b'test' + \
                b'\x00\x00\x00\x00\x00\x00\x00\x10content'
    flv_reader = FlvReader(test_data)
    assert flv_reader.read_box_info() == (16, b'test', b'content')



# Generated at 2022-06-12 16:36:06.118481
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:36:43.171736
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from ..utils import (
        find_xpath_attr,
    )
    # It's the bootstrap_info of youku video "XMTcxOTQ2MzAwNA"

# Generated at 2022-06-12 16:36:55.919941
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    """ It is a unit test for method read_afrt of class FlvReader """

# Generated at 2022-06-12 16:37:04.782246
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-12 16:37:12.500540
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    raw_data = compat_struct_pack('!I4s7I',
                                  30, b'abcd', 1, 2, 3, 4, 5, 6, 7)
    reader = FlvReader(raw_data)
    assert reader.read_box_info() == (30, b'abcd',
                                      compat_struct_pack('!7I', 1, 2, 3, 4, 5, 6, 7))


# Generated at 2022-06-12 16:37:23.536785
# Unit test for function get_base_url

# Generated at 2022-06-12 16:37:25.198407
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    print("running test case: F4mFD.real_download")
    
    

# Generated at 2022-06-12 16:37:28.991374
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    file_str = b'\x00\x00\x00\x2F\x75\x72\x6C\x20http://example.com/test.mp4\x00'
    file = FlvReader(file_str)
    info = file.read_box_info()
    assert info == (47, b'url ', b'http://example.com/test.mp4')



# Generated at 2022-06-12 16:37:40.421311
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        """<?xml version="1.0"?>
        <manifest xmlns="http://ns.adobe.com/f4m/1.0">
          <baseURL>http://example.com/</baseURL>
        </manifest>""").getroot()
    assert get_base_url(manifest) == 'http://example.com/'

    manifest = compat_etree_fromstring(
        """<?xml version="1.0"?>
        <manifest xmlns="http://ns.adobe.com/f4m/2.0">
          <baseURL>http://example.com/</baseURL>
        </manifest>""").getroot()
    assert get_base_url(manifest) == 'http://example.com/'

    manifest = compat_etree

# Generated at 2022-06-12 16:37:51.630533
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    def generate_flv_data(n, l):
        ret = io.BytesIO()
        ret.write(compat_struct_pack('!I', n))
        ret.write(b'abst')
        ret.write(compat_struct_pack('!B', 0))
        ret.write(b'\x00\x00\x00')
        ret.write(compat_struct_pack('!I', 0))
        ret.write(compat_struct_pack('!Q', 0))
        ret.write(compat_struct_pack('!I', l))
        ret.write(compat_struct_pack('!Q', 0))
        ret.write(b'\x00')
        ret.write(compat_struct_pack('!B', 0))
        return ret.getvalue()
   

# Generated at 2022-06-12 16:38:05.144149
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # |7|6|5|4|3|2|1|0|7|6|5|4|3|2|1|0|7|6|5|4|3|2|1|0|7|6|5|4|3|2|1|0|
    # | box size                                                     | box_type
    # | box data...                                                  |
    raw_data = compat_struct_pack('!I4s', 2, b'abcd')
    flv_reader = FlvReader(raw_data)
    box_info = flv_reader.read_box_info()
    assert box_info == (2, b'abcd', b'')

    # |7|6|5|4|3|2|1|0|7|6|5|4|3|2|1|

# Generated at 2022-06-12 16:38:36.602221
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    string1 = b'abcdef\x00'
    string2 = b'hijklmnop\x00'
    bytes_io = io.BytesIO(string1 + string2)
    reader = FlvReader(bytes_io)
    assert reader.read_string() == b'abcdef'
    assert reader.read_string() == b'hijklmnop'



# Generated at 2022-06-12 16:38:47.182504
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    data = b'\x00\x00\x00(\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    assert FlvReader(data).read_afrt() == {
        'fragments': [],
    }

# Generated at 2022-06-12 16:38:56.972554
# Unit test for function build_fragments_list
def test_build_fragments_list():
    # segment_run_table
    segments = [
        {'segment_run': [(0, 2), (2, 1), (5, 3)]},
    ]
    # fragment_run_entry_table
    fragments = [
        {'fragments': [
            {'first': 0, 'ts': 0},
            {'first': 2, 'ts': 60000},
            {'first': 5, 'ts': 120000},
        ]},
    ]
    boot_info = {
        'segments': segments,
        'fragments': fragments,
    }
    fragments_list = build_fragments_list(boot_info)
    assert fragments_list == [(0, 0), (0, 1), (2, 2), (5, 3), (5, 4), (5, 5)]



# Generated at 2022-06-12 16:39:07.453789
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    test_data = (
        b'\x00\x00\x00\x6B\x61\x73\x72\x74\x00\x00\x00\x00\x01test1\x00\x00'
        b'\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x14\x00\x00\x00'
        b'\x00'
    )
    test_obj = FlvReader(test_data)
    box = test_obj.read_asrt()
    assert box == {
        'segment_run': [(20, 1)],
    }


# Generated at 2022-06-12 16:39:17.182231
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-12 16:39:27.394357
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    # ASRT segment table data
    # see https://www.adobe.com/content/dam/Adobe/en/devnet/video/articles/
    #         f4v_file_format_spec_v10_1.pdf page 94
    segment_table_data = compat_b64decode(b'''
        AAAAYQIAABQCEQYMAAUABgABAAAaPwIAD7UIACq1/wAA6v8AAOr/AADq/wAA6v8AAOr/
        AAw=
    ''')
    assert FlvReader(segment_table_data).read_asrt() == {
        'segment_run': [(1, 5), (6, 3), (9, 2)],
    }


# Generated at 2022-06-12 16:39:32.322606
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import sys
    import os
    fn = os.path.basename(__file__)
    if fn == "__main__.py":
        fn = sys.argv[0]
    p = os.path.dirname(os.path.dirname(os.path.realpath(fn)))
    sys.path.append(p)
    from ydl import xfrm_f4m
    import tempfile
    import shutil
    from ydl.compat import compat_urllib_request

    def mock_open_url(url, *args, **kwargs):
        return compat_urllib_request.urlopen(url)
    #@unittest.skip("skipping")

# Generated at 2022-06-12 16:39:40.468578
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    # Definition of a sample data for test
    data = b'\x00\x00\x00$\xAFRT\x00\x00\x00\x00\x00\x00\x00\x00\x05\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-12 16:39:52.748760
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    video_id = 'QWbq3ucMWCw'
    # Path to youtube-dl.
    YTDL_PATH = 'youtube-dl'
    # Fake options for unit test.

# Generated at 2022-06-12 16:40:00.158815
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:40:26.016245
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    sample_string = 'test'
    assert FlvReader(sample_string.encode('utf-8') + b'\x00\x01\x00').read_string() == sample_string



# Generated at 2022-06-12 16:40:36.479589
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:40:46.518922
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:40:58.198834
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    m1 = '<media url="http://www.example.com/media" bitrate="1" bootstrapInfoId="1" />'
    m2 = '<media url="http://www.example.com/media" bitrate="2" bootstrapInfoId="2" drmAdditionalHeaderId="3" drmAdditionalHeaderSetId="4" />'
    m3 = '<media url="http://www.example.com/media" bitrate="3" bootstrapInfoId="3" />'
    media = compat_etree_fromstring(
        '<media><media>{0}</media><media>{1}</media><media>{2}</media></media>'.format(
            m1, m2, m3))
    res = remove_encrypted_media(media)
    assert len(res) == 2
   

# Generated at 2022-06-12 16:41:08.717226
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    from io import BytesIO
    from .test_fragment import TEST_FRAGMENTS
    for fd in TEST_FRAGMENTS:
        fd.seek(0)
        bst_data = fd.read(fd.bootstrap_size)
        box_size, box_type, box_data = FlvReader(bst_data).read_box_info()
        assert box_type == b'abst'
        abst_data = FlvReader(box_data)
        abst_data.read_unsigned_char()
        abst_data.read_bytes(3)
        abst_data.read_unsigned_int()
        abst_data.read_unsigned_char()
        abst_data.read_string()
        abst_data.read_unsigned_char()

# Generated at 2022-06-12 16:41:16.657996
# Unit test for function get_base_url
def test_get_base_url():
    test_url = 'http://example.com'
    test_xml_string = '''\
<manifest xmlns="http://ns.adobe.com/f4m/1.0"
          xmlns:hd2="http://ns.adobe.com/hd2/1.0">
  <baseURL>%s</baseURL>
</manifest>''' % test_url
    base_url = get_base_url(compat_etree_fromstring(test_xml_string))
    assert base_url == test_url


# Generated at 2022-06-12 16:41:22.251882
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:41:34.372461
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:41:43.104233
# Unit test for function build_fragments_list
def test_build_fragments_list():
    def assert_fragments_list(boot_str, expected):
        boot_info = read_bootstrap_info(boot_str)
        fragments_list = build_fragments_list(boot_info)
        assert fragments_list == expected


# Generated at 2022-06-12 16:41:54.464532
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    f = io.open('f4mTester/resources/cws.bootstrap', 'rb')
    flv = FlvReader(f.read())