

# Generated at 2022-06-12 16:34:55.450932
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:35:00.346949
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    """Test that real_download is returning the correct information for a given segment
    """
    # Given
    opt = DummyOptions()
    opt.format = 'segment'
    opt.proxy = None
    opt.cookies = None
    opt.username = None
    opt.password = None
    opt.forcedurl = False
    opt.forcetitle = False
    opt.forceid = False
    opt.forcedescription = False
    opt.forcethumbnail = False
    opt.forcefilename = False
    opt.forceduration = False
    opt.forceurl = False
    opt.forcetags = False
    opt.forcejson = False
    opt.simulate = False
    opt.skip_download = False
    opt.quiet = True
    opt.no_warnings = True
    opt.no_color = False

# Generated at 2022-06-12 16:35:10.985386
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    s = '\x00\x00\x00\x4c\x61\x73\x72\x74\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00\x03\x00\x00\x00\x02\x00\x00\x00\x06\x61\x76\x63\x31\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x02\x00\x00\x00\x03\x00\x00\x00\x04\x00\x00\x00\x05\x00\x00\x00\x06'
    r = FlvReader(s)

# Generated at 2022-06-12 16:35:22.107335
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    import re
    import unittest
    from ..utils import (
        dict_get,
        dict_location,
    )
    from ..compat import (
        compat_bytes_chr,
    )

    a_pattern = re.compile(r'{0}'.format(compat_bytes_chr(int(0xa4))))

    class TestFlvReaderReadAbst(unittest.TestCase):
        def _bool_to_str(self, value):
            return 'Yes' if value else 'No'

        def test_read(self):
            abst_file = 'm3u8-parser/tests/abst/abst-1.dat'
            with io.open(abst_file, 'rb') as f:
                data = f.read()

# Generated at 2022-06-12 16:35:30.596792
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'live': False,
        'segments': [{
            'segment_run': [
                (0, 10)
            ]
        }],
        'fragments': [{
            'fragments': [{
                'first': 1,
                'ts': 1233,
                'duration': 1456,
                'discontinuity_indicator': None,
            }]
        }]
    }
    assert build_fragments_list(boot_info) == [(0, n) for n in range(1, 11)]



# Generated at 2022-06-12 16:35:35.600860
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    print("Testing real_download of F4mFD class")
    # Arrange
    url = 'http://some_url/some_manifest.f4m'
    # Act
    result = F4mFD().real_download(None, { 'url' : url })
    # Assert
    assert result == True

# Generated at 2022-06-12 16:35:45.585586
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media_list = [
        {
            'id': '1',
            'drmAdditionalHeaderId': '',
            'drmAdditionalHeaderSetId': ''
        }, {
            'id': '2',
            'drmAdditionalHeaderId': '',
            'drmAdditionalHeaderSetId': ''
        }, {
            'id': '3',
            'drmAdditionalHeaderId': '',
            'drmAdditionalHeaderSetId': ''
        }, {
            'id': '4',
            'drmAdditionalHeaderId': '',
            'drmAdditionalHeaderSetId': ''
        }
    ]
    assert len(remove_encrypted_media(media_list)) == 0


# Generated at 2022-06-12 16:35:56.130154
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    #test variables
    filename = 'test.mp4'

# Generated at 2022-06-12 16:36:06.240718
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    from ..compat import compat_etree_Element
    from ..utils import xpath_text


# Generated at 2022-06-12 16:36:13.513694
# Unit test for function get_base_url
def test_get_base_url():
    xml = '''\
<manifest>
  <baseURL> 1  </baseURL>
  <media>
    <bootstrapInfo profile="named" id="bootstrap1" url="bootstrap1.abst"/>
    <media url="media1.f4f" bootstrapInfoId="bootstrap1"
      bitrate="10000"
      width="720"
      height="320"
      main="true"
    />
  </media>
</manifest>
'''
    manifest = compat_etree_fromstring(xml)
    assert get_base_url(manifest) == '1'


# Generated at 2022-06-12 16:36:46.463273
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:36:58.941299
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    metadata = b"<test></test>"
    out = io.BytesIO()
    write_metadata_tag(out, metadata)
    out.seek(0, io.SEEK_SET)
    out.read(3)
    assert out.read(1) == b'\x12'
    assert out.read(3) == b'\x00\x00\x0C'
    assert out.read(1) == b'\x00'
    assert out.read(3) == b'\x00\x00\x00'
    assert out.read(1) == b'\x00'
    assert out.read(4) == b'\x00\x00\x00\x00'
    assert out.read(12) == b'<test></test>'
    assert out.read(4)

# Generated at 2022-06-12 16:37:11.281710
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    from ..utils import determine_ext


# Generated at 2022-06-12 16:37:14.881758
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (b'\x00\x00\x00\x27\x61\x73\x72\x74'
            b'\x00\x00\x00\x00\x00\x00\x00\x01'
            b'\x65\x6C\x65\x6E\x74\x00\x00\x01'
            b'\x00\x50\x00\x00\x00\x0C\x00\x00'
            b'\x00\x01\x00\x00\x00\x01\x00\x00'
            b'\x00\x03')


# Generated at 2022-06-12 16:37:18.329786
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    r = FlvReader(b'ABCDE\x00FG\x00')
    assert r.read_string() == b'ABCDE'
    assert r.read_string() == b'FG'



# Generated at 2022-06-12 16:37:27.941632
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from .test import get_testdata_file
    bootstrap_data = get_testdata_file(b'ut-bootstrap.data')
    abst = FlvReader(bootstrap_data).read_abst()

# Generated at 2022-06-12 16:37:39.286350
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-12 16:37:50.789308
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    from .test.test_download import SkipTest, _TEST_FILE_SIG_F4F
    # Test file provided by the project https://github.com/lequan/f4fstreaming
    resource_path = _TEST_FILE_SIG_F4F
    iframe_fragment_data = open(resource_path, 'rb').read()
    # I have inserted a afrt box with 1 fragment in the middle of an iframe fragment
    iframe_fragment_data = iframe_fragment_data[:33] + b'\x00\x00\x00\x1cafrt' + iframe_fragment_data[37:]
    fr = FlvReader(iframe_fragment_data)
    fr.read_unsigned_int()
    fr.read_unsigned_char()

# Generated at 2022-06-12 16:38:03.979248
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:38:15.290695
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    class InfoDict(dict):
        def __init__(self, dict_={}):
            dict.__init__(self, dict_)
