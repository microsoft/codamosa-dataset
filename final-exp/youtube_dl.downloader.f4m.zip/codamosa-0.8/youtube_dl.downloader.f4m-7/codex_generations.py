

# Generated at 2022-06-12 16:34:43.093876
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    TEST_DATA = b'\x00\x00\x00\x87\x00\x00\x00\x00\x00\x00\x00\x04\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x06\x00\x00\x00\x01\x00\x00\x01\x56\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'
    assert Flv

# Generated at 2022-06-12 16:34:50.779302
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    data = compat_struct_pack('!7s3s3s', b'\x00\x00\x00\x00\x00\x00\x00', b'\x00\x00\x00', b'\x00\x00\x00')
    obj = FlvReader(data)
    assert obj.read_string() == b''
    assert obj.read_string() == b''
    assert obj.read_string() == b''
    assert obj.read_string() == b''



# Generated at 2022-06-12 16:35:00.215303
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-12 16:35:07.620707
# Unit test for function get_base_url
def test_get_base_url():
    manifest_xml = """<?xml version="1.0" encoding="utf-8"?>
        <manifest xmlns="http://ns.adobe.com/f4m/1.0">
        <baseURL>http://example.com</baseURL>
        </manifest>"""
    manifest = compat_etree_fromstring(manifest_xml)
    assert get_base_url(manifest) == 'http://example.com'

    manifest_xml = """<?xml version="1.0" encoding="utf-8"?>
        <manifest xmlns="http://ns.adobe.com/f4m/2.0">
        <baseURL>http://example.org</baseURL>
        </manifest>"""
    manifest = compat_etree_fromstring(manifest_xml)

# Generated at 2022-06-12 16:35:18.493482
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    for _ in range(4):
        import sys
        from .downloader import DownloadContext
        from .extractor import YoutubeIE

        # F4mFD().real_download('', {'url': 'http%3A%2F%2Fmedia-bcr.cbsistatic.com%2Fplayer%2Fv1%2Fplayer_brazil_live.swf', 'tbr': None, 'auto_template': 'http%3A%2F%2Fmedia-bcr.cbsistatic.com%2Fplayer%2Fv1%2Fplayer_brazil_live.swf', 'epoch': 1475297681})
        # print(sys.argv)

# Generated at 2022-06-12 16:35:30.166369
# Unit test for function get_base_url
def test_get_base_url():
    base_urls = [
        'http://domain.com/page.html',
        'http://domain.com/page.html/',
        'http://domain.com/page.html//',
        'page.html',
        'page.html/',
        'page.html//',
        '',
        None,
        'http://domain.com:8080/page.html',
        'http://user:password@domain.com/page.html'
    ]

# Generated at 2022-06-12 16:35:40.433058
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-12 16:35:47.824314
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-12 16:35:52.843050
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    import pprint
    with open('test.bootstrap', 'rb') as f:
        data = f.read()
    abst_info = FlvReader(data).read_bootstrap_info()
    abst_info['fragments'][0]['fragments'][0]['duration'] = 0
    pprint.pprint(abst_info)



# Generated at 2022-06-12 16:36:00.663548
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    """Check that the writing of bootstrap box is working correctly.
    """
    # pylint: disable=protected-access,too-many-locals
    from io import BytesIO
    from copy import copy

    class DummyFD(F4mFD):
        """A dummy version of F4mFD that does not perform actual downloads.
        """
        def real_download(self, *args, **kwargs):
            """Override real_download."""
            pass

    class DummyYDL(object):
        """A dummy version of YoutubeDL.
        """

        def __init__(self):
            """Create a DummyYDL."""
            self._opener = compat_urllib_request.build_opener()

        def urlopen(self, url):
            """Override urlopen to return a BytesIO."""


# Generated at 2022-06-12 16:36:42.085452
# Unit test for function build_fragments_list
def test_build_fragments_list():
    def run_test(boot_info, expected):
        assert build_fragments_list(boot_info) == expected


# Generated at 2022-06-12 16:36:54.264165
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:37:03.839139
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Verify correct download of an HDS file
    # We create a mock ydl object
    ydl = Mock()
    ydl.urlopen = Mock()
    # We create a mock urlh object
    urlh = Mock()
    # We create mock objects for the tags in the flv files
    script_tag = Mock()
    media_tag = Mock()
    # We create a mock file object for the destination file
    destination_file = Mock()
    # We assume that all the wanted files are available
    urlh.geturl.return_value = 'http://mock_url'
    ydl.urlopen.return_value = urlh

# Generated at 2022-06-12 16:37:15.855781
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    info = FlvReader(open(
        'tests/bootstrapinfo.txt', 'rb').read()).read_bootstrap_info()
    # Check segments
    assert len(info['segments']) == 1
    segment_run = info['segments'][0]['segment_run']
    assert len(segment_run) == 1
    first_segment, fragments_per_segment = segment_run[0]
    assert first_segment == 0
    assert fragments_per_segment == 3
    # Check fragments
    assert len(info['fragments']) == 1
    fragments = info['fragments'][0]['fragments']
    assert len(fragments) == 3
    fragment = fragments[0]
    assert fragment['first'] == 1
    assert fragment['ts'] == 0
   

# Generated at 2022-06-12 16:37:26.593865
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.downloader.f4m import F4mFD

    class YDL:
        params = {'test': True}

        def urlopen(self, url):
            url_parsed = compat_urllib_parse_urlparse(url)
            assert url_parsed.path == '/mypath'
            return compat_urllib_request.urlopen(url)

    class DummyInfoDict(dict):
        def __init__(self, url):
            dict.__init__(self)
            self['url'] = url
        def __getattr__(self, key):
            return self[key]

    ydl = YDL()
    d = F4mFD(ydl)
    assert d.real_download(None, DummyInfoDict('http://localhost/mypath'))

# Generated at 2022-06-12 16:37:35.920885
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = b'\x00\x00\x00\x10\x61\x73\x72\x74\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x32'
    flv_reader = FlvReader(data)
    assert flv_reader.read_asrt() == {'segment_run': [(1, 1), (50, 1)]}


# Generated at 2022-06-12 16:37:48.070971
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:37:55.142594
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    f4mFD = F4mFD()
    f4mFD.ydl.warn_function = lambda s : print(s)
    f4mFD.ydl.simulate = False
    f4mFD.params['test'] = True
    filename = 'test.flv'
    info_dict = {'url' : 'http://video.rtl.fr/emissions/journal/1267190554001/journal-du-dimanche-23-aout-2015-journal-du-dimanche-23-aout-2015--1267190554001.f4m'}
    assert f4mFD.real_download(filename, info_dict), 'F4mFD._real_download() failed.'



# Generated at 2022-06-12 16:38:08.883484
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:38:17.358091
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:38:50.617402
# Unit test for function write_flv_header
def test_write_flv_header():
    from StringIO import StringIO
    stream = StringIO()
    write_flv_header(stream)
    res = stream.getvalue()
    assert res == b'FLV\x01\x05\x00\x00\x00\t\x00\x00\x00\x00'



# Generated at 2022-06-12 16:38:54.509638
# Unit test for function write_flv_header
def test_write_flv_header():
    import io
    import binascii
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == binascii.a2b_hex('464c5610000001050000000900000000')

# Generated at 2022-06-12 16:38:57.791723
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-12 16:39:01.197819
# Unit test for function write_flv_header
def test_write_flv_header():
    from io import BytesIO
    stream = BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-12 16:39:07.943438
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    data = b'\x07mojito\x00\x0bmojitotwinc\x00\x00'
    flv_reader = FlvReader(data)
    assert flv_reader.read_string() == b'mojito'
    assert flv_reader.read_string() == b'mojitotwinc'
    assert flv_reader.read_string() == b''



# Generated at 2022-06-12 16:39:17.698767
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-12 16:39:28.261074
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-12 16:39:33.304684
# Unit test for function remove_encrypted_media

# Generated at 2022-06-12 16:39:39.322880
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    import tempfile
    with tempfile.NamedTemporaryFile(mode='wb') as out:
        metadata = b'\x12\x12\x12\x12'
        write_metadata_tag(out, metadata)
        out.seek(0)
        assert out.read() == b'\x12' + b'\x00\x00\x04' + b'\x00\x00\x00\x00\x00\x00\x00' + metadata + b'\x00\x00\x00\x0f'



# Generated at 2022-06-12 16:39:51.291734
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import os
    import sys
    if sys.version_info < (3,):
        import urllib as compat_urllib_request
        compat_urlparse = compat_urllib_parse
        compat_str = unicode
    else:
        import urllib.request as compat_urllib_request
        import urllib.parse as compat_urlparse
        compat_str = str
    import tempfile
    import shutil
    # delete the tempfile if it exists.

# Generated at 2022-06-12 16:41:45.218520
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:41:56.120928
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = b'\x00\x00\x00\xB8' + b'asrt' + b'\x00\x00\x00\x00' + \
        b'\x00\x00\x00\x01' + b'\x00\x00\x00\x00' + \
        b'\x00\x00\x00\x02' + \
        b'\x00\x00\x00\x00' + \
        b'\x00\x00\x00\x00' + \
        b'\x00\x00\x00\x01' + \
        b'\x00\x00\x00\x02'

    box = FlvReader(data).read_asrt()

# Generated at 2022-06-12 16:42:05.507377
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    from ..compat import compat_struct_pack
    from ..utils import encode_data_uri
    data = b'\x00\x00\x00\x20'  #Size 0x20
    data += b'abst'  # Box Type
    data += b'\x00\x00\x00\x08'  #Box data
    data = encode_data_uri(data, 'text/plain')
    reader = FlvReader(data)
    box_info = reader.read_box_info()
    assert box_info[0] == 32  # box_size
    assert box_info[1] == b'abst'  # box_type
    assert len(box_info[2]) == 8  # box_data size



# Generated at 2022-06-12 16:42:11.542736
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    metadata = b'\x00\x00'
    metadata_tag = b'\x12\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00' + metadata + b'\x00\x00\x00\x14'
    stream = io.BytesIO()
    write_metadata_tag(stream, metadata)
    assert(stream.getvalue() == metadata_tag)

# Generated at 2022-06-12 16:42:22.172360
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    from xml.etree.ElementTree import fromstring

# Generated at 2022-06-12 16:42:28.052162
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    tests = [
        (b'abc\x00', 'abc'),
        (b'abc\x00\x00', 'abc'),
        (b'\x00', ''),
        (b'\x00\x00', ''),
        (b'ab\x00cd\x00', 'ab'),
    ]
    for data, expected in tests:
        reader = FlvReader(data)
        res = reader.read_string()
        assert res == expected, 'For %r and %r, %r should equal %r' % (
            data, expected, res, expected)



# Generated at 2022-06-12 16:42:37.471685
# Unit test for function build_fragments_list
def test_build_fragments_list():
    def test_fragments_list(boot_info, result):
        assert build_fragments_list(boot_info) == result
    # BootInfo version 2

# Generated at 2022-06-12 16:42:42.047238
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from .common import update_url_query
    from .fragment import FragmentProcessor
    from .utils import sanitize_open
    import pytest
    import sys
    from io import BytesIO

    # Unit test body
    F4mFD.real_download.im_func(
        None,
        None,
        {
            'url': None,
            'tbr': None,
            'frag_index': 0,
            'infos': {},
            'params': {'test': True},
            'ydl': None,
        },
    )

    real_sanitize_open = sanitize_open
    real_update_url_query = update_url_query
    real_FragmentProcessor_process = FragmentProcessor.process.im_func
    real_F4mFD

# Generated at 2022-06-12 16:42:47.321200
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    ret = io.BytesIO()
    write_metadata_tag(ret, b'metadata')
    assert ret.getvalue() == b'\x12\x00\x00\x0b\x00\x00\x00\x00\x00\x00\x00metadata\x00\x00\x00\x1a'



# Generated at 2022-06-12 16:42:52.040686
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    # Init object
    reader = FlvReader(compat_b64decode(b'AArVwNQQAAGq5NgAAfEAABzRt/Rp/X9f0B/OIHgA=='))
    # Expected result
    result = {
        'segment_run': [
            (1, 2),
            (3, 1),
        ]
    }

    # Call function
    res = reader.read_asrt()

    assert result == res

