

# Generated at 2022-06-12 16:34:31.047506
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    assert FlvReader(b'\x06\x00\x00\x00abcd\x00efg\x00hi\x00').read_string() == b'abcd'



# Generated at 2022-06-12 16:34:43.380180
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    fragments_data = (
        # first, ts, duration, discontinuity_indicator
        (0, 0, 0, None),
        (1, 0, 10, None),
        (2, 0, 0, 5),
    )

# Generated at 2022-06-12 16:34:54.895928
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader = FlvReader(b'\x00\x00\x00\x1b\x61\x66\x72\x74\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01')
    afrt = flv_reader.read_afrt()
    assert afrt['fragments'][0]['first'] == 1
    assert afrt['fragments'][0]['ts'] == 1
    assert afrt['fragments'][0]['duration'] == 1

# Generated at 2022-06-12 16:35:02.179232
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    data = b"""
asrt
afrt
"""
    info = FlvReader(data).read_abst()
    assert info['segments'][0]['segment_run'][0][0] == 0
    assert info['segments'][1]['segment_run'][0][0] == 0
    assert info['fragments'][0]['fragments'][0]['first'] == 0
    assert info['fragments'][1]['fragments'][0]['first'] == 0



# Generated at 2022-06-12 16:35:10.580671
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    class DummyYDL(object):
        def __init__(self, *args, **kwargs):
            self.params = {'test': False}

        class FileDownloader(object):
            def __init__(self, *args, **kwargs):
                pass

            def report_warning(self, *args, **kwargs):
                pass

            def to_screen(self, *args, **kwargs):
                pass

            def report_error(self, *args, **kwargs):
                raise NotImplementedError()

            def urlopen(self, *args, **kwargs):
                raise NotImplementedError()

    class DummyInfoDict(object):
        def __init__(self, url):
            self.url = url

    # test_manifest_url = 'https://mnmedias.api

# Generated at 2022-06-12 16:35:21.909613
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        """
        <manifest xmlns="http://ns.adobe.com/f4m/1.0">
            <baseURL>http://example.com/</baseURL>
        </manifest>
        """)
    assert get_base_url(manifest) == 'http://example.com/'
    manifest = compat_etree_fromstring(
        """
        <manifest xmlns="http://ns.adobe.com/f4m/2.0">
            <baseURL>http://example.com/path/</baseURL>
        </manifest>
        """)
    assert get_base_url(manifest) == 'http://example.com/path/'

# Generated at 2022-06-12 16:35:27.247812
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-12 16:35:32.925403
# Unit test for method read_string of class FlvReader

# Generated at 2022-06-12 16:35:42.599429
# Unit test for function remove_encrypted_media

# Generated at 2022-06-12 16:35:46.291466
# Unit test for function build_fragments_list
def test_build_fragments_list():
    f = open('test/hds-bootstrap.bin', 'rb')
    boot_bytes = f.read()
    f.close()
    boot_info = read_bootstrap_info(boot_bytes)
    res = build_fragments_list(boot_info)
    assert res == [(0, 0), (0, 1), (0, 2)]



# Generated at 2022-06-12 16:36:35.120525
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:36:41.998678
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = read_bootstrap_info(FIXTURE_BOOTSTRAP_LIVE)
    assert build_fragments_list(boot_info)[-2:] == [(1520, 1083), (1520, 1084)]
    boot_info = read_bootstrap_info(FIXTURE_BOOTSTRAP_VOD)
    assert build_fragments_list(boot_info) == [(1, 1), (1, 2)]



# Generated at 2022-06-12 16:36:54.152858
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:37:03.740535
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:37:15.755484
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import sys
    path = sys.argv[1]
    if len(sys.argv) > 2:
        test_data = open(sys.argv[2], 'rb').read()
    else:
        test_data = None

    # Test if you can run a download using the class
    import youtube_dl

    class MyYDL(youtube_dl.YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MyYDL, self).__init__(*args, **kwargs)
            self.cache = {}


# Generated at 2022-06-12 16:37:26.470282
# Unit test for function build_fragments_list
def test_build_fragments_list():
    bootstrap_info = {
        'segments': [
            {
                'segment_run': [
                    (1, 2),
                    (2, 3),
                ],
            },
        ],
        'fragments': [
            {
                'fragments': [
                    {
                        'first': 30,
                        'ts': 0,
                        'duration': 2000,
                        'discontinuity_indicator': None
                    },
                ],
            },
        ],
        'live': False,
    }
    assert build_fragments_list(bootstrap_info) == [(1, 30), (1, 31), (2, 32), (2, 33), (2, 34)]


# Generated at 2022-06-12 16:37:37.530423
# Unit test for function build_fragments_list
def test_build_fragments_list():
    from .test import read_test_data

    # The bootstrap info comes from http://www.dailymotion.com/cdn/H264-1400x1050/video/xzvo0a.mp4
    bootstrap_byte = read_test_data('cnn-live-bootstrap.bytes')
    boot_info = read_bootstrap_info(bootstrap_byte)
    assert boot_info['live'] is True
    assert build_fragments_list(boot_info)[-2:] == [(0, 26), (0, 27)]

    # The bootstrap info comes from http://www.dailymotion.com/cdn/H264-854x480/video/x3nptxs.mp4
    bootstrap_byte = read_test_data('dailymotion-bootstrap.bytes')
    boot_info = read_bootstrap

# Generated at 2022-06-12 16:37:49.533246
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    test_data1 = b'\x00\x00\x00\x0c\xab\xcd\xef\x00\x00\x00\x00\x12\x34\x56\x78'
    flvreader = FlvReader(test_data1)
    box_info = flvreader.read_box_info()
    assert box_info[0] == 12
    assert box_info[1] == b'\xab\xcd\xef'
    assert box_info[2] == b'\x00\x00\x00\x00\x12\x34\x56\x78'


# Generated at 2022-06-12 16:37:56.191345
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-12 16:38:09.757073
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    import base64

# Generated at 2022-06-12 16:38:33.289515
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:38:36.812108
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    reader = FlvReader(b'\x01test1test2\x00test3')
    assert reader.read_string() == b'\x01test1test2'
    assert reader.read_string() == b'test3'



# Generated at 2022-06-12 16:38:47.229238
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import sys
    import io
    import unittest
    import webvtt
    import datetime
    import test_utils

    class Test_F4mFD(unittest.TestCase):

        # mocks and fake data
        def setUp(self):
            self.mock_urlopen = test_utils.mock_urlopen()
            F4mFD._download_fragment = lambda x, y, z: (True, 'test_data')
            self._prepare_frag_download = lambda x: None
            self._start_frag_download = lambda x: None
            self._append_fragment = lambda x, y: None
            self._finish_frag_download = lambda x: None

# Generated at 2022-06-12 16:38:57.001348
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    from xml.etree import ElementTree as etree

# Generated at 2022-06-12 16:39:03.761991
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    from ..compat import compat_etree_Element

    assert remove_encrypted_media([]) == []
    assert remove_encrypted_media([compat_etree_Element('media')]) == [
        compat_etree_Element('media')]
    assert remove_encrypted_media([compat_etree_Element(
        'media', attrib={'drmAdditionalHeaderId': 'head1'})]) == []
    assert remove_encrypted_media([
        compat_etree_Element('media-1', attrib={'drmAdditionalHeaderId': 'head1'}),
        compat_etree_Element('media-2'),
        compat_etree_Element(
            'media-3', attrib={'drmAdditionalHeaderSetId': 'head1'}),
    ]) == [compat_etree_Element('media-2')]




# Generated at 2022-06-12 16:39:09.926326
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    with io.open('test/test.bootstrap', 'rb') as f:
        abst = FlvReader(f.read()).read_bootstrap_info()

# Generated at 2022-06-12 16:39:19.785363
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():

    def check_error(box_data, errmsg):
        try:
            FlvReader(box_data).read_afrt()
        except IndexError as e:
            assert str(e) == errmsg

    # Test case 1

# Generated at 2022-06-12 16:39:27.993032
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    def _test_FlvReader_read_abst(filename):
        data = open(filename, 'rb').read()
        assert len(data) > 0
        info = FlvReader(data).read_bootstrap_info()
        assert info['fragments'][0]['fragments'][-1]['first'] == 16
        assert info['fragments'][0]['fragments'][-1]['duration'] == 10

    _test_FlvReader_read_abst('test/test.bootstrap')
    _test_FlvReader_read_abst('test/test2.bootstrap')



# Generated at 2022-06-12 16:39:37.763294
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    reader1 = FlvReader(open('test/test_video/test_asrt.bin', 'rb').read())
    assert reader1.read_asrt() == {'segment_run':
        [(0, 1),
         (1, 1),
         (2, 1),
         (3, 1),
         (4, 1),
         (5, 1),
         (6, 1)]
    }
    reader2 = FlvReader(open('test/test_video/test_asrt2.bin', 'rb').read())
    assert reader2.read_asrt() == {'segment_run':
        [(0, 1),
         (1, 2),
         (3, 2),
         (5, 1)]
    }

# Generated at 2022-06-12 16:39:48.775416
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from .common import FakeFD
    from .aes import aes_cbc_decrypt
    from .mp4 import Mp4Reader

    # Example from http://www.adobe.com/devnet-docs/f4v/bootstrapinfo.html