

# Generated at 2022-06-12 16:34:18.137659
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    """
    Test case for F4mFD class.
    """
    manifest = read_file('f4m_tests/manifest.f4m')
    bootstrap = read_file('f4m_tests/bootstrap.abst')
    bootstrap_info = read_bootstrap_info(bootstrap)
    base_url = 'https://example.com/'
    url_data1 = read_file('f4m_tests/root_url_data1.dat')
    url_data2 = read_file('f4m_tests/root_url_data2.dat')
    url_data3 = read_file('f4m_tests/root_url_data3.dat')
    url_data4 = read_file('f4m_tests/root_url_data4.dat')
    expected_dest_

# Generated at 2022-06-12 16:34:23.531973
# Unit test for constructor of class F4mFD
def test_F4mFD():
    fd = F4mFD(None)
    assert fd.ext == fd.manifest_url_ext == 'f4m'
    assert fd.params == {
        'noprogress': True,
    }
    assert fd.logger.name == "F4mFD"



# Generated at 2022-06-12 16:34:28.958838
# Unit test for function build_fragments_list
def test_build_fragments_list():
    def assert_fragments_list(bootstrap_info, expected_fragments):
        fragments = build_fragments_list(bootstrap_info)
        if fragments != expected_fragments:
            import pprint
            pp = pprint.PrettyPrinter(indent=1)
            print('Expected fragments:')
            pp.pprint(expected_fragments)
            print('Actual fragments:')
            pp.pprint(fragments)
        assert fragments == expected_fragments


# Generated at 2022-06-12 16:34:41.049892
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    import os
    import unittest
    
    class TestFlvReader_read_asrt(unittest.TestCase):
        @unittest.skipIf(not os.path.exists('test/test.abst'), 'The abst file is not in current directory.')
        def test_read(self):
            res = FlvReader(open('test/test.abst', 'rb').read()).read_bootstrap_info()

# Generated at 2022-06-12 16:34:53.016357
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    if not os.path.exists('tests'):
        os.mkdir('tests')
    url = 'http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8'
    ydl_opts = {
        'quiet': True,
        'outtmpl': u'tests/test_f4m_%(ext)s',
        'format': 'best'
    }
    expected_files = ['test_f4m_f1.mp4',
                      'test_f4m_f2.mp4',
                      'test_f4m_f3.mp4',
                      'test_f4m_f4.mp4',
                      'test_f4m_f5.mp4']

# Generated at 2022-06-12 16:35:01.661960
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:35:08.782741
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # no manifest specified
    manifest = None
    assert not F4mFD().real_download(None, manifest)

    # manifest doesn't exist
    manifest = []
    assert not F4mFD().real_download(None, manifest)

    # manifest doesn't contain any media info
    manifest = {'media': []}
    assert not F4mFD().real_download(None, manifest)

    # manifest contains media info
    manifest = {'media': ['media']}
    assert F4mFD().real_download(None, manifest)

    # manifest contains media info and error should occur
    manifest = {'media': 'media', 'params': {'error': True}}
    with pytest.raises(Exception):
        F4mFD().real_download(None, manifest)



# Generated at 2022-06-12 16:35:20.090861
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:35:31.363633
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    import os
    test_case = './test/test_data/test.abst'
    with open(test_case, 'rb') as f:
        abst = FlvReader(f.read()).read_bootstrap_info()
        assert abst['segments'] == [{'segment_run': [(0, 15)]}]

# Generated at 2022-06-12 16:35:37.904614
# Unit test for constructor of class F4mFD
def test_F4mFD():
    stream_name = "test"
    ydl = YoutubeDL({'skip_download': True, 'logger': YoutubeDL.FileLogger('/dev/null')})
    D = F4mFD(stream_name, ydl)
    assert D.name == stream_name
    assert D.fd.stream == stream_name
    assert D.fd.ydl == ydl

if __name__ == '__main__':
    test_F4mFD()

# Generated at 2022-06-12 16:36:29.397848
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    """
    f4m_fd_test.py:Unit test for method real_download of class F4mFD.
    """
    # test_F4mFD_real_download begin
    return True
# test_F4mFD_real_download end

# Generated at 2022-06-12 16:36:40.850963
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    import xml.etree.ElementTree as ET
    xml = """<media>
                <media>
                    <media>
                        <media drmAdditionalHeaderId="foo" drmAdditionalHeaderSetId="bar"/>
                        <media drmAdditionalHeaderId="foo" drmAdditionalHeaderSetId="bar"/>
                    </media>
                    <media>
                        <media />
                        <media drmAdditionalHeaderId="foo" drmAdditionalHeaderSetId="bar"/>
                        <media />
                    </media>
                    <media/>
                </media>
                <media>
                    <media />
                </media>
                <media/>
            </media>"""

# Generated at 2022-06-12 16:36:45.565113
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring('''
    <manifest xmlns="http://ns.adobe.com/f4m/1.0">
        <baseURL>this_is_baseurl_v1_0</baseURL>
    </manifest>
    ''')
    base_url = get_base_url(manifest)
    assert base_url == 'this_is_baseurl_v1_0'


# Generated at 2022-06-12 16:36:58.572240
# Unit test for function get_base_url
def test_get_base_url():
    assert get_base_url(compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0"/>')) is None
    assert get_base_url(compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0"><baseURL>BASE </baseURL></manifest>')) == 'BASE'
    assert get_base_url(compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/2.0">'
        '<baseURL>BASE </baseURL></manifest>')) == 'BASE'

# Generated at 2022-06-12 16:37:11.014935
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media_list = list()
    video_element = compat_etree_fromstring('<video bootstrapInfoId="1" bitrate="3298" codec="h264" '
                                            'height="240" language="eng" url="https://something/ab.mp4" '
                                            'width="426" />')
    media_list.append(video_element)
    audio_element = compat_etree_fromstring('<video bootstrapInfoId="1" bitrate="3298" codec="h264" '
                                            'height="240" language="eng" url="https://something/ab.mp4" '
                                            'width="426" drmAdditionalHeaderId="abc" drmAdditionalHeaderSetId="cde"/>')
    media_list.append(audio_element)

# Generated at 2022-06-12 16:37:22.880384
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv_file_path = 'test_flvs/test.bootstrap.vod'
    reader = FlvReader(open(flv_file_path, 'rb').read())
    bootstrap_info = reader.read_bootstrap_info()

# Generated at 2022-06-12 16:37:33.007963
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = b'\x00\x00\x00\x1D\x61\x73\x72\x74\x00\x00\x00\x00\x00\x00\x00\x01\x65\x6E\x67\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    assert FlvReader(data).read_asrt() == {
        'segment_run': [],
    }


# Generated at 2022-06-12 16:37:41.873400
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    with open('testdata/bootstrap.abst', 'rb') as abst:
        data = abst.read()
    bootstrap_info = FlvReader(data).read_bootstrap_info()
    assert len(bootstrap_info['segments']) == 1
    assert len(bootstrap_info['fragments']) == 1
    assert bootstrap_info['live'] == True
    assert len(bootstrap_info['segments'][0]['segment_run']) == 1
    assert len(bootstrap_info['fragments'][0]['fragments']) == 2



# Generated at 2022-06-12 16:37:52.491557
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:38:05.803276
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:38:29.686371
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:38:39.104218
# Unit test for function remove_encrypted_media

# Generated at 2022-06-12 16:38:43.392935
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    file_path = 'media/test.f4f'
    flv_reader = FlvReader(open(file_path, 'rb').read())
    total_size, box_type, box_data = flv_reader.read_box_info()
    assert box_type == b'abst'


# Generated at 2022-06-12 16:38:53.366639
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:39:01.947809
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    f = io.BytesIO(test_bootstrap_info)
    assert FlvReader(f).read_bootstrap_info() == test_bootstrap_info_result

# Generated at 2022-06-12 16:39:13.335050
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    """ FlvReader.remove_encrypted_media
    """
    # No encrypted chunks
    assert remove_encrypted_media([]) == []
    assert remove_encrypted_media([
        compat_etree_fromstring(b'<media url="xxx.mp4"/>')]) == [
            compat_etree_fromstring(b'<media url="xxx.mp4"/>')]
    assert remove_encrypted_media([
        compat_etree_fromstring(b'<media url="xxx.mp4"/>'),
        compat_etree_fromstring(b'<media url="xxx2.mp4"/>')]) == [
            compat_etree_fromstring(b'<media url="xxx.mp4"/>'),
            compat_etree_fromstring(b'<media url="xxx2.mp4"/>')]

    # Some encrypted chunk


# Generated at 2022-06-12 16:39:23.765929
# Unit test for function build_fragments_list
def test_build_fragments_list():
    import unittest


# Generated at 2022-06-12 16:39:28.111117
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # define all the needed mocks
    class MockInfoDict:
        def __init__(self):
            self.url = 'https://example.org/file.f4m'
            self.tbr = 1337
            self.extra_param_to_segment_url = 'asdf'

    class MockYDL:
        def __init__(self):
            self.params = {'test': True}
            self.verbose = True

        def urlopen(self, url):
            class MockUrlOpen:
                def __init__(self, url):
                    self.url = url

                def geturl(self):
                    return self.url

                def read(self):
                    with open('test_data/example.f4m', 'rb') as f:
                        return f.read()

# Generated at 2022-06-12 16:39:35.958519
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    start = time.time()
    with open('tests/test.abst', 'rb') as f:
        abst = FlvReader(f.read()).read_bootstrap_info()
        assert abst['segments'][0]['segment_run'][0] == (0, 1)
        assert abst['fragments'][0]['fragments'][0]['duration'] == 5
        assert abst['live'] is False
        print('Test of FlvReader.read_bootstrap_info() passed. %d s' % (time.time() - start))


# Generated at 2022-06-12 16:39:47.157744
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:40:09.719971
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import test_data_folder
    bsi_file = test_data_folder() + '/flash/bootstrap_info.dat'
    with open(bsi_file, 'rb') as inp:
        bsi = FlvReader(inp.read()).read_bootstrap_info()
        assert bsi['segments'][0]['segment_run'][0][0] == 0
        assert bsi['segments'][0]['segment_run'][0][1] == 12
        assert bsi['segments'][0]['segment_run'][1][0] == 12
        assert bsi['segments'][0]['segment_run'][1][1] == 1
        assert bsi['fragments'][0]['fragments'][0]['first'] == 0

# Generated at 2022-06-12 16:40:21.557191
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00,\x61\x73\x72\x74\x00'
        b'\x00\x00\x00\x03\x73\x65\x67\x6d\x65\x6e\x74\x32\x00\x73\x65\x67\x6d\x65\x6e\x74\x33\x00\x73\x65\x67\x6d\x65\x6e\x74\x34\x00'
        b'\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x03\x00\x00\x00\x05'
    )
    assert Flv

# Generated at 2022-06-12 16:40:33.436508
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-12 16:40:43.412974
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-12 16:40:55.104857
# Unit test for function build_fragments_list
def test_build_fragments_list():
    segments = [{'segment_run': [(0, 2), (1, 1), (2, 1)]}]
    fragments = [{'fragments': [{'first': 0}, {'first': 2}, {'first': 3}]}]
    assert build_fragments_list({'segments': segments, 'fragments': fragments}) == [(0, 0), (0, 1), (1, 2), (2, 3)]

    live_segments = [{'segment_run': [(0, 4294967295), (1, 4294967295)]}]
    live_fragments = [{'fragments': [{'first': 0}, {'first': 1}]}]

# Generated at 2022-06-12 16:41:05.618205
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    test_data = "00000000000000000000000000000000000000000002017426f6f7374"
    test_data += "20726571756972650000000000000000000000000000000000000000"
    test_data += "00000003000000050000000c00000001746573740000000000000005"
    test_data += "0000000c00000002e803000000000000040000004d0300000000000004"
    test_data += "00000063dc000000000000040000007e390000000000000400000098"
    test_data += "9600000000000004000000b23100000000000004000000cd2d000000"
    test_data += "000000004000000e82900000000000004000000000000000004000000"
    test_data += "1a00000000000000040000003500000000000000040000004f000000"
    test_data += "0000000040000006a00000000000000040000008400000000000000"

# Generated at 2022-06-12 16:41:13.922627
# Unit test for function build_fragments_list
def test_build_fragments_list():
    import os
    import tempfile

    def build_temp_bootstrap_info(segments, fragments):
        data = (
            b'<bootstrapInfo profile="named" '
            b'live="true" update="true" '
            b'id="d12654321-63dc-4a1f-b4b4-8f54b0c0e000">'
            b'<segmentRunTable>')
        for segment, fragments_count in segments:
            data += (
                b'<segmentRun>'
                b'<initialization sourceURL="Seg1-Frag%d"/>'
                b'<segmentURL media="Seg1-Frag%d" mediaRange="801-1001"/>'
                b'</segmentRun>') % (segment, segment)

# Generated at 2022-06-12 16:41:23.451060
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {'segments': [{'segment_run': [(0, 2),
                                               (1, 3),
                                               (2, 4)]}],
                 'fragments': [{'fragments': [{'first': 0, 'ts': 0},
                                              {'first': 2, 'ts': 3},
                                              {'first': 5, 'ts': 6},
                                              {'first': 9, 'ts': 10}]}],
                 'live': False}
    assert build_fragments_list(boot_info) == [(0, 0), (0, 1),
                                               (1, 2), (1, 3), (1, 4),
                                               (2, 5), (2, 6), (2, 7), (2, 8)]

# Generated at 2022-06-12 16:41:35.113504
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    flv_reader = FlvReader(b'\x00\x00\x00\x51\x61\x73\x72\x74\x00\x00\x00\x00\x00\x01\x66\x00\x00\x00\x04\x73\x65\x67\x6d\x00\x00\x00\x01\x00\x00\x00\x03\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00')
    asrt_info = flv_reader.read_asrt()
    assert asrt_info['segment_run'] == [(1, 1)]


# Generated at 2022-06-12 16:41:38.438701
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Assign parameter values
    filename = 'filename'
    info_dict = {'url': 'man_url', 'extra_param_to_segment_url': 'extra_param_to_segment_url'}
    # Instantiate the class to be tested
    cls = F4mFD()
    # Call the method to be tested
    result = cls.real_download(filename, info_dict)
    assert result == True
