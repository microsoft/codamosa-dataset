

# Generated at 2022-06-12 16:34:16.250321
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-12 16:34:23.238384
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-12 16:34:34.741822
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:34:46.356354
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    module_name = 'youtube_dl.downloader.f4m'
    def test_real_download(self, ydl, filename, info_dict):
        fd = F4mFD(ydl, info_dict)
        return fd.real_download(filename, info_dict)
    setattr(F4mFD, '_real_extract', test_real_download)

# Generated at 2022-06-12 16:34:57.157426
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:35:06.366571
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'segments': [
            {
                'segment_run': [
                    (0, 2),
                    (5, 3),
                ],
            }
        ],
        'fragments': [
            {
                'fragments': [
                    {'first': 1},
                    {'first': 4},
                ],
            }
        ],
        'live': False,
    }
    assert build_fragments_list(boot_info) == [
        (0, 1),
        (0, 2),
        (5, 4),
        (5, 5),
        (5, 6),
    ]



# Generated at 2022-06-12 16:35:11.460826
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    assert not f4mFD.real_download('filename',{'url':'http://cdnbakmi.kaltura.com/p/1326572/sp/132657200/playManifest/entryId/1_usoi9e7h/flavorIds/1_cr6luzeg,1_je19idjh,1_2y9zex8v,1_x4xhmzgf,1_3qe4q2dt,1_mfevzyzu/deliveryProfileId/16698/protocol/http/format/applehttp/a.m3u8','hls_prefer_native':False})
#tests
    

# Generated at 2022-06-12 16:35:22.540294
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'live': False,
        'segments': [
            {
                'segment_run': [(0, 1), (1, 1)],
            },
        ],
        'fragments': [
            {
                'fragments': [
                    {'first': 0, 'ts': 0, 'duration': 5, 'discontinuity_indicator': None},
                    {'first': 1, 'ts': 5, 'duration': 4, 'discontinuity_indicator': 0},
                    {'first': 2, 'ts': 9, 'duration': 0, 'discontinuity_indicator': 0},
                ],
            },
        ],
    }
    assert build_fragments_list(boot_info) == [(0, 0), (1, 1), (1, 2)]




# Generated at 2022-06-12 16:35:34.166820
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:35:43.479178
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-12 16:36:15.770554
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from .extractor.common import InfoExtractor
    from .utils import FakeYdl
    from .downloader import DownloadContext

    def _download_fragment(ctx, url):
        return True

    def _append_fragment(ctx, data):
        pass

    def _finish_frag_download(ctx):
        pass

    def _prepare_frag_download(ctx):
        ctx['dest_stream'] = io.BytesIO()

    ctx = DownloadContext()
    ctx['ie'] = InfoExtractor()
    ctx['ydl'] = FakeYdl()
    ctx['frag_index'] = 0
    ctx['complete_frags_downloaded_bytes'] = 0

    def _start_frag_download(ctx):
        pass

    f4mfd = F4mFD

# Generated at 2022-06-12 16:36:27.371586
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:36:39.013003
# Unit test for method read_box_info of class FlvReader

# Generated at 2022-06-12 16:36:47.063526
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import shutil
    import tempfile
    import os

    FIELDS = {'url':
              'http://manifest.us.rtl.nl/rtlxl/network/20150219105637_13/adaptive.f4m?hdcore=3.3.0&g=MTZBMGFWZTQD',
              'id': '12',
              'http_headers': {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36'}}

    with tempfile.NamedTemporaryFile(suffix='.f4m') as tmp_file:
        tmp_dir = tempfile.mkdtemp()
        downloader

# Generated at 2022-06-12 16:36:54.625917
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    data = b'\x05\x00\x00\x00\x06test\x00\x04'
    flv_reader = FlvReader(data)
    box_size, box_type, box_data = flv_reader.read_box_info()
    assert flv_reader.read_string() == b'test'
    assert flv_reader.read_string() == b''



# Generated at 2022-06-12 16:37:03.984588
# Unit test for function write_metadata_tag

# Generated at 2022-06-12 16:37:16.001194
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
      b'\x00\x00\x00\x3D\x61\x73\x72\x74'
      b'\x01\x00\x00\x00\x01\x00\x00\x00'
      b'\x2F\x00\x00\x00\x00\x00\x00\x00'
      b'\x1F\x00\x00\x00\x00\x00\x00\x00'
      b'\x00\x00\x00\x00\x00\x00\x00\x00'
      b'\x00\x00\x00\x00\x00\x00\x00\x00'
    )
    flv_reader = FlvReader(data)
   

# Generated at 2022-06-12 16:37:26.669750
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    f = io.BytesIO(
        compat_struct_pack('!IB4sB7s', 8, b'abcd', b'test') +
        compat_struct_pack('!Q', 20) +
        compat_struct_pack('!IB4sB7s', 8, b'abcd', b'efg') +
        compat_struct_pack('!Q', 32) +
        compat_struct_pack('!IB4sB7s', 8, b'abcd', b'hij')
    )
    flv_reader = FlvReader(f)
    assert flv_reader.read_box_info() == (
        8, b'abcd', compat_struct_pack('!B7s', b'test'))

# Generated at 2022-06-12 16:37:37.719709
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:37:49.749323
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    """
    Function tests if the real_download method of the F4mFD 
    class is working properly.
    """
    fd = F4mFD()
    def report_warning(self, msg):
        print("Warning: " + msg)
    def report_error(self, msg):
        print("Error: " + msg)
    def ydl_urlopen(self, url):
        return ""
    def urlopen(self, url):
        return ""
    def _prepare_url(self, info_dict, man_url):
        return man_url
    fd.report_warning = report_warning.__get__(fd)
    fd.report_error = report_error.__get__(fd)
    fd.ydl_urlopen = ydl_urlopen.__get__(fd)


# Generated at 2022-06-12 16:38:14.812718
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x00'  # size 0
        b'\x40\x15\x00\x00'  # asrt
        b'\x00'  # Version 0
        b'\x00\x00\x00'  # Flags 0
        b'\x01'  # QualityEntryCount
        b'video' b'\x00'  # QualitySegmentUrlModifiers
        b'\x00\x00\x00\x01'  # SegmentRunEntryCount
        b'\x00\x00\x00\x67'  # FirstSegment
        b'\x00\x00\x00\x03'  # FragmentsPerSegment
    )
    reader = FlvReader(data)
    assert reader.read_

# Generated at 2022-06-12 16:38:27.954889
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
# Based on pyamf/util/__init__.py by:
# Copyright (c) 2006-2009, Nicolas Lehuen, BSD licence
# Based on http://codespeak.net/svn/lxml/trunk/src/lxml/etree.c
# lxml is Copyright (c) 2004-2008 Infrae. All rights reserved.
# See LICENSE.txt for details.
    class DummyImporter(object):
        """
        Dummy Importer class to replace PyAMF importer,
        since PyAMF is not a dependency for youtube-dl
        """
        def load_module(self, fullname):
            if fullname in sys.modules:
                return sys.modules[fullname]

            return sys.modules.setdefault(
                fullname, types.ModuleType(fullname))


# Generated at 2022-06-12 16:38:37.588077
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:38:48.257569
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from .common import FakeFD
    from .downloader import FakeYDL

    test_f4m_url = "http://test_f4m.com/test.f4m"
    test_f4m_manifest = (
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0"><baseURL>http://test_f4m.com/</baseURL><bootstrapInfo profile="named" url="bootstrap001.abst"/></manifest>'
    )

    ydl = FakeYDL()
    fd = F4mFD(ydl, {'url': test_f4m_url, 'format': 'fakefmt'})
    ydl.urlopen = lambda *args: FakeFD(test_f4m_manifest)
    ydl.prepare_filename

# Generated at 2022-06-12 16:38:57.783319
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-12 16:39:09.469435
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:39:19.092074
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..compat import compat_urllib_request
    with compat_urllib_request.urlopen(
            'http://devimages.apple.com/iphone/samples/bipbop/gear1/prog_index.m3u8'
    ) as manifest:
        manifest_str = manifest.read()
    assert manifest_str.startswith(b'#EXTM3U\n#EXT-X-TARGETDURATION:')
    manifest_str = manifest_str.split(b'#EXT-X-BOOTSTRAP:')[1].split(b'\n')[0]
    bs_info = FlvReader(compat_b64decode(manifest_str.decode('ascii'))).read_bootstrap_info()

# Generated at 2022-06-12 16:39:29.429665
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    """
    Test the FlvReader.read_asrt() method
    """

# Generated at 2022-06-12 16:39:38.999355
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    import xml.etree.ElementTree as ET
    sample = '''<Media sequence="0" url="videourl.f4m" bootstrapInfoId="bootstrap0"/>
                <Media sequence="0" url="videourl.f4m" bootstrapInfoId="bootstrap0" drmAdditionalHeaderSetId="1" drmAdditionalHeaderId="1"/>
                <Media sequence="0" url="videourl.f4m" bootstrapInfoId="bootstrap0"/>'''
    et = ET.XML(sample)
    media_list = et.findall('.//media')
    media_list_filtered = remove_encrypted_media(media_list)
    assert len(media_list_filtered) == 2
    assert media_list[0] == media_list_filtered[0]

# Generated at 2022-06-12 16:39:50.640370
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    with open('test/test_files/test.abst', 'rb') as abst_file:
        abst_data = abst_file.read()

# Generated at 2022-06-12 16:40:11.267003
# Unit test for function get_base_url
def test_get_base_url():
    text = fix_xml_ampersands('''<?xml version="1.0" encoding="utf-8" ?>
<manifest xmlns="http://ns.adobe.com/f4m/2.0">
    <baseURL>http://example.org/</baseURL>
</manifest>''')
    xml_tree = compat_etree_fromstring(text)
    base_url = get_base_url(xml_tree)
    assert base_url == 'http://example.org/'


# Generated at 2022-06-12 16:40:23.499623
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:40:30.085927
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    fd = F4mFD()
    info_dict = {'url': 'http://www.youtube.com/watch?v=y1iGZPgLMr8', 'tbr': 1998, 'extra_param_to_segment_url': 'testParam'}
    fd.real_download('/tmp/test.flv', info_dict)
test_F4mFD_real_download()



# Generated at 2022-06-12 16:40:39.058043
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    # The following file was downloaded from
    # https://video.twimg.com/ext_tw_video/477039005562146816/pu/pl/538e4.flv
    with open('pl/538e4.flv', 'rb') as f:
        flv = FlvReader(f.read())
    info = flv.read_bootstrap_info()
    assert len(info['segments']) == 1
    assert len(info['segments'][0]['segment_run']) == 1
    assert info['segments'][0]['segment_run'][0] == (0, 1)
    assert len(info['fragments']) == 1
    fragments = info['fragments'][0]['fragments']
    assert len(fragments) == 2
   

# Generated at 2022-06-12 16:40:50.129229
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-12 16:41:01.606618
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:41:11.464994
# Unit test for function get_base_url
def test_get_base_url():
    manifest_template = '''
    <manifest xmlns="http://ns.adobe.com/f4m/2.0">
      <baseURL>%s</baseURL>
    </manifest>
    '''
    base_url = 'http://example.com/'
    expected_url = base_url.strip()
    manifest_string = manifest_template % base_url
    manifest = compat_etree_fromstring(manifest_string)
    assert expected_url == get_base_url(manifest)

    manifest_template = '''
    <manifest xmlns="http://ns.adobe.com/f4m/1.0">
      <baseURL>%s</baseURL>
    </manifest>
    '''
    manifest_string = manifest_template % base_url
    manifest = compat_et

# Generated at 2022-06-12 16:41:20.219209
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring('<manifest xmlns="http://ns.adobe.com/f4m/2.0"><baseURL>http://foo.bar/</baseURL></manifest>')
    assert get_base_url(manifest) == 'http://foo.bar/'

    manifest = compat_etree_fromstring('<manifest xmlns="http://ns.adobe.com/f4m/2.0"><baseURL/></manifest>')
    assert get_base_url(manifest) == ''

    manifest = compat_etree_fromstring('<manifest xmlns="http://ns.adobe.com/f4m/2.0"><baseURL>http://foo.bar/</baseURL>'
                                       '<baseURL>http://baz.bar/</baseURL></manifest>')


# Generated at 2022-06-12 16:41:24.572131
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    f = FlvReader(b'string1\x00string2\x00string3\x00')
    assert f.read_string() == b'string1'
    assert f.read_string() == b'string2'
    assert f.read_string() == b'string3'


# Generated at 2022-06-12 16:41:37.070276
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-12 16:42:07.302880
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-12 16:42:08.744446
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    utils_testing.F4mFD_test(F4mFD)


# Generated at 2022-06-12 16:42:18.551689
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x04\x13'
        b'\x00\x00\x00\x01'
        b'\x01'
        b'\x00\x00\x00\x00'
        b'\x00\x00\x00\x02'
        b'\x00\x00\x00\x00\x00\x00\x00\x00'
        b'\x00\x00\x00\x00\x00\x00\x00\x01'
    )

    f = FlvReader(data)
    f.read_asrt()


# Generated at 2022-06-12 16:42:26.840616
# Unit test for function build_fragments_list

# Generated at 2022-06-12 16:42:32.085170
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    import binascii

# Generated at 2022-06-12 16:42:42.346495
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..compat import compat_str

    # This test case is generated from youtube-dl test case
    # test_parse_bootstrap_info of test_extractor

# Generated at 2022-06-12 16:42:51.445714
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-12 16:43:02.241256
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    def run_test_case(input, expected):
        assert FlvReader(input).read_asrt() == expected
    run_test_case(
        # input
        b'\x00\x00\x00\x18\x61\x73\x72\x74\x01\x00\x00\x00'
        b'\x00\x63\x68\x75\x6E\x6B\x0A\x00\x00\x00'
        b'\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00'
        b'\x00\x00\x00\x05',
        # expected
        {
            'segment_run': [(0, 5)]
        }
    )
   

# Generated at 2022-06-12 16:43:09.458989
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = b"\x00\x00\x00\x2A\x61\x73\x72\x74\x05\x73\x65\x67\x6d\x65\x6E\x00\x00\x00\x01\x00\x00\x00\x01\x00\x04\x00\x01\x00\x00\x00\x01"
    result = FlvReader(data).read_asrt()
    assert result
    assert result['segment_run'] == [(1,1)]



# Generated at 2022-06-12 16:43:18.978405
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from .extractor import gen_extractors
    from .common import mock_f4m_manifest
    from .downloader import Downloader
    import io

    downloader = Downloader(gen_extractors())
    test_filename = 'test_F4mFD_real_download.test'
    expected_test_filename = 'test_F4mFD_real_download.test.!qb'

    with open(expected_test_filename, 'rb') as expected_stream:
        with io.open(test_filename, 'wb') as test_stream:
            f4m_manifest = mock_f4m_manifest()
            stream_urlh = fake_urlopen(f4m_manifest)
            stream_url = stream_urlh.geturl()