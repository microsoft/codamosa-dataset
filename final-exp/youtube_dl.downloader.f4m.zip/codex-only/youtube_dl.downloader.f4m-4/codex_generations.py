

# Generated at 2022-06-24 11:42:20.114967
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    read_unsigned_int = FlvReader(compat_struct_pack('!I', 0x01020304)).read_unsigned_int
    assert read_unsigned_int() == 0x01020304



# Generated at 2022-06-24 11:42:29.107557
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    test_metadata = b'test metadata'
    stream = io.BytesIO()
    write_flv_header(stream)
    write_metadata_tag(stream, test_metadata)
    stream.seek(0)
    assert b'FLV' == stream.read(3)
    # version
    assert stream.read(1) == b'\x01'
    # flags
    assert stream.read(1) == b'\x05'
    # header_size
    assert stream.read(4) == b'\x00\x00\x00\x09'
    # defined tag
    assert stream.read(1) == b'\x12'
    assert stream.read(3) == compat_struct_pack('!I', len(test_metadata))[1:]
    # timestamp

# Generated at 2022-06-24 11:42:31.615323
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    flv = FlvReader(b'\x00\x00\x00\x04\x00\x00\x00\x05')
    assert flv.read_unsigned_int() == 4
    assert flv.read_unsigned_int() == 5



# Generated at 2022-06-24 11:42:37.586502
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    from .smil import parse_smil_stream_data
    base_url = 'http://example.com/manifest.f4m'
    url = 'http://example.com/manifest.f4m?foo=bar'
    display_id = 'http_example_com_manifest_f4m'

# Generated at 2022-06-24 11:42:48.120929
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:42:56.887048
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    for i in range(2 ** 24):
        stream = io.BytesIO()
        write_unsigned_int_24(stream, i)
        stream.seek(0)
        assert i == compat_struct_unpack('!I', stream.read(3) + b'\x00')[0]
        assert stream.read() == b''
    for i in (2 ** 24, 2 ** 25 - 1, 2 ** 31 - 1, -2 ** 31, -1):
        stream = io.BytesIO()
        write_unsigned_int_24(stream, i)
        assert stream.getvalue() == b'\xff\xff\xff'
test_write_unsigned_int_24()



# Generated at 2022-06-24 11:43:05.485416
# Unit test for function write_flv_header
def test_write_flv_header():
    from ..utils import determine_ext
    from .fragment import FragmentFD
    from . import F4mFD
    from ..compat import BytesIO
    from ..downloader import FileDownloader
    import os
    import tempfile
    tmp_dir = tempfile.mkdtemp()
    tmp_flv_file = os.path.join(tmp_dir, 'test_write_flv_header.flv')
    def wrap_downloader(config, params):
        params_new = params.copy()
        params_new['_writetodisk'] = tmp_flv_file
        params_new['_write_to_file'] = True
        params_new['_noprogress'] = True
        params_new['_continuedl'] = False

# Generated at 2022-06-24 11:43:16.884452
# Unit test for constructor of class FlvReader
def test_FlvReader():
    # A simple FlvReader test
    test_flv = (
        b'\x00\x00\x00\x1cftypisom\x00\x00\x02\x00isomiso2avc1\x00'
        b'\x00\x00\x01\x00\x00\x00\x00\x1cmoov\x00\x00\x02\x00\x00'
        b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x1cfree\x00\x00'
        b'\x00\x00')
    reader = FlvReader(test_flv)
    # Test case for method read_unsigned_long_long
    assert reader.read_unsigned

# Generated at 2022-06-24 11:43:23.861324
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    tests = [
        (1, '\x00\x00\x00\x01'),
        (0xFFFFFFFF, '\xff\xff\xff\xff'),
        (0xFFFFFFFE, '\xff\xff\xff\xfe'),
    ]
    for test, expected in tests:
        stream = io.BytesIO()
        write_unsigned_int(stream, test)
        assert stream.getvalue() == expected



# Generated at 2022-06-24 11:43:30.266913
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    reader = FlvReader(compat_b64decode(
        'AAABAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=='))
    assert reader.read_unsigned_long_long() == 0x4142434445464748



# Generated at 2022-06-24 11:43:39.606729
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    r = read_bootstrap_info(open(
        'test/files/vod_bootstrap.abst', 'rb').read())
    assert r['live'] is False
    assert r['segments'][0]['segment_run'][0] == (0, 100)
    assert r['segments'][0]['segment_run'][1] == (1, 100)
    assert r['fragments'][0]['fragments'][0] == {
        'first': 1,
        'ts': 0,
        'duration': 10000,
        'discontinuity_indicator': None,
    }

# Generated at 2022-06-24 11:43:45.233693
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    data = compat_struct_pack('!I', 0x12345678)
    data = data[1:] + b'abc'
    stream = io.BytesIO(data)
    assert stream.read(1) == b'\x56'
    assert stream.read(1) == b'\x78'
    assert stream.read(1) == b'\x12'
    assert stream.read(3) == b'abc'



# Generated at 2022-06-24 11:43:48.965986
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    assert FlvReader(compat_struct_pack('!Q', (1 << 63) - 1)).read_unsigned_long_long() == (1 << 63) - 1



# Generated at 2022-06-24 11:43:53.752242
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    r = FlvReader(b'\x00\x01\x02\x03\x04\x05\x06\x07')
    assert 0x0001020304050607 == r.read_unsigned_long_long()



# Generated at 2022-06-24 11:44:04.525237
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from .testdata import testdata
    from .fragment import _parse_bootstrap_info

    # Download the file
    url = 'https://www.youtube.com/api/timedtext?expire=1518505304&hl=en_US&v=nfWlot6h_JM&signature=E80F1B574A1A787D50A4722FBEF3A7FD4A94A9C4.88E4E301EE5A5B5C5D5CBC8E5A5C744DB2ECD9D1'  # NOQA
    data = testdata.get_data(url)

    # Extract the bootstrap info from the first tag
    f = io.BytesIO(data)
    f.read(13)  # skip flv header
    tag_data_size

# Generated at 2022-06-24 11:44:05.857528
# Unit test for constructor of class F4mFD
def test_F4mFD():
    F4mFD(YoutubeDL())


# Generated at 2022-06-24 11:44:09.056022
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    reader = FlvReader(b'Test\x00ing')
    assert reader.read_string() == b'Test'
    assert reader.read_string() == b'ing'



# Generated at 2022-06-24 11:44:18.699385
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from .test_fragment import FRAGMENT_TEST_CASES

    for case in FRAGMENT_TEST_CASES:
        bs_info = FlvReader(compat_b64decode(case['bootstrap_info'])).read_bootstrap_info()
        assert bs_info == case['bootstrap_info_json']

    # Test an error case
    data = compat_b64decode(FRAGMENT_TEST_CASES[0]['bootstrap_info'])
    bad_data = compat_b64decode(FRAGMENT_TEST_CASES[0]['bootstrap_info'])[:-1]
    for i in range(len(data)):
        FlvReader(bad_data[:i]).read_bootstrap_info()



# Generated at 2022-06-24 11:44:23.930815
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    from io import BytesIO
    stream = BytesIO()
    write_unsigned_int(stream, 12)
    stream.seek(0)
    assert compat_struct_unpack('!I', stream.read())[0] == 12
test_write_unsigned_int()



# Generated at 2022-06-24 11:44:34.006118
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    # test with no encrypted media
    media = [
        b'<media url="http://my/url1" bootstrapInfoId="bootstrap_id"',
        b'bitrate="1000"/>',
        b'<media url="http://my/url2" bootstrapInfoId="bootstrap_id"',
        b'bitrate="2000"/>',
    ]

    media = remove_encrypted_media(
        [compat_etree_fromstring(b''.join(media))])
    assert len(media) == 2

    # test with no encrypted media

# Generated at 2022-06-24 11:44:36.489268
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    reader = FlvReader(b'\x01')
    assert reader.read_unsigned_char() == 1

# Generated at 2022-06-24 11:44:38.968453
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    test_string = b'\x99'
    reader = FlvReader(test_string)
    assert 0x99 == reader.read_unsigned_char()



# Generated at 2022-06-24 11:44:45.298248
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    with open('tests/resources/bootstrap.abst', 'rb') as f:
        result = read_bootstrap_info(f.read())
        assert result['live'] is False
        assert len(result['segments']) == 3
        assert len(result['fragments']) == 3
        for expected_fragments_count, segment in zip([15, 10, 16], result['segments']):
            assert len(segment['segment_run']) == 1
            assert segment['segment_run'][0][1] == expected_fragments_count
        for expected_fragments_count, fragments in zip([15, 10, 16], result['fragments']):
            assert len(fragments['fragments']) == expected_fragments_count

# Generated at 2022-06-24 11:44:48.350039
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    assert FlvReader(compat_struct_pack('>I', 1)).read_unsigned_int() == 1



# Generated at 2022-06-24 11:44:56.518823
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # |abst| = |size (4bytes)|box_type(4bytes)|content(8bytes)|
    input_data = b'\x00\x00\x00\x0Eabst' + b'\x00' * 8
    fr = FlvReader(input_data)
    real_size, box_type, box_data = fr.read_box_info()
    assert real_size == 0x0E
    assert box_type == b'abst'
    assert len(box_data) == 8



# Generated at 2022-06-24 11:45:06.461267
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-24 11:45:08.572899
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    assert FlvReader(compat_struct_pack('!Q', 0x1234567890abcdef)).read_unsigned_long_long() == 0x1234567890abcdef


# Generated at 2022-06-24 11:45:12.683370
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-24 11:45:16.567428
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    s = io.BytesIO()
    write_unsigned_int(s, 700)
    assert s.getvalue() == b'\x00\x00\x02\xbc'
test_write_unsigned_int()



# Generated at 2022-06-24 11:45:26.611239
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    flvreader = FlvReader(b'\x12')
    assert flvreader.read_unsigned_char() == 0x12
    assert flvreader.read_unsigned_long_long() == 0x0000000000000012
    assert flvreader.read_unsigned_int() == 0x0000000000000012
    assert flvreader.read_string() == ''
    flvreader = FlvReader(b'\x12\x23\x34\x45\x56\x67\x78\x89\x01\x00\x0a\x00\x0b\x00\x0c\x00\x0d\x00\x0e\x00\x0f')
    assert flvreader.read_unsigned_char() == 0x12

# Generated at 2022-06-24 11:45:37.310861
# Unit test for constructor of class FlvReader
def test_FlvReader():
    # test for the utility functions
    flv_reader = FlvReader(
        compat_struct_pack('!QI4sB3sB', 1, 13, b'abcd', 1, b'123', 0x88) +
        compat_struct_pack('!Q', 9) +
        b'abcd' +
        b'\x01\x00\x00\x00' +
        b'\x08\x00\x00\x00' +
        b'\x01\x00\x00\x00' +
        b'abcd')
    assert flv_reader.read_unsigned_long_long() == 1
    assert flv_reader.read_unsigned_int() == 13
    assert flv_reader.read_bytes(4) == b'abcd'
    assert flv_

# Generated at 2022-06-24 11:45:48.713090
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    data = b'\x00\x00\x00\x28\x21\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00' \
           b'\x00\x00\x00\x00\x00\x00\x00\x00\x20\x00\x00\x00\x00\x00\x06\x5c' \
           b'\x00\x00\x00\x00\x00\x00\x00\x00\x80\x00\x00\x00'

# Generated at 2022-06-24 11:45:57.765854
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        # size version flags
        b'\x00\x00\x00\x2a\x00\x00\x00\x00\x00\x00\x00\x01' +
        # segment run count
        b'\x00\x00\x00\x01' +
        # fragments per segment
        b'\x00\x00\x00\x01\x00\x00\x00\x01'
    )
    assert FlvReader(data).read_asrt() == {
        'segment_run': [
            (1, 1),
        ],
    }

# Generated at 2022-06-24 11:46:06.384786
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    import unittest
    import sys
    if sys.version_info[0] == 2:
        import StringIO as io_module
    else:
        import io as io_module


# Generated at 2022-06-24 11:46:07.754237
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError('this is a DataTruncatedError exception')
    except DataTruncatedError as e:
        assert e.__class__ is DataTruncatedError
        assert e.args[0] == 'this is a DataTruncatedError exception'


# Generated at 2022-06-24 11:46:16.107672
# Unit test for constructor of class FlvReader
def test_FlvReader():
    data = b'''
    <?xml version="1.0"?>
    <manifest xmlns="http://ns.adobe.com/f4m/1.0">
      <id>6566_1622334</id>
      <mimeType>video/x-flv</mimeType>
      <streamType>recorded</streamType>
      <duration>20</duration>
      <bootstrapInfo profile="named" id="bootstrap1000" url="http://example.com/bootstrap_1000" />
    </manifest>
    '''
    etree = compat_etree_fromstring(fix_xml_ampersands(data))
    bootstrap_url = xpath_text(etree, './/bootstrapInfo/@url', 'bootstrapUrl')

# Generated at 2022-06-24 11:46:26.800825
# Unit test for constructor of class FlvReader

# Generated at 2022-06-24 11:46:36.124432
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    # Expected result of read_abst
    abst = {
        'segments': [
            {
                'segment_run': [
                    (1, 1)
                ]
            }
        ],
        'fragments': [
            {
                'fragments': [
                    {
                        'first': 1,
                        'ts': 0,
                        'duration': 1000,
                        'discontinuity_indicator': None,
                    }
                ]
            }
        ],
        'live': False,
    }

    # The raw data for read_abst

# Generated at 2022-06-24 11:46:44.894349
# Unit test for constructor of class FlvReader

# Generated at 2022-06-24 11:46:52.520070
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    sample = b'\x00\x00\x00\x19\x41\x42\x53\x54\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'
    result = FlvReader(sample).read_bootstrap_info()

# Generated at 2022-06-24 11:46:57.599399
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    reader = FlvReader(b'123456789')
    assert reader.read_bytes(2) == b'12'
    assert reader.read_bytes(3) == b'345'
    assert reader.read_bytes(4) == b'6789'
    try:
        reader.read_bytes(1)
        # The next line should not be executed
        assert False, 'DataTruncatedError not raised'
    except DataTruncatedError:
        pass

# Generated at 2022-06-24 11:47:02.552988
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    src = """<media url="playmanifest.f4m" bootstrapInfoId="bootstrap_0" bitrate="800" width="320" height="240"
        streamId="video_0" />"""
    xml = compat_etree_fromstring(src)
    remove_encrypted_media(xml)
    assert xml.attrib['url'] == "playmanifest.f4m"
    assert xml.attrib['bitrate'] == "800"
    assert 'drmAdditionalHeaderId' not in xml.attrib
    assert 'drmAdditionalHeaderSetId' not in xml.attrib


# Generated at 2022-06-24 11:47:14.642764
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:47:19.517757
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from .testutils import read_fixture_data_bytes
    data = read_fixture_data_bytes('bootstrapinfo_example.flv')
    bootstrap_info = FlvReader(data).read_bootstrap_info()
    assert len(bootstrap_info['segments']) == 1
    assert len(bootstrap_info['fragments']) == 1


# Generated at 2022-06-24 11:47:24.460760
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    import struct
    import random
    import zlib
    import json
    import binascii
    md = {}
    md['author'] = 'Naren'
    md['description'] = 'Unit test function write_metadata_tag'


# Generated at 2022-06-24 11:47:33.410120
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring('''
<manifest xmlns="http://ns.adobe.com/f4m/1.0"
          xmlns:ns2="http://ns.adobe.com/f4m/2.0"
          xmlns:ns3="http://ns.adobe.com/f4m/3.0">
    <baseURL>A</baseURL>
    <ns2:baseURL>B</ns2:baseURL>
    <ns3:baseURL>C</ns3:baseURL>
</manifest>''')
    assert get_base_url(manifest) == 'A'



# Generated at 2022-06-24 11:47:37.088173
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    reader = FlvReader(b'\x00\x00\x00\x01\x00\x00\x00\x01')
    assert reader.read_unsigned_long_long() == 1



# Generated at 2022-06-24 11:47:41.628083
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    val = 12345
    write_unsigned_int(stream, val)
    stream.seek(0)
    assert compat_struct_unpack('!I', stream.read())[0] == val
test_write_unsigned_int()



# Generated at 2022-06-24 11:47:51.834457
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    data = (b'\x01' + b'\x00' * 7 +
            b'\x02' + b'\x00' * 7 +
            b'\xFF' + b'\xFF' * 7 +
            b'\x00' + b'\x00' * 7)
    flv = FlvReader(data)
    assert flv.read_unsigned_long_long() == 1
    assert flv.read_unsigned_long_long() == 2
    assert flv.read_unsigned_long_long() == 18446744073709551615
    assert flv.read_unsigned_long_long() == 0



# Generated at 2022-06-24 11:48:00.729863
# Unit test for function remove_encrypted_media

# Generated at 2022-06-24 11:48:04.052843
# Unit test for function write_flv_header
def test_write_flv_header():
    from .test import get_testdata_stream
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == get_testdata_stream(
        b'flv.dat').read(13)



# Generated at 2022-06-24 11:48:14.634680
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {'live': False, 'segments': [{'segment_run': [(0, 2)]}], 'fragments': [{'fragments': [{'duration': 0, 'first': 0, 'ts': 0}, {'duration': 0, 'first': 3, 'ts': 0}]}]}
    res = build_fragments_list(boot_info)
    assert res[0] == (0, 0)
    assert res[1] == (0, 1)
    assert boot_info['fragments'][0]['fragments'][0]['first'] == 0


_F4M_NS = '{http://ns.adobe.com/f4m/1.0}'



# Generated at 2022-06-24 11:48:18.638098
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    write_unsigned_int(stream, 123)
    assert stream.getvalue() == b'{'



# Generated at 2022-06-24 11:48:23.078347
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    import pytest
    stream = io.BytesIO()
    write_unsigned_int(stream, 1)
    assert stream.getvalue() == b'\x00\x00\x00\x01'
    with pytest.raises(TypeError):
        write_unsigned_int(1, 1)
test_write_unsigned_int()



# Generated at 2022-06-24 11:48:24.980577
# Unit test for function get_base_url
def test_get_base_url():
    xml = """
        <manifest>
            <baseURL>http://example.com/</baseURL>
        </manifest>
    """
    assert get_base_url(compat_etree_fromstring(xml)) == 'http://example.com/'



# Generated at 2022-06-24 11:48:30.570348
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    flv_reader = FlvReader(b'\x02\x66\x6f\x6f\x00\x01\x62\x61\x00')

    assert flv_reader.read_string() == b'\x66\x6f\x6f'
    assert flv_reader.read_string() == b'\x62\x61'


# Generated at 2022-06-24 11:48:40.587859
# Unit test for function build_fragments_list
def test_build_fragments_list():
    def expected_fragments_list(files, live=False):
        return [(0 if live else 1, int(f.split('Seg')[1].split('-')[0])) for f in files]

    # Test for non-live stream
    with io.open('tests/data/bipbop_16x9_variant.bootstrap') as f:
        bootstrap = read_bootstrap_info(f.read().encode('utf-8'))

# Generated at 2022-06-24 11:48:47.617115
# Unit test for function write_flv_header
def test_write_flv_header():
    from io import BytesIO
    from .testcases import TestCase
    
    assert write_flv_header(BytesIO()) == TestCase().assert_equals('\x46\x4C\x56\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00')
    
    

# Generated at 2022-06-24 11:48:56.545396
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    metadata = b'\x00\x00\x00\x00\x00\x00\x00\x00\xff\xff'
    data = io.BytesIO()
    write_metadata_tag(data, metadata)
    # print 'test_write_metadata_tag:', len(data.getvalue()), data.getvalue()
    assert len(data.getvalue()) == (11 + 9 + 4)


# Test for write_metadata_tag
test_write_metadata_tag()



# Generated at 2022-06-24 11:49:00.702342
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    reader = FlvReader(b'\x05hello\x06test\x00end\x00')
    assert reader.read_string() == b'hello'
    assert reader.read_string() == b'test'
    assert reader.read_string() == b'end'

# Generated at 2022-06-24 11:49:05.022568
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    flv = FlvReader(b'test')
    assert flv.read_bytes(2) == b'te'
    assert flv.read_bytes(2) == b'st'
    flv = FlvReader(b'0123456789')
    with pytest.raises(DataTruncatedError):
        flv.read_bytes(11)



# Generated at 2022-06-24 11:49:17.308798
# Unit test for constructor of class FlvReader

# Generated at 2022-06-24 11:49:21.862635
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    h = FlvReader(b'\x00\x00\x00\x03\x00\x00\x00\x04')
    assert h.read_unsigned_int() == 3
    assert h.read_unsigned_int() == 4



# Generated at 2022-06-24 11:49:26.616223
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    data = b'\x12\x34\x56\x78\x9a\xbc\xde\xf0'
    reader = FlvReader(data)
    res = reader.read_bytes(4)
    assert res == b'\x12\x34\x56\x78'
    res = reader.read_bytes(4)
    assert res == b'\x9a\xbc\xde\xf0'
    try:
        reader.read_bytes(4)
    except DataTruncatedError:
        pass
    else:
        assert False, 'Did not raise DataTruncatedError'

# Generated at 2022-06-24 11:49:30.204772
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    write_unsigned_int(stream, 233)
    assert stream.getvalue() == b'\x00\x00\x00\xe9'

# Generated at 2022-06-24 11:49:36.222344
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    data = b'\x01\x02\x03\x04'
    flv_reader = FlvReader(data)
    assert flv_reader.read_unsigned_char() == 1
    assert flv_reader.read_unsigned_char() == 2
    assert flv_reader.read_unsigned_char() == 3
    assert flv_reader.read_unsigned_char() == 4



# Generated at 2022-06-24 11:49:39.758430
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    import io
    stream = io.BytesIO()
    for i in range(256):
        write_unsigned_int_24(stream, i)
    assert stream.getvalue() == b'\x00' + bytes(range(256))



# Generated at 2022-06-24 11:49:42.235585
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    assert write_unsigned_int_24(io.BytesIO(), 0x12345678) == b'\x00\x12\x34\x56'



# Generated at 2022-06-24 11:49:46.982456
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    data = compat_struct_pack('!I', 0x0A) + b'abcde'
    reader = FlvReader(data)
    assert reader.read_bytes(4) == b'\x00\x00\x00\x0A'
    assert reader.read_bytes(5) == b'abcde'
    try:
        reader.read_bytes(1)
        assert False, 'need to raise exception'
    except DataTruncatedError:
        pass



# Generated at 2022-06-24 11:49:51.668310
# Unit test for constructor of class F4mFD
def test_F4mFD():
    fd = F4mFD({})
    assert(fd.params['test'] == False)
    assert(fd.params['fragment_retries'] == 10)
    assert(fd.params['fragment_retry_delay'] == 0.5)
    assert(fd.params['skip_unavailable_fragments'] == True)
    fd = F4mFD({'test': True})
    assert(fd.params['test'] == True)
    assert(fd.params['fragment_retries'] == 10)
    assert(fd.params['fragment_retry_delay'] == 0.5)
    assert(fd.params['skip_unavailable_fragments'] == True)
    fd = F4mFD({'fragment_retries': 1})

# Generated at 2022-06-24 11:49:53.816466
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    with DataTruncatedError("test message"):
        raise DataTruncatedError("test message")


# Generated at 2022-06-24 11:49:59.156775
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    node = compat_etree_fromstring(
        '''<media fileSize="9645" bitrate="492"
            isCrypted="true" drmAdditionalHeaderId="1"
            drmAdditionalHeaderSetId="2"
            url="http://example.com/media"/>''')
    assert not remove_encrypted_media([node])



# Generated at 2022-06-24 11:50:11.699103
# Unit test for method read_unsigned_long_long of class FlvReader

# Generated at 2022-06-24 11:50:20.674545
# Unit test for method read_string of class FlvReader

# Generated at 2022-06-24 11:50:25.441927
# Unit test for function write_flv_header
def test_write_flv_header():
    from .testutils import T
    assert T(write_flv_header)(
        b''.join([b'FLV\x01', b'\x05', b'\x00\x00\x00\x09', b'\x00\x00\x00\x00']))


# Generated at 2022-06-24 11:50:37.212379
# Unit test for function build_fragments_list
def test_build_fragments_list():
    segments = [{
        'segment_run': [
            (0, 2),
        ]
    }]
    fragments = [{
        'fragments': [
            {
                'first': 0,
                'ts': 0,
                'duration': 0,
                'discontinuity_indicator': 0,
            },
        ]
    }]
    assert build_fragments_list({
        'segments': segments,
        'fragments': fragments,
        'live': False,
    }) == [(0, 0), (0, 1)]

    segments = [{
        'segment_run': [
            (0, 4294967295),
        ]
    }]

# Generated at 2022-06-24 11:50:42.622196
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    reader = FlvReader(b'1234')
    assert reader.read_bytes(1) == b'1'
    assert reader.read_bytes(2) == b'23'
    assert reader.read_bytes(2) == b'34'



# Generated at 2022-06-24 11:50:44.994832
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    # 0x0123456789ABCDEF
    data = compat_struct_pack('!Q', 0x0123456789ABCDEF)
    fd = FlvReader(data)
    assert fd.read_unsigned_long_long() == 0x0123456789ABCDEF



# Generated at 2022-06-24 11:50:54.300665
# Unit test for function build_fragments_list
def test_build_fragments_list():
    assert [
        (0, 0), (0, 1), (1, 0), (1, 1)
    ] == build_fragments_list({
        'live': False,
        'segments': [{
            'segment_run': [
                (0, 2),
                (1, 2),
            ]
        }],
        'fragments': [{
            'fragments': [
                {'first': 0},
                {'first': 1},
                {'first': 0},
                {'first': 1},
            ]
        }],
    })

# Generated at 2022-06-24 11:50:58.741775
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    assert len(write_unsigned_int_24(io.BytesIO(), 0xdeadbeef)) == 3
    assert len(write_unsigned_int_24(io.BytesIO(), 0)) == 3
    assert len(write_unsigned_int_24(io.BytesIO(), 0xffffff)) == 3



# Generated at 2022-06-24 11:51:10.491859
# Unit test for method read_unsigned_int of class FlvReader

# Generated at 2022-06-24 11:51:20.087921
# Unit test for function read_bootstrap_info

# Generated at 2022-06-24 11:51:26.406569
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    """ Test real_download method of F4mFD"""

    import unittest
    from .downloader import common
    from .common import FakeYDL

    class F4mDownloaderFake(F4mFD):
        def __init__(self, info_dict, downloader=None, params={}):
            F4mFD.__init__(self, info_dict, downloader, params)

        def _get_unencrypted_media(self, doc):
            return doc.findall(self._add_ns('media'))

        def _download_fragment(self, ctx, url, info_dict):
            return True, b'\x00\x00\x00\x00\x00\x00\x00\x00'

        def real_download(self, filename, info_dict):
            return F

# Generated at 2022-06-24 11:51:29.476086
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    flv_reader = FlvReader(b'\x00\x00\x00\x04')
    assert flv_reader.read_unsigned_int() == 4



# Generated at 2022-06-24 11:51:33.664316
# Unit test for constructor of class F4mFD
def test_F4mFD():
    assert F4mFD.name() == 'f4m'
    assert F4mFD.description()
    assert F4mFD.options()['username']
    assert F4mFD.options()['password']
    assert F4mFD.options()['cookiefile']
    assert F4mFD.extractor() == GenericIE



# Generated at 2022-06-24 11:51:36.209858
# Unit test for function write_flv_header
def test_write_flv_header():
    buf = io.BytesIO()
    write_flv_header(buf)
    assert buf.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-24 11:51:44.805534
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    import binascii
    # Example from http://download.macromedia.com/f4v/video_file_format_spec_v10_1.pdf
    data_str = binascii.unhexlify(
        b'0000001c6166727400000004010000070010000000000000000fc')
    data = FlvReader(data_str)
    actual = data.read_afrt()

# Generated at 2022-06-24 11:51:55.919233
# Unit test for constructor of class FlvReader
def test_FlvReader():
    from ..compat import compat_urllib_request

    req = compat_urllib_request.Request(
        'http://vm2.dashif.org/livesim/testpic_2s/Manifest.mpd')
    data = compat_urllib_request.urlopen(req).read()
    # remove namespace
    data = data.replace(b'xmlns=', b'ns=')
    tree = compat_etree_fromstring(data)
    base_url_node = tree.find('./Period/AdaptationSet/Representation/BaseURL')
    base_url = base_url_node.text

    full_url = base_url
    date_time = '2014-11-22T00%3A00%3A00Z'

# Generated at 2022-06-24 11:51:57.568839
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError()
    except DataTruncatedError:
        pass



# Generated at 2022-06-24 11:52:06.402331
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-24 11:52:09.569852
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    assert FlvReader(b'\x00\x01\x02\x03\x00\x01\x02').read_string() == b'\x00\x01\x02\x03'



# Generated at 2022-06-24 11:52:15.603225
# Unit test for constructor of class F4mFD
def test_F4mFD():
    from youtube_dl.YoutubeDL import YoutubeDL
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD
    from .downloader import DeprecatedDownloader

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kargs):
            super(FakeYDL, self).__init__(*args, **kargs)
            self.extractors = []

        def add_info_extractor(self, ie):
            self.extractors.append(ie)

    ie = InfoExtractor(FakeYDL())
    ie.fd_downloader = HttpFD(FakeYDL(), ie)
    ie.params = {}

    def fake_downld(self, filename, info_dict):
        return True

    ie.fd_downloader.real_download

# Generated at 2022-06-24 11:52:23.650502
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    import base64