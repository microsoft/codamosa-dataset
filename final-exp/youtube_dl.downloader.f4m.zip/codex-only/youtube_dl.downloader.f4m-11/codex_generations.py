

# Generated at 2022-06-24 11:42:27.398451
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    manifest = """<manifest xmlns="http://ns.adobe.com/f4m/1.0"></manifest>"""
    ydl = FakeYoutubeDl()
    ydl.params['test'] = False
    ydl.params['ignoreerrors'] = False
    ydl.params['quiet'] = False
    ydl.params['no_warnings'] = False
    ydl.params['simulate'] = False
    ydl.params['format'] = ''
    ydl.params['merge_output_format'] = ''
    ydl.params['outtmpl'] = 'test'
    info_dict = {'url': 'http://example.com/manifest.f4m', 'http_headers': {}}
    info_dict['http_headers'][b'User-Agent'] = 'fake ua'
   

# Generated at 2022-06-24 11:42:36.325505
# Unit test for function read_bootstrap_info

# Generated at 2022-06-24 11:42:39.007983
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    write_unsigned_int(stream, 12345678)
    assert stream.getvalue() == '\xbc\x61\xd2\x0b'



# Generated at 2022-06-24 11:42:45.371768
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    flv = FlvReader(b'\x00\x00\x00\x0cabcd\x01\x02\x03\x04')
    assert flv.read_box_info() == (12, b'abcd', b'\x01\x02\x03\x04')
    flv = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x14eeee\x01\x02\x03\x04')
    assert flv.read_box_info() == (20, b'eeee', b'\x01\x02\x03\x04')



# Generated at 2022-06-24 11:42:55.684423
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (b'\x00\x00\x00\x1b\x61\x73\x72\x74\x00\x00\x00\x00\x00\x00\x00\x01'
            b'\x00\x00\x00\x00\x00\x00\x00\x00\x64\x65\x66\x61\x75\x6c\x74\x00'
            b'\x00\x00\x00\x00\x01\x00\x00\x00\x01')
    result = FlvReader(data).read_asrt()
    assert result == {
        'segment_run': [(0, 1)],
    }



# Generated at 2022-06-24 11:43:00.899898
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        exc = DataTruncatedError("test message")
        repr(exc)
        str(exc)
    except Exception as err:
        assert False, "Unexpected exception %s" % err
    assert DataTruncatedError("test message").__str__() == "test message"


# Generated at 2022-06-24 11:43:11.210553
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-24 11:43:24.334332
# Unit test for method read_string of class FlvReader

# Generated at 2022-06-24 11:43:37.239262
# Unit test for function build_fragments_list
def test_build_fragments_list():
    from io import BytesIO

    def check(boot_info, expected):
        actual = build_fragments_list(boot_info)
        for act, exp in zip(actual, expected):
            assert act == exp


# Generated at 2022-06-24 11:43:41.451465
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-24 11:43:48.976960
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x28'
        b'asrt'
        b'\x00'
        b'\x00\x00\x00'
        b'\x01'
        b'\x05'
        b'audio'
        b'\x00'
        b'\x00\x00\x00\x02'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x02'
        b'\x00\x00\x00\x08'
        b'\x00\x00\x00\x0B'
    )
    info = FlvReader(data).read_asrt()

# Generated at 2022-06-24 11:44:00.629437
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    test_media = [
        {
            'url': 'http://example.com/1',
            'attrib': {}
        },
        {
            'url': 'http://example.com/2',
            'attrib': {'drmAdditionalHeaderId': '1'}
        },
        {
            'url': 'http://example.com/3',
            'attrib': {'drmAdditionalHeaderSetId': '2'}
        },
        {
            'url': 'http://example.com/4',
            'attrib': {'drmAdditionalHeaderId': '1', 'drmAdditionalHeaderSetId': '2'}
        },
        {
            'url': 'http://example.com/5',
            'attrib': {'drmAdditionalHeaderId': '1'}
        },
    ]
    xml_

# Generated at 2022-06-24 11:44:11.626307
# Unit test for constructor of class F4mFD
def test_F4mFD():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'logger': NullLogger()})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(F4mIE())
    info_dict = ydl.extract_info('http://www.rtl2.de/service/fernsehen/video-schwiegertochter-gesucht-folge-128-zur-ue-bertragung-30.php', download=False)

    with open('test.f4m', 'wb') as f:
        f.write(compat_urllib_request.urlopen(info_dict['url']).read())


# Generated at 2022-06-24 11:44:17.475355
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    buf = io.BytesIO()
    buf.write(b'\x01\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00')
    buf.seek(0)
    fr = FlvReader(buf)
    assert fr.read_unsigned_long_long() == 1
    assert fr.read_unsigned_long_long() == 2

# Generated at 2022-06-24 11:44:29.149835
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    data = b''.join([compat_struct_pack('!I4s', 12, b'abst'),
                     b'\x00abcdefghijklmno'])
    reader = FlvReader(data)
    res = reader.read_box_info()
    assert res[0] == 12
    assert res[1] == b'abst'
    assert res[2] == b'\x00abcdefghijklmno'

    data = b''.join([compat_struct_pack('!IQ', 1, 12),
                     b'abstabcdefghijklmno'])
    reader = FlvReader(data)
    res = reader.read_box_info()
    assert res[0] == 12
    assert res[1] == b'abst'

# Generated at 2022-06-24 11:44:35.439791
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    data = b'\x00\x00\x00\x05'
    actual_result = FlvReader(data).read_unsigned_int()
    expected_result = 5
    assert actual_result == expected_result


# Generated at 2022-06-24 11:44:42.375940
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>test://test.test</baseURL></manifest>')
    assert get_base_url(manifest) == 'test://test.test'

    # Test with no baseURL
    assert get_base_url(
        compat_etree_fromstring('<manifest xmlns="http://ns.adobe.com/f4m/1.0"></manifest>')) is None



# Generated at 2022-06-24 11:44:53.701718
# Unit test for constructor of class FlvReader
def test_FlvReader():
    data = (
        b'\x00\x00\x00<\xaf\x12\x09\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00'
        b'\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'
        b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    data_io = FlvReader(data)
    data_io.read_asrt()

# Generated at 2022-06-24 11:44:58.412481
# Unit test for constructor of class F4mFD
def test_F4mFD():
    filename = "test.f4m"

    def test_download(url, filename, info_dict):
        """
        A simple function that downloads an URL

        Args:
            url: The full URL
            filename: The filename to save the content in
            info_dict: The info_dict, which will be fed as self.params to
                F4mFD().
                The following key is used
                'test': A boolean indicating if we are testing
        """
        with open(filename, 'wb') as outf:
            return F4mFD(info_dict).real_download(outf, {'url': url})

    def _get_expected_content(filename):
        with open(filename, 'rb') as f:
            return f.read()


# Generated at 2022-06-24 11:45:07.828669
# Unit test for method read_box_info of class FlvReader

# Generated at 2022-06-24 11:45:08.539706
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    e = DataTruncatedError()



# Generated at 2022-06-24 11:45:10.873202
# Unit test for constructor of class F4mFD
def test_F4mFD():
    from youtube_dl.YoutubeDL import YoutubeDL
    url = 'http://somafm.com/lush.pls'
    ydl = YoutubeDL({'quiet': True})
    fd = F4mFD(ydl, {'url': url, 'force_generic_extractor': True})
    fd.real_download('', {})


# Generated at 2022-06-24 11:45:12.714498
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    # TODO: Add unit test
    pass



# Generated at 2022-06-24 11:45:15.612330
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    test_str = b'\x00\x01\x02\x03\x04\x05\x06\x07'
    test_reader = FlvReader(test_str)
    assert test_reader.read_string() == test_str[:-1]


# Generated at 2022-06-24 11:45:18.661858
# Unit test for constructor of class FlvReader
def test_FlvReader():
    FlvReader(b'\x00\x00\x00\x00\xafrtABCD\x00\x00\x00\x00')



# Generated at 2022-06-24 11:45:22.367720
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    buf = io.BytesIO()
    write_unsigned_int(buf, 0x1234)
    assert buf.getvalue() == b'\x12\x34\x00\x00'
test_write_unsigned_int()



# Generated at 2022-06-24 11:45:32.262225
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-24 11:45:34.395739
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    obj = DataTruncatedError()
    assert str(obj) == ''
    obj = DataTruncatedError('error message')
    assert str(obj) == 'error message'



# Generated at 2022-06-24 11:45:45.333378
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    def test_list(list):
        stream = io.BytesIO()
        write_metadata_tag(stream, list[0])
        return stream.getvalue() == list[1]

    assert test_list([b'', b'\x12\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'])
    assert test_list([b'a', b'\x12\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00a\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00'])
    assert test_

# Generated at 2022-06-24 11:45:48.800106
# Unit test for constructor of class F4mFD
def test_F4mFD():
    fd = F4mFD(downloader=YoutubeDL(dict()), params=dict())
    assert fd.downloader is not None
    assert fd.params == dict()


# Unit tests for video.adobe.com manifests

# Generated at 2022-06-24 11:45:54.936231
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    flv = FlvReader(b'\x0a\x0b\x0c\x0d')
    assert 10 == flv.read_unsigned_char()
    assert 11 == flv.read_unsigned_char()
    assert 12 == flv.read_unsigned_char()
    assert 13 == flv.read_unsigned_char()

# Generated at 2022-06-24 11:46:04.039423
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    import struct
    test_stream = io.BytesIO()
    test_val_1 = 1234
    write_unsigned_int(test_stream, test_val_1)
    assert test_stream.getvalue() == struct.pack('!I', test_val_1)
    test_val_2 = 4294967295
    write_unsigned_int(test_stream, test_val_2)
    assert test_stream.getvalue() == struct.pack('!I', test_val_1) + struct.pack('!I', test_val_2)
    test_val_3 = 70000
    write_unsigned_int(test_stream, test_val_3)

# Generated at 2022-06-24 11:46:14.081692
# Unit test for method read_box_info of class FlvReader

# Generated at 2022-06-24 11:46:26.384777
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-24 11:46:27.617553
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError
    except DataTruncatedError:
        pass


# Generated at 2022-06-24 11:46:37.709842
# Unit test for function get_base_url
def test_get_base_url():
    assert get_base_url(
        compat_etree_fromstring(
            '<manifest xmlns="http://ns.adobe.com/f4m/1.0"><baseURL>foo</baseURL><test /></manifest>')) == 'foo'
    assert not get_base_url(compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0"><test /></manifest>'))
    assert get_base_url(
        compat_etree_fromstring(
            '<manifest xmlns="http://ns.adobe.com/f4m/2.0"><baseURL>foo</baseURL><test /></manifest>')) == 'foo'



# Generated at 2022-06-24 11:46:45.941353
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    import unittest
    import sys
    import os
    from ..extractor import (
        get_info_extractor,
    )

    # For testing download_testdata.sh must be called first
    # to get the test file
    sys.path.append(os.path.join('test', 'files'))
    from rtmp_test_data import (
        rtmp_test_data,
    )

    class TestFlvReaderMethods(unittest.TestCase):

        def test_read_bootstrap_info(self):
            flv_reader = FlvReader(rtmp_test_data)
            info = flv_reader.read_bootstrap_info()
            self.assertCountEqual(list(info), ['segments', 'fragments', 'live'])

# Generated at 2022-06-24 11:46:57.581535
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    with io.open('tests/testdata/test.abst', mode='rb') as f:
        abst = FlvReader(f.read()).read_bootstrap_info()

    assert abst['segments'][0]['segment_run'][0] == (7, 1)
    assert abst['segments'][0]['segment_run'][1] == (8, 1)
    assert abst['segments'][0]['segment_run'][2] == (9, 1)
    assert abst['segments'][0]['segment_run'][3] == (10, 1)
    assert abst['segments'][0]['segment_run'][4] == (11, 1)
    assert abst['segments'][0]['segment_run'][5] == (12, 1)

# Generated at 2022-06-24 11:46:59.638561
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    flvReader = FlvReader(b'abcd')
    data = flvReader.read_bytes(10)
    assert data == b'abcd'

# Generated at 2022-06-24 11:47:07.333436
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = compat_etree_fromstring('<media url="http://fake.com/drm" '
                                    'drmAdditionalHeaderId="1" '
                                    'drmAdditionalHeaderSetId="0">'
                                    '<media url="http://fake.com/no_drm"/>'
                                    '</media>')
    none_encrypted_media = remove_encrypted_media(media)
    assert len(none_encrypted_media) == 1
    assert none_encrypted_media[0].attrib['url'] == 'http://fake.com/no_drm'



# Generated at 2022-06-24 11:47:18.289186
# Unit test for function get_base_url
def test_get_base_url():
    assert get_base_url(compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0" baseURL="http://example.com/" />')) == 'http://example.com/'
    assert get_base_url(compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/2.0" baseURL="http://example.com/" />')) == 'http://example.com/'
    assert get_base_url(compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/3.0" baseURL="http://example.com/" />')) == 'http://example.com/'
    assert get_base_url

# Generated at 2022-06-24 11:47:27.934776
# Unit test for function build_fragments_list

# Generated at 2022-06-24 11:47:37.269016
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    test_file_name = "test.flv"
    with open(test_file_name, "rb") as test_file:
        flv_reader = FlvReader(test_file.read())
        total_size, box_type, box_data = flv_reader.read_box_info()
        assert total_size == len(flv_reader.read())
        assert box_type == b"FLV\x01"
        assert len(box_data) == 9
        assert flv_reader.raw.read() == b""


# Generated at 2022-06-24 11:47:49.768446
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    f4mFD = F4mFD()

# Generated at 2022-06-24 11:47:54.136341
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    f4mTest = F4mFD()
    f4mTest.real_download("path/to/file","url")
    assert True
#END test_F4mFD_real_download


# Generated at 2022-06-24 11:47:57.436064
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    test_input = b'\x01\x02\x03'
    expected_output = [0x01, 0x02, 0x03]
    assert [FlvReader(test_input).read_unsigned_char() for _ in expected_output] == expected_output

# Generated at 2022-06-24 11:48:00.387304
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
  flv = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x01')
  assert(flv.read_unsigned_long_long() == 1)


# Generated at 2022-06-24 11:48:07.794642
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-24 11:48:09.532901
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    assert write_unsigned_int(None, 31415926) == None

# Generated at 2022-06-24 11:48:13.568944
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    for test_value, expected_read in [
            (b'\xff', 255),
            (b'\x00', 0),
    ]:
        stream = FlvReader(test_value)
        assert stream.read_unsigned_char() == expected_read

# Generated at 2022-06-24 11:48:25.196685
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    import os
    import json

    test_files_dir = os.path.join(os.getcwd(), 'test_files')
    abst_content = open(os.path.join(test_files_dir, 'abst_test.bin'), 'rb').read()
    result = FlvReader(abst_content).read_abst()
    expect_result = json.load(open(os.path.join(test_files_dir, 'abst_test.json'), 'r'))
    assert result == expect_result


    test_files_dir = os.path.join(os.getcwd(), 'test_files')
    abst_content = open(os.path.join(test_files_dir, 'abst_live.bin'), 'rb').read()

# Generated at 2022-06-24 11:48:35.852766
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    byte1 = b'\x00'
    byte2 = b'\x00\x00'
    byte3 = b'\x00\x00\x00'
    byte4 = b'\x00\x00\x00\x00'
    byte5 = b'\x00\x00\x00\x00\x00'
    byte6 = b'\x00\x00\x00\x00\x00\x00'
    byte7 = b'\x00\x00\x00\x00\x00\x00\x00'
    byte8 = b'\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-24 11:48:41.781263
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    flv = io.BytesIO(b'123456789')
    obj = FlvReader(flv.read())
    assert obj.read_bytes(1) == b'1'
    assert obj.read_bytes(4) == b'2345'
    assert obj.read_bytes(4) == b'6789'
    try:
        obj.read_bytes(1)
        assert False, 'DataTruncatedError should be raised'
    except DataTruncatedError:
        assert True

# Generated at 2022-06-24 11:48:49.622360
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    import tempfile
    import os
    import sys
    fd, fname = tempfile.mkstemp()
    f = os.fdopen(fd, 'wb')
    f.write(b'\x00')
    write_unsigned_int_24(f, 0xffffff)
    f.close()
    f = open(fname, 'rb')
    assert f.read() == b'\x00\xff\xff\xff'
    f.close()
    os.remove(fname)



# Generated at 2022-06-24 11:48:54.114560
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    from ..compat import BytesIO
    stream = BytesIO()
    write_unsigned_int(stream, 40)
    stream.seek(0)
    assert stream.read(4) == compat_struct_pack('!I', 40)



# Generated at 2022-06-24 11:49:00.965132
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    s = b'\x00\x00\x00\x01\x00\x00\x00\x01'
    fh = FlvReader(s)
    assert fh.read_unsigned_long_long() == 0x100000001
    assert fh.read_bytes(1) == b''

# Generated at 2022-06-24 11:49:07.874571
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # one test box with size=4
    flv_reader = FlvReader()
    flv_reader.write(compat_struct_pack('!I4s4s', 4, b'abcd', b'defg'))
    flv_reader.seek(0)
    box_size, box_type, box_data = flv_reader.read_box_info()
    assert box_size == 4
    assert box_type == b'abcd'
    assert box_data == b'defg'
    # one test box with size=1
    flv_reader = FlvReader()
    flv_reader.write(compat_struct_pack('!I4sQ4s', 1, b'abcd', 1000, b'defg'))
    flv_reader.seek(0)
    box_

# Generated at 2022-06-24 11:49:15.404020
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    with open('test/testdata/test.flv', 'rb') as fp:
        flv_reader = FlvReader(fp.read())
        assert flv_reader.read_bytes(4) == b'FLV\x01'
        assert flv_reader.read_bytes(1) == b'\x05'
        assert flv_reader.read_bytes(4) == b'\x00\x00\x00\x09'


# Generated at 2022-06-24 11:49:26.664416
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    metadata = """
<DOUBLE
	byteRate="5394.9951171875"
	duration="10.056667"
	encoder="Lavf52.78.4"
	fileSize="53950"
	frameRate="29.97"
	height="144"
	width="176"/>

    """
    metadata_bytes = compat_struct_pack(
        '!B', len(metadata)) + metadata.encode('ascii')

    expected_bytes = b'\x12' + compat_struct_pack(
        '!I', len(metadata_bytes)) + b'\x00\x00\x00\x00\x00\x00\x00' + metadata_bytes + compat_struct_pack(
            '!I', 11 + len(metadata_bytes))
    metadata_tag = io

# Generated at 2022-06-24 11:49:33.942356
# Unit test for function build_fragments_list

# Generated at 2022-06-24 11:49:43.573543
# Unit test for function get_base_url

# Generated at 2022-06-24 11:49:53.712584
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    def _test(x, expected):
        stream = io.BytesIO()
        write_unsigned_int(stream, x)
        assert stream.getvalue() == expected

    _test(1, b'\x00\x00\x00\x01')
    _test(0, b'\x00\x00\x00\x00')
    _test(1 << 31, b'\x80\x00\x00\x00')
    _test((1 << 31) + 1, b'\x80\x00\x00\x01')



# Generated at 2022-06-24 11:50:03.319432
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:50:12.103088
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    reader = FlvReader(
        b'\x00\x00\x00\x21\x61\x73\x72\x74\x01\x00\x00\x00'
        b'\x01\x63\x00\x00\x00\x00'
        b'\x02\x00\x00\x00'
        b'\x01\x00\x00\x00\x01\x00\x00\x00')
    assert reader.read_asrt() == {
        'segment_run': [
            (1, 1),
            (2, 0),
        ],
    }



# Generated at 2022-06-24 11:50:20.991044
# Unit test for function get_base_url
def test_get_base_url():
    assert get_base_url(compat_etree_fromstring('<manifest><baseURL>test_base_url</baseURL></manifest>')) == 'test_base_url'
    assert get_base_url(compat_etree_fromstring('<manifest><baseURL> </baseURL></manifest>')) == ' '
    assert get_base_url(compat_etree_fromstring('<manifest><baseURL></baseURL></manifest>')) == ''
    assert get_base_url(compat_etree_fromstring('<manifest></manifest>')) is None
    assert get_base_url(compat_etree_fromstring('<manifest><baseURL2> </baseURL2></manifest>')) is None

# Generated at 2022-06-24 11:50:34.024798
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    xmltext = '''<media bootstrapInfoId="bootstrap1"
                        url="http://some.com/some"
                        bitrate="280000"
                        width="960"
                        height="540"
                        maintainAspectRatio="true"
                        streamType="recorded"
                        duration="4558.049876"
                        start="0.0">
               </media>'''
    expected = '''<media bitrate="280000"
                        maintainAspectRatio="true"
                        height="540"
                        start="0.0"
                        streamType="recorded"
                        duration="4558.049876"
                        width="960"
                        bootstrapInfoId="bootstrap1"
                        url="http://some.com/some"></media>'''
    etree = compat_etree_fromstring(xmltext)
   

# Generated at 2022-06-24 11:50:40.748719
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    metadata = b'\x02\x00\x0a\x6f\x6e\x4d\x65\x74\x61\x44\x61\x74\x61\x08\x00\x00\x00\x00\x00\x00\xf0?\x00\x00\x00\x00\x02\x00\x0a\x76\x65\x72\x73\x69\x6f\x6e\x08\x00\x00\x00\x04\x00\x00\x00\x00'
    import io
    stream = io.BytesIO()
    write_flv_header(stream)
    write_metadata_tag(stream, metadata)
    #print(stream.getvalue().encode('hex'))


# Generated at 2022-06-24 11:50:50.874167
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-24 11:51:02.457227
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:51:06.493672
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    write_unsigned_int(stream, 1)
    assert stream.getvalue() == b'\x00\x00\x00\x01'



# Generated at 2022-06-24 11:51:13.848559
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    TEST_STRING = b'The quick brown fox jumps over the lazy dog'

    stream = io.BytesIO()
    write_metadata_tag(stream, TEST_STRING)

    assert stream.getvalue() == (
        b'\x12\x00\x00\x29'
        b'\x00\x00\x00\x00\x00\x00\x00'
        b'The quick brown fox jumps over the lazy dog'
        b'\x00\x00\x00$'
    )



# Generated at 2022-06-24 11:51:22.488288
# Unit test for function get_base_url
def test_get_base_url():
    assert get_base_url(compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0"/>')) == None
    assert get_base_url(compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '  <baseURL/>'
        '</manifest>')) == ''
    assert get_base_url(compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '  <baseURL>BASEURL</baseURL>'
        '</manifest>')) == 'BASEURL'

# Generated at 2022-06-24 11:51:27.491815
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    import sys
    stream = io.BytesIO()
    value = 24613
    write_unsigned_int_24(stream, value)
    result = binascii.hexlify(stream.getvalue())
    expected = b'e903'
    assert result == expected



# Generated at 2022-06-24 11:51:38.954659
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import re
    import os
    import shutil
    import io
    import tempfile
    import unittest

    from youtube_dl.utils import ffmpeg_extract_audio, match_filter_func, strip_jsonp, encode_compat_str

    from .test_file import TEST_HOME, TEST_DATA_DIR

    class MyTest(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp(prefix='ytdl_F4mFD_test')

        def tearDown(self):
            shutil.rmtree(self.test_dir)

        def test_download(self):
            video_id = 'kQFKtI6gn9Y'

# Generated at 2022-06-24 11:51:49.103902
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    input_ = (
        b'\x00\x00\x00\x24' b'asrt'  # Box size, box type
        b'\x00'  # Version
        b'\x00\x00\x00'  # Flags
        b'\x00'  # QualityEntryCount
        b'\x00\x00\x00\x02'  # SegmentRun Table Count
        b'\x00\x00\x00\x00'  # First Segments
        b'\x00\x00\x00\x01'  # FragmentsPerSegment
        b'\x00\x00\x00\x01'  # First Segments
        b'\x00\x00\x00\x00'  # FragmentsPerSegment
    )

# Generated at 2022-06-24 11:51:58.928776
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    assert FlvReader(compat_struct_pack('!Q', 0x1)).read_unsigned_long_long() == 0x1
    assert FlvReader(compat_struct_pack('!Q', 0x10000)).read_unsigned_long_long() == 0x10000
    assert FlvReader(compat_struct_pack('!Q', 0x10001)).read_unsigned_long_long() == 0x10001

# Generated at 2022-06-24 11:52:09.810433
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    import os
    import json

    test_file = 'test.bootstrap'
    if not os.path.exists(test_file):
        import base64

# Generated at 2022-06-24 11:52:15.768932
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from .test_fragments import _TEST_SMOOTH_BOOTSTRAP
    info = FlvReader(_TEST_SMOOTH_BOOTSTRAP).read_bootstrap_info()
    assert info['segments'] == [{'segment_run': [(0, 1)]}]

# Generated at 2022-06-24 11:52:22.385853
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    box_info = FlvReader(b'\x00\x00\x00\x20abcd123456789012345').read_box_info()
    assert box_info == (32, b'abcd', b'123456789012345')

    box_info = FlvReader(b'\x00\x00\x01\x00abcd1234567890123456789012345').read_box_info()
    assert box_info == (
        264, b'abcd', b'1234567890123456789012345')

