

# Generated at 2022-06-24 11:42:26.032062
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-24 11:42:28.983019
# Unit test for function write_flv_header
def test_write_flv_header():
    flv_header = io.BytesIO()
    write_flv_header(flv_header)
    assert flv_header.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-24 11:42:33.533740
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    test_data = (b'\x01\x02\x03\x04', 0, 1, 2, 3, 4)
    assert FlvReader(test_data).read_unsigned_char() == 0
    assert FlvReader(test_data).read_unsigned_char() == 1
    assert FlvReader(test_data).read_unsigned_char() == 2
    assert FlvReader(test_data).read_unsigned_char() == 3
    assert FlvReader(test_data).read_unsigned_char() == 4



# Generated at 2022-06-24 11:42:42.058468
# Unit test for function write_flv_header
def test_write_flv_header():
    import hashlib
    stream = io.BytesIO()
    write_flv_header(stream)
    assert hashlib.sha256(stream.getvalue()).hexdigest() == '8ae74313b1c242b7cf8e9e8c1bb3d574dce5f63f4b8e95b3e3ba4f4d04808f68'
test_write_flv_header()



# Generated at 2022-06-24 11:42:48.698596
# Unit test for function read_bootstrap_info

# Generated at 2022-06-24 11:42:53.908686
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    tests = [
        ('00 00 00 00', 0),
        ('00 00 00 01', 1),
        ('ff ff ff ff', 0xFFFFFFFF),
    ]
    for test in tests:
        assert FlvReader(test[0].encode('ascii')).read_unsigned_int() == test[1]



# Generated at 2022-06-24 11:43:04.323495
# Unit test for function write_unsigned_int

# Generated at 2022-06-24 11:43:15.205345
# Unit test for function read_bootstrap_info

# Generated at 2022-06-24 11:43:21.145706
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    assert write_unsigned_int_24(None, 0) == b''
    assert write_unsigned_int_24(None, 0x1234ab) == b'\x34\xab'
    assert write_unsigned_int_24(None, 0xffffff) == b'\xff\xff\xff'



# Generated at 2022-06-24 11:43:29.478599
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from ytdl_server.router import router
    from ytdl_server.server import build_handler_class, make_request_handler, make_server
    from requests import get, head
    from threading import Thread
    from socketserver import TCPServer
    from socketserver import BaseServer
    from time import sleep
    from sys import version_info
    # import aiohttp
    # import asyncio
    # import uvloop
    # asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())

    class MockDownloader:
        params = {}
        def report_error(self, msg):
            print(msg, file=sys.stderr)

        def report_warning(self, msg):
            print(msg, file=sys.stderr)


# Generated at 2022-06-24 11:43:36.723926
# Unit test for function remove_encrypted_media

# Generated at 2022-06-24 11:43:39.437457
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    reader=FlvReader(open('/home/shashank/Downloads/bootstrap_info.bin', 'rb').read())
    info = reader.read_bootstrap_info()
    print(info)



# Generated at 2022-06-24 11:43:48.947611
# Unit test for constructor of class FlvReader

# Generated at 2022-06-24 11:43:51.686458
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    err = DataTruncatedError('abc')
    assert str(err) == 'abc'


# Generated at 2022-06-24 11:43:54.196490
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    test_str = b'ABCD'
    test_r = FlvReader(test_str)
    assert test_r.read_unsigned_int() == 0x44434241



# Generated at 2022-06-24 11:44:03.303720
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    metadata = b'<?xml version="1.0" encoding="utf-8"?>\n<test>test</test>\n'
    expected_stream = (b'\x12\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00' +
                       metadata + 
                       b'\x00\x00\x00\x17')
    stream = io.BytesIO()
    write_metadata_tag(stream, metadata)
    written_stream = stream.getvalue()
    assert expected_stream == written_stream


# Generated at 2022-06-24 11:44:06.808985
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    f = io.BytesIO()
    write_unsigned_int(f, 8)
    assert f.getvalue() == b'\x00\x00\x00\x08'



# Generated at 2022-06-24 11:44:09.057943
# Unit test for constructor of class F4mFD
def test_F4mFD():
    f4m_fd = F4mFD()
    assert f4m_fd.FD_NAME == 'f4m'



# Generated at 2022-06-24 11:44:18.087157
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    metadata = b'\x02\x00\x0a\x6f\x6e\x4d\x65\x74\x61\x44\x61\x74\x61\x08\x00\x00\x00\x00\x00\x00\x00\x00'
    output = io.BytesIO()
    write_metadata_tag(output, metadata)

    assert output.getvalue() == (
        b'\x12\x00\x00\x2a\x00\x00\x00\x00\x00\x00\x00' +
        metadata +
        b'\x00\x00\x00\x2a'
    )


# Generated at 2022-06-24 11:44:30.058642
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    box_data = (
        b'\x00'
        b'\x00\x00\x00'
        b'\x02'
        b'\x09'
        b'\x41\x4d\x4f\x42\x69\x74'
        b'\x00'
        b'\x02'
        b'\x00\x00\x00\x0a'
        b'\x00\x00\x00\x00\x00\x00\x00\x01'
        b'\x00\x00\x00\x00\x00\x00\x00\x02'
    )
    reader = FlvReader(box_data)

# Generated at 2022-06-24 11:44:37.984839
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    flv_reader = FlvReader(
        compat_struct_pack(
            '!I4s4s4sI4s',
            0x30, b'abst', b'flv ', b'', 0x04, b'abcd'))
    try:
        flv_reader.read_bytes(0x30)
    except DataTruncatedError:
        assert False, 'Unexpected DataTruncatedError'
    total_size, box_type, box_data = flv_reader.read_box_info()
    assert total_size == 0x30
    assert box_type == b'abst'
    assert box_data == b'flv \x00\x00\x00\x04abcd'



# Generated at 2022-06-24 11:44:46.267486
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:44:58.131276
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    from ..utils import (
        decode_packed_codes,
    )

# Generated at 2022-06-24 11:45:00.058700
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError
    except DataTruncatedError:
        return
    assert False



# Generated at 2022-06-24 11:45:04.259209
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    from .fragment import _test_read_unsigned_long_long
    for i in itertools.count(0):
        test_data = compat_struct_pack('!Q', i)
        _test_read_unsigned_long_long('FlvReader', FlvReader, test_data)


# Generated at 2022-06-24 11:45:07.647413
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\t\x00\x00\x00\x00'



# Generated at 2022-06-24 11:45:09.360603
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError('Error message')
    except DataTruncatedError as e:
        assert e.message == 'Error message'



# Generated at 2022-06-24 11:45:15.807066
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    test_data = b'\x00\x00\x00\x32\x61\x73\x72\x74\x01\x00\x00\x00\x73\x65\x71\x00\x04\x00\x00\x00\x30\x00\x00\x00\x01\x00\x00\x00\x64\x00\x00\x00\x01\x00\x00\x00\x64\x00\x00\x00\x01\x00\x00\x00\x64\x00\x00\x00\x01\x00\x00\x00'

# Generated at 2022-06-24 11:45:26.059337
# Unit test for function build_fragments_list
def test_build_fragments_list():
    # Tests only against known values to make sure the API doesn't change
    bootstrap_info = read_bootstrap_info(BOOTSTRAP_INFO_DATA)

# Generated at 2022-06-24 11:45:31.273691
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\t\x00\x00\x00\x00'



# Generated at 2022-06-24 11:45:34.394186
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    test_string = 'test'
    test_bytes = b'test\x00'
    reader = FlvReader(test_bytes)
    assert reader.read_string() == test_string

# Generated at 2022-06-24 11:45:40.075207
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media_xml_1 = '''
    <media href="QualityLevels({bitrate})/Fragments(video={start time})"
        bitrate="{bitrate}"
        codec="{codec}"
        type="video"
        drmAdditionalHeaderId="0"
        drmAdditionalHeaderSetId="0"
        width="{width}"
        height="{height}"
        duration="{duration}"
        timeScale="{time scale}"
        framerate="{framerate}">
    </media>
    '''


# Generated at 2022-06-24 11:45:44.542538
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    flv_reader = FlvReader()
    flv_reader.write(compat_struct_pack('!B', 0x01))
    flv_reader.seek(0)
    assert(flv_reader.read_unsigned_char() == 0x01)



# Generated at 2022-06-24 11:45:49.361664
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    with open('tests/f4m/sintel_trailer-1080p.f4m', 'rb') as f:
        data = f.read()
    # A bootstrap box starts at byte 989
    flv_reader = FlvReader(data[989:])
    assert flv_reader.read_unsigned_long_long() == 2398 # total_size of abst box


# Generated at 2022-06-24 11:45:53.204047
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    flv_reader = FlvReader(b'\x00\x00\x00\x03')
    header = flv_reader.read_unsigned_int()
    assert header == 3


# Generated at 2022-06-24 11:46:02.797014
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    import os
    from ..downloader.http import HttpFD

    test_file_list = [
        'bootstrap1',
        'bootstrap2',
        'bootstrap3',
        'bootstrap4',
    ]

    bootstrap1_info = {
        'segments': [
            {
                'segment_run': [
                    (1, 1),
                ]
            },
        ],
        'fragments': [{
            'fragments': [{
                'discontinuity_indicator': None,
                'duration': 5000,
                'first': 1,
                'ts': 0,
            }]
        }],
        'live': False,
    }


# Generated at 2022-06-24 11:46:07.699187
# Unit test for constructor of class F4mFD
def test_F4mFD():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'logger': YoutubeDL.logger_class('error')})
    fd = F4mFD(ydl, {})
    assert fd.ydl is ydl
    assert fd.params == {}

# Generated at 2022-06-24 11:46:11.734496
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    # Arrange
    flv_reader = FlvReader(io.BytesIO(compat_struct_pack('!Q', 13)))

    # Act
    res = flv_reader.read_unsigned_long_long()

    # Assert
    assert res == 13



# Generated at 2022-06-24 11:46:20.245168
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    xml = fix_xml_ampersands(b'''
    <media>
      <drmAdditionalHeaderId>1</drmAdditionalHeaderId>
      <drmAdditionalHeaderSetId>2</drmAdditionalHeaderSetId>
      <some>Attribute</some>
      <metadata>Data</metadata>
    </media>
    ''')
    tree = compat_etree_fromstring(xml)
    assert remove_encrypted_media(tree[0]) == []



# Generated at 2022-06-24 11:46:27.085135
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    assert write_unsigned_int(io.BytesIO(), 0) == b'\x00\x00\x00\x00'
    assert write_unsigned_int(io.BytesIO(), 1) == b'\x00\x00\x00\x01'
    assert write_unsigned_int(io.BytesIO(), 100) == b'\x00\x00\x00d'
    assert write_unsigned_int(io.BytesIO(), 0x1000000) == b'\x00\x00\x01\x00\x00\x00'



# Generated at 2022-06-24 11:46:37.953330
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    import unittest
    import binascii

# Generated at 2022-06-24 11:46:40.433484
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError('foo')
    except DataTruncatedError as e:
        assert e.args[0] == 'foo'



# Generated at 2022-06-24 11:46:42.624994
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    url = 'http://some/url'
    filename = 'test.flv'
    info_dict = {
        'url': url
    }

    f4mFD = F4mFD()
    assert f4mFD.real_download(filename, info_dict) is True



# Generated at 2022-06-24 11:46:46.668043
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    # 0x06050403
    write_unsigned_int(stream, 0x04030506)
    assert stream.getvalue() == b'\x03\x05\x06\x04'
    stream.close()



# Generated at 2022-06-24 11:46:54.988216
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    data = b'\x00\x00\x00\x05hello'
    reader = FlvReader(data)
    assert reader.read_bytes(5) == data[4:]
    data = b'\x00\x00\x00\x05hell'
    reader = FlvReader(data)
    try:
        reader.read_bytes(6)
        assert False, 'test_FlvReader_read_bytes error: expected exception not raised'
    except DataTruncatedError:
        pass



# Generated at 2022-06-24 11:46:57.637558
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    from io import BytesIO
    stream = BytesIO()
    write_unsigned_int(stream, 9)
    assert stream.getvalue() == b'\x00\x00\x00\t'



# Generated at 2022-06-24 11:47:04.347058
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv_header = (
        b'\x46\x4c\x56\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00\x00\x00\x00')

# Generated at 2022-06-24 11:47:16.243691
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    import sys
    import struct
    import binascii
    # Create a test buffer
    stream = io.BytesIO()
    # Create metadata
    metadata = b'onMetaData'
    # Invoke the function
    write_metadata_tag(stream, metadata)
    # Check the result
    actual_result = stream.getvalue()
    expected_result = binascii.unhexlify(
        b'1200000009000000000000006f6e4d65746144617461')
    if actual_result != expected_result:
        sys.exit("test_write_metadata_tag failed, actual_result = %s, expected_result = %s" %
                 (binascii.hexlify(actual_result),
                  binascii.hexlify(expected_result)))



# Generated at 2022-06-24 11:47:22.137369
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    import io
    stream = io.BytesIO()
    write_unsigned_int(stream, 1000)
    assert stream.getvalue() == b'\x00\x00\x03\xe8'
    stream = io.BytesIO()
    write_unsigned_int(stream, 4294967295)
    assert stream.getvalue() == b'\xff\xff\xff\xff'


# Generated at 2022-06-24 11:47:26.081972
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    reader = FlvReader(b'123456')
    assert reader.read_bytes(3) == b'123'
    assert reader.read_bytes(3) == b'456'
    try:
        reader.read_bytes(1)
    except DataTruncatedError:
        pass


# Generated at 2022-06-24 11:47:36.948261
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    test_box_1 = compat_struct_pack('!I4s5s', 9, b'abcd', b'12345')
    assert FlvReader(test_box_1).read_box_info() == (
        9, b'abcd', b'12345')
    test_box_2 = compat_struct_pack('!I4sQ4s', 1, b'abcd', 0x123456789abcdef0, b'1234')
    assert FlvReader(test_box_2).read_box_info() == (
        0x123456789abcdef0, b'abcd', b'1234')


# Generated at 2022-06-24 11:47:49.255852
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    from ..utils import encode_data_uri
    from .fragment import (
        get_video_2_fragments_bootstrap_info,
    )
    bootstrap_bytes = compat_b64decode(get_video_2_fragments_bootstrap_info())
    bootstrap_info = read_bootstrap_info(bootstrap_bytes)

    assert bootstrap_info['segments'] == [{
        'segment_run': [
            (0, 1)
        ]
    }]

# Generated at 2022-06-24 11:47:55.005009
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    for val in (0, 255, 256, (1 << 31) + 256):
        stream = io.BytesIO()
        write_unsigned_int(stream, val)
        if stream.getvalue() != compat_struct_pack('!I', val):
            raise AssertionError('Test failed for val %d' % val)



# Generated at 2022-06-24 11:48:03.955342
# Unit test for function build_fragments_list

# Generated at 2022-06-24 11:48:06.711954
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    assert FlvReader(compat_struct_pack('!B', 0x12)).read_unsigned_char() == 0x12



# Generated at 2022-06-24 11:48:19.307979
# Unit test for constructor of class FlvReader
def test_FlvReader():
    from .f4m import M4SMultiStreamParser
    mp = M4SMultiStreamParser()

# Generated at 2022-06-24 11:48:23.332029
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    f = FlvReader(b'\x00\x00\x00\x04')
    assert f.read_unsigned_int() == 4
    f = FlvReader(b'\x00\x00\x00\x04')
    assert f.read_unsigned_int() == 4



# Generated at 2022-06-24 11:48:29.868182
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    # This is extracted from a live stream
    bootstrap_info_bytes = compat_b64decode(
        b'AAAAIGZ0eXBpc29tAAAAAG1wNDFhdmMxAAAANh21kYXQAAAAOAABAAABAAAA'
        b'ABAAAHgAAAGRhdGEAAAA=')
    bootstrap_info = read_bootstrap_info(bootstrap_info_bytes)
    assert bootstrap_info['live']
    assert len(bootstrap_info['segments']) == 1
    assert len(bootstrap_info['segments'][0]['segment_run']) == 1
    segment_run = bootstrap_info['segments'][0]['segment_run'][0]
    assert segment_run[0] == 1
    assert segment_run[1]

# Generated at 2022-06-24 11:48:39.975328
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-24 11:48:47.698859
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    with io.open('tests/data/cbc-abst.bin', 'rb') as f:
        data = f.read()

# Generated at 2022-06-24 11:48:59.960615
# Unit test for function build_fragments_list

# Generated at 2022-06-24 11:49:06.948210
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    from .common import find_xpath_attr
    from .smil import SMIL

# Generated at 2022-06-24 11:49:12.551072
# Unit test for constructor of class F4mFD
def test_F4mFD():
    """
    Call constructor of F4mFD.
    """
    ydl_opts = {
        'format': 'http-f4m',
        'quiet': True,
        'no_warnings': True,
    }
    return F4mFD(ydl_opts)



# Generated at 2022-06-24 11:49:16.174842
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    flv_reader = FlvReader(compat_struct_pack('!I', 2))
    assert flv_reader.read_unsigned_int() == 2
    assert flv_reader.read_unsigned_int() == 0



# Generated at 2022-06-24 11:49:23.368484
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    cases = [
        # input, expected
        (b'\x00\x00\x00\x00', 0),
        (b'\x00\x00\x00\x01', 1),
        (b'\xFF\xFF\xFF\xFF', 4294967295),
    ]
    for data, expected in cases:
        yield check_FlvReader_read_unsigned_int, data, expected


# Generated at 2022-06-24 11:49:32.109982
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    abc = compat_struct_pack(b'!I', 1) + b'abst' + compat_struct_pack(b'!B', 1) + b'\x00' * 3 + compat_struct_pack(
        b'!I', 0) + compat_struct_pack(b'!Q', 1) + compat_struct_pack(b'!I', 2) + b'\x00\x00\x00\x00'
    abc += compat_struct_pack(b'!I', 1) + b'afrt' + compat_struct_pack(b'!I', 0)
    abc += compat_struct_pack(b'!I', 1) + b'asrt' + compat_struct_pack(b'!I', 0)

# Generated at 2022-06-24 11:49:40.785256
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    assert FlvReader(b'\x06\x00\x00\x00abc\x00def\x00').read_string() == b'abc'
    assert FlvReader(b'\x03\x00\x00\x00abc\x00def\x00').read_string() == b'abc'
    assert FlvReader(b'\x02\x00\x00\x00abc\x00def\x00').read_string() == b'ab'
    assert FlvReader(b'\x01\x00\x00\x00abc\x00def\x00').read_string() == b'a'



# Generated at 2022-06-24 11:49:48.361489
# Unit test for function build_fragments_list
def test_build_fragments_list():
    from ..utils import (
        read_json,
        sanitized_Request,
    )
    from .common import (
        BaseFD,
    )
    class DummyFD(BaseFD):
        def read(self, *args, **kwargs):
            return True
    url = compat_urllib_parse_urlparse('http://test-stream.test/test.f4m')
    class DummyIE(object):
        def __init__(self, *args, **kwargs):
            pass
        def url_result(self, *args, **kwargs):
            return DummyFD(url)
        def add_default_headers(self, *args, **kwargs):
            pass
    dummy_ie = DummyIE()
    dummy_ie.add_info_extractor(DummyIE)
    dummy_

# Generated at 2022-06-24 11:50:00.349734
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:50:11.943393
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    tdir = tempfile.mkdtemp()
    url = 'http://qa-sandbox.visiblemeasures.com/akamai/staging/hourglass/bbb/bbb-05-alternate-audio.f4m?hdnea=st=1408874933~exp=1408876233~acl=/*~hmac=54d3f4e2b4a4e1354a96dcc1e766b8ebeedb7d958f0a8dde65b1a0d33a056eb5'

# Generated at 2022-06-24 11:50:19.549099
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring('''
<manifest xmlns="http://ns.adobe.com/f4m/1.0">
</manifest>
''')
    base_url = get_base_url(manifest)
    assert base_url is None
    manifest = compat_etree_fromstring('''
<manifest xmlns="http://ns.adobe.com/f4m/1.0">
    <baseURL>
    http://localhost/dir/dir2/
    </baseURL>
</manifest>
''')
    base_url = get_base_url(manifest)
    assert base_url == 'http://localhost/dir/dir2/'



# Generated at 2022-06-24 11:50:22.005003
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    stream = io.BytesIO()
    write_unsigned_int_24(stream, 0x010000)
    assert stream.getvalue() == b'\x00\x01\x00'



# Generated at 2022-06-24 11:50:25.166785
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    assert b'\x00\x00\x10' == write_unsigned_int_24(io.BytesIO(), 0x100000).getvalue()



# Generated at 2022-06-24 11:50:37.022689
# Unit test for function read_bootstrap_info

# Generated at 2022-06-24 11:50:41.137017
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    stream = io.BytesIO()
    write_unsigned_int_24(stream, 0xABCD)
    assert (stream.getvalue() == b'\x00\xAB\xCD')



# Generated at 2022-06-24 11:50:49.397076
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    f = io.BytesIO()

# Generated at 2022-06-24 11:50:59.125882
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    s = b'\x00\x01\x02abc\x00\x03\x02def\x00\x04\x05'
    f = FlvReader(s)
    assert f.read_string() == b'\x01\x02abc'
    assert f.read_string() == b'\x03\x02def'
    assert f.read_string() == b'\x04\x05'
    # if \x00 is not found, an error should be raised
    try:
        f.read_string()
        assert False, 'should not be here'
    except DataTruncatedError:
        pass
# Test class FlvReader

# Generated at 2022-06-24 11:51:04.797984
# Unit test for function get_base_url
def test_get_base_url():
    data = """
    <manifest xmlns="http://ns.adobe.com/f4m/1.0">
      <baseURL>http://example.com/</baseURL>
      <media href="media.f4m" bootstrapInfoId="bootstrap"/>
    </manifest>
    """
    assert 'http://example.com/' == get_base_url(compat_etree_fromstring(data))



# Generated at 2022-06-24 11:51:13.439121
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    reader = FlvReader(b'0123456789')
    assert reader.tell() == 0
    assert reader.read_bytes(4) == b'0123'
    assert reader.tell() == 4
    assert reader.read_bytes(4) == b'4567'
    assert reader.tell() == 8
    assert reader.read_bytes(4) == b'89'
    assert reader.tell() == 10
    try:
        reader.read_bytes(4)
        assert False
    except DataTruncatedError as e:
        assert e.args[0] == 'FlvReader error: need 4 bytes while only 2 bytes got'


# Generated at 2022-06-24 11:51:21.404147
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media1 = b'<media url="http://example.com/encrypted.mp4" bootstrapInfoId="bootstrap1" drmAdditionalHeaderId="header1" drmAdditionalHeaderSetId="headerset1" />'
    media2 = b'<media url="http://example.com/decrypted.mp4" bootstrapInfoId="bootstrap2" />'
    media_list = [compat_etree_fromstring(media1), compat_etree_fromstring(media2)]
    media_list = remove_encrypted_media(media_list)
    assert len(media_list) == 1
    assert media_list[0].attrib['bootstrapInfoId'] == 'bootstrap2'



# Generated at 2022-06-24 11:51:25.389545
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    YDL = YoutubeDL({})
    test = F4mFD(YDL)
    #TODO: Test real_download method of this class


# Generated at 2022-06-24 11:51:32.176361
# Unit test for constructor of class F4mFD
def test_F4mFD():
    # Create instance of class F4mFD
    f4mFD = F4mFD()
    # Just test it is initialized correctly
    print(f4mFD.params)
    print(f4mFD.ydl)
    print(f4mFD.progress_hooks)
    print(f4mFD.fragment_index)
    print(f4mFD.complete_frags_downloaded_bytes)
    print(f4mFD.dest_stream)

# Generated at 2022-06-24 11:51:42.034331
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    output = io.BytesIO()
    metadata = b'\x00\x00\x00\x01\x00\x06@duration\x00\x00\x00\x00\x00\x00?\x10\x00\x00\x00\x00\x00\x01\x00\x04data\x00\x00\x00<\x01\x00\x00\x00\x00\n\x00\x00\x00\x00\x00\x00\x00\x05onMetaData\x00\x04\x00\x00\x00\x00\x00\x00\x00\x08'
    write_flv_header(output)
    write_metadata_tag(output, metadata)

    assert output.getvalue() == b

# Generated at 2022-06-24 11:51:50.957448
# Unit test for function remove_encrypted_media

# Generated at 2022-06-24 11:51:59.891946
# Unit test for function get_base_url
def test_get_base_url():
    xml = u'<manifest xmlns="http://ns.adobe.com/f4m/1.0"></manifest>'
    manifest = compat_etree_fromstring(fix_xml_ampersands(xml))
    assert get_base_url(manifest) is None
    assert get_base_url(None) is None

    xml = u'<manifest xmlns="http://ns.adobe.com/f4m/2.0">' + \
          u'<baseURL>https://www.example.com/</baseURL></manifest>'
    manifest = compat_etree_fromstring(fix_xml_ampersands(xml))
    assert get_base_url(manifest) == 'https://www.example.com/'


# Generated at 2022-06-24 11:52:07.278000
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    input_data = b'\x00\x00\x00\x07\x00\x00\x00\x41'
    expected = [0x41, 0x0700, 0x07000000, 0x0700000000]
    flv_reader = FlvReader(input_data)
    for i in range(4):
        assert flv_reader.read_unsigned_long_long() == expected[i]
    assert flv_reader.read(1) == b''



# Generated at 2022-06-24 11:52:09.457712
# Unit test for constructor of class FlvReader
def test_FlvReader():
    data = compat_b64decode(b'AAABAAIAAgAEAAAAAAAAAAAAAAAAAAAAEAAAAAgAAAAAAAAAAAAAAAgAAAAIAAAAEAAAEAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAA')
    reader = FlvReader(data)
    reader.read_bootstrap_info()



# Generated at 2022-06-24 11:52:11.107790
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    reader = FlvReader(compat_struct_pack('!Q', 25))
    assert reader.read_unsigned_long_long() == 25


# Generated at 2022-06-24 11:52:16.302886
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    from io import BytesIO
    buf = BytesIO()
    write_unsigned_int(buf, 1)
    write_unsigned_int(buf, 2)
    assert buf.getvalue() == b'\x00\x00\x00\x01\x00\x00\x00\x02'
    buf.close()
test_write_unsigned_int()

