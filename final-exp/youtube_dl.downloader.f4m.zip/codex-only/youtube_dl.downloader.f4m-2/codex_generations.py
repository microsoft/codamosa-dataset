

# Generated at 2022-06-24 11:42:26.806654
# Unit test for function build_fragments_list

# Generated at 2022-06-24 11:42:35.790760
# Unit test for method read_box_info of class FlvReader

# Generated at 2022-06-24 11:42:41.966686
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    test_stream = io.BytesIO()
    test_values = [0, 1, 10, 10000, 20000, 2147483648, 4294967295]
    for test_value in test_values:
        write_unsigned_int(test_stream, test_value)

    test_stream.seek(0)
    for test_value in test_values:
        assert test_value == compat_struct_unpack('!I', test_stream.read(4))[0]
test_write_unsigned_int()



# Generated at 2022-06-24 11:42:53.219791
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    data = b'\x00\x00\x00\x01\x00\x00\x00\xF0'
    f = FlvReader(data)
    assert (f.read_unsigned_long_long() == 241)
    data = b'\x00\x00\x00\x00\xFF\xFF\xFF\xFF'
    f = FlvReader(data)
    assert (f.read_unsigned_long_long() == 4294967295)
    data = b'\x00\x00\x00\x01\x00\x00\x00\x00'
    f = FlvReader(data)
    assert (f.read_unsigned_long_long() == 2 ** 32)

# Generated at 2022-06-24 11:43:04.296030
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-24 11:43:09.565038
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    if compat_struct_pack('!Q', 1)[-1:] == b'\x01':
        # Big endian
        reader = FlvReader(compat_struct_pack('!Q', 1))
    else:
        # Little endian
        reader = FlvReader(compat_struct_pack('!Q', 1)[::-1])
    assert reader.read_unsigned_long_long() == 1

# Generated at 2022-06-24 11:43:11.788770
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    r = FlvReader(compat_struct_pack('!Q', 1 << 40))
    assert r.read_unsigned_long_long() == 1 << 40



# Generated at 2022-06-24 11:43:24.938614
# Unit test for method read_box_info of class FlvReader

# Generated at 2022-06-24 11:43:32.593899
# Unit test for function remove_encrypted_media

# Generated at 2022-06-24 11:43:43.106626
# Unit test for constructor of class FlvReader

# Generated at 2022-06-24 11:43:45.844200
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\t\x00\x00\x00\x00'



# Generated at 2022-06-24 11:43:50.023236
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    ydl = YoutubeDL()
    ydl.params['test'] = True
    ydl.params['noprogress'] = True
    try:
        import __main__
        __main__.test = True
    except:
        pass
    url = 'http://falco.video.yorku.ca/hls-live/livepkgr/_definst_/livestream1/playlist.m3u8'
    ydl.params['test'] = True
    ydl.download([url])

# Generated at 2022-06-24 11:44:00.815666
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = []
    media.append(compat_etree_fromstring(r'''
    <media url="media_1" bitrate="1234" bootstrapInfoId="bootstrap_1"
            keySystem="aes"
            keyURL="key_1"
            drmAdditionalHeaderId="add_1"
            drmAdditionalHeaderSetId="add_set_1">
    </media>
    '''))
    media.append(compat_etree_fromstring(r'''
    <media url="media_2" bitrate="1234" bootstrapInfoId="bootstrap_2"
            keySystem="aes"
            keyURL="key_2"
            drmAdditionalHeaderSetId="add_set_2">
    </media>
    '''))

# Generated at 2022-06-24 11:44:11.743811
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from common import F4mFD
    from common import get_testdata_file
    from common import expect_download, record_download
    from common import urlopen, urlretrieve

    # Create instance of F4mFD
    f4mfd = F4mFD()
    # Set properties
    f4mfd.to_screen = print
    f4mfd.report_warning = print
    f4mfd.report_error = print
    f4mfd.report_destination = print

    f4mfd.ydl = None
    
    # Set input parameters
    f4mfd.params = {'test': True}
    # Set output parameters
    filename = get_testdata_file('F4mFD/real_download.m3u8')
    

# Generated at 2022-06-24 11:44:16.519840
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    flv_reader=FlvReader(b'\x01\x02\x03\x04')
    assert flv_reader.read_unsigned_char() == 1
    assert flv_reader.read_unsigned_char() == 2
    assert flv_reader.read_unsigned_char() == 3
    assert flv_reader.read_unsigned_char() == 4



# Generated at 2022-06-24 11:44:28.041586
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Initialization of class F4mFD
    class YDL(object):
        def __init__(self):
            self.params = {'test': False}
        def urlopen(self, url):
            # Mock urllib.urlopen
            class MockUrlLib(object):
                def __init__(self, url):
                    self.url = url
                def geturl(self):
                    return self.url
                def read(self):
                    # Mock read function
                    if self.url == 'http://manifest_url.f4m':
                        return b'<manifest><media url="test_url.f4m"/>'

# Generated at 2022-06-24 11:44:37.106585
# Unit test for function build_fragments_list

# Generated at 2022-06-24 11:44:45.690883
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader = FlvReader(b'\x00\x00\x07\xE1\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00')
    info = flv_reader.read_afrt()
    print(info)

# Generated at 2022-06-24 11:44:48.808843
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    assert len(write_metadata_tag(b'test\x00\x00\x00\x01\x02')) == 24



# Generated at 2022-06-24 11:45:00.150279
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:45:08.896825
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:45:15.380940
# Unit test for function get_base_url
def test_get_base_url():
    """Returns success if baseURL works with both namespaces"""
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0"></manifest>')
    assert get_base_url(manifest) is None
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/2.0"></manifest>')
    assert get_base_url(manifest) is None
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '  <baseURL>http://example.com/</baseURL>'
        '</manifest>')

# Generated at 2022-06-24 11:45:25.215279
# Unit test for constructor of class FlvReader

# Generated at 2022-06-24 11:45:35.777981
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:45:46.644312
# Unit test for function remove_encrypted_media

# Generated at 2022-06-24 11:45:51.518036
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    s = io.BytesIO()
    write_unsigned_int(s, 29)
    assert s.getvalue() == b'\x00\x00\x00\x1d'
    assert write_unsigned_int(s, 4294967295) is None
    assert s.getvalue() == b'\x1d\x00\x00\x00\xff\xff\xff\xff'
# Invoke unit tests
test_write_unsigned_int()



# Generated at 2022-06-24 11:46:01.461189
# Unit test for constructor of class FlvReader
def test_FlvReader():
    flv_header = b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'

# Generated at 2022-06-24 11:46:12.840831
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    f = compat_struct_pack('!Q', 9223372036854775807) + b'\x00'
    assert FlvReader(f).read_unsigned_long_long() == 9223372036854775807
    assert FlvReader(compat_struct_pack('!I', 2147483647) + b'\x00').read_unsigned_int() == 2147483647
    assert FlvReader(compat_struct_pack('!B', 255) + b'\x00').read_unsigned_char() == 255
    assert FlvReader(b'\x00' + b'\x00' + b'\x00').read_string() == b''
    assert FlvReader(b'a' + b'\x00' + b'\x00' + b'\x00').read

# Generated at 2022-06-24 11:46:19.218295
# Unit test for function write_flv_header
def test_write_flv_header():
    from io import BytesIO
    stream = BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'


# Generated at 2022-06-24 11:46:24.067331
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    out = io.BytesIO()
    write_unsigned_int_24(out, 0x0f)
    write_unsigned_int_24(out, 0x10)
    out_val = out.getvalue()
    assert out_val == b'\x0f\x00\x00\x10\x00\x00'


# Generated at 2022-06-24 11:46:28.571357
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    """Test whether write_unsigned_int_24 writes ints correctly"""
    stream = io.BytesIO()
    write_unsigned_int_24(stream, 123)
    write_unsigned_int_24(stream, 1)
    write_unsigned_int_24(stream, 456)
    assert (
        stream.getvalue() ==
        b'\x00\x00\x7B\x00\x00\x01\x00\x00\xC8')



# Generated at 2022-06-24 11:46:39.462834
# Unit test for function build_fragments_list
def test_build_fragments_list():
    def _struct_to_str(struct):
        return json.dumps(struct, sort_keys=True)

    def _assert_equals(a, b):
        assert _struct_to_str(a) == _struct_to_str(b)


# Generated at 2022-06-24 11:46:49.224907
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    def get_metadata_tag(metadata):
        stream = io.BytesIO()
        write_metadata_tag(stream, metadata)
        return stream
    # Empty metadata
    assert get_metadata_tag(b'').getvalue() == (
        b'\x12\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    # With metadata

# Generated at 2022-06-24 11:47:00.081718
# Unit test for function remove_encrypted_media

# Generated at 2022-06-24 11:47:11.265064
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    stream = io.BytesIO()
    ctx = {
        'dest_stream': stream,
        'live': False,
        'filename': 'test_filename',
        'test': True
    }
    f = F4mFD(None)

    akamai_pv = None
    extra_param_to_segment_url = None
    info_dict = {
        'url': 'test_url',
        'akamai_pv': akamai_pv,
        'extra_param_to_segment_url': extra_param_to_segment_url
    }
    url_parsed = compat_urllib_parse_urlparse(url_parsed)
    # Unit Test 1. Test correct behavior when the fragment is not truncated
    success, down_data = f._download_

# Generated at 2022-06-24 11:47:22.184066
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    # a short FLV file (2.6KB) is taken from travis.
    # http://devimages.apple.com/iphone/samples/bipbop/gear1/prog_index.m3u8
    f = FlvReader(open('test_bootstrap_info.flv', 'rb').read())
    bootstrap_info = f.read_bootstrap_info()
    assert bootstrap_info['live'] == False
    assert bootstrap_info['segments'][0]['segment_run'] == [(0, 1)]
    assert bootstrap_info['fragments'][0]['fragments'][0]['first'] == 0
    assert bootstrap_info['fragments'][0]['fragments'][0]['ts'] == 0

# Generated at 2022-06-24 11:47:24.499544
# Unit test for function write_flv_header
def test_write_flv_header():
    test_stream = io.BytesIO()
    write_flv_header(test_stream)
    assert test_stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-24 11:47:36.193774
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-24 11:47:42.962121
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    flv_reader = FlvReader(b'\x00\x01\x02\x03\x04\x05\x06\x07'
                           b'\x08\x09\x0A\x0B\x0C\x0D\x0E\x0F')
    for i in range(0, 16):
        assert flv_reader.read_unsigned_char() == i



# Generated at 2022-06-24 11:47:54.165046
# Unit test for constructor of class FlvReader
def test_FlvReader():
    # prepare test data
    # a typical flv file is less than 10 KB
    flv_data = io.BytesIO(b'testdata')
    # now add RTMP message (with MESSAGE_TYPE_AUDIO)
    flv_data.write(compat_struct_pack(
        '!B',  # MESSAGE_TYPE_AUDIO
    ))
    flv_data.write(compat_struct_pack(
        '!I',  # timestamp
        3,  # timestamp extended
        0,  # size of message
        0x12,  # message stream id
        0x00, 0x00, 0x00, 0x00,  # message data
    ))
    flv_data.seek(0)
    # construct the FlvReader object

# Generated at 2022-06-24 11:48:03.211972
# Unit test for function remove_encrypted_media

# Generated at 2022-06-24 11:48:14.736582
# Unit test for function get_base_url
def test_get_base_url():
    manifest = '''<manifest></manifest>'''
    assert get_base_url(manifest=manifest) is None
    manifest = '''<manifest><baseURL>fdsafds</baseURL></manifest>'''
    assert get_base_url(manifest=manifest) == 'fdsafds'
    manifest = '''<manifest xmlns="http://ns.adobe.com/f4m/2.0"><baseURL>fdsafds</baseURL></manifest>'''
    assert get_base_url(manifest=manifest) == 'fdsafds'
    manifest = '''<manifest><bad>fdsafds</bad></manifest>'''
    assert get_base_url(manifest=manifest) is None

# Generated at 2022-06-24 11:48:21.125156
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    info = FlvReader(open('f4m_bootstrap_info', 'rb').read()).read_bootstrap_info()
    assert info['segments'][0]['segment_run'][0] == (0, 0)
    assert info['fragments'][0]['fragments'][0]['first'] == 0


# Generated at 2022-06-24 11:48:25.352349
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    with io.open('tests/fragment.f4f/f4f_abst_box_data.dat', 'rb') as f:
        abst_box_data = f.read()
        abst_box_data_reader = FlvReader(abst_box_data)
        abst_box_data_reader.read_abst()


# Generated at 2022-06-24 11:48:31.721236
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    flv_reader = FlvReader(b'\x00\x00\x00\x05abcde\x00\x00\x00\x04fghi\x00\x00\x00\x00')
    assert flv_reader.read_string() == b'abcde'
    assert flv_reader.read_string() == b'fghi'
    assert flv_reader.read_string() == b''



# Generated at 2022-06-24 11:48:33.155919
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    assert write_unsigned_int_24(io.BytesIO(), 0x123456) == io.BytesIO(b'\x56\x34\x12')



# Generated at 2022-06-24 11:48:42.432780
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    import xml.etree.ElementTree as ET
    data = b'<media bootstrapInfoId="bootstrap0" bitrate="2112000" width="1280" height="720" url="media0.mp4" isDefault="true" qualityLevels="6" maintainAspectRatio="true" presentationTimeOffset="0" codec="H264" lang="und">\n' \
           b'<metadata>\n' \
           b'</metadata>\n' \
           b'<drmAdditionalHeaderId>0</drmAdditionalHeaderId>\n' \
           b'<drmAdditionalHeaderSetId>0</drmAdditionalHeaderSetId>\n' \
           b'</media>'
    data = compat_etree_fromstring(data)
    assert len(data) == 3
    remove_encrypted_media(data)
   

# Generated at 2022-06-24 11:48:52.847716
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    fake_media = [
        {
            'url': 'https://secure.example.com/0/0/servicename/streams/stream_id/chunklist.m3u8',
            'drmAdditionalHeaderId': 'urn:uuid:4a7b1e0c-e7e4-4285-9b55-a440a1ba7b68',
            'drmAdditionalHeaderSetId': 'urn:uuid:4a7b1e0c-e7e4-4285-9b55-a440a1ba7b68',
        },
        {
            'url': 'http://streams.example.com/0/0/servicename/streams/stream_id/chunklist.m3u8',
        },
    ]

# Generated at 2022-06-24 11:49:03.506457
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    assert write_unsigned_int_24(io.BytesIO(), 0) == b'\x00\x00\x00'
    assert write_unsigned_int_24(io.BytesIO(), 1) == b'\x01\x00\x00'
    assert write_unsigned_int_24(io.BytesIO(), 256) == b'\x00\x01\x00'
    assert write_unsigned_int_24(io.BytesIO(), 16777216) == b'\x00\x00\x01'
    assert write_unsigned_int_24(io.BytesIO(), 16777217) == b'\x01\x00\x01'
    assert write_unsigned_int_24(io.BytesIO(), 16777218) == b'\x02\x00\x01'


# Generated at 2022-06-24 11:49:08.667480
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    ex_data = b'\x80\x00\x00\x00\x00\x00\x00\x00'
    reader = FlvReader(ex_data)
    assert reader.read_unsigned_long_long() == 9223372036854775808


# Generated at 2022-06-24 11:49:19.211714
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    def test(buf, expected):
        res = FlvReader(buf).read_afrt()
        assert res == expected

# Generated at 2022-06-24 11:49:29.787737
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:49:40.256008
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    flvReader_a = FlvReader(b'\x00')
    assert flvReader_a.read_bytes(1) == b'\x00'
    assert flvReader_a.read_string() == b''

    flvReader_b = FlvReader(b'\x0f\x00')
    assert flvReader_b.read_bytes(1) == b'\x0f'
    assert flvReader_b.read_string() == b''

    flvReader_c = FlvReader(b'\x0f\x41\x00')
    assert flvReader_c.read_bytes(1) == b'\x0f'
    assert flvReader_c.read_string() == b'A'

# Generated at 2022-06-24 11:49:41.189251
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError('missing data')
    except DataTruncatedError as e:
        assert str(e) == 'missing data'



# Generated at 2022-06-24 11:49:45.213406
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    my_data = io.BytesIO(compat_struct_pack('!I4s3BI4s2B',
        0x14, b'abst', 0x00, 0x00, 0x00, 0x01,
        0x00, b'f4v ', 0x01, 0x02))
    FlvReader(my_data).read_box_info()



# Generated at 2022-06-24 11:49:58.439391
# Unit test for function get_base_url
def test_get_base_url():
    xml_text = fix_xml_ampersands('''
        <manifest xmlns="http://ns.adobe.com/f4m/1.0">
            <baseURL>http://hostname/f4m</baseURL>
        </manifest>
    ''')
    manifest = compat_etree_fromstring(xml_text.encode('utf-8'))
    assert 'http://hostname/f4m' == get_base_url(manifest)
    xml_text = fix_xml_ampersands('''
        <manifest xmlns="http://ns.adobe.com/f4m/2.0">
            <baseURL>http://hostname/f4m</baseURL>
        </manifest>
    ''')

# Generated at 2022-06-24 11:50:05.979425
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    assert FlvReader(b'\x00\x00\x00\x01').read_unsigned_int() == 1
    assert FlvReader(b'\x00\x00\x01\x00').read_unsigned_int() == 256
    assert FlvReader(b'\x00\x00\x00\x00').read_unsigned_int() == 0



# Generated at 2022-06-24 11:50:12.145161
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import time
    import os
    import subprocess
    # Change to this directory (This file directory)
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    # Open _test_F4mFD_real_download.f4m in read mode
    f4m_data = open('_test_F4mFD_real_download.f4m','r')
    # Create a dictionary that contains info_dict

# Generated at 2022-06-24 11:50:23.184560
# Unit test for function read_bootstrap_info

# Generated at 2022-06-24 11:50:35.773611
# Unit test for function write_metadata_tag

# Generated at 2022-06-24 11:50:45.031783
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    flv = FlvReader(compat_b64decode(
        b'AAAAAAABCwAAAAoAAAADAP9fA8M/XwPDMysnJAMbGxgAAAAQAAAAIAAAANAAAAGQAAABoAAAAb'
        b'AAAAGwAAABwAAAAgAAAAJgAAACcAAAAoAAAAAAAAAA=='))
    assert flv.read_unsigned_long_long() == 17
    assert flv.read_unsigned_long_long() == 5



# Generated at 2022-06-24 11:50:52.247824
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    test_data = (b'\x00\x00\x01\x05\x00\x00\x00\x17\x00\x00\x00\x01'
                 b'\x00\x00\x00\x01\x00\x00\x00\x02\x00\x00\x00\x03\x00\x00\x00\x01')
    reader = FlvReader(test_data)
    asrt = reader.read_asrt()
    assert asrt == {'segment_run': [
        (1, 2),
        (3, 1),
    ]}



# Generated at 2022-06-24 11:50:58.790121
# Unit test for function build_fragments_list
def test_build_fragments_list():
    test_data = read_bootstrap_info(open(
        'tests/test_data/asf_bootstrap_info.bin', 'rb').read())
    test_result = build_fragments_list(test_data)
    assert test_result == [
        (0, 0), (0, 1), (0, 2), (0, 3), (0, 4), (0, 5), (1, 0), (1, 1)]



# Generated at 2022-06-24 11:51:07.189840
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    """
    Test the method read_abst of the class FlvReader using a bootstrap
    information box data of a sample flv file.
    """

# Generated at 2022-06-24 11:51:08.169693
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    DataTruncatedError("test")



# Generated at 2022-06-24 11:51:17.925855
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:51:25.139762
# Unit test for method read_box_info of class FlvReader

# Generated at 2022-06-24 11:51:35.061954
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:51:44.422352
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    s = io.BytesIO()
    write_unsigned_int(s, 0)
    assert s.getvalue() == b'\x00\x00\x00\x00'
    write_unsigned_int(s, 0xFF)
    assert s.getvalue() == b'\x00\x00\x00\x00\x00\x00\x00\xFF'
    write_unsigned_int(s, 0xFFFF)
    assert s.getvalue() == b'\x00\x00\x00\x00\x00\x00\x00\xFF\x00\x00\x00\xFF'
    write_unsigned_int(s, 0xFFFFFFFF)

# Generated at 2022-06-24 11:51:51.115717
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    flv_data = compat_struct_pack('!I', 0x00000001)
    reader = FlvReader(flv_data)
    assert reader.read_unsigned_int() == 1
    flv_data = compat_struct_pack('!I', 0x00000001)[:-2] + b'\x00' * 2
    reader = FlvReader(flv_data)
    try:
        reader.read_unsigned_int()
        assert False
    except DataTruncatedError as e:
        assert str(e) == 'FlvReader error: need 4 bytes while only 2 bytes got'


# Generated at 2022-06-24 11:51:53.590976
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    from ..utils import encode_data_uri
    from io import BytesIO
    stream = BytesIO()
    write_unsigned_int_24(stream, 0x12345678)
    assert stream.getvalue() == b'\x12\x34\x56'



# Generated at 2022-06-24 11:51:54.963579
# Unit test for constructor of class F4mFD
def test_F4mFD():
    F4mFD('http://www.youtube.com/fake', {})


# Generated at 2022-06-24 11:52:04.275475
# Unit test for function get_base_url
def test_get_base_url():
    manifest = '''<manifest xmlns="http://ns.adobe.com/f4m/1.0">
    <baseURL>http://example.com/</baseURL></manifest>'''
    assert 'http://example.com/' == get_base_url(
        compat_etree_fromstring(manifest.encode('utf-8')))
    manifest = '''<manifest xmlns="http://ns.adobe.com/f4m/1.0">
    <baseURL> http://example.com/</baseURL></manifest>'''
    assert 'http://example.com/' == get_base_url(
        compat_etree_fromstring(manifest.encode('utf-8')))

# Generated at 2022-06-24 11:52:10.337797
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    assert FlvReader(b'a\x00b\x00c\x00\x00').read_string() == b'a'
    assert FlvReader(b'a\x00b\x00c\x00\x00').read_string() == b'b'
    assert FlvReader(b'a\x00b\x00c\x00\x00').read_string() == b'c'



# Generated at 2022-06-24 11:52:20.199601
# Unit test for method read_bootstrap_info of class FlvReader