

# Generated at 2022-06-24 11:42:26.131990
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:42:30.794173
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    assert FlvReader(compat_struct_pack('!Q', 10)).read_unsigned_long_long() == 10
    try:
        FlvReader(compat_struct_pack('!I', 1)).read_unsigned_long_long()
        assert False
    except DataTruncatedError:
        pass


# Generated at 2022-06-24 11:42:35.742556
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    f = io.BytesIO()
    f.write(b'\x00\x01\x00\x00\x00\x02\x00\x00\x00\x02')
    f.seek(0)
    r = FlvReader(f)
    assert r.read_unsigned_char() == 0
    assert r.read_unsigned_char() == 1
    assert r.read_unsigned_char() == 2


# Generated at 2022-06-24 11:42:37.398771
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    with pytest.raises(DataTruncatedError):
        raise DataTruncatedError()



# Generated at 2022-06-24 11:42:47.652224
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-24 11:42:54.691884
# Unit test for constructor of class FlvReader
def test_FlvReader():
    test_data = (b'\x00\x00\x00\x00\x00\x00\x00\x00'
                 b'\x00\x00\x00\x00\x00\x00\x00\x00'
                 b'\x00\x00\x00\x00\x00\x00\x00\x00'
                 b'\x00\x00\x00\x00\x00\x00\x00\x00'
                 b'\x00\x00\x00\x00\x00\x00\x00\x00')
    f = FlvReader(test_data)
    assert f.read_unsigned_long_long() == 0
    assert f.read_unsigned_long_long() == 0
    assert f.read_unsigned

# Generated at 2022-06-24 11:43:01.431755
# Unit test for function build_fragments_list

# Generated at 2022-06-24 11:43:07.055917
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    from io import BytesIO
    from .test import read_test_data

    out = BytesIO()
    write_metadata_tag(out, b'\x01\x02\x03\x04')
    assert out.getvalue() == read_test_data(b'flv/metadata_tag.bin')
test_write_metadata_tag()



# Generated at 2022-06-24 11:43:12.835027
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import sys
    import youtube_dl.YoutubeDL
    from youtube_dl.utils import _args_from_opt_strings
    ydl = youtube_dl.YoutubeDL.YoutubeDL(_args_from_opt_strings(['--skip-download']))
    ydl.add_default_info_extractors()
    sys.argv.pop()
    sys.argv.pop()
    sys.argv.pop()
    sys.argv.pop()
    sys.argv.pop()
    sys.argv.append('https://vevoplaylist-live.hls.adaptive.level3.net/vevo/ch1/appleman.m3u8')
    ydl.download(sys.argv[1:])

# Generated at 2022-06-24 11:43:25.030334
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-24 11:43:29.400281
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import sys
    import test_download
    import test_dl
    def _do_test(filename='F4mFD_real_download_test_temp.flv', test_dir='./newTestVideo/F4mFD', test_name = 'F4mFD_real_download_test', url = 'http://live-1-1.rutube.ru/stream/1024/HDS/SD/C2NKsS85HQNckgn5HdEmOQ/1454167650/S-s604419906/move/four/dirs/upper/1024-576p.f4m'):
        len_file = 7988
        len_first_fragment = len_file - 9

# Generated at 2022-06-24 11:43:31.663898
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError
    except DataTruncatedError:
        # This is the expected control path
        pass
    else:
        raise Exception


# Generated at 2022-06-24 11:43:37.964766
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    b = io.BytesIO(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09')
    reader = FlvReader(b)
    assert reader.read_unsigned_char() == 0
    assert reader.read_unsigned_char() == 1
    assert reader.read_unsigned_char() == 2
    assert reader.read_unsigned_char() == 3
    assert b.tell() == 4


# Generated at 2022-06-24 11:43:48.225009
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-24 11:43:51.659321
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    flv_reader = FlvReader(b'\x01\x02\x03')
    assert flv_reader.read_unsigned_char() == 1
    assert flv_reader.read_unsigned_char() == 2
    assert flv_reader.read_unsigned_char() == 3

# Generated at 2022-06-24 11:44:01.651710
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:44:12.054844
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    class MyFlvReader(FlvReader):
        def __init__(self, data):
            FlvReader.__init__(self, data)
            self.times_read = 0

        def read(self, n):
            self.times_read += 1
            return FlvReader.read(self, n)

    f = MyFlvReader(b'test\x00test2\x00\x00\x00')

    assert f.read_string() == b'test'
    assert f.times_read == 5

    assert f.read_string() == b'test2'
    assert f.times_read == 10

    try:
        f.read_string()
        assert False
    except DataTruncatedError:
        pass
    assert f.times_read == 11



# Generated at 2022-06-24 11:44:18.780350
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    def decode_base64(s):
        return compat_b64decode(s.encode('ascii'))

# Generated at 2022-06-24 11:44:30.628240
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    from xml.etree import ElementTree
    from io import StringIO


# Generated at 2022-06-24 11:44:33.541816
# Unit test for function write_flv_header
def test_write_flv_header():
    test_stream = io.BytesIO()
    write_flv_header(test_stream)
    assert test_stream.getvalue() == (
        b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00')
test_write_flv_header()



# Generated at 2022-06-24 11:44:43.514686
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = b'\x00\x00\x00\x1c\x61\x73\x72\x74\x00\x00\x00\x00\x00\x00\x00\x01'
    data += b'\x00\x00\x00\x01\x69\x6d\x61\x67\x65\x00\x00\x00\x00\x00\x00\x00'
    data += b'\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'
    result = FlvReader(data).read_asrt()
    assert result['segment_run'] == [(1, 1)]



# Generated at 2022-06-24 11:44:46.698311
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    assert write_unsigned_int_24(io.BytesIO(), 0x12345).getvalue() == b'\x45\x23\x01'



# Generated at 2022-06-24 11:44:52.715346
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    assert FlvReader(b'\x00\x00\x01\xd4').read_unsigned_int() == 468
    assert FlvReader(b'\x00\x00\x00\x00').read_unsigned_int() == 0
    assert FlvReader(b'\xff\xff\xff\xff').read_unsigned_int() == 4294967295



# Generated at 2022-06-24 11:44:56.949632
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    from struct import pack
    flv_reader = FlvReader(pack('!Q', 0x123456789abcdef0))
    assert flv_reader.read_unsigned_long_long() == 0x123456789abcdef0



# Generated at 2022-06-24 11:44:58.671553
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    err = DataTruncatedError()
    assert(isinstance(err, DataTruncatedError))



# Generated at 2022-06-24 11:45:08.021140
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    f = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x00')
    assert f.read_box_info() == (0, b'\x00\x00\x00\x00', b'')

    f = FlvReader(b'\x00\x00\x00\x09\x66\x6c\x61\x67\x00\x00')
    assert f.read_box_info() == (9, b'flag', b'\x00\x00')

    f = FlvReader(b'\x00\x00\x01\x00\x66\x6c\x61\x67\x00\x00')

# Generated at 2022-06-24 11:45:11.871247
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    import os
    test_resources = os.path.join(os.path.dirname(__file__), 'test_data')
    with open(os.path.join(test_resources, 'test.bootstrap'), 'rb') as f:
        bootstrap_info = FlvReader(f.read()).read_bootstrap_info()
        assert bootstrap_info['fragments'][0]['fragments'][0]['duration'] == 60000



# Generated at 2022-06-24 11:45:12.828902
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError()
    except DataTruncatedError:
        pass


# Generated at 2022-06-24 11:45:17.127284
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    fd = io.BytesIO(b'\x00\x00\x00K\x00\x00\x00\x01foo\x00bar\x00')
    fr = FlvReader(fd)
    assert fr.read_unsigned_int() == 75
    assert fr.read_unsigned_int() == 1
    assert fr.read_string() == b'foo'
    assert fr.read_string() == b'bar'



# Generated at 2022-06-24 11:45:26.914859
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:45:29.136031
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    e = DataTruncatedError('test')




# Generated at 2022-06-24 11:45:32.293005
# Unit test for constructor of class FlvReader
def test_FlvReader():
    f = FlvReader(open('test.f4m', 'rb').read())
    bootstrap_info = f.read_bootstrap_info()
    print(bootstrap_info)



# Generated at 2022-06-24 11:45:40.657843
# Unit test for function build_fragments_list

# Generated at 2022-06-24 11:45:46.650689
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-24 11:45:49.074361
# Unit test for constructor of class F4mFD
def test_F4mFD():
    url = 'http://example.com/manifest.f4m'
    ydl = FakeYDL()
    ydl.add_default_info_extractors()
    fd = F4mFD(ydl, {'url':url})
    assert fd.FD_NAME == 'f4m'
    assert fd.ydl is ydl
    assert fd.params == {}
    assert fd.num == 0


# Generated at 2022-06-24 11:45:55.224786
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    flv_reader = FlvReader(b'abc\x00')
    assert flv_reader.read_unsigned_char() == 0x61
    assert flv_reader.read_unsigned_char() == 0x62
    assert flv_reader.read_unsigned_char() == 0x63
    assert flv_reader.read_unsigned_char() == 0x00


# Generated at 2022-06-24 11:45:58.562272
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    tdata = b'\x00\x00\x00\x00\x00\x00\x00\x03'
    reader = FlvReader(tdata)
    assert reader.read_unsigned_long_long() == 3


# Generated at 2022-06-24 11:46:02.560845
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    import hashlib
    stream = io.BytesIO()
    metadata = b'hello world'
    write_metadata_tag(stream, metadata)
    assert hashlib.md5(stream.getvalue()).hexdigest() == 'c8b512f5975ba6e1b0d56e965b4ea6e1'



# Generated at 2022-06-24 11:46:13.748701
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    import unittest
    import tempfile
    import shutil

    class TestCases(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            self.temp_dir = tempfile.mkdtemp()
            super(TestCases, self).__init__(*args, **kwargs)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_write_unsigned_int_24(self):
            # Test 24-bit unsigned integer can be written
            f = open(os.path.join(self.temp_dir, 'foo'), 'wb')
            write_unsigned_int_24(f, 16777216)
            f.close()

# Generated at 2022-06-24 11:46:24.298270
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    size_test = [1, 100, 20000]
    for size in size_test:
        tmp = io.BytesIO()
        for i in range(size):
            tmp.write(compat_struct_pack('!B', i % 256))
        tmp.seek(0)
        reader = FlvReader(tmp.read())
        for i in range(size):
            reader.read_bytes(1)
            assert reader.tell() == i + 1

    try:
        reader.read_bytes(1)
    except DataTruncatedError:
        pass
    else:
        raise Exception('DataTruncatedError not raised')



# Generated at 2022-06-24 11:46:29.749199
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    xml_str = """
    <media>
        <metadata />
        <metadata drmAdditionalHeaderId="0" />
        <metadata drmAdditionalHeaderSetId="1" />
        <metadata drmAdditionalHeaderId="2" drmAdditionalHeaderSetId="3" />
        <metadata />
    </media>
    """
    xml = compat_etree_fromstring(xml_str)
    assert len(xml.findall('metadata')) == 5
    assert len(remove_encrypted_media(xml.findall('metadata'))) == 2



# Generated at 2022-06-24 11:46:40.697246
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-24 11:46:45.647784
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = compat_etree_fromstring(
        '<media url="http://example.com/foo.mp4" bitrate="928" '
        'drmAdditionalHeaderSetId="my_header" '
        'drmAdditionalHeaderId="my_header_2">test</media>'
    )
    assert remove_encrypted_media(media) == []



# Generated at 2022-06-24 11:46:52.978566
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    assert FlvReader(b'\x00\x00\x00\x00\x00\x00\x05\x10').read_unsigned_long_long() == 1320
    assert FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x05\x10').read_unsigned_long_long() == 1320



# Generated at 2022-06-24 11:46:59.050425
# Unit test for function build_fragments_list
def test_build_fragments_list():
    import sys
    import glob
    for f in glob.glob('../ytdl/extractor/test/fixtures/hds/*.bootstrap'):
        bootstrap_bytes = open(f, 'rb').read()
        boot_info = read_bootstrap_info(bootstrap_bytes)

        try:
            assert boot_info['live'] == ('live' in f)
            fragments = build_fragments_list(boot_info)
            assert len(fragments) > 0
        except:
            print(f)
            raise


# Generated at 2022-06-24 11:47:01.626671
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError("DataTruncatedError Test")
    except DataTruncatedError as e:
        assert str(e) == 'DataTruncatedError Test'


# Generated at 2022-06-24 11:47:13.655693
# Unit test for function build_fragments_list

# Generated at 2022-06-24 11:47:17.370579
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    # 0x100000000 (4 bytes)
    data = b'\x00\x00\x00\x01\x00\x00\x00\x00'
    assert FlvReader(data).read_unsigned_long_long() == 0x100000000

# Generated at 2022-06-24 11:47:27.337410
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media_xml = "<media href='url.flv'/>" \
                "<media href='url.flv' drmAdditionalHeaderId='1'/>" \
                "<media href='url.mp4' drmAdditionalHeaderId='2'/>" \
                "<media href='url.mp4' drmAdditionalHeaderSetId='1'/>" \
                "<media href='url.mp4' drmAdditionalHeaderSetId='2'/>"
    media_xml_tree = compat_etree_fromstring(media_xml)
    media_elements = media_xml_tree.getchildren()
    media_elements_expected = media_elements[0:1]
    media_elements_result = remove_encrypted_media(media_elements)
    assert media_elements_expected == media_elements_result



# Generated at 2022-06-24 11:47:39.215740
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    def read_abst(data):
        return FlvReader(data).read_abst()

# Generated at 2022-06-24 11:47:51.052019
# Unit test for function get_base_url
def test_get_base_url():
    assert get_base_url(compat_etree_fromstring('''
    <manifest xmlns="http://ns.adobe.com/f4m/1.0">
        <baseURL>base/url/</baseURL>
    </manifest>
    ''')) == 'base/url/'
    assert get_base_url(compat_etree_fromstring('''
    <manifest xmlns="http://ns.adobe.com/f4m/1.0">
        <baseURL/>
    </manifest>
    ''')) == ''
    assert get_base_url(compat_etree_fromstring('''
    <manifest xmlns="http://ns.adobe.com/f4m/1.0"/>
    ''')) is None



# Generated at 2022-06-24 11:47:54.633695
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-24 11:48:03.619287
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    data = b'\x00\x00\x00%ftypisomiso2avc1mp41\x00\x00\x02\x00free\x05\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    box_info = FlvReader(data).read_box_info()
    assert box_info[0]

# Generated at 2022-06-24 11:48:10.275198
# Unit test for function build_fragments_list
def test_build_fragments_list():
    from .smil import SMIL_DATA

    boot_info = read_bootstrap_info(SMIL_DATA)
    res = build_fragments_list(boot_info)
    if boot_info['live']:
        assert res[-1][1] == res[-2][1] + 1
    else:
        assert res == [(4, 1), (4, 2)]
test_build_fragments_list()



# Generated at 2022-06-24 11:48:22.360678
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    metadata = b'<?xml version="1.0" encoding="UTF-8"?>'
    '<abst'
    '  packetTime="2000"'
    '  timeScale="20000"'
    '  currentTime="20175"'
    '  live="0"'
    '  profile="live"'
    '  version="1"'
    '  bootstrapInfoId="_default"'
    '  url="" >'
    '  <segments'
    '    duration="2013"'
    '    segmentCount="3"'
    '    bitrate="0"'
    '  />'
    '  <fragments'
    '    duration="2013"'
    '    bitrate="0"'
    '    fragmentCount="3"'
    '    firstFragment="1"'
    '    lastFragment="3"'

# Generated at 2022-06-24 11:48:26.389019
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-24 11:48:37.273680
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'live': False,
        'segments': [
            {
                'segment_run': [
                    (0, 2),
                    (1, 3),
                ]
            }
        ],
        'fragments': [
            {
                'fragments': [
                    {'first': 1, 'duration': 0},
                    {'first': 2, 'duration': 0},
                    {'first': 3, 'duration': 0},
                    {'first': 4, 'duration': 0},
                    {'first': 5, 'duration': 0},
                ]
            }
        ]
    }


# Generated at 2022-06-24 11:48:43.383169
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    data = [0, 1, 2, 3, 0x7F]
    for i in data:
        data = compat_struct_pack('!%sB' % (len(data)), *data)
        bytes_io = FlvReader(data)
        for j in data:
            assert bytes_io.read_unsigned_char() == j



# Generated at 2022-06-24 11:48:53.169913
# Unit test for constructor of class FlvReader

# Generated at 2022-06-24 11:49:03.728190
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # Test an MPEG-4 file
    data = b'\x00\x00\x00\x1C\x66\x74\x79\x70\x69\x73\x6F\x6D\x00\x00\x00\x01\x69\x73\x6F\x6D\x69\x6E\x66\x00\x00\x00\x01\x6D\x6F\x6F\x76\x00\x00\x00\x00'
    reader = FlvReader(data)
    assert reader.read_box_info() == (
        28, b'ftyp', b'isom\x00\x00\x00\x01isom\x00\x00\x00\x01moov')


# Unit test

# Generated at 2022-06-24 11:49:07.021550
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    write_unsigned_int(stream, 10)
    assert stream.getvalue() == b'\x00\x00\x00\n'



# Generated at 2022-06-24 11:49:12.603927
# Unit test for function write_flv_header
def test_write_flv_header():
    from ..compat import compat_BytesIO
    stream = compat_BytesIO()
    write_flv_header(stream)
    return stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'


# Generated at 2022-06-24 11:49:20.995451
# Unit test for function write_metadata_tag

# Generated at 2022-06-24 11:49:31.030705
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media0 = compat_etree_fromstring(
        '<media url="http://example.com/M1.f4m" bitrate="400" bootstrapInfoId="a" metadataId="d" drmAdditionalHeaderId="h" drmAdditionalHeaderSetId="s"><metadata>M1</metadata></media>')
    media1 = compat_etree_fromstring(
        '<media url="http://example.com/M2.f4m" bitrate="400" bootstrapInfoId="a" metadataId="d"><metadata>M2</metadata></media>')

# Generated at 2022-06-24 11:49:36.932639
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():

    data = b"\x00\x00\x00X\xafrt\x00\x00\x00\x00\x00\x00\x00\x03\xe8\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01"
    #data = b'\x00\x00\x00\x5b\xafrt\x00\x00\x00\x00\x00\x00\x00\x03\xe8\x00\x00\x

# Generated at 2022-06-24 11:49:45.703095
# Unit test for function get_base_url
def test_get_base_url():
    manifest_1 = compat_etree_fromstring('''
        <manifest xmlns="http://ns.adobe.com/f4m/1.0">
          <baseURL>
            http://test.url
          </baseURL>
        </manifest>
    ''')

    manifest_2 = compat_etree_fromstring('''
        <manifest xmlns="http://ns.adobe.com/f4m/2.0">
          <baseURL>
          http://another.test.url
          </baseURL>
        </manifest>
    ''')

    manifest_3 = compat_etree_fromstring('''
        <manifest xmlns="http://ns.adobe.com/f4m/1.0">
        </manifest>
    ''')

    assert get_base_

# Generated at 2022-06-24 11:49:51.828143
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'
# end unit test


# Generated at 2022-06-24 11:50:02.137467
# Unit test for method read_box_info of class FlvReader

# Generated at 2022-06-24 11:50:05.628807
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError('foo')
    except DataTruncatedError as e:
        if e.args[0] != 'foo':
            raise Exception(e.args[0])



# Generated at 2022-06-24 11:50:14.299523
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    data1 = b'\x01\x01\x02\x04\x08\x10\x20\x40\x80\xff\xff\xff\xff\xff\xff\xff\xff'
    data2 = b'\x01\x00\x02\x00\x08\x00\x10\x00\x20\x00\x40\x00\x80\x00\xff\x00\x00'
    fp = io.BytesIO(data1 + data2)
    reader = FlvReader(fp)
    assert reader.read_unsigned_char() == 1
    assert reader.tell() == 1
    assert reader.read_unsigned_char() == 1
    assert reader.tell() == 2
    assert reader.read_unsigned_char() == 2

# Generated at 2022-06-24 11:50:18.690655
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    res = io.BytesIO()
    write_unsigned_int(res, 1)
    write_unsigned_int(res, 0xFFFFFFFF)
    assert res.getvalue() == b'\x00\x00\x00\x01\xFF\xFF\xFF\xFF'



# Generated at 2022-06-24 11:50:28.616510
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    import unittest

    class FlvReaderTest(unittest.TestCase):
        def test_read_abst(self):
            import base64
            data = compat_b64decode(
                'AAAA/wAAAAAAAAAAAAAAAAAAAAAA//+MQAAEgACYdt/AAAOCvcAAEUAQAAAAAAAAAAAAAAAQAA')
            data = FlvReader(data).read_abst()
            self.assertEqual(data['live'], False)
            self.assertEqual(len(data['segments']), 1)
            self.assertEqual(len(data['fragments']), 1)

    return unittest.main()



# Generated at 2022-06-24 11:50:38.778682
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    test_data = bytearray(b'\x00\x00\x00\x00')

    reader = FlvReader(test_data)
    box_info = reader.read_box_info()
    assert box_info == (0, b'\x00\x00\x00\x00', b'')

    test_data = bytearray(b'\x00\x00\x00\x08data\x00\x00\x00')
    reader = FlvReader(test_data)
    box_info = reader.read_box_info()
    assert box_info == (8, b'data', b'\x00\x00\x00')


# Generated at 2022-06-24 11:50:44.856706
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    write_unsigned_int(stream, 0)
    write_unsigned_int(stream, 1)
    write_unsigned_int(stream, 4294967295)
    assert stream.getvalue() == b'\x00\x00\x00\x00\x00\x00\x00\x01\xff\xff\xff\xff'



# Generated at 2022-06-24 11:50:48.901135
# Unit test for function get_base_url
def test_get_base_url():
    assert get_base_url(compat_etree_fromstring('<manifest/>')) is None
    assert get_base_url(compat_etree_fromstring(
        '<manifest><baseURL>http://example.com/</baseURL></manifest>'
    )) == 'http://example.com/'



# Generated at 2022-06-24 11:50:52.590407
# Unit test for constructor of class FlvReader
def test_FlvReader():
    with io.open('tests/data/live_hls_bootstrap.bin', 'rb') as f:
        abst = FlvReader(f.read()).read_bootstrap_info()
    assert abst['fragments'][0]['fragments'][0]['duration'] == 250



# Generated at 2022-06-24 11:50:56.789350
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    s = b'0123456789'
    reader = FlvReader(s)
    assert reader.read_bytes(3) == b'012'
    assert reader.read_bytes(3) == b'345'
    assert reader.read_bytes(3) == b'678'
    assert reader.read_bytes(3) == b'9'


# Generated at 2022-06-24 11:51:07.686794
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    import unittest
    import io
    class TestWriteUnsignedInt(unittest.TestCase):
        def test_write(self):
            val = 99
            file_stream = io.BytesIO()
            write_unsigned_int(file_stream, val)
            file_stream.seek(0, 0)
            result = file_stream.read(4)

            self.assertEqual(
                result,
                b'\x00\x00\x00c',
                "write_unsigned_int does not work."
            )

    suite = unittest.TestLoader().loadTestsFromTestCase(TestWriteUnsignedInt)
    unittest.TextTestRunner(verbosity=2).run(suite)



# Generated at 2022-06-24 11:51:11.125450
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    s = io.BytesIO()
    write_unsigned_int_24(s, 0x01020304)
    assert s.getvalue() == b'\x01\x02\x03'
test_write_unsigned_int_24()



# Generated at 2022-06-24 11:51:20.564212
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import os
    assert os.path.sep != '/'
    test_F4mFD_real_download_src = (
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">\n'
        '  <baseURL>file:///tmp/</baseURL>\n'
        '  <media url="test"/>\n'
        '  <bootstrapInfo url="test_bootstrap"/>\n'
        '</manifest>\n'
    )

# Generated at 2022-06-24 11:51:27.030062
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    x = io.BytesIO()
    write_unsigned_int(x, 0x1234abcd)
    c = x.getvalue()
    assert c == b'\xcd\xab\x34\x12'
    x = io.BytesIO()
    write_unsigned_int(x, 0xabcd)
    c = x.getvalue()
    assert c == b'\x00\x00\xcd\xab'
    x = io.BytesIO()
    write_unsigned_int(x, 0xffff)
    c = x.getvalue()
    assert c == b'\xff\xff\x00\x00'
test_write_unsigned_int()



# Generated at 2022-06-24 11:51:32.632634
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x01'
                       + b'\x00\x00\x00\x00\x00\x00\x00\x02')
    assert reader.read_unsigned_long_long() == 1
    assert reader.read_unsigned_long_long() == 2


# Generated at 2022-06-24 11:51:35.252456
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    for i in range(2**32):
        stream.truncate(0)
        write_unsigned_int(stream, i)
        assert read_unsigned_int(stream) == i



# Generated at 2022-06-24 11:51:44.513697
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-24 11:51:55.770302
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:52:05.070299
# Unit test for constructor of class F4mFD

# Generated at 2022-06-24 11:52:14.134045
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    flv_reader = FlvReader(b'abcd\x00\x00\x00efgh\x00ijklmn\x00opq\x00\x00\x00\x00rst')
    assert flv_reader.read_string() == b'abcd'
    assert flv_reader.read_string() == b'\x00\x00\x00efgh'
    assert flv_reader.read_string() == b'ijklmn'
    assert flv_reader.read_string() == b'opq'
    assert flv_reader.read_string() == b'\x00\x00\x00\x00rst'



# Generated at 2022-06-24 11:52:22.850435
# Unit test for method read_abst of class FlvReader