

# Generated at 2022-06-24 11:42:28.125852
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    """
    Test for the read_afrt() method, of class FlvReader
    """

# Generated at 2022-06-24 11:42:31.461737
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    reader = FlvReader()
    reader.write(b'\x00\x03foo\x00\x0512345\x00')
    reader.seek(0)
    assert reader.read_string() == b'foo'
    assert reader.read_string() == b'12345'
    assert reader.read_string() == b''



# Generated at 2022-06-24 11:42:40.590177
# Unit test for function read_bootstrap_info

# Generated at 2022-06-24 11:42:46.767673
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = read_bootstrap_info(open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                      'data', 'bootstrap.abst'), 'rb').read())
    segments = build_fragments_list(boot_info)
    assert len(segments) == 8
    assert segments[0] == (1, 1)
    assert segments[7] == (1, 8)



# Generated at 2022-06-24 11:42:53.875114
# Unit test for function read_bootstrap_info

# Generated at 2022-06-24 11:43:01.106744
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    data = b'\x00'
    assert FlvReader(data).read_string() == b''
    data = b'\x01\x00'
    assert FlvReader(data).read_string() == b'\x01'
    data = b'\x01\x02\x00'
    assert FlvReader(data).read_string() == b'\x01\x02'

# Generated at 2022-06-24 11:43:04.483296
# Unit test for constructor of class F4mFD
def test_F4mFD():
    with NamedTemporaryFile(suffix='.f4m') as t:
        fd = F4mFD(
            0,
            None,
            'http://example.com/manifest.f4m',
            'abcd',
            {'retries': 10},
            t.name,
            {})
        assert fd.retries == 10



# Generated at 2022-06-24 11:43:15.345083
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    doc = '''
    <?xml version="1.0"?>
    <D:prop xmlns:D="DAV:">
        <D:resourcetype>
            <D:collection/>
        </D:resourcetype>
        <D:creationdate>2013-10-02T05:15:11Z</D:creationdate>
        <D:getcontenttype/>
        <D:getcontentlength/>
        <D:getlastmodified>Wed, 02 Oct 2013 05:00:39 GMT</D:getlastmodified>
        <D:getetag>W/"1a7970-d6-4eb6a2b55f9c0"</D:getetag>
        <D:lockdiscovery/>
        <D:getcontentlanguage/>
    </D:prop>
    '''

# Generated at 2022-06-24 11:43:17.963160
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError('Unit testing DataTruncatedError class')
    except DataTruncatedError as e:
        assert e.args[0] == 'Unit testing DataTruncatedError class'



# Generated at 2022-06-24 11:43:28.634906
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:43:33.225839
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    assert FlvReader(compat_struct_pack('!Q', 1)).read_unsigned_long_long() == 1
    assert FlvReader(compat_struct_pack('!Q', 2 ** 32 - 1)).read_unsigned_long_long() == 2 ** 32 - 1
    assert FlvReader(compat_struct_pack('!Q', 2 ** 32)).read_unsigned_long_long() == 2 ** 32



# Generated at 2022-06-24 11:43:38.446493
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    reader = FlvReader(bytes(64))
    val = reader.read_unsigned_char()
    assert val == 0

    reader = FlvReader(bytes([255, 255]))
    val = reader.read_unsigned_char()
    assert val == 255

    reader = FlvReader(bytes([0, 255]))
    val = reader.read_unsigned_char()
    assert val == 0

# Generated at 2022-06-24 11:43:43.410714
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    from tempfile import NamedTemporaryFile
    from .fragment import FragmentFD
    write_metadata_tag(NamedTemporaryFile(delete=False), "")
    return True


# Generated at 2022-06-24 11:43:48.088373
# Unit test for constructor of class FlvReader
def test_FlvReader():
    import os
    test_file = 'bootstrapinfo.txt'
    with io.open(test_file, 'rb') as f:
        bootstrapinfo = f.read()
    try:
        FlvReader(bootstrapinfo).read_bootstrap_info()
    except AssertionError:
        raise AssertionError('Failed to parse %s' % test_file)


# Generated at 2022-06-24 11:43:59.950483
# Unit test for constructor of class F4mFD
def test_F4mFD():
    from .extractor.common import InfoExtractor
    from .downloader import get_suitable_downloader

    class MockIE(InfoExtractor):
        def __init__(self, youtube_id):
            self.youtube_id = youtube_id
            InfoExtractor.__init__(self, None)

        def _real_extract(self, url):
            return {
                'id': self.youtube_id,
                'ext': 'f4m',
                'url': url,
                'title': 'Title %s' % self.youtube_id,
            }

    # Test the case where the last fragment has been downloaded
    ie = MockIE('QKeLi_f5yjY')

# Generated at 2022-06-24 11:44:03.150363
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError()
    except DataTruncatedError as e:
        pass


# Generated at 2022-06-24 11:44:12.970584
# Unit test for function remove_encrypted_media

# Generated at 2022-06-24 11:44:19.674960
# Unit test for method read_string of class FlvReader

# Generated at 2022-06-24 11:44:24.355514
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    with io.BytesIO() as test_stream:
        write_unsigned_int(test_stream, 0x01020304)
        test_stream.seek(0)
        assert test_stream.read(4) == compat_struct_pack('!I', 0x01020304)



# Generated at 2022-06-24 11:44:34.320539
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    import unittest
    import base64


# Generated at 2022-06-24 11:44:41.879013
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    file_content = b'\x00\x00\x00\x18abcd\x00\x00\x00\x04dada\x00\x00\x00\x18dcba'
    fr = FlvReader(file_content)
    for box_size, box_type, box_data in (
            (24, b'abcd', b'\x00\x00\x00\x04dada'),
            (24, b'dcba', b'')):
        s, t, d = fr.read_box_info()
        assert s == box_size
        assert t == box_type
        assert d == box_data
    try:
        fr.read_box_info()
        assert False
    except DataTruncatedError:
        pass

# Generated at 2022-06-24 11:44:49.028781
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = compat_etree_fromstring(
        b'<media url="media_l3_1_aac_und_1_96_amf_ipad_streaming.ismv" bitrate="96000" '
        b'bootstrapInfoId="bootstrap_l3_1_aac_und_1_96_amf_ipad_streaming.abst" '
        b'drmAdditionalHeaderId="0" drmAdditionalHeaderSetId="3" '
        b'drmAdditionalHeaderSetVersion="1" drmAdditionalHeaderSetCount="3"/>')
    assert remove_encrypted_media(media) == []


# Generated at 2022-06-24 11:44:52.874392
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    f = FlvReader(b'\x01\x00\x00\x00' + b'\xff' * 7)
    assert f.read_unsigned_long_long() == 1
    # Test for overflow, the high 1 byte will be discarded
    f = FlvReader(b'\x01\x00\x00\x00' + b'\xff' * 15)
    assert f.read_unsigned_long_long() == 1
    try:
        f.read_unsigned_long_long()
        assert False
    except DataTruncatedError:
        pass



# Generated at 2022-06-24 11:45:03.927101
# Unit test for function build_fragments_list
def test_build_fragments_list():
    from ..utils import encode_base_n

    # Running in a context so that we can modify sys.stdout
    class _FakeStdout(io.BytesIO):
        def write(self, s):
            pass

    with contextlib.nested(_FakeStdout(),
                           contextlib.closing(io.open('/dev/null', 'w'))) as (fake_stdout, null_file):
        old_stdout = sys.stdout

# Generated at 2022-06-24 11:45:07.262216
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    f = FlvReader(b'1234567890')
    assert f.read_bytes(3) == b'123'
    assert f.read_bytes(3) == b'456'
# Unit tests for method read_unsigned_long_long of class FlvReader

# Generated at 2022-06-24 11:45:14.163934
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    data = b'\x03abc\x00\x04123\x00\x06\x00\x00\x00'
    reader = FlvReader(data)
    assert reader.read_string() == b'abc'
    assert reader.read_string() == b'123'
    assert reader.read_string() == b''
    assert reader.read_string() == b''
    assert reader.read_string() == b''



# Generated at 2022-06-24 11:45:20.033217
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    flv_file = FlvReader(open(
        'test/test_videos/test.f4v', 'rb').read())
    assert flv_file.read_unsigned_int() == 8
    assert flv_file.read_unsigned_int() == 1836019574
    assert flv_file.read_unsigned_int() == 0



# Generated at 2022-06-24 11:45:30.939752
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    write_unsigned_int(stream, 0)
    assert stream.getvalue() == b'\x00\x00\x00\x00'
    stream.seek(0)
    write_unsigned_int(stream, 1)
    assert stream.getvalue() == b'\x00\x00\x00\x01'
    stream.seek(0)
    write_unsigned_int(stream, 255)
    assert stream.getvalue() == b'\x00\x00\x00\xff'
    stream.seek(0)
    write_unsigned_int(stream, 16777215)
    assert stream.getvalue() == b'\x00\x00\xff\xff'
    stream.seek(0)

# Generated at 2022-06-24 11:45:35.069139
# Unit test for function write_flv_header
def test_write_flv_header():
    from ..compat import BytesIO
    stream = BytesIO()
    write_flv_header(stream)
    assert (stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\t\x00\x00\x00\x00')



# Generated at 2022-06-24 11:45:37.737180
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    data = compat_struct_pack('!Q', 0x12345678abcdef01)
    assert FlvReader(data).read_unsigned_long_long() == 0x12345678abcdef01



# Generated at 2022-06-24 11:45:44.458557
# Unit test for constructor of class FlvReader
def test_FlvReader():
    a = b'\x00\x00\x00\x11' + b'asrt' + \
        b'\x01\x00\x00\x00\x01\x00\x00\x00' + \
        b'\x05test1\x00' + \
        b'\x00\x00\x00\x07' + \
        b'\x00\x00\x00\x01\x00\x00\x00\x05' + \
        b'\x01\x00\x00\x00\x01\x00\x00\x00\x01'


# Generated at 2022-06-24 11:45:51.026808
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    with open('test.flv', 'wb') as f:
        write_flv_header(f)
        write_metadata_tag(f, b'<test>test test</test>')
        write_metadata_tag(f, None)



# Generated at 2022-06-24 11:45:57.278669
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    flv_reader = FlvReader(b'\x00\x00\x00\x08\x00\x00\x00\x08' + b'a' * 8)
    assert flv_reader.read_unsigned_long_long() == 8
    assert flv_reader.read_unsigned_long_long() == 8
    assert flv_reader.read_string() == b'a' * 8


# Generated at 2022-06-24 11:46:04.266340
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    # null-terminated string
    assert FlvReader(b'\x0b1234567890\x00\x01').read_string() == b'1234567890'
    # String without null terminator
    assert FlvReader(b'\x0b1234567890').read_string() == b'1234567890'
    # Empty string
    assert FlvReader(b'\x00').read_string() == b''



# Generated at 2022-06-24 11:46:14.206229
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data1 = b'\x00\x00\x00\x12@asrt\x03\x02\x00\x01\x07_default\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'
    data2 = b'\x00\x00\x00 \x40asrt\x00\x00\x00\x02\x07_default\x02\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'

# Generated at 2022-06-24 11:46:26.544080
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-24 11:46:35.251690
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = b'\x00\x00\x00\x1E\x61\x73\x72\x74\x01\x61\x61'
    data += b'\x00\x00\x00\x03\x00\x00\x00\x01\x00\x00\x00\x05\x00\x00\x00\x02\x00\x00\x00\x06'
    assert FlvReader(data).read_asrt() == {
        'segment_run': [(1, 5), (2, 6)],
    }



# Generated at 2022-06-24 11:46:44.336336
# Unit test for function build_fragments_list
def test_build_fragments_list():
    # A test case
    boot_info = {
        'segments': [
            {'segment_run': [
                (1, 2),
                (2, 3),
                (3, 1),
            ]},
        ],
        'fragments': [
            {'fragments': [
                {'first': 1, 'discontinuity_indicator': None},
                {'first': 2, 'discontinuity_indicator': None},
                {'first': 3, 'discontinuity_indicator': None},
                {'first': 4, 'discontinuity_indicator': None},
                {'first': 5, 'discontinuity_indicator': None},
                {'first': 6, 'discontinuity_indicator': None},
            ]}
        ],
    }


# Generated at 2022-06-24 11:46:52.978300
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    flv_reader = FlvReader(b'Hello\x00World')
    assert flv_reader.read_bytes(1) == b'H'
    assert flv_reader.read_bytes(5) == b'ello\x00'
    assert flv_reader.read_bytes(5) == b'World'
    try:
        flv_reader.read_bytes(1)
    except DataTruncatedError as e:
        assert str(e) == 'FlvReader error: need 1 bytes while only 0 bytes got'
    else:
        assert False


# Generated at 2022-06-24 11:47:01.611583
# Unit test for function get_base_url
def test_get_base_url():
    test_manifest = """
<manifest xmlns="http://ns.adobe.com/f4m/2.0">
<baseURL>http://www.example.com/</baseURL>
<media>
<video bitrate="938" />
</media>
</manifest>"""
    assert get_base_url(compat_etree_fromstring(test_manifest)) == 'http://www.example.com/'

    test_manifest2 = """
<manifest xmlns="http://ns.adobe.com/f4m/1.0">
<baseURL>http://www.example.com/</baseURL>
<media>
<video bitrate="938" />
</media>
</manifest>"""

# Generated at 2022-06-24 11:47:07.552217
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    flv_reader = FlvReader(b'\x00\x00\x00\x04test')
    assert flv_reader.read_unsigned_int() == 4
    assert flv_reader.read() == b'test'
    assert flv_reader.read_unsigned_int() == 4
    assert flv_reader.read() == b'test'

# Generated at 2022-06-24 11:47:10.558462
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError('hello')
    except DataTruncatedError as e:
        assert e.args[0] == 'hello'


# Generated at 2022-06-24 11:47:14.825016
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    n = 0x1234567890ABCDEF
    s = compat_struct_pack('!Q', n)
    r = FlvReader(s)
    nn = r.read_unsigned_long_long()
    assert n == nn



# Generated at 2022-06-24 11:47:16.490699
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    reader = FlvReader(compat_struct_pack('!B', 10))
    assert reader.read_unsigned_char() == 10



# Generated at 2022-06-24 11:47:26.717130
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    bootstrap_info = '''<bootstrapInfo
        profile="named"
        id="Bootstrap1"
        timeScale="1000"
        mediaTime="0"
        serverBaseURL="http://server/content"
       >
        <metrics
        bandwidth="500000"
        width="640"
        height="480"
        />
        <segmentRunTable
        quality="High"
        segmentDuration="9000"
        mediaURL="hls_450k_video.ts"
        />
        <segmentRunTable
        quality="Low"
        segmentDuration="9000"
        mediaURL="hls_70k_video.ts"
        />
    </bootstrapInfo>'''

    parsed = read_bootstrap_info(bootstrap_info)
#     print parsed
#     print parsed['segments']

# Generated at 2022-06-24 11:47:35.041723
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    assert FlvReader(b'test\x00\x00\x00\x00').read_string() == b'test'
    assert FlvReader(b'test\x00\x00\x00').read_string() == b'test'
    assert FlvReader(b'test\x00\x00').read_string() == b'test'
    assert FlvReader(b'test\x00').read_string() == b'test'



# Generated at 2022-06-24 11:47:40.541977
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    write_unsigned_int(stream, 4294967295)
    assert stream.getvalue() == b'\xff\xff\xff\xff'
try:
    test_write_unsigned_int()
except AssertionError:
    def write_unsigned_int(stream, val):
        stream.write(compat_struct_pack('!I', val & 0xffffffff))
    test_write_unsigned_int()



# Generated at 2022-06-24 11:47:46.476408
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    with open('tests/test.flv', 'rb') as flv_file:
        reader = FlvReader(flv_file.read())
    size, type, data = reader.read_box_info()
    assert size == 379
    assert type == b'abst'

# Unit tests for method read_type of class FlvReader

# Generated at 2022-06-24 11:47:56.296312
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-24 11:48:03.253586
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    data = (
        b'\x00\x00\x00\x21'
        b'abst'
        b'\x00\x00\x00\x00\x00\x00\x00\x01'
        b'\x00\x00\x00\x00\x00\x00\x00\x01'
    )
    res = FlvReader(data).read_box_info()
    assert res == (33, b'abst', b'\x00\x00\x00\x00\x00\x00\x00\x01')



# Generated at 2022-06-24 11:48:11.820589
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    data = (
        b'\x00\x00\x00\x01'
        b'\x01'
        b'\x00\x00\x00'
    )
    reader = FlvReader(data)
    assert reader.read_bytes(4) == data[:4]
    assert reader.read_bytes(1) == data[4:5]
    assert reader.read_bytes(3) == data[5:]
    try:
        reader.read_bytes(1)
        assert False
    except DataTruncatedError:
        pass



# Generated at 2022-06-24 11:48:18.802276
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    stream = io.BytesIO()
    for val in [0x0, 0xff, 0xffff, 0xffffff]:
        write_unsigned_int_24(stream, val)
        assert stream.getvalue() == compat_struct_pack('!I', val)[1:]
        stream.seek(0)
        stream.truncate(0)



# Generated at 2022-06-24 11:48:27.531508
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from ..extractor.hls import HlsFD, HlsNativeFD
    from ..compat import (
        compat_parse_qs,
        compat_urllib_request,
    )
    from ..downloader.http import HttpFD
    from ..cache import cache
    from ..utils import (
        sanitize_open,
    )

    # Some m3u8 URL that contains "abst" box
    url = 'http://tungsten.aaplimg.com/VOD/bipbop_adv_example_v2/master.m3u8'
    hls_url = HlsNativeFD(url).get_best_entry().path
    abst_data = cache.load('FlvReader_read_abst', lambda: HttpFD(hls_url).read())

# Generated at 2022-06-24 11:48:30.523170
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    reader = FlvReader(b'\x00' * 7 + b'\x01')
    assert reader.read_unsigned_long_long() == 1



# Generated at 2022-06-24 11:48:34.454029
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-24 11:48:35.385604
# Unit test for constructor of class F4mFD
def test_F4mFD():
    f4m_fd = F4mFD()
    assert f4m_fd.FD_NAME == 'f4m'

# Generated at 2022-06-24 11:48:36.952250
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    assert write_unsigned_int(io.BytesIO(), 1) == 4
    import struct
    assert write_unsigned_int(io.BytesIO(), 2**32) == 8
    assert write_unsigned_int(io.BytesIO(), 2**32-1) == 4



# Generated at 2022-06-24 11:48:44.807528
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    fmt = compat_struct_pack('!I', 16)
    fmt += b"asrt"
    fmt += compat_struct_pack('!B', 1) # QualityEntryCount
    fmt += b"\x01\x02" # QualitySegmentUrlModifiers
    fmt += compat_struct_pack('!I', 0) # SegmentRunCount
    flvReader = FlvReader(fmt)
    assert flvReader.read_asrt() == {
        'segment_run': [],
    }


# Generated at 2022-06-24 11:48:47.803333
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    b = compat_struct_pack('!B', 0xAB)
    with FlvReader(b) as f:
        assert f.read_unsigned_char() == 0xAB



# Generated at 2022-06-24 11:49:00.065933
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    from ..compat import bytes_to_intlist

# Generated at 2022-06-24 11:49:07.580529
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    stream = io.BytesIO()
    metadata = b'''<?xml version="1.0" encoding="utf-8"?>
    <D:propertyupdate xmlns:D="DAV:"><D:set><D:prop><future:random xmlns:future="http://example.com/neon/litmus/">random</future:random></D:prop></D:set></D:propertyupdate>'''
    metadata = fix_xml_ampersands(metadata)

# Generated at 2022-06-24 11:49:18.569701
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from .test import read_test_data
    bootstrap_info_data = read_test_data('bootstrapinfo.bin')
    bootstrap_info = FlvReader(bootstrap_info_data).read_bootstrap_info()
    assert bootstrap_info['segments'][0]['segment_run'] == [
        (0, 11),
        (11, 136),
        (147, 14),
    ]

# Generated at 2022-06-24 11:49:29.282829
# Unit test for function read_bootstrap_info

# Generated at 2022-06-24 11:49:40.123282
# Unit test for function remove_encrypted_media

# Generated at 2022-06-24 11:49:47.258564
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-24 11:49:59.668641
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # Test on a flv sample which has a box of size 1
    with io.open('tests/testdata/FlvReader/box_size_1.flv', 'rb') as f:
        box_size, box_type, box_data = FlvReader(f.read()).read_box_info()
    assert box_size == 48
    assert box_type == b'mdat'
    assert box_data[:4] == b'\x00\x00\x00\x12'
    assert len(box_data) == box_size - 16
    # Test on a flv sample which has a box of size 0

# Generated at 2022-06-24 11:50:11.787126
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from .compat import parse_qsl
    from .utils import format_bytes
    from .downloader import FileDownloader

    # Case 1: Downloading a f4m manifest file
    # videourl url for testing: http://players.edgesuite.net/flash/plugins/osmf/advanced-streaming-plugin-2.0.swf?&streamType=live&src=http://www.helsinki.fi/~jjaakkol/test_flash.f4m
    class TestFD1(F4mFD):
        def real_download(self, filename, info_dict):
            return F4mFD.real_download(self, filename, info_dict)

    print("\nCase 1: Downloading a f4m manifest file")

# Generated at 2022-06-24 11:50:23.041424
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    import os.path
    f = os.path.join(os.path.dirname(os.path.realpath(__file__)),
                     'data', 'test.abst')

# Generated at 2022-06-24 11:50:34.260603
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    B64STR = ('AAAADUNLRUFZL1dJVEg5RDpGRVRDSFM6MzAwQzowMDA6Q049VElD'
              'AAAADUNLRUFZL1dJVEg5RDpGRVRDSFM6MzAwQzowMDA6Q049VElD')
    flv_data = compat_b64decode(B64STR)
    data = FlvReader(flv_data).read_bootstrap_info()
    assert len(data['segments']) == 1
    assert data['segments'][0]['segment_run'][1][1] == 24



# Generated at 2022-06-24 11:50:46.412859
# Unit test for function build_fragments_list

# Generated at 2022-06-24 11:50:49.528330
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    from .test import fakefile
    stream = fakefile()
    write_unsigned_int(stream, 674)
    assert stream.value == b'\x00\x00\x02\x9a'
test_write_unsigned_int()



# Generated at 2022-06-24 11:50:56.031634
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    for val, test in [(1, b'\x00\x00\x01'),
                      (2, b'\x00\x00\x02'),
                      (0xFFFFFF, b'\xFF\xFF\xFF')]:
        stream = io.BytesIO()
        write_unsigned_int_24(stream, val)
        assert stream.getvalue() == test



# Generated at 2022-06-24 11:51:08.095721
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-24 11:51:17.841607
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    # Test for normal values
    for i in range(0x00010000):
        assert compat_struct_unpack('!I', write_unsigned_int_24(io.BytesIO(), i))[0] == i
    # Test for some of the high values
    assert compat_struct_unpack('!I', write_unsigned_int_24(io.BytesIO(), 0x12343210))[0] == 0x0012343210
    assert compat_struct_unpack('!I', write_unsigned_int_24(io.BytesIO(), 0x12345678))[0] == 0x0012345678
    assert compat_struct_unpack('!I', write_unsigned_int_24(io.BytesIO(), 0xABCDEF00))[0] == 0x00ABCDEF00

# Generated at 2022-06-24 11:51:25.380931
# Unit test for function get_base_url
def test_get_base_url():
    assert get_base_url(compat_etree_fromstring('''
    <manifest xmlns='http://ns.adobe.com/f4m/1.0'>
      <baseURL>http://example.com/</baseURL>
      <media/>
    </manifest>''')) == 'http://example.com/'
    assert get_base_url(compat_etree_fromstring('''
    <manifest xmlns='http://ns.adobe.com/f4m/2.0'>
      <baseURL>http://example.com/</baseURL>
      <media/>
    </manifest>''')) == 'http://example.com/'



# Generated at 2022-06-24 11:51:35.252678
# Unit test for function get_base_url
def test_get_base_url():
    manifest_with_base_url = '''<?xml version="1.0" encoding="utf-8"?>
    <manifest xmlns="http://ns.adobe.com/f4m/1.0">
        <baseURL>http://example.com</baseURL>
    </manifest>'''
    manifest_without_base_url = '''<?xml version="1.0" encoding="utf-8"?>
    <manifest xmlns="http://ns.adobe.com/f4m/1.0">
        <media baseURL="http://example.com"/>
    </manifest>'''
    assert get_base_url(compat_etree_fromstring(manifest_with_base_url)) == 'http://example.com'

# Generated at 2022-06-24 11:51:39.668848
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError('Message')
    except Exception as e:
        if e.args[0] != 'Message':
            raise AssertionError('Unexpected exception message: ' + e.args[0])
    else:
        raise AssertionError('Exception not raised')



# Generated at 2022-06-24 11:51:44.404733
# Unit test for function write_flv_header
def test_write_flv_header():
    header_bytes = io.BytesIO()
    write_flv_header(header_bytes)
    assert header_bytes.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-24 11:51:46.452311
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    reader = FlvReader(b'\x10\x00\x00\x00')
    assert reader.read_unsigned_int() == 16



# Generated at 2022-06-24 11:51:57.249903
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    data = compat_b64decode('''
    AgAAAAAAADkAAB4qgIxn2wCVUhMRgHMYhWDVy9PA1gTIAAAABAABQCQAAAAAtAAAA
    BwAAAAAEAAABAAAAAAACAAAAAwBVU0QAVVNEAAAAAAAAAAIAAAABAAQCQAAAAAt
    AAAACwAAAAAEAAABAAAAAAAKAAAAAwBVU0QAVVNEAAAAAAAAAAEAAABAAgAAAAA
    tAAAABgAAAAAEAAABAAAAAAABAAAAAwBVU0QAVVNEAAAAAAAAAAMAAABAAgAA
    AAA=
    ''')
    some_bootstrap_info = read_bootstrap_info(data)


# Generated at 2022-06-24 11:52:01.168699
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    data = b'ABC'
    f = FlvReader(data)
    assert f.read_bytes(1) == b'A'
    assert f.read_bytes(2) == b'BC'
    try:
        f.read_bytes(1)
        assert False
    except DataTruncatedError:
        pass


# Generated at 2022-06-24 11:52:10.854228
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    with open('test/files/bootstrap.bin', 'rb') as f:
        abst = FlvReader(f.read()).read_bootstrap_info()
        print('#' * 30)
        print(abst['segments'][0]['segment_run'])
        print('#' * 30)
        print('segments')
        for i, segment in enumerate(abst['segments']):
            print('Segment %d: %s' % (i, segment))
        print('#' * 30)
        print('fragments')
        for i, fragment in enumerate(abst['fragments']):
            print('Fragment %d: %s' % (i, fragment))




# Generated at 2022-06-24 11:52:20.632778
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    data = b''
    s = io.BytesIO()
    write_unsigned_int_24(s, 10)
    data += s.getvalue()
    write_unsigned_int_24(s, 20)
    data += s.getvalue()
    write_unsigned_int_24(s, 30)
    data += s.getvalue()
    write_unsigned_int_24(s, 40)
    data += s.getvalue()
    write_unsigned_int_24(s, 50)
    data += s.getvalue()
    write_unsigned_int_24(s, 60)
    data += s.getvalue()
    write_unsigned_int_24(s, 70)
    data += s.getvalue()
    write_unsigned_int_24(s, 80)
    data += s.getvalue()
