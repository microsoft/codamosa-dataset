

# Generated at 2022-06-24 11:42:27.678355
# Unit test for function get_base_url
def test_get_base_url():
    manifest = """<?xml version="1.0" encoding="UTF-8"?>
<manifest xmlns="http://ns.adobe.com/f4m/1.0">
    <id>test</id>
    <streamType>recorded</streamType>
    <duration>12500</duration>
    <baseURL>http://somedomain/path/to/video/</baseURL>
    <media url="test.stream.mp4"
           bootstrapInfoId="bootstrap1"
           bitrate="14296"
           width="256"
           height="144"
           streamId="1"
           />
</manifest>
"""
    base_url = get_base_url(compat_etree_fromstring(manifest))

# Generated at 2022-06-24 11:42:36.548015
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-24 11:42:44.079904
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    sample = (
        b'\x00\x00\x00\x10'
        b'\x61\x73\x72\x74'
        b'\x00\x00\x00\x00'
        b'\x00'
        b'\x00\x00\x00\x04'
        b'\x30\x30\x31\x00'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x00\x01\x00\x00\x00'
    )
    res = FlvReader(sample).read_asrt()
    assert res['segment_run'] == [(0, 1)]



# Generated at 2022-06-24 11:42:49.457357
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    import base64
    from io import BytesIO
    from datetime import timedelta


# Generated at 2022-06-24 11:42:58.130282
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-24 11:43:03.960513
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    assert write_unsigned_int(io.BytesIO(), 1) == 4
    assert write_unsigned_int(io.BytesIO(), 1341234) == 4
    assert write_unsigned_int(io.BytesIO(), 4294967295) == 4



# Generated at 2022-06-24 11:43:14.866317
# Unit test for function get_base_url
def test_get_base_url():
    manifest_xml = ('<manifest xmlns="http://ns.adobe.com/f4m/2.0">'
                    '<baseURL>ftp://example.com/</baseURL>'
                    '</manifest>')
    assert (get_base_url(compat_etree_fromstring(manifest_xml))
            == 'ftp://example.com/')

    manifest_xml = ('<manifest xmlns="http://ns.adobe.com/f4m/2.0">'
                    '<baseURL>ftp://example.com</baseURL>'
                    '</manifest>')
    assert (get_base_url(compat_etree_fromstring(manifest_xml))
            == 'ftp://example.com')


# Generated at 2022-06-24 11:43:26.555087
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-24 11:43:31.207515
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    flv_data = compat_struct_pack('!II4s', 10, 0, b'mypy')
    assert FlvReader(flv_data).read_box_info() == (10, b'mypy', b'')
    flv_data = compat_struct_pack('!QQ4s', 1, 0, b'mypy')
    assert FlvReader(flv_data).read_box_info() == (1, b'mypy', b'')


# Generated at 2022-06-24 11:43:40.166708
# Unit test for function read_bootstrap_info

# Generated at 2022-06-24 11:43:48.639738
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    data = b'\x00\x00\x00 \x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00'
    box = FlvReader(data).read_afrt()
    assert box['fragments'][0]['first'] == 1

# Generated at 2022-06-24 11:44:00.695928
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():

    from io import BytesIO
    from .test_downloader import FakeYDL


# Generated at 2022-06-24 11:44:06.971340
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    data = (
        b'\x00\x00\x00\x00\x00\x00\x00\x00',
        b'\x00\x00\x00\x00\xff\xff\xff\xff',
        b'\xff\xff\xff\xff\x00\x00\x00\x00',
        b'\xff\xff\xff\xff\xff\xff\xff\xff',
    )
    for x in data:
        assert FlvReader(x).read_unsigned_long_long() == compat_struct_unpack('!Q', x)[0]



# Generated at 2022-06-24 11:44:15.190926
# Unit test for function get_base_url
def test_get_base_url():
    manifest_url = 'http://a.com/base/base/manifest.f4m'
    manifest_contents = ('<manifest>'
                         '<baseURL>/base/</baseURL>'
                         '<media baseURL="media/" />'
                         '<media baseURL="media/"/>'
                         '</manifest>')

    base_url = get_base_url(
        compat_etree_fromstring(manifest_contents.encode('utf-8')))

    assert base_url == '/base/'
    assert base_url, 'Failed to get base_url'



# Generated at 2022-06-24 11:44:24.271600
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring('''
    <manifest xmlns="http://ns.adobe.com/f4m/2.0">
        <baseURL>http://example.com</baseURL>
    </manifest>''')
    assert get_base_url(manifest) == 'http://example.com'

    manifest = compat_etree_fromstring('''
    <manifest xmlns="http://ns.adobe.com/f4m/1.0">
        <baseURL>http://example.com</baseURL>
    </manifest>''')
    assert get_base_url(manifest) == 'http://example.com'


# Generated at 2022-06-24 11:44:27.938936
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    flv = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x00')
    value = flv.read_unsigned_long_long()
    assert value == 0



# Generated at 2022-06-24 11:44:41.806374
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    # An example from an actual video
    packet_data = (
        b'\x00\x00\x01\x34'  # size
        b'asrt'  # type
        b'\x00'  # version
        b'\x00\x00\x00'  # flags
        b'\x01'  # QualityEntryCount
        b'AUDIO\x00'  # QualitySegmentUrlModifiers[0]
        b'\x00\x00\x00\x01'  # SegmentRunEntryCount
        b'\x00\x00\x00\x01'  # FirstSegment
        b'\x00\x00\x00\x43'  # FragmentsPerSegment
    )
    segment = FlvReader(packet_data).read_asrt()



# Generated at 2022-06-24 11:44:43.624398
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    assert write_unsigned_int(io.BytesIO(), 0x01020304) == io.BytesIO(
        b'\x01\x02\x03\x04')



# Generated at 2022-06-24 11:44:51.793536
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    flv_reader = FlvReader(b'\x01\x02\x03\x04')
    assert flv_reader.read_bytes(1) == b'\x01'
    assert flv_reader.read_bytes(2) == b'\x02\x03'
    assert flv_reader.read_bytes(1) == b'\x04'
    import pytest
    pytest.raises(DataTruncatedError, flv_reader.read_bytes, 4)



# Generated at 2022-06-24 11:45:03.004453
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    stream = io.BytesIO()
    write_flv_header(stream)

# Generated at 2022-06-24 11:45:07.604206
# Unit test for function get_base_url
def test_get_base_url():
    manifest = '''
    <manifest xmlns="http://ns.adobe.com/f4m/2.0">
      <baseURL>http://foobar.com/</baseURL>
    </manifest>
    '''

    assert get_base_url(compat_etree_fromstring(manifest)) == 'http://foobar.com/'



# Generated at 2022-06-24 11:45:19.842792
# Unit test for function build_fragments_list

# Generated at 2022-06-24 11:45:22.030152
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    import io
    assert write_unsigned_int(io.BytesIO(), 0x01020304).getvalue() == b'\x00\x00\x01\x02'


# Generated at 2022-06-24 11:45:27.821874
# Unit test for function write_flv_header
def test_write_flv_header():
    stream=io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue()==b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-24 11:45:33.585131
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    stream = io.BytesIO()
    write_unsigned_int_24(stream, 0x12345)
    assert stream.getvalue() == b'\x45\x23\x01'
    stream.close()
test_write_unsigned_int_24()



# Generated at 2022-06-24 11:45:36.846288
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-24 11:45:42.975905
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    from io import BytesIO
    test_stream = BytesIO()
    test_val = 0x12345678
    write_unsigned_int(test_stream, test_val)
    test_res = test_stream.getvalue()
    ref_res = compat_struct_pack('!I', test_val)
    assert test_res == ref_res
test_write_unsigned_int()


# Generated at 2022-06-24 11:45:47.287114
# Unit test for constructor of class FlvReader

# Generated at 2022-06-24 11:45:52.696209
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    test_data = b'ABC\x00EFG\x00\x00\x00'
    assert FlvReader(test_data).read_string() == b'ABC'
    assert FlvReader(test_data).read_string() == b'EFG\x00'



# Generated at 2022-06-24 11:45:58.934205
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    assert FlvReader(b'\x00').read_unsigned_char() == 0
    assert FlvReader(b'\x01').read_unsigned_char() == 1
    assert FlvReader(b'\xFF').read_unsigned_char() == 255
    assert FlvReader(b'\xFF\x12').read_unsigned_char() == 255
    assert FlvReader(b'\x00\x12').read_unsigned_char() == 0


# Generated at 2022-06-24 11:46:07.117269
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-24 11:46:15.719897
# Unit test for constructor of class FlvReader

# Generated at 2022-06-24 11:46:26.695786
# Unit test for function write_unsigned_int_24

# Generated at 2022-06-24 11:46:37.814763
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'segments': [{
            'segment_run': [
                (0, 1),
                (1, 1),
            ],
        }],
        'fragments': [{
            'fragments': [
                {'first': 0, 'duration': 1000, 'discontinuity_indicator': None},
                {'first': 1, 'duration': 1000, 'discontinuity_indicator': None},
            ]
        }],
        'live': False,
    }
    assert(build_fragments_list(boot_info)) == [(0, 0), (1, 1)]


# Generated at 2022-06-24 11:46:46.023626
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-24 11:46:48.759291
# Unit test for constructor of class F4mFD
def test_F4mFD():
    fd = F4mFD({
        'url': 'http://test.url/test.f4m',
        'fragment_index': 2,
        'test': True,
        'params': {
            'test': True
        }
    }, {
        'test': True
    })
    assert fd



# Generated at 2022-06-24 11:46:54.631584
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    FlvReader(b'\x00\x00\x00\x05ABCDE').read_bytes(4)
    try:
        FlvReader(b'\x00\x00\x00\x05ABCDE').read_bytes(5)
        assert False
    except DataTruncatedError:
        return



# Generated at 2022-06-24 11:46:58.810030
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    data = b'\x01\x00\x00\x00\x01\x02\x03\x04\x05\x06\x07\x08' \
           b'TestMe\x00'
    reader = FlvReader(data)
    reader.read_bytes(4)
    assert reader.read_string() == b'TestMe'



# Generated at 2022-06-24 11:47:09.723511
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    with temp_dir(prefix='ytdl', suffix='test_F4mFD_real_download') as tmpdir:
        with open(os.path.join(tmpdir, 'temp.f4f'), 'wb') as f:
            f.write(b'\x00\x00\x00\x00\x00\x00\x00\x00')

        url = 'http://example.com/video.f4m'
        info_dict = {
            'url': url,
            'fragment_base_url': 'http://example.com/video.f4f',
            'fragment_filename': 'temp.f4f',
            'duration': 10,
            'filesize': 10,
        }
        expected_result = True
        # Initialize object
        F4mFD_obj

# Generated at 2022-06-24 11:47:16.198319
# Unit test for function build_fragments_list
def test_build_fragments_list():
    import os

# Generated at 2022-06-24 11:47:26.478197
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    test_data = (
        b'\x00\x00\x00\x20\x61\x73\x72\x74\x01\x4c\x6f\x63\x61\x6c\x65'
        b'\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x03\x00\x00\x00'
        b'\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01')
    data = FlvReader(test_data)
    result = data.read_asrt()

# Generated at 2022-06-24 11:47:38.702907
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    f = '''
    <Media id="1" bitrate="30000" drmAdditionalHeaderId="0" drmAdditionalHeaderSetId="2"
          bootstrapInfoId="123"><Metadata></Metadata><SegmentURL media="s1v" mediaRange="0-11999"/>
    <SegmentURL media="s1v" mediaRange="12000-23999"/></Media>
    '''
    media = compat_etree_fromstring(f).findall('%sMedia' % '')
    assert len(media) == 2
    media = remove_encrypted_media(media)
    assert len(media) == 0


# Generated at 2022-06-24 11:47:50.858042
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    s = io.BytesIO()

# Generated at 2022-06-24 11:47:54.313615
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    f = FlvReader(b'\x03xxx\x00\x04xxxx\x00')
    assert f.read_string() == b'xxx'
    assert f.read_string() == b'xxxx'



# Generated at 2022-06-24 11:47:59.370972
# Unit test for function write_flv_header
def test_write_flv_header():
    from ..utils import make_tempfile
    expected = b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'
    with make_tempfile() as tmp:
        with open(tmp, 'wb') as fd:
            write_flv_header(fd)
        with open(tmp, 'rb') as fd:
            assert fd.read() == expected



# Generated at 2022-06-24 11:48:03.253723
# Unit test for function write_flv_header
def test_write_flv_header():
    from ..compat import BytesIO
    stream = BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == (b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00')



# Generated at 2022-06-24 11:48:14.784277
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # Make a fake Flv file containing 'moov' box and 'moof' box
    import struct
    data = struct.pack('!I', 8) + b'moov'  # Header of moov box
    data += struct.pack('!I', 8) + b'moof'  # Header of moof box
    flv_reader = FlvReader(data)
    # Check the first box
    actual_size, actual_type, actual_data = flv_reader.read_box_info()
    assert actual_size == 8
    assert actual_type == b'moov'
    assert actual_data == b''
    # Check the second box
    actual_size, actual_type, actual_data = flv_reader.read_box_info()
    assert actual_size == 8

# Generated at 2022-06-24 11:48:21.173542
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    import struct
    stream = io.BytesIO()
    sut = write_unsigned_int_24(stream, 0x12345678)
    bs = struct.unpack('!I', stream.getvalue())
    print('bs: ', hex(bs[0]))
    assert hex(bs[0]) == '0x123456'



# Generated at 2022-06-24 11:48:28.803248
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    flv_reader = FlvReader(open(
        'test/testdata/f4m/test_read_afrt.flv', 'rb').read())
    res = flv_reader.read_bootstrap_info()
    assert res['fragments'][0]['fragments'][0]['first'] == 0
    assert res['fragments'][0]['fragments'][0]['ts'] == 0
    assert res['fragments'][0]['fragments'][0]['duration'] == 8
    assert res['fragments'][0]['fragments'][0]['discontinuity_indicator'] is None
    assert res['fragments'][0]['fragments'][1]['first'] == 1

# Generated at 2022-06-24 11:48:39.055853
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-24 11:48:47.351604
# Unit test for function build_fragments_list
def test_build_fragments_list():
    # Test with a sample file
    with io.open('test/test.bootstrap', 'rb') as f:
        bootstrap_info = read_bootstrap_info(f.read())
    segments_fragments = build_fragments_list(bootstrap_info)

# Generated at 2022-06-24 11:48:52.703217
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    test_data = b'\x00\x00\x00\x05Hello'
    f = FlvReader(test_data)
    assert f.read_unsigned_int() == 5
    assert f.read() == b'Hello'

# Generated at 2022-06-24 11:49:03.432716
# Unit test for function write_flv_header
def test_write_flv_header():
    """Test for write_flv_header"""
    import os.path
    from .test import _download_file, _download_file_with_retries
    _download_file_with_retries(
        'https://github.com/ytdl-org/youtube-dl/raw/master/youtube_dl/postprocessor/tests/test.flv',
        os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test.flv')
    )
    flv_file = io.BytesIO(open(
        os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test.flv'),
        'rb').read())
    flv_file.seek(0)
    flv_file.read(9)


# Generated at 2022-06-24 11:49:15.845633
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    data = compat_b64decode('''
            AQAHAAIAAAAAAAAAAAAAAAAAAAc3VwAAAAAAAMAAAEAAAAAwAAAQAAAAFAAAAAAAAAAAAAAQAAAAEAAAEAAAABAAAAAAAAAAAAAAAAAAAABwDAAAAAAA
            AA==
    ''')
    box_data = FlvReader(data).read_afrt()
    assert box_data['fragments'][0]['first'] == 1
    assert box_data['fragments'][0]['ts'] == 0
    assert box_data['fragments'][0]['duration'] == 1
    assert box_data['fragments'][0]['discontinuity_indicator'] is None
    assert box_data['fragments'][1]['first'] == 2

# Generated at 2022-06-24 11:49:22.888659
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    reader = FlvReader(b'\x00\x00\x00\x03' + b'\x00\x00\x00\x0A')
    assert reader.read_unsigned_int() == 3
    assert reader.read_unsigned_int() == 10
    try:
        reader.read_unsigned_int()
    except (AssertionError, DataTruncatedError):
        pass
    else:
        assert False



# Generated at 2022-06-24 11:49:29.660815
# Unit test for function remove_encrypted_media

# Generated at 2022-06-24 11:49:34.173952
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    flv_reader = FlvReader(b'\x01\x02\xff\x00')
    assert flv_reader.read_unsigned_char() == 1
    assert flv_reader.read_unsigned_char() == 2
    assert flv_reader.read_unsigned_char() == 255



# Generated at 2022-06-24 11:49:41.662348
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    url = ''
    filename = ''
    info_dict = ''
    f4m_fd = F4mFD(match)
    f4m_fd._get_unencrypted_media(doc)
    f4m_fd._get_bootstrap_from_url(bootstrap_url)
    f4m_fd._update_live_fragments(bootstrap_url, latest_fragment)
    f4m_fd._parse_bootstrap_node(node, base_url)
    f4m_fd.real_download(filename, info_dict)

# Generated at 2022-06-24 11:49:48.242279
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        b'<?xml version="1.0" encoding="ISO-8859-1"?>'
        b'<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        b'<baseURL>https://www.example.com/</baseURL></manifest>')
    assert get_base_url(manifest) == 'https://www.example.com/'


# Generated at 2022-06-24 11:50:00.273086
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    import base64
    bootstrap_bytes_b64 = 'AAEAAAMo8gAAAAAABwCAAIAAAABAAAABQAAAAAAAAAA8W+AAMAAQDAKLhohQE/KjCgDTAwNf/'
    bootstrap_bytes = compat_b64decode(bootstrap_bytes_b64)
    bootstrap_info = read_bootstrap_info(bootstrap_bytes)
    assert bootstrap_info['live'] is False
    assert len(bootstrap_info['segments'][0]['segment_run']) == 1
    assert bootstrap_info['segments'][0]['segment_run'][0] == (1, 680)
    assert len(bootstrap_info['fragments']) == 1

# Generated at 2022-06-24 11:50:11.868573
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Tested with f4m manifests and AdobeHDS.php
    from .downloader import YoutubeDL
    import os.path

    ydl = YoutubeDL({'outtmpl': '%(id)s'})  # no_color does not work here
    class DummyF4mFD(F4mFD):
        def real_download(self, filename, info_dict):
            return super(DummyF4mFD, self).real_download(filename, info_dict)

    # AdobeHDS

# Generated at 2022-06-24 11:50:20.824845
# Unit test for function get_base_url
def test_get_base_url():
    from io import BytesIO
    from xml.etree import ElementTree as etree

    iobuffer_with_base_url = BytesIO(b"""
<?xml version="1.0" encoding="UTF-8"?>
<manifest xmlns="http://ns.adobe.com/f4m/1.0">
  <baseURL>http://example.com/</baseURL>
</manifest>
""")
    iobuffer_with_base_url_v2 = BytesIO(b"""
<?xml version="1.0" encoding="UTF-8"?>
<manifest xmlns="http://ns.adobe.com/f4m/2.0">
  <baseURL>http://example.com/</baseURL>
</manifest>
""")
    iobuffer_without_base_url = Bytes

# Generated at 2022-06-24 11:50:33.834952
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:50:40.670073
# Unit test for constructor of class FlvReader

# Generated at 2022-06-24 11:50:45.765829
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    file_data = b'12345678'

    reader = FlvReader(file_data)
    result1 = reader.read_bytes(4)
    result2 = reader.read_bytes(4)

    assert result1 == b'1234' and result2 == b'5678'



# Generated at 2022-06-24 11:50:50.648083
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    write_unsigned_int(stream, 1)
    assert(stream.getvalue() == b'\x00\x00\x00\x01')
    write_unsigned_int(stream, 4294967295)
    assert(stream.getvalue() == b'\x00\x00\x00\x01\xff\xff\xff\xff')
    stream.close()


# Generated at 2022-06-24 11:50:55.263434
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    assert FlvReader(compat_struct_pack('!B', 10)).read_unsigned_char() == 0x0a
    assert FlvReader(compat_struct_pack('!B', 255)).read_unsigned_char() == 0xff
    assert FlvReader(compat_struct_pack('!B', 0)).read_unsigned_char() == 0x00

# Generated at 2022-06-24 11:51:06.874575
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring('<manifest url="http://example.com" />')
    assert get_base_url(manifest) == 'http://example.com'
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com'
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/2.0">'
        '<baseURL>http://example.com</baseURL>'
        '</manifest>')

# Generated at 2022-06-24 11:51:11.475919
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    """Test utility read_box_info()."""
    data = b'\x00\x60\x09\x00' + b'ftyp' + b'isomiso2avc1mp41'
    reader = FlvReader(data)
    assert reader.read_box_info() == (9, b'ftyp', b'isomiso2avc1mp41')



# Generated at 2022-06-24 11:51:13.258589
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    FlvReader(compat_struct_pack('!I', 1)).read_unsigned_int()



# Generated at 2022-06-24 11:51:20.950709
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    reader = FlvReader(b'\x00\x01')
    assert reader.read_bytes(1) == b'\x00'
    assert reader.read_bytes(1) == b'\x01'
    assert reader.read_bytes(1) == b'\x00'
    reader = FlvReader(b'\x00\x01')
    try:
        reader.read_bytes(2)
    except:
        pass
    else:
        assert False
    reader = FlvReader(b'\x00\x01')
    assert reader.read_bytes(3) == b'\x00\x01'


# Generated at 2022-06-24 11:51:27.772688
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    """
    Tests function remove_encrypted_media
    """
    xml = """
    <body>
        <switch>
            <video src="v0.mp4" systemBitrate="1178851" />
            <video src="v1.mp4" systemBitrate="1368233" />
            <video src="v2.mp4" systemBitrate="2090351" />
            <video src="v0.mp4" systemBitrate="3596379" />
            <video src="v1.mp4" systemBitrate="7559288" />
            <video src="v2.mp4" systemBitrate="9473660" />
        </switch>
    </body>
    """
    # Set of expected results

# Generated at 2022-06-24 11:51:32.376525
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    reader = FlvReader(b'12345\x00\x00\x00\x00\x00\x00\x00')
    assert(reader.read_string() == b'12345')
    assert(reader.read_string() == b'')



# Generated at 2022-06-24 11:51:42.142920
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    with open('test/test_1.abst', 'rb') as f:
        abst = FlvReader(f.read()).read_bootstrap_info()
        assert abst['segments'] == [
            {'segment_run': [(0, 1), (1, 2), (3, 1), (4, 1), (5, 1), (6, 1)]}
        ]

# Generated at 2022-06-24 11:51:51.053134
# Unit test for method read_unsigned_char of class FlvReader

# Generated at 2022-06-24 11:51:54.644997
# Unit test for constructor of class F4mFD
def test_F4mFD():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    fd = F4mFD(ydl, {})
    assert fd is not None

if __name__ == '__main__':
    test_F4mFD()

# Generated at 2022-06-24 11:52:03.015593
# Unit test for function build_fragments_list

# Generated at 2022-06-24 11:52:13.750394
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:52:19.296779
# Unit test for constructor of class FlvReader
def test_FlvReader():
    # create a mock stream
    data = io.BytesIO(b'abcdefghijklmn')
    data.read(3)
    flv_data = data.read(10)
    flv = FlvReader(flv_data)
    assert flv.read_unsigned_int() == 10
    assert flv.read_bytes(4) == b'ijkl'
    assert flv.read_string() == b'mn'

