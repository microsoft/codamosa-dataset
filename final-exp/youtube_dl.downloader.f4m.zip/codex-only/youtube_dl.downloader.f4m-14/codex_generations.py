

# Generated at 2022-06-24 11:42:24.725057
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError()
    except DataTruncatedError as exception:
        assert isinstance(exception, DataTruncatedError)


# Generated at 2022-06-24 11:42:29.075359
# Unit test for function write_flv_header
def test_write_flv_header():
    from ..utils import make_tempfile
    with make_tempfile() as f:
        write_flv_header(f)
        f.seek(0)
        res = f.read()
        assert res == b'FLV\x01\x05\x00\x00\x00\t\x00\x00\x00\x00'



# Generated at 2022-06-24 11:42:35.540309
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    # Test data is in data/f4m/asrt-0.abst
    with open('data/f4m/asrt-0.abst', 'rb') as f:
        data = f.read()
    abst = FlvReader(data).read_asrt()
    assert abst == {'segment_run': [
        (0, 1), (1, 1), (2, 1), (3, 1), (4, 1), (5, 1), (6, 1), (7, 1),
        (8, 1), (9, 1), (10, 1), (11, 1), (12, 1), (13, 1), (14, 1), (15, 1),
        (16, 1), (17, 1), (18, 1), (19, 1), (20, 1)]}



# Generated at 2022-06-24 11:42:41.010770
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    byte_array = io.BytesIO()
    write_unsigned_int(byte_array, 0x12345678)
    assert byte_array.getvalue() == b'\x12\x34\x56\x78'
    byte_array = io.BytesIO()
    write_unsigned_int(byte_array, 0x0)
    assert byte_array.getvalue() == b'\x00\x00\x00\x00'



# Generated at 2022-06-24 11:42:44.487728
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    data = io.BytesIO(compat_struct_pack('!3L', 1, 2, 3))
    assert FlvReader(data).read_unsigned_long_long() == 0x02010000030000



# Generated at 2022-06-24 11:42:55.257086
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    def test(data, expected):
        test_data = compat_struct_pack('%dB' % len(data), *data)
        info = FlvReader(test_data).read_afrt()
        assert info == expected
    # Empty table
    test([0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x00], {
        'fragments': [],
    })
    # One entry

# Generated at 2022-06-24 11:42:57.213536
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    flv_reader = FlvReader(b'\x00\x00\x00\x02')
    assert flv_reader.read_unsigned_int() == 2


# Generated at 2022-06-24 11:43:06.372055
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    reader = FlvReader(b'\x00 \x04 \x00test\x00test2\x0000')
    assert reader.read_string() == b' '
    assert reader.read_string() == b' '
    assert reader.read_string() == b'test'
    assert reader.read_string() == b'test2'
    try:
        reader.read_string()
    except DataTruncatedError:
        pass
    else:
        assert False, 'Should throw DataTruncatedError'

# Generated at 2022-06-24 11:43:17.419800
# Unit test for function get_base_url
def test_get_base_url():
    manifest = '''
        <manifest xmlns="http://ns.adobe.com/f4m/1.0">
            <baseURL>url1</baseURL>
        </manifest>
    '''
    manifest = compat_etree_fromstring(fix_xml_ampersands(manifest))
    assert get_base_url(manifest) == 'url1'

    manifest = '''
        <manifest xmlns="http://ns.adobe.com/f4m/2.0">
            <baseURL>url2</baseURL>
        </manifest>
    '''
    manifest = compat_etree_fromstring(fix_xml_ampersands(manifest))
    assert get_base_url(manifest) == 'url2'



# Generated at 2022-06-24 11:43:21.132546
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    flv_reader = FlvReader(compat_struct_pack('!Q', 16))
    assert flv_reader.read_unsigned_long_long() == 16



# Generated at 2022-06-24 11:43:30.136112
# Unit test for function get_base_url
def test_get_base_url():
    assert get_base_url('''<manifest xmlns="http://ns.adobe.com/f4m/2.0">
                           <baseURL>abc</baseURL></manifest>''') == 'abc'
    assert get_base_url('''<manifest xmlns="http://ns.adobe.com/f4m/2.0">
                           <baseURL>abc</baseURL><media></media></manifest>''') == 'abc'
    assert get_base_url('''<manifest xmlns="http://ns.adobe.com/f4m/1.0">
                           <baseURL>abc</baseURL></manifest>''') == 'abc'

# Generated at 2022-06-24 11:43:32.404882
# Unit test for function write_flv_header
def test_write_flv_header():
    assert write_flv_header(io.BytesIO()) == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'


# Generated at 2022-06-24 11:43:42.748898
# Unit test for method read_string of class FlvReader

# Generated at 2022-06-24 11:43:45.096278
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    stream = io.BytesIO()
    write_unsigned_int_24(stream, 0x1020304)
    assert stream.getvalue() == b'\x02\x03\x04'



# Generated at 2022-06-24 11:43:57.987143
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-24 11:44:04.094798
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    info = io.BytesIO()
    write_unsigned_int_24(info, 0x1234)
    assert info.getvalue() == compat_struct_pack('!3B', 0x12, 0x34, 0)



# Generated at 2022-06-24 11:44:15.371041
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:44:18.623715
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    data = io.BytesIO()
    write_unsigned_int(data, 0x01020304)
    assert data.getvalue() == b'\x00\x00\x01\x02\x03\x04'
test_write_unsigned_int()



# Generated at 2022-06-24 11:44:30.627031
# Unit test for function get_base_url
def test_get_base_url():
    test_cases = [
        ('<manifest xmlns="http://ns.adobe.com/f4m/1.0"></manifest>', None),
        ('<manifest xmlns="http://ns.adobe.com/f4m/1.0"><baseURL>http://example.com/</baseURL></manifest>',
         'http://example.com/'),
        ('<manifest xmlns="http://ns.adobe.com/f4m/2.0"></manifest>', None),
        ('<manifest xmlns="http://ns.adobe.com/f4m/2.0"><baseURL>http://example.com/</baseURL></manifest>',
         'http://example.com/'),
    ]

# Generated at 2022-06-24 11:44:32.448964
# Unit test for constructor of class FlvReader
def test_FlvReader():
    flv_reader = FlvReader(open('./test/fixtures/flv_sample_2/bootstrap.abst', 'rb').read())
    flv_reader.read_bootstrap_info()



# Generated at 2022-06-24 11:44:39.619281
# Unit test for function get_base_url
def test_get_base_url():
    test_cases = [
        ('''<manifest xmlns="http://ns.adobe.com/f4m/1.0"><baseURL>https://example.com/content/</baseURL></manifest>''',
         'https://example.com/content/'),
        ('''<manifest xmlns="http://ns.adobe.com/f4m/2.0"><baseURL>https://example.com/content/</baseURL></manifest>''',
         'https://example.com/content/'),
    ]
    for content, res in test_cases:
        assert get_base_url(
            compat_etree_fromstring(fix_xml_ampersands(content))) == res



# Generated at 2022-06-24 11:44:46.927792
# Unit test for function get_base_url
def test_get_base_url():
    manifest = u"""
    <manifest xmlns="http://ns.adobe.com/f4m/1.0">
        <baseURL>http://example.com</baseURL>
        <media>
            <media>
        </media>
    </manifest>
    """
    assert get_base_url(manifest) == 'http://example.com'

    manifest = u"""
    <manifest xmlns="http://ns.adobe.com/f4m/2.0">
        <baseURL>http://example.com</baseURL>
        <media>
            <media>
        </media>
    </manifest>
    """
    assert get_base_url(manifest) == 'http://example.com'


# Generated at 2022-06-24 11:44:48.446441
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    reader = FlvReader(b'\x00\x00\x04\x00')
    assert reader.read_unsigned_int() == 4

# Generated at 2022-06-24 11:44:56.210585
# Unit test for function write_flv_header
def test_write_flv_header():
    test_data = b''.join((
        compat_struct_pack('>3s', b'FLV'), # Signature
        compat_struct_pack('B', 0x01),     # Version
        # Type flags
        compat_struct_pack('B', 0x05),
        # Data offset
        compat_struct_pack('>I', 9),
        # Previous tag size
        compat_struct_pack('>I', 0),
    ))
    assert write_flv_header(io.BytesIO()) == test_data



# Generated at 2022-06-24 11:45:01.409233
# Unit test for function write_flv_header
def test_write_flv_header():
    # No exception is the only test possible
    stream = io.BytesIO()
    write_flv_header(stream)
    stream.seek(0)
    assert stream.read() == (
        b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00')

# Generated at 2022-06-24 11:45:09.545961
# Unit test for function remove_encrypted_media

# Generated at 2022-06-24 11:45:11.222928
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError("error")
    except DataTruncatedError as e:
        assert str(e) == "error"



# Generated at 2022-06-24 11:45:16.906840
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    f = FlvReader(b'\x00\x00\x00\x00')
    f.read_bytes(1)
    f.read_bytes(2)
    f.read_bytes(3)
    f.read_bytes(4)
    assert f.read_bytes(5) == b''


# Generated at 2022-06-24 11:45:26.853415
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from .test import fake_f4m_bootstrap_urls
    assert len(fake_f4m_bootstrap_urls) == 1
    assert len(fake_f4m_bootstrap_urls[0]) == 3
    bootstrap_url = fake_f4m_bootstrap_urls[0][2]
    bootstrap_data = compat_b64decode(bootstrap_url.split('data=')[1])
    assert bootstrap_data
    abst = FlvReader(bootstrap_data).read_abst()
    assert abst
    assert 'segments' in abst
    assert len(abst['segments']) == 1
    assert abst['segments'][0]
    assert abst['segments'][0]['segment_run']

# Generated at 2022-06-24 11:45:37.826166
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-24 11:45:47.832342
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    stream = io.BytesIO()
    metadata = b'\x00\x00\x00\x00\x00\x00\x00'
    write_metadata_tag(stream, metadata)
    assert stream.getvalue() == b'\x12\x00\x00\x00\x07\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00\x00'


# Unit tests for functions write_unsigned_int
# and write_unsigned_int_24

# Generated at 2022-06-24 11:45:59.106267
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from .common import tmp_files, urlopen
    from ..compat import (
        compat_urlparse,
        compat_urllib_error,
        compat_urllib_parse_urlparse,
        compat_urllib_parse_unquote,
    )
    from ..utils import (
        float_or_none,
    )

    # First, download some sample mp4 file served by dash.js
    test_video_url = 'http://dash.edgesuite.net/envivio/EnvivioDash3/manifest.mpd'
    test_video_url_parsed = compat_urllib_parse_urlparse(test_video_url)

# Generated at 2022-06-24 11:46:03.962628
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    f = FlvReader(b'1\x002\x00')
    assert f.read_bytes(3) == b'1\x002\x00'
    # read_bytes should throw an exception when there is not enough data
    exception_thrown = False
    try:
        f.read_bytes(3)
    except DataTruncatedError:
        exception_thrown = True
    assert exception_thrown


# Generated at 2022-06-24 11:46:10.905798
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-24 11:46:16.724385
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    with io.open('test.flv', 'r+b') as flv:
        reader = FlvReader(flv.read())
        # header: 9, previousTagSize0: 4, audio: 13, previousTagSize1: 4, video: 16
        assert reader.read_unsigned_int() == 9


# Generated at 2022-06-24 11:46:27.147487
# Unit test for function build_fragments_list

# Generated at 2022-06-24 11:46:38.001877
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    url = 'http://test.test/test.f4m'

# Generated at 2022-06-24 11:46:46.133387
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():

    # create mock objects
    filename = mock.Mock()
    info_dict = mock.Mock()

    # create real object
    f4mfd = F4mFD()

    # create real object
    f4mfd._get_unencrypted_media = mock.Mock()
    f4mfd._get_unencrypted_media.return_value = mock.Mock()
    f4mfd._get_unencrypted_media.return_value.findall = mock.Mock()
    f4mfd._get_unencrypted_media.return_value.findall.return_value = mock.Mock()
    f4mfd._get_unencrypted_media.return_value.findall.return_value[0] = mock.Mock()
    f4mfd._get_unencrypted_media.return_value.find

# Generated at 2022-06-24 11:46:48.915500
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError('A message')
    except DataTruncatedError as e:
        assert str(e) == 'A message'



# Generated at 2022-06-24 11:46:49.959097
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    f4mfd = F4mFD()



# Generated at 2022-06-24 11:47:00.471983
# Unit test for constructor of class F4mFD
def test_F4mFD():
    """ test F4mFD class constructor """
    from .extractor import gen_extractors
    extractors = gen_extractors()
    f4m_fd = None
    for extractor in extractors:
        if extractor.IE_NAME == 'hds':
            f4m_fd = extractor
            break
    if not f4m_fd:
        raise Exception('The F4mFD unit test needs to be updated, extractor changed')

# Generated at 2022-06-24 11:47:09.155107
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    # Test with a string of ascii characters
    f = io.BytesIO(b'\x00\x01\x02\x00')
    r = FlvReader(f)
    assert r.read_string() == b'\x00\x01\x02'
    # Test with a string containing the zero character
    f = io.BytesIO(b'\x00\x01\x00\x02\x00')
    r = FlvReader(f)
    assert r.read_string() == b'\x00\x01\x00\x02'



# Generated at 2022-06-24 11:47:20.113981
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-24 11:47:23.268396
# Unit test for function get_base_url
def test_get_base_url():
    assert get_base_url(
        compat_etree_fromstring('<root><baseURL>http://example.com</baseURL></root>')) == 'http://example.com'



# Generated at 2022-06-24 11:47:26.316555
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    err = DataTruncatedError()
    assert str(err) == ''

    test_msg = 'Error message for unit test'
    err = DataTruncatedError(test_msg)
    assert str(err) == test_msg



# Generated at 2022-06-24 11:47:29.000413
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    from .fragment_asc import test_write_unsigned_int as test_st
    test_st(write_unsigned_int)

# Generated at 2022-06-24 11:47:40.255606
# Unit test for function remove_encrypted_media

# Generated at 2022-06-24 11:47:52.203324
# Unit test for function get_base_url
def test_get_base_url():
    t_1 = '''
        <manifest xmlns="http://ns.adobe.com/f4m/1.0"></manifest>
    '''
    assert get_base_url(compat_etree_fromstring(t_1)) is None

    t_2 = '''
        <manifest xmlns="http://ns.adobe.com/f4m/2.0"></manifest>
    '''
    assert get_base_url(compat_etree_fromstring(t_2)) is None

    t_3 = '''
        <manifest xmlns="http://ns.adobe.com/f4m/1.0">
            <baseURL>http://server/path</baseURL>
        </manifest>
    '''

# Generated at 2022-06-24 11:48:01.331009
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    import sys
    from .common import create_tempfile

    metadata = b'\x0a\x6f\x6e\x4d\x65\x74\x61\x44\x61\x74\x61\x08\x0a'
    metadata += b'\x01\x02\x08\x0a\x08\x01\x02\x08'
    metadata += b'\x08\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-24 11:48:03.917307
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError
    except DataTruncatedError:
        pass
    except:
        assert False, "DataTruncatedError - constructor failed"


# Generated at 2022-06-24 11:48:07.862987
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    val, stream = 42, io.BytesIO()
    write_unsigned_int(stream, val)
    stream.seek(0)
    assert compat_struct_unpack('!I', stream.read())[0] == val



# Generated at 2022-06-24 11:48:14.232713
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    test_data = b'd\x00\x00\x00\x04test' + b'\x05\x00\x00\x00abcd'
    flv_reader = FlvReader(test_data)
    assert flv_reader.read_box_info() == (4, b'test', b'')
    assert flv_reader.read_box_info() == (5, b'abcd', b'')


# Generated at 2022-06-24 11:48:16.262942
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    error = DataTruncatedError('test')
    assert error.args == ('test',)


# Generated at 2022-06-24 11:48:23.890015
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    flv_reader = FlvReader(b'\x00\x01\x02\x03\x04')
    assert flv_reader.read_unsigned_char() == 0
    assert flv_reader.read_unsigned_char() == 1
    assert flv_reader.read_unsigned_char() == 2
    assert flv_reader.read_unsigned_char() == 3
    assert flv_reader.read_unsigned_char() == 4


# Generated at 2022-06-24 11:48:33.401880
# Unit test for function build_fragments_list

# Generated at 2022-06-24 11:48:35.119417
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    error = DataTruncatedError('error_message')
    assert error.message == 'error_message'


# Generated at 2022-06-24 11:48:43.890909
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:48:52.125513
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # normal case
    box_info = FlvReader(b'\x00\x00\x00\x0cabcdabcd').read_box_info()
    assert box_info == (12, b'abcd', b'abcd')
    # large box
    box_reader = FlvReader(b'\x00\x00\x01\x00abcdabcd')
    with open('tests/data/64bytes', 'rb') as f:
        file_data = f.read()
    box_info = box_reader.read_box_info()
    assert box_info == (65536, b'abcd', file_data)



# Generated at 2022-06-24 11:49:02.957716
# Unit test for constructor of class FlvReader

# Generated at 2022-06-24 11:49:05.206303
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    f = io.BytesIO()
    write_unsigned_int(f, 0x1234)
    assert f.getvalue() == b'\x12\x34\x00\x00'



# Generated at 2022-06-24 11:49:17.475004
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    from io import BytesIO
    FLV_HEADER_SIZE = 9
    s = BytesIO()
    write_flv_header(s)
    # Add one tag:
    write_metadata_tag(s, b'\x02\x00\x0a\x6f\x6e\x4d\x65\x74\x61\x44\x61\x74\x61\x08\x00\x00\x00\x00\x00\x00\x00')
    s.seek(0, 2)
    assert s.tell() == FLV_HEADER_SIZE + 18 + 4 + 4
    s.seek(4, 0)
    assert read_unsigned_int(s) == FLV_HEADER_SIZE + 18 + 4



# Generated at 2022-06-24 11:49:23.793145
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    import struct
    # normal case
    data1 = struct.pack('!Q', 100) + struct.pack('!I', 200)
    flv = FlvReader(data1)
    if flv.read_unsigned_long_long() != 100:
        raise RuntimeError('Failed to read_unsigned_long_long')
    if flv.read_unsigned_int() != 200:
        raise RuntimeError('Failed to read_unsigned_int')

    # long case
    data2 = struct.pack('!I', 1) + struct.pack('!Q', 2)
    flv = FlvReader(data2)
    if flv.read_unsigned_long_long() != 2:
        raise RuntimeError('Failed to read_unsigned_long_long')

    # error case
    data3 = b''
    flv

# Generated at 2022-06-24 11:49:25.345869
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError("Time")
    except DataTruncatedError as e:
        assert str(e) == "Time"



# Generated at 2022-06-24 11:49:28.969466
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError('data truncated')
    except DataTruncatedError as e:
        pass
    else:
        raise AssertionError('DataTruncatedError not raised')

#
# Support for on-demand HTTP requests
#



# Generated at 2022-06-24 11:49:39.804852
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:49:47.847085
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    import base64

# Generated at 2022-06-24 11:50:00.153548
# Unit test for constructor of class FlvReader

# Generated at 2022-06-24 11:50:11.867837
# Unit test for function get_base_url
def test_get_base_url():
    def one_test(manifest, expected_base_url):
        actual_base_url = get_base_url(manifest)
        print('base URL: {!r}'.format(actual_base_url))
        assert actual_base_url == expected_base_url

    one_test(compat_etree_fromstring(b"""
        <manifest/>
    """), None)

    one_test(compat_etree_fromstring(b"""
        <manifest xmlns="http://ns.adobe.com/f4m/1.0">
            <baseURL>http://example.com/</baseURL>
        </manifest>
    """), 'http://example.com/')


# Generated at 2022-06-24 11:50:14.457400
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    reader = FlvReader(compat_struct_pack('!I', 42))
    assert reader.read_unsigned_int() == 42
    size = 0x01020304
    reader = FlvReader(compat_struct_pack('!I', size))
    assert reader.read_unsigned_int() == size

# Generated at 2022-06-24 11:50:17.406798
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    test_stream = io.BytesIO()
    write_unsigned_int(test_stream, 0xdecafbad)
    assert test_stream.getvalue() == b'\xde\xca\xfb\xad'



# Generated at 2022-06-24 11:50:21.591027
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    flvreader = FlvReader(b'abc\x00def\x00\x00\x00\x00')
    assert flvreader.read_string() == b'abc'
    assert flvreader.read_string() == b'def'
    assert flvreader.read_string() == b''

# Generated at 2022-06-24 11:50:27.235837
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == (
        b'FLV\x01'
        b'\x05'
        b'\x00\x00\x00\x09'
        b'\x00\x00\x00\x00')



# Generated at 2022-06-24 11:50:38.134892
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    from xml.etree import ElementTree
    from .common import parse_xml
    # Create an XML fragment with a media which is encrypted and one which is
    # not.
    media = ElementTree.fromstring('''
        <media src="src" systemBitrate="systemBitrate">
            <metadata>
                <some>metadata</some>
            </metadata>
            <drmAdditionalHeaderId>headerId</drmAdditionalHeaderId>
            <drmAdditionalHeaderSetId>headerSetId</drmAdditionalHeaderSetId>
        </media>
        <media src="src" systemBitrate="systemBitrate">
            <metadata>
                <some>metadata</some>
            </metadata>
        </media>
    ''')

# Generated at 2022-06-24 11:50:49.379962
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    TestCases = [
        [b'\x00\x00\x00\x00\x00\x00\x00\x00', {'segment_run': []}],
        [b'\x00\x00\x00\x2A\x00\x00\x00\x01qualityLevels\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x04\x00\x00\x00\x02\x00\x00\x00\x08', {'segment_run': [(0, 1), (2, 4), (8, 2)]}],
    ]

# Generated at 2022-06-24 11:51:00.643339
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    from ..downloader.http import HEADRequest
    from ..utils import HEADRequest as FakeHEADRequest

    HEADRequest.request = FakeHEADRequest
    HEADRequest.strategy = HEADRequest.FAKE_HEAD_STRATEGY


# Generated at 2022-06-24 11:51:05.550231
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    bytes = b'\x01\x02\x03\x04'
    fr = FlvReader(bytes)
    assert fr.read_unsigned_char() == 1
    assert fr.read_unsigned_char() == 2
    assert fr.read_unsigned_char() == 3
    assert fr.read_unsigned_char() == 4



# Generated at 2022-06-24 11:51:08.140475
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    e = DataTruncatedError("error1", "error2")
    assert str(e) == "error1: error2"



# Generated at 2022-06-24 11:51:10.627818
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    # pylint: disable=redefined-outer-name
    reader = FlvReader(b'\x01')
    assert reader.read_unsigned_char() == 1


# Generated at 2022-06-24 11:51:13.348159
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    f = FlvReader(compat_struct_pack('!I', 1234567890))
    assert f.read_unsigned_int() == 1234567890



# Generated at 2022-06-24 11:51:22.162344
# Unit test for function get_base_url
def test_get_base_url():
    assert get_base_url(compat_etree_fromstring('<manifest />')) is None
    assert get_base_url(compat_etree_fromstring(
        '<manifest><baseURL>http://example.com/</baseURL></manifest>')) == 'http://example.com/'
    assert get_base_url(compat_etree_fromstring(
        '<manifest><baseURL> http://example.com/ </baseURL></manifest>')) == 'http://example.com/'

    tree = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/2.0"><baseURL>http://example.com/</baseURL></manifest>')

# Generated at 2022-06-24 11:51:33.430475
# Unit test for function read_bootstrap_info

# Generated at 2022-06-24 11:51:36.874296
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    test_data = b'\x00\x00\x00 \x61\x73\x72\x74\x02foobar\x07\x00\x00\x00\x01\x00\x00\x00\x02'
    res = FlvReader(test_data).read_asrt()
    assert res['segment_run'] == [(1, 2)]


# Generated at 2022-06-24 11:51:41.769435
# Unit test for function write_flv_header
def test_write_flv_header():
    class Stream(object):
        def __init__(self):
            self.data = b''

        def write(self, data):
            self.data += data
    stream = Stream()
    write_flv_header(stream)
    assert stream.data == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-24 11:51:44.447745
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    a = io.open('tests/input/bootstrap.abst', 'rb').read()
    bi = read_bootstrap_info(a)
    assert bi['live'] is True



# Generated at 2022-06-24 11:51:50.617455
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    from io import BytesIO
    metadata = b'\x12\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    stream = BytesIO()
    write_metadata_tag(stream, metadata)
    assert stream.getvalue() == b'\x12\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00' + metadata + b'\x21\x00\x00\x00'



# Generated at 2022-06-24 11:51:59.932711
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:52:04.229037
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    f = io.BytesIO()
    write_unsigned_int_24(f, 0x1234567)
    f.seek(0)
    assert f.read(3) == b'\x45\x67\x12'



# Generated at 2022-06-24 11:52:14.815314
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    from .test import make_temp_file
    from .test import create_test_streaming_extractor as create_test_video
    from ..utils import encode_base_n

    def assert_write_unsigned_int(val, b):
        with make_temp_file() as output:
            stream = io.open(output, 'wb')
            write_unsigned_int(stream, val)
            stream.close()
            with io.open(output, 'rb') as f:
                assert f.read() == b
    assert_write_unsigned_int(0, b'\x00\x00\x00\x00')
    assert_write_unsigned_int(1, b'\x00\x00\x00\x01')

# Generated at 2022-06-24 11:52:23.250570
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    f = io.BytesIO()
    f.write(compat_struct_pack('!I4s3s', 7, b'abst', b'\x00\x00\x00'))
    f.write(compat_struct_pack('!B', 1))
    f.write(compat_struct_pack('!3s', b'\x00\x00\x00'))
    f.write(b'\x00\x00\x00\x00')
    box_size, box_type, box_data = FlvReader(f.getvalue()).read_box_info()
    assert box_size == 7
    assert box_type == b'abst'