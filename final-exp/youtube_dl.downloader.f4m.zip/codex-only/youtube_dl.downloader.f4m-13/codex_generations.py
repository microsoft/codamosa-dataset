

# Generated at 2022-06-24 11:42:27.942068
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    import sys
    metadata = 'onMetaData'.encode('utf-8')
    metadata += ''.encode('utf-8')
    metadata += 'duration'.encode('utf-8')
    metadata += '\x00\xb4\x00\x00\x00\x00\x00\x00\x00'.encode('utf-8')
    metadata += 'fileSize'.encode('utf-8')
    metadata += '\x00'.encode('utf-8')
    metadata += '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'.encode('utf-8')
    metadata += 'width'.encode('utf-8')

# Generated at 2022-06-24 11:42:36.511453
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    stream = io.BytesIO()
    metadata = compat_b64decode('Q1BSAEdERVAgSFRNTCBQVVQAAAAAGAAAAAQCAVUEAAAMABwAAAAIAEwAAAAAAAAAACwAAAAA')
    write_metadata_tag(stream, metadata)
    expected_data = b'\x12\x00\x00\x80Q1BSAEdERVAgSFRNTCBQVVQAAAAAGAAAAAQCAVUEAAAMABwAAAAIAEwAAAAAAAAAACwAAAAA\x00\x00\x00\x00\x00\x00\x00O\x00\x00\x00'
    assert stream.getvalue() == expected_data
test_write_metadata_tag()


# Generated at 2022-06-24 11:42:41.079459
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    flv_reader = FlvReader(b'\x01\x02\x03\x04\x05\x06\x07\x08')
    assert flv_reader.read_unsigned_long_long() == 0x0102030405060708

test_FlvReader_read_unsigned_long_long()

# Generated at 2022-06-24 11:42:52.319229
# Unit test for function get_base_url
def test_get_base_url():
    test_manifest_1 = """
        <manifest xmlns="http://ns.adobe.com/f4m/1.0">
            <id>0</id>
            <mimeType>application/vnd.ms-sstr+xml</mimeType>
            <streamType>recorded</streamType>
            <duration>0</duration>
            <bootstrapInfo profile="named" id="bootstrap0" url="bootstrap_0.abst"/>
            <media streamId="0" bootstrapInfoId="bootstrap0" url="Manifest" bitrate="0" bandwidth="0" />
        </manifest>
    """

# Generated at 2022-06-24 11:43:04.205533
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring('<manifest><baseURL>https://example.com</baseURL></manifest>')
    assert get_base_url(manifest) == 'https://example.com'

    manifest = compat_etree_fromstring('<manifest><baseURL>https://example.com</baseURL><baseURL>http://example.com</baseURL></manifest>')
    assert get_base_url(manifest) == 'https://example.com'

    manifest = compat_etree_fromstring(
        '<manifest><baseURL majorVersion="2">https://example.com</baseURL><baseURL>http://example.com</baseURL></manifest>')
    assert get_base_url(manifest) == 'https://example.com'


# Generated at 2022-06-24 11:43:15.105396
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    # assert
    assert FlvReader(b'\x01').read_unsigned_char() == 1
    assert FlvReader(b'\x02').read_unsigned_char() == 2
    assert FlvReader(b'\x03').read_unsigned_char() == 3
    assert FlvReader(b'\x04').read_unsigned_char() == 4
    assert FlvReader(b'\x05').read_unsigned_char() == 5
    assert FlvReader(b'\x06').read_unsigned_char() == 6
    assert FlvReader(b'\x07').read_unsigned_char() == 7
    assert FlvReader(b'\x08').read_unsigned_char() == 8
    assert FlvReader(b'\x09').read_unsigned_char() == 9

# Generated at 2022-06-24 11:43:22.235257
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    assert FlvReader(b'\x06\x00\x00\x00test\x00\x00\x00\x00').read_string() == b'test'
    assert FlvReader(b'\x07\x00\x00\x00te\x00st\x00\x00\x00').read_string() == b'te\x00st'


# Generated at 2022-06-24 11:43:26.283152
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    f = io.BytesIO()
    write_unsigned_int_24(f, 1023)
    write_unsigned_int_24(f, 8388607)
    assert f.getvalue() == '\x00\x00\x03\xFF\xFF\xFF\xFF\x7F'



# Generated at 2022-06-24 11:43:34.821566
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():  # noqa: N802
    flv_reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x00')
    assert flv_reader.read_asrt() == {'segment_run': []}


# Generated at 2022-06-24 11:43:44.522287
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    import unittest
    import xml.etree.ElementTree as ET

    class TestEncryptedMedia(unittest.TestCase):

        # Test that a media tag is removed if it
        # contains both "drmAdditionalHeaderId" and
        # "drmAdditionalHeaderSetId" attributes
        def testMediaWithBothAttrs(self):
            media = ET.Element('media')
            media.attrib['url'] = 'http://example.com/media1.flv'
            media.attrib['drmAdditionalHeaderId'] = 'media1_drm'
            media.attrib['drmAdditionalHeaderSetId'] = 'media1_drm_set'

            media_tree = [media]
            expected_tree = []
            self.assertEqual(remove_encrypted_media(media_tree), expected_tree)

        # Test that media tag without

# Generated at 2022-06-24 11:43:57.947665
# Unit test for function remove_encrypted_media

# Generated at 2022-06-24 11:44:05.017084
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    import binascii
    full_box_header = binascii.unhexlify('00000010667479704d534e56')
    flvreader = FlvReader(full_box_header)
    assert flvreader.read_box_info() == (16, b'ftyp', b'MSNV')


# Generated at 2022-06-24 11:44:15.548389
# Unit test for constructor of class F4mFD
def test_F4mFD():
    assert F4mFD('http://blabla.com/manifest.f4m').downloader_name == 'f4m'
    assert F4mFD('http://blabla.com/manifest.f4m?x=1&y=2').downloader_name == 'f4m'
    assert F4mFD('http://blabla.com/manifest.f4m#abc').downloader_name == 'f4m'
    assert F4mFD('http://blabla.com/manifest.f4m#abc?x=1').downloader_name == 'f4m'
    assert F4mFD('http://blabla.com/manifest.f4m?x=1#abc').downloader_name == 'f4m'


# Generated at 2022-06-24 11:44:24.626690
# Unit test for constructor of class F4mFD
def test_F4mFD():
    class TestF4mFD(F4mFD):
        def __init__(self):
            self._initialize_frag_download = lambda x: None
            self._prepare_url = lambda x, y: y
            self._download_fragment = lambda x, y: (True, y)
            self._finish_frag_download = lambda x: None
    ydl = YoutubeDL({})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(TestF4mFD())
    url = 'http://download.tsi.telecom-paristech.fr/gpac/mp4box.frag/elephants_dream_1080p.mp4.f4m'
    info = ydl.extract_info(url, download=False)

# Generated at 2022-06-24 11:44:32.023335
# Unit test for constructor of class FlvReader

# Generated at 2022-06-24 11:44:40.133376
# Unit test for constructor of class FlvReader
def test_FlvReader():
    # Test data for FlvReader
    # A flv of length 10 with a sequence of four number: 1,2,3,4
    data = compat_struct_pack('!BBI', 0x46, 0x4c, 0x56)
    data += compat_struct_pack('!B', 0x01)
    data += compat_struct_pack('!BBII', 0, 0, 0, 10)
    data += compat_struct_pack('!I', 15)
    data += b'test'
    data += compat_struct_pack('!BBII', 0, 0, 0, 10)
    data += compat_struct_pack('!B', 0x08)
    for n in range(4):
        data += compat_struct_pack('!I', 1)

# Generated at 2022-06-24 11:44:47.281869
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest>'
        '  <name>/foooo/bar</name>'
        '  <baseURL>/foooo/bar/base</baseURL>'
        '</manifest>')

    assert get_base_url(manifest) == '/foooo/bar/base'
    del manifest[0]
    assert get_base_url(manifest) is None
    manifest.append(compat_etree_fromstring('<{0}>/foooo/bar/base2</{0}>'.format(
        _add_ns('baseURL', 2))))
    assert get_base_url(manifest) == '/foooo/bar/base2'


# Generated at 2022-06-24 11:44:49.986859
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    err = DataTruncatedError()
    assert type(err) == DataTruncatedError, "DataTruncatedError()"



# Generated at 2022-06-24 11:45:00.744667
# Unit test for constructor of class FlvReader
def test_FlvReader():
    data = (b'\x00\x00\x00\x16\x72\x63\x66\x66\x00\x00\x00\x00\x00'
            b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01')
    f = FlvReader(data)
    f.read_box_info()
    f.read_box_info()
    assert f.read_box_info() == (8, b'\x72\x63\x66\x66', b'\x00\x00\x00\x00\x00\x00\x00\x01')



# Generated at 2022-06-24 11:45:05.155926
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    test_file = io.BytesIO(compat_struct_pack('!Q', 0x0123456789ABCDEF))
    test_FlvReader = FlvReader(test_file)
    ret = test_FlvReader.read_unsigned_long_long()
    assert ret == 0x0123456789ABCDEF

# Generated at 2022-06-24 11:45:13.201712
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    import os
    import json
    from .fragment import test_read_fragment
    fixture_path = os.path.join(os.path.dirname(__file__), 'fixtures')

    fragment = test_read_fragment(read_bootstrap_info)
    with open(os.path.join(
            fixture_path, 'bootstrapinfo.f4f.json'), 'r') as f:
        expected_fragment = json.load(f)
    assert expected_fragment == fragment


# Add a timestamp to the segment_run table in the bootstrap_info

# Generated at 2022-06-24 11:45:18.089182
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    test_stream = io.BytesIO()
    write_unsigned_int(test_stream, 1)
    write_unsigned_int(test_stream, 0x12345678)
    test_stream.seek(0)
    assert test_stream.read(4) == b'\x00\x00\x00\x01'
    assert test_stream.read(4) == b'\x12\x34\x56\x78'
test_write_unsigned_int()



# Generated at 2022-06-24 11:45:21.198003
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    write_unsigned_int(stream, 150)
    assert stream.getvalue() == compat_struct_pack('!I', 150)



# Generated at 2022-06-24 11:45:24.463412
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    f = io.BytesIO()

    f.write(b'abcd')
    f.seek(0)

    flv = FlvReader(f)
    assert flv.read_bytes(4) == b'abcd'


# Generated at 2022-06-24 11:45:33.869526
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    test_bytes = b'\x00\x00\x0f\xd0\x7a\x69\x70\x32\x69\x70\x33\x00\x00'

    # Case for normal: the number of bytes is equal to required
    f = FlvReader(test_bytes)
    ret = f.read_unsigned_int()
    assert ret == 4000

    # Case for unexpected EOF: the number of bytes is less than required
    f = FlvReader(test_bytes[:1])
    try:
        f.read_unsigned_int()
    except DataTruncatedError:
        pass
    else:
        assert False



# Generated at 2022-06-24 11:45:41.728007
# Unit test for function read_bootstrap_info

# Generated at 2022-06-24 11:45:50.154845
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    class DummyFile(object):
        def __init__(self, data):
            self.data = data
            self.pos = 0

        def read(self, n):
            res = self.data[self.pos:self.pos + n]
            self.pos += n
            return res

    reader = FlvReader(b'123')
    assert reader.read_unsigned_long_long() == 0x3132333435363738

    reader = FlvReader(b'123')
    d = DummyFile(b'123')
    reader.read = d.read
    assert reader.read_unsigned_long_long() == 0x3132333435363738

# Generated at 2022-06-24 11:45:57.721740
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    from .test import make_working_files_dir
    from ..utils import encode_data_uri
    working_files_dir = make_working_files_dir(__name__)

    for test_val in range(2 ** 24):
        data_uri = encode_data_uri(write_unsigned_int_24, test_val)
        assert data_uri == 'data:application/octet-stream;base64,AAAA%sAAAA' % (test_val + 2 ** 24).to_bytes(3, 'big').hex()



# Generated at 2022-06-24 11:46:06.347606
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    data = (b'\x00\x00\x00\x00' + b'abcd' +  # size, type
            b'\x00\x00\x00\x00')  # data
    reader = FlvReader(data)
    size, box_type, box_data = reader.read_box_info()
    assert size == 0
    assert box_type == b'abcd'
    assert box_data == b'\x00\x00\x00\x00'

    data = (b'\x00\x00\x00\x01' + b'abcd' +  # size, type
            b'\x00' +  # data
            b'\x00\x00\x00\x00\x00\x00\x00\x00')
    reader = Fl

# Generated at 2022-06-24 11:46:12.242892
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    import tempfile

    metadata = 'a' * 2000
    out = io.BytesIO()
    write_metadata_tag(out, metadata)
    with tempfile.NamedTemporaryFile() as f:
        f.write(out.getvalue())
        f.flush()
        assert (subprocess.call([
            'flvtool2', '-U', f.name], stderr=subprocess.PIPE) == 0)



# Generated at 2022-06-24 11:46:22.890506
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from .test_fragment import (
        _read_chunks as _read_test_chunks, _read_random_chunk as _read_test_random_chunk,
        _load_bootstrap_info as _load_test_bootstrap_info
    )
    bootstrap_info = _load_test_bootstrap_info()
    data = _read_test_chunks(bootstrap_info['baseurl'], bootstrap_info['bootstrap_chunks'], bootstrap_info['chunk_size'])
    assert FlvReader(data).read_bootstrap_info() == bootstrap_info
# End of unit test


# Generated at 2022-06-24 11:46:32.173951
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    test_stream = io.BytesIO()
    test_val = 1
    write_unsigned_int(test_stream, test_val)
    assert test_stream.getvalue() == compat_struct_pack('!I', test_val)
    test_val = 4294967296
    write_unsigned_int(test_stream, test_val)
    assert test_stream.getvalue() == compat_struct_pack('!I', 1) + compat_struct_pack('!Q', test_val)



# Generated at 2022-06-24 11:46:42.864868
# Unit test for function remove_encrypted_media

# Generated at 2022-06-24 11:46:54.676700
# Unit test for function read_bootstrap_info

# Generated at 2022-06-24 11:47:01.765278
# Unit test for constructor of class FlvReader
def test_FlvReader():
    from .fragment import testdata_fragments
    for frag in testdata_fragments:
        bootstrap_info = FlvReader(frag['bootstrap_info']).read_bootstrap_info()
        segments = bootstrap_info['segments']
        assert len(segments) == 1
        print("segments[0]='%s'" % segments[0])
        fragments = bootstrap_info['fragments']
        assert len(fragments) == 2
        print("fragments[0]='%s'" % fragments[0])
        print("fragments[1]='%s'" % fragments[1])
        assert bootstrap_info['live'] == True
        return



# Generated at 2022-06-24 11:47:13.753611
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    assert FlvReader(compat_struct_pack('!Q', 0)).read_unsigned_long_long() == 0
    assert FlvReader(compat_struct_pack('!Q', 1)).read_unsigned_long_long() == 1
    assert FlvReader(compat_struct_pack('!Q', 127)).read_unsigned_long_long() == 127
    assert FlvReader(compat_struct_pack('!Q', 128)).read_unsigned_long_long() == 128
    assert FlvReader(compat_struct_pack('!Q', 0xFFFF)).read_unsigned_long_long() == 0xFFFF
    assert FlvReader(compat_struct_pack('!Q', 0x10000)).read_unsigned_long_long() == 0x10000

# Generated at 2022-06-24 11:47:14.779389
# Unit test for method read_unsigned_long_long of class FlvReader

# Generated at 2022-06-24 11:47:25.237911
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    e = lambda x: compat_urllib_parse.quote(x, safe='')

# Generated at 2022-06-24 11:47:37.408632
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    flv_reader = FlvReader(
        b'\x00\x00\x00\x00\x00\x00\x00\x00'
        b'\x00\x00\x00\x00\x00\x00\x00\x00')
    assert flv_reader.read_string() == b''
    flv_reader = FlvReader(
        b'\x00\x01\x02\x03\x04\x05\x06\x07'
        b'\x00\x01\x02\x03\x04\x05\x06\x07')
    assert flv_reader.read_string() == b'\x00\x01\x02\x03\x04\x05\x06\x07'



# Generated at 2022-06-24 11:47:49.864146
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-24 11:48:00.260459
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # Test case 1
    flv = FlvReader(b'\x00\x00\x00\x08abcdef')
    size, box_type, data = flv.read_box_info()
    assert size == 8
    assert box_type == b'abcd'
    assert data == b'ef'

    # Test case 2

# Generated at 2022-06-24 11:48:06.873648
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    assert (FlvReader(b'\x00\x00\x00\x1c\x61\x73\x72\x74\x00\x00\x00\x00'
                     b'\x00\x00\x00\x01\x08\x00\x00\x00\x00\x00\x00\x01'
                     b'\x01\x00\x00\x00\x01\x00\x00\x00\x01').read_asrt() ==
            {'segment_run': [(0, 1)]})

# Generated at 2022-06-24 11:48:19.507536
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    instance = F4mFD()

    ## F4mFD._get_unencrypted_media
    man_url = 'http://example.com/manifest.f4m'
    requested_bitrate = 270
    self = MockF4mFD({
        'url': man_url,
        'tbr': 270,
    })
    self.to_screen = Mock(return_value=None)
    self.ydl = Mock(return_value=None)
    urlh = Mock(return_value=None)
    urlh.geturl = Mock(return_value=man_url)
    self.ydl.urlopen = Mock(return_value=urlh)
    doc = Mock(return_value=None)
    compat_etree_fromstring = Mock(return_value=doc)

# Generated at 2022-06-24 11:48:22.818737
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    from binascii import hexlify
    from io import BytesIO
    f = BytesIO()
    write_unsigned_int_24(f, -1)
    assert hexlify(f.getvalue()) == b'ffffff'



# Generated at 2022-06-24 11:48:27.621469
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError('test')
    except DataTruncatedError as e:
        assert str(e) == 'test'


# Data structures for different RTMP protocol control messages ##################

# https://github.com/claireellul/RTMPy/blob/master/rtmpy/protocol/message.py
# https://github.com/hydralabs/python-rtmp/blob/master/rtmp/message.py


# Generated at 2022-06-24 11:48:34.263942
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    assert (
        FlvReader(
            compat_struct_pack(
                '!ccccII', b'F', b'L', b'V', b'\x01', 9, 18)).read_unsigned_int(
        ) == 9)
    assert (
        FlvReader(
            compat_struct_pack(
                '!ccccI', b'F', b'L', b'V', b'\x01', 18)).read_unsigned_int() == 18)



# Generated at 2022-06-24 11:48:38.252161
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    bootstrap_bytes = compat_b64decode(b'''
    AAEAAQAAAAEAAQAAo21nZW9ncmFwaHl4Y2YxAAAAAAAAAAAAAAAAAAAADwAAAGpvaG5kcmln
    bG9yAAAAAAAAAAA=
    ''')
    bootstrap_info = read_bootstrap_info(bootstrap_bytes)
    assert bootstrap_info['live']
    assert len(bootstrap_info['segments']) == 1
    assert len(bootstrap_info['fragments']) == 1
    # We have a single segment, with fragments starting at 0, 1, 2
    # The fragment #0 has duration 0, it means a discontinuity
    assert bootstrap_info['segments'][0]['segment_run'] == [(0, 3)]
    assert len

# Generated at 2022-06-24 11:48:45.469975
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    with open('tests/testvid.flv', 'rb') as f:
        data = f.read()
    flv_reader = FlvReader(data)
    # Read the first two boxes in the file
    for i in range(2):
        size, type, data = flv_reader.read_box_info()
        assert size == len(data) + 8
    # Read the third box in the file, which should be an extended box
    size, type, data = flv_reader.read_box_info()
    assert size == len(data) + 16

# Generated at 2022-06-24 11:48:54.168975
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # Test for reading a box whose size is less than 2^32
    flv_reader = FlvReader(b'\x0C\x00\x00\x00ftyp\x00\x00\x00\x00abcd')
    box_size, box_type, box_data = flv_reader.read_box_info()
    assert box_size==12
    assert box_type==b'ftyp'
    assert box_data==b''
    # Test for reading a box whose size is 2^32
    flv_reader = FlvReader(b'\x00\x00\x00\x01\x00\x00\x00\x00ftyp\x00\x00\x00\x00abcd')

# Generated at 2022-06-24 11:49:05.117175
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    # 生成一个的十六进制的测试用例数据
    VALUES = ['9a', '3b', 'ba', '0f', '00', '00', '00', '00', '00', '00']
    # 调用read_bytes方法,参数为要读取的字节长度
    FLV_READER = FlvReader(bytearray.fromhex(''.join(VALUES)))
    # 输出读取后的值
    for _ in range(10):
        print('%X' % FLV_READER.read_unsigned_char(), end=' ')
    print()
    # 生成

# Generated at 2022-06-24 11:49:08.285468
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    assert write_unsigned_int_24(io.BytesIO(), 3) == b'\x00\x00\x03'



# Generated at 2022-06-24 11:49:16.505008
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'


# According to https://github.com/multichat/flv/commit/c1aa1bba5856deea8e7a9f98e922b2e2b8d8f620
# the standard actually states that it should be signed int, but either way works

# Generated at 2022-06-24 11:49:27.948446
# Unit test for function build_fragments_list
def test_build_fragments_list():
    # The following bootstrap info is from Rai (Italian TV channel) live stream.
    # Some times the fragments_count is 4294967295 which is abnormal.
    # It is OK to change the fragments_count in live streams as they are
    # updated periodically.
    boot_info = {
        'live': True,
        'segments': [
            {
                'segment_run': [
                    (
                        0,
                        4294967295,
                    ),
                ],
            },
        ],
        'fragments': [
            {
                'fragments': [
                    {
                        'first': 0,
                        'ts': 0,
                        'duration': 40000,
                        'discontinuity_indicator': None,  # Can be 1
                    },
                ],
            },
        ],
    }

# Generated at 2022-06-24 11:49:33.212056
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    flv_reader = FlvReader(b'\x00\x01\x02\x03')
    assert flv_reader.read_unsigned_char() == 0
    assert flv_reader.read_unsigned_char() == 1
    assert flv_reader.read_unsigned_char() == 2
    assert flv_reader.read_unsigned_char() == 3



# Generated at 2022-06-24 11:49:42.756913
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    res = b''
    stream = io.BytesIO()
    write_unsigned_int_24(stream, 0)
    res += stream.getvalue()
    assert res == b'\x00\x00\x00'
    stream = io.BytesIO()
    write_unsigned_int_24(stream, 1)
    res += stream.getvalue()
    assert res == b'\x00\x00\x00\x01\x00\x00'
    stream = io.BytesIO()
    write_unsigned_int_24(stream, 0x123456)
    res += stream.getvalue()
    assert res == b'\x00\x00\x00\x01\x00\x00\x12\x34\x56'



# Generated at 2022-06-24 11:49:45.856049
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    flv = FlvReader(b'\x00\x01\x02')
    assert flv.read_bytes(1) == b'\x00'
    assert flv.read_bytes(1) == b'\x01'
    assert flv.read_bytes(1) == b'\x02'

# Generated at 2022-06-24 11:49:59.073499
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:50:03.473512
# Unit test for constructor of class F4mFD
def test_F4mFD():
    fd = F4mFD(Downloader())
    fd.real_download('/tmp/test.mp4', {})

# Generated at 2022-06-24 11:50:13.214484
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-24 11:50:16.174686
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    with io.open(
            'test/data/bootstrap_sample_fragmented.abst', 'rb') as f:
        r = FlvReader(f.read())
        r.read_bootstrap_info()


# Generated at 2022-06-24 11:50:25.855393
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    import os
    import tempfile
    tmp_file = tempfile.NamedTemporaryFile(delete=False)
    write_unsigned_int(tmp_file, 1)
    write_unsigned_int(tmp_file, 2)
    write_unsigned_int(tmp_file, 3)
    tmp_file.close()
    assert open(tmp_file.name, 'rb').read() == b'\x00\x00\x00\x01\x00\x00\x00\x02\x00\x00\x00\x03'
    os.unlink(tmp_file.name)
#test_write_unsigned_int()



# Generated at 2022-06-24 11:50:32.977418
# Unit test for function build_fragments_list
def test_build_fragments_list():
    from .test import get_testdata_file

    boot_info = read_bootstrap_info(open(get_testdata_file('bootstrap.abst'), 'rb').read())
    res = build_fragments_list(boot_info)
    assert res == [(0, 0), (1, 1), (1, 2), (1, 3)]



# Generated at 2022-06-24 11:50:37.613297
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    from base64 import b64decode
    from nose.tools import assert_raises, assert_equals
    reader = FlvReader(b64decode(b'Ow=='))
    assert_equals(reader.read_unsigned_char(), 0)
    assert_raises(DataTruncatedError, reader.read_unsigned_char)
    assert reader.read(1) == b''


# Generated at 2022-06-24 11:50:49.359249
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # Create a box of the form 0x00 0x00 0x00 0x09 0x6F 0x6F 0x6F 0x6F 0x00 0x00
    # 0x00 0x00
    box = compat_struct_pack(
        '!I4sI', 13, b'oooo', 0)
    # Create a box of the form 0x00 0x00 0x00 0x0C 0x6F 0x6F 0x6F 0x6F
    # 0x00 0x00 0x00 0x00 0x00 0x00 0x00 0x03
    box1 = compat_struct_pack(
        '!I4sQ', 12, b'oooo', 3)
    data = box + box1
    f = FlvReader(data)
    res = f.read_box_

# Generated at 2022-06-24 11:50:52.531472
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    flv_reader = FlvReader(compat_struct_pack('!I', 4))
    assert flv_reader.read_unsigned_int() == 4



# Generated at 2022-06-24 11:51:04.198701
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    """
    Unit test for method real_download of class F4mFD
    """
    # Init
    ydl = YoutubeDL()
    f4m_fd = F4mFD(ydl)

# Generated at 2022-06-24 11:51:09.083599
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    # format: read_string(self):
    # returns: a string
    test_string = b'This is a test'
    test_string_bytes = b'This is a test\x00'
    assert FlvReader(test_string_bytes).read_string() == test_string



# Generated at 2022-06-24 11:51:11.979937
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    test_val = 0x12345678
    stream = io.BytesIO()
    write_unsigned_int(stream, test_val)
    assert stream.getvalue() == b'\x12\x34\x56\x78'



# Generated at 2022-06-24 11:51:17.018957
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    write_unsigned_int(stream, 2)
    assert stream.getvalue() == b'\x00\x00\x00\x02'
    write_unsigned_int(stream, 3)
    assert stream.getvalue() == b'\x00\x00\x00\x02\x00\x00\x00\x03'


# Generated at 2022-06-24 11:51:24.590546
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:51:34.693902
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-24 11:51:44.205775
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    # Little endian
    flv_reader = FlvReader(b'\x00\x00\x00\x00')
    assert flv_reader.read_unsigned_int() == 0
    flv_reader = FlvReader(b'\x01\x00\x00\x00')
    assert flv_reader.read_unsigned_int() == 1
    flv_reader = FlvReader(b'\x10\x00\x00\x00')
    assert flv_reader.read_unsigned_int() == 16
    flv_reader = FlvReader(b'\x80\x00\x00\x00')
    assert flv_reader.read_unsigned_int() == 128
    flv_reader = FlvReader(b'\x00\x00\x00\x01')

# Generated at 2022-06-24 11:51:52.707513
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import encode_base_n
    flv_path = os.path.join(os.path.dirname(__file__), 'live', 'bootstrap.flv')
    bootstrap_info = FlvReader(open(flv_path, 'rb').read()).read_bootstrap_info()
    # test case in https://github.com/rg3/youtube-dl/issues/9223
    assert bootstrap_info['segments'][0]['segment_run'][0] == (0, 10)
    assert bootstrap_info['segments'][0]['segment_run'][1] == (10, 10)
    assert bootstrap_info['segments'][0]['segment_run'][2] == (20, 10)

# Generated at 2022-06-24 11:51:56.743212
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    # Correct data
    correct_data = 'aaaa\x00bbbb\x00cccc\x00\x00'
    res = FlvReader(correct_data).read_string()
    assert res == b'aaaa'
    # Error data
    error_data = 'aaaa\x00bbbb\x00cccc\x00'
    err = None
    try:
        FlvReader(error_data).read_string()
    except Exception as e:
        err = e
    assert err
    assert isinstance(err, DataTruncatedError)



# Generated at 2022-06-24 11:52:00.907385
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    element = compat_etree_fromstring(
            """
            <Media>
                <Metadata>
                    <AMS name="DRMAdditionalHeaderSetId" value="1" />
                </Metadata>
                <Metadata>
                    <AMS name="DRMAdditionalHeaderId" value="1" />
                    <AMS name="DRMAdditionalHeaderMetadata" value="Test" />
                </Metadata>
            </Media>
            """)
    result = remove_encrypted_media(element)
    assert len(result) == 0



# Generated at 2022-06-24 11:52:11.523149
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring("""
        <manifest xmlns="http://ns.adobe.com/f4m/1.0">
            <baseURL>http://example.com</baseURL>
        </manifest>
    """)
    base_url = get_base_url(manifest)
    assert base_url == 'http://example.com'

    manifest = compat_etree_fromstring("""
        <manifest xmlns="http://ns.adobe.com/f4m/2.0">
            <baseURL>http://example.com</baseURL>
        </manifest>
    """)
    base_url = get_base_url(manifest)
    assert base_url == 'http://example.com'


# Generated at 2022-06-24 11:52:17.725687
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from .common import FakeYDL
    fake_ydl = FakeYDL({'test_value': test_FlvReader_read_bootstrap_info.__doc__})
    # Parse a test flv file
    flv_file = FlvReader(open(fake_ydl.test_file('bootstrap.flv'), 'rb').read())

# Generated at 2022-06-24 11:52:24.653880
# Unit test for function remove_encrypted_media