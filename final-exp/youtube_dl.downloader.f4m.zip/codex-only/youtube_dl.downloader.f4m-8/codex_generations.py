

# Generated at 2022-06-24 11:42:28.499910
# Unit test for function read_bootstrap_info

# Generated at 2022-06-24 11:42:32.734542
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    stream.seek(0)
    assert b'FLV\x01\x05\x00\x00\x00\t\x00\x00\x00\x00' == (stream.read())
test_write_flv_header()



# Generated at 2022-06-24 11:42:38.260937
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-24 11:42:48.716507
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():

    # Create a FD object and invoke real_download() method 
    from .extractor import YoutubeDL
    from .common import FileDownloader
    from .downloader.http import HttpFD
    
    dummy_ydl = YoutubeDL()
    dummy_fd = HttpFD(dummy_ydl)

    f4m_fd = F4mFD(dummy_fd)
    
    # Fix for comparing with unittest2 version
    if sys.version_info[:2] < (2, 7):
        import unittest2 as unittest
    else:
        import unittest
    
    

# Generated at 2022-06-24 11:42:56.990097
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    # Prepare the args
    media_list = [compat_etree_fromstring('''
<media url="http://download.tsi.telecom-paristech.fr/gpac/DASH_CONFORMANCE/TelecomParisTech/mp4-live-frag/mp4-live-frag_goto4-init.mp4"
    bitrate="300" bootstrapInfoId="1" drmAdditionalHeaderId="0" drmAdditionalHeaderSetId="0" width="1280" height="720"/>
''')]
    # Call function
    media_list = remove_encrypted_media(media_list)
    # Check result
    assert not media_list


# Generated at 2022-06-24 11:43:02.015761
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    write_unsigned_int(stream, 0x01020304)
    stream.seek(0)
    assert stream.read() == b'\x01\x02\x03\x04'



# Generated at 2022-06-24 11:43:08.997819
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    from ..compat import compat_struct_pack
    stream = io.BytesIO()
    metadata = compat_struct_pack('!I', 2)
    write_metadata_tag(stream, metadata)
    assert (stream.getvalue()
            == b'\x12\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x0c')
    stream.close()



# Generated at 2022-06-24 11:43:14.405647
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    with open('test/testdata/bootstrapinfo_abst.bin', 'rb') as f:
        bootstrap_bytes = f.read()
    bootstrap_info = read_bootstrap_info(bootstrap_bytes)

# Generated at 2022-06-24 11:43:26.100701
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    from binascii import a2b_hex

# Generated at 2022-06-24 11:43:30.355355
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    write_unsigned_int(stream, 0x01020304)
    assert stream.getvalue() == b'\x00\x00\x01\x02'
test_write_unsigned_int()



# Generated at 2022-06-24 11:43:38.408416
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    import os
    import json
    path = os.path.join(os.path.dirname(__file__), 'tests/files/bootstrap.bin')
    with open(path, 'rb') as f:
        data = f.read()
    bootstrap_info = FlvReader(data).read_bootstrap_info()
    path = os.path.join(os.path.dirname(__file__), 'tests/files/bootstrap.json')
    with open(path, 'r') as f:
        jsondata = f.read()
    assert json.loads(jsondata) == bootstrap_info
# end of unit test



# Generated at 2022-06-24 11:43:45.424897
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    f4m_fd = F4mFD()
    info_dict = {'url':'https://hds-silex-test.s3.eu-central-1.amazonaws.com/sintel_trailer-720p.f4m'}
    filename = 'sintel_trailer-720p.mp4'
    test_value = f4m_fd.real_download(filename, info_dict)
    assert test_value == True

# Generated at 2022-06-24 11:43:57.990567
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-24 11:44:07.523668
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
  flv_reader=FlvReader(open(r"/Users/aref/Documents/amazon/tests/test.abst",'rb').read())
  abst=flv_reader.read_bootstrap_info()

  flv_reader=FlvReader(open(r"/Users/aref/Documents/amazon/tests/test.afrt",'rb').read())
  afrt=flv_reader.read_afrt()
  print(afrt)
  pass



# Generated at 2022-06-24 11:44:10.903505
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    assert FlvReader(compat_struct_pack('!Q', 0x123456789abcdef0)).read_unsigned_long_long() == 0x123456789abcdef0



# Generated at 2022-06-24 11:44:17.727381
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    stream.seek(0)
    assert stream.read(3) == b'FLV'
    assert compat_struct_unpack('!B', stream.read(1))[0] == 1
    assert compat_struct_unpack('!B', stream.read(1))[0] == 5
    assert compat_struct_unpack('!I', stream.read(4))[0] == 9
    assert compat_struct_unpack('!I', stream.read(4))[0] == 0


# Generated at 2022-06-24 11:44:29.557434
# Unit test for function remove_encrypted_media

# Generated at 2022-06-24 11:44:33.102306
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    f = FlvReader(b'abcd\x00\x00\x00\x01\x00\x00\x00\x00')
    f.seek(4)
    assert f.read_unsigned_long_long() == 1



# Generated at 2022-06-24 11:44:39.352179
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    # flv_reader = FlvReader(open("C:\\Users\\linh\\Downloads\\cnn.frag2.abst", "rb").read())
    flv_reader = FlvReader(open("/home/linh/Desktop/cnn.frag2.abst", "rb").read())
    print(flv_reader.read_bootstrap_info())

# test_FlvReader_read_afrt()


# Generated at 2022-06-24 11:44:45.534376
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-24 11:44:57.858003
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-24 11:45:07.435430
# Unit test for function get_base_url
def test_get_base_url():
    f = compat_etree_fromstring(
        b'<manifest xmlns="http://ns.adobe.com/f4m/1.0"></manifest>')
    assert get_base_url(f) is None

    f = compat_etree_fromstring(
        b'<manifest xmlns="http://ns.adobe.com/f4m/1.0"><baseURL>/foo/</baseURL></manifest>')
    assert get_base_url(f) == '/foo/'

    f = compat_etree_fromstring(
        b'<manifest xmlns="http://ns.adobe.com/f4m/1.0"><baseURL> /foo/  </baseURL></manifest>')
    assert get_base_url(f) == '/foo/'

    f = compat_etree

# Generated at 2022-06-24 11:45:19.024174
# Unit test for constructor of class FlvReader
def test_FlvReader():
    # Test construct
    # 1. Test case - "normal" construct
    content = b'\x00\x00\x00\n\x61\x62\x73\x74\x00\x00\x00\x00'
    flv_reader = FlvReader(content)
    assert flv_reader.read_bytes(4) == b'\x00\x00\x00\n'
    assert flv_reader.read_bytes(4) == b'\x61\x62\x73\x74'
    assert flv_reader.read_box_info() == (8, b'abst', b'\x00\x00\x00\x00')

    # 2. Test case - "insufficient" content

# Generated at 2022-06-24 11:45:25.165799
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    reader = FlvReader(b'\x01\x02\x03\x04\x05\x06')
    assert reader.read_bytes(3) == b'\x01\x02\x03'
    assert reader.read_bytes(2) == b'\x04\x05'
    assert reader.read_bytes(1) == b'\x06'
    try:
        reader.read_bytes(1)
    except:
        pass
    else:
        assert False

# Generated at 2022-06-24 11:45:28.154516
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    assert FlvReader(compat_struct_pack('!I', 10)).read_unsigned_int() == 10

# Generated at 2022-06-24 11:45:36.283360
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    stream = io.BytesIO()
    metadata = '<test>test</test>'
    write_metadata_tag(stream, metadata)
    assert stream.getvalue() == (
        b'\x12\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x0b'
        b'<test>test</test>\x0b\x00\x00\x00')



# Generated at 2022-06-24 11:45:43.448444
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-24 11:45:52.563241
# Unit test for function remove_encrypted_media

# Generated at 2022-06-24 11:46:02.270766
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import (
        determine_ext,
    )
    from .fragment import (
        FragmentFD
    )
    from .dash import (
        parse_mpd_formats,
        MpdParser,
    )

    t = 'video_only.flv'
    url = 'http://rmcdn.2mdn.net/Demo/vast_inspector/android.flv'
    stream = FragmentFD(t, url).open()
    reader = FlvReader(stream.read())
    b = reader.read_bootstrap_info()
    mpd_url = 'http://rmcdn.2mdn.net/Demo/vast_inspector/android.mpd'

# Generated at 2022-06-24 11:46:13.527849
# Unit test for function build_fragments_list

# Generated at 2022-06-24 11:46:22.309954
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    reader = FlvReader(b'\x00\x01\x00\x00\x00\x02bc\x00\x03def\x00\x00\x00')
    assert reader.read_string() == b'\x01\x00\x00'
    assert reader.read_string() == b'bc'
    assert reader.read_string() == b'def'
    assert reader.read_string() == b''

# Generated at 2022-06-24 11:46:28.550872
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    reader = FlvReader(compat_b64decode(b'AAAAAAAAAAAAAAAA'))
    assert reader.read_bytes(10) == b'AAAAAAAAAA'
    assert reader.read_bytes(1) == b'A'
    assert reader.read_bytes(1) == b'A'



# Generated at 2022-06-24 11:46:39.415226
# Unit test for constructor of class FlvReader

# Generated at 2022-06-24 11:46:49.173480
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    metadata = b'my metadata'
    expected_content = b'\x12\x00\x00\x11\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x6d\x79\x20\x6d\x65\x74\x61\x64\x61\x74\x61\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x1a'
    stream = io.BytesIO()
    write_flv_header(stream)
    write_metadata_tag(stream, metadata)
    content = stream.getvalue()
    assert content == expected

# Generated at 2022-06-24 11:47:00.047973
# Unit test for function write_metadata_tag

# Generated at 2022-06-24 11:47:02.483481
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():  # NOQA
    test_string = compat_struct_pack('!I', 0x01020304)
    reader = FlvReader(test_string)
    assert reader.read_unsigned_int() == 0x01020304



# Generated at 2022-06-24 11:47:10.057864
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    sample_info = open('test/testdata/sample.abst', 'rb').read()
    info = FlvReader(sample_info).read_bootstrap_info()
    assert type(info['fragments']) == list
    assert type(info['fragments'][0]['fragments']) == list
    assert type(info['segments']) == list
    assert type(info['segments'][0]['segment_run']) == list


# Generated at 2022-06-24 11:47:13.601688
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    write_unsigned_int(stream, 0x01020304)
    assert stream.getvalue() == b'\x01\x02\x03\x04'



# Generated at 2022-06-24 11:47:17.657186
# Unit test for function write_flv_header
def test_write_flv_header():
    with io.BytesIO() as f:
        write_flv_header(f)
        assert f.getvalue() == b'FLV\x01\x05\x00\x00\x00\t\x00\x00\x00\x00'
test_write_flv_header()



# Generated at 2022-06-24 11:47:21.121899
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    from .test import read_test_data
    data = read_test_data('bootstrapinfo.dat')
    reader = FlvReader(data)
    reader.read_bootstrap_info()



# Generated at 2022-06-24 11:47:24.515156
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    flv_reader = FlvReader(compat_struct_pack('!Q', 0x1122334455667788))
    assert flv_reader.read_unsigned_long_long() == 0x1122334455667788



# Generated at 2022-06-24 11:47:36.247257
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    from io import BytesIO
    from collections import defaultdict
    from xml.dom.minidom import parseString
    from xml.etree import ElementTree


# Generated at 2022-06-24 11:47:39.957544
# Unit test for function write_flv_header
def test_write_flv_header():
    assert write_flv_header(io.BytesIO()).getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-24 11:47:51.641174
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    import unittest
    import random
    class TestFlvReaderReadUnsignedLongLong(unittest.TestCase):
        def runTest(self):
            random.seed()
            for i in range(0,1000):
                number = random.randint(0,18446744073709551615)
                f = io.BytesIO()
                f.write(compat_struct_pack('!Q', number))
                f.seek(0)
                self.assertEqual(FlvReader(f).read_unsigned_long_long(), number)
    suite = unittest.TestSuite()
    suite.addTest(TestFlvReaderReadUnsignedLongLong())
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-24 11:47:54.302399
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    assert FlvReader(compat_struct_pack(
        '!Q', 0x123456789ABCDEF0)).read_unsigned_long_long() == 0x123456789ABCDEF0



# Generated at 2022-06-24 11:47:56.265632
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    assert compat_struct_unpack('!I', compat_struct_pack('!I', 10))[0] == 10



# Generated at 2022-06-24 11:48:04.113133
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
  """
      Test for the method read_box_info of class FlvReader.
      This test does not have the main() function.
      To run this test and see the result, please use:
          $ python test_FlvReader.py \
              | tee test_FlvReader_read_box_info.log
  """
  # Prepare the test data in variable flv_binary
  flv_binary = b''
  flv_binary += compat_struct_pack('!I', 0)
  flv_binary += b'abst'
  flv_binary += compat_struct_pack('!I', 0)
  flv_binary += b'asrt'
  flv_binary += compat_struct_pack('!I', 0)
  flv_binary += b'afrt'
  flv_binary += compat_struct

# Generated at 2022-06-24 11:48:14.736051
# Unit test for constructor of class FlvReader
def test_FlvReader():
    a = FlvReader(b'\x00\x00\x00\x10\xab\xcd\xef\x12\x34\x56\x78\x00\x00\x00\x02\x00\x00\x00\x03')
    assert a.read_box_info() == (16, b'\xab\xcd\xef\x12', b'\x34\x56\x78\x00\x00\x00\x02\x00\x00\x00\x03')
    assert a.read() == b''
    try:
        a.read_box_info()
        assert False
    except EOFError:
        assert True



# Generated at 2022-06-24 11:48:20.336504
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    assert b'\x00\x00\x01\x02' == compat_struct_pack('!I', 0x00000102)
    assert b'\x01\x02' == compat_struct_pack('!I', 0x00000102)[1:]



# Generated at 2022-06-24 11:48:23.547711
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    flvreader = FlvReader(compat_struct_pack('!HHI', 3, 1,
                                             16) + b'teststring\x00')
    assert flvreader.read_string() == b'teststring'



# Generated at 2022-06-24 11:48:29.948507
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:48:40.016870
# Unit test for function build_fragments_list

# Generated at 2022-06-24 11:48:47.727175
# Unit test for function build_fragments_list
def test_build_fragments_list():
    bootstrap_info = {
        'segments': [{
            'segment_run': [
                (1, 5),
                (2, 5),
                (3, 5),
            ],
        }],
        'fragments': [{
            'fragments': [
                {
                    'first': 1,
                    'duration': 0,
                },
                {
                    'first': 2,
                    'duration': 0,
                },
                {
                    'first': 3,
                    'duration': 0,
                },
            ]
        }],
        'live': False
    }
    res = build_fragments_list(bootstrap_info)

# Generated at 2022-06-24 11:48:59.970541
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    import unittest
    import base64


# Generated at 2022-06-24 11:49:07.531233
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(bytes('''
        <manifest>
          <baseURL>https://example.com/</baseURL>
        </manifest>
    ''', 'utf-8'))
    assert get_base_url(manifest) == 'https://example.com/'
    manifest = compat_etree_fromstring(bytes('''
        <manifest>
          <foo>bar</foo>
        </manifest>
    ''', 'utf-8'))
    assert get_base_url(manifest) is None

# Generated at 2022-06-24 11:49:11.677139
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    relative_path_data = '../test/f4m/bootstrap_info_frag_offset.dat'
    flv_reader = FlvReader(open(relative_path_data, 'rb').read())
    bootstrap_info = flv_reader.read_bootstrap_info()

# Generated at 2022-06-24 11:49:17.631273
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    f = FlvReader(b'\x00\x00\x00\x01s\x00\x00\x00\x09test1\x00\x00\x00\x09test2')
    assert f.read_string() == b''
    assert f.read_string() == b'test1'
    assert f.read_string() == b'test2'



# Generated at 2022-06-24 11:49:26.141870
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # This unit test is not intended to be executed. It is used only to document the method real_download and its parameters
    assert False
    ydl = get_test_ydl()
    ydl.params['test'] = True

    filename = None
    info_dict = {
        'url': None,
        'extra_param_to_segment_url': None,
        'tbr': None,
    }

    f4mFD_obj = F4mFD(ydl)

    success = f4mFD_obj.real_download(filename, info_dict)
    assert success is not None

# Generated at 2022-06-24 11:49:32.557830
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    with open('tests/test_data/frag_bunny1.bootstrap', 'rb') as f:
        data = f.read()
    abst = FlvReader(data).read_bootstrap_info()
    assert abst['segments'][0]['segment_run'][0] == (0, 1)
    assert abst['fragments'][0]['fragments'][0]['first'] == 1
    assert abst['fragments'][0]['fragments'][0]['ts'] == 0
    assert abst['fragments'][0]['fragments'][0]['duration'] == 54


# Generated at 2022-06-24 11:49:41.678659
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    input1 = (b'\x00\x00\x00\x00'  # box size - 0
              b'\x61\x62\x63\x64')  # box type - abcd

    input2 = (b'\x00\x00\x00\x01'  # box size - 1
              b'\x61\x62\x63\x64'  # box type - abcd
              b'\x00\x00\x00\x00\x00\x00\x00'
              b'\x00\x00\x00\x00\x00\x00\x00\x00')  # box data


# Generated at 2022-06-24 11:49:44.750684
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    reader = FlvReader(b'12345')
    assert reader.read_bytes(5) == b'12345'
    try:
        reader.read_bytes(10)
        assert False
    except DataTruncatedError:
        assert True



# Generated at 2022-06-24 11:49:49.212250
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    assert FlvReader(b'hello\x00world\x00').read_string() == b'hello'
    assert FlvReader(b'hello\x00world\x00').read_string() == b'world'



# Generated at 2022-06-24 11:50:00.959387
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-24 11:50:12.366075
# Unit test for function build_fragments_list
def test_build_fragments_list():
    bootstrap_info = {
        'live': False,
        'segments': [{
            'segment_run': [(0, 1), (1, 2)],
        }],
        'fragments': [{
            'fragments': [
                {
                    'discontinuity_indicator': None,
                    'duration': 10,
                    'first': 1,
                    'ts': 0,
                },
                {
                    'discontinuity_indicator': None,
                    'duration': 10,
                    'first': 2,
                    'ts': 0,
                },
                {
                    'discontinuity_indicator': None,
                    'duration': 10,
                    'first': 3,
                    'ts': 0,
                },
            ],
        }],
    }
    fragments = build_fr

# Generated at 2022-06-24 11:50:21.346688
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media_encrypted = [
        {'url': 'http://test.test/test.mp4', 'drmAdditionalHeaderId': '1'},
        {'url': 'http://test.test/test.mp4', 'drmAdditionalHeaderSetId': '1'},
    ]
    media_not_encrypted = [
        {'url': 'http://test.test/test.mp4'},
        {'url': 'http://test.test/test.mp4'},
    ]
    assert media_encrypted == list(remove_encrypted_media(media_encrypted))
    assert media_not_encrypted == list(remove_encrypted_media(media_not_encrypted))



# Generated at 2022-06-24 11:50:34.398798
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    from .f4f_test import FLVReaderTestGetter

# Generated at 2022-06-24 11:50:37.182241
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError(u'message')
    except DataTruncatedError as e:
        assert str(e) == 'message'



# Generated at 2022-06-24 11:50:48.936824
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    def _test(t, s):
        test_value = FlvReader(compat_struct_pack(str(t), s)).read_unsigned_long_long()
        assert test_value == s, "%s failed, %s %s" % (
            t, test_value, s)

    # Test cases from https://www.adobe.com/devnet/f4v.html
    _test('>Q', 0)
    _test('>Q', 1)
    _test('>Q', 0x7FFFFFFF)
    _test('>Q', 0x80000000)
    _test('>Q', 0xFFFFFFFF)
    _test('>Q', 0xFFFFFFFFFFFFFFFE)
    _test('>Q', 0xFFFFFFFFFFFFFFFF)



# Generated at 2022-06-24 11:50:54.808994
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    def assert_read(expected, bytes):
        info = read_bootstrap_info(compat_b64decode(bytes))
        assert info == expected

# Generated at 2022-06-24 11:51:06.636857
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    try:
        import youtube_dl.YoutubeDL
        import youtube_dl.extractor.rutube
    except ImportError as e:
        print('[Warning] Importing YouTubeDL or its rutube extractor failed.')
        print('[Warning] Skipping F4mFD._start_frag_download method tests')
        return

    url = "http://blob-fra.rutube.ru/stream/1024/HDS/SD/C2NKsS85HQNckgn5HdEmOQ/1454161700/S-s604419906/move/four/dirs/upper/1024-576p.f4m"
    ydl = youtube_dl.YoutubeDL({})
    f4m_fd = F4mFD(ydl=ydl, params={})
    f4m

# Generated at 2022-06-24 11:51:12.049414
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    fro = io.BytesIO()
    metadata = "test"
    write_metadata_tag(fro, metadata)
    assert fro.getvalue() == '\x12\x00\x00\x04\x00\x00\x00\x00\x00\x00\x00test\x00\x00\x00\x0e'



# Generated at 2022-06-24 11:51:21.177008
# Unit test for constructor of class FlvReader
def test_FlvReader():
    # read the content of a flv file
    with io.open('f4m_example.flv', 'rb') as f:
        content = f.read()

    # Then pass it to FlvReader
    fd = FlvReader(content)

    # The file should start with FLV signature
    assert fd.read(3) == b'FLV'

    # Next byte is the version
    assert fd.read_unsigned_char() == 1

    # Next byte is the flags
    flags = fd.read_unsigned_char()
    assert flags & 0xFA == 0

    # Next is the data offset
    assert fd.read_unsigned_int() == 9

    # At this point, we should be at FLV header end
    assert fd.tell() == 9

    # Parse all the tags

# Generated at 2022-06-24 11:51:29.247127
# Unit test for constructor of class FlvReader
def test_FlvReader():
    raw_reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x00\x01\x02')
    assert raw_reader.read_string() == b''
    assert raw_reader.read_unsigned_long_long() == 1
    assert raw_reader.read_unsigned_int() == 0
    assert raw_reader.read_unsigned_char() == 2



# Generated at 2022-06-24 11:51:33.083839
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    # Just make sure that no unhandled exceptions are raised
    FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x00abst').read_abst()



# Generated at 2022-06-24 11:51:43.311617
# Unit test for method read_unsigned_int of class FlvReader

# Generated at 2022-06-24 11:51:47.210027
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    assert FlvReader(compat_struct_pack('!Q', 0x0)).read_unsigned_long_long() == 0x0
    assert FlvReader(compat_struct_pack('!Q', 0xFFFFFFFFFFFFFFFF)).read_unsigned_long_long() == 0xFFFFFFFFFFFFFFFF


# Generated at 2022-06-24 11:51:57.340607
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    bootstrap_info = read_bootstrap_info(b'dasd')
    assert bootstrap_info['segments'][0]['segment_run'] == [
        (0, 1),
        (1, 1),
        (2, 1),
        (3, 1),
        (4, 1),
        (5, 1),
        (6, 1),
        (7, 1),
        (8, 1),
        (9, 1),
        (10, 1),
    ]
    assert len(bootstrap_info['fragments']) == 1
    frags = bootstrap_info['fragments'][0]['fragments']
    assert frags[0]['first'] == 0
    assert frags[0]['duration'] == 2
    assert frags[0]['ts'] == 13714

# Generated at 2022-06-24 11:51:58.506299
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    e = DataTruncatedError('foo')
    assert str(e) == 'foo'


# Generated at 2022-06-24 11:52:06.955685
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    assert write_unsigned_int(io.BytesIO(), 1) == b'\x00\x00\x00\x01'
    assert write_unsigned_int(io.BytesIO(), 0) == b'\x00\x00\x00\x00'
    assert write_unsigned_int(io.BytesIO(), 2147483648) == b'\x00\x00\x00\x8000000'
    assert write_unsigned_int(io.BytesIO(), 4294967295) == b'\x00\x00\x00\xff\xff\xff\xff'
test_write_unsigned_int()



# Generated at 2022-06-24 11:52:14.086718
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    flv = FlvReader(b'')
    try:
        flv.read_bytes(1)
        assert False, 'Should not reach here'
    except DataTruncatedError:
        pass
    flv = FlvReader(b'\x12')
    assert flv.read_bytes(1) == b'\x12'
    try:
        flv.read_bytes(1)
        assert False, 'Should not reach here'
    except DataTruncatedError:
        pass

# Generated at 2022-06-24 11:52:15.116148
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    DataTruncatedError("test")


# Generated at 2022-06-24 11:52:21.216602
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # create a fake f4m url
    url = 'http://example.com/file.f4m'