

# Generated at 2022-06-24 11:42:26.207516
# Unit test for method read_box_info of class FlvReader

# Generated at 2022-06-24 11:42:32.362326
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    bin1 = (
        b'\x00\x00\x00\x24\x61\x73\x72\x74\x00\x00\x00\x00\x00'
        b'\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00'
        b'\x00\x00\x00\x00\x00\x00\x00\x10\x00\x00\x00\x01\x00'
        b'\x00\x00\x01\x00\x00\x00\x01'
    )
    flv = FlvReader(bin1)
    asrt = flv.read_asrt()

# Generated at 2022-06-24 11:42:41.871161
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError("Data is truncated")
    except DataTruncatedError as e:
        assert (str(e) == "Data is truncated")


# Dependency:  fmt and fmt in formats require each other
# formats = {'fmt': (prefixes, quality, dl_formats)}
# prefixes is a dict, {prefix1: current_fmt, prefix2: current_fmt, ..., 'general': current_fmt}
# current_fmt is a int, for example: 36
# quality is a list of str, in order, for example: ['hd1080', 'hd720', 'large', 'medium', 'small']
# dl_formats stores the downloadable formats, a dict {fmt: (ext, resolution)}

# fmt = {
#	'itag': (prot

# Generated at 2022-06-24 11:42:44.533786
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    data = compat_struct_pack('!Q', 50)
    reader = FlvReader(data)
    assert reader.read_unsigned_long_long() == 50


# Generated at 2022-06-24 11:42:47.608777
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    reader = FlvReader(compat_struct_pack('!I', 0xDEADBEEF))
    assert reader.read_unsigned_int() == 0xDEADBEEF


# Generated at 2022-06-24 11:42:54.634013
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    import re
    import base64

# Generated at 2022-06-24 11:43:04.344669
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    # data for test cases
    data = compat_b64decode(b'AAAAbXNnQmFzZTY0')
    fr = FlvReader(data)
    assert fr.read_afrt() == {
        'fragments': [],
    }
    data = compat_b64decode(
        b'AAAAbXNnQmFzZTY0AAAAAAEAQkEAAQAAgEEAAIABwEMAAgABgEAAAMABXVybA==')
    fr = FlvReader(data)
    assert fr.read_afrt() == {
        'fragments': [{
            'discontinuity_indicator': None,
            'first': 0,
            'ts': 0,
            'duration': 0,
        }],
    }
    data

# Generated at 2022-06-24 11:43:08.144232
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Initialize parameters for real_download
    f4mfd = F4mFD() # init a F4mFD object
    # Set attribute values
    f4mfd.params = {'test': True}
    f4mfd.ydl = YoutubeDL() # init a YoutubeDL object
    filename = 'test.f4m'
    info_dict = {}
    # Run _real_download
    f4mfd.real_download(filename, info_dict)



# Generated at 2022-06-24 11:43:11.382053
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    file_data = b'\x00test\x00test2\x00\x01\x02'
    reader = FlvReader(file_data)
    assert reader.read_string() == b'test'
    assert reader.read_string() == b'test2'
    assert reader.read_string() == b''
    assert reader.read() == b'\x01\x02'

# Generated at 2022-06-24 11:43:24.520260
# Unit test for constructor of class FlvReader
def test_FlvReader():
    def test_parsing(bootstrap_info_hex, expected_bootstrap_info):
        # Compute the size of the hex
        # Remove the spaces
        bootstrap_info_hex = bootstrap_info_hex.replace(' ', '')
        bootstrap_info_hex = bootstrap_info_hex.encode('ascii')
        # The size of each item in hex
        item_size = 2
        # The length of bootstrap_info_hex
        length = len(bootstrap_info_hex)
        # The number of items in bootstrap_info_hex
        n = length // item_size
        result = []
        for i in range(n):
            item_start = i * item_size
            item_end = item_start + item_size

# Generated at 2022-06-24 11:43:32.304362
# Unit test for function get_base_url
def test_get_base_url():
    """
    Unit test for function get_base_url
    """
    xml_str1 = (
        '<manifest>'
        '<baseURL>http://test.test</baseURL>'
        '</manifest>'
    )
    assert 'http://test.test' == get_base_url(compat_etree_fromstring(xml_str1))
    xml_str2 = (
        '<manifest>'
        '<baseURL></baseURL>'
        '</manifest>'
    )
    assert '' == get_base_url(compat_etree_fromstring(xml_str2))
    xml_str3 = (
        '<manifest>'
        '</manifest>'
    )

# Generated at 2022-06-24 11:43:40.899551
# Unit test for constructor of class FlvReader
def test_FlvReader():
    flvreader = FlvReader(b'\x00' * 5)

    assert flvreader.read_bytes(5) == b'\x00' * 5
    try:
        flvreader.read_bytes(6)
        assert False
    except DataTruncatedError:
        pass

    assert flvreader.read_unsigned_long_long() == 0
    assert flvreader.read_unsigned_int() == 0
    assert flvreader.read_unsigned_char() == 0

    assert flvreader.read_string() == b''
    assert flvreader.read_string() == b''

# Generated at 2022-06-24 11:43:50.301407
# Unit test for function read_bootstrap_info

# Generated at 2022-06-24 11:44:00.998997
# Unit test for function remove_encrypted_media

# Generated at 2022-06-24 11:44:06.418611
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    reader = FlvReader(b'abc\x00d')
    assert reader.read_bytes(4) == b'abc\x00'
    try:
        reader.read_bytes(2)
    except DataTruncatedError:
        pass
    else:
        raise AssertionError('DataTruncatedError is not raised')


# Generated at 2022-06-24 11:44:15.540713
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    """ Tests function write_unsigned_int_24 """
    assert(write_unsigned_int_24(io.BytesIO(), 0x0) == io.BytesIO(b'\x00\x00\x00') )
    assert(write_unsigned_int_24(io.BytesIO(), 0xFF) == io.BytesIO(b'\x00\x00\xFF') )
    assert(write_unsigned_int_24(io.BytesIO(), 0xFFFF) == io.BytesIO(b'\x00\xFF\xFF') )
    assert(write_unsigned_int_24(io.BytesIO(), 0xFFFFFF) == io.BytesIO(b'\xFF\xFF\xFF') )

# Generated at 2022-06-24 11:44:20.348695
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv = FlvReader(open('tests/fixtures/bootstrap.abst', 'rb').read())
    abst = flv.read_bootstrap_info()
    assert abst['live'] is True
    assert abst['fragments'][0]['fragments'][0] == {
        'first': 1,
        'ts': 934671091000000,
        'duration': 4000000,
        'discontinuity_indicator': None,
    }



# Generated at 2022-06-24 11:44:31.291233
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    reader = FlvReader(b'\x00\x00\x01\x00')
    assert reader.read_unsigned_int() == 256
    reader = FlvReader(b'\x00\x00\x01\x00')
    assert reader.read_unsigned_int() == 1
    reader = FlvReader(b'\x00\x00\x01\x00')
    assert reader.read_unsigned_int() == 0
    reader = FlvReader(b'\x00\x00\x01\x00')
    assert reader.read_unsigned_int() == 257
    reader = FlvReader(b'\x00\x00\x01\x00')
    assert reader.read_unsigned_int() == 16777216

# Generated at 2022-06-24 11:44:39.577838
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    # Test case 1
    test_case = b'\x00\x00\x00\x01'
    reader = FlvReader(test_case)
    assert reader.read_unsigned_int() == 1
    # Test case 2
    test_case = b'\x00\x00\x00\x02\x00\x00\x00\x03'
    reader = FlvReader(test_case)
    assert reader.read_unsigned_int() == 2
    # Test case 3
    test_case = b'\x00\x00\x00\x04\x00\x00\x00\x03'
    reader = FlvReader(test_case)
    assert reader.read_unsigned_int() == 4
    # Test case 4

# Generated at 2022-06-24 11:44:42.849089
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    stream = io.BytesIO()
    for i in range(16777216):
        write_unsigned_int_24(stream, i)
    stream.seek(0)
    for i in range(16777216):
        n = compat_struct_unpack('!I', b'\x00' + stream.read(3))[0]
        assert n == i



# Generated at 2022-06-24 11:44:50.554034
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    in_file = io.BytesIO(b'foobar')
    r = FlvReader(in_file)
    assert r.read_bytes(3) == b'foo'
    assert r.read_bytes(2) == b'ba'
    assert r.read_bytes(1) == b'r'
    try:
        r.read_bytes(1)
        assert False, 'DataTruncatedError should be raised'
    except DataTruncatedError:
        pass


# Generated at 2022-06-24 11:45:00.835627
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    xml = '''
        <media url="somewhere.f4m">
        </media>
        <media url="somewhere.f4m">
            <drmAdditionalHeaderId>header1</drmAdditionalHeaderId>
            <drmAdditionalHeaderSetId>headerSet1</drmAdditionalHeaderSetId>
        </media>
        <media url="somewhere.f4m">
            <drmAdditionalHeaderId>header2</drmAdditionalHeaderId>
            <drmAdditionalHeaderSetId>headerSet2</drmAdditionalHeaderSetId>
        </media>'''
    doc = compat_etree_fromstring(xml)
    media = doc.findall('./media')
    assert media[0] == remove_encrypted_media(media)[0]



# Generated at 2022-06-24 11:45:06.121185
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    data = b'\x00\x00\x00\x02\x00\x00\x00\x04\x00\x00\x00\x06'
    freader = FlvReader(data)
    assert freader.read_unsigned_int() == 2
    assert freader.read_unsigned_int() == 4
    assert freader.read_unsigned_int() == 6



# Generated at 2022-06-24 11:45:16.664814
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    from ..compat import compat_urlopen
    import os.path
    import random
    base_url = 'http://s.jwpcdn.com/player/v/7.6.3/'
    jwplayer_urls = [
        'jwplayer.flash.swf',
        'jwplayer.html5.js',
    ]
    for jwplayer_url in jwplayer_urls:
        res = compat_urlopen(base_url + jwplayer_url)
        assert res.getcode() == 200
        bootstrap_bytes = res.read()
        # Parse the bytes
        read_bootstrap_info(bootstrap_bytes)
        # Try to parse the bytes again
        read_bootstrap_info(bootstrap_bytes)

# Generated at 2022-06-24 11:45:21.371367
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    import io
    test = io.BytesIO()
    write_unsigned_int(test, 100)
    test.seek(0)
    assert 100 == compat_struct_unpack('!I', test.read(4))[0]
test_write_unsigned_int()



# Generated at 2022-06-24 11:45:24.946340
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    data = b'\x0c\x00\x00\x00' + b'abcd\x00' + b'efgh'
    reader = FlvReader(data)
    assert reader.read_string() == b'abcd'
    assert reader.read_string() == b'efgh'



# Generated at 2022-06-24 11:45:30.700738
# Unit test for function write_flv_header
def test_write_flv_header():
    test_stream = io.BytesIO()
    write_flv_header(test_stream)
    assert test_stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-24 11:45:33.160102
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    rdr = FlvReader(b'\x02')
    assert rdr.read_unsigned_char() == 2



# Generated at 2022-06-24 11:45:41.183728
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    import sys
    if sys.version_info < (3, 0):
        import io
        sys.stdout = io.open(sys.stdout.fileno(), 'w', 1, encoding='utf-8')

# Generated at 2022-06-24 11:45:50.790619
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    test_str = b'\x00\x00\x00\x00' + b'type' + b'data'
    inp = FlvReader(test_str)
    assert inp.read_box_info() == (0, b'type', b'data')
    test_str = b'\x00\x00\x00\x08' + b'type' + b'data'
    inp = FlvReader(test_str)
    assert inp.read_box_info() == (8, b'type', b'data')
    test_str = b'\x00\x00\x00\x01' + b'type' + b'\x00\x00\x00\x00\x00\x00\x00\x08' + b'data'

# Generated at 2022-06-24 11:46:01.207006
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    from io import BufferedWriter, BytesIO
    from xml.dom import minidom
    metadata = b'<test/>'
    stream = BufferedWriter(BytesIO())
    write_metadata_tag(stream, metadata)
    stream.seek(0)
    res = stream.read()
    header = res[:11]
    assert header[0] == b'\x12'
    assert header[1:4] == b'\x00\x00' + b'\x07'
    assert header[4:11] == b'\x00\x00\x00\x00\x00\x00\x00'
    assert minidom.parseString(compat_b64decode(res[11:-4])).toxml() == u'<test/>'
    assert res[-4:] == b

# Generated at 2022-06-24 11:46:08.790605
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:46:09.742853
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    assert str(DataTruncatedError()) == "Data truncated."



# Generated at 2022-06-24 11:46:11.733181
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    err = DataTruncatedError("error")
    assert isinstance(err, Exception)
    assert str(err) == "error"



# Generated at 2022-06-24 11:46:24.299148
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-24 11:46:28.709391
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # BoxSize is 0~2^32 - 1, Type is 4 bytes
    assert FlvReader(b'\00\00\00\00aaaa').read_box_info() == (4, b'aaaa', b'')
    # BoxSize is 1, Type is 4 bytes
    assert FlvReader(b'\00\00\00\01' + b'\00' * 8 + b'aaaa').read_box_info() == (9, b'aaaa', b'')



# Generated at 2022-06-24 11:46:37.709877
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    data = (b"\x06string\x00\x05\x00\x00\x00"
            b"Hello\x00World\x00\x06string\x00\x05\x00\x00\x00"
            b"Hello")
    reader = FlvReader(data)
    assert reader.read_string() == b"string"
    assert reader.read_string() == b"Hello"
    assert reader.read_string() == b"World"
    # Test the case when end of box is met
    assert reader.read_string() == b"Hello"
    assert reader.read_string() == b""



# Generated at 2022-06-24 11:46:44.157553
# Unit test for function write_flv_header
def test_write_flv_header():
    import unittest
    class WriteFlvHeaderTest(unittest.TestCase):
        def testWriteFlvHeader(self):
            output = io.BytesIO()
            write_flv_header(output)
            self.assertTrue(output.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00')
    # Run the unit test
    unittest.main(argv=['first-arg-is-ignored'], exit=False)


# Generated at 2022-06-24 11:46:51.165559
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    data = b'\x12\x34\x56\x78\x00\xAB\xCD\xEF\x01\x00\x00\x00'
    offset = 0
    assert FlvReader(data).read_string() == b'\x12\x34\x56\x78'
    offset += 5
    assert FlvReader(data[offset:]).read_string() == b''



# Generated at 2022-06-24 11:47:00.758340
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:47:03.631819
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    from .test import read_test_data
    bootstrap_bytes = read_test_data('bootstrap_info.dat')
    print(read_bootstrap_info(bootstrap_bytes))



# Generated at 2022-06-24 11:47:15.564971
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
  flv = b'\x12\x00\x00\x00' \
        b'abst' \
        b'\x00\x00\x00\x00'
  fp = FlvReader(flv)
  assert fp.read_box_info() == (18, b'abst', b'')

  flv = b'\x00\x00\x00\x12' \
        b'abst' \
        b'\x00\x00\x00\x00'
  fp = FlvReader(flv)
  assert fp.read_box_info() == (18, b'abst', b'')


# Generated at 2022-06-24 11:47:23.317691
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    from io import BytesIO
    metadata = b'<?xml version="1.0"?>\n<show><a>hello world</a></show>'
    stream = BytesIO()
    write_metadata_tag(stream, metadata)
    assert stream.getvalue() == b'\x12\x00\x00\xA6\x00\x00\x00\x00\x00\x00\x00<?xml version="1.0"?>\n<show><a>hello world</a></show>\x00\x00\x00\xAC'



# Generated at 2022-06-24 11:47:26.975311
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    flv = FlvReader(open(os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'amf0_bootstrap.bin'), 'rb').read())
    res = flv.read_bootstrap_info()
    #print res



# Generated at 2022-06-24 11:47:35.148359
# Unit test for function build_fragments_list
def test_build_fragments_list():
    assert build_fragments_list({
        'live': False,
        'segments': [{
            'segment_run': [(1, 1), (2, 2)],
        }],
        'fragments': [{
            'fragments': [{
                'first': 1,
                'ts': 0,
                'duration': 0,
            }],
        }],
    }) == [(1, 1), (2, 2), (2, 3)]



# Generated at 2022-06-24 11:47:39.091019
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    write_unsigned_int(stream, 5)
    write_unsigned_int(stream, 100)
    stream.seek(0)
    assert stream.read() == b'\x00\x00\x00\x05\x00\x00\x00d'



# Generated at 2022-06-24 11:47:45.939783
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    with open('test.f4m', 'rb') as f:
        data = f.read()
    reader = FlvReader(data)
    assert reader.read_bootstrap_info() == {
        'fragments': [],
        'segments': [{'segment_run': [(0, 4)]}],
        'live': False
    }


# Parser for AdobeHDS manifests

# Generated at 2022-06-24 11:47:49.617764
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    f = FlvReader()
    f.write(compat_struct_pack('!I', 987654321))
    f.seek(0)
    assert f.read_unsigned_int() == 987654321



# Generated at 2022-06-24 11:47:59.569776
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    assert FlvReader(b'\x00\x00\x00\x00').read_box_info() == (0, b'\x00\x00\x00\x00', b'')
    assert FlvReader(b'\x00\x00\x00\x04abcd').read_box_info() == (4, b'abcd', b'')
    assert FlvReader(b'\x00\x00\x00\x01\x00\x00\x0f\xf0\x00\x00\x00\x04abcd').read_box_info() == (4096, b'\x00\x00\x00\x04', b'abcd')


# Generated at 2022-06-24 11:48:05.177615
# Unit test for function write_flv_header
def test_write_flv_header():
    import zlib
    from hashlib import md5
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == zlib.decompress(
        b'x\x9c\x04\x00\x00\x00\x00\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'
    )
    assert md5(stream.getvalue()).hexdigest() == '14541c30b6e3dc6f3b3d594806dfdf97'



# Generated at 2022-06-24 11:48:17.386796
# Unit test for constructor of class F4mFD
def test_F4mFD():
    ydl = YoutubeDL({})

    # Test for regular manifest
    f4m_fd = F4mFD(ydl, {'url': 'http://fake-manifest.f4m'})
    assert f4m_fd.manifest_url == 'http://fake-manifest.f4m'
    assert f4m_fd.fragment_base_url is None

    # Test for encrypted manifest with relative fragment base URL
    ydl = YoutubeDRMWorkaroundInvoker({}, {'f4m_id': 'dummy_id'})
    f4m_fd = F4mFD(ydl, {'url': 'http://fake-manifest.f4m'})

# Generated at 2022-06-24 11:48:19.384773
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    flv_reader = FlvReader(b'\x00\x00\x00\x01\x00\x00\x00\x01')
    assert flv_reader.read_unsigned_long_long() == 1



# Generated at 2022-06-24 11:48:22.728292
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    fd = F4mFD()
    fd.params['test'] = True
    res = fd.real_download('filename', {'url': 'http://test.com/manifest.f4m'})
    assert res


# Generated at 2022-06-24 11:48:29.741004
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:48:31.665623
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    for i in range(0x7fffffffffffffff):
        s = compat_struct_pack('!Q', i)
        flv = FlvReader(s)
        assert flv.read_unsigned_long_long() == i

# Generated at 2022-06-24 11:48:41.286056
# Unit test for constructor of class FlvReader
def test_FlvReader():
    test_string = (
        b'\x00\x00\x00\x15' + b'adbs' +  # size=21, type=adbs
        b'\x00' +  # version=0
        b'\x00\x00\x00' +  # flags=0
        b'\x00\x00\x00\x01' +  # BootstrapinfoVersion=1
        # Profile,Live,Update,Reserved
        b'\x08' +
        b'\x00\x00\x04\x00'  # timescale=1024
    )

    class TestCase(object):
        def __init__(self, *args):
            self.assertEqual = self.assertEqual_real


# Generated at 2022-06-24 11:48:52.735208
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring('<manifest/>')
    assert get_base_url(manifest) is None
    manifest = compat_etree_fromstring('<manifest xmlns="http://ns.adobe.com/f4m/2.0" baseURL="http://example.com/base_url_2/"/>')
    assert get_base_url(manifest) == 'http://example.com/base_url_2/'
    manifest = compat_etree_fromstring('<manifest xmlns="http://ns.adobe.com/f4m/1.0" baseURL="http://example.com/base_url_1/"/>')
    assert get_base_url(manifest) == 'http://example.com/base_url_1/'

# Generated at 2022-06-24 11:49:03.470454
# Unit test for function remove_encrypted_media

# Generated at 2022-06-24 11:49:15.844848
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    data = (
        b'\x07\x00\x00\x00'
        b'\x00\x00\x00\x00'
        b'\x6e\x6f\x6e\x65'
    )
    assert FlvReader(data).read_box_info() == (
        7, b'\x00\x00\x00\x00', b'none')

    data = (
        b'\x01\x00\x00\x00'
        b'test'
        b'\x01\x02\x03\x04'
    )
    assert FlvReader(data).read_box_info() == (
        1, b'test', b'\x01\x02\x03\x04')


# Generated at 2022-06-24 11:49:27.461682
# Unit test for constructor of class FlvReader

# Generated at 2022-06-24 11:49:37.525816
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00<\x61\x73\x72\x74\x00\x00\x00\x00\x00\x00\x00\x01'
        b'\x00\x00\x00\x02\x00\x00\x00\x04\x00\x00\x00\x04\x00\x00\x00\x08'
    )
    reader = FlvReader(data)
    ast_info = reader.read_asrt()
    assert ast_info == {
        'segment_run': [(1, 2), (4, 4)],
    }

#Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:49:43.240438
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    """
    test method read_unsigned_int of class FlvReader
    """
    test_input = b'\x00\x00\x00\x01'
    test_output = 1
    for blen in range(4, 8):
        test_input += b'\x00'*(blen-4)
        res = FlvReader(test_input).read_unsigned_int()
        assert test_output == res
        test_output = int(test_output*0x100)



# Generated at 2022-06-24 11:49:49.919911
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-24 11:49:50.898352
# Unit test for constructor of class F4mFD
def test_F4mFD():
    from ..utils import FakeYDL
    f4m_downloader = F4mFD(FakeYDL(), {})

# Generated at 2022-06-24 11:49:55.541005
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    reader = FlvReader(compat_struct_pack('!Q', 0x0102030405060708))
    assert reader.read_unsigned_long_long() == 0x0102030405060708
test_FlvReader_read_unsigned_long_long()

# Generated at 2022-06-24 11:50:00.137216
# Unit test for constructor of class F4mFD
def test_F4mFD():
    def test(name, data, args={}):
        filename = os.path.join(os.path.dirname(__file__), 'f4m', name)
        filename += '.manifest'
        with open(filename, 'rb') as f:
            manifest = f.read().decode('utf-8')
        params = {
            'format': 'best',
            'test': True,
        }
        params.update(args)
        fd = F4mFD(params)
        fd.real_download('test.flv', {'url': 'test', 'f4m_manifest_url': 'test'})
        return fd.ydl.downloaded_info_dicts[0]


# Generated at 2022-06-24 11:50:11.827250
# Unit test for function remove_encrypted_media

# Generated at 2022-06-24 11:50:20.955613
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x00')
    assert reader.read_unsigned_long_long() == 0
    reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x01')
    assert reader.read_unsigned_long_long() == 1
    reader = FlvReader(b'\x00\x00\x00\x00\xff\xff\xff\xff')
    assert reader.read_unsigned_long_long() == 4294967295



# Generated at 2022-06-24 11:50:31.466791
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    cases = [
        (b'\x06\x00\x00\x00abcd\x00efgh\x00\x00\x00', [b'abcd', b'efgh']),
        (b'\x07\x00\x00\x00abcde\x00fghij\x00\x00\x00', [b'abcde', b'fghij']),
    ]
    for input, expect_output in cases:
        fr = FlvReader(input)
        for expect_output_item in expect_output:
            assert expect_output_item == fr.read_string()



# Generated at 2022-06-24 11:50:36.561610
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    file = io.BytesIO(b'\x00\x01\x02\x03')
    reader = FlvReader(file)
    assert reader.read_unsigned_char() == 0
    assert reader.read_unsigned_char() == 1
    assert reader.read_unsigned_char() == 2
    assert reader.read_unsigned_char() == 3



# Generated at 2022-06-24 11:50:49.199170
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    stream = io.BytesIO()
    metadata = b'\x00\x09onMetaData'
    metadata += b'\x08\x02\x01\x01'
    metadata += b'\x00\x00\x00\x00'
    metadata += b'\x00\x00\x00\x00'
    metadata += b'\x00\x00\x00\x00'
    metadata += b'\x00\x00\x00\x00'
    metadata += b'\x00\x00\x00\x00'
    metadata += b'\x00\x00\x00\x00'
    metadata += b'\x00\x00\x00\x00'
    metadata += b'\x00\x00\x00\x00'

    write_

# Generated at 2022-06-24 11:50:50.383959
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    exc = DataTruncatedError('error message')
    assert exc.args[0] == 'error message'


# Generated at 2022-06-24 11:51:01.996639
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Create a instance of F4mFD and call to 'real_download' method.
    from youtube_dl.compat import compat_urlretrieve
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.FileDownloader import FileDownloader
    from io import BytesIO


# Generated at 2022-06-24 11:51:07.139170
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from .test import _TEST_DATA_DIR
    dump_path = _TEST_DATA_DIR + '/trailer_400kbps.flv'
    with open(dump_path, 'rb') as f:
        flv = f.read()

    metadata = FlvReader(flv).read_bootstrap_info()
    assert len(metadata['segments']) > 0
    assert len(metadata['fragments']) > 0



# Generated at 2022-06-24 11:51:17.225946
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-24 11:51:24.726002
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'segments': [
            {
                'duration': 4294967295,
                'segment_run': [
                    (1, 1),
                    (2, 2),
                ],
            },
        ],
        'fragments': [
            {
                'duration': 4294967295,
                'fragments': [
                    {
                        'duration': 10,
                        'first': 1,
                        'ts': 0,
                    },
                ],
            },
        ],
    }
    assert build_fragments_list(boot_info) == [(1, 1), (2, 2), (2, 3)]



# Generated at 2022-06-24 11:51:34.804997
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:51:44.262026
# Unit test for function read_bootstrap_info

# Generated at 2022-06-24 11:51:52.736773
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        """
        <manifest xmlns="http://ns.adobe.com/f4m/2.0">
            <baseURL>another_url</baseURL>
        </manifest>
        """)
    assert get_base_url(manifest) == 'another_url'

    manifest = compat_etree_fromstring(
        """
        <manifest xmlns="http://ns.adobe.com/f4m/2.0">
            <baseURL></baseURL>
        </manifest>
        """)
    assert get_base_url(manifest) == ''


# Generated at 2022-06-24 11:51:54.425325
# Unit test for function get_base_url
def test_get_base_url():
    manifest = """<manifest>
        <baseURL>abcd</baseURL>
    </manifest>"""
    assert get_base_url(manifest) == 'abcd'



# Generated at 2022-06-24 11:51:56.885917
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    reader = FlvReader(compat_struct_pack(b'!B', 0x04))
    assert reader.read_unsigned_char() == 0x04


# Generated at 2022-06-24 11:52:05.827896
# Unit test for function build_fragments_list
def test_build_fragments_list():
    # live stream
    assert build_fragments_list({
        'segments': [{
            'segment_run': [(1, 2)],
        }],
        'fragments': [{
            'fragments': [{
                'first': 1,
                'ts': 0,
                'duration': 0,
                'discontinuity_indicator': None
            }],
        }],
        'live': True,
    }) == [(1, 1), (1, 2)]

    # on demand stream

# Generated at 2022-06-24 11:52:08.111735
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    reader = FlvReader(b'\x00\x00\x00\x06')
    assert reader.read_unsigned_int() == 6



# Generated at 2022-06-24 11:52:18.547470
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    from ..compat import compat_etree_element
    from ..utils import xpath_with_ns
    from xml.etree import cElementTree

    class Mock:
        def __init__(self, attrib):
            self.attrib = attrib
