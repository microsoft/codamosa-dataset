

# Generated at 2022-06-24 11:42:17.344206
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError
    except DataTruncatedError:
        pass
# End of unit test for class DataTruncatedError



# Generated at 2022-06-24 11:42:21.165836
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\t\x00\x00\x00\x00'



# Generated at 2022-06-24 11:42:30.508012
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    """Unit test for method read_bootstrap_info of class FlvReader
    """
    # Tested with real data and Python 2.7.6

# Generated at 2022-06-24 11:42:39.191324
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    from xml.etree.ElementTree import fromstring
    xml = """
    <media baseURL="https://bitdash-a.akamaihd.net/content/sintel/hls/">
        <drmAdditionalHeaderId>1</drmAdditionalHeaderId>
        <drmAdditionalHeaderSetId>5</drmAdditionalHeaderSetId>
        <media baseURL="https://bitdash-a.akamaihd.net/content/sintel/hls/">
        </media>
        <media baseURL="https://bitdash-a.akamaihd.net/content/sintel/hls/">
        </media>
    </media>
    """

    elem = fromstring(xml)
    media = remove_encrypted_media(elem.findall('media'))

    assert len(media) == 2


# Generated at 2022-06-24 11:42:43.391764
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    reader = FlvReader(b'\x00\x00\x00\x03')
    assert reader.read_unsigned_int() == 3
    # Test reading unsigned int with more bytes than needed
    reader = FlvReader(b'\x00\x00\x00\x03\x01')
    assert reader.read_unsigned_int() == 3



# Generated at 2022-06-24 11:42:48.583453
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    assert FlvReader(b'\x00').read_string() == b''
    assert FlvReader(b'\x00\x00').read_string() == b''
    assert FlvReader(b'aaa\x00').read_string() == b'aaa'
    assert FlvReader(b'aaa\x00\x00').read_string() == b'aaa'



# Generated at 2022-06-24 11:42:55.134789
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    from ..utils import make_tempdir_context
    with make_tempdir_context() as tmp_dir:
        tmp_file = os.path.join(tmp_dir, 'temp_file')
        with open(tmp_file, 'wb') as f:
            write_unsigned_int(f, 6)
        with open(tmp_file, 'rb') as f:
            assert f.read() == compat_struct_pack('!I', 6)



# Generated at 2022-06-24 11:43:03.660025
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    with open('test/test_data/test_bootstrap_info.txt') as f:
        bootstrap_bytes = compat_b64decode(f.read())
    bootstrap_info = read_bootstrap_info(bootstrap_bytes)
    assert len(bootstrap_info['segments']) == 2
    assert len(bootstrap_info['fragments']) == 2
    assert bootstrap_info['live'] is False



# Generated at 2022-06-24 11:43:14.514669
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from .fragment import (
        unpack_fragment_base_urls_and_initialization,
        parse_fragment_base_urls_and_initialization,
    )
    from ..parser import get_element_by_id
    from ..compat import (
        compat_urllib_request,
    )


# Generated at 2022-06-24 11:43:23.957082
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    reader = FlvReader(b'\x00')
    assert reader.read_unsigned_char() == 0

    reader = FlvReader(b'\x01')
    assert reader.read_unsigned_char() == 1

    reader = FlvReader(b'\xff')
    assert reader.read_unsigned_char() == 255

    # Test for exception DataTruncatedError in method read_unsigned_char
    reader = FlvReader(b'')
    try:
        reader.read_unsigned_char()
        assert False
    except DataTruncatedError:
        pass



# Generated at 2022-06-24 11:43:27.233044
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import subprocess
    args = ["python", "youtube_dl/downloader/f4m.py", "tests/test.f4m"]
    p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = p.communicate()
    print(out)

# test unit for above method
import sys
test_F4mFD_real_download()

# Generated at 2022-06-24 11:43:31.713894
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    def _test(data, expected_segment_run):
        reader = FlvReader(data)
        segment_run = reader.read_asrt()['segment_run']
        assert segment_run == expected_segment_run

# Generated at 2022-06-24 11:43:40.623467
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:43:50.045670
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    res = FlvReader(
        compat_b64decode(
            b'AAABAAABSgAAAAEAZABpAHIAZQBjAHQAIABSAGUAcwBlAHIAdgBlAHIAAAAAAAIAAA'
            b'AAAAAAIAAABABQAZwBGAGUAcgBtAAMAdGVzdAAAAAQAAAAEAAAABAAAAAAAAAAAAAA'
            b'AAAAAAAAAAA=')).read_asrt()

# Generated at 2022-06-24 11:43:58.247050
# Unit test for function write_flv_header
def test_write_flv_header():
    from io import BytesIO
    stream = BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\t\x00\x00\x00\x00'



# Generated at 2022-06-24 11:44:11.291265
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-24 11:44:18.306588
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    if __name__ == '__main__':
        abst = FlvReader(open('abst.dump', 'rb').read()).read_asrt()

# Generated at 2022-06-24 11:44:23.128638
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    reader = FlvReader(b'\x06abc\x00\x03xyz\x00')
    assert reader.read_string() == b'abc'
    assert reader.read_string() == b'xyz'

# Generated at 2022-06-24 11:44:33.365735
# Unit test for function get_base_url
def test_get_base_url():
    manifest = b'''<?xml version="1.0" encoding="UTF-8"?>
    <manifest
        xmlns="http://ns.adobe.com/f4m/1.0">
        <baseURL>http://example.com/</baseURL>
        <media baseURL="http://example.com/test">
            <metadata>
                <ttl>30</ttl>
            </metadata>
            <bootstrapInfo profile="named" id="bootstrap1"
                url="http://example.com/bootstrap.abst" />
        </media>
    </manifest>
    '''
    base_url = get_base_url(fix_xml_ampersands(manifest))
    assert base_url == 'http://example.com/'


# Generated at 2022-06-24 11:44:43.349786
# Unit test for constructor of class FlvReader

# Generated at 2022-06-24 11:44:46.474663
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    reader = FlvReader(b'\x00\x00\x00\x04test')
    assert reader.read_unsigned_int() == 4



# Generated at 2022-06-24 11:44:54.624474
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    from io import BytesIO
    from .compat import compat_struct_unpack

    stream = BytesIO()
    for i in [0, 1, 10, 1000, 1000000, 1000000000, 4294967295]:
        write_unsigned_int(stream, i)
    assert stream.getvalue() == b''.join(
        compat_struct_pack('!I', i) for i
        in [0, 1, 10, 1000, 1000000, 1000000000, 4294967295])

# Generated at 2022-06-24 11:44:56.860493
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    f = FlvReader(compat_struct_pack('!Q', 0x0102030405060708))
    assert f.read_unsigned_long_long() == 0x0102030405060708


# Generated at 2022-06-24 11:45:01.536887
# Unit test for constructor of class F4mFD
def test_F4mFD():
    """
    Simple unit tests for the F4mFD
    """
    from youtube_dl.utils import *
    import os.path
    import tempfile
    import zipfile

    fd = F4mFD()

    # Test download of a normal video
    url = 'http://video.ted.com/talks/podcast/AlGore_2006-480p.mp4.f4v?apikey=022b9e45-f1e5-4e89-9cf9-52bf8edd5158'

# Generated at 2022-06-24 11:45:10.786433
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import encode_data_uri


# Generated at 2022-06-24 11:45:22.869775
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    import zlib

# Generated at 2022-06-24 11:45:34.878911
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:45:41.215197
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    """Test read_box_info method of FlvReader class"""
    box_type = b"test"
    data = b'\x00\x00\x00\x00' + b'\x00'*10 + b'\x00\x00\x00\x10' + box_type + b'\x00'*14
    flv_reader = FlvReader(data)
    size, box_type_read, box_data = flv_reader.read_box_info()
    assert box_type == box_type_read
    assert size == 16
    assert box_data == b'\x00'*10

# Generated at 2022-06-24 11:45:50.342835
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    test_data = b'\x00\x00\x00\x1b\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x03\x00\x00\x00\x00\x00\x07\x00\x00\x00\x01'
    f = FlvReader(test_data)
    assert f.read_afrt() == {
        'fragments': [{
            'first': 1,
            'ts': 12,
            'duration': 3,
            'discontinuity_indicator': None,
        }],
    }



# Generated at 2022-06-24 11:46:00.962096
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = b'''
        \x00\x00\x00\x50
        asrt
        \x00\x05\x00\x00\x00\x00\x00\x00
        \x00\x01
        \x05
        \x00\x00\x00\x02
        \x00\x00\x00\x00\x01\x00\x00\x00
        \x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x03\x00\x00\x00
    '''.replace(b' ', b'')
    res = FlvReader(data).read_asrt()

# Generated at 2022-06-24 11:46:08.601043
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    data = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    test = FlvReader(data)
    assert test.read_unsigned_long_long() == 0
    test = FlvReader(data)
    assert test.read_unsigned_long_long() == 0
    assert test.read_unsigned_int() == 0
    assert test.read_unsigned_char() == 0
    test = FlvReader(data)
    assert test.read_unsigned_int() == 16
    assert test.read_unsigned_long_long() == 0
    assert test.read_unsigned_int() == 0
    assert test.read_unsigned_char() == 0
    test = Fl

# Generated at 2022-06-24 11:46:13.804398
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-24 11:46:26.099333
# Unit test for method read_unsigned_int of class FlvReader

# Generated at 2022-06-24 11:46:31.115129
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    reader = FlvReader(b'\x01\x02\x03\x04\x05\x06\x07\x08')
    for i in range(4):
        assert reader.read_unsigned_int() == 0x01020304
        assert reader.read_unsigned_long_long() == 0x0807060504030201

# Generated at 2022-06-24 11:46:42.818513
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-24 11:46:54.631057
# Unit test for function read_bootstrap_info

# Generated at 2022-06-24 11:47:02.498301
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    from .test_fragment import FragmentTester


# Generated at 2022-06-24 11:47:07.277752
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    # Test if the method read_unsigned_int correctly read the 4 bytes
    # from given buffer.
    reader = FlvReader(b'\x00\x00\x00\xc8')
    assert(reader.read_unsigned_int() == 200)

# Generated at 2022-06-24 11:47:09.835181
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
        try:
            raise DataTruncatedError()
        except DataTruncatedError as e:
            assert str(e)




# Generated at 2022-06-24 11:47:20.664802
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    """
    Test the method read_unsigned_long_long of class FlvReader
    """
    FLV_TEST_FILE = 'test.flv'

# Generated at 2022-06-24 11:47:29.143493
# Unit test for constructor of class FlvReader

# Generated at 2022-06-24 11:47:35.346254
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    from ..compat import compat_chr
    expected = {
        'segment_run': [
            (1, 4),
            (5, 4),
            (9, 4),
            (13, 4),
            (17, 4),
            (21, 4),
            (25, 4),
            (29, 4),
            (33, 4),
            (37, 4)
        ]
    }

# Generated at 2022-06-24 11:47:47.356802
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    sample_input = '''
<media url="http://flv.123.com/2013/03/22/1093x576x30x9x123.flv?expires=1364131588&token=abc123&id=123"
       bootstrapInfoId="bootstrap005"
       drmAdditionalHeaderId="drm001"
       drmAdditionalHeaderSetId="drm001_set001" />
<media url="http://flv.123.com/2013/03/22/1920x1080x30x9x123.flv?expires=1364131588&token=abc123&id=123"
       bootstrapInfoId="bootstrap005" />
'''

# Generated at 2022-06-24 11:47:56.914226
# Unit test for constructor of class FlvReader

# Generated at 2022-06-24 11:48:03.442071
# Unit test for constructor of class F4mFD
def test_F4mFD():
    f4m_fd = F4mFD(ydl)
    assert f4m_fd.params['url'].endswith('manifest.f4m')
    assert 'video' in f4m_fd.params['format'].lower()
    assert f4m_fd.fd_name() == 'f4m'
    assert f4m_fd.info_dict() == (
        {u'url': u'https://example.com/manifest.f4m',
         u'ext': u'mp4', u'format_id': u'f4m-flv-1M-video'})



# Generated at 2022-06-24 11:48:14.784354
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from .common import DataTruncatedError
    from .f4m import read_flv_header

# Generated at 2022-06-24 11:48:20.384927
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    """
    Unit test for method read_unsigned_long_long of class FlvReader
    """
    f = FlvReader(compat_struct_pack('!Q', 123456789))
    assert f.read_unsigned_long_long() == 123456789


# Generated at 2022-06-24 11:48:25.392031
# Unit test for function get_base_url
def test_get_base_url():
    import xml.etree.ElementTree as ET
    manifest = ET.fromstring('''
        <manifest xmlns="http://ns.adobe.com/f4m/2.0">
            <baseURL>
                http://example.com
            </baseURL>
        </manifest>
    ''')
    assert get_base_url(manifest) == 'http://example.com'



# Generated at 2022-06-24 11:48:31.720245
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    flvreader = FlvReader(b"\x00\x00\x00\x0f" + b"\x00\x00\x00\x04" + b"\x00\x00\x00\x03")
    assert flvreader.read_unsigned_int() == 15
    assert flvreader.read_unsigned_int() == 4
    assert flvreader.read_unsigned_int() == 3


# Generated at 2022-06-24 11:48:37.548923
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    metadata = b"abcdefg"
    stream = io.BytesIO()
    write_metadata_tag(stream, metadata)
    expected_result = b"\x12\x00\x00\x00\x07\x00\x00\x00\x00\x00\x00\x00abcdefg\x00\x00\x00\x19"
    assert stream.getvalue() == expected_result


# Generated at 2022-06-24 11:48:43.963237
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    """
    Unit test for method read_bytes of class FlvReader
    """
    flv_reader = FlvReader(b'1234567890')
    try:
        assert(flv_reader.read_bytes(5)==b'12345')
        assert(flv_reader.read_bytes(10) == b'67890')
    except DataTruncatedError:
        print("FlvReader unit test: Success")


# Generated at 2022-06-24 11:48:53.329773
# Unit test for constructor of class FlvReader

# Generated at 2022-06-24 11:49:05.085378
# Unit test for constructor of class FlvReader
def test_FlvReader():
    # Copyed from https://gist.github.com/briandryden/2351370
    flv_data = b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'
    reader = FlvReader(flv_data)
    assert reader.read_unsigned_char() == 0x01
    assert reader.read_unsigned_char() == 0x05
    assert reader.read_unsigned_int() == 0
    assert reader.read_unsigned_int() == 9
    assert reader.read_unsigned_long_long() == 0
    # test on_progress_hook
    data = b'0123456789'
    assert FlvReader(data, on_progress=lambda x: x).read() == data

# Generated at 2022-06-24 11:49:17.352182
# Unit test for function build_fragments_list
def test_build_fragments_list():
    import os
    test_datas = {
        'rtmpdump-asrt': 'rtmpdump-asrt.ts',
        'osmf-asrt': 'osmf-asrt.ts',
        'osmf-asrt2': 'osmf-asrt2.ts',
        'osmf-asrt3': 'osmf-asrt3.ts',
        'rtmpdump-asrt-live': 'rtmpdump-asrt-live.ts',
        'osmf-asrt-live': 'osmf-asrt-live.ts',
        'osmf-asrt-live2': 'osmf-asrt-live2.ts',
    }

# Generated at 2022-06-24 11:49:28.431824
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:49:32.270273
# Unit test for function write_flv_header
def test_write_flv_header():
    out = io.BytesIO()
    write_flv_header(out)
    assert out.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-24 11:49:36.488385
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    stream = io.BytesIO()
    write_unsigned_int_24(stream, 420)
    stream.seek(0)
    assert stream.read() == b'\x00\x00\x01\xac'
test_write_unsigned_int_24()



# Generated at 2022-06-24 11:49:42.510898
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-24 11:49:46.183179
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    reader = FlvReader(b'\x00\x01\x02\x03')
    assert reader.read_bytes(4) == b'\x00\x01\x02\x03'
    try:
        reader.read_bytes(1)
        assert False
    except DataTruncatedError:
        assert True



# Generated at 2022-06-24 11:49:48.814486
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError
    except DataTruncatedError:
        pass


# Generated at 2022-06-24 11:50:00.656915
# Unit test for function read_bootstrap_info

# Generated at 2022-06-24 11:50:12.124311
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    test_data = (
        (0x112233, b'\x33\x22\x11'),
        (0x000000, b'\x00\x00\x00'),
        (0x123456, b'\x56\x34\x12'),
        (0x1234567, b'\x67\x45\x23'),
    )
    for val, expected in test_data:
        fd = io.BytesIO()
        write_unsigned_int_24(fd, val)
        assert fd.getvalue() == expected


# Generated at 2022-06-24 11:50:19.393678
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    test_cases = [
        (0, b'\x00\x00\x00\x00'),
        (1, b'\x00\x00\x00\x01'),
        (2**31 - 1, b'\xff\xff\xff\x7f'),
        (2**31, b'\x00\x00\x80\x80'),
        (2**32 - 1, b'\xff\xff\xff\xff'),
    ]

    for val, expected in test_cases:
        stream = io.BytesIO()
        write_unsigned_int(stream, val)
        assert(stream.getvalue() == expected)



# Generated at 2022-06-24 11:50:28.063987
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    write_unsigned_int(stream, 0)
    assert stream.getvalue() == b'\x00\x00\x00\x00'
    stream = io.BytesIO()
    write_unsigned_int(stream, 1)
    assert stream.getvalue() == b'\x00\x00\x00\x01'
    stream = io.BytesIO()
    write_unsigned_int(stream, 0xffffffff)
    assert stream.getvalue() == b'\xff\xff\xff\xff'



# Generated at 2022-06-24 11:50:38.475328
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    def box_generator(box_type, box_data):
        data = compat_struct_pack('!I', 1)
        data += box_type
        data += compat_struct_pack('!Q', 1+len(box_data))
        data += box_data
        return data

    def abst_generator(box_data):
        return box_generator(b'abst', box_data)

    def asrt_generator(box_data):
        return box_generator(b'asrt', box_data)

    def afrt_generator(box_data):
        return box_generator(b'afrt', box_data)

    abst_data = b''
    abst_data += compat_struct_pack('!B', 0)   # version

# Generated at 2022-06-24 11:50:44.633691
# Unit test for function build_fragments_list
def test_build_fragments_list():
    from .test_fragment import TEST_BOOTSTRAP_INFO
    boot_info = read_bootstrap_info(TEST_BOOTSTRAP_INFO)
    res = build_fragments_list(boot_info)
    assert res == [(0, 0), (0, 1), (0, 2), (0, 3), (0, 4), (0, 5)]



# Generated at 2022-06-24 11:50:53.880004
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:51:05.524304
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    def compare_box(file_name, box_type, expected_box_info):
        with open(file_name, 'rb') as f:
            file_data = f.read()
            flvReader = FlvReader(file_data)
            actual_box_info = flvReader.read_box_info()
            assert actual_box_info[1] == box_type
            assert actual_box_info[0] == expected_box_info[0]
            assert actual_box_info[2] == expected_box_info[2]

    # test for box size < 0xFFFFFFFF

# Generated at 2022-06-24 11:51:09.267007
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    stream = io.BytesIO()
    write_unsigned_int_24(stream, 0x01020304)
    assert stream.getvalue() == b'\x01\x02\x03'
test_write_unsigned_int_24()



# Generated at 2022-06-24 11:51:18.827713
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-24 11:51:20.682699
# Unit test for function write_flv_header
def test_write_flv_header():
    assert io.BytesIO(write_flv_header()).getvalue().encode('hex') == '464c5601050000000900000000'



# Generated at 2022-06-24 11:51:25.102109
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    s = b'\x90\xF0\x0F\x00'
    io_obj = FlvReader(s)
    assert io_obj.read_unsigned_char() == 144
    assert io_obj.read_unsigned_char() == 240
    assert io_obj.read_unsigned_char() == 15
    assert io_obj.read_unsigned_char() == 0


# Generated at 2022-06-24 11:51:31.863084
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    sample_size = 1 << 17
    with open('tests/data/sample.abst', 'rb') as sample:
        fd = FlvReader(sample.read(sample_size))
        afrt = fd.read_afrt()
    with open('tests/data/sample.afrt', 'rb') as sample:
        fd = FlvReader(sample.read(sample_size))
        assert afrt == fd.read_afrt()



# Generated at 2022-06-24 11:51:41.694572
# Unit test for constructor of class FlvReader

# Generated at 2022-06-24 11:51:48.750256
# Unit test for constructor of class FlvReader

# Generated at 2022-06-24 11:51:52.754343
# Unit test for function write_flv_header
def test_write_flv_header():
    fileobj = io.BytesIO()
    write_flv_header(fileobj)
    assert fileobj.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-24 11:51:56.740925
# Unit test for function get_base_url
def test_get_base_url():
    assert get_base_url(compat_etree_fromstring(FIXTURE_ADOBE_DASH_MANIFEST)) == 'https://adobe-sample-fms.akamaized.net/vod/mp4:mediademo/manifest.f4m'
    assert get_base_url(compat_etree_fromstring(FIXTURE_ADOBE_HDS_MANIFEST)) == 'https://adobe-sample-fms.akamaized.net/vod/mp4:mediademo/manifest.f4m'
    assert get_base_url(compat_etree_fromstring(FIXTURE_ADOBE_DASH_MANIFEST_NO_BASE_URL)) is None

# Generated at 2022-06-24 11:52:05.739292
# Unit test for method read_unsigned_long_long of class FlvReader

# Generated at 2022-06-24 11:52:08.807258
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    "Unit test for constructor of class DataTruncatedError"
    try:
        raise DataTruncatedError
    except DataTruncatedError:
        print('In DataTruncatedError')


# Generated at 2022-06-24 11:52:11.919330
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError
    except DataTruncatedError:
        pass
    try:
        raise DataTruncatedError('Error Message')
    except DataTruncatedError:
        pass


# Generated at 2022-06-24 11:52:16.401320
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    reader = FlvReader(b'\x00\x00\x00\x03abc')
    assert reader.read_unsigned_int() == 3
    assert reader.read_bytes(3) == b'abc'
    assert reader.tell() == 7
test_FlvReader_read_unsigned_int()

