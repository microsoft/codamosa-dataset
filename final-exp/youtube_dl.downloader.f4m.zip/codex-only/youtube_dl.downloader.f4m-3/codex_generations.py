

# Generated at 2022-06-24 11:42:26.571247
# Unit test for function get_base_url
def test_get_base_url():
    def base_url_test(test_url, expected_url):
        manifest = compat_etree_fromstring(test_url)
        url = get_base_url(manifest)
        assert url == expected_url

    base_url_test('<manifest/>', None)
    base_url_test(
        '<manifest><baseURL>http://test-domain.com</baseURL></manifest>',
        'http://test-domain.com'
    )
    base_url_test(
        '<manifest><baseURL> http://test-domain.com </baseURL></manifest>',
        'http://test-domain.com'
    )
    base_url_test(
        '<manifest><baseURL></baseURL></manifest>', None
    )

# Generated at 2022-06-24 11:42:32.065923
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    flv_reader = FlvReader(b'\x00')
    assert flv_reader.read_unsigned_char() == 0
    flv_reader = FlvReader(b'\xff')
    assert flv_reader.read_unsigned_char() == 255
    flv_reader = FlvReader(b'\x01\x00')
    assert flv_reader.read_unsigned_char() == 1

# Generated at 2022-06-24 11:42:41.079705
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    reader = FlvReader(b'\x00\x00\x00\x1c\x61\x73\x72\x74\x08\x00\x00\x00\x01\x61\x00\x00\x00\x00\x00\x00\x00\x01\x03\x00\x00\x00\x01\x60\x00\x00\x00\x00\x00\x00')
    data = reader.read_asrt()
    assert data == {
        'segment_run': [(1, 3)]
    }

# Generated at 2022-06-24 11:42:52.319536
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = [
        '<media url="http://manifest.auth.adobe.com/some'
        'url1" bitrate="3500" bandwidth="3676"'
        'drmAdditionalHeaderId="someid" '
        'drmAdditionalHeaderSetId="somesetid"/>',
        '<media url="http://manifest.auth.adobe.com/some'
        'url2" bitrate="3500" bandwidth="3676"/>',
        '<media url="http://manifest.auth.adobe.com/some'
        'url3" bitrate="3500" bandwidth="3676" '
        'drmAdditionalHeaderId="someid" '
        'drmAdditionalHeaderSetId="somesetid"/>'
    ]

# Generated at 2022-06-24 11:42:56.410724
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    f = io.BytesIO(b'\x00\x01\x02\x00\x03\x04\x05\x00\x06\x07\x08\x00')
    reader = FlvReader(f)
    assert reader.read_string() == b'\x00\x01\x02'
    assert reader.read_string() == b'\x03\x04\x05'
    assert reader.read_string() == b'\x06\x07\x08'

# Generated at 2022-06-24 11:43:05.308379
# Unit test for constructor of class FlvReader

# Generated at 2022-06-24 11:43:16.256209
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    stream = io.BytesIO()

# Generated at 2022-06-24 11:43:22.978572
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == (
        b'FLV\x01\x05'
        b'\x00\x00\x00\x09'
        b'\x00\x00\x00\x00'
    )
test_write_flv_header()



# Generated at 2022-06-24 11:43:37.161014
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    # pylint: disable=W0212
    from .test import read_test_data
    info = FlvReader(read_test_data('bootstrap_sample.abst')).read_bootstrap_info()
    assert info['segments'] == [{
        'segment_run': [
            (0, 1),
            (1, 1)
        ]
    }]

# Generated at 2022-06-24 11:43:44.173772
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    buf = io.BytesIO()
    buf.write(b'\x12\x0c\x00\x00\x00\x00\x00\x00\x00\x03foo\x00\x00\x00\x00\x00\x00\x00\x00')
    assert buf.getvalue() == write_metadata_tag(io.BytesIO(), b'foo')



# Generated at 2022-06-24 11:43:52.407878
# Unit test for constructor of class FlvReader
def test_FlvReader():
    data = b'\x00\x00\x00\x20\x66\x6d\x74\x68\x00\x00\x00\x00\x01\x00\x00\x00'
    data += b'\x02\x00\x00\x00\x03\x00\x00\x00\x04\x00\x00\x00\x05\x00\x00\x00'
    data += b'\x06\x00\x00\x00\x07\x00\x00\x00'
    data += b'\x00\x00\x00$\x66\x6d\x74\x68\x00\x00\x00\x00\x01\x00\x00\x00'

# Generated at 2022-06-24 11:43:55.262035
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    assert write_unsigned_int(io.BytesIO(), 1) == None
    assert write_unsigned_int(io.BytesIO(), 4294967295) == None
    with pytest.raises(OverflowError):
        write_unsigned_int(io.BytesIO(), 4294967296)

# Generated at 2022-06-24 11:44:03.451083
# Unit test for constructor of class FlvReader
def test_FlvReader():
    flv_reader = FlvReader(b'\x00\x00\x01\xAa')
    assert flv_reader.read_unsigned_int() == 1
    assert flv_reader.read_unsigned_char() == 170
    try:
        flv_reader.read_unsigned_char()
    except DataTruncatedError as e:
        assert str(e) == 'FlvReader error: need 1 bytes while only 0 bytes got'



# Generated at 2022-06-24 11:44:13.174784
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-24 11:44:21.169558
# Unit test for method read_unsigned_long_long of class FlvReader

# Generated at 2022-06-24 11:44:25.322843
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    assert FlvReader(compat_struct_pack('!Q', 0x123456789abcdef0)).read_unsigned_long_long() == 0x123456789abcdef0
test_FlvReader_read_unsigned_long_long()



# Generated at 2022-06-24 11:44:31.913557
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    assert FlvReader(compat_struct_pack('!I', 1)).read_unsigned_int() == 1
    assert FlvReader(compat_struct_pack('!I', 15)).read_unsigned_int() == 15
    assert FlvReader(compat_struct_pack('!I', 400000)).read_unsigned_int() == 400000
    assert FlvReader(compat_struct_pack('!I', 2147483647)).read_unsigned_int() == 2147483647


# Generated at 2022-06-24 11:44:34.539119
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    for i in range(100):
        assert compat_struct_unpack('!I', write_unsigned_int_24(io.BytesIO(), i).getvalue())[0] == i



# Generated at 2022-06-24 11:44:39.993252
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    test_manifest_url = 'http://localhost:8083/test/test.f4m'  # Manually created f4m manifest
    f4m_FD = F4mFD()
    f4m_FD.real_download('test.flv', {'url': test_manifest_url})
    f4m_FD.real_download('test.flv', {'url': test_manifest_url, 'test': True})
if __name__ == '__main__':
    test_F4mFD_real_download()

# Generated at 2022-06-24 11:44:42.965783
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    f = FlvReader(b'\x00\x00\x00\x01')
    assert f.read_bytes(4) == b'\x00\x00\x00\x01'
    try:
        f.read_bytes(1)
        assert False
    except DataTruncatedError:
        pass



# Generated at 2022-06-24 11:44:44.928738
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    reader = FlvReader(b'\x00')
    res = reader.read_unsigned_char()
    assert res==0


# Generated at 2022-06-24 11:44:48.756730
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    reader = FlvReader(b'\x00\x00\x00\x04flv')
    assert reader.read_unsigned_int() == 4



# Generated at 2022-06-24 11:45:00.105920
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    def bin2long(binary):
        return int(binary, 2)

    def long2bin(l):
        binary = bin(l)[2:]
        return str(binary).zfill(32)


# Generated at 2022-06-24 11:45:08.050066
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    flv = FlvReader(b'\x00')
    assert flv.read_unsigned_char() == 0
    flv = FlvReader(b'\x01')
    assert flv.read_unsigned_char() == 1
    flv = FlvReader(b'\x7f')
    assert flv.read_unsigned_char() == 127
    flv = FlvReader(b'\x80')
    assert flv.read_unsigned_char() == 128
    flv = FlvReader(b'\xff')
    assert flv.read_unsigned_char() == 255


# Generated at 2022-06-24 11:45:09.269088
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError()
    except DataTruncatedError:
        pass


# Generated at 2022-06-24 11:45:12.260617
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    init = b'\xde\xad\xbe\xef'
    expected = b'\x00\x00\x00\x00\xde\xad\xbe\xef'
    stream = io.BytesIO()
    stream.write(init)
    write_unsigned_int(stream, 0)
    assert stream.getvalue() == expected



# Generated at 2022-06-24 11:45:21.064369
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    flvreader = FlvReader(
        b'\x00\x00\x00(ftypiso5\x00\x00\x00\x00iso5avc1\x00\x00\x00\x00free')
    assert flvreader.read_box_info() == (40, b'ftyp', b'iso5\x00\x00\x00\x00iso5avc1\x00\x00\x00\x00free')
    assert flvreader.read_box_info() == (0, b'', b'')



# Generated at 2022-06-24 11:45:31.585550
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-24 11:45:38.339488
# Unit test for constructor of class FlvReader
def test_FlvReader():
    f = FlvReader(b'abcd\x00\x00\x00\x10moov\x00\x00\x00\x00\xf0')
    assert f.read_unsigned_char() == 0x61
    assert f.read_unsigned_char() == 0x62
    assert f.read_unsigned_char() == 0x63
    assert f.read_unsigned_char() == 0x64
    assert f.read_string() == b'moov'
    assert f.read_unsigned_long_long() == 0xf0



# Generated at 2022-06-24 11:45:43.478181
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x00\x00\x00\x00\x00'



# Generated at 2022-06-24 11:45:52.588731
# Unit test for function get_base_url
def test_get_base_url():
    assert get_base_url(compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0"></manifest>'
    )) is None
    assert get_base_url(compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>BASE</baseURL>'
        '</manifest>'
    )) == 'BASE'
    assert get_base_url(compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        'BASE'
        '</manifest>'
    )) is None

# Generated at 2022-06-24 11:45:59.455629
# Unit test for constructor of class FlvReader
def test_FlvReader():
    from .smil import SMIL_BASE_URL

    # Read the whole file into the buffer to make it available for FlvReader
    with io.open('test/test.abst.bin', 'rb') as f:
        abst_data = f.read()

    # Create reader and read the bootstrap info
    reader = FlvReader(abst_data)
    bootstrap_info = reader.read_bootstrap_info()

    assert bootstrap_info['live'] is False

    # Check the SegmentRunTableBox:
    # SegmentRunTableBox consists of three SegmentRunEntry:
    assert len(bootstrap_info['segments']) == 3
    # First SegmentRunEntry:
    assert bootstrap_info['segments'][0]['segment_run'] == [(0, 14), (14, 10)]


# Generated at 2022-06-24 11:46:02.349737
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    f = FlvReader(b'\x01\x06\x05\x04\x03\x02\x01\x00')
    assert f.read_unsigned_long_long() == 0x0001020304050601

# Generated at 2022-06-24 11:46:09.680016
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-24 11:46:13.073675
# Unit test for constructor of class F4mFD
def test_F4mFD():
    f4m_obj = F4mFD({
        'url': 'manifest.f4m',
        'fragment_index': 0,
        'fragment_count': 3,
    }, {})
    assert f4m_obj



# Generated at 2022-06-24 11:46:25.556452
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    from xml.etree import ElementTree
    element = ElementTree.fromstring("""
        <media url="test.flv" bootstrapInfoId="test" bitrate="0" width="1280"
               height="720" streamType="recorded"
               duration="251.225" contentType="video/mp4" lookahead="3"
               isLive="true"
               drmAdditionalHeaderSetId="1"
               drmAdditionalHeaderId="1"
               />
        <media url="test2.flv" bootstrapInfoId="test2" bitrate="0" width="1280"
               height="720" streamType="recorded"
               duration="251.225" contentType="video/mp4" lookahead="3"
               isLive="true"
               />
    """)
    media = remove_encrypted_media(element)

# Generated at 2022-06-24 11:46:29.125352
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    flv_reader = FlvReader(b'\x01\x02\x03\x04')
    assert flv_reader.read_bytes(2) == b'\x01\x02'
    # Test DataTruncatedError
    with pytest.raises(DataTruncatedError):
        flv_reader.read_bytes(10)



# Generated at 2022-06-24 11:46:38.182513
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    metadata = b'<?xml version="1.0"?><video test="test" />'
    correct_tag =b'\x12\x00\x00\x3a\x00\x00\x00\x00\x00\x00\x00\x04\x00\x00\x00\x00\x00\x00\x00<?xml version="1.0"?><video test="test" />\x30\x00\x00\x00'
    from io import BytesIO
    stream = BytesIO()
    write_metadata_tag(stream, metadata)
    assert stream.getvalue() == correct_tag



# Generated at 2022-06-24 11:46:46.208625
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    assert FlvReader(b'\x00\x00\x00\x14\x00\x00\x00\x00').read_box_info() == (8, b'\x00\x00\x00\x00', b'')
    assert FlvReader(b'\x00\x00\x00\x14\x00\x00\x00\x00' + b'\x00' * 8).read_box_info() == (16, b'\x00\x00\x00\x00', b'')

# Generated at 2022-06-24 11:46:49.327006
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    f = io.BytesIO()
    write_unsigned_int(f, 0x01020304)
    assert f.getvalue() == b'\x01\x02\x03\x04'



# Generated at 2022-06-24 11:46:59.866553
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    # Test 1: read 1 byte
    test_file = io.BytesIO(b'123456789')
    test_FlvReader = FlvReader(test_file)
    test_FlvReader.read_bytes(1)
    assert test_FlvReader.read(1) == b'2'
    test_FlvReader.seek(0)
    # Test 2: read more bytes then the file contains.
    test_file = io.BytesIO(b'123456789')
    test_FlvReader = FlvReader(test_file)
    try:
        test_FlvReader.read_bytes(11)
        assert False
    except DataTruncatedError:
        pass
    assert test_FlvReader.tell() == 9



# Generated at 2022-06-24 11:47:03.628985
# Unit test for function write_flv_header
def test_write_flv_header():
    out = io.BytesIO()
    write_flv_header(out)
    expected = b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'
    assert out.getvalue() == expected



# Generated at 2022-06-24 11:47:10.337069
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    reader = FlvReader(b'string\x00stringwithnull\x00\x00stringwithtwonulls\x00\x00\x00')
    assert reader.read_string() == b'string'
    assert reader.read_string() == b'stringwithnull'
    assert reader.read_string() == b'stringwithtwonulls'

# Generated at 2022-06-24 11:47:21.320940
# Unit test for function get_base_url
def test_get_base_url():
    test_manifest = """<?xml version="1.0" encoding="utf-8"?>
    <manifest xmlns="http://ns.adobe.com/f4m/1.0">
        <baseURL>https://example.com/</baseURL>
    </manifest>
    """
    assert get_base_url(compat_etree_fromstring(test_manifest)) == 'https://example.com/'
    test_manifest_2 = """<?xml version="1.0" encoding="utf-8"?>
    <manifest xmlns="http://ns.adobe.com/f4m/2.0">
    <baseURL>https://example.com/</baseURL>
    </manifest>
    """

# Generated at 2022-06-24 11:47:29.414429
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-24 11:47:38.789727
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    from .test_fragment_fd import mux_fragments
    from .test_mp4 import Mp4Reader
    def test(data, expected):
        stream = io.BytesIO()
        write_unsigned_int(stream, data)
        assert stream.getvalue() == expected

    test(0x00000001, b'\x00\x00\x00\x01')
    test(0x10000000, b'\x10\x00\x00\x00')
    test(0x7FFFFFFF, b'\x7F\xFF\xFF\xFF')
test_write_unsigned_int()



# Generated at 2022-06-24 11:47:41.957168
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    fd = io.BytesIO(b'daa\x00')
    reader = FlvReader(fd)
    assert reader.read_string() == b'daa'



# Generated at 2022-06-24 11:47:53.652656
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    raw = b'\x00\x00\x01\x00a\x00\x00\x00\x00\x00'
    flv = FlvReader(raw)
    size, box_type, box_data = flv.read_box_info()

    assert size == 1
    assert box_type == b'a\x00\x00\x00'
    assert box_data == b''

    raw = b'\x00\x00\x00\x01a\x00\x00\x00\x00\x00\x00\x00\x00'
    flv = FlvReader(raw)
    size, box_type, box_data = flv.read_box_info()

    assert size == 1

# Generated at 2022-06-24 11:47:59.439056
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from .test_fragment import _gen_tests
    for test_video_id, test_f4m_url in _gen_tests():
        fragment_fd = FragmentFD(test_f4m_url, {'test_video_id': test_video_id})
        data = b''
        for chunk in fragment_fd.read_chunks():
            data += chunk
        flv_reader = FlvReader(data)
        flv_reader.read_bootstrap_info()



# Generated at 2022-06-24 11:48:06.486137
# Unit test for method read_unsigned_long_long of class FlvReader

# Generated at 2022-06-24 11:48:11.508434
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == (b'FLV\x01'
        b'\x05'
        b'\x00\x00\x00\x09'
        b'\x00\x00\x00\x00')



# Generated at 2022-06-24 11:48:23.417983
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-24 11:48:29.910663
# Unit test for function read_bootstrap_info

# Generated at 2022-06-24 11:48:35.419091
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import sys
    import unittest
    import xml.etree.ElementTree as etree
    if sys.version_info[0] < 3:
        import urllib as urllib_geturl
    else:
        import urllib.parse as urllib_geturl
    
    class FakeYTDL(object):
        def __init__(self, info_dict):
            self.info_dict = info_dict
         
        def report_warning(self, msg):
            raise Exception("Unexpected call to report_warning: {}".format(msg))

        def urlopen(self, url):
            class FakeUH(object):
                def __init__(self):
                    self.code = 200
                def getcode(self):
                    return 200
                def geturl(self):
                    return url

# Generated at 2022-06-24 11:48:39.966991
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    data = b'\x00\x00\x00\x05'
    data += b'Data'
    assert FlvReader(data).read_unsigned_int() == 5



# Generated at 2022-06-24 11:48:45.361804
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    remove_encrypted_media([])
    remove_encrypted_media([Element('test_1')])
    remove_encrypted_media([Element('test_2', attrib={'drmAdditionalHeaderId': 'Y'})])
    remove_encrypted_media([Element('test_3', attrib={'drmAdditionalHeaderSetId': 'Y'})])
    remove_encrypted_media([Element('test_4', attrib={'drmAdditionalHeaderId': 'Y', 'drmAdditionalHeaderSetId': 'Y'})])



# Generated at 2022-06-24 11:48:49.081245
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\t\x00\x00\x00\x00'



# Generated at 2022-06-24 11:48:58.709874
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    # Reference data
    reference_data = b'\x12\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

    # Create test stream
    stream = io.BytesIO()
    metadata = b'\x00'

    # Write test data to the stream
    write_metadata_tag(stream, metadata)

    # Compare with reference data
    assert stream.getvalue() == reference_data



# Generated at 2022-06-24 11:49:04.120849
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    """
    Tests the read_unsigned_long_long method of class FlvReader
    """
    flv_reader = FlvReader(
        compat_struct_pack('!II', 1, 0) +
        compat_struct_pack('!Q', 0xFFFFFFFFFFFFFFFF))
    assert flv_reader.read_unsigned_long_long() == 0xFFFFFFFFFFFFFFFF


# Generated at 2022-06-24 11:49:16.688523
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import os
    import sys
    import json
    import tempfile
    from youtube_dl.PostProcessor import PostProcessor
    from youtube_dl.utils import prepend_extension

    def test_downloader(pyfile, url, **kw):
        assert 'http://httpbin.org/' in url
        with open(prepare_filename(pyfile['name']), 'rb') as f:
            content = f.read()
            assert content == b'Hello!\n'
        return {'name': 'foobar.txt'}

    class PP(PostProcessor):
        def run(self, info):
            assert 'filepath' in info
            assert info['filepath'] == 'foobar.txt'


# Generated at 2022-06-24 11:49:19.528077
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    s = io.BytesIO()
    write_unsigned_int(s, 123)
    assert(s.getvalue() == b'{\x00\x00')



# Generated at 2022-06-24 11:49:29.989945
# Unit test for constructor of class F4mFD
def test_F4mFD():
    # test FlvReader class
    input_str = b'\x00\x00\x00\x04\x00\x00\x00\x03f\x00\x00\x00\x06\x00\x00\x00\x00\x00\x00\x00\x01'
    res = FlvReader(input_str).read_unsigned_char()
    assert res == 3
    res = FlvReader(input_str).read_unsigned_short()
    assert res == 102

    res = FlvReader(input_str).read_unsigned_int()
    assert res == 262144


# Generated at 2022-06-24 11:49:40.774696
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-24 11:49:47.655378
# Unit test for function remove_encrypted_media

# Generated at 2022-06-24 11:49:53.865380
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    for s, b in [
            ('\x00', b'\x00'),
            ('foobar', b'foobar\x00'),
            ('foobar\x00baz', b'foobar\x00baz\x00'),
    ]:
        assert FlvReader(b).read_string() == s



# Generated at 2022-06-24 11:50:03.485062
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:50:13.874605
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    bootstrap_url = 'http://c.brightcove.com/services/mobile/streaming/index/master.m3u8?videoId=4039084767001&pubId=1564549380&playerId=1315535019001'
    bootstrap_bytes = compat_urllib_request.urlopen(bootstrap_url).read()
    flv_reader = FlvReader(bootstrap_bytes)
    bootstrap_info = flv_reader.read_bootstrap_info()
    assert bootstrap_info['fragments'][0]['fragments'][0] == {'first': 1, 'ts': 0, 'duration': 1000, 'discontinuity_indicator': 0}

# Generated at 2022-06-24 11:50:21.002851
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    # Test on emtpy string
    fd = FlvReader(b'\x00')
    assert fd.read_string() == b''

    # Test on non empty string
    fd = FlvReader(b'urlfragment\x00\x00\x00')
    assert fd.read_string() == b'urlfragment'

    # Test on not null terminated string
    fd = FlvReader(b'urlfragment')
    assert fd.read_string() == b''

# Generated at 2022-06-24 11:50:34.071504
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    url = 'http://mds.cdnakmi.brightcove.com/ts/i4/v1/AQ~~,AAAAB_i4_Zc~,ygfR0lHhh_u9bQ2L-q3V7nfYpYwV7ZhB/master.f4m'
    ydl = YoutubeDL({
        'simulate': True,
        'skip_download': True,
        'format': 'best',
        'writedescription': True,
        'dump_single_json': True,
    })
    res = ydl.extract_info(url, download=False)

# Generated at 2022-06-24 11:50:38.288649
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = b'\x00\x00\x00\x2f\x61\x73\x72\x74\x00\x00\x00\x00\x00\x01\x00\x00\x00\x03\x00\x00\x00\x01\x31\x32\x33\x34\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'
    assert FlvReader(data).read_asrt() == {'segment_run': [(1, 1)]}

# Generated at 2022-06-24 11:50:49.412046
# Unit test for function build_fragments_list
def test_build_fragments_list():
    bootstrap_info = read_bootstrap_info(open(
        'test/files/hds/bootstrap1.bootstrap', 'rb').read())

# Generated at 2022-06-24 11:50:53.892328
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    assert FlvReader(b'\x00\x01\x02\x03\x04\x05\x06\x07').read_unsigned_long_long() == 0x0706050403020100

# Generated at 2022-06-24 11:50:58.425484
# Unit test for function write_flv_header
def test_write_flv_header():
    # assert write_flv_header(io.BytesIO()) == b'FLV\x01\x05\x00\x00\x00\x00\x00\x00\x00\x00'
    fd = io.BytesIO()
    write_flv_header(fd)
    assert fd.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'


# Generated at 2022-06-24 11:51:00.033491
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError
    except Exception as e:
        assert(e.message == None)


# Generated at 2022-06-24 11:51:08.806475
# Unit test for function get_base_url
def test_get_base_url():
    manifest_xml_1 = """
        <manifest
            xmlns="http://ns.adobe.com/f4m/1.0">
            <baseURL>/f4m</baseURL>
        </manifest>"""
    manifest_xml_2 = """
        <manifest
            xmlns="http://ns.adobe.com/f4m/2.0">
            <baseURL>/f4m</baseURL>
        </manifest>"""
    manifest_xml_3 = """
        <manifest
            xmlns="http://ns.adobe.com/f4m/3.0">
            <baseURL>/f4m</baseURL>
        </manifest>"""

# Generated at 2022-06-24 11:51:18.594591
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    """Test write_metadata_tag function.
    """
    from .http import FakeSocket
    from .extractor import (
        int_or_none,
        float_or_none,
        str_or_none,
        attempt_get,
        parse_age_limit,
    )
    from .extractor.common import InfoExtractor
    from .compat import (
        compat_HTTPError,
        compat_urllib_error,
        compat_urllib_parse,
        compat_urllib_request,
    )

    def _test_metadata(expected_title, expected_duration, metadata):
        stream = io.BytesIO()
        write_flv_header(stream)
        write_metadata_tag(stream, metadata)
        stream.seek(0)

# Generated at 2022-06-24 11:51:25.465992
# Unit test for function build_fragments_list
def test_build_fragments_list():
    test_asrt = {
        'segment_run': [
            (1, 10),
            (2, 10),
            (3, 10),
        ]
    }

    test_afrt = {
        'fragments': [
            {
                'first': 1,
                'ts': 1000000,
                'duration': 1000,
                'discontinuity_indicator': None,
            },
            {
                'first': 11,
                'ts': 2000000,
                'duration': 1000,
                'discontinuity_indicator': None,
            },
            {
                'first': 21,
                'ts': 3000000,
                'duration': 1000,
                'discontinuity_indicator': None,
            },
        ],
    }


# Generated at 2022-06-24 11:51:35.313893
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    def assert_box_info(box_string, box_size, box_type, box_data):
        box_reader = FlvReader(box_string)
        size, type, data = box_reader.read_box_info()
        assert size == box_size
        assert type == box_type
        assert data == box_data
    assert_box_info(b'\x00\x00\x00\x1c' + b'moov' + b'abcdefghijklmnopqrstuvwxyz',
                    28, b'moov', b'abcdefghijklmnopqrstuvwxyz')

# Generated at 2022-06-24 11:51:44.534740
# Unit test for function get_base_url
def test_get_base_url():
    content = """
    <manifest xmlns="http://ns.adobe.com/f4m/1.0" xmlns:hdnts="http://www.hdnts.org/2003/hdnts" xmlns:hdd="http://hddfvm.hd.pbs.org/2011/08/hdne" xmlns:hd="http://ns.adobe.com/hd/1.0" xmlns:pbs="http://www.pbs.org/video">
    <baseURL>https://d2zihajmogu5jn.cloudfront.net/bipbop-advanced/bipbop_16x9_variant.m3u8</baseURL>
    </manifest>
    """
    manifest = compat_etree_fromstring(fix_xml_ampersands(content))


# Generated at 2022-06-24 11:51:48.044244
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    reader = FlvReader(b"\x04")
    assert reader.read_unsigned_char() == 4



# Generated at 2022-06-24 11:51:50.556749
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError()
    except(DataTruncatedError) as e:
        pass


# Generated at 2022-06-24 11:51:55.969717
# Unit test for function build_fragments_list
def test_build_fragments_list():
    import os
    import json
    _TEST_FILE = os.path.join(os.path.dirname(__file__), 'test_data/hds.bootstrap')
    with io.open(_TEST_FILE, 'rb') as f:
        boot_info = read_bootstrap_info(f.read())

    assert build_fragments_list(boot_info) == [(15, 0), (15, 1)]



# Generated at 2022-06-24 11:52:05.212548
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:52:15.858463
# Unit test for method read_string of class FlvReader

# Generated at 2022-06-24 11:52:22.940661
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    """Test method real_download of class F4mFD."""
    # Load test data
    # by pytest-datafiles
    return [
        # (F4mFD, filename, info_dict, man_url)
        #(F4mFD(), "f4m_manifest.xml", info_dict, man_url),
        #(F4mFD(), "f4m_manifest.xml", info_dict, man_url),
        #(F4mFD(), "f4m_manifest.xml", info_dict, man_url),
        #(F4mFD(), "f4m_manifest.xml", info_dict, man_url),
    ]