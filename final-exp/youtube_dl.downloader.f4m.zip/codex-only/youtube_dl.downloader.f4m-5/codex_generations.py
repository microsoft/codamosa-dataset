

# Generated at 2022-06-24 11:42:26.706410
# Unit test for function read_bootstrap_info

# Generated at 2022-06-24 11:42:33.874762
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    from .common import parse_m3u8_attributes

# Generated at 2022-06-24 11:42:37.177529
# Unit test for function write_flv_header
def test_write_flv_header():
    from io import BytesIO
    stream = BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\t\x00\x00\x00\x00'



# Generated at 2022-06-24 11:42:47.519843
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    sample_flv_data = b'\x00\x00\x00\x08\x64\x61\x74\x61\x00\x00\x00\x04\x66\x6c\x76\x34\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00abcd'
    flv_reader = FlvReader(sample_flv_data)
    real_size, box_type, box_data = flv_reader.read_box_info()
    assert real_size == 24
    assert box_type == b'data'

# Generated at 2022-06-24 11:42:57.433178
# Unit test for function build_fragments_list
def test_build_fragments_list():
    # Tests for live streams
    boot_info = {
        'segments': [
            {
                'segment_run': [
                    (1, 2),
                    (4, 1),
                ],
            },
        ],
        'fragments': [
            {
                'fragments': [
                    {
                        'first': 5,
                        'ts': 1000,
                        'duration': 0,
                    },
                    {
                        'first': 6,
                        'ts': 2000,
                        'duration': 0,
                    },
                ],
            },
        ],
        'live': True,
    }
    assert build_fragments_list(boot_info) == [(4, 6), (1, 7)]


# Generated at 2022-06-24 11:43:00.665916
# Unit test for constructor of class F4mFD
def test_F4mFD():
    from .utils import sanitize_open
    with sanitize_open('tests/data/test.f4m') as f:
        f4m = F4mFD(f, {'url': 'test.f4m'})
        f4m.real_download('test.flv', {'url': 'test.f4m'})



# Generated at 2022-06-24 11:43:02.160891
# Unit test for constructor of class F4mFD
def test_F4mFD():
    fd = F4mFD(None, None, {})
    if fd is None:
        raise Exception('Failed to create F4mFD')
    return fd

# Generated at 2022-06-24 11:43:05.820970
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    flvreader = FlvReader(b'helloworld')
    assert flvreader.read_bytes(5) == b'hello'
    assert flvreader.read_bytes(6) == b'world'


# Generated at 2022-06-24 11:43:10.168907
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = read_bootstrap_info(bootstrap_live_frag)
    assert build_fragments_list(boot_info) == [(0, 0), (0, 1), (0, 2), (0, 3)]

    boot_info = read_bootstrap_info(bootstrap_live_frag_abnormal)
    assert build_fragments_list(boot_info) == [(0, 0), (0, 1), (0, 2), (0, 3)]



# Generated at 2022-06-24 11:43:14.064982
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    import io
    import struct
    stream = io.BytesIO()
    for i in range(300):
        write_unsigned_int_24(stream, i)
    read_data = stream.getvalue()
    assert len(read_data) == 300 * 3
    for i in range(300):
        val = read_data[i * 3: i * 3 + 3]
        assert len(val) == 3
        read_int = struct.unpack('!I', val + b'\x00')[0]
        assert read_int == i



# Generated at 2022-06-24 11:43:25.829524
# Unit test for constructor of class FlvReader

# Generated at 2022-06-24 11:43:28.254462
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    with DataTruncatedError() as e:
        pass



# Generated at 2022-06-24 11:43:31.218961
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    f = FlvReader(compat_struct_pack('!B', 255))
    assert f.read_unsigned_char() == 255



# Generated at 2022-06-24 11:43:33.129822
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    error = DataTruncatedError('foo')
    assert error.args[0] == 'foo'



# Generated at 2022-06-24 11:43:37.350627
# Unit test for function write_flv_header
def test_write_flv_header():
    _ = io.BytesIO()
    write_flv_header(_)
    assert _.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-24 11:43:42.357547
# Unit test for function write_flv_header
def test_write_flv_header():
    assert write_flv_header(io.BytesIO()) == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-24 11:43:49.431617
# Unit test for function write_metadata_tag

# Generated at 2022-06-24 11:44:01.571306
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    from .dash import _parse_segment_timeline

# Generated at 2022-06-24 11:44:04.846819
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    assert write_unsigned_int(io.BytesIO(), 0) == b'\x00\x00\x00\x00'
    assert write_unsigned_int(io.BytesIO(), 16843009) == b'\x01\x02\x03\x04'



# Generated at 2022-06-24 11:44:12.375694
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    test_data = compat_struct_pack(
        '!I4sI', 1, b'a', 1
    )
    reader = FlvReader(test_data)
    assert reader.read_box_info() == (1, b'a', b'')
    test_data = compat_struct_pack(
        '!I4sQ', 1, b'a', 1
    )
    reader = FlvReader(test_data)
    assert reader.read_box_info() == (1, b'a', b'')


# Generated at 2022-06-24 11:44:19.019294
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    from gzip import decompress
    from ..compat import unescapeHTML

# Generated at 2022-06-24 11:44:30.627529
# Unit test for function remove_encrypted_media

# Generated at 2022-06-24 11:44:35.946803
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:44:44.959332
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()

# Generated at 2022-06-24 11:44:57.551258
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    data = b"abcd\x00\x00\x00\x0cwxyz\x00\x00\x00\x04"
    reader = FlvReader(data)
    size, box_type, box_data = reader.read_box_info()
    assert size == 12
    assert box_type == b'abcd'
    assert box_data == b'wxyz\x00\x00\x00\x04'
    assert reader.read() == b''



# Generated at 2022-06-24 11:45:02.442778
# Unit test for function get_base_url
def test_get_base_url():
    assert get_base_url(compat_etree_fromstring(b"""
<manifest xmlns="http://ns.adobe.com/f4m/1.0">
    <baseURL>http://example.com/</baseURL>
</manifest>
    """)) == 'http://example.com/'



# Generated at 2022-06-24 11:45:07.473944
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    binary = bytearray([0x00, 0x00, 0x00, 0x0C,
                        0x61, 0x62, 0x63, 0x64,
                        0x65, 0x66, 0x67, 0x68])
    reader = FlvReader(binary)
    assert reader.read_unsigned_int() == 12
    assert reader.read_string() == b'abcd'



# Generated at 2022-06-24 11:45:11.006815
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    flv = FlvReader(b'\x00\x01\x02')
    assert flv.read_bytes(1) == b'\x00'
    assert flv.read_bytes(2) == b'\x01\x02'



# Generated at 2022-06-24 11:45:23.064084
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-24 11:45:34.911453
# Unit test for constructor of class F4mFD
def test_F4mFD():
    stream_urls = []

# Generated at 2022-06-24 11:45:45.966198
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    flv = FlvReader(b'\x00\x00\x00\x18' + b'moov' + b'\x00'*22)
    box_size, box_type, box_data = flv.read_box_info()
    assert box_size == 24
    assert box_type == b'moov'
    assert len(box_data) == 0
    flv = FlvReader(b'\x00\x00\x00\x01' + b'moov' + b'\x00'*8)
    box_size, box_type, box_data = flv.read_box_info()
    assert box_size == 9
    assert box_type == b'moov'
    assert len(box_data) == 0


# Generated at 2022-06-24 11:45:53.852090
# Unit test for function build_fragments_list
def test_build_fragments_list():
    # Example from https://github.com/ytdl-org/youtube-dl/issues/10474
    # The live stream has 2 segments 0, 1 with segment 0 containing 4 fragments
    # and segment 1 containing 3 fragments.
    boot_info = {
        'live': True,
        'segments': [{
            'segment_run': [
                (0, 4),
                (1, 3),
            ],
        }],
    }
    assert build_fragments_list(boot_info) == [(0, 0), (0, 1), (0, 2), (0, 3),
                                               (1, 0), (1, 1), (1, 2)]
    boot_info['live'] = False

# Generated at 2022-06-24 11:45:58.888924
# Unit test for function get_base_url
def test_get_base_url():
    manifest = (
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://test.se/</baseURL>'
        '</manifest>')
    assert get_base_url(compat_etree_fromstring(manifest)) == 'http://test.se/'



# Generated at 2022-06-24 11:46:00.250318
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    """
    This method is tested when reading metadata
    """
    pass


# Generated at 2022-06-24 11:46:12.201607
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-24 11:46:17.707914
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    assert write_unsigned_int(io.BytesIO(), 0) is None
    assert write_unsigned_int(io.BytesIO(), 0xfffffffe) is None
    assert write_unsigned_int(io.BytesIO(), 0xffffffff) is None



# Generated at 2022-06-24 11:46:21.869462
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    buf = io.BytesIO()
    buf.write(compat_struct_pack('!I', 4))
    buf.seek(0)
    reader = FlvReader(buf)
    assert reader.read_unsigned_int() == 4



# Generated at 2022-06-24 11:46:29.464952
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    f_test = io.BytesIO(b'111222333444555666777888999')
    fr = FlvReader(f_test)
    assert fr.read_bytes(1) == b'1'
    assert fr.read_bytes(3) == b'112'
    fr.seek(0)
    assert fr.read_bytes(10) == b'11122233344'
    fr.seek(0)
    assert fr.read_bytes(10) == b'11122233344'
    fr.seek(0)
    assert fr.read_bytes(20) == b'111222333444555666777'
    fr.seek(0)
    assert fr.read_bytes(40) == b'111222333444555666777888999'



# Generated at 2022-06-24 11:46:40.384492
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    # The data below is taken from a real world example
    data = 'AACSftbpBQAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAA'.encode('ascii')
    data += b'AABQ0jJHwv8AAAAAAAAAAAAAAAAAAAAAAAAAAAEAAf9lAG'
    data += b'MAAAAAAAIDAAAAAwAAAAAAAAAAAAAAAAAAAAAABwBAAgAN'
    data += b'EBkAGQAZQAgADcAAQACAAAAAwAAAAAAAAAAAAAAAAAAAAA'
    data += b'AABgBAAQAFNIdyNQAAAAAAAAAAAAAAAAAAAAAAAQAAAAAA'
    data += b'AAAAAAkAAAABABgAZAAIAAI9AAAAAAEAAAAyAAAAAAAAAA'
    data += b'ID6wgAAACwEAAAAAAAABQAAAAAAAAA0AQAAH+cAUxBUlQv'

# Generated at 2022-06-24 11:46:47.255527
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    flv_reader = FlvReader(b'abc\x00abc')
    assert flv_reader.read_bytes(4) == b'abc\x00'
    assert flv_reader.read_bytes(4) == b'abc'
    try:
        flv_reader.read_bytes(4)
        assert False, 'Should not reach here'
    except DataTruncatedError as e:
        assert e.args[0] == 'FlvReader error: need 4 bytes while only 0 bytes got'


# Generated at 2022-06-24 11:46:49.174403
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    x = DataTruncatedError()
    x.exception(DataTruncatedError)



# Generated at 2022-06-24 11:47:00.048205
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    fmt = '!B3I4QII'

# Generated at 2022-06-24 11:47:11.218634
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    return

# Generated at 2022-06-24 11:47:17.322641
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    flv_reader = FlvReader(b'\x00\x00\x00\x0Fftyp')
    assert flv_reader.read_unsigned_char() == 0
    assert flv_reader.read_unsigned_char() == 0
    assert flv_reader.read_unsigned_char() == 0
    assert flv_reader.read_unsigned_char() == 15
    return flv_reader

# Generated at 2022-06-24 11:47:25.748804
# Unit test for function get_base_url
def test_get_base_url():
    manifest = '''
    <manifest xmlns="http://ns.adobe.com/f4m/2.0">
      <baseURL>BASE-URL-2</baseURL>
    </manifest>'''
    assert get_base_url(manifest) == 'BASE-URL-2'

    manifest = '''
    <manifest xmlns="http://ns.adobe.com/f4m/1.0">
      <baseURL>BASE-URL-1</baseURL>
    </manifest>'''
    assert get_base_url(manifest) == 'BASE-URL-1'



# Generated at 2022-06-24 11:47:30.496211
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    fp = io.BytesIO(b'abcdefgh')
    reader = FlvReader(fp)
    assert reader.read_bytes(4) == b'abcd'
    assert reader.read_bytes(4) == b'efgh'



# Generated at 2022-06-24 11:47:40.996333
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Test if F4mFD.real_download is able to retrieve fragments of a video
    f4m_url = 'http://flashmedia.eastbaymedia.com/w/news/traffic/MassDOT/687/687_h264_high.f4m'

    class MockYDL(object):
        def __init__(self):
            self.params = {'test': True}

        def urlopen(self, url):
            return compat_urllib_request.urlopen(url)

    ydl = MockYDL()
    fd = F4mFD(ydl, {})

    # Download manifest
    urlh = ydl.urlopen(f4m_url)
    manifest = urlh.read().decode('utf-8', 'ignore').strip()

# Generated at 2022-06-24 11:47:52.751215
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-24 11:47:59.308721
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    bytes = compat_struct_pack(
        '!I', 11) + b'abst' + compat_struct_pack('!I', 0)+b'\x00\x00\x00\x00'
    reader = FlvReader(bytes)
    try:
        reader.read_bytes(4)
        reader.read_bytes(4)
        reader.read_bytes(4)
    except DataTruncatedError as e:
        assert str(e) == 'FlvReader error: need 4 bytes while only 0 bytes got'
    else:
        assert False


# Generated at 2022-06-24 11:48:04.997368
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    """
    Test read_unsigned_long_long of class FlvReader
    """
    input = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    # big endian: 0x0000000000000000
    # little endian: 0x0000000000000000
    expected = 0x0000000000000000
    reader = FlvReader(input)
    assert reader.read_unsigned_long_long() == expected
    assert reader.tell() == len(input)
test_download_flv_read_unsigned_long_long = test_FlvReader_read_unsigned_long_long

# Generated at 2022-06-24 11:48:17.386184
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-24 11:48:27.033386
# Unit test for method read_unsigned_long_long of class FlvReader

# Generated at 2022-06-24 11:48:37.998793
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    import base64
    import hashlib
    import lzma
    import unittest
    if hasattr(unittest.TestCase, 'assertIsNone'):
        # Python 3.4+
        def assertIsNone(self, expr):
            self.assertIs(expr, None)
    else:
        # Python 3.2, 3.3
        def assertIsNone(self, expr):
            self.assertTrue(expr is None)

    class TestWriteMetadataTag(unittest.TestCase):
        def testWriteEmptyMetadataTag(self):
            stream = io.BytesIO()
            write_flv_header(stream)
            write_metadata_tag(stream, b'')

            stream.seek(0)
            self.assertEqual(stream.read(4), b'FLV\x01')


# Generated at 2022-06-24 11:48:45.434085
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:48:49.124107
# Unit test for function write_flv_header
def test_write_flv_header():
    data = io.BytesIO()
    write_flv_header(data)
    assert data.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'


# Generated at 2022-06-24 11:49:00.838874
# Unit test for function write_flv_header
def test_write_flv_header():
    from ..utils import mkstemp
    from .f4m import F4M

    f4m_url = 'http://example.com/stream.f4m'
    manifest = F4M(f4m_url, {})
    f4m_data = compat_struct_pack('!I', len(f4m_url)) + f4m_url.encode('utf-8')
    disk_f4m_filename, disk_f4m_handle = mkstemp(suffix='.f4m')
    with io.open(disk_f4m_handle, 'wb') as disk_f4m:
        write_flv_header(disk_f4m)

# Generated at 2022-06-24 11:49:07.559546
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-24 11:49:18.569505
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    raw = b'\x00\x00\x00(\x61\x73\x72\x74\x00\x00\x00\x00\x00\x00\x00\x01\x00\x0F'\
          b'\x61\x76\x63\x31\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x0A'

    # Use BytesIO to simulate a file
    reader = FlvReader(raw)
    data = reader.read_asrt()
    assert data['segment_run'] == [(0, 1)]


# Generated at 2022-06-24 11:49:29.283103
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    import unittest
    from io import BytesIO

    class TestWriteMetadataTag(unittest.TestCase):
        def setUp(self):
            self.stream = BytesIO()
            self.metadata = b'<xml><metadata>metadata</metadata></xml>'

        def assert_stream_equals(self, expected):
            actual_header = self.stream.getvalue()
            self.assertEqual(expected, actual_header)

        def test_write_metadata_tag(self):
            write_flv_header(self.stream)
            write_metadata_tag(self.stream, self.metadata)

# Generated at 2022-06-24 11:49:40.123548
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-24 11:49:46.998607
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    import io
    metadata = b'<some-xml/>'
    stream = io.BytesIO()
    write_metadata_tag(stream, metadata)

    stream.seek(0)
    assert stream.read(1) == b'\x12'
    assert stream.read(3) == b'\x00\x00\x0b'
    assert stream.read(4) == b'\x00\x00\x00\x00'
    assert stream.read(8) == b'\x00\x00\x00\x00\x00\x00\x00\x00'
    assert stream.read(len(metadata)) == metadata
    assert stream.read(4) == b'\x00\x00\x00\x1c'



# Generated at 2022-06-24 11:49:52.175801
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    """
    Test method read_string
    """
    reader = FlvReader(b'12345\x0067890\x00')
    assert reader.read_string() == b'12345'
    assert reader.read_string() == b'67890'



# Generated at 2022-06-24 11:49:55.434856
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError('Invalid data received.')
    except DataTruncatedError as e:
        if str(e) != 'Invalid data received.':
            return False
    return True



# Generated at 2022-06-24 11:50:02.877391
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    flv_content = b'\x00\x00\x00\x1C\x61\x62\x73\x74\x00\x00\x00\x01'
    r = FlvReader(flv_content)
    assert r.read_bootstrap_info()['live']

    flv_content = b'\x00\x00\x00\x1C\x61\x62\x73\x74\x00\x00\x00\x00'
    r = FlvReader(flv_content)
    assert not r.read_bootstrap_info()['live']



# Generated at 2022-06-24 11:50:12.848962
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    import os
    path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'bootstrap', 'bootstrapinfo_vod.abst')
    with open(path, 'rb') as bootstrap_file:
        bootstrap = read_bootstrap_info(bootstrap_file.read())
        assert bootstrap['segments'] == [{'segment_run': [(0, 2)]}]
        assert bootstrap['fragments'] == [{
            'fragments': [
                {'first': 1, 'ts': 0, 'duration': 1000, 'discontinuity_indicator': None},
                {'first': 2, 'ts': 1000, 'duration': 1000, 'discontinuity_indicator': None},
            ],
        }]
       

# Generated at 2022-06-24 11:50:19.154457
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    input_string = b'\x24test\x00\x00\x00test\x00\x00\x00test'
    assert FlvReader(input_string).read_string() == b'$test'
    assert FlvReader(input_string).read_string() == b'test'
    assert FlvReader(input_string).read_string() == b'test'
    assert FlvReader(input_string).read_string() == b''



# Generated at 2022-06-24 11:50:21.753579
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError()
    except DataTruncatedError:
        pass
    else:
        raise Exception('DataTruncatedError does not work')


# Generated at 2022-06-24 11:50:26.954331
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    test_data = b'foo\x00bar\x00\x00'
    fr = FlvReader(test_data)
    assert fr.read_string() == b'foo'
    assert fr.read_string() == b'bar'
    assert fr.read_string() == b''



# Generated at 2022-06-24 11:50:37.976633
# Unit test for function build_fragments_list
def test_build_fragments_list():
    import xml.etree.ElementTree as ET
    if ET.LXML is not None:
        def _fast_iter(context, func, *args, **kwargs):
            for event, elem in context:
                func(elem, *args, **kwargs)
                elem.clear()
            context.close()
        ET._fast_iter = ET._serialize.default_serialization_handlers[0]
        ET._serialize.default_serialization_handlers[0] = _fast_iter

# Generated at 2022-06-24 11:50:46.784145
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    with io.BytesIO() as f:
        write_unsigned_int_24(f,0x010203)
        assert f.getvalue() == b'\x01\x02\x03'

        f.seek(0)
        write_unsigned_int_24(f,0x100203)
        assert f.getvalue() == b'\x01\x02\x03'

        f.seek(0)
        write_unsigned_int_24(f,0x00ff03)
        assert f.getvalue() == b'\x00\xff\x03'


# Generated at 2022-06-24 11:50:49.923863
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    from io import BytesIO
    stream = BytesIO()
    write_unsigned_int(stream, 1234567890)
    assert stream.getvalue() == b'\x49\x96\x02\xd2'
# Unit test end


# Generated at 2022-06-24 11:51:01.486892
# Unit test for constructor of class F4mFD
def test_F4mFD():
  manifest = '''
<manifest xmlns="http://ns.adobe.com/f4m/1.0">
  <id>skate_philly</id>
  <mimeType>video/f4m</mimeType>
  <streamType>live</streamType>
  <deliveryType>streaming</deliveryType>
  <duration>0</duration>
  <bootstrapInfo profile="named" id="bootstrap1">
    YXZhc2QgAAAABJRU5ErkJggg==
  </bootstrapInfo>
  <media url="http://server/skate_philly.m3u8" bitrate="500" bootstrapInfoId="bootstrap1" />
</manifest>
'''

# Generated at 2022-06-24 11:51:05.226386
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    write_unsigned_int(stream, 0x12345678)
    assert stream.getvalue() == b'\x12\x34\x56\x78'



# Generated at 2022-06-24 11:51:15.600258
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-24 11:51:22.084050
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    '''
    >>> a = FlvReader(b'abcd')
    >>> a.read_bytes(1)
    b'a'
    >>> a.read_bytes(1)
    b'b'
    >>> a.read_bytes(3)
    b'cd'
    Traceback (most recent call last):
    ...
    DataTruncatedError: FlvReader error: need 3 bytes while only 1 bytes got
    '''
    pass

# Generated at 2022-06-24 11:51:33.429809
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    test_data = (b'\x00' * 7 + b'\x01' + b'\x00' * 7 +
                 b'\x01\x02\x03\x04' + b'\x01\x00\x00\x00' +
                 b'\x01\x00\x00\x00' + b'\x00\x00\x00\x10' +
                 b'\x01\x02\x03\x04' + b'\x01\x00\x00\x00' +
                 b'\x01\x00\x00\x00' + b'\x00\x00\x00\x00' +
                 b'\x00' * 16)
    flv_reader = FlvReader(test_data)
    assert flv_

# Generated at 2022-06-24 11:51:43.537584
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    from .common import load_fixture
    bootstrap_bytes = load_fixture(b'bootstrap_info_multiple_fragments.bootstrap')
    bootstrap_info = read_bootstrap_info(bootstrap_bytes)
    assert bootstrap_info['live'] == True
    assert len(bootstrap_info['segments']) == 1
    assert len(bootstrap_info['fragments']) == 1
    assert bootstrap_info['segments'][0]['segment_run'] == [(0, 5)]

# Generated at 2022-06-24 11:51:52.045055
# Unit test for method read_box_info of class FlvReader

# Generated at 2022-06-24 11:52:01.155980
# Unit test for method read_string of class FlvReader

# Generated at 2022-06-24 11:52:04.272680
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    test_data = b'\x01\x00\x00'
    flvReader = FlvReader(test_data)
    assert flvReader.read_unsigned_char() == 1



# Generated at 2022-06-24 11:52:08.407873
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    """
    >>> test_FlvReader_read_unsigned_long_long()
    'OK'
    """
    flv = FlvReader(compat_struct_pack('!Q', 0x0102030405060708))
    assert flv.read_unsigned_long_long() == 0x0102030405060708
    return 'OK'



# Generated at 2022-06-24 11:52:18.815727
# Unit test for constructor of class F4mFD
def test_F4mFD():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor import get_info_extractor
    from .common import fake_urlh

    ie = get_info_extractor('generic')
    ie.add_info_extractor(F4mFD())

    ydl = YoutubeDL({})
    ydl.add_default_info_extractors()

    # Note: The following tests are not used in unit tests.
    # Instead they are used to debug the test cases before
    # converting them to proper unit tests.
    #
    # Test manifest with manifestVersion of 1.0
    # manifest = '''
    # <manifest xmlns="http://ns.adobe.com/f4m/1.0">
    #     <id>test_f4m_1.0</id>
    #    