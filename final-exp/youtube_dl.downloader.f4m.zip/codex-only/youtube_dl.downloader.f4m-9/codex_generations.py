

# Generated at 2022-06-24 11:42:27.148469
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    bytes_data = b'\x00\x00\x00\x6e\x61\x73\x72\x74\x01\x00\x00\x00\x01\x00\x00\x00\x25\x64\x65\x66\x61\x75\x6c\x74\x5f\x68\x61\x72\x64\x5f\x67\x6f\x70\x5f\x70\x6c\x75\x67\x2d\x69\x6e\x5f\x74\x6c\x00\x00\x00\x00\x00\x0f\x00\x00\x00\x01\x00\x00\x00\x16\x00'
   

# Generated at 2022-06-24 11:42:32.899707
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    f = FlvReader(b'1234567890')
    assert f.read_bytes(1) == b'1'
    assert f.read_bytes(1) == b'2'
    assert f.read_bytes(2) == b'34'
    assert f.read_bytes(4) == b'5678'
    assert f.read_bytes(5) == b'90'
    assert f.read_bytes(1) == b''



# Generated at 2022-06-24 11:42:36.885835
# Unit test for function write_flv_header
def test_write_flv_header():
    """Tests for function write_flv_header"""
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'
# End unit test for function write_flv_header



# Generated at 2022-06-24 11:42:46.945331
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    f = FlvReader(b'abc\x00abc\x00abc\x00abc\x00')
    assert f.read_bytes(1) == b'a'
    assert f.read_bytes(2) == b'bc'
    assert f.read_bytes(3) == b'\x00ab'
    try:
        f.read_bytes(4)
    except DataTruncatedError:
        pass

test_flv_file_name = 'test.flv'

# Generated at 2022-06-24 11:42:51.962613
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    stream = io.BytesIO()
    write_unsigned_int_24(stream, 0x12345)
    assert stream.getvalue() == b'\x45\x23\x01'
# /Unit test for function write_unsigned_int_24



# Generated at 2022-06-24 11:42:59.497334
# Unit test for function build_fragments_list
def test_build_fragments_list():
    def check_fragments_list(boot_info, expected_fragments_list):
        assert build_fragments_list(boot_info) == expected_fragments_list

    # OnDemand case
    boot_info = {
        'segments': [
            {
                'segment_run': [(0, 1), (1, 2), (2, 3), (3, 4), (4, 5)],
            },
        ],
        'fragments': [
            {
                'fragments': [
                    {
                        'first': 1, 'ts': 0, 'duration': 0,
                        'discontinuity_indicator': None,
                    },
                ],
            },
        ],
        'live': False,
    }

# Generated at 2022-06-24 11:43:07.310007
# Unit test for function remove_encrypted_media

# Generated at 2022-06-24 11:43:09.741833
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    error = DataTruncatedError()
    assert error.message is None
    error = DataTruncatedError(u"message")
    assert error.message == u"message"



# Generated at 2022-06-24 11:43:14.694569
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:43:26.375845
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # case 1
    test_data = (b'\x00' * 4 + b'aaaa' + b'\x00' * 12)
    flv_reader = FlvReader(test_data)
    size, box_type, box_data = flv_reader.read_box_info()
    assert size == 16
    assert box_type == b'aaaa'
    assert box_data == b'\x00' * 12
    # case 2
    test_data = (b'\x00' * 4 + b'aaaa' + b'\x00' * 16)
    flv_reader = FlvReader(test_data)
    size, box_type, box_data = flv_reader.read_box_info()
    assert size == 20
    assert box_type == b'aaaa'
    assert box_

# Generated at 2022-06-24 11:43:34.898727
# Unit test for function build_fragments_list
def test_build_fragments_list():
    """Test for build_fragments_list()"""

# Generated at 2022-06-24 11:43:36.148270
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    f4mFD = F4mFD()
    f4mFD.real_download('filename', {'url':'https://example.org'})

# Generated at 2022-06-24 11:43:45.797917
# Unit test for function get_base_url
def test_get_base_url():
    xml_test = '''
    <manifest xmlns="http://ns.adobe.com/f4m/1.0">
        <baseURL>test.flv</baseURL>
    </manifest>'''
    manifest_test = compat_etree_fromstring(xml_test)
    base_url_test = get_base_url(manifest_test)
    assert base_url_test == 'test.flv'

    xml_test2 = '''
    <manifest xmlns="http://ns.adobe.com/f4m/2.0">
        <baseURL>test2.flv</baseURL>
    </manifest>'''
    manifest_test2 = compat_etree_fromstring(xml_test2)

# Generated at 2022-06-24 11:43:56.290831
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    box_data = b'\x20\x00\x00\x00ftypisom\x00\x00\x02\x00mp41\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    f = FlvReader(box_data)
    assert f.read_box_info() == (32, b'ftyp', b'isom\x00\x00\x02\x00mp41')
    assert f.read_box_info() == (0, b'', b'')



# Generated at 2022-06-24 11:43:57.975961
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    write_unsigned_int_24(io.BytesIO(), 0x012345)



# Generated at 2022-06-24 11:44:11.248763
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x0a'
        b'\x61\x73\x72\x74\x00\x00\x00\x00'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x01'
        b'\x31'
        b'\x00\x00\x00\x02'
        b'\x00\x00\x00\x00'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x01')
    assert FlvReader(data).read_asrt() == {
        'segment_run': [(0, 1), (1, 1)],
    }

# Generated at 2022-06-24 11:44:15.693225
# Unit test for function write_flv_header
def test_write_flv_header():
    from io import BytesIO
    stream = BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'
test_write_flv_header()



# Generated at 2022-06-24 11:44:24.701382
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    import io
    expected_data = b'\x12\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00{"duration":0,"width":0,"height":0,"videodatarate":0,"videocodecid":0,"framerate":0,"audiosamplerate":0,"audiosamplesize":0,"stereo":false,"audiocodecid":0}\x00\x00\x00C'
    stream = io.BytesIO()
    metadata = b'{"duration":0,"width":0,"height":0,"videodatarate":0,"videocodecid":0,"framerate":0,"audiosamplerate":0,"audiosamplesize":0,"stereo":false,"audiocodecid":0}'
    write

# Generated at 2022-06-24 11:44:31.594319
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    stream = io.BytesIO(compat_b64decode('''
        //ASRT
        AQAACAyAAABfX19iYXNlNjRfX18AAAAAAAoAAAAAgAACgAABAAAABQAAAAQAAAA
        BAAAAAAAAAAAAAAAAAAAAAwAAAAEAAAD4AAAAAgAAAAYAAAD8AAAABAAAAAUA
        AAEAAAAAAAAAAAAAAAEAAAABAAAAAQAAAAEAAAABAAAAAAAAAAAAAAAAAAAA
        AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
        AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=
    '''))
    assert FlvReader(stream).read_asrt() == {
        'segment_run': [(
            0,
            3,
        )],
    }


# Generated at 2022-06-24 11:44:39.846994
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():

    # Test reading info from a fake box
    f = FlvReader(b'\x00\x00\x00\x0Cabcd1234')
    box_size, box_type, box_data = f.read_box_info()
    assert box_size == 12
    assert box_type == b'abcd'
    assert box_data == b'1234'

    # Test reading info from a fake box, with a long size
    f = FlvReader(b'\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x0Cabcd1234')
    box_size, box_type, box_data = f.read_box_info()
    assert box_size == 12

# Generated at 2022-06-24 11:44:47.530196
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    flvreader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x00')
    assert flvreader.read_unsigned_int() == 0
    assert flvreader.read_unsigned_int() == 0

    flvreader = FlvReader(b'\xFF\xFF\xFF\xFF\x00\x00\x00\x00')
    assert flvreader.read_unsigned_int() == 0xFFFFFFFF
    assert flvreader.read_unsigned_int() == 0

    flvreader = FlvReader(b'\x00\x00\x00\x01\xFF\xFF\xFF\xFF')
    assert flvreader.read_unsigned_int() == 1
    assert flvreader.read_unsigned_

# Generated at 2022-06-24 11:44:52.872524
# Unit test for function remove_encrypted_media

# Generated at 2022-06-24 11:44:55.414106
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    flv = b'\x00\x01\x00\x00\x00\x01\x0f\xff\xff\xff\xff\xff\xff'
    assert FlvReader(flv).read_unsigned_char() == 0
    assert FlvReader(flv).read_unsigned_char() == 1
    assert FlvReader(flv).read_unsigned_char() == 0

# Generated at 2022-06-24 11:45:05.685758
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    """
    Test FlvReader.read_abst
    """
    # Test bootstrap info from file 'bootstrapinfo.abc'

# Generated at 2022-06-24 11:45:07.516751
# Unit test for function write_flv_header
def test_write_flv_header():
    from .flv_test import test_write_flv_header
    test_write_flv_header(write_flv_header)



# Generated at 2022-06-24 11:45:19.490515
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-24 11:45:30.580441
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:45:38.321490
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    import sys
    import io
    import os

    metadata = (
        '<meta>\n'
        '<duration>9</duration>\n'
        '<width>320</width>\n'
        '<height>240</height>\n'
        '<framerate>12.000000</framerate>\n'
        '<videocodecid>4</videocodecid>\n'
        '<videodatarate>256</videodatarate>\n'
        '</meta>'
    ).encode('utf-8')

# Generated at 2022-06-24 11:45:49.670133
# Unit test for function get_base_url
def test_get_base_url():
    manifest = """<?xml version="1.0" encoding="UTF-8"?>
<manifest xmlns="http://ns.adobe.com/f4m/1.0">
    <baseURL>http://example.com/</baseURL>
</manifest>
"""
    assert get_base_url(fix_xml_ampersands(compat_etree_fromstring(manifest))) == 'http://example.com/'
    manifest = """<?xml version="1.0" encoding="UTF-8"?>
<manifest xmlns="http://ns.adobe.com/f4m/2.0">
    <baseURL>http://example.com/</baseURL>
</manifest>
"""

# Generated at 2022-06-24 11:46:00.420793
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from xml.dom import minidom
    with open("../assets/test.bootstrap", "rb") as f:
        bootstrap_info = FlvReader(f.read()).read_bootstrap_info()
    assert bootstrap_info["live"] == True
    assert bootstrap_info["segments"] == [{'segment_run': [(0, 12), (12, 12)]}]

# Generated at 2022-06-24 11:46:12.365653
# Unit test for constructor of class FlvReader

# Generated at 2022-06-24 11:46:15.410675
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    assert FlvReader(compat_struct_pack('!B', 255)).read_unsigned_char() == 255



# Generated at 2022-06-24 11:46:18.797332
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError
    except DataTruncatedError:
        assert True
    except Exception:
        assert False



# Generated at 2022-06-24 11:46:20.032539
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    pass


# Generated at 2022-06-24 11:46:21.627951
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    err = DataTruncatedError()
    assert not err



# Generated at 2022-06-24 11:46:29.340378
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    import unittest
    class TestFlvReaderReadUnsignedLongLongMethods(unittest.TestCase):
        def test_FlvReader_calc_unsigned_long_long(self):
            self.assertEqual(FlvReader(b'\x10\x00\x00\x00').read_unsigned_long_long(), 402653184)
            self.assertEqual(FlvReader(b'\x00\x00\x00\x01').read_unsigned_long_long(), 1)
            self.assertEqual(FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x01').read_unsigned_long_long(), 1)

# Generated at 2022-06-24 11:46:35.666484
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    data = compat_struct_pack('!5I', 1, 2, 3, 4, 5)
    reader = FlvReader(data)
    assert reader.read_unsigned_int() == 1
    assert reader.read_unsigned_int() == 2
    assert reader.read_unsigned_int() == 3
    assert reader.read_unsigned_int() == 4
    assert reader.read_unsigned_int() == 5

# Generated at 2022-06-24 11:46:44.602602
# Unit test for function read_bootstrap_info

# Generated at 2022-06-24 11:46:53.024811
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    # "00000065 asrt 00000014".decode('hex')
    test_string = b'\x00\x00\x00\x65asrt\x00\x00\x00\x00\x00\x00\x01\x04hi\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'
    asrt = FlvReader(test_string).read_asrt()
    assert asrt == {'segment_run': [(1, 1)]}


# Generated at 2022-06-24 11:47:01.134415
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from .extractor.common import InfoExtractor
    from .utils import _debug_pprint
    from .compat import compat_str
    from .downloader.http import HttpFD
    import re
    import os
    import sys
    import time
    import random
    import shutil
    import tempfile
    from .utils import sanitize_open
    import unittest
    from .downloader.http import HTTPDownloader
    class MockFD(BaseFD):
        def __init__(self, ie, downloader=None, params=None, info_dicts=None):
            self.ie = ie
            self.downloader = downloader
            self.params = params
            self.info_dicts = info_dicts


# Generated at 2022-06-24 11:47:12.732412
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    # Test data is copied from sample file in
    # https://helpx.adobe.com/adobe-media-server/dev/bootstrap-info.html
    # Many thanks to Adobe
    data = b'\x00\x00\x01\xBFabst\x00\x00\x00\x0C\x00\x00\x00\x00\x00\x00\x00\x00'
    data += b'\x00\x00\x00$\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x06'

# Generated at 2022-06-24 11:47:18.957327
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    segment_run_table = (
        (1, 1),
        (2, 2),
        (3, 3),
    )
    abst = {
        'segment_run': segment_run_table,
    }
    data = io.BytesIO()
    data.write(compat_struct_pack('!B', 0))
    data.write(compat_struct_pack('!B', 0))
    data.write(compat_struct_pack('!B', 0))
    data.write(compat_struct_pack('!B', 0))
    data.write(compat_struct_pack('!I', len(segment_run_table)))
    for segment_run in segment_run_table:
        data.write(compat_struct_pack('!I', segment_run[0]))
        data

# Generated at 2022-06-24 11:47:23.792105
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-24 11:47:31.191272
# Unit test for function read_bootstrap_info

# Generated at 2022-06-24 11:47:36.194127
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'


# Generated at 2022-06-24 11:47:48.336537
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-24 11:47:52.991387
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    data = b'\x01\x02\x03\x04'
    reader = FlvReader(data)
    assert reader.read_unsigned_char() == 1
    assert reader.read_unsigned_char() == 2
    assert reader.read_unsigned_char() == 3
    assert reader.read_unsigned_char() == 4



# Generated at 2022-06-24 11:48:01.543291
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    import os
    from ..compat import (
        compat_chr,
        compat_ord,
    )
    from ..utils import (
        calculate_time_base,
        download_file,
    )

# Generated at 2022-06-24 11:48:08.275512
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:48:20.783284
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-24 11:48:27.765321
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = [compat_etree_fromstring(b"""
    <media url="media_00000.ts" bitrate="828" bitrateInitial="828"
           keyframeFrequency="101" bootstrapInfoId="bootstrap0" />"""),
            compat_etree_fromstring(b"""
    <media url="media_00001.ts" bitrate="828" bitrateInitial="828"
           keyframeFrequency="101" bootstrapInfoId="bootstrap0"
           drmAdditionalHeaderId="drmheader"
           drmAdditionalHeaderSetId="drmheaderset" />""")]
    assert remove_encrypted_media(media) == [media[0]]


# Generated at 2022-06-24 11:48:32.082581
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    assert write_unsigned_int(io.BytesIO(), 0x01020304) == b'\x00\x00\x01\x02'
    assert write_unsigned_int(io.BytesIO(), 0x03040506) == b'\x00\x03\x04\x05'
    assert write_unsigned_int(io.BytesIO(), 0x04050607) == b'\x00\x04\x05\x06'
    assert write_unsigned_int(io.BytesIO(), 0x05060708) == b'\x00\x05\x06\x07'



# Generated at 2022-06-24 11:48:38.222572
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    import os
    try:
        test_file_path = os.path.join(os.path.dirname(__file__), 'bootstrap_test')
        with open(test_file_path, 'rb') as f:
            bootstrap_bytes = f.read()
    except IOError:
        from ..test import skip_if_no_network
        skip_if_no_network()
        assert False
    return read_bootstrap_info(bootstrap_bytes)



# Generated at 2022-06-24 11:48:45.367054
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv_url = 'L2Jpbi9CdWlsZC9SZWxlYXNlL0FuZHJvaWQgT0YvYXBpLTEzL3Rlc3QvdXRpbGl0aWVzL2xpdmV0aW1lLzEyOC9yZmMvQlVJTEQxMjgtV0NCQ19DT1VOVF8xMjhfMjAxNzAyMjUxODMyMjEubXA0'
    flv_data = compat_b64decode(flv_url)
    box_info = FlvReader(flv_data).read_bootstrap_info()
    assert box_info



# Generated at 2022-06-24 11:48:49.979558
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Todo: Unit test this method without the internet connection
    url = 'http://fake.url/fake.f4m'
    ydl = YoutubeDL()
    ydl.urlopen = MagicMock()
    ydl.urlopen.side_effect = lambda url: MagicMock()
    ydl.urlopen.side_effect.geturl = lambda: url


# Generated at 2022-06-24 11:48:55.470616
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    f = io.BytesIO()
    write_unsigned_int(f, 1)
    assert f.getvalue() == b'\x00\x00\x00\x01'
    f.seek(0)
    write_unsigned_int(f, 255)
    assert f.getvalue() == b'\x00\x00\x00\xFF'
    f.seek(0)
    write_unsigned_int(f, 256)
    assert f.getvalue() == b'\x00\x00\x01\x00'
    f.seek(0)
    write_unsigned_int(f, 4294967295)
    assert f.getvalue() == b'\xFF\xFF\xFF\xFF'
test_write_unsigned_int()



# Generated at 2022-06-24 11:49:05.176599
# Unit test for method read_box_info of class FlvReader

# Generated at 2022-06-24 11:49:17.435520
# Unit test for function read_bootstrap_info

# Generated at 2022-06-24 11:49:26.615953
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    def _write_and_read(x):
        stream = io.BytesIO()
        write_unsigned_int_24(stream, x)
        stream.seek(0)
        return compat_struct_unpack('!I', b'\x00' + stream.read(3))[0]
    assert _write_and_read(0) == 0
    assert _write_and_read(0xffffff) == 0xffffff
    assert _write_and_read(0xffffff + 1) == 0x1ffffff
    assert _write_and_read(0xffffffff) == 0xffffffff



# Generated at 2022-06-24 11:49:30.364404
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    data = b'\x00\x01\x02\x03\xFF\xFF\xFF\xFF'
    for i in range(len(data)):
        fr = FlvReader(data)
        fr.read_bytes(i)
        assert fr.read_unsigned_char() == i

# Generated at 2022-06-24 11:49:41.067695
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        b'<manifest xmlns="http://ns.adobe.com/f4m/1.0"></manifest>')
    assert get_base_url(manifest) is None

    manifest = compat_etree_fromstring(
        b'<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        b'<baseURL></baseURL></manifest>')
    assert get_base_url(manifest) is None

    manifest = compat_etree_fromstring(
        b'<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        b'<baseURL> </baseURL></manifest>')
    assert get_base_url(manifest) == ''

    manifest = compat_et

# Generated at 2022-06-24 11:49:48.567037
# Unit test for function build_fragments_list

# Generated at 2022-06-24 11:49:59.200428
# Unit test for constructor of class FlvReader
def test_FlvReader():
    data = (
        b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
        b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    reader = FlvReader(data)
    assert reader.read_unsigned_long_long() == 0
    assert reader.read_unsigned_int() == 0
    assert reader.read_unsigned_char() == 0



# Generated at 2022-06-24 11:50:05.682997
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from .common import make_f4m_tests_data, print_abst

    for t in make_f4m_tests_data():
        f = FlvReader(t['abst'])
        abst = f.read_abst()
        print_abst(t['name'], abst)



# Generated at 2022-06-24 11:50:15.967818
# Unit test for function read_bootstrap_info

# Generated at 2022-06-24 11:50:27.234226
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    import struct
    from io import BytesIO

    def _test(expected, value):
        stream = BytesIO()
        write_unsigned_int_24(stream, value)
        res = stream.getvalue()
        assert len(res) == 3, (
            'Expected 3 bytes, got %d bytes.' % len(res))
        if expected is not None:
            assert res == expected, (
                'Expected %r, got %r.' % (expected, res))

    _test(b'\x01\x00\x00', 0x01000000)
    _test(b'\x00\x01\x00', 0x00010000)
    _test(b'\x00\x00\x01', 0x00000100)



# Generated at 2022-06-24 11:50:33.723064
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    data = (b'\x00\x00\x00K\xafrt\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00'
            b'\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01,\x00\x00\x00\x00\x00'
            b'\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    f = FlvReader(data)
    actual = f.read_afrt()

# Generated at 2022-06-24 11:50:46.102286
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    # Cases where exception should be raised (not enough bytes)
    assert False == False
    try:
        reader = FlvReader(b'\x01\x02\x03')
        reader.read_bytes(4)
        assert False
    except DataTruncatedError:
        pass
    # Cases where exception should NOT be raised (enough bytes)
    reader = FlvReader(b'\x01\x02\x03\x04')
    assert reader.read_bytes(4) == b'\x01\x02\x03\x04'
    reader = FlvReader(b'\x01\x02\x03\x04\x05\x06')
    assert reader.read_bytes(4) == b'\x01\x02\x03\x04'


# Generated at 2022-06-24 11:50:55.341159
# Unit test for function read_bootstrap_info

# Generated at 2022-06-24 11:50:55.997718
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    pass


# Generated at 2022-06-24 11:50:58.790314
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError('foo')
    except DataTruncatedError as err:
        assert str(err) == 'foo'


# Generated at 2022-06-24 11:51:04.801348
# Unit test for constructor of class F4mFD
def test_F4mFD():
    dummy_url = 'http://dummy_url/manifest.f4m'

    # Test constructor using a F4mInfoExtractor
    dummy_info = {
        'url': dummy_url,
        'id': 'dummy_id',
        'extractor': DummyIE({}),
    }
    fd = F4mFD(DummyYdl(), dummy_info)
    assert fd._man_url == dummy_url
    assert fd._ie == dummy_info['extractor']
    assert fd._ie_key == 'dummy_id'

    # Test constructor using a YoutubeIE
    dummy_info = {
        'url': dummy_url,
        'id': 'dummy_id',
        'extractor': 'Youtube',
        'extractor_key': 'Youtube',
    }

# Generated at 2022-06-24 11:51:15.326861
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    # The file was obtained by downloading the first fragment of
    # http://www.collegerama.tudelft.nl/Mediasite/Play/063d7c39dcbb41a2a6c59d96fdda3f811d
    # and converting it from flv to mp4 format with ffmpeg
    import os
    path = os.path.join(os.path.dirname(__file__), 'test.mp4')
    with open(path, 'rb') as f:
        f.seek(13)
        bootstrap_box = f.read(120)
    info = read_bootstrap_info(bootstrap_box)

# Generated at 2022-06-24 11:51:21.420605
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    bytes_io = io.BytesIO()
    write_unsigned_int(bytes_io, 2)
    assert bytes_io.getvalue() == b'\x00\x00\x00\x02'
    bytes_io = io.BytesIO()
    write_unsigned_int(bytes_io, 0x01020304)
    assert bytes_io.getvalue() == b'\x01\x02\x03\x04'



# Generated at 2022-06-24 11:51:29.707097
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    # Test case 1
    r = FlvReader(b'\x00\x00\x00\x05')
    assert r.read_unsigned_int() == 5

    # Test case 2
    r = FlvReader(b'\x00\x00\x00\x04\x00\x00\x00\x05')
    assert r.read_unsigned_int() == 4
    assert r.read_unsigned_int() == 5

# Generated at 2022-06-24 11:51:33.177296
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    from ..compat import compat_struct_pack
    # Test the case of one byte
    flv = FlvReader(compat_struct_pack('!B', 0xAB))
    assert flv.read_unsigned_char() == 0xAB



# Generated at 2022-06-24 11:51:39.315428
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    res_stream = io.BytesIO()
    write_unsigned_int(res_stream, 688)
    assert res_stream.getvalue() == b'\x00\x00\x02b'
    res_stream = io.BytesIO()
    write_unsigned_int(res_stream, 1)
    assert res_stream.getvalue() == b'\x00\x00\x00\x01'



# Generated at 2022-06-24 11:51:49.529255
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    stream = io.BytesIO()
    write_metadata_tag(stream, b'\x02\x00\x0a\x6f\x6e\x4d\x65\x74\x61\x44\x61\x74\x61\x08\x00\x00\x00\x00\x00\x00')

# Generated at 2022-06-24 11:51:53.309728
# Unit test for function write_flv_header
def test_write_flv_header():
    from io import BytesIO
    from ..utils import strip_jsonp, url_basename
    stream = BytesIO()
    write_flv_header(stream)
    print(stream.getvalue())
    print(len(stream.getvalue()))


# Generated at 2022-06-24 11:52:02.099627
# Unit test for method read_unsigned_int of class FlvReader

# Generated at 2022-06-24 11:52:12.988450
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:52:22.153004
# Unit test for method read_abst of class FlvReader