

# Generated at 2022-06-24 11:42:19.515014
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError('Error')
    except DataTruncatedError as e:
        assert e.args[0] == 'Error'


# Generated at 2022-06-24 11:42:30.017559
# Unit test for function build_fragments_list
def test_build_fragments_list():
    bootstrap_info_str = """
        <bootstrapInfo version="1" profile="0" live="1" update="0"
        timeScale="1000" currentMediaTime="0"
        smpteTimeCodeOffset="00:00:00:00"
        movieIdentifier="">
        <segmentRunTable>
          <segmentRun segmentRunEntry="0" fragmentRunTableCount="3"/>
        </segmentRunTable>
        <fragmentRunTablePresent>true</fragmentRunTablePresent>
        </bootstrapInfo>
    """
    bootstrap_info_xml = compat_etree_fromstring(
        fix_xml_ampersands(bootstrap_info_str))
    bootstrap_info_xml_b64 = bootstrap_info_xml.text
    bootstrap_info_bytes = compat_b64

# Generated at 2022-06-24 11:42:34.498676
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    s = '\x00\x00\x00\xff\xff\xff\xff\xff'
    f = FlvReader(s)
    assert f.read_unsigned_long_long() == (255**4 + 255**3 +
                                           255**2 + 255)
    assert f.read_unsigned_long_long() == 0



# Generated at 2022-06-24 11:42:37.177451
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    reader = FlvReader(compat_struct_pack('!BB', 0x04, 0x00))
    assert reader.read_unsigned_char() == 0x04
    assert reader.read_unsigned_char() == 0x00



# Generated at 2022-06-24 11:42:40.580526
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    for val in [1, 256, 2**32 - 1]:
        stream = io.BytesIO()
        write_unsigned_int(stream, val)
        assert compat_struct_unpack('!I', stream.getvalue())[0] == val



# Generated at 2022-06-24 11:42:52.007975
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:42:57.587944
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    from .fragment import prepend_flv_header

# Generated at 2022-06-24 11:43:09.830074
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-24 11:43:16.116079
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    reader_test = FlvReader(b'\x00\x00\x00\x01\x00\x02\x00\x03')
    assert reader_test.read_unsigned_char() == 0
    assert reader_test.read_unsigned_char() == 1
    assert reader_test.read_unsigned_char() == 2
    assert reader_test.read_unsigned_char() == 3


# Generated at 2022-06-24 11:43:19.999771
# Unit test for constructor of class F4mFD
def test_F4mFD():
    """
    Unit test for F4mFD constructor
    """
    dummy_ydl = object()
    dummy_params = object()
    f4mFD = F4mFD(dummy_ydl, dummy_params)
    # Assert required attributes are created
    assert f4mFD.ydl is not None
    assert f4mFD.params is not None



# Generated at 2022-06-24 11:43:28.250600
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    filepath = 'test.f4m'
    outtmpl = 'out.mp4'

    class DummyF4MDateIE(InfoExtractor):
        IE_NAME = 'dummyF4MDate'
        _VALID_URL = r'(?:http://)?(?:\w+\.)?dummyF4MDate\.com/'
        ie_key = 'dummyF4MDate'


# Generated at 2022-06-24 11:43:36.510024
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:43:46.119981
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    """
    Test method FlvReader.read_unsigned_long_long
    """
    bytes_str = (b'\x00\x00\x00\x00\x00\x00\x00\x01'
                 b'\x00\x00\x00\x00\x00\x00\x00\x13'
                 b'\x00\x00\x00\x00\x00\x00\x00\x44'
                 b'\x00\x00\x00\x00\x00\x00\x01\x00'
                 b'\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF')
    flv_reader = FlvReader(bytes_str)

# Generated at 2022-06-24 11:43:50.837756
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    test_data_file_path = "tests/data/unsigned_int"
    with open(test_data_file_path, "rb") as test_data_file:
        test_data = test_data_file.read()
    flv_reader = FlvReader(test_data)
    assert flv_reader.read_unsigned_int() == 4
    assert flv_reader.read_unsigned_int() == 0x000F000B
    assert flv_reader.read_unsigned_int() == 0x01234567


# Generated at 2022-06-24 11:43:58.713045
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    write_unsigned_int(stream, 0)
    assert stream.getvalue() == b'\x00\x00\x00\x00'
    stream = io.BytesIO()
    write_unsigned_int(stream, 3)
    assert stream.getvalue() == b'\x00\x00\x00\x03'
    stream = io.BytesIO()
    write_unsigned_int(stream, (1 << 32) - 1)
    assert stream.getvalue() == b'\xff\xff\xff\xff'



# Generated at 2022-06-24 11:44:11.330691
# Unit test for function read_bootstrap_info

# Generated at 2022-06-24 11:44:18.306065
# Unit test for function get_base_url
def test_get_base_url():
    assert get_base_url(io.BytesIO(b'')) is None
    assert get_base_url(io.BytesIO(b'<manifest/>')) is None
    assert get_base_url(io.BytesIO(b'<manifest><baseURL> </baseURL></manifest>')) == ' '
    assert get_base_url(io.BytesIO(b'<manifest xmlns="http://ns.adobe.com/f4m/1.0"><baseURL/></manifest>')) is None
    assert get_base_url(io.BytesIO(b'<manifest xmlns="http://ns.adobe.com/f4m/1.0"><baseURL> </baseURL></manifest>')) == ' '

# Generated at 2022-06-24 11:44:28.961276
# Unit test for function get_base_url
def test_get_base_url():
    base_url = get_base_url(compat_etree_fromstring('''
<manifest
  xmlns="http://ns.adobe.com/f4m/1.0">
  <baseURL>http://example.com</baseURL>
</manifest>
    '''))
    assert base_url == 'http://example.com'

    base_url = get_base_url(compat_etree_fromstring('''
<manifest xmlns="http://ns.adobe.com/f4m/2.0">
  <media baseURL="http://example.com"/>
</manifest>
    '''))
    assert base_url == 'http://example.com'



# Generated at 2022-06-24 11:44:40.469086
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    s = b'\x00\x00\x00^\xafrt\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00C\x00\x00\x00c'
    p = FlvReader(s)
    assert p.read_afrt() == {'fragments':
                             [{'discontinuity_indicator': None, 'ts': 67, 'duration': 100, 'first': 1}]}



# Generated at 2022-06-24 11:44:45.104246
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Test case for method real_download of class F4mFD
    class Opts:
        _ = {}
        test = False

    # Placeholder for global object ydl.
    ydl = None
    # Placeholder for global object ydl_opts.
    ydl_opts = Opts()


# Generated at 2022-06-24 11:44:57.639725
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-24 11:45:05.805106
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    data = b'abc\x00\x01\x02'
    reader = FlvReader(data)

    assert reader.read_bytes(1) == b'a'
    assert reader.read_bytes(3) == b'bc\x00'
    assert reader.read_bytes(3) == b'\x01\x02'

    reader = FlvReader(b'')
    try:
        reader.read_bytes(1)
        assert 0, 'Should not reach here'
    except DataTruncatedError:
        pass
    except Exception:
        assert 0, 'Should not raise any other exception here'



# Generated at 2022-06-24 11:45:07.988393
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    write_unsigned_int(stream, 4294967295)
    assert stream.getvalue() == b'\xff\xff\xff\xff'
# End of unit test



# Generated at 2022-06-24 11:45:10.543288
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    s = io.BytesIO()
    write_unsigned_int_24(s, 0x12345678)
    assert s.getvalue() == b'\x34\x56\x78'



# Generated at 2022-06-24 11:45:22.791182
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-24 11:45:28.367285
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    reader = FlvReader(compat_b64decode(b'AAIA'))
    assert reader.read_unsigned_long_long() == 65437


# Generated at 2022-06-24 11:45:37.970376
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-24 11:45:44.626315
# Unit test for function build_fragments_list
def test_build_fragments_list():
    # Simple test case
    boot_info = {
        'segments': [{
            'segment_run': [(1, 1), (2, 1)],
        }],
        'fragments': [{
            'fragments': [{
                'first': 0,
                'ts': 0,
                'duration': 5,
                'discontinuity_indicator': None,
            }, {
                'first': 1,
                'ts': 5,
                'duration': 5,
                'discontinuity_indicator': None,
            }],
        }],
        'live': False,
    }
    assert build_fragments_list(boot_info) == [(1, 0), (2, 1)]

    # Live stream test case - the one from Rai

# Generated at 2022-06-24 11:45:58.557427
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    test_data = (
        (b'\x00\x00\x00\x00', 0, b''),
        (b'\x00\x00\x00\x03', 3, b''),
        (b'\x00\x00\x00\x0c\x00\x00\x00\x01', 12, b''),
        (b'\x00\x00\x00\x17\x00\x00\x00\x01', 23, b''),
        (b'\x00\x00\x00\x05test', 5, b'test'),
        (b'\x00\x00\x00\x0b\x00\x00\x00\x01test', 11, b'test'),
    )

# Generated at 2022-06-24 11:46:05.343859
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    flv_content = compat_struct_pack('!I I I I', 12, 0x15, 1, 1)

    reader = FlvReader(flv_content)

    assert (reader.read_bytes(4) == flv_content[0:4])
    assert (reader.read_bytes(3) == flv_content[4:7])
    assert (reader.read_bytes(1) == flv_content[7:8])
    try:
        reader.read_bytes(1)
        assert(False == True)
    except DataTruncatedError:
        assert(True == True)



# Generated at 2022-06-24 11:46:08.188160
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError()
    except DataTruncatedError as e:
        assert str(e) == 'data truncated'



# Generated at 2022-06-24 11:46:16.160353
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    # The following file was created with the adobe tool mp42f4f
    # echo "dump flv C:\Users\jean\Downloads\a.flv -s" | cmd /C
    # C:\adobe\adobe_media_server_5_developer_edition\tools\mp42f4f\mp42f4f.exe
    with io.open('test/bootstrapinfo.flv', 'rb') as fd:
        flv_reader = FlvReader(fd.read())
    bootstrap_info = flv_reader.read_bootstrap_info()

# Generated at 2022-06-24 11:46:26.834257
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    import unittest
    from ..compat import compat_urllib_request

    class TestReadBootstrapInfo(unittest.TestCase):
        def do_test(self, data):
            with open('/tmp/test.dump', 'wb') as f:
                f.write(data)

# Generated at 2022-06-24 11:46:29.957468
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    test_data = b'\x00\x00\x00\x1b' + b'abst' + b'\x00' + b'\x00' + b'\x00' + b'\x00'
    reader = FlvReader(test_data)
    assert reader.read_unsigned_long_long() == 27



# Generated at 2022-06-24 11:46:40.887433
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-24 11:46:49.174357
# Unit test for function get_base_url
def test_get_base_url():
    tests = [
        (
            '<manifest><baseURL>http://example.com</baseURL></manifest>',
            'http://example.com'
        ),
        (
            '<manifest><media><baseURL>http://example.com</baseURL></media></manifest>',
            'http://example.com'
        ),
        (
            '<manifest><media><url>http://example.com</url></media></manifest>',
            None
        ),
    ]

    for xml, url in tests:
        assert get_base_url(compat_etree_fromstring(xml)) == url



# Generated at 2022-06-24 11:46:58.819270
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    flv = FlvReader(
        compat_struct_pack('!I', 1) +
        compat_struct_pack('!I', 2) +
        compat_struct_pack('!I', 3) +
        compat_struct_pack('!I', 4) +
        compat_struct_pack('!I', 0xFFFFFFFF)
    )
    assert flv.read_unsigned_int() == 1
    assert flv.read_unsigned_int() == 2
    assert flv.read_unsigned_int() == 3
    assert flv.read_unsigned_int() == 4
    assert flv.read_unsigned_int() == 0xFFFFFFFF



# Generated at 2022-06-24 11:47:04.211618
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-24 11:47:10.993742
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    # data from https://www.adobe.com/devnet/f4v.html
    sample = b'\x00\x00\x00\x01\x00\x00\x00\x01'
    f = FlvReader(sample)
    assert f.read_unsigned_long_long() == 1
    assert f.read_unsigned_long_long() == 1


# Generated at 2022-06-24 11:47:14.054808
# Unit test for function get_base_url
def test_get_base_url():
    f = get_base_url(compat_etree_fromstring(_TEST_MANIFEST))
    assert f == 'http://example.com'



# Generated at 2022-06-24 11:47:22.572859
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    """
    Test the method read_bytes of class FlvReader
    """
    reader = FlvReader(b'1234\x00\x00\x00\x00')
    assert reader.read_bytes(1) == b'1'
    assert reader.read_bytes(3) == b'234'
    assert reader.read_bytes(4) == b'\x00\x00\x00\x00'
    try:
        reader.read_bytes(1)
        assert False
    except DataTruncatedError as e:
        assert e.message == 'FlvReader error: need 1 bytes while only 0 bytes got'


# Generated at 2022-06-24 11:47:30.209551
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info(): # pragma: no cover
    import json


# Generated at 2022-06-24 11:47:40.837243
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    flv_reader = FlvReader(b'\x01\x00\x00\x00abcd\x05\x00\x00\x00efgh')
    box_info = flv_reader.read_box_info()
    assert box_info == (1, b'abcd', b'')

    box_info = flv_reader.read_box_info()
    assert box_info == (6, b'efgh', b'')

    flv_reader = FlvReader(b'\x00\x00\x00\x00abcd\x00\x00\x00\x00\x00\x00\x00\x06efgh')
    box_info = flv_reader.read_box_info()

# Generated at 2022-06-24 11:47:52.625857
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..compat import compat_urlopen
    from ..downloader import FakeHttpDict
    from io import BytesIO

    def get_content(url):
        for line in open(url, 'rb').read().splitlines():
            fields = line.decode('utf-8').split(' ')
            yield FakeHttpDict({
                'location': 'http://video.example.com' + fields[0],
                'status': '200',
                'content-type': fields[1],
            }, compat_urlopen(url).read())

    url = 'https://github.com/ytdl-org/youtube-dl/blob/master/test/bootstrapinfo'
    downloader = YoutubeDL(params={'noplaylist': True})
    downloader.fd = FragmentFD(get_content(url), False)

# Generated at 2022-06-24 11:47:57.138674
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    metadata = b'1'
    b = io.BytesIO()
    write_metadata_tag(b, metadata)
    assert b.getvalue() == b'\x12\x00\x00\x01\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01'



# Generated at 2022-06-24 11:48:04.873395
# Unit test for function remove_encrypted_media

# Generated at 2022-06-24 11:48:10.482365
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    info = FlvReader(open('test/test.abst', 'rb').read()).read_bootstrap_info()
    assert info['segments'][0]['segment_run'][0] == (1, 1)
    assert info['fragments'][0]['fragments'][0]['duration'] == 3000


# Generated at 2022-06-24 11:48:22.593397
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    f = FlvReader(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08')
    assert f.read_unsigned_char() == 0
    assert f.read_unsigned_char() == 1
    assert f.read_unsigned_char() == 2
    assert f.read_unsigned_char() == 3
    assert f.read_unsigned_char() == 4
    assert f.read_unsigned_char() == 5
    assert f.read_unsigned_char() == 6
    assert f.read_unsigned_char() == 7
    assert f.read_unsigned_char() == 8

# Generated at 2022-06-24 11:48:28.513669
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    data = b'\x1b\x00\x00\x00' + b'asrt' + b'\x00'*11 + b'\x01' + b'\x0b\x00\x00\x00' + b'afrt' + b'\x00'*7
    reader = FlvReader(data)
    assert reader.read_box_info() == (27, b'asrt', b'\x00'*11 + b'\x01' + b'\x0b\x00\x00\x00' + b'afrt' + b'\x00'*7)

# Generated at 2022-06-24 11:48:38.834276
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest>'
        '    <baseURL>base</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'base'
    manifest = compat_etree_fromstring(
        '<manifest>'
        '    <baseURL> base </baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'base'
    manifest = compat_etree_fromstring(
        '<manifest>'
        '    <baseurl>base</baseurl>'
        '</manifest>')
    assert get_base_url(manifest) is None
    manifest = compat_etree_fromstring(
        '<manifest></manifest>')
    assert get_

# Generated at 2022-06-24 11:48:43.959197
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    import binascii
    stream=io.BytesIO()
    write_flv_header(stream)
    write_metadata_tag(stream,b'\x02\x00\x10@author\x00\x03\x00\x06\x00\x00\x00Golshifteh\x00\x04\x00')
    f=open("out.flv",'wb')
    f.write(stream.getvalue())
    f.close()


# Generated at 2022-06-24 11:48:53.298294
# Unit test for function build_fragments_list

# Generated at 2022-06-24 11:49:05.085665
# Unit test for constructor of class FlvReader

# Generated at 2022-06-24 11:49:17.353571
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    data_str = b'\x00\x00\x00\x00'  # box_size
    data_str += b'\xaf\xab\x23\xde'  # box_type: afrt
    data_str += b'\x01'  # version
    data_str += b'\x00\x00\x00'  # flags
    data_str += b'\x00\x00\x01\x58'  # time scale: 600
    data_str += b'\x01'  # QualityEntryCount
    data_str += b'\x06\x63\x6f\x6e\x74\x72\x6f\x6c'  # QualitySegmentUrlModifiers: control

# Generated at 2022-06-24 11:49:28.431270
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    info_dict = {
        'url': 'https://p-events-delivery.akamaized.net/18oijbasfvuhbfsdvoijhbsfdvljkb6/m3u8/hls_vod_mvp2_1280x720_500.mp4.m3u8',
        'manifest_url': 'http://c.brightcove.com/services/mobile/streaming/index/rendition.f4m',
        'manifest_type': 'f4m'
    }
    # Create a temporary file to store the downloaded segments
    temp_file_name = tempfile.NamedTemporaryFile(suffix='.flv')
    temp_file_name.close()
    ydl = YoutubeDL()
    ydl.params = {}

    # Test the real_download method

# Generated at 2022-06-24 11:49:39.251217
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    import base64

# Generated at 2022-06-24 11:49:41.691395
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    s = b'\x01\x02\x03\x04\x00\x10\x20\x30'
    f = FlvReader(s)
    assert f.read_string() == b'\x01\x02\x03\x04'



# Generated at 2022-06-24 11:49:48.566374
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    print('Testing FlvReader.read_asrt')
    input_ = b'\x00\x00\x00\x1B\x61\x73\x72\x74\x01\x63\x6F\x6D\x6D\x6F\x6E\x00\x00\x00\x01\x00\x00\x00\x07\x00\x00\x00\x01\x00\x00\x00\x01'
    output = {'segment_run': [(7, 1)]}
    f = FlvReader(input_)
    res = f.read_asrt()
    assert res == output
    print('Success')


# Generated at 2022-06-24 11:49:50.348804
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    obj = DataTruncatedError()
    assert str(obj) == ''



# Generated at 2022-06-24 11:50:01.514066
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    # Generate a string of length 1
    s = compat_struct_pack('!B', 5) + b'\x00'
    # Generate a string of length 2, which is valid utf-8
    s += '5\xf0\x9f\x8c\x9f\x00'.encode('utf-8')
    # Generate a nul character in the string, which is invalid utf-8
    s += b'\x05\x00\xf0\x9f\x8c\x9f\x00'
    # Generate a string of length 1 which contains an invalid utf-8 character
    s += b'\x05\xed\xA0\x80\x00'
    # Generate an empty string
    s += b'\x00\x00'

# Generated at 2022-06-24 11:50:12.531461
# Unit test for function build_fragments_list

# Generated at 2022-06-24 11:50:16.541824
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    s = b'testing123\x00testing456\x00'
    flv = FlvReader(s)
    s1 = flv.read_string()
    assert s1 == b'testing123'
    s2 = flv.read_string()
    assert s2 == b'testing456'



# Generated at 2022-06-24 11:50:19.281118
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    flvReader = FlvReader(b'\x00')
    assert flvReader.read_unsigned_char() == 0



# Generated at 2022-06-24 11:50:31.797741
# Unit test for function get_base_url

# Generated at 2022-06-24 11:50:39.997042
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    from ..test import read_test_data
    bootstrap_bytes = read_test_data('vevo_bootstrap_info.bin')
    bootstrap_info = read_bootstrap_info(bootstrap_bytes)
    assert bootstrap_info['segments'] == [
        {'segment_run': [(0, 1)]},
        {'segment_run': [(1, 1)]},
        {'segment_run': [(2, 1)]},
    ]

# Generated at 2022-06-24 11:50:50.474375
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    # Test 1: when tag should not be removed, keep it
    test_1 = """<media url="http://example.com/path/segment-1.ts"
                bootstrapInfoId="bootstrap1"
                drmAdditionalHeaderId="0" drmAdditionalHeaderSetId="0"
                mediaType="audio" duration="15000">
                <metadata><![CDATA[]]></metadata>
                </media>"""
    media_1 = compat_etree_fromstring(test_1)
    assert media_1 == remove_encrypted_media(media_1)

    # Test 2: when tag should be removed, do so

# Generated at 2022-06-24 11:50:56.122652
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    def check(val):
        res = io.BytesIO()
        write_unsigned_int(res, val)
        return res.getvalue() == compat_struct_pack('!I', val)

    assert check(0)
    assert check(1)
    assert check(0x12345678)
    assert check(0xffffffff)



# Generated at 2022-06-24 11:51:08.187638
# Unit test for constructor of class FlvReader

# Generated at 2022-06-24 11:51:17.926246
# Unit test for method read_box_info of class FlvReader

# Generated at 2022-06-24 11:51:21.291232
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    s = io.BytesIO()
    write_unsigned_int_24(s, 0x12345678)
    _ = s.getvalue()
    assert _ == b'\x12\x34\x56'



# Generated at 2022-06-24 11:51:27.508577
# Unit test for function get_base_url
def test_get_base_url():
    manifest = (
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://localhost/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://localhost/'

    manifest = (
        '<manifest xmlns="http://ns.adobe.com/f4m/2.0">'
        '<baseURL>http://localhost/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://localhost/'

    manifest = '<manifest>http://localhost/</manifest>'
    assert get_base_url(manifest) is None



# Generated at 2022-06-24 11:51:30.386794
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    flv_reader = FlvReader(compat_struct_pack('!I', 0x00000001))
    assert flv_reader.read_unsigned_int() == 0x00000001



# Generated at 2022-06-24 11:51:32.295270
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    dte = DataTruncatedError()



# Generated at 2022-06-24 11:51:34.957555
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    r = FlvReader(b'\x00\x00\x00\x01')
    assert r.read_unsigned_int() == 1


# Generated at 2022-06-24 11:51:44.371952
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from streamlink.utils.test import FakeFD
    from pprint import pprint

# Generated at 2022-06-24 11:51:55.593613
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    metadata = b'\x02\x00\x0a\x6f\x6e\x4d\x65\x74\x61\x44\x61\x74\x61\x08\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    stream = io.BytesIO()
    write_flv_header(stream)
    write_metadata_tag(stream, metadata)
    stream.seek(0)
    actual = FlvReader(stream.read()).read_bootstrap_info()
    stream.close()

    expected = read_bootstrap_info(metadata)

    # Test Bootstrap version
    assert actual.get('bootstrap_version') == expected.get('bootstrap_version')

    # Test profile

# Generated at 2022-06-24 11:51:58.055460
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError('test exception')
    except DataTruncatedError as e:
        assert str(e) == 'test exception'


# Generated at 2022-06-24 11:51:59.973982
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    flv = FlvReader(b'\x01')
    assert flv.read_unsigned_char() == 1



# Generated at 2022-06-24 11:52:06.154137
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    reader = FlvReader(b'123\x00abc\x00\x00def\x00\x00\x00')
    assert reader.read_string() == b'123'
    assert reader.read_string() == b'abc'
    assert reader.read_string() == b''
    assert reader.read_string() == b'def'
    assert reader.read_string() == b''


# Generated at 2022-06-24 11:52:12.193406
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    f = io.BytesIO(b'123')
    reader = FlvReader(f)
    assert reader.read_bytes(3) == b'123'
    assert reader.read_bytes(2) == b'12'
    f = io.BytesIO(b'')
    reader = FlvReader(f)
    try:
        reader.read_bytes(1)
        assert False
    except DataTruncatedError:
        pass

# Generated at 2022-06-24 11:52:21.678004
# Unit test for method read_afrt of class FlvReader