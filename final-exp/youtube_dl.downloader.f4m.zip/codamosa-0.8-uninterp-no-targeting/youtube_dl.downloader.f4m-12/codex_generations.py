

# Generated at 2022-06-22 06:50:45.753158
# Unit test for function write_metadata_tag

# Generated at 2022-06-22 06:50:57.529883
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # Normal case
    assert FlvReader(b'\x00\x00\x00\x08\x66\x6f\x6f\x62\x61\x72').read_box_info() == (8, b'foob', b'ar')
    # Abnormal case 1
    assert FlvReader(b'\x00\x00\x00\x05\x66\x6f\x6f\x62\x61\x72').read_box_info() == (5, b'foob', b'ar')
    # Abnormal case 2
    assert FlvReader(b'\x00\x00\x00\x05\x66\x6f\x6f\x62\x61').read_box_info() == (5, b'foob', b'a')


# Generated at 2022-06-22 06:51:00.607438
# Unit test for constructor of class F4mFD
def test_F4mFD():
    F4mFD('http://localhost/index.f4m', 'test.flv')

if __name__ == '__main__':
    test_F4mFD()

# Generated at 2022-06-22 06:51:12.357636
# Unit test for function get_base_url
def test_get_base_url():
    manifest_xml = '''<manifest xmlns="http://ns.adobe.com/f4m/1.0">
    <baseURL>https://sample/test.m3u8</baseURL> </manifest>'''
    manifest = compat_etree_fromstring(manifest_xml)
    assert get_base_url(manifest) == 'https://sample/test.m3u8'
    manifest_xml = '''<manifest xmlns="http://ns.adobe.com/f4m/2.0">
    <baseURL>https://sample/test.m3u8</baseURL> </manifest>'''
    manifest = compat_etree_fromstring(manifest_xml)
    assert get_base_url(manifest) == 'https://sample/test.m3u8'
    manifest_

# Generated at 2022-06-22 06:51:19.252421
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-22 06:51:32.089800
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'segments': [{'segment_run': [(1, 8), (2, 3)]}],
        'fragments': [
            {'fragments': [{'first': 0, 'duration': 5000}, {'first': 1, 'duration': 5002}, {'first': 2, 'duration': 5002}, {'first': 3, 'duration': 5002}, {'first': 4, 'duration': 5002}, {'first': 5, 'duration': 2}, {'first': 6, 'duration': 2}, {'first': 7, 'duration': 2}]},
            {'fragments': [{'first': 8, 'duration': 2}, {'first': 9, 'duration': 2}]}],
        'live': False
    }

# Generated at 2022-06-22 06:51:35.987825
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError('test_msg')
        assert False
    except DataTruncatedError as e:
        assert e.args[0] == 'test_msg'
    except:
        assert False



# Generated at 2022-06-22 06:51:46.447857
# Unit test for function get_base_url
def test_get_base_url():
    assert get_base_url(compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')) == 'http://example.com/'
    assert get_base_url(compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL> \n http://example.com/ \n </baseURL>'
        '</manifest>')) == 'http://example.com/'

# Generated at 2022-06-22 06:51:49.630900
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    data = b'\x00'
    reader = FlvReader(data)
    assert reader.read_unsigned_char() == 0


# Generated at 2022-06-22 06:51:51.308304
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    f4mFD = F4mFD()
    f4mFD.real_download(None, None)



# Generated at 2022-06-22 06:52:28.159703
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    def to_hex(s):
        return b''.join(('%0.2x' % by).encode() for by in s)
    # test simple case
    assert FlvReader(b'\x00\x00\x00\x0c' + b'test').read_box_info() == (12, b'test', b'')
    # test case with size 1
    assert FlvReader(b'\x00\x00\x00\x01' + b'abcd' + (b'\x00' * 8)).read_box_info() == (16, b'abcd', b'')
    # test case with some real data

# Generated at 2022-06-22 06:52:38.729448
# Unit test for function get_base_url
def test_get_base_url():
    test_urls = {
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0" />': None,
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0"><baseURL>http://example.com</baseURL></manifest>': 'http://example.com',
        '<manifest xmlns="http://ns.adobe.com/f4m/2.0" />': None,
        '<manifest xmlns="http://ns.adobe.com/f4m/2.0"><baseURL>http://example.com</baseURL></manifest>': 'http://example.com',
    }
    for (test, expected) in test_urls.items():
        manifest_el = compat_etree_fromstring(test)
        url

# Generated at 2022-06-22 06:52:41.287477
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError('test_DataTruncatedError')
    except DataTruncatedError as e:
        assert str(e) == 'test_DataTruncatedError'


# Generated at 2022-06-22 06:52:44.577094
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    test_str = b'test'
    data = test_str + b'\x00'
    reader = FlvReader(data)
    res = reader.read_string()
    assert res == test_str



# Generated at 2022-06-22 06:52:56.614770
# Unit test for function build_fragments_list
def test_build_fragments_list():
    download_fragments.boot_info = {
        'live': False,
        'segments': [
            {
                'segment_run': [
                    (1, 1),
                    (2, 1),
                    (3, 1),
                ],
            },
        ],
        'fragments': [
            {
                'fragments': [
                    {'first': 1, 'ts': 0, 'duration': 10, 'discontinuity_indicator': None},
                ],
            },
        ],
    }
    assert [
        (1, 1),
        (2, 2),
        (3, 3),
    ] == build_fragments_list(download_fragments.boot_info)
# End of unit test



# Generated at 2022-06-22 06:53:01.397848
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    _, box_type, box_data = FlvReader(b'\x00\x00\x00\x10' + b'abcd' + b'abcd').read_box_info()
    assert box_type == b'abcd'
    assert box_data == b'abcd'
    _, box_type, box_data = FlvReader(b'\x00\x00\x00\x14' + b'abcd' + b'\x00\x00\x00\x00\x00\x00\x00\x00' + b'abcd').read_box_info()
    assert box_type == b'abcd'

# Generated at 2022-06-22 06:53:12.227983
# Unit test for function build_fragments_list

# Generated at 2022-06-22 06:53:19.440302
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    test_string = 'aáààâäåãæbcd'
    test_string_bytes = test_string.encode('utf-8') + b'\x00'
    reader = FlvReader(test_string_bytes)
    assert reader.read_string() == test_string_bytes[:-1].decode('utf-8')
test_FlvReader_read_string()



# Generated at 2022-06-22 06:53:28.240893
# Unit test for function get_base_url
def test_get_base_url():
    assert get_base_url(compat_etree_fromstring(
        b'<manifest><baseURL>http://example.com</baseURL></manifest>')) == 'http://example.com'
    assert get_base_url(compat_etree_fromstring(
        b'<manifest><baseURL>http://example.com</baseURL>'
        b'<prefix>\n</prefix></manifest>')) == 'http://example.com'
    assert get_base_url(compat_etree_fromstring(
        b'<manifest xmlns="http://ns.adobe.com/f4m/2.0"><baseURL>http://example.com</baseURL></manifest>')) == 'http://example.com'

# Generated at 2022-06-22 06:53:39.273652
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    metadata = b'\x02\x00\x0a\x6f\x6e\x4d\x65\x74\x61\x44\x61\x74\x61\x08\x00\x00\x00\x00\x00\x00\x00\x02\x00\x11\x6f\x6e\x4f\x66\x66\x69\x63\x65\x41\x74\x74\x61\x63\x6b\x01\x00\x0b\x66\x6c\x76\x32\x31\x2e\x30\x2e\x30\x2e\x30\x00\x04'
    test = io.BytesIO()

# Generated at 2022-06-22 06:55:05.378149
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-22 06:55:15.377596
# Unit test for method read_unsigned_int of class FlvReader

# Generated at 2022-06-22 06:55:21.500195
# Unit test for function write_flv_header
def test_write_flv_header():
    import io
    stream = io.BytesIO()
    write_flv_header(stream)
    val = stream.getvalue()
    assert val == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00', val
test_write_flv_header()


# Generated at 2022-06-22 06:55:25.305759
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-22 06:55:36.828217
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1b'
        b'asrt'
        b'\x00'
        b'\x00\x00\x00'
        b'\x01'
        b'\x00\x04'
        b'high'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x12'
        b'\x00\x00\x00\x0a'
    )

    reader = FlvReader(data)
    res = reader.read_asrt()
    assert res == {
        'segment_run': [
            (18, 10),
        ],
    }



# Generated at 2022-06-22 06:55:47.570718
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    assert remove_encrypted_media('') == ''
    assert remove_encrypted_media(
        '<media url="http://server.com/media?key=a" '
        'drmAdditionalHeaderId="1" '
        'drmAdditionalHeaderSetId="2" />') == ''
    assert remove_encrypted_media(
        '<media url="http://server.com/media?key=a" />') == (
        '<media url="http://server.com/media?key=a" />')
    assert remove_encrypted_media(
        '<media url="http://server.com/media?key=a" '
        'drmAdditionalHeaderSetId="2" />') == (
        '<media url="http://server.com/media?key=a" '
        'drmAdditionalHeaderSetId="2" />')
   

# Generated at 2022-06-22 06:56:00.066900
# Unit test for method read_box_info of class FlvReader

# Generated at 2022-06-22 06:56:04.488021
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    input_data = b'\x12\x34\x56\x78\x9a\xbc\xde\xf0'
    f = FlvReader(input_data)
    assert f.read_unsigned_long_long() == 0x123456789abcdef0

# Generated at 2022-06-22 06:56:13.778011
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-22 06:56:21.127697
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    testset = [
        # Empty
        '<media/>',
        # Not present
        '<media url="url" />',
        # Single
        '<media url="url" drmAdditionalHeaderId="id" />',
        # Multiple on the same tag
        '<media url="url" drmAdditionalHeaderId="id" drmAdditionalHeaderSetId="setId" />',
        # Multiple
        """<media url="url" drmAdditionalHeaderId="id"/>
           <media url="url2" drmAdditionalHeaderId="id2"/><media url="url3"/><media url="url4" drmAdditionalHeaderId="id3"/>""",
    ]

    def _check(testcase):
        info = compat_etree_fromstring(fix_xml_ampersands(testcase))

# Generated at 2022-06-22 06:57:31.613910
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    from .test_fragments import fake_base_url

    flv_reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x03')
    assert flv_reader.read_bytes(4) == b'\x00\x00\x00\x00'
    assert flv_reader.read_bytes(4) == b'\x00\x00\x00\x00'
    assert flv_reader.read_bytes(4) == b'\x00\x00\x00\x01'

# Generated at 2022-06-22 06:57:44.598590
# Unit test for constructor of class F4mFD
def test_F4mFD():
    class FakeYDL():
        def __init__(self):
            self.params = {}
        def report_warning(self, msg):
            pass
        def urlopen(self, url):
            class FakeURLHTTPResponse():
                def __init__(self):
                    self.code = 200
                    self.read = lambda : 'manifest text'
                    self.geturl = lambda : 'manifest url'
                    self.headers = {'content-type': 'text/xml charset=UTF-8'}
            return FakeURLHTTPResponse()

    ydl = FakeYDL()
    ydl.params['forceurl'] = False
    ydl.params['forcetitle'] = False
    ydl.params['forceduration'] = False
    ydl.params['forcethumbnail'] = False
    y

# Generated at 2022-06-22 06:57:56.320598
# Unit test for function build_fragments_list
def test_build_fragments_list():
    import os
    from .smil import read_bootstrap_info
    from .common import F4mTestCase
    from .common import read_filesize
    from .downloader import FragmentFD
    from .downloader import _resolve_fragment_url

    class TestHDSStream(F4mTestCase):
        def test_bootstrap_info(self):
            self.download_bootstrap()
            self.assertTrue(os.path.exists(self.bootstrap_path))


# Generated at 2022-06-22 06:58:02.602271
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    data = b'\x00\x01\x02\x03\x04\x05'
    f = FlvReader(data)
    try:
        f.read_bytes(4)
        f.read_bytes(4)
    except DataTruncatedError:
        f.close()
        return True
    f.close()
    return False


# Generated at 2022-06-22 06:58:07.170921
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    reader = FlvReader(b'abcdefg\x00ijklmn\x00')
    assert reader.read_string() == b'abcdefg'
    assert reader.read_string() == b'ijklmn'



# Generated at 2022-06-22 06:58:16.723786
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    expected_values = [(b'\x00\x00\x00', 0),
                       (b'\x00\x00\x01', 1),
                       (b'\x00\xff\xff', 65535),
                       (b'\xff\xff\xff', 16777215),
                       ]
    for expected_bytes, val in expected_values:
        stream = io.BytesIO()
        write_unsigned_int_24(stream, val)
        result = stream.getvalue()
        if result != expected_bytes:
            raise ValueError('write_unsigned_int_24 failed for value=%d, got %r' % (val, result))
test_write_unsigned_int_24()



# Generated at 2022-06-22 06:58:18.964575
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError('Exception message')
    except DataTruncatedError as e:
        assert str(e) == 'Exception message'



# Generated at 2022-06-22 06:58:28.717074
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    with open('tests/data/example.abst', 'rb') as f:
        abst_data = f.read()
    flv_reader = FlvReader(abst_data)
    abst = flv_reader.read_bootstrap_info()
    assert abst['fragments'][0]['fragments'][0]['first'] == 0
    assert abst['fragments'][0]['fragments'][0]['ts'] == 0
    assert abst['fragments'][0]['fragments'][0]['duration'] == 1000
    assert abst['segments'][0]['segment_run'][0] == (0, 2)



# Generated at 2022-06-22 06:58:39.924947
# Unit test for method read_box_info of class FlvReader

# Generated at 2022-06-22 06:58:49.775258
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    import binascii

# Generated at 2022-06-22 06:59:49.836976
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    from os.path import join
    from ..utils import encode_base_n
    from ..compat import compat_chr

# Generated at 2022-06-22 07:00:01.493823
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    flv_data = bytearray([
        0x00, 0x00, 0x00, 0x24, 0xab, 0x20, 0x20, 0x20,
        0x20, 0x13, 0xbb, 0x21, 0x00, 0x00, 0x00, 0x01,
        0x00, 0x00, 0x00, 0x08, 0xaa, 0x44, 0x93, 0xbb,
        0x09, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00])
    flv = FlvReader(flv_data)
    flv.read_bytes(8)
    assert flv.read_unsigned_char() == 19
    flv.read_bytes(3)
   