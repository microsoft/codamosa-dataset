

# Generated at 2022-06-22 06:50:33.310894
# Unit test for constructor of class F4mFD
def test_F4mFD():
    fd = F4mFD(params={'rtmp_live': True})
    assert fd.params['live'] == True



# Generated at 2022-06-22 06:50:45.754047
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    import unittest
    # Pass
    test1 = FlvReader(
        compat_struct_pack(
            '!I4s',
            8 + 4, b'abcd'
        ) + b'1234')
    assert test1.read_box_info() == (8, b'abcd', b'1234')
    # Fail
    test2 = FlvReader(b'')
    try:
        test2.read_box_info()
    except DataTruncatedError:
        pass
    else:
        raise unittest.SkipTest('FlvReader.read_box_info failed')
    # Pass

# Generated at 2022-06-22 06:50:56.001043
# Unit test for constructor of class FlvReader

# Generated at 2022-06-22 06:50:57.315436
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    raise Exception('Test not implemented')


# Generated at 2022-06-22 06:51:09.438060
# Unit test for function build_fragments_list
def test_build_fragments_list():
    from ..utils import encode_data_uri
    from .common import determine_ext
    from .f4m import read_f4m_manifest


# Generated at 2022-06-22 06:51:12.694407
# Unit test for constructor of class FlvReader
def test_FlvReader():
    f = open('test.bootstrap', 'rb')
    data = f.read()
    f.close()
    r = FlvReader(data)
    r.read_bootstrap_info()


# Generated at 2022-06-22 06:51:16.085330
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Failed to determine the code to be tested
    # Input arguments:
    #   filename = ?
    #   info_dict = ?
    # Expected output:
    #   assertEqual(?, ?)
    return



# Generated at 2022-06-22 06:51:24.965876
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    flv_reader = FlvReader(b'\x00\x00\x00\x00')
    assert flv_reader.read_unsigned_int() == 0
    flv_reader = FlvReader(b'\x00\x00\x00\x01')
    assert flv_reader.read_unsigned_int() == 1
    flv_reader = FlvReader(b'\xff\xff\xff\xff')
    assert flv_reader.read_unsigned_int() == 0xffffffff



# Generated at 2022-06-22 06:51:27.512605
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    assert  FlvReader(b'\x07').read_unsigned_char() == 7


# Generated at 2022-06-22 06:51:35.097657
# Unit test for constructor of class FlvReader
def test_FlvReader():
    flv_data = b'\x00\x00\x00\x21' + b'abst' + b'\x00' * 11 + b'segment run table'
    with FlvReader(flv_data) as reader:
        res = reader.read_bootstrap_info()
        assert res == {
            'segments': [
                {'segment_run': [],
            }],
            'fragments': [],
            'live': False,
        }



# Generated at 2022-06-22 06:51:50.416240
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    e = DataTruncatedError('test_message')
    assert e.message == 'test_message'



# Generated at 2022-06-22 06:51:57.357218
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    write_unsigned_int(stream, 1)
    write_unsigned_int(stream, 1<<8)
    write_unsigned_int(stream, 1<<16)
    write_unsigned_int(stream, 1<<24)
    assert stream.getvalue() == b'\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00'



# Generated at 2022-06-22 06:52:04.679055
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    _test_files = ['../test/files/test.flv']
    for test_file in _test_files:
        with io.open(test_file, 'rb') as f:
            flv_reader = FlvReader(f.read())
            box_size, box_type, box_data = flv_reader.read_box_info()
            assert box_size == len(flv_reader.read()) + 8
            assert box_type == b'FLV\x01'



# Generated at 2022-06-22 06:52:07.432288
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    assert write_unsigned_int(io.BytesIO(), 1) == b'\x00\x00\x00\x01'



# Generated at 2022-06-22 06:52:14.037864
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    import io
    import xml.etree.ElementTree as ET
    metadata = "metadata"
    data = io.BytesIO()
    write_metadata_tag(data, metadata)
    data.seek(0)
    assert data.read() == b'\x12\x00\x00\x00\x0c\x00\x00\x00\x00\x00\x00\x00metadata\x00\x00\x00\x10'


# Generated at 2022-06-22 06:52:24.107412
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    input_data = b'\x19\x00\x00\xa1\x00\x00\x00\x01\x00\x02\x00\x03\x00\x04'
    f = FlvReader(input_data)
    assert f.read_unsigned_int() == 0x001a
    assert f.read_unsigned_int() == 0xa100
    assert f.read_unsigned_int() == 0x0001
    assert f.read_unsigned_int() == 0x0200
    assert f.read_unsigned_int() == 0x0300
    assert f.read_unsigned_long_long() == 0x0000040000000000



# Generated at 2022-06-22 06:52:27.125326
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    test_input = b'\x00\x00\x00\x0Aabcd'
    test_output = FlvReader(test_input).read_unsigned_int()
    assert test_output == 10


# Generated at 2022-06-22 06:52:37.884881
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    from .common import open_mock, Response

    def check_write_metadata_tag(metadata, expected):
        encoded_metadata = compat_b64decode(metadata)
        write_metadata_tag(open_mock, encoded_metadata)
        assert open_mock.getvalue() == expected


# Generated at 2022-06-22 06:52:42.366749
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    data = compat_struct_pack('!I', 10) + \
          compat_struct_pack('!I', 20) + \
          compat_struct_pack('!I', 30)
    reader = FlvReader(data)
    assert reader.read_unsigned_int() == 10
    assert reader.read_unsigned_int() == 20
    assert reader.read_unsigned_int() == 30



# Generated at 2022-06-22 06:52:48.144608
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    from .common import FileDownloader
    from .fragment import FragmentFD
    from .rtmp import RTMPFD
    from .utils import (
        sanitize_open,
    )
    from ..compat import (
        compat_urllib_request,
    )
    from ..utils import (
        encode_compat_str,
        sanitize_open,
    )

    url = 'http://video.ted.com/talks/podcast/AlGore_2006-640.mp4'

# Generated at 2022-06-22 06:53:44.374219
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = b'\x00\x00\x00\x2A\x61\x73\x72\x74\x01\x00\x00\x00\x41\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x02\x00\x00\x00\x01'
    reader = FlvReader(data)
    assert reader.read_asrt() == {'segment_run': [(1, 1), (2, 1)]}



# Generated at 2022-06-22 06:53:47.735579
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    assert write_unsigned_int(io.BytesIO(), 0) == None
    assert write_unsigned_int(io.BytesIO(), 2147483647) == None
test_write_unsigned_int()



# Generated at 2022-06-22 06:53:59.443266
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-22 06:54:01.758803
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    reader = FlvReader(b'\x03')
    assert reader.read_unsigned_char() == 3



# Generated at 2022-06-22 06:54:03.614766
# Unit test for constructor of class F4mFD
def test_F4mFD():
    ydl = YoutubeDL()
    ydl.add_info_extractor(F4mFD())


# Generated at 2022-06-22 06:54:09.063050
# Unit test for function write_flv_header
def test_write_flv_header():
    f = io.BytesIO()
    write_flv_header(f)
    assert f.getvalue() == (
        b'FLV\x01\x05\x00\x00\x00\x09'
        b'\x00\x00\x00\x00')



# Generated at 2022-06-22 06:54:19.392524
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-22 06:54:29.412362
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..compat import unhexlify

# Generated at 2022-06-22 06:54:33.550337
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    assert (FlvReader(b'\x00\x00\x00\x05').read_unsigned_int() == 5)
    assert (FlvReader(b'\x00\x00\x05\x00').read_unsigned_int() == 130048)



# Generated at 2022-06-22 06:54:45.109329
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    data = b'\x00\x00\x00\x00'  # Box size: 0; Box type: b''; Box data:
    reader = FlvReader(data)
    box_size, box_type, box_data = reader.read_box_info()
    assert (box_size, box_type, box_data) == (0, b'', b'')
    assert reader.read() == b''

    data = b'\x00\x00\x00\x00'  # Box size: 0; Box type: b''; Box data:
    data += b'\x00'  # Box size: 1; Box type: b'\x00'; Box data:
    reader = FlvReader(data)
    box_size, box_type, box_data = reader.read_box_info()

# Generated at 2022-06-22 06:56:49.753222
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    test_tag = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    # default
    assert FlvReader(test_tag).read_bytes(len(test_tag)) == test_tag

    # read bytes over the tag
    assert FlvReader(test_tag).read_bytes(len(test_tag) + 1) == test_tag

    # read bytes less than tag
    assert FlvReader(test_tag).read_bytes(0) == b''



# Generated at 2022-06-22 06:57:01.028901
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    metadata = b'<?xml version="1.0"?><test></test>'
    metadata2 = b'<?xml version="1.0"?><test>/test>'
    expected_result = b'\x12\x00\x00\x1d\x00\x00\x00\x00\x00\x00\x00<?xml version="1.0"?><test></test>\x00\x00\x00\x1a'
    stream = io.BytesIO()
    write_metadata_tag(stream, metadata)
    assert stream.getvalue() == expected_result
    stream = io.BytesIO()
    try:
        write_metadata_tag(stream, metadata2)
    except compat_etree_fromstring:
        assert True
    else:
        assert False



# Generated at 2022-06-22 06:57:10.967311
# Unit test for constructor of class F4mFD
def test_F4mFD():
    from .utils import fake_urlopen

    f4m_url = 'http://test.se/man.f4m'
    # Cache the test url
    urlcache[f4m_url] = (urlcache_path(f4m_url), 'asd')
    # Open the test url
    urlh = fake_urlopen(f4m_url)
    # Empty parameters
    params = {}
    # Init the downloader
    f4mfd = F4mFD(urlh.geturl(), params)
    # Check if it's the right downloader
    assert f4mfd.can_download(urlh)
    # Check if it can extract the manifest
    assert f4mfd.can_extract(urlh, params)

    # The manifest

# Generated at 2022-06-22 06:57:21.227392
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    r = FlvReader(b'\x00\x00\x00\x08')
    assert r.read_unsigned_int() == 8
    r = FlvReader(b'\x00\x00\x00\x00')
    assert r.read_unsigned_int() == 0
    r = FlvReader(b'\x00\x00\x01\x00')
    assert r.read_unsigned_int() == 256
    r = FlvReader(b'\xff\xff\xff\xff')
    assert r.read_unsigned_int() == 4294967295
    r = FlvReader(b'\x00\x01\x00\x00')
    assert r.read_unsigned_int() == 65536


# Generated at 2022-06-22 06:57:31.860863
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    with open('tests/data/fragment.flv', 'rb') as fo:
        data = fo.read()
    reader = FlvReader(data)
    # Read bytes
    assert reader.read_bytes(1) == b'\x46'
    assert reader.read_bytes(1) == b'\x4c'
    assert reader.read_bytes(1) == b'\x56'
    assert reader.read_bytes(1) == b'\x01'
    # Read unsigned numbers
    assert reader.read_unsigned_long_long() == 0
    assert reader.read_unsigned_int() == 9
    assert reader.read_unsigned_char() == 5
    # Read string
    assert reader.read_string() == b'onMetaData'

# Generated at 2022-06-22 06:57:39.665363
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    assert FlvReader(b'\x00\x00\x00\x02').read_unsigned_int() == 2
    assert FlvReader(b'\x00\x00\x01\x00').read_unsigned_int() == 256
    assert FlvReader(b'\x00\x00\x00\x00').read_unsigned_int() == 0
    assert FlvReader(b'\xff\xff\xff\x7f').read_unsigned_int() == 2147483647


# Generated at 2022-06-22 06:57:41.732106
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\t\x00\x00\x00\x00'



# Generated at 2022-06-22 06:57:53.266216
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    import unittest
    from .test_fragment import read_manifest
    from .test_fragment import read_sample_manifests

    class TestFlvReader(unittest.TestCase):

        def test_read_abst(self):
            for manifest in read_sample_manifests():
                with read_manifest(manifest) as flv_reader:
                    abst = flv_reader.read_bootstrap_info()
                    self.assertTrue('segments' in abst)
                    self.assertTrue('fragments' in abst)

    return unittest.main()

test_read_abst = test_FlvReader_read_abst


# Generated at 2022-06-22 06:58:02.513585
# Unit test for constructor of class F4mFD
def test_F4mFD():
    import xml.etree.ElementTree as ET
    # Minimum valid f4m file.
    f4m_url = "http://www.example.com/movie.f4m"
    f4m_xml = """<?xml version="1.0" encoding="UTF-8"?>
<manifest xmlns="http://ns.adobe.com/f4m/1.0">
</manifest>"""
    f4m_content = f4m_xml.encode('utf-8')
    f4m_etree = ET.fromstring(f4m_content)

    f4m_fd = F4mFD("http://www.example.com/movie.f4m")
    f4m_fd.url_data = {f4m_url: f4m_content}

# Generated at 2022-06-22 06:58:14.398761
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    class ResultStream(io.BytesIO):

        def __init__(self):
            self.data = None
            io.BytesIO.__init__(self)

        def getvalue(self):
            return self.data

        def write(self, buf):
            if self.data is not None:
                self.data = self.data + buf
            else:
                self.data = buf

    metadata = b'\x02\x00\x0a\x6f\x6e\x4d\x65\x74\x61\x44\x61\x74\x61\x08'
    metadata += b'\x00\x00\x00\x03\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00'
    metadata