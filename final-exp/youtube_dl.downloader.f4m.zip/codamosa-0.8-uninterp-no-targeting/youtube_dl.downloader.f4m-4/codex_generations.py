

# Generated at 2022-06-22 06:50:57.746408
# Unit test for constructor of class FlvReader
def test_FlvReader():
    fd = io.BytesIO(
        b'\x00\x00\x00\x0Cabcd\x00\x00\x00\x00' +
        b'\x00\x00\x00\x0Cefgh\x00\x00\x00\x01' +
        b'\x00\x00\x00\x00\x00\x00\x00\x00' +
        b'\x00\x00\x00\x0Cijkl\x00\x00\x00\x02' +
        b'\x00\x00\x00\x00\x00\x00\x00\x00'
    )
    fr = FlvReader(fd)
    assert fr.read_string() == b'abcd'
    assert fr

# Generated at 2022-06-22 06:51:09.846616
# Unit test for constructor of class FlvReader
def test_FlvReader():
    """
    The sample data is extracted from an Adobe HTTP Dynamic Streaming video
    """

# Generated at 2022-06-22 06:51:14.735577
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    data_read_unsigned_char = io.BytesIO()
    data_read_unsigned_char.write(compat_struct_pack('!B', 0x30))
    data_read_unsigned_char.seek(0)
    print(FlvReader(data_read_unsigned_char).read_unsigned_char())

# Generated at 2022-06-22 06:51:21.278220
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    class FakeStream(object):
        def __init__(self):
            self.byte_str = b''

        def write(self, b_str):
            self.byte_str += b_str

    stream = FakeStream()
    # example value taken from a real HDS file
    frags = [(2, 3), (2, 4)]
    write_unsigned_int(stream, len(frags))
    assert stream.byte_str == b'\x00\x00\x00\x02'



# Generated at 2022-06-22 06:51:33.573100
# Unit test for constructor of class FlvReader
def test_FlvReader():
    data = (b'\x00\x00\x00\x2C\x61\x62\x73\x74\x00\x00\x00'
            b'\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00'
            b'\x00\xD8\x0A\x65\x6E\x64\x73\x00\x00\x00\x00')
    reader = FlvReader(data)

# Generated at 2022-06-22 06:51:42.405721
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    fd = io.BytesIO()
    write_unsigned_int_24(fd, 16777215)
    assert fd.getvalue() == b'\xff\xff\xff'
    fd = io.BytesIO()
    write_unsigned_int_24(fd, 0)
    assert fd.getvalue() == b'\x00\x00\x00'
    fd = io.BytesIO()
    write_unsigned_int_24(fd, 1677)
    assert fd.getvalue() == b'\x00\x06\xa5'
#


# Generated at 2022-06-22 06:51:46.374895
# Unit test for constructor of class F4mFD
def test_F4mFD():
    fd = F4mFD({
        'url': 'http://example.org/manifest.f4m',
        'outtmpl': '-',
    })
    info_dict = {}
    ret = fd.real_download('-', info_dict)
    assert False, 'Unexpected success'

if __name__ == '__main__':
    test_F4mFD()

# Generated at 2022-06-22 06:51:49.859420
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    test_string = 'a\x00b'
    reader = FlvReader(test_string)
    assert reader.read_string() == test_string[:-1]



# Generated at 2022-06-22 06:51:53.062485
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    bytes = compat_struct_pack('!I', 12) + b'abcd'
    f = FlvReader(bytes)
    assert f.read_unsigned_int() == 12
    assert f.read() == b'abcd'



# Generated at 2022-06-22 06:51:59.122180
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    test_str = b'\x00\x01\x02hello\x00\x03\x04\x05'
    reader = FlvReader(test_str)
    assert reader.read_string() == b'\x01\x02hello'
    assert reader.read_string() == b''


# Generated at 2022-06-22 06:52:48.136092
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-22 06:52:51.017765
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    reader = FlvReader(compat_struct_pack('!I', 0x12345678))
    assert reader.read_unsigned_int() == 0x12345678

# Generated at 2022-06-22 06:52:51.681688
# Unit test for constructor of class F4mFD
def test_F4mFD():
    assert F4mFD()

# Generated at 2022-06-22 06:53:05.195874
# Unit test for function get_base_url
def test_get_base_url():
    # Check empty base_url
    doc = compat_etree_fromstring('''
        <manifest xmlns="http://ns.adobe.com/f4m/1.0">
            <media baseURL=""/>
        </manifest>
    ''')
    assert get_base_url(doc) == ''

    # Check normal base_url
    doc = compat_etree_fromstring('''
        <manifest xmlns="http://ns.adobe.com/f4m/1.0">
            <media baseURL="http://example.com/"/>
        </manifest>
    ''')
    assert get_base_url(doc) == 'http://example.com/'

    # Check full url in a base_url

# Generated at 2022-06-22 06:53:15.573300
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from ytdl.F4mFD import F4mFD
    # Define some global variables to be used in the test function
    global test_filename, test_info_dict
    test_filename = 'file'

# Generated at 2022-06-22 06:53:24.748959
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    xmldoc = u'<media url="http://test.test" bootstrapInfoId="bootstrap62">' \
             u'<metadata>test</metadata>' \
             u'<drmAdditionalHeaderId>test</drmAdditionalHeaderId>' \
             u'<drmAdditionalHeaderSetId>test</drmAdditionalHeaderSetId>' \
             u'<media url="http://test.test" bootstrapInfoId="bootstrap62">' \
             u'<metadata>test</metadata>' \
             u'</media>' \
             u'</media>'
    treedoc = compat_etree_fromstring(xmldoc)
    assert len(remove_encrypted_media(treedoc)) == 1
    assert remove_encrypted_media(treedoc)[0].tag == 'media'



# Generated at 2022-06-22 06:53:29.457398
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    t = FlvReader(b'1234')
    assert t.read_bytes(1) == b'1'
    assert t.read_bytes(1) == b'2'
    assert t.read_bytes(2) == b'34'



# Generated at 2022-06-22 06:53:41.187516
# Unit test for constructor of class F4mFD
def test_F4mFD():
    from io import BytesIO
    from .extractor import gen_extractors
    from .extractor.common import InfoExtractor
    from .downloader.http import HttpFD

    class IE(InfoExtractor):
        _VALID_URL = 'http://foo.bar'
        _TEST = {
            'url': 'http://foo.bar',
            'info_dict': {
                'id': '0',
                'ext': 'f4m',
                'title': 'bla',
            }
        }

        def _real_extract(self, url):
            ext = F4mFD()
            ext.add_info_extractor(self)
            ext.download(self.IE_NAME, [self.url_result(url)])

    ie = IE()
    extractors = gen_extract

# Generated at 2022-06-22 06:53:53.153480
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    def _test_fragment_download(self, url, filename, info_dict):
        """ A wrapper class to simulate F4mFD._download_fragment """
        # This piece of code is almost a simplification of F4mFD._download_fragment
        self.report_fragment_download(info_dict, filename)
        ctx = self.get_temp_filename('fragment.tmp')
        tmp_file = open(ctx['tmpfilename'], 'wb')
        success = False
        down_data = None

# Generated at 2022-06-22 06:54:04.995116
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    data = b'\x00\x00\x00\x00'
    # test box size is 0
    reader = FlvReader(data)
    try:
        reader.read_box_info()
    except DataTruncatedError:
        pass
    # test box size is less than 8
    data = b'\x0a\x00\x00\x00' + b'\x00' * 6
    reader = FlvReader(data)
    try:
        reader.read_box_info()
    except DataTruncatedError:
        pass
    # test box size is 8
    data = b'\x08\x00\x00\x00' + b'\x00' * 8
    reader = FlvReader(data)
    reader.read_box_info()
    # test box size

# Generated at 2022-06-22 06:54:33.702614
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    """
    Test case for method read_unsigned_char of class FlvReader
    """
    assert FlvReader(b'\x00').read_unsigned_char() == 0
    assert FlvReader(b'\xff').read_unsigned_char() == 255



# Generated at 2022-06-22 06:54:45.256107
# Unit test for function build_fragments_list
def test_build_fragments_list():
    f = io.BytesIO()
    f.write(b'<bootstrapInfo version="3" profile="ADOBE"><segments/><fragments><fragmentDuration>2</fragmentDuration><timescale>1000</timescale><fragmentsTimeline><t><d>1</d></t></fragmentsTimeline></fragments></bootstrapInfo>')
    f.seek(0)
    root = compat_etree_fromstring(f.read())
    nodes = root.findall('.//t')
    test_boot_info = {}
    test_boot_info['live'] = False
    test_boot_info['fragments'] = []
    test_boot_info['segments'] = []
    test_fragments = []
    test_segment_run = []

# Generated at 2022-06-22 06:54:57.056694
# Unit test for function build_fragments_list

# Generated at 2022-06-22 06:54:59.753858
# Unit test for constructor of class F4mFD
def test_F4mFD():
    fd = F4mFD({}, None, None)


if __name__ == '__main__':
    test_F4mFD()

# Generated at 2022-06-22 06:55:08.576281
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    assert FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x01').read_unsigned_long_long() == 1
    assert FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x02').read_unsigned_long_long() == 2
    assert FlvReader(b'\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFE').read_unsigned_long_long() == 18446744073709551614


# Generated at 2022-06-22 06:55:20.456923
# Unit test for function build_fragments_list

# Generated at 2022-06-22 06:55:31.975336
# Unit test for function build_fragments_list

# Generated at 2022-06-22 06:55:40.862297
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    assert FlvReader(
        b'\x00\x00\x00\x04foo').read_unsigned_int() == 4
    assert FlvReader(
        b'\x00\x00\x00\xfffoo').read_unsigned_int() == 255
    assert FlvReader(
        b'\x00\x00\x01\x00foo').read_unsigned_int() == 256
    assert FlvReader(
        b'\xff\xff\xff\xfffoo').read_unsigned_int() == (1 << 32) - 1


# Generated at 2022-06-22 06:55:47.145939
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    tests = [
        (b'\x00\x00\x00\x00\x00\x00\x00\x00', 0),
        (b'\x01\x00\x00\x00\x00\x00\x00\x00', 1),
        (b'\xff\xff\xff\xff\xff\xff\xff\xff', (2 ** 64) - 1),
    ]
    for data, expected in tests:
        assert FlvReader(data).read_unsigned_long_long() == expected


# Generated at 2022-06-22 06:55:55.603697
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    from .test_fragments import _load_chunk
    buffer = _load_chunk('gB7GpzmTt9Y')
    f = FlvReader(buffer)
    def f2(expected):
        assert f.read_unsigned_int() == expected
    f2(0x00027869)
    f2(0x00000041)
    f2(0x00000000)
    f2(0x00000000)
    f2(0x0000014B)


# Generated at 2022-06-22 06:56:34.222672
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    from binascii import a2b_hex
    buffer = a2b_hex('2c0000006166 72740000000004000000010000000040000000040000000100000000'
                     '0000000a00000001000000000000000100000006000000010000000000000000000000'
                     '0000000a0000000200000000000000010000001600000001000000000000000000000000'
                     '0000000a00000003000000000000010000001700000001000000000000000000000000'
                     '0000000a00000004000000000000010000001b00000001000000000000000000000000'
                     '0000000a00000005000000000000010000001700000001000000000000000000000000'
                     '0000000a00000006000000000000010000001600000001000000000000000000000000')
    fr = FlvReader(buffer)
    fr.read_afrt()


# Generated at 2022-06-22 06:56:45.848979
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    from xml.etree import ElementTree as ET

    media = ET.XML('''
        <Media id="id" bitrate="2" width="1" height="1" url="http://test.url" type="video/mp4" bootstrapInfoId="bootstrap1">
            <Metadata duration="0.000000" creationdate="2019-01-01T00:00:00Z" url="http://test.url" />
        </Media>
    ''')
    res = remove_encrypted_media([media])
    assert res == [media]


# Generated at 2022-06-22 06:56:52.710064
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    import unittest
    import binascii

# Generated at 2022-06-22 06:56:56.712011
# Unit test for function write_flv_header
def test_write_flv_header():
    from .test import fake_tag_data
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'
test_write_flv_header()



# Generated at 2022-06-22 06:57:00.573058
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    reader = FlvReader('\x00\x00\x00\x1A' + 'A' * 26)
    assert reader.read_unsigned_int() == 0x1A


# Generated at 2022-06-22 06:57:09.054908
# Unit test for function write_flv_header
def test_write_flv_header():
    from ..utils import ensure_fd_or_path_to_fd

    fd = ensure_fd_or_path_to_fd('/tmp/test.flv')
    fd.seek(0)
    write_flv_header(fd)
    fd.close()
    from .m3u8.m3u8 import M3u8Parser
    p = M3u8Parser(headers={'Host': 'v10.lscache7.c.youtube.com'})

# Generated at 2022-06-22 06:57:13.487437
# Unit test for function write_flv_header
def test_write_flv_header():
    import io
    import struct
    f = io.BytesIO()
    write_flv_header(f)
    assert f.getvalue() == b'FLV\x01\x05\x00\x00\x00\t\x00\x00\x00\x00'



# Generated at 2022-06-22 06:57:15.644226
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError
    except DataTruncatedError as e:
        assert str(e) == ''



# Generated at 2022-06-22 06:57:27.139286
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-22 06:57:37.452238
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-22 06:59:25.600331
# Unit test for function build_fragments_list
def test_build_fragments_list():
    """ This is a test for the function build_fragments_list """
    # Test for the function build_fragments_list
    assert [(0, 0), (0, 1)] == build_fragments_list({
        'segments': [
            {'segment_run': [(0, 2)]},
        ],
        'fragments': [
            {'fragments': [
                {'first': 0, 'ts': 0, 'duration': 0,
                 'discontinuity_indicator': None},
            ]},
        ],
        'live': False,
    })



# Generated at 2022-06-22 06:59:35.992627
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    assert FlvReader(b'\x00\x00\x00\x0c\x61\x73\x72\x74\x01\x00\x00\x03\x00\x00\x00\x00\x00\x00\x00\x05\x6d\x6f\x6f\x6d\x05\x61\x70\x70\x6c\x65').read_asrt() == {'segment_run': [(0, 5), (5, 5)]}

# Generated at 2022-06-22 06:59:46.064307
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    from ..utils import encode_data_uri
    from io import BytesIO
    stream = BytesIO()
    write_unsigned_int(stream, 1)
    assert stream.getvalue() == b'\x00\x00\x00\x01'
    write_unsigned_int(stream, 4294967295)
    assert stream.getvalue() == b'\x00\x00\x00\x01\xff\xff\xff\xff'
    stream.write(b'\xff')
    write_unsigned_int(stream, 15)
    assert stream.getvalue() == b'\x00\x00\x00\x01\xff\xff\xff\xff\xff\x00\x00\x0f'

# Generated at 2022-06-22 06:59:52.643136
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Correct real_download with live stream
    man_url = 'http://multiplatform-f.akamaihd.net/i/multi/will/bunny/big_buck_bunny_,640x360_400,640x360_700,640x360_1000,950x540_1500,.f4m'
    info_dict = {
        'url': man_url,
        'ext': 'flv',
    }
    fd = F4mFD()
    fd.real_download('test.flv', info_dict)


if __name__ == '__main__':
    test_F4mFD_real_download()
    print("Done")

# Generated at 2022-06-22 07:00:03.449289
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    from ..utils import xml_to_dict
    filename = 'playlist.f4m'