

# Generated at 2022-06-22 06:51:04.068137
# Unit test for constructor of class FlvReader

# Generated at 2022-06-22 06:51:07.442414
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    file = io.BytesIO(compat_struct_pack('!B', 0xF0))
    reader = FlvReader(file)
    assert reader.read_unsigned_char() == 0xF0



# Generated at 2022-06-22 06:51:10.155434
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError('foo')
    except DataTruncatedError as e:
        assert str(e) == 'foo'



# Generated at 2022-06-22 06:51:14.585702
# Unit test for function write_flv_header
def test_write_flv_header():
    from io import BytesIO
    s = BytesIO()
    write_flv_header(s)
    return s.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-22 06:51:23.368313
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/2.0">'
        ' <baseURL>https://cdn.example.com/path/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'https://cdn.example.com/path/'
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/2.0" xmlns:ns2="http://ns.adobe.com/f4m/1.0">'
        ' <ns2:baseURL>https://cdn.example.com/path/</ns2:baseURL>'
        '</manifest>')

# Generated at 2022-06-22 06:51:26.541273
# Unit test for constructor of class F4mFD
def test_F4mFD():
    assert F4mFD({'url': 'x'}) is not None

if __name__ == '__main__':
    test_F4mFD()

# Generated at 2022-06-22 06:51:30.618140
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    read = FlvReader(b'\x00abcd\x00\x00').read_string
    assert read() == b''
    assert read() == b'abcd'
    assert read() == b''



# Generated at 2022-06-22 06:51:38.144727
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    reader = FlvReader(b'\x01\x02\x03')
    assert reader.read_bytes(2) == b'\x01\x02'
    try:
        reader.read_bytes(10)
    except Exception as e:
        assert isinstance(e, DataTruncatedError)
    else:
        assert False, 'FlvReader.read_bytes does not raise DataTruncatedError when failed'
    assert reader.read_bytes(1) == b'\x03'

# Generated at 2022-06-22 06:51:42.132654
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    test_data = compat_struct_pack('!Q', 0x0123456789ABCDEF)
    reader = FlvReader(test_data)
    assert reader.getbuffer().nbytes == len(test_data)
    assert reader.getbuffer().nbytes == 8
    assert reader.read_unsigned_long_long() == 0x0123456789ABCDEF


# Generated at 2022-06-22 06:51:51.400885
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    import os
    from ..downloader import temp_name
    downloader = None

# Generated at 2022-06-22 06:52:36.576067
# Unit test for function write_flv_header
def test_write_flv_header():
    from ..compat import compat_StringIO
    fd = compat_StringIO()
    write_flv_header(fd)
    assert fd.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-22 06:52:44.369641
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    from xml.etree.ElementTree import fromstring

# Generated at 2022-06-22 06:52:56.916992
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    from xml.etree import ElementTree

# Generated at 2022-06-22 06:53:01.209109
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    stream = io.BytesIO()
    write_unsigned_int_24(stream, 0x1234ABCD)
    assert stream.getvalue() == compat_struct_pack('!3s', b'\x34\xAB\xCD')



# Generated at 2022-06-22 06:53:12.354670
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    assert (write_unsigned_int_24(io.BytesIO(), 0x1234) is None and
            write_unsigned_int_24(io.BytesIO(), 0x12345678) is None)
    from ..utils import PY3
    if PY3:
        # On Python 2, BytesIO does not have "getbuffer"
        assert (write_unsigned_int_24(io.BytesIO().getbuffer(), 0x1234) is None and
                write_unsigned_int_24(io.BytesIO().getbuffer(), 0x12345678) is None)
    assert (write_unsigned_int_24(
        io.BytesIO(b'foo'), 0x1234).getvalue() == b'foo\x12\x34')

# Generated at 2022-06-22 06:53:19.069453
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    s = io.BytesIO()
    write_unsigned_int(s, 4294967295)
    assert s.getvalue() == b'\xff\xff\xff\xff'
    s = io.BytesIO()
    write_unsigned_int(s, 1)
    assert s.getvalue() == b'\x00\x00\x00\x01'



# Generated at 2022-06-22 06:53:28.203969
# Unit test for constructor of class F4mFD
def test_F4mFD():
    try:
        from xml.etree.ElementTree import XML
    except ImportError:
        from cElementTree import XML

    F4mFD(None, {})
    F4mFD(None, {'url': 'http://example.com/manifest.f4m'})
    F4mFD(None, {'url': 'http://example.com/manifest.f4m',
                 'f4m_id': 'abcd'})
    F4mFD(None, {'url': 'http://example.com/manifest.f4m',
                 'f4m_id': 'abcd', 'f4m_live_offset': 0})

# Generated at 2022-06-22 06:53:30.782076
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    # Throw an exception and catch it, otherwise the unit test runner will
    # interpret it as a failure
    try:
        raise DataTruncatedError('this is my message')
    except DataTruncatedError:
        pass



# Generated at 2022-06-22 06:53:40.386563
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    with io.open('test/test.bootstrap', 'rb') as f:
        flv = FlvReader(f.read())

# Generated at 2022-06-22 06:53:52.169880
# Unit test for constructor of class F4mFD
def test_F4mFD():
    FD = F4mFD('http://host.com/manifest.f4m', {})
    FD.report_error = lambda msg: None  # Do nothing
    assert FD.params == []

    FD = F4mFD('http://host.com/manifest.f4m', {'f4m_id': 'p0'})
    assert FD.params == ['-y', '-i', 'http://host.com/manifest.f4m', '-map', '0:p:0']
    FD.report_error = lambda msg: None  # Do nothing

    # Make sure the -ignore_error option is supported
    FD = F4mFD('http://host.com/manifest.f4m', {'f4m_id': 'p0', 'skip_unavailable_fragments': True})
   

# Generated at 2022-06-22 06:54:27.269771
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-22 06:54:38.235350
# Unit test for function read_bootstrap_info

# Generated at 2022-06-22 06:54:50.351710
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    f = FlvReader(
        compat_b64decode(
            'AAAAAQAAAAIAAAABAAkAAAABAAEAAwAAAAIAAAABAAUAAAABAAIAAgAAAAIAAAABAAYAAAABAAEAAwAAAAIAAAABAAkAAAABAAIAAgAAAAIAAAABAA8AAAABAAEAAwAAAAIAAAABABEAAAABAAIAAwAAAAIAAAABAAAAAQAAAAIAAAABAAAAAAAAAAEAAQAAAAAAAAAIAAAABAAAAAAAAAAMAAAACAAAAAAAAAAQAAAADAAAAAAAAAAUAAAACAAAAAAAAAAYAAAACAAAAAAAAAAcAAAACAAAAAAAAAAgAAAACAAAAAAAAAAMAAAABAAAAAQAAAAEAAAABAAA'))

    assert f.read_unsigned_long_long() == 694524128914992
    assert f.read_unsigned_long_long() == 664

# Generated at 2022-06-22 06:54:52.754421
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    assert FlvReader(compat_struct_pack('!I', 13)).read_unsigned_int() == 13


# Generated at 2022-06-22 06:54:57.834749
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    f = open('bootstrapinfo.xml', 'rb')
    s = f.read()
    xml = compat_etree_fromstring(s)
    bootstrap_bytes = compat_b64decode(xml.text)
    return read_bootstrap_info(bootstrap_bytes)



# Generated at 2022-06-22 06:55:09.613353
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-22 06:55:15.127529
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    data = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f'
    assert FlvReader(data).read_unsigned_char() == 0
    assert FlvReader(data).read_unsigned_char() == 1

# Generated at 2022-06-22 06:55:17.596845
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError
    except Exception as err:
        assert isinstance(err, DataTruncatedError)



# Generated at 2022-06-22 06:55:24.670418
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # manifest_url = 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8'
    manifest_url = 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8'
    info_dict = {
        'url': manifest_url,
        'tbr': '871',
        'vcodec': 'avc1.4d001f',
        'resolution': '640x360',
        'filesize': 106494,
        'ext': 'mp4',
    }
    fd = F4mFD()
    fd.real_download('test.flv', info_dict)


if __name__ == '__main__':
    test_F4mFD_real_download

# Generated at 2022-06-22 06:55:28.550673
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    test_str = compat_struct_pack('!I', 10)
    out = io.BytesIO()
    write_unsigned_int(out, 10)
    assert out.getvalue() == test_str



# Generated at 2022-06-22 06:57:24.330420
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '  <baseURL>http://host/path/to/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://host/path/to/'



# Generated at 2022-06-22 06:57:33.530098
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    import unittest
    import sys
    class TestFlvReader(unittest.TestCase):
        def do(self, f):
            abst = FlvReader(f).read_bootstrap_info()
            self.assertEqual(abst['segments'][0]['segment_run'][0], (1, 1))
            self.assertEqual(abst['fragments'][0]['fragments'][0], {
                'first': 1,
                'ts': 0,
                'duration': 5000,
                'discontinuity_indicator': None,
            })

# Generated at 2022-06-22 06:57:37.702367
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    for val in (1, 0, 1 << 32 - 1):
        stream = io.BytesIO()
        write_unsigned_int(stream, val)
        assert stream.getvalue() == compat_struct_pack('!I', val)
test_write_unsigned_int()



# Generated at 2022-06-22 06:57:45.964274
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    fd = io.BytesIO()
    write_unsigned_int_24(fd, 0x0f0f0f0)
    assert fd.getvalue() == b'\x0f\x0f\x0f'
    write_unsigned_int_24(fd, 0x0a0a0a0a)
    assert fd.getvalue() == b'\x0f\x0f\x0f\x0a\x0a\x0a'



# Generated at 2022-06-22 06:57:57.681471
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    text = (
        # box_size
        '\x00\x00\x02\x12'
        # box_type
        'asrt'
        # Version
        '\x00'
        # Flags
        '\x00\x00\x00'
        # QualityEntryCount
        '\x01'
        # QualitySegmentUrlModifiers
        '\x02\x61\x62\x00'
        # SegmentRunEntryCount
        '\x00\x00\x00\x01'
        # FirstSegment
        '\x00\x00\x00\x01'
        # FragmentsPerSegment
        '\x00\x00\x00\x01'
    )
    flv_reader = FlvReader(text)

# Generated at 2022-06-22 06:58:03.384869
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    flv_reader = FlvReader(b'\x00\x01\x02\x03\x04\x05\x06\x07')
    bytes = flv_reader.read_bytes(5)
    assert bytes == b'\x00\x01\x02\x03\x04'
    bytes = flv_reader.read_bytes(3)
    assert bytes == b'\x05\x06\x07'
    try:
        flv_reader.read_bytes(3)
        assert False
    except DataTruncatedError:
        assert True

# Generated at 2022-06-22 06:58:15.490181
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-22 06:58:26.973568
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    # Test the results of read_unsigned_long_long
    assert FlvReader(
        compat_struct_pack('!Q', 1)).read_unsigned_long_long() == 1
    assert FlvReader(
        compat_struct_pack('!Q', 2)).read_unsigned_long_long() == 2
    assert FlvReader(
        compat_struct_pack('!Q', 0xFFFFFFFFFFFFFFFF)).read_unsigned_long_long(
    ) == 0xFFFFFFFFFFFFFFFF
    # Test the error message when FlvReader needs more bytes than expected
    reader = FlvReader(compat_struct_pack('!Q', 0))
    with pytest.raises(DataTruncatedError) as excinfo:
        reader.read_unsigned_long_long()
    assert 'need 8 bytes' in str(excinfo.value)

# Generated at 2022-06-22 06:58:33.175342
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    test_data = b'metadata'
    output = io.BytesIO()
    write_metadata_tag(output, test_data)
    output.seek(0)
    assert output.read() == b'\x12\x00\x00\x00\x0A\x00\x00\x00\x00\x00\x00\x00metadata\x00\x00\x00\x00\x00\x00\x00\x1A'



# Generated at 2022-06-22 06:58:37.420197
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from ytdl_resolver_test import YtdlResolverTest