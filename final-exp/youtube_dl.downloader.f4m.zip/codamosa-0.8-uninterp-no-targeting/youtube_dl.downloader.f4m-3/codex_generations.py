

# Generated at 2022-06-22 06:51:18.738228
# Unit test for function remove_encrypted_media

# Generated at 2022-06-22 06:51:22.513303
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError('test')
    except Exception as e:
        assert isinstance(e, DataTruncatedError)
    else:
        raise AssertionError('Exception not raised')



# Generated at 2022-06-22 06:51:26.518226
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    f = io.BytesIO(compat_struct_pack('!I', 1234))
    reader = FlvReader(f)
    assert reader.read_unsigned_int() == 1234
    assert f.tell() == 4


# Generated at 2022-06-22 06:51:38.758722
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-22 06:51:47.818742
# Unit test for constructor of class FlvReader

# Generated at 2022-06-22 06:51:53.852123
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    reader = FlvReader()
    reader.write(compat_struct_pack('!B', 1))
    reader.write(compat_struct_pack('!Q', 255))
    reader.seek(0)
    assert reader.read_unsigned_char() == 1
    assert reader.read_unsigned_long_long() == 255


# Generated at 2022-06-22 06:52:01.814738
# Unit test for function build_fragments_list

# Generated at 2022-06-22 06:52:12.992140
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    metadata = 'metadata'
    output = io.BytesIO()
    write_metadata_tag(output, metadata)
    assert output.getvalue() == (
        b'\x12'  # type
        b'\x00\x00\x00'  # body length
        b'\x00\x00\x00\x00\x00\x00\x00'  # timestamp
        b'\x00\x00\x00\x00'  # stream id
        b'metadata'  # body
        b'\x12\x00\x00\x00'  # previous tag length
    )



# Generated at 2022-06-22 06:52:18.937167
# Unit test for function write_flv_header
def test_write_flv_header():
    from ..compat import compat_StringIO
    stream = compat_StringIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-22 06:52:20.362357
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from .compat import mock
    from .common import FileDownloader
    f4m_url = 'https://example.com/video.f4m'


# Generated at 2022-06-22 06:52:55.118784
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = compat_etree_fromstring('''
    <media bitrate="848" bootstrapInfoId="bootstrap0"
           drmAdditionalHeaderId="drmAdditionalHeader0"
           drmAdditionalHeaderSetId="drmAdditionalHeaderSet0"
           height="427" href="test.f4v"
           id="video" maintainAspectRatio="true"
           scala="1" width="640" x="0" y="0"/>
    <media bitrate="48" bootstrapInfoId="bootstrap1" height="0"
           href="test.f4v" id="audio" maintainAspectRatio="false"
           scala="1" width="0" x="0" y="0"/>
    ''')


# Generated at 2022-06-22 06:53:07.601949
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-22 06:53:12.125268
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    f = FlvReader(b'X\x00\x00\x00abcd')
    assert f.read_bytes(4) == b'X\x00\x00\x00'
    assert f.read_bytes(4) == b'abcd'

# Generated at 2022-06-22 06:53:20.198501
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    # Test bytearrays
    tests = [
        (b'abc\x00\x00\x00\x01', b'abc'),
        (b'\x00\x00\x00\x01', b''),
        (b'', None)
    ]
    for test in tests:
        fr = FlvReader(test[0])
        assert fr.read_string() == test[1]
# Function test_FlvReader_read_string


# Generated at 2022-06-22 06:53:25.204626
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    flv_data = io.BytesIO(compat_struct_pack('!B', 0x12) + b'\x34\x56')
    flv = FlvReader(flv_data)
    assert flv.read_unsigned_char() == 0x12
    assert flv.read_unsigned_char() == 0x34

# Generated at 2022-06-22 06:53:36.373921
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    """ Tests for function remove_encrypted_media """
    doc = """\
    <Media>
       <Metadata />
    </Media>
    """
    et = compat_etree_fromstring(doc)
    assert remove_encrypted_media(et) == []

    doc = """\
    <Media>
       <Metadata />
       <Metadata drmAdditionalHeaderId="24"/>
    </Media>
    """
    et = compat_etree_fromstring(doc)
    result = remove_encrypted_media(et)
    assert len(result) == 1
    assert 'drmAdditionalHeaderId' not in result[0].attrib
    assert 'drmAdditionalHeaderSetId' not in result[0].attrib


# Generated at 2022-06-22 06:53:41.756232
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    assert FlvReader(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09').read_bytes(4) == b'\x00\x01\x02\x03'
    try:
        FlvReader(b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09').read_bytes(11)
        assert False, 'Should not get here'
    except DataTruncatedError:
        pass

# Generated at 2022-06-22 06:53:53.761451
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    import os
    from .html5_media import write_metadata_tag
    from .rtmp import write_packet_header
    from .common import AMF3_MARKER
    stream = io.BytesIO()
    write_unsigned_int(stream, 3)
    stream.write(b'\x00\x00\x00\x00\x1a\xf6\x06\xcf\xfa\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00')
    write_unsigned_int_24(stream, 3)
    stream.seek(0)
    f = FragmentFD(stream)

# Generated at 2022-06-22 06:54:05.514413
# Unit test for function read_bootstrap_info

# Generated at 2022-06-22 06:54:16.674567
# Unit test for function get_base_url
def test_get_base_url():
    # Case 1: f4m 1.0
    manifest = compat_etree_fromstring('''<?xml version="1.0" encoding="utf-8"?>
        <manifest xmlns="http://ns.adobe.com/f4m/1.0">
          <baseURL>http://example.com/</baseURL>
        </manifest>
    ''')
    assert get_base_url(manifest) == 'http://example.com/'

    # Case 2: f4m 2.0

# Generated at 2022-06-22 06:54:55.185750
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    flv = FlvReader(compat_struct_pack('>I', 0x01020304))
    assert flv.read_unsigned_int() == 0x01020304



# Generated at 2022-06-22 06:54:58.742271
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    assert DataTruncatedError.__name__ == 'DataTruncatedError'
    assert str(DataTruncatedError('data')) == 'data'



# Generated at 2022-06-22 06:55:03.823818
# Unit test for function write_flv_header
def test_write_flv_header():
    from ..compat import BytesIO
    s = BytesIO()
    write_flv_header(s)
    assert s.getvalue() == b'FLV\x01\x05\x00\x00\x00\t\x00\x00\x00\x00'
test_write_flv_header()



# Generated at 2022-06-22 06:55:14.805103
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-22 06:55:21.579951
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    test_data = b'\x00\x00\x00\x2C\x61\x73\x72\x74\x05\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x04\x00\x00\x00\x0D\x00\x00\x00\x02\x00\x00\x00\x0D'
    asrt_info = FlvReader(test_data).read_asrt()
    assert asrt_info['segment_run'] == [(1, 13), (13, 13)]


# Generated at 2022-06-22 06:55:23.577741
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    write_unsigned_int(stream, 7)
    assert stream.getvalue() == b'\x00\x00\x00\x07'



# Generated at 2022-06-22 06:55:26.446794
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    test_data = b'\x00\x01\x80\xFF'
    reader = FlvReader(test_data)
    assert reader.read_unsigned_char() == 0
    assert reader.read_unsigned_char() == 1
    assert reader.read_unsigned_char() == 128
    assert reader.read_unsigned_char() == 255



# Generated at 2022-06-22 06:55:31.130609
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'


# Generated at 2022-06-22 06:55:42.167867
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-22 06:55:52.613279
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    unsigned_long_long = 25545664363565216
    reader = FlvReader()

    # case 1
    reader.write(compat_struct_pack('!Q', unsigned_long_long))
    reader.seek(0)
    assert reader.read_unsigned_long_long() == unsigned_long_long
    # case 2
    reader.seek(0)
    unsigned_long_long = 18446744073709551615
    reader.write(compat_struct_pack('!Q', unsigned_long_long))
    reader.seek(0)
    assert reader.read_unsigned_long_long() == unsigned_long_long



# Generated at 2022-06-22 06:56:25.979064
# Unit test for constructor of class F4mFD
def test_F4mFD():
    ydl = YoutubeDL({})

    f4m_fd = F4mFD(ydl, {'url': 'http://example.com/manifest.f4m', 'ie_key': 'F4m'})
    assert f4m_fd.url == 'http://example.com/manifest.f4m'
    assert f4m_fd.ie_key == 'F4m'
    assert f4m_fd._formats ==  []
    assert f4m_fd._formats_dict ==  {}


# Generated at 2022-06-22 06:56:30.221960
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from .test import TEST_FILES_DIR
    from .test import get_testdata_files
    from .test import get_minimal_testdata_file

    for abs_test_path in get_testdata_files():
        flv_reader = FlvReader(get_minimal_testdata_file(abs_test_path))
        abst_info = flv_reader.read_bootstrap_info()
        print (abst_info)


# Generated at 2022-06-22 06:56:40.468166
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    from ..utils import https_get
    url = 'https://download.tsi.telecom-paristech.fr/gpac/DASH_CONFORMANCE/TelecomParisTech/mp4-onDemand/mp4-onDemand-mpd-AV-BS.mpd'
    mpd_data = https_get(url)
    mpd_element = compat_etree_fromstring(mpd_data)
    base_url = xpath_text(mpd_element, './BaseURL', 'base URL')
    segment_list = mpd_element.find('./Period/AdaptationSet/SegmentList')
    initialization = segment_list.find('./Initialization')
    initialization_source_url = initialization.get('sourceURL')
    initialization_url = initialization_source_url

# Generated at 2022-06-22 06:56:41.648604
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    assert True

# Generated at 2022-06-22 06:56:53.254554
# Unit test for function build_fragments_list
def test_build_fragments_list():
    def _make_bootstrap_info(fragments):
        return {
            'live': True,
            'segments': [
                {
                    'segment_run': [(1, len(fragments))],
                },
            ],
            'fragments': [
                {
                    'fragments': [
                        {
                            'first': i,
                            'duration': 4 if i == 0 else 0,
                            'ts': i * 5,
                        }
                        for i in fragments
                    ],
                },
            ],
        }

    f = build_fragments_list
    # Test a normal case

# Generated at 2022-06-22 06:56:55.562354
# Unit test for constructor of class F4mFD
def test_F4mFD():
    fd = F4mFD.downloader_factory({})
    assert fd.__name__ == 'ffmpeg'


# Generated at 2022-06-22 06:56:58.237033
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    res = io.BytesIO()
    write_unsigned_int(res, 10)
    assert res.getvalue() == compat_struct_pack('!I', 10)



# Generated at 2022-06-22 06:57:01.981538
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    flv_reader = FlvReader(b'1234')
    assert flv_reader.read_bytes(1) == b'1'
    with pytest.raises(DataTruncatedError):
        flv_reader.read_bytes(3)


# Generated at 2022-06-22 06:57:13.170570
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    data = b'\x00\x00\x00\x00\x00\x00\x00'
    data += b'\x00\x00\x00\x00\x00\x00\x00'
    data += b'\x00\x00\x00\x00\x00\x00\x00'
    data += b'\x00\x00\x00\x00\x00\x00\x00'
    data += b'\x00\x00\x00\x00\x00\x00\x00'
    data += b'\x00\x00\x00\x00\x00\x00\x00'
    data += b'\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-22 06:57:21.903101
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    import sys
    if sys.version_info >= (3, 0):
        return  # Tested in Python 2.7 only
    reader = FlvReader(b'\xab\xcd\xef\x01\x23')
    assert reader.tell() == 0
    assert reader.read_unsigned_char() == 0xab
    assert reader.tell() == 1
    assert reader.read_unsigned_char() == 0xcd
    assert reader.tell() == 2
    assert reader.read_unsigned_char() == 0xef
    assert reader.tell() == 3
    assert reader.read_unsigned_char() == 0x01
    assert reader.tell() == 4
    assert reader.read_unsigned_char() == 0x23
    assert reader.tell() == 5

# Generated at 2022-06-22 06:57:45.554995
# Unit test for function write_flv_header
def test_write_flv_header():
    f = io.BytesIO()
    write_flv_header(f)
    assert f.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-22 06:57:57.337987
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    # test case: normal
    normal_case = lambda: FlvReader(b'\x00\x01\x02\x03').read_bytes(4)
    assert normal_case() == b'\x00\x01\x02\x03'
    # test case: read not enough
    not_enough_case = lambda: FlvReader(b'\x00\x01\x02').read_bytes(4)
    try:
        not_enough_case()
        assert False
    except DataTruncatedError:
        pass
    # test case: read too much
    too_much_case = lambda: FlvReader(b'\x00\x01\x02').read_bytes(2)
    assert too_much_case() == b'\x00\x01'


# Generated at 2022-06-22 06:58:02.402918
# Unit test for function write_flv_header
def test_write_flv_header():
    out = io.BytesIO()
    write_flv_header(out)
    assert out.getvalue() == 'FLV\x01\x05\x00\x00\x00\t\x00\x00\x00\x00'



# Generated at 2022-06-22 06:58:14.244135
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    teststr = b'\x00\x00\x00\x59\x61\x73\x72\x74\x01\x00\x00\x00\x02\x00\x00\x00\x04\x00\x00\x00Test\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00Test2\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00Test3\x00\x00'
    reader = FlvReader(teststr)
    res = reader.read_asrt()

# Generated at 2022-06-22 06:58:23.595449
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-22 06:58:26.320928
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError
    except DataTruncatedError:
        pass


# Generated at 2022-06-22 06:58:37.149072
# Unit test for constructor of class FlvReader
def test_FlvReader():
    from .test import fake_f4m
    f4m_data = fake_f4m['test_f4m']
    f4m_bootstrap = fake_f4m['test_f4m_bootstrap']
    flv = FlvReader(compat_b64decode(f4m_bootstrap))
    bootstrap = flv.read_bootstrap_info()
    # Generated by AdobeHDS.php

# Generated at 2022-06-22 06:58:42.604741
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import time
    import json
    import os
    import sys
    try:
        os.remove('test.flv')
    except OSError:
        pass
    dl = youtube_dl.YoutubeDL({
        'logger': YoutubeDLHandler(sys.stdout, {}),
        'noprogress': True,
        'quiet': True,
        'no_warnings': True,
        'outtmpl': 'test.flv',
        'nooverwrites': True,
        'format': 'bestvideo+bestaudio',
    })
    dl.params['test'] = True
    fd = F4mFD(dl, {'url': 'http://127.0.0.1:43210/akamai/test_001/test.f4m'})
    dl._parse

# Generated at 2022-06-22 06:58:43.983079
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    assert write_unsigned_int(io.BytesIO(), 4) == 4


# Generated at 2022-06-22 06:58:44.930220
# Unit test for constructor of class F4mFD
def test_F4mFD():
    x = F4mFD()
    assert x.contentType == 'video/f4m'

# Generated at 2022-06-22 06:59:50.366952
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    import io
    from .f4f_test import write_unsigned_int_24 as func
    res = io.BytesIO()
    func(res, 0xABCDEF)
    assert res.getvalue() == b'\xBC\xDE\xF0'



# Generated at 2022-06-22 07:00:01.022265
# Unit test for function get_base_url
def test_get_base_url():
    base_url = 'http://example.com/'
    manifest = io.BytesIO(compat_etree_fromstring(
        u'<manifest xmlns="http://ns.adobe.com/f4m/1.0"></manifest>'.encode('utf8')))

    assert get_base_url(manifest) == None

    manifest = io.BytesIO(compat_etree_fromstring(
        u'<manifest xmlns="http://ns.adobe.com/f4m/1.0"><baseURL>%s</baseURL></manifest>'
        % base_url).encode('utf8'))

    assert get_base_url(manifest) == base_url

