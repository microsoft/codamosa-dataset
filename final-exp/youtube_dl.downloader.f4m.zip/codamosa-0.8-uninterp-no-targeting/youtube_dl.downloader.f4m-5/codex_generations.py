

# Generated at 2022-06-22 06:50:39.995125
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    assert DataTruncatedError('error message')


# Generated at 2022-06-22 06:50:50.405098
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    test_file = io.BytesIO(b'\x01\x02\x03\x04\x05\x06\x07\x08')
    fr = FlvReader(test_file)
    assert 0x0807060504030201 == fr.read_unsigned_long_long()
    test_file = io.BytesIO(b'\x01\x02\x03\x04')
    fr = FlvReader(test_file)
    try:
        fr.read_unsigned_long_long()
        assert False
    except DataTruncatedError:
        pass


# Generated at 2022-06-22 06:51:00.992492
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    xml_str = b"""
        <media url="http://example.com/encrypted"
            bootstrapInfoId="bootstrap1"
            bitrate="600"
            width="800"
            height="600"
            dvrInfoId="dvr1"
            drmAdditionalHeaderId="drm_header_1"
            drmAdditionalHeaderSetId="drm_header_set_1"
            streamId="video" />
        <media url="http://example.com/unencrypted"
            bootstrapInfoId="bootstrap1"
            bitrate="600"
            width="800"
            height="600"
            dvrInfoId="dvr1"
            streamId="video" />
    """
    root = compat_etree_fromstring(xml_str)
    remove_encrypted_media(root)

# Generated at 2022-06-22 06:51:07.495540
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Parameters
    filename = 'filename'
    tbr = 'tbr'
    url = 'url'
    test = 'test'
    info_dict = {'tbr': tbr, 'url': url, 'test': test}
    f4mfd = F4mFD()
    assert f4mfd.FD_NAME == 'f4m'


# Generated at 2022-06-22 06:51:18.608260
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-22 06:51:19.302519
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    pass

# Generated at 2022-06-22 06:51:25.087832
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    flv_reader = FlvReader(b'\x01\x00\x00\x00\x01')
    assert flv_reader.read_unsigned_long_long() == 1
    with pytest.raises(DataTruncatedError):
        flv_reader.read_unsigned_long_long()



# Generated at 2022-06-22 06:51:27.611486
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():

    data = compat_struct_pack('!Q', 1)
    assert FlvReader(data).read_unsigned_long_long() == 1


# Generated at 2022-06-22 06:51:39.040287
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    # Tests for string with different encodings
    input_string = 'abcdefghijklmnopqrstuvwxyz'
    test_cases = [
        ['ascii', input_string],
        ['utf-8', input_string],
        ['gbk', input_string.encode('gbk')],
        ['gb2312', input_string.encode('gb2312')],
        ['big5', input_string.encode('big5')]
    ]
    for encoding, data in test_cases:
        flv_string = io.BytesIO(data + b'\x00')
        string_reader = FlvReader(flv_string)
        read_string = string_reader.read_string()

# Generated at 2022-06-22 06:51:41.895180
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    reader = FlvReader(b'\x06\x00\x00\x00test\x00')
    assert reader.read_string() == b'test'



# Generated at 2022-06-22 06:52:39.337455
# Unit test for function build_fragments_list

# Generated at 2022-06-22 06:52:51.339872
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-22 06:53:04.966859
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    from binascii import b2a_hex
    from .files import open_file
    from .common import write_to_file
    from .downloader import FileDownloader
    fd = open_file('test.f4m')
    downloader = FileDownloader({'outtmpl': 'test.f4m'})
    downloader.process_info({'url': 'test.f4m'})
    content = downloader.result()[0][1]
    flv_reader = FlvReader(content)
    boxes_info = []
    while True:
        try:
            box_info = flv_reader.read_box_info()
        except DataTruncatedError:
            break
        boxes_info.append(box_info)

# Generated at 2022-06-22 06:53:08.229081
# Unit test for function write_flv_header
def test_write_flv_header():
    assert write_flv_header(io.BytesIO()) == b'FLV\x01\x05\x00\x00\x00\t\x00\x00\x00\x00'



# Generated at 2022-06-22 06:53:18.279980
# Unit test for function read_bootstrap_info

# Generated at 2022-06-22 06:53:29.804881
# Unit test for constructor of class FlvReader

# Generated at 2022-06-22 06:53:34.913432
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    for i in range(4):
        for j in itertools.product(range(256), repeat=i):
            stream = io.BytesIO()
            write_unsigned_int(stream, sum(256**j*k for j, k in enumerate(j)))
            assert stream.getvalue() == b'\x00' * (4 - i) + bytes(j)



# Generated at 2022-06-22 06:53:42.326710
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media_with_drm = [
        {'name': 'Media1', 'url': 'url1', 'drmAdditionalHeaderId': 'header1',
         'drmAdditionalHeaderSetId': 'set1'},
        {'name': 'Media2', 'url': 'url2'},
        {'name': 'Media3', 'url': 'url3'},
        {'name': 'Media4', 'url': 'url4', 'drmAdditionalHeaderId': 'header4',
         'drmAdditionalHeaderSetId': 'set4'},
    ]
    medias_expected = [
        {'name': 'Media2', 'url': 'url2'},
        {'name': 'Media3', 'url': 'url3'},
    ]
    assert remove_encrypted_media(media_with_drm) == medias_expected



# Generated at 2022-06-22 06:53:52.715998
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    val = 0x0102030405060708
    reader = FlvReader(compat_struct_pack('!Q', val))
    assert reader.read_unsigned_long_long() == val
    reader = FlvReader(compat_struct_pack('!q', val))
    assert reader.read_unsigned_long_long() == val
    val = 0x7fffffffffffffff
    reader = FlvReader(compat_struct_pack('!q', val))
    assert reader.read_unsigned_long_long() == val
    try:
        reader.read_unsigned_long_long()
        assert False
    except DataTruncatedError:
        pass



# Generated at 2022-06-22 06:54:00.853272
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    flv_reader = FlvReader(b'\x00\x00\x00\x18ftypqt  \x00\x00\x00\x00qt  \x00\x00\x00\x00qt  ')
    assert flv_reader.read_box_info() == (24, b'ftyp', b'qt  \x00\x00\x00\x00qt  \x00\x00\x00\x00qt  ')


# Generated at 2022-06-22 06:55:42.289634
# Unit test for function remove_encrypted_media

# Generated at 2022-06-22 06:55:46.623942
# Unit test for function write_flv_header
def test_write_flv_header():
    s = io.BytesIO()
    write_flv_header(s)
    assert (
        s.getvalue() ==
        b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00')
# End unit test



# Generated at 2022-06-22 06:55:54.648909
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    assert FlvReader(compat_struct_pack('!Q', 10)).read_unsigned_long_long() == 10
    assert FlvReader(compat_struct_pack('!Q', (1 << 63))).read_unsigned_long_long() == (1 << 63)
    assert FlvReader(compat_struct_pack('!Q', (1 << 64) - 1)).read_unsigned_long_long() == (1 << 64) - 1



# Generated at 2022-06-22 06:56:05.803308
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-22 06:56:17.680519
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-22 06:56:25.870698
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    reader = FlvReader(b'123\x00')
    assert reader.read_bytes(3) == b'123'
    reader = FlvReader(b'123')
    try:
        reader.read_bytes(4)
        # an exception should be thrown
        assert False
    except DataTruncatedError:
        assert True
    reader = FlvReader(b'12345')
    assert reader.read_bytes(3) == b'123'
    assert reader.read_bytes(2) == b'45'


# Generated at 2022-06-22 06:56:32.072603
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    metadata = b'\x02\n\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    import tempfile
    tmp_file = tempfile.TemporaryFile()
    write_flv_header(tmp_file)
    write_metadata_tag(tmp_file, metadata)
    tmp_file.seek(0)

# Generated at 2022-06-22 06:56:41.741234
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    import os
    import requests
    import sys
    # First downlod the flv sample file
    data_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
    sample_file_name = 'simple_bootstrap_info.flv'
    sample_file_path = os.path.join(data_dir, sample_file_name)
    if not os.path.exists(sample_file_path):
        sys.stderr.write('Downloading flv sample file %s\n' % sample_file_name)
        url = 'http://dailymotion.github.io/hls.js/demo/simple-bootstrap-info.flv'
        r = requests.get(url)
        r.raise_for_status()
       

# Generated at 2022-06-22 06:56:51.292205
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-22 06:57:02.306509
# Unit test for function build_fragments_list

# Generated at 2022-06-22 06:59:21.719111
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-22 06:59:27.774149
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    from io import StringIO
    from .common import tempdir
    from .test_download import _TEST_HDS_LIVE, _TEST_HDS_LIVE_URL
    from .dash import _download_dash_manifest

    with tempdir() as tmpdir:
        hds_live_url, filepath = _TEST_HDS_LIVE
        key_url, iv = _TEST_HDS_LIVE_URL
        f4f_bootstrap = _download_dash_manifest(hds_live_url, tmpdir, 'test_write_metadata_tag', 'f4f')
        f4f_bootstrap_info = read_bootstrap_info(f4f_bootstrap)

# Generated at 2022-06-22 06:59:36.488401
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    test_data = b'\n\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'
    r = FlvReader(test_data)
    assert r.read_string() == b'\n'
    remaining = r.read()
    r = FlvReader(remaining)
    assert r.read_string() == b''
    remaining = r.read()
    r = FlvReader(remaining)
    assert r.read_string() == b''
    remaining = r.read()
    r = FlvReader(remaining)
    assert r.read_string() == b''

# Generated at 2022-06-22 06:59:43.758860
# Unit test for constructor of class FlvReader
def test_FlvReader():
    data = compat_b64decode('''
        AAAAMjR0AAAAUGFydHAAAgBAVgKjAIAAAAAAAAAAHVzZXJkYXRhY29kZQKjAgAAAA
        AAAAAAAAAAAAKkAgAAAAAAAAAAAAAJAAAAAAAQVVJAAAAAANIAAAAAAAAAAAA
        AA==
    ''')
    reader = FlvReader(data)

# Generated at 2022-06-22 06:59:48.745038
# Unit test for function write_flv_header
def test_write_flv_header():
    """Test writing the FLV header to stream

    >>> import sys
    >>> test_write_flv_header()
    b'FLV\\x01\\x05\\x00\\x00\\x00\\t\\x00\\x00\\x00\\x00'
    
    """
    outstream = io.BytesIO()
    write_flv_header(outstream)
    return outstream.getvalue()



# Generated at 2022-06-22 06:59:51.881548
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    buffer = io.BytesIO()
    buffer.write(b'\x07\x00\x00\x00abcd\x00')
    buffer.seek(0)
    reader = FlvReader(buffer)
    assert reader.read_string() == b'abcd'



# Generated at 2022-06-22 06:59:55.813158
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    write_unsigned_int(stream, 0x01020304)
    assert stream.getvalue() == b'\x01\x02\x03\x04'



# Generated at 2022-06-22 07:00:00.621211
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    from .testcases import bootstrap_info
    bi = read_bootstrap_info(bootstrap_info)
    print(bi)
# test_read_bootstrap_info()


# Different from standard base64, in m3u8, '+' will be encoded as '-' and '/' as '_'