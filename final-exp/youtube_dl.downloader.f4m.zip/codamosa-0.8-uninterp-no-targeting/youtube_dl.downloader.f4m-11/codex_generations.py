

# Generated at 2022-06-22 06:50:38.670094
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    # Test items with no fragments
    assert FlvReader(b'\x00\x00\x00\x0c\x61\x66\x72\x74\x00\x00\x00\x00\x00\x00\x00\x00').read_afrt() == {
        'fragments': [],
    }

    # Test items with only one segment

# Generated at 2022-06-22 06:50:51.548495
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    test_data = (
        b'\x00\x00\x00\x33\x61\x73\x72\x74\x00\x00\x00\x00\x00\x00\x00'
        b'\x01\x74\x65\x73\x74\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00'
        b'\x00\x00\x0a\x00\x00\x00\x0b\x00\x00\x00\x07'
    )
    assert FlvReader(test_data).read_asrt() == {
        'segment_run': [
            (10, 11),
        ],
    }


# Generated at 2022-06-22 06:50:56.989775
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    man_url = 'http://www.inshow.tv/live/livestream.f4m'
    fd = F4mFD(DummyYDL(), {'url': man_url})
    fd.real_download('/tmp/f.flv', {'url': man_url})



# Generated at 2022-06-22 06:51:09.233656
# Unit test for function build_fragments_list

# Generated at 2022-06-22 06:51:15.710013
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    class FakeFlvReader(FlvReader):
        def __init__(self, data):
            io.BytesIO.__init__(self, data)

    assert FakeFlvReader(
        compat_struct_pack('!I', 1234)).read_unsigned_int() == 1234
    try:
        FakeFlvReader(compat_struct_pack('!H', 1234)).read_unsigned_int()
        assert False
    except DataTruncatedError:
        pass

# Generated at 2022-06-22 06:51:28.043697
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    """
    Unit test for method read_asrt of class FlvReader
    """
    # data from a real world file downloaded from Adobe HTTPD example server

# Generated at 2022-06-22 06:51:38.145005
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    flv_reader = FlvReader(b"\x01\x02\x03\x04")
    assert flv_reader.read_unsigned_char() == b"\x01"[0]
    assert flv_reader.read_unsigned_char() == b"\x02"[0]
    assert flv_reader.read_unsigned_char() == b"\x03"[0]
    assert flv_reader.read_unsigned_char() == b"\x04"[0]

    try:
        flv_reader.read_unsigned_char()
        assert False
    except DataTruncatedError:
        pass

# Generated at 2022-06-22 06:51:47.521979
# Unit test for function build_fragments_list
def test_build_fragments_list():
    # Live
    boot_info = {
        'segments': [{'segment_run': [(1, 2), (2, 6)]}],
        'fragments': [{
            'fragments': [{'first': 0, 'duration': 3700},
                          {'first': 1, 'duration': 3696},
                          {'first': 2, 'duration': 3696},
                          {'first': 3, 'duration': 3696},
                          {'first': 4, 'duration': 3696},
                          {'first': 5, 'duration': 3696},
                          {'first': 6, 'duration': 3696},
                          ],
        }],
        'live': True
    }

# Generated at 2022-06-22 06:51:58.229691
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    fd = io.BytesIO(
        b'\x00\x00\x00\x15'
        b'asrt'
        b'\x00\x00\x00\x00'
        b'\x00\x00\x00'
        b'\x01'
        b'\x00\x00'
        b'\x00\x00\x00\x01\x00\x00\x00\x01'
        b'\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01')
    abl = FlvReader(fd).read_asrt()

# Generated at 2022-06-22 06:52:07.928823
# Unit test for constructor of class FlvReader

# Generated at 2022-06-22 06:53:01.716261
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    from xml.etree import ElementTree as ET
    encrypted_media = ET.fromstring(
        '<media url="encrypted-media" '
        'drmAdditionalHeaderSetId="encrypted-media" '
        'drmAdditionalHeaderId="encrypted-media" />')
    clean_media = ET.fromstring(
        '<media url="clean-media" />')
    assert remove_encrypted_media([encrypted_media, clean_media]) == [clean_media]



# Generated at 2022-06-22 06:53:12.308209
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():

    # In memory file
    f = io.BytesIO()

    # Parameters
    args = {
            "url": "http://www.nbc.com/assets/video/5-0/swf/DirectPlayer.swf?sid=1072&vid=14143602& cat=50&o=3",
            "format": "bestvideo"
        }
    params = {
        "test": True
    }
    # File has been created
    assert os.path.isfile(f.name), "Failed to create test file"
    # Download success using real_download
    fd = F4mFD()
    fd.params = params
    res = fd.real_download(f.name, args)
    assert res

# Generated at 2022-06-22 06:53:15.647346
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError
    except DataTruncatedError:
        pass


# Generated at 2022-06-22 06:53:21.888380
# Unit test for constructor of class FlvReader
def test_FlvReader():
    data = (
        b'\x00\x00\x00\x2C'  # size
        b'\x75\x72\x6C\x20'  # type
        b'\x00\x00\x00\x00'  # version
        b'\x00\x00\x00\x00'  # flags
        b'\x75\x72\x6C\x3A\x2F\x2F\x65\x78\x61\x6D\x70\x6C\x65\x2E\x63\x6F\x6D'  # data
    )
    reader = FlvReader(data)
    assert reader.read_bytes(4) == b'\x00\x00\x00\x2C'  # size


# Generated at 2022-06-22 06:53:28.008748
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    assert FlvReader(b'\x01').read_unsigned_char() == 1
    assert FlvReader(b'\x02').read_unsigned_char() == 2
    assert FlvReader(b'\x03').read_unsigned_char() == 3
    assert FlvReader(b'\x04').read_unsigned_char() == 4
    assert FlvReader(b'\x05').read_unsigned_char() == 5

# Generated at 2022-06-22 06:53:38.677716
# Unit test for function read_bootstrap_info

# Generated at 2022-06-22 06:53:40.079842
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    x = DataTruncatedError()
    assert x is not None


# Generated at 2022-06-22 06:53:42.307315
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    test_str = b'test\x00this'
    reader = FlvReader(test_str)
    assert reader.read_string() == b'test'



# Generated at 2022-06-22 06:53:54.229893
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-22 06:53:57.410906
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    assert FlvReader(
        compat_struct_pack('!I', 0x01020304)).read_unsigned_int() == 0x01020304



# Generated at 2022-06-22 06:54:14.567354
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    stream = FlvReader(compat_struct_pack('!IBBBH', 0, 1, 2, 3, 4))
    assert stream.read_unsigned_int() == 0x01020304



# Generated at 2022-06-22 06:54:22.128405
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from .test import (
        TEST_BOOTSTRAP_FILE,
        TEST_BOOTSTRAP_INFO,
    )
    with io.open(TEST_BOOTSTRAP_FILE, 'rb') as f:
        data = f.read()
        reader = FlvReader(data)
        got_bootstrap_info = reader.read_bootstrap_info()
        assert got_bootstrap_info == TEST_BOOTSTRAP_INFO
test_FlvReader_read_bootstrap_info()



# Generated at 2022-06-22 06:54:33.449009
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    # test data from https://github.com/bytedeco/javacv/blob/master/samples/FlvDump.java
    from .fragment import test_FragmentFD_download
    bootstrap_info = FlvReader(test_FragmentFD_download()).read_bootstrap_info()

# Generated at 2022-06-22 06:54:44.962936
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # Create a BytesIO object
    box_data = io.BytesIO()
    # Box size for a simple box
    box_data.write(compat_struct_pack('!I', 8))
    # Box type for a simple box
    box_data.write(b'simp')
    # The box data
    box_data.write(b'\x11\x22\x33\x44')

    # Create a FlvReader
    reader = FlvReader(box_data.getvalue())
    # Read the box
    size, box_type, data = reader.read_box_info()
    # Verify the data
    assert size == 8
    assert box_type == b'simp'
    assert data == b'\x11\x22\x33\x44'

    # Create a BytesIO object
   

# Generated at 2022-06-22 06:54:56.775360
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # One normal box
    data = b'\x00\x00\x00\x0c' + b'type' + b'abcd'
    reader = FlvReader(data)
    box_size, box_type, box_data = reader.read_box_info()
    assert box_size == 12
    assert box_type == b'type'
    assert box_data == b'abcd'
    # One extended box
    data = b'\x00\x00\x00\x01' + b'type' + b'\x00\x00\x00\x00\x00\x00\x00\x10' + b'abcdefgh'
    reader = FlvReader(data)
    box_size, box_type, box_data = reader.read_box_info()

# Generated at 2022-06-22 06:55:04.289366
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    f = io.BytesIO()
    write_metadata_tag(f, b'\x01\x02\x03')
    assert f.getvalue() == (b'\x12'
                            b'\x00\x00\x03'
                            b'\x00\x00\x00\x00\x00\x00\x00'
                            b'\x01\x02\x03'
                            b'\x00\x00\x00\x10')



# Generated at 2022-06-22 06:55:14.402958
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    test_asrt_box = (
        b'\x00\x00\x00\x1a'  # asrt size
        b'asrt'  # type
        b'\x00'  # version 0
        b'\x00\x00\x00'  # flags
        b'\x00'  # QualityEntryCount 0
        b'\x00\x00\x00\x01'  # SegmentRunEntryCount
        b'\x00\x00\x00\x01'  # FirstSegment
        b'\x00\x00\x00\x01'  # FragmentsPerSegment
    )
    assert FlvReader(test_asrt_box).read_asrt() == {
        'segment_run': [(1, 1)],
    }


#

# Generated at 2022-06-22 06:55:17.808589
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'


# Generated at 2022-06-22 06:55:20.814369
# Unit test for function write_flv_header
def test_write_flv_header():
    result = io.BytesIO()
    write_flv_header(result)
    assert result.getvalue() == (b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00')


# Generated at 2022-06-22 06:55:26.848529
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import os
    import shutil
    ydl = YoutubeDL({'outtmpl': '%(epoch)s.%(id)s.%(ext)s'})
    fd_name = 'f4m'
    test_cases = [
        # Input_data, expected result
        ['http://live-a.live.test.test.test:1935/live/myStream/playlist.f4m', True],
        ['http://live-a.live.test.test.test:1935/live/myStream/playlist.f4m', True],
        ['http://live-a.live.test.test.test:1935/live/myStream/playlist.f4m', True]

    ]

# Generated at 2022-06-22 06:56:19.000400
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    """ Method real_download of class F4mFD
        Unit test for real_download method of F4mFD.
        Tests a simple f4m download using the example from wikipedia.
        Simple test of exception catching.
    """

    from .extractor import YoutubeDL
    from .utils import encodeFilename
    from .compat import compat_urllib_request

    # create youtube-dl object
    ydl = YoutubeDL({'outtmpl': encodeFilename('test_f4mfd')})

    # create test F4mFD object
    f4mfd = F4mFD(ydl=ydl, params={})

    # create test url
    #test_url = 'http://download.macromedia.com/f4v/video/sample.f4v.f4m'

# Generated at 2022-06-22 06:56:21.682565
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    assert FlvReader(b'\x00').read_string() == b''
    assert FlvReader(b'a\x00').read_string() == b'a'
    assert FlvReader(b'ab\x00').read_string() == b'ab'
    assert FlvReader(b'abc\x00').read_string() == b'abc'



# Generated at 2022-06-22 06:56:24.676492
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    assert len(remove_encrypted_media([1, 2])) == 2
    assert len(remove_encrypted_media([1, 2, 3])) == 2


# Generated at 2022-06-22 06:56:29.446766
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    reader = FlvReader(b'abcd')
    assert reader.read_bytes(2) == b'ab'
    try:
        reader.read_bytes(3)
    except DataTruncatedError:
        pass
    else:
        assert False


# Generated at 2022-06-22 06:56:40.002640
# Unit test for function read_bootstrap_info

# Generated at 2022-06-22 06:56:49.980854
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-22 06:57:01.324254
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    path = os.path.dirname(os.path.abspath(__file__))
    # Create a downloader

# Generated at 2022-06-22 06:57:02.690757
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError
    except DataTruncatedError:
        pass


# Generated at 2022-06-22 06:57:06.630543
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    reader = FlvReader(compat_struct_pack('!Q', 0x0102030405060708))
    assert reader.read_unsigned_long_long() == 0x0102030405060708

# Generated at 2022-06-22 06:57:16.952140
# Unit test for function remove_encrypted_media

# Generated at 2022-06-22 06:58:33.835134
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    import unittest
    class TestFlvReader_read_bootstrap_info(unittest.TestCase):
        def test_basic(self):
            with io.open('tests/bootstrap', 'rb') as f:
                bootstrap_info = FlvReader(f.read()).read_bootstrap_info()
            self.assertEqual(bootstrap_info['fragments'][0]['fragments'][0]['discontinuity_indicator'], 0)
            self.assertEqual(bootstrap_info['fragments'][0]['fragments'][1]['discontinuity_indicator'], 1)
            self.assertEqual(bootstrap_info['fragments'][0]['fragments'][2]['discontinuity_indicator'], 1)

   

# Generated at 2022-06-22 06:58:38.883196
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    flv = FlvReader(b'12345678')
    assert flv.read_bytes(4) == b'1234'
    flv = FlvReader(b'1234')
    with pytest.raises(DataTruncatedError):
        flv.read_bytes(5)



# Generated at 2022-06-22 06:58:49.278011
# Unit test for function build_fragments_list

# Generated at 2022-06-22 06:58:56.386730
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    flv_reader = FlvReader(b'\x00\x00\x00\x00')
    assert flv_reader.read_bytes(3) == b'\x00\x00\x00'
    assert flv_reader.read_bytes(1) == b'\x00'
    try:
        flv_reader.read_bytes(1)
        assert False
    except DataTruncatedError:
        pass

# Generated at 2022-06-22 06:59:00.175619
# Unit test for function write_flv_header
def test_write_flv_header():
    from io import BytesIO
    stream = BytesIO()
    write_flv_header(stream)
    stream.seek(0)
    assert stream.read() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-22 06:59:04.630370
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    f = open('bootstrap', 'rb')
    result = read_bootstrap_info(f.read())
    for fragment in itertools.chain.from_iterable(
            fragments['fragments'] for fragments in result['fragments']):
        assert fragment['discontinuity_indicator'] is None



# Generated at 2022-06-22 06:59:07.880498
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    assert (FlvReader(compat_struct_pack('!I', 0x01020304)).read_unsigned_int()
            == 0x01020304)

# Generated at 2022-06-22 06:59:10.501362
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    tag = write_metadata_tag('metadata_test')
    assert tag == 12
    assert len(tag) == 9
    assert tag == 'metadata_test'

# Generated at 2022-06-22 06:59:19.659149
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    flv_reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x00')
    result = flv_reader.read_unsigned_long_long()
    assert result == 0
    flv_reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\xff')
    result = flv_reader.read_unsigned_long_long()
    assert result == 255
    flv_reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x01\x00')
    result = flv_reader.read_unsigned_long_long()
    assert result == 256

# Generated at 2022-06-22 06:59:26.489752
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    from ..utils import (
        encode_base_n,
    )

    # Test vector from
    # http://download.macromedia.com/f4v/video_file_format_spec_v10_1.pdf
    # Chapter E.3.2.2 SegmentRunBox