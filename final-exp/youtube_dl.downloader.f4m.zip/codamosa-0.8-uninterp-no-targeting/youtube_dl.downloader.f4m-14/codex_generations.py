

# Generated at 2022-06-22 06:50:36.367538
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    from .common import fake_filesystem
    from .common import make_mocked_request
    from .common import MockedRequestHandler
    from .common import fake_socket
    from .common import fake_http_server
    import urllib3.poolmanager
    from urllib3.util import parse_url

    def test_bytes_producer(bytes_list):
        return bytes_list.pop(0)

    fake_fs = fake_filesystem.FakeFilesystem()
    fake_os = fake_filesystem.FakeOsModule(fake_fs)
    fake_open = fake_filesystem.FakeFileOpen(fake_fs)
    mocked_request = make_mocked_request(fake_fs, fake_open)


# Generated at 2022-06-22 06:50:44.146183
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    stream = io.BytesIO()
    write_unsigned_int_24(stream, 0xAABBCC)
    assert stream.getvalue() == b'\xbb\xcc'
    stream.seek(0)
    write_unsigned_int_24(stream, 0x123456)
    assert stream.getvalue() == b'\x12\x34\x56'
    stream.close()
test_write_unsigned_int_24()



# Generated at 2022-06-22 06:50:46.895044
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00&\x61\x73\x72\x74\x01\x61\x61'
        b'\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'
    )
    parsed = FlvReader(data).read_asrt()
    assert parsed['segment_run'] == [
        (0, 1),
    ]



# Generated at 2022-06-22 06:50:51.830077
# Unit test for function write_flv_header
def test_write_flv_header():
    assert write_flv_header(io.BytesIO()).getvalue() == (
        b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00')



# Generated at 2022-06-22 06:51:03.408551
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-22 06:51:10.941958
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    flv = FlvReader(b'\x01')
    assert flv.read_unsigned_char() == 1
    try:
        flv.read_unsigned_char()
        assert False, 'DataTruncatedError expected'
    except DataTruncatedError:
        pass
    flv = FlvReader(b'\x01\x02')
    assert flv.read_unsigned_char() == 1
    assert flv.read_unsigned_char() == 2


# Test method read_unsigned_int of class FlvReader

# Generated at 2022-06-22 06:51:21.210472
# Unit test for function remove_encrypted_media

# Generated at 2022-06-22 06:51:24.213480
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    s = compat_struct_pack('!B', 123)
    f = FlvReader(s)
    assert f.read_unsigned_char() == 123



# Generated at 2022-06-22 06:51:35.775840
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    from ..utils import decode_packed_uint32
    import uuid
    # Test case from https://github.com/ytdl-org/youtube-dl/pull/6017

# Generated at 2022-06-22 06:51:46.324510
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from ..utils import encode_data_uri
    from .fragment import (
        Box_asrt,
        Box_asrt_SegmentRunEntry,
        Box_afrt,
        Box_abst,
    )

    abst = Box_abst()

    abst.bootstrapinfo_version = 0
    abst.profile = 'live'
    abst.live = True
    abst.update = 'full'
    abst.timescale = 1000
    abst.currentmediatime = 600000
    abst.smptetimecodeoffset = 0
    abst.server_entry_table = []
    abst.quality_entry_table = []
    abst.drm_data = ''
    abst.metadata = ''

    abst.segments = [
        Box_asrt(),
        Box_asrt(),
    ]

    abst.segments

# Generated at 2022-06-22 06:52:06.598902
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    assert FlvReader(b'\x00').read_unsigned_char() == 0
    assert FlvReader(b'\x01').read_unsigned_char() == 1
    assert FlvReader(b'\xff').read_unsigned_char() == 255


# Generated at 2022-06-22 06:52:15.215714
# Unit test for function get_base_url
def test_get_base_url():
    data = r"""<?xml version="1.0"?>
<manifest xmlns="http://ns.adobe.com/f4m/1.0">
    <baseURL>http://example.com</baseURL>
</manifest>
"""
    manifest = compat_etree_fromstring(data)
    assert get_base_url(manifest) == 'http://example.com'
    # Test default value
    manifest = compat_etree_fromstring('<manifest xmlns="http://ns.adobe.com/f4m/1.0"/>')
    assert get_base_url(manifest) is None



# Generated at 2022-06-22 06:52:23.836298
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    # create a stream
    stream = compat_struct_pack('!IcBBIBBI', [
        10, b'f', b'l', b'v', b'\x00', 1, 3, 7
    ])
    stream_reader = FlvReader(stream)

    # test method read_bytes
    assert stream_reader.read_bytes(3) == b'flv'
    assert stream_reader.read_bytes(3) == b'\x00\x01\x03'
    assert stream_reader.read_bytes(2) == b'\x07\x00'



# Generated at 2022-06-22 06:52:35.361450
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-22 06:52:41.173864
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    test_string1 = b'\x84\x01\x01\x00\x06\x01\x00\x00\x00'
    test_string2 = b'\x03\x00\x00\x00\x66\x6f\x6f\x00'
    test_string = test_string1 + test_string2
    flv_reader = FlvReader(test_string)
    assert flv_reader.read_string() == b'\x84\x01\x01'



# Generated at 2022-06-22 06:52:52.897623
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = [
        {
            'attrib': {
                'url': 'http://host/media_1',
            }
        },
        {
            'attrib': {
                'url': 'http://host/media_2',
                'drmAdditionalHeaderId': '1',
                'drmAdditionalHeaderSetId': '0',
            }
        },
        {
            'attrib': {
                'url': 'http://host/media_3',
            }
        },
        {
            'attrib': {
                'url': 'http://host/media_4',
                'drmAdditionalHeaderId': '2',
                'drmAdditionalHeaderSetId': '0',
            }
        }
    ]

# Generated at 2022-06-22 06:53:05.485129
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    metadata = b'\x00\x00\x00\x00\x06onMetaData\x00\x08\x00\x00\x00'
    fd = io.BytesIO()
    write_metadata_tag(fd, metadata)
    fd.seek(0)
    assert fd.read() == (
        b'\x12\x00\x00\x0B\x00\x00\x00\x00\x00\x00\x00'
        b'\x00\x00\x00\x00\x06onMetaData\x00\x08\x00\x00\x00'
        b'\x00\x00\x00\x00\x00\x00\x18')



# Generated at 2022-06-22 06:53:15.615088
# Unit test for function read_bootstrap_info

# Generated at 2022-06-22 06:53:24.811618
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    def int2bigendian(number):
        return b''.join(compat_struct_pack('!B', (number >> i * 8) & 0xff) for i in reversed(range(8)))
    # Test pos case
    input_data = b'\x01\x00\x00\x00\x01\x00\x00\x00'
    reader = FlvReader(input_data)
    assert reader.read_unsigned_long_long() == 1

    input_data = b'\x01\x00\x00\x00\x02\x00\x00\x00'
    reader = FlvReader(input_data)
    assert reader.read_unsigned_long_long() == 515
    assert reader.read_unsigned_long_long() == 515


# Generated at 2022-06-22 06:53:35.972667
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    import zlib
    import re

# Generated at 2022-06-22 06:54:06.508618
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor

    class _FakeInfoExtractor(InfoExtractor):
        def _real_initialize(self):
            pass
        def _real_extract(self, url):
            return {}
        def _download_webpage(self, *args, **kwargs):
            self.to_screen('_download_webpage')
            return ''
        def _download_xml(self, url, *args, **kwargs):
            self.to_screen('_download_xml')
            class _FakeXML:
                def __init__(self, count):
                    self.count = count
                def __getitem__(self, key):
                    if key == 'media':
                        return ['fake-url']

# Generated at 2022-06-22 06:54:17.333069
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {'segments': [{'segment_run': [(1, 2), (2, 2)]}], 'fragments': [{'fragments': [{'first': 1, 'discontinuity_indicator': None, 'ts': 266928000, 'duration': 5000}, {'first': 3, 'discontinuity_indicator': None, 'ts': 271928000, 'duration': 5000}, {'first': 5, 'discontinuity_indicator': None, 'ts': 71928000, 'duration': 5000}, {'first': 7, 'discontinuity_indicator': None, 'ts': 276928000, 'duration': 5000}]}], 'live': False}
    result = build_fragments_list(boot_info)

# Generated at 2022-06-22 06:54:27.551171
# Unit test for function read_bootstrap_info

# Generated at 2022-06-22 06:54:34.793256
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    flv_reader = FlvReader(
        b'\x2F\x68\x65\x6C\x6C\x6F\x20\x77\x6F\x72\x6C\x64\x00\x2F\x64\x61\x74\x61\x00')
    assert flv_reader.read_string() == b'/hello world'
    assert flv_reader.read_string() == b'/data'



# Generated at 2022-06-22 06:54:46.207136
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    import base64

# Generated at 2022-06-22 06:54:48.462478
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError
    except DataTruncatedError:
        pass


# Generated at 2022-06-22 06:54:50.990103
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError("Youtube error")
    except DataTruncatedError:
        pass


# Generated at 2022-06-22 06:55:01.558588
# Unit test for constructor of class F4mFD
def test_F4mFD():
    from youtube_dl.YoutubeDL import YoutubeDL
    from .extractor.common import InfoExtractor

    ie = InfoExtractor({})
    params = {
        'format': 'best',
        'skip_download': True,
        'outtmpl': '%(id)s.%(ext)s',
    }
    ydl = YoutubeDL(params)
    ie.add_default_info_extractors()
    ydl.add_info_extractor(ie)

    f4mfd = F4mFD(ydl, params, {})


# Generated at 2022-06-22 06:55:11.834510
# Unit test for constructor of class FlvReader
def test_FlvReader():
    """
    Test for the constructor of class FlvReader
    """

# Generated at 2022-06-22 06:55:17.335518
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    flv = FlvReader(b'\x00\x00\x00\x06abcd\x00\x00\x00\x07123456\x00\x00\x00\x00')
    assert flv.read_string() == b'abcd'
    assert flv.read_string() == b'123456'
    assert flv.read_string() == b''



# Generated at 2022-06-22 06:55:53.985854
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-22 06:55:58.140070
# Unit test for constructor of class F4mFD
def test_F4mFD():
    fd = F4mFD('foo', {'format': 'mp4'})
    assert fd.url == 'foo'
    assert fd.info_dict == {'format': 'mp4'}



# Generated at 2022-06-22 06:56:03.868560
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv_file_path='../test_files/test_f4m.flv'
    with io.open(flv_file_path, 'rb') as f:
        file_obj = f.read()
        f4m_reader = FlvReader(file_obj)
        bootstrap = f4m_reader.read_bootstrap_info()
    print(bootstrap)

# Generated at 2022-06-22 06:56:13.513013
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    print('Testing FlvReader read afrt box')
    # afrtDataB64 is from a live broadcast of the channel "CGTN" on Bilibili

# Generated at 2022-06-22 06:56:20.885049
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-22 06:56:29.665281
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    test_data = b'\x01\x02\x03\x04'
    reader = FlvReader(test_data)
    assert reader.read_unsigned_char() == 1
    assert reader.read_unsigned_char() == 2
    assert reader.read_unsigned_char() == 3
    assert reader.read_unsigned_char() == 4
    try:
        reader.read_unsigned_char()
    except DataTruncatedError:
        pass
    else:
        assert(False)  # DataTruncatedError is not raised!

# Generated at 2022-06-22 06:56:40.138468
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from .common import download_public_file
    from ..utils import encode_data_uri
    with open(download_public_file('f4m/test_abst.flv',
                                   '969c1a0a62a38b0883452837a9fceaa2d396c0d8'), 'rb') as f:
        abst_box = f.read()
    f = FlvReader(abst_box)

# Generated at 2022-06-22 06:56:50.106141
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    bootstrap_info = FlvReader(io.BytesIO(open(
        'tests/resources/FlvReader_read_bootstrap_info.flv', 'rb').read())).read_bootstrap_info()

# Generated at 2022-06-22 06:57:01.421587
# Unit test for function read_bootstrap_info

# Generated at 2022-06-22 06:57:05.607714
# Unit test for function write_flv_header
def test_write_flv_header():
    import io
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-22 06:57:35.883284
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    assert write_unsigned_int_24(None, 0x123456) == b'\x12\x34\x56'



# Generated at 2022-06-22 06:57:45.757799
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    s = io.BytesIO(
        b'\x00\x01\x02\x03\x00\x01\x02\x03\x00\x01\x02\x03\x00\x01\x02\x03\x00'
    )
    assert FlvReader(s).read_string() == b'\x00\x01\x02\x03'
    assert FlvReader(s).read_string() == b'\x00\x01\x02\x03'
    assert FlvReader(s).read_string() == b'\x00\x01\x02\x03'



# Generated at 2022-06-22 06:57:57.537596
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    with open('tests/data/abst.flv', 'rb') as f:
        # Test big-endian format
        box_size, box_type, box_data = FlvReader(f.read()).read_box_info()
        assert box_size == len(f.read()) + 8
        assert box_type == b'abst'
        assert len(box_data) == box_size - 8
        # Test little-endian format
        with open('tests/data/abst_le.flv', 'rb') as f:
            box_size, box_type, box_data = FlvReader(f.read()).read_box_info()
            assert box_size == len(f.read()) + 8
            assert box_type == b'abst'
            assert len(box_data) == box

# Generated at 2022-06-22 06:58:02.261829
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    from .test_fragment import str_to_bytes
    reader = FlvReader(str_to_bytes('\x00\x00\x00\x15'))
    assert reader.read_unsigned_int() == 21



# Generated at 2022-06-22 06:58:14.093027
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-22 06:58:21.532841
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():

    data = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    m = FlvReader(data)
    afrt = m.read_afrt()
    assert afrt['fragments'][0]['first'] == 0
    assert afrt['fragments'][0]['ts'] == 0
    assert afrt['fragments'][0]['duration'] == 0
    assert afrt['fragments'][0]['discontinuity_indicator'] == 1



# Generated at 2022-06-22 06:58:28.758479
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    flv_reader = FlvReader(b'\x00\x01\x02\x03\x04')
    assert flv_reader.read_unsigned_char() == 0
    assert flv_reader.read_unsigned_char() == 1
    assert flv_reader.read_unsigned_char() == 2
    assert flv_reader.read_unsigned_char() == 3
    assert flv_reader.read_unsigned_char() == 4



# Generated at 2022-06-22 06:58:35.963427
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    # Test case 1: read a stream with size n
    r = FlvReader(b'\x00' * 10)
    n = 10
    assert len(r.read_bytes(n)) == n

    # Test case 2: read a stream with size less than n
    r = FlvReader(b'\x00')
    try:
        r.read_bytes(10)
    except DataTruncatedError:
        pass
    else:
        assert False


# Generated at 2022-06-22 06:58:47.043839
# Unit test for constructor of class FlvReader
def test_FlvReader():
    from ..utils import (
        compat_urllib_request,
    )

    # Try to make requests to a test server
    try:
        bootstrap_info = FlvReader(compat_urllib_request.urlopen(
            'http://rmcdn.2mdn.net/Demo/vast_inspector/android.flv').read()).read_bootstrap_info()
    except (compat_urllib_error.URLError, compat_urllib_error.HTTPError):
        from ..test.server import run_server
        url = run_server(port=60000)
        bootstrap_info = FlvReader(compat_urllib_request.urlopen(url).read()).read_bootstrap_info()

    assert bootstrap_info['segments']
    assert boot

# Generated at 2022-06-22 06:58:52.979491
# Unit test for function remove_encrypted_media