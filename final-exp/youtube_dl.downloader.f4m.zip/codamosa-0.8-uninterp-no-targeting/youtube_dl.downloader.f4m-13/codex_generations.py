

# Generated at 2022-06-22 06:50:45.229214
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-22 06:50:52.748497
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from .extractor.common import InfoExtractor
    name_pattern = 'Example-%(autonumber)s.f4m'
    ie = InfoExtractor(F4mFD(name_pattern=name_pattern).real_download)
    ie.set_downloader(DummyFD().real_download)
    ie.params = {'format': 'm3u8_native'}
    ie.add_default_info_extractors()
    ie.extract('http://example.com/manifest.f4m')



# Generated at 2022-06-22 06:51:04.682448
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-22 06:51:16.037992
# Unit test for constructor of class FlvReader

# Generated at 2022-06-22 06:51:28.514931
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-22 06:51:40.746737
# Unit test for function build_fragments_list

# Generated at 2022-06-22 06:51:50.279188
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    from base64 import b64decode

# Generated at 2022-06-22 06:52:01.524978
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-22 06:52:14.601418
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    test_data = b'\x00\x01\x02\x03\x04\x05\x06\x07'

    r = FlvReader(test_data)
    assert r.read_bytes(8) == test_data
    assert r.read_bytes(1) == b''

    r = FlvReader(test_data)
    try:
        r.read_bytes(9)
    except DataTruncatedError:
        pass
    else:
        assert False, 'test_FlvReader_read_bytes failed'

    r = FlvReader(test_data)
    assert r.read_bytes(7) == test_data[:7]
    try:
        r.read_bytes(3)
    except DataTruncatedError:
        pass

# Generated at 2022-06-22 06:52:17.242188
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError('foo')
    except DataTruncatedError as e:
        assert str(e) == 'foo'



# Generated at 2022-06-22 06:52:40.944500
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    encrypted_media = """
    <media url="enc1.f4f" bitrate="1" bootstrapInfoId="bootstrap0" width="250" height="200" >
        <metadata name="displayWidth" content="250" />
        <metadata name="displayHeight" content="200" />
        <metadata name="duration" content="22" />
        <metadata name="bootstrapInfoVersion" content="1" />
        <metadata name="drmAdditionalHeaderId" content="481" />
        <metadata name="drmAdditionalHeaderSetId" content="432" />
    </media>
    """

# Generated at 2022-06-22 06:52:44.837776
# Unit test for function get_base_url
def test_get_base_url():
    test_doc = '<manifest><baseURL>http://foo.com/</baseURL></manifest>'
    assert get_base_url(compat_etree_fromstring(test_doc)) == 'http://foo.com/'



# Generated at 2022-06-22 06:52:50.517367
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    data = (
        b'\x00\x00\x00\x12\x66\x74\x79\x70\x61\x66\x72\x61\x00\x00\x00\x00'
        b'\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x04\x00\x00\x00\x00'
        b'\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00\x3c\x00\x00\x00\x00'
    )

# Generated at 2022-06-22 06:52:59.355247
# Unit test for constructor of class FlvReader
def test_FlvReader():
    from .common import (
        load_fixture,
    )
    absolute_uri = (
        'http://fms.cntv.lxdns.com/live/flv/channel114.flv?wsSecret=7b96bbd18f9aa34a0e917be16d303688&wsTime=1462698983&'
        'uid=8ea5ed22bf449a5f5d5cf8b5d5fa2e68&hardware=cuda&multirate=1')
    fragment_urls = [
        (absolute_uri + '&start=0&end=3423.878'),
        (absolute_uri + '&start=3423.878&end=6887.333'),
    ]

# Generated at 2022-06-22 06:53:10.939588
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    import base64
    import binascii
    from io import BytesIO
    from ..utils import dict_get

# Generated at 2022-06-22 06:53:14.182096
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    stream = io.BytesIO()
    write_unsigned_int_24(stream, 1)
    assert stream.getvalue() == compat_struct_pack('!B',0) + compat_struct_pack('!H',1)



# Generated at 2022-06-22 06:53:25.617805
# Unit test for method read_bytes of class FlvReader

# Generated at 2022-06-22 06:53:35.496110
# Unit test for function build_fragments_list

# Generated at 2022-06-22 06:53:42.534761
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    # sample mp4 file:
    # http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8
    #  , segment 0:
    # http://devimages.apple.com/iphone/samples/bipbop/gear1/prog_index.m3u8
    #  , fragment 0:
    # http://devimages.apple.com/iphone/samples/bipbop/gear1/fileSequence0.ts
    # Convert fileSequence0.ts to a mp4 file
    mp4_file = b''

# Generated at 2022-06-22 06:53:54.476672
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    # Sample ftyp data got from https://github.com/kaltura/nginx-vod-module/blob/master/doc/dash.format (file dash_sample.mpd)
    ftyp_data = b'\x00\x00\x00(\x66\x74\x79\x70\x61\x73\x70\x4d\x34\x56\x20\x10\x0E\x66\x74\x79\x70\x6D\x70\x34\x32\x69\x73\x6F\x6D\x76\x32\x20\x20'
    box_size, box_type, box_data = FlvReader(ftyp_data).read_box_info()
    assert box_size == 40
    assert box_type

# Generated at 2022-06-22 06:54:23.666264
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    """
    This function tests the FlvReader method read_afrt
    """

# Generated at 2022-06-22 06:54:27.885823
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    f = FlvReader(b'\x05hello\x00world')
    assert f.read_string() == b'hello'
    assert f.read_string() == b'world'

test_FlvReader_read_string()


# Generated at 2022-06-22 06:54:34.327409
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    test_file = os.path.join(os.path.dirname(__file__), "test.f4m")
    # Create a new instance of F4mFD
    instance = F4mFD(None, {'url': test_file}, None)
    result = instance.real_download('', {'url': test_file})
    # Test if method real_download of class F4mFD returns true
    assert result



# Generated at 2022-06-22 06:54:45.533549
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-22 06:54:57.409869
# Unit test for function get_base_url
def test_get_base_url():
    # constructor for etree.Element
    def _e(tag, text, attrib=None):
        el = compat_etree_fromstring('<%s>%s</%s>' % (tag, text, tag))
        if attrib:
            el.attrib.update(attrib)
        return el

    manifest = _e('manifest', '', {'xmlns': _add_ns('').split('}')[0][1:]})
    base_url = get_base_url(manifest)
    assert base_url is None

    manifest.append(_e('baseURL', '  '))
    base_url = get_base_url(manifest)
    assert base_url == ''

    manifest[1].text = 'http://fake.url/'

# Generated at 2022-06-22 06:55:06.481930
# Unit test for constructor of class F4mFD
def test_F4mFD():
    class YDL:
        def __init__(self):
            self.params = {}
        def to_screen(self, msg):
            pass
    ydl = YDL()
    fd = F4mFD(ydl, {'url': 'http://xxx/manifest.f4m'})
    assert fd.downloader is ydl


if __name__ == '__main__':
    import sys
    bootstrap_url = sys.argv[1]
    boot_info = read_bootstrap_info(urllib.request.urlopen(bootstrap_url).read())
    print(boot_info)

# Generated at 2022-06-22 06:55:16.783616
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-22 06:55:29.477218
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    def _test_info(bootstrap_url, expected_info):
        info = FlvReader(_get_bootstrap_info_file(bootstrap_url)).read_bootstrap_info()
        assert info == expected_info

        info = FlvReader(io.BytesIO(compat_b64decode(bootstrap_url))).read_bootstrap_info()
        assert info == expected_info

    # Test 1

# Generated at 2022-06-22 06:55:35.935088
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    data_list = [
        (b'\x00\x00\x00\x01', 1),
        (b'\x00\x00\x10\x00', 4096),
        (b'\x00\x00\xFF\xFF', 65535),
    ]
    for data, expected in data_list:
        assert FlvReader(data).read_unsigned_int() == expected


# Generated at 2022-06-22 06:55:47.119545
# Unit test for function build_fragments_list

# Generated at 2022-06-22 06:56:38.036267
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    stream = io.BytesIO()
    write_unsigned_int_24(stream, 0x1234ABCD)
    assert stream.getvalue() == b'\x34\xAB\xCD'



# Generated at 2022-06-22 06:56:41.941235
# Unit test for function write_flv_header
def test_write_flv_header():
    s = io.BytesIO()
    write_flv_header(s)
    assert s.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-22 06:56:45.521696
# Unit test for function get_base_url
def test_get_base_url():
    assert get_base_url(compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0"></manifest>')) is None
    assert get_base_url(compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0"><baseURL>BASE</baseURL></manifest>')) == 'BASE'
    assert get_base_url(compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/2.0"><baseURL>BASE</baseURL></manifest>')) == 'BASE'



# Generated at 2022-06-22 06:56:53.569137
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    test_cases = [
        (b'\x04\x00\x00\x00test', b'test'),
        (b'\x04\x00\x00\x00test\x00more', b'test'),
        (b'\x05\x00\x00\x00test\x00', b'test'),
    ]
    for test_case, expected in test_cases:
        r = FlvReader(test_case)
        assert r.read_string() == expected

# Generated at 2022-06-22 06:57:03.492784
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-22 06:57:14.929803
# Unit test for constructor of class FlvReader

# Generated at 2022-06-22 06:57:26.368927
# Unit test for function build_fragments_list

# Generated at 2022-06-22 06:57:29.901375
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    reader = FlvReader(b'\x00\x00\x00\x0e\x00\x00\x00\x00test_string\x00')
    assert reader.read_string() == b'test_string'



# Generated at 2022-06-22 06:57:34.978408
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    test_string = b'\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0A\x0B'
    reader = FlvReader(test_string)
    assert reader.read_string() == test_string[:-1]



# Generated at 2022-06-22 06:57:47.128198
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-22 06:59:54.119004
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    if __name__ == '__main__':
        # Create a F4mFD object and init it
        fm = F4mFD()
        fm.report_warning = mock.Mock()
        fm.report_error = mock.Mock()
        fm.ydl = mock.Mock()
        open_mock = mock.Mock()

# Generated at 2022-06-22 07:00:04.755672
# Unit test for function get_base_url
def test_get_base_url():
    xml_manifest_1 = '<manifest><baseURL>http://url.com</baseURL></manifest>'
    xml_manifest_2 = '<manifest><b/><baseURL>http://url.com</baseURL><a/></manifest>'
    xml_manifest_3 = '<manifest><baseURL>http://url.com</baseURL><baseURL>http://url2.com</baseURL></manifest>'
    xml_manifest_4 = '<manifest><baseURL>http://url.com</baseURL><b/><baseURL>http://url2.com</baseURL></manifest>'