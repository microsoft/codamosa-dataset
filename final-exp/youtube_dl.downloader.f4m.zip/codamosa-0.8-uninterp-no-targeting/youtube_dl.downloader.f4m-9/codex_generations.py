

# Generated at 2022-06-22 06:51:41.011670
# Unit test for function remove_encrypted_media

# Generated at 2022-06-22 06:51:50.634784
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    data = b'\x00\x00\x00\x25\x6d\x6f\x6f\x76\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x03\x8f\x6d\x6f\x6f\x76\x00\x00\x00\x03\x00\x00\x00\x01\x00\x00\x00\x01'
    assert FlvReader(data).read_box_info() == (37, b'moov', b'\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x03\x8f')



# Generated at 2022-06-22 06:51:55.893726
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    b = bytearray(b'\x00' * 1024)
    s = io.BytesIO(b)
    write_unsigned_int_24(s, 0x12345678)
    assert s.tell() == 3
    assert b[0:3] == b'\x12\x34\x56'



# Generated at 2022-06-22 06:51:59.481614
# Unit test for function build_fragments_list
def test_build_fragments_list():
    bootstrap = read_bootstrap_info(open(
        'tests/resources/bootstrap_live.abst', 'rb').read())
    assert boot_info_to_fragments_list(bootstrap) == [
        (3517, 23), (3517, 24), (3517, 25), (3517, 26)]



# Generated at 2022-06-22 06:52:11.884322
# Unit test for constructor of class F4mFD
def test_F4mFD():
    from io import BytesIO
    from xml.dom import minidom

    manifest_str = '<manifest xmlns="http://ns.adobe.com/f4m/1.0"></manifest>'
    assert(minidom.parseString(manifest_str) == minidom.parseString(manifest_str))


# Generated at 2022-06-22 06:52:14.510478
# Unit test for constructor of class F4mFD
def test_F4mFD():
    exc = False
    try:
        F4mFD('', {'format': 'mp4'})
    except TypeError:
        exc = True
    assert exc


# Generated at 2022-06-22 06:52:25.960252
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring('<manifest><baseURL>http://base</baseURL></manifest>')
    base_url = get_base_url(manifest)
    assert base_url == 'http://base'
    manifest = compat_etree_fromstring('<manifest><baseurl>http://base</baseurl></manifest>') # typo from Adobe
    base_url = get_base_url(manifest)
    assert base_url == 'http://base'
    manifest = compat_etree_fromstring('<manifest><baseURL>http://base</baseurl></manifest>') # both tag names
    base_url = get_base_url(manifest)
    assert base_url == 'http://base'
    manifest = compat_etree_fromstring('<manifest></manifest>')


# Generated at 2022-06-22 06:52:33.509059
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    data = b'\x00\x01\x02\x03\x04\x05'
    reader = FlvReader(data)
    assert reader.read_bytes(3) == b'\x00\x01\x02'
    assert reader.read_bytes(4) == b'\x03\x04\x05'
    try:
        reader.read_bytes(1)
        raise AssertionError('it should fail when reaching EOF')
    except DataTruncatedError:
        pass


# Generated at 2022-06-22 06:52:37.823097
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    f = FlvReader(compat_struct_pack('!Q',
                                     0x123456789abcdef0))
    assert f.read_unsigned_long_long() == 0x123456789abcdef0
    assert f.read_box_info() == (
        16, b'boxt', compat_struct_pack('!Q',
                                        0x123456789abcdef0))

# Generated at 2022-06-22 06:52:39.734159
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    bytes = io.BytesIO()
    write_unsigned_int(bytes, 200)
    assert bytes.getvalue() == b'\x00\x00\x00\xc8'



# Generated at 2022-06-22 06:53:03.034740
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    test_url = 'https://static-gaia.espn.com/i/espn/mlb/schedule/_assets/content/espn.m3u8'

# Generated at 2022-06-22 06:53:12.843221
# Unit test for function build_fragments_list

# Generated at 2022-06-22 06:53:18.695223
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    import os, random
    val = random.getrandbits(32)
    stream = io.BytesIO()
    write_unsigned_int(stream, val)
    stream.seek(0)
    read_val = compat_struct_unpack('!I', stream.read(4))[0]
    assert read_val == val



# Generated at 2022-06-22 06:53:21.390273
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    r = FlvReader(compat_struct_pack('!B', 255))
    char = r.read_unsigned_char()
    assert char == 255

# Generated at 2022-06-22 06:53:32.042354
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    # An example of media tag with encrypted fragment
    media1 = compat_etree_fromstring(
        '<media url="Encrypted.f4f" bitrate="998" '
        'drmAdditionalHeaderId="2" drmAdditionalHeaderSetId="2"/>')
    media2 = compat_etree_fromstring(
        '<media url="NotEncrypted.f4f" bitrate="998"/>')

    # These media tags contain an encrypted media
    assert remove_encrypted_media([media1, media2]) == [media2]
    # Empty media tags do not contain an encrypted media
    assert remove_encrypted_media([]) == []
    # Media tags contain only encrypted media
    assert remove_encrypted_media([media1]) == []



# Generated at 2022-06-22 06:53:39.568269
# Unit test for function write_flv_header
def test_write_flv_header():
    import io
    import sys
    stream = io.BytesIO()
    write_flv_header(stream)
    print(stream.getvalue())
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'
    try:
        stream.close()
    except AttributeError:
        pass

# Generated at 2022-06-22 06:53:50.855920
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    flv_reader = FlvReader(b'\x00\x61\x00\x62\x00\x63\x00\x00\x61\x61\x00\x62\x00\x63\x00\x00')
    assert flv_reader.read_string() == b'a'
    assert flv_reader.read_string() == b'b'
    assert flv_reader.read_string() == b'c'
    assert flv_reader.read_string() == b''
    assert flv_reader.read_string() == b'aa'
    assert flv_reader.read_string() == b'b'
    assert flv_reader.read_string() == b'c'
    assert flv_reader.read_string() == b''



# Generated at 2022-06-22 06:53:54.685796
# Unit test for function write_flv_header
def test_write_flv_header():
    out = io.BytesIO()
    write_flv_header(out)
    assert out.getvalue() == b'FLV\x01\x05\x00\x00\x00\t\x00\x00\x00\x00'



# Generated at 2022-06-22 06:53:59.910669
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    r = FlvReader(b'abcd\x00wxyz\x00')
    assert r.read_string() == b'abcd'
    assert r.read_string() == b'wxyz'
    assert r.tell() == 9



# Generated at 2022-06-22 06:54:05.202207
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    stream.seek(0)
    assert stream.read() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-22 06:54:23.467883
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    example_flv = b'\x00\x00\x00\x1C\x66\x74\x79\x70\x61\x73\x73\x76\x30'
    reader = FlvReader(example_flv)
    assert reader.read_box_info() == (28, b'ftyp', b'assv0')
    assert reader.read_box_info() == (0, b'assv', b'')


# Generated at 2022-06-22 06:54:26.324858
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    fr = FlvReader(compat_struct_pack('!I4s', 10, b'abst'))
    assert fr.read_string() == 'ab'


# Generated at 2022-06-22 06:54:34.066229
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    flv_reader = FlvReader(b'12345678')
    assert flv_reader.read_bytes(4) == b'1234'
    assert flv_reader.read_bytes(3) == b'567'
    assert flv_reader.read_bytes(2) == b'78'

    flv_reader = FlvReader(b'12345')
    try:
        flv_reader.read_bytes(6)
        assert False
    except DataTruncatedError:
        pass

# Generated at 2022-06-22 06:54:45.625684
# Unit test for constructor of class FlvReader

# Generated at 2022-06-22 06:54:57.537629
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    with open('bootstrap', 'rb') as f:
        bootstrap = f.read()
    bootstrap = compat_b64decode(bootstrap)
    bootstrap_info = FlvReader(bootstrap).read_bootstrap_info()
    # print(bootstrap_info)
    # {'live': True,
    # 'segments': [{'segment_run': [(0, 1), (1, 1)]}, {'segment_run': [(0, 1)]}],
    # 'fragments': [
    #     {'fragments': [{'duration': 0, 'discontinuity_indicator': 0,
    #                     'first': 0, 'ts': 0}, {'duration': 0,
    #                                                     'discontinuity_indicator': 0, 'first': 1, 'ts':

# Generated at 2022-06-22 06:55:04.914198
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    assert FlvReader(compat_struct_pack('!Q', 0x123456789abcdef0)).read_unsigned_long_long() == 0x123456789abcdef0
    assert FlvReader(compat_struct_pack('!Q', 0x0)).read_unsigned_long_long() == 0x0
    assert FlvReader(compat_struct_pack('!Q', 0xffffffffffffffff)).read_unsigned_long_long() == 0xffffffffffffffff


# Generated at 2022-06-22 06:55:15.910836
# Unit test for function build_fragments_list

# Generated at 2022-06-22 06:55:28.439370
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-22 06:55:40.683791
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Test download of video from url:
    # https://s1.yimg.com/nl/sambafoot/site/f_100p_videos/sambafoot-all-goals-algeria.f4m
    url = 'https://s1.yimg.com/nl/sambafoot/site/f_100p_videos/sambafoot-all-goals-algeria.f4m'
    ydl_opts = {} # type: Dict[str, Any]
    ydl_opts.update({'nooverwrites': True, 'quiet': True})
    ydl_opts.update({'outtmpl': 'test.%(ext)s'})
    ydl = YoutubeDL(ydl_opts)

# Generated at 2022-06-22 06:55:47.766939
# Unit test for function get_base_url
def test_get_base_url():
    manifest_template = '''<manifest xmlns="http://ns.adobe.com/f4m/1.0">
    <baseURL>%s</baseURL>
</manifest>'''
    expected = 'http://example.org/'

    manifest = compat_etree_fromstring(manifest_template % expected)
    url = get_base_url(manifest)
    if url != expected:
        raise AssertionError('Expected %r, got %r' % (expected, url))



# Generated at 2022-06-22 06:56:11.996403
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        b'''
        <manifest xmlns="http://ns.adobe.com/f4m/1.0"
         xmlns:media="http://search.yahoo.com/mrss/"
         xmlns:yt="http://youtube.com/yt/2012/10/10">
         <baseURL>http://example.com/base/url/</baseURL>
         <media>some/resource</media>
        </manifest>''')
    assert get_base_url(manifest) == 'http://example.com/base/url/'

# Generated at 2022-06-22 06:56:24.681627
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    # The binary data is generated with the scripts/get_f4f_bootstrap_info.py script
    reader = FlvReader(
        compat_b64decode(b'''
AAAAAABABMDoACEAAAABAAEAMQBDADABQAAAQABAR8AEAAWAAAAAAAB
BAAAAABEAAAAAIAAAABAAABAAAAEgAAABAAACAAAABAADAAAAEAAAB
AAAAMQAAABAAABAAAAEgAAABAAABAAAAAgAAABAAACAAAAAQAAABAA
AQAAAAEAAAAEAAAEAAAABAAAAAAABEAAAAIAAAABAAABAADABAAAA
EAAAEAAAAAAAAAAAAAIAAAAEAAAAAgAAAAEAAAEABQAAAAQAAAAAAA
AAAAABAAAAAAAAAAAAAAAAAAAAAAA=
'''))

# Generated at 2022-06-22 06:56:28.352472
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    l = [{'drmAdditionalHeaderId': '1', "drmAdditionalHeaderSetId": '2'},
         {'drmAdditionalHeaderId': '1', "drmAdditionalHeaderSetId": '0'}]
    assert remove_encrypted_media(l) == [{'drmAdditionalHeaderId': '1', "drmAdditionalHeaderSetId": '0'}]



# Generated at 2022-06-22 06:56:38.768321
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-22 06:56:40.263725
# Unit test for constructor of class F4mFD
def test_F4mFD():
    fd = F4mFD({})
    assert fd is not None

# Generated at 2022-06-22 06:56:46.878637
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = b'testdata/f4m_test_asrt.bin'
    with open(data, 'rb') as f:
        content = f.read()
    asrt = FlvReader(content).read_asrt()
    assert asrt['segment_run'] == [
        (0, 1),
        (2, 1),
        (3, 1),
        (4, 1),
        (5, 1),
        (6, 1),
    ]



# Generated at 2022-06-22 06:56:52.222668
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    f = io.BytesIO(compat_struct_pack('!4i', 1, 2, 3, 4))
    reader = FlvReader(f.read())
    assert reader.read_bytes(4) == compat_struct_pack('!i', 1)
    assert reader.read_bytes(4) == compat_struct_pack('!i', 2)
    try:
        reader.read_bytes(1)
    except DataTruncatedError:
        assert True
    else:
        assert False



# Generated at 2022-06-22 06:56:56.529234
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    r = FlvReader(b'\x01\x00\x00\x00\xaf')
    assert r.read_unsigned_char() == 1
    assert r.read_unsigned_char() == 0
    assert r.read_unsigned_char() == 0
    assert r.read_unsigned_char() == 0
    assert r.read_unsigned_char() == 175


# Generated at 2022-06-22 06:57:00.470374
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError
    except DataTruncatedError as e:
        assert isinstance(e, Exception)
        assert isinstance(e, DataTruncatedError)



# Generated at 2022-06-22 06:57:11.040816
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x30'
        b'asrt'
        b'\x00'
        b'\x00\x00\x00'
        b'\x02'
        b'\x00\x00\x00\x03'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x02'
        b'\x00\x00\x00\x00'
        b'\x00\x00\x00\x03'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x02'
    )
    box = FlvReader(data).read_asrt()

# Generated at 2022-06-22 06:57:31.174704
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    metadata = b'\x02\x00\x0a6\x00\x08\x00\x01'
    from io import BytesIO
    stream = BytesIO()

    write_metadata_tag(stream, metadata)

    assert stream.getvalue() == b'\x12\x00\x00\x07\x00\x00\x00\x00\x00\x00\x00\x02\x00\n6\x00\x08\x00\x01\x00\x00\x00\x1b'


# Generated at 2022-06-22 06:57:43.844943
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
	downloader = F4mFD("", "", {})
	info_dict = {
		"url": "http://csm-e.cineplex.com/movies/media/trr/cm_bbff_med_2014_05_20.f4m",
		"protocol": "http"
	}
	filename = "cm_bbff_med_2014_05_20.mp4"

	result = downloader.real_download(filename, info_dict)
	if not result:
		raise Exception("real_download of F4mFD failed")

	if not os.path.isfile(os.path.join(os.getcwd(), filename)):
		raise Exception("real_download of F4mFD failed (file not found)")


# Generated at 2022-06-22 06:57:49.532837
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    test_data = b'\x00\x00\x00\x2c\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'

# Generated at 2022-06-22 06:58:00.865284
# Unit test for constructor of class FlvReader

# Generated at 2022-06-22 06:58:05.797495
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    stream = io.BytesIO()
    metadata = b'<?xml version="1.0" encoding="utf-8"?>'
    write_metadata_tag(stream, metadata)
    header = stream.getvalue()[:8]
    assert header == b'\x12\x00\x00\x00\x00\x00\x00\x00'



# Generated at 2022-06-22 06:58:16.968745
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-22 06:58:27.697569
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    import json
    import os.path
    import hashlib
    sampl_metadata = {"width": 1920, "duration": 12.5666667,
                      "height": 1080, "videodatarate": 6548.979,
                      "audiodatarate": 104.424, "framerate": 24.99,
                      "videocodecid": "avc1", "audiosamplerate": 44.1,
                      "audiosamplesize": 16.0, "filesize": 28960.0, "audiosizelength": 2.0,
                      "stereo": True, "audiocodecid": "mp4a"}
    fp = io.BytesIO()
    write_flv_header(fp)

# Generated at 2022-06-22 06:58:33.635087
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    assert write_unsigned_int(io.BytesIO(), 0) == b'\x00\x00\x00\x00'
    assert write_unsigned_int(io.BytesIO(), 2147483647) == b'\xff\xff\xff\x7f'
    assert write_unsigned_int(io.BytesIO(), 4294967295) == b'\xff\xff\xff\xff'
test_write_unsigned_int()



# Generated at 2022-06-22 06:58:40.937804
# Unit test for function write_flv_header
def test_write_flv_header():
    from .test import make_temp_copy
    f = make_temp_copy('hds_f4m_url')
    with open(f, 'wb') as stream:
        write_flv_header(stream)
    assert open(f, 'rb').read(13) == (
        b'FLV\x01\x05\x00\x00\x00\x09'
        b'\x00\x00\x00\x00')



# Generated at 2022-06-22 06:58:43.027733
# Unit test for function write_flv_header
def test_write_flv_header():
    f = io.BytesIO()
    write_flv_header(f)
    f.seek(0)
    assert f.read() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-22 06:59:14.027090
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    reader = FlvReader(b'\x00\x00\x00\x08')
    assert reader.read_unsigned_int() == 8
    reader = FlvReader(b'\x00\x00\x00\x01\x00\x00\x00\x08')
    assert reader.read_unsigned_int() == 1
    reader = FlvReader(b'\x00\x00\x00\x01\x00\x00\x00\x08')
    assert reader.read_unsigned_int() == 1
    reader = FlvReader(b'\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x08')

# Generated at 2022-06-22 06:59:22.371519
# Unit test for method read_string of class FlvReader

# Generated at 2022-06-22 06:59:27.500190
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    asrt = b'\x01\x00\x00\x00\x01\x00\x00\x00\x01\x03\x00\x00\x00\x00\x00\x00\x00\x01\x05\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    fr = FlvReader(asrt)
    res = fr.read_asrt()
    assert res['segment_run'] == [
        (1, 3),
        (5, 0),
    ]

# Generated at 2022-06-22 06:59:37.208961
# Unit test for constructor of class FlvReader

# Generated at 2022-06-22 06:59:47.459133
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-22 06:59:51.467821
# Unit test for constructor of class F4mFD
def test_F4mFD():
    f = F4mFD().real_download


# Unit test
if __name__ == '__main__':
    import sys

    boot_info = read_bootstrap_info(open(sys.argv[1], 'rb').read())
    import json
    print(json.dumps(build_fragments_list(boot_info)))

# Generated at 2022-06-22 07:00:02.994114
# Unit test for function get_base_url
def test_get_base_url():
    assert get_base_url(compat_etree_fromstring('<manifest/>')) is None
    assert get_base_url(compat_etree_fromstring(
        '<manifest><baseURL>http://example.com</baseURL></manifest>')) == \
        'http://example.com'
    assert get_base_url(compat_etree_fromstring(
        '<manifest><baseURL> http://example.com </baseURL></manifest>')) == \
        'http://example.com'