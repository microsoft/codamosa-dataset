

# Generated at 2022-06-22 06:51:06.555357
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Test case for real_download method of class F4mFD
    #
    # Inputs:
    #     filename:
    #            Name of the output files
    #     info_dict:
    #            A dictionary of the form:
    #                -'url': the url of the manifest
    #                -'live': a boolean
    #                -'tbr': bitrate
    #
    # Expected output:
    #     True if the download is successful
    #

    #TODO: implement unit test for F4mFD class
    pass

# Generated at 2022-06-22 06:51:09.832106
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    assert write_unsigned_int_24(io.BytesIO(), 1) == b'\x00\x00\x01'



# Generated at 2022-06-22 06:51:14.337735
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    stream = io.BytesIO()
    for i in range(16777215):
        write_unsigned_int_24(stream, i)
    assert stream.getvalue() == (b'\x00' * 4 + b'\x01' * 4 + b'\x02' * 4)[:-1]



# Generated at 2022-06-22 06:51:22.314844
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    file_data = b'\x00\x00\x00\x1c\x61\x73\x72\x74\x01\x00\x00\x00\x02' + \
               b'\x00\x00\x00\x61\x73\x73\x65\x74\x62\x31\x00\x00\x00' + \
               b'\x04\x00\x00\x00\x00\x10\x00\x00'
    assert FlvReader(file_data).read_asrt() == \
        {'segment_run': [(0, 16)]}


# Generated at 2022-06-22 06:51:34.674509
# Unit test for constructor of class FlvReader
def test_FlvReader():
    from .common import version_tuple

    if version_tuple >= (3, ):
        from base64 import b64decode as compat_b64decode
    data = 'AAAAIGZ0eXBpc29tAAAAAG1wNDFhdmMxAAAACGZyZWUAAAAgbWRoZAAAAAAALWhkbHIAAAAAAAAAAHZpZGUAAAAAAAAAAAAAAABEaXJlY3QAAAAzJtXEAAAAADNbW9kRgAAAAA='.encode('utf-8')
    data = compat_b64decode(data)
    bootstrap_info = FlvReader(data).read_bootstrap_info()

# Generated at 2022-06-22 06:51:45.746821
# Unit test for function read_bootstrap_info

# Generated at 2022-06-22 06:51:56.961768
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    from .fragment import (
        SegmentInfo,
    )
    segment_url = 'http://example.com/segment.flv'
    segment_info = SegmentInfo('name', SegmentInfo.MODE_LIVE, 1.0, 0, 0, segment_url)

# Generated at 2022-06-22 06:52:06.094373
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    # Content of box_data_asrt is grabbed from real f4f file
    box_data_asrt = b'\x00\x00\x00\x20\x00\x00\x00\x01\x00\x00\x00\x04\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x01\x90@'
    flv_reader = FlvReader(box_data_asrt)
    res = flv_reader.read_asrt()
    assert res['segment_run'] == [(0, 400)]



# Generated at 2022-06-22 06:52:16.418069
# Unit test for constructor of class FlvReader

# Generated at 2022-06-22 06:52:28.262845
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-22 06:53:20.372973
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    reader = FlvReader(b'\x00\x01\x00\x02\x00\x03\x00\x04\x00')
    assert reader.read_string() == b''
    assert reader.read_string() == b'\x01'
    assert reader.read_string() == b'\x01\x02'
    assert reader.read_string() == b'\x01\x02\x03'
    assert reader.read_string() == b'\x01\x02\x03\x04'
    reader.read_bytes(1)


# Generated at 2022-06-22 06:53:28.964416
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.postprocessor.metadata import Metadata

    class F4mFD_test(F4mFD):
        def _download_fragment(self, ctx, fragment_url, info_dict):
            return True, b'\x00\x00\x00\x00'

        def _prepare_frag_download(self, ctx):
            pass

        def _start_frag_download(self, ctx):
            pass

        def _append_fragment(self, ctx, fragment):
            pass

        def _finish_frag_download(self, ctx):
            pass


# Generated at 2022-06-22 06:53:30.051850
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    DataTruncatedError()



# Generated at 2022-06-22 06:53:33.170056
# Unit test for function write_flv_header
def test_write_flv_header():
    assert write_flv_header(io.BytesIO()) == b'FLV\x01\x05\x00\x00\x00\t\x00\x00\x00\x00'



# Generated at 2022-06-22 06:53:34.197227
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    pass




# Generated at 2022-06-22 06:53:42.022788
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-22 06:53:54.093769
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-22 06:53:59.808853
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    one_byte_string = b'\x00'
    three_bytes_string = b'abc\x00'
    assert FlvReader(one_byte_string).read_string() == b''
    assert FlvReader(three_bytes_string).read_string() == b'abc'


# Generated at 2022-06-22 06:54:05.692952
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():

#     filePath = r'C:\Users\m\Downloads\video.mp4'
    filePath = r'/home/m/Downloads/video.mp4'

    if 'Windows' in platform.system():
        pass
        # filename = 'C:\Users\m\Downloads\video.mp4'
    else:
        pass


    info_dict = {
        'url': 'http://download.tsi.telecom-paristech.fr/gpac/DASH_CONFORMANCE/TelecomParisTech/mp4-live-inband-track-selection/mp4-live-inband-track-selection-a1.f4m',
        'tbr': None
    }

    f4mFD = F4mFD()


# Generated at 2022-06-22 06:54:10.987741
# Unit test for function write_flv_header
def test_write_flv_header():
    import io
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == (
        b'FLV\x01'
        b'\x05'
        b'\x00\x00\x00\x09'
        b'\x00\x00\x00\x00'
    )
test_write_flv_header()



# Generated at 2022-06-22 06:54:52.116828
# Unit test for constructor of class FlvReader
def test_FlvReader():
    flv_reader = FlvReader(b'test data')
    assert flv_reader.read_unsigned_char() == ord(b't')
    assert flv_reader.read_unsigned_char() == ord('e')
    assert flv_reader.read_string() == b'st '
    assert flv_reader.read_string() == b'dat'
    assert flv_reader.read_unsigned_char() == 0
    assert flv_reader.read_unsigned_char() == ord('a')
    assert flv_reader.read_bytes(3) == b'\x00\x00\x00'
    assert flv_reader.read_unsigned_long_long() == 0
    assert flv_reader.read_unsigned_int() == 0



# Generated at 2022-06-22 06:54:56.559421
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    res = io.BytesIO()
    write_unsigned_int(res, 4294967295)
    assert res.getvalue() == b'\xff\xff\xff\xff'



# Generated at 2022-06-22 06:55:02.846720
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    flv_reader = FlvReader(b'123456\x00')
    assert flv_reader.read_bytes(1) == b'1'
    assert flv_reader.read_bytes(5) == b'23456\x00'
    try:
        flv_reader.read_bytes(1)
        assert False
    except DataTruncatedError:
        assert True


# Generated at 2022-06-22 06:55:13.440956
# Unit test for function build_fragments_list

# Generated at 2022-06-22 06:55:16.135200
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    reader = FlvReader(b'\x31')
    assert reader.read_unsigned_char() == 49


# Generated at 2022-06-22 06:55:28.721386
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    abst_info = FlvReader(open('tests/fixtures/bootstrap_abst.dat', 'rb').read()).read_abst()
    assert abst_info['segments'][0]['segment_run'][0] == (1, 2)
    assert abst_info['segments'][0]['segment_run'][1] == (3, 4)
    assert abst_info['fragments'][0]['fragments'][0] == {'first': 0, 'ts': 0, 'duration': 0, 'discontinuity_indicator': 0}
    assert abst_info['fragments'][0]['fragments'][1] == {'first': 1, 'ts': 20000, 'duration': 10000, 'discontinuity_indicator': None}

# Generated at 2022-06-22 06:55:39.933927
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    s = io.BytesIO()
    tags = bytearray(b'\x02\x00\x06onMetaData\x08\x00\x00\x00\x00\x00\x00\x00\x00')
    write_metadata_tag(s, tags)
    assert s.getvalue() == (
        b'\x12\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
        b'\x02\x00\x06onMetaData\x08\x00\x00\x00\x00\x00\x00\x00\x00')



# Generated at 2022-06-22 06:55:48.060956
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    # Test 1
    # Test case with one encrypted media in the list
    # The list has two elements but after the function call,
    # the list has one element because it removes the encrypted media
    media_list = [
        {
            'id': 'id1',
            'drmAdditionalHeaderId': 'drmAdditionalHeaderId1',
            'drmAdditionalHeaderSetId': 'drmAdditionalHeaderSetId1',
            'url': 'url1'
        },
        {
            'id': 'id2',
            'url': 'url2'
        }
    ]

# Generated at 2022-06-22 06:55:57.645802
# Unit test for constructor of class F4mFD
def test_F4mFD():
    """
    SIMPLE TEST FOR F4mFD CONSTRUCTOR
    """
    ydl = YoutubeDL({})
    f4mfd = F4mFD(ydl, {'url': 'http://www.url.com/video.f4m', 'title': 'Test'})
    assert not f4mfd is None
    assert f4mfd.ydl is ydl
    assert f4mfd.params == {'url': 'http://www.url.com/video.f4m', 'title': 'Test'}

if __name__ == '__main__':
    test_F4mFD()

# Generated at 2022-06-22 06:56:08.459752
# Unit test for constructor of class FlvReader

# Generated at 2022-06-22 06:57:18.270098
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    DATA = (
        b'\x00\x00\x00\xcb'
        b'asrt'
        b'\x00\x00\x00\x00'
        b'\x01'
        b'QualityLevels(600000,450000,300000,150000)'
        b'\x00\x00\x00\x06\x00\x00\x00\x02\x00\x00\x00\x02\x00\x00\x00\x03')
    assert FlvReader(DATA).read_asrt() == {
        'segment_run': [
            (0, 2),
            (2, 3),
        ]
    }



# Generated at 2022-06-22 06:57:24.070476
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring('''\
<manifest xmlns="http://ns.adobe.com/f4m/2.0"><baseURL>http://my_url.com</baseURL></manifest>''')
    assert get_base_url(manifest) == 'http://my_url.com'



# Generated at 2022-06-22 06:57:28.597262
# Unit test for function write_flv_header
def test_write_flv_header():
    from io import BytesIO
    f = BytesIO()
    write_flv_header(f)
    assert f.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-22 06:57:40.076999
# Unit test for function build_fragments_list

# Generated at 2022-06-22 06:57:44.600172
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    write_unsigned_int(stream, 9)
    stream.seek(0)
    assert stream.read() == b'\x00\x00\x00\t'



# Generated at 2022-06-22 06:57:48.869744
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import io
    import urllib
    import sys
    url = 'http://ferrari-vr-live-prod.hls.adaptive.level3.net/ferrari/formula1/2015/canada/race/1/master.m3u8'
    url_data = urlopen(url).read()
    media_url = re.findall(r'^http.*\.m3u8', url_data, flags=re.MULTILINE)[0]
    print(media_url)
    #===========================================================================
    # for i in range(10):
    #     print('Fetching URL %s' % media_url)
    #     url_data = urllib.urlopen(media_url).read()
    #     ts_urls = re.findall(r'^http.*\.

# Generated at 2022-06-22 06:58:00.388548
# Unit test for constructor of class F4mFD
def test_F4mFD():
    # check for missing 'url' attribute in the manifest
    info_dict = {'url': 'http://www.example.com/manifest.f4m'}
    fd = F4mFD(ydl=None, params=None, info_dict=info_dict)
    assert fd._get_unencrypted_media(fd._parse_manifest('<manifest></manifest>')) == []

    # check for missing 'bitrate' attribute in the media
    info_dict = {'url': 'http://www.example.com/manifest.f4m'}
    fd = F4mFD(ydl=None, params=None, info_dict=info_dict)

# Generated at 2022-06-22 06:58:09.241272
# Unit test for function build_fragments_list
def test_build_fragments_list():
    """Test for function build_fragments_list"""
    bootstrap_bytes = compat_b64decode(
        'AAAAHGZ0eXBpc29tAAAAAG1wNDFhdmMxAAAIA21kYXQAAAAEAAAAAMm5CQAAAFUAAABZU0J'
        'HUiBPcGVyYXNpb24gUHJhZGVzaWMgQ29udGVudCBCYXNlAAAAAEU3d3cucGF5bG9hZHNkZWxl'
        'dGNoLmNvbQAAAAkAFoAAA==')
    bootstrap_info = read_bootstrap_info(bootstrap_bytes)
    fragments = build_fragments_list(bootstrap_info)
    print(fragments)
   

# Generated at 2022-06-22 06:58:19.649420
# Unit test for constructor of class FlvReader

# Generated at 2022-06-22 06:58:31.183458
# Unit test for function remove_encrypted_media