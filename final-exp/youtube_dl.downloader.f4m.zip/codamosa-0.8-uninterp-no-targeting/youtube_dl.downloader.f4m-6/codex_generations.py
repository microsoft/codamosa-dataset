

# Generated at 2022-06-22 06:50:52.833758
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-22 06:51:00.975866
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    string = u'abcdef\u2603'
    data = (
        compat_struct_pack('!I4s', len(string)+5, b'abcd') +
        string.encode('utf-8') + b'\x00'
    )
    reader = FlvReader(data)
    assert reader.read_bytes(8) == compat_struct_pack('!I4s', len(string)+5, b'abcd')
    assert reader.read_string() == string



# Generated at 2022-06-22 06:51:12.613254
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    def test_eq(e, e2):
        assert e.__str__() == 'The file pointing to "%s" is truncated.' % e.url
        assert e.__unicode__() == 'The file pointing to "%s" is truncated.' % e.url
        assert e == e2
    e = DataTruncatedError('url', 'expected_length', 'actual_length')
    test_eq(e, e)
    e2 = DataTruncatedError('url', 'expected_length', 'actual_length')
    test_eq(e, e2)
    b = bytes(e)
    assert b == 'Expected length: expected_length, actual length: actual_length, url: url'
    assert bytes(e) == b

# Generated at 2022-06-22 06:51:17.137753
# Unit test for function write_flv_header
def test_write_flv_header():
    out = io.BytesIO()
    write_flv_header(out)
    assert out.getvalue() == (b'FLV\x01\x05\x00\x00\x00\x09'
                              b'\x00\x00\x00\x00')
# End of unit test



# Generated at 2022-06-22 06:51:21.725820
# Unit test for function write_flv_header
def test_write_flv_header():
    stream_ = io.BytesIO()
    write_flv_header(stream_)
    assert stream_.getvalue() == b'FLV\x01\x05\x00\x00\x00\t\x00\x00\x00\x00'




# Generated at 2022-06-22 06:51:34.059494
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Create a F4mFD object
    f4mFD = F4mFD("testUser", "testPassword", "testDownloadPath")
    # Create a dictionary that contains the information about the video to download
    testInfoDict = {"url": "testUrl", "tbr": 1000}
    # Create a file object that represents the file where to store the downloaded video
    testFile = open("testDownloadPath", "wb")
    try:
        # Execute the real_download method of the f4mFD object with the file and info dictionary as parameters
        f4mFD.real_download(testFile, testInfoDict)
    except:
        # If any exception was raised, return False
        return False
    # Otherwise, return True
    return True


# Class that represents the result of a unit test

# Generated at 2022-06-22 06:51:36.616790
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    data_truncated_error = DataTruncatedError()
    assert isinstance(data_truncated_error, Exception)
    assert True


# Generated at 2022-06-22 06:51:40.412566
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    '''
    Test read_unsigned_long_long function
    '''
    f1 = io.BytesIO(compat_struct_pack('!Q', 100))
    f2 = FlvReader(f1.read())
    assert f2.read_unsigned_long_long() == 100


# Generated at 2022-06-22 06:51:45.631068
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    import random
    stream = io.BytesIO()
    for i in range(1000):
        val = random.randint(1, 2 ** 24 - 1)
        write_unsigned_int_24(stream, val)
        stream.seek(0)
        res = compat_struct_unpack('!I', b'\x00' + stream.read(3))[0]
        assert res == val
        stream.seek(0)
        stream.truncate()



# Generated at 2022-06-22 06:51:56.917663
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    import base64
    from io import BytesIO


# Generated at 2022-06-22 06:52:18.292802
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    io = FlvReader(b'\x01\x00\x00\x00\x00\x00\x00\x00')
    assert io.read_unsigned_long_long() == 1

# Generated at 2022-06-22 06:52:29.160427
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    flv_data = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    assert FlvReader(flv_data).read_box_info() == (0, b'\x00\x00\x00\x00', b'')
    flv_data = b'\x00\x00\x00\x08\x00\x00\x00\x00\x00\x00\x00\x00'
    assert FlvReader(flv_data).read_box_info() == (8, b'\x00\x00\x00\x00', b'')

# Generated at 2022-06-22 06:52:38.934154
# Unit test for function build_fragments_list

# Generated at 2022-06-22 06:52:39.894785
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    exc = DataTruncatedError()
    str(exc)



# Generated at 2022-06-22 06:52:42.915820
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    a = DataTruncatedError('test')
    assert str(a) == 'test'

# Generated at 2022-06-22 06:52:55.187335
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    drm_header = '<drmAdditionalHeaderId>0</drmAdditionalHeaderId>\
        <drmAdditionalHeaderSetId>0</drmAdditionalHeaderSetId>'
    media_with_drm_header = '<media url="https://adaptive.example.com/\
        master.m3u8" bitrate="1248" width="1248" height="712" ' +\
        drm_header + '/>'
    media_without_drm_header = '<media url="https://adaptive.example.com/\
        master.m3u8" bitrate="1248" width="1248" height="712" />'

# Generated at 2022-06-22 06:53:01.438396
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    test_data = b'\x00\x01\x02\x03\x04\x05\x06\x07'
    reader = FlvReader(test_data)
    assert reader.read_unsigned_long_long() == 0x0706050403020100
    assert reader.read_unsigned_long_long() == 0x0706050403020100



# Generated at 2022-06-22 06:53:12.230892
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    f = io.BytesIO(b'\x00\x01\x00\x03\x00\x06\x00\x08A\x00BC\x00D0123\x00\x00\x00')
    flvreader = FlvReader(f)
    assert flvreader.read_string() == b''
    assert flvreader.read_string() == b'\x01'
    assert flvreader.read_string() == b''
    assert flvreader.read_string() == b'\x03'
    assert flvreader.read_string() == b'\x00\x06'
    assert flvreader.read_string() == b'\x00\x08A'
    assert flvreader.read_string() == b'BC'
    assert flvreader.read_

# Generated at 2022-06-22 06:53:16.001228
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    result = FlvReader(b'test\x00').read_string()
    assert result == b'test'



# Generated at 2022-06-22 06:53:23.156979
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    x = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    assert FlvReader(x).read_unsigned_long_long() == 0
    x = b'\x00\xff\xff\xff\xff\xff\xff\xff'
    assert FlvReader(x).read_unsigned_long_long() == (1 << 56) - 1
    x = b'\xff\xff\xff\xff\xff\xff\xff\xff'
    assert FlvReader(x).read_unsigned_long_long() == (1 << 64) - 1



# Generated at 2022-06-22 06:53:57.077226
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from .extractor.common import InfoExtractor
    from .downloader.f4m import F4mFD
    
    f4m_manifest_url = "http://www.streambox.fr/playlists/test_001/stream.m3u8"
    
    ci = InfoExtractor({})
    ci.set_downloader(YoutubeDL({}))
    ci.add_default_info_extractors()
    
    F4mFD.real_download(ci, ci.cache_fn, {'url': f4m_manifest_url})

if __name__ == '__main__':
    test_F4mFD_real_download()

# Generated at 2022-06-22 06:54:02.745695
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # We test the method real_download of the class F4mFD to make
    # sure that it works well.
    # First, we need to initialize the downloader
    # For this unit test, we use a YouTube video
    test_url = 'https://www.youtube.com/watch?v=J---aiyznGQ'
    ydl_opts = {
        'outtmpl': '%(id)s.%(ext)s',
        'format': 'mp4',
    }
    ydl = YoutubeDL(ydl_opts)
    video_info = ydl.extract_info(test_url, download=False)
    # Second, we need to initialize the f4mFD
    fd = F4mFD(ydl=ydl)

    # Third, we need an info dict.
   

# Generated at 2022-06-22 06:54:16.320048
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    urls = []
    sources = []
    if os.path.isdir("../misc/test_data"):
        urls = [line.strip() for line in open("../misc/test_data/f4m_urls.txt")]
    elif os.path.isdir("test_data"):
        urls = [line.strip() for line in open("test_data/f4m_urls.txt")]
    for url in urls:
        with YoutubeDL(params={'noprogress': True}) as ydl:
            # ydl.add_default_info_extractors()
            entry = ydl.extract_info(url, download=False)

# Generated at 2022-06-22 06:54:26.520351
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    def read_test_file(test_file):
        with open(test_file, 'rb') as f:
            data = f.read()
            return FlvReader(data).read_afrt()


# Generated at 2022-06-22 06:54:29.091260
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError('test_DataTruncatedError')
    except DataTruncatedError:
        pass


# Generated at 2022-06-22 06:54:39.614235
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    data = b'\x00\x00\x00\x01' + b'type' + b'\x01'
    reader = FlvReader(data)
    box_size, box_type, box_data = reader.read_box_info()
    assert box_size == 1
    assert box_type == b'type'
    assert box_data == b'\x01'

    data = b'\x00\x00\x00\x0C' + b'type' + b'\x01\x02\x03\x04\x05\x06\x07\x08\x09'
    reader = FlvReader(data)
    box_size, box_type, box_data = reader.read_box_info()
    assert box_size == 12

# Generated at 2022-06-22 06:54:51.841610
# Unit test for constructor of class FlvReader

# Generated at 2022-06-22 06:55:02.387059
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    import binascii

# Generated at 2022-06-22 06:55:13.093162
# Unit test for function remove_encrypted_media

# Generated at 2022-06-22 06:55:15.217116
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    f = FlvReader(b'\x01\x02\x03\x04\x05\x06\x07\x08')
    assert f.read_unsigned_long_long() == 0x807060504030201
    assert f.read() == b''



# Generated at 2022-06-22 06:56:20.910630
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    parser = FlvReader()
    # 32-bit size
    s = compat_struct_pack('!I4s', 12, b'abcd')
    assert parser.read_box_info() == (12, b'abcd', b'')
    parser = FlvReader(s)
    assert parser.read_box_info() == (12, b'abcd', b'')
    # 64-bit size
    s = compat_struct_pack('!I4sQ4s', 1, b'bcde', 16, b'efgh')
    assert parser.read_box_info() == (16, b'bcde', b'efgh')
    parser = FlvReader(s)
    assert parser.read_box_info() == (16, b'bcde', b'efgh')


# Reader for Adobe HDS

# Generated at 2022-06-22 06:56:25.654916
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    vals = [0, 1, 2**30, 2**31-1, 2**32-1, 2**63-1]
    for val in vals:
        r = FlvReader(compat_struct_pack('!I', val))
        assert r.read_unsigned_int() == val

# Generated at 2022-06-22 06:56:31.996882
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-22 06:56:37.461354
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    w = io.BytesIO(b'123456')
    obj = FlvReader(w.read())
    
    # Test method read_bytes
    result = obj.read_bytes(2)
    assert result == b'12', 'Failed at test_FlvReader_read_bytes'
    result = obj.read_bytes(4)
    assert result == b'3456', 'Failed at test_FlvReader_read_bytes'


# Generated at 2022-06-22 06:56:47.522371
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    fh = io.open('tests/bootstrap_info.bin', 'rb')
    data = fh.read()
    fh.close()

# Generated at 2022-06-22 06:56:56.041642
# Unit test for method read_string of class FlvReader

# Generated at 2022-06-22 06:57:01.002104
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-22 06:57:11.822204
# Unit test for function build_fragments_list

# Generated at 2022-06-22 06:57:15.785684
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    assert FlvReader(b'\x00').read_string() == b''
    assert FlvReader(b'a\x00').read_string() == b'a'
    assert FlvReader(b'ab\x00').read_string() == b'ab'



# Generated at 2022-06-22 06:57:20.459728
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    b = io.BytesIO()
    write_unsigned_int(b, 4)
    write_unsigned_int(b, 1)
    write_unsigned_int(b, 0)
    assert b.getvalue() == b'\x00\x00\x00\x04\x00\x00\x00\x01\x00\x00\x00\x00'
test_write_unsigned_int()

