

# Generated at 2022-06-22 06:51:31.763437
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    flv_reader = FlvReader(b'hola\x00adio')
    assert flv_reader.read_string() == b'hola'
    assert flv_reader.read_string() == b'adio'



# Generated at 2022-06-22 06:51:39.712345
# Unit test for function write_flv_header
def test_write_flv_header():
    from .test import PL_HD_VIDEO
    with io.BytesIO(PL_HD_VIDEO) as pl_hd:
        pl_hd.seek(8)
        assert pl_hd.read(4) == b'\x05\x00\x00\x00'
    stream = io.BytesIO()
    write_flv_header(stream)
    stream.seek(0)
    assert stream.read(8) == b'FLV\x01\x05\x00\x00\x00\x09'



# Generated at 2022-06-22 06:51:45.342177
# Unit test for function get_base_url
def test_get_base_url():
    assert get_base_url(
        compat_etree_fromstring(
            '<manifest><baseURL>foo</baseURL></manifest>')) == 'foo'
    assert get_base_url(
        compat_etree_fromstring(
            '<manifest><baseURL>foo</baseURL>'
            '<baseURL>bar</baseURL></manifest>')) == 'foo'
    assert not get_base_url(
        compat_etree_fromstring('<manifest></manifest>'))



# Generated at 2022-06-22 06:51:50.977439
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    write_unsigned_int(stream, 0x01020304)
    assert stream.getvalue() == b'\x01\x02\x03\x04'
    stream = io.BytesIO()
    write_unsigned_int(stream, 0xffffffff)
    assert stream.getvalue() == b'\xff\xff\xff\xff'



# Generated at 2022-06-22 06:52:00.168481
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    # 2-bytes integer
    assert write_unsigned_int_24(io.BytesIO(), 0x0102) == None
    assert write_unsigned_int_24(io.BytesIO(), 0xfeff) == None
    # 3-bytes integer
    assert write_unsigned_int_24(io.BytesIO(), 0x010203) == None
    assert write_unsigned_int_24(io.BytesIO(), 0xfeff00) == None
    # 4-bytes integer
    with pytest.raises(OverflowError):
        write_unsigned_int_24(io.BytesIO(), 0x01020304) == None
    with pytest.raises(OverflowError):
        write_unsigned_int_24(io.BytesIO(), 0xfeff0000) == None



# Generated at 2022-06-22 06:52:12.750358
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    metadata = b'\x02\x00\x0a\x6f\x6e\x4d\x65\x74\x61\x44\x61\x74\x61\x08'
    metadata += b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x03\x00\x04\x74'
    metadata += b'\x69\x74\x6c\x04\x00\x00\x00\x08\x74\x65\x73\x74\x00\x00\x08'

# Generated at 2022-06-22 06:52:15.576019
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    assert str(DataTruncatedError('some message')) == 'some message'



# Generated at 2022-06-22 06:52:21.331816
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    def _real_extract(self, url):
        # _real_extract is defined in YoutubeIE and YoutubePlaylistIE
        return 'foo', None

    test_extractor = YoutubeIE(None)
    test_extractor.suitable = lambda *args: True
    test_extractor._real_extract = _real_extract
    test_extractor.params = {}
    test_extractor.report_following_redirect = lambda x: None
    test_extractor.add_info_extractor = lambda x: None

    test_F4mFD = F4mFD(test_extractor.ydl, {})
    test_F4mFD.report_following_redirect = lambda x: None
    test_F4mFD.report_destination = lambda x: None
    test_F4mFD

# Generated at 2022-06-22 06:52:32.991761
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    from ..compat import compat_struct_pack
    flv_reader = FlvReader(b'\x00\x00\x03\xe8')
    assert flv_reader.read_unsigned_int() == 1000

    flv_reader = FlvReader(b'\x00\x00\x00\x00')
    assert flv_reader.read_unsigned_int() == 0

    flv_reader = FlvReader(b'\x00\x00\x00\x01')
    assert flv_reader.read_unsigned_int() == 1

    flv_reader = FlvReader(b'\xff\xff\xff\xff')
    assert flv_reader.read_unsigned_int() == 0xffffffff


# Generated at 2022-06-22 06:52:40.388459
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    read_string = FlvReader(b'12345\x006789\x00').read_string
    assert read_string() == b'12345'
    assert read_string() == b'6789'
    try:
        read_string()
    except:
        return
    raise AssertionError("FlvReader.read_string() should have raised exception")


# Basic types used in the manifest
Segment = collections.namedtuple('Segment', ['bitrate', 'first_segment', 'fragments_per_segment'])
Fragment = collections.namedtuple('Fragment', ['bitrate', 'fragment_number', 'discontinuity_indicator'])



# Generated at 2022-06-22 06:53:02.000562
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    assert FlvReader(b'\x0a\x0b').read_unsigned_char() == 0x0a


# Generated at 2022-06-22 06:53:13.362968
# Unit test for constructor of class F4mFD
def test_F4mFD():
    tpath = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tests', 'f4m')
    f4m_url = os.path.join(tpath, 'cnn.url.f4m')
    ydl = YoutubeDL({})
    f4m_fd = F4mFD(ydl, f4m_url, {})
    assert f4m_fd.manifest_url == 'http://cnn.vo.llnwd.net/o16/vod/e/intl/intl_hls_all_480p.f4m'

# Generated at 2022-06-22 06:53:24.715307
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    # data from a live stream
    asrt_data = (
        b'\x00\x00\x00\x8D'  # box size
        b'asrt'  # box type
        b'\x00'  # version, flags
        b'\x01'  # QualityEntryCount
        b'\x00'  # QualitySegmentUrlModifiers
        b'\x00\x00\x00\x01'  # SegmentRunEntryCount
        b'\x00\x00\x00\x00'  # FirstSegment
        b'\x00\x00\x00\x0A'  # FragmentsPerSegment
    )

# Generated at 2022-06-22 06:53:31.866357
# Unit test for method read_afrt of class FlvReader
def test_FlvReader_read_afrt():
    data = compat_b64decode(b'''
            AQAAAAIAAAABAAEAAAABAAEAAAABAAIAAAABAAQAAAABAAUAAAABAAAAAAAAAAAAAAAAAAAAAA==''')
    res = FlvReader(data).read_afrt()
    assert res['fragments'] == [{
        'ts': 0,
        'first': 0,
        'duration': 30000,
        'discontinuity_indicator': None
    }]



# Generated at 2022-06-22 06:53:40.916893
# Unit test for function build_fragments_list

# Generated at 2022-06-22 06:53:51.257670
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    class InfoDict:
        url = 'http://p.jwpcdn.com/player/v/7.3.5/jwplayer.flash.swf?pid=M2z4PFDa&file=http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8'
        tbr = None
    downloader = F4mFD('test_F4mFD_real_download', InfoDict())
    filename = 'test_F4mFD_real_download.flv'
    info_dict = InfoDict()
    assert downloader.real_download(filename, info_dict)


# Generated at 2022-06-22 06:53:53.812502
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    data = io.BytesIO()
    write_unsigned_int(data, 10)
    assert data.getvalue() == b'\x00\x00\x00\n'



# Generated at 2022-06-22 06:54:05.557594
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-22 06:54:07.351117
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    exception = DataTruncatedError('DataTruncatedError')
    assert exception is not None


# Generated at 2022-06-22 06:54:18.189091
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'segments': [{
            'segment_run': [(0, 1), (1, 2)],
        }],
        'fragments': [{
            'fragments': [{'first': 2, 'ts': 0}, {'first': 5, 'ts': 2}],
        }],
    }
    assert (
        build_fragments_list(boot_info)
        == [(0, 2), (1, 5), (1, 6)])

# Generated at 2022-06-22 06:54:44.794684
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    test_string = b'abcdabcd\x00\x00'
    reader = FlvReader(test_string)
    assert reader.read_string() == b'abcdabcd'



# Generated at 2022-06-22 06:54:46.516352
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    assert isinstance(DataTruncatedError(), Exception)



# Generated at 2022-06-22 06:54:49.996682
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    bytes = compat_struct_pack('!I', 42) + compat_struct_pack('!I', 16)
    r = FlvReader(bytes)
    assert r.read_unsigned_int() == 42
    assert r.read_unsigned_int() == 16


# Generated at 2022-06-22 06:54:57.481350
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    example_asrt = b'\x00\x00\x00\x1C\x61\x73\x72\x74\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x08\x00\x00\x00\x04'
    res = FlvReader(example_asrt).read_asrt()
    assert res == {
        'segment_run': [(8, 4)],
    }


# Generated at 2022-06-22 06:55:00.112380
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    write_unsigned_int(stream, 1)
    assert stream.getvalue() == b'\x00\x00\x00\x01'



# Generated at 2022-06-22 06:55:11.007584
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    import os
    from ..utils import encode_base_n

    bootstrap_file = os.path.join(
        os.path.dirname(__file__), 'bootstrap_info.raw')
    with open(bootstrap_file, 'rb') as f:
        bootstrap_bytes = f.read()
    info = read_bootstrap_info(bootstrap_bytes)

    assert info['live']
    assert len(info['segments']) == 10
    assert len(info['segments'][1]['segment_run']) == 6
    assert info['segments'][1]['segment_run'][5] == (5, 1)
    assert len(info['fragments']) == 10
    assert len(info['fragments'][1]['fragments']) == 7
    assert info

# Generated at 2022-06-22 06:55:22.816664
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-22 06:55:27.950861
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    import unittest
    import base64
    from .fragment import _parse_base64, _parse_flv

    class TestFlvReader(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            super(TestFlvReader, self).__init__(*args, **kwargs)

# Generated at 2022-06-22 06:55:34.960710
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    test_string = b"\x01\x02\x03"
    assert len(test_string) == 3
    reader = FlvReader(test_string)
    assert reader.read_bytes(1) == b"\x01"
    assert reader.read_bytes(2) == b"\x02\x03"

    try:
        reader.read_bytes(1)
    except DataTruncatedError:
        pass
    else:
        assert False



# Generated at 2022-06-22 06:55:45.545998
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    assert FlvReader(b'\x00\x00\x00\x0b\x66\x6f\x6f\x62\x61\x72\x2a').read_box_info() == (11, b'foobar', b'*')
    assert FlvReader(b'\x00\x00\x00\x00\x66\x6f\x6f\x62\x61\x72').read_box_info() == (8, b'foobar', b'')

# Generated at 2022-06-22 06:56:08.458827
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-22 06:56:16.285103
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    # test for normal case
    assert FlvReader(compat_struct_pack('!B', 0x12)).read_unsigned_char() == 0x12
    # test for failure case
    try:
        FlvReader(compat_struct_pack('!B', 0x12)).read_bytes(2)
    except DataTruncatedError:
        pass
    else:
        assert 0, 'failed test for method read_unsigned_char of class FlvReader'

# Generated at 2022-06-22 06:56:20.304412
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    write_unsigned_int(stream, 0x01020304)
    assert stream.getvalue() == b'\x01\x02\x03\x04'
test_write_unsigned_int()



# Generated at 2022-06-22 06:56:32.190880
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    with open(
            'test/test_data/test_video_bootstrap_info_KaKa_hds_3.data',
            'rb') as f:
        bitstream = io.BytesIO(f.read())
    bootstrap_info = FlvReader(bitstream).read_bootstrap_info()
    assert bootstrap_info['live'] is True

    # Test a live stream
    with open(
            'test/test_data/test_video_bootstrap_info_KaKa_hds_live_2.data',
            'rb') as f:
        bitstream = io.BytesIO(f.read())
    bootstrap_info = FlvReader(bitstream).read_bootstrap_info()
    assert bootstrap_info['live'] is True
    assert bootstrap_info['fragments'][0]

# Generated at 2022-06-22 06:56:44.025594
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    bytes_with_box_header = (
        b'\x00\x00\x00\x27'  # box size = 39 bytes
        b'box1'  # box type
        b'\x00\x00\x00\x01'  # version = 1
        b'\x00\x00\x00'      # flags
        b'\x00\x00\x00\x0c'  # box size = 12 bytes
        b'box2'  # box type
        b'\x00\x00\x00\x01'  # version = 1
        b'\x00\x00\x00'      # flags
        b'\x00\x00\x00\x0e'  # box size = 14
        b'box3'  # box type
    )
   

# Generated at 2022-06-22 06:56:55.821321
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-22 06:57:04.608991
# Unit test for function remove_encrypted_media

# Generated at 2022-06-22 06:57:10.662946
# Unit test for function get_base_url
def test_get_base_url():
    data = b'<?xml version="1.0" encoding="UTF-8"?>\n<manifest xmlns="http://ns.adobe.com/f4m/1.0">\n <baseURL>http://example.com/base/</baseURL>\n</manifest>'
    manifest = compat_etree_fromstring(data)
    assert get_base_url(manifest) == 'http://example.com/base/'


# Generated at 2022-06-22 06:57:17.246839
# Unit test for function get_base_url
def test_get_base_url():
    from .common import load_xml
    manifest = load_xml('test_get_base_url.f4m')
    assert get_base_url(manifest) == 'http://mediadl.microsoft.com/mediadl/iisnet/smoothmedia/Experience/BigBuckBunny_720p.ism/'
    manifest = load_xml('test_get_base_url2.f4m')
    assert get_base_url(manifest) is None
test_get_base_url()



# Generated at 2022-06-22 06:57:22.541827
# Unit test for function write_flv_header
def test_write_flv_header():
    import io
    test_stream = io.BytesIO()
    write_flv_header(test_stream)
    assert test_stream.getvalue() == (
        b'FLV\x01\x05\x00\x00\x00\t\x00\x00\x00\x00')



# Generated at 2022-06-22 06:58:09.311787
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    from .common import FakeDict
    desc = read_bootstrap_info(open(os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'PlayReadySample', 'PlayReady.bootstrap'), 'rb').read())
    assert desc['live'] is False
    assert len(desc['segments']) == 3
    assert len(desc['segments'][0]['segment_run']) == 2
    assert desc['segments'][0]['segment_run'][0] == (0, 9)
    assert desc['segments'][0]['segment_run'][1] == (2, 1)
    assert len(desc['fragments']) == 3
    assert len(desc['fragments'][0]['fragments']) == 9

# Generated at 2022-06-22 06:58:17.490600
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    xml = b'<media url="http://foo.com/1" drmAdditionalHeaderId="headerId" />'\
          b'<media url="http://foo.com/2" drmAdditionalHeaderSetId="headerId" />'\
          b'<media url="http://foo.com/3" />'
    expected = b'<media url="http://foo.com/3" />'
    removed = remove_encrypted_media(compat_etree_fromstring(xml))[0]
    assert compat_etree_fromstring(expected).attrib == removed.attrib



# Generated at 2022-06-22 06:58:28.185560
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    from ..utils import fix_xml_ampersands
    from xml.etree.ElementTree import fromstring, tostring
    xml_string = '<?xml version="1.0"?><test a="b">&amp;</test>';
    expected_result = b'\x12\x00\x00\x1a\x00\x00\x00\x00\x00\x00\x00<?xml version="1.0"?><test a="b">&amp;</test>\x00\x00\x00\x1e'
    metadata = fix_xml_ampersands(xml_string).encode('utf-8')
    stream = io.BytesIO()
    write_metadata_tag(stream, metadata)
    assert stream.getvalue() == expected_result



# Generated at 2022-06-22 06:58:30.266654
# Unit test for constructor of class DataTruncatedError
def test_DataTruncatedError():
    try:
        raise DataTruncatedError()
    except DataTruncatedError:
        pass



# Generated at 2022-06-22 06:58:41.513906
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    test_bytes = (
        b'\x00\x00\x00,asrt'
        b'\x01\x00\x00\x00'
        b'\x05\x00\x00\x00\x08\x00\x00\x00'
        b'\x00\x00\x00\x00\x00\x00\x00\x00'
        b'\x00\x00\x00\x01\x00\x00\x00\x01'
        b'\x00\x00\x00\x02\x00\x00\x00\x01')
    f = FlvReader(test_bytes)

# Generated at 2022-06-22 06:58:50.727866
# Unit test for method read_unsigned_long_long of class FlvReader
def test_FlvReader_read_unsigned_long_long():
    from codecs import encode
    from random import randint
    from .fragment import fmt_iso639_2
    for i in range(100):
        number = randint(0, 2**63)
        # Convert a number to binnary ascii string
        binstring = encode(compat_struct_pack(
            '!q', number), 'ascii')
        fr = FlvReader(binstring)
        assert fr.read_unsigned_long_long() == number
        # Test read_bytes method
        fr = FlvReader(binstring)
        # read one byte
        assert fr.read_bytes(1) == binstring[0]
        # read bytes until end
        assert fr.read_bytes(len(binstring) - 1) == binstring[1:]
        # Test

# Generated at 2022-06-22 06:58:54.805191
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    assert write_unsigned_int(io.BytesIO(), 3894) == io.BytesIO(b'\x00\x00\x0f\x16')



# Generated at 2022-06-22 06:59:02.658002
# Unit test for function get_base_url
def test_get_base_url():
    assert get_base_url(compat_etree_fromstring(
        '<manifest><baseURL>whatever</baseURL></manifest>')) == 'whatever'
    assert get_base_url(compat_etree_fromstring(
        '<manifest><baseURL>whatever</baseURL><foo>bar</foo></manifest>')) == 'whatever'
    assert not get_base_url(compat_etree_fromstring(
        '<manifest>whatever<foo>bar</foo></manifest>'))
    assert get_base_url(compat_etree_fromstring(
        '<manifest><foo>bar</foo></manifest>')) is None



# Generated at 2022-06-22 06:59:05.305852
# Unit test for method read_unsigned_int of class FlvReader
def test_FlvReader_read_unsigned_int():
    result = compat_struct_unpack('!I', compat_struct_pack('>I', 1))[0]
    assert result == 1

# Generated at 2022-06-22 06:59:12.473119
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    movie_test_file = io.open(
        'test/movie.bootstrap.test.data',
        'rb'
    )
    bootstrap_info = FlvReader(movie_test_file.read()).read_abst()
    assert len(bootstrap_info['segments']) == 1
    assert len(bootstrap_info['fragments']) == 1
    assert bootstrap_info['fragments'][0]['fragments'][0]['ts'] == 338530000000
