

# Generated at 2022-06-22 06:50:39.566354
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    def _gen_box_data():
        box_size = compat_struct_pack('!I', 10)
        box_type = b'moov'
        box_data = b'\x00\x00\x00\x00'
        return box_size + box_type + box_data
    reader = FlvReader(_gen_box_data())
    assert reader.read_box_info() == (10, b'moov', b'\x00\x00\x00\x00')

# Generated at 2022-06-22 06:50:45.451068
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    test_data = b'Test Data \x00 String.'
    data_reader = FlvReader(test_data)
    assert data_reader.read_bytes(12) == b'Test Data  '
    assert data_reader.read_bytes(10) == b'String.'

# Generated at 2022-06-22 06:50:50.608567
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    reader = FlvReader(b'abc')
    assert reader.read_bytes(2) == b'ab'

    try:
        reader.read_bytes(2)
        assert False
    except DataTruncatedError as e:
        assert str(e) == 'FlvReader error: need 2 bytes while only 1 bytes got'

# Generated at 2022-06-22 06:50:56.816885
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    f = FlvReader(b'123')
    assert f.read_bytes(1) == b'1'
    assert f.read_bytes(1) == b'2'
    assert f.read_bytes(1) == b'3'
    try:
        f.read_bytes(1)
        assert False
    except DataTruncatedError:
        pass


# Generated at 2022-06-22 06:51:00.580516
# Unit test for function write_flv_header
def test_write_flv_header():
    import base64
    myio = io.BytesIO()
    write_flv_header(myio)
    assert myio.getvalue() == base64.b64decode(b'AgAKAAAAAAAA7tI=')



# Generated at 2022-06-22 06:51:12.357037
# Unit test for function remove_encrypted_media

# Generated at 2022-06-22 06:51:15.419434
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    stream = io.BytesIO()
    write_unsigned_int(stream, 0x12345678)
    assert stream.getvalue() == b'\x12\x34\x56\x78'



# Generated at 2022-06-22 06:51:26.806102
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = [
        {'attrib': {'url': '1', 'drmAdditionalHeaderId': '2'}},
        {'attrib': {'url': '3', 'drmAdditionalHeaderSetId': '4'}},
        {'attrib': {'url': '5', 'bitrate': '6'}},
    ]

    expected = [
        {'attrib': {'url': '1', 'drmAdditionalHeaderId': '2'}},
        {'attrib': {'url': '3', 'drmAdditionalHeaderSetId': '4'}},
        {'attrib': {'url': '5', 'bitrate': '6'}},
    ]

    assert remove_encrypted_media(media) == expected



# Generated at 2022-06-22 06:51:35.097196
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    from . import FragmentFD
    x = FragmentFD()
    write_unsigned_int_24(x, 0)
    write_unsigned_int_24(x, 0x123456)
    write_unsigned_int_24(x, 0xffffff)
    write_unsigned_int_24(x, 0x100000)
    assert x.get_read_buffer() == b'\x00\x00\x00\x12\x34\x56\xff\xff\xff\x10\x00\x00'
test_write_unsigned_int_24()



# Generated at 2022-06-22 06:51:44.654995
# Unit test for constructor of class FlvReader
def test_FlvReader():
    flv_content = (
        b"\x00\x00\x00\x1d" b"\xaf\xbf" b"\x00\x00\x00\x01" b"\x00\x00\x00"
        b"\x04\x67\x65\x74\x00\x00\x00\x00"
    )
    a = FlvReader(flv_content)
    assert a.read_box_info() == (29, b'\xaf\xbf', b'\x00\x00\x00\x01\x00\x00\x00\x04get')



# Generated at 2022-06-22 06:52:13.854329
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    test_case_1 = "<media><mediaProperty/><mediaProperty drmAdditionalHeaderId=\"9\" drmAdditionalHeaderSetId=\"0\"/></media>"
    test_case_2 = "<media><mediaProperty/><mediaProperty drmAdditionalHeaderId=\"9\"/></media>"
    test_case_3 = "<media><mediaProperty/><mediaProperty drmAdditionalHeaderSetId=\"9\"/></media>"
    test_case_4 = "<media><mediaProperty/><mediaProperty drmAdditionalHeaderId=\"9\"/><mediaProperty drmAdditionalHeaderSetId=\"0\"/></media>"
    test_case_5 = "<media><mediaProperty/><mediaProperty drmAdditionalHeaderId=\"9\"/><mediaProperty drmAdditionalHeaderSetId=\"0\"/><mediaProperty/></media>"

# Generated at 2022-06-22 06:52:25.752102
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    import binascii

# Generated at 2022-06-22 06:52:37.056444
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-22 06:52:47.189495
# Unit test for function build_fragments_list
def test_build_fragments_list():
    from ..utils import encode_data_uri

    # Test for live stream, with `fragments_count` abnormal
    boot_info = {
        'segments': [
            {'segment_run': [
                (0, 1),
                (1, 4294967295),
            ]}
        ],
        'fragments': [
            {
                'fragments': [
                    {'first': 0},
                    {'first': 1},
                    {'first': 2},
                    {'first': 3},
                    {'first': 4},
                ],
            },
        ],
        'live': True,
    }
    assert build_fragments_list(boot_info) == [(1, 5), (1, 6)]

    # Test for live stream, with normal `fragments_count`
    boot

# Generated at 2022-06-22 06:52:53.751502
# Unit test for function write_flv_header
def test_write_flv_header():
    flv = io.BytesIO()
    write_flv_header(flv)
    assert flv.getvalue() == (
        b'FLV\x01'
        b'\x05'
        b'\x00\x00\x00\x09'
        b'\x00\x00\x00\x00')



# Generated at 2022-06-22 06:53:06.297930
# Unit test for method read_string of class FlvReader

# Generated at 2022-06-22 06:53:16.400040
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info1 = {
        'segments': [
            {
                'segment_run': [
                    (
                        0,      # segment
                        10      # fragments count
                    ),
                    (
                        1,
                        15
                    ),
                    (
                        2,
                        3
                    ),
                ]
            }
        ],
        'fragments': [
            {
                'fragments': [
                    {
                        'first': 0,             # first fragment number
                        'ts': 6000000,          # first fragment timestamp
                        'duration': 10000,      # duration
                        'discontinuity_indicator': None
                    },
                ],
            }
        ],
        'live': False
    }

# Generated at 2022-06-22 06:53:18.774086
# Unit test for function write_unsigned_int
def test_write_unsigned_int():
    file = io.BytesIO()
    write_unsigned_int(file, 10)
    file.seek(0, 0)
    assert read_unsigned_int(file) == 10


# Generated at 2022-06-22 06:53:23.377965
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    xml = '''<media url="enc.ts" qualityLevels="1"
            drmAdditionalHeaderId="1"
            drmAdditionalHeaderSetId="1" />
            <media url="b.ts" qualityLevels="1"></media>'''
    root = compat_etree_fromstring(xml)
    result = remove_encrypted_media(root)
    assert len(result) == 1



# Generated at 2022-06-22 06:53:34.621716
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    from ..downloadermock import DownloaderMock
    from ..downloader.rtmp import Downloader as RTMP