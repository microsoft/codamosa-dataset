

# Generated at 2022-06-22 06:51:15.013949
# Unit test for constructor of class F4mFD
def test_F4mFD():
    info = {
        'url': 'http://example.com',
        'player_url': 'https://example.com/player',
        'fragment_base_url': 'https://example.com/f4mTester/fragment.f4m',
        'bootstrap_base_url': 'https://example.com/f4mTester/bootstrap.abst',
        'fragments': [],
    }
    ydl = FakeYDL()
    f4mfd = F4mFD(ydl, info)
    assert f4mfd.params == {
        'player_url': 'https://example.com/player',
    }
    assert f4mfd.manifest_url == 'http://example.com'

# Generated at 2022-06-22 06:51:23.895344
# Unit test for function write_unsigned_int_24
def test_write_unsigned_int_24():
    import struct
    stream = io.BytesIO()
    write_unsigned_int_24(stream, 0x00FFFFFF)
    assert stream.getvalue() == b'\xFF\xFF\xFF'
    write_unsigned_int_24(stream, 0xFFFFFF00)
    assert stream.getvalue() == b'\xFF\xFF\xFF\x00\x00\x00'
    stream = io.BytesIO()
    write_unsigned_int_24(stream, 0x0000FFFF)
    assert stream.getvalue() == b'\xFF\xFF\x00'
    write_unsigned_int_24(stream, 0xFFFF0000)
    assert stream.getvalue() == b'\xFF\xFF\x00\xFF\xFF\x00'



# Generated at 2022-06-22 06:51:27.298517
# Unit test for function read_bootstrap_info
def test_read_bootstrap_info():
    from .test_fragments import _TEST_BOOTSTRAP_INFO
    read_bootstrap_info(_TEST_BOOTSTRAP_INFO)



# Generated at 2022-06-22 06:51:38.783202
# Unit test for constructor of class FlvReader
def test_FlvReader():
    data = (
        b'\x00\x00\x06\xEF'
        b'avcC'
        b'\x01'
        b'\x42\xE0\x0F\xA0'
        b'\x03\x01\x01\xE9'
        b'\x00\x10\x21\xA5'
        b'\xFD\x09\x5E\x80'
        b'\x00\x00\x00\x01'
        b'\x09\xEC'
    )
    reader = FlvReader(data)
    box_size, box_type, box_data = reader.read_box_info()
    assert box_size == len(data)
    assert box_type == b'avcC'


# Generated at 2022-06-22 06:51:47.844405
# Unit test for function build_fragments_list
def test_build_fragments_list():
    # Testing for case with one segment
    boot_info = {
        'live': False,
        'segments': [
            {
                'segment_run': [
                    (
                        1,
                        2
                    )
                ]
            }
        ],
        'fragments': [
            {
                'fragments': [
                    {
                        'first': 1,
                        'discontinuity_indicator': None,
                        'ts': 0,
                        'duration': 0
                    },
                    {
                        'first': 2,
                        'discontinuity_indicator': None,
                        'ts': 0,
                        'duration': 0
                    }
                ]
            }
        ]
    }
    assert build_fragments_list(boot_info) == [(1, 1), (1, 2)]



# Generated at 2022-06-22 06:51:58.449185
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-22 06:52:08.051850
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():

    flvReader = FlvReader(b'\x00\x00\x00\x00'+b'abcd'+b'\x00\x00\x00')
    size, box_type, box_data = flvReader.read_box_info()
    assert flvReader.read() == b''
    assert size == 0
    assert box_type == b'abcd'
    assert box_data == b''

    flvReader = FlvReader(b'\x00\x00\x00\x01'+b'abcd'+b'\x00\x00\x00')
    size, box_type, box_data = flvReader.read_box_info()
    assert flvReader.read() == b''
    assert size == 1

# Generated at 2022-06-22 06:52:17.658409
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    fd = io.BytesIO()
    write_flv_header(fd)

# Generated at 2022-06-22 06:52:28.907702
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    data = compat_struct_pack('!QQQQQQ', 1, 2, 3, 4, 5, 6)
    reader = FlvReader(data)
    assert reader.read_bytes(1) == compat_struct_pack('!B', 1)
    assert reader.read_bytes(4) == compat_struct_pack('!I', 2)
    assert reader.read_bytes(8) == compat_struct_pack('!Q', 3)
    # Test if it is able to handle end of data
    assert reader.read_bytes(8) == compat_struct_pack('!Q', 4)
    assert reader.read_bytes(8) == compat_struct_pack('!Q', 5)
    assert reader.read_bytes(8) == compat_struct_pack('!Q', 6)


# Generated at 2022-06-22 06:52:34.078446
# Unit test for function write_flv_header
def test_write_flv_header():
    """ Tests write_flv_header with an empty stream """
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\t\x00\x00\x00\x00'



# Generated at 2022-06-22 06:52:59.924560
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    import xml.etree.ElementTree as ET
    media1 = ET.fromstring(u"""
<media url="http://bob.com/segment1.ts" bitrate="2097255" duration="1397"
drmAdditionalHeaderId="1" drmAdditionalHeaderSetId="0">
<metadata></metadata></media>
""")

    media2 = ET.fromstring(u"""
<media url="http://bob.com/segment2.ts" bitrate="2097255" duration="1397"
drmAdditionalHeaderId="2" drmAdditionalHeaderSetId="0">
<metadata></metadata></media>
""")


# Generated at 2022-06-22 06:53:05.264428
# Unit test for function get_base_url
def test_get_base_url():
    manifest = '''
    <manifest xmlns="http://ns.adobe.com/f4m/2.0">
      <baseURL>http://example.com/</baseURL>
    </manifest>
    '''
    manifest_doc = compat_etree_fromstring(manifest)
    assert get_base_url(manifest_doc) == 'http://example.com/'

    manifest = '''
    <manifest xmlns="http://ns.adobe.com/f4m/2.0">
      <baseURL>
        http://example.com/
      </baseURL>
    </manifest>
    '''
    manifest_doc = compat_etree_fromstring(manifest)
    assert get_base_url(manifest_doc) == 'http://example.com/'



# Generated at 2022-06-22 06:53:15.573161
# Unit test for method read_bytes of class FlvReader
def test_FlvReader_read_bytes():
    flv_content = b'\x00\x00\x00\x01'
    flv_reader = FlvReader(flv_content)
    assert flv_reader.read_bytes(1) == b'\x00'
    flv_reader = FlvReader(flv_content)
    assert flv_reader.read_bytes(2) == b'\x00\x00'
    flv_reader = FlvReader(flv_content)
    assert flv_reader.read_bytes(3) == b'\x00\x00\x00'
    flv_reader = FlvReader(flv_content)
    assert flv_reader.read_bytes(4) == b'\x00\x00\x00\x01'


# Generated at 2022-06-22 06:53:21.799325
# Unit test for function build_fragments_list

# Generated at 2022-06-22 06:53:26.652032
# Unit test for method read_unsigned_char of class FlvReader
def test_FlvReader_read_unsigned_char():
    val = 0
    for i in range(8 * 4):
        val = (val << 1) + 1
    test_str = compat_struct_pack('>L', val) + b"\x00\x00\x00"
    FlvReader(test_str).read_unsigned_char()
    assert True



# Generated at 2022-06-22 06:53:37.650643
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-22 06:53:40.391876
# Unit test for constructor of class F4mFD
def test_F4mFD():
    fd = F4mFD(FakeYDL(), {'url': 'manifest.f4m'})
    fd.real_download('test.f4m', {'url': 'manifest.f4m'})

if __name__ == '__main__':
    test_F4mFD()

# Generated at 2022-06-22 06:53:52.119690
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-22 06:54:03.420738
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    stream = io.BytesIO()
    write_metadata_tag(stream, b'\x02\x00\x0a\x6f\x6e\x4d\x65\x74\x61\x44\x61\x74\x61\x08\x00\x00\x00\x00\x00\x00\x00\x02\x00\x11\x6f\x6e\x4f\x66\x66\x69\x63\x65\x4d\x65\x73\x73\x61\x67\x65\x00\x40\x09\x00\x00\x00\x00\x00\x00\x00\x00\x00\x09')


# Generated at 2022-06-22 06:54:08.347779
# Unit test for function write_flv_header
def test_write_flv_header():
    assert write_flv_header(io.BytesIO()).getvalue() == b'FLV\x01\x05\x00\x00\x00\t\x00\x00\x00\x00'

