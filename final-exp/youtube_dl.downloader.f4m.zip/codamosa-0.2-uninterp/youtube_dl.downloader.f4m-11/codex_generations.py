

# Generated at 2022-06-18 13:07:03.427713
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:07:14.067361
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    import io

# Generated at 2022-06-18 13:07:25.599174
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from ..utils import (
        encode_base_n,
    )
    from ..compat import (
        compat_struct_pack,
        compat_struct_unpack,
    )

# Generated at 2022-06-18 13:07:34.214089
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1c'  # box size
        b'asrt'  # box type
        b'\x00'  # version
        b'\x00\x00\x00'  # flags
        b'\x01'  # QualityEntryCount
        b'\x00\x00\x00\x00'  # SegmentRunEntryCount
    )
    assert FlvReader(data).read_asrt() == {
        'segment_run': [],
    }


# Generated at 2022-06-18 13:07:45.634595
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:07:54.380270
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:08:00.747349
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:08:13.177011
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import encode_data_uri
    from ..compat import compat_urlopen
    from io import BytesIO
    from ..extractor import gen_extractors
    from ..downloader.common import FileDownloader
    from ..downloader.f4m import F4mFD
    from ..downloader.http import HttpFD
    from ..downloader.rtmp import RtmpFD
    from ..downloader.external import ExternalFD
    from ..downloader.fragment import FragmentFD
    from ..downloader.ism import IsmFD
    from ..downloader.dash import DashSegmentsFD
    from ..downloader.hls import HlsFD
    from ..downloader.http import HttpRequest
    from ..downloader.http import HttpFD
    from ..downloader.http import HttpQuietDownloader

# Generated at 2022-06-18 13:08:20.391185
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = [
        {'url': 'http://example.com/1', 'drmAdditionalHeaderId': '1'},
        {'url': 'http://example.com/2', 'drmAdditionalHeaderSetId': '2'},
        {'url': 'http://example.com/3'},
    ]
    assert remove_encrypted_media(media) == [
        {'url': 'http://example.com/3'},
    ]



# Generated at 2022-06-18 13:08:32.165993
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:08:52.719588
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/2.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

# Generated at 2022-06-18 13:09:02.506529
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com/</baseURL>'
        '<media baseURL="http://example.com/media/"></media>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

    manifest = compat_etree_from

# Generated at 2022-06-18 13:09:14.123838
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1c'
        b'\x61\x73\x72\x74'
        b'\x00'
        b'\x00\x00\x00'
        b'\x00'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x00\x00\x00\x00\x01'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x00\x00\x00\x00\x01'
    )

# Generated at 2022-06-18 13:09:19.701271
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-18 13:09:30.808489
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-18 13:09:39.410061
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    data = b'\x00\x00\x00\x00'
    reader = FlvReader(data)
    assert reader.read_box_info() == (0, b'\x00\x00\x00\x00', b'')

    data = b'\x00\x00\x00\x01'
    reader = FlvReader(data)
    assert reader.read_box_info() == (1, b'\x00\x00\x00\x01', b'')

    data = b'\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00'
    reader = FlvReader(data)

# Generated at 2022-06-18 13:09:49.809001
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:09:58.829487
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/2.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'


# Generated at 2022-06-18 13:10:10.442207
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:10:18.345051
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:10:50.508390
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from .common import fake_httpd
    from ..utils import encode_data_uri

    # Test data generated by Adobe's flvtool2
    # http://osflash.org/flvtool2

# Generated at 2022-06-18 13:11:02.745175
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    xml = """
    <media url="http://example.com/encrypted.f4f"
           bootstrapInfoId="bootstrap1"
           bitrate="400"
           width="320"
           height="240"
           type="video/mp4"
           drmAdditionalHeaderId="drm1"
           drmAdditionalHeaderSetId="drmSet1"
           />
    <media url="http://example.com/unencrypted.f4f"
           bootstrapInfoId="bootstrap1"
           bitrate="400"
           width="320"
           height="240"
           type="video/mp4"
           />
    """
    media = remove_encrypted_media(compat_etree_fromstring(xml))
    assert len(media) == 1

# Generated at 2022-06-18 13:11:13.109774
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x3c'  # size
        b'asrt'  # type
        b'\x00'  # version
        b'\x00\x00\x00'  # flags
        b'\x01'  # QualityEntryCount
        b'\x00\x00\x00\x00'  # SegmentRunTableCount
        b'\x00\x00\x00\x00'  # QualityEntryCount
        b'\x00\x00\x00\x00'  # QualitySegmentUrlModifiers
    )
    res = FlvReader(data).read_asrt()
    assert res == {
        'segment_run': [],
    }



# Generated at 2022-06-18 13:11:22.987463
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-18 13:11:35.125258
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DownloadError
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_struct_pack
    from youtube_dl.compat import compat_b64decode
    from youtube_dl.compat import compat_etree_fromstring
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.utils import DataTruncatedError
    from youtube_dl.utils import fix_xml_ampersands
    from youtube_dl.utils import xpath_

# Generated at 2022-06-18 13:11:46.098514
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv_reader = FlvReader(open('tests/test.bootstrap', 'rb').read())

# Generated at 2022-06-18 13:11:57.271987
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:12:08.998541
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request
    from ..downloader.common import FileDownloader
    from ..downloader.http import HttpFD
    from ..downloader.f4m import F4mFD
    from ..downloader.fragment import FragmentFD
    from ..downloader.http import HttpRequest
    from ..downloader.http import HEADRequest
    from ..downloader.http import HEADRequest
    from ..downloader.http import HEADRequest
    from ..downloader.http import HEADRequest
    from ..downloader.http import HEADRequest
    from ..downloader.http import HEADRequest
    from ..downloader.http import HEADRequest
    from ..downloader.http import HEADRequest
    from ..downloader.http import HEADRequest
    from ..downloader.http import HEADRequest

# Generated at 2022-06-18 13:12:17.454020
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-18 13:12:21.906031
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class F4mFD
    # Called from __main__; tests download from a f4m manifest
    #
    # This test is not meant to be exhaustive, but rather to
    # catch regressions.

    # The test video is a short clip from Sintel, a CC-BY movie
    # by Blender Foundation
    url = 'http://mirrorblender.top-ix.org/movies/sintel-1024-surround.mp4.f4m'
    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    ydl.add_default_info_extractors()
    ydl.download([url])


if __name__ == '__main__':
    test_F4

# Generated at 2022-06-18 13:13:56.786163
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:14:05.727030
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:14:12.985829
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:14:19.075479
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-18 13:14:26.704078
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    xml = """
    <media url="http://example.com/encrypted.f4m" bootstrapInfoId="bootstrap1"
           bitrate="500" width="320" height="240"
           drmAdditionalHeaderId="drmHeader1"
           drmAdditionalHeaderSetId="drmHeaderSet1" />
    <media url="http://example.com/not-encrypted.f4m" bootstrapInfoId="bootstrap2"
           bitrate="500" width="320" height="240" />
    """
    root = compat_etree_fromstring(xml)
    media = root.findall('media')
    assert len(media) == 2
    media = remove_encrypted_media(media)
    assert len(media) == 1

# Generated at 2022-06-18 13:14:34.958223
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    data = b'\x00\x00\x00\x00'
    reader = FlvReader(data)
    assert reader.read_box_info() == (0, b'\x00\x00\x00\x00', b'')

    data = b'\x00\x00\x00\x01' + b'\x00\x00\x00\x00'
    reader = FlvReader(data)
    assert reader.read_box_info() == (1, b'\x00\x00\x00\x00', b'')

    data = b'\x00\x00\x00\x01' + b'\x00\x00\x00\x00' + b'\x00'
    reader = FlvReader(data)
    assert reader.read_box

# Generated at 2022-06-18 13:14:43.122532
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from ..utils import (
        encode_base_n,
        decode_base_n,
    )

# Generated at 2022-06-18 13:14:51.551698
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:15:00.232165
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:15:10.692582
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1c'  # size
        b'asrt'  # type
        b'\x00'  # version
        b'\x00\x00\x00'  # flags
        b'\x01'  # QualityEntryCount
        b'\x00\x00\x00\x00'  # SegmentRunEntryCount
    )
    assert FlvReader(data).read_asrt() == {
        'segment_run': [],
    }
