

# Generated at 2022-06-18 13:06:55.286229
# Unit test for method read_box_info of class FlvReader

# Generated at 2022-06-18 13:07:05.399002
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    flv_reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x00')
    assert flv_reader.read_string() == b''
    flv_reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x01\x01\x00\x00\x00\x00\x00\x00\x00')
    assert flv_reader.read_string() == b'\x01'
    flv_reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x02\x01\x02\x00\x00\x00\x00\x00\x00')
    assert fl

# Generated at 2022-06-18 13:07:15.216597
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv_reader = FlvReader(open('test.bootstrap', 'rb').read())
    bootstrap_info = flv_reader.read_bootstrap_info()
    assert bootstrap_info['segments'][0]['segment_run'][0] == (0, 1)
    assert bootstrap_info['fragments'][0]['fragments'][0]['first'] == 1
    assert bootstrap_info['fragments'][0]['fragments'][0]['ts'] == 0
    assert bootstrap_info['fragments'][0]['fragments'][0]['duration'] == 5
    assert bootstrap_info['fragments'][0]['fragments'][0]['discontinuity_indicator'] is None



# Generated at 2022-06-18 13:07:24.186582
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = [
        {'url': 'http://example.com/1'},
        {'url': 'http://example.com/2', 'drmAdditionalHeaderId': '1'},
        {'url': 'http://example.com/3', 'drmAdditionalHeaderSetId': '1'},
        {'url': 'http://example.com/4'},
    ]
    assert remove_encrypted_media(media) == [
        {'url': 'http://example.com/1'},
        {'url': 'http://example.com/4'},
    ]



# Generated at 2022-06-18 13:07:30.665173
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # Test for normal box
    data = compat_struct_pack('!I4s', 8, b'abcd')
    reader = FlvReader(data)
    assert reader.read_box_info() == (8, b'abcd', b'')
    # Test for large box
    data = compat_struct_pack('!I4sQ', 1, b'abcd', 16)
    reader = FlvReader(data)
    assert reader.read_box_info() == (16, b'abcd', b'')


# Generated at 2022-06-18 13:07:42.347476
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..compat import compat_urlopen
    from ..utils import (
        determine_ext,
        url_basename,
    )
    from ..extractor import (
        gen_extractors,
        YoutubeIE,
    )
    from ..downloader import (
        FileDownloader,
    )
    from ..postprocessor import (
        FFmpegPostProcessor,
    )

    # Test data

# Generated at 2022-06-18 13:07:51.344345
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..compat import compat_urlopen
    from ..utils import (
        determine_ext,
        HEADRequest,
    )
    from ..downloader.common import (
        DownloadError,
    )
    from ..downloader.http import (
        HttpFD,
    )
    from ..downloader.f4m import (
        F4mFD,
    )
    from ..downloader.fragment import (
        FragmentFD,
    )
    from ..downloader.hds import (
        HdsFD,
    )
    from ..downloader.hls import (
        HlsFD,
    )
    from ..downloader.ism import (
        IsmFD,
    )
    from ..downloader.rtmp import (
        RtmpFD,
    )

# Generated at 2022-06-18 13:07:58.814623
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    data = b'\x00\x00\x00\x00'
    reader = FlvReader(data)
    assert reader.read_box_info() == (0, b'\x00\x00\x00\x00', b'')

    data = b'\x00\x00\x00\x01'
    reader = FlvReader(data)
    assert reader.read_box_info() == (1, b'\x00\x00\x00\x01', b'')

    data = b'\x00\x00\x00\x01' + b'\x00' * 8
    reader = FlvReader(data)
    assert reader.read_box_info() == (1, b'\x00\x00\x00\x01', b'')

    data = b

# Generated at 2022-06-18 13:08:11.157218
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/2.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

# Generated at 2022-06-18 13:08:22.914535
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    from ..utils import encode_data_uri
    from ..compat import compat_chr

# Generated at 2022-06-18 13:09:03.728441
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:09:14.788317
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:09:22.202212
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = [
        {'url': 'http://example.com/1'},
        {'url': 'http://example.com/2', 'drmAdditionalHeaderId': '1'},
        {'url': 'http://example.com/3', 'drmAdditionalHeaderSetId': '2'},
        {'url': 'http://example.com/4'},
    ]
    assert remove_encrypted_media(media) == [
        {'url': 'http://example.com/1'},
        {'url': 'http://example.com/4'},
    ]



# Generated at 2022-06-18 13:09:33.414707
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:09:41.039470
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:09:51.086372
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:09:59.710242
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'segments': [{
            'segment_run': [
                (0, 2),
                (1, 3),
            ],
        }],
        'fragments': [{
            'fragments': [
                {'first': 0},
                {'first': 4},
            ],
        }],
        'live': False,
    }
    assert build_fragments_list(boot_info) == [
        (0, 0),
        (0, 1),
        (1, 2),
        (1, 3),
        (1, 4),
    ]


# Generated at 2022-06-18 13:10:11.357102
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1c'  # box size
        b'asrt'  # box type
        b'\x00'  # version
        b'\x00\x00\x00'  # flags
        b'\x01'  # QualityEntryCount
        b'\x00\x00\x00\x00'  # SegmentRunTableCount
    )
    assert FlvReader(data).read_asrt() == {
        'segment_run': [],
    }


# Generated at 2022-06-18 13:10:17.082666
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:10:28.443483
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import encode_data_uri
    from ..compat import compat_urlopen
    from io import BytesIO

    # Test data is generated by Adobe's tool flvtool2
    # https://github.com/unnu/flvtool2
    # The test data is generated by the following command
    # flvtool2 -U test.flv test.flv
    # The test data is the output of the command
    # flvtool2 -P test.flv

# Generated at 2022-06-18 13:10:56.859492
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:11:08.970364
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from ..utils import (
        encode_base_n,
    )

# Generated at 2022-06-18 13:11:18.765462
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:11:30.470175
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import encode_data_uri
    from ..compat import compat_urlopen
    from ..downloader.common import ContentTooShortError
    from ..downloader.http import HEADRequest

    # Download the bootstrap info

# Generated at 2022-06-18 13:11:39.642136
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1C'
        b'asrt'
        b'\x00'
        b'\x00\x00\x00'
        b'\x01'
        b'\x00\x00\x00\x00'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x01'
    )

# Generated at 2022-06-18 13:11:50.836794
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # Test case 1
    data = b'\x00\x00\x00\x0c' + b'abcd' + b'\x01\x02\x03\x04'
    reader = FlvReader(data)
    assert reader.read_box_info() == (12, b'abcd', b'\x01\x02\x03\x04')

    # Test case 2
    data = b'\x00\x00\x00\x01' + b'abcd' + b'\x00\x00\x00\x00\x00\x00\x00\x0c' + b'\x01\x02\x03\x04'
    reader = FlvReader(data)

# Generated at 2022-06-18 13:11:55.520224
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-18 13:12:07.747471
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:12:12.190477
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = compat_etree_fromstring(
        '<media url="http://example.com/encrypted.f4m" '
        'drmAdditionalHeaderId="1" drmAdditionalHeaderSetId="2"/>'
        '<media url="http://example.com/not_encrypted.f4m"/>')
    assert len(remove_encrypted_media(media)) == 1



# Generated at 2022-06-18 13:12:22.029935
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # Test case 1: normal case
    data = b'\x00\x00\x00\x0C\x61\x62\x73\x74\x00\x00\x00\x00'
    reader = FlvReader(data)
    assert reader.read_box_info() == (12, b'abst', b'\x00\x00\x00\x00')
    # Test case 2: size is 1
    data = b'\x00\x00\x00\x01\x61\x62\x73\x74\x00\x00\x00\x00\x00\x00\x00\x00\x0C\x00\x00\x00'
    reader = FlvReader(data)

# Generated at 2022-06-18 13:12:59.895234
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:13:10.318898
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from ..utils import (
        encode_base_n,
        decode_base_n,
    )

# Generated at 2022-06-18 13:13:21.429495
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:13:32.450145
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:13:42.900326
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:13:52.778623
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    xml_str = '''
    <media url="http://example.com/encrypted.f4v"
           bootstrapInfoId="bootstrap1"
           drmAdditionalHeaderId="header1"
           drmAdditionalHeaderSetId="headerSet1"
           bitrate="1"
           width="1"
           height="1"
           />
    <media url="http://example.com/not_encrypted.f4v"
           bootstrapInfoId="bootstrap1"
           bitrate="1"
           width="1"
           height="1"
           />
    '''
    xml_tree = compat_etree_fromstring(xml_str)
    media = xml_tree.findall('./media')
    assert len(media) == 2
    media = remove_encrypted_media(media)

# Generated at 2022-06-18 13:14:02.502812
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # Test case 1
    data = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    reader = FlvReader(data)
    assert reader.read_box_info() == (0, b'\x00\x00\x00\x00', b'')
    # Test case 2
    data = b'\x00\x00\x00\x01\x00\x00\x00\x00'
    reader = FlvReader(data)
    assert reader.read_box_info() == (1, b'\x00\x00\x00\x00', b'')
    # Test case 3
    data = b'\x00\x00\x00\x01\x00\x00\x00\x00\x00'

# Generated at 2022-06-18 13:14:10.413344
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from ..utils import encode_base_n
    from ..compat import compat_chr

    def _test_read_abst(data):
        abst = FlvReader(data).read_abst()
        assert abst['live'] == False

# Generated at 2022-06-18 13:14:16.757959
# Unit test for function write_metadata_tag

# Generated at 2022-06-18 13:14:19.427184
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = compat_etree_fromstring(
        '<media url="http://example.com/encrypted.f4m" '
        'drmAdditionalHeaderId="1" drmAdditionalHeaderSetId="1"/>'
        '<media url="http://example.com/not_encrypted.f4m"/>')
    assert len(remove_encrypted_media(media)) == 1



# Generated at 2022-06-18 13:15:40.846401
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:15:53.013875
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import unittest
    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.common
    import youtube_dl.utils
    import youtube_dl.downloader.f4m
    import youtube_dl.downloader.fragment
    import youtube_dl.downloader.http
    import youtube_dl.downloader.rtmp
    import youtube_dl.postprocessor.ffmpeg
    import youtube_dl.postprocessor.metadata
    import youtube_dl.postprocessor.common

    class MockYDL(youtube_dl.YoutubeDL):
        def __init__(self, params):
            youtube_dl.YoutubeDL.__init__(self, params)
            self.cache = {}


# Generated at 2022-06-18 13:16:02.046736
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:16:12.856375
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-18 13:16:17.417587
# Unit test for method read_string of class FlvReader

# Generated at 2022-06-18 13:16:24.971628
# Unit test for method read_asrt of class FlvReader