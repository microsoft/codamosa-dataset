

# Generated at 2022-06-18 13:08:28.737909
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'segments': [{
            'segment_run': [
                (0, 2),
                (1, 3),
            ],
        }],
        'fragments': [{
            'fragments': [
                {'first': 0},
                {'first': 2},
                {'first': 5},
                {'first': 9},
                {'first': 14},
                {'first': 20},
            ],
        }],
        'live': False,
    }
    assert build_fragments_list(boot_info) == [
        (0, 0), (0, 1),
        (1, 2), (1, 3), (1, 4),
    ]


# Generated at 2022-06-18 13:08:39.686502
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-18 13:08:49.494821
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import io
    import tempfile
    import unittest
    from youtube_dl.utils import *
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.f4m import F4mFD
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat_urllib_parse_urlencode
    from youtube_dl.compat import compat_urllib_request_urlopen
    from youtube_dl.compat import compat_struct_pack
    from youtube_dl.compat import compat_struct_unpack
    from youtube_dl.compat import compat_b64decode
    from youtube_dl.compat import compat_b64encode

# Generated at 2022-06-18 13:08:54.434489
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-18 13:09:01.737995
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1c'  # box size
        b'asrt'  # box type
        b'\x00'  # version
        b'\x00\x00\x00'  # flags
        b'\x01'  # QualityEntryCount
        b'\x00\x00\x00\x00'  # SegmentRunEntryCount
    )
    box_info = FlvReader(data).read_asrt()
    assert box_info['segment_run'] == []


# Generated at 2022-06-18 13:09:13.476111
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/2.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'


# Generated at 2022-06-18 13:09:23.984978
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-18 13:09:35.105069
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Test with a manifest that has a single media
    manifest = """
    <manifest xmlns="http://ns.adobe.com/f4m/1.0">
      <id>tag:example.com,2012:test</id>
      <mimeType>video/x-flv</mimeType>
      <streamType>recorded</streamType>
      <duration>0</duration>
      <bootstrapInfo profile="named" id="bootstrap1">
        <metadata>
          AAAA
        </metadata>
      </bootstrapInfo>
      <media url="http://example.com/media" bitrate="500" bootstrapInfoId="bootstrap1">
        <metadata>
          AAAA
        </metadata>
      </media>
    </manifest>
    """

# Generated at 2022-06-18 13:09:43.717994
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # Test for normal box
    data = b'\x00\x00\x00\x0c' + b'test' + b'\x00' * 4
    reader = FlvReader(data)
    assert reader.read_box_info() == (12, b'test', b'\x00' * 4)
    # Test for large box
    data = b'\x00\x00\x00\x01' + b'test' + b'\x00' * 8
    reader = FlvReader(data)
    assert reader.read_box_info() == (16, b'test', b'\x00' * 8)
test_FlvReader_read_box_info()



# Generated at 2022-06-18 13:09:48.171631
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DownloadError
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_parse_urlunparse
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat_urllib_parse_urlencode
    from youtube_dl.compat import compat_urllib_parse_unquote_plus