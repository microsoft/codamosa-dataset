

# Generated at 2022-06-18 13:08:08.216177
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-18 13:08:20.921315
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:08:32.606985
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DownloadError
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat_urllib_parse_unquote_plus
    from youtube_dl.compat import compat_urllib_parse_urlencode
    from youtube_dl.compat import compat_urllib_parse_urljoin

# Generated at 2022-06-18 13:08:37.194810
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Test case 1
    # Input:
    #   filename = 'test.flv'
    #   info_dict = {
    #       'url': 'http://test.com/test.f4m',
    #       'tbr': None,
    #   }
    # Expected output:
    #   True
    filename = 'test.flv'
    info_dict = {
        'url': 'http://test.com/test.f4m',
        'tbr': None,
    }
    assert F4mFD().real_download(filename, info_dict) == True

    # Test case 2
    # Input:
    #   filename = 'test.flv'
    #   info_dict = {
    #       'url': 'http://test.com/test.f4m',
    #

# Generated at 2022-06-18 13:08:47.841319
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL> http://example.com/ </baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

# Generated at 2022-06-18 13:08:52.575067
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com/</baseURL>'
        '<baseURL>http://example.com/2</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

    manifest = compat_etree_fromstring

# Generated at 2022-06-18 13:09:02.479241
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:09:14.127393
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:09:24.254447
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DownloadError
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat_urllib_parse_unquote_plus
    from youtube_dl.compat import compat_urllib_parse_urlencode
    from youtube_dl.compat import compat_urllib_parse_urljoin

# Generated at 2022-06-18 13:09:35.269828
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:10:06.019697
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:10:15.446683
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import encode_data_uri
    from ..compat import compat_urlopen
    from ..downloader.http import HEADRequest

    # Download the bootstrap info from a video

# Generated at 2022-06-18 13:10:25.604253
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    import os
    import sys
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    from ..utils import (
        read_bootstrap_info,
    )
    from ..compat import (
        compat_urllib_request,
    )
    url = 'http://vod.leasewebcdn.com/bbb.flv?ri=1024&rs=150&start=0'
    req = compat_urllib_request.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (X11; Linux x86_64; rv:10.0) Gecko/20100101 Firefox/10.0 (Chrome)')

# Generated at 2022-06-18 13:10:35.907785
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # Test case 1
    data = b'\x00\x00\x00\x00'
    flv_reader = FlvReader(data)
    assert flv_reader.read_box_info() == (0, b'\x00\x00\x00\x00', b'')
    # Test case 2
    data = b'\x00\x00\x00\x01'
    flv_reader = FlvReader(data)
    assert flv_reader.read_box_info() == (1, b'\x00\x00\x00\x01', b'')
    # Test case 3

# Generated at 2022-06-18 13:10:47.150517
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:10:59.235761
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    data = compat_struct_pack('!I4s', 12, b'abcd')
    assert FlvReader(data).read_box_info() == (12, b'abcd', b'')
    data = compat_struct_pack('!I4s', 1, b'abcd')
    data += compat_struct_pack('!Q', 12)
    assert FlvReader(data).read_box_info() == (12, b'abcd', b'')
    data = compat_struct_pack('!I4s', 1, b'abcd')
    data += compat_struct_pack('!Q', 12)
    data += b'1234567890'
    assert FlvReader(data).read_box_info() == (12, b'abcd', b'1234567890')



# Generated at 2022-06-18 13:11:06.986340
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'quiet': True})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(F4mFD())
    ydl.download(['http://www.dailymotion.com/cdn/manifest/video/x2a3x2b.f4m'])

if __name__ == '__main__':
    test_F4mFD_real_download()

# Generated at 2022-06-18 13:11:11.613322
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    stream = io.BytesIO()

# Generated at 2022-06-18 13:11:15.785444
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:11:25.841306
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:12:07.829194
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:12:16.453198
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:12:27.555957
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:12:37.865336
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:12:42.794375
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-18 13:12:55.013270
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:13:05.511145
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:13:14.257004
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'segments': [{
            'segment_run': [
                (0, 1),
                (1, 2),
                (2, 3),
            ],
        }],
        'fragments': [{
            'fragments': [
                {'first': 0},
                {'first': 1},
                {'first': 2},
                {'first': 3},
                {'first': 4},
                {'first': 5},
            ],
        }],
        'live': False,
    }
    assert build_fragments_list(boot_info) == [
        (0, 0),
        (1, 1),
        (1, 2),
        (2, 3),
        (2, 4),
        (2, 5),
    ]



# Generated at 2022-06-18 13:13:15.307369
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # TODO: write unit test
    pass



# Generated at 2022-06-18 13:13:26.823572
# Unit test for function build_fragments_list