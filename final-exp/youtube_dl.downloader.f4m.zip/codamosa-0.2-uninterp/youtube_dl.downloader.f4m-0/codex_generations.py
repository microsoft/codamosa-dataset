

# Generated at 2022-06-18 13:07:28.392076
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # Test for a box with size less than 2^32
    data = compat_struct_pack('!I4s', 12, b'abcd') + b'\x00' * 8
    reader = FlvReader(data)
    assert reader.read_box_info() == (12, b'abcd', b'\x00' * 8)
    # Test for a box with size greater than 2^32
    data = compat_struct_pack('!I4sQ', 1, b'abcd', 16) + b'\x00' * 12
    reader = FlvReader(data)
    assert reader.read_box_info() == (16, b'abcd', b'\x00' * 12)
test_FlvReader_read_box_info()



# Generated at 2022-06-18 13:07:35.877154
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-18 13:07:46.615391
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    # Test case 1
    data = (
        b'\x00\x00\x00\x1c'  # box size
        b'asrt'  # box type
        b'\x00'  # version
        b'\x00\x00\x00'  # flags
        b'\x01'  # QualityEntryCount
        b'\x00'  # QualitySegmentUrlModifiers
        b'\x00\x00\x00\x01'  # SegmentRunEntryCount
        b'\x00\x00\x00\x00'  # FirstSegment
        b'\x00\x00\x00\x01'  # FragmentsPerSegment
    )

# Generated at 2022-06-18 13:07:55.134295
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import random
    import string
    import re
    import json
    import time
    import datetime
    import urllib.request
    import urllib.parse
    import urllib.error
    import urllib.request
    import urllib.parse
    import urllib.error
    import http.cookiejar
    import ssl
    import socket
    import hashlib
    import random
    import string
    import re
    import json
    import time
    import datetime
    import urllib.request
    import urllib.parse
    import urllib.error
    import urllib.request
    import urllib.parse
    import urllib.error
    import http.cookiejar

# Generated at 2022-06-18 13:08:07.756941
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:08:20.306801
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import io
    import tempfile
    import unittest
    import youtube_dl.YoutubeDL
    import youtube_dl.downloader.f4m
    import youtube_dl.utils
    import youtube_dl.extractor.common
    import youtube_dl.extractor.rutube
    import youtube_dl.extractor.prosiebensat1
    import youtube_dl.extractor.akamaihd
    import youtube_dl.extractor.rtl2
    import youtube_dl.extractor.rtl
    import youtube_dl.extractor.orf
    import youtube_dl.extractor.mtv
    import youtube_dl.extractor.dreisat
    import youtube_dl.extractor.srgssr
    import youtube_dl.extractor.tvnow
    import youtube_dl.extractor.tvplay

# Generated at 2022-06-18 13:08:32.059279
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from ..utils import encode_data_uri
    from ..compat import compat_urlopen
    from io import BytesIO
    from ..downloader.common import DownloadError
    from ..downloader.http import HEADRequest

    # Test case 1:
    #   The bootstrap info of a live stream
    #   http://www.ustream.tv/channel/live-iss-stream
    #   The bootstrap info is located at
    #   http://c.ustream.tv/ustreamVideo/235/5/9/0/0/0/0/0/0/0/0/0/0/0/0/0/0/0/0/0/0/0/0/0/0/0/0/0/0/0/0/0/0/0/0/0/0/0/0/0/0

# Generated at 2022-06-18 13:08:43.162436
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:08:49.813699
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    assert FlvReader(b'\x00').read_string() == b''
    assert FlvReader(b'\x01\x00').read_string() == b'\x01'
    assert FlvReader(b'\x01\x02\x00').read_string() == b'\x01\x02'
    assert FlvReader(b'\x01\x02\x03\x00').read_string() == b'\x01\x02\x03'
    assert FlvReader(b'\x01\x02\x03\x04\x00').read_string() == b'\x01\x02\x03\x04'



# Generated at 2022-06-18 13:08:54.715388
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Test case 1
    # Input:
    #   filename = 'test.flv'
    #   info_dict = {'url': 'http://example.com/manifest.f4m'}
    # Expected output:
    #   True
    filename = 'test.flv'
    info_dict = {'url': 'http://example.com/manifest.f4m'}
    assert F4mFD().real_download(filename, info_dict) == True

    # Test case 2
    # Input:
    #   filename = 'test.flv'
    #   info_dict = {'url': 'http://example.com/manifest.f4m'}
    # Expected output:
    #   True
    filename = 'test.flv'

# Generated at 2022-06-18 13:09:17.660391
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-18 13:09:28.912061
# Unit test for function write_metadata_tag

# Generated at 2022-06-18 13:09:38.256963
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:09:48.694012
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    flv_reader = FlvReader(b'\x00\x00\x00\x00')
    assert flv_reader.read_box_info() == (0, b'\x00\x00\x00\x00', b'')
    flv_reader = FlvReader(b'\x00\x00\x00\x01\x00\x00\x00\x00')
    assert flv_reader.read_box_info() == (1, b'\x00\x00\x00\x00', b'')
    flv_reader = FlvReader(b'\x00\x00\x00\x01\x00\x00\x00\x01\x00')

# Generated at 2022-06-18 13:09:58.073424
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL> http://example.com/ </baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

# Generated at 2022-06-18 13:10:09.300458
# Unit test for function write_metadata_tag

# Generated at 2022-06-18 13:10:17.745027
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import encode_data_uri
    from ..compat import compat_urlopen
    from io import BytesIO
    from ..extractor import get_info_extractor
    from ..downloader.common import FileDownloader
    from ..downloader.http import HttpFD
    from ..downloader.http import HttpRequest
    from ..downloader.http import HEADRequest
    from ..downloader.http import HEADRequest
    from ..downloader.http import HEADRequest
    from ..downloader.http import HEADRequest
    from ..downloader.http import HEADRequest
    from ..downloader.http import HEADRequest
    from ..downloader.http import HEADRequest
    from ..downloader.http import HEADRequest
    from ..downloader.http import HEADRequest
    from ..downloader.http import HEADRequest
    from ..downloader.http import HEADRequest

# Generated at 2022-06-18 13:10:29.488881
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:10:38.171666
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/2.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'


# Generated at 2022-06-18 13:10:50.340069
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:11:27.011739
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Test case 1
    # Inputs
    filename = 'test.flv'
    info_dict = {
        'url': 'http://example.com/manifest.f4m',
        'tbr': None,
    }
    # Expected outputs
    expected_output = True
    # Instantiation of target class
    f4m_fd = F4mFD()
    # Call of the target function
    actual_output = f4m_fd.real_download(filename, info_dict)
    # Assertion verification
    assert actual_output == expected_output



# Generated at 2022-06-18 13:11:38.193871
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from .test_fragment import test_bootstrap_info
    flv_reader = FlvReader(test_bootstrap_info)

# Generated at 2022-06-18 13:11:49.471839
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    import io

# Generated at 2022-06-18 13:11:59.591689
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:12:11.095260
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-18 13:12:19.158216
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    flv_reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x00')
    assert flv_reader.read_string() == b''
    flv_reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x01\x01\x00\x00\x00\x00\x00\x00\x00')
    assert flv_reader.read_string() == b'\x01'
    flv_reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x02\x01\x02\x00\x00\x00\x00\x00\x00')
    assert fl

# Generated at 2022-06-18 13:12:29.100773
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    xml = '''
    <media url="http://example.com/encrypted.f4m"
           bootstrapInfoId="bootstrap1"
           bitrate="1000"
           width="1280"
           height="720"
           streamId="stream1"
           drmAdditionalHeaderId="drm1"
           drmAdditionalHeaderSetId="drm2"
           />
    <media url="http://example.com/unencrypted.f4m"
           bootstrapInfoId="bootstrap2"
           bitrate="1000"
           width="1280"
           height="720"
           streamId="stream2"
           />
    '''
    xml_doc = compat_etree_fromstring(xml)
    media = xml_doc.findall('./media')
    assert len(media) == 2
    media = remove_

# Generated at 2022-06-18 13:12:40.531701
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'segments': [
            {
                'segment_run': [
                    (0, 2),
                    (1, 3),
                ]
            }
        ],
        'fragments': [
            {
                'fragments': [
                    {'first': 0},
                    {'first': 2},
                    {'first': 5},
                    {'first': 9},
                ]
            }
        ],
        'live': False,
    }
    assert build_fragments_list(boot_info) == [
        (0, 0),
        (0, 1),
        (1, 2),
        (1, 3),
        (1, 4),
    ]


# Generated at 2022-06-18 13:12:47.303697
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:12:58.390887
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1c'  # size
        b'asrt'  # type
        b'\x00'  # version
        b'\x00\x00\x00'  # flags
        b'\x01'  # QualityEntryCount
        b'\x00'  # QualitySegmentUrlModifiers
        b'\x00\x00\x00\x01'  # SegmentRunEntryCount
        b'\x00\x00\x00\x00'  # FirstSegment
        b'\x00\x00\x00\x01'  # FragmentsPerSegment
    )
    assert FlvReader(data).read_asrt() == {
        'segment_run': [(0, 1)],
    }


# Generated at 2022-06-18 13:13:22.623451
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:13:33.764598
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:13:44.194940
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import re
    import random
    import time
    import hashlib
    import json
    import threading
    import socket
    import http.server
    import socketserver
    import urllib.parse
    import xml.etree.ElementTree as ET
    import base64
    import zlib
    from xml.sax.saxutils import escape as xml_escape
    from xml.sax.saxutils import unescape as xml_unescape
    from collections import namedtuple
    from io import BytesIO
    from io import StringIO
    from io import SEEK_SET
    from io import SEEK_CUR
    from io import SEEK_END
    from io import DEFAULT_BUFFER_SIZE
    from io import Buffered

# Generated at 2022-06-18 13:13:53.814308
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    from io import BytesIO
    stream = BytesIO()

# Generated at 2022-06-18 13:14:03.470459
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:14:09.586274
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = b'\x00\x00\x00\x1c\x61\x73\x72\x74\x01\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00'
    assert FlvReader(data).read_asrt() == {
        'segment_run': [(0, 1)],
    }


# Generated at 2022-06-18 13:14:16.133414
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:14:23.553023
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    bootstrap_info = FlvReader(open(
        'test/bootstrap_info.bin', 'rb').read()).read_bootstrap_info()

# Generated at 2022-06-18 13:14:30.705193
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    from ..utils import encode_data_uri
    from ..compat import compat_chr


# Generated at 2022-06-18 13:14:40.557678
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'segments': [
            {
                'segment_run': [
                    (0, 2),
                    (1, 3),
                ]
            }
        ],
        'fragments': [
            {
                'fragments': [
                    {'first': 0},
                    {'first': 2},
                    {'first': 5},
                    {'first': 9},
                ]
            }
        ],
        'live': False,
    }
    assert build_fragments_list(boot_info) == [
        (0, 0),
        (0, 1),
        (1, 2),
        (1, 3),
        (1, 4),
    ]


# Generated at 2022-06-18 13:15:22.204365
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import youtube_dl.YoutubeDL
    ydl = youtube_dl.YoutubeDL({})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(F4mFD())

# Generated at 2022-06-18 13:15:33.901367
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-18 13:15:44.896973
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-18 13:15:54.136570
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    data = compat_struct_pack('!I4s', 12, b'abcd') + b'1234'
    reader = FlvReader(data)
    assert reader.read_box_info() == (12, b'abcd', b'1234')

    data = compat_struct_pack('!Q4s', 12, b'abcd') + b'1234'
    reader = FlvReader(data)
    assert reader.read_box_info() == (12, b'abcd', b'1234')



# Generated at 2022-06-18 13:16:02.495218
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import encode_data_uri
    from ..compat import compat_urlopen
    from ..downloader.common import DownloadError
    from ..downloader.http import HEADRequest

    def _get_bootstrap_info(url):
        try:
            request = HEADRequest(url)
            data = compat_urlopen(request).read()
        except (compat_urllib_error.URLError, compat_http_client.HTTPException, socket.error) as err:
            raise DownloadError(u'ERROR: unable to download video data: %s' % error_to_compat_str(err))
        return FlvReader(data).read_bootstrap_info()

    # Test case 1

# Generated at 2022-06-18 13:16:07.552803
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = compat_etree_fromstring(
        '<media url="http://example.com/encrypted.f4m" '
        'drmAdditionalHeaderId="1" drmAdditionalHeaderSetId="2"/>'
        '<media url="http://example.com/unencrypted.f4m"/>')
    assert len(remove_encrypted_media(media)) == 1



# Generated at 2022-06-18 13:16:18.020539
# Unit test for method read_string of class FlvReader

# Generated at 2022-06-18 13:16:25.300243
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DownloadError
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat_urllib_parse_unquote_plus
    from youtube_dl.compat import compat_urllib_parse_urlencode
    from youtube_dl.compat import compat_urllib_parse_urljoin

# Generated at 2022-06-18 13:16:33.139411
# Unit test for method read_string of class FlvReader