

# Generated at 2022-06-18 13:07:17.453304
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:07:28.786744
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DownloadError
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.utils import encode_data_uri
    from youtube_dl.utils import sanitize_open
    from youtube_dl.utils import sanitized_Request
    from youtube_dl.utils import write_json_file
    from youtube_dl.utils import read_json_file
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import sanitize_open
    from youtube_dl.utils import encode_data_uri

# Generated at 2022-06-18 13:07:39.964763
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    assert FlvReader(b'\x00').read_string() == b''
    assert FlvReader(b'\x01\x00').read_string() == b'\x01'
    assert FlvReader(b'\x01\x02\x00').read_string() == b'\x01\x02'
    assert FlvReader(b'\x01\x02\x03\x00').read_string() == b'\x01\x02\x03'
    assert FlvReader(b'\x01\x02\x03\x04\x00').read_string() == b'\x01\x02\x03\x04'

# Generated at 2022-06-18 13:07:49.107971
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request

    # Test data is from http://www.bilibilijj.com/Files/DownLoad/10/10.flv
    # The file is downloaded from http://www.bilibilijj.com/video/av10/
    # The bootstrap info is extracted from the file by using
    # flvtool2 -U 10.flv
    # The bootstrap info is encoded as a data uri

# Generated at 2022-06-18 13:07:57.569600
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:08:10.266173
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/2.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

# Generated at 2022-06-18 13:08:22.139546
# Unit test for method read_string of class FlvReader

# Generated at 2022-06-18 13:08:26.522887
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-18 13:08:38.478436
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-18 13:08:48.435352
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:09:34.405998
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    flv_reader = FlvReader(b'\x00\x00\x00\x00' + b'abcd' + b'\x00\x00\x00\x00')
    assert flv_reader.read_box_info() == (0, b'abcd', b'')
    flv_reader = FlvReader(b'\x00\x00\x00\x01' + b'abcd' + b'\x00\x00\x00\x00')
    assert flv_reader.read_box_info() == (1, b'abcd', b'')
    flv_reader = FlvReader(b'\x00\x00\x00\x01' + b'abcd' + b'\x00\x00\x00\x01')
    assert fl

# Generated at 2022-06-18 13:09:43.627593
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:09:50.350227
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # Test for normal box
    data = compat_struct_pack('!I4s', 12, b'abcd')
    reader = FlvReader(data)
    assert reader.read_box_info() == (12, b'abcd', b'')

    # Test for large box
    data = compat_struct_pack('!I4sQ', 1, b'abcd', 12)
    reader = FlvReader(data)
    assert reader.read_box_info() == (12, b'abcd', b'')



# Generated at 2022-06-18 13:09:55.837045
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DownloadError
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.utils import encode_data_uri
    from youtube_dl.utils import sanitize_open
    from youtube_dl.utils import sanitized_Request
    from youtube_dl.utils import write_json_file
    from youtube_dl.utils import read_json_file
    from youtube_dl.utils import remove_start
    from youtube_dl.utils import remove_end
    from youtube_dl.utils import clean_html
    from youtube_dl.utils import unescapeHTML
    from youtube_dl.utils import un

# Generated at 2022-06-18 13:10:07.460852
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1c'
        b'asrt'
        b'\x00'
        b'\x00\x00\x00'
        b'\x01'
        b'\x00'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x01'
    )
    assert FlvReader(data).read_asrt() == {
        'segment_run': [(1, 1), (1, 1), (1, 1), (1, 1)],
    }



# Generated at 2022-06-18 13:10:16.488302
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:10:27.394973
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    import io
    import json

# Generated at 2022-06-18 13:10:36.196842
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = b'\x00\x00\x00\x1a\x61\x73\x72\x74\x01\x00\x00\x00\x6d\x61\x78\x2d\x76\x69\x64\x65\x6f\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'
    reader = FlvReader(data)
    assert reader.read_asrt() == {
        'segment_run': [(1, 1)],
    }



# Generated at 2022-06-18 13:10:47.488848
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:10:59.561216
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:11:47.420300
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:11:51.730730
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from .extractor.common import InfoExtractor
    from .utils import ExtractorError
    from .compat import compat_urllib_parse_urlparse

    class FakeYDL(object):
        def __init__(self):
            self.params = {
                'test': True,
            }

        def urlopen(self, url):
            if url == 'http://example.com/manifest.f4m':
                return compat_urllib_request.urlopen(
                    compat_urllib_request.Request(
                        'https://raw.githubusercontent.com/ytdl-org/youtube-dl/master/test/test_data/manifest.f4m'))

# Generated at 2022-06-18 13:12:00.344793
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'segments': [{
            'segment_run': [
                (0, 1),
                (1, 2),
                (2, 3),
            ]
        }],
        'fragments': [{
            'fragments': [
                {'first': 0},
                {'first': 1},
                {'first': 2},
                {'first': 3},
                {'first': 4},
                {'first': 5},
            ]
        }],
        'live': False,
    }
    assert build_fragments_list(boot_info) == [
        (0, 0),
        (1, 1),
        (1, 2),
        (2, 3),
        (2, 4),
        (2, 5),
    ]

    boot_

# Generated at 2022-06-18 13:12:11.177630
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-18 13:12:19.222608
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-18 13:12:29.101107
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:12:33.577375
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.utils import DownloadError
    from youtube_dl.utils import sanitize_open
    from youtube_dl.utils import encodeFilename
    from youtube_dl.utils import encodeArgument
    from youtube_dl.utils import prepend_extension
    from youtube_dl.utils import write_json_file
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DateRange

# Generated at 2022-06-18 13:12:44.204219
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:12:55.803540
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:13:02.339691
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.downloader.f4m import F4mFD
    from youtube_dl.utils import urlopen
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat_urllib_parse_urlencode
    from youtube_dl.compat import compat_urllib_parse_urljoin
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_struct_pack
    from youtube_dl.compat import compat_struct

# Generated at 2022-06-18 13:13:41.835621
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-18 13:13:52.092815
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..compat import compat_urllib_request
    with compat_urllib_request.urlopen(
            'https://github.com/ytdl-org/youtube-dl/raw/master/youtube_dl/extractor/test/bootstrap_info.abst') as f:
        bootstrap_info = FlvReader(f.read()).read_bootstrap_info()

# Generated at 2022-06-18 13:14:01.818436
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    import io

# Generated at 2022-06-18 13:14:09.769801
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:14:16.298287
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    import os
    from ..compat import compat_urlopen

# Generated at 2022-06-18 13:14:23.731495
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    data = b'\x00\x00\x00\x00'
    reader = FlvReader(data)
    assert reader.read_box_info() == (0, b'\x00\x00\x00\x00', b'')

    data = b'\x00\x00\x00\x01'
    reader = FlvReader(data)
    assert reader.read_box_info() == (1, b'\x00\x00\x00\x01', b'')

    data = b'\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x00'
    reader = FlvReader(data)

# Generated at 2022-06-18 13:14:30.854367
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:14:40.697724
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    import tempfile
    import os
    from .fragment import FragmentFD

# Generated at 2022-06-18 13:14:46.251716
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from ..utils import (
        encode_base_n,
    )
    from ..compat import (
        compat_struct_pack,
    )
    from ..downloader.common import (
        FileDownloader,
    )
    from ..extractor.common import (
        InfoExtractor,
    )
    from ..extractor.youtube import (
        YoutubeIE,
    )

    class TestInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return {
                'id': 'test',
                'url': url,
                'title': 'test',
                'ext': 'mp4',
                'http_headers': {
                    'Range': 'bytes=0-%d' % (
                        len(self._TEST_FILE_CONTENT) - 1),
                },
            }

# Generated at 2022-06-18 13:14:56.675509
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import encode_data_uri
    from ..compat import compat_urlopen
    from ..downloader.common import ContentTooShortError
    from ..downloader.http import HEADRequest
    from ..downloader.http.headers import HEADRequestHeaders
    from ..downloader.http.cookies import CookieJar
    from ..downloader.http.cookies import extract_cookies_to_jar
    from ..downloader.http.cookies import compat_cookiejar_from_dict
    from ..downloader.http.cookies import compat_cookiejar_from_list
    from ..downloader.http.cookies import compat_cookiejar_from_list
    from ..downloader.http.cookies import compat_cookiejar_from_list
    from ..downloader.http.cookies import compat_cookiejar_from_list

# Generated at 2022-06-18 13:15:50.183303
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1c'  # box size
        b'asrt'  # box type
        b'\x00'  # version
        b'\x00\x00\x00'  # flags
        b'\x01'  # QualityEntryCount
        b'\x00\x00\x00\x00'  # SegmentRunTableCount
    )
    assert FlvReader(data).read_asrt() == {
        'segment_run': [],
    }


# Generated at 2022-06-18 13:16:00.265154
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class F4mFD
    # Called from __main__; parameters set there
    # Tests download of a f4m manifest
    # set parameters for test
    filename = 'test.flv'
    info_dict = {
        'url': 'http://some.url/manifest.f4m',
        'tbr': None,
    }
    # call the code to be tested
    f4mfd = F4mFD()
    f4mfd.real_download(filename, info_dict)
    # check the results
    # TODO: implement test
    assert True # TODO: implement test



# Generated at 2022-06-18 13:16:10.690207
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:16:20.467145
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from ..utils import encode_data_uri
    from ..compat import compat_chr
    # Test data is generated by the following code:
    #
    # from pyamf.remoting.client import RemotingService
    # client = RemotingService('http://fpdownload.adobe.com/strobe/FlashMediaPlayback.swf',
    #                          amf_version=3)
    # result = client.call('getDataForResource', 'http://mediapm.edgesuite.net/strobe/content/test/AFaerysTale_sylviaApostol_640_500_short.flv')
    # print(result.bootstrapInfo.to_string())
    #
    # The output is then converted to a data URI by the following command:
    #
    # python -c "import base64; import

# Generated at 2022-06-18 13:16:30.147600
# Unit test for method read_afrt of class FlvReader