

# Generated at 2022-06-18 13:07:28.567553
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:07:35.977845
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-18 13:07:46.614161
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    test_data = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    reader = FlvReader(test_data)
    assert reader.read_box_info() == (0, b'\x00\x00\x00\x00', b'')
    test_data = b'\x00\x00\x00\x01\x00\x00\x00\x00'
    reader = FlvReader(test_data)
    assert reader.read_box_info() == (1, b'\x00\x00\x00\x00', b'')

# Generated at 2022-06-18 13:07:55.894277
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com/</baseURL></manifest>')
    assert get_base_url(manifest) == 'http://example.com/'
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/2.0">'
        '<baseURL>http://example.com/</baseURL></manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

# Generated at 2022-06-18 13:08:08.027440
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:08:20.557063
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1c'
        b'\x61\x73\x72\x74'
        b'\x00'
        b'\x00\x00\x00'
        b'\x01'
        b'\x00\x00\x00\x00'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x01'
    )

# Generated at 2022-06-18 13:08:32.217392
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com/</baseURL>'
        '<media baseURL="http://example.com/media/"></media>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'
    manifest = compat_etree_from

# Generated at 2022-06-18 13:08:43.335766
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:08:51.405493
# Unit test for method read_string of class FlvReader

# Generated at 2022-06-18 13:08:52.699554
# Unit test for constructor of class F4mFD
def test_F4mFD():
    fd = F4mFD({})
    assert fd.params is not None
    assert fd.ydl is not None


# Generated at 2022-06-18 13:09:35.990088
# Unit test for constructor of class F4mFD
def test_F4mFD():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'quiet': True})
    f4m_fd = F4mFD(ydl, {'url': 'http://example.com/manifest.f4m'})
    assert f4m_fd.name == 'f4m'
    assert f4m_fd.real_download('test.flv', {'url': 'http://example.com/manifest.f4m'}) is True

# Generated at 2022-06-18 13:09:39.567001
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-18 13:09:49.973950
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:09:58.951815
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:10:10.670865
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:10:18.488944
# Unit test for constructor of class F4mFD
def test_F4mFD():
    fd = F4mFD({'url': 'http://example.com/manifest.f4m'})
    assert fd.params['url'] == 'http://example.com/manifest.f4m'
    assert fd.params['fragment_index'] == 0
    assert fd.params['complete_frags_downloaded_bytes'] == 0
    assert fd.params['frag_download_timeout'] == 10
    assert fd.params['skip_unavailable_fragments'] == True
    assert fd.params['retries'] == 10
    assert fd.params['test'] == False
    assert fd.params['fragment_retries'] == 10
    assert fd.params['fragment_retry_sleep'] == 0

# Generated at 2022-06-18 13:10:30.226180
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:10:40.930179
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:10:47.104271
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = [
        {'url': 'http://example.com/1', 'drmAdditionalHeaderId': '1'},
        {'url': 'http://example.com/2', 'drmAdditionalHeaderSetId': '2'},
        {'url': 'http://example.com/3'},
    ]
    assert remove_encrypted_media(media) == [
        {'url': 'http://example.com/3'},
    ]



# Generated at 2022-06-18 13:10:59.173346
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:12:33.047099
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:12:43.735628
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:12:55.715321
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:13:02.294825
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-18 13:13:12.024553
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'quiet': True, 'skip_download': True})
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(F4mFD())

# Generated at 2022-06-18 13:13:22.757586
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    flv_reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x00')
    assert flv_reader.read_string() == b''
    flv_reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x01\x00')
    assert flv_reader.read_string() == b'\x00'
    flv_reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00')
    assert flv_reader.read_string() == b'\x00\x00'

# Generated at 2022-06-18 13:13:33.858421
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'segments': [{
            'segment_run': [
                (0, 2),
                (1, 3),
            ]
        }],
        'fragments': [{
            'fragments': [
                {'first': 0},
                {'first': 2},
                {'first': 5},
            ]
        }],
        'live': False,
    }
    assert build_fragments_list(boot_info) == [
        (0, 0),
        (0, 1),
        (1, 2),
        (1, 3),
        (1, 4),
    ]


# Generated at 2022-06-18 13:13:44.286092
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request

    # Download a sample flv file
    url = 'http://www.youtube.com/get_video_info?video_id=9bZkp7q19f0'
    req = compat_urllib_request.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (X11; Linux x86_64; rv:22.0) Gecko/20100101 Firefox/22.0')
    data = compat_urllib_request.urlopen(req).read()
    video_info = compat_urlparse.parse_qs(data.decode('utf-8'))

# Generated at 2022-06-18 13:13:53.888685
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1c'  # size
        b'asrt'  # type
        b'\x00'  # version
        b'\x00\x00\x00'  # flags
        b'\x01'  # QualityEntryCount
        b'\x00\x00\x00\x00'  # SegmentRunEntryCount
    )
    assert FlvReader(data).read_asrt() == {
        'segment_run': [],
    }


# Generated at 2022-06-18 13:14:03.584554
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-18 13:15:13.816141
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1c'
        b'asrt'
        b'\x00'
        b'\x00\x00\x00'
        b'\x01'
        b'\x00\x00\x00\x00'
        b'\x00\x00\x00\x02'
        b'\x00\x00\x00\x00\x00\x00\x00\x01'
        b'\x00\x00\x00\x00\x00\x00\x00\x01'
    )
    assert FlvReader(data).read_asrt() == {
        'segment_run': [
            (0, 1),
            (1, 1),
        ],
    }

# Generated at 2022-06-18 13:15:22.318243
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import sys
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.f4m import F4mFD
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import std_headers
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_request_build_opener
    from youtube_dl.compat import compat_urllib_request_install_opener
    from youtube_dl.compat import compat_urllib_request_urlopen
    from youtube_dl.compat import compat_urllib_error_URLError
    from youtube_dl.compat import compat_urllib_error_HTTPError
    from youtube_dl.compat import compat_

# Generated at 2022-06-18 13:15:34.042927
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:15:45.072080
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import os
    import tempfile
    import shutil
    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.common

    # Create a temporary directory
    tmp_dir = tempfile.mkdtemp()
    # Create a temporary file
    tmp_file = tempfile.NamedTemporaryFile(dir=tmp_dir, delete=False)
    # Create a YoutubeDL object
    ydl_obj = youtube_dl.YoutubeDL({})
    # Create an F4mFD object
    f4m_fd_obj = F4mFD(ydl_obj, {}, tmp_file.name)
    # Create a YoutubeDL object
    ydl_obj = youtube_dl.YoutubeDL({})
    # Create an YoutubeIE object

# Generated at 2022-06-18 13:15:57.884135
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:16:07.689000
# Unit test for method read_string of class FlvReader

# Generated at 2022-06-18 13:16:18.154047
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-18 13:16:25.351086
# Unit test for method read_afrt of class FlvReader