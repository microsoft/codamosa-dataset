

# Generated at 2022-06-18 13:07:34.338318
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/2.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

# Generated at 2022-06-18 13:07:45.761336
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import urlopen
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.downloader.f4m import F4mFD
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_parse_urlencode
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat_urllib_parse_unquote_plus
    from youtube_dl.compat import compat_urllib_parse_urljoin
    from youtube_dl.compat import compat_urllib_parse_urlsplit

# Generated at 2022-06-18 13:07:54.443753
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x2c'  # size
        b'asrt'  # type
        b'\x00'  # version
        b'\x00\x00\x00'  # flags
        b'\x01'  # QualityEntryCount
        b'\x00\x00\x00\x00'  # SegmentRunEntryCount
        b'\x00\x00\x00\x00'  # FirstSegment
        b'\x00\x00\x00\x00'  # FragmentsPerSegment
    )
    res = FlvReader(data).read_asrt()
    assert res == {
        'segment_run': [],
    }


# Generated at 2022-06-18 13:08:06.717111
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:08:19.293051
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from ..utils import encode_data_uri

# Generated at 2022-06-18 13:08:31.103684
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:08:41.658361
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request

    # Test data is from https://github.com/rg3/youtube-dl/issues/5409

# Generated at 2022-06-18 13:08:50.803061
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-18 13:09:01.433960
# Unit test for function remove_encrypted_media

# Generated at 2022-06-18 13:09:13.434101
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-18 13:09:53.646222
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..compat import compat_urlopen
    from ..utils import (
        determine_ext,
        float_or_none,
        int_or_none,
        parse_duration,
        parse_iso8601,
        strip_jsonp,
        unified_strdate,
        unified_timestamp,
        update_url_query,
    )
    from ..extractor import (
        YoutubeIE,
        YoutubePlaylistIE,
    )
    from ..downloader import (
        HttpFD,
    )
    from ..downloader.common import FileDownloader
    from ..downloader.http import HttpRequest
    from ..downloader.http.headers import HeadRequest
    from ..downloader.http.cookies import CookieJar

# Generated at 2022-06-18 13:09:55.955415
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Test for method real_download of class F4mFD
    # This test is not yet implemented
    assert False


# Generated at 2022-06-18 13:10:07.503367
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class F4mFD
    # Called from __main__; parameters set there
    # Tests download of a single fragment
    # Set up parameters
    ydl_opts = {
        'fragment_retries': 10,
        'skip_unavailable_fragments': False,
        'test': True,
    }
    params = {
        'test': True,
    }

# Generated at 2022-06-18 13:10:12.032372
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = compat_etree_fromstring(
        '<media url="http://example.com/1" '
        'drmAdditionalHeaderId="1" drmAdditionalHeaderSetId="2"/>'
        '<media url="http://example.com/2"/>')
    assert len(remove_encrypted_media(media)) == 1



# Generated at 2022-06-18 13:10:17.496757
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:10:28.937953
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-18 13:10:36.938300
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.f4m import F4mFD
    from youtube_dl.utils import DownloadError
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat_urllib_parse_urlencode
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_parse_urljoin
    from youtube_dl.compat import compat_urllib_parse_urlsplit

# Generated at 2022-06-18 13:10:49.107961
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:11:00.518159
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_parse

    def _test_FlvReader_read_bootstrap_info(url):
        data = compat_urllib_request.urlopen(url).read()
        data_uri = encode_data_uri(data, 'application/octet-stream')
        bootstrap_info = FlvReader(data).read_bootstrap_info()
        return bootstrap_info

    # Test case 1:
    # http://www.youtube.com/watch?v=JNwNXF9Y6kY

# Generated at 2022-06-18 13:11:12.166816
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:11:56.927822
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1c'
        b'asrt'
        b'\x00'
        b'\x00\x00\x00'
        b'\x00'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x00\x00\x00\x00\x01'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x00\x00\x00\x00\x01'
    )
    assert FlvReader(data).read_

# Generated at 2022-06-18 13:12:08.655834
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DownloadError
    from youtube_dl.utils import ExtractorError
    from youtube_dl.utils import format_bytes
    from youtube_dl.utils import format_seconds
    from youtube_dl.utils import sanitize_open
    from youtube_dl.utils import std_headers
    from youtube_dl.utils import urlopen
    from youtube_dl.utils import urlretrieve
    from youtube_dl.utils import USER_AGENT
    from youtube_dl.utils import version_tuple
    from youtube_dl.utils import write_string
    from youtube_dl.utils import write_json_file
    from youtube_dl.utils import write_string

# Generated at 2022-06-18 13:12:17.185196
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:12:28.033718
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-18 13:12:38.568630
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1c'  # size
        b'asrt'  # type
        b'\x00'  # version
        b'\x00\x00\x00'  # flags
        b'\x01'  # QualityEntryCount
        b'\x00\x00\x00\x00'  # SegmentRunEntryCount
    )
    assert FlvReader(data).read_asrt() == {
        'segment_run': [],
    }


# Generated at 2022-06-18 13:12:46.802268
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:12:57.951946
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from ..utils import encode_data_uri
    from .common import make_fake_bootstrap_info
    from .fragment import FragmentFD
    from .dash import DASHFragmentFD
    from .smoothstreams import SmoothStreamsFragmentFD
    from .hls import HLSFragmentFD
    from .ism import ISMFragmentFD

    def _test_read_abst(bootstrap_info):
        bootstrap_info_data = bootstrap_info.encode('utf-8')
        bootstrap_info_data_uri = encode_data_uri(
            bootstrap_info_data, 'text/plain')
        bootstrap_info_url = 'http://localhost/bootstrap_info'

# Generated at 2022-06-18 13:13:09.134529
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import re
    import time

    from .utils import (
        encodeFilename,
        prepend_extension,
        urlopen,
    )

    from .extractor import (
        gen_extractors,
        get_info_extractor,
    )

    from .compat import (
        compat_struct_pack,
        compat_urllib_parse_urlparse,
        compat_urllib_request,
    )

    from .downloader import (
        FileDownloader,
    )

    from .postprocessor import (
        FFmpegMergerPP,
    )

    from .common import (
        InfoExtractor,
        FileDownloader,
        PostProcessor,
        FileDownloader,
    )



# Generated at 2022-06-18 13:13:19.725539
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-18 13:13:30.966740
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:15:30.654526
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from ..utils import encode_data_uri
    from ..compat import compat_urlopen
    from ..downloader.common import ContentTooShortError

    def _test_FlvReader_read_abst(url, expected):
        try:
            data = compat_urlopen(url).read()
        except compat_urllib_error.URLError as err:
            raise ContentTooShortError(err.reason)
        abst = FlvReader(data).read_bootstrap_info()
        assert abst == expected


# Generated at 2022-06-18 13:15:41.917960
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:15:45.516212
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:15:58.208779
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from ..utils import encode_data_uri
    from .fragment import (
        _parse_fragment_base_url,
        _parse_fragment_list,
        _parse_fragment_metadata,
    )

# Generated at 2022-06-18 13:16:08.005201
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:16:18.479314
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class F4mFD
    # Called from __main__; tests F4mFD.real_download()
    #
    # Typical input:
    # filename = 'test.flv'
    # info_dict = {'url': 'http://example.com/manifest.f4m',
    #              'tbr': None,
    #              'extra_param_to_segment_url': None}
    #
    # Typical output:
    # True

    # Create a dummy F4mFD object
    f4mfd = F4mFD()

    # Create a dummy filename
    filename = 'test.flv'

    # Create a dummy info_dict

# Generated at 2022-06-18 13:16:26.449323
# Unit test for method read_asrt of class FlvReader