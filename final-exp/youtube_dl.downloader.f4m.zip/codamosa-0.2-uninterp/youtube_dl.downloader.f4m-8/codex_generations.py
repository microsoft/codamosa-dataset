

# Generated at 2022-06-18 13:07:04.216241
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:07:14.543714
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    import unittest
    import os
    import sys
    from ..utils import (
        encode_base_n,
        decode_base_n,
    )


# Generated at 2022-06-18 13:07:26.164513
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x00')
    assert reader.read_string() == b''
    reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x01a')
    assert reader.read_string() == b'a'
    reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x02ab')
    assert reader.read_string() == b'ab'
    reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x03abc')
    assert reader.read_string() == b'abc'
    reader

# Generated at 2022-06-18 13:07:34.207518
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    import io

# Generated at 2022-06-18 13:07:45.651992
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:07:54.380444
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.downloader.f4m import F4mFD
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DownloadError
    from youtube_dl.utils import sanitize_open
    from youtube_dl.utils import encodeFilename
    from youtube_dl.utils import write_json_file
    from youtube_dl.utils import read_json_file
    from youtube_dl.utils import remove_start
    from youtube_dl.utils import unescapeHTML
    from youtube_dl.utils import url_basename
    from youtube_dl.utils import urljoin
    from youtube_dl.utils import urlencode_postdata
    from youtube_dl.utils import USER_AGENT
    from youtube_dl.utils import compat_urll

# Generated at 2022-06-18 13:08:06.636350
# Unit test for method read_string of class FlvReader

# Generated at 2022-06-18 13:08:19.192881
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:08:30.948952
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:08:41.528263
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DownloadError
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_parse_urlencode
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat_urllib_parse_unquote_plus
    from youtube_dl.compat import compat_urllib_parse_urljoin

# Generated at 2022-06-18 13:09:10.784640
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-18 13:09:21.917061
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:09:28.457519
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = [
        {'url': 'http://example.com/1', 'drmAdditionalHeaderId': '1'},
        {'url': 'http://example.com/2', 'drmAdditionalHeaderSetId': '2'},
        {'url': 'http://example.com/3'},
    ]
    assert remove_encrypted_media(media) == [{'url': 'http://example.com/3'}]



# Generated at 2022-06-18 13:09:37.963171
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import os
    import sys
    import unittest
    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.common
    import youtube_dl.utils
    import youtube_dl.downloader.f4m
    import youtube_dl.downloader.fragment
    import youtube_dl.downloader.common
    import youtube_dl.postprocessor.ffmpeg
    import youtube_dl.postprocessor.metadata
    import youtube_dl.postprocessor.common
    import youtube_dl.postprocessor.execafterdownload
    import youtube_dl.postprocessor.xattr
    import youtube_dl.postprocessor.embedthumbnail
    import youtube_dl.postprocessor.ffmpegmetadata
    import youtube_dl.postprocessor.xattrtomp4
    import youtube_dl.postprocessor.execafterdownload

# Generated at 2022-06-18 13:09:48.652382
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..compat import compat_urllib_request

# Generated at 2022-06-18 13:09:58.038992
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:10:09.304783
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:10:13.076971
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:10:19.388375
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1c'
        b'asrt'
        b'\x00'
        b'\x00\x00\x00'
        b'\x01'
        b'\x00\x00\x00\x00'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x00'
    )
    assert FlvReader(data).read_asrt() == {
        'segment_run': [
            (0, 1),
        ],
    }

# Generated at 2022-06-18 13:10:30.384533
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-18 13:11:17.711190
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import encode_data_uri
    from ..compat import compat_urlopen

    # Download a sample bootstrap info file
    bootstrap_info_url = 'http://devimages.apple.com/iphone/samples/bipbop/bipbopall.bootstrap.bin'
    bootstrap_info_data = compat_urlopen(bootstrap_info_url).read()
    bootstrap_info = FlvReader(bootstrap_info_data).read_bootstrap_info()

    # Check the result
    assert bootstrap_info['live'] == False
    assert len(bootstrap_info['segments']) == 1
    assert len(bootstrap_info['fragments']) == 1
    assert len(bootstrap_info['segments'][0]['segment_run']) == 1

# Generated at 2022-06-18 13:11:28.383788
# Unit test for method read_string of class FlvReader

# Generated at 2022-06-18 13:11:38.946482
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:11:50.010903
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:11:59.790656
# Unit test for method read_string of class FlvReader

# Generated at 2022-06-18 13:12:11.098674
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-18 13:12:19.548479
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:12:29.689989
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    data = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    reader = FlvReader(data)
    assert reader.read_box_info() == (0, b'\x00\x00\x00\x00', b'')
    data = b'\x00\x00\x00\x01\x00\x00\x00\x00'
    reader = FlvReader(data)
    assert reader.read_box_info() == (1, b'\x00\x00\x00\x00', b'')
    data = b'\x00\x00\x00\x01\x00\x00\x00\x01'
    reader = FlvReader(data)
    assert reader.read_box_info()

# Generated at 2022-06-18 13:12:40.705562
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:12:51.171679
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        b'<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        b'<baseURL>http://example.com/</baseURL>'
        b'</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

    manifest = compat_etree_fromstring(
        b'<manifest xmlns="http://ns.adobe.com/f4m/2.0">'
        b'<baseURL>http://example.com/</baseURL>'
        b'</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'


# Generated at 2022-06-18 13:15:08.590502
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import unittest
    import youtube_dl.extractor.common as common
    import youtube_dl.utils as utils
    import youtube_dl.downloader.f4m as f4m

    class TestF4mFD(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.outfile = os.path.join(self.tmpdir, 'out.flv')

# Generated at 2022-06-18 13:15:18.321264
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:15:29.863017
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-18 13:15:36.476943
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:15:48.472354
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:15:55.635004
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = [
        {'url': 'http://example.com/1', 'drmAdditionalHeaderId': '1'},
        {'url': 'http://example.com/2', 'drmAdditionalHeaderSetId': '2'},
        {'url': 'http://example.com/3'},
    ]
    assert remove_encrypted_media(media) == [
        {'url': 'http://example.com/3'},
    ]



# Generated at 2022-06-18 13:16:03.196751
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1c'  # box size
        b'asrt'  # box type
        b'\x00'  # version
        b'\x00\x00\x00'  # flags
        b'\x01'  # QualityEntryCount
        b'\x00\x00\x00\x00'  # SegmentRunEntryCount
    )
    assert FlvReader(data).read_asrt() == {
        'segment_run': [],
    }


# Generated at 2022-06-18 13:16:13.920782
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    xml = '''
    <media url="http://example.com/encrypted.f4m"
           bootstrapInfoId="bootstrap1"
           bitrate="500"
           width="1280"
           height="720"
           streamId="stream1"
           drmAdditionalHeaderId="drmHeader1"
           drmAdditionalHeaderSetId="drmHeaderSet1">
    </media>
    <media url="http://example.com/unencrypted.f4m"
           bootstrapInfoId="bootstrap1"
           bitrate="500"
           width="1280"
           height="720"
           streamId="stream1">
    </media>
    '''
    xml_doc = compat_etree_fromstring(xml)
    media = xml_doc.findall('./media')

# Generated at 2022-06-18 13:16:22.547713
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:16:31.452492
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'segments': [{
            'segment_run': [
                (0, 1),
                (1, 2),
                (2, 3),
            ],
        }],
        'fragments': [{
            'fragments': [
                {'first': 0},
                {'first': 1},
                {'first': 2},
                {'first': 3},
                {'first': 4},
                {'first': 5},
            ],
        }],
        'live': False,
    }
    assert build_fragments_list(boot_info) == [
        (0, 0),
        (1, 1),
        (1, 2),
        (2, 3),
        (2, 4),
        (2, 5),
    ]

