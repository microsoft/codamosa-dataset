

# Generated at 2022-06-18 13:07:09.929301
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # Test case 1: box size is less than 0xFFFFFFFF
    data = compat_struct_pack('!I4s3s', 12, b'abcd', b'efg')
    reader = FlvReader(data)
    assert reader.read_box_info() == (12, b'abcd', b'efg')

    # Test case 2: box size is greater than 0xFFFFFFFF
    data = compat_struct_pack('!I4sQ3s', 1, b'abcd', 12, b'efg')
    reader = FlvReader(data)
    assert reader.read_box_info() == (12, b'abcd', b'efg')


# Generated at 2022-06-18 13:07:18.823958
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:07:29.159668
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import encode_data_uri
    from ..compat import compat_urlopen


# Generated at 2022-06-18 13:07:40.627171
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:07:49.589468
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        b'<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        b'<baseURL>http://example.com/</baseURL>'
        b'</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

    manifest = compat_etree_fromstring(
        b'<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        b'<baseURL>http://example.com/</baseURL>'
        b'<media baseURL="http://example.com/media/"></media>'
        b'</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

    manifest

# Generated at 2022-06-18 13:07:57.929315
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    data = b'\x00\x00\x00\x00'
    reader = FlvReader(data)
    assert reader.read_box_info() == (0, b'\x00\x00\x00\x00', b'')

    data = b'\x00\x00\x00\x01'
    reader = FlvReader(data)
    assert reader.read_box_info() == (1, b'\x00\x00\x00\x01', b'')

    data = b'\x00\x00\x00\x01' + b'\x00\x00\x00\x00'
    reader = FlvReader(data)

# Generated at 2022-06-18 13:08:10.537799
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:08:22.356796
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    test_data = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    reader = FlvReader(test_data)
    assert reader.read_box_info() == (0, b'\x00\x00\x00\x00', b'')

    test_data = b'\x00\x00\x00\x01\x00\x00\x00\x00'
    reader = FlvReader(test_data)
    assert reader.read_box_info() == (1, b'\x00\x00\x00\x00', b'')


# Generated at 2022-06-18 13:08:30.704215
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Test case 1
    # Inputs
    filename = 'test_filename'
    info_dict = {'url': 'test_url'}
    # Expected outputs
    expected_output = True
    # Instantiate the class
    f4m_fd = F4mFD()
    # Call the method
    actual_output = f4m_fd.real_download(filename, info_dict)
    # Compare actual and expected outputs
    assert actual_output == expected_output


# Generated at 2022-06-18 13:08:41.247057
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:09:04.572368
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-18 13:09:15.600469
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    import io

# Generated at 2022-06-18 13:09:21.392779
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    data = b'\x00\x00\x00\x00'
    reader = FlvReader(data)
    assert reader.read_box_info() == (0, b'\x00\x00\x00\x00', b'')
    data = b'\x00\x00\x00\x01\x00\x00\x00\x00'
    reader = FlvReader(data)
    assert reader.read_box_info() == (1, b'\x00\x00\x00\x00', b'')
    data = b'\x00\x00\x00\x01\x00\x00\x00\x00\x00'
    reader = FlvReader(data)

# Generated at 2022-06-18 13:09:32.632950
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    import os
    import tempfile
    import shutil
    import subprocess
    from ..utils import (
        encode_data_uri,
    )


# Generated at 2022-06-18 13:09:36.687154
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'segments': [{
            'segment_run': [
                (0, 2),
                (1, 1),
            ],
        }],
        'fragments': [{
            'fragments': [
                {'first': 0, 'ts': 0, 'duration': 0, 'discontinuity_indicator': None},
                {'first': 1, 'ts': 0, 'duration': 0, 'discontinuity_indicator': None},
                {'first': 2, 'ts': 0, 'duration': 0, 'discontinuity_indicator': None},
            ],
        }],
        'live': False,
    }
    assert build_fragments_list(boot_info) == [(0, 0), (0, 1), (1, 2)]



# Generated at 2022-06-18 13:09:46.829907
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x2d'  # size
        b'\x61\x73\x72\x74'  # type
        b'\x00'  # version
        b'\x00\x00\x00'  # flags
        b'\x01'  # QualityEntryCount
        b'\x6d\x65\x64\x69\x61\x00'  # QualitySegmentUrlModifiers
        b'\x00\x00\x00\x01'  # SegmentRunEntryCount
        b'\x00\x00\x00\x00'  # FirstSegment
        b'\x00\x00\x00\x01'  # FragmentsPerSegment
    )

# Generated at 2022-06-18 13:09:57.056643
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:10:08.356079
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:10:17.108419
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:10:28.442869
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:10:51.180288
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:11:02.288807
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = b'\x00\x00\x00\x1c\x61\x73\x72\x74\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'
    assert FlvReader(data).read_asrt() == {
        'segment_run': [(1, 1), (1, 1), (1, 1), (1, 1)],
    }


# Generated at 2022-06-18 13:11:13.257417
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:11:23.104861
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import encode_data_uri
    from ..compat import compat_chr

    # Generate a bootstrap box
    # The bootstrap box is generated by the following code:
    #   from pyamf.remoting.client import RemotingService
    #   client = RemotingService('http://fpdownload.adobe.com/strobe/services/amfgateway')
    #   result = client.getBootstrapInfo(streamName='ondemand/mp4:mediapm/ovp/content/test/video/spacealonehd_sounas_640_300.mp4')
    #   print(result.bootstrapInfo)
    # The bootstrap box is then base64 encoded and put in the following variable

# Generated at 2022-06-18 13:11:35.212911
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    from io import BytesIO

# Generated at 2022-06-18 13:11:46.196083
# Unit test for function remove_encrypted_media

# Generated at 2022-06-18 13:11:54.195224
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    xml = """
    <media>
        <metadata>
            <someTag>someValue</someTag>
        </metadata>
        <drmAdditionalHeaderId>someId</drmAdditionalHeaderId>
        <drmAdditionalHeaderSetId>someSetId</drmAdditionalHeaderSetId>
        <otherTag>otherValue</otherTag>
    </media>
    """
    media = compat_etree_fromstring(xml)
    assert len(remove_encrypted_media(media)) == 1
    assert remove_encrypted_media(media)[0].tag == 'metadata'



# Generated at 2022-06-18 13:12:01.297468
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:12:11.687610
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    data = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    reader = FlvReader(data)
    assert reader.read_box_info() == (0, b'\x00\x00\x00\x00', b'')
    data = b'\x00\x00\x00\x01\x00\x00\x00\x00'
    reader = FlvReader(data)
    assert reader.read_box_info() == (1, b'\x00\x00\x00\x00', b'')
    data = b'\x00\x00\x00\x01\x00\x00\x00\x01'
    reader = FlvReader(data)
    assert reader.read_box_info()

# Generated at 2022-06-18 13:12:19.583358
# Unit test for function write_metadata_tag

# Generated at 2022-06-18 13:12:35.684103
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Test for method real_download of class F4mFD
    # Create a F4mFD object
    f4mFD = F4mFD()
    # Create a info_dict object
    info_dict = {'url': 'http://example.com/manifest.f4m'}
    # Call the real_download method of F4mFD object
    f4mFD.real_download('filename', info_dict)


# Generated at 2022-06-18 13:12:43.102761
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # Test with a box of size 1
    data = compat_struct_pack('!I4sQ', 1, b'abcd', 123456789)
    assert FlvReader(data).read_box_info() == (123456789, b'abcd', b'')
    # Test with a box of size 4
    data = compat_struct_pack('!I4sI', 4, b'abcd', 123456789)
    assert FlvReader(data).read_box_info() == (4, b'abcd', b'')



# Generated at 2022-06-18 13:12:55.233377
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # Test for normal box
    data = compat_struct_pack('!I4s', 8, b'abcd')
    reader = FlvReader(data)
    assert reader.read_box_info() == (8, b'abcd', b'')
    # Test for large box
    data = compat_struct_pack('!I4sQ', 1, b'abcd', 16)
    reader = FlvReader(data)
    assert reader.read_box_info() == (16, b'abcd', b'')
    # Test for large box with data
    data = compat_struct_pack('!I4sQ12s', 1, b'abcd', 16, b'abcdefghijkl')
    reader = FlvReader(data)

# Generated at 2022-06-18 13:13:05.693723
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:13:14.368463
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    import io

# Generated at 2022-06-18 13:13:25.615302
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:13:36.260647
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:13:46.892118
# Unit test for function write_metadata_tag
def test_write_metadata_tag():
    stream = io.BytesIO()

# Generated at 2022-06-18 13:13:56.571710
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:14:05.547160
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:15:09.085227
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import std_headers
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.downloader.http import HttpDownloader
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_struct_pack
    from youtube_dl.compat import compat_b64decode
    from youtube_dl.compat import compat_etree_fromstring
    from youtube_dl.compat import compat_urlparse


# Generated at 2022-06-18 13:15:14.183308
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Test case 1
    # Inputs
    filename = 'test_filename'
    info_dict = {'url': 'test_url'}
    # Expected output
    expected_output = False
    # Output
    output = F4mFD().real_download(filename, info_dict)
    # Check
    assert output == expected_output



# Generated at 2022-06-18 13:15:22.530412
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:15:34.323458
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.downloader.f4m import F4mFD
    from youtube_dl.utils import urlopen
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor import get_info_extractor
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.extractor.generic import GenericIE
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.extractor.youtube import YoutubePlaylistIE
    from youtube_dl.extractor.youtube import YoutubeChannelIE
    from youtube_dl.extractor.youtube import YoutubeSearchIE
    from youtube_dl.extractor.youtube import YoutubeShowIE
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.extractor.youtube import YoutubePlaylistIE

# Generated at 2022-06-18 13:15:45.291616
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:15:55.835175
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1c\x61\x73\x72\x74\x00\x00\x00\x00\x00\x00\x00\x00'
        b'\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'
    )
    assert FlvReader(data).read_asrt() == {
        'segment_run': [(1, 1)],
    }



# Generated at 2022-06-18 13:16:03.280517
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-18 13:16:14.022545
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DownloadError
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat_urllib_parse_unquote_plus
    from youtube_dl.compat import compat_urllib_parse_urlencode
    from youtube_dl.compat import compat_urllib_parse_urljoin
    from youtube_dl.compat import compat_urllib_parse_urlsplit

# Generated at 2022-06-18 13:16:17.568447
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = b'\x00\x00\x00\x1c\x61\x73\x72\x74\x01\x6d\x6f\x64\x65\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x02'
    assert FlvReader(data).read_asrt() == {
        'segment_run': [
            (0, 1),
            (1, 2),
        ]
    }

# Generated at 2022-06-18 13:16:25.027726
# Unit test for method read_abst of class FlvReader