

# Generated at 2022-06-18 13:07:12.157511
# Unit test for method read_string of class FlvReader

# Generated at 2022-06-18 13:07:19.665512
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    flv_reader = FlvReader(b'\x00\x01\x02\x03\x04\x00\x06\x07\x08\x00')
    assert flv_reader.read_string() == b'\x00\x01\x02\x03\x04'
    assert flv_reader.read_string() == b'\x06\x07\x08'
    assert flv_reader.read_string() == b''


# Generated at 2022-06-18 13:07:29.882436
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DownloadError
    from youtube_dl.downloader.f4m import F4mFD
    from youtube_dl.downloader.external import ExternalFD
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.downloader.rtmp import RtmpFD
    from youtube_dl.downloader.hls import HlsFD
    from youtube_dl.downloader.dash import DashFD
    from youtube_dl.downloader.ism import IsmFD
    from youtube_dl.downloader.fragment import FragmentFD
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.compat import compat_urllib_parse_urlparse


# Generated at 2022-06-18 13:07:41.618332
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import encode_data_uri
    from ..compat import compat_chr
    from ..downloader.common import FileDownloader
    from ..extractor import get_info_extractor
    from ..compat import compat_urllib_request

    # Download a sample file
    url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    ie = get_info_extractor(url)
    info = ie.extract(url)
    fd = FileDownloader(params={})
    fd.add_info_extractor(ie)
    fd.params.update(info)
    fd.params['noplaylist'] = True
    fd.params['nocheckcertificate'] = True
    fd.params['prefer_free_formats'] = True

# Generated at 2022-06-18 13:07:50.381172
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import re
    import json
    import random
    import string
    import time
    import urllib.request
    import urllib.parse
    import urllib.error
    import xml.etree.ElementTree
    import base64
    import struct
    import hashlib
    import itertools
    import collections
    import socket
    import ssl
    import http.client
    import http.cookiejar
    import http.server
    import socketserver
    import threading
    import traceback
    import unittest
    import unittest.mock
    import warnings
    import zlib
    import pytest
    import pytest_localserver
    import youtube_dl.utils
    import youtube_dl.extractor


# Generated at 2022-06-18 13:07:58.310264
# Unit test for method read_box_info of class FlvReader

# Generated at 2022-06-18 13:08:10.805402
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL> http://example.com/ </baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'


# Generated at 2022-06-18 13:08:22.574874
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from ..utils import encode_data_uri
    from ..compat import compat_str
    from ..extractor.common import InfoExtractor
    from ..extractor.generic import GenericIE
    from ..compat import (
        compat_urllib_request,
    )

    class TestIE(InfoExtractor):
        IE_NAME = 'test'
        _VALID_URL = r'https?://(?:www\.)?test\.com/video/(?P<id>[^/]+)'


# Generated at 2022-06-18 13:08:34.465104
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from ..utils import encode_data_uri
    from ..compat import compat_chr

    def _test_FlvReader_read_abst(data, expected):
        bootstrap_info = FlvReader(data).read_bootstrap_info()
        assert bootstrap_info == expected

    # Test case 1

# Generated at 2022-06-18 13:08:45.582830
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1c'  # box size
        b'asrt'  # box type
        b'\x00'  # version
        b'\x00\x00\x00'  # flags
        b'\x01'  # QualityEntryCount
        b'\x00\x00\x00\x00'  # SegmentRunEntryCount
    )
    assert FlvReader(data).read_asrt() == {
        'segment_run': [],
    }


# Generated at 2022-06-18 13:09:37.546982
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-18 13:09:48.611187
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:09:58.003705
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:10:09.318949
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import encode_data_uri
    from ..compat import compat_urlopen
    from ..downloader.http import HEADRequest
    from ..downloader.common import FileDownloader
    from ..extractor import get_info_extractor

    # Download the bootstrap info
    ie = get_info_extractor('Youtube', 'youtube')
    url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    request = HEADRequest(url)
    info = ie._request_webpage(url, None, request, False, {})
    bootstrap_url = info['url']
    request = HEADRequest(bootstrap_url)
    fd = FileDownloader({'outtmpl': '%(id)s.f4m'}, ie, downloader=None)
    fd.add

# Generated at 2022-06-18 13:10:17.746864
# Unit test for function write_flv_header
def test_write_flv_header():
    from ..utils import encode_data_uri
    stream = io.BytesIO()
    write_flv_header(stream)

# Generated at 2022-06-18 13:10:29.520027
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from ..utils import encode_data_uri

# Generated at 2022-06-18 13:10:38.180315
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:10:50.339956
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-18 13:11:01.876306
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from .extractor.common import InfoExtractor
    from .utils import ExtractorError
    from .downloader.http import HttpFD
    from .downloader.http import HEADRequest
    from .compat import compat_urllib_request
    from .compat import compat_urllib_error
    import os
    import tempfile
    import shutil
    import random
    import string
    import json
    import time
    import re
    import sys
    import io
    import hashlib
    import unittest
    import unittest.mock
    import urllib.parse
    import urllib.error
    import urllib.request
    import xml.etree.ElementTree
    import xml.etree.cElementTree
    import xml.etree.ElementTree as ET
    import xml.etree.c

# Generated at 2022-06-18 13:11:13.209716
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-18 13:11:51.517600
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    data = b'\x00\x01\x02\x03\x04\x00\x05\x06\x07\x08\x09\x00'
    reader = FlvReader(data)
    assert reader.read_string() == b'\x00\x01\x02\x03\x04'
    assert reader.read_string() == b'\x05\x06\x07\x08\x09'



# Generated at 2022-06-18 13:12:00.233413
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    xml = '''
    <media url="http://example.com/video.mp4"
           bootstrapInfoId="bootstrap1"
           bitrate="1234"
           width="1280"
           height="720"
           drmAdditionalHeaderId="drmHeader1"
           drmAdditionalHeaderSetId="drmHeaderSet1"
           />
    <media url="http://example.com/video2.mp4"
           bootstrapInfoId="bootstrap2"
           bitrate="1234"
           width="1280"
           height="720"
           />
    '''
    media = remove_encrypted_media(compat_etree_fromstring(xml))
    assert len(media) == 1
    assert media[0].attrib['url'] == 'http://example.com/video2.mp4'



# Generated at 2022-06-18 13:12:11.135355
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:12:19.190566
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:12:23.780930
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Test with a manifest file
    manifest_url = 'https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/bipbop_4x3_variant.m3u8'
    ydl = YoutubeDL({'outtmpl': '%(id)s.%(ext)s'})
    f4m_fd = F4mFD(ydl, {'url': manifest_url, 'ext': 'mp4'})
    f4m_fd.real_download('test.mp4', {'url': manifest_url})
    # Test with a f4m file

# Generated at 2022-06-18 13:12:27.352383
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-18 13:12:31.132088
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-18 13:12:42.069488
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:12:53.644011
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request

    # Test data is generated by the following command:
    #   ffmpeg -i http://vod.leasewebcdn.com/bbb.flv?ri=1024&rs=150&start=0 -c copy -f flv -
    # The output is then manually edited to remove the first 8 bytes (FLV header)
    # and the last 4 bytes (previous tag size)

# Generated at 2022-06-18 13:12:57.474978
# Unit test for function write_flv_header
def test_write_flv_header():
    from io import BytesIO
    stream = BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-18 13:15:19.281388
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import sys
    import os
    import tempfile
    import shutil
    import re
    import subprocess
    import random
    import string
    import json
    import time
    import urllib.parse
    import urllib.request
    import urllib.error
    import xml.etree.ElementTree as ET
    import base64
    import struct
    import itertools
    import collections
    import hashlib
    import binascii
    import zlib
    import io
    import socket
    import ssl
    import http.client
    import http.cookiejar
    import http.cookies
    import http.server
    import socketserver
    import threading
    import queue
    import unittest
    import unittest.mock
    import tempfile
    import shutil
    import re

# Generated at 2022-06-18 13:15:30.654781
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:15:41.917732
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:15:54.193754
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1c'  # box size
        b'asrt'  # box type
        b'\x00'  # version
        b'\x00\x00\x00'  # flags
        b'\x01'  # QualityEntryCount
        b'\x00\x00\x00\x00'  # SegmentRunEntryCount
    )
    assert FlvReader(data).read_asrt() == {
        'segment_run': [],
    }


# Generated at 2022-06-18 13:15:59.132466
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = compat_etree_fromstring(
        '<media url="http://example.com/encrypted" '
        'drmAdditionalHeaderId="1" drmAdditionalHeaderSetId="2"/>'
        '<media url="http://example.com/not-encrypted"/>')
    assert len(remove_encrypted_media(media)) == 1



# Generated at 2022-06-18 13:16:09.549270
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:16:19.567068
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-18 13:16:28.390283
# Unit test for method read_afrt of class FlvReader