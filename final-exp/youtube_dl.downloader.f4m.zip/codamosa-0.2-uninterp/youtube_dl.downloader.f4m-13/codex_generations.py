

# Generated at 2022-06-18 13:06:51.722292
# Unit test for function write_flv_header
def test_write_flv_header():
    from ..compat import BytesIO
    stream = BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-18 13:07:02.727274
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:07:13.680951
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL> http://example.com/ </baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

# Generated at 2022-06-18 13:07:25.090741
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:07:33.845098
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-18 13:07:45.248315
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/2.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'


# Generated at 2022-06-18 13:07:55.824659
# Unit test for function get_base_url

# Generated at 2022-06-18 13:08:07.942871
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        b'<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        b'<baseURL>http://example.com/</baseURL></manifest>')
    assert get_base_url(manifest) == 'http://example.com/'
    manifest = compat_etree_fromstring(
        b'<manifest xmlns="http://ns.adobe.com/f4m/2.0">'
        b'<baseURL>http://example.com/</baseURL></manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

# Generated at 2022-06-18 13:08:17.391022
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = [
        {'url': 'http://example.com/1'},
        {'url': 'http://example.com/2', 'drmAdditionalHeaderId': '1'},
        {'url': 'http://example.com/3', 'drmAdditionalHeaderSetId': '1'},
        {'url': 'http://example.com/4'},
    ]
    assert remove_encrypted_media(media) == [
        {'url': 'http://example.com/1'},
        {'url': 'http://example.com/4'},
    ]



# Generated at 2022-06-18 13:08:22.377534
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1c'
        b'asrt'
        b'\x00'
        b'\x00\x00\x00'
        b'\x01'
        b'\x00'
        b'\x00\x00\x00\x02'
        b'\x00\x00\x00\x00\x00\x00\x00\x01'
        b'\x00\x00\x00\x00\x00\x00\x00\x02'
    )
    assert FlvReader(data).read_asrt() == {
        'segment_run': [
            (0, 1),
            (1, 2),
        ],
    }


# Generated at 2022-06-18 13:09:27.957180
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1e'  # box size
        b'asrt'  # box type
        b'\x00'  # version
        b'\x00\x00\x00'  # flags
        b'\x01'  # QualityEntryCount
        b'\x00\x00\x00\x00'  # SegmentRunEntryCount
        b'\x00\x00\x00\x00'  # QualitySegmentUrlModifiers
    )
    assert FlvReader(data).read_asrt() == {
        'segment_run': [],
    }


# Generated at 2022-06-18 13:09:35.391746
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1c'  # size
        b'asrt'  # type
        b'\x00'  # version
        b'\x00\x00\x00'  # flags
        b'\x01'  # QualityEntryCount
        b'\x00\x00\x00\x00'  # SegmentRunEntryCount
    )
    asrt = FlvReader(data).read_asrt()
    assert asrt['segment_run'] == []


# Generated at 2022-06-18 13:09:42.180499
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:09:46.593669
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-18 13:09:56.845050
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'segments': [{
            'segment_run': [
                (0, 2),
                (1, 3),
                (2, 4),
            ],
        }],
        'fragments': [{
            'fragments': [
                {'first': 0},
                {'first': 5},
                {'first': 10},
                {'first': 15},
            ],
        }],
        'live': False,
    }
    assert build_fragments_list(boot_info) == [
        (0, 0), (0, 1),
        (1, 2), (1, 3), (1, 4),
        (2, 5), (2, 6), (2, 7), (2, 8),
    ]


# Generated at 2022-06-18 13:10:07.962944
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:10:16.870899
# Unit test for method read_string of class FlvReader

# Generated at 2022-06-18 13:10:28.141577
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:10:37.500609
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    # Test with a real file
    with io.open('tests/data/bootstrap_live.abst', 'rb') as f:
        abst = FlvReader(f.read()).read_abst()
    assert abst['live']

# Generated at 2022-06-18 13:10:49.751512
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:11:15.865278
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DownloadError
    from youtube_dl.utils import sanitize_open
    from youtube_dl.utils import encodeFilename
    from youtube_dl.utils import write_json_file
    from youtube_dl.utils import read_json_file
    from youtube_dl.utils import prepend_extension
    from youtube_dl.utils import remove_start
    from youtube_dl.utils import remove_end
    from youtube_dl.utils import clean_html
    from youtube_dl.utils import unescapeHTML
    from youtube_dl.utils import unescapeURL
    from youtube_dl.utils import unescapeFilename
    from youtube_dl.utils import unescapeApostrophes

# Generated at 2022-06-18 13:11:25.931168
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:11:32.220776
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = compat_etree_fromstring(
        '<media url="http://example.com/encrypted.f4m" '
        'drmAdditionalHeaderId="1" drmAdditionalHeaderSetId="2"/>'
        '<media url="http://example.com/not_encrypted.f4m"/>')
    assert len(remove_encrypted_media(media)) == 1



# Generated at 2022-06-18 13:11:40.599198
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:11:51.604245
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:11:57.619839
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-18 13:12:05.908618
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from .test_fragment import _TEST_BOOTSTRAP_INFO
    bootstrap_info = FlvReader(_TEST_BOOTSTRAP_INFO).read_bootstrap_info()
    assert bootstrap_info['live'] is False
    assert len(bootstrap_info['segments']) == 1
    assert len(bootstrap_info['fragments']) == 1
    assert len(bootstrap_info['fragments'][0]['fragments']) == 2



# Generated at 2022-06-18 13:12:15.099550
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:12:21.901017
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-18 13:12:32.245842
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-18 13:12:57.392512
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DownloadError
    from youtube_dl.extractor import common
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_struct_pack
    from youtube_dl.compat import compat_b64decode
    from youtube_dl.compat import compat_etree_fromstring
    from youtube_dl.compat import compat_urlparse
    from youtube_dl.compat import compat_urllib_parse_urlparse


# Generated at 2022-06-18 13:13:03.110649
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DownloadError
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_etree_fromstring
    from youtube_dl.compat import compat_struct_pack
    from youtube_dl.compat import compat_b64decode
    from youtube_dl.compat import compat_urlparse
    from youtube_dl.utils import DataTruncatedError
    from youtube_dl.utils import fix_xml_ampersands
    from youtube_dl.utils import xpath_text

# Generated at 2022-06-18 13:13:12.595393
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    data = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    reader = FlvReader(data)
    assert reader.read_box_info() == (0, b'\x00\x00\x00\x00', b'')

    data = b'\x00\x00\x00\x01\x00\x00\x00\x00'
    reader = FlvReader(data)
    assert reader.read_box_info() == (1, b'\x00\x00\x00\x00', b'')

    data = b'\x00\x00\x00\x01\x00\x00\x00\x01'
    reader = FlvReader(data)
    assert reader.read_box_info()

# Generated at 2022-06-18 13:13:23.247011
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:13:34.472428
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import encode_data_uri
    from .common import urlopen
    from .dash import _parse_mpd_formats
    from .dash import _get_formats_from_mpd_node
    from .dash import _get_mpd_formats
    from .dash import _extract_mpd_formats
    from .dash import _extract_mpd_formats_for_legacy_rtmp_protocol
    from .dash import _extract_mpd_formats_for_f4m_formats
    from .dash import _extract_mpd_formats_for_f4m_formats_with_bootstrap_info
    from .dash import _extract_mpd_formats_for_f4m_formats_with_bootstrap_info_v2

# Generated at 2022-06-18 13:13:44.857064
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Test case 1
    # Input:
    #   filename = 'test.flv'
    #   info_dict = {
    #       'url': 'http://example.com/manifest.f4m',
    #       'tbr': None,
    #   }
    # Expected output:
    #   True
    filename = 'test.flv'
    info_dict = {
        'url': 'http://example.com/manifest.f4m',
        'tbr': None,
    }
    assert F4mFD().real_download(filename, info_dict) == True

    # Test case 2
    # Input:
    #   filename = 'test.flv'
    #   info_dict = {
    #       'url': 'http://example.com/manifest.f4m',

# Generated at 2022-06-18 13:13:54.469194
# Unit test for method read_string of class FlvReader

# Generated at 2022-06-18 13:14:04.264765
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    xml = '''
    <media url="http://example.com/encrypted.f4m"
           bootstrapInfoId="bootstrap1"
           bitrate="500"
           width="320"
           height="180"
           streamId="stream1"
           drmAdditionalHeaderId="drm1"
           drmAdditionalHeaderSetId="drm2"
           />
    <media url="http://example.com/unencrypted.f4m"
           bootstrapInfoId="bootstrap1"
           bitrate="500"
           width="320"
           height="180"
           streamId="stream1"
           />
    '''
    media = compat_etree_fromstring(xml)
    assert len(media) == 2
    assert 'drmAdditionalHeaderId' in media[0].attrib

# Generated at 2022-06-18 13:14:11.769703
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:14:18.007854
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = [
        {'attrib': {'url': 'http://example.com/1'}},
        {'attrib': {'url': 'http://example.com/2',
                    'drmAdditionalHeaderId': '1',
                    'drmAdditionalHeaderSetId': '2'}},
        {'attrib': {'url': 'http://example.com/3'}},
        {'attrib': {'url': 'http://example.com/4',
                    'drmAdditionalHeaderId': '3',
                    'drmAdditionalHeaderSetId': '4'}},
    ]

# Generated at 2022-06-18 13:15:11.066995
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:15:16.457930
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-18 13:15:23.932104
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:15:35.083083
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:15:46.482238
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DownloadError
    from youtube_dl.utils import encodeFilename
    from youtube_dl.utils import sanitize_open
    from youtube_dl.utils import sanitized_Request
    from youtube_dl.utils import write_json_file
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_

# Generated at 2022-06-18 13:15:58.995826
# Unit test for method read_string of class FlvReader

# Generated at 2022-06-18 13:16:09.551082
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:16:19.566439
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:16:26.257132
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-18 13:16:34.118720
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    data = b'\x00\x00\x00\x00'
    reader = FlvReader(data)
    assert reader.read_box_info() == (0, b'\x00\x00\x00\x00', b'')

    data = b'\x00\x00\x00\x01'
    reader = FlvReader(data)
    assert reader.read_box_info() == (1, b'\x00\x00\x00\x01', b'')

    data = b'\x00\x00\x00\x01' + b'\x00\x00\x00\x00'
    reader = FlvReader(data)