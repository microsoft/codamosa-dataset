

# Generated at 2022-06-18 13:07:05.357607
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:07:15.179224
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0"><baseURL>http://example.com/</baseURL></manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/2.0"><baseURL>http://example.com/</baseURL></manifest>')
    assert get_base_url(manifest) == 'http://example.com/'


# Generated at 2022-06-18 13:07:21.661411
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import re
    import random
    import string
    import json
    import urllib.request
    import urllib.parse
    import urllib.error
    import xml.etree.ElementTree as ET
    import base64
    import hashlib
    import hmac
    import time
    import datetime
    import itertools
    import struct
    import zlib
    import binascii
    import collections
    import socket
    import ssl
    import http.client
    import http.cookiejar
    import email.utils
    import mimetypes
    import io
    import warnings
    import traceback
    import platform
    import subprocess
    import random
    import string
    import json

# Generated at 2022-06-18 13:07:31.328614
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/2.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

# Generated at 2022-06-18 13:07:42.396798
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:07:51.380454
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import encode_data_uri
    from ..compat import compat_urlretrieve
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_parse

    # Download the file
    url = 'http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8'
    request = compat_urllib_request.Request(url)
    request.add_header('User-Agent', 'Mozilla/5.0 (X11; Linux x86_64; rv:22.0) Gecko/20100101 Firefox/22.0 Iceweasel/22.0')

# Generated at 2022-06-18 13:07:58.837958
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    flv_reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x00')
    assert flv_reader.read_bootstrap_info() == {
        'segments': [],
        'fragments': [],
        'live': False,
    }
    flv_reader = FlvReader(b'\x00\x00\x00\x00\x00\x00\x00\x00')
    assert flv_reader.read_bootstrap_info() == {
        'segments': [],
        'fragments': [],
        'live': False,
    }

# Generated at 2022-06-18 13:08:03.403270
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:08:13.817150
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = compat_etree_fromstring('''
        <media url="http://example.com/encrypted.f4m"
               bootstrapInfoId="bootstrap1"
               bitrate="1"
               width="1"
               height="1"
               drmAdditionalHeaderId="1"
               drmAdditionalHeaderSetId="1"
               />
        <media url="http://example.com/not_encrypted.f4m"
               bootstrapInfoId="bootstrap1"
               bitrate="1"
               width="1"
               height="1"
               />
        ''')
    assert len(remove_encrypted_media(media)) == 1


# Generated at 2022-06-18 13:08:25.893928
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL> http://example.com/ </baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

# Generated at 2022-06-18 13:09:01.828989
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:09:13.476558
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Test case 1
    # Inputs
    filename = 'test_filename'
    info_dict = {'url': 'test_url'}
    # Expected outputs
    expected_output = True

    # Test case 2
    # Inputs
    filename = 'test_filename'
    info_dict = {'url': 'test_url'}
    # Expected outputs
    expected_output = True

    # Test case 3
    # Inputs
    filename = 'test_filename'
    info_dict = {'url': 'test_url'}
    # Expected outputs
    expected_output = True

    # Test case 4
    # Inputs
    filename = 'test_filename'
    info_dict = {'url': 'test_url'}
    # Expected outputs
    expected_output = True

    # Test

# Generated at 2022-06-18 13:09:17.741320
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DownloadError
    from youtube_dl.utils import ExtractorError
    from youtube_dl.utils import format_bytes
    from youtube_dl.utils import format_seconds
    from youtube_dl.utils import get_filesystem_encoding
    from youtube_dl.utils import make_HTTPS_handler
    from youtube_dl.utils import make_shorthand_to_format
    from youtube_dl.utils import match_filter_func
    from youtube_dl.utils import prepend_extension
    from youtube_dl.utils import read_batch_urls
    from youtube_dl.utils import remove_end
    from youtube_dl.utils import remove

# Generated at 2022-06-18 13:09:29.060621
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DownloadError
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.extractor.generic import GenericIE
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat_urllib_parse_unquote_plus
    from youtube_dl.compat import compat_urllib_parse_urlencode
    from youtube_dl.compat import compat_ur

# Generated at 2022-06-18 13:09:38.329901
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:09:45.753784
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = b'\x00\x00\x00\x1c\x61\x73\x72\x74\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01'
    assert FlvReader(data).read_asrt() == {
        'segment_run': [(0, 1)],
    }


# Generated at 2022-06-18 13:09:56.124791
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request
    from .common import (
        determine_ext,
        HEADRequest,
    )
    from .dash import (
        DASHIE,
        parse_mpd_formats,
    )
    from .fragment import (
        download_fragment,
    )
    from .smoothstreams import (
        SmoothStreamsIE,
    )
    from .youtube import (
        YoutubeIE,
    )


# Generated at 2022-06-18 13:10:07.504603
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'segments': [{
            'segment_run': [
                (0, 2),
                (1, 2),
            ],
        }],
        'fragments': [{
            'fragments': [
                {'first': 0},
                {'first': 2},
            ],
        }],
        'live': False,
    }
    assert build_fragments_list(boot_info) == [
        (0, 0), (0, 1),
        (1, 2), (1, 3),
    ]


# Generated at 2022-06-18 13:10:16.526513
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-18 13:10:27.435997
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:10:52.274853
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-18 13:11:04.394734
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:11:14.973769
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1c'  # box size
        b'asrt'  # box type
        b'\x00'  # version
        b'\x00\x00\x00'  # flags
        b'\x01'  # QualityEntryCount
        b'\x00\x00\x00\x00'  # SegmentRunEntryCount
    )
    assert FlvReader(data).read_asrt() == {
        'segment_run': [],
    }


# Generated at 2022-06-18 13:11:25.295592
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:11:36.955598
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.downloader.http import HttpDownloader
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.utils import sanitize_open
    from youtube_dl.utils import encodeFilename
    from youtube_dl.utils import sanitize_filename
    from youtube_dl.utils import sanitized_Request
    from youtube_dl.utils import write_json_file
    from youtube_dl.utils import read_json_

# Generated at 2022-06-18 13:11:48.465550
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x2c'  # size
        b'asrt'  # type
        b'\x00'  # version
        b'\x00\x00\x00'  # flags
        b'\x01'  # QualityEntryCount
        b'\x00\x00\x00\x00'  # SegmentRunEntryCount
        b'\x00\x00\x00\x00'  # FirstSegment
        b'\x00\x00\x00\x00'  # FragmentsPerSegment
    )
    res = FlvReader(data).read_asrt()
    assert res == {
        'segment_run': [],
    }


# Generated at 2022-06-18 13:11:58.882523
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-18 13:12:10.760137
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:12:18.888117
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-18 13:12:29.067691
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:12:46.697349
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:12:57.882805
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Test case 1
    # Input:
    #   filename = 'test.flv'
    #   info_dict = {
    #       'url': 'http://example.com/manifest.f4m',
    #       'tbr': None,
    #       'extra_param_to_segment_url': None,
    #   }
    # Expected output:
    #   True
    filename = 'test.flv'
    info_dict = {
        'url': 'http://example.com/manifest.f4m',
        'tbr': None,
        'extra_param_to_segment_url': None,
    }
    assert F4mFD.real_download(filename, info_dict) == True

    # Test case 2
    # Input:
    #   filename = 'test

# Generated at 2022-06-18 13:13:09.094191
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:13:19.693170
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DownloadError
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat_urllib_parse_unquote_plus
    from youtube_dl.compat import compat_urllib_parse_urlencode
    from youtube_dl.compat import compat_urllib_parse_urljoin

# Generated at 2022-06-18 13:13:30.917028
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:13:41.117333
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:13:51.480570
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-18 13:13:56.530077
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = compat_etree_fromstring(
        '<media url="http://example.com/1" drmAdditionalHeaderId="1" />'
        '<media url="http://example.com/2" drmAdditionalHeaderSetId="1" />'
        '<media url="http://example.com/3" />')
    assert len(remove_encrypted_media(media)) == 1



# Generated at 2022-06-18 13:14:03.002856
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    data = compat_struct_pack('!I4s', 12, b'abcd') + b'efgh'
    reader = FlvReader(data)
    assert reader.read_box_info() == (12, b'abcd', b'efgh')
    data = compat_struct_pack('!Q4s', 12, b'abcd') + b'efgh'
    reader = FlvReader(data)
    assert reader.read_box_info() == (12, b'abcd', b'efgh')



# Generated at 2022-06-18 13:14:11.007248
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    import base64
    from ..compat import compat_str
    from ..utils import encode_data_uri

    # Test data is from https://github.com/ytdl-org/youtube-dl/issues/13404

# Generated at 2022-06-18 13:14:51.392570
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..compat import compat_urlopen
    from ..utils import (
        determine_ext,
        float_or_none,
        int_or_none,
        parse_iso8601,
        strip_jsonp,
    )
    from ..downloader.common import FileDownloader
    from ..extractor import (
        get_info_extractor,
        gen_extractors,
        ListExtractor,
    )
    from ..post import (
        PostProcessingError,
        FFmpegPostProcessor,
    )
    from ..cache import (
        YoutubeDLFileCache,
    )
    from ..downloader.f4m import (
        F4mFD,
    )

    class TestInfoExtractor(object):
        IE_NAME = 'test'

# Generated at 2022-06-18 13:15:00.115592
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from ..compat import compat_chr
    from ..utils import encode_base_n

    def _encode_base_n(n, b):
        return encode_base_n(n, b, '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_')

    def _encode_base_64(n):
        return _encode_base_n(n, 64)

    def _encode_base_36(n):
        return _encode_base_n(n, 36)

    def _encode_base_16(n):
        return _encode_base_n(n, 16)

    def _encode_base_10(n):
        return _encode_base_n(n, 10)

# Generated at 2022-06-18 13:15:10.561974
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-18 13:15:20.099020
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:15:31.482586
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:15:37.255966
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:15:49.059201
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from ..utils import encode_data_uri

# Generated at 2022-06-18 13:16:00.459778
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:16:11.269411
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-18 13:16:20.697317
# Unit test for method read_abst of class FlvReader