

# Generated at 2022-06-18 13:07:18.305107
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:07:28.972483
# Unit test for method read_string of class FlvReader

# Generated at 2022-06-18 13:07:40.246541
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1c'
        b'\x61\x73\x72\x74'
        b'\x00'
        b'\x00\x00\x00'
        b'\x01'
        b'\x00\x00\x00\x00'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x00'
        b'\x00\x00\x00\x00'
    )
    assert FlvReader(data).read_asrt() == {
        'segment_run': [(0, 1), (1, 0)],
    }

# Unit

# Generated at 2022-06-18 13:07:47.243189
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = b'\x00\x00\x00\x1c\x61\x73\x72\x74\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'
    assert FlvReader(data).read_asrt() == {
        'segment_run': [(1, 1)],
    }


# Generated at 2022-06-18 13:07:56.137639
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-18 13:08:08.152825
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from .common import fake_httpd
    from ..utils import encode_data_uri


# Generated at 2022-06-18 13:08:20.883112
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'segments': [{
            'segment_run': [
                (0, 2),
                (1, 3),
                (2, 4),
            ]
        }],
        'fragments': [{
            'fragments': [
                {'first': 0},
                {'first': 1},
                {'first': 2},
                {'first': 3},
                {'first': 4},
                {'first': 5},
                {'first': 6},
                {'first': 7},
                {'first': 8},
                {'first': 9},
            ]
        }],
        'live': False,
    }

# Generated at 2022-06-18 13:08:31.690548
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    xml = """<media url="http://example.com/video.mp4" bootstrapInfoId="bootstrap1"
    drmAdditionalHeaderId="drmHeader1" drmAdditionalHeaderSetId="drmHeaderSet1"
    bitrate="500" width="320" height="240"
    />"""
    media = compat_etree_fromstring(xml)
    assert len(remove_encrypted_media(media)) == 0

    xml = """<media url="http://example.com/video.mp4" bootstrapInfoId="bootstrap1"
    bitrate="500" width="320" height="240"
    />"""
    media = compat_etree_fromstring(xml)
    assert len(remove_encrypted_media(media)) == 1



# Generated at 2022-06-18 13:08:42.855718
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-18 13:08:51.162282
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL> http://example.com/ </baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

# Generated at 2022-06-18 13:09:21.337541
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DownloadError
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.extractor.generic import GenericIE
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_parse_urlencode
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat_urllib_parse_unquote_

# Generated at 2022-06-18 13:09:32.586004
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:09:40.525593
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:09:50.845576
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:09:59.559331
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:10:11.267801
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-18 13:10:17.044969
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-18 13:10:28.410954
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:10:37.669802
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:10:49.974670
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DateRange
    from youtube_dl.utils import DownloadError
    from youtube_dl.utils import ExtractorError
    from youtube_dl.utils import format_bytes
    from youtube_dl.utils import format_seconds
    from youtube_dl.utils import sanitize_open
    from youtube_dl.utils import std_headers
    from youtube_dl.utils import urlopen
    from youtube_dl.utils import write_string
    from youtube_dl.utils import write_json_file
    from youtube_dl.utils import write_string
    from youtube_dl.utils import write_string
    from youtube_dl.utils import write_string
    from youtube_dl.utils import write_string

# Generated at 2022-06-18 13:12:13.600715
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    data = b'\x00\x00\x00\x00'
    reader = FlvReader(data)
    assert reader.read_box_info() == (0, b'\x00\x00\x00\x00', b'')

    data = b'\x00\x00\x00\x01'
    reader = FlvReader(data)
    assert reader.read_box_info() == (1, b'\x00\x00\x00\x01', b'')

    data = b'\x00\x00\x00\x01' + b'\x00' * 8
    reader = FlvReader(data)
    assert reader.read_box_info() == (1, b'\x00\x00\x00\x01', b'')

    data = b

# Generated at 2022-06-18 13:12:20.874497
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-18 13:12:30.965299
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:12:35.623926
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DownloadError
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_response
    from youtube_dl.compat import compat_urllib_parse_urlencode
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat_urllib_parse_unquote_plus
    from youtube_dl.compat import compat_urllib_parse_urljoin

# Generated at 2022-06-18 13:12:44.939935
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # Test case 1: normal case
    data = compat_struct_pack('!I4s', 12, b'abcd') + b'1234'
    reader = FlvReader(data)
    assert reader.read_box_info() == (12, b'abcd', b'1234')
    # Test case 2: size = 1
    data = compat_struct_pack('!I4sQ', 1, b'abcd', 12) + b'1234'
    reader = FlvReader(data)
    assert reader.read_box_info() == (12, b'abcd', b'1234')
    # Test case 3: size = 0
    data = compat_struct_pack('!I4s', 0, b'abcd')
    reader = FlvReader(data)
    assert reader.read_box_info

# Generated at 2022-06-18 13:12:56.017178
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DownloadError
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_parse_urlencode
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat_urllib_parse_unquote_plus
    from youtube_dl.compat import compat_urllib_parse_urljoin

# Generated at 2022-06-18 13:13:06.763849
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:13:14.923357
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    xml = '''
    <media url="http://example.com/encrypted.f4f"
           bootstrapInfoId="bootstrap1"
           bitrate="500"
           width="1280"
           height="720"
           drmAdditionalHeaderId="1"
           drmAdditionalHeaderSetId="1">
    </media>
    <media url="http://example.com/not_encrypted.f4f"
           bootstrapInfoId="bootstrap1"
           bitrate="500"
           width="1280"
           height="720">
    </media>
    '''
    media = remove_encrypted_media(compat_etree_fromstring(xml))
    assert len(media) == 1
    assert media[0].attrib['url'] == 'http://example.com/not_encrypted.f4f'



# Generated at 2022-06-18 13:13:26.288584
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import youtube_dl.YoutubeDL
    import youtube_dl.extractor.common
    import youtube_dl.utils
    import youtube_dl.downloader.common
    import youtube_dl.downloader.f4m
    import youtube_dl.downloader.fragment
    import youtube_dl.downloader.hls
    import youtube_dl.downloader.http
    import youtube_dl.downloader.rtmp
    import youtube_dl.postprocessor.ffmpeg
    import youtube_dl.postprocessor.metadatafromtitle
    import youtube_dl.postprocessor.xattr
    import youtube_dl.postprocessor.execafterdownload
    import youtube_dl.postprocessor.ffmpegmetadata
    import youtube_dl.postprocessor.embedthumbnail
    import youtube_dl.postprocessor.xattrpp

# Generated at 2022-06-18 13:13:36.659445
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x0c'  # size
        b'asrt'  # type
        b'\x00'  # version
        b'\x00\x00\x00'  # flags
        b'\x01'  # QualityEntryCount
        b'\x00\x00\x00\x00'  # SegmentRunEntryCount
    )
    assert FlvReader(data).read_asrt() == {
        'segment_run': [],
    }


# Generated at 2022-06-18 13:14:58.775746
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import encode_data_uri
    from ..compat import compat_urlopen
    from ..downloader.common import ContentTooShortError
    from ..downloader.http import HEADRequest
    from ..downloader.http.headers import HEADRequestHeaders
    from ..downloader.http.cookies import CookieJar
    from ..downloader.http.cookies import compat_cookiejar_Cookie
    from ..downloader.http.cookies import compat_cookiejar_CookieJar
    from ..downloader.http.cookies import compat_cookiejar_MozillaCookieJar
    from ..downloader.http.cookies import compat_cookiejar_load
    from ..downloader.http.cookies import compat_cookiejar_save
    from ..downloader.http.cookies import compat_cookiejar_set_cookie

# Generated at 2022-06-18 13:15:09.085059
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:15:18.751064
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-18 13:15:30.172165
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:15:34.960828
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = compat_etree_fromstring(
        '<media url="http://example.com/1" '
        'drmAdditionalHeaderId="1" '
        'drmAdditionalHeaderSetId="1"/>'
        '<media url="http://example.com/2" '
        'drmAdditionalHeaderId="2" '
        'drmAdditionalHeaderSetId="2"/>'
        '<media url="http://example.com/3"/>'
    )
    assert len(remove_encrypted_media(media)) == 1



# Generated at 2022-06-18 13:15:37.458919
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class F4mFD
    pass



# Generated at 2022-06-18 13:15:49.608342
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.f4m import F4mFD
    from youtube_dl.utils import sanitize_open
    from youtube_dl.extractor import get_info_extractor
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_request_urlopen
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat_urllib_parse_urlencode
    from youtube_dl.compat import compat_urllib_parse_urljoin
    from youtube_dl.compat import compat_urllib_parse_urlsplit
    from youtube_dl.compat import compat_urllib_parse_

# Generated at 2022-06-18 13:16:00.637117
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:16:11.457871
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-18 13:16:20.820433
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'segments': [{
            'segment_run': [
                (0, 1),
                (1, 2),
                (2, 3),
            ],
        }],
        'fragments': [{
            'fragments': [
                {'first': 0},
                {'first': 1},
                {'first': 2},
                {'first': 3},
                {'first': 4},
                {'first': 5},
            ],
        }],
    }
    assert build_fragments_list(boot_info) == [
        (0, 0),
        (1, 1),
        (1, 2),
        (2, 3),
        (2, 4),
        (2, 5),
    ]

