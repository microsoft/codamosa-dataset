

# Generated at 2022-06-18 13:07:14.927005
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = b'\x00\x00\x00\x1c\x61\x73\x72\x74\x01\x00\x00\x00\x68\x65\x6c\x6c\x6f\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'
    reader = FlvReader(data)
    assert reader.read_asrt() == {
        'segment_run': [(1, 1)],
    }


# Generated at 2022-06-18 13:07:19.881020
# Unit test for function write_flv_header
def test_write_flv_header():
    stream = io.BytesIO()
    write_flv_header(stream)
    assert stream.getvalue() == b'FLV\x01\x05\x00\x00\x00\x09\x00\x00\x00\x00'



# Generated at 2022-06-18 13:07:30.014757
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:07:36.744976
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-18 13:07:47.132197
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-18 13:07:56.476291
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.postprocessor.ffmpeg import FFmpegMetadataPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegExtractAudioPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegVideoConvertorPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegEmbedSubtitlePP
    from youtube_dl.postprocessor.ffmpeg import FFmpegFixupStretchedPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegFixupM3u8PP
    from youtube_dl.postprocessor.ffmpeg import FFmpegFixupM4aPP
    from youtube_dl.postprocessor.ffmpeg import FFmpegFixupM4aPP

# Generated at 2022-06-18 13:08:08.697569
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:08:21.002177
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:08:32.595462
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:08:37.113923
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-18 13:09:17.025562
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL> http://example.com/ </baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'


# Generated at 2022-06-18 13:09:28.149116
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:09:37.739388
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    import os
    import unittest

    class TestFlvReader_read_abst(unittest.TestCase):
        def setUp(self):
            self.flv_reader = FlvReader(open(os.path.join(
                os.path.dirname(__file__),
                'test_data',
                'test_FlvReader_read_abst.flv'), 'rb').read())

        def test_read_abst(self):
            abst = self.flv_reader.read_bootstrap_info()
            self.assertEqual(abst['live'], False)
            self.assertEqual(len(abst['segments']), 1)
            self.assertEqual(len(abst['fragments']), 1)

# Generated at 2022-06-18 13:09:41.913694
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.f4m import F4mFD
    from youtube_dl.utils import urlopen
    from youtube_dl.extractor import get_info_extractor
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat_urllib_parse_unquote_plus
    from youtube_dl.compat import compat_urllib_parse_urlencode
    from youtube_dl.compat import compat_urllib_parse_urljoin
    from youtube_dl.compat import compat_urllib_parse_urlsplit
    from youtube_dl.compat import compat_urllib_parse_url

# Generated at 2022-06-18 13:09:52.585039
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # Test case 1
    # Test data is from https://www.adobe.com/devnet/f4v.html
    # The test data is a box with size = 0x00000018, type = 'abst'
    # The box data is a box with size = 0x00000001, type = 'afrt'
    # The box data is a box with size = 0x0000000C, type = 'asrt'
    test_data = b'\x00\x00\x00\x18abst\x00\x00\x00\x01afrt\x00\x00\x00\x0Casrt'
    reader = FlvReader(test_data)

# Generated at 2022-06-18 13:10:00.177137
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/2.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

# Generated at 2022-06-18 13:10:11.740289
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:10:19.186114
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import DateRange
    from youtube_dl.extractor import get_info_extractor
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat_urllib_parse_unquote_plus
    from youtube_dl.compat import compat_urllib_parse_urlencode
    from youtube_dl.compat import compat

# Generated at 2022-06-18 13:10:30.391545
# Unit test for function remove_encrypted_media

# Generated at 2022-06-18 13:10:41.238534
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/2.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

# Generated at 2022-06-18 13:11:07.973288
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:11:17.753253
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:11:28.431592
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1c'
        b'asrt'
        b'\x00'
        b'\x00\x00\x00'
        b'\x01'
        b'\x00'
        b'\x00\x00\x00\x02'
        b'\x00\x00\x00\x00\x00\x00\x00\x01'
        b'\x00\x00\x00\x01\x00\x00\x00\x01'
    )
    assert FlvReader(data).read_asrt() == {
        'segment_run': [
            (0, 1),
            (1, 1),
        ],
    }


# Generated at 2022-06-18 13:11:38.981597
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    assert FlvReader(b'\x00').read_string() == b''
    assert FlvReader(b'\x00\x00').read_string() == b''
    assert FlvReader(b'\x01\x00').read_string() == b'\x01'
    assert FlvReader(b'\x01\x02\x00').read_string() == b'\x01\x02'
    assert FlvReader(b'\x01\x02\x03\x00').read_string() == b'\x01\x02\x03'
    assert FlvReader(b'\x01\x02\x03\x04\x00').read_string() == b'\x01\x02\x03\x04'


# Generated at 2022-06-18 13:11:44.456049
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = compat_etree_fromstring(
        '<media url="http://example.com/encrypted" '
        'drmAdditionalHeaderId="1" drmAdditionalHeaderSetId="1"/>'
        '<media url="http://example.com/not-encrypted"/>')
    assert len(remove_encrypted_media(media)) == 1



# Generated at 2022-06-18 13:11:55.945181
# Unit test for function build_fragments_list
def test_build_fragments_list():
    # Test for a non-live stream
    boot_info = {
        'segments': [{
            'segment_run': [
                (0, 1),
                (1, 1),
                (2, 1),
            ],
        }],
        'fragments': [{
            'fragments': [
                {'first': 0, 'ts': 0, 'duration': 0, 'discontinuity_indicator': None},
                {'first': 1, 'ts': 0, 'duration': 0, 'discontinuity_indicator': None},
                {'first': 2, 'ts': 0, 'duration': 0, 'discontinuity_indicator': None},
            ],
        }],
        'live': False,
    }

# Generated at 2022-06-18 13:12:01.968024
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = compat_etree_fromstring(
        '<media url="http://example.com/encrypted.f4m" '
        'drmAdditionalHeaderId="1" drmAdditionalHeaderSetId="2"/>'
        '<media url="http://example.com/not-encrypted.f4m"/>')
    assert len(remove_encrypted_media(media)) == 1



# Generated at 2022-06-18 13:12:12.149245
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:12:17.976610
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    data = compat_struct_pack('!I4s', 12, b'abcd') + b'1234'
    reader = FlvReader(data)
    assert reader.read_box_info() == (12, b'abcd', b'1234')
    data = compat_struct_pack('!Q4s', 12, b'abcd') + b'1234'
    reader = FlvReader(data)
    assert reader.read_box_info() == (12, b'abcd', b'1234')


# Generated at 2022-06-18 13:12:28.891050
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:13:00.200887
# Unit test for function write_metadata_tag

# Generated at 2022-06-18 13:13:10.596036
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-18 13:13:21.807040
# Unit test for method read_string of class FlvReader

# Generated at 2022-06-18 13:13:32.757653
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-18 13:13:40.408925
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = [
        {'url': 'http://example.com/1'},
        {'url': 'http://example.com/2', 'drmAdditionalHeaderId': '1'},
        {'url': 'http://example.com/3', 'drmAdditionalHeaderSetId': '1'},
        {'url': 'http://example.com/4'},
    ]
    assert remove_encrypted_media(media) == [
        {'url': 'http://example.com/1'},
        {'url': 'http://example.com/4'},
    ]



# Generated at 2022-06-18 13:13:50.439070
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # Test case 1: normal case
    data = compat_struct_pack('!I4s', 12, b'abcd') + b'efgh'
    reader = FlvReader(data)
    assert reader.read_box_info() == (12, b'abcd', b'efgh')

    # Test case 2: size is 1
    data = compat_struct_pack('!I4sQ', 1, b'abcd', 12) + b'efgh'
    reader = FlvReader(data)
    assert reader.read_box_info() == (12, b'abcd', b'efgh')

    # Test case 3: size is 0
    data = compat_struct_pack('!I4s', 0, b'abcd')
    reader = FlvReader(data)
    assert reader.read_box_info

# Generated at 2022-06-18 13:14:00.451982
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:14:08.555851
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:14:13.303387
# Unit test for method read_box_info of class FlvReader
def test_FlvReader_read_box_info():
    # Test for normal case
    data = compat_struct_pack('!I4s', 8, b'abcd')
    reader = FlvReader(data)
    assert reader.read_box_info() == (8, b'abcd', b'')
    # Test for large size
    data = compat_struct_pack('!I4sQ', 1, b'abcd', 10)
    reader = FlvReader(data)
    assert reader.read_box_info() == (10, b'abcd', b'')



# Generated at 2022-06-18 13:14:19.288479
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..compat import compat_urllib_request
    from ..utils import (
        determine_ext,
        HEADRequest,
    )
    from ..downloader.common import (
        FileDownloader,
    )

    def _get_bootstrap_info(url):
        downloader = FileDownloader(
            params=dict(nopart=True),
            progress_hooks=[lambda *args: None],
        )
        info_dict = downloader.ydl.prepare_filename(
            {'url': url, 'ext': determine_ext(url)})
        info_dict['urlhandle'] = HEADRequest(url)
        info_dict['http_headers'] = info_dict['urlhandle'].headers
        info_dict['filename'] = 'test.f4f'

# Generated at 2022-06-18 13:15:26.211449
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = [
        {'url': 'http://example.com/1'},
        {'url': 'http://example.com/2', 'drmAdditionalHeaderId': '1'},
        {'url': 'http://example.com/3', 'drmAdditionalHeaderSetId': '1'},
        {'url': 'http://example.com/4'},
    ]
    assert remove_encrypted_media(media) == [
        {'url': 'http://example.com/1'},
        {'url': 'http://example.com/4'},
    ]



# Generated at 2022-06-18 13:15:37.958728
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:15:49.821488
# Unit test for method read_string of class FlvReader

# Generated at 2022-06-18 13:16:00.755022
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..compat import compat_urlopen
    from ..utils import (
        determine_ext,
    )
    from ..extractor import (
        YoutubeIE,
    )
    from ..downloader import (
        FileDownloader,
    )
    from ..downloader.http import (
        HttpFD,
    )
    from ..downloader.f4m import (
        F4mFD,
    )
    from ..downloader.fragment import (
        FragmentFD,
    )
    from ..downloader.external import (
        ExternalFD,
    )
    from ..downloader.rtmp import (
        RtmpFD,
    )
    from ..downloader.dash import (
        DashSegmentsFD,
    )
    from ..downloader.hls import (
        HlsFD,
    )

# Generated at 2022-06-18 13:16:11.570371
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import encode_data_uri
    from ..compat import compat_urllib_request
    from io import BytesIO
    from ..extractor import gen_extractors
    from ..downloader.common import FileDownloader

    # Download the file
    url = 'http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8'
    request = compat_urllib_request.Request(url)
    request.add_header('User-Agent', 'Mozilla/5.0 (X11; Linux x86_64; rv:22.0) Gecko/20100101 Firefox/22.0 Iceweasel/22.0')
    opener = compat_urllib_request.build_opener()
    data = opener.open(request).read()

# Generated at 2022-06-18 13:16:20.917836
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:16:30.469024
# Unit test for method real_download of class F4mFD