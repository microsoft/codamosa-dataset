

# Generated at 2022-06-18 13:07:13.521396
# Unit test for method read_bootstrap_info of class FlvReader
def test_FlvReader_read_bootstrap_info():
    from ..utils import encode_data_uri
    from ..compat import compat_urlopen
    from ..downloader.common import FileDownloader
    from ..extractor import gen_extractors

    # Download a sample flv file
    url = 'https://github.com/ytdl-org/youtube-dl/raw/master/test/testdata/test.flv'
    fd = FileDownloader({})
    fd.params['nopart'] = True
    fd.params['continuedl'] = False
    fd.params['nocheckcertificate'] = True
    fd.params['quiet'] = True
    fd.params['outtmpl'] = '%(id)s'
    fd.params['test'] = True

# Generated at 2022-06-18 13:07:19.175457
# Unit test for function remove_encrypted_media
def test_remove_encrypted_media():
    media = [
        {'url': 'http://example.com/encrypted_media.f4m',
         'drmAdditionalHeaderId': '1',
         'drmAdditionalHeaderSetId': '2'},
        {'url': 'http://example.com/media.f4m'}
    ]
    assert remove_encrypted_media(media) == [media[1]]



# Generated at 2022-06-18 13:07:29.478039
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:07:41.056330
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-18 13:07:49.879527
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:08:00.635858
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-18 13:08:13.046491
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.utils import DownloadError
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_response
    from youtube_dl.compat import compat_urllib_parse_urlencode
    from youtube_dl.utils import encode_compat_str
    from youtube_dl.utils import encode_data_uri
    from youtube_dl.utils import sanitize_open
    from youtube_dl.utils import sanitized_Request
    from youtube_dl.utils import write_json_

# Generated at 2022-06-18 13:08:25.257597
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:08:36.669486
# Unit test for function get_base_url
def test_get_base_url():
    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/1.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'

    manifest = compat_etree_fromstring(
        '<manifest xmlns="http://ns.adobe.com/f4m/2.0">'
        '<baseURL>http://example.com/</baseURL>'
        '</manifest>')
    assert get_base_url(manifest) == 'http://example.com/'


# Generated at 2022-06-18 13:08:47.386549
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    # Test for method real_download(self, filename, info_dict)
    # of class F4mFD
    # Called from __main__; parameters set there
    import sys
    import os
    import tempfile
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_request
    from .utils import sanitize_open

    ie = InfoExtractor()
    ie.report_warning = lambda msg: sys.stderr.write(msg + '\n')
    ie.report_error = lambda msg: sys.stderr.write(msg + '\n')
    ie.troubleshoot = lambda: sys.stderr.write('troubleshoot\n')

# Generated at 2022-06-18 13:09:33.955769
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1c'
        b'asrt'
        b'\x00'
        b'\x00\x00\x00'
        b'\x00'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x00\x00\x00\x00\x01'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x01'
        b'\x00\x00\x00\x01'
    )

# Generated at 2022-06-18 13:09:41.355676
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:09:49.809143
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    test_data = b'\x00\x00\x00\x1c\x61\x73\x72\x74\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'
    reader = FlvReader(test_data)
    assert reader.read_asrt() == {
        'segment_run': [(1, 1)],
    }


# Generated at 2022-06-18 13:09:58.828951
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:10:10.488111
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import re
    import time
    import random
    import json
    import urllib.request
    import urllib.parse
    import urllib.error
    import http.cookiejar
    import ssl
    import socket
    import threading
    import queue
    import hashlib
    import base64
    import xml.etree.ElementTree
    import xml.etree.cElementTree
    import xml.etree.ElementTree as ET
    import xml.dom.minidom
    import xml.sax.saxutils
    import xml.sax
    import xml.parsers.expat
    import xml.dom.expatbuilder
    import xml.dom.minidom
    import xml.dom.pulldom


# Generated at 2022-06-18 13:10:16.764404
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'segments': [{
            'segment_run': [
                (0, 2),
                (1, 3),
                (2, 4),
            ],
        }],
        'fragments': [{
            'fragments': [
                {'first': 0},
                {'first': 2},
                {'first': 5},
                {'first': 9},
                {'first': 14},
                {'first': 20},
                {'first': 27},
                {'first': 35},
                {'first': 44},
                {'first': 54},
                {'first': 65},
                {'first': 77},
            ],
        }],
        'live': False,
    }

# Generated at 2022-06-18 13:10:27.773574
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:10:37.144746
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1c'
        b'asrt'
        b'\x00'
        b'\x00\x00\x00'
        b'\x01'
        b'\x00'
        b'\x00\x00\x00\x02'
        b'\x00\x00\x00\x00\x00\x00\x00\x01'
        b'\x00\x00\x00\x01\x00\x00\x00\x01'
    )
    assert FlvReader(data).read_asrt() == {
        'segment_run': [(0, 1), (1, 1)],
    }


# Generated at 2022-06-18 13:10:49.339155
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:11:00.779215
# Unit test for method read_string of class FlvReader

# Generated at 2022-06-18 13:12:04.017431
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from ytdl.downloader.f4m import F4mFD
    from ytdl.extractor.common import InfoExtractor
    from ytdl.utils import urlopen
    from ytdl.YoutubeDL import YoutubeDL
    from io import BytesIO
    from xml.etree import ElementTree as ET
    from urllib.parse import urlparse
    from ytdl.compat import compat_urllib_parse_urlparse
    from ytdl.compat import compat_urllib_error
    from ytdl.compat import compat_struct_pack
    from ytdl.compat import compat_b64decode
    from ytdl.compat import compat_etree_fromstring
    from ytdl.compat import compat_urlparse
    from ytdl.utils import xpath_text

# Generated at 2022-06-18 13:12:14.085838
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.downloader.f4m import F4mFD
    from youtube_dl.utils import DownloadError
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_etree_fromstring
    from youtube_dl.compat import compat_struct_pack
    from youtube_dl.compat import compat_b64decode
    from youtube_dl.compat import compat_urlparse
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_parse_urlencode

# Generated at 2022-06-18 13:12:21.246979
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.utils import DownloadError
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.extractor.http import HttpFD
    from youtube_dl.downloader.http import HttpDownloader
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.compat import compat_urllib_error
    from youtube_dl.compat import compat_urllib_parse
    from youtube_dl.compat import compat_urllib_parse_urlparse
    from youtube_dl.compat import compat_urllib_parse_unquote
    from youtube_dl.compat import compat_urllib_parse_unquote_plus
    from youtube_dl.compat import compat_urllib_parse

# Generated at 2022-06-18 13:12:25.693519
# Unit test for method real_download of class F4mFD

# Generated at 2022-06-18 13:12:29.953872
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import sys
    import os
    import shutil
    import tempfile
    import unittest
    import youtube_dl.YoutubeDL
    import youtube_dl.utils
    from youtube_dl.extractor.common import InfoExtractor
    from youtube_dl.extractor.f4m import F4mFD
    from youtube_dl.utils import (
        encode_data_uri,
        encodeFilename,
        sanitize_open,
    )
    from youtube_dl.compat import (
        compat_urllib_parse,
        compat_urllib_request,
    )

# Generated at 2022-06-18 13:12:40.954474
# Unit test for method read_asrt of class FlvReader
def test_FlvReader_read_asrt():
    data = (
        b'\x00\x00\x00\x1c'  # box size
        b'asrt'  # box type
        b'\x00'  # version
        b'\x00\x00\x00'  # flags
        b'\x01'  # QualityEntryCount
        b'\x00\x00\x00\x00'  # SegmentRunTableCount
    )
    assert FlvReader(data).read_asrt() == {
        'segment_run': [],
    }


# Generated at 2022-06-18 13:12:51.810531
# Unit test for method real_download of class F4mFD
def test_F4mFD_real_download():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json
    import re
    import random
    import string
    import time
    import urllib.parse
    import urllib.request
    import urllib.error
    import xml.etree.ElementTree as ET

# Generated at 2022-06-18 13:13:00.409141
# Unit test for method read_asrt of class FlvReader

# Generated at 2022-06-18 13:13:10.751270
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:13:21.913484
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:15:00.125981
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:15:10.561337
# Unit test for function build_fragments_list
def test_build_fragments_list():
    boot_info = {
        'segments': [{
            'segment_run': [
                (0, 2),
                (1, 1),
            ],
        }],
        'fragments': [{
            'fragments': [
                {'first': 0, 'ts': 0, 'duration': 0, 'discontinuity_indicator': 0},
                {'first': 1, 'ts': 0, 'duration': 0, 'discontinuity_indicator': 0},
                {'first': 2, 'ts': 0, 'duration': 0, 'discontinuity_indicator': 0},
                {'first': 3, 'ts': 0, 'duration': 0, 'discontinuity_indicator': 0},
            ],
        }],
        'live': False,
    }
    assert build_

# Generated at 2022-06-18 13:15:20.099218
# Unit test for method read_abst of class FlvReader
def test_FlvReader_read_abst():
    from ..utils import (
        encode_base_n,
    )

# Generated at 2022-06-18 13:15:25.069233
# Unit test for method read_string of class FlvReader
def test_FlvReader_read_string():
    assert FlvReader(b'\x00').read_string() == b''
    assert FlvReader(b'\x01\x00').read_string() == b'\x01'
    assert FlvReader(b'\x01\x02\x00').read_string() == b'\x01\x02'



# Generated at 2022-06-18 13:15:36.220467
# Unit test for method read_abst of class FlvReader

# Generated at 2022-06-18 13:15:48.090668
# Unit test for method read_afrt of class FlvReader

# Generated at 2022-06-18 13:15:59.920376
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-18 13:16:10.394056
# Unit test for method read_bootstrap_info of class FlvReader

# Generated at 2022-06-18 13:16:20.229013
# Unit test for function build_fragments_list

# Generated at 2022-06-18 13:16:29.829027
# Unit test for method read_asrt of class FlvReader