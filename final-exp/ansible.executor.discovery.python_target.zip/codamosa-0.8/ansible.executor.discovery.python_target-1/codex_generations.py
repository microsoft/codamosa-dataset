

# Generated at 2022-06-10 23:02:01.677762
# Unit test for function read_utf8_file
def test_read_utf8_file():
    # test read_utf8_file with test_file which contains unicode characters
    content = read_utf8_file('/home/dipto/project/ansible/lib/ansible/module_utils/facts/test_file')
    assert content == '\u0000a\n'

# Generated at 2022-06-10 23:02:04.418823
# Unit test for function get_platform_info
def test_get_platform_info():
    result = get_platform_info()
    assert isinstance(result, dict)
    assert result['osrelease_content']
    assert isinstance(result['platform_dist_result'], list)

# Generated at 2022-06-10 23:02:11.081779
# Unit test for function read_utf8_file
def test_read_utf8_file():
    try:
        os.mkdir('testdir')
        os.chdir('testdir')
        f = open("test_utf8.txt", "w+")
        f.write("tête-à-tête")
        f.close()
        assert read_utf8_file('test_utf8.txt') == "tête-à-tête"
        os.remove('test_utf8.txt')
        os.chdir('..')
        os.rmdir('testdir')
    except OSError:
        pass

# Generated at 2022-06-10 23:02:19.839910
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release') == '''\
NAME="Ubuntu"
VERSION="16.04.4 LTS (Xenial Xerus)"
ID=ubuntu
ID_LIKE=debian
PRETTY_NAME="Ubuntu 16.04.4 LTS"
VERSION_ID="16.04"
HOME_URL="http://www.ubuntu.com/"
SUPPORT_URL="http://help.ubuntu.com/"
BUG_REPORT_URL="http://bugs.launchpad.net/ubuntu/"
VERSION_CODENAME=xenial
UBUNTU_CODENAME=xenial
'''

# Generated at 2022-06-10 23:02:22.820754
# Unit test for function get_platform_info
def test_get_platform_info():
    assert get_platform_info()['osrelease_content'] == ''
    assert get_platform_info()['platform_dist_result'] == ['', '', '']

# Generated at 2022-06-10 23:02:32.720441
# Unit test for function get_platform_info
def test_get_platform_info():
    osrelease_content = """"""
    osrelease_expected_output = dict(
        osrelease_content=osrelease_content,
        platform_dist_result=[],
    )

    osrelease_content = """NAME="Amazon Linux"
VERSION="2"
ID="amzn"
ID_LIKE="centos rhel fedora"
VERSION_ID="2"
PRETTY_NAME="Amazon Linux 2"
ANSI_COLOR="0;33"
CPE_NAME="cpe:2.3:o:amazon:amazon_linux:2"
HOME_URL="https://amazonlinux.com/"

"""
    osrelease_expected_output = dict(
        osrelease_content=osrelease_content,
        platform_dist_result=['', '', '', ''],
    )


# Generated at 2022-06-10 23:02:39.487708
# Unit test for function read_utf8_file
def test_read_utf8_file():
    demo_str = '''{"platform": {"name": "ubuntu", "ver": "12.04"}}'''
    demo_filename = '/tmp/abc.json'
    with open(demo_filename, 'w') as f:
        f.write(demo_str)
    assert read_utf8_file(demo_filename) == '''{"platform": {"name": "ubuntu", "ver": "12.04"}}'''
    os.remove(demo_filename)

# Generated at 2022-06-10 23:02:41.127150
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release')

# Generated at 2022-06-10 23:02:49.293149
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('test_data/test_utf8_txt_file') == u"\u2211 \u03A3 \u03B1 \u03BB \u03BB \u03B7 \u03BB \u03B7"
    assert read_utf8_file('test_data/test_bad_encoding.txt') == u"\u2211 \u03A3 \u03B1 \u03BB \u03BB \u03B7 \u03BB \u03B7"
    assert read_utf8_file('test_data/test_ansi_txt_file') == u"\u2211 \u03A3 \u03B1 \u03BB \u03BB \u03B7 \u03BB \u03B7"

# Generated at 2022-06-10 23:02:52.384925
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/hosts') == '127.0.0.1 localhost\n'



# Generated at 2022-06-10 23:02:57.304547
# Unit test for function get_platform_info
def test_get_platform_info():
    p_info = get_platform_info()
    assert p_info['osrelease_content'] == ''
    assert p_info['platform_dist_result'] == ['', '', '']

# Generated at 2022-06-10 23:02:59.596822
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('file.txt', 'utf-8').strip() == "test test test"

# Generated at 2022-06-10 23:03:04.156373
# Unit test for function get_platform_info
def test_get_platform_info():
    assert get_platform_info() == {'platform_dist_result': (),
                                   'osrelease_content': 'NAME=Linux Mint\nVERSION="18.3 Sylvia"\nID=linuxmint\nID_LIKE=ubuntu\nPRETTY_NAME="Linux Mint 18.3"\nVERSION_ID="18.3"\nHOME_URL="http://www.linuxmint.com/"\nSUPPORT_URL="http://forums.linuxmint.com/"\nBUG_REPORT_URL="http://bugs.launchpad.net/linuxmint/"\nVERSION_CODENAME=sylvia\nUBUNTU_CODENAME=xenial\n'}

# Generated at 2022-06-10 23:03:06.641528
# Unit test for function get_platform_info
def test_get_platform_info():
    from ansibullbot.utils.platforminfo import get_platform_info
    assert(get_platform_info())

# Generated at 2022-06-10 23:03:16.937164
# Unit test for function get_platform_info
def test_get_platform_info():
    # Create a dummy output directory
    try:
        os.mkdir('output')
    except:
        pass

    # Write test content to dummy
    with open('/etc/os-release', 'w') as f:
        f.write('ID=ubuntu\n')     # ID was previously returned as well
        f.write('VERSION_ID=16.04\n')
        f.write('PRETTY_NAME="Ubuntu 16.04 LTS"\n')

    # Execute get_platform_info()
    info = get_platform_info()

    # Write result to output dir
    with open('output/ubunturel.txt', 'w') as f:
        f.write(str(info))

    # Read result back in and convert to dict

# Generated at 2022-06-10 23:03:17.846609
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()

# Generated at 2022-06-10 23:03:23.688553
# Unit test for function read_utf8_file
def test_read_utf8_file():
    # Test unreadable file path
    assert read_utf8_file('/notarealpath') == None
    # Test readable file path
    assert read_utf8_file('/etc/passwd') == read_utf8_file('/etc/passwd')

    # Unreadable file should return None
    assert read_utf8_file('/notarealpath') == None
# Test unreadable file path

# Generated at 2022-06-10 23:03:30.557649
# Unit test for function read_utf8_file
def test_read_utf8_file():

    # Write UTF-8 encoded file
    with io.open('/tmp/testfile', 'w', encoding='utf-8') as f:
        f.write(u'\u620a\u5b50')

    # Now read in the file (should be the same) and test
    content = read_utf8_file('/tmp/testfile')
    assert content == u'\u620a\u5b50'

    # Remove file when done
    os.remove('/tmp/testfile')

# Generated at 2022-06-10 23:03:33.642296
# Unit test for function read_utf8_file
def test_read_utf8_file():
    actual = read_utf8_file('/etc/os-release')
    expected = read_utf8_file('tests/test_data/expected_response_os-release')
    assert actual == expected

# Generated at 2022-06-10 23:03:35.692161
# Unit test for function get_platform_info
def test_get_platform_info():
    assert get_platform_info() == {
        'platform_dist_result': [],
        'osrelease_content': None
    }

# Generated at 2022-06-10 23:03:40.070915
# Unit test for function read_utf8_file
def test_read_utf8_file():
    expected = 'Hello World'
    content = read_utf8_file('./testfile.txt')
    assert content == expected


# Generated at 2022-06-10 23:03:40.775221
# Unit test for function get_platform_info
def test_get_platform_info():
    assert get_platform_info()

# Generated at 2022-06-10 23:03:48.544817
# Unit test for function read_utf8_file
def test_read_utf8_file():
    import tempfile
    import shutil
    import os
    import os.path

    tmp_dir = tempfile.mkdtemp()
    tmp_file_name = os.path.join(tmp_dir, 'tmp_file')

    with open(tmp_file_name, 'w+') as fd:
        fd.write('hello_world')
        fd.write('\n')

    assert read_utf8_file(tmp_file_name) == 'hello_world\n'

    shutil.rmtree(tmp_dir)



# Generated at 2022-06-10 23:03:52.644673
# Unit test for function read_utf8_file
def test_read_utf8_file():
    infile = "tests/fixtures/platform_data/os-release"
    osrelease_content = read_utf8_file(infile)
    assert osrelease_content is not None
    assert osrelease_content.startswith('NAME="Amazon Linux AMI"')
    assert osrelease_content.strip().endswith('"')


# Generated at 2022-06-10 23:03:59.869797
# Unit test for function read_utf8_file
def test_read_utf8_file():
    import pytest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    with patch('ansible_collections.ansible.community.tests.unit.compat.misc.read_utf8_file') as mock_read_utf8_file:
        mock_read_utf8_file.return_value = 'test'
        assert read_utf8_file('test_path') == 'test'

# Generated at 2022-06-10 23:04:04.006722
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert 'osrelease_content' in info, "Platform does not include os-release file"
    assert 'platform_dist_result' in info, "Uses platform.dist() to get os info"

# Generated at 2022-06-10 23:04:08.133092
# Unit test for function get_platform_info
def test_get_platform_info():
    result = get_platform_info()

    assert result['platform_dist_result'] == [], "platform_dist_result should be empty"
    assert result['osrelease_content'], "os_release_content should not be empty"

# Generated at 2022-06-10 23:04:11.371264
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release')
    assert not read_utf8_file('/etc/os-release123')


# Generated at 2022-06-10 23:04:13.499743
# Unit test for function get_platform_info
def test_get_platform_info():
    res = get_platform_info()
    assert res['osrelease_content']
    assert res['platform_dist_result']

# Generated at 2022-06-10 23:04:16.116255
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release')
    assert not read_utf8_file('/etc/os-release-not-exist')

# Generated at 2022-06-10 23:04:19.605808
# Unit test for function get_platform_info
def test_get_platform_info():
    test_info = get_platform_info()
    assert test_info['platform_dist_result'] is not None

# Generated at 2022-06-10 23:04:27.732264
# Unit test for function get_platform_info
def test_get_platform_info():
    from ansible.compat.tests.mock import patch
    from ansible.compat.tests.mock import MagicMock
    with patch("ansible.utils.platform_info._get_platform_info") as mock_platform_info:
        mock_platform_info.side_effect = OSError
        result = {}
        assert get_platform_info() == result
        mock_platform_info.side_effect = None
        mock_platform_info.return_value = dict(platform_dist_result=['Fedora', '28', 'Rawhide'])
        mock_file_return = MagicMock(return_value='Fedora')

# Generated at 2022-06-10 23:04:31.201549
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release')
    assert not read_utf8_file('/etc/os-release_missing')
    assert read_utf8_file('/usr/lib/os-release')
    assert not read_utf8_file('/usr/lib/os-release_missing')

# Generated at 2022-06-10 23:04:34.065924
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert None == read_utf8_file('/path/no/exist')
    assert "example" == read_utf8_file('../../examples/files/example.txt')

# Generated at 2022-06-10 23:04:41.757770
# Unit test for function get_platform_info
def test_get_platform_info():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, MagicMock

    with patch.object(platform, 'dist', return_value='test') as mock_dist:
        with patch('ansible_collections.ansible.community.plugins.module_utils.basic.distro.read_utf8_file', return_value='test') as mock_file:
            result = get_platform_info()
            assert mock_dist.call_count == 1
            assert mock_file.call_count == 2
            assert result.get('platform_dist_result') == 'test'
            assert result.get('osrelease_content') == 'test'

# Generated at 2022-06-10 23:04:43.399908
# Unit test for function read_utf8_file
def test_read_utf8_file():
    path = "/etc/os-release"
    assert read_utf8_file(path) is not None

# Generated at 2022-06-10 23:04:52.606264
# Unit test for function get_platform_info
def test_get_platform_info():
    expected = {'osrelease_content': 'NAME="Amazon Linux AMI"\nVERSION="2012.03"\nID="amzn"\nID_LIKE="rhel fedora"\nVERSION_ID="2012.03"\nPRETTY_NAME="Amazon Linux AMI release 2012.03"\nANSI_COLOR="0;33"\nCPE_NAME="cpe:/o:amazon:linux:2012.03:ga"\n\nAMI_VERSION="2012.03"\n', 'platform_dist_result': ('', '', '')}
    assert get_platform_info() == expected

# Generated at 2022-06-10 23:04:56.931933
# Unit test for function read_utf8_file
def test_read_utf8_file():
    dst_path = '/tmp/read_utf8_file.txt'
    fd = io.open(dst_path, 'w', encoding='utf-8')
    fd.write(u'Test Message\n')
    fd.close()
    content = read_utf8_file(dst_path)
    assert (content == u'Test Message\n')

# Generated at 2022-06-10 23:05:08.856953
# Unit test for function read_utf8_file
def test_read_utf8_file():
    # Test case 1 - File content is ascii
    test_file_content = 'abc123'
    path = '/tmp/readutf8file.txt'
    with open(path, 'w') as fd:
        fd.write(test_file_content)
    if not os.access(path, os.R_OK):
        assert False
    content = read_utf8_file(path, encoding='utf-8')

    assert content == test_file_content

    os.remove(path)

    # Test case 2 - File content is unicode
    test_file_content = u'\u042d\u0442\u043e UTF-8'
    path = '/tmp/readutf8file.txt'

# Generated at 2022-06-10 23:05:17.959843
# Unit test for function get_platform_info
def test_get_platform_info():
    class osrelease(object):
        def __init__(self):
            self.read = False

        def read(self):
            self.read = True
            return "OSRELEASE_CONTENT"

    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] is None

    setattr(platform, 'dist', lambda: ('Linux', '7.2', 'Core'))
    info = get_platform_info()
    assert info['platform_dist_result'] == ('Linux', '7.2', 'Core')
    assert info['osrelease_content'] is None

    setattr(os, 'access', lambda p, r: True)
    setattr(io, 'open', osrelease())
    info = get_platform_info()

# Generated at 2022-06-10 23:05:20.916740
# Unit test for function read_utf8_file
def test_read_utf8_file():
  assert isinstance(read_utf8_file('run.py'), str)


# Generated at 2022-06-10 23:05:22.166053
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('test_utils.py')



# Generated at 2022-06-10 23:05:33.806125
# Unit test for function get_platform_info
def test_get_platform_info():

    assert os.path.exists('tests/resources/faux_os_release'), "tests/resources/faux_os_release not found, cannot run test"

    def mock_read_utf8_file(path, encoding=None):
        if path.endswith('os-release'):
            return open('tests/resources/faux_os_release').read()
        else:
            return None

    try:
        get_platform_info_backup = get_platform_info.__code__
    except AttributeError:
        # Python 2.6 doesn't support __code__
        get_platform_info_backup = get_platform_info.func_code


# Generated at 2022-06-10 23:05:43.416961
# Unit test for function read_utf8_file
def test_read_utf8_file():
    # Test non exist file
    path = '/tmp/test_read_utf8_file.txt'
    encoding='utf-8'
    assert read_utf8_file(path, encoding) == None

    # Test empty file
    with io.open(path, 'w', encoding=encoding) as fd:
        fd.write('')
    assert read_utf8_file(path, encoding) == ''

    # Test file with one line content
    with io.open(path, 'w', encoding=encoding) as fd:
        fd.write('Hello')
    assert read_utf8_file(path, encoding) == 'Hello'

    # Test file with multi line content
    with io.open(path, 'w', encoding=encoding) as fd:
        fd.write('Hello\nWorld')

# Generated at 2022-06-10 23:05:49.434276
# Unit test for function read_utf8_file
def test_read_utf8_file():
    if sys.version_info >= (3, 0):
        stdout = io.StringIO()
    else:
        stdout = io.BytesIO()

    with redirect_stdout(stdout):
        main()

    output = stdout.getvalue().strip()
    result = json.loads(output)
    assert 'platform_dist_result' in result
    assert 'osrelease_content' in result

# Generated at 2022-06-10 23:05:50.772697
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file("test.txt") == "This is a test"

# Generated at 2022-06-10 23:05:52.701288
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert isinstance(info['platform_dist_result'], tuple)

# Generated at 2022-06-10 23:05:54.728516
# Unit test for function get_platform_info
def test_get_platform_info():
    load = get_platform_info()
    assert load['osrelease_content'] == read_utf8_file('/etc/os-release')

# Generated at 2022-06-10 23:05:58.038739
# Unit test for function get_platform_info
def test_get_platform_info():
    platform_info = get_platform_info()
    assert platform_info['platform_dist_result'] == []
    assert platform_info['osrelease_content'] == None

# Generated at 2022-06-10 23:06:06.312278
# Unit test for function get_platform_info
def test_get_platform_info():
    import tempfile
    from ansible.module_utils.facts.collector import get_file_content
    # Create temporary files and directories
    tmpdir = tempfile.mkdtemp()
    osrelease = os.path.join(tmpdir, 'os-release')
    usrosrelease = os.path.join(tmpdir, 'usr', 'lib', 'os-release')

# Generated at 2022-06-10 23:06:08.972411
# Unit test for function get_platform_info
def test_get_platform_info():
    assert get_platform_info()

# Generated at 2022-06-10 23:06:10.791371
# Unit test for function read_utf8_file
def test_read_utf8_file():
    result = read_utf8_file('test_data/test.txt')
    assert result == 'test'

# Generated at 2022-06-10 23:06:12.395433
# Unit test for function get_platform_info
def test_get_platform_info():
    assert isinstance(get_platform_info(), dict)

# Generated at 2022-06-10 23:06:18.207043
# Unit test for function read_utf8_file
def test_read_utf8_file():
    import tempfile

    content = "This is sample test text file"
    fh, fn = tempfile.mkstemp()

    try:
        file_obj = os.fdopen(fh, 'w')
        file_obj.write(content)
        file_obj.close()
        result = read_utf8_file(fn)
        assert result == content
    finally:
        os.remove(fn)

# Generated at 2022-06-10 23:06:26.898601
# Unit test for function get_platform_info
def test_get_platform_info():
    test_info = dict(platform_dist_result=['Linux', 'Ubuntu', '16.04', 'xenial', 'Linux'])
    test_info['osrelease_content'] = '''NAME="Ubuntu"
VERSION="16.04.2 LTS (Xenial Xerus)"
ID=ubuntu
ID_LIKE=debian
PRETTY_NAME="Ubuntu 16.04.2 LTS"
VERSION_ID="16.04"
HOME_URL="http://www.ubuntu.com/"
SUPPORT_URL="http://help.ubuntu.com/"
BUG_REPORT_URL="http://bugs.launchpad.net/ubuntu/"
VERSION_CODENAME=xenial
UBUNTU_CODENAME=xenial'''

    info = get_platform_info()
    assert info == test_info

# Generated at 2022-06-10 23:06:30.349929
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()

    assert isinstance(info, dict)
    assert isinstance(info['platform_dist_result'], list)
    assert isinstance(info['osrelease_content'], str)

# Generated at 2022-06-10 23:06:36.292750
# Unit test for function get_platform_info
def test_get_platform_info():
    """
    Test function get_platform_info, not actually testing the behavior of the platform module,
    but just the structure that we get back.
    """
    info = get_platform_info()
    assert isinstance(info, dict)
    assert isinstance(info['platform_dist_result'], (tuple, list))
    assert isinstance(info['osrelease_content'], str)

# Generated at 2022-06-10 23:06:40.244286
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()

    assert isinstance(info, dict)
    assert isinstance(info['platform_dist_result'], list)
    assert isinstance(info['osrelease_content'], str)

# Generated at 2022-06-10 23:06:42.613629
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] != None

# Generated at 2022-06-10 23:06:46.272210
# Unit test for function get_platform_info
def test_get_platform_info():
    result = get_platform_info()
    assert isinstance(result['osrelease_content'], str), 'osrelease_content is not a str'
    assert isinstance(result['platform_dist_result'], list), 'platform_dist_result is not a list'

# Generated at 2022-06-10 23:06:50.310006
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert len(info['platform_dist_result']) == 3
    assert len(info['osrelease_content']) > 0

# Generated at 2022-06-10 23:06:59.395761
# Unit test for function get_platform_info
def test_get_platform_info():
    result = get_platform_info()
    assert result['osrelease_content'] == 'NAME="Amazon Linux AMI"\nVERSION="2018.03"\nID="amzn"\nID_LIKE="rhel fedora"\nVERSION_ID="2018.03"\nPRETTY_NAME="Amazon Linux AMI 2018.03"\nANSI_COLOR="0;33"\nCPE_NAME="cpe:/o:amazon:linux:2018.03:ga"\nHOME_URL="http://aws.amazon.com/amazon-linux-ami/"\n',\
        "Unexpected os-release content"

# Generated at 2022-06-10 23:07:04.157052
# Unit test for function read_utf8_file
def test_read_utf8_file():
    with io.open('os-release', 'w', encoding='utf-8') as f:
        f.write(u'ID="centos"\nNAME="CentOS Linux"')

    content = read_utf8_file('os-release', encoding='utf-8')
    assert content == u'ID="centos"\nNAME="CentOS Linux"'
    os.remove('os-release')

# Generated at 2022-06-10 23:07:09.823658
# Unit test for function get_platform_info
def test_get_platform_info():
    platform_info = get_platform_info()

    assert platform_info['osrelease_content']
    assert len(platform_info['osrelease_content']) > 0
    assert platform_info['osrelease_content'].startswith('ID')

    assert platform_info['platform_dist_result']
    assert len(platform_info['platform_dist_result']) > 0
    assert platform_info['platform_dist_result'][0]
    assert len(platform_info['platform_dist_result'][0]) > 0
    assert platform_info['platform_dist_result'][1]
    assert len(platform_info['platform_dist_result'][1]) > 0

# Generated at 2022-06-10 23:07:15.259494
# Unit test for function read_utf8_file
def test_read_utf8_file():
    # Tests with a path that does not exist
    assert read_utf8_file("/some/random/path") is None

    # Tests with a path that exists and contains the content 'test'
    with open('temp', 'w') as f:
        f.write('test')

    assert read_utf8_file("temp") == 'test'

    os.remove('temp')

# Generated at 2022-06-10 23:07:17.723474
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/does/not/exist') == None
    assert read_utf8_file('/dev/zero') is not None


# Generated at 2022-06-10 23:07:20.451492
# Unit test for function get_platform_info
def test_get_platform_info():
    assert get_platform_info() == {
        'osrelease_content': None,
        'platform_dist_result': ('', '', '')
    }


# Generated at 2022-06-10 23:07:23.152294
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release')
    assert read_utf8_file('/etc/os-release.bak') is None



# Generated at 2022-06-10 23:07:27.180668
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert isinstance(info['osrelease_content'], str)
    assert isinstance(info['platform_dist_result'], list)
    assert info['platform_dist_result'][0] == 'redhat'

# Generated at 2022-06-10 23:07:28.852285
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert(info['platform_dist_result'])