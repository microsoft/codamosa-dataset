

# Generated at 2022-06-16 20:44:09.801082
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release') is not None
    assert read_utf8_file('/usr/lib/os-release') is not None
    assert read_utf8_file('/etc/os-release-not-exists') is None
    assert read_utf8_file('/etc/os-release', 'utf-16') is not None


# Generated at 2022-06-16 20:44:14.020525
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release') is not None
    assert read_utf8_file('/usr/lib/os-release') is not None
    assert read_utf8_file('/etc/os-release-not-exist') is None


# Generated at 2022-06-16 20:44:16.907753
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == platform.dist()
    assert info['osrelease_content'] == read_utf8_file('/etc/os-release')

# Generated at 2022-06-16 20:44:19.493733
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release') is not None
    assert read_utf8_file('/usr/lib/os-release') is not None
    assert read_utf8_file('/etc/os-release-not-exist') is None

# Generated at 2022-06-16 20:44:21.331144
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None
    assert info['platform_dist_result'] is not None

# Generated at 2022-06-16 20:44:23.573147
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()

    assert info['platform_dist_result'] == platform.dist()
    assert info['osrelease_content'] == read_utf8_file('/etc/os-release')

# Generated at 2022-06-16 20:44:25.870640
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release')
    assert read_utf8_file('/usr/lib/os-release')
    assert not read_utf8_file('/etc/os-release-not-exist')

# Generated at 2022-06-16 20:44:28.453080
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:44:30.605163
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] is not None

# Generated at 2022-06-16 20:44:31.587680
# Unit test for function get_platform_info
def test_get_platform_info():
    assert get_platform_info()

# Generated at 2022-06-16 20:44:35.032339
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:44:37.865358
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:44:39.899058
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:44:40.876030
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:44:52.280259
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release') is not None
    assert read_utf8_file('/usr/lib/os-release') is not None
    assert read_utf8_file('/etc/os-release', 'utf-8') is not None
    assert read_utf8_file('/usr/lib/os-release', 'utf-8') is not None
    assert read_utf8_file('/etc/os-release', 'utf-8') is not None
    assert read_utf8_file('/usr/lib/os-release', 'utf-8') is not None
    assert read_utf8_file('/etc/os-release', 'utf-16') is not None
    assert read_utf8_file('/usr/lib/os-release', 'utf-16') is not None
   

# Generated at 2022-06-16 20:44:54.419215
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:44:59.038127
# Unit test for function read_utf8_file
def test_read_utf8_file():
    # Test for file which exists
    assert read_utf8_file('/etc/os-release') is not None

    # Test for file which does not exist
    assert read_utf8_file('/etc/os-release-not-exist') is None

# Generated at 2022-06-16 20:45:01.413166
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None
    assert info['platform_dist_result'] is not None

# Generated at 2022-06-16 20:45:02.556735
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None

# Generated at 2022-06-16 20:45:06.596075
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release')
    assert read_utf8_file('/usr/lib/os-release')
    assert not read_utf8_file('/etc/os-release-not-exist')


# Generated at 2022-06-16 20:45:10.192432
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:45:12.905299
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] is not None

# Generated at 2022-06-16 20:45:17.881532
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:45:20.203019
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release') is not None
    assert read_utf8_file('/usr/lib/os-release') is not None
    assert read_utf8_file('/etc/os-release-not-exist') is None

# Generated at 2022-06-16 20:45:27.441598
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] == 'NAME="Ubuntu"\nVERSION="18.04.1 LTS (Bionic Beaver)"\nID=ubuntu\nID_LIKE=debian\nPRETTY_NAME="Ubuntu 18.04.1 LTS"\nVERSION_ID="18.04"\nHOME_URL="https://www.ubuntu.com/"\nSUPPORT_URL="https://help.ubuntu.com/"\nBUG_REPORT_URL="https://bugs.launchpad.net/ubuntu/"\nPRIVACY_POLICY_URL="https://www.ubuntu.com/legal/terms-and-policies/privacy-policy"\nVERSION_CODENAME=bionic\nUBUNTU_CODENAME=bionic\n'
    assert info

# Generated at 2022-06-16 20:45:31.053103
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:45:33.203338
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] is not None

# Generated at 2022-06-16 20:45:35.271138
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:45:37.751772
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] is not None

# Generated at 2022-06-16 20:45:40.748959
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None
    assert info['platform_dist_result'] is not None

# Generated at 2022-06-16 20:45:44.429271
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:45:46.714510
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:45:48.680419
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:45:50.861874
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:45:53.443539
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:45:56.676453
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == platform.dist()
    assert info['osrelease_content'] == read_utf8_file('/etc/os-release')

# Generated at 2022-06-16 20:46:03.656606
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] == 'NAME="Ubuntu"\nVERSION="18.04.1 LTS (Bionic Beaver)"\nID=ubuntu\nID_LIKE=debian\nPRETTY_NAME="Ubuntu 18.04.1 LTS"\nVERSION_ID="18.04"\nHOME_URL="https://www.ubuntu.com/"\nSUPPORT_URL="https://help.ubuntu.com/"\nBUG_REPORT_URL="https://bugs.launchpad.net/ubuntu/"\nPRIVACY_POLICY_URL="https://www.ubuntu.com/legal/terms-and-policies/privacy-policy"\nVERSION_CODENAME=bionic\nUBUNTU_CODENAME=bionic\n'
    assert info

# Generated at 2022-06-16 20:46:06.805040
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == platform.dist()
    assert info['osrelease_content'] == read_utf8_file('/etc/os-release')

# Generated at 2022-06-16 20:46:08.793574
# Unit test for function get_platform_info
def test_get_platform_info():
    assert get_platform_info() == {'platform_dist_result': [], 'osrelease_content': None}

# Generated at 2022-06-16 20:46:12.760180
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release') is not None
    assert read_utf8_file('/usr/lib/os-release') is not None
    assert read_utf8_file('/etc/os-release-not-exist') is None

# Generated at 2022-06-16 20:46:15.256965
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:46:17.694742
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:46:20.266225
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:46:22.267889
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None
    assert info['platform_dist_result'] is not None

# Generated at 2022-06-16 20:46:29.148227
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release') is not None
    assert read_utf8_file('/usr/lib/os-release') is not None
    assert read_utf8_file('/etc/os-release') == read_utf8_file('/usr/lib/os-release')
    assert read_utf8_file('/etc/os-release') == read_utf8_file('/etc/os-release')
    assert read_utf8_file('/usr/lib/os-release') == read_utf8_file('/usr/lib/os-release')
    assert read_utf8_file('/etc/os-release') != read_utf8_file('/etc/os-release-test')
    assert read_utf8_file('/usr/lib/os-release') != read_

# Generated at 2022-06-16 20:46:32.726692
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == platform.dist()
    assert info['osrelease_content'] == read_utf8_file('/etc/os-release')

# Generated at 2022-06-16 20:46:35.261297
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] == read_utf8_file('/etc/os-release')

# Generated at 2022-06-16 20:46:36.494007
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None

# Generated at 2022-06-16 20:46:39.646193
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:46:42.051209
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:46:45.528302
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] is not None

# Generated at 2022-06-16 20:46:50.058529
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == platform.dist()
    assert info['osrelease_content'] == read_utf8_file('/etc/os-release')

# Generated at 2022-06-16 20:46:52.301585
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None
    assert info['platform_dist_result'] is not None

# Generated at 2022-06-16 20:46:53.239614
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None
    assert info['platform_dist_result'] is not None

# Generated at 2022-06-16 20:46:56.254287
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert isinstance(info, dict)
    assert isinstance(info['platform_dist_result'], list)
    assert isinstance(info['osrelease_content'], str)

# Generated at 2022-06-16 20:46:59.006914
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release')
    assert read_utf8_file('/usr/lib/os-release')
    assert not read_utf8_file('/etc/os-release-not-exist')

# Generated at 2022-06-16 20:47:03.162213
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release') is not None
    assert read_utf8_file('/usr/lib/os-release') is not None
    assert read_utf8_file('/etc/os-release-not-exist') is None

# Generated at 2022-06-16 20:47:05.951870
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == platform.dist()
    assert info['osrelease_content'] == read_utf8_file('/etc/os-release')

# Generated at 2022-06-16 20:47:08.396749
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] is not None

# Generated at 2022-06-16 20:47:11.201410
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == platform.dist()
    assert info['osrelease_content'] == read_utf8_file('/etc/os-release')

# Generated at 2022-06-16 20:47:15.067315
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == platform.dist()
    assert info['osrelease_content'] == read_utf8_file('/etc/os-release')

# Generated at 2022-06-16 20:47:18.386558
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == platform.dist()
    assert info['osrelease_content'] == read_utf8_file('/etc/os-release')

# Generated at 2022-06-16 20:47:22.376197
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release')
    assert read_utf8_file('/usr/lib/os-release')
    assert not read_utf8_file('/etc/os-release-not-exist')

# Generated at 2022-06-16 20:47:24.674897
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None
    assert info['platform_dist_result'] is not None

# Generated at 2022-06-16 20:47:28.174687
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release') is not None
    assert read_utf8_file('/usr/lib/os-release') is not None
    assert read_utf8_file('/etc/os-release.notfound') is None


# Generated at 2022-06-16 20:47:30.247777
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] is not None

# Generated at 2022-06-16 20:47:34.135091
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release')
    assert read_utf8_file('/usr/lib/os-release')
    assert not read_utf8_file('/etc/os-release-not-exist')


# Generated at 2022-06-16 20:47:36.760684
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None
    assert info['platform_dist_result'] is not None

# Generated at 2022-06-16 20:47:39.613458
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == platform.dist()
    assert info['osrelease_content'] == read_utf8_file('/etc/os-release')

# Generated at 2022-06-16 20:47:44.872224
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert isinstance(info, dict)
    assert 'platform_dist_result' in info
    assert 'osrelease_content' in info
    assert isinstance(info['platform_dist_result'], list)
    assert isinstance(info['osrelease_content'], str)

# Generated at 2022-06-16 20:47:50.292200
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release')
    assert read_utf8_file('/usr/lib/os-release')
    assert not read_utf8_file('/etc/os-release-not-exist')


# Generated at 2022-06-16 20:47:51.548174
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:47:53.812358
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:48:05.164042
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release')
    assert read_utf8_file('/usr/lib/os-release')
    assert read_utf8_file('/etc/os-release', 'utf-8')
    assert read_utf8_file('/usr/lib/os-release', 'utf-8')
    assert read_utf8_file('/etc/os-release', 'utf-16')
    assert read_utf8_file('/usr/lib/os-release', 'utf-16')
    assert read_utf8_file('/etc/os-release', 'utf-32')
    assert read_utf8_file('/usr/lib/os-release', 'utf-32')
    assert read_utf8_file('/etc/os-release', 'utf-64')
    assert read

# Generated at 2022-06-16 20:48:08.180641
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == platform.dist()
    assert info['osrelease_content'] == read_utf8_file('/etc/os-release')

# Generated at 2022-06-16 20:48:10.126646
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:48:12.914343
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:48:17.461479
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None
    assert info['platform_dist_result'] is not None

# Generated at 2022-06-16 20:48:19.173964
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == platform.dist()

# Generated at 2022-06-16 20:48:21.880235
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert isinstance(info, dict)
    assert isinstance(info['platform_dist_result'], list)
    assert isinstance(info['osrelease_content'], str)

# Generated at 2022-06-16 20:48:26.735590
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:48:30.654564
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release')
    assert read_utf8_file('/usr/lib/os-release')
    assert not read_utf8_file('/etc/os-release-not-exist')

# Generated at 2022-06-16 20:48:34.337284
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == platform.dist()
    assert info['osrelease_content'] == read_utf8_file('/etc/os-release')

# Generated at 2022-06-16 20:48:36.578730
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None
    assert info['platform_dist_result'] is not None

# Generated at 2022-06-16 20:48:38.781386
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] is not None

# Generated at 2022-06-16 20:48:43.817362
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == platform.dist()
    assert info['osrelease_content'] == read_utf8_file('/etc/os-release')

# Generated at 2022-06-16 20:48:45.883499
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:48:47.848237
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] is not None

# Generated at 2022-06-16 20:48:50.070002
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None
    assert info['platform_dist_result'] is not None

# Generated at 2022-06-16 20:48:53.463459
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release')
    assert read_utf8_file('/usr/lib/os-release')
    assert not read_utf8_file('/etc/os-release-not-exist')

# Generated at 2022-06-16 20:48:59.201293
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == platform.dist()
    assert info['osrelease_content'] == read_utf8_file('/etc/os-release')

# Generated at 2022-06-16 20:49:00.853481
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] is not None

# Generated at 2022-06-16 20:49:03.864246
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:49:06.184911
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()

    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:49:10.174018
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:49:12.439341
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] is not None

# Generated at 2022-06-16 20:49:14.441954
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:49:17.991887
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release') is not None
    assert read_utf8_file('/usr/lib/os-release') is not None
    assert read_utf8_file('/etc/os-release-not-exist') is None

# Generated at 2022-06-16 20:49:20.519092
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()

    assert info['platform_dist_result'] == platform.dist()
    assert info['osrelease_content'] == read_utf8_file('/etc/os-release')

# Generated at 2022-06-16 20:49:22.498248
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:49:25.778049
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:49:29.136338
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None
    assert info['platform_dist_result'] is not None

# Generated at 2022-06-16 20:49:31.886381
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] is not None

# Generated at 2022-06-16 20:49:34.747705
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None
    assert info['platform_dist_result'] is not None

# Generated at 2022-06-16 20:49:37.114460
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None
    assert info['platform_dist_result'] is not None

# Generated at 2022-06-16 20:49:40.067550
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:49:41.213769
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:49:45.386505
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release')
    assert read_utf8_file('/usr/lib/os-release')
    assert not read_utf8_file('/etc/os-release-not-exists')


# Generated at 2022-06-16 20:49:47.773183
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None
    assert info['platform_dist_result'] is not None

# Generated at 2022-06-16 20:49:50.275426
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None
    assert info['platform_dist_result'] is not None

# Generated at 2022-06-16 20:49:53.402865
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None

# Generated at 2022-06-16 20:49:56.337287
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:49:58.522673
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()

    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] is not None

# Generated at 2022-06-16 20:50:00.370875
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:50:02.940146
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:50:06.095857
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] is not None

# Generated at 2022-06-16 20:50:08.009741
# Unit test for function get_platform_info
def test_get_platform_info():
    assert get_platform_info() == {'osrelease_content': None, 'platform_dist_result': []}

# Generated at 2022-06-16 20:50:10.647716
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None
    assert info['platform_dist_result'] is not None

# Generated at 2022-06-16 20:50:13.266350
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None
    assert info['platform_dist_result'] is not None

# Generated at 2022-06-16 20:50:15.778935
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] is not None

# Generated at 2022-06-16 20:50:19.773177
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None

# Generated at 2022-06-16 20:50:23.975938
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release')
    assert read_utf8_file('/usr/lib/os-release')
    assert not read_utf8_file('/etc/os-release-not-exist')

# Generated at 2022-06-16 20:50:27.249697
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:50:30.073291
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:50:31.879445
# Unit test for function get_platform_info
def test_get_platform_info():
    assert get_platform_info() == {'platform_dist_result': [], 'osrelease_content': None}

# Generated at 2022-06-16 20:50:33.805570
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:50:38.195052
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:50:39.706584
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None

# Generated at 2022-06-16 20:50:42.608146
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()

    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:50:44.619334
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:50:49.032704
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] is not None

# Generated at 2022-06-16 20:50:51.748725
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()

    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] is not None

# Generated at 2022-06-16 20:50:53.874599
# Unit test for function get_platform_info
def test_get_platform_info():
    assert get_platform_info() == {'platform_dist_result': [], 'osrelease_content': None}

# Generated at 2022-06-16 20:50:56.497163
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == platform.dist()
    assert info['osrelease_content'] == read_utf8_file('/etc/os-release')

# Generated at 2022-06-16 20:51:01.191330
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:51:03.080743
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:51:05.834798
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release')
    assert read_utf8_file('/usr/lib/os-release')
    assert not read_utf8_file('/etc/os-release-not-exist')

# Generated at 2022-06-16 20:51:07.401103
# Unit test for function get_platform_info
def test_get_platform_info():
    assert get_platform_info() == {'platform_dist_result': [], 'osrelease_content': None}

# Generated at 2022-06-16 20:51:08.826618
# Unit test for function get_platform_info
def test_get_platform_info():
    assert get_platform_info() == {'platform_dist_result': [], 'osrelease_content': None}

# Generated at 2022-06-16 20:51:10.208282
# Unit test for function get_platform_info
def test_get_platform_info():
    assert get_platform_info() == {'platform_dist_result': [], 'osrelease_content': None}

# Generated at 2022-06-16 20:51:15.974931
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:51:18.722117
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None
    assert info['platform_dist_result'] is not None

# Generated at 2022-06-16 20:51:20.644918
# Unit test for function get_platform_info
def test_get_platform_info():
    assert get_platform_info() == {'platform_dist_result': [], 'osrelease_content': None}

# Generated at 2022-06-16 20:51:39.286382
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()

    assert info['platform_dist_result'] == platform.dist()
    assert info['osrelease_content'] == read_utf8_file('/etc/os-release') or read_utf8_file('/usr/lib/os-release')

# Generated at 2022-06-16 20:51:42.089171
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:51:43.856340
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None
    assert info['platform_dist_result'] is not None

# Generated at 2022-06-16 20:51:47.314044
# Unit test for function get_platform_info
def test_get_platform_info():
    assert get_platform_info() == {'platform_dist_result': [], 'osrelease_content': None}

# Generated at 2022-06-16 20:51:51.245720
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release') is not None
    assert read_utf8_file('/usr/lib/os-release') is not None
    assert read_utf8_file('/etc/os-release-not-exist') is None

# Generated at 2022-06-16 20:51:53.183359
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:51:55.548724
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] is not None

# Generated at 2022-06-16 20:52:08.571909
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release') == read_utf8_file('/etc/os-release')
    assert read_utf8_file('/etc/os-release') != read_utf8_file('/etc/passwd')
    assert read_utf8_file('/etc/os-release') != read_utf8_file('/etc/os-release', 'utf-16')
    assert read_utf8_file('/etc/os-release') != read_utf8_file('/etc/os-release', 'utf-32')
    assert read_utf8_file('/etc/os-release') != read_utf8_file('/etc/os-release', 'utf-8')

# Generated at 2022-06-16 20:52:10.433503
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] is not None

# Generated at 2022-06-16 20:52:15.142645
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release') is not None
    assert read_utf8_file('/usr/lib/os-release') is not None
    assert read_utf8_file('/etc/os-release-not-exist') is None


# Generated at 2022-06-16 20:52:17.378705
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:52:19.856862
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == platform.dist()
    assert info['osrelease_content'] == read_utf8_file('/etc/os-release')

# Generated at 2022-06-16 20:52:21.836997
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:52:25.511031
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release') is not None
    assert read_utf8_file('/usr/lib/os-release') is not None
    assert read_utf8_file('/etc/os-release-not-exist') is None

# Generated at 2022-06-16 20:52:27.494591
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()

    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:52:30.062024
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:52:31.989813
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:52:38.512246
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] is not None

# Generated at 2022-06-16 20:52:39.485337
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:52:51.388965
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release')
    assert read_utf8_file('/usr/lib/os-release')
    assert read_utf8_file('/etc/os-release', 'utf-8')
    assert read_utf8_file('/usr/lib/os-release', 'utf-8')
    assert read_utf8_file('/etc/os-release', 'utf-8')
    assert read_utf8_file('/usr/lib/os-release', 'utf-8')
    assert read_utf8_file('/etc/os-release', 'utf-8')
    assert read_utf8_file('/usr/lib/os-release', 'utf-8')
    assert read_utf8_file('/etc/os-release', 'utf-8')
    assert read

# Generated at 2022-06-16 20:52:53.353937
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:52:58.194671
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] is not None

# Generated at 2022-06-16 20:53:02.273291
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert isinstance(info, dict)
    assert 'platform_dist_result' in info
    assert isinstance(info['platform_dist_result'], list)
    assert 'osrelease_content' in info
    assert isinstance(info['osrelease_content'], str)

# Generated at 2022-06-16 20:53:05.665206
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:53:08.030574
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content']
    assert info['platform_dist_result']

# Generated at 2022-06-16 20:53:10.879137
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None
    assert info['platform_dist_result'] is not None

# Generated at 2022-06-16 20:53:12.702953
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None
    assert info['platform_dist_result'] is not None

# Generated at 2022-06-16 20:53:20.963842
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] != None

# Generated at 2022-06-16 20:53:22.850389
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None
    assert info['platform_dist_result'] is not None

# Generated at 2022-06-16 20:53:26.065652
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] is not None

# Generated at 2022-06-16 20:53:29.618245
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release') is not None
    assert read_utf8_file('/usr/lib/os-release') is not None
    assert read_utf8_file('/etc/os-release-not-exist') is None

# Generated at 2022-06-16 20:53:32.449268
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == platform.dist()
    assert info['osrelease_content'] == read_utf8_file('/etc/os-release')

# Generated at 2022-06-16 20:53:34.981753
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:53:37.949679
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:53:41.233172
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == platform.dist()
    assert info['osrelease_content'] == read_utf8_file('/etc/os-release')

# Generated at 2022-06-16 20:53:43.390797
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:53:45.413474
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None

# Generated at 2022-06-16 20:53:59.162291
# Unit test for function get_platform_info
def test_get_platform_info():
    assert get_platform_info() == {'platform_dist_result': [], 'osrelease_content': None}

# Generated at 2022-06-16 20:54:03.795592
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release') is not None
    assert read_utf8_file('/usr/lib/os-release') is not None
    assert read_utf8_file('/etc/os-release-not-exists') is None