

# Generated at 2022-06-22 19:41:06.638297
# Unit test for function get_platform_info
def test_get_platform_info():
    # Test if the distro is detected correctly
    test_info = get_platform_info()

    if test_info['platform_dist_result']:
        assert test_info['platform_dist_result'][0] in ['centos', 'ubuntu', 'debian']
    elif test_info['osrelease_content']:
        assert test_info['osrelease_content'].split('\n')[0] in ['NAME="CentOS Linux"', 'NAME="Ubuntu"', 'NAME="Debian GNU/Linux"']
    else:
        assert False

# Generated at 2022-06-22 19:41:08.829074
# Unit test for function read_utf8_file
def test_read_utf8_file():
    test_content = read_utf8_file('test.txt')
    assert test_content == 'This is a test'

# Generated at 2022-06-22 19:41:11.911977
# Unit test for function read_utf8_file
def test_read_utf8_file():
    tst_file = "tst_file.txt"
    tst_content = "test test test"
    with open(tst_file, mode="w") as fd:
        fd.write(tst_content)

    assert read_utf8_file(tst_file) == tst_content

# Generated at 2022-06-22 19:41:14.185456
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert type(info) is dict
    assert len(info['platform_dist_result']) == 3

# Generated at 2022-06-22 19:41:15.810733
# Unit test for function main
def test_main():
    """
    Test main()

    :return: None
    """
    main()

# Generated at 2022-06-22 19:41:20.770752
# Unit test for function get_platform_info
def test_get_platform_info():
    result = get_platform_info()
    if os.path.exists('/etc/os-release'):
        assert result['osrelease_content'].startswith('NAME=')
    else:
        assert result['osrelease_content'] is None

    if hasattr(platform, 'dist'):
        assert result['platform_dist_result'][0]

# Generated at 2022-06-22 19:41:24.025478
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    
    assert info['platform_dist_result'] == []
    assert info['osrelease_content'] == None


# Generated at 2022-06-22 19:41:34.589899
# Unit test for function get_platform_info

# Generated at 2022-06-22 19:41:39.869517
# Unit test for function get_platform_info
def test_get_platform_info():
    INFO = get_platform_info()

    ETC_OS_RELEASE = read_utf8_file('/etc/os-release')
    if not ETC_OS_RELEASE:
        ETC_OS_RELEASE = read_utf8_file('/usr/lib/os-release')

    assert INFO['osrelease_content'] == ETC_OS_RELEASE

# Generated at 2022-06-22 19:41:45.235246
# Unit test for function main
def test_main():
    assert json.loads(main())['platform_dist_result'][0] == platform.dist()[0]
    assert json.loads(main())['platform_dist_result'][1] == platform.dist()[1]
    assert json.loads(main())['platform_dist_result'][2] == platform.dist()[2]
    assert json.loads(main())['osrelease_content']

# Generated at 2022-06-22 19:41:55.133277
# Unit test for function main
def test_main():
    try:
        from io import StringIO
    except ImportError:
        from StringIO import StringIO

    import sys
    import platform

    osrelease_content = '''
NAME="Ubuntu"
VERSION="16.04.5 LTS (Xenial Xerus)"
ID=ubuntu
ID_LIKE=debian
PRETTY_NAME="Ubuntu 16.04.5 LTS"
VERSION_ID="16.04"
HOME_URL="http://www.ubuntu.com/"
SUPPORT_URL="http://help.ubuntu.com/"
BUG_REPORT_URL="http://bugs.launchpad.net/ubuntu/"
VERSION_CODENAME=xenial
UBUNTU_CODENAME=xenial
'''

    osrelease_content = osrelease_content.lstrip()


# Generated at 2022-06-22 19:41:57.908500
# Unit test for function get_platform_info
def test_get_platform_info():
    assert get_platform_info()['platform_dist_result'] == []

# Generated at 2022-06-22 19:41:58.491457
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-22 19:41:59.854650
# Unit test for function get_platform_info
def test_get_platform_info():

    info = get_platform_info()
    print(info)


# Generated at 2022-06-22 19:42:06.201914
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] == 'NAME="Ubuntu"\nVERSION="14.04.5 LTS, Trusty Tahr"\nID=ubuntu\nID_LIKE=debian\nPRETTY_NAME="Ubuntu 14.04.5 LTS"\nVERSION_ID="14.04"\nHOME_URL="http://www.ubuntu.com/"\nSUPPORT_URL="http://help.ubuntu.com/"\nBUG_REPORT_URL="http://bugs.launchpad.net/ubuntu/"\n', "Unexpected osrelease content."

# Generated at 2022-06-22 19:42:07.581665
# Unit test for function main
def test_main():
    info = main()
    info = json.loads(info)
    assert 'platform_dist_result' or 'osrelease_content' in info.keys()

# Generated at 2022-06-22 19:42:17.596101
# Unit test for function main
def test_main():
    class FakePopen():
        def communicate(self):
            return ['Ubuntu\n', '']

    class FakePopen2():
        def communicate(self):
            return ['', '']

    class FakePopen3():
        def communicate(self):
            return ['Ubuntu\n', '']

    class FakePopen4():
        def communicate(self):
            return ['', '']

    class FakePopen5():
        def communicate(self):
            return ['Ubuntu\n', '']

    class FakePopen6():
        def communicate(self):
            return ['', '']

    class FakePopen7():
        def communicate(self):
            return ['16.04\n', '']

    class FakePopen8():
        def communicate(self):
            return ['', '']


# Generated at 2022-06-22 19:42:22.519075
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert not read_utf8_file(test_read_utf8_file.__name__)
    assert read_utf8_file('/dev/null') == ''
    assert read_utf8_file('/dev/zero') != ''

# Generated at 2022-06-22 19:42:28.474524
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content']

# Generated at 2022-06-22 19:42:36.821281
# Unit test for function main
def test_main():
    import json
    import sys
    import tempfile

    if sys.version_info[0] == 2:
        import ConfigParser as configparser
    elif sys.version_info[0] == 3:
        import configparser

    def test_main():
        with tempfile.NamedTemporaryFile(mode='w', delete=False) as osrelease_file:
            osrelease_file.write('ID=centos')

# Generated at 2022-06-22 19:42:44.876591
# Unit test for function get_platform_info
def test_get_platform_info():
    import subprocess

    results = subprocess.check_output(['python', '-m', 'ansible.module_utils.common.distro']).strip()
    assert results

    # test that module works when read_utf8_file can not read a file
    import mock
    import ansible.module_utils.common.distro as distro

    for filename in ['/etc/os-release', '/usr/lib/os-release']:
        with mock.patch('ansible.module_utils.common.distro.read_utf8_file', return_value=None):
            assert distro.get_platform_info()['osrelease_content'] is None

# Generated at 2022-06-22 19:42:50.099702
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()

    assert info is not None
    assert 'osrelease_content' in info
    assert 'platform_dist_result' in info
    assert info['osrelease_content'] is not None
    assert 'ID' in info['osrelease_content']
    assert 'VERSION_ID' in info['osrelease_content']