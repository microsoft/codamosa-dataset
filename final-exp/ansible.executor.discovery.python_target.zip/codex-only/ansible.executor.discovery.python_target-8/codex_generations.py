

# Generated at 2022-06-22 19:41:03.452285
# Unit test for function main
def test_main():
    import __main__
    import json
    import re

    (fd, filename) = tempfile.mkstemp()

# Generated at 2022-06-22 19:41:07.308576
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['osrelease_content'] is not None
    assert info['platform_dist_result'] is not None

# Generated at 2022-06-22 19:41:13.669628
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    # simple test to show args at the end:
    # ./hacking/test-module -m lib/ansible/module_utils/facts/system/distribution.py -a "filter=ansible_distribution*"

    module = AnsibleModule(argument_spec=dict())
    res = get_platform_info()

    assert 'platform_dist_result' in res
    assert 'osrelease_content' in res

    module.exit_json(changed=False, ansible_facts=res)

# Generated at 2022-06-22 19:41:17.921882
# Unit test for function read_utf8_file
def test_read_utf8_file():
    import tempfile
    (fd, path) = tempfile.mkstemp()
    with os.fdopen(fd, "w") as f:
        f.write("test\n")
    result = read_utf8_file(path)
    os.remove(path)

    assert result == "test\n"

# Generated at 2022-06-22 19:41:19.665891
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 19:41:23.230058
# Unit test for function read_utf8_file
def test_read_utf8_file():
    # Assert that file exists
    assert read_utf8_file('/etc/os-release') is not None
    # Assert that file does not exist
    assert read_utf8_file('not_exists') is None

# Generated at 2022-06-22 19:41:33.878657
# Unit test for function main
def test_main():
    import json
    import sys

    # Setup temporary environment

# Generated at 2022-06-22 19:41:35.801897
# Unit test for function get_platform_info
def test_get_platform_info():
    assert get_platform_info() == json.load(open('platform_info_mock_output.json'))

# Generated at 2022-06-22 19:41:46.135601
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    main()

    result = module.from_json(module.params['_ansible_remote_tmp'])

# Generated at 2022-06-22 19:41:55.475846
# Unit test for function get_platform_info
def test_get_platform_info():
    # The test_get_platform_info can only be executed on a Linux machine.
    # Because if the platform is Darwin or Windows, we will get the empty content.
    if platform.system().lower() != 'linux':
        return

    result = get_platform_info()
    # Assert the result is not empty.
    assert result

    # Assert the format of the result.
    keys = ['platform_dist_result', 'osrelease_content']
    for key in keys:
        assert key in result

    # Assert the values are not empty.
    for key in keys:
        assert result[key] is not None

    # Assert the os release content is not empty
    assert 'ansible_os_family' in result['osrelease_content']

# Generated at 2022-06-22 19:42:02.990549
# Unit test for function read_utf8_file
def test_read_utf8_file():
    # read_utf8_file should read a file in utf-8 and return unicode
    assert isinstance(read_utf8_file('/etc/os-release'), unicode)
    # read_utf8_file should return None if the file is not readable
    assert read_utf8_file('/') is None
    # read_utf8_file should read a file in utf-8 and return unicode
    assert isinstance(read_utf8_file('/etc/os-release', encoding='UTF-8'), unicode)

# Generated at 2022-06-22 19:42:04.480684
# Unit test for function main
def test_main():
    res = main()
    # We cannot rely on the content of the results, output format only
    assert '{' in res

# Generated at 2022-06-22 19:42:06.135106
# Unit test for function get_platform_info
def test_get_platform_info():
    result = get_platform_info()
    assert result['platform_dist_result'] == []
    assert result['osrelease_content'] == ""

# Generated at 2022-06-22 19:42:14.661185
# Unit test for function get_platform_info
def test_get_platform_info():
    assert(get_platform_info() == {'osrelease_content': 'NAME="Amazon Linux AMI"\nVERSION="2018.03"\nID="amzn"\nID_LIKE="rhel fedora"\nVERSION_ID="2018.03"\nPRETTY_NAME="Amazon Linux AMI 2018.03"\nANSI_COLOR="0;33"\nCPE_NAME="cpe:/o:amazon:linux:2018.03:ga"\nHOME_URL="http://aws.amazon.com/amazon-linux-ami/"\n\n', 'platform_dist_result': []})

# Generated at 2022-06-22 19:42:16.984651
# Unit test for function get_platform_info
def test_get_platform_info():
    pfinfo = get_platform_info()
    assert isinstance(pfinfo, dict)
    assert pfinfo['platform_dist_result']

# Generated at 2022-06-22 19:42:20.373768
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('non_existent') is None
    a = read_utf8_file('/proc/cpuinfo')
    assert isinstance(a, str)
    assert a
    assert a.strip()
    assert a[0] == 'v'

# Generated at 2022-06-22 19:42:29.223329
# Unit test for function read_utf8_file
def test_read_utf8_file():
    # Test case 1: input path is None
    assert read_utf8_file(None) is None

    # Test case 2: input path is empty
    assert read_utf8_file('') is None

    # Test case 3: input path is not a file
    assert read_utf8_file('/tmp') is None

    # Test case 4: input path is a file, but not readable
    path = '/etc/passwd'
    os.chmod(path, 0)
    assert read_utf8_file(path) is None
    os.chmod(path, 0o644)

    # Test case 5: input path is a file and readable
    assert read_utf8_file(path) is not None

# Generated at 2022-06-22 19:42:34.432913
# Unit test for function read_utf8_file
def test_read_utf8_file():
    test_str = "Unable to read file"
    assert read_utf8_file("/test") == None
    assert read_utf8_file("test/test.txt", "utf-8") == test_str
    assert read_utf8_file("test/test_unsupported_utf8_encoding.txt") == test_str.encode("utf-8")

# Generated at 2022-06-22 19:42:37.792801
# Unit test for function get_platform_info
def test_get_platform_info():
    assert get_platform_info() == {'platform_dist_result': (), 'osrelease_content': ''}, \
        'Function get_platform_info failed'

# Generated at 2022-06-22 19:42:39.287636
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release')

# Generated at 2022-06-22 19:42:48.213197
# Unit test for function read_utf8_file
def test_read_utf8_file():
    info = 'test_read_utf8_file'

    if os.path.exists('test_utf8'):
        os.remove('test_utf8')

    # Test of read empty line
    with open('test_utf8', 'w') as f:
        f.write('')
    assert read_utf8_file('test_utf8') is None
    os.remove('test_utf8')

    # Test of utf8
    with open('test_utf8', 'w') as f:
        f.write(u'Hello World!')
    assert read_utf8_file('test_utf8') == info
    os.remove('test_utf8')

# Generated at 2022-06-22 19:42:53.844156
# Unit test for function read_utf8_file
def test_read_utf8_file():
    with open('test_read_utf8_file.txt', 'w') as fd:
        fd.write('HELLO, WORLD')
    res = read_utf8_file('test_read_utf8_file.txt')
    assert res == 'HELLO, WORLD'



# Generated at 2022-06-22 19:42:55.372060
# Unit test for function get_platform_info
def test_get_platform_info():
    # Test for get_platform_info function
    assert get_platform_info()

# Generated at 2022-06-22 19:43:03.455715
# Unit test for function get_platform_info
def test_get_platform_info():
    # Test default return
    result = dict(platform_dist_result=[])
    osrelease_content = None
    assert result == get_platform_info()
    assert osrelease_content == read_utf8_file('/etc/os-release')
    assert osrelease_content == read_utf8_file('/usr/lib/os-release')

    # Test return with /etc/os-release
    osrelease_content = read_utf8_file('../../test/files/os-release/fedora29')
    assert osrelease_content == read_utf8_file('/etc/os-release')

# Generated at 2022-06-22 19:43:07.945913
# Unit test for function get_platform_info
def test_get_platform_info():
    platform_dist_result = platform.dist()
    osrelease_content = read_utf8_file('/etc/os-release')
    test_info = dict(platform_dist_result=platform_dist_result,
                     osrelease_content=osrelease_content)
    assert get_platform_info() == test_info

# Generated at 2022-06-22 19:43:17.264725
# Unit test for function read_utf8_file
def test_read_utf8_file():
  from distro import get_distro
  from distro import linux_distribution as distro
  safe_distro = get_distro(True)
  distro = linux_distribution(False)
  distro = linux_distribution(True)
  distro = linux_distribution(False, False)
  distro = linux_distribution(True, False)
  distro = linux_distribution(False, True)
  distro = linux_distribution(True, True)
  distro = linux_distribution()
  #TODO: this could be swapped out for our bundled version of distro to move more complete platform
  # logic to the targets, so long as we maintain Py2.6 compat and don't need to do any kind of script assembly

# Generated at 2022-06-22 19:43:20.842382
# Unit test for function main
def test_main():
    info = get_platform_info()

    assert isinstance(info['osrelease_content'], str) is True

# Generated at 2022-06-22 19:43:22.642344
# Unit test for function main
def test_main():
    info = get_platform_info()
    print(json.dumps(info))

# Generated at 2022-06-22 19:43:31.743403
# Unit test for function read_utf8_file
def test_read_utf8_file():
    # This test is here to assert that read_utf8_file reads a file as expected and returns the content.
    # We can't test this function directly because it's defined in the __init__.py for this directory,
    # and the unit test is expecting a module called 'platform' to not be there. If we import the
    # __init__.py or the package, we get a circular import error.
    temp_file = tempfile.NamedTemporaryFile(prefix='ansible_test_platform_')
    example_content = "some random text\n\n"
    temp_file.write(example_content.encode('utf-8'))
    temp_file.flush()

    assert read_utf8_file(temp_file.name) == example_content


# Generated at 2022-06-22 19:43:34.779308
# Unit test for function main
def test_main():
    print("Unit test for function main")
    expected_result = dict(
        platform_dist_result=[
            '',
            '',
            '',
        ],
        osrelease_content=''
    )
    actual_result = main()
    assert actual_result == expected_result

# Generated at 2022-06-22 19:43:40.267305
# Unit test for function get_platform_info
def test_get_platform_info():
    distribution, version, id_ = platform.dist()
    assert get_platform_info()['platform_dist_result'] == list([distribution, version, id_])

    osrelease_content = read_utf8_file('/etc/os-release')
    assert get_platform_info()['osrelease_content'] == osrelease_content

# Generated at 2022-06-22 19:43:46.751191
# Unit test for function main
def test_main():
    # Mock /etc/os-release file to provide a test
    test_content = '''NAME="Ubuntu"
VERSION="18.04.2 LTS (Bionic Beaver)"
ID=ubuntu
ID_LIKE=debian
PRETTY_NAME="Ubuntu 18.04.2 LTS"
VERSION_ID="18.04"
HOME_URL="https://www.ubuntu.com/"
SUPPORT_URL="https://help.ubuntu.com/"
BUG_REPORT_URL="https://bugs.launchpad.net/ubuntu/"
PRIVACY_POLICY_URL="https://www.ubuntu.com/legal/terms-and-policies/privacy-policy"
VERSION_CODENAME=bionic
UBUNTU_CODENAME=bionic'''

# Generated at 2022-06-22 19:43:50.789017
# Unit test for function read_utf8_file
def test_read_utf8_file():
    # Test for normal usage
    content = read_utf8_file('/etc/os-release')
    assert content is not None
    # Test for file not exist
    content = read_utf8_file('/etc/os-release-not-exist')
    assert content is None

# Generated at 2022-06-22 19:43:55.025762
# Unit test for function get_platform_info
def test_get_platform_info():
    file_name_path = 'test_platform.py'


# Generated at 2022-06-22 19:43:56.993157
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/this/file/does/not/exist') is None


# Generated at 2022-06-22 19:44:04.608539
# Unit test for function read_utf8_file
def test_read_utf8_file():
    std = 'hello world'
    # Test 1 - check a file that does exist will return correct results
    f = io.open('tests/linux.txt', 'r', encoding='utf-8')
    f.write(std)
    f.close()
    assert read_utf8_file('tests/linux.txt', encoding='utf-8') == std
    # Test 2 - check a file that doesn't exist will return None
    assert read_utf8_file('tests/linux.txt2', encoding='utf-8') is None

# Generated at 2022-06-22 19:44:08.665744
# Unit test for function read_utf8_file
def test_read_utf8_file():
    # Testing function when file does exist
    assert read_utf8_file('/etc/os-release') is not None
    # Testing function when file does not exist
    assert read_utf8_file('/tmp/doesnotexistfile') is None

# Generated at 2022-06-22 19:44:14.718562
# Unit test for function main
def test_main():
    import sys
    import tempfile
    info = get_platform_info()
    with tempfile.TemporaryFile() as output:
        sys.stdout = output
        main()
        output.seek(0)
        assert output.read() == ('{"platform_dist_result": %s, "osrelease_content": "%s"}' %
            (info['platform_dist_result'], info['osrelease_content'])).encode()

# Generated at 2022-06-22 19:44:15.651523
# Unit test for function main
def test_main():
    assert main() == 'get_platform_info()'

# Generated at 2022-06-22 19:44:23.000841
# Unit test for function read_utf8_file
def test_read_utf8_file():
    import tempfile
    import shutil
    import os

    # Create test temp dir
    tempdir = tempfile.mkdtemp()
    filename = os.path.join(tempdir, "file.txt")

    # Test wrong file name
    assert read_utf8_file(os.path.join(tempdir, "A")) is None

    # Test read
    with io.open(filename, 'w', encoding='utf-8') as fd:
        fd.write(u"test")
    assert read_utf8_file(filename) == u"test"

    shutil.rmtree(tempdir)

# Generated at 2022-06-22 19:44:23.988609
# Unit test for function get_platform_info
def test_get_platform_info():
    assert isinstance(get_platform_info(), dict)

# Generated at 2022-06-22 19:44:28.058677
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert isinstance(info,dict)
    info = info['platform_dist_result']
    assert isinstance(info, list)
    for i in info:
        assert isinstance(i,str)



# Generated at 2022-06-22 19:44:30.055866
# Unit test for function main
def test_main():
    test_info = get_platform_info()
    assert test_info is not None

# Generated at 2022-06-22 19:44:36.968896
# Unit test for function read_utf8_file
def test_read_utf8_file():
    osrelease_content = read_utf8_file('/etc/os-release')
    # try to fall back to /usr/lib/os-release
    if not osrelease_content:
        osrelease_content = read_utf8_file('/usr/lib/os-release')
    assert osrelease_content is not None
    assert osrelease_content.find("REDHAT_SUPPORT_PRODUCT") != -1


# Generated at 2022-06-22 19:44:38.132217
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/motd')

# Generated at 2022-06-22 19:44:39.140033
# Unit test for function main
def test_main():
    retval = main()
    assert retval == None

# Generated at 2022-06-22 19:44:40.425116
# Unit test for function get_platform_info
def test_get_platform_info():
    assert len(get_platform_info()) == 2

# Generated at 2022-06-22 19:44:50.632125
# Unit test for function main

# Generated at 2022-06-22 19:44:56.084481
# Unit test for function read_utf8_file
def test_read_utf8_file():
    with mock.patch('os.access', side_effect=True):
        mock_file_content = "HelloWorld"
        with mock.patch('io.open', mock.mock_open(read_data=mock_file_content)):
            file_content = read_utf8_file("test.txt")
            assert(file_content == mock_file_content)

# Generated at 2022-06-22 19:44:59.999630
# Unit test for function read_utf8_file
def test_read_utf8_file():
    # read a UTF-8 file
    utf8_file = read_utf8_file('/usr/share/ansible/ansible/module_utils/facts/__init__.py')
    assert utf8_file is not None

# Generated at 2022-06-22 19:45:01.532471
# Unit test for function get_platform_info
def test_get_platform_info():
    result = get_platform_info()
    assert result['osrelease_content']

# Generated at 2022-06-22 19:45:03.741652
# Unit test for function read_utf8_file
def test_read_utf8_file():
    # invalid path
    assert read_utf8_file(None) is None

    # valid path
    assert read_utf8_file(__file__)



# Generated at 2022-06-22 19:45:06.146931
# Unit test for function get_platform_info
def test_get_platform_info():
    assert get_platform_info()
    assert get_platform_info() == {'osrelease_content': None, 'platform_dist_result': []}

# Generated at 2022-06-22 19:45:10.741165
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()

    if os.path.isfile('/etc/os-release'):
        assert isinstance(info['osrelease_content'], str)
    elif os.path.isfile('/usr/lib/os-release'):
        assert isinstance(info['osrelease_content'], str)
    else:
        assert info['osrelease_content'] is None

    if hasattr(platform, 'dist'):
        assert isinstance(info['platform_dist_result'], tuple)

# Generated at 2022-06-22 19:45:18.209564
# Unit test for function get_platform_info
def test_get_platform_info():
    test_platform_dist_result = ('redhat\n', '7.7\n', 'Core\n')

# Generated at 2022-06-22 19:45:19.108493
# Unit test for function get_platform_info
def test_get_platform_info():
    assert isinstance(get_platform_info(), dict)

# Generated at 2022-06-22 19:45:21.159301
# Unit test for function main
def test_main():
    info = main()
    assert 'platform_dist_result' in info.keys()
    assert 'osrelease_content' in info.keys()

# Generated at 2022-06-22 19:45:28.796006
# Unit test for function get_platform_info
def test_get_platform_info():
    try:
        path = os.path.join(os.path.dirname(__file__), '../../lib/ansible/module_utils/facts/system/osrelease.py')
        os.symlink(path, 'module_utils/facts/system/osrelease.py')
    except Exception:
        pass

    try:
        import module_utils.facts.system.osrelease as osrelease
    except Exception:
        # Assume it is ready for Python 3 and the file is symlinked.
        pass

    info = get_platform_info()
    info2 = dict(platform_dist_result=('Fedora', '26', 'Twenty Six'))
    osrelease_content = 'NAME="Fedora"\nVERSION="26 (Twenty Six)"'
    info2['osrelease_content'] = osrelease_content



# Generated at 2022-06-22 19:45:29.334189
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 19:45:34.647460
# Unit test for function read_utf8_file
def test_read_utf8_file():
    content = read_utf8_file('/etc/issue')
    assert isinstance(content, str)
    assert len(content) > 0
    assert content.endswith('\n')

    content = read_utf8_file('/etc/os-release')
    assert isinstance(content, str)
    assert len(content) > 0
    assert content.endswith('\n')

# Generated at 2022-06-22 19:45:39.253267
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert isinstance(info, dict)
    assert info.get('platform_dist_result') != [], 'platform.dist() does not return empty list'
    assert info.get('osrelease_content'), 'os-release file is empty!'

# Generated at 2022-06-22 19:45:48.389488
# Unit test for function main
def test_main():
    # Check when platform_dist_result is non-empty
    import platform
    import copy
    with patch('ansible_collections.ansible.os_hardening.plugins.module_utils.facts.platform.dist', new=lambda: ('Ubuntu', '16.04', 'xenial')):
        assert(main() == json.dumps({'platform_dist_result': ['Ubuntu', '16.04', 'xenial'], 'osrelease_content': None}))

    # Check when platform_dist_result is empty

# Generated at 2022-06-22 19:45:51.304433
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release')
    assert read_utf8_file('/usr/lib/os-release')

# Generated at 2022-06-22 19:45:58.686952
# Unit test for function main
def test_main():
    content = main()
    assert isinstance(content, str)
    content_dict = json.loads(content)
    assert isinstance(content_dict, dict)
    assert 'osrelease_content' in content_dict
    assert 'platform_dist_result' in content_dict
    assert 'os_name' in content_dict
    assert 'os_family' in content_dict
    assert 'dist' in content_dict
    assert 'os_major_version' in content_dict
    assert 'os_minor_version' in content_dict

# Generated at 2022-06-22 19:46:09.837539
# Unit test for function get_platform_info

# Generated at 2022-06-22 19:46:14.438808
# Unit test for function read_utf8_file
def test_read_utf8_file():
    expected = ''
    read_utf8_file_return = read_utf8_file('/etc/os-release')

    assert read_utf8_file_return == expected


# Generated at 2022-06-22 19:46:21.571974
# Unit test for function get_platform_info
def test_get_platform_info():
    import json
    import platform
    import os
    import get_platform_info

    os.path.isfile = lambda path: path == '/etc/os-release'
    with open('/etc/os-release', 'w') as fd:
        fd.write('NAME="foo"\nVERSION="bar"')

    info = get_platform_info.get_platform_info()

    if hasattr(platform, 'dist'):
        assert info['platform_dist_result'] == platform.dist()

    assert info['osrelease_content'] == 'NAME="foo"\nVERSION="bar"'



# Generated at 2022-06-22 19:46:32.816048
# Unit test for function main
def test_main():
    class mock_platform:
        def __init__(self):
            self.dist_result = ('Arch', '10', 'Testing')

        def dist(self):
            return self.dist_result

    class mock_os_release_file:
        def __init__(self):
            self.content = None

        def __call__(self, path, encoding='utf-8'):
            return self.content

    with mock.patch.object(platform, 'dist', new_callable=mock_platform):
        with mock.patch.object(os, 'access', return_value=True):
            with mock.patch.object(io, 'open', new_callable=mock_os_release_file):
                # no misc files, dist
                os_release_file.content = None
                info = get_platform_info()

# Generated at 2022-06-22 19:46:37.867206
# Unit test for function main
def test_main():
    test_values = dict(platform_dist_result=['system', 'version', 'codename'],
                       osrelease_content='os release content')
    with patch.object(platform,'dist') as mock_dist:
        mock_dist.return_value = test_values['platform_dist_result']

        with patch('__main__.read_utf8_file', return_value=test_values['osrelease_content']):
            main()

    assert test_values == json.loads(sys.stdout.getvalue())

# Generated at 2022-06-22 19:46:46.938262
# Unit test for function get_platform_info
def test_get_platform_info():
    result = {
        'osrelease_content': 'NAME="Ubuntu"\nVERSION="14.04.3 LTS, Trusty Tahr"\nID=ubuntu\nID_LIKE=debian\nPRETTY_NAME="Ubuntu 14.04.3 LTS"\nVERSION_ID="14.04"\nHOME_URL="http://www.ubuntu.com/"\nSUPPORT_URL="http://help.ubuntu.com/"\nBUG_REPORT_URL="http://bugs.launchpad.net/ubuntu/"\n\n',
        'platform_dist_result': ['Ubuntu', '14.04', 'trusty'],
    }

    assert result == get_platform_info()

# Generated at 2022-06-22 19:46:57.133654
# Unit test for function get_platform_info
def test_get_platform_info():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, mock_open

    # Passing in None for /etc/os-release
    info = get_platform_info()

    # Assert that uname call was made
    assert len(info['platform_dist_result']) == 0

    # Assert that default value was set for osrelease_content
    assert info['osrelease_content'] == None


# Generated at 2022-06-22 19:46:59.602420
# Unit test for function get_platform_info
def test_get_platform_info():
    result = get_platform_info()
    assert 'platform_dist_result' in result
    assert 'osrelease_content' in result
    assert isinstance(result['osrelease_content'],str) or result['osrelease_content'] is None

# Generated at 2022-06-22 19:47:00.862179
# Unit test for function get_platform_info
def test_get_platform_info():
    assert get_platform_info()['platform_dist_result'] == platform.dist()


# Generated at 2022-06-22 19:47:05.752735
# Unit test for function main
def test_main():
    result = main()
    assert result['osrelease_content'] is not None
    assert result['platform_dist_result'][0] is not None
    assert result['platform_dist_result'][1] is not None
    assert result['platform_dist_result'][2] is not None

# Generated at 2022-06-22 19:47:09.767230
# Unit test for function read_utf8_file
def test_read_utf8_file():
    file_content = 'this is a test file'
    with open('/tmp/test_file', 'w') as f:
        f.write(file_content)
    assert read_utf8_file('/tmp/test_file') == file_content


# Generated at 2022-06-22 19:47:18.757452
# Unit test for function main
def test_main():
    import platform as _platform

    def fake_read_utf8_file(*args, **kwargs):
        return args[0]

    def fake_get_platform_info():
        return dict(platform_dist_result=[1, 2, 3], osrelease_content="id=1")

    json.dumps_original = json.dumps
    print_original = __builtins__['print']
    _platform.dist_original = _platform.dist
    read_utf8_file_original = read_utf8_file


# Generated at 2022-06-22 19:47:23.216271
# Unit test for function main
def test_main():
    test_result = get_platform_info()
    assert test_result['osrelease_content'] is not None
    assert test_result['platform_dist_result'] != []
    assert test_result['platform_dist_result'] == ['debian', 'debian', 'stretch/sid']

# Generated at 2022-06-22 19:47:28.597366
# Unit test for function read_utf8_file
def test_read_utf8_file():
    with open('testdata/utf8_test.txt', 'r') as fd:
        utf8_string = fd.read()

    assert read_utf8_file('testdata/utf8_test.txt') == utf8_string
    assert read_utf8_file('testdata/utf8_test_file_doesnt_exist') is None

# Generated at 2022-06-22 19:47:30.528384
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()

    assert 'platform_dist_result' in info
    assert 'osrelease_content' in info

# Generated at 2022-06-22 19:47:38.518475
# Unit test for function read_utf8_file
def test_read_utf8_file():
    @pytest.mark.parametrize('encoding, result', [
        ('utf-8', u''),
        ('gbk', u''),
    ])
    def do_test(tmpdir, encoding, result):
        # test with not exist file
        p = tmpdir.join('no_exist.txt')
        assert read_utf8_file(p, encoding) is None

        # test with exist file
        p = tmpdir.join('exist.txt')
        p.write(result, encoding=encoding)
        assert read_utf8_file(p, encoding) == result
    do_test()


# Generated at 2022-06-22 19:47:44.891234
# Unit test for function main
def test_main():
    # this test can't be executed during run because dpkg is not available on Windows
    if platform.system() == 'Windows':
        return
    info = get_platform_info()
    assert(info['platform_dist_result'] == ['debian'])
    assert('version_id="9"' in info['osrelease_content'])

# Generated at 2022-06-22 19:47:52.026017
# Unit test for function main
def test_main():
    import tempfile


# Generated at 2022-06-22 19:48:02.967164
# Unit test for function main
def test_main():
    # Create a file
    with io.open('/tmp/os_release', 'w', encoding='utf-8') as fd:
        fd.write('ID=debian\n')
        fd.write('VERSION_ID="8.12"\n')
        fd.write('PRETTY_NAME="Debian GNU/Linux 8 (jessie)"\n')

    os.symlink('/tmp/os_release', '/etc/os-release')

    platform_info = get_platform_info()

    os.remove('/tmp/os_release')
    os.remove('/etc/os-release')

    # Test dist result
    dist_result = ('debian', '8.12', '')

    assert platform_info['platform_dist_result'] == dist_result
    assert '/etc/os-release'

# Generated at 2022-06-22 19:48:08.711459
# Unit test for function read_utf8_file
def test_read_utf8_file():
    # Read a file that doesn't exist
    assert read_utf8_file('/etc/ansible/hosts') is None

    # Read a file that exists
    os_release_fixture = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../fixtures/os-release'))
    assert read_utf8_file(os_release_fixture)

# Generated at 2022-06-22 19:48:12.487345
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()

    assert info['platform_dist_result'] == platform.dist()
    assert info['osrelease_content'] == read_utf8_file('/etc/os-release') or read_utf8_file('/usr/lib/os-release')

# Generated at 2022-06-22 19:48:21.582248
# Unit test for function get_platform_info
def test_get_platform_info():

    import tempfile
    import shutil
    import os
    import json

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-22 19:48:30.186751
# Unit test for function get_platform_info
def test_get_platform_info():

    # Test with /etc/os-release
    os.environ['ANSIBLE_RUNTIME_PROFILES_TESTING'] = 'yes'
    os.environ['ANSIBLE_RUNTIME_PROFILES_CONFIG_DIR'] = os.path.join(os.path.dirname(__file__), '../..', 'testdata', 'runtime_profiles_testing')
    result = get_platform_info()

# Generated at 2022-06-22 19:48:32.841078
# Unit test for function get_platform_info
def test_get_platform_info():
    platform_info = get_platform_info()

    assert platform_info['osrelease_content'].startswith("NAME=")

# Generated at 2022-06-22 19:48:36.978464
# Unit test for function main
def test_main():
    platform_info = get_platform_info()
    assert "platform_dist_result" in platform_info
    assert "osrelease_content" in platform_info

# Generated at 2022-06-22 19:48:40.149175
# Unit test for function get_platform_info
def test_get_platform_info():
    assert get_platform_info() == dict(platform_dist_result=[], osrelease_content=None)

# Generated at 2022-06-22 19:48:42.167747
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('./test/test_0') == 'test_case'
    assert read_utf8_file('./test/test_1') == None

# Generated at 2022-06-22 19:48:47.544854
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert None == read_utf8_file('/nonexistent')
    with open('/etc/os-release', 'w') as fd:
        fd.write('ID="debian"\n\n')
    assert 'ID="debian"\n\n' == read_utf8_file('/etc/os-release')

# Generated at 2022-06-22 19:48:50.442444
# Unit test for function read_utf8_file
def test_read_utf8_file():

    assert read_utf8_file('') == None

    assert read_utf8_file('/etc/os-release') == 'NAME="Debian GNU/Linux"\nVERSION_ID="8"\nVERSION="8 (jessie)"\nID=debian\nHOME_URL="http://www.debian.org/"\nSUPPORT_URL="http://www.debian.org/support/"\nBUG_REPORT_URL="https://bugs.debian.org/"\n'  # noqa

# Generated at 2022-06-22 19:48:51.651636
# Unit test for function main
def test_main():
    info = get_platform_info()
    assert info["osrelease_content"] is not None

# Generated at 2022-06-22 19:48:53.135593
# Unit test for function get_platform_info
def test_get_platform_info():
    assert get_platform_info() == {'osrelease_content': None, 'platform_dist_result': []}

# Generated at 2022-06-22 19:49:02.464752
# Unit test for function read_utf8_file
def test_read_utf8_file():
    fp = '/tmp/test_read_utf8_file_script.py'
    with open(fp, 'w') as f:
        f.write('#!/bin/sh\n')
        f.write('echo hello world')

    # file is readable
    assert(read_utf8_file(fp) == '#!/bin/sh\necho hello world')
    # file is not readable
    assert(read_utf8_file('/tmp/script.py') is None)
    # file is not readable
    assert(read_utf8_file('') is None)

    # cleanup
    os.remove(fp)


# Generated at 2022-06-22 19:49:03.967322
# Unit test for function get_platform_info
def test_get_platform_info():
    # No tests available, since this is a function which returns little
    # more than the upstream platform module does.
    pass

# Generated at 2022-06-22 19:49:08.246860
# Unit test for function read_utf8_file
def test_read_utf8_file():
    result = read_utf8_file('./invalid_file')
    assert result is None
    result = read_utf8_file('./test_utils/scripts/platform_utils.py')
    assert result is not None
    assert 'import io' in result

# Generated at 2022-06-22 19:49:09.910804
# Unit test for function main
def test_main():
    info = get_platform_info()

    assert info['osrelease_content'] is not None

# Generated at 2022-06-22 19:49:13.225547
# Unit test for function read_utf8_file
def test_read_utf8_file():
   fd = open('testfile-utf8', 'w')
   fd.write('welcome')
   fd.close()
   s = read_utf8_file('testfile-utf8')
   assert s == 'welcome'


# Generated at 2022-06-22 19:49:19.086786
# Unit test for function get_platform_info
def test_get_platform_info():
    test_osrelease_content = """
NAME="Ubuntu"
VERSION="18.04.2 LTS (Bionic Beaver)"
ID=ubuntu
ID_LIKE=debian
PRETTY_NAME="Ubuntu 18.04.2 LTS"
VERSION_ID="18.04"
HOME_URL="https://www.ubuntu.com/"
SUPPORT_URL="https://help.ubuntu.com/"
BUG_REPORT_URL="https://bugs.launchpad.net/ubuntu/"
PRIVACY_POLICY_URL="https://www.ubuntu.com/legal/terms-and-policies/privacy-policy"
VERSION_CODENAME=bionic
UBUNTU_CODENAME=bionic
"""
    assert test_osrelease_content == read_utf8_file('/etc/os-release')

# Generated at 2022-06-22 19:49:21.016597
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()
    assert info['platform_dist_result'] == ['', '', '']

# Generated at 2022-06-22 19:49:25.833470
# Unit test for function get_platform_info
def test_get_platform_info():
    info = get_platform_info()

    # platform.dist() returns a tuple
    assert isinstance(info['platform_dist_result'], tuple)

    # /etc/os-release exists and is readable
    assert info['osrelease_content'] is not None

# Generated at 2022-06-22 19:49:28.405822
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/bin/ls') is not None
    assert read_utf8_file('does-not-exist') is None


# Generated at 2022-06-22 19:49:32.848999
# Unit test for function main
def test_main():
    info = main()
    assert isinstance(info, (dict))
    assert len(info) == 2
    assert isinstance(info['platform_dist_result'], (list))
    assert len(info['platform_dist_result']) == 3
    assert isinstance(info['osrelease_content'], (str))
    assert info['osrelease_content']


# Generated at 2022-06-22 19:49:40.748112
# Unit test for function read_utf8_file
def test_read_utf8_file():

    path = "testfile"
    data = "test\ndata\n"

    fd = open(path, "w")
    fd.write(data)
    fd.close()

    res = read_utf8_file(path)

    assert res is not None
    assert res == data

    # Cleanup
    os.remove(path)

# Generated at 2022-06-22 19:49:52.378524
# Unit test for function get_platform_info
def test_get_platform_info():
    assert not get_platform_info()['platform_dist_result']

    # make sure the function doesn't break when platform_dist returns a value
    old_platform_dist = platform.dist
    platform.dist = lambda: ('dist1', 'v1', 'codename')
    assert get_platform_info()['platform_dist_result'] == ('dist1', 'v1', 'codename')
    platform.dist = old_platform_dist

    # test that os-release read file can be returned
    osrelease_content = read_utf8_file('/etc/os-release')
    if osrelease_content:
        assert get_platform_info()['osrelease_content'] == osrelease_content
    else:
        assert not get_platform_info()['osrelease_content']

# Generated at 2022-06-22 19:49:55.984525
# Unit test for function main
def test_main():

    # Patch
    from ansible.module_utils.basic import AnsibleModule

    mod_mock = AnsibleModule(argument_spec={})
    mod_mock.exit_json = lambda x: x

    # Run function
    result = main()

    # Test conditions
    assert result
    assert result['platform_dist_result']

# Generated at 2022-06-22 19:49:57.929799
# Unit test for function read_utf8_file
def test_read_utf8_file():
    path = '/etc/os-release'
    file_content = read_utf8_file(path)
    print(file_content)

# Generated at 2022-06-22 19:50:00.037865
# Unit test for function read_utf8_file
def test_read_utf8_file():
    info = {}
    info['osrelease_content'] = read_utf8_file('/etc/os-release')

    assert info['osrelease_content'].startswith('NAME="openSUSE Tumbleweed"')

# Generated at 2022-06-22 19:50:11.258223
# Unit test for function read_utf8_file

# Generated at 2022-06-22 19:50:17.615305
# Unit test for function main
def test_main():
    module = AnsibleModule(
        argument_spec=dict(),
    )

    before_info = get_platform_info()
    main()
    after_info = json.loads(module.stdout().strip())
    assert before_info == after_info

from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 19:50:21.268179
# Unit test for function main
def test_main():
    info = get_platform_info()

    if not os.path.isfile('/etc/os-release'):
        info['osrelease_content'] = ""
    else:
        info['osrelease_content'] = read_utf8_file('/etc/os-release')
    assert(json.dumps(info) == main())


# Generated at 2022-06-22 19:50:22.599770
# Unit test for function get_platform_info
def test_get_platform_info():
    assert get_platform_info()

# Generated at 2022-06-22 19:50:29.484528
# Unit test for function main
def test_main():
    import tempfile
    import os

    with tempfile.TemporaryDirectory() as tmpdirname:
        os.chdir(tmpdirname)

        with open('os-release', 'w') as fd:
            os_release = ['NAME="Test-OS"', 'ID=test']
            fd.write('\n'.join(os_release))

        assert get_platform_info()['osrelease_content'] == '\n'.join(os_release)

# Generated at 2022-06-22 19:50:30.897751
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file(__file__) is not None

# Generated at 2022-06-22 19:50:32.408552
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release') != None

# Generated at 2022-06-22 19:50:41.158721
# Unit test for function main
def test_main():
    os.environ['LC_ALL'] = 'C'
    os.environ['LANG'] = 'C'
    os.environ['LANGUAGE'] = 'C'
    os.environ['LC_MESSAGES'] = 'C'

    with open('/tmp/ansible_test_run_vars_target.json', 'w+') as f:
        f.write(main())

    with open('/tmp/ansible_test_run_vars_target.json', 'r') as f:
        actual = json.loads(f.read())
    with open('/tmp/ansible_test_run_vars_expected_target.json', 'r') as f:
        expected = json.loads(f.read())

    assert actual == expected

# Generated at 2022-06-22 19:50:48.144761
# Unit test for function read_utf8_file
def test_read_utf8_file():
    # mock a file
    open('/tmp/mock_file', 'a').close()
    info = read_utf8_file('/tmp/mock_file')
    assert info

    # mock a non exist file
    info = read_utf8_file('/tmp/non_exist')
    assert info is None
    open('/tmp/non_exist', 'w').close()
    os.chmod('/tmp/non_exist', 0000)
    info = read_utf8_file('/tmp/non_exist')
    assert info is None

    # remove mock files
    os.chmod('/tmp/non_exist', 0o777)
    os.remove('/tmp/non_exist')
    os.chmod('/tmp/mock_file', 0o777)

# Generated at 2022-06-22 19:50:53.986216
# Unit test for function main
def test_main():
    info = dict(
        platform_dist_result=['debian', 'stretch/sid', '9.5'],
        osrelease_content='NAME="Debian GNU/Linux"\nVERSION_ID="9"\nVERSION="9 (stretch)"\nID=debian\nHOME_URL="https://www.debian.org/"\nSUPPORT_URL="https://www.debian.org/support"\nBUG_REPORT_URL="https://bugs.debian.org/"\n',
    )
    assert get_platform_info() == info

# Generated at 2022-06-22 19:50:57.948457
# Unit test for function read_utf8_file
def test_read_utf8_file():
    assert read_utf8_file('/etc/os-release') != None
    assert read_utf8_file('/usr/lib/os-release') != None
    assert read_utf8_file('/usr/bin/python') != None
    assert read_utf8_file('/usr/bin/python2') != None
