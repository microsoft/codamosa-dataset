

# Generated at 2022-06-17 14:53:43.225970
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    gargs = GlobalCLIArgs.from_options(args)
    assert gargs['foo'] is True
    assert gargs['bar'] is True
    assert gargs['baz'] is False

# Generated at 2022-06-17 14:53:47.894780
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:53:55.795796
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 1, 'b': 2})
    assert args['a'] == 1
    assert args['b'] == 2
    assert args.get('c') is None
    assert args.get('c', 3) == 3
    assert args.get('a', 3) == 1
    assert args.get('b', 3) == 2
    assert args.get('a', default=3) == 1
    assert args.get('b', default=3) == 2
    assert args.get('c', default=3) == 3
    assert args.get('a', 'default') == 1
    assert args.get('b', 'default') == 2
    assert args.get('c', 'default') == 'default'
    assert args.get('a', default='default') == 1

# Generated at 2022-06-17 14:54:00.727810
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 'b', 'c': {'d': 'e'}, 'f': ['g', 'h'], 'i': ('j', 'k')})
    assert args['a'] == 'b'
    assert args['c']['d'] == 'e'
    assert args['f'][0] == 'g'
    assert args['f'][1] == 'h'
    assert args['i'][0] == 'j'
    assert args['i'][1] == 'k'
    assert isinstance(args, ImmutableDict)
    assert isinstance(args['c'], ImmutableDict)
    assert isinstance(args['f'], tuple)
    assert isinstance(args['i'], tuple)

# Generated at 2022-06-17 14:54:06.395452
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': [5, 6, 7]}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert isinstance(test_args, ImmutableDict)
    assert isinstance(test_args['c'], ImmutableDict)
    assert isinstance(test_args['f'], tuple)

# Generated at 2022-06-17 14:54:13.733132
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_dict_immutable = CLIArgs(test_dict)
    assert test_dict_immutable == test_dict
    assert isinstance(test_dict_immutable, ImmutableDict)
    assert isinstance(test_dict_immutable, CLIArgs)
    assert not isinstance(test_dict_immutable, GlobalCLIArgs)
    assert test_dict_immutable.a == 1
    assert test_dict_immutable.b == 2
    assert test_dict_immutable.c == 3
    assert test_dict_immutable['a'] == 1
    assert test_dict_immutable['b'] == 2
    assert test_dict_immutable['c'] == 3

# Generated at 2022-06-17 14:54:19.513324
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    class TestClass2(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()
    assert TestClass2() is TestClass2()
    assert TestClass() is not TestClass2()

# Generated at 2022-06-17 14:54:27.652914
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser(description='Test CLIArgs')
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')

# Generated at 2022-06-17 14:54:37.553997
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that the constructor works
    args = CLIArgs({'foo': 'bar'})
    assert args['foo'] == 'bar'

    # Test that the constructor makes a copy of the data
    args = CLIArgs({'foo': 'bar'})
    args['foo'] = 'baz'
    assert args['foo'] == 'baz'

    # Test that the constructor makes a copy of the data
    args = CLIArgs({'foo': 'bar'})
    args['foo'] = 'baz'
    assert args['foo'] == 'baz'

    # Test that the constructor makes a copy of the data
    args = CLIArgs({'foo': 'bar'})
    args['foo'] = 'baz'
    assert args['foo'] == 'baz'

    # Test that the constructor makes a copy of the data

# Generated at 2022-06-17 14:54:47.590282
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # test for a simple dictionary
    test_dict = {'a': 1, 'b': 2}
    test_dict_copy = test_dict.copy()
    test_dict_copy['a'] = 3
    test_dict_copy['c'] = 4
    test_dict_copy['d'] = 5
    test_dict_copy['e'] = 6
    test_dict_copy['f'] = 7
    test_dict_copy['g'] = 8
    test_dict_copy['h'] = 9
    test_dict_copy['i'] = 10
    test_dict_copy['j'] = 11
    test_dict_copy['k'] = 12
    test_dict_copy['l'] = 13
    test_dict_copy['m'] = 14
    test_dict_copy['n'] = 15
    test_dict

# Generated at 2022-06-17 14:54:56.083296
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:55:02.290865
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:55:06.674514
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:55:09.576632
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:55:21.620672
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import boolean
    from ansible.module_utils.common.text.formatters import to_nice_yaml
    from ansible.module_utils.common.text.formatters import to_nice_json
    from ansible.module_utils.common.text.formatters import to_nice_text
    from ansible.module_utils.common.text.formatters import to_nice_path
    from ansible.module_utils.common.text.formatters import to_nice_url

# Generated at 2022-06-17 14:55:32.655076
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs({'a': 1, 'b': 2})
    assert cli_args['a'] == 1
    assert cli_args['b'] == 2
    assert cli_args.a == 1
    assert cli_args.b == 2
    assert cli_args.get('a') == 1
    assert cli_args.get('b') == 2
    assert cli_args.get('c') is None
    assert cli_args.get('c', 3) == 3
    assert cli_args.get('c', default=3) == 3
    assert cli_args.get('c', 'default') == 'default'
    assert cli_args.get('c', default='default') == 'default'

# Generated at 2022-06-17 14:55:44.245753
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_yaml_vars
    from ansible.utils.vars import load_vault_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_vars
    from ansible.utils.vars import load_vars
    from ansible.utils.vars import load_vars_from_inventory
    from ansible.utils.vars import load_vars_from_file
    from ansible.utils.vars import load_vars_from

# Generated at 2022-06-17 14:55:53.118261
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that the constructor works
    args = CLIArgs({'a': 1, 'b': 2})
    assert args['a'] == 1
    assert args['b'] == 2

    # Test that the constructor works with a nested dictionary
    args = CLIArgs({'a': 1, 'b': {'c': 2, 'd': 3}})
    assert args['a'] == 1
    assert args['b']['c'] == 2
    assert args['b']['d'] == 3

    # Test that the constructor works with a nested list
    args = CLIArgs({'a': 1, 'b': [2, 3]})
    assert args['a'] == 1
    assert args['b'][0] == 2
    assert args['b'][1] == 3

    # Test that the constructor works with a nested set
    args = CLI

# Generated at 2022-06-17 14:56:01.204825
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3

    # Test that the constructor of CLIArgs works
    test_dict = {
        'foo': 'bar',
        'baz': 'qux',
        'quux': 'corge',
        'grault': 'garply',
        'waldo': 'fred',
        'plugh': 'xyzzy',
        'thud': 'baz',
        'spam': 'eggs',
    }
    test_dict_copy = test_dict.copy()
    test_dict_copy['foo'] = 'baz'
    test_dict_copy['baz'] = 'quux'
   

# Generated at 2022-06-17 14:56:09.364559
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:56:23.537505
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])

    cli_args = CLIArgs.from_options(args)
    assert cli_args['foo'] is True
    assert cli_args['bar'] is True
    assert cli_args['baz'] is False
    assert cli_args['baz'] is not None
    assert cli_args['baz'] is not False

    # Test that it is immutable

# Generated at 2022-06-17 14:56:32.074102
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    args = CLIArgs({'foo': 'bar'})
    assert args['foo'] == 'bar'

    # Test that we can create a CLIArgs object with a nested dict
    args = CLIArgs({'foo': {'bar': 'baz'}})
    assert args['foo']['bar'] == 'baz'

    # Test that we can create a CLIArgs object with a nested list
    args = CLIArgs({'foo': ['bar', 'baz']})
    assert args['foo'][0] == 'bar'
    assert args['foo'][1] == 'baz'

    # Test that we can create a CLIArgs object with a nested set
    args = CLIArgs({'foo': set(['bar', 'baz'])})
    assert 'bar' in args['foo']

# Generated at 2022-06-17 14:56:38.886990
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    args = parser.parse_args([])
    GlobalCLIArgs.from_options(args)

# Generated at 2022-06-17 14:56:49.375140
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    options = Options(
        connection='local',
        forks=10,
        module_path='/path/to/mymodules',
        become=True,
        become_method='sudo',
        become_user='root',
        check=False,
        diff=False,
        extra_vars=['foo=bar', 'baz=qux'],
        inventory='/path/to/inventory',
        listhosts=False,
        listtasks=False,
        listtags=False,
        syntax=False,
        verbosity=4,
    )

    cli_args = GlobalCLIArgs.from_options(options)

   

# Generated at 2022-06-17 14:56:54.291269
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:56:56.009927
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:57:04.254727
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a dictionary
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert isinstance(test_args, ImmutableDict)

    # Test with a list
    test_list = [1, 2, 3]
    test_args = CLIArgs(test_list)
    assert test_args == test_list
    assert isinstance(test_args, tuple)

    # Test with a set
    test_set = set([1, 2, 3])
    test_args = CLIArgs(test_set)
    assert test_args == test_set
    assert isinstance(test_args, frozenset)

    # Test with a string
    test_string = 'abc'
    test_

# Generated at 2022-06-17 14:57:13.226431
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode

# Generated at 2022-06-17 14:57:23.945996
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3

    # Test that we can create an instance of CLIArgs
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_cli_args = CLIArgs(test_dict)
    assert isinstance(test_cli_args, ImmutableDict)

    # Test that we can create an instance of CLIArgs from an options object
    test_options = type('TestOptions', (object,), test_dict)
    test_cli_args = CLIArgs.from_options(test_options)
   

# Generated at 2022-06-17 14:57:27.084572
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:57:38.742459
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:57:46.452092
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a dict
    test_dict = {'a': 'b', 'c': 'd'}
    cli_args = CLIArgs(test_dict)
    assert cli_args == test_dict

    # Test with a list
    test_list = ['a', 'b', 'c']
    cli_args = CLIArgs(test_list)
    assert cli_args == test_list

    # Test with a set
    test_set = set(['a', 'b', 'c'])
    cli_args = CLIArgs(test_set)
    assert cli_args == test_set

    # Test with a tuple
    test_tuple = tuple(['a', 'b', 'c'])
    cli_args = CLIArgs(test_tuple)
    assert cli_args == test_

# Generated at 2022-06-17 14:57:57.411459
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_set
    from ansible.module_utils.common.collections import is_mapping
    from ansible.module_utils.common.collections import is_container

    # Test that the constructor works
    GlobalCLIArgs({})

    # Test that the constructor works with a non-empty dict
    GlobalCLIArgs({'foo': 'bar'})

    # Test that the constructor works with a non-empty dict with a list
    GlobalCLIArgs({'foo': ['bar']})

    # Test that the constructor works with

# Generated at 2022-06-17 14:58:08.737898
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a dict
    test_dict = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    cli_args = CLIArgs(test_dict)
    assert cli_args == test_dict
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args['c'], ImmutableDict)
    assert isinstance(cli_args['c']['e'], int)

    # Test with a list
    test_list = [1, 2, 3, 4]
    cli_args = CLIArgs(test_list)
    assert cli_args == test_list
    assert isinstance(cli_args, tuple)
    assert isinstance(cli_args[0], int)

    # Test with a set
    test_set

# Generated at 2022-06-17 14:58:13.968982
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.utils.display import Display
    display = Display()
    cli = CLI(args=sys.argv[1:], display=display)
    cli.parse()
    GlobalCLIArgs.from_options(cli.options)

# Generated at 2022-06-17 14:58:23.910330
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import argparse
    from ansible.module_utils.common.collections import ImmutableDict

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)

    # Create the parser
    parser = argparse.ArgumentParser()

    # Add some arguments
    parser.add_argument('-a', action='store_true', dest='a')
    parser.add_argument('-b', action='store', dest='b')
    parser.add_argument('-c', action='store', dest='c', type=int)
    parser.add_argument('-d', action='store', dest='d', type=float)

# Generated at 2022-06-17 14:58:33.945191
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar', action='append')
    parser.add_argument('--baz', nargs='+')
    parser.add_argument('--qux', nargs='*')
    parser.add_argument('--quux', nargs='?')
    parser.add_argument('--corge', nargs=2)
    parser.add_argument('--grault', nargs=3)
    parser.add_argument('--garply', nargs=4)
    parser.add_argument('--waldo', nargs=5)
    parser.add_argument('--fred', nargs=6)
    parser.add_argument('--plugh', nargs=7)
   

# Generated at 2022-06-17 14:58:46.509032
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that the constructor does not modify the input
    test_dict = {'a': 'b', 'c': 'd'}
    test_instance = CLIArgs(test_dict)
    assert test_dict == {'a': 'b', 'c': 'd'}
    assert test_instance == {'a': 'b', 'c': 'd'}
    assert test_instance == ImmutableDict({'a': 'b', 'c': 'd'})

    # Test that the constructor converts the input to an ImmutableDict
    test_dict = {'a': 'b', 'c': 'd'}
    test_instance = CLIArgs(test_dict)
    assert test_dict == {'a': 'b', 'c': 'd'}

# Generated at 2022-06-17 14:58:56.121075
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 1, 'b': [1, 2, 3], 'c': {'d': 4, 'e': [5, 6, 7]}})
    assert args['a'] == 1
    assert args['b'] == (1, 2, 3)
    assert args['c']['d'] == 4
    assert args['c']['e'] == (5, 6, 7)
    assert isinstance(args['c'], ImmutableDict)
    assert isinstance(args['b'], tuple)
    assert isinstance(args['c']['e'], tuple)
    assert isinstance(args, ImmutableDict)

# Generated at 2022-06-17 14:59:02.575577
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:59:16.449986
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('-a', '--arg1', action='store_true')
    parser.add_argument('-b', '--arg2', action='store_true')
    parser.add_argument('-c', '--arg3', action='store_true')
    parser.add_argument('-d', '--arg4', action='store_true')
    parser.add_argument('-e', '--arg5', action='store_true')
    parser.add_argument('-f', '--arg6', action='store_true')
    parser.add_argument('-g', '--arg7', action='store_true')
    parser.add_argument('-h', '--arg8', action='store_true')

# Generated at 2022-06-17 14:59:19.705107
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.utils.display import Display
    display = Display()
    cli = CLI(args=sys.argv[1:], display=display)
    options = cli.parse()
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-17 14:59:31.353364
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_str
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 14:59:33.717560
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'a': 1, 'b': 2, 'c': 3}
    cli_args = CLIArgs(mapping)
    assert cli_args == mapping


# Generated at 2022-06-17 14:59:46.636719
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.utils.display import Display
    display = Display()
    cli = CLI(args=sys.argv[1:], display=display)
    options = cli.parse()
    args = GlobalCLIArgs.from_options(options)
    assert args.get('verbosity') == 0
    assert args.get('connection') == 'smart'
    assert args.get('module_path') == None
    assert args.get('forks') == 5
    assert args.get('become') == False
    assert args.get('become_method') == 'sudo'
    assert args.get('become_user') == None
    assert args.get('check') == False
    assert args.get('listhosts') == None

# Generated at 2022-06-17 14:59:54.484080
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    GlobalCLIArgs.from_options(args)
    assert GlobalCLIArgs.instance().foo is True
    assert GlobalCLIArgs.instance().bar is True
    assert GlobalCLIArgs.instance().baz is False

# Generated at 2022-06-17 15:00:00.691385
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest

    class TestGlobalCLIArgs(unittest.TestCase):
        def setUp(self):
            self.old_sys_argv = sys.argv
            sys.argv = ['ansible-playbook', '--list-hosts']

        def tearDown(self):
            sys.argv = self.old_sys_argv

        def test_GlobalCLIArgs(self):
            from ansible.cli import CLI
            from ansible.utils.display import Display
            display = Display()
            cli = CLI(args=sys.argv[1:], display=display)
            options = cli.parse()
            args = GlobalCLIArgs.from_options(options)
            self.assertEqual(args['list_hosts'], True)


# Generated at 2022-06-17 15:00:14.501623
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': [5, 6, 7]}
    test_dict_copy = test_dict.copy()
    test_dict_copy['c']['e'] = 5
    test_dict_copy['f'].append(8)
    test_dict_copy['g'] = 9

    cli_args = CLIArgs(test_dict)
    assert cli_args == test_dict
    assert cli_args is not test_dict
    assert cli_args['c'] is not test_dict['c']
    assert cli_args['f'] is not test_dict['f']

    # Test that we can't change the dict

# Generated at 2022-06-17 15:00:17.497174
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 15:00:19.148082
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 15:00:29.710267
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--test', action='store_true')
    parser.add_argument('--test2', action='store_true')
    args = parser.parse_args([])
    GlobalCLIArgs.from_options(args)

# Generated at 2022-06-17 15:00:33.901043
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 15:00:41.405056
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABCSingleton(object):
        __metaclass__ = _ABCSingleton
    class TestABCSingleton2(object):
        __metaclass__ = _ABCSingleton
    assert TestABCSingleton() is TestABCSingleton()
    assert TestABCSingleton2() is TestABCSingleton2()
    assert TestABCSingleton() is not TestABCSingleton2()

# Generated at 2022-06-17 15:00:52.250951
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    test_dict = {'a': 1, 'b': 2}
    test_cli_args = CLIArgs(test_dict)

    # Test that we can access the values
    assert test_cli_args['a'] == 1
    assert test_cli_args['b'] == 2

    # Test that we can't modify the values
    try:
        test_cli_args['a'] = 2
    except TypeError:
        pass
    else:
        raise AssertionError('Should not be able to modify a CLIArgs object')

    # Test that we can't modify the values
    try:
        test_cli_args['c'] = 3
    except TypeError:
        pass
    else:
        raise AssertionError('Should not be able to modify a CLIArgs object')

   

# Generated at 2022-06-17 15:00:57.041312
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 15:00:59.785544
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 15:01:03.030063
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 15:01:09.693182
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args([])
    cli_args = GlobalCLIArgs.from_options(args)
    assert cli_args['foo'] is False
    assert cli_args['bar'] is False
    assert cli_args['baz'] is False

# Generated at 2022-06-17 15:01:14.410506
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object):
        __metaclass__ = _ABCSingleton

    class Test2(Test):
        pass

    assert Test() is Test()
    assert Test2() is Test2()

# Generated at 2022-06-17 15:01:22.821413
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='append')
    parser.add_argument('--qux', nargs=2)
    parser.add_argument('--quux', nargs='*')
    parser.add_argument('--corge', nargs='+')
    parser.add_argument('--grault', type=int)
    parser.add_argument('--garply', type=float)
    parser.add_argument('--waldo', type=str)
    parser.add_argument('--fred', type=bool)
    parser.add_argument('--plugh', type=list)

# Generated at 2022-06-17 15:01:43.663309
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args([])
    cli_args = GlobalCLIArgs.from_options(args)
    assert cli_args['foo'] is False
    assert cli_args['bar'] is False
    assert cli_args['baz'] is False

# Generated at 2022-06-17 15:01:54.011514
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create an instance of CLIArgs
    args = CLIArgs({'a': 1, 'b': 2, 'c': 3})
    assert args['a'] == 1
    assert args['b'] == 2
    assert args['c'] == 3

    # Test that we can create an instance of CLIArgs from an optparse.Values object
    from optparse import Values
    args = CLIArgs.from_options(Values({'a': 1, 'b': 2, 'c': 3}))
    assert args['a'] == 1
    assert args['b'] == 2
    assert args['c'] == 3

    # Test that we can create an instance of CLIArgs from an argparse.Namespace object
    from argparse import Namespace
    args = CLIArgs.from_options(Namespace(a=1, b=2, c=3))

# Generated at 2022-06-17 15:01:58.848427
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 15:02:07.828416
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type

    # Test that we can create an instance of CLIArgs
    args = CLIArgs({})
    assert isinstance(args, ImmutableDict)

    # Test that we can create an instance of CLIArgs with a dict
    args = CLIArgs({'a': 1, 'b': 2})
    assert isinstance(args, ImmutableDict)

    # Test that we can

# Generated at 2022-06-17 15:02:13.840137
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes

    # Test that we can create a CLIArgs object
    test_dict = {'a': 1, 'b': 2}
    cli_args = CLIArgs(test_dict)
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args, CLIArgs)
    assert cli_args == test_dict

    # Test that we can create a CLIArgs object from an options object
    from ansible.utils.display import Display
    from ansible.utils.plugin_docs import read_docstring
    from ansible.utils.vars import combine_v

# Generated at 2022-06-17 15:02:18.802261
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.utils.display import Display
    display = Display()
    cli = CLI(args=sys.argv[1:], display=display)
    cli.parse()
    GlobalCLIArgs.from_options(cli.options)

# Generated at 2022-06-17 15:02:26.076114
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    args = CLIArgs({'foo': 'bar'})
    assert isinstance(args, CLIArgs)
    assert isinstance(args, ImmutableDict)
    assert args['foo'] == 'bar'

    # Test that we can create a CLIArgs object with a nested dict
    args = CLIArgs({'foo': {'bar': 'baz'}})
    assert isinstance(args, CLIArgs)
    assert isinstance(args, ImmutableDict)
    assert args['foo']['bar'] == 'baz'

    # Test that we can create a CLIArgs object with a nested list
    args = CLIArgs({'foo': ['bar', 'baz']})
    assert isinstance(args, CLIArgs)
    assert isinstance(args, ImmutableDict)

# Generated at 2022-06-17 15:02:35.934610
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    assert CLIArgs({})

    # Test that we can create a CLIArgs object from an optparse.Values object
    from optparse import Values
    assert CLIArgs.from_options(Values({}))

    # Test that we can create a CLIArgs object from an argparse.Namespace object
    from argparse import Namespace
    assert CLIArgs.from_options(Namespace(**{}))

    # Test that we can create a CLIArgs object from a dict
    assert CLIArgs({})

    # Test that we can create a CLIArgs object from a dict with a list
    assert CLIArgs({'list': ['a', 'b', 'c']})

    # Test that we can create a CLIArgs object from a dict with a dict
    assert CLIArgs({'dict': {'a': 'b'}})



# Generated at 2022-06-17 15:02:43.614117
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 15:02:50.276932
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 'b', 'c': 'd'})
    assert args['a'] == 'b'
    assert args['c'] == 'd'
    assert len(args) == 2
    assert args.get('a') == 'b'
    assert args.get('c') == 'd'
    assert args.get('e') is None
    assert args.get('e', 'f') == 'f'
    assert 'a' in args
    assert 'c' in args
    assert 'e' not in args
    assert args.keys() == ['a', 'c']
    assert args.values() == ['b', 'd']
    assert args.items() == [('a', 'b'), ('c', 'd')]

# Generated at 2022-06-17 15:03:18.495231
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    cli_args = GlobalCLIArgs.from_options(args)
    assert cli_args['foo'] is True
    assert cli_args['bar'] is True

# Generated at 2022-06-17 15:03:25.034824
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    import copy
    import types

    # Test that we can create a CLIArgs object
    args = CLIArgs({'foo': 'bar'})
    assert isinstance(args, collections.Mapping)
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, CLIArgs)
    assert args == {'foo': 'bar'}

    # Test that we can't modify the object
    with pytest.raises(TypeError):
        args['foo'] = 'baz'

    # Test that we can't modify the object
    with pytest.raises(TypeError):
        del args['foo']

    # Test that we can't modify the object
    with pytest.raises(TypeError):
        args.clear()

    # Test that we can't modify the object

# Generated at 2022-06-17 15:03:35.802018
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

    # Test that we can create a CLIArgs object
    test_dict = {'a': 'b', 'c': 'd'}
    test_cli_args = CLIArgs(test_dict)
    assert isinstance(test_cli_args, ImmutableDict)
    assert test_cli_args == test_dict

    # Test that we can create a CLIArgs object with a unicode string
    test_dict = {'a': 'b', 'c': 'd', 'e': u'f'}
    test_cli_args = CLIArgs(test_dict)