

# Generated at 2022-06-17 14:53:38.781496
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:53:44.125529
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:53:45.884765
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:53:54.313656
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.module_utils.common.collections import CLIArgs
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_set
    from ansible.module_utils.common.collections import is_mapping
    from ansible.module_utils.common.collections import is_container

    # Test that GlobalCLIArgs is a singleton
    a = GlobalCLIArgs({'a': 1})
    b = GlobalCLIArgs({'a': 1})
    assert a is b

    # Test that Global

# Generated at 2022-06-17 14:53:59.779622
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:54:08.810779
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    import copy
    import sys

    # Test that we can create a CLIArgs object from a dictionary
    test_dict = {'foo': 'bar', 'baz': 'qux'}
    test_cli_args = CLIArgs(test_dict)
    assert isinstance(test_cli_args, collections.Mapping)
    assert isinstance(test_cli_args, collections.Mapping)
    assert test_cli_args == test_dict

    # Test that we can create a CLIArgs object from a CLIArgs object
    test_cli_args2 = CLIArgs(test_cli_args)
    assert isinstance(test_cli_args2, collections.Mapping)
    assert isinstance(test_cli_args2, collections.Mapping)
    assert test_cli_args2 == test_dict

    # Test that we

# Generated at 2022-06-17 14:54:17.105552
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:54:26.090265
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.module_utils.common.collections import CLIArgs
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import is_immutable
    import ansible.module_utils.common.collections as collections
    import sys
    import types

    # Test that the GlobalCLIArgs class is a Singleton
    assert isinstance(GlobalCLIArgs, collections._ABCSingleton)
    assert isinstance(GlobalCLIArgs, types.TypeType)

    # Test that the GlobalCLIArgs class is a subclass of CLIArgs
    assert issubclass(GlobalCLIArgs, CLIArgs)

    # Test that the GlobalCLIArgs class is a subclass of ImmutableDict

# Generated at 2022-06-17 14:54:32.174947
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    GlobalCLIArgs.from_options(args)
    sys.exit(0)

# Generated at 2022-06-17 14:54:39.460181
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:54:46.390246
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:54:57.446688
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.module_utils.common.collections import CLIArgs
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_set
    from ansible.module_utils.common.collections import is_mapping
    from ansible.module_utils.common.collections import is_container
    from ansible.module_utils.common.collections import is_hashable

# Generated at 2022-06-17 14:55:07.894248
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import PY2
    import sys

    if PY2:
        from collections import Mapping, Sequence, Set
    else:
        from collections.abc import Mapping, Sequence, Set

    # Test that we can create an empty CLIArgs object
    cli_args = CLIArgs({})
    assert isinstance(cli_args, ImmutableDict)
    assert len(cli_args) == 0

    # Test that we can create a CLIArgs object with a single string value
    cli_args = CLIArgs({'foo': 'bar'})
    assert isinstance(cli_args, ImmutableDict)
    assert len(cli_args) == 1
    assert cli_args['foo'] == 'bar'

    #

# Generated at 2022-06-17 14:55:12.121825
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    GlobalCLIArgs.from_options(args)

# Generated at 2022-06-17 14:55:18.317613
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:55:28.247846
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3

    # Test that the constructor works
    test_dict = {'test_key': 'test_value'}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict

    # Test that the constructor works with a dict that has a list
    test_dict = {'test_key': ['test_value']}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict

    # Test that the constructor works with a dict that has a dict

# Generated at 2022-06-17 14:55:30.122056
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:55:37.267745
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleError
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import string_types

    display = Display()
    vault_secrets = VaultLib(password_files=['/dev/null'],
                             vault_password_files=['/dev/null'],
                             loader=DataLoader())
    loader = DataLoader()
    vault_opts = {'vault_password_file': '/dev/null'}

    # Create a GlobalCLIArgs object
    global_cli_args

# Generated at 2022-06-17 14:55:48.764482
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:55:58.504342
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:56:05.275724
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:56:07.848372
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(TestClass(), TestClass)
    assert isinstance(TestClass(), Singleton)
    assert isinstance(TestClass(), ABCMeta)

# Generated at 2022-06-17 14:56:16.593821
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a simple dictionary
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    result = CLIArgs(test_dict)
    assert result == test_dict

    # Test with a nested dictionary
    test_dict = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    result = CLIArgs(test_dict)
    assert result == test_dict

    # Test with a list
    test_dict = {'a': 1, 'b': [2, 3, 4], 'c': 5}
    result = CLIArgs(test_dict)
    assert result == test_dict

    # Test with a nested list
    test_dict = {'a': 1, 'b': [2, [3, 4], 5], 'c': 6}
   

# Generated at 2022-06-17 14:56:26.685484
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Create a dictionary of arguments
    args = {
        'foo': 'bar',
        'baz': [1, 2, 3],
        'qux': {'quux': 'quuz'}
    }

    # Create an instance of CLIArgs
    cli_args = CLIArgs(args)

    # Assert that the instance is immutable
    assert isinstance(cli_args, ImmutableDict)

    # Assert that the instance is immutable
    assert isinstance(cli_args['baz'], tuple)

    # Assert that the instance is immutable
    assert isinstance(cli_args['qux'], ImmutableDict)

    # Assert that the instance is immutable
    assert isinstance(cli_args['qux']['quux'], text_type)

# Generated at 2022-06-17 14:56:34.810932
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_set
    from ansible.module_utils.common.collections import is_mapping

    # Test that we can create a CLIArgs object
    args = CLIArgs({'foo': 'bar'})
    assert args == {'foo': 'bar'}

    # Test that we can create a CLIArgs object with a nested dict
    args = CLIArgs({'foo': {'bar': 'baz'}})
    assert args == {'foo': {'bar': 'baz'}}

    # Test that we can create a CLIArgs object with a nested list

# Generated at 2022-06-17 14:56:47.977339
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    import ansible.module_utils.common.collections
    import ansible.module_utils.common._collections_compat

    # Test that we can create a CLIArgs object
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_args = CLIArgs(test_dict)
    assert isinstance(test_args, CLIArgs)
    assert isinstance(test_args, ansible.module_utils.common.collections.ImmutableDict)
    assert isinstance(test_args, collections.Mapping)
    assert isinstance(test_args, ansible.module_utils.common._collections_compat.Mapping)
    assert test_args == test_dict

    # Test that we can create a CLIArgs object with a nested dict

# Generated at 2022-06-17 14:56:52.107519
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:56:58.026554
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    GlobalCLIArgs.from_options(args)
    assert GlobalCLIArgs()['foo'] is True
    assert GlobalCLIArgs()['bar'] is True
    assert GlobalCLIArgs()['baz'] is False

# Generated at 2022-06-17 14:57:07.348702
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import unittest

    from ansible.cli.arguments import CLIArgumentParser

    class TestGlobalCLIArgs(unittest.TestCase):
        def setUp(self):
            self.parser = CLIArgumentParser(
                usage="%(prog)s [options]",
                description="Ansible CLI test",
                epilog="This is a test",
            )
            self.parser.add_argument("-t", "--test", action="store_true", dest="test", default=False,
                                     help="Test option")
            self.parser.add_argument("-l", "--list", action="store_true", dest="list", default=False,
                                     help="List option")

# Generated at 2022-06-17 14:57:15.068005
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:57:27.487014
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import os
    import sys
    from ansible.cli import CLI
    from ansible.utils.display import Display
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleError

    display = Display()
    display.verbosity = 3
    cli = CLI(
        args=sys.argv[1:],
        display=display,
        options=None,
    )
    try:
        cli.parse()
    except AnsibleError as e:
        display.error(str(e))
        sys.exit(1)

    loader = DataLoader()
    loader.set_basedir(cli.options.basedir)
    loader.set_vault_password(cli.options.vault_password)

    GlobalCLIArgs.from_options(cli.options)

# Generated at 2022-06-17 14:57:30.307066
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
        pass

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:57:37.423489
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest
    from ansible.module_utils.common.collections import ImmutableDict

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_constructor(self):
            args = GlobalCLIArgs({'foo': 'bar'})
            self.assertTrue(isinstance(args, ImmutableDict))
            self.assertEqual(args['foo'], 'bar')

    # Run unit tests
    suite = unittest.TestLoader().loadTestsFromModule(sys.modules[__name__])
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-17 14:57:47.867762
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type

    # Test that we can create a CLIArgs object with a dict
    test_dict = {'a': 'b', 'c': 'd'}
    test_cli_args = CLIArgs(test_dict)
    assert test_cli_args == test_dict

    # Test that we can create a CLIArgs object with a dict containing a list

# Generated at 2022-06-17 14:57:57.332017
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--bam', action='store_true')
    parser.add_argument('--bob', action='store_true')
    parser.add_argument('--bob2', action='store_true')
    parser.add_argument('--bob3', action='store_true')
    parser.add_argument('--bob4', action='store_true')
    parser.add_argument('--bob5', action='store_true')

# Generated at 2022-06-17 14:58:01.920766
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:58:04.724416
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:58:13.305463
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:58:23.475157
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that the constructor works as expected
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    cli_args = CLIArgs(test_dict)
    assert cli_args == test_dict
    assert cli_args.a == 1
    assert cli_args.b == 2
    assert cli_args.c == 3

    # Test that the constructor converts the dict to immutable
    test_dict['a'] = 4
    assert cli_args.a == 1
    assert cli_args.b == 2
    assert cli_args.c == 3

    # Test that the constructor converts the dict to immutable
    test_dict['b'] = 5
    assert cli_args.a == 1
    assert cli_args.b == 2
    assert cli_args.c == 3

# Generated at 2022-06-17 14:58:33.642643
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.module_utils.common.collections import ImmutableSet
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableSequence
    from ansible.module_utils.common.collections import ImmutableMapping
    from ansible.module_utils.common.collections import ImmutableContainer
    from ansible.module_utils.common.collections import MutableMapping
    from ansible.module_utils.common.collections import MutableSequence
    from ansible.module_utils.common.collections import MutableSet

# Generated at 2022-06-17 14:58:44.612734
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:58:51.920899
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_args = CLIArgs(test_dict)
    assert test_args['a'] == 1
    assert test_args['b'] == 2
    assert test_args['c'] == 3
    assert test_args.get('d') is None
    assert test_args.get('d', 4) == 4
    assert test_args.get('a', 4) == 1
    assert test_args.get('a', 'four') == 1
    assert test_args.get('a', 'four') == 1
    assert test_args.get('a', 'four') == 1
    assert test_args.get('a', 'four') == 1
    assert test_args.get('a', 'four') == 1

# Generated at 2022-06-17 14:58:55.633991
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:58:58.240703
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:59:04.086776
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:59:09.237149
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    class TestClass2(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()
    assert TestClass2() is TestClass2()
    assert TestClass() is not TestClass2()

# Generated at 2022-06-17 14:59:20.435278
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='append')
    parser.add_argument('--qux', nargs='+')
    parser.add_argument('--quux', nargs='*')
    parser.add_argument('--corge', nargs=2)
    parser.add_argument('--grault', nargs=3)
    parser.add_argument('--garply', nargs='?')
    parser.add_argument('--waldo', nargs='+')
    parser.add_argument('--fred', nargs='*')
    parser.add_argument('--plugh', nargs=2)
    parser.add

# Generated at 2022-06-17 14:59:25.926309
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:59:29.874556
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    class TestClass2(TestClass):
        pass

    assert TestClass() is TestClass()
    assert TestClass2() is TestClass2()
    assert TestClass() is not TestClass2()

# Generated at 2022-06-17 14:59:35.036715
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 4
    display.deprecation_warnings = False
    display.color = 'auto'
    display.debug = True
    display.warnings = True
    display.info = True
    display.error = True
    display.skipped = True
    display.verbose = True
    display.set_verbosity(4)
    display.set_deprecation_warnings(False)
    display.set_color('auto')
    display.set_debug(True)
    display.set_warnings(True)
    display.set_info(True)
    display.set_error(True)
    display.set_skipped(True)
    display.set_verbose(True)

# Generated at 2022-06-17 14:59:56.342117
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs constructor works as expected
    """
    # Test that we can create an instance of CLIArgs
    cli_args = CLIArgs({})
    assert isinstance(cli_args, CLIArgs)

    # Test that we can create an instance of CLIArgs with a mapping
    cli_args = CLIArgs({'a': 1})
    assert isinstance(cli_args, CLIArgs)

    # Test that we can create an instance of CLIArgs with a mapping that has a list
    cli_args = CLIArgs({'a': [1, 2, 3]})
    assert isinstance(cli_args, CLIArgs)

    # Test that we can create an instance of CLIArgs with a mapping that has a dict
    cli_args = CLIArgs({'a': {'b': 1}})

# Generated at 2022-06-17 15:00:07.443075
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.module_utils.common.collections import ImmutableSet
    from ansible.module_utils.common.collections import ImmutableSequence

    # Test that we can create an instance of CLIArgs
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_args = CLIArgs(test_dict)
    assert isinstance(test_args, ImmutableDict)
    assert test_args == test_dict

    # Test that we can create an instance of CLIArgs with nested dicts
    test_dict = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}

# Generated at 2022-06-17 15:00:19.212104
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 1, 'b': 2})
    assert args['a'] == 1
    assert args['b'] == 2

    args = CLIArgs({'a': 1, 'b': {'c': 2}})
    assert args['a'] == 1
    assert args['b']['c'] == 2

    args = CLIArgs({'a': 1, 'b': [2, 3]})
    assert args['a'] == 1
    assert args['b'][0] == 2
    assert args['b'][1] == 3

    args = CLIArgs({'a': 1, 'b': {'c': [2, 3]}})
    assert args['a'] == 1
    assert args['b']['c'][0] == 2
    assert args['b']['c'][1] == 3

# Generated at 2022-06-17 15:00:29.322536
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.text.converters import to_text
    import json
    import sys

    # Create a dict that contains all the types of objects that we want to test
    # We use json.loads to create the dict so that we can use the same dict for
    # both python2 and python3.  We also use json.loads because it will create
    # unicode strings for us in python2.

# Generated at 2022-06-17 15:00:40.130290
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-17 15:00:48.639488
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.module_utils.common.collections import ImmutableSet
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableSequence

    # Test that we can create an instance of CLIArgs
    args = CLIArgs({})
    assert isinstance(args, ImmutableDict)

    # Test that we can create an instance of CLIArgs with a dict
    args = CLIArgs({'a': 'b'})
    assert isinstance(args, ImmutableDict)

    # Test that we can create an instance of CLIArgs with a list

# Generated at 2022-06-17 15:00:50.371454
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli.arguments import options
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-17 15:00:59.893027
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode

    # Test that we can create an instance of CLIArgs
    cli_args = CLIArgs({})
    assert isinstance(cli_args, CLIArgs)

    # Test that we can create an instance of CLIArgs with a mapping
    cli_args = CLIArgs({'a': 1})
    assert isinstance(cli_args, CLIArgs)

    # Test that we can create an instance of CLIArgs with a mapping
    cli_args = CLIArgs({'a': 1, 'b': 2})

# Generated at 2022-06-17 15:01:02.898259
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is B()
    assert A() is C()
    assert B() is C()

# Generated at 2022-06-17 15:01:05.726216
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 15:01:26.577483
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'a': 'b', 'c': 'd'}
    args = CLIArgs(mapping)
    assert args == mapping


# Generated at 2022-06-17 15:01:32.879608
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_constructor(self):
            args = GlobalCLIArgs({'foo': 'bar'})
            self.assertEqual(args['foo'], 'bar')

    suite = unittest.TestLoader().loadTestsFromModule(sys.modules[__name__])
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-17 15:01:45.643713
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'foo': 'bar'})
    assert cli_args['foo'] == 'bar'

    # Test that we can create a CLIArgs object with a nested dict
    cli_args = CLIArgs({'foo': {'bar': 'baz'}})
    assert cli_args['foo']['bar'] == 'baz'

    # Test that we can create a CLIArgs object with a nested list
    cli_args = CLIArgs({'foo': ['bar', 'baz']})
    assert cli_args['foo'][0] == 'bar'
    assert cli_args['foo'][1] == 'baz'

    # Test that we can create a CLIArgs object with a nested set

# Generated at 2022-06-17 15:01:55.296089
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a mapping
    mapping = {
        'a': 1,
        'b': 2,
        'c': {
            'd': 3,
            'e': 4,
            'f': {
                'g': 5,
                'h': 6,
            },
        },
    }
    cli_args = CLIArgs(mapping)
    assert cli_args == mapping
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args['c'], ImmutableDict)
    assert isinstance(cli_args['c']['f'], ImmutableDict)

    # Test with a class
    class Options(object):
        def __init__(self):
            self.a = 1
            self.b = 2

# Generated at 2022-06-17 15:02:05.580406
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.config.manager import ConfigManager
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

    display = Display()
    cli = CLI(args=sys.argv[1:], display=display)
    config_manager = ConfigManager(cli.options, display)
    config_manager.finalize()
    cli.options = config_manager.options
    cli.options.connection = 'local'
    cli.options.module_path = None
    cli.options.forks = 1
    cli.options.become = None
    cli.options.become_method = None
    cli.options.become_user = None
    cli.options.check = False
    cli

# Generated at 2022-06-17 15:02:09.124745
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.utils.display import Display
    display = Display()
    cli = CLI(args=sys.argv[1:], display=display)
    options, args = cli.parse()
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-17 15:02:20.940722
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_set
    from ansible.module_utils.common.collections import is_mapping

    # Test that we can create a CLIArgs object
    args = CLIArgs({'a': 1, 'b': 2})
    assert isinstance(args, CLIArgs)
    assert is_immutable(args)
    assert is_mapping(args)

    # Test that we can create a CLIArgs object with nested data
    args = CLIArgs({'a': [1, 2, 3], 'b': {'c': 1, 'd': 2}})
    assert isinstance(args, CLIArgs)

# Generated at 2022-06-17 15:02:24.244888
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.utils.display import Display
    display = Display()
    cli = CLI(args=sys.argv[1:], display=display)
    options = cli.parse()
    args = GlobalCLIArgs.from_options(options)
    assert args is GlobalCLIArgs()

# Generated at 2022-06-17 15:02:27.063071
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 15:02:30.561616
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 15:03:05.669501
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert isinstance(TestClass(), TestClass)
    assert TestClass() is TestClass()

# Generated at 2022-06-17 15:03:09.202454
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 15:03:19.568237
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import os
    import sys
    import tempfile
    import unittest

    class TestCLIArgs(unittest.TestCase):
        def test_CLIArgs(self):
            # Test that CLIArgs can be created and that it is immutable
            args = CLIArgs({'a': 1, 'b': 2, 'c': 3})
            self.assertEqual(args['a'], 1)
            self.assertEqual(args['b'], 2)
            self.assertEqual(args['c'], 3)
            self.assertRaises(TypeError, args.__setitem__, 'a', 2)
            self.assertRaises(AttributeError, args.__setattr__, 'a', 2)


# Generated at 2022-06-17 15:03:26.276742
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()