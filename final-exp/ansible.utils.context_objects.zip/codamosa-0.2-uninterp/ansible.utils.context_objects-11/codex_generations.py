

# Generated at 2022-06-17 14:53:44.994022
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:53:48.955984
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    args = CLIArgs({'foo': 'bar'})
    assert args['foo'] == 'bar'

    # Test that we can create a CLIArgs object with a nested dict
    args = CLIArgs({'foo': {'bar': 'baz'}})
    assert args['foo']['bar'] == 'baz'

    # Test that we can create a CLIArgs object with a nested list
    args = CLIArgs({'foo': ['bar', 'baz']})
    assert args['foo'][0] == 'bar'
    assert args['foo'][1] == 'baz'

    # Test that we can create a CLIArgs object with a nested set
    args = CLIArgs({'foo': {'bar', 'baz'}})
    assert 'bar' in args['foo']


# Generated at 2022-06-17 14:53:56.075051
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.errors import AnsibleError
    from ansible.utils.display import Display
    display = Display()
    try:
        cli = CLI(args=sys.argv[1:], display=display)
    except AnsibleError as e:
        display.error(e)
        sys.exit(1)
    cli_args = CLIArgs.from_options(cli.options)
    assert cli_args.get('module_path') == cli.options.module_path
    assert cli_args.get('connection') == cli.options.connection
    assert cli_args.get('forks') == cli.options.forks
    assert cli_args.get('become') == cli.options.become
    assert cli_args

# Generated at 2022-06-17 14:54:05.853083
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import GlobalCLIArgs

    # Test that the constructor of GlobalCLIArgs works as expected
    # First, test that the constructor of GlobalCLIArgs works as expected
    # when it is passed a dictionary
    test_dict = {'foo': 'bar'}
    test_GlobalCLIArgs = GlobalCLIArgs(test_dict)
    assert isinstance(test_GlobalCLIArgs, ImmutableDict)
    assert test_GlobalCLIArgs['foo'] == 'bar'

    # Test that the constructor of GlobalCLIArgs works as expected
    # when it is passed a dictionary with a nested dictionary
    test_dict = {'foo': {'bar': 'baz'}}
    test

# Generated at 2022-06-17 14:54:10.327735
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:54:12.283525
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:54:17.629353
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_constructor(self):
            # Test that the constructor does not throw an exception
            GlobalCLIArgs({})

    # Run the unit test
    sys.exit(unittest.main())

# Generated at 2022-06-17 14:54:22.822112
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(sys.argv[1:])
    GlobalCLIArgs.from_options(args)

# Generated at 2022-06-17 14:54:26.460169
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:54:32.412412
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:54:45.387974
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode

    # Test that we can create a GlobalCLIArgs object
    GlobalCLIArgs({})

    # Test that we can create a GlobalCLIArgs object with a dict
    GlobalCLIArgs({"foo": "bar"})

    # Test that we can create a GlobalCLIArgs object with a ImmutableDict
    GlobalCLIArgs(ImmutableDict({"foo": "bar"}))

    # Test

# Generated at 2022-06-17 14:54:56.203350
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.module_utils.common.collections import CLIArgs
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_mutable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_set
    from ansible.module_utils.common.collections import is_string
    from ansible.module_utils.common.collections import is_container
    from ansible.module_utils.common.collections import is_mapping

# Generated at 2022-06-17 14:54:58.159344
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:55:08.545492
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.utils.display import Display
    display = Display()
    cli = CLI(args=sys.argv[1:], display=display)
    options = cli.parse()
    args = GlobalCLIArgs.from_options(options)
    assert args.get('verbosity') == 0
    assert args.get('connection') == 'smart'
    assert args.get('module_path') == None
    assert args.get('forks') == 5
    assert args.get('become') == False
    assert args.get('become_method') == 'sudo'
    assert args.get('become_user') == 'root'
    assert args.get('check') == False
    assert args.get('diff') == False

# Generated at 2022-06-17 14:55:20.334087
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser.add_argument

# Generated at 2022-06-17 14:55:25.652416
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:55:36.451000
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.module_utils.common.collections import CLIArgs
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_set
    from ansible.module_utils.common.collections import is_mapping

    # Test that GlobalCLIArgs is a subclass of CLIArgs
    assert issubclass(GlobalCLIArgs, CLIArgs)

    # Test that GlobalCLIArgs is a singleton
    assert GlobalCLIArgs() is GlobalCLIArgs()

    # Test that GlobalCLIArgs is an immutable dictionary


# Generated at 2022-06-17 14:55:38.619735
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    class Bar(object):
        __metaclass__ = _ABCSingleton

    assert Foo() is Foo()
    assert Bar() is Bar()
    assert Foo() is not Bar()

# Generated at 2022-06-17 14:55:46.188761
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    args = CLIArgs({'foo': 'bar'})
    assert isinstance(args, CLIArgs)
    assert isinstance(args, ImmutableDict)
    assert args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from an options object
    options = type('', (), {'foo': 'bar'})()
    args = CLIArgs.from_options(options)
    assert isinstance(args, CLIArgs)
    assert isinstance(args, ImmutableDict)
    assert args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from a dict
    args = CLIArgs({'foo': 'bar'})
    assert isinstance(args, CLIArgs)
    assert isinstance(args, ImmutableDict)

# Generated at 2022-06-17 14:55:54.262149
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:56:00.102322
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    args = parser.parse_args(sys.argv[1:])
    GlobalCLIArgs.from_options(args)

# Generated at 2022-06-17 14:56:02.754282
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    a = A()
    b = A()
    assert a is b

# Generated at 2022-06-17 14:56:10.043023
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar', action='append')
    parser.add_argument('--baz', action='append_const', const='baz')
    parser.add_argument('--qux', action='append_const', const='qux')
    parser.add_argument('--quux', action='append_const', const='quux')
    parser.add_argument('--corge', action='append_const', const='corge')
    parser.add_argument('--grault', action='append_const', const='grault')
    parser.add_argument('--garply', action='append_const', const='garply')

# Generated at 2022-06-17 14:56:18.025627
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_list
    from ansible.module_utils.common.text.converters import to_set
    from ansible.module_utils.common.text.converters import to_dict
    from ansible.module_utils.common.text.converters import to_bytes_or_unicode
    from ansible.module_utils.common.text.converters import to_unicode

# Generated at 2022-06-17 14:56:26.295310
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest
    from ansible.module_utils.common.collections import ImmutableDict

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_GlobalCLIArgs(self):
            # Test that GlobalCLIArgs is a Singleton
            self.assertIs(GlobalCLIArgs(), GlobalCLIArgs())

            # Test that GlobalCLIArgs is an ImmutableDict
            self.assertIsInstance(GlobalCLIArgs(), ImmutableDict)

            # Test that GlobalCLIArgs is a CLIArgs
            self.assertIsInstance(GlobalCLIArgs(), CLIArgs)

            # Test that GlobalCLIArgs is a Mapping
            self.assertIsInstance(GlobalCLIArgs(), Mapping)

    # Run the unit test
    sys.exit(unittest.main())

# Generated at 2022-06-17 14:56:30.588440
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:56:37.596472
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest
    from ansible.cli import CLI

    class TestGlobalCLIArgs(unittest.TestCase):
        def setUp(self):
            self.parser = CLI.base_parser(
                usage="%prog [options]",
                connect_opts=True,
                meta_opts=True,
                runas_opts=True,
                subset_opts=True,
                check_opts=True,
                runtask_opts=True,
                vault_opts=True,
                fork_opts=True,
                module_opts=True,
                desc="does cool things",
            )


# Generated at 2022-06-17 14:56:38.543513
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:56:44.917674
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:56:51.550900
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is B()
    assert A() is C()
    assert B() is C()

# Generated at 2022-06-17 14:56:58.373459
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:57:04.944648
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest
    from ansible.module_utils.common.collections import GlobalCLIArgs

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_constructor(self):
            args = GlobalCLIArgs({'foo': 'bar'})
            self.assertEqual(args['foo'], 'bar')

    suite = unittest.TestLoader().loadTestsFromTestCase(TestGlobalCLIArgs)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-17 14:57:10.663325
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:57:14.373543
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABCSingleton(_ABCSingleton):
        pass

    class TestABCSingleton2(_ABCSingleton):
        pass

    assert TestABCSingleton() is TestABCSingleton()
    assert TestABCSingleton2() is TestABCSingleton2()
    assert TestABCSingleton() is not TestABCSingleton2()

# Generated at 2022-06-17 14:57:25.299767
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-17 14:57:31.967418
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:57:35.665479
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:57:40.520700
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:57:52.568253
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_set
    from ansible.module_utils.common.collections import is_mapping
    from ansible.module_utils.common.collections import is_container

    # Test that the constructor of GlobalCLIArgs makes a copy of the input
    # and makes it immutable
    input_dict = {'foo': 'bar', 'baz': 'qux'}
    input_dict_copy = input_dict.copy()
    args = GlobalCLIArgs(input_dict)
    assert is_immutable(args)
    assert is_mapping(args)
    assert is_container(args)

# Generated at 2022-06-17 14:57:54.928487
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
        pass
    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:58:03.197214
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object):
        __metaclass__ = _ABCSingleton

    class Test2(Test):
        pass

    assert Test() is Test()
    assert Test2() is Test2()
    assert Test() is not Test2()

# Generated at 2022-06-17 14:58:12.325515
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 'b', 'c': 'd'})
    assert args['a'] == 'b'
    assert args['c'] == 'd'
    assert len(args) == 2
    assert args == {'a': 'b', 'c': 'd'}
    assert args != {'a': 'b', 'c': 'e'}
    assert args != {'a': 'b', 'c': 'd', 'e': 'f'}
    assert args != {'a': 'b'}
    assert args != {'c': 'd'}
    assert args != {'a': 'b', 'c': 'd', 'e': 'f'}
    assert args != {'a': 'b', 'c': 'd', 'e': 'f', 'g': 'h'}
    assert args

# Generated at 2022-06-17 14:58:16.640529
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    assert D() is D()

# Generated at 2022-06-17 14:58:21.458235
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is B()
    assert A() is C()
    assert B() is C()

# Generated at 2022-06-17 14:58:27.955803
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_constructor(self):
            # Make sure the constructor works
            GlobalCLIArgs({'foo': 'bar'})

    suite = unittest.TestLoader().loadTestsFromModule(sys.modules[__name__])
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-17 14:58:39.154358
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('-a', action='store_true')
    parser.add_argument('-b', action='store_true')
    parser.add_argument('-c', action='store_true')
    parser.add_argument('-d', action='store_true')
    parser.add_argument('-e', action='store_true')
    parser.add_argument('-f', action='store_true')
    parser.add_argument('-g', action='store_true')
    parser.add_argument('-h', action='store_true')
    parser.add_argument('-i', action='store_true')
    parser.add_argument('-j', action='store_true')

# Generated at 2022-06-17 14:58:49.357642
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({'foo': 'bar'})
    assert args['foo'] == 'bar'
    assert args.get('foo') == 'bar'
    assert args.get('baz') is None
    assert args.get('baz', 'qux') == 'qux'
    assert args.get('baz', default='qux') == 'qux'
    assert args.get('foo', default='qux') == 'bar'
    assert args.get('foo', 'qux') == 'bar'

# Generated at 2022-06-17 14:59:02.646372
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.cli import CLI
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars_from_file
    from ansible.utils.vars import load_vars_from_inventory
    from ansible.utils.vars import load_vars_from_main
    from ansible.utils.vars import load_vars_from_task_vars
    from ansible.utils.vars import load_vars_from_task_vars_file

# Generated at 2022-06-17 14:59:09.336147
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:59:20.435682
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    import sys
    import unittest


# Generated at 2022-06-17 14:59:32.068205
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar', type=int)
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', nargs='+')
    parser.add_argument('--quux', nargs='*')
    parser.add_argument('--corge', nargs='?')
    parser.add_argument('--grault', default='garply')
    parser.add_argument('--waldo', default=['fred', 'plugh'])
    parser.add_argument('--fred', default={'thud': 'xyzzy'})
    parser.add_argument('--garply', default=['thud', 'xyzzy'])


# Generated at 2022-06-17 14:59:40.269830
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:59:47.655978
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 'b', 'c': {'d': 'e', 'f': 'g'}, 'h': ['i', 'j', 'k']}
    test_immutable_dict = CLIArgs(test_dict)
    assert test_immutable_dict == test_dict
    assert isinstance(test_immutable_dict, ImmutableDict)
    assert isinstance(test_immutable_dict['c'], ImmutableDict)
    assert isinstance(test_immutable_dict['h'], tuple)
    assert isinstance(test_immutable_dict['h'][0], text_type)

# Generated at 2022-06-17 14:59:57.024468
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import os
    import sys
    import tempfile
    import unittest

    from ansible.cli import CLI

    class TestGlobalCLIArgs(unittest.TestCase):
        def setUp(self):
            self.parser = CLI.base_parser(
                usage='usage',
                connect_opts=True,
                meta_opts=True,
                runas_opts=True,
                subset_opts=True,
                check_opts=True,
                diff_opts=True,
                vault_opts=True,
                fork_opts=True,
                module_opts=True,
                desc='description',
                epilog='epilog',
                version=CLI.version,
            )

# Generated at 2022-06-17 15:00:02.315445
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 15:00:06.063225
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 15:00:12.904761
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', default='bar')
    parser.add_argument('--baz', default='qux')
    args = parser.parse_args(sys.argv[1:])

    # Create a new instance of GlobalCLIArgs
    GlobalCLIArgs.from_options(args)

    # Create a new instance of GlobalCLIArgs
    GlobalCLIArgs.from_options(args)

# Generated at 2022-06-17 15:00:21.575073
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    if PY3:
        from ansible.module_utils.six.moves import configparser
    else:
        from ansible.module_utils.six.moves import ConfigParser as configparser

    # Test that a simple dict is converted to an ImmutableDict
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_immutable_dict = CLIArgs(test_dict)
    assert isinstance(test_immutable_dict, ImmutableDict)
    assert test_immutable_dict == test_dict

    # Test that a nested dict is converted to an ImmutableDict

# Generated at 2022-06-17 15:00:28.114321
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import unittest
    from ansible.module_utils.common.collections import ImmutableDict

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_GlobalCLIArgs(self):
            args = {'foo': 'bar', 'baz': 'qux'}
            global_args = GlobalCLIArgs(args)
            self.assertIsInstance(global_args, ImmutableDict)
            self.assertEqual(global_args, args)

    unittest.main()

# Generated at 2022-06-17 15:00:31.173230
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
    test_instance = TestClass()
    assert isinstance(test_instance, TestClass)

# Generated at 2022-06-17 15:00:50.470253
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is B()
    assert A() is C()
    assert B() is C()

# Generated at 2022-06-17 15:00:59.926353
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY2

    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'foo': 'bar'})
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args, CLIArgs)

    # Test that we can create a CLIArgs object from an options object
    from ansible.cli import CLI
    cli = CLI(args=['--foo', 'bar'])
    cli_args = CLIArgs.from_options(cli.parser.parse_args())
    assert isinstance(cli_args, ImmutableDict)

# Generated at 2022-06-17 15:01:02.269127
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert isinstance(TestClass(), TestClass)

# Generated at 2022-06-17 15:01:10.881127
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options:
        pass
    options = Options()
    options.foo = 'bar'
    options.baz = 'qux'
    options.baz_list = ['qux', 'quux']
    options.baz_dict = {'qux': 'quux', 'corge': 'grault'}
    options.baz_set = {'qux', 'quux', 'corge'}
    options.baz_tuple = ('qux', 'quux', 'corge')
    options.baz_int = 1
    options.baz_float = 1.0
    options.baz_bool = True
    options.baz_none = None
    options.baz_unicode = u'unicode'
    options.baz_bytes = b'bytes'
    options.baz_

# Generated at 2022-06-17 15:01:19.830730
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # pylint: disable=protected-access
    # pylint: disable=no-member
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=unused-import
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.module_utils.common.collections import ImmutableSet
    from ansible.module_utils.common.collections import ImmutableSequence
    from ansible.module_utils.common.collections import ImmutableMapping
    from ansible.module_utils.common.collections import ImmutableContainer
    from ansible.module_utils.common.collections import MutableMapping

# Generated at 2022-06-17 15:01:31.320958
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    options = Options(
        foo=True,
        bar=False,
        baz=dict(
            a=1,
            b=2,
            c=3,
        ),
        qux=dict(
            a=dict(
                a=1,
                b=2,
                c=3,
            ),
            b=dict(
                a=1,
                b=2,
                c=3,
            ),
            c=dict(
                a=1,
                b=2,
                c=3,
            ),
        ),
    )
    args = CLIArgs.from_options(options)

# Generated at 2022-06-17 15:01:40.492265
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes

    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'foo': 'bar'})

    # Test that we can access the values
    assert cli_args['foo'] == 'bar'

    # Test that we can't modify the values
    try:
        cli_args['foo'] = 'baz'
    except TypeError:
        pass
    else:
        assert False, 'Expected TypeError'

    # Test that we can't modify the keys

# Generated at 2022-06-17 15:01:52.768614
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 15:02:04.173453
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 15:02:11.934738
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    args = CLIArgs({'a': 1, 'b': 2})
    assert isinstance(args, CLIArgs)

    # Test that we can create a CLIArgs object from an options object
    from ansible.utils.display import Display
    from ansible.utils.path import module_finder
    from ansible.cli import CLI
    from ansible.cli.arguments import optparse_helpers as opt_help
    from ansible.config.manager import ConfigManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import module_loader
    from ansible.plugins.loader import plugin_loader
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 15:03:02.667676
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.module_utils.common.collections import ImmutableSet
    from ansible.module_utils.common.collections import ImmutableDict


# Generated at 2022-06-17 15:03:08.669041
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    import unittest

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_GlobalCLIArgs(self):
            parser = argparse.ArgumentParser()
            parser.add_argument('--foo', default='bar')
            parser.add_argument('--baz', default=42)
            parser.add_argument('--qux', default=False)
            parser.add_argument('--quux', default=None)
            parser.add_argument('--corge', default=['grault', 'garply'])
            parser.add_argument('--waldo', default={'fred': 'plugh', 'xyzzy': 'thud'})
            parser.add_argument('--fred', default=['plugh', 'thud'])

# Generated at 2022-06-17 15:03:19.427744
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    import json

    # Test that we can create a CLIArgs object
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_cli_args = CLIArgs(test_dict)
    assert isinstance(test_cli_args, ImmutableDict)
    assert isinstance(test_cli_args, CLIArgs)
    assert test_cli_args == test_dict

    # Test that we can create a CLIArgs object from an options object
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 15:03:20.412977
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 15:03:27.237957
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 15:03:37.091273
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.module_utils.common.collections import ImmutableSet
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableSequence
    from ansible.module_utils.common.collections import ImmutableMapping
    from ansible.module_utils.common.collections import ImmutableContainer
    import collections

    # Test that the constructor works
    test_dict = {'a': 'b', 'c': 'd'}
    test_obj = CLIArgs(test_dict)
    assert isinstance(test_obj, ImmutableDict)
    assert test_obj == test_dict