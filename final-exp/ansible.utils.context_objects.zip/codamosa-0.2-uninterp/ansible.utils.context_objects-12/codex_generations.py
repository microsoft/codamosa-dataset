

# Generated at 2022-06-17 14:53:49.275378
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    import copy
    import types

    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'foo': 'bar'})
    assert isinstance(cli_args, CLIArgs)

    # Test that we can't modify the CLIArgs object
    try:
        cli_args['foo'] = 'baz'
        assert False, "Should not be able to modify CLIArgs object"
    except TypeError:
        pass

    # Test that we can't modify the CLIArgs object
    try:
        cli_args.update({'foo': 'baz'})
        assert False, "Should not be able to modify CLIArgs object"
    except TypeError:
        pass

    # Test that we can't modify the CLIArgs object

# Generated at 2022-06-17 14:53:56.183004
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that the constructor works
    args = CLIArgs({'foo': 'bar'})
    assert args['foo'] == 'bar'

    # Test that the constructor makes the object immutable
    try:
        args['foo'] = 'baz'
        assert False, 'Should not be able to change the value of an item in an immutable object'
    except TypeError:
        pass

    # Test that the constructor makes the object immutable
    try:
        args['baz'] = 'qux'
        assert False, 'Should not be able to add an item to an immutable object'
    except TypeError:
        pass

    # Test that the constructor makes the object immutable
    try:
        del args['foo']
        assert False, 'Should not be able to delete an item from an immutable object'
    except TypeError:
        pass

    # Test that

# Generated at 2022-06-17 14:54:01.974648
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 'b', 'c': 'd'}
    test_obj = CLIArgs(test_dict)
    assert test_obj == test_dict
    assert test_obj['a'] == 'b'
    assert test_obj['c'] == 'd'
    assert test_obj.get('a') == 'b'
    assert test_obj.get('c') == 'd'
    assert test_obj.get('e') is None
    assert test_obj.get('e', 'f') == 'f'
    assert test_obj.get('a', 'f') == 'b'
    assert test_obj.get('c', 'f') == 'd'
    assert test_obj.keys() == ['a', 'c']
    assert test_obj.values() == ['b', 'd']
   

# Generated at 2022-06-17 14:54:07.376515
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': [5, 6, 7]}
    test_obj = CLIArgs(test_dict)
    assert test_obj == test_dict
    assert isinstance(test_obj, ImmutableDict)
    assert isinstance(test_obj['c'], ImmutableDict)
    assert isinstance(test_obj['f'], tuple)

# Generated at 2022-06-17 14:54:10.681625
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', default='bar')
    args = parser.parse_args(['--foo', 'baz'])
    GlobalCLIArgs.from_options(args)
    assert GlobalCLIArgs['foo'] == 'baz'

# Generated at 2022-06-17 14:54:18.728771
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_set
    from ansible.module_utils.common.collections import is_mapping
    from ansible.module_utils.common.collections import is_container
    from ansible.module_utils.common.collections import is_immutable_mapping
    from ansible.module_utils.common.collections import is_immutable_sequence
    from ansible.module_utils.common.collections import is_immutable_set
    from ansible.module_utils.common.collections import is_immutable_

# Generated at 2022-06-17 14:54:24.720392
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.module_utils.common.argparse import CLIArgParser
    parser = CLIArgParser()
    options = parser.parse_args(sys.argv[1:])
    args = GlobalCLIArgs.from_options(options)
    assert isinstance(args, GlobalCLIArgs)
    assert isinstance(args, CLIArgs)
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, Mapping)
    assert isinstance(args, Container)

# Generated at 2022-06-17 14:54:26.798018
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:54:31.376870
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    assert D() is D()

# Generated at 2022-06-17 14:54:44.967885
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_set
    from ansible.module_utils.common.collections import is_mapping
    from ansible.module_utils.common.collections import is_container

    # Test that the constructor of GlobalCLIArgs works
    # Test that it is a singleton
    # Test that it is immutable
    # Test that it is a mapping
    # Test that it is a container
    # Test that it is not a sequence
    # Test that it is not a set
    # Test that it is not a list
    # Test that

# Generated at 2022-06-17 14:54:58.405302
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import ansible.module_utils.common.collections as collections
    import ansible.module_utils.common.json_utils as json_utils
    import ansible.module_utils.common.text.converters as text_converters
    import ansible.module_utils.common.text.formatters as text_formatters
    import ansible.module_utils.common.text.utils as text_utils
    import ansible.module_utils.common.validation as validation
    import ansible.module_utils.common.warnings as warnings
    import ansible.module_utils.six as six
    import ansible.module_utils.urls as urls
    import ansible.module_utils.yaml as yaml

    # Create a GlobalCLIArgs object
    GlobalCLIArgs()

    # Create a second GlobalCLIArgs

# Generated at 2022-06-17 14:55:08.750586
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs constructor works as expected
    """
    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'foo': 'bar'})
    assert cli_args['foo'] == 'bar'

    # Test that we can't modify the CLIArgs object
    try:
        cli_args['foo'] = 'baz'
    except TypeError:
        pass
    else:
        assert False, "Should not be able to modify CLIArgs object"

    # Test that we can't modify the CLIArgs object
    try:
        cli_args.update({'foo': 'baz'})
    except TypeError:
        pass
    else:
        assert False, "Should not be able to modify CLIArgs object"

    # Test that we can't modify the CLIArgs object

# Generated at 2022-06-17 14:55:12.481649
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()

# Generated at 2022-06-17 14:55:16.633221
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:55:26.698537
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_set
    from ansible.module_utils.common.collections import is_mapping
    from ansible.module_utils.common.collections import is_container
    from ansible.module_utils.common.collections import is_immutable_mapping
    from ansible.module_utils.common.collections import is_immutable_sequence
    from ansible.module_utils.common.collections import is_immutable_set
    from ansible.module_utils.common.collections import is_immutable_

# Generated at 2022-06-17 14:55:37.293633
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.six import PY2

    # Test basic constructor
    args = CLIArgs({'foo': 'bar'})
    assert args['foo'] == 'bar'
    assert is_immutable(args)

    # Test constructor with nested dict
    args = CLIArgs({'foo': {'bar': 'baz'}})
    assert args['foo']['bar'] == 'baz'
    assert is_immutable(args)
    assert is_immutable(args['foo'])

    # Test constructor with nested list
    args = CLIArgs({'foo': ['bar', 'baz']})

# Generated at 2022-06-17 14:55:48.801679
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a dict
    test_dict = {'a': 'b', 'c': 'd'}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert test_args.a == 'b'
    assert test_args.c == 'd'

    # Test with a list
    test_list = [('a', 'b'), ('c', 'd')]
    test_args = CLIArgs(test_list)
    assert test_args == dict(test_list)
    assert test_args.a == 'b'
    assert test_args.c == 'd'

    # Test with a tuple
    test_tuple = (('a', 'b'), ('c', 'd'))
    test_args = CLIArgs(test_tuple)

# Generated at 2022-06-17 14:55:54.100891
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:56:01.650711
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest
    from ansible.cli import CLI
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

    class TestCLI(CLI):
        def __init__(self):
            super(TestCLI, self).__init__()
            self.parser = None
            self.args = None
            self.options = None
            self.display = Display()

    class TestGlobalCLIArgs(unittest.TestCase):
        def setUp(self):
            self.cli = TestCLI()
            self.cli.parse()
            self.args = self.cli.args
            self.options = self.cli.options

# Generated at 2022-06-17 14:56:06.893993
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_list
    from ansible.module_utils.common.text.converters import to_set
    from ansible.module_utils.common.text.converters import to_dict
    from ansible.module_utils.common.text.converters import to_bytes_or_unicode
    from ansible.module_utils.common.text.converters import to_unicode

# Generated at 2022-06-17 14:56:17.586524
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    import copy
    import types

    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'foo': 'bar'})
    assert isinstance(cli_args, CLIArgs)

    # Test that we can create a CLIArgs object with a nested dictionary
    cli_args = CLIArgs({'foo': {'bar': 'baz'}})
    assert isinstance(cli_args, CLIArgs)

    # Test that we can create a CLIArgs object with a nested list
    cli_args = CLIArgs({'foo': ['bar', 'baz']})
    assert isinstance(cli_args, CLIArgs)

    # Test that we can create a CLIArgs object with a nested set
    cli_args = CLIArgs({'foo': {'bar', 'baz'}})
    assert isinstance

# Generated at 2022-06-17 14:56:26.367917
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs constructor works as expected
    """
    test_dict = {'a': 'b', 'c': 'd', 'e': {'f': 'g', 'h': 'i'}, 'j': [1, 2, 3], 'k': {1, 2, 3}}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert isinstance(test_args, ImmutableDict)
    assert isinstance(test_args['e'], ImmutableDict)
    assert isinstance(test_args['j'], tuple)
    assert isinstance(test_args['k'], frozenset)

# Generated at 2022-06-17 14:56:30.693868
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:56:34.512018
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:56:47.880692
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six.moves import builtins

    # Test that the constructor of CLIArgs works
    # This is a unit test for the constructor of class CLIArgs
    # The constructor of class CLIArgs is defined in the file
    # lib/ansible/module_utils/common/arguments.py
    # The constructor of class CLIArgs is called in the file
    # lib/ansible/cli/__init__.py
    # The function ansible.cli.__init__.display.cli() calls the function
    # ansible.cli.__init__.display.display()
    # The

# Generated at 2022-06-17 14:56:50.484069
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {'foo': 'bar', 'baz': 'qux'}
    cli_args = CLIArgs(args)
    assert cli_args == args


# Generated at 2022-06-17 14:56:57.467587
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert D() is D()
    assert A() is B()
    assert A() is C()
    assert A() is D()
    assert B() is C()
    assert B() is D()
    assert C() is D()

# Generated at 2022-06-17 14:57:06.898156
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 1, 'b': 2, 'c': [1, 2, 3]})
    assert args['a'] == 1
    assert args['b'] == 2
    assert args['c'] == (1, 2, 3)
    assert args.get('d') is None
    assert args.get('d', 4) == 4
    assert args.get('a', 4) == 1
    assert args.get('a', 4) != 4
    assert args.get('a') == 1
    assert args.get('a') != 4
    assert args.get('a', 4) != args.get('a')
    assert args.get('a', 4) != args.get('b')
    assert args.get('a', 4) != args.get('c')
    assert args.get('b', 4) != args

# Generated at 2022-06-17 14:57:14.885511
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode

    # Test the constructor
    args = GlobalCLIArgs({'foo': 'bar'})
    assert isinstance(args, ImmutableDict)
    assert is_immutable(args)
    assert args == {'foo': 'bar'}

    # Test the constructor with a nested dict
    args = GlobalCLIArgs({'foo': {'bar': 'baz'}})
    assert isinstance(args, ImmutableDict)
    assert is_immutable(args)
    assert args

# Generated at 2022-06-17 14:57:19.240431
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(TestClass(), TestClass)
    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:57:30.907105
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import HumanReadable
    from ansible.module_utils.common.text.formatters import Formatter
    from ansible.module_utils.common.text.formatters import VerboseStr
    from ansible.module_utils.common.text.formatters import to_bytes
    from ansible.module_utils.common.text.formatters import to_native
    from ansible.module_utils.common.text.formatters import to_text
    from ansible.module_utils.common.text.formatters import to_unicode
    from ansible.module_utils.common.text.formatters import to_bytes

# Generated at 2022-06-17 14:57:35.440633
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:57:42.020222
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is B()
    assert A() is C()
    assert B() is C()

# Generated at 2022-06-17 14:57:44.549814
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:57:47.630326
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:57:58.527745
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar', action='append')
    parser.add_argument('--baz', action='append_const', const=True)
    parser.add_argument('--qux', action='append_const', const=False)
    parser.add_argument('--quux', action='append_const', const=None)
    parser.add_argument('--corge', action='append_const', const=1)
    parser.add_argument('--grault', action='append_const', const=1.0)
    parser.add_argument('--garply', action='append_const', const='1')
    parser.add_argument('--waldo', action='append_const', const=['1'])

# Generated at 2022-06-17 14:58:09.125173
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a simple dictionary
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict

    # Test with a dictionary with nested dictionaries
    test_dict = {'a': 1, 'b': 2, 'c': {'d': 4, 'e': 5}}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict

    # Test with a dictionary with nested lists
    test_dict = {'a': 1, 'b': 2, 'c': [4, 5]}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict

    # Test with a dictionary with nested sets

# Generated at 2022-06-17 14:58:15.486674
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:58:18.767916
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        pass

    class Test2(_ABCSingleton):
        pass

    assert Test() is Test()
    assert Test2() is Test2()
    assert Test() is not Test2()

# Generated at 2022-06-17 14:58:23.289651
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:58:45.522533
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    import json
    import os
    import sys

    # Create a dictionary of command line arguments

# Generated at 2022-06-17 14:58:49.995204
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test that GlobalCLIArgs is a Singleton and that it is immutable
    """
    # Test that GlobalCLIArgs is a Singleton
    assert GlobalCLIArgs() is GlobalCLIArgs()

    # Test that GlobalCLIArgs is immutable
    try:
        GlobalCLIArgs()['foo'] = 'bar'
    except TypeError:
        pass
    else:
        assert False, 'GlobalCLIArgs is not immutable'

# Generated at 2022-06-17 14:58:56.955046
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    GlobalCLIArgs.from_options(args)

# Generated at 2022-06-17 14:58:59.291869
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:59:06.655624
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', default='bar')
    parser.add_argument('--baz', default='qux')
    parser.add_argument('--quux', default='corge')
    parser.add_argument('--grault', default='garply')
    parser.add_argument('--waldo', default='fred')
    parser.add_argument('--plugh', default='xyzzy')
    parser.add_argument('--thud', default='wibble')
    parser.add_argument('--spam', default='eggs')
    parser.add_argument('--ham', default='bacon')
    parser.add_argument('--spam_list', default=['eggs', 'eggs'], nargs='+')


# Generated at 2022-06-17 14:59:17.456135
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'foo': 'bar'})
    assert cli_args['foo'] == 'bar'

    # Test that we can't modify the CLIArgs object
    try:
        cli_args['foo'] = 'baz'
    except TypeError:
        pass
    else:
        assert False, 'Should not be able to modify CLIArgs object'

    # Test that we can't modify the CLIArgs object
    try:
        cli_args.update({'foo': 'baz'})
    except TypeError:
        pass
    else:
        assert False, 'Should not be able to modify CLIArgs object'

    # Test that we can't modify the CLIArgs object

# Generated at 2022-06-17 14:59:28.725916
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs is immutable
    """
    args = CLIArgs({'a': 1, 'b': 2})
    assert args['a'] == 1
    assert args['b'] == 2
    assert args.get('c') is None
    assert args.get('c', 3) == 3
    assert args.get('a', 3) == 1
    assert args.get('a') == 1
    assert args.get('b') == 2
    assert args.get('b', 3) == 2
    assert args.get('c', 3) == 3
    assert args.get('c') is None

    try:
        args['c'] = 3
        assert False
    except TypeError:
        pass

    try:
        args['a'] = 3
        assert False
    except TypeError:
        pass


# Generated at 2022-06-17 14:59:33.014133
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a dictionary
    test_dict = {'a': 'b', 'c': 'd'}
    cli_args = CLIArgs(test_dict)
    assert cli_args == test_dict

    # Test with a list
    test_list = ['a', 'b', 'c', 'd']
    cli_args = CLIArgs(test_list)
    assert cli_args == test_list

    # Test with a set
    test_set = {'a', 'b', 'c', 'd'}
    cli_args = CLIArgs(test_set)
    assert cli_args == test_set

    # Test with a tuple
    test_tuple = ('a', 'b', 'c', 'd')
    cli_args = CLIArgs(test_tuple)
    assert cli

# Generated at 2022-06-17 14:59:44.428443
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    global_args = GlobalCLIArgs.from_options(args)
    assert global_args['foo'] is True
    assert global_args['bar'] is True
    assert global_args['baz'] is False

# Generated at 2022-06-17 14:59:54.301493
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest


# Generated at 2022-06-17 15:00:20.700407
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar')

    args = parser.parse_args(['--foo', 'foo', '--bar', 'bar'])
    GlobalCLIArgs.from_options(args)

    # Make sure we can't change the args
    try:
        GlobalCLIArgs['foo'] = 'baz'
    except TypeError:
        pass
    else:
        sys.exit(1)

    # Make sure we can't change the args
    try:
        GlobalCLIArgs['foo']
    except TypeError:
        sys.exit(1)

    # Make sure we can't change the args

# Generated at 2022-06-17 15:00:26.201096
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 15:00:32.456015
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type

    # Test that we can create a CLIArgs object from a dict
    test_dict = {
        'foo': 'bar',
        'baz': 'qux',
    }
    test_cli_args = CLIArgs(test_dict)
    assert isinstance(test_cli_args, ImmutableDict)
    assert isinstance(test_cli_args, CLIArgs)
    assert test_cli_args == test_dict

    # Test that we can

# Generated at 2022-06-17 15:00:45.068637
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])

    # Make sure the constructor works
    GlobalCLIArgs.from_options(args)

    # Make sure the constructor works with no arguments
    GlobalCLIArgs.from_options(parser.parse_args([]))

    # Make sure we can't change the object
    try:
        GlobalCLIArgs.from_options(args)['foo'] = False
    except TypeError:
        pass
    else:
        sys.exit(1)

    # Make

# Generated at 2022-06-17 15:00:53.572047
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])

    GlobalCLIArgs.from_options(args)
    assert GlobalCLIArgs.instance().foo is True
    assert GlobalCLIArgs.instance().bar is True
    assert GlobalCLIArgs.instance().baz is False

# Generated at 2022-06-17 15:01:01.812360
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('-a', action='store_true')
    parser.add_argument('-b', action='store_true')
    parser.add_argument('-c', action='store_true')
    parser.add_argument('-d', action='store_true')

    args = parser.parse_args(['-a', '-b', '-c', '-d'])
    cli_args = CLIArgs.from_options(args)

    assert cli_args['a'] is True
    assert cli_args['b'] is True
    assert cli_args['c'] is True
    assert cli_args['d'] is True


# Generated at 2022-06-17 15:01:10.676609
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that the constructor of class CLIArgs works as expected.
    """
    # Test that the constructor works as expected
    test_dict = {'a': 1, 'b': 2}
    test_cli_args = CLIArgs(test_dict)
    assert test_cli_args == test_dict

    # Test that the constructor works as expected with nested dictionaries
    test_dict = {'a': 1, 'b': {'c': 2, 'd': 3}}
    test_cli_args = CLIArgs(test_dict)
    assert test_cli_args == test_dict

    # Test that the constructor works as expected with nested lists
    test_dict = {'a': 1, 'b': [1, 2, 3]}
    test_cli_args = CLIArgs(test_dict)

# Generated at 2022-06-17 15:01:16.602972
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    GlobalCLIArgs.from_options(args)

# Generated at 2022-06-17 15:01:20.917262
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that the constructor of CLIArgs works as expected
    # Create a dictionary of values to test
    test_dict = {'a': 'b', 'c': 'd'}
    # Create a CLIArgs object from the test dictionary
    test_cliargs = CLIArgs(test_dict)
    # Assert that the CLIArgs object is equal to the test dictionary
    assert test_cliargs == test_dict

# Generated at 2022-06-17 15:01:31.925627
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    options = Options(
        foo=1,
        bar=2,
        baz=3,
        qux=4,
        quux=5,
        corge=6,
        grault=7,
        garply=8,
        waldo=9,
        fred=10,
        plugh=11,
        xyzzy=12,
        thud=13,
    )

    args = CLIArgs.from_options(options)

    assert isinstance(args, ImmutableDict)

# Generated at 2022-06-17 15:02:13.108007
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
   

# Generated at 2022-06-17 15:02:17.423383
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 15:02:21.176242
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 15:02:31.293049
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys

# Generated at 2022-06-17 15:02:32.983551
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object):
        __metaclass__ = _ABCSingleton

    assert Test() is Test()

# Generated at 2022-06-17 15:02:46.117259
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.module_utils.common.collections import ImmutableSet
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableSequence
    from ansible.module_utils.common.collections import ImmutableMapping
    from ansible.module_utils.common.collections import ImmutableContainer
    from ansible.module_utils.common.collections import MutableMapping
    from ansible.module_utils.common.collections import MutableSequence
    from ansible.module_utils.common.collections import MutableSet

# Generated at 2022-06-17 15:02:53.877369
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test empty dict
    assert CLIArgs({}) == {}

    # Test dict with one key
    assert CLIArgs({'a': 1}) == {'a': 1}

    # Test dict with multiple keys
    assert CLIArgs({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}

    # Test dict with nested dict
    assert CLIArgs({'a': {'b': 1}}) == {'a': {'b': 1}}

    # Test dict with nested list
    assert CLIArgs({'a': [1, 2, 3]}) == {'a': (1, 2, 3)}

    # Test dict with nested set
    assert CLIArgs({'a': {1, 2, 3}}) == {'a': frozenset({1, 2, 3})}

    # Test dict with nested tuple
   

# Generated at 2022-06-17 15:03:04.332824
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text


# Generated at 2022-06-17 15:03:05.602346
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 15:03:14.433299
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test CLIArgs constructor
    """
    # Test with a simple dict
    simple_dict = {'a': 1, 'b': 2, 'c': 3}
    cli_args = CLIArgs(simple_dict)
    assert cli_args == simple_dict

    # Test with a nested dict
    nested_dict = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    cli_args = CLIArgs(nested_dict)
    assert cli_args == nested_dict

    # Test with a list
    simple_list = [1, 2, 3]
    cli_args = CLIArgs(simple_list)
    assert cli_args == simple_list

    # Test with a nested list