

# Generated at 2022-06-17 14:53:41.702102
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:53:44.037531
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _TestClass(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(_TestClass(), _TestClass)

# Generated at 2022-06-17 14:53:48.578497
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:53:55.902682
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 'b', 'c': {'d': 'e', 'f': 'g'}, 'h': ['i', 'j', 'k']}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert test_args['a'] == 'b'
    assert test_args['c']['d'] == 'e'
    assert test_args['h'][0] == 'i'
    assert test_args['h'][1] == 'j'
    assert test_args['h'][2] == 'k'
    assert test_args.get('a') == 'b'
    assert test_args.get('c').get('d') == 'e'
    assert test_args.get('h')[0] == 'i'
    assert test

# Generated at 2022-06-17 14:54:05.672285
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    import json
    import os
    import sys

    # Create a dict of the command line arguments
    args = {}
    for arg in sys.argv:
        if '=' in arg:
            key, value = arg.split('=', 1)
            args[key] = value
        else:
            args[arg] = True

    # Create an instance of CLIArgs
    cli_args = CLIArgs(args)

    # Verify that the instance is immutable
    try:
        cli_args['foo'] = 'bar'
    except TypeError:
        pass
    else:
        raise AssertionError('Expected TypeError')

    # Verify that the instance

# Generated at 2022-06-17 14:54:09.784397
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:54:14.063546
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    GlobalCLIArgs.from_options(args)

# Generated at 2022-06-17 14:54:21.362624
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import ansible.module_utils.common.argparse as argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args([])
    GlobalCLIArgs.from_options(args)

# Generated at 2022-06-17 14:54:24.629600
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert isinstance(TestClass(), TestClass)
    assert isinstance(TestClass(), Singleton)
    assert isinstance(TestClass(), ABCMeta)

# Generated at 2022-06-17 14:54:35.243787
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode

    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({})
    assert isinstance(cli_args, ImmutableDict)

    # Test that we can create a CLIArgs object with a dict
    cli_args = CLIArgs({'a': 'b'})
    assert isinstance(cli_args, ImmutableDict)

    # Test that we can create a CLIArgs object with a dict with a list

# Generated at 2022-06-17 14:54:46.494415
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs constructor works as expected
    """
    # Test that we can create an empty CLIArgs object
    cli_args = CLIArgs({})
    assert cli_args == {}

    # Test that we can create a CLIArgs object with a single key
    cli_args = CLIArgs({'foo': 'bar'})
    assert cli_args == {'foo': 'bar'}

    # Test that we can create a CLIArgs object with a single key and a value that is a list
    cli_args = CLIArgs({'foo': ['bar', 'baz']})
    assert cli_args == {'foo': ('bar', 'baz')}

    # Test that we can create a CLIArgs object with a single key and a value that is a dict

# Generated at 2022-06-17 14:54:54.423200
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    import copy
    import types

    # Make sure that we can't modify the CLIArgs object
    args = CLIArgs({'foo': 'bar'})
    assert args['foo'] == 'bar'
    try:
        args['foo'] = 'baz'
    except TypeError:
        pass
    else:
        assert False, 'Should not be able to modify CLIArgs object'

    # Make sure that we can't modify the CLIArgs object's children
    args = CLIArgs({'foo': {'bar': 'baz'}})
    assert args['foo']['bar'] == 'baz'
    try:
        args['foo']['bar'] = 'qux'
    except TypeError:
        pass
    else:
        assert False, 'Should not be able to modify CLIArgs object'

    # Make sure

# Generated at 2022-06-17 14:54:56.937549
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.utils.display import Display
    display = Display()
    cli = CLI(args=sys.argv[1:], display=display)
    options = cli.parse()
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-17 14:55:01.274955
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:55:09.791082
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that the constructor works
    args = CLIArgs({'a': 1, 'b': 2})
    assert args['a'] == 1
    assert args['b'] == 2

    # Test that the constructor works with a nested dictionary
    args = CLIArgs({'a': {'b': {'c': 3}}})
    assert args['a']['b']['c'] == 3

    # Test that the constructor works with a nested list
    args = CLIArgs({'a': [1, 2, 3]})
    assert args['a'][0] == 1
    assert args['a'][1] == 2
    assert args['a'][2] == 3

    # Test that the constructor works with a nested set
    args = CLIArgs({'a': {1, 2, 3}})
    assert 1 in args['a']
   

# Generated at 2022-06-17 14:55:18.166440
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        def __init__(self):
            self.foo = 'bar'
            self.baz = ['qux']
            self.quux = {'corge': 'grault'}

    options = Options()
    args = CLIArgs.from_options(options)
    assert args['foo'] == 'bar'
    assert args['baz'] == ('qux',)
    assert args['quux'] == ImmutableDict({'corge': 'grault'})

# Generated at 2022-06-17 14:55:28.127741
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_list
    from ansible.module_utils.common.text.converters import to_set
    from ansible.module_utils.common.text.converters import to_dict
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-17 14:55:37.877457
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_set
    from ansible.module_utils.common.collections import is_mapping
    from ansible.module_utils.common.collections import is_container
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.collections import is_string
    from ansible.module_utils.common.collections import is_binary
    from ansible.module_utils.common.collections import is_text

    # Test that we can create a GlobalCLIArgs object
   

# Generated at 2022-06-17 14:55:48.757466
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_GlobalCLIArgs(self):
            # Check that we can create a GlobalCLIArgs object
            # and that it is a singleton
            args = GlobalCLIArgs({'foo': 'bar'})
            self.assertEqual(args['foo'], 'bar')
            args2 = GlobalCLIArgs({'foo': 'baz'})
            self.assertEqual(args2['foo'], 'bar')

    # Run the unit test
    suite = unittest.TestLoader().loadTestsFromModule(sys.modules[__name__])
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-17 14:55:58.504455
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:56:02.363578
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:56:03.751913
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:56:10.725580
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    options = parser.parse_args(sys.argv[1:])
    args = GlobalCLIArgs.from_options(options)
    assert isinstance(args, GlobalCLIArgs)
    assert isinstance(args, CLIArgs)
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, Mapping)
    assert isinstance(args, Container)
    assert isinstance(args, Set)
    assert isinstance(args, Sequence)
    assert isinstance(args, object)

# Generated at 2022-06-17 14:56:16.520445
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': [5, 6, 7]}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert isinstance(test_args, ImmutableDict)
    assert isinstance(test_args['c'], ImmutableDict)
    assert isinstance(test_args['f'], tuple)
    assert test_args['f'] == (5, 6, 7)

# Generated at 2022-06-17 14:56:18.726771
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:56:21.877823
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:56:24.740275
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:56:33.226354
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'a': 'b'})
    assert cli_args['a'] == 'b'

    # Test that we can create a CLIArgs object with a nested dict
    cli_args = CLIArgs({'a': {'b': 'c'}})
    assert cli_args['a']['b'] == 'c'

    # Test that we can create a CLIArgs object with a nested list
    cli_args = CLIArgs({'a': ['b', 'c']})
    assert cli_args['a'][0] == 'b'
    assert cli_args['a'][1] == 'c'

    # Test that we can create a CLIArgs object with a nested set

# Generated at 2022-06-17 14:56:46.377919
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import os
    import tempfile
    import shutil
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file in the temporary directory
    fd, tmpfile2 = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a temporary file in the temporary directory
    fd, tmpfile3 = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a temporary file in the temporary directory
    fd, tmpfile4 = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a temporary file in the

# Generated at 2022-06-17 14:56:56.926180
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest

    # This is a hack to make sure we don't accidentally use the real command line arguments
    # when we are running unit tests.  We don't want to accidentally use the real command line
    # arguments because then we would be testing the code that parses the command line arguments
    # instead of testing the code that uses the command line arguments.
    sys.argv = ['ansible-playbook']

    from ansible.cli import CLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.display import Display

    class TestGlobalCLIArgs(unittest.TestCase):
        def setUp(self):
            self.display = Display()
            self.loader = DataLoader()
            self.options = CLI

# Generated at 2022-06-17 14:57:05.892889
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'a': 'b'})
    assert cli_args['a'] == 'b'

    # Test that we can create a CLIArgs object from an options object
    class Options(object):
        a = 'b'
    cli_args = CLIArgs.from_options(Options())
    assert cli_args['a'] == 'b'

    # Test that we can create a CLIArgs object from an options object with a nested object
    class Options(object):
        class Nested(object):
            a = 'b'
    cli_args = CLIArgs.from_options(Options())
    assert cli_args['nested']['a'] == 'b'

    # Test that we can create a CLIArgs object from an options object with a nested object

# Generated at 2022-06-17 14:57:11.145957
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:57:17.825071
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    GlobalCLIArgs.from_options(args)
    sys.exit(0)

# Generated at 2022-06-17 14:57:27.806523
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that the constructor works
    args = CLIArgs({'foo': 'bar', 'baz': 'qux'})
    assert args['foo'] == 'bar'
    assert args['baz'] == 'qux'

    # Test that the constructor works with a nested dict
    args = CLIArgs({'foo': {'bar': 'baz'}})
    assert args['foo']['bar'] == 'baz'

    # Test that the constructor works with a nested list
    args = CLIArgs({'foo': ['bar', 'baz']})
    assert args['foo'][0] == 'bar'
    assert args['foo'][1] == 'baz'

    # Test that the constructor works with a nested set
    args = CLIArgs({'foo': {'bar', 'baz'}})

# Generated at 2022-06-17 14:57:32.925130
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': [5, 6, 7]})
    assert args.a == 1
    assert args.b == 2
    assert args.c.d == 3
    assert args.c.e == 4
    assert args.f[0] == 5
    assert args.f[1] == 6
    assert args.f[2] == 7

# Generated at 2022-06-17 14:57:37.848047
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton(_ABCSingleton):
        pass

    class TestSingleton2(_ABCSingleton):
        pass

    assert TestSingleton() is TestSingleton()
    assert TestSingleton2() is TestSingleton2()

# Generated at 2022-06-17 14:57:40.377524
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:57:44.050158
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:57:49.296517
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:57:56.729508
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 'b', 'c': {'d': 'e'}, 'f': ['g', {'h': 'i'}]}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert isinstance(test_args, ImmutableDict)
    assert isinstance(test_args['c'], ImmutableDict)
    assert isinstance(test_args['f'], tuple)
    assert isinstance(test_args['f'][1], ImmutableDict)

# Generated at 2022-06-17 14:58:06.643296
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    GlobalCLIArgs.from_options(args)
    assert GlobalCLIArgs.instance().foo is True
    assert GlobalCLIArgs.instance().bar is True
    assert GlobalCLIArgs.instance().baz is False

# Generated at 2022-06-17 14:58:13.272831
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import pytest
    from ansible.module_utils.common.collections import is_immutable

    # Test that we can create a CLIArgs object
    args = CLIArgs({'foo': 'bar'})
    assert args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from an optparse.Values object
    from optparse import Values
    options = Values({'foo': 'bar'})
    args = CLIArgs.from_options(options)
    assert args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from an argparse.Namespace object
    from argparse import Namespace
    options = Namespace(foo='bar')
    args = CLIArgs.from_options(options)
    assert args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from

# Generated at 2022-06-17 14:58:14.790838
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Test that we can create a GlobalCLIArgs object
    GlobalCLIArgs()

# Generated at 2022-06-17 14:58:24.456501
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel

    class TestGlobalCLIArgs(unittest.TestCase):
        def setUp(self):
            self.display = Display()
            self.sentinel = Sentinel()

        def tearDown(self):
            pass


# Generated at 2022-06-17 14:58:29.214559
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:58:32.815126
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:58:46.074419
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_cli_args = CLIArgs(test_dict)
    assert test_cli_args['a'] == 1
    assert test_cli_args['b'] == 2
    assert test_cli_args['c'] == 3
    assert test_cli_args == test_dict
    assert test_cli_args != {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert test_cli_args != {'a': 1, 'b': 2, 'c': 4}
    assert test_cli_args != {'a': 1, 'b': 2}
    assert test_cli_args != {'a': 1}

# Generated at 2022-06-17 14:58:48.818921
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:59:02.646519
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'foo': 'bar'})
    assert cli_args['foo'] == 'bar'

    # Test that we can create a CLIArgs object with a nested dict
    cli_args = CLIArgs({'foo': {'bar': 'baz'}})
    assert cli_args['foo']['bar'] == 'baz'

    # Test that we can create a CLIArgs object with a nested list
    cli_args = CLIArgs({'foo': ['bar', 'baz']})
    assert cli_args['foo'][0] == 'bar'

    # Test that we can create a CLIArgs object with a nested set
    cli_args = CLIArgs({'foo': {'bar', 'baz'}})
    assert 'bar'

# Generated at 2022-06-17 14:59:13.830637
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create an instance of CLIArgs
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    args = CLIArgs(test_dict)
    assert args == test_dict
    assert isinstance(args, ImmutableDict)

    # Test that we can create an instance of CLIArgs from an options object
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    class Options(object):
        def __init__(self, mapping):
            for key, value in mapping.items():
                setattr(self, key, value)
    options = Options(test_dict)
    args = CLIArgs.from_options(options)
    assert args == test_dict
    assert isinstance(args, ImmutableDict)

    # Test that we can create an instance

# Generated at 2022-06-17 14:59:23.972068
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'foo': 'bar'})
    assert cli_args == {'foo': 'bar'}

    # Test that we can create a CLIArgs object with a nested dict
    cli_args = CLIArgs({'foo': {'bar': 'baz'}})
    assert cli_args == {'foo': {'bar': 'baz'}}

    # Test that we can create a CLIArgs object with a nested list
    cli_args = CLIArgs({'foo': ['bar', 'baz']})
    assert cli_args == {'foo': ('bar', 'baz')}

    # Test that we can create a CLIArgs object with a nested set

# Generated at 2022-06-17 14:59:32.817251
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    import copy
    import types

    # Test that we can create a CLIArgs object
    args = CLIArgs({'foo': 'bar'})
    assert isinstance(args, CLIArgs)

    # Test that we can't modify the object
    try:
        args['foo'] = 'baz'
    except TypeError:
        pass
    else:
        assert False, "Should not be able to modify CLIArgs object"

    # Test that we can't modify the object
    try:
        args.update({'foo': 'baz'})
    except TypeError:
        pass
    else:
        assert False, "Should not be able to modify CLIArgs object"

    # Test that we can't modify the object
    try:
        args.pop('foo')
    except TypeError:
        pass

# Generated at 2022-06-17 14:59:46.422343
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.utils.display import Display

    display = Display()
    cli = CLI(args=sys.argv[1:], display=display)
    options = cli.parse()
    args = GlobalCLIArgs.from_options(options)
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, GlobalCLIArgs)
    assert isinstance(args, CLIArgs)
    assert isinstance(args, Mapping)
    assert isinstance(args, Container)
    assert isinstance(args, Sequence)
    assert isinstance(args, Set)

# Generated at 2022-06-17 14:59:56.172230
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar', action='append')
    parser.add_argument('--baz', nargs='+')
    parser.add_argument('--qux', nargs='*')
    parser.add_argument('--quux', nargs='?')
    parser.add_argument('--corge', type=int)
    parser.add_argument('--grault', type=int, nargs='+')
    parser.add_argument('--garply', type=int, nargs='*')
    parser.add_argument('--waldo', type=int, nargs='?')
    parser.add_argument('--fred', type=int, nargs='+', action='append')

# Generated at 2022-06-17 15:00:07.362099
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a dictionary
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict

    # Test with a list
    test_list = [1, 2, 3]
    test_args = CLIArgs(test_list)
    assert test_args == test_list

    # Test with a set
    test_set = set([1, 2, 3])
    test_args = CLIArgs(test_set)
    assert test_args == test_set

    # Test with a tuple
    test_tuple = (1, 2, 3)
    test_args = CLIArgs(test_tuple)
    assert test_args == test_tuple

    # Test with a string

# Generated at 2022-06-17 15:00:17.835892
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    GlobalCLIArgs.from_options(args)
    assert GlobalCLIArgs()['foo'] is True
    assert GlobalCLIArgs()['bar'] is True
    assert GlobalCLIArgs()['baz'] is False
    sys.exit(0)

# Generated at 2022-06-17 15:00:19.294155
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 15:00:25.915456
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', default='bar')
    parser.add_argument('--baz', default='qux')
    options = parser.parse_args(sys.argv[1:])
    args = GlobalCLIArgs.from_options(options)
    assert args['foo'] == 'bar'
    assert args['baz'] == 'qux'

# Generated at 2022-06-17 15:00:29.791378
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 15:00:40.166872
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_false')
    parser.add_argument('--qux', nargs='+')
    parser.add_argument('--quux', nargs='*')
    parser.add_argument('--corge', nargs='?')
    parser.add_argument('--grault', type=int)
    parser.add_argument('--garply', type=float)
    parser.add_argument('--waldo', type=complex)
    parser.add_argument('--fred', type=str)
    parser.add_argument('--plugh', type=text_type)
   

# Generated at 2022-06-17 15:00:58.077298
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_dict_copy = test_dict.copy()
    test_dict_copy['d'] = 4
    test_dict_copy['e'] = 5
    test_dict_copy['f'] = 6
    test_dict_copy['g'] = 7
    test_dict_copy['h'] = 8
    test_dict_copy['i'] = 9
    test_dict_copy['j'] = 10
    test_dict_copy['k'] = 11
    test_dict_copy['l'] = 12
    test_dict_copy['m'] = 13
    test_dict_copy['n'] = 14
    test_dict_copy['o'] = 15
    test_dict_copy['p'] = 16

# Generated at 2022-06-17 15:01:06.721739
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        def __init__(self):
            self.foo = 'bar'
            self.baz = 'qux'

    options = Options()
    cli_args = CLIArgs.from_options(options)
    assert cli_args['foo'] == 'bar'
    assert cli_args['baz'] == 'qux'
    assert cli_args.get('foo') == 'bar'
    assert cli_args.get('baz') == 'qux'
    assert cli_args.get('quux') is None



# Generated at 2022-06-17 15:01:17.806986
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import collections
    import copy
    import sys

    # Make sure we can't create more than one instance of GlobalCLIArgs
    try:
        GlobalCLIArgs()
        assert False, "GlobalCLIArgs() should fail"
    except TypeError:
        pass

    # Make sure we can't create more than one instance of GlobalCLIArgs
    try:
        GlobalCLIArgs.__new__(GlobalCLIArgs)
        assert False, "GlobalCLIArgs.__new__(GlobalCLIArgs) should fail"
    except TypeError:
        pass

    # Make sure we can't create more than one instance of GlobalCLIArgs
    try:
        GlobalCLIArgs.__call__()
        assert False, "GlobalCLIArgs.__call__() should fail"
    except TypeError:
        pass

    # Make sure we

# Generated at 2022-06-17 15:01:24.428627
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest

    class TestGlobalCLIArgs(unittest.TestCase):
        def setUp(self):
            self.old_sys_argv = sys.argv
            sys.argv = ['ansible-playbook', '-i', 'hosts', 'playbook.yml']

        def tearDown(self):
            sys.argv = self.old_sys_argv

        def test_GlobalCLIArgs(self):
            from ansible.cli import CLI
            from ansible.utils.display import Display
            display = Display()
            cli = CLI(args=sys.argv[1:], display=display)
            cli.parse()
            cli_args = cli.options
            global_cli_args = GlobalCLIArgs.from_options(cli_args)


# Generated at 2022-06-17 15:01:33.780395
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 1, 'b': {'c': 2, 'd': {'e': 3}}, 'f': [4, 5, 6]})
    assert args['a'] == 1
    assert args['b']['c'] == 2
    assert args['b']['d']['e'] == 3
    assert args['f'][0] == 4
    assert args['f'][1] == 5
    assert args['f'][2] == 6
    assert isinstance(args, ImmutableDict)
    assert isinstance(args['b'], ImmutableDict)
    assert isinstance(args['b']['d'], ImmutableDict)
    assert isinstance(args['f'], tuple)

# Generated at 2022-06-17 15:01:38.046565
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # pylint: disable=protected-access
    assert GlobalCLIArgs._instance is None
    GlobalCLIArgs.from_options(None)
    assert GlobalCLIArgs._instance is not None

# Generated at 2022-06-17 15:01:48.088080
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    args = CLIArgs({'foo': 'bar'})
    assert args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from an optparse.Values object
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars_from_file
    from ansible.utils.vars import load_vars_from_yaml_file
    from ansible.utils.vars import load_vars_from_inventory
    from ansible.utils.vars import load_vars_from_task_vars

# Generated at 2022-06-17 15:01:57.917424
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({})
    assert isinstance(cli_args, CLIArgs)

    # Test that we can create a CLIArgs object from a dict
    cli_args = CLIArgs({'a': 'a', 'b': 'b'})
    assert isinstance(cli_args, CLIArgs)
    assert cli_args['a'] == 'a'
    assert cli_args['b'] == 'b'

    # Test that we can create a CLIArgs object from a dict with nested dicts
    cli_

# Generated at 2022-06-17 15:02:07.311721
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test the CLIArgs constructor.

    This test is not part of the normal unit test suite because it is not a test of the CLIArgs
    class itself, but rather a test of the _make_immutable() function which is used by the
    CLIArgs constructor.
    """
    # Test that _make_immutable() can handle all of the container types
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_list = [1, 2, 3]
    test_set = {1, 2, 3}
    test_tuple = (1, 2, 3)
    test_str = 'abc'
    test_unicode = u'abc'
    test_bytes = b'abc'
    test_int = 1
    test_float = 1.0
    test_bool = True


# Generated at 2022-06-17 15:02:18.032096
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import format_value
    from ansible.module_utils.common.text.formatters import format_value_strict
    from ansible.module_utils.common.text.formatters import format_value_strict_quotes
    from ansible.module_utils.common.text.formatters import format_value_utf8
    from ansible.module_utils.common.text.formatters import format_value_utf8_strict
    from ansible.module_utils.common.text.formatters import format_value_

# Generated at 2022-06-17 15:02:47.213787
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test CLIArgs constructor
    """
    # Test that the constructor converts all mutable types to immutable types
    test_dict = {
        'a': 'a',
        'b': [1, 2, 3],
        'c': {'d': 'd', 'e': 'e'},
        'f': (1, 2, 3),
        'g': {1, 2, 3},
    }
    cli_args = CLIArgs(test_dict)
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args['b'], tuple)
    assert isinstance(cli_args['c'], ImmutableDict)
    assert isinstance(cli_args['f'], tuple)
    assert isinstance(cli_args['g'], frozenset)

# Generated at 2022-06-17 15:02:54.294712
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test the CLIArgs constructor
    """
    # Test that we can create an instance of CLIArgs
    cli_args = CLIArgs({'foo': 'bar'})
    assert cli_args['foo'] == 'bar'

    # Test that we can create an instance of CLIArgs with a nested dict
    cli_args = CLIArgs({'foo': {'bar': 'baz'}})
    assert cli_args['foo']['bar'] == 'baz'

    # Test that we can create an instance of CLIArgs with a nested list
    cli_args = CLIArgs({'foo': ['bar', 'baz']})
    assert cli_args['foo'][0] == 'bar'
    assert cli_args['foo'][1] == 'baz'

    # Test that we can create an instance of

# Generated at 2022-06-17 15:03:03.948518
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(C):
        pass

    class F(D, E):
        pass

    assert issubclass(A, A)
    assert issubclass(B, A)
    assert issubclass(C, A)
    assert issubclass(D, A)
    assert issubclass(E, A)
    assert issubclass(F, A)

    assert issubclass(D, B)
    assert issubclass(D, C)
    assert issubclass(F, D)
    assert issubclass(F, E)

# Generated at 2022-06-17 15:03:07.996032
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel

    display = Display()
    sentinel = Sentinel()

    # Test that the constructor works
    args = GlobalCLIArgs({'foo': 'bar'})
    assert isinstance(args, ImmutableDict)
    assert args['foo'] == 'bar'

    # Test that the constructor works with a Display object
    args = GlobalCLIArgs({'display': display})
    assert isinstance(args, ImmutableDict)
    assert args['display'] == display

    # Test that the constructor works with a Sentinel object
    args = GlobalCLIArgs({'sentinel': sentinel})

# Generated at 2022-06-17 15:03:19.005386
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='append')
    parser.add_argument('--qux', nargs='+')
    parser.add_argument('--quux', nargs='*')
    parser.add_argument('--corge', nargs=2)
    parser.add_argument('--grault', nargs=3)
    parser.add_argument('--garply', nargs=4)
    parser.add_argument('--waldo', nargs=5)
    parser.add_argument('--fred', nargs=6)
    parser.add_argument('--plugh', nargs=7)
    parser.add

# Generated at 2022-06-17 15:03:21.570199
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert B() is not C()
    assert A() is not C()

# Generated at 2022-06-17 15:03:28.376228
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()