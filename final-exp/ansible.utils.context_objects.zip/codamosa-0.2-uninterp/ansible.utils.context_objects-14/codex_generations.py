

# Generated at 2022-06-17 14:53:41.629228
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _TestABCSingleton(_ABCSingleton):
        pass

    class _TestABCSingleton2(_ABCSingleton):
        pass

    assert _TestABCSingleton is _TestABCSingleton2

# Generated at 2022-06-17 14:53:48.024281
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', default='bar')
    parser.add_argument('--baz', default='qux')
    args = parser.parse_args(sys.argv[1:])
    cli_args = CLIArgs.from_options(args)
    assert cli_args['foo'] == 'bar'
    assert cli_args['baz'] == 'qux'


# Generated at 2022-06-17 14:53:49.792869
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:53:52.693092
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:54:03.245721
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that the constructor of CLIArgs works as expected
    # Test that the constructor of CLIArgs works as expected
    # Create a dictionary
    test_dict = {'a': 'b', 'c': 'd'}
    # Create a CLIArgs object from the dictionary
    test_CLIArgs = CLIArgs(test_dict)
    # Check that the CLIArgs object is immutable
    try:
        test_CLIArgs['a'] = 'e'
    except TypeError:
        pass
    else:
        assert False, "CLIArgs object is not immutable"
    # Check that the CLIArgs object is a dictionary
    assert isinstance(test_CLIArgs, dict), "CLIArgs object is not a dictionary"
    # Check that the CLIArgs object has the correct values

# Generated at 2022-06-17 14:54:11.805684
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.module_utils.common.collections import ImmutableSet
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableSequence
    from ansible.module_utils.common.collections import ImmutableMapping
    from ansible.module_utils.common.collections import ImmutableContainer
    from ansible.module_utils.common.collections import MutableMapping
    from ansible.module_utils.common.collections import MutableSequence
    from ansible.module_utils.common.collections import MutableSet

# Generated at 2022-06-17 14:54:19.407714
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs constructor works as expected
    """
    test_dict = {'a': 'b', 'c': 'd'}
    test_obj = CLIArgs(test_dict)
    assert test_obj['a'] == 'b'
    assert test_obj['c'] == 'd'
    assert test_obj == test_dict
    assert test_obj != {'a': 'b', 'c': 'd'}
    assert test_obj != {'a': 'b', 'c': 'd', 'e': 'f'}
    assert test_obj != {'a': 'b', 'c': 'd', 'e': 'f', 'g': 'h'}

# Generated at 2022-06-17 14:54:23.465522
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict

    # Test that we can create a GlobalCLIArgs object
    GlobalCLIArgs({})

    # Test that we can't create a second GlobalCLIArgs object
    with pytest.raises(TypeError):
        GlobalCLIArgs({})

    # Test that we can't create a GlobalCLIArgs object from a non-immutable dict
    with pytest.raises(TypeError):
        GlobalCLIArgs({'a': {'b': 'c'}})

    # Test that we can create a GlobalCLIArgs object from an ImmutableDict
    GlobalCLIArgs(ImmutableDict({'a': {'b': 'c'}}))

# Generated at 2022-06-17 14:54:34.112178
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import HumanReadable
    from ansible.module_utils.common.text.formatters import Formatter
    from ansible.module_utils.common.text.formatters import VerboseStr
    from ansible.module_utils.common.text.formatters import VerboseBytes
    from ansible.module_utils.common.text.formatters import to_bytes
    from ansible.module_utils.common.text.formatters import to_text
    from ansible.module_utils.common.text.formatters import to_native
    from ansible.module_utils.common.text.formatters import to_nice_

# Generated at 2022-06-17 14:54:40.445421
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    global_cli_args = GlobalCLIArgs.from_options(args)
    assert global_cli_args['foo']
    assert global_cli_args['bar']
    assert not global_cli_args['baz']
    assert isinstance(global_cli_args, GlobalCLIArgs)
    assert isinstance(global_cli_args, CLIArgs)
    assert isinstance(global_cli_args, ImmutableDict)

# Generated at 2022-06-17 14:54:52.438135
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    from ansible.module_utils.common.argparse import CLIArgumentParser

    parser = CLIArgumentParser(description='test')
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')

# Generated at 2022-06-17 14:55:04.069967
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 1, 'b': 2})
    assert args['a'] == 1
    assert args['b'] == 2
    assert len(args) == 2
    assert args.get('a') == 1
    assert args.get('c') is None
    assert args.get('c', 3) == 3
    assert args.get('a', 3) == 1
    assert 'a' in args
    assert 'c' not in args
    assert args.keys() == ['a', 'b']
    assert args.values() == [1, 2]
    assert args.items() == [('a', 1), ('b', 2)]
    assert args.pop('a') == 1
    assert len(args) == 1
    assert args.pop('c', 3) == 3
    assert len(args) == 1

# Generated at 2022-06-17 14:55:12.597265
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test the CLIArgs constructor
    """
    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'a': 1, 'b': 2})
    assert cli_args['a'] == 1
    assert cli_args['b'] == 2

    # Test that we can't modify the CLIArgs object
    try:
        cli_args['a'] = 3
    except TypeError:
        pass
    else:
        assert False, "Should not be able to modify a CLIArgs object"

    # Test that we can create a CLIArgs object with nested dictionaries
    cli_args = CLIArgs({'a': 1, 'b': {'c': 2, 'd': 3}})
    assert cli_args['a'] == 1

# Generated at 2022-06-17 14:55:24.474005
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3
    import json

    # Make sure that the constructor works
    test_dict = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': [5, 6, 7]}
    test_immutable_dict = CLIArgs(test_dict)
    assert isinstance(test_immutable_dict, ImmutableDict)
    assert test_immutable_dict == test_dict
    assert test_immutable_dict['c'] == test_dict['c']
    assert test_immutable_dict['f'] == test_dict['f']

    # Make sure that

# Generated at 2022-06-17 14:55:27.200060
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    assert A() is A()
    assert B() is B()
    assert A() is not B()
    assert B() is not A()

# Generated at 2022-06-17 14:55:32.388947
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:55:39.288200
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:55:44.872382
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:55:49.592586
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:55:53.572201
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:55:59.366191
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object):
        __metaclass__ = _ABCSingleton

    class Test2(object):
        __metaclass__ = _ABCSingleton

    assert Test() is Test()
    assert Test2() is Test2()
    assert Test() is not Test2()

# Generated at 2022-06-17 14:56:08.227024
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'foo': 'bar'})
    assert isinstance(cli_args, CLIArgs)
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from an options object
    class Options(object):
        def __init__(self, foo):
            self.foo = foo
    options = Options('bar')
    cli_args = CLIArgs.from_options(options)
    assert isinstance(cli_args, CLIArgs)
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from a nested options object

# Generated at 2022-06-17 14:56:16.893407
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_set
    from ansible.module_utils.common.collections import is_mapping

    # Test that we can create a GlobalCLIArgs object
    GlobalCLIArgs()

    # Test that we can create a GlobalCLIArgs object with a dict
    GlobalCLIArgs({'a': 1})

    # Test that we can create a GlobalCLIArgs object with a dict and that it is immutable
    a = GlobalCLIArgs({'a': 1})
    assert is_immutable(a)

    # Test that we

# Generated at 2022-06-17 14:56:23.079771
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', default='bar')
    parser.add_argument('--baz', default='qux')
    args = parser.parse_args([])

    global_args = GlobalCLIArgs.from_options(args)
    assert global_args['foo'] == 'bar'
    assert global_args['baz'] == 'qux'

# Generated at 2022-06-17 14:56:31.597790
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.module_utils.common.collections import ImmutableSet
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableSequence
    from ansible.module_utils.common.collections import ImmutableMapping
    from ansible.module_utils.common.collections import ImmutableContainer

    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'a': 'b'})
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args, ImmutableMapping)

# Generated at 2022-06-17 14:56:45.717304
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    test_args = CLIArgs({'foo': 'bar'})
    assert test_args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from an options object
    test_options = ImmutableDict({'foo': 'bar'})
    test_args = CLIArgs.from_options(test_options)
    assert test_args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from a nested options object
    test_options = ImmutableDict({'foo': {'bar': 'baz'}})
    test_args = CLIArgs.from_options(test_options)
    assert test_args['foo']['bar'] == 'baz'

    # Test that we can create a CLIArgs object from a nested options object
   

# Generated at 2022-06-17 14:56:57.860770
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser.add_argument

# Generated at 2022-06-17 14:57:07.227258
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can construct a CLIArgs object
    args = CLIArgs({'foo': 'bar'})
    assert isinstance(args, CLIArgs)
    assert isinstance(args, ImmutableDict)
    assert args['foo'] == 'bar'

    # Test that we can construct a CLIArgs object from an optparse.Values object
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.validation import check_type_bool
    from ansible.module_utils.common.validation import check_type_dict
    from ansible.module_utils.common.validation import check_type_list
    from ansible.module_utils.common.validation import check_type_string
    from ansible.module_utils.common.validation import check_type_string_

# Generated at 2022-06-17 14:57:15.009020
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes


# Generated at 2022-06-17 14:57:18.973449
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    a = A()
    b = B()
    assert a is b

# Generated at 2022-06-17 14:57:29.816688
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that the CLIArgs constructor works as expected
    """
    test_dict = {
        'foo': 'bar',
        'baz': ['qux', 'quux'],
        'corge': {
            'grault': 'garply',
            'waldo': 'fred',
            'plugh': ['xyzzy', 'thud'],
        },
    }
    cli_args = CLIArgs(test_dict)
    assert cli_args == test_dict
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args['baz'], tuple)
    assert isinstance(cli_args['corge'], ImmutableDict)
    assert isinstance(cli_args['corge']['plugh'], tuple)

# Generated at 2022-06-17 14:57:31.490467
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(Test(), Test)

# Generated at 2022-06-17 14:57:37.479087
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:57:47.866482
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a dict
    mapping = {'a': 1, 'b': 2}
    cli_args = CLIArgs(mapping)
    assert cli_args == mapping

    # Test with a list
    mapping = [1, 2, 3]
    cli_args = CLIArgs(mapping)
    assert cli_args == mapping

    # Test with a set
    mapping = {1, 2, 3}
    cli_args = CLIArgs(mapping)
    assert cli_args == mapping

    # Test with a tuple
    mapping = (1, 2, 3)
    cli_args = CLIArgs(mapping)
    assert cli_args == mapping

    # Test with a string
    mapping = '123'
    cli_args = CLIArgs(mapping)
    assert cli_args == mapping

# Generated at 2022-06-17 14:57:58.797708
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import is_immutable
    import ansible.module_utils.common.args as args
    import ansible.module_utils.common.json_utils as json_utils
    import ansible.module_utils.common.text.converters as text_converters
    import ansible.module_utils.common.text.formatters as text_formatters
    import ansible.module_utils.common.text.utils as text_utils
    import ansible.module_utils.common.validation as validation
    import ansible.module_utils.common.warnings as warnings
    import ansible.module_utils.common.yaml_utils as yaml_utils

# Generated at 2022-06-17 14:58:02.798858
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:58:05.998813
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:58:14.025653
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create an instance of CLIArgs
    cli_args = CLIArgs({'foo': 'bar'})
    assert isinstance(cli_args, CLIArgs)

    # Test that we can create an instance of CLIArgs from an options object
    from ansible.cli import CLI
    from ansible.utils.display import Display
    display = Display()
    cli = CLI(args=[], display=display)
    cli_args = CLIArgs.from_options(cli.parser.parse_args([]))
    assert isinstance(cli_args, CLIArgs)

    # Test that we can create an instance of GlobalCLIArgs
    cli_args = GlobalCLIArgs({'foo': 'bar'})
    assert isinstance(cli_args, GlobalCLIArgs)

    # Test that we can create an instance of GlobalCLI

# Generated at 2022-06-17 14:58:19.608639
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:58:31.340827
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.common.text.formatters import to_nice_yaml
    from ansible.module_utils.common.text.utils import to_bytes as to_bytes_func
    from ansible.module_utils.common.text.utils import to_text as to_text_func
    from ansible.module_utils.common.text.utils import to_unicode as to_unicode_func
    from ansible.module_utils.common.text.utils import to_bytes as to_bytes_func
    from ansible.module_utils.common.text.utils import to_text as to_text_func

# Generated at 2022-06-17 14:58:43.537170
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar')
    parser.add_argument('--baz')
    parser.add_argument('--qux')
    parser.add_argument('--quux')
    parser.add_argument('--corge')
    parser.add_argument('--grault')
    parser.add_argument('--garply')
    parser.add_argument('--waldo')
    parser.add_argument('--fred')
    parser.add_argument('--plugh')
    parser.add_argument('--xyzzy')
    parser.add_argument('--thud')
    parser.add_argument('--spam')
    parser.add_argument('--ham')

# Generated at 2022-06-17 14:58:51.675191
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:58:56.672683
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:58:59.129305
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:59:01.271878
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:59:06.969487
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:59:17.524587
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser.add_argument

# Generated at 2022-06-17 14:59:28.856938
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test the CLIArgs constructor
    """
    import collections
    import copy

    # Test that the constructor works
    test_dict = {
        'test_string': 'test',
        'test_int': 1,
        'test_list': [1, 2, 3],
        'test_dict': {
            'test_string': 'test',
            'test_int': 1,
            'test_list': [1, 2, 3],
            'test_dict': {
                'test_string': 'test',
                'test_int': 1,
                'test_list': [1, 2, 3],
            },
        },
    }
    test_dict_copy = copy.deepcopy(test_dict)

# Generated at 2022-06-17 14:59:40.578122
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import CLIArgs
    from ansible.module_utils.common.collections import _make_immutable
    from ansible.module_utils.common.collections import _ABCSingleton
    from ansible.utils.singleton import Singleton
    from ansible.module_utils.six import add_metaclass
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type
    from abc import ABCMeta
    from ansible.module_utils.common._collections_compat import Container
    from ansible.module_utils.common._collections_compat import M

# Generated at 2022-06-17 14:59:45.875573
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'a': 1, 'b': 2, 'c': 3}
    cli_args = CLIArgs(mapping)
    assert cli_args == mapping
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args, Mapping)
    assert not isinstance(cli_args, Set)
    assert not isinstance(cli_args, Sequence)


# Generated at 2022-06-17 15:00:00.285435
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

    test_dict = {
        'foo': 'bar',
        'baz': {
            'qux': 'quux',
            'corge': 'grault',
            'garply': ['waldo', 'fred', 'plugh', 'xyzzy'],
            'waldo': {
                'fred': 'plugh',
                'xyzzy': 'thud',
            },
        },
    }

# Generated at 2022-06-17 15:00:09.106941
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type

    test_dict = {
        'foo': 'bar',
        'baz': {
            'qux': 'quux',
            'corge': 'grault',
        },
        'waldo': [
            'fred',
            'plugh',
            'xyzzy',
        ],
        'thud': {
            'fred': 'plugh',
            'xyzzy': 'thud',
        },
    }

    # Test that

# Generated at 2022-06-17 15:00:18.570093
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test the CLIArgs class constructor
    """
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3

    # Test that the constructor works
    test_dict = {'a': 'b', 'c': 'd'}
    test_cli_args = CLIArgs(test_dict)
    assert isinstance(test_cli_args, ImmutableDict)
    assert test_cli_args == test_dict

    # Test that the constructor works with a unicode string
    test_dict = {'a': 'b', 'c': 'd'}
    test_cli

# Generated at 2022-06-17 15:00:20.788699
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 15:00:24.265999
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(TestClass(), TestClass)
    assert TestClass() is TestClass()

# Generated at 2022-06-17 15:00:27.167213
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 15:00:36.776543
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({'a': 1, 'b': 2, 'c': 3})
    assert args['a'] == 1
    assert args['b'] == 2
    assert args['c'] == 3
    assert args.get('a') == 1
    assert args.get('b') == 2
    assert args.get('c') == 3
    assert args.get('d') is None
    assert args.get('d', 4) == 4
    assert args.get('d', default=4) == 4
    assert args.get('a', default=4) == 1
    assert args.get('a', 4) == 1
    assert args.get('a', 'b') == 1
    assert args.get('a', 'b', 'c') == 1
    assert args.get('a', 'b', 'c', 'd')

# Generated at 2022-06-17 15:00:48.235367
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes

    # Test that the constructor of GlobalCLIArgs works as expected
    # This is a unit test for the constructor of class GlobalCLIArgs
    # It is not a unit test for the class GlobalCLIArgs
    # The class GlobalCLIArgs is a singleton and cannot be instantiated
    # more than once.
    #
    # This test is not part of the unit tests for the class GlobalCLIArgs
    # because it is not possible to instantiate the class GlobalCLIArgs
    # more than once.
    #
    # This test is not part of the unit tests for the class CLIArgs
    # because it is not possible to instantiate the class CLIArgs
    # more than once

# Generated at 2022-06-17 15:00:58.270774
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.utils.display import Display
    display = Display()
    cli = CLI(args=sys.argv[1:], display=display)
    options = cli.parse()
    args = GlobalCLIArgs.from_options(options)
    assert args['connection'] == 'smart'
    assert args['verbosity'] == 0
    assert args['inventory'] == '/etc/ansible/hosts'
    assert args['module_path'] == '/usr/share/ansible/plugins/modules'
    assert args['forks'] == 5
    assert args['become'] is False
    assert args['become_method'] == 'sudo'
    assert args['become_user'] == 'root'
    assert args['check'] is False

# Generated at 2022-06-17 15:01:08.945631
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true', default=False)
    parser.add_argument('--bar', action='store_true', default=False)
    parser.add_argument('--baz', action='store_true', default=False)
    parser.add_argument('--qux', action='store_true', default=False)
    parser.add_argument('--quux', action='store_true', default=False)
    parser.add_argument('--corge', action='store_true', default=False)
    parser.add_argument('--grault', action='store_true', default=False)
    parser.add_argument('--garply', action='store_true', default=False)
    parser.add_

# Generated at 2022-06-17 15:01:34.558994
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_false')
    parser.add_argument('--qux', action='append')
    parser.add_argument('--quux', action='append_const', const=True)
    parser.add_argument('--corge', action='append_const', const=False)
    parser.add_argument('--grault', action='append_const', const=None)
    parser.add_argument('--garply', action='append_const', const=1)
    parser.add_argument('--waldo', action='append_const', const=1.1)
    parser.add_

# Generated at 2022-06-17 15:01:39.335266
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.utils.display import Display
    display = Display()
    cli = CLI(args=sys.argv[1:], display=display)
    options = cli.parse()
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-17 15:01:43.903970
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 15:01:49.362782
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    import json

    # Test that we can create an instance of CLIArgs
    args = CLIArgs({'foo': 'bar'})
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, CLIArgs)
    assert isinstance(args, Mapping)
    assert isinstance(args, Container)
    assert isinstance(args, Sequence)
    assert not isinstance(args, Set)
    assert isinstance(args, object)

    # Test that we can create an instance of CLIArgs from an options object
    class Options(object):
        def __init__(self):
            self.foo = 'bar'
    options = Options()
    args = CLI

# Generated at 2022-06-17 15:02:01.113581
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 15:02:09.323727
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        def __init__(self):
            self.foo = 'bar'
            self.baz = {'quux': 'quuz'}
            self.corge = ['grault', 'garply']
            self.waldo = {'fred': ['plugh', 'xyzzy']}

    options = Options()
    cli_args = CLIArgs.from_options(options)

    assert cli_args['foo'] == 'bar'
    assert cli_args['baz'] == {'quux': 'quuz'}
    assert cli_args['corge'] == ('grault', 'garply')
    assert cli_args['waldo'] == {'fred': ('plugh', 'xyzzy')}

    # Make sure we can't modify the data

# Generated at 2022-06-17 15:02:21.175196
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import pytest
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_set
    from ansible.module_utils.common.collections import is_mapping

    # Test that the constructor works
    test_dict = {'a': 'b', 'c': 'd'}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict

    # Test that the constructor makes the object immutable
    with pytest.raises(TypeError):
        test_args['a'] = 'b'

    # Test that the constructor makes the object immutable

# Generated at 2022-06-17 15:02:25.643276
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 15:02:31.099858
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    options = Options(foo=1, bar=2, baz=3)
    args = GlobalCLIArgs.from_options(options)
    assert args['foo'] == 1
    assert args['bar'] == 2
    assert args['baz'] == 3

# Generated at 2022-06-17 15:02:37.187366
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_constructor(self):
            args = GlobalCLIArgs({'foo': 'bar'})
            self.assertEqual(args['foo'], 'bar')
            self.assertRaises(TypeError, args.__setitem__, 'foo', 'baz')

    suite = unittest.TestLoader().loadTestsFromTestCase(TestGlobalCLIArgs)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    sys.exit(not result.wasSuccessful())

# Generated at 2022-06-17 15:03:18.150941
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    import copy
    import types

    # Test that we can create a CLIArgs object
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_args = CLIArgs(test_dict)

    # Test that we can't modify the CLIArgs object
    with pytest.raises(TypeError):
        test_args['a'] = 2

    # Test that we can't modify the CLIArgs object
    with pytest.raises(TypeError):
        test_args.update({'a': 2})

    # Test that we can't modify the CLIArgs object
    with pytest.raises(TypeError):
        test_args.pop('a')

    # Test that we can't modify the CLIArgs object
    with pytest.raises(TypeError):
        test_args.popitem

# Generated at 2022-06-17 15:03:24.822798
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode

# Generated at 2022-06-17 15:03:32.840520
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 'b', 'c': {'d': 'e'}, 'f': ['g', 'h', {'i': 'j'}]}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert isinstance(test_args, ImmutableDict)
    assert isinstance(test_args['c'], ImmutableDict)
    assert isinstance(test_args['f'], tuple)
    assert isinstance(test_args['f'][2], ImmutableDict)