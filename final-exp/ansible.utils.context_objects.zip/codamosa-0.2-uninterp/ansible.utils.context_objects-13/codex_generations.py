

# Generated at 2022-06-17 14:53:36.739889
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:53:39.548396
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({'foo': 'bar'})
    assert args['foo'] == 'bar'

# Generated at 2022-06-17 14:53:44.672543
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:53:53.425312
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six import u

    # Test basic types
    assert CLIArgs({'a': 1}) == {'a': 1}
    assert CLIArgs({'a': 1.0}) == {'a': 1.0}
    assert CLIArgs({'a': '1'}) == {'a': '1'}

# Generated at 2022-06-17 14:54:03.846981
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a dictionary
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    cli_args = CLIArgs(test_dict)
    assert cli_args == test_dict
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args, Mapping)
    assert not isinstance(cli_args, Set)
    assert not isinstance(cli_args, Sequence)
    assert isinstance(cli_args, Container)

    # Test with a list
    test_list = [1, 2, 3]
    cli_args = CLIArgs(test_list)
    assert cli_args == test_list
    assert isinstance(cli_args, ImmutableDict)
    assert not isinstance(cli_args, Mapping)
    assert not isinstance

# Generated at 2022-06-17 14:54:12.135217
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:54:19.486826
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs constructor works as expected
    """
    # Test that we can create a CLIArgs object with a dictionary
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_cli_args = CLIArgs(test_dict)
    assert test_cli_args == test_dict

    # Test that we can create a CLIArgs object with a list
    test_list = ['a', 'b', 'c']
    test_cli_args = CLIArgs(test_list)
    assert test_cli_args == test_list

    # Test that we can create a CLIArgs object with a tuple
    test_tuple = ('a', 'b', 'c')
    test_cli_args = CLIArgs(test_tuple)
    assert test_cli_args == test_tuple

    #

# Generated at 2022-06-17 14:54:24.142982
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:54:27.613133
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:54:31.071389
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert isinstance(TestClass(), TestClass)
    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:54:37.391509
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert isinstance(TestClass(), TestClass)
    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:54:46.473140
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import json
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')

# Generated at 2022-06-17 14:54:57.543956
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.text.converters import to_text
    import json
    import os
    import sys

    # Create a copy of the command line arguments
    args = sys.argv[:]

    # Remove the first argument, which is the name of the script
    del args[0]

    # Add a few arguments to test
    args.append('--foo=bar')
    args.append('--baz=qux')
    args.append('--quux=corge')

    # Add a few arguments with the same name to test
    args.append('--foo=baz')
    args.append('--baz=quux')
    args.append('--quux=grault')

    # Add a few arguments with

# Generated at 2022-06-17 14:55:08.019921
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar')
    parser.add_argument('--baz')
    parser.add_argument('--qux')
    parser.add_argument('--quux')
    parser.add_argument('--corge')
    parser.add_argument('--grault')
    parser.add_argument('--garply')
    parser.add_argument('--waldo')
    parser.add_argument('--fred')
    parser.add_argument('--plugh')
    parser.add_argument('--xyzzy')
    parser.add_argument('--thud')
    parser.add_argument('--spam')
    parser.add_argument('--ham')

# Generated at 2022-06-17 14:55:10.425012
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:55:22.304580
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Unit test for CLIArgs constructor
    """
    test_dict = {'a': 'b', 'c': 'd'}
    test_cli_args = CLIArgs(test_dict)
    assert test_cli_args['a'] == 'b'
    assert test_cli_args['c'] == 'd'
    assert test_cli_args.a == 'b'
    assert test_cli_args.c == 'd'
    assert test_cli_args.get('a') == 'b'
    assert test_cli_args.get('c') == 'd'
    assert test_cli_args.get('e') is None
    assert test_cli_args.get('e', 'f') == 'f'
    assert test_cli_args.get('a', 'f') == 'b'
    assert test

# Generated at 2022-06-17 14:55:28.144808
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:55:37.916087
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('-a', action='store_true')
    parser.add_argument('-b', action='store_true')
    parser.add_argument('-c', action='store_true')
    parser.add_argument('-d', action='store_true')
    parser.add_argument('-e', action='store_true')
    parser.add_argument('-f', action='store_true')
    parser.add_argument('-g', action='store_true')
    parser.add_argument('-h', action='store_true')
    parser.add_argument('-i', action='store_true')
    parser.add_argument('-j', action='store_true')

# Generated at 2022-06-17 14:55:49.470598
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import json
    import sys
    import tempfile

    # Create a temporary file to hold the json data
    with tempfile.NamedTemporaryFile(mode='w+t', delete=False) as temp_file:
        temp_file.write(json.dumps({'a': {'b': {'c': 'd'}}}))

    # Create a CLIArgs object with the json data
    cli_args = CLIArgs.from_options(type('', (), {'json': temp_file.name}))

    # Check that the data is stored correctly
    assert cli_args['a']['b']['c'] == 'd'

    # Remove the temporary file
    sys.stdout.write('Removing temporary file: %s\n' % temp_file.name)
    sys.stdout.flush()

# Generated at 2022-06-17 14:55:59.253571
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    options = Options(foo=1, bar=2, baz=3)
    args = GlobalCLIArgs.from_options(options)
    assert args['foo'] == 1
    assert args['bar'] == 2
    assert args['baz'] == 3
    assert args.get('foo') == 1
    assert args.get('bar') == 2
    assert args.get('baz') == 3
    assert args.get('quux') is None
    assert args.get('quux', 'default') == 'default'
    assert args.get('quux', default='default') == 'default'

# Generated at 2022-06-17 14:56:09.788991
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    import json

    # Test that we can create a CLIArgs object
    args = CLIArgs({'foo': 'bar'})
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, CLIArgs)
    assert args['foo'] == 'bar'

    # Test that we can create a CLIArgs object with a nested dict
    args = CLIArgs({'foo': {'bar': 'baz'}})
    assert isinstance(args, ImmutableDict)

# Generated at 2022-06-17 14:56:17.866577
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    args = CLIArgs({'foo': 'bar'})
    assert args['foo'] == 'bar'

    # Test that we can create a CLIArgs object with a nested dict
    args = CLIArgs({'foo': {'bar': 'baz'}})
    assert args['foo']['bar'] == 'baz'

    # Test that we can create a CLIArgs object with a nested list
    args = CLIArgs({'foo': ['bar', 'baz']})
    assert args['foo'][0] == 'bar'
    assert args['foo'][1] == 'baz'

    # Test that we can create a CLIArgs object with a nested set
    args = CLIArgs({'foo': {'bar', 'baz'}})
    assert 'bar' in args['foo']


# Generated at 2022-06-17 14:56:20.903447
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(TestClass(), TestClass)
    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:56:29.833016
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a dict
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    cli_args = CLIArgs(test_dict)
    assert cli_args['a'] == 1
    assert cli_args['b'] == 2
    assert cli_args['c'] == 3

    # Test with a list
    test_list = [1, 2, 3]
    cli_args = CLIArgs(test_list)
    assert cli_args[0] == 1
    assert cli_args[1] == 2
    assert cli_args[2] == 3

    # Test with a set
    test_set = {1, 2, 3}
    cli_args = CLIArgs(test_set)
    assert 1 in cli_args
    assert 2 in cli_

# Generated at 2022-06-17 14:56:33.423010
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_init(self):
            # Test that we can create a GlobalCLIArgs object
            GlobalCLIArgs({})

    # Run the unit tests
    unittest.main(argv=[sys.argv[0]])

# Generated at 2022-06-17 14:56:40.178033
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.utils.display import Display
    display = Display()
    cli = CLI(args=sys.argv[1:], display=display)
    options = cli.parse()
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-17 14:56:49.843145
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create an instance of CLIArgs
    cli_args = CLIArgs({'foo': 'bar'})
    assert cli_args['foo'] == 'bar'

    # Test that we can create an instance of CLIArgs from an options object
    from ansible.cli import CLI
    from ansible.utils.display import Display
    display = Display()
    cli = CLI(args=[], display=display)
    cli_args = CLIArgs.from_options(cli.parser.parse_args([]))
    assert cli_args['version'] is False

    # Test that we can create an instance of CLIArgs from an options object with a non-default value
    cli = CLI(args=[], display=display)

# Generated at 2022-06-17 14:56:59.868933
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # pylint: disable=protected-access
    args = GlobalCLIArgs({'foo': 'bar'})
    assert args._mapping == {'foo': 'bar'}
    assert args._hash is None
    assert args._hash_cache == {}
    assert args._hash_cache_version == 0
    assert args._hash_cache_version_key == '_hash_cache_version'
    assert args._hash_cache_version_key_hash is None
    assert args._hash_cache_version_key_hash_cache == {}
    assert args._hash_cache_version_key_hash_cache_version == 0
    assert args._hash_cache_version_key_hash_cache_version_key == '_hash_cache_version_key_hash_cache_version'
    assert args._hash_cache_version_key_hash

# Generated at 2022-06-17 14:57:06.100593
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:57:14.800282
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create an instance of CLIArgs
    cli_args = CLIArgs({'foo': 'bar'})
    assert cli_args['foo'] == 'bar'

    # Test that we can create an instance of CLIArgs from an optparse.Values object
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.optparse import Values
    options = Values({'foo': 'bar'})
    cli_args = CLIArgs.from_options(options)
    assert cli_args['foo'] == 'bar'

    # Test that we can create an instance of CLIArgs from an ImmutableDict
    options = ImmutableDict({'foo': 'bar'})
    cli_args = CLIArgs.from_options(options)
    assert cli_args

# Generated at 2022-06-17 14:57:27.340532
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.config.manager import ConfigManager

    # Create a fake command line
    sys.argv = ['ansible', '--version']

    # Create a fake config file
    config_file = ConfigManager()
    config_file.add_config_file('/dev/null')

    # Create a fake options object
    options = CLI.base_parser(config_file).parse_args(sys.argv[1:])

    # Create a GlobalCLIArgs object
    args = GlobalCLIArgs.from_options(options)

    # Check that it is a singleton
    assert args is GlobalCLIArgs()

    # Check that it is immutable
    try:
        args['version'] = '2.0'
    except TypeError:
        pass

# Generated at 2022-06-17 14:57:29.800954
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:57:36.459936
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    cli_args = GlobalCLIArgs.from_options(args)
    assert cli_args['foo'] is True
    assert cli_args['bar'] is True
    assert cli_args['baz'] is False

# Generated at 2022-06-17 14:57:46.683474
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    import json

    # Test a simple case
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_cli_args = CLIArgs(test_dict)
    assert test_cli_args == test_dict
    assert isinstance(test_cli_args, ImmutableDict)

    # Test a more complex case
    test_dict = {'a': 1, 'b': 2, 'c': 3, 'd': {'e': 4, 'f': 5}, 'g': [6, 7, 8], 'h': {9, 10, 11}}
    test_cli_args = CLIArgs(test_dict)
    assert test

# Generated at 2022-06-17 14:57:50.376849
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:58:02.030460
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    args = CLIArgs({'foo': 'bar'})
    assert isinstance(args, CLIArgs)

    # Test that we can create a CLIArgs object from an optparse.Values object
    from optparse import Values
    args = CLIArgs.from_options(Values({'foo': 'bar'}))
    assert isinstance(args, CLIArgs)

    # Test that we can create a CLIArgs object from an argparse.Namespace object
    from argparse import Namespace
    args = CLIArgs.from_options(Namespace(foo='bar'))
    assert isinstance(args, CLIArgs)

    # Test that we can create a CLIArgs object from a dict
    args = CLIArgs({'foo': 'bar'})
    assert isinstance(args, CLIArgs)

    # Test that we can

# Generated at 2022-06-17 14:58:04.465163
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()
    assert TestClass() is not object()

# Generated at 2022-06-17 14:58:09.629864
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:58:21.581159
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser.add_argument

# Generated at 2022-06-17 14:58:27.509607
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:58:31.264218
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:58:41.065905
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    args = parser.parse_args(sys.argv[1:])
    GlobalCLIArgs.from_options(args)

# Generated at 2022-06-17 14:58:42.944496
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:58:51.176852
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest
    from ansible.module_utils.common.collections import ImmutableDict


# Generated at 2022-06-17 14:59:02.853690
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.module_utils.common.collections import ImmutableSet
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableSequence
    from ansible.module_utils.common.collections import ImmutableMapping
    from ansible.module_utils.common.collections import ImmutableContainer
    from ansible.module_utils.common.collections import MutableMapping
    from ansible.module_utils.common.collections import MutableSequence
    from ansible.module_utils.common.collections import MutableSet

# Generated at 2022-06-17 14:59:07.610809
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    a = A()
    b = B()
    assert a is b

# Generated at 2022-06-17 14:59:08.902766
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(TestClass(), TestClass)

# Generated at 2022-06-17 14:59:20.368741
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    assert isinstance(A(), A)
    assert isinstance(B(), A)
    assert isinstance(C(), A)
    assert isinstance(D(), A)

    assert isinstance(A(), B)
    assert isinstance(B(), B)
    assert isinstance(C(), B)
    assert isinstance(D(), B)

    assert isinstance(A(), C)
    assert isinstance(B(), C)
    assert isinstance(C(), C)
    assert isinstance(D(), C)

    assert isinstance(A(), D)
    assert isinstance(B(), D)
    assert isinstance(C(), D)


# Generated at 2022-06-17 14:59:25.929368
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:59:33.786071
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    args = CLIArgs({'foo': 'bar'})
    assert args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from an optparse.Values object
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.optparse import Values
    options = Values({'foo': 'bar'})
    args = CLIArgs.from_options(options)
    assert isinstance(args, ImmutableDict)
    assert args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from a dict
    args = CLIArgs({'foo': 'bar'})
    assert isinstance(args, ImmutableDict)
    assert args['foo'] == 'bar'

    # Test that we

# Generated at 2022-06-17 14:59:47.599675
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-17 14:59:54.588668
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    global_args = GlobalCLIArgs.from_options(args)
    assert global_args['foo'] is True
    assert global_args['bar'] is True
    assert global_args['baz'] is False

# Generated at 2022-06-17 14:59:57.115071
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 15:00:03.643124
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.utils.display import Display
    display = Display()
    cli = CLI(args=sys.argv[1:], display=display)
    options = cli.parse()
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-17 15:00:07.661277
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    GlobalCLIArgs.from_options(args)

# Generated at 2022-06-17 15:00:15.155614
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is B()
    assert A() is C()
    assert B() is C()

# Generated at 2022-06-17 15:00:28.419578
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    test_dict = {'test_key': 'test_value'}
    test_args = CLIArgs(test_dict)
    assert test_args['test_key'] == 'test_value'
    # Test that we can't modify the CLIArgs object
    try:
        test_args['test_key'] = 'new_value'
        assert False
    except TypeError:
        assert True
    # Test that we can't modify the CLIArgs object's values
    try:
        test_args['test_key'] = ['new_value']
        assert False
    except TypeError:
        assert True
    # Test that we can't modify the CLIArgs object's values

# Generated at 2022-06-17 15:00:39.067286
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that the constructor works
    test_dict = {'a': 1, 'b': 2}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict

    # Test that the constructor makes a copy
    test_dict['a'] = 3
    assert test_args != test_dict

    # Test that the constructor makes a copy of the object
    test_dict = {'a': [1, 2, 3]}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    test_dict['a'].append(4)
    assert test_args != test_dict

    # Test that the constructor makes a copy of the object in the object
    test_dict = {'a': {'b': [1, 2, 3]}}
    test_args = CLIArgs

# Generated at 2022-06-17 15:00:50.614760
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 15:01:00.056708
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict

    # Test that the constructor of GlobalCLIArgs is working as expected
    # Create a dictionary with a list, a set, a string, and a dictionary
    test_dict = {'a': [1, 2, 3], 'b': {'c': 'd'}, 'e': 'f', 'g': {1, 2, 3}}
    # Create an instance of GlobalCLIArgs
    test_instance = GlobalCLIArgs(test_dict)
    # Check that the instance is an instance of GlobalCLIArgs
    assert isinstance(test_instance, GlobalCLIArgs)
    # Check that the instance is an instance of ImmutableDict
    assert isinstance(test_instance, ImmutableDict)
    # Check that the instance is an instance of

# Generated at 2022-06-17 15:01:06.601051
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 15:01:17.767555
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

    display = Display()
    cli = CLI(args=sys.argv[1:], display=display)
    options = cli.parse()

    # This is the only way to get the options object to be populated with the defaults
    # for the options that are not specified on the command line.
    options = combine_vars(options, options)

    # This is the only way to get the options object to be populated with the defaults
    # for the options that are not specified on the command line.
    options = combine_vars(options, options)

    # This is the only way to get the options object to be populated with the defaults
    # for the options that are not specified on the

# Generated at 2022-06-17 15:01:21.518610
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 15:01:32.064933
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 15:01:37.237927
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert isinstance(TestClass(), TestClass)
    assert TestClass() is TestClass()

# Generated at 2022-06-17 15:01:47.674517
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode

# Generated at 2022-06-17 15:01:54.610339
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.cli import CLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    display = Display()
    cli = CLI(args=[])
    options, display_args = cli.parse()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=options.inventory)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-17 15:02:05.152250
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six import u

    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({})
    assert isinstance(cli_args, ImmutableDict)

    # Test that we

# Generated at 2022-06-17 15:02:09.305311
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    options = Options(foo='bar', baz=['qux'])
    args = GlobalCLIArgs.from_options(options)
    assert args['foo'] == 'bar'
    assert args['baz'] == ('qux',)

# Generated at 2022-06-17 15:02:16.698591
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest
    from ansible.module_utils.common.collections import GlobalCLIArgs

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_GlobalCLIArgs(self):
            self.assertIsInstance(GlobalCLIArgs(), GlobalCLIArgs)

    suite = unittest.TestLoader().loadTestsFromModule(TestGlobalCLIArgs())
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-17 15:02:36.016397
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', default='bar')
    parser.add_argument('--baz', default='qux')
    parser.add_argument('--quux', default='corge')
    parser.add_argument('--grault', default='garply')
    parser.add_argument('--waldo', default='fred')
    parser.add_argument('--plugh', default='xyzzy')
    parser.add_argument('--thud', default='wibble')
    parser.add_argument('--spam', default='eggs')
    parser.add_argument('--spam2', default='eggs2')
    parser.add_argument('--spam3', default='eggs3')

# Generated at 2022-06-17 15:02:46.539779
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 1, 'b': {'c': 2, 'd': 3}, 'e': [4, 5, 6]})
    assert args['a'] == 1
    assert args['b']['c'] == 2
    assert args['b']['d'] == 3
    assert args['e'][0] == 4
    assert args['e'][1] == 5
    assert args['e'][2] == 6
    assert isinstance(args, ImmutableDict)
    assert isinstance(args['b'], ImmutableDict)
    assert isinstance(args['e'], tuple)

# Generated at 2022-06-17 15:02:56.987465
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode

# Generated at 2022-06-17 15:02:59.946757
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    args = parser.parse_args(sys.argv[1:])
    GlobalCLIArgs.from_options(args)

# Generated at 2022-06-17 15:03:08.693555
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    cli_args = CLIArgs.from_options(args)
    assert cli_args['foo'] is True
    assert cli_args['bar'] is True
    assert cli_args['baz'] is False
    # Make sure we can't change it
    try:
        cli_args['foo'] = False
    except TypeError:
        pass
    else:
        assert False, "Should not be able to change CLIArgs"
    #

# Generated at 2022-06-17 15:03:19.421811
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import unittest

    from ansible.cli.arguments import CLIArgumentParser

    class TestGlobalCLIArgs(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.test_dir, 'test.json')

        def tearDown(self):
            shutil.rmtree(self.test_dir)

        def test_constructor(self):
            parser = CLIArgumentParser(usage="%(prog)s [options]",
                                       description="Ansible CLI tool")

# Generated at 2022-06-17 15:03:25.530027
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest
    from ansible.module_utils.common.argparse import ArgumentParser

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_constructor(self):
            parser = ArgumentParser()
            parser.add_argument('--foo', action='store_true')
            parser.add_argument('--bar', action='store_true')
            parser.add_argument('--baz', action='store_true')
            args = parser.parse_args(['--foo', '--bar'])
            GlobalCLIArgs.from_options(args)
            self.assertEqual(GlobalCLIArgs.instance().foo, True)
            self.assertEqual(GlobalCLIArgs.instance().bar, True)

# Generated at 2022-06-17 15:03:31.730255
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABCSingleton(object):
        __metaclass__ = _ABCSingleton

    class TestABCSingleton2(object):
        __metaclass__ = _ABCSingleton

    assert TestABCSingleton() is TestABCSingleton()
    assert TestABCSingleton2() is TestABCSingleton2()
    assert TestABCSingleton() is not TestABCSingleton2()