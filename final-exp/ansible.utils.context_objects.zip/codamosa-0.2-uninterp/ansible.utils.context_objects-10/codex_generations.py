

# Generated at 2022-06-17 14:53:48.546935
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.module_utils.common.collections import CLIArgs
    import sys
    import os
    import tempfile
    import shutil
    import json
    import subprocess
    import pytest

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)

    # Create the test data that will be written to the temporary file

# Generated at 2022-06-17 14:53:55.878870
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a simple dictionary
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert test_args.a == 1
    assert test_args.b == 2
    assert test_args.c == 3

    # Test with a nested dictionary
    test_dict = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert test_args.a == 1
    assert test_args.b == {'c': 2, 'd': 3}
    assert test_args.b.c == 2
    assert test_args.b.d == 3


# Generated at 2022-06-17 14:53:59.390216
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    assert A() is A()
    assert B() is B()
    assert A() is not B()
    assert B() is not A()

# Generated at 2022-06-17 14:54:08.488269
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs constructor converts all mutable types to immutable types
    """
    # Test that the constructor converts all mutable types to immutable types
    test_dict = {
        "a": "a",
        "b": 1,
        "c": [1, 2, 3],
        "d": {
            "e": "e",
            "f": [1, 2, 3],
            "g": {
                "h": "h",
                "i": [1, 2, 3],
                "j": {
                    "k": "k",
                    "l": [1, 2, 3],
                },
            },
        },
    }
    test_args = CLIArgs(test_dict)

    assert isinstance(test_args, ImmutableDict)

# Generated at 2022-06-17 14:54:13.644970
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils.display import Display
    display = Display()
    cli = CLI(args=sys.argv[1:], display=display)
    options = cli.parse()
    args = GlobalCLIArgs.from_options(options)
    assert isinstance(args, ImmutableDict)

# Generated at 2022-06-17 14:54:17.274116
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:54:23.143252
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.cli import CLI
    from ansible.module_utils.common.collections import ImmutableDict

    cli = CLI(args=['--version'])
    cli.parse()
    args = GlobalCLIArgs.from_options(cli.options)
    assert isinstance(args, ImmutableDict)
    assert args['version'] is True
    with pytest.raises(AttributeError):
        args['version'] = False

# Generated at 2022-06-17 14:54:30.444685
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', default='bar')
    parser.add_argument('--baz', default='qux')
    args = parser.parse_args(sys.argv[1:])
    cli_args = CLIArgs.from_options(args)
    assert cli_args['foo'] == 'bar'
    assert cli_args['baz'] == 'qux'

# Generated at 2022-06-17 14:54:39.591743
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.module_utils.common.collections import ImmutableSet
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableSequence
    from ansible.module_utils.common.collections import ImmutableMapping

    # Test that we can create an instance of CLIArgs
    cli_args = CLIArgs({'a': 1, 'b': 2})

    # Test that we can access the values
    assert cli_args['a'] == 1
    assert cli_args['b'] == 2

    # Test that we can't modify the values

# Generated at 2022-06-17 14:54:44.126275
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is B()
    assert A() is C()
    assert B() is C()

# Generated at 2022-06-17 14:54:57.294390
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test the CLIArgs class.

    This is a unit test for the CLIArgs class.  It tests that the class
    correctly converts all of the data types it contains into immutable
    data types.
    """
    # Test that the class correctly converts a dictionary into an ImmutableDict
    test_dict = {'a': 1, 'b': 2}
    test_cli_args = CLIArgs(test_dict)
    assert isinstance(test_cli_args, ImmutableDict)

    # Test that the class correctly converts a list into a tuple
    test_list = [1, 2, 3]
    test_cli_args = CLIArgs({'a': test_list})
    assert isinstance(test_cli_args['a'], tuple)

    # Test that the class correctly converts a set into a frozenset
    test_set

# Generated at 2022-06-17 14:55:07.422964
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that the constructor works
    args = CLIArgs({'a': 'b'})
    assert isinstance(args, ImmutableDict)
    assert args['a'] == 'b'

    # Test that the constructor converts to immutable types
    args = CLIArgs({'a': {'b': 'c'}})
    assert isinstance(args, ImmutableDict)
    assert isinstance(args['a'], ImmutableDict)
    assert args['a']['b'] == 'c'

    # Test that the constructor converts to immutable types
    args = CLIArgs({'a': ['b', 'c']})
    assert isinstance(args, ImmutableDict)
    assert isinstance(args['a'], tuple)
    assert args['a'][0] == 'b'

# Generated at 2022-06-17 14:55:10.986284
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:55:22.534157
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import string_types

    # Test the constructor of class CLIArgs
    test_dict = {'a': 'b', 'c': 'd'}
    test_cli_args = CLIArgs(test_dict)
    assert isinstance(test_cli_args, ImmutableDict)
    assert isinstance(test_cli_args, Mapping)
    assert isinstance(test_cli_args, Container)
    assert isinstance(test_cli_args, Sequence)
    assert isinstance(test_cli_args, Set)
    assert isinstance(test_cli_args, string_types)

# Generated at 2022-06-17 14:55:28.285296
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:55:31.759858
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    assert A() is A()
    assert B() is B()
    assert A() is not B()
    assert B() is not A()

# Generated at 2022-06-17 14:55:43.889107
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Create a dictionary with a list, dictionary, and set
    test_dict = {'list': [1, 2, 3], 'dict': {'a': 1, 'b': 2}, 'set': {1, 2, 3}}
    # Create an instance of CLIArgs
    test_args = CLIArgs(test_dict)
    # Test that the instance is immutable
    try:
        test_args['list'] = [4, 5, 6]
    except TypeError:
        pass
    else:
        raise AssertionError('CLIArgs is not immutable')
    # Test that the instance is a dictionary
    if not isinstance(test_args, dict):
        raise AssertionError('CLIArgs is not a dictionary')
    # Test that the instance is a CLIArgs

# Generated at 2022-06-17 14:55:52.858955
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs constructor works as expected
    """
    # Test that it converts a dict to an ImmutableDict
    test_dict = {'a': 'b', 'c': 'd'}
    cli_args = CLIArgs(test_dict)
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args == test_dict

    # Test that it converts a list to a tuple
    test_list = ['a', 'b', 'c']
    cli_args = CLIArgs(test_list)
    assert isinstance(cli_args, tuple)
    assert cli_args == tuple(test_list)

    # Test that it converts a set to a frozenset
    test_set = {'a', 'b', 'c'}

# Generated at 2022-06-17 14:55:58.160203
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    options = Options(foo=1, bar=2)
    args = GlobalCLIArgs.from_options(options)
    assert args['foo'] == 1
    assert args['bar'] == 2

# Generated at 2022-06-17 14:56:05.770782
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', default='bar')
    parser.add_argument('--baz', default='qux')
    args = parser.parse_args(sys.argv[1:])
    cli_args = CLIArgs.from_options(args)

    assert isinstance(cli_args, ImmutableDict)
    assert cli_args['foo'] == 'bar'
    assert cli_args['baz'] == 'qux'


# Generated at 2022-06-17 14:56:10.033363
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:56:14.511976
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import os
    import tempfile
    import shutil
    import json

    # Create a temp directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temp directory
    fd, temp_file = tempfile.mkstemp(dir=tmpdir)

    # Write data to the file
    os.write(fd, b'{"foo": "bar"}')
    os.close(fd)

    # Create a CLIArgs object
    cli_args = CLIArgs.from_options(
        type('Options', (object,), {
            'foo': 'bar',
            'baz': 'qux',
            'file': temp_file,
        })
    )

    # Test the CLIArgs object
    assert cli_args['foo'] == 'bar'
    assert cli_args

# Generated at 2022-06-17 14:56:19.052967
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:56:28.149508
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    import copy
    import types

    def test_immutable(obj):
        if isinstance(obj, (text_type, binary_type)):
            # Strings first because they are also sequences
            return True
        elif isinstance(obj, collections.Mapping):
            for key, value in obj.items():
                if not test_immutable(value):
                    return False
            return True
        elif isinstance(obj, collections.Set):
            for value in obj:
                if not test_immutable(value):
                    return False
            return True
        elif isinstance(obj, collections.Sequence):
            for value in obj:
                if not test_immutable(value):
                    return False
            return True

        return True


# Generated at 2022-06-17 14:56:32.353037
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:56:34.857370
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:56:45.149728
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    cli_args = GlobalCLIArgs.from_options(args)
    assert cli_args['foo'] is True
    assert cli_args['bar'] is True
    assert cli_args['baz'] is False

# Generated at 2022-06-17 14:56:49.416992
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:56:59.242230
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.module_utils.common.collections import CLIArgs
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_set
    from ansible.module_utils.common.collections import is_mapping

    # Test that GlobalCLIArgs is a subclass of CLIArgs
    assert issubclass(GlobalCLIArgs, CLIArgs)

    # Test that GlobalCLIArgs is a subclass of ImmutableDict
    assert issubclass(GlobalCLIArgs, ImmutableDict)

    # Test that GlobalCL

# Generated at 2022-06-17 14:57:03.276974
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.utils.display import Display
    display = Display()
    cli = CLI(args=sys.argv[1:], display=display)
    options = cli.parse()
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-17 14:57:09.163260
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:57:20.485903
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import HumanReadable
    from ansible.module_utils.common.text.formatters import Formatter
    from ansible.module_utils.common.text.formatters import BoolFormatter
    from ansible.module_utils.common.text.formatters import IntFormatter
    from ansible.module_utils.common.text.formatters import FloatFormatter
    from ansible.module_utils.common.text.formatters import ListFormatter
    from ansible.module_utils.common.text.formatters import DictFormatter
    from ansible.module_utils.common.text.formatters import JSONForm

# Generated at 2022-06-17 14:57:22.319280
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:57:30.277721
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', default='bar')
    parser.add_argument('--baz', default='qux')
    parser.add_argument('--quux', default='corge')
    parser.add_argument('--grault', default='garply')
    parser.add_argument('--waldo', default='fred')
    parser.add_argument('--plugh', default='xyzzy')
    parser.add_argument('--thud', default='wibble')
    parser.add_argument('--spam', default='eggs')
    parser.add_argument('--ham', default='spam')
    parser.add_argument('--foo-bar', default='baz')

# Generated at 2022-06-17 14:57:34.537361
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is B()
    assert A() is C()
    assert B() is C()

# Generated at 2022-06-17 14:57:37.048483
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object):
        __metaclass__ = _ABCSingleton

    assert Test() is Test()

# Generated at 2022-06-17 14:57:41.950739
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:57:45.446317
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:57:50.103857
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is B()
    assert A() is C()
    assert B() is C()

# Generated at 2022-06-17 14:57:58.789501
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_false')
    parser.add_argument('--qux', action='append')
    parser.add_argument('--quux', nargs='+')
    parser.add_argument('--corge', nargs='*')
    parser.add_argument('--grault', nargs=2)
    parser.add_argument('--garply', nargs=3)
    parser.add_argument('--waldo', nargs=4)
    parser.add_argument('--fred', nargs=5)
    parser.add_argument('--plugh', nargs=6)

# Generated at 2022-06-17 14:58:02.058317
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:58:03.436705
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:58:10.452710
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    cli_args = CLIArgs.from_options(args)
    assert cli_args['foo'] is True
    assert cli_args['bar'] is True
    assert cli_args['baz'] is False



# Generated at 2022-06-17 14:58:18.353763
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    args = parser.parse_args(['--foo'])
    GlobalCLIArgs.set(CLIArgs.from_options(args))
    assert GlobalCLIArgs.get()['foo'] is True
    assert GlobalCLIArgs.get()['bar'] is False

# Generated at 2022-06-17 14:58:23.052792
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:58:33.256183
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can construct a CLIArgs object
    args = CLIArgs({'foo': 'bar'})
    assert isinstance(args, CLIArgs)

    # Test that we can construct a CLIArgs object from an optparse.Values object
    from optparse import Values
    args = CLIArgs.from_options(Values({'foo': 'bar'}))
    assert isinstance(args, CLIArgs)

    # Test that we can construct a CLIArgs object from an argparse.Namespace object
    from argparse import Namespace
    args = CLIArgs.from_options(Namespace(foo='bar'))
    assert isinstance(args, CLIArgs)

    # Test that we can construct a CLIArgs object from a dict
    args = CLIArgs({'foo': 'bar'})
    assert isinstance(args, CLIArgs)

    # Test that we can

# Generated at 2022-06-17 14:58:41.610795
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')

    args = parser.parse_args(sys.argv[1:])

    GlobalCLIArgs.from_options(args)

# Generated at 2022-06-17 14:58:45.793206
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    import json
    import sys

    # Create a CLIArgs object
    args = CLIArgs({'foo': 'bar', 'baz': 'qux'})

    # Check that it is an ImmutableDict
    assert isinstance(args, ImmutableDict)

    # Check that it is the same as the original
    assert args == {'foo': 'bar', 'baz': 'qux'}

    # Check that it is immutable
    try:
        args['foo'] = 'qux'
    except TypeError:
        pass
    else:
        raise AssertionError("CLIArgs object is not immutable")

    # Check that it is a singleton
   

# Generated at 2022-06-17 14:58:50.953011
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    options = parser.parse_args(['--foo', '--bar'])
    args = GlobalCLIArgs.from_options(options)
    assert args['foo'] is True
    assert args['bar'] is True
    assert args['baz'] is False

# Generated at 2022-06-17 14:58:57.453247
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:59:12.380943
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest

    class TestGlobalCLIArgs(unittest.TestCase):
        def setUp(self):
            self.old_sys_argv = sys.argv

        def tearDown(self):
            sys.argv = self.old_sys_argv

        def test_constructor(self):
            from ansible.cli import CLI
            from ansible.utils.display import Display

            sys.argv = ['ansible-playbook', '--version']
            cli = CLI(args=sys.argv[1:])
            cli.parse()
            display = Display()
            display.verbosity = cli.options.verbosity
            args = GlobalCLIArgs.from_options(cli.options)
            self.assertEqual(args['version'], True)

    unitt

# Generated at 2022-06-17 14:59:17.981307
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:59:25.373920
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:59:28.606609
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:59:32.970483
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:59:46.488887
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # pylint: disable=protected-access
    # pylint: disable=no-member
    # pylint: disable=unused-variable

    # Test that we can create a GlobalCLIArgs object
    args = GlobalCLIArgs({'foo': 'bar'})

    # Test that we can't create a second GlobalCLIArgs object
    try:
        args = GlobalCLIArgs({'foo': 'bar'})
    except TypeError:
        pass
    else:
        assert False, "GlobalCLIArgs should only be instantiated once"

    # Test that we can't create a second GlobalCLIArgs object with a different constructor
    try:
        args = GlobalCLIArgs.from_options(None)
    except TypeError:
        pass

# Generated at 2022-06-17 14:59:56.241557
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.module_utils.common.collections import ImmutableSet
    from ansible.module_utils.common.collections import ImmutableSequence

    # Test that we can create a CLIArgs object
    test_dict = {'foo': 'bar', 'baz': 'qux'}
    cli_args = CLIArgs(test_dict)

    # Test that we can access the values in the CLIArgs object
    assert cli_args['foo'] == 'bar'
    assert cli_args['baz'] == 'qux'

    # Test that we can't modify the CLIArgs object
    with pytest.raises(TypeError):
        cl

# Generated at 2022-06-17 15:00:03.401942
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 15:00:08.381810
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 15:00:12.990338
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 15:00:26.878449
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import ansible.module_utils.common.argparse as argparse
    from ansible.module_utils.common.argparse import (
        AnsibleArgumentError,
        AnsibleParser,
    )

    parser = AnsibleParser(
        description='description',
        usage='usage',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        add_help=False,
    )
    parser.add_argument('-a', '--arg', action='store_true', default=False, dest='arg')
    parser.add_argument('-b', '--bar', action='store_true', default=False, dest='bar')
    parser.add_argument('-c', '--baz', action='store_true', default=False, dest='baz')

# Generated at 2022-06-17 15:00:35.420224
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.six import string_types
    import pytest

    # Test that we can create an instance of CLIArgs
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_cli_args = CLIArgs(test_dict)

    # Test that we can access the values in the CLIArgs object
    assert test_cli_args['a'] == 1
    assert test_cli_args['b'] == 2
    assert test_cli

# Generated at 2022-06-17 15:00:45.913816
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that CLIArgs constructor works as expected
    # Test that CLIArgs constructor works as expected
    test_dict = {'a': 'b', 'c': 'd'}
    test_args = CLIArgs(test_dict)
    assert test_args['a'] == 'b'
    assert test_args['c'] == 'd'
    assert test_args.a == 'b'
    assert test_args.c == 'd'
    assert test_args.get('a') == 'b'
    assert test_args.get('c') == 'd'
    assert test_args.get('e') is None
    assert test_args.get('e', 'f') == 'f'
    assert test_args.get('a', 'f') == 'b'

# Generated at 2022-06-17 15:00:54.180830
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 15:01:02.189960
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 1, 'b': 2})
    assert args['a'] == 1
    assert args['b'] == 2
    assert len(args) == 2
    assert args.get('a') == 1
    assert args.get('c') is None
    assert args.get('c', 3) == 3
    assert args.get('a', 3) == 1
    assert 'a' in args
    assert 'c' not in args
    assert args.keys() == ['a', 'b']
    assert args.values() == [1, 2]
    assert args.items() == [('a', 1), ('b', 2)]
    assert args.copy() == {'a': 1, 'b': 2}
    assert args.pop('a') == 1
    assert args.pop('c', 3) == 3
   

# Generated at 2022-06-17 15:01:10.835883
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import CLIArgs
    from ansible.module_utils.common.collections import _make_immutable
    from ansible.module_utils.common.collections import _ABCSingleton
    from ansible.utils.singleton import Singleton
    from ansible.module_utils.six import add_metaclass
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type
    from abc import ABCMeta
    from ansible.module_utils.common._collections_compat import (Container, Mapping, Sequence, Set)

# Generated at 2022-06-17 15:01:19.830916
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 15:01:31.321196
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 15:01:34.270497
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    class Bar(object):
        __metaclass__ = _ABCSingleton

    assert Foo() is Foo()
    assert Bar() is Bar()
    assert Foo() is not Bar()

# Generated at 2022-06-17 15:01:43.303152
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.display import Display
    from ansible.utils.path import module_loader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars_from_file
    from ansible.utils.vars import load_vars_from_inventory
    from ansible.utils.vars import load_vars_from_main
    from ansible.utils.vars import load_vars_from_task_vars
    from ansible.utils.vars import load_vars_from_task_vars_file
    from ansible.utils.vars import load_vars_from_vault
    from ansible.utils.vars import merge_extra_vars

# Generated at 2022-06-17 15:02:05.662486
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'foo': 'bar'})
    assert cli_args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from an optparse.Values object
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.optparse import Values
    options = Values({'foo': 'bar'})
    cli_args = CLIArgs.from_options(options)
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from a dict
    cli_args = CLIArgs({'foo': 'bar'})

# Generated at 2022-06-17 15:02:12.621190
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    import copy
    import types

    # Test that the constructor works
    test_dict = {
        'a': 1,
        'b': 2,
        'c': 3,
    }
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict

    # Test that the constructor makes a copy
    test_dict['d'] = 4
    assert test_args != test_dict

    # Test that the constructor makes a deep copy
    test_dict = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': {
            'e': 5,
            'f': 6,
            'g': 7,
        },
    }
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict



# Generated at 2022-06-17 15:02:23.566260
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    import json

    # Test that we can create an instance of CLIArgs
    cli_args = CLIArgs({'a': 1, 'b': 2})
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args == {'a': 1, 'b': 2}

    # Test that we can create an instance of CLIArgs from an options object
    from ansible.utils.display import Display
    display = Display()
    parser = display.option_parser
    options, args = parser.parse_args()
    cli_args = CLIArgs.from_options(options)
    assert isinstance(cli_args, ImmutableDict)

# Generated at 2022-06-17 15:02:34.539280
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-17 15:02:44.292052
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 'b', 'c': 'd'}
    test_dict_immutable = CLIArgs(test_dict)
    assert test_dict_immutable['a'] == 'b'
    assert test_dict_immutable['c'] == 'd'
    assert test_dict_immutable.get('a') == 'b'
    assert test_dict_immutable.get('c') == 'd'
    assert test_dict_immutable.get('e') is None
    assert test_dict_immutable.get('e', 'f') == 'f'
    assert test_dict_immutable.get('a', 'f') == 'b'
    assert test_dict_immutable.get('c', 'f') == 'd'

# Generated at 2022-06-17 15:02:50.777558
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import HumanReadable
    from ansible.module_utils.common.text.formatters import Formatter
    from ansible.module_utils.common.text.formatters import ValueFormatter
    from ansible.module_utils.common.text.formatters import ValueFormatter
    from ansible.module_utils.common.text.formatters import ValueFormatter
    from ansible.module_utils.common.text.formatters import ValueFormatter
    from ansible.module_utils.common.text.formatters import ValueFormatter
    from ansible.module_utils.common.text.formatters import ValueFormatter


# Generated at 2022-06-17 15:03:01.291325
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that the constructor of CLIArgs works as expected
    # Create a dictionary
    test_dict = {'test_key': 'test_value'}
    # Create a CLIArgs object from the dictionary
    test_cli_args = CLIArgs(test_dict)
    # Check that the CLIArgs object is immutable
    assert isinstance(test_cli_args, ImmutableDict)
    # Check that the CLIArgs object is not a Singleton
    assert not isinstance(test_cli_args, Singleton)
    # Check that the CLIArgs object is not a GlobalCLIArgs
    assert not isinstance(test_cli_args, GlobalCLIArgs)
    # Check that the CLIArgs object has the correct key and value
    assert test_cli_args['test_key'] == 'test_value'


# Generated at 2022-06-17 15:03:08.202011
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    import copy
    import types

    # Test that we can't modify the original
    original = {'a': 1, 'b': 2, 'c': 3}
    cli_args = CLIArgs(original)
    assert original == {'a': 1, 'b': 2, 'c': 3}
    assert cli_args == {'a': 1, 'b': 2, 'c': 3}

    # Test that we can't modify the copy
    cli_args['a'] = 5
    assert original == {'a': 1, 'b': 2, 'c': 3}
    assert cli_args == {'a': 1, 'b': 2, 'c': 3}

    # Test that we can't modify the copy
    cli_args['a'] = 5

# Generated at 2022-06-17 15:03:11.360627
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert isinstance(TestClass(), TestClass)
    assert TestClass() is TestClass()

# Generated at 2022-06-17 15:03:21.036218
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

    # Test that the constructor makes a copy of the input
    # and that the copy is immutable
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_obj = CLIArgs(test_dict)
    assert test_obj == test_dict
    assert test_obj is not test_dict
    assert is_immutable(test_obj)

    # Test that the constructor makes a copy of the input
    # and that the copy is immutable
    test_list = [1, 2, 3]
    test_obj = CLIArgs(test_list)
