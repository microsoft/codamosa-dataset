

# Generated at 2022-06-17 14:53:45.228954
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', default='bar')
    parser.add_argument('--baz', default='qux')
    args = parser.parse_args([])
    global_args = GlobalCLIArgs.from_options(args)
    assert global_args['foo'] == 'bar'
    assert global_args['baz'] == 'qux'

# Generated at 2022-06-17 14:53:53.738138
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a dictionary
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_obj = CLIArgs(test_dict)
    assert test_obj == test_dict
    assert isinstance(test_obj, ImmutableDict)

    # Test with a list
    test_list = [1, 2, 3]
    test_obj = CLIArgs(test_list)
    assert test_obj == test_list
    assert isinstance(test_obj, tuple)

    # Test with a set
    test_set = set([1, 2, 3])
    test_obj = CLIArgs(test_set)
    assert test_obj == test_set
    assert isinstance(test_obj, frozenset)

    # Test with a nested dictionary

# Generated at 2022-06-17 14:53:57.651965
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    class Bar(object):
        __metaclass__ = _ABCSingleton

    assert Foo() is Foo()
    assert Bar() is Bar()
    assert Foo() is not Bar()

# Generated at 2022-06-17 14:54:02.654306
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:54:11.456963
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_false')
    parser.add_argument('--qux', action='append')
    parser.add_argument('--quux', nargs='+')
    parser.add_argument('--corge', nargs='*')
    parser.add_argument('--grault', nargs='?')
    parser.add_argument('--garply', default='waldo')
    parser.add_argument('--fred', default=['plugh', 'xyzzy'])
    parser.add_argument('--waldo', default=['thud'])

# Generated at 2022-06-17 14:54:19.385513
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:54:27.595243
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')

    args = parser.parse_args(['--foo', '--bar', '--baz'])

    # This should be the first time we instantiate the class
    args1 = GlobalCLIArgs.from_options(args)
    assert args1.foo is True
    assert args1.bar is True
    assert args1.baz is True
    assert args1.qux is False

    # This should be the second time we instantiate the class
    args2

# Generated at 2022-06-17 14:54:37.553889
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:54:47.552814
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create an instance of CLIArgs
    args = CLIArgs({'foo': 'bar'})
    assert isinstance(args, CLIArgs)
    assert isinstance(args, ImmutableDict)
    assert args == {'foo': 'bar'}

    # Test that we can create an instance of CLIArgs from an options object
    options = type('', (), {'foo': 'bar'})()
    args = CLIArgs.from_options(options)
    assert isinstance(args, CLIArgs)
    assert isinstance(args, ImmutableDict)
    assert args == {'foo': 'bar'}

    # Test that we can create an instance of CLIArgs from an options object with a nested dict
    options = type('', (), {'foo': {'bar': 'baz'}})()

# Generated at 2022-06-17 14:54:58.753397
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_set
    from ansible.module_utils.common.collections import is_mapping
    from ansible.module_utils.common.collections import is_container

    # Test that we can create a GlobalCLIArgs object
    # Test that we can create a GlobalCLIArgs object
    # Test that we can create a GlobalCLIArgs object
    # Test that we can create a GlobalCLIArgs object
    # Test that we can create a GlobalCLIArgs object
    # Test that we can create a GlobalCLIArgs object

# Generated at 2022-06-17 14:55:05.972762
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    args = CLIArgs({'foo': 'bar'})
    assert isinstance(args, ImmutableDict)
    assert args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from a Namespace object
    args = CLIArgs.from_options(Namespace(foo='bar'))
    assert isinstance(args, ImmutableDict)
    assert args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from a Namespace object
    args = CLIArgs.from_options(Namespace(foo=Namespace(bar='baz')))
    assert isinstance(args, ImmutableDict)
    assert args['foo']['bar'] == 'baz'

    # Test that we can create a CLIArgs object from a Namespace object
   

# Generated at 2022-06-17 14:55:11.144853
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 1, 'b': {'c': 2, 'd': [3, 4]}})
    assert isinstance(args, ImmutableDict)
    assert isinstance(args['b'], ImmutableDict)
    assert isinstance(args['b']['d'], tuple)
    assert args['a'] == 1
    assert args['b']['c'] == 2
    assert args['b']['d'][0] == 3
    assert args['b']['d'][1] == 4

# Generated at 2022-06-17 14:55:22.677685
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs constructor works as expected
    """
    # Test that we can create an empty CLIArgs object
    empty_cli_args = CLIArgs({})
    assert empty_cli_args == {}

    # Test that we can create a CLIArgs object with a single string value
    string_cli_args = CLIArgs({'string': 'string'})
    assert string_cli_args == {'string': 'string'}

    # Test that we can create a CLIArgs object with a single integer value
    int_cli_args = CLIArgs({'int': 1})
    assert int_cli_args == {'int': 1}

    # Test that we can create a CLIArgs object with a single float value
    float_cli_args = CLIArgs({'float': 1.0})

# Generated at 2022-06-17 14:55:32.756752
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode

    # Test that we can create an instance of CLIArgs
    cli_args = CLIArgs({})
    assert isinstance(cli_args, CLIArgs)

    # Test that we can create an instance of CLIArgs with a mapping
    cli_args = CLIArgs({'foo': 'bar'})
    assert isinstance(cli_args, CLIArgs)
    assert cli_args['foo'] == 'bar'

    # Test that we can create an instance of CLIArgs with a mapping of mappings


# Generated at 2022-06-17 14:55:41.171040
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.common.text.formatters import HumanReadable
    from ansible.module_utils.common.text.formatters import Formatter
    from ansible.module_utils.common.text.formatters import ValueFormatter
    from ansible.module_utils.common.text.formatters import ValueFormatter
    from ansible.module_utils.common.text.formatters import ValueFormatter
    from ansible.module_utils.common.text.formatters import ValueFormatter
    from ansible.module_utils.common.text.formatters import ValueFormatter

# Generated at 2022-06-17 14:55:50.654538
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.formatters import BOOLEANS_TRUE
    from ansible.module_utils.common.text.formatters import BOOLEANS_FALSE
    from ansible.module_utils.common.text.formatters import to_bool
    from ansible.module_utils.common.text.formatters import to_bytes
    from ansible.module_utils.common.text.formatters import to_float

# Generated at 2022-06-17 14:55:54.027837
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:56:01.609773
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    import copy
    import types
    import unittest

    class TestCLIArgs(unittest.TestCase):
        def test_init(self):
            # Test that we can create a CLIArgs object
            cli_args = CLIArgs({})
            self.assertIsInstance(cli_args, CLIArgs)

            # Test that we can create a CLIArgs object with a dict
            cli_args = CLIArgs({'a': 'b'})
            self.assertIsInstance(cli_args, CLIArgs)

            # Test that we can create a CLIArgs object with a dict with a list
            cli_args = CLIArgs({'a': ['b', 'c']})
            self.assertIsInstance(cli_args, CLIArgs)

            # Test that we can create a CLIArgs object with a dict with a dict
           

# Generated at 2022-06-17 14:56:06.848864
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.module_utils.common.collections import ImmutableSet
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableSequence
    from ansible.module_utils.common.collections import ImmutableMapping
    from ansible.module_utils.common.collections import ImmutableContainer
    from ansible.module_utils.common.collections import MutableMapping
    from ansible.module_utils.common.collections import MutableSequence
    from ansible.module_utils.common.collections import MutableSet

# Generated at 2022-06-17 14:56:15.639116
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 1, 'b': 2})
    assert args['a'] == 1
    assert args['b'] == 2
    assert args.get('c') is None
    assert args.get('c', 3) == 3
    assert args.get('a', 3) == 1
    assert args.get('b', 3) == 2
    assert args.get('a', 'b') == 1
    assert args.get('b', 'a') == 2
    assert args.get('c', 'a') == 'a'
    assert args.get('c', 'b') == 'b'
    assert args.get('c', 'a', 'b') == 'a'
    assert args.get('c', 'b', 'a') == 'b'

# Generated at 2022-06-17 14:56:28.633520
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-17 14:56:35.943024
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    options = Options(
        foo=1,
        bar=2,
        baz=3,
        qux=4,
        quux=5,
        corge=6,
        grault=7,
        garply=8,
        waldo=9,
        fred=10,
        plugh=11,
        xyzzy=12,
        thud=13,
    )

    cli_args = CLIArgs.from_options(options)

    assert cli_args.foo == 1
    assert cli_args.bar == 2
    assert cli_args.baz == 3
    assert cli_args

# Generated at 2022-06-17 14:56:48.387911
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:56:57.233537
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 'b', 'c': {'d': 'e'}, 'f': ['g', 'h']})
    assert args['a'] == 'b'
    assert args['c']['d'] == 'e'
    assert args['f'][0] == 'g'
    assert args['f'][1] == 'h'

    # Make sure we can't change the values
    try:
        args['a'] = 'z'
    except TypeError:
        pass
    else:
        raise AssertionError('Should not be able to change value of args')

    try:
        args['c']['d'] = 'z'
    except TypeError:
        pass
    else:
        raise AssertionError('Should not be able to change value of args')


# Generated at 2022-06-17 14:57:02.104111
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:57:11.090781
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import ansible.utils.display as display
    import ansible.utils.plugin_docs as plugin_docs
    import ansible.utils.vars as vars
    import ansible.utils.version as version
    import ansible.utils.template as template
    import ansible.utils.ssh_functions as ssh_functions
    import ansible.utils.connection as connection
    import ansible.utils.encrypt as encrypt
    import ansible.utils.path as path
    import ansible.utils.plugin_list as plugin_list
    import ansible.utils.sentinel as sentinel
    import ansible.utils.unicode as unicode
    import ansible.utils.vault as vault
    import ansible.utils.vars_plugins as vars_plugins
    import ansible.utils.yaml as yaml
    import ansible

# Generated at 2022-06-17 14:57:22.558289
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:57:25.902451
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:57:31.717027
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', default='bar')
    parser.add_argument('--baz', default='qux')
    args = parser.parse_args(sys.argv[1:])
    GlobalCLIArgs.from_options(args)

# Generated at 2022-06-17 14:57:45.294894
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.json_utils import jsonify
    from ansible.module_utils.common.text.converters import to_bytes

    # Test that the constructor of CLIArgs works as expected
    # Test that the constructor of CLIArgs works as expected
    # Test that the constructor of CLIArgs works as expected
    # Test that the constructor of CLIArgs works as expected
    # Test that the constructor of CLIArgs works as expected
    # Test that the constructor of CLIArgs works as expected
    # Test that the constructor of CLIArgs works as expected
    # Test that the constructor of CLIArgs works as expected
    # Test that the constructor of CLIArgs works as expected
    # Test that the constructor of CLIArgs works as expected
    # Test that the constructor

# Generated at 2022-06-17 14:57:50.927772
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:58:02.663186
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a simple dictionary
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_cli_args = CLIArgs(test_dict)
    assert test_cli_args == test_dict
    assert isinstance(test_cli_args, ImmutableDict)

    # Test with a nested dictionary
    test_dict = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    test_cli_args = CLIArgs(test_dict)
    assert test_cli_args == test_dict
    assert isinstance(test_cli_args, ImmutableDict)
    assert isinstance(test_cli_args['b'], ImmutableDict)

    # Test with a nested dictionary and a list

# Generated at 2022-06-17 14:58:05.573085
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:58:09.550714
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test that GlobalCLIArgs is a singleton
    """
    a = GlobalCLIArgs({'a': 1})
    b = GlobalCLIArgs({'a': 2})
    assert a is b
    assert a == b
    assert a['a'] == b['a']

# Generated at 2022-06-17 14:58:16.058190
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()


# Generated at 2022-06-17 14:58:20.995487
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is B()
    assert A() is C()
    assert B() is C()

# Generated at 2022-06-17 14:58:24.086363
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:58:28.581444
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_GlobalCLIArgs(self):
            # Create a new instance of GlobalCLIArgs
            GlobalCLIArgs()

            # Create a new instance of GlobalCLIArgs
            GlobalCLIArgs()

            # Check that the two instances are the same
            self.assertIs(GlobalCLIArgs(), GlobalCLIArgs())

    # Run the unit test
    sys.exit(unittest.main())

# Generated at 2022-06-17 14:58:39.668856
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a simple dict
    test_dict = {'a': 1, 'b': 2}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert isinstance(test_args, ImmutableDict)

    # Test with a dict with a list
    test_dict = {'a': 1, 'b': [2, 3]}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert isinstance(test_args, ImmutableDict)
    assert isinstance(test_args['b'], tuple)

    # Test with a dict with a dict
    test_dict = {'a': 1, 'b': {'c': 2, 'd': 3}}
    test_args = CLIArgs(test_dict)
    assert test_

# Generated at 2022-06-17 14:58:50.717246
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:59:04.996630
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_GlobalCLIArgs(self):
            # Create a new instance of GlobalCLIArgs
            GlobalCLIArgs()

            # Create a second instance of GlobalCLIArgs
            GlobalCLIArgs()

            # Check that the two instances are the same
            self.assertEqual(sys.getrefcount(GlobalCLIArgs()), 3)

    unittest.main()

# Generated at 2022-06-17 14:59:16.022275
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    args = CLIArgs({'foo': 'bar'})
    assert args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from an options object
    options = type('', (), {'foo': 'bar'})()
    args = CLIArgs.from_options(options)
    assert args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from a nested options object
    options = type('', (), {'foo': {'bar': 'baz'}})()
    args = CLIArgs.from_options(options)
    assert args['foo']['bar'] == 'baz'

    # Test that we can create a CLIArgs object from a nested options object
    options = type('', (), {'foo': ['bar', 'baz']})

# Generated at 2022-06-17 14:59:17.236190
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:59:22.606376
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser.add_argument

# Generated at 2022-06-17 14:59:32.691102
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:59:37.199608
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.utils.display import Display
    display = Display()
    cli = CLI(args=sys.argv[1:], display=display)
    options = cli.parse()
    args = GlobalCLIArgs.from_options(options)
    assert args['ask_vault_pass'] == False

# Generated at 2022-06-17 14:59:46.698697
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict

    # Test that the constructor of GlobalCLIArgs works as expected
    # The constructor of GlobalCLIArgs is the same as the constructor of CLIArgs
    # We test the constructor of CLIArgs here
    # The constructor of CLIArgs is the same as the constructor of ImmutableDict
    # We test the constructor of ImmutableDict here
    # The constructor of ImmutableDict is the same as the constructor of dict
    # We test the constructor of dict here
    # The constructor of dict is the same as the constructor of dict
    # We test the constructor of dict here
    # The constructor of dict is the same as the constructor of dict
    # We test the constructor of dict here
    # The constructor of dict is the same as the constructor of dict
    # We test the

# Generated at 2022-06-17 14:59:53.167364
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    GlobalCLIArgs.from_options(args)
    sys.exit(0)

# Generated at 2022-06-17 14:59:55.982001
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 15:00:07.159518
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_list
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native

# Generated at 2022-06-17 15:00:26.365739
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', default='bar')
    args = parser.parse_args([])
    global_args = GlobalCLIArgs.from_options(args)
    assert global_args['foo'] == 'bar'

# Generated at 2022-06-17 15:00:35.061637
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a dictionary
    test_dict = {'a': 'b', 'c': 'd'}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert test_args.a == 'b'
    assert test_args.c == 'd'
    # Test with a list
    test_list = ['a', 'b', 'c']
    test_args = CLIArgs(test_list)
    assert test_args == test_list
    assert test_args[0] == 'a'
    assert test_args[1] == 'b'
    assert test_args[2] == 'c'
    # Test with a set
    test_set = {'a', 'b', 'c'}
    test_args = CLIArgs(test_set)
    assert test_

# Generated at 2022-06-17 15:00:39.870752
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 15:00:45.890202
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    options = parser.parse_args(['--foo', '--bar'])
    args = GlobalCLIArgs.from_options(options)
    assert args['foo'] is True
    assert args['bar'] is True
    assert args['baz'] is False

# Generated at 2022-06-17 15:00:54.157388
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that the constructor works
    args = CLIArgs({'a': 1, 'b': 2})
    assert args['a'] == 1
    assert args['b'] == 2

    # Test that the constructor works with nested containers
    args = CLIArgs({'a': 1, 'b': [1, 2, 3], 'c': {'d': 4, 'e': [5, 6, 7]}})
    assert args['a'] == 1
    assert args['b'] == (1, 2, 3)
    assert args['c']['d'] == 4
    assert args['c']['e'] == (5, 6, 7)

    # Test that the constructor works with nested containers and strings

# Generated at 2022-06-17 15:00:56.375369
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert isinstance(TestClass(), TestClass)

# Generated at 2022-06-17 15:00:58.583442
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 15:01:07.069263
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.utils.display import Display

    display = Display()
    cli = CLI(args=sys.argv[1:], display=display)
    options = cli.parse()
    args = GlobalCLIArgs.from_options(options)
    assert isinstance(args, GlobalCLIArgs)
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, Mapping)
    assert isinstance(args, Container)
    assert isinstance(args, Sequence)
    assert isinstance(args, Set)

# Generated at 2022-06-17 15:01:17.845195
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import argparse

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)
    # Write json data into the temporary file
    json.dump({'foo': 'bar'}, tmpfile)
    tmpfile.flush()

    # Create the parser
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', default='default_foo')
    parser.add_argument('--bar', default='default_bar')
    parser.add_argument('--baz', default='default_baz')
    parser.add_argument('--json', default=tmpfile.name)
    parser.add_argument

# Generated at 2022-06-17 15:01:24.427476
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 15:01:49.241704
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 15:01:52.048790
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', default='bar')
    args = parser.parse_args([])
    assert GlobalCLIArgs.from_options(args) == {'foo': 'bar'}

# Generated at 2022-06-17 15:02:03.162236
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import CLIArgs
    from ansible.module_utils.common.collections import _make_immutable
    from ansible.module_utils.common.collections import _ABCSingleton
    from ansible.utils.singleton import Singleton
    from ansible.module_utils.six import add_metaclass
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type
    from ansible.module_utils.common._collections_compat import (Container, Mapping, Sequence, Set)
    from ansible.module_utils.common.collections import ImmutableD

# Generated at 2022-06-17 15:02:07.543636
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest
    from ansible.module_utils.common.argparse import CLIArgsParser

    class TestGlobalCLIArgs(unittest.TestCase):
        def setUp(self):
            self.parser = CLIArgsParser(usage="%(prog)s [options]", prog='ansible-test')
            self.parser.add_argument('-a', '--arg1', action='store_true', default=False, dest='arg1')
            self.parser.add_argument('-b', '--arg2', action='store_true', default=False, dest='arg2')
            self.parser.add_argument('-c', '--arg3', action='store_true', default=False, dest='arg3')

# Generated at 2022-06-17 15:02:18.229914
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test for empty dict
    assert CLIArgs({}) == {}

    # Test for dict with one key
    assert CLIArgs({'a': 1}) == {'a': 1}

    # Test for dict with multiple keys
    assert CLIArgs({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}

    # Test for dict with nested dict
    assert CLIArgs({'a': {'b': 1}}) == {'a': {'b': 1}}

    # Test for dict with nested list
    assert CLIArgs({'a': [1, 2, 3]}) == {'a': (1, 2, 3)}

    # Test for dict with nested set
    assert CLIArgs({'a': {1, 2, 3}}) == {'a': frozenset({1, 2, 3})}

    # Test

# Generated at 2022-06-17 15:02:23.043440
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 15:02:33.954408
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_set
    from ansible.module_utils.common.collections import is_mapping

    class TestGlobalCLIArgs(unittest.TestCase):

        def test_init(self):
            # Test that we can initialize a GlobalCLIArgs object
            # and that it is immutable
            options = ImmutableDict({'foo': 'bar'})
            args = GlobalCLIArgs(options)
            self.assertTrue(is_immutable(args))

# Generated at 2022-06-17 15:02:39.104193
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import to_bytes
    from ansible.module_utils.six import PY3

    # Test that we can create a GlobalCLIArgs object
    args = GlobalCLIArgs({'foo': 'bar'})
    assert args['foo'] == 'bar'

    # Test that we can create a GlobalCLIArgs object with a unicode string
    args = GlobalCLIArgs({'foo': to_text('bar')})
    assert args['foo'] == 'bar'

    # Test that we can create a GlobalCLIArgs object with a byte string

# Generated at 2022-06-17 15:02:41.686282
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 15:02:48.716416
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test that the constructor of class GlobalCLIArgs works as expected.
    """
    # Create a dictionary with a list, a tuple, a set, a string, and a dictionary
    test_dict = {'list': [1, 2, 3], 'tuple': (1, 2, 3), 'set': {1, 2, 3}, 'string': 'string', 'dict': {'a': 1, 'b': 2}}
    # Create an instance of GlobalCLIArgs
    test_instance = GlobalCLIArgs(test_dict)
    # Check that the instance is a GlobalCLIArgs
    assert isinstance(test_instance, GlobalCLIArgs)
    # Check that the instance is a CLIArgs
    assert isinstance(test_instance, CLIArgs)
    # Check that the instance is an ImmutableDict

# Generated at 2022-06-17 15:03:36.859816
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.validation import check_type_bool
    from ansible.module_utils.common.validation import check_type_dict
    from ansible.module_utils.common.validation import check_type_list
    from ansible.module_utils.common.validation import check_type_string
    from ansible.module_utils.common.validation import check_type_unicode
    from ansible.module_utils.common.validation import check_type_version
    from ansible.module_utils.common.validation import check_type_version_string
    from ansible.module_utils.common.validation import check_