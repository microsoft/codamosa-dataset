

# Generated at 2022-06-17 14:53:48.617609
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 1, 'b': 2})
    assert args['a'] == 1
    assert args['b'] == 2
    assert args.a == 1
    assert args.b == 2
    assert args == {'a': 1, 'b': 2}
    assert args == {'b': 2, 'a': 1}
    assert args == {'a': 1, 'b': 2, 'c': 3}
    assert args != {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    assert args != {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    assert args != {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6}

# Generated at 2022-06-17 14:53:56.131965
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import collections
    import ansible.module_utils.common.collections
    import ansible.module_utils.common._collections_compat
    import ansible.module_utils.common.text.converters
    import ansible.module_utils.six
    import ansible.utils.singleton

    # Create a new instance of GlobalCLIArgs
    instance = GlobalCLIArgs({})

    # Check that the instance is an instance of GlobalCLIArgs
    assert isinstance(instance, GlobalCLIArgs)

    # Check that the instance is an instance of CLIArgs
    assert isinstance(instance, CLIArgs)

    # Check that the instance is an instance of ImmutableDict
    assert isinstance(instance, ansible.module_utils.common.collections.ImmutableDict)

    # Check that the instance is an instance of Mapping

# Generated at 2022-06-17 14:54:01.752960
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test the CLIArgs class.
    """
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes

    # Test that the constructor works

# Generated at 2022-06-17 14:54:06.255112
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:54:13.665359
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({"a": 1, "b": 2})
    assert args["a"] == 1
    assert args["b"] == 2
    assert args.get("c") is None
    assert args.get("c", 3) == 3
    assert args.get("a", 3) == 1
    assert args.get("b", 3) == 2
    assert args.get("a", 3) == 1
    assert args.get("b", 3) == 2
    assert args.get("a", 3) == 1
    assert args.get("b", 3) == 2
    assert args.get("a", 3) == 1
    assert args.get("b", 3) == 2
    assert args.get("a", 3) == 1
    assert args.get("b", 3) == 2
    assert args.get("a", 3)

# Generated at 2022-06-17 14:54:21.833542
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_constructor(self):
            args = GlobalCLIArgs({'foo': 'bar'})
            self.assertEqual(args['foo'], 'bar')

    suite = unittest.TestLoader().loadTestsFromTestCase(TestGlobalCLIArgs)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    sys.exit(not result.wasSuccessful())

# Generated at 2022-06-17 14:54:32.332763
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    args = parser.parse_args([])
    GlobalCLIArgs.from_options(args)
    assert GlobalCLIArgs.instance is not None
    assert GlobalCLIArgs.instance['foo'] is False
    assert GlobalCLIArgs.instance['bar'] is False
    assert GlobalCLIArgs.instance['baz'] is False
    assert GlobalCLIArgs.instance['qux'] is False

# Generated at 2022-06-17 14:54:44.455693
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_init(self):
            class Options(object):
                def __init__(self, **kwargs):
                    self.__dict__.update(kwargs)

            options = Options(foo='bar', baz=42)
            args = GlobalCLIArgs.from_options(options)
            self.assertEqual(args['foo'], 'bar')
            self.assertEqual(args['baz'], 42)

    suite = unittest.TestLoader().loadTestsFromModule(sys.modules[__name__])
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-17 14:54:47.991818
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton(object):
        __metaclass__ = _ABCSingleton

    assert isinstance(TestSingleton(), TestSingleton)
    assert isinstance(TestSingleton(), Singleton)
    assert isinstance(TestSingleton(), ABCMeta)

# Generated at 2022-06-17 14:54:55.259249
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.text.converters import to_text

    # Create a dict with a nested dict, list, and set
    test_dict = {
        'test_dict': {
            'test_dict_key': 'test_dict_value',
        },
        'test_list': [
            'test_list_value',
        ],
        'test_set': {
            'test_set_value',
        },
    }

    # Create a CLIArgs object from the dict
    cli_args = CLIArgs(test_dict)

    # Make sure that the CLIArgs object is immutable
    assert is_immutable(cli_args)

    # Make sure that the CLIArgs object is a dict

# Generated at 2022-06-17 14:55:03.011731
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    args = parser.parse_args([])
    cli_args = GlobalCLIArgs.from_options(args)
    assert cli_args['foo'] is False
    assert cli_args['bar'] is False

# Generated at 2022-06-17 14:55:11.878255
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:55:23.647270
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.module_utils.common.collections import ImmutableDict

    cli = CLI(args=['--version'])
    cli.parse()
    cli_args = cli.options

    global_cli_args = GlobalCLIArgs.from_options(cli_args)

    assert isinstance(global_cli_args, ImmutableDict)
    assert isinstance(global_cli_args, GlobalCLIArgs)
    assert isinstance(global_cli_args, CLIArgs)
    assert global_cli_args['version'] is True
    assert global_cli_args['verbosity'] == 0
    assert global_cli_args['inventory'] == '/etc/ansible/hosts'

# Generated at 2022-06-17 14:55:31.305150
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])

    # Test that we can create a GlobalCLIArgs object
    GlobalCLIArgs.from_options(args)

    # Test that we can't create a second GlobalCLIArgs object
    try:
        GlobalCLIArgs.from_options(args)
    except RuntimeError:
        sys.exit(0)
    else:
        sys.exit(1)

# Generated at 2022-06-17 14:55:43.812334
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create an instance of CLIArgs
    cli_args = CLIArgs({'foo': 'bar'})
    assert isinstance(cli_args, CLIArgs)
    assert cli_args['foo'] == 'bar'

    # Test that we can create an instance of CLIArgs from an options object
    class Options(object):
        def __init__(self):
            self.foo = 'bar'
    options = Options()
    cli_args = CLIArgs.from_options(options)
    assert isinstance(cli_args, CLIArgs)
    assert cli_args['foo'] == 'bar'

    # Test that we can create an instance of CLIArgs from an options object
    class Options(object):
        def __init__(self):
            self.foo = 'bar'
    options = Options()
    cli

# Generated at 2022-06-17 14:55:45.603330
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:55:53.945711
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that the constructor works
    args = CLIArgs({'foo': 'bar'})
    assert args['foo'] == 'bar'

    # Test that the constructor works with a nested dict
    args = CLIArgs({'foo': {'bar': 'baz'}})
    assert args['foo']['bar'] == 'baz'

    # Test that the constructor works with a nested list
    args = CLIArgs({'foo': ['bar', 'baz']})
    assert args['foo'][0] == 'bar'
    assert args['foo'][1] == 'baz'

    # Test that the constructor works with a nested set
    args = CLIArgs({'foo': {'bar', 'baz'}})
    assert 'bar' in args['foo']
    assert 'baz' in args['foo']

    # Test that

# Generated at 2022-06-17 14:55:56.816796
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object):
        __metaclass__ = _ABCSingleton

    assert isinstance(Test(), Test)
    assert Test() is Test()

# Generated at 2022-06-17 14:56:07.020422
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a dict
    test_dict = {'a': 'b', 'c': 'd'}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert test_args.a == 'b'
    assert test_args.c == 'd'

    # Test with a list
    test_list = [1, 2, 3, 4]
    test_args = CLIArgs(test_list)
    assert test_args == test_list
    assert test_args[0] == 1
    assert test_args[1] == 2
    assert test_args[2] == 3
    assert test_args[3] == 4

    # Test with a set
    test_set = {1, 2, 3, 4}
    test_args = CLIArgs(test_set)
   

# Generated at 2022-06-17 14:56:10.782378
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', default='bar')
    parser.add_argument('--baz', default='qux')
    args = parser.parse_args([])
    GlobalCLIArgs.from_options(args)

# Generated at 2022-06-17 14:56:25.169357
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    import pytest

    # Test that we can create a CLIArgs object from a dict
    test_dict = {'a': 'b', 'c': 'd'}
    args = CLIArgs(test_dict)
    assert args == test_dict

    # Test that we can create a CLIArgs object from a collections.OrderedDict
    test_dict = collections.OrderedDict()
    test_dict['a'] = 'b'
    test_dict['c'] = 'd'
    args = CLIArgs(test_dict)
    assert args == test_dict

    # Test that we can create a CLIArgs object from a collections.defaultdict
    test_dict = collections.defaultdict(str)
    test_dict['a'] = 'b'
    test_dict['c'] = 'd'
    args = CLIArgs

# Generated at 2022-06-17 14:56:33.550135
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3

    # Test for constructor of class CLIArgs
    # Test for constructor of class CLIArgs
    # Test for constructor of class CLIArgs
    # Test for constructor of class CLIArgs
    # Test for constructor of class CLIArgs
    # Test for constructor of class CLIArgs
    # Test for constructor of class CLIArgs
    # Test for constructor of class CLIArgs
    # Test for constructor of class CLIArgs
    # Test for constructor of class CLIArgs
    # Test for constructor of class CLIArgs
    # Test for constructor of class CLIArgs
    # Test for constructor of class CLIArgs
    # Test for constructor of class CLIArgs
    # Test for

# Generated at 2022-06-17 14:56:46.552298
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six import PY3

    # Test with a simple dictionary
    test_dict = {'a': 'b', 'c': 'd'}
    test_args = CLIArgs(test_dict)
    assert isinstance(test_args, ImmutableDict)
    assert test_args == test_dict

    # Test with a dictionary with a list

# Generated at 2022-06-17 14:56:50.666708
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:56:55.724340
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:57:02.141017
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    GlobalCLIArgs.from_options(args)
    # If we get here, the constructor didn't throw an exception
    sys.exit(0)

# Generated at 2022-06-17 14:57:11.132129
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser.add_argument

# Generated at 2022-06-17 14:57:12.666412
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:57:15.614406
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:57:19.602942
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:57:25.299923
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(TestClass(), TestClass)
    assert isinstance(TestClass(), Singleton)
    assert isinstance(TestClass(), ABCMeta)
    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:57:36.571838
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs can be constructed with a dictionary and that it will convert all of the
    containers in the dictionary to immutable containers.
    """
    test_dict = {
        'a': 'a',
        'b': {
            'b1': 'b1',
            'b2': ['b2', 'b3'],
            'b3': {
                'b31': 'b31',
                'b32': ['b32', 'b33'],
            },
        },
        'c': ['c1', 'c2'],
    }
    test_cli_args = CLIArgs(test_dict)
    assert test_cli_args == test_dict
    assert isinstance(test_cli_args, ImmutableDict)

# Generated at 2022-06-17 14:57:47.268974
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--foo", action="store_true")
    parser.add_argument("--bar", action="store_true")
    parser.add_argument("--baz", action="store_true")
    parser.add_argument("--qux", action="store_true")
    parser.add_argument("--quux", action="store_true")
    parser.add_argument("--corge", action="store_true")
    parser.add_argument("--grault", action="store_true")
    parser.add_argument("--garply", action="store_true")
    parser.add_argument("--waldo", action="store_true")
    parser.add_argument("--fred", action="store_true")
    parser

# Generated at 2022-06-17 14:57:51.305406
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:57:55.818690
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode

# Generated at 2022-06-17 14:58:08.273082
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    args = CLIArgs({'foo': 'bar'})
    assert isinstance(args, CLIArgs)
    assert args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from an options object
    from ansible.cli import CLI
    from ansible.config.manager import ConfigManager
    from ansible.utils.display import Display
    display = Display()
    config_manager = ConfigManager(args=['ansible-playbook', '--foo', 'bar'], display=display)
    cli = CLI(config_manager)
    options = cli.parse()
    args = CLIArgs.from_options(options)
    assert isinstance(args, CLIArgs)
    assert args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from

# Generated at 2022-06-17 14:58:19.904506
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.module_utils.common.collections import ImmutableSet
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableSequence
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_set
    from ansible.module_utils.common.collections import is_dict
    from ansible.module_utils.common.collections import is_container

# Generated at 2022-06-17 14:58:26.720272
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:58:31.936039
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:58:45.636860
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.module_utils.common.collections import CLIArgs
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_set
    from ansible.module_utils.common.collections import is_mapping
    from ansible.module_utils.common.collections import is_container
    from ansible.module_utils.common.collections import is_binary
    from ansible.module_utils.common.collections import is_text
    from ansible.module_utils.common.collections import is_

# Generated at 2022-06-17 14:59:02.646529
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.module_utils.common.collections import ImmutableSet
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableSequence
    from ansible.module_utils.common.collections import ImmutableMapping
    from ansible.module_utils.common.collections import ImmutableContainer

    # Test that we can create an instance of CLIArgs

# Generated at 2022-06-17 14:59:13.830207
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type

    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'foo': 'bar'})
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args['foo'] == 'bar'

    # Test that we can create a CLIArgs object with a unicode string

# Generated at 2022-06-17 14:59:18.468611
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:59:25.007230
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.utils.display import Display
    display = Display()
    cli = CLI(args=sys.argv[1:], display=display)
    options = cli.parse()
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-17 14:59:28.469226
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:59:35.001002
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_constructor(self):
            # Test that the constructor works
            args = GlobalCLIArgs({'foo': 'bar'})
            self.assertEqual(args['foo'], 'bar')

            # Test that the constructor makes the object immutable
            with self.assertRaises(TypeError):
                args['foo'] = 'baz'

            # Test that the constructor makes the object immutable
            with self.assertRaises(TypeError):
                args['baz'] = 'qux'

            # Test that the constructor makes the object immutable
            with self.assertRaises(TypeError):
                del args['foo']

            # Test that the constructor makes the object immutable

# Generated at 2022-06-17 14:59:37.509715
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _TestClass(object):
        __metaclass__ = _ABCSingleton
    assert _TestClass() is _TestClass()

# Generated at 2022-06-17 14:59:47.021772
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test that the GlobalCLIArgs class is a singleton
    """
    import sys
    import os
    import tempfile
    import shutil
    import subprocess

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, tmpfile = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary python script
    fd, tmpscript = tempfile.mkstemp(suffix='.py')
    os.write(fd, b"""#!/usr/bin/env python
import sys
from ansible.module_utils.common.collections import GlobalCLIArgs

args = GlobalCLIArgs.from_options(sys.modules['__main__'].options)
print(args)
""")

# Generated at 2022-06-17 14:59:51.941468
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')

    args = parser.parse_args(sys.argv[1:])
    GlobalCLIArgs.from_options(args)

# Generated at 2022-06-17 14:59:54.011587
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({'a': 1, 'b': 2})
    assert args['a'] == 1
    assert args['b'] == 2

# Generated at 2022-06-17 15:00:09.763725
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 15:00:19.077919
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(args=['--foo', '--bar'])

    # Test that we can create an instance of GlobalCLIArgs
    GlobalCLIArgs.from_options(args)

    # Test that we can't create a second instance of GlobalCLIArgs
    try:
        GlobalCLIArgs.from_options(args)
    except RuntimeError as e:
        assert 'GlobalCLIArgs already instantiated' in str(e)

# Generated at 2022-06-17 15:00:22.784242
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 15:00:29.492788
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(sys.argv[1:])
    cli_args = GlobalCLIArgs.from_options(args)
    assert cli_args['foo'] is True
    assert cli_args['bar'] is True
    assert cli_args['baz'] is True

# Generated at 2022-06-17 15:00:40.166719
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.utils.display import Display
    display = Display()
    cli = CLI(args=sys.argv[1:], display=display)
    options = cli.parse()
    args = GlobalCLIArgs.from_options(options)
    assert args['connection'] == 'smart'
    assert args['module_path'] == '/usr/share/ansible/plugins/modules'
    assert args['forks'] == 5
    assert args['become'] is False
    assert args['become_method'] == 'sudo'
    assert args['become_user'] == 'root'
    assert args['check'] is False
    assert args['diff'] is False
    assert args['inventory'] == '/etc/ansible/hosts'
    assert args['listhosts']

# Generated at 2022-06-17 15:00:48.264586
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    args = parser.parse_args(['--foo', '--bar', '--baz', '--qux'])
    global_args = GlobalCLIArgs.from_options(args)
    assert global_args['foo'] is True
    assert global_args['bar'] is True
    assert global_args['baz'] is True
    assert global_args['qux'] is True

# Generated at 2022-06-17 15:00:55.805453
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert D() is D()
    assert A() is B()
    assert A() is C()
    assert A() is D()
    assert B() is C()
    assert B() is D()
    assert C() is D()

# Generated at 2022-06-17 15:00:57.721037
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', default='bar')
    args = parser.parse_args([])
    global_args = GlobalCLIArgs.from_options(args)
    assert global_args['foo'] == 'bar'

# Generated at 2022-06-17 15:01:00.327430
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 15:01:10.003696
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Unit test for CLIArgs constructor
    """
    # Test that we can create a CLIArgs object
    test_dict = {'a': 1, 'b': 2}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict

    # Test that we can create a CLIArgs object from an options object
    test_dict = {'a': 1, 'b': 2}
    test_options = type('', (), test_dict)
    test_args = CLIArgs.from_options(test_options)
    assert test_args == test_dict

    # Test that we can create a CLIArgs object from an options object with nested objects
    test_dict = {'a': 1, 'b': {'c': 3, 'd': 4}, 'e': [5, 6]}
    test_options = type

# Generated at 2022-06-17 15:01:37.909586
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 'b', 'c': 'd'}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict

# Generated at 2022-06-17 15:01:47.983593
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # test for empty dict
    assert CLIArgs({}) == {}
    # test for dict with one element
    assert CLIArgs({'a': 1}) == {'a': 1}
    # test for dict with multiple elements
    assert CLIArgs({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    # test for dict with nested dict
    assert CLIArgs({'a': {'b': 1}}) == {'a': {'b': 1}}
    # test for dict with nested list
    assert CLIArgs({'a': [1, 2]}) == {'a': (1, 2)}
    # test for dict with nested set
    assert CLIArgs({'a': {1, 2}}) == {'a': frozenset([1, 2])}
    # test for dict with nested tuple

# Generated at 2022-06-17 15:01:57.568006
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that the constructor works
    test_dict = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': [5, 6, 7], 'g': (8, 9, 10), 'h': {11, 12, 13}}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert isinstance(test_args, ImmutableDict)
    assert isinstance(test_args['c'], ImmutableDict)
    assert isinstance(test_args['f'], tuple)
    assert isinstance(test_args['g'], tuple)
    assert isinstance(test_args['h'], frozenset)
    assert test_args['c']['d'] == 3

# Generated at 2022-06-17 15:02:07.154089
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test the CLIArgs class
    """
    # Test the constructor of class CLIArgs
    test_dict = {'a': 'b', 'c': 'd'}
    test_cli_args = CLIArgs(test_dict)
    assert test_cli_args == test_dict
    assert isinstance(test_cli_args, ImmutableDict)
    assert isinstance(test_cli_args, Mapping)
    assert isinstance(test_cli_args, Container)
    assert not isinstance(test_cli_args, Sequence)
    assert not isinstance(test_cli_args, Set)
    assert test_cli_args.a == 'b'
    assert test_cli_args.c == 'd'
    assert test_cli_args['a'] == 'b'
    assert test_cli_args['c']

# Generated at 2022-06-17 15:02:11.782443
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.module_utils.common.collections import ImmutableDict

    # Test that GlobalCLIArgs is a singleton
    a = GlobalCLIArgs({'a': 1})
    b = GlobalCLIArgs({'b': 2})
    assert a is b

    # Test that GlobalCLIArgs is immutable
    with pytest.raises(AttributeError):
        a['c'] = 3

    # Test that GlobalCLIArgs is a subclass of ImmutableDict
    assert isinstance(a, ImmutableDict)

# Generated at 2022-06-17 15:02:23.262634
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs constructor works as expected
    """
    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'foo': 'bar'})
    assert cli_args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from an optparse.Values object
    from ansible.utils.display import Display
    from ansible.utils.plugin_docs import get_docstring
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_vars_from_inventory
    from ansible.utils.vars import load_vars

# Generated at 2022-06-17 15:02:34.188921
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # pylint: disable=protected-access
    assert GlobalCLIArgs._instances == {}
    assert GlobalCLIArgs._instances == {}
    assert GlobalCLIArgs._instances == {}
    assert GlobalCLIArgs._instances == {}
    assert GlobalCLIArgs._instances == {}
    assert GlobalCLIArgs._instances == {}
    assert GlobalCLIArgs._instances == {}
    assert GlobalCLIArgs._instances == {}
    assert GlobalCLIArgs._instances == {}
    assert GlobalCLIArgs._instances == {}
    assert GlobalCLIArgs._instances == {}
    assert GlobalCLIArgs._instances == {}
    assert GlobalCLIArgs._instances == {}
    assert GlobalCLIArgs._instances == {}
    assert GlobalCLIArgs._instances == {}
    assert GlobalCLIArgs._

# Generated at 2022-06-17 15:02:46.695472
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a simple dict
    test_dict = {'a': 1, 'b': 2}
    test_cli_args = CLIArgs(test_dict)
    assert test_cli_args['a'] == 1
    assert test_cli_args['b'] == 2

    # Test with a nested dict
    test_dict = {'a': 1, 'b': {'c': 2, 'd': 3}}
    test_cli_args = CLIArgs(test_dict)
    assert test_cli_args['a'] == 1
    assert test_cli_args['b']['c'] == 2
    assert test_cli_args['b']['d'] == 3

    # Test with a nested list
    test_dict = {'a': 1, 'b': [2, 3]}
    test_cli_args = CLIArgs

# Generated at 2022-06-17 15:02:50.408590
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    class Bar(object):
        __metaclass__ = _ABCSingleton

    assert Foo() is Foo()
    assert Bar() is Bar()
    assert Foo() is not Bar()

# Generated at 2022-06-17 15:02:55.470187
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.module_utils.common.collections import ImmutableDict

    cli = CLI(args=sys.argv[1:])
    options = cli.parse()
    args = GlobalCLIArgs.from_options(options)
    assert isinstance(args, ImmutableDict)

# Generated at 2022-06-17 15:03:37.162436
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs constructor works as expected
    """
    # Test that the constructor works as expected