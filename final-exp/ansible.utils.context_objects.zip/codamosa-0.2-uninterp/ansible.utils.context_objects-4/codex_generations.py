

# Generated at 2022-06-17 14:53:45.528197
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a simple dict
    test_dict = {'a': 'b', 'c': 'd'}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert test_args['a'] == 'b'
    assert test_args['c'] == 'd'
    assert test_args.a == 'b'
    assert test_args.c == 'd'

    # Test with a nested dict
    test_dict = {'a': 'b', 'c': {'d': 'e', 'f': 'g'}}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert test_args['a'] == 'b'
    assert test_args['c'] == {'d': 'e', 'f': 'g'}


# Generated at 2022-06-17 14:53:48.622741
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:53:52.863357
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:53:58.230364
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:53:59.996652
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object):
        __metaclass__ = _ABCSingleton

    assert Test() is Test()

# Generated at 2022-06-17 14:54:02.652148
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert issubclass(TestClass, Singleton)
    assert issubclass(TestClass, ABCMeta)

# Generated at 2022-06-17 14:54:11.456142
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    import copy
    import sys
    import types

    # Create a copy of the CLIArgs class and make it mutable
    MutableCLIArgs = copy.deepcopy(CLIArgs)
    MutableCLIArgs.__setitem__ = dict.__setitem__
    MutableCLIArgs.__delitem__ = dict.__delitem__

    # Create a copy of the CLIArgs class and make it mutable
    MutableGlobalCLIArgs = copy.deepcopy(GlobalCLIArgs)
    MutableGlobalCLIArgs.__setitem__ = dict.__setitem__
    MutableGlobalCLIArgs.__delitem__ = dict.__delitem__

    # Create a copy of the CLIArgs class and make it mutable
    MutableImmutableDict = copy.deepcopy(ImmutableDict)
    Mut

# Generated at 2022-06-17 14:54:14.456472
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    cli_args = GlobalCLIArgs.from_options(args)
    assert cli_args['foo'] is True
    assert cli_args['bar'] is True

# Generated at 2022-06-17 14:54:25.102561
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'foo': 'bar'})
    assert cli_args['foo'] == 'bar'

    # Test that we can create a CLIArgs object with a nested dict
    cli_args = CLIArgs({'foo': {'bar': 'baz'}})
    assert cli_args['foo']['bar'] == 'baz'

    # Test that we can create a CLIArgs object with a nested list
    cli_args = CLIArgs({'foo': ['bar', 'baz']})
    assert cli_args['foo'][0] == 'bar'
    assert cli_args['foo'][1] == 'baz'

    # Test that we can create a CLIArgs object with a nested set

# Generated at 2022-06-17 14:54:32.052532
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert D() is D()
    assert B() is C()
    assert B() is D()
    assert C() is D()

# Generated at 2022-06-17 14:54:40.717973
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:54:46.216450
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    GlobalCLIArgs.from_options(args)

# Generated at 2022-06-17 14:54:50.995625
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:55:02.718406
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest
    import tempfile
    import shutil
    import os

    class TestGlobalCLIArgs(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.tempdir, 'test_file')
            with open(self.test_file, 'w') as f:
                f.write('test')

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_GlobalCLIArgs(self):
            from ansible.cli.arguments import option_helpers
            from ansible.module_utils.common.collections import ImmutableDict

            # Create a fake options object
            options = option_helpers.create_base_

# Generated at 2022-06-17 14:55:11.668312
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # pylint: disable=protected-access
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=no-self-use
    # pylint: disable=too-few-public-methods
    class Options(object):
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)


# Generated at 2022-06-17 14:55:17.025347
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
    class TestClass2(object):
        __metaclass__ = _ABCSingleton
    assert TestClass() is TestClass()
    assert TestClass2() is TestClass2()
    assert TestClass() is not TestClass2()

# Generated at 2022-06-17 14:55:20.494918
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:55:25.422172
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is B()
    assert A() is C()
    assert B() is C()

# Generated at 2022-06-17 14:55:36.230234
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.module_utils.common.collections import CLIArgs
    import sys
    import os
    import tempfile
    import shutil
    import json
    import pytest

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    d = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)

    # Create the test_file
    test_file = d.name

    # Close the file
    d.close()

    # Write data to the test_file
    with open(test_file, 'wb') as f:
        f.write(b"{\"ANSIBLE_MODULE_ARGS\":{\"test\":\"test\"}}")

    # Create

# Generated at 2022-06-17 14:55:41.344007
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import subprocess
    import unittest

    class TestCLIArgs(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.tempdir, 'test_file')
            self.test_file_content = '{"foo": "bar", "baz": ["qux", "quux"]}'
            with open(self.test_file, 'w') as f:
                f.write(self.test_file_content)

        def tearDown(self):
            shutil.rmtree(self.tempdir)


# Generated at 2022-06-17 14:55:51.520732
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import string_types

    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'foo': 'bar'})
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args, Mapping)
    assert isinstance(cli_args, Container)
    assert isinstance(cli_args, CLIArgs)
    assert not isinstance(cli_args, GlobalCLIArgs)

    # Test that we can create a GlobalCLIArgs object
    cli_args = GlobalCLIArgs({'foo': 'bar'})

# Generated at 2022-06-17 14:56:00.309204
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:56:08.656695
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'foo': 'bar'})
    assert cli_args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from an options object
    from ansible.utils.display import Display
    from ansible.utils.plugin_docs import get_docstring
    from ansible.plugins.loader import module_loader
    from ansible.parsing.plugin_docs import read_docstub
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.constructor import AnsibleConstructor
   

# Generated at 2022-06-17 14:56:17.246349
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    args = CLIArgs({'a': 1, 'b': 2})
    assert isinstance(args, CLIArgs)

    # Test that we can create a CLIArgs object with a nested dict
    args = CLIArgs({'a': 1, 'b': {'c': 2, 'd': 3}})
    assert isinstance(args, CLIArgs)

    # Test that we can create a CLIArgs object with a nested list
    args = CLIArgs({'a': 1, 'b': [2, 3]})
    assert isinstance(args, CLIArgs)

    # Test that we can create a CLIArgs object with a nested set
    args = CLIArgs({'a': 1, 'b': {2, 3}})
    assert isinstance(args, CLIArgs)

    # Test that we can create a CLI

# Generated at 2022-06-17 14:56:28.283124
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that CLIArgs works as expected
    args = CLIArgs({'foo': 'bar'})
    assert args['foo'] == 'bar'
    assert args.get('foo') == 'bar'
    assert args.get('baz') is None
    assert args.get('baz', 'qux') == 'qux'
    assert args.get('baz', default='qux') == 'qux'
    assert args.get('baz', 'qux', 'quux') == 'qux'

# Generated at 2022-06-17 14:56:35.816634
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar', '--baz'])
    global_args = GlobalCLIArgs.from_options(args)
    assert global_args['foo']
    assert global_args['bar']
    assert global_args['baz']
    assert global_args.get('foo')
    assert global_args.get('bar')
    assert global_args.get('baz')
    assert global_args.get('not_foo') is None

# Generated at 2022-06-17 14:56:43.721412
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:56:55.593871
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('-a', '--arg1', action='store_true')
    parser.add_argument('-b', '--arg2', action='store_true')
    parser.add_argument('-c', '--arg3', action='store_true')
    parser.add_argument('-d', '--arg4', action='store_true')
    parser.add_argument('-e', '--arg5', action='store_true')
    parser.add_argument('-f', '--arg6', action='store_true')
    parser.add_argument('-g', '--arg7', action='store_true')
    parser.add_argument('-h', '--arg8', action='store_true')

# Generated at 2022-06-17 14:57:00.871819
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    GlobalCLIArgs.from_options(args)

# Generated at 2022-06-17 14:57:09.797809
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest


# Generated at 2022-06-17 14:57:22.268520
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:57:30.277602
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import collections
    import copy
    import types

    # Test that the constructor of GlobalCLIArgs makes a copy of the input
    # and that the copy is immutable
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_dict_copy = copy.deepcopy(test_dict)
    test_dict_copy['a'] = 10
    test_dict_copy['b'] = 20
    test_dict_copy['c'] = 30
    test_dict_copy['d'] = 40
    test_dict_copy['e'] = 50
    test_dict_copy['f'] = 60
    test_dict_copy['g'] = 70
    test_dict_copy['h'] = 80
    test_dict_copy['i'] = 90
    test_dict_copy['j'] = 100
   

# Generated at 2022-06-17 14:57:33.499812
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    assert A() is A()
    assert B() is B()
    assert A() is not B()
    assert B() is not A()

# Generated at 2022-06-17 14:57:37.565279
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:57:39.584342
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        pass

    assert Test() is Test()

# Generated at 2022-06-17 14:57:47.581056
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test CLIArgs constructor
    """
    # pylint: disable=protected-access
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-nested-blocks
    # pylint: disable=unbalanced-tuple-unpacking
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=expression-not-assigned
    # pylint: disable=singleton-comparison
    # pylint: disable=unsubscriptable-object
    # pylint: disable=unsupported-membership-test
    # pylint: disable=un

# Generated at 2022-06-17 14:57:58.488979
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import HumanReadable
    from ansible.module_utils.common.text.formatters import Formatter
    from ansible.module_utils.common.text.formatters import ValueFormatter
    from ansible.module_utils.common.text.formatters import ValueFormatter
    from ansible.module_utils.common.text.formatters import ValueFormatter
    from ansible.module_utils.common.text.formatters import ValueFormatter
    from ansible.module_utils.common.text.formatters import ValueFormatter

# Generated at 2022-06-17 14:58:09.087692
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_list
    from ansible.module_utils.common.text.converters import to_set
    from ansible.module_utils.common.text.converters import to_dict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

# Generated at 2022-06-17 14:58:20.995072
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli.arguments import CLIArgumentParser
    from ansible.module_utils.common.collections import ImmutableDict

    parser = CLIArgumentParser(usage='%(prog)s [options]',
                               description='Ansible command line tool')
    parser.add_argument('--version', action='version', version='%(prog)s 1.0')
    parser.add_argument('-v', '--verbose', dest='verbosity', action='count', default=0,
                        help='verbose mode (-vvv for more, -vvvv to enable connection debugging)')
    parser.add_argument('-C', '--check', dest='check', action='store_true',
                        help='don\'t make any changes; instead, try to predict some of the changes that may occur')
   

# Generated at 2022-06-17 14:58:25.778467
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert isinstance(TestClass(), TestClass)
    assert isinstance(TestClass(), Singleton)
    assert isinstance(TestClass(), ABCMeta)

# Generated at 2022-06-17 14:58:35.744061
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    GlobalCLIArgs.from_options(args)
    assert GlobalCLIArgs()['foo'] is True
    assert GlobalCLIArgs()['bar'] is True
    assert GlobalCLIArgs()['baz'] is False

# Generated at 2022-06-17 14:58:43.599778
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs constructor works as expected
    """
    test_dict = {
        'a': 'a',
        'b': 'b',
        'c': {
            'd': 'd',
            'e': 'e',
            'f': {
                'g': 'g',
                'h': 'h',
            },
        },
        'i': [
            'i',
            'j',
            'k',
            {
                'l': 'l',
                'm': 'm',
            },
        ],
        'n': set(['n', 'o', 'p']),
    }
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert test_args.c == test_dict['c']

# Generated at 2022-06-17 14:58:51.025739
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    args = parser.parse_args([])
    cli_args = GlobalCLIArgs.from_options(args)
    assert cli_args == {'foo': False, 'bar': False, 'baz': False, 'qux': False}

# Generated at 2022-06-17 14:59:02.773435
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.utils.display import Display
    from ansible.utils.plugin_docs import get_docstring

    display = Display()
    display.verbosity = 4

    # Create a fake module to test the CLIArgs class
    fake_module = StringIO()
    fake_module.write(u'#!/usr/bin/python\n')
    fake_module.write(u'# -*- coding: utf-8 -*-\n')
    fake_module.write(u'\n')

# Generated at 2022-06-17 14:59:13.945275
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs is immutable
    """
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict

    # Test that CLIArgs is immutable
    args = CLIArgs({'a': 1, 'b': 2, 'c': 3})
    with pytest.raises(TypeError):
        args['a'] = 2
    with pytest.raises(TypeError):
        args['d'] = 4
    with pytest.raises(TypeError):
        del args['a']
    with pytest.raises(TypeError):
        args.pop('a')
    with pytest.raises(TypeError):
        args.popitem()
    with pytest.raises(TypeError):
        args.clear()
    with pytest.raises(TypeError):
        args

# Generated at 2022-06-17 14:59:15.743466
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:59:21.601183
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.module_utils.common.collections import ImmutableSet
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableSequence

    # Test that the constructor works
    args = CLIArgs({'a': 1, 'b': 2})
    assert isinstance(args, ImmutableDict)

    # Test that the constructor works with a nested dict
    args = CLIArgs({'a': 1, 'b': {'c': 2}})
    assert isinstance(args, ImmutableDict)
    assert isinstance(args['b'], ImmutableDict)

    # Test that the

# Generated at 2022-06-17 14:59:32.947682
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-17 14:59:46.489555
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode

# Generated at 2022-06-17 14:59:49.573462
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert isinstance(TestClass(), TestClass)
    assert TestClass() is TestClass()

# Generated at 2022-06-17 15:00:04.965566
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test the CLIArgs constructor
    """
    # Test that we can create an instance of CLIArgs
    args = CLIArgs({})
    assert isinstance(args, CLIArgs)

    # Test that we can create an instance of CLIArgs with a mapping
    args = CLIArgs({'a': 1, 'b': 2})
    assert isinstance(args, CLIArgs)

    # Test that we can create an instance of CLIArgs with a mapping with a list
    args = CLIArgs({'a': 1, 'b': [1, 2, 3]})
    assert isinstance(args, CLIArgs)

    # Test that we can create an instance of CLIArgs with a mapping with a dict
    args = CLIArgs({'a': 1, 'b': {'c': 3, 'd': 4}})
    assert isinstance(args, CLIArgs)



# Generated at 2022-06-17 15:00:15.238012
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes

    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({"foo": "bar"})
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args["foo"] == "bar"

    # Test that we can create a CLIArgs object from an options object
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_yaml_vars

# Generated at 2022-06-17 15:00:21.681430
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'foo': 'bar'})
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from an options object
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 15:00:24.180272
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 15:00:28.344381
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    options = Options(foo=1, bar=2, baz=3)
    args = GlobalCLIArgs.from_options(options)
    assert args['foo'] == 1
    assert args['bar'] == 2
    assert args['baz'] == 3

# Generated at 2022-06-17 15:00:38.954374
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    args = CLIArgs({'foo': 'bar'})
    assert args['foo'] == 'bar'

    # Test that we can create a CLIArgs object with a nested dict
    args = CLIArgs({'foo': {'bar': 'baz'}})
    assert args['foo']['bar'] == 'baz'

    # Test that we can create a CLIArgs object with a nested list
    args = CLIArgs({'foo': ['bar', 'baz']})
    assert args['foo'][0] == 'bar'
    assert args['foo'][1] == 'baz'

    # Test that we can create a CLIArgs object with a nested set
    args = CLIArgs({'foo': {'bar', 'baz'}})
    assert 'bar' in args['foo']


# Generated at 2022-06-17 15:00:44.434320
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 15:00:50.326274
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    GlobalCLIArgs.from_options(args)

# Generated at 2022-06-17 15:00:59.825908
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'foo': 'bar'})
    assert cli_args['foo'] == 'bar'

    # Test that we can't modify the CLIArgs object
    try:
        cli_args['foo'] = 'baz'
    except TypeError:
        pass
    else:
        assert False, "Should not be able to modify CLIArgs object"

    # Test that we can't modify the CLIArgs object
    try:
        cli_args.update({'foo': 'baz'})
    except TypeError:
        pass
    else:
        assert False, "Should not be able to modify CLIArgs object"

    # Test that we can't modify the CLIArgs object

# Generated at 2022-06-17 15:01:03.963983
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': [5, 6, 7]})
    assert args['a'] == 1
    assert args['b'] == 2
    assert args['c']['d'] == 3
    assert args['c']['e'] == 4
    assert args['f'][0] == 5
    assert args['f'][1] == 6
    assert args['f'][2] == 7

# Generated at 2022-06-17 15:01:18.419618
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    options = parser.parse_args([])
    args = GlobalCLIArgs.from_options(options)
    assert args['foo'] is False
    assert args['bar'] is False
    assert args['baz'] is False

# Generated at 2022-06-17 15:01:19.807733
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton(_ABCSingleton):
        pass

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-17 15:01:25.519999
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.module_utils.common.collections import ImmutableDict

    cli = CLI(args=sys.argv[1:])
    options = cli.parse()

    args = GlobalCLIArgs.from_options(options)
    assert isinstance(args, ImmutableDict)

# Generated at 2022-06-17 15:01:37.005171
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs constructor works as expected
    """
    # Test that the constructor works as expected

# Generated at 2022-06-17 15:01:47.532181
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    from ansible.module_utils.six import PY3

    # Test that we can create a CLIArgs object
    args = CLIArgs({'foo': 'bar'})
    assert isinstance(args, ImmutableDict)
    assert args['foo'] == 'bar'

    # Test that we can create a CLIArgs object with a list
    args = CLIArgs({'foo': ['bar', 'baz']})
    assert isinstance(args, ImmutableDict)
    assert args['foo'] == ('bar', 'baz')

    # Test that we can create a CLIArgs object with a dict

# Generated at 2022-06-17 15:01:57.215865
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_set
    from ansible.module_utils.common.collections import is_mapping
    from ansible.module_utils.common.collections import is_container
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.collections import is_sequence_of
    from ansible.module_utils.common.collections import is_set_of
    from ansible.module_utils.common.collections import is_mapping_of

# Generated at 2022-06-17 15:02:06.958612
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 15:02:08.357205
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 15:02:13.750494
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    args = parser.parse_args(['--foo', '--bar', '--baz', '--qux'])
    global_args = GlobalCLIArgs.from_options(args)
    assert global_args['foo'] is True
    assert global_args['bar'] is True
    assert global_args['baz'] is True
    assert global_args['qux'] is True

# Generated at 2022-06-17 15:02:19.092255
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is B()
    assert A() is C()
    assert B() is C()

# Generated at 2022-06-17 15:02:44.556946
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    GlobalCLIArgs.from_options(args)
    sys.exit(0)

# Generated at 2022-06-17 15:02:48.915162
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 1, 'b': {'c': 2, 'd': 3}, 'e': [1, 2, 3]})
    assert args['a'] == 1
    assert args['b']['c'] == 2
    assert args['b']['d'] == 3
    assert args['e'][0] == 1
    assert args['e'][1] == 2
    assert args['e'][2] == 3

    # Test that we can't modify the dict
    try:
        args['a'] = 2
    except TypeError:
        pass
    else:
        raise AssertionError('Should not be able to modify the dict')

    try:
        args['b']['c'] = 3
    except TypeError:
        pass

# Generated at 2022-06-17 15:03:00.052825
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 1, 'b': {'c': 2, 'd': {'e': 3}}, 'f': [4, 5, {'g': 6}]})
    assert isinstance(args, ImmutableDict)
    assert args['a'] == 1
    assert isinstance(args['b'], ImmutableDict)
    assert args['b']['c'] == 2
    assert isinstance(args['b']['d'], ImmutableDict)
    assert args['b']['d']['e'] == 3
    assert isinstance(args['f'], tuple)
    assert args['f'][0] == 4
    assert args['f'][1] == 5
    assert isinstance(args['f'][2], ImmutableDict)

# Generated at 2022-06-17 15:03:08.682328
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that the constructor of CLIArgs works
    # Test that it converts a dict into an ImmutableDict
    test_dict = {'a': 1, 'b': 2}
    cli_args = CLIArgs(test_dict)
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args == test_dict

    # Test that it converts a list into a tuple
    test_list = [1, 2, 3]
    cli_args = CLIArgs(test_list)
    assert isinstance(cli_args, tuple)
    assert cli_args == test_list

    # Test that it converts a set into a frozenset
    test_set = {1, 2, 3}
    cli_args = CLIArgs(test_set)
    assert isinstance(cli_args, frozenset)

# Generated at 2022-06-17 15:03:12.732178
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 15:03:19.526869
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser.add_argument

# Generated at 2022-06-17 15:03:25.422749
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is B()
    assert A() is C()
    assert B() is C()