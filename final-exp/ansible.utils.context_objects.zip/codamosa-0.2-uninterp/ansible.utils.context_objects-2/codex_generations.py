

# Generated at 2022-06-17 14:53:47.240433
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 'b', 'c': 'd'}
    test_obj = CLIArgs(test_dict)
    assert test_obj == test_dict
    assert isinstance(test_obj, ImmutableDict)
    assert isinstance(test_obj, Mapping)
    assert not isinstance(test_obj, Sequence)
    assert not isinstance(test_obj, Set)
    assert not isinstance(test_obj, Container)
    assert not isinstance(test_obj, dict)
    assert not isinstance(test_obj, list)
    assert not isinstance(test_obj, set)
    assert not isinstance(test_obj, tuple)
    assert not isinstance(test_obj, object)


# Generated at 2022-06-17 14:53:50.286102
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:53:54.096418
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:54:04.412006
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a dictionary
    test_dict = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert isinstance(test_args, ImmutableDict)
    assert isinstance(test_args['c'], ImmutableDict)
    assert isinstance(test_args['c']['e'], int)
    assert test_args['c']['e'] == 4
    # Test with a list
    test_list = [1, 2, 3, 4]
    test_args = CLIArgs(test_list)
    assert test_args == test_list
    assert isinstance(test_args, tuple)
    assert isinstance(test_args[0], int)


# Generated at 2022-06-17 14:54:08.319302
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is B()
    assert A() is C()
    assert B() is C()

# Generated at 2022-06-17 14:54:11.034583
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    class Bar(object):
        __metaclass__ = _ABCSingleton

    assert Foo() is Foo()
    assert Bar() is Bar()
    assert Foo() is not Bar()

# Generated at 2022-06-17 14:54:19.022848
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.six import string_types

    # Test that we can create a CLIArgs object
    args = CLIArgs({'foo': 'bar'})
    assert isinstance(args, ImmutableDict)
    assert args['foo'] == 'bar'

    # Test that we can create a CLIArgs object with a nested dict
    args = CLIArgs({'foo': {'bar': 'baz'}})
    assert isinstance(args, ImmutableDict)
    assert isinstance(args['foo'], ImmutableDict)
    assert args['foo']['bar'] == 'baz'

    # Test that we can create a CLIArgs object with a

# Generated at 2022-06-17 14:54:27.094270
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_constructor(self):
            # Make sure that we can construct a GlobalCLIArgs object
            # and that it is a Singleton
            #
            # We need to use the sys.modules trick to get the class
            # because we are in the same module as the class and
            # importing it would cause a circular import.
            cli_args = sys.modules[__name__].GlobalCLIArgs({'foo': 'bar'})
            self.assertEqual(cli_args['foo'], 'bar')
            self.assertIs(cli_args, sys.modules[__name__].GlobalCLIArgs({'foo': 'bar'}))

    unittest.main()

# Generated at 2022-06-17 14:54:31.549313
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:54:45.019467
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict

    with pytest.raises(TypeError):
        GlobalCLIArgs()

    with pytest.raises(TypeError):
        GlobalCLIArgs({'a': 1})

    with pytest.raises(TypeError):
        GlobalCLIArgs({'a': 1}, {'b': 2})

    with pytest.raises(TypeError):
        GlobalCLIArgs({'a': 1}, b=2)

    with pytest.raises(TypeError):
        GlobalCLIArgs(a=1, b=2)

    with pytest.raises(TypeError):
        GlobalCLIArgs(a=1)

    with pytest.raises(TypeError):
        GlobalCLIArgs(1)


# Generated at 2022-06-17 14:54:51.967163
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
        pass

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:55:03.720060
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser.add_argument

# Generated at 2022-06-17 14:55:07.060905
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(TestClass(), TestClass)
    assert isinstance(TestClass(), Singleton)
    assert isinstance(TestClass(), ABCMeta)

# Generated at 2022-06-17 14:55:09.921018
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:55:16.630391
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:55:23.330587
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:55:33.414200
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that CLIArgs constructor works
    args = CLIArgs({'foo': 'bar', 'baz': 'qux'})
    assert args['foo'] == 'bar'
    assert args['baz'] == 'qux'

    # Test that CLIArgs constructor works with nested dicts
    args = CLIArgs({'foo': 'bar', 'baz': {'qux': 'quux'}})
    assert args['foo'] == 'bar'
    assert args['baz']['qux'] == 'quux'

    # Test that CLIArgs constructor works with nested lists
    args = CLIArgs({'foo': 'bar', 'baz': ['qux', 'quux']})
    assert args['foo'] == 'bar'
    assert args['baz'][0] == 'qux'

# Generated at 2022-06-17 14:55:44.573640
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that the constructor of CLIArgs works as expected
    # Create a dictionary
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    # Create an instance of CLIArgs
    test_instance = CLIArgs(test_dict)
    # Check that the instance is an instance of CLIArgs
    assert isinstance(test_instance, CLIArgs)
    # Check that the instance is an instance of ImmutableDict
    assert isinstance(test_instance, ImmutableDict)
    # Check that the instance is an instance of Mapping
    assert isinstance(test_instance, Mapping)
    # Check that the instance is an instance of Container
    assert isinstance(test_instance, Container)
    # Check that the instance is an instance of Sequence
    assert not isinstance(test_instance, Sequence)
    # Check that the

# Generated at 2022-06-17 14:55:53.366930
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a simple dictionary
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    cli_args = CLIArgs(test_dict)
    assert cli_args == test_dict

    # Test with a nested dictionary
    test_dict = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    cli_args = CLIArgs(test_dict)
    assert cli_args == test_dict

    # Test with a nested dictionary and a list
    test_dict = {'a': 1, 'b': {'c': 2, 'd': [3, 4, 5]}, 'e': 4}
    cli_args = CLIArgs(test_dict)
    assert cli_args == test_dict

    # Test with a nested dictionary

# Generated at 2022-06-17 14:55:56.033646
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:56:05.643985
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()
    assert isinstance(A(), A)
    assert isinstance(B(), A)
    assert isinstance(C(), A)
    assert not isinstance(A(), B)
    assert not isinstance(A(), C)
    assert not isinstance(B(), C)

# Generated at 2022-06-17 14:56:11.928443
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.module_utils.common.collections import ImmutableSet
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableSequence

    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'a': 1, 'b': 2})
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args, CLIArgs)
    assert cli_args['a'] == 1
    assert cli_args['b'] == 2

    # Test that we can create a CLIArgs object from an options object
    # This is the same

# Generated at 2022-06-17 14:56:24.563544
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3

    # Test that the constructor works
    args = CLIArgs({'a': 1, 'b': 2})
    assert isinstance(args, ImmutableDict)
    assert args == {'a': 1, 'b': 2}

    # Test that the constructor converts to immutable
    args = CLIArgs({'a': 1, 'b': {'c': 3, 'd': 4}, 'e': [5, 6, 7]})
    assert isinstance(args, ImmutableDict)

# Generated at 2022-06-17 14:56:27.058345
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    class Bar(Foo):
        pass

    assert Foo() is Foo()
    assert Bar() is Bar()
    assert Foo() is not Bar()

# Generated at 2022-06-17 14:56:35.201520
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser.add_argument

# Generated at 2022-06-17 14:56:42.573381
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is B()
    assert A() is C()
    assert B() is C()

# Generated at 2022-06-17 14:56:47.887831
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:56:56.228129
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode

# Generated at 2022-06-17 14:57:00.471144
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.utils.display import Display
    display = Display()
    cli = CLI(args=sys.argv[1:], display=display)
    options = cli.parse()
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-17 14:57:12.092100
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_false')
    parser.add_argument('--list', nargs='*')
    parser.add_argument('--dict', nargs='*')
    parser.add_argument('--set', nargs='*')
    parser.add_argument('--tuple', nargs='*')
    parser.add_argument('--list_of_dicts', nargs='*')
    parser.add_argument('--list_of_sets', nargs='*')

# Generated at 2022-06-17 14:57:14.866346
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:57:25.692261
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:57:36.615341
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_false')
    parser.add_argument('--qux', action='append')
    parser.add_argument('--quux', action='append_const', const='const')
    parser.add_argument('--corge', action='count')
    parser.add_argument('--grault', action='store_const', const='const')
    parser.add_argument('--garply', action='store_false')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store')

# Generated at 2022-06-17 14:57:40.118631
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.module_utils.common.collections import ImmutableDict

    cli = CLI(args=sys.argv[1:])
    options = cli.parse()
    args = GlobalCLIArgs.from_options(options)
    assert isinstance(args, ImmutableDict)

# Generated at 2022-06-17 14:57:47.217821
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])

    cli_args = CLIArgs.from_options(args)
    assert cli_args['foo'] is True
    assert cli_args['bar'] is True
    assert cli_args['baz'] is False

    # Make sure we can't change the values
    try:
        cli_args['foo'] = False
    except TypeError:
        pass
    else:
        assert False, "Should not be able to change values in CLIArgs"

# Generated at 2022-06-17 14:57:57.282466
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    import json

    # Test that the constructor works
    args = CLIArgs({'foo': 'bar'})
    assert args['foo'] == 'bar'

    # Test that the constructor makes a copy of the input
    args = CLIArgs({'foo': 'bar'})
    args['foo'] = 'baz'
    assert args['foo'] == 'baz'

    # Test that the constructor makes a copy of the input
    args = CLIArgs({'foo': 'bar'})
    args['foo'] = 'baz'
    assert args['foo'] == 'baz'

    # Test that the constructor makes a copy of the input

# Generated at 2022-06-17 14:58:03.199877
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args([])
    GlobalCLIArgs.from_options(args)

# Generated at 2022-06-17 14:58:12.326454
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest

    class TestGlobalCLIArgs(unittest.TestCase):
        def setUp(self):
            self.old_argv = sys.argv
            sys.argv = ['ansible-playbook', '-i', 'inventory', 'playbook.yml']

        def tearDown(self):
            sys.argv = self.old_argv

        def test_GlobalCLIArgs(self):
            from ansible.cli import CLI
            from ansible.utils.display import Display
            display = Display()
            cli = CLI(args=sys.argv[1:], display=display)
            cli.parse()
            cli_args = GlobalCLIArgs.from_options(cli.options)
            self.assertIsInstance(cli_args, GlobalCLIArgs)


# Generated at 2022-06-17 14:58:23.214293
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    import json
    import os
    import sys

    # Create a test file to read in
    test_file = to_bytes(os.path.join(os.path.dirname(__file__), 'test_CLIArgs.json'))
    with open(test_file, 'rb') as f:
        test_data = json.load(f)

    # Create a CLIArgs object from the test data
    cli_args = CLIArgs(test_data)

    # Test that the CLIArgs object is immutable

# Generated at 2022-06-17 14:58:33.336296
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    # pylint: disable=unused-variable
    cli_args = CLIArgs({})

    # Test that we can create a CLIArgs object with a dict
    cli_args = CLIArgs({'foo': 'bar'})

    # Test that we can create a CLIArgs object with a list
    cli_args = CLIArgs({'foo': ['bar']})

    # Test that we can create a CLIArgs object with a set
    cli_args = CLIArgs({'foo': set(['bar'])})

    # Test that we can create a CLIArgs object with a tuple
    cli_args = CLIArgs({'foo': ('bar',)})

    # Test that we can create a CLIArgs object with a dict of dicts

# Generated at 2022-06-17 14:58:40.683172
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:58:50.750174
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a dict
    test_dict = {'a': 'b', 'c': 'd'}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert test_args.a == 'b'
    assert test_args.c == 'd'

    # Test with a list
    test_list = ['a', 'b', 'c']
    test_args = CLIArgs(test_list)
    assert test_args == test_list
    assert test_args[0] == 'a'
    assert test_args[1] == 'b'
    assert test_args[2] == 'c'

    # Test with a tuple
    test_tuple = ('a', 'b', 'c')
    test_args = CLIArgs(test_tuple)
    assert test_

# Generated at 2022-06-17 14:59:02.731175
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-17 14:59:13.906865
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.utils.display import Display
    from ansible.utils.path import makedirs_safe
    from ansible.utils.plugin_docs import get_docstring

    # Create a dummy set of options
    class Options(object):
        def __init__(self):
            self.connection = 'local'
            self.module_path = None
            self.forks = 5
            self.remote_user = 'root'
            self.private_key_file = None
            self.ssh_common_args = None
            self.ssh_extra_args = None
            self.sftp_extra_args = None
            self.scp_extra_args

# Generated at 2022-06-17 14:59:16.797504
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:59:20.776773
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.utils.display import Display
    display = Display()
    cli = CLI(args=sys.argv[1:], display=display)
    options = cli.parse()
    args = GlobalCLIArgs.from_options(options)
    assert isinstance(args, GlobalCLIArgs)
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, Mapping)
    assert isinstance(args, Container)
    assert isinstance(args, Sequence)

# Generated at 2022-06-17 14:59:27.534662
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:59:28.348957
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:59:29.970853
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:59:34.444823
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    a = A()
    b = B()
    c = C()

    assert a is b
    assert a is c
    assert b is c

# Generated at 2022-06-17 14:59:48.357148
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:59:57.432163
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.utils.display import Display
    display = Display()
    cli = CLI(args=sys.argv[1:], display=display)
    options = cli.parse()
    args = GlobalCLIArgs.from_options(options)
    assert args['connection'] == 'smart'
    assert args['module_path'] == '/usr/share/ansible/plugins/modules'
    assert args['forks'] == 5
    assert args['become'] is False
    assert args['become_method'] == 'sudo'
    assert args['become_user'] == 'root'
    assert args['check'] is False
    assert args['diff'] is False
    assert args['listhosts'] is False
    assert args['listtasks'] is False
    assert args

# Generated at 2022-06-17 15:00:08.082844
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    import copy
    import sys

    # Make a copy of sys.argv so we can modify it
    argv = copy.copy(sys.argv)

    # Remove the first argument (the name of the program)
    argv.pop(0)

    # Make a new parser
    parser = collections.namedtuple('parser', ['parse_args'])(lambda: collections.namedtuple('args', ['foo', 'bar'])('foo', 'bar'))

    # Make a new CLIArgs object
    cli_args = CLIArgs.from_options(parser.parse_args(argv))

    # Make sure the object is immutable
    try:
        cli_args['foo'] = 'baz'
    except TypeError:
        pass

# Generated at 2022-06-17 15:00:14.541556
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 'b', 'c': {'d': 'e'}, 'f': ['g', 'h', {'i': 'j'}]}
    test_object = CLIArgs(test_dict)
    assert test_object == test_dict
    assert isinstance(test_object, ImmutableDict)
    assert isinstance(test_object['c'], ImmutableDict)
    assert isinstance(test_object['f'], tuple)
    assert isinstance(test_object['f'][2], ImmutableDict)

# Generated at 2022-06-17 15:00:21.455797
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.module_utils.common.collections import CLIArgs
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_mutable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_set
    from ansible.module_utils.common.collections import is_mapping
    from ansible.module_utils.common.collections import is_container
    from ansible.module_utils.common.collections import is_primitive

    # Test that GlobalCLIArgs is a Singleton
   

# Generated at 2022-06-17 15:00:30.480617
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')

# Generated at 2022-06-17 15:00:38.227807
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.module_utils.common.collections import ImmutableSet
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableSequence
    from ansible.module_utils.common.collections import ImmutableMapping
    from ansible.module_utils.common.collections import ImmutableContainer
    from ansible.module_utils.common.collections import MutableMapping
    from ansible.module_utils.common.collections import MutableSequence
    from ansible.module_utils.common.collections import MutableSet

# Generated at 2022-06-17 15:00:50.517507
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text

    # Test that the constructor works
    args = GlobalCLIArgs({'foo': 'bar'})
    assert isinstance(args, ImmutableDict)
    assert args['foo'] == 'bar'

    # Test that the constructor works with unicode
    args = GlobalCLIArgs({'foo': to_text('bar')})
    assert isinstance(args, ImmutableDict)
    assert args['foo'] == to_text('bar')

    # Test that the constructor works with bytes
    args = GlobalCLIArgs({'foo': to_bytes('bar')})

# Generated at 2022-06-17 15:00:59.960276
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.module_utils.common.collections import ImmutableSet
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableSequence
    from ansible.module_utils.common.collections import ImmutableMapping
    from ansible.module_utils.common.collections import ImmutableContainer

    # Test that the constructor makes a copy of the input
    a = {'a': 1, 'b': 2, 'c': 3}
    b = CLIArgs(a)
    assert a == b
    assert a is not b

    # Test that the constructor makes a copy of the input
   

# Generated at 2022-06-17 15:01:09.785994
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import string_types

    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'foo': 'bar'})
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from an options object
    from ansible.cli.arguments import Options
    options = Options()
    options.foo = 'bar'
    cli_args = CLIArgs.from_options(options)

# Generated at 2022-06-17 15:01:29.178023
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    args = parser.parse_args(['--foo', '--bar', '--baz'])
    global_args = GlobalCLIArgs.from_options(args)
    assert global_args['foo'] is True
    assert global_args['bar'] is True
    assert global_args['baz'] is True
    assert global_args['qux'] is False

# Generated at 2022-06-17 15:01:32.524865
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 15:01:45.610703
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.six import PY3

    # Test basic types
    assert isinstance(CLIArgs({}), ImmutableDict)
    assert isinstance(CLIArgs({'a': 1}), ImmutableDict)
    assert isinstance(CLIArgs({'a': 1, 'b': 2}), ImmutableDict)

    # Test that we can't modify the dict

# Generated at 2022-06-17 15:01:47.133294
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 15:01:56.925414
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs constructor works as expected
    """
    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'foo': 'bar'})
    assert cli_args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from an options object
    from ansible.utils.display import Display
    from ansible.cli import CLI
    display = Display()
    cli = CLI(args=[], display=display)
    options = cli.parse()
    cli_args = CLIArgs.from_options(options)
    assert cli_args['verbosity'] == 0

    # Test that we can create a CLIArgs object from an options object with a non-default verbosity
    display = Display()
    cli = CLI(args=['-v'], display=display)

# Generated at 2022-06-17 15:02:02.180348
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 15:02:04.929161
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 15:02:12.213132
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        def __init__(self):
            self.foo = 'bar'
            self.baz = 'qux'
            self.list = ['a', 'b', 'c']
            self.dict = {'a': 'b', 'c': 'd'}
            self.set = {'a', 'b', 'c'}

    options = Options()
    cli_args = CLIArgs.from_options(options)
    assert cli_args['foo'] == 'bar'
    assert cli_args['baz'] == 'qux'
    assert cli_args['list'] == ('a', 'b', 'c')
    assert cli_args['dict'] == ImmutableDict({'a': 'b', 'c': 'd'})

# Generated at 2022-06-17 15:02:23.398057
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    cli_args = CLIArgs.from_options(args)
    assert cli_args['foo'] is True
    assert cli_args['bar'] is True
    assert cli_args['baz'] is False
    assert cli_args['baz'] is not None
    assert cli_args['baz'] is not False
    assert cli_args['baz'] is not True
    assert cli_args['baz'] is not 0

# Generated at 2022-06-17 15:02:34.371034
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a dictionary
    test_dict = {'a': 'b', 'c': 'd'}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict

    # Test with a list
    test_list = ['a', 'b', 'c', 'd']
    test_args = CLIArgs(test_list)
    assert test_args == test_list

    # Test with a set
    test_set = {'a', 'b', 'c', 'd'}
    test_args = CLIArgs(test_set)
    assert test_args == test_set

    # Test with a tuple
    test_tuple = ('a', 'b', 'c', 'd')
    test_args = CLIArgs(test_tuple)
    assert test_args == test_tuple



# Generated at 2022-06-17 15:02:54.661704
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 15:02:58.032659
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 15:03:06.847454
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test the constructor of class CLIArgs
    """
    # Test with a dictionary
    dictionary = {'a': 1, 'b': 2, 'c': 3}
    cli_args = CLIArgs(dictionary)
    assert cli_args == dictionary

    # Test with a list
    list_ = [1, 2, 3]
    cli_args = CLIArgs(list_)
    assert cli_args == list_

    # Test with a set
    set_ = {1, 2, 3}
    cli_args = CLIArgs(set_)
    assert cli_args == set_

    # Test with a tuple
    tuple_ = (1, 2, 3)
    cli_args = CLIArgs(tuple_)
    assert cli_args == tuple_

    # Test with a string
   

# Generated at 2022-06-17 15:03:14.967075
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    gargs = GlobalCLIArgs.from_options(args)
    assert gargs['foo'] is True
    assert gargs['bar'] is True
    assert gargs['baz'] is False

# Generated at 2022-06-17 15:03:23.084886
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    import json

    test_dict = {'a': {'b': {'c': {'d': 'e'}}}}
    test_dict_json = to_text(json.dumps(test_dict))
    test_cli_args = CLIArgs(test_dict)
    assert isinstance(test_cli_args, ImmutableDict)
    assert test_cli_args == ImmutableDict(test_dict)
    assert test_cli_args == ImmutableDict(json.loads(test_dict_json))
    assert test_cli_args == ImmutableDict(json.loads(test_dict_json))
    assert test_cli_args == Imm

# Generated at 2022-06-17 15:03:35.126595
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser