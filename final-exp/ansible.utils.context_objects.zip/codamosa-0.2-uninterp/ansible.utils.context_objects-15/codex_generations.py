

# Generated at 2022-06-17 14:53:42.055943
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test1(object):
        __metaclass__ = _ABCSingleton

    class Test2(object):
        __metaclass__ = _ABCSingleton

    assert Test1() is Test2()

# Generated at 2022-06-17 14:53:46.660589
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is B()
    assert A() is C()
    assert B() is C()

# Generated at 2022-06-17 14:53:49.907484
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:53:54.763267
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': [5, 6, 7]})
    assert args['a'] == 1
    assert args['b'] == 2
    assert args['c']['d'] == 3
    assert args['c']['e'] == 4
    assert args['f'][0] == 5
    assert args['f'][1] == 6
    assert args['f'][2] == 7

# Generated at 2022-06-17 14:54:04.911419
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:54:10.290904
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    GlobalCLIArgs.from_options(args)
    sys.exit(0)

# Generated at 2022-06-17 14:54:18.429521
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a simple dictionary
    test_dict = {'a': 1, 'b': 2}
    cli_args = CLIArgs(test_dict)
    assert cli_args == test_dict
    assert isinstance(cli_args, ImmutableDict)

    # Test with a nested dictionary
    test_dict = {'a': 1, 'b': {'c': 2, 'd': 3}}
    cli_args = CLIArgs(test_dict)
    assert cli_args == test_dict
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args['b'], ImmutableDict)

    # Test with a nested list
    test_dict = {'a': 1, 'b': [1, 2, 3]}

# Generated at 2022-06-17 14:54:26.932711
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar', action='append')
    parser.add_argument('--baz', action='append')
    parser.add_argument('--qux', action='append_const', const='qux')
    parser.add_argument('--quux', action='append_const', const='quux')
    parser.add_argument('--corge', action='append_const', const='corge')
    parser.add_argument('--grault', action='append_const', const='grault')
    parser.add_argument('--garply', action='append_const', const='garply')
    parser.add_argument('--waldo', action='append_const', const='waldo')

# Generated at 2022-06-17 14:54:32.797628
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:54:45.146819
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test the CLIArgs constructor to make sure it makes the data immutable
    """
    test_dict = {
        'a': 'b',
        'c': {
            'd': 'e',
            'f': ['g', 'h', 'i'],
            'j': {
                'k': 'l',
                'm': ['n', 'o', 'p'],
            },
        },
    }
    cli_args = CLIArgs(test_dict)
    assert cli_args == test_dict
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args['c'], ImmutableDict)
    assert isinstance(cli_args['c']['f'], tuple)

# Generated at 2022-06-17 14:54:58.158256
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:55:08.545401
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text

    # Create a new GlobalCLIArgs object
    cli_args = GlobalCLIArgs({'foo': 'bar'})

    # Test that the object is an instance of ImmutableDict
    assert isinstance(cli_args, ImmutableDict)

    # Test that the object is an instance of GlobalCLIArgs
    assert isinstance(cli_args, GlobalCLIArgs)

    # Test that the object is an instance of CLIArgs
    assert isinstance(cli_args, CLIArgs)

    # Test that the object is an instance of Singleton
    assert isinstance(cli_args, Singleton)

    # Test that the object is an instance of ABCMeta


# Generated at 2022-06-17 14:55:14.774110
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:55:20.131093
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:55:30.101600
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-17 14:55:37.535765
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')

    args = parser.parse_args(sys.argv[1:])

    cli_args = CLIArgs.from_options(args)
    assert cli_args['foo'] == args.foo
    assert cli_args['bar'] == args.bar
    assert cli_args['baz'] == args.baz

# Generated at 2022-06-17 14:55:40.622638
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:55:46.144325
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    GlobalCLIArgs.from_options(args)

# Generated at 2022-06-17 14:55:52.173592
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    options = parser.parse_args(['--foo', '--bar'])
    args = GlobalCLIArgs.from_options(options)
    assert args['foo'] is True
    assert args['bar'] is True
    assert args['baz'] is False

# Generated at 2022-06-17 14:55:59.589687
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=redefined-outer-name
    # pylint: disable=too-few-public-methods
    class Options(object):
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    options = Options(foo='bar', baz=['qux', 'quux'])
    args = GlobalCLIArgs.from_options(options)
    assert args['foo'] == 'bar'
    assert args['baz'] == ('qux', 'quux')

# Generated at 2022-06-17 14:56:10.144773
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'foo': 'bar'})
    assert cli_args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from an options object
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    options = parser.parse_args(['--foo', 'bar'])
    cli_args = CLIArgs.from_options(options)
    assert cli_args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from a nested options object
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar')

# Generated at 2022-06-17 14:56:11.699836
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:56:15.089715
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.module_utils.common.collections import ImmutableDict

    # Test that GlobalCLIArgs is a singleton
    args1 = GlobalCLIArgs({'foo': 'bar'})
    args2 = GlobalCLIArgs({'foo': 'bar'})
    assert args1 is args2

    # Test that GlobalCLIArgs is immutable
    with pytest.raises(TypeError):
        args1['foo'] = 'baz'

    # Test that GlobalCLIArgs is a subclass of ImmutableDict
    assert isinstance(args1, ImmutableDict)

# Generated at 2022-06-17 14:56:17.539835
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:56:19.820237
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:56:24.467911
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:56:32.967375
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test the CLIArgs class constructor
    """
    # Test that we can create a CLIArgs object
    assert CLIArgs({})

    # Test that we can create a CLIArgs object with a dictionary
    assert CLIArgs({'a': 1})

    # Test that we can create a CLIArgs object with a dictionary with a list
    assert CLIArgs({'a': [1, 2, 3]})

    # Test that we can create a CLIArgs object with a dictionary with a list with a dictionary
    assert CLIArgs({'a': [1, 2, 3, {'b': 4}]})

    # Test that we can create a CLIArgs object with a dictionary with a list with a dictionary with a list
    assert CLIArgs({'a': [1, 2, 3, {'b': [4, 5, 6]}]})

    # Test that we can create

# Generated at 2022-06-17 14:56:40.858246
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:56:43.586421
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is B()
    assert A() is C()
    assert B() is C()

# Generated at 2022-06-17 14:56:48.505084
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:57:02.728186
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])

    global_args = GlobalCLIArgs.from_options(args)

    assert global_args['foo'] is True
    assert global_args['bar'] is True
    assert global_args['baz'] is False

# Generated at 2022-06-17 14:57:13.142495
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('-a', action='store_true', default=False)
    parser.add_argument('-b', action='store_true', default=False)
    parser.add_argument('-c', action='store_true', default=False)
    parser.add_argument('-d', action='store_true', default=False)
    parser.add_argument('-e', action='store_true', default=False)
    parser.add_argument('-f', action='store_true', default=False)
    parser.add_argument('-g', action='store_true', default=False)
    parser.add_argument('-h', action='store_true', default=False)

# Generated at 2022-06-17 14:57:18.356270
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:57:21.972930
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:57:30.076414
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test CLIArgs constructor
    """
    test_dict = {
        'foo': 'bar',
        'baz': {
            'qux': 'quux',
            'corge': 'grault',
        },
        'waldo': [
            'fred',
            'plugh',
            'xyzzy',
        ],
    }
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert test_args.baz == test_dict['baz']
    assert test_args.baz.qux == test_dict['baz']['qux']
    assert test_args.waldo == test_dict['waldo']
    assert test_args.waldo[0] == test_dict['waldo'][0]
    assert test_args.wald

# Generated at 2022-06-17 14:57:31.717395
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:57:37.702338
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:57:42.520842
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:57:52.642370
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')

# Generated at 2022-06-17 14:58:02.427451
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that the constructor works
    args = CLIArgs({'a': 1, 'b': 2})
    assert args['a'] == 1
    assert args['b'] == 2
    assert args.get('c', 3) == 3
    assert 'c' not in args

    # Test that the constructor works with a nested dict
    args = CLIArgs({'a': 1, 'b': {'c': 2}})
    assert args['a'] == 1
    assert args['b']['c'] == 2

    # Test that the constructor works with a nested list
    args = CLIArgs({'a': 1, 'b': [1, 2, 3]})
    assert args['a'] == 1
    assert args['b'][0] == 1
    assert args['b'][1] == 2

# Generated at 2022-06-17 14:58:27.347342
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    args = parser.parse_args([])
    GlobalCLIArgs.from_options(args)

# Generated at 2022-06-17 14:58:38.679484
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    import json

    # Test the constructor of class CLIArgs
    # Test the constructor of class CLIArgs

# Generated at 2022-06-17 14:58:48.622368
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_false')
    parser.add_argument('--qux', type=int)
    parser.add_argument('--quux', type=float)
    parser.add_argument('--corge', type=str)
    parser.add_argument('--grault', type=list)
    parser.add_argument('--garply', type=dict)
    parser.add_argument('--waldo', type=set)
    parser.add_argument('--fred', type=tuple)
    parser.add_argument('--plugh', type=complex)
    parser.add_

# Generated at 2022-06-17 14:59:02.603385
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:59:13.791110
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.module_utils.common.collections import ImmutableSet
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableSequence
    from ansible.module_utils.common.collections import ImmutableContainer

    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'foo': 'bar'})
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args, ImmutableContainer)
    assert isinstance(cli_args, ImmutableMapping)
    assert isinstance(cli_args, ImmutableSequence)


# Generated at 2022-06-17 14:59:17.218223
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:59:23.532844
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test the constructor of class CLIArgs
    """
    # Test with a simple dictionary
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_obj = CLIArgs(test_dict)
    assert test_obj == test_dict

    # Test with a dictionary with a list
    test_dict = {'a': 1, 'b': 2, 'c': [1, 2, 3]}
    test_obj = CLIArgs(test_dict)
    assert test_obj == test_dict

    # Test with a dictionary with a dictionary
    test_dict = {'a': 1, 'b': 2, 'c': {'d': 4, 'e': 5}}
    test_obj = CLIArgs(test_dict)
    assert test_obj == test_dict

    # Test with a dictionary with

# Generated at 2022-06-17 14:59:27.868770
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:59:31.709774
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest
    from ansible.module_utils.common.collections import ImmutableDict

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_GlobalCLIArgs(self):
            args = GlobalCLIArgs({'foo': 'bar'})
            self.assertIsInstance(args, ImmutableDict)
            self.assertEqual(args['foo'], 'bar')

    suite = unittest.TestLoader().loadTestsFromModule(TestGlobalCLIArgs())
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    sys.exit(not result.wasSuccessful())

# Generated at 2022-06-17 14:59:45.937516
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test CLIArgs constructor

    Test that the CLIArgs constructor converts the input into an ImmutableDict
    """
    # Test that the constructor converts the input into an ImmutableDict
    input_dict = {'a': 'b', 'c': 'd'}
    cli_args = CLIArgs(input_dict)
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args == input_dict

    # Test that the constructor converts the input into an ImmutableDict
    input_dict = {'a': 'b', 'c': 'd'}
    cli_args = CLIArgs(input_dict)
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args == input_dict

    # Test that the constructor converts the input into an ImmutableDict
    input

# Generated at 2022-06-17 15:00:05.922122
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 1, 'b': 2})
    assert args['a'] == 1
    assert args['b'] == 2
    assert len(args) == 2
    assert 'a' in args
    assert 'b' in args
    assert 'c' not in args
    assert args.get('c') is None
    assert args.get('c', 3) == 3
    assert args.get('a', 3) == 1
    assert args.get('b', 3) == 2
    assert args.keys() == ['a', 'b']
    assert args.values() == [1, 2]
    assert args.items() == [('a', 1), ('b', 2)]
    assert args.copy() == {'a': 1, 'b': 2}
    assert args.pop('a') == 1

# Generated at 2022-06-17 15:00:11.387370
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    class Bar(Foo):
        pass

    class Baz(Foo):
        pass

    assert Foo() is Foo()
    assert Bar() is Bar()
    assert Baz() is Baz()
    assert Foo() is Bar()
    assert Foo() is Baz()
    assert Bar() is Baz()

# Generated at 2022-06-17 15:00:20.700687
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest

    class TestGlobalCLIArgs(unittest.TestCase):
        def setUp(self):
            self.old_sys_argv = sys.argv
            sys.argv = ['ansible-playbook', '-i', 'localhost,', '-e', 'foo=bar', '-e', 'baz=qux']

        def tearDown(self):
            sys.argv = self.old_sys_argv

        def test_GlobalCLIArgs(self):
            from ansible.cli.arguments import Options
            from ansible.utils.display import Display

            display = Display()
            options = Options(display)
            options.parse()

            global_cli_args = GlobalCLIArgs.from_options(options)


# Generated at 2022-06-17 15:00:30.118624
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import json
    import sys
    import tempfile
    import textwrap
    import yaml

    from ansible.module_utils.common.collections import is_sequence

    from ansible.cli import CLI
    from ansible.config.manager import ConfigManager
    from ansible.module_utils._text import to_bytes

    # Create a temporary file to hold our config file
    fd, config_file = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file to hold our inventory file
    fd, inventory_file = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file to hold our playbook file
    fd, playbook_file = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file to hold our vault password file
   

# Generated at 2022-06-17 15:00:34.266947
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 15:00:45.627107
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 15:00:56.375755
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_set
    from ansible.module_utils.common.collections import is_mapping

    # Test that we can construct a CLIArgs object
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_args = CLIArgs(test_dict)

    # Test that we can access the data
    assert test_args['a'] == 1
    assert test_args['b'] == 2
    assert test_args['c'] == 3

    # Test that we can't change the data
    try:
        test_args['a'] = 4
    except TypeError:
        pass
   

# Generated at 2022-06-17 15:01:00.222060
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 15:01:09.917915
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a simple dictionary
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_cli_args = CLIArgs(test_dict)
    assert test_cli_args == test_dict
    assert isinstance(test_cli_args, ImmutableDict)
    assert isinstance(test_cli_args, Mapping)
    assert not isinstance(test_cli_args, Set)
    assert not isinstance(test_cli_args, Sequence)
    assert not isinstance(test_cli_args, Singleton)

    # Test with a nested dictionary
    test_dict = {'a': 1, 'b': 2, 'c': {'d': 4, 'e': 5, 'f': 6}}
    test_cli_args = CLIArgs(test_dict)
    assert test_cli

# Generated at 2022-06-17 15:01:13.519360
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 15:01:45.408175
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.module_utils.common.collections import ImmutableSet
    from ansible.module_utils.common.collections import ImmutableDict

    test_dict = {
        'key1': 'value1',
        'key2': 'value2',
        'key3': {
            'key4': 'value3',
            'key5': 'value4',
            'key6': [
                'value5',
                'value6',
                {
                    'key7': 'value7',
                    'key8': 'value8',
                },
            ],
        },
    }

    cli_args = CLIArgs(test_dict)


# Generated at 2022-06-17 15:01:49.954598
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
        pass

    class TestClass2(object):
        __metaclass__ = _ABCSingleton
        pass

    assert TestClass() is TestClass()
    assert TestClass2() is TestClass2()
    assert TestClass() is not TestClass2()

# Generated at 2022-06-17 15:02:01.155099
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create an instance of CLIArgs
    args = CLIArgs({'foo': 'bar'})
    assert args['foo'] == 'bar'

    # Test that we can create an instance of CLIArgs from an optparse.Values object
    from optparse import Values
    args = CLIArgs.from_options(Values({'foo': 'bar'}))
    assert args['foo'] == 'bar'

    # Test that we can create an instance of CLIArgs from an argparse.Namespace object
    from argparse import Namespace
    args = CLIArgs.from_options(Namespace(foo='bar'))
    assert args['foo'] == 'bar'

    # Test that we can create an instance of CLIArgs from an ImmutableDict object
    from ansible.module_utils.common.collections import ImmutableDict
    args = CLI

# Generated at 2022-06-17 15:02:09.352700
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import unittest

    class TestGlobalCLIArgs(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.test_dir)

        def test_GlobalCLIArgs(self):
            # Create a file with some data in it
            test_file = os.path.join(self.test_dir, 'test_file')
            with open(test_file, 'w') as f:
                f.write('{"test_key": "test_value"}')

            # Create a new instance of GlobalCLIArgs

# Generated at 2022-06-17 15:02:10.946887
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object):
        __metaclass__ = _ABCSingleton

    assert Test() is Test()

# Generated at 2022-06-17 15:02:16.027068
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    sys.argv = ['ansible-playbook', '--version']
    from ansible.cli import CLI
    cli = CLI(args=sys.argv[1:])
    cli.parse()
    GlobalCLIArgs.from_options(cli.options)

# Generated at 2022-06-17 15:02:21.583416
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 15:02:26.349172
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 15:02:35.988451
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a simple dictionary
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert isinstance(test_args, ImmutableDict)
    assert isinstance(test_args, Mapping)
    assert not isinstance(test_args, Set)
    assert not isinstance(test_args, Sequence)

    # Test with a nested dictionary
    test_dict = {'a': 1, 'b': {'c': 2, 'd': 3}, 'e': 4}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert isinstance(test_args, ImmutableDict)
    assert isinstance(test_args, Mapping)

# Generated at 2022-06-17 15:02:47.438024
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.module_utils.common.collections import CLIArgs
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_immutable_mapping
    from ansible.module_utils.common.collections import is_immutable_sequence
    from ansible.module_utils.common.collections import is_immutable_set
    from ansible.module_utils.common.collections import is_immutable_type

    # Test that GlobalCLIArgs is a Singleton
    assert GlobalCLIArgs() is GlobalCLIArgs()

    # Test that GlobalCLIArgs

# Generated at 2022-06-17 15:03:35.507299
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode