

# Generated at 2022-06-17 14:53:44.819807
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    args = parser.parse_args(['--foo', '--bar', '--baz', '--qux'])
    GlobalCLIArgs.from_options(args)
    assert GlobalCLIArgs.instance().foo is True
    assert GlobalCLIArgs.instance().bar is True
    assert GlobalCLIArgs.instance().baz is True
    assert GlobalCLIArgs.instance().qux is True
    sys.exit(0)

# Generated at 2022-06-17 14:53:51.464306
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    GlobalCLIArgs.from_options(args)
    assert GlobalCLIArgs.instance.foo is True
    assert GlobalCLIArgs.instance.bar is True
    assert GlobalCLIArgs.instance.baz is False

# Generated at 2022-06-17 14:53:53.426511
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert isinstance(TestClass(), TestClass)
    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:54:01.387188
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    global_args = GlobalCLIArgs.from_options(args)
    assert global_args['foo'] is True
    assert global_args['bar'] is True
    assert global_args['baz'] is False

# Generated at 2022-06-17 14:54:10.572401
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    options = {'foo': 'bar', 'baz': 'qux'}
    cli_args = CLIArgs(options)
    assert cli_args['foo'] == 'bar'
    assert cli_args['baz'] == 'qux'
    assert cli_args.get('foo') == 'bar'
    assert cli_args.get('baz') == 'qux'
    assert cli_args.get('missing') is None
    assert cli_args.get('missing', 'default') == 'default'
    assert cli_args.get('missing', default='default') == 'default'
    assert cli_args.get('missing', 'default', 'extra') == 'default'
    assert cli_args.get('missing', default='default', extra='extra') == 'default'
    assert cli

# Generated at 2022-06-17 14:54:15.056506
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:54:25.378501
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode

# Generated at 2022-06-17 14:54:35.662329
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import PY3

    # Test that we can create a CLIArgs object
    cliargs = CLIArgs({'foo': 'bar'})
    assert isinstance(cliargs, ImmutableDict)
    assert cliargs['foo'] == 'bar'

    # Test that we can create a CLIArgs object with a nested dict
    cliargs = CLIArgs({'foo': {'bar': 'baz'}})
    assert isinstance(cliargs, ImmutableDict)
    assert isinstance(cliargs['foo'], ImmutableDict)
    assert cliargs['foo']['bar'] == 'baz'

    #

# Generated at 2022-06-17 14:54:45.474797
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    import sys
    import unittest

    class TestCLIArgs(unittest.TestCase):
        def test_init(self):
            test_dict = {'a': 1, 'b': 2, 'c': 3}
            test_args = CLIArgs(test_dict)
            self.assertIsInstance(test_args, collections.Mapping)
            self.assertIsInstance(test_args, collections.MutableMapping)
            self.assertIsInstance(test_args, collections.MappingView)
            self.assertIsInstance(test_args, collections.KeysView)
            self.assertIsInstance(test_args, collections.ValuesView)
            self.assertIsInstance(test_args, collections.ItemsView)
            self.assertIsInstance(test_args, collections.Set)
            self.assertIs

# Generated at 2022-06-17 14:54:56.297389
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.module_utils.common.collections import CLIArgs
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_immutable_mapping
    from ansible.module_utils.common.collections import is_immutable_sequence
    from ansible.module_utils.common.collections import is_immutable_set
    from ansible.module_utils.common.collections import is_immutable_type
    from ansible.module_utils.common.collections import is_mutable_mapping
    from ansible.module_utils.common.collections import is_mutable

# Generated at 2022-06-17 14:55:03.280498
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:55:12.085599
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:55:18.272487
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    class Bar(Foo):
        pass

    class Baz(Foo):
        pass

    assert Foo() is Foo()
    assert Bar() is Bar()
    assert Baz() is Baz()
    assert Foo() is not Bar()
    assert Foo() is not Baz()
    assert Bar() is not Baz()

# Generated at 2022-06-17 14:55:23.647168
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:55:29.028369
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:55:38.484842
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar', action='append')
    parser.add_argument('--baz', action='append_const', const='baz')
    parser.add_argument('--qux', action='append_const', const='qux')
    parser.add_argument('--quux', action='append_const', const='quux')
    parser.add_argument('--corge', action='append_const', const='corge')
    parser.add_argument('--grault', action='append_const', const='grault')
    parser.add_argument('--garply', action='append_const', const='garply')

# Generated at 2022-06-17 14:55:43.306187
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:55:52.366368
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    import json
    import sys

    # Create a dictionary of all the types of data that we want to test

# Generated at 2022-06-17 14:55:57.990979
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    options = Options(foo=1, bar=2)
    args = GlobalCLIArgs.from_options(options)
    assert args['foo'] == 1
    assert args['bar'] == 2

# Generated at 2022-06-17 14:56:08.020840
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a dict
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_cli_args = CLIArgs(test_dict)
    assert test_cli_args == test_dict
    assert isinstance(test_cli_args, ImmutableDict)

    # Test with a list
    test_list = [1, 2, 3]
    test_cli_args = CLIArgs(test_list)
    assert test_cli_args == test_list
    assert isinstance(test_cli_args, ImmutableDict)

    # Test with a tuple
    test_tuple = (1, 2, 3)
    test_cli_args = CLIArgs(test_tuple)
    assert test_cli_args == test_tuple

# Generated at 2022-06-17 14:56:19.874373
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:56:26.178415
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': [5, 6, 7]}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert isinstance(test_args, ImmutableDict)
    assert isinstance(test_args['c'], ImmutableDict)
    assert isinstance(test_args['f'], tuple)
    assert test_args['f'] == (5, 6, 7)

# Generated at 2022-06-17 14:56:34.449477
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.module_utils.common.collections import CLIArgs
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_immutable_mapping
    from ansible.module_utils.common.collections import is_immutable_sequence
    from ansible.module_utils.common.collections import is_immutable_set
    from ansible.module_utils.common.collections import is_immutable_type

    # Test that the GlobalCLIArgs class is a Singleton
    assert isinstance(GlobalCLIArgs(), GlobalCLIArgs)
    assert GlobalCLIArgs() is Global

# Generated at 2022-06-17 14:56:39.493869
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:56:49.595444
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import pytest
    from ansible.module_utils.common.argparse import CLIArgParser
    from ansible.module_utils.common.argparse import CLIArgumentParserError

    # Test that the GlobalCLIArgs class is a Singleton
    with pytest.raises(RuntimeError):
        GlobalCLIArgs()

    # Test that the GlobalCLIArgs class is a Singleton
    with pytest.raises(RuntimeError):
        GlobalCLIArgs()

    # Test that the GlobalCLIArgs class is a Singleton
    with pytest.raises(RuntimeError):
        GlobalCLIArgs()

    # Test that the GlobalCLIArgs class is a Singleton
    with pytest.raises(RuntimeError):
        GlobalCLIArgs()

    # Test that the GlobalCLIArgs class is a Singleton
   

# Generated at 2022-06-17 14:56:59.554233
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('-a', action='store_true')
    parser.add_argument('-b', action='store_true')
    parser.add_argument('-c', action='store_true')
    parser.add_argument('-d', action='store_true')
    parser.add_argument('-e', action='store_true')
    parser.add_argument('-f', action='store_true')
    parser.add_argument('-g', action='store_true')
    parser.add_argument('-h', action='store_true')
    parser.add_argument('-i', action='store_true')
    parser.add_argument('-j', action='store_true')

# Generated at 2022-06-17 14:57:04.683022
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    GlobalCLIArgs.from_options(args)
    assert GlobalCLIArgs()['foo'] is True
    assert GlobalCLIArgs()['bar'] is True
    assert GlobalCLIArgs()['baz'] is False

# Generated at 2022-06-17 14:57:13.694921
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    test_dict = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert test_args['a'] == 1
    assert test_args['b'] == 2
    assert test_args['c'] == {'d': 3, 'e': 4}
    assert test_args['c']['d'] == 3
    assert test_args['c']['e'] == 4

    # Test that we can create a CLIArgs object with a nested list
    test_dict = {'a': 1, 'b': 2, 'c': [{'d': 3, 'e': 4}]}

# Generated at 2022-06-17 14:57:24.634259
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-17 14:57:26.260734
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:57:39.831090
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import format
    from ansible.module_utils.common.text.formatters import human_to_bytes
    from ansible.module_utils.common.text.formatters import human_to_kilobytes
    from ansible.module_utils.common.text.formatters import human_to_megabytes
    from ansible.module_utils.common.text.formatters import human_to_terabytes
    from ansible.module_utils.common.text.formatters import human_to_gigabytes

# Generated at 2022-06-17 14:57:47.097930
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'foo': 'bar'})
    assert cli_args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from an options object
    from ansible.utils.display import Display
    from ansible.utils.path import module_loader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars_from_file
    from ansible.utils.vars import load_vars_from_yaml_file
    from ansible.utils.vars import load_vars_from_inventory

# Generated at 2022-06-17 14:57:58.046324
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import unittest
    import argparse

    class TestGlobalCLIArgs(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.test_dir = os.path.join(self.tempdir, 'test_dir')
            os.mkdir(self.test_dir)
            self.test_file = os.path.join(self.test_dir, 'test_file')
            with open(self.test_file, 'w') as f:
                f.write('test_file')
            self.test_file2 = os.path.join(self.test_dir, 'test_file2')

# Generated at 2022-06-17 14:58:03.895329
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert B() is not C()
    assert A() is not C()

# Generated at 2022-06-17 14:58:12.844378
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a dict
    test_dict = {'a': 'b', 'c': 'd'}
    cli_args = CLIArgs(test_dict)
    assert cli_args == test_dict
    assert cli_args is not test_dict

    # Test with a list
    test_list = ['a', 'b', 'c', 'd']
    cli_args = CLIArgs(test_list)
    assert cli_args == test_list
    assert cli_args is not test_list

    # Test with a set
    test_set = {'a', 'b', 'c', 'd'}
    cli_args = CLIArgs(test_set)
    assert cli_args == test_set
    assert cli_args is not test_set

    # Test with a nested dict
   

# Generated at 2022-06-17 14:58:23.329315
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that CLIArgs can be constructed with a dictionary
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_cli_args = CLIArgs(test_dict)
    assert test_cli_args == test_dict

    # Test that CLIArgs can be constructed with a dictionary of lists
    test_dict = {'a': [1, 2, 3], 'b': [4, 5, 6], 'c': [7, 8, 9]}
    test_cli_args = CLIArgs(test_dict)
    assert test_cli_args == test_dict

    # Test that CLIArgs can be constructed with a dictionary of sets
    test_dict = {'a': {1, 2, 3}, 'b': {4, 5, 6}, 'c': {7, 8, 9}}
    test_cli_args

# Generated at 2022-06-17 14:58:27.468022
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # pylint: disable=protected-access
    assert GlobalCLIArgs._instance is None
    GlobalCLIArgs.from_options(None)
    assert GlobalCLIArgs._instance is not None
    GlobalCLIArgs.from_options(None)
    assert GlobalCLIArgs._instance is not None

# Generated at 2022-06-17 14:58:38.799294
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.text.converters import to_text
    import json

    # Test the constructor of class CLIArgs
    # Test the constructor of class CLIArgs
    # Test the constructor of class CLIArgs
    # Test the constructor of class CLIArgs
    # Test the constructor of class CLIArgs
    # Test the constructor of class CLIArgs
    # Test the constructor of class CLIArgs
    # Test the constructor of class CLIArgs
    # Test the constructor of class CLIArgs
    # Test the constructor of class CLIArgs
    # Test the constructor of class CLIArgs
    # Test the constructor of class CLIArgs
    # Test the constructor of class CLIArgs
    # Test the constructor of class CLIArgs
    # Test the constructor of class CLIArgs
    # Test the constructor

# Generated at 2022-06-17 14:58:48.672070
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can make a CLIArgs object
    args = CLIArgs({'foo': 'bar'})
    assert args['foo'] == 'bar'

    # Test that we can make a CLIArgs object from an optparse object
    from optparse import Values
    args = CLIArgs.from_options(Values({'foo': 'bar'}))
    assert args['foo'] == 'bar'

    # Test that we can make a CLIArgs object from an argparse object
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    args = CLIArgs.from_options(parser.parse_args(['--foo', 'bar']))
    assert args['foo'] == 'bar'

    # Test that we can make a CLIArgs object from an argparse object with a default

# Generated at 2022-06-17 14:58:55.498041
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:59:12.424066
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:59:21.620660
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:59:32.670169
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.module_utils.common.collections import ImmutableSet
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableSequence
    from ansible.module_utils.common.collections import ImmutableMapping
    from ansible.module_utils.common.collections import ImmutableContainer
    from ansible.module_utils.common.collections import MutableMapping
    from ansible.module_utils.common.collections import MutableSequence
    from ansible.module_utils.common.collections import MutableContainer

# Generated at 2022-06-17 14:59:43.295024
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': [5, 6, 7]})
    assert args['a'] == 1
    assert args['b'] == 2
    assert args['c']['d'] == 3
    assert args['c']['e'] == 4
    assert args['f'][0] == 5
    assert args['f'][1] == 6
    assert args['f'][2] == 7

# Generated at 2022-06-17 14:59:53.719454
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs constructor works as expected
    """
    # Test that CLIArgs constructor works as expected
    args = CLIArgs({'a': 'b', 'c': 'd'})
    assert args['a'] == 'b'
    assert args['c'] == 'd'

    # Test that CLIArgs constructor works as expected with a nested dict
    args = CLIArgs({'a': 'b', 'c': {'d': 'e'}})
    assert args['a'] == 'b'
    assert args['c']['d'] == 'e'

    # Test that CLIArgs constructor works as expected with a nested list
    args = CLIArgs({'a': 'b', 'c': ['d', 'e']})
    assert args['a'] == 'b'
    assert args['c'][0] == 'd'
   

# Generated at 2022-06-17 15:00:00.259476
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser.add_argument

# Generated at 2022-06-17 15:00:09.085657
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes

    # Test that we can create an instance of GlobalCLIArgs
    GlobalCLIArgs()

    # Test that we can create an instance of GlobalCLIArgs
    # and that it is a singleton
    GlobalCLIArgs()

    # Test that we can create an instance of GlobalCLIArgs
    # and that it is a singleton
    GlobalCLIArgs()

    # Test that we can create an instance of GlobalCLIArgs
    # and that it is a singleton
    GlobalCLIArgs()

    # Test that we can create an instance of GlobalCLIArgs
    # and that it

# Generated at 2022-06-17 15:00:18.527260
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.module_utils.common.collections import CLIArgs
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import _make_immutable
    from ansible.module_utils.common.collections import _ABCSingleton

    # Test the constructor of class GlobalCLIArgs
    # Test the constructor of class CLIArgs
    # Test the constructor of class ImmutableDict
    # Test the function _make_immutable
    # Test the class _ABCSingleton
    # Test the class Singleton
    # Test the class ABCMeta
    # Test the class Container
    # Test the class Mapping
    # Test the class Sequence
    # Test the class Set
   

# Generated at 2022-06-17 15:00:26.322671
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a simple dict
    test_dict = {'a': 1, 'b': 2}
    test_args = CLIArgs(test_dict)
    assert test_args['a'] == 1
    assert test_args['b'] == 2

    # Test with a nested dict
    test_dict = {'a': 1, 'b': {'c': 2, 'd': 3}}
    test_args = CLIArgs(test_dict)
    assert test_args['a'] == 1
    assert test_args['b']['c'] == 2
    assert test_args['b']['d'] == 3

    # Test with a nested list
    test_dict = {'a': 1, 'b': [1, 2, 3]}
    test_args = CLIArgs(test_dict)
    assert test_args['a']

# Generated at 2022-06-17 15:00:29.855388
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is B()
    assert A() is C()
    assert B() is C()

# Generated at 2022-06-17 15:00:42.014774
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 15:00:52.934347
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar')
    parser.add_argument('--baz')
    parser.add_argument('--qux')
    parser.add_argument('--quux')
    parser.add_argument('--corge')
    parser.add_argument('--grault')
    parser.add_argument('--garply')
    parser.add_argument('--waldo')
    parser.add_argument('--fred')
    parser.add_argument('--plugh')
    parser.add_argument('--xyzzy')
    parser.add_argument('--thud')

# Generated at 2022-06-17 15:00:56.297790
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    assert A() is A()
    assert B() is B()
    assert A() is not B()
    assert B() is not A()

# Generated at 2022-06-17 15:00:58.937140
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 15:01:09.306055
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_false')
    parser.add_argument('--qux', action='append')
    parser.add_argument('--quux', nargs='+')
    parser.add_argument('--corge', nargs='*')
    parser.add_argument('--grault', nargs='?')
    parser.add_argument('--garply', default='waldo')
    parser.add_argument('--fred', default=['plugh', 'xyzzy'])
    parser.add_argument('--waldo', default=['thud'])

# Generated at 2022-06-17 15:01:14.845223
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    assert D() is D()

# Generated at 2022-06-17 15:01:23.046037
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 15:01:33.203158
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    options = Options(
        module_path=['/path/to/modules'],
        forks=10,
        become=True,
        become_method='sudo',
        become_user='root',
        check=False,
        diff=False,
        extra_vars=[{'foo': 'bar'}],
        inventory=['/path/to/inventory'],
        listhosts=False,
        listtasks=False,
        listtags=False,
        syntax=False,
        verbosity=3,
        start_at_task='task1',
    )

    args = GlobalCLIArgs.from_options(options)



# Generated at 2022-06-17 15:01:45.673742
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import CLIArgs
    from ansible.module_utils.common.collections import _make_immutable
    from ansible.module_utils.common.collections import _ABCSingleton
    from ansible.utils.singleton import Singleton
    from ansible.module_utils.six import add_metaclass
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type
    from ansible.module_utils.common._collections_compat import Container
    from ansible.module_utils.common._collections_compat import Mapping
   

# Generated at 2022-06-17 15:01:55.493624
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.module_utils.common.collections import CLIArgs
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_set
    from ansible.module_utils.common.collections import is_mapping
    from ansible.module_utils.common.collections import is_container
    from ansible.module_utils.common.collections import is_sequence_of_strings
    from ansible.module_utils.common.collections import is_sequence_of_mappings

# Generated at 2022-06-17 15:02:13.954326
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 15:02:24.033242
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.validation import check_type_bool
    from ansible.module_utils.six import PY3

    # Test that we can create a GlobalCLIArgs object
    args = GlobalCLIArgs({'foo': 'bar'})
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, GlobalCLIArgs)
    assert args['foo'] == 'bar'

    # Test that we can create a GlobalCLIArgs object with a list
    args = GlobalCLIArgs({'foo': ['bar']})
    assert isinstance(args, ImmutableDict)

# Generated at 2022-06-17 15:02:34.977060
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')

# Generated at 2022-06-17 15:02:44.777999
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a simple dictionary
    test_dict = {'a': 'b', 'c': 'd'}
    test_obj = CLIArgs(test_dict)
    assert test_obj == test_dict
    assert isinstance(test_obj, ImmutableDict)

    # Test with a nested dictionary
    test_dict = {'a': 'b', 'c': {'d': 'e', 'f': 'g'}}
    test_obj = CLIArgs(test_dict)
    assert test_obj == test_dict
    assert isinstance(test_obj, ImmutableDict)
    assert isinstance(test_obj['c'], ImmutableDict)

    # Test with a nested dictionary and a list

# Generated at 2022-06-17 15:02:52.769521
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 1, 'b': {'c': 'd'}})
    assert args['a'] == 1
    assert args['b']['c'] == 'd'
    assert isinstance(args['b'], ImmutableDict)
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, CLIArgs)
    assert not isinstance(args, GlobalCLIArgs)

# Generated at 2022-06-17 15:02:56.153337
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 15:03:05.849285
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'a': 1, 'b': 2, 'c': 3})

    # Test that we can't modify the CLIArgs object
    try:
        cli_args['a'] = 4
    except TypeError:
        pass
    else:
        raise AssertionError("Should not be able to modify CLIArgs object")

    # Test that we can't modify the CLIArgs object
    try:
        cli_args['d'] = 4
    except TypeError:
        pass
    else:
        raise AssertionError("Should not be able to modify CLIArgs object")

    # Test that we can't modify the CLIArgs object
    try:
        del cli_args['a']
    except TypeError:
        pass
    else:
        raise Assert

# Generated at 2022-06-17 15:03:11.736720
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 15:03:14.819477
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert isinstance(TestClass(), TestClass)
    assert TestClass() is TestClass()

# Generated at 2022-06-17 15:03:22.086935
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true', default=False)
    parser.add_argument('--bar', action='store_true', default=False)
    parser.add_argument('--baz', action='store_true', default=False)
    parser.add_argument('--qux', action='store_true', default=False)
    parser.add_argument('--quux', action='store_true', default=False)
    parser.add_argument('--corge', action='store_true', default=False)
    parser.add_argument('--grault', action='store_true', default=False)
    parser.add_argument('--garply', action='store_true', default=False)
    parser.add_