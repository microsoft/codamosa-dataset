

# Generated at 2022-06-17 14:53:44.647915
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # pylint: disable=protected-access
    assert GlobalCLIArgs._instance is None
    GlobalCLIArgs()
    assert GlobalCLIArgs._instance is not None
    assert isinstance(GlobalCLIArgs._instance, GlobalCLIArgs)
    assert GlobalCLIArgs._instance is GlobalCLIArgs()
    assert GlobalCLIArgs._instance is GlobalCLIArgs()
    assert GlobalCLIArgs._instance is GlobalCLIArgs()

# Generated at 2022-06-17 14:53:49.880671
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', default='bar')
    parser.add_argument('--baz', default='qux')
    args = parser.parse_args([])
    global_args = GlobalCLIArgs.from_options(args)
    assert global_args['foo'] == 'bar'
    assert global_args['baz'] == 'qux'

# Generated at 2022-06-17 14:53:56.914675
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.module_utils.common.collections import CLIArgs
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_immutable_mapping
    from ansible.module_utils.common.collections import is_immutable_sequence
    from ansible.module_utils.common.collections import is_immutable_set
    from ansible.module_utils.common.collections import is_immutable_container

    # Test that we can create a GlobalCLIArgs object
    gca = GlobalCLIArgs({'a': 1, 'b': 2})
   

# Generated at 2022-06-17 14:54:02.737322
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', default='bar')
    parser.add_argument('--baz', default='qux')
    options = parser.parse_args(args=sys.argv[1:])
    args = GlobalCLIArgs.from_options(options)
    assert args['foo'] == 'bar'
    assert args['baz'] == 'qux'

# Generated at 2022-06-17 14:54:11.456086
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    options = Options(
        foo='bar',
        baz=['qux', 'quux'],
        corge={'grault': 'garply', 'waldo': 'fred'},
        plugh=('xyzzy', 'thud'),
        thud=set(['xyzzy', 'plugh']),
    )

    args = CLIArgs.from_options(options)

    assert args['foo'] == 'bar'
    assert args['baz'] == ('qux', 'quux')
    assert args['corge'] == ImmutableDict({'grault': 'garply', 'waldo': 'fred'})

# Generated at 2022-06-17 14:54:19.376663
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.text.converters import to_text
    import json

    # Test that we can create a CLIArgs object from a dict
    test_dict = {
        'a': 'b',
        'c': 'd',
        'e': {
            'f': 'g',
            'h': 'i',
            'j': [
                'k',
                'l',
                'm',
            ],
            'n': {
                'o': 'p',
                'q': 'r',
            },
        },
    }
    test_cli_args = CLIArgs(test_dict)
    assert test_cli_args == test_dict
    assert is_immutable(test_cli_args)

# Generated at 2022-06-17 14:54:27.595247
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.module_utils.common.collections import ImmutableSet
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableSequence
    from ansible.module_utils.common.collections import ImmutableMapping
    from ansible.module_utils.common.collections import ImmutableContainer
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.collections import is_mapping

# Generated at 2022-06-17 14:54:37.553731
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:54:47.552201
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_list
    from ansible.module_utils.common.text.converters import to_set
    from ansible.module_utils.common.text.converters import to_tuple
    from ansible.module_utils.common.text.converters import to_dict
    from ansible.module_utils.common.text.converters import to_bytes_or_unicode

# Generated at 2022-06-17 14:54:49.267407
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:55:03.082086
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.text.converters import to_text
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_vault_vars
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import merge_vars
    from ansible.utils.vars import strip_internal_keys
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-17 14:55:11.912894
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs constructor makes a copy of the input and converts it to immutable data types
    """

# Generated at 2022-06-17 14:55:23.697059
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import os
    import sys
    import tempfile
    import unittest


# Generated at 2022-06-17 14:55:25.815501
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()
    assert TestClass() is not object()

# Generated at 2022-06-17 14:55:30.033675
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    class Bar(object):
        __metaclass__ = _ABCSingleton

    assert Foo() is Foo()
    assert Bar() is Bar()
    assert Foo() is not Bar()

# Generated at 2022-06-17 14:55:33.138320
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:55:41.436813
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that the constructor of CLIArgs works as expected
    # Create a dictionary
    test_dict = {'a': 'b', 'c': 'd'}
    # Create an instance of CLIArgs
    test_instance = CLIArgs(test_dict)
    # Check that the instance is immutable
    assert isinstance(test_instance, ImmutableDict)
    # Check that the instance is a CLIArgs instance
    assert isinstance(test_instance, CLIArgs)
    # Check that the instance is not a GlobalCLIArgs instance
    assert not isinstance(test_instance, GlobalCLIArgs)
    # Check that the instance is not a Singleton instance
    assert not isinstance(test_instance, Singleton)
    # Check that the instance is not a _ABCSingleton instance
    assert not isinstance(test_instance, _ABCSingleton)


# Generated at 2022-06-17 14:55:45.988065
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        def __init__(self):
            self.foo = 'bar'
            self.baz = 'qux'

    options = Options()
    args = GlobalCLIArgs.from_options(options)
    assert args['foo'] == 'bar'
    assert args['baz'] == 'qux'

# Generated at 2022-06-17 14:55:53.227106
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': [5, 6, 7]}
    test_obj = CLIArgs(test_dict)
    assert test_obj == test_dict
    assert isinstance(test_obj, ImmutableDict)
    assert isinstance(test_obj['c'], ImmutableDict)
    assert isinstance(test_obj['f'], tuple)
    assert isinstance(test_obj['f'][0], int)
    assert isinstance(test_obj['f'][1], int)
    assert isinstance(test_obj['f'][2], int)

# Generated at 2022-06-17 14:55:57.252845
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:56:07.704011
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    args = parser.parse_args(['--foo', '--bar', '--baz', '--qux'])
    global_args = GlobalCLIArgs.from_options(args)
    assert global_args['foo'] is True
    assert global_args['bar'] is True
    assert global_args['baz'] is True
    assert global_args['qux'] is True

# Generated at 2022-06-17 14:56:12.230959
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:56:24.743522
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_str
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native

# Generated at 2022-06-17 14:56:26.983941
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'foo': 'bar', 'baz': 'qux'})
    assert args['foo'] == 'bar'
    assert args['baz'] == 'qux'

# Generated at 2022-06-17 14:56:35.012794
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')

# Generated at 2022-06-17 14:56:48.014734
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.module_utils.common.collections import CLIArgs
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_immutable_mapping
    from ansible.module_utils.common.collections import is_immutable_sequence
    from ansible.module_utils.common.collections import is_immutable_set
    from ansible.module_utils.common.collections import is_immutable_type
    from ansible.module_utils.common.collections import is_mutable_mapping

# Generated at 2022-06-17 14:56:49.218124
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:56:59.000036
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    args = CLIArgs({'foo': 'bar'})
    assert isinstance(args, CLIArgs)
    assert isinstance(args, ImmutableDict)
    assert args == {'foo': 'bar'}
    assert args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from an options object
    args = CLIArgs.from_options(ImmutableDict({'foo': 'bar'}))
    assert isinstance(args, CLIArgs)
    assert isinstance(args, ImmutableDict)
    assert args == {'foo': 'bar'}
    assert args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from a mutable dict
    args = CLIArgs({'foo': 'bar'})

# Generated at 2022-06-17 14:57:03.797991
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:57:11.760101
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath

    display = Display()
    display.verbosity = 3

    sys.path.insert(0, unfrackpath("/usr/lib/python2.7/dist-packages"))
    from ansible.cli import CLI

    cli = CLI(args=['--version'])
    cli.parse()

    args = GlobalCLIArgs.from_options(cli.options)

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_version(self):
            self.assertEqual(args['version'], True)

    unittest.main()

# Generated at 2022-06-17 14:57:28.060164
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_bytes

# Generated at 2022-06-17 14:57:37.459433
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs is immutable
    """
    args = CLIArgs({'a': 1, 'b': 2, 'c': 3})
    assert args['a'] == 1
    assert args['b'] == 2
    assert args['c'] == 3
    try:
        args['a'] = 4
        assert False, 'Should not be able to change a value'
    except TypeError:
        pass
    try:
        args['d'] = 4
        assert False, 'Should not be able to add a value'
    except TypeError:
        pass
    try:
        del args['a']
        assert False, 'Should not be able to delete a value'
    except TypeError:
        pass

# Generated at 2022-06-17 14:57:43.967199
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABCSingleton(object):
        __metaclass__ = _ABCSingleton

    class TestABCSingleton2(object):
        __metaclass__ = _ABCSingleton

    assert TestABCSingleton() is TestABCSingleton()
    assert TestABCSingleton2() is TestABCSingleton2()
    assert TestABCSingleton() is not TestABCSingleton2()

# Generated at 2022-06-17 14:57:47.077671
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:57:58.046007
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode

# Generated at 2022-06-17 14:58:08.829932
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser.add_argument

# Generated at 2022-06-17 14:58:20.618120
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 1, 'b': {'c': 2, 'd': {'e': 3}}, 'f': [4, 5, 6]})
    assert args['a'] == 1
    assert args['b']['c'] == 2
    assert args['b']['d']['e'] == 3
    assert args['f'][0] == 4
    assert args['f'][1] == 5
    assert args['f'][2] == 6

    # Test that we can't modify the data
    try:
        args['a'] = 2
    except TypeError:
        pass
    else:
        assert False, "Should not be able to modify the data"

    try:
        args['b']['c'] = 3
    except TypeError:
        pass

# Generated at 2022-06-17 14:58:32.365297
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.six import string_types

    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({})
    assert isinstance(cli_args, ImmutableDict)

    # Test that we can create a CLIArgs object with a mapping
    cli_args = CLIArgs({'foo': 'bar'})
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args['foo'] == 'bar'

    #

# Generated at 2022-06-17 14:58:45.818054
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs constructor correctly converts a dict into an immutable dict
    """
    test_dict = {
        'a': 'b',
        'c': ['d', 'e'],
        'f': {
            'g': 'h',
            'i': ['j', 'k'],
            'l': {
                'm': 'n',
                'o': ['p', 'q'],
            },
        },
    }
    cli_args = CLIArgs(test_dict)
    assert cli_args == test_dict
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args['c'], tuple)
    assert isinstance(cli_args['f'], ImmutableDict)

# Generated at 2022-06-17 14:58:52.421176
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:59:01.407313
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.utils.display import Display
    display = Display()
    cli = CLI(args=sys.argv[1:], display=display)
    options = cli.parse()
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-17 14:59:04.764646
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.utils.display import Display
    display = Display()
    cli = CLI(args=sys.argv[1:], display=display)
    options = cli.parse()
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-17 14:59:10.520589
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:59:21.109403
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import pytest
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_mutable

    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'foo': 'bar'})
    assert cli_args['foo'] == 'bar'

    # Test that we can create a CLIArgs object with a nested dict
    cli_args = CLIArgs({'foo': {'bar': 'baz'}})
    assert cli_args['foo']['bar'] == 'baz'

    # Test that we can create a CLIArgs object with a nested list
    cli_args = CLIArgs({'foo': ['bar', 'baz']})
    assert cli_args['foo'][0] == 'bar'
   

# Generated at 2022-06-17 14:59:27.533717
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    GlobalCLIArgs.from_options(args)

# Generated at 2022-06-17 14:59:31.879383
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:59:46.054579
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a dict
    test_dict = {'a': 'b', 'c': 'd'}
    test_args = CLIArgs(test_dict)
    assert test_args['a'] == 'b'
    assert test_args['c'] == 'd'
    assert test_args == test_dict
    assert test_args != {'a': 'b', 'c': 'd', 'e': 'f'}
    assert test_args != {'a': 'b', 'c': 'd', 'e': 'f'}
    assert test_args != {'a': 'b', 'c': 'd', 'e': 'f'}
    assert test_args != {'a': 'b', 'c': 'd', 'e': 'f'}

# Generated at 2022-06-17 14:59:50.928005
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.module_utils.common.collections import ImmutableDict

    cli = CLI(args=sys.argv[1:])
    options = cli.parse()
    args = GlobalCLIArgs.from_options(options)
    assert isinstance(args, ImmutableDict)

# Generated at 2022-06-17 14:59:55.358782
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 15:00:01.187201
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    options = {'foo': 'bar', 'baz': 'qux'}
    cli_args = CLIArgs.from_options(options)
    assert cli_args['foo'] == 'bar'
    assert cli_args['baz'] == 'qux'
    assert cli_args.get('foo') == 'bar'
    assert cli_args.get('baz') == 'qux'
    assert cli_args.get('quux') is None
    assert cli_args.get('quux', 'default') == 'default'
    assert cli_args.get('foo', 'default') == 'bar'
    assert cli_args.get('baz', 'default') == 'qux'
    assert cli_args.get('foo', 'default') != 'default'
    assert cli_

# Generated at 2022-06-17 15:00:20.700754
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import ansible.module_utils.common.arguments as arguments
    import ansible.module_utils.common.collections as collections
    import ansible.module_utils.common.text.converters as converters
    import ansible.module_utils.common.text.formatters as formatters
    import ansible.module_utils.common.text.utils as text_utils
    import ansible.module_utils.common.validation as validation

    # Make sure that we can import all the modules that we depend on
    assert arguments
    assert collections
    assert converters
    assert formatters
    assert text_utils
    assert validation

    # Make sure that we can create a GlobalCLIArgs object
    GlobalCLIArgs()

# Generated at 2022-06-17 15:00:30.118996
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.common.text.converters import to_unicode

# Generated at 2022-06-17 15:00:38.261521
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(sys.argv[1:])
    cli_args = CLIArgs.from_options(args)
    assert cli_args['foo'] == args.foo
    assert cli_args['bar'] == args.bar
    assert cli_args['baz'] == args.baz

# Generated at 2022-06-17 15:00:50.532469
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type
    from ansible.module_utils.six import u
    from ansible.module_utils.six import unichr

    # Test that we can create a GlobalCLIArgs object
    GlobalCLIArgs()

    # Test that we can create a GlobalCLIArgs object with a dict
    GlobalCLIArgs({})

    # Test that we can create a GlobalCLIArgs

# Generated at 2022-06-17 15:01:00.003566
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_false')
    parser.add_argument('--qux', action='append')
    parser.add_argument('--quux', nargs='+')
    parser.add_argument('--corge', nargs='*')
    parser.add_argument('--grault', nargs='?')
    parser.add_argument('--garply', nargs=2)
    parser.add_argument('--waldo', nargs=3)
    parser.add_argument('--fred', nargs=4)
    parser.add_argument('--plugh', nargs=5)

# Generated at 2022-06-17 15:01:09.811579
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs is immutable
    """
    args = CLIArgs({'a': 1, 'b': 2, 'c': 3})
    assert args['a'] == 1
    assert args['b'] == 2
    assert args['c'] == 3
    try:
        args['a'] = 2
    except TypeError:
        pass
    else:
        raise AssertionError('CLIArgs should be immutable')
    try:
        args['d'] = 4
    except TypeError:
        pass
    else:
        raise AssertionError('CLIArgs should be immutable')
    try:
        del args['a']
    except TypeError:
        pass
    else:
        raise AssertionError('CLIArgs should be immutable')

# Generated at 2022-06-17 15:01:19.420962
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that the constructor works
    args = CLIArgs({'foo': 'bar'})
    assert args['foo'] == 'bar'

    # Test that the constructor makes a copy of the input
    args = CLIArgs({'foo': 'bar'})
    args['foo'] = 'baz'
    assert args['foo'] == 'baz'

    # Test that the constructor makes a copy of the input
    args = CLIArgs({'foo': 'bar'})
    args['foo'] = 'baz'
    assert args['foo'] == 'baz'

    # Test that the constructor makes a copy of the input
    args = CLIArgs({'foo': 'bar'})
    args['foo'] = 'baz'
    assert args['foo'] == 'baz'

    # Test that the constructor makes a copy of the input

# Generated at 2022-06-17 15:01:30.889989
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs constructor works as expected
    """
    # Test that we can create a CLIArgs object
    test_dict = {'a': 1, 'b': 2}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict

    # Test that we can create a CLIArgs object from an options object
    test_options = type('test_options', (object,), test_dict)
    test_args = CLIArgs.from_options(test_options)
    assert test_args == test_dict

    # Test that we can create a CLIArgs object from a nested dictionary
    test_dict = {'a': 1, 'b': {'c': 2, 'd': {'e': 3}}}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict

# Generated at 2022-06-17 15:01:33.992229
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 15:01:45.931098
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import argparse
    from ansible.module_utils.common.argparse import CLIArgParser

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir)

    # Create the parser
    parser = CLIArgParser()

    # Add the arguments to the parser
    parser.add_argument('--foo', dest='foo', action='store_true')
    parser.add_argument('--bar', dest='bar', action='store_true')
    parser.add_argument('--baz', dest='baz', action='store_true')

    # Parse the arguments
    args = parser.parse_args()

    # Create the

# Generated at 2022-06-17 15:02:23.368894
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes

    # Test the constructor
    cli_args = CLIArgs({'foo': 'bar'})
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args['foo'] == 'bar'

    # Test the constructor with a nested dict
    cli_args = CLIArgs({'foo': {'bar': 'baz'}})
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args['foo'], ImmutableDict)
    assert cli_args['foo']['bar'] == 'baz'

   

# Generated at 2022-06-17 15:02:34.329455
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.module_utils.common.collections import CLIArgs
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.collections import is_mutable
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import binary_type
    from ansible.module_utils.six import text_type

    # Test that GlobalCLIArgs is a singleton
    assert GlobalCLIArgs() is GlobalCLIArgs()

    # Test that GlobalCLIArgs is a subclass of CLIArgs
    assert issubclass(GlobalCLIArgs, CLIArgs)

    # Test that

# Generated at 2022-06-17 15:02:36.734565
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(TestClass(), TestClass)
    assert TestClass() is TestClass()
    assert isinstance(TestClass(), Singleton)
    assert isinstance(TestClass(), ABCMeta)

# Generated at 2022-06-17 15:02:47.755205
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a dictionary
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_cli_args = CLIArgs(test_dict)
    assert test_cli_args == test_dict

    # Test with a list
    test_list = [1, 2, 3]
    test_cli_args = CLIArgs(test_list)
    assert test_cli_args == test_list

    # Test with a set
    test_set = {1, 2, 3}
    test_cli_args = CLIArgs(test_set)
    assert test_cli_args == test_set

    # Test with a string
    test_string = 'abc'
    test_cli_args = CLIArgs(test_string)
    assert test_cli_args == test_string

    # Test with a tuple

# Generated at 2022-06-17 15:02:50.689272
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 15:02:55.935784
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 15:03:05.703986
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_obj = CLIArgs(test_dict)
    assert test_obj['a'] == 1
    assert test_obj['b'] == 2
    assert test_obj['c'] == 3
    assert len(test_obj) == 3
    assert test_obj.get('a') == 1
    assert test_obj.get('b') == 2
    assert test_obj.get('c') == 3
    assert test_obj.get('d') is None
    assert test_obj.get('d', 4) == 4
    assert test_obj.get('d', default=4) == 4
    assert test_obj.keys() == ['a', 'b', 'c']
    assert test_obj.values() == [1, 2, 3]


# Generated at 2022-06-17 15:03:09.235446
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 15:03:12.030644
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()


# Generated at 2022-06-17 15:03:17.527308
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()