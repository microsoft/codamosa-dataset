

# Generated at 2022-06-17 14:53:47.695155
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'foo': 'bar'})
    assert cli_args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from an optparse.Values object
    from optparse import Values
    cli_args = CLIArgs.from_options(Values({'foo': 'bar'}))
    assert cli_args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from an argparse.Namespace object
    from argparse import Namespace
    cli_args = CLIArgs.from_options(Namespace(foo='bar'))
    assert cli_args['foo'] == 'bar'

    # Test that we can create a CLIArgs object from a dict

# Generated at 2022-06-17 14:53:55.605711
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test the CLIArgs constructor
    """
    # Test that the constructor works
    test_dict = {
        'foo': 'bar',
        'baz': [1, 2, 3],
        'qux': {
            'a': 1,
            'b': 2,
            'c': 3,
        },
    }
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict

    # Test that the constructor makes the data immutable
    test_dict['foo'] = 'baz'
    assert test_args != test_dict

    # Test that the constructor makes the data immutable
    test_dict['baz'].append(4)
    assert test_args != test_dict

    # Test that the constructor makes the data immutable

# Generated at 2022-06-17 14:54:00.711183
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:54:03.961169
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton
    class Bar(object):
        __metaclass__ = _ABCSingleton
    assert Foo() is Foo()
    assert Bar() is Bar()
    assert Foo() is not Bar()

# Generated at 2022-06-17 14:54:12.193339
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test the CLIArgs constructor
    """
    # Test that the constructor works
    cli_args = CLIArgs({'foo': 'bar'})
    assert cli_args['foo'] == 'bar'

    # Test that the constructor works with a nested dict
    cli_args = CLIArgs({'foo': {'bar': 'baz'}})
    assert cli_args['foo']['bar'] == 'baz'

    # Test that the constructor works with a nested list
    cli_args = CLIArgs({'foo': ['bar', 'baz']})
    assert cli_args['foo'][0] == 'bar'
    assert cli_args['foo'][1] == 'baz'

    # Test that the constructor works with a nested set

# Generated at 2022-06-17 14:54:19.539622
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import json
    import sys
    import tempfile

    # Create a temporary file to hold the json data
    with tempfile.NamedTemporaryFile(delete=False) as f:
        f.write(b'{"a": {"b": {"c": "d"}}}')

    # Create a CLIArgs object from the temporary file

# Generated at 2022-06-17 14:54:25.910244
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': [5, 6, 7], 'g': {8, 9, 10}}
    cli_args = CLIArgs(test_dict)
    assert cli_args == test_dict
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args['c'], ImmutableDict)
    assert isinstance(cli_args['f'], tuple)
    assert isinstance(cli_args['g'], frozenset)

# Generated at 2022-06-17 14:54:36.031948
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.formatters import format
    from ansible.module_utils.common.text.formatters import safe_text
    from ansible.module_utils.common.text.formatters import to_bytes
    from ansible.module_utils.common.text.formatters import to_text
    from ansible.module_utils.common.text.formatters import to_unicode
    from ansible.module_utils.six import PY

# Generated at 2022-06-17 14:54:41.966388
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.utils.display import Display
    display = Display()
    cli = CLI(args=sys.argv[1:], display=display)
    options = cli.parse()
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-17 14:54:44.821523
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:54:57.590954
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs constructor works as expected
    """
    test_dict = {'a': 'a', 'b': 'b', 'c': 'c'}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert test_args is not test_dict
    assert isinstance(test_args, ImmutableDict)
    assert isinstance(test_args, Mapping)
    assert isinstance(test_args, Container)
    assert not isinstance(test_args, Sequence)
    assert not isinstance(test_args, Set)

    test_dict = {'a': 'a', 'b': 'b', 'c': 'c', 'd': {'a': 'a', 'b': 'b', 'c': 'c'}}

# Generated at 2022-06-17 14:55:03.395281
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:55:12.155288
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    options = Options(foo=1, bar=2)
    args = GlobalCLIArgs.from_options(options)
    assert args['foo'] == 1
    assert args['bar'] == 2
    assert args.get('foo') == 1
    assert args.get('bar') == 2
    assert args.get('baz') is None
    assert args.get('baz', 3) == 3
    assert args.get('baz', default=3) == 3
    assert args.get('baz', 'default') == 'default'
    assert args.get('baz', default='default') == 'default'
    assert args.get('baz', 'default', 4) == 'default'
   

# Generated at 2022-06-17 14:55:18.369059
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:55:20.231580
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:55:30.195385
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 'b', 'c': 'd', 'e': {'f': 'g', 'h': 'i', 'j': ['k', 'l', 'm']}}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert test_args['e'] == test_dict['e']
    assert test_args['e']['j'] == test_dict['e']['j']
    assert test_args['e']['j'][0] == test_dict['e']['j'][0]
    assert test_args['e']['j'][1] == test_dict['e']['j'][1]

# Generated at 2022-06-17 14:55:39.330269
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test the CLIArgs class constructor
    """
    # Test with a dictionary
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert isinstance(test_args, ImmutableDict)

    # Test with a list
    test_list = [1, 2, 3]
    test_args = CLIArgs(test_list)
    assert test_args == test_list
    assert isinstance(test_args, ImmutableDict)

    # Test with a tuple
    test_tuple = (1, 2, 3)
    test_args = CLIArgs(test_tuple)
    assert test_args == test_tuple
    assert isinstance(test_args, ImmutableDict)

# Generated at 2022-06-17 14:55:47.619392
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 1, 'b': {'c': 2, 'd': 3}, 'e': [4, 5, 6]})
    assert args['a'] == 1
    assert args['b']['c'] == 2
    assert args['b']['d'] == 3
    assert args['e'][0] == 4
    assert args['e'][1] == 5
    assert args['e'][2] == 6
    assert isinstance(args, ImmutableDict)
    assert isinstance(args['b'], ImmutableDict)
    assert isinstance(args['e'], tuple)

# Generated at 2022-06-17 14:55:58.289505
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a dictionary
    test_dict = {'a': 'b', 'c': 'd'}
    test_cli_args = CLIArgs(test_dict)
    assert test_cli_args['a'] == 'b'
    assert test_cli_args['c'] == 'd'

    # Test with a list
    test_list = ['a', 'b', 'c', 'd']
    test_cli_args = CLIArgs(test_list)
    assert test_cli_args[0] == 'a'
    assert test_cli_args[1] == 'b'
    assert test_cli_args[2] == 'c'
    assert test_cli_args[3] == 'd'

    # Test with a set
    test_set = {'a', 'b', 'c', 'd'}


# Generated at 2022-06-17 14:56:08.293805
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.utils.display import Display
    from ansible.utils.color import stringc

    display = Display()
    cli = CLI(args=sys.argv[1:], display=display)
    options = cli.parse()

    args = GlobalCLIArgs.from_options(options)
    assert isinstance(args, GlobalCLIArgs)
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, Mapping)
    assert isinstance(args, Container)
    assert isinstance(args, Sequence)
    assert isinstance(args, Set)
    assert isinstance(args, object)
    assert args == vars(options)
    assert args == GlobalCLIArgs.from_options(options)

# Generated at 2022-06-17 14:56:18.467896
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import is_immutable
    import sys

    # test that the class is a singleton
    args1 = GlobalCLIArgs({'foo': 'bar'})
    args2 = GlobalCLIArgs({'foo': 'bar'})
    assert args1 is args2

    # test that the class is immutable
    args1 = GlobalCLIArgs({'foo': 'bar'})
    try:
        args1['foo'] = 'baz'
    except TypeError:
        pass
    else:
        raise AssertionError('GlobalCLIArgs is not immutable')

    # test that the class is immutable recursively
    args

# Generated at 2022-06-17 14:56:28.992790
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import CLIArgs

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_constructor(self):
            # Test that the constructor of GlobalCLIArgs works as expected
            # Create a dictionary with some values
            test_dict = {'a': 1, 'b': 2, 'c': 3}
            # Create a GlobalCLIArgs object from the dictionary
            test_object = GlobalCLIArgs(test_dict)
            # Check that the object is an instance of GlobalCLIArgs
            self.assertIsInstance(test_object, GlobalCLIArgs)
            #

# Generated at 2022-06-17 14:56:32.858508
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:56:46.163214
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:56:49.622531
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:56:59.553217
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a dictionary
    test_dict = {'key1': 'value1', 'key2': 'value2'}
    test_cli_args = CLIArgs(test_dict)
    assert isinstance(test_cli_args, ImmutableDict)
    assert test_cli_args == test_dict

    # Test with a list
    test_list = ['value1', 'value2']
    test_cli_args = CLIArgs(test_list)
    assert isinstance(test_cli_args, ImmutableDict)
    assert test_cli_args == test_list

    # Test with a set
    test_set = {'value1', 'value2'}
    test_cli_args = CLIArgs(test_set)
    assert isinstance(test_cli_args, ImmutableDict)
    assert test_

# Generated at 2022-06-17 14:57:06.045454
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    import json
    import sys

    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'foo': 'bar'})
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args == {'foo': 'bar'}

    # Test that we can create a CLIArgs object from an options object
    class Options(object):
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    options = Options(foo='bar')
    cli_args = CLIArgs.from_options(options)

# Generated at 2022-06-17 14:57:11.267239
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:57:13.650795
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        pass

    t1 = Test()
    t2 = Test()
    assert t1 is t2

# Generated at 2022-06-17 14:57:18.869732
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass
    assert D() is D()
    assert D() is not A()
    assert D() is not B()
    assert D() is not C()

# Generated at 2022-06-17 14:57:27.751867
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 14:57:33.084392
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.module_utils.common.collections import ImmutableSet
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableSequence
    from ansible.module_utils.common.collections import ImmutableMapping
    from ansible.module_utils.common.collections import ImmutableContainer
    from ansible.module_utils.common.collections import MutableMapping
    from ansible.module_utils.common.collections import MutableSequence
    from ansible.module_utils.common.collections import MutableSet

# Generated at 2022-06-17 14:57:40.161753
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.module_utils.common.collections import ImmutableDict

    cli = CLI(args=sys.argv[1:])
    options = cli.parse()
    args = GlobalCLIArgs.from_options(options)
    assert isinstance(args, ImmutableDict)

# Generated at 2022-06-17 14:57:47.217676
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    args = CLIArgs({'foo': 'bar'})
    assert args['foo'] == 'bar'

    # Test that we can create a CLIArgs object with a nested dict
    args = CLIArgs({'foo': {'bar': 'baz'}})
    assert args['foo']['bar'] == 'baz'

    # Test that we can create a CLIArgs object with a nested list
    args = CLIArgs({'foo': ['bar', 'baz']})
    assert args['foo'][0] == 'bar'
    assert args['foo'][1] == 'baz'

    # Test that we can create a CLIArgs object with a nested set
    args = CLIArgs({'foo': {'bar', 'baz'}})
    assert 'bar' in args['foo']


# Generated at 2022-06-17 14:57:58.126271
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test the constructor of class CLIArgs
    test_dict = {'a': 'b', 'c': 'd'}
    test_cli_args = CLIArgs(test_dict)
    assert test_cli_args['a'] == 'b'
    assert test_cli_args['c'] == 'd'
    assert test_cli_args.a == 'b'
    assert test_cli_args.c == 'd'

    # Test the constructor of class CLIArgs with a nested dictionary
    test_dict = {'a': 'b', 'c': {'d': 'e'}}
    test_cli_args = CLIArgs(test_dict)
    assert test_cli_args['a'] == 'b'
    assert test_cli_args['c']['d'] == 'e'
    assert test_cli_args.a

# Generated at 2022-06-17 14:58:00.728313
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:58:02.474929
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:58:11.136366
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'a': 1, 'b': 2, 'c': 3}
    cli_args = CLIArgs(mapping)
    assert cli_args['a'] == 1
    assert cli_args['b'] == 2
    assert cli_args['c'] == 3
    assert cli_args.a == 1
    assert cli_args.b == 2
    assert cli_args.c == 3
    assert cli_args.get('a') == 1
    assert cli_args.get('b') == 2
    assert cli_args.get('c') == 3
    assert cli_args.get('d') is None
    assert cli_args.get('d', 4) == 4
    assert cli_args.get('d', default=4) == 4

# Generated at 2022-06-17 14:58:16.058530
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-17 14:58:24.962835
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import ansible.module_utils.common.arguments as arguments
    import ansible.module_utils.common.json_utils as json_utils
    import ansible.module_utils.common.text.converters as text_converters
    import ansible.module_utils.common.text.formatters as text_formatters
    import ansible.module_utils.common.text.utils as text_utils
    import ansible.module_utils.common.validation as validation
    import ansible.module_utils.common.warnings as warnings
    import ansible.module_utils.common.yaml_utils as yaml_utils
    import ansible.module_utils.common.xml_utils as xml_utils

    # The following modules are imported to make sure that the GlobalCLIArgs is not
    # initialized before the test.
    #

# Generated at 2022-06-17 14:58:43.536964
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that CLIArgs is immutable
    args = CLIArgs({'a': 1, 'b': 2})
    try:
        args['a'] = 3
    except TypeError:
        pass
    else:
        raise AssertionError('CLIArgs should be immutable')

    # Test that CLIArgs is a singleton
    args2 = CLIArgs({'a': 1, 'b': 2})
    assert args is args2

    # Test that CLIArgs is a singleton
    args3 = CLIArgs({'a': 1, 'b': 2})
    assert args is args3

    # Test that CLIArgs is a singleton
    args4 = CLIArgs({'a': 1, 'b': 2})
    assert args is args4

    # Test that CLIArgs is a singleton

# Generated at 2022-06-17 14:58:45.006760
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:58:52.076790
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    import sys
    import os
    import tempfile
    import shutil

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    curdir = os.getcwd()
    os.chdir(tmpdir)

    # Create the test file
    fd, testfile = tempfile.mkstemp()
    with os.fdopen(fd, 'wb') as f:
        f.write(to_bytes('foo: bar\n'))

# Generated at 2022-06-17 14:59:00.467893
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object
    cli_args = CLIArgs({'foo': 'bar'})
    assert cli_args['foo'] == 'bar'

    # Test that we can create a CLIArgs object with a nested dict
    cli_args = CLIArgs({'foo': {'bar': 'baz'}})
    assert cli_args['foo']['bar'] == 'baz'

    # Test that we can create a CLIArgs object with a nested list
    cli_args = CLIArgs({'foo': ['bar', 'baz']})
    assert cli_args['foo'][0] == 'bar'
    assert cli_args['foo'][1] == 'baz'

    # Test that we can create a CLIArgs object with a nested set

# Generated at 2022-06-17 14:59:07.072445
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a simple dict
    test_dict = {'a': 1, 'b': 2}
    test_args = CLIArgs(test_dict)
    assert test_args['a'] == 1
    assert test_args['b'] == 2

    # Test with a nested dict
    test_dict = {'a': 1, 'b': {'c': 2, 'd': 3}}
    test_args = CLIArgs(test_dict)
    assert test_args['a'] == 1
    assert test_args['b']['c'] == 2
    assert test_args['b']['d'] == 3

    # Test with a nested dict and a list
    test_dict = {'a': 1, 'b': {'c': 2, 'd': [3, 4]}}

# Generated at 2022-06-17 14:59:09.432457
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object):
        __metaclass__ = _ABCSingleton

    assert Test() is Test()

# Generated at 2022-06-17 14:59:16.534584
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:59:19.377353
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils.singleton import Singleton
    from ansible.utils.display import Display
    from ansible.utils.color import stringc

    assert issubclass(GlobalCLIArgs, ImmutableDict)
    assert issubclass(GlobalCLIArgs, Singleton)
    assert issubclass(GlobalCLIArgs, Display)
    assert issubclass(GlobalCLIArgs, stringc)

# Generated at 2022-06-17 14:59:23.150409
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:59:25.736490
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
    assert TestClass() is TestClass()

# Generated at 2022-06-17 14:59:52.189928
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 14:59:53.964513
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()

# Generated at 2022-06-17 15:00:00.408151
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a simple dictionary
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_args = CLIArgs(test_dict)
    assert test_args['a'] == 1
    assert test_args['b'] == 2
    assert test_args['c'] == 3

    # Test with a nested dictionary
    test_dict = {'a': 1, 'b': 2, 'c': {'d': 4, 'e': 5}}
    test_args = CLIArgs(test_dict)
    assert test_args['a'] == 1
    assert test_args['b'] == 2
    assert test_args['c']['d'] == 4
    assert test_args['c']['e'] == 5

    # Test with a nested dictionary and a list

# Generated at 2022-06-17 15:00:09.126070
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # pylint: disable=protected-access
    # pylint: disable=no-member
    # pylint: disable=unused-variable
    # pylint: disable=unused-argument
    # pylint: disable=redefined-outer-name
    # pylint: disable=unused-import
    import argparse
    from ansible.module_utils.common.argparse import ArgumentParser

    parser = ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add

# Generated at 2022-06-17 15:00:18.570891
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import subprocess
    import unittest

    class TestGlobalCLIArgs(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.test_file = os.path.join(self.test_dir, 'test_file')

        def tearDown(self):
            shutil.rmtree(self.test_dir)

        def test_GlobalCLIArgs(self):
            # Create a test file
            with open(self.test_file, 'w') as f:
                f.write(json.dumps({'test_key': 'test_value'}))

            # Run a subprocess to test GlobalCLIArgs

# Generated at 2022-06-17 15:00:26.359351
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.module_utils.common.argparse import ArgumentParser
    from ansible.module_utils.common.argparse import SUPPRESS

    parser = ArgumentParser(description='Test GlobalCLIArgs', add_help=False)
    parser.add_argument('-a', '--arg', dest='arg', default='default', help=SUPPRESS)
    parser.add_argument('-b', '--bar', dest='bar', default='default', help=SUPPRESS)
    parser.add_argument('-c', '--baz', dest='baz', default='default', help=SUPPRESS)
    parser.add_argument('-d', '--quux', dest='quux', default='default', help=SUPPRESS)

# Generated at 2022-06-17 15:00:31.544448
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': [5, 6, 7]})
    assert args['a'] == 1
    assert args['b'] == 2
    assert args['c']['d'] == 3
    assert args['c']['e'] == 4
    assert args['f'][0] == 5
    assert args['f'][1] == 6
    assert args['f'][2] == 7
    assert isinstance(args['c'], ImmutableDict)
    assert isinstance(args['f'], tuple)

# Generated at 2022-06-17 15:00:44.740710
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs constructor works as expected
    """
    test_dict = {'a': 1, 'b': {'c': [1, 2, 3], 'd': {'e': 4}}, 'f': [1, 2, 3]}
    test_args = CLIArgs(test_dict)

    assert test_args['a'] == 1
    assert test_args['b']['c'] == (1, 2, 3)
    assert test_args['b']['d']['e'] == 4
    assert test_args['f'] == (1, 2, 3)

    # Test that the dict is immutable
    try:
        test_args['a'] = 2
    except TypeError:
        pass
    else:
        raise AssertionError('CLIArgs should be immutable')


# Generated at 2022-06-17 15:00:55.757905
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a dict
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert isinstance(test_args, ImmutableDict)
    assert isinstance(test_args, Mapping)
    assert isinstance(test_args, Container)

    # Test with a list
    test_list = [1, 2, 3]
    test_args = CLIArgs(test_list)
    assert test_args == test_list
    assert isinstance(test_args, ImmutableDict)
    assert isinstance(test_args, Mapping)
    assert isinstance(test_args, Container)

    # Test with a set
    test_set = {1, 2, 3}
    test_args

# Generated at 2022-06-17 15:01:08.526311
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    import copy
    import types

    # Test that we can create an instance of CLIArgs
    test_dict = {'a': 1, 'b': 2, 'c': 3}
    cli_args = CLIArgs(test_dict)

    # Test that we can't modify the instance of CLIArgs
    with pytest.raises(TypeError):
        cli_args['a'] = 2

    # Test that we can't modify the instance of CLIArgs
    with pytest.raises(TypeError):
        cli_args.update({'a': 2})

    # Test that we can't modify the instance of CLIArgs
    with pytest.raises(TypeError):
        del cli_args['a']

    # Test that we can't modify the instance of CLIArgs

# Generated at 2022-06-17 15:01:57.748557
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.six import PY3

    if PY3:
        unicode_type = str
    else:
        unicode_type = unicode

    # Test that the constructor of GlobalCLIArgs is working
    # as expected.
    args = GlobalCLIArgs({'foo': 'bar', 'baz': 'qux'})
    assert isinstance(args, ImmutableDict)
    assert args['foo'] == 'bar'
    assert args['baz'] == 'qux'

    # Test that the constructor of GlobalCLIArgs is working
    # as expected.

# Generated at 2022-06-17 15:02:07.194367
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import CLIArgs
    from ansible.module_utils.common.collections import _make_immutable
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')

# Generated at 2022-06-17 15:02:10.016138
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    options = parser.parse_args(sys.argv[1:])
    args = GlobalCLIArgs.from_options(options)
    assert args.get('foo') is None

# Generated at 2022-06-17 15:02:21.926682
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    parser.add_argument('--qux', action='store_true')
    parser.add_argument('--quux', action='store_true')
    parser.add_argument('--corge', action='store_true')
    parser.add_argument('--grault', action='store_true')
    parser.add_argument('--garply', action='store_true')
    parser.add_argument('--waldo', action='store_true')
    parser.add_argument('--fred', action='store_true')
    parser

# Generated at 2022-06-17 15:02:23.080955
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Test that we can create a GlobalCLIArgs object
    GlobalCLIArgs({})

# Generated at 2022-06-17 15:02:32.065489
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()
    assert isinstance(A(), A)
    assert isinstance(B(), A)
    assert isinstance(C(), A)
    assert isinstance(A(), B) is False
    assert isinstance(A(), C) is False
    assert isinstance(B(), C) is False

# Generated at 2022-06-17 15:02:40.459209
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()

# Generated at 2022-06-17 15:02:47.437764
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', action='store_true')
    parser.add_argument('--baz', action='store_true')
    args = parser.parse_args(['--foo', '--bar'])
    GlobalCLIArgs.from_options(args)
    assert GlobalCLIArgs()['foo'] is True
    assert GlobalCLIArgs()['bar'] is True
    assert GlobalCLIArgs()['baz'] is False

# Generated at 2022-06-17 15:02:57.036617
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a dict
    test_dict = {'a': 'b', 'c': 'd'}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict

    # Test with a list
    test_list = ['a', 'b', 'c', 'd']
    test_args = CLIArgs(test_list)
    assert test_args == test_list

    # Test with a set
    test_set = set(['a', 'b', 'c', 'd'])
    test_args = CLIArgs(test_set)
    assert test_args == test_set

    # Test with a tuple
    test_tuple = ('a', 'b', 'c', 'd')
    test_args = CLIArgs(test_tuple)
    assert test_args == test_tuple

# Generated at 2022-06-17 15:02:59.190790
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', default='bar')
    args = parser.parse_args(['--foo', 'baz'])
    global_args = GlobalCLIArgs.from_options(args)
    assert global_args['foo'] == 'baz'