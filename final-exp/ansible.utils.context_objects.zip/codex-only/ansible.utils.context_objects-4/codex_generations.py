

# Generated at 2022-06-23 13:54:05.025028
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    assert isinstance(Foo(), Foo)
    # If this fails with "Missing ABCMeta attribute", then __metaclass__ isn't being overridden.
    assert Foo.__abstractmethods__ == frozenset()

# Generated at 2022-06-23 13:54:06.989349
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Should be able to create a new GlobalCLIArgs object
    GlobalCLIArgs.from_options(object())

# Generated at 2022-06-23 13:54:11.899281
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        def __init__(self):
            self.value = True
    test = Test()
    assert str(test) == '<Test>'
    assert repr(test) == '<Test>'

    # Singleton should only ever make one of these
    test2 = Test()
    assert id(test2) == id(test)
    del Test

# Generated at 2022-06-23 13:54:21.173237
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Create a dictionary
    test_dict = {
        "test1": "test1",
        "test2": ["test21", "test22"],
        "test3": {
            "test31": "test31",
            "test32": ["test321", "test322"],
            },
        "test4": {
            "test5": {
                "test51": "test51"
                },
            "test6": {
                "test61": ["test611", "test612"],
                },
            "test7": ["test71", "test72"],
            }
        }

    # Convert to CLIArgs
    cli_args = CLIArgs(test_dict)
    # Compare
    assert cli_args["test1"] == "test1"
    assert cli_args['test3']['test31']

# Generated at 2022-06-23 13:54:27.593762
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class TempCLIArgs(CLIArgs):
        def __init__(self, mapping):
            super(TempCLIArgs, self).__init__(mapping)

    class TempGlobalCLIArgs(GlobalCLIArgs):
        def __init__(self, mapping):
            super(TempGlobalCLIArgs, self).__init__(mapping)

    args = {'hello': 'world', 'spam': 'eggs'}
    temp_args = TempCLIArgs(args)
    assert temp_args == args

    temp_global_args = TempGlobalCLIArgs(args)
    assert temp_global_args == args

# Generated at 2022-06-23 13:54:37.972819
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    original = {'a': 'string', 'b': [1, 2, 3], 'c': {'d': 4, 'e': 5}, 'f': {}}
    args = CLIArgs(original)
    assert args.keys() == original.keys()
    assert args['a'] == original['a']
    assert args['b'] == original['b']
    assert args['c'] == original['c']
    assert args['f'] == original['f']

    original['a'] = 'foo'
    assert args['a'] != original['a']

    original['b'].pop()
    assert args['b'] != original['b']

    original['c']['d'] = 10
    assert args['c']['d'] != original['c']['d']

    original['f']['g'] = 'bar'
   

# Generated at 2022-06-23 13:54:45.385600
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Alpha(metaclass=_ABCSingleton):
        pass

    class Beta(Alpha):
        pass

    class Gamma(Beta):
        pass

    alphas = Alpha()
    assert isinstance(alphas, Alpha)

    betas = Beta()
    assert isinstance(betas, Beta)
    assert isinstance(betas, Alpha)

    gammas = Gamma()
    assert isinstance(gammas, Gamma)
    assert isinstance(gammas, Beta)
    assert isinstance(gammas, Alpha)


# Generated at 2022-06-23 13:54:51.786614
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import json
    import sys
    # fix sys.argv so it looks like the caller is 'ansible' running a playbook
    sys.argv = ['ansible', '-i /home/me/inventory', '-m ping', '-a "data={{inventory_hostname}}"', 'all']
    try:
        # ensure that the singleton instance is destroyed before we try to create a new instance
        del(GlobalCLIArgs._instances)
        gc = GlobalCLIArgs()
    except SystemExit as e:
        # we expect a SystemExit Exception to occur because sys.argv has data that is not valid for an
        # 'ansible' call.
        assert isinstance(e, SystemExit)
        assert e.code == 255

# Generated at 2022-06-23 13:55:00.928787
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_data = {
        'a': 1,
        'b': {'c': 2},
        'd': [1, 2, 3]
    }
    test_data_mutable = {
        'a': 1,
        'b': {'c': 2},
        'd': [1, 2, 3]
    }
    test_data_frozen = _make_immutable(test_data)
    instance = CLIArgs(test_data)
    assert instance == test_data_frozen
    test_data_mutable['a'] = 2
    assert instance != test_data_mutable



# Generated at 2022-06-23 13:55:05.009155
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object, metaclass=_ABCSingleton):
        pass
    class B(A):
        pass
    class C(A):
        pass
    A()
    B()
    C()

    x = A()
    y = A()
    assert x is y # and only one of them exists

# Generated at 2022-06-23 13:55:15.759051
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options_dict = dict(
        b_option='B',
        option_one='1',
        option_two=2,
        option_three=dict(
            nested_option_one='1',
            nested_option_two=2,
        ),
        option_four=dict(
            nested_option_one='1',
            nested_option_two=2,
            sub_dict=dict(
                double_nested_one='1',
                double_nested_two=2,
            ),
        ),
    )
    options = ImmutableDict(options_dict)
    GlobalCLIArgs(options)

# Generated at 2022-06-23 13:55:17.212553
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert GlobalCLIArgs is GlobalCLIArgs()



# Generated at 2022-06-23 13:55:20.318740
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    try:
        GlobalCLIArgs(vars(dict()))
        assert False
    except TypeError:
        pass

    try:
        GlobalCLIArgs.from_options(dict())
        assert False
    except TypeError:
        pass

# Generated at 2022-06-23 13:55:24.380182
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = {
        'check': True,
        'diff': True,
        'inventory': None,
        'listhosts': True,
    }
    GlobalCLIArgs(args)  # Constructor does not return anything

# Generated at 2022-06-23 13:55:35.020045
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class TestOptions(object):
        # This is a class made to mimic the class options
        def __init__(self):
            self.test1 = 'test'
            self.test2 = 'test 2'
            self.test3 = [1, 2, 3]
            self.test4 = [{'key': 'value'}]
            self.test5 = {'key': 'value'}

    # Create an instance of TestOptions and pass it to GlobalCLIArgs
    options = TestOptions()
    global_cli_args = GlobalCLIArgs.from_options(options)

    # Test various data types in GlobalCLIArgs
    assert global_cli_args.get('test1') == options.test1
    assert global_cli_args.get('test2') == options.test2
    assert global_cli_args.get

# Generated at 2022-06-23 13:55:40.104619
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # We can't access GlobalCLIArgs.instance() here because we haven't yet parsed args from the CLI
    # so there's nothing to test, but we can test that GlobalCLIArgs' superclass, CLIArgs, instantiates
    # and does the proper conversion on its data.
    args = GlobalCLIArgs({'test': [True, False]})
    assert args['test'][0] is True
    assert args['test'][1] is False

# Generated at 2022-06-23 13:55:43.132855
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Ensure _ABCSingleton is usable as a metaclass"""
    class _Test(object):
        __metaclass__ = _ABCSingleton
    assert type(_Test()) is _Test

# Generated at 2022-06-23 13:55:51.208335
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert isinstance(_make_immutable(set()), frozenset)
    assert isinstance(_make_immutable(frozenset()), frozenset)
    assert isinstance(_make_immutable(set()), frozenset)
    assert isinstance(_make_immutable([1]), tuple)
    assert isinstance(_make_immutable((1,)), tuple)
    assert isinstance(_make_immutable({1: 2}), ImmutableDict)
    assert isinstance(_make_immutable(ImmutableDict({1: 2})), ImmutableDict)
    assert isinstance(_make_immutable(""), text_type)

# Generated at 2022-06-23 13:55:59.322167
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils import basic
    from collections import OrderedDict
    from io import StringIO
    from ansible.cli import CLI

    # Create a mock stdout for our command line to use
    stdout = StringIO()

    # Create a mock file for our command line to use for a config file
    config_file_contents = text_type(OrderedDict([
        ('action_plugins', '/path/to/action_plugins'),
        ('host_key_checking', False),
        ('inventory', '/path/to/inventory'),
        ('module_utils', '/path/to/module_utils'),
        ('timeout', 30),
    ]))

# Generated at 2022-06-23 13:56:07.613527
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class A(object):
        def __init__(self, string):
            print("A's init: {}".format(string))

    class B(A):
        def __init__(self, string):
            pass

    class C(B, metaclass=_ABCSingleton):
        def __init__(self, string):
            print("Singleton's init: {}".format(string))
            super(C, self).__init__(string)

    # Confirm the superclass is called properly when there is only a subclass
    C("test")

    # Confirm the subclass is called properly when there is more than 1 class
    class D(B, metaclass=_ABCSingleton):
        def __init__(self, string):
            print("Singleton's init: {}".format(string))
            super(D, self).__

# Generated at 2022-06-23 13:56:10.046289
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object):
        __metaclass__ = _ABCSingleton

    class Test2(object):
        __metaclass__ = _ABCSingleton

    assert Test is Test2

# Generated at 2022-06-23 13:56:12.200328
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    first_instance = GlobalCLIArgs.instance()
    second_instance = GlobalCLIArgs.instance()
    assert first_instance == second_instance

# Generated at 2022-06-23 13:56:15.818262
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-23 13:56:24.211128
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import argparse
    arg_parser = argparse.ArgumentParser()
    arg_parser.add_argument("--foo", type=str, nargs='*')
    arg_parser.add_argument("--bar", type=int, nargs='*')
    options = arg_parser.parse_args("--foo f1 --foo f2 --bar 1 --bar 2".split())
    args = CLIArgs.from_options(options)
    assert isinstance(args, CLIArgs)
    assert args["foo"] == frozenset(["f1", "f2"])
    assert args["bar"] == (1, 2)

# Generated at 2022-06-23 13:56:33.761739
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(A):
        pass

    class C(B):
        pass

    assert issubclass(B, A)
    assert issubclass(C, A)
    assert issubclass(C, B)

    a = A()
    b = B()
    c = C()

    assert type(a) is A
    assert type(b) is A
    assert type(c) is A

    assert isinstance(a, A)
    assert isinstance(b, A)
    assert isinstance(c, A)
    assert isinstance(b, B)
    assert isinstance(c, B)
    assert isinstance(c, C)

# Generated at 2022-06-23 13:56:43.803051
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-23 13:56:46.620767
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # It is not possible to construct an instance of an abstract class.
    # So, if the constructor does not raise an exception, the test is passing.
    try:
        _ABCSingleton()
    except TypeError:
        pass

# Generated at 2022-06-23 13:56:54.422839
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ImplementsABC(_ABCSingleton):
        pass

    # See that this class only has one instance
    first = ImplementsABC()
    second = ImplementsABC()
    assert first is second, "_ABCSingleton didn't make a singleton"

    # See that it's a subclass of ABCMeta
    assert issubclass(ImplementsABC, ImplementsABC), "ImplementsABC is *not* a subclass of itself"

# Generated at 2022-06-23 13:56:59.892380
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ABCSingletonSingleton(object):
        __metaclass__ = _ABCSingleton

    class ABCSingletonSingletonChild(ABCSingletonSingleton):
        pass

    class NonSingleton(object):
        __metaclass__ = _ABCSingleton

    class NonSingletonChild(NonSingleton):
        pass

    class NonSingletonSingleton(object):
        pass

    class NonSingletonSingletonChild(NonSingletonSingleton):
        pass



# Generated at 2022-06-23 13:57:12.058350
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    global test_singleton
    if 'test_singleton' in globals():
        del globals()['test_singleton']
        del globals()['another_singleton']
    assert 'test_singleton' not in globals()
    assert 'another_singleton' not in globals()

    @add_metaclass(_ABCSingleton)
    class TestSingleton:
        def __init__(self):
            self.foo = 'bar'

    @add_metaclass(_ABCSingleton)
    class AnotherSingleton(TestSingleton):
        def __init__(self):
            super(AnotherSingleton, self).__init__()
            self.bar = 'foo'

    test_singleton = TestSingleton()
    another_singleton = AnotherSingleton()
    assert 'test_singleton' in globals

# Generated at 2022-06-23 13:57:22.312396
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    class B(A):
        pass

    assert issubclass(A, A)
    assert issubclass(B, B)
    assert issubclass(B, A)
    assert issubclass(A, B)

    # Make sure that the given metaclass functioned as a metaclass properly
    assert issubclass(A, Singleton)
    assert issubclass(A, ABCMeta)
    assert not issubclass(A, (Singleton, ABCMeta))
    assert not issubclass(A, (ABCMeta, Singleton))
    assert not issubclass(A, (ABCMeta, Singleton))
    assert not issubclass(A, (Singleton, ABCMeta))

# Generated at 2022-06-23 13:57:31.765153
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # This test is not used for module testing
    #
    #   It is used for manually testing the module to ensure
    # the proper behavior is being implemented.
    #
    #   To execute the unit test, run the following command:
    # python -m ansible.module_utils.common.arguments test_GlobalCLIArgs
    #
    #   The output will be printed to the stdout
    #

    # Initialize the object
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--tags", type=int)
    parser.add_argument("--check", action='store_true')
    parser.add_argument("--verbose", action='count', default=0)
    parser.add_argument("--force-handlers", action='store_false')
    parser.add_argument

# Generated at 2022-06-23 13:57:33.016298
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    obj = GlobalCLIArgs.instance(1)
    assert id(obj) == id(GlobalCLIArgs.instance(1))
    assert id(obj) != id(GlobalCLIArgs.instance(2))



# Generated at 2022-06-23 13:57:41.971909
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

        def __init__(self, *args, **kwargs):
            super(A, self).__init__(*args, **kwargs)

        def __str__(self):
            return 'A'

    # Construct an instance of A
    a = A()
    # check that we really only have one instance of A
    assert(id(a) == id(A()))
    # Check str representation
    assert(str(a) == 'A')

# Generated at 2022-06-23 13:57:47.296743
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        def __init__(self, **kwargs):
            self.__dict__ = kwargs
    import warnings
    warnings.simplefilter('error', UserWarning)
    opts = Options(foo='bar')
    args = GlobalCLIArgs.from_options(opts)
    assert args['foo'] == 'bar'

# Generated at 2022-06-23 13:57:54.536815
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Make a class based on _ABCSingleton
    class __ABCSingletonTest(object):
        __metaclass__ = _ABCSingleton

    # Check that only one object of the class exists, and that it is a singleton
    class_instance_one = __ABCSingletonTest()
    class_instance_two = __ABCSingletonTest()

    assert class_instance_one is class_instance_two, \
        '__ABCSingletonTest should be a singleton'

    # Check that the class is an abstract base class
    try:
        class_instance_one = __ABCSingletonTest()
        raise AssertionError(u'__ABCSingletonTest should be an abstract class')
    except TypeError:
        pass



# Generated at 2022-06-23 13:58:05.415902
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert GlobalCLIArgs == GlobalCLIArgs
    assert GlobalCLIArgs is GlobalCLIArgs
    assert GlobalCLIArgs is GlobalCLIArgs()
    global_cli_args = GlobalCLIArgs()
    assert global_cli_args == GlobalCLIArgs
    assert global_cli_args is GlobalCLIArgs
    assert global_cli_args is GlobalCLIArgs()
    assert global_cli_args == global_cli_args
    assert global_cli_args is global_cli_args
    assert global_cli_args is global_cli_args
    try:
        GlobalCLIArgs().__init__(dict())
        raise AssertionError("Failed to raise TypeError as __init__ should be overridden")
    except TypeError:
        pass

# Generated at 2022-06-23 13:58:16.800936
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class DummyOptions():
        pass

    mapping = DummyOptions()
    mapping.a = 1
    mapping.b = 'two'
    mapping.c = [1, 2, 3]
    mapping.d = {'a': 1, 'b': 2}
    mapping.e = {'a', 'b', 'c'}
    mapping.f = {'a', 'b', 'c', 'b'}
    mapping.g = ['a', 'b', 'c', 'b']
    mapping.h = ['Foo', 'Bar', 'Baz']
    mapping.i = 'hyvaa'

    args = CLIArgs.from_options(mapping)

    assert args.a == 1
    assert args.b == 'two'
    assert args.c == (1, 2, 3)

# Generated at 2022-06-23 13:58:22.326946
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli.arguments import AnsibleCLIArguments
    from ansible.module_utils._text import to_native

    options = AnsibleCLIArguments().parse()
    args = GlobalCLIArgs(vars(options))
    assert(args == vars(options))
    assert(str(args) == to_native(vars(options)))

# Generated at 2022-06-23 13:58:28.369432
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class __TestClass(_ABCSingleton):
        def __init__(self):
            self.value = "test"

    obj1 = __TestClass()
    obj2 = __TestClass()

    assert obj1 is obj2
    assert obj1.value == "test"
    assert obj2.value == "test"

# Generated at 2022-06-23 13:58:30.348698
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {"key1": "value1", "key2": "value2"}
    result = CLIArgs(mapping)
    assert isinstance(result, ImmutableDict)
    for key, value in mapping.items():
        assert result[key] == value


# Generated at 2022-06-23 13:58:33.642172
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class testclass(metaclass=_ABCSingleton):
        def __init__(self):
            self.a = 'a'
            self.b = 'b'
        def __eq__(self, other):
            return self.a == other.a and self.b == other.b
        def __iter__(self):
            for i in ('a', 'b'):
                yield i

    t1 = testclass()
    t2 = testclass()
    assert(t1 == t2)



# Generated at 2022-06-23 13:58:37.475702
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_dict = {'a': 'b', 'c': 3, 'd': {}, 'e': '{{}}'}
    if not isinstance(GlobalCLIArgs(test_dict), GlobalCLIArgs):
        raise Exception('Failed to create GlobalCLIArgs.')

# Generated at 2022-06-23 13:58:47.874340
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict_ = dict(a=dict(b=dict(c=dict(d=1))), e=2)
    args = CLIArgs(dict_)
    assert isinstance(args, dict)
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, CLIArgs)
    # ImmutableDict is a subclass of dict
    assert isinstance(args, dict)
    # ImmutableDict is a subclass of dict, dict is a subclass of Mapping
    assert isinstance(args, Mapping)
    assert isinstance(args['a'], ImmutableDict)
    assert isinstance(args['a']['b'], ImmutableDict)
    assert isinstance(args['a']['b']['c'], ImmutableDict)

# Generated at 2022-06-23 13:58:54.476519
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Check that the constructor works
    args_dict = {
        'a': 1,
        'b': '2',
        'c': True,
        'd': {
            'nested': True,
        },
    }
    args = CLIArgs(args_dict)

    # Check that the constructor creates all the immutable data types
    assert isinstance(args, Mapping)
    assert isinstance(args['d'], Mapping)
    for key, value in args.items():
        assert not isinstance(value, Container)

    # Check that the constructor created the dictionary correctly
    for key, value in args.items():
        assert args_dict[key] == value
        assert args_dict[key] == args[key]
        assert value == args[key]



# Generated at 2022-06-23 13:58:57.976998
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import argparse
    parser = argparse.ArgumentParser(description="Unit test for CLIArgs")
    parser.add_argument('--tags', default='', type=str)
    options = parser.parse_args()
    cli_args = CLIArgs.from_options(options)
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args['tags'] == ''

# Generated at 2022-06-23 13:59:08.467053
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_data = {'ints': 2, 'strings': 'hello', 'lists': [2, 3, 4], 'dicts': {'bar': 'hello', 'foo': 2}}
    for key, value in test_data.items():
        if isinstance(value, Mapping):
            assert isinstance(CLIArgs(test_data)[key], ImmutableDict),\
                "Key %s should be immutable" % key
        elif isinstance(value, Sequence):
            assert isinstance(CLIArgs(test_data)[key], tuple),\
                "Key %s should be immutable" % key
        elif isinstance(value, Set):
            assert isinstance(CLIArgs(test_data)[key], frozenset),\
                "Key %s should be immutable" % key

# Generated at 2022-06-23 13:59:09.664904
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # unit test of constructor
    GlobalCLIArgs(dict())
    assert True

# Generated at 2022-06-23 13:59:20.179404
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        a = 1
    class B(A):
        b = 2
    class C(B):
        c = 3
    a1 = A()
    a2 = A()
    # Demonstrate that C is a subclass of A, B is a subclass of A and that A is an abstract base
    # class by constructing an instance of each.
    assert isinstance(a1, A)
    assert isinstance(a1, B)
    assert isinstance(a1, C)
    assert issubclass(A, A)
    assert issubclass(B, A)
    assert issubclass(C, A)
    assert issubclass(C, B)
    assert a1.a == a2.a == 1
    assert a1.b == a2.b == 2


# Generated at 2022-06-23 13:59:28.050968
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    data = dict(a=1, b=2)
    cli_args = CLIArgs(data)
    assert cli_args == ImmutableDict(data)

    data = dict(a=1, b=dict(c=2))
    cli_args = CLIArgs(data)
    assert cli_args == ImmutableDict(data)

    data = dict(a=1, b=dict(c=dict(d=2)))
    cli_args = CLIArgs(data)
    assert cli_args == ImmutableDict(data)

    data = dict(a=dict(b=dict(c=dict(d=2))))
    cli_args = CLIArgs(data)
    assert cli_args == ImmutableDict(data)


# Generated at 2022-06-23 13:59:37.633681
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton):
        pass

    class Bar(_ABCSingleton):
        pass

    # pylint: disable=unused-variable
    foo1 = Foo()
    foo2 = Foo()
    # pylint: enable=unused-variable

    # pylint: disable=unused-variable
    bar1 = Bar()
    bar2 = Bar()
    # pylint: enable=unused-variable

    # Ensure that aliases do not trigger hash collisions
    # pylint: disable=unused-variable
    class FooBar(_ABCSingleton):
        pass
    # pylint: enable=unused-variable

    # Ensure that metaclasses do not trigger hash collisions
    # pylint: disable=unused-variable
    class Baz(object):
        __metaclass__ = _ABCSingleton


# Generated at 2022-06-23 13:59:41.201940
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(ImmutableDict, metaclass=_ABCSingleton):
        pass

    class B(A):
        pass

    B()

    class C(A):
        pass

    C()

# Generated at 2022-06-23 13:59:47.241932
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    options = {'a': 'a', 'b': 'b', 'c': [1, 2, 3]}
    opt_obj = type("OptionObject", (object, ), options)
    args = CLIArgs.from_options(opt_obj)
    assert args['a'] == 'a'
    assert args['b'] == 'b'
    assert args['c'] == (1, 2, 3)

# Generated at 2022-06-23 13:59:58.816715
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import json
    import tempfile
    from ansible.module_utils.common._text import to_bytes

    with tempfile.NamedTemporaryFile('wb', suffix='.json') as f:
        f.write(to_bytes(json.dumps({'a': {'b': {'c': 'd'}}, 'e': [{'f': ['g', 'h']}]})))
        f.flush()


# Generated at 2022-06-23 14:00:10.802040
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import os

    assert os.path.exists('/bin/bash')
    assert not os.path.exists('/bin/bash1')
    assert not os.path.exists('/bin/bash2')

    fo = make_options()
    cli_args = CLIArgs.from_options(fo)

    assert cli_args.get('verbosity') == 2
    assert cli_args.get('module_path') == '/usr/share/ansible'
    assert cli_args.get('inventory') is None
    assert cli_args.get('module_name') == 'file'
    assert cli_args.get('module_args') == 'state=directory path=/bin/bash owner=foo group=bar mode=0755'
    assert cli_args.get('forks') == 10

# Generated at 2022-06-23 14:00:13.302321
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    a = A()
    assert a == A()

# Generated at 2022-06-23 14:00:26.420751
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Set up a dictionary of values to initialize the CLIArgs object with
    temp_dict = {
        'foo': [1, 2, 3, 4, 5],
        'bar': {
            'bar1': {'bar1-1': 'bar1-1', 'bar1-2': 'bar1-2'},
            'bar2': {'bar2-1': 'bar2-1', 'bar2-2': 'bar2-2'},
        },
        'baz': {1, 2, 3, 4, 5}
    }

    # Verify that the CLIArgs object properly converts the values to immutable values
    cli_args = CLIArgs(temp_dict)

    # Verify that all values are immutable

# Generated at 2022-06-23 14:00:30.199368
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'verbose': 2, 'answer': 42})
    assert isinstance(args, Mapping)
    assert args == {'verbose': 2, 'answer': 42}
    assert args.verbose == 2
    assert args.answer == 42
    assert not hasattr(args, 'not blah blah blah')



# Generated at 2022-06-23 14:00:31.766548
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({})

# Generated at 2022-06-23 14:00:42.392860
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import yaml
    GlobalCLIArgs.instance(CLIArgs.from_options({'CONFIG_FILE': '/path/to/ansible.cfg',
                                                 'vault_password_file': '/path/to/vault_password_file',
                                                 'inventory': './hosts.inventory',
                                                 'listhosts': 'true'}))
    assert GlobalCLIArgs().CONFIG_FILE == '/path/to/ansible.cfg'
    assert GlobalCLIArgs().vault_password_file == '/path/to/vault_password_file'
    assert GlobalCLIArgs().inventory == './hosts.inventory'
    assert GlobalCLIArgs().listhosts == 'true'

# Generated at 2022-06-23 14:00:53.562766
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.module_utils.common.text.converters import to_text
    from ansible.plugins.loader import cli as cli_plugins
    from ansible.cli import CLI
    options, _ = CLI.parse()

    toplevel = {}
    for key, value in vars(options).items():
        toplevel[key] = _make_immutable(value)

    global_args = GlobalCLIArgs(toplevel)

    assert isinstance(global_args, GlobalCLIArgs)
    assert isinstance(global_args, CLIArgs)
    assert isinstance(global_args, ImmutableDict)
    assert isinstance(global_args, dict)
    assert global_args == toplevel
    assert global_args.vars() == options.vars()


# Generated at 2022-06-23 14:00:56.817625
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Instance of GlobalCLIArgs does not exist yet.
    args = GlobalCLIArgs(dict(foo=123))
    assert args['foo'] == 123
    assert args.get('bar', None) is None
    assert args.get('foo', None) == 123
    assert len(args) == 1



# Generated at 2022-06-23 14:01:05.018204
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test CLIArgs. This function is called by 'pytest'
    """

    # Check empty dict
    cli_args = CLIArgs({})
    assert boolean_env == {}

    # Check dict with single value
    cli_args = CLIArgs({'key': 'val'})
    assert boolean_env == {'key': 'val'}

    # Check dict with multi value and immutability
    cli_args = CLIArgs({'key': 'val', 'key2': ['v1', 'v2']})
    assert boolean_env == {'key': 'val', 'key2': ('v1', 'v2')}

    cli_args['key2'][0] = 'v3'
    assert boolean_env == {'key': 'val', 'key2': ('v1', 'v2')}



# Generated at 2022-06-23 14:01:10.579120
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    mapping = {"a": 1, "b": 2}

    args = GlobalCLIArgs(mapping)

    assert isinstance(args, CLIArgs)
    assert args["a"] == 1
    assert args["b"] == 2

    mapping["a"] = 3

    assert args["a"] == 1
    assert args["b"] == 2

GlobalCLIArgs()

# Generated at 2022-06-23 14:01:22.518029
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.removed import removed
    assert removed is not None

    class Options(object):
        pass

    options = Options()
    options.foo = 'blah'
    options.bar = 3
    options.baz = {'a': 'b', 'c': 'd'}
    options.bing = ['hi', 'there']
    options.bang = {'oops'}
    options.bung = {'oops', 'wa'}
    options.boom = [{'a': 'b'}, 'c', {'d': 'e'}]
    options.bunk = ('f', {'g': 'h'}, 'i')

    options = CLIArgs.from_options(options)
    assert options['foo'] == 'blah'
    assert options['bar'] == 3
   

# Generated at 2022-06-23 14:01:24.257515
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton(_ABCSingleton):
        pass

    class TestABC(_ABCSingleton):
        pass

    assert TestSingleton == TestSingleton
    assert TestABC == TestABC

# Generated at 2022-06-23 14:01:29.273680
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options_dict = {'something': list(range(5))}
    options = type('Options', (object,), options_dict)
    cli_args = GlobalCLIArgs.from_options(options)

    assert cli_args is GlobalCLIArgs()
    assert isinstance(cli_args['something'], tuple)
    for item in cli_args['something']:
        assert isinstance(item, int)

# Generated at 2022-06-23 14:01:30.568615
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
     a = GlobalCLIArgs.from_options()


# Generated at 2022-06-23 14:01:32.780508
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Make sure we can create an instance of GlobalCLIArgs
    """
    args = GlobalCLIArgs({})

# Generated at 2022-06-23 14:01:41.354945
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import json
    import sys
    sys.argv = ['/path/to/python', '--foo', 'bar']

    # Test ability to create and verify type, default values and fairness
    # of comparisons
    args = GlobalCLIArgs({})
    assert len(args) == 0
    assert isinstance(args, ImmutableDict)
    assert args == {}
    assert args != {}
    assert args != {'foo': 'bar'}

    # Test ability to create from a options object and verify type, and
    # basic parsing.  We don't need to test the full set of command line
    # arguments, because we'll use the python argparse module to test the
    # parsing for us.
    args = GlobalCLIArgs.from_options({'foo': 'bar'})
    assert len(args) == 1
    assert isinstance

# Generated at 2022-06-23 14:01:52.770218
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Set up arguments
    original = {u'foo': {'my_var': b'baz', 'my_var2': "bat"}, u'bar': {'my_var': 8, 'my_var2': "bat"}}
    args = CLIArgs(original)
    assert args == original

    # Verify set-like behaviour
    assert isinstance(args['foo'], ImmutableDict)
    assert isinstance(args['bar'], ImmutableDict)

    # Verify failure on mutation
    try:
        args['foo']['my_var'] = 'qux'
        assert False, 'Mutation was not prevented.'
    except TypeError:
        pass

# Generated at 2022-06-23 14:01:55.196428
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': '1', 'b':'2'}
    obj = CLIArgs(test_dict)
    assert obj.a == '1'
    assert obj.b == '2'
    assert isinstance(obj, ImmutableDict)


# Generated at 2022-06-23 14:02:04.175966
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import unittest
    import os
    import tempfile
    from ansible.parsing import vault

    options = unittest.mock.Mock()

    options.ask_vault_pass = True
    vault_pass_fd, options.vault_pass = tempfile.mkstemp()
    os.close(vault_pass_fd)
    options.ask_new_vault_pass = True
    new_vault_pass_fd, options.new_vault_pass = tempfile.mkstemp()
    os.close(new_vault_pass_fd)
    options.vault_identity_list = []
    options.vault_password_files = []
    options.ask_sudo_pass = True
    options.sudo = True
    options.sudo_user = "ansible"
   

# Generated at 2022-06-23 14:02:10.829169
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    pytest_1 = dict(
        ansible_python_interpreter='/usr/bin/python3',
        extra_vars=[],
        connection='local',
        module_path=None,
        forks=5,
        ask_vault_pass=False,
        verbosity=None,
        src=None,
        become=False,
        become_method='sudo',
        become_user='root',
        check=False,
        diff=False,
        listhosts=None,
        listtasks=None,
        listtags=None,
        syntax=None
    )

    options_1 = ImmutableDict(pytest_1)

    options_2 = CLIArgs.from_options(options_1)
    assert pytest_1 == dict(options_2)

# Generated at 2022-06-23 14:02:17.785798
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Test that subclasses of _ABCSingleton cannot be created more than once
    """
    class FooSingleton(_ABCSingleton):
        def __init__(self, foo):
            self.foo = foo

    instance1 = FooSingleton('bar')
    instance2 = FooSingleton('baz')
    assert instance1 is instance2
    assert instance1.foo == 'baz'
    assert instance2.foo == 'baz'



# Generated at 2022-06-23 14:02:26.763218
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    options = {'foo': 'bar', 'baz': {'bim': 'bop'}, 'ding': ['dong', 'ding', 'dang']}
    options_obj = CLIArgs(options)
    # Make sure it is immutable
    with pytest.raises(TypeError):
        options_obj['foo'] = 'Bang!'
    # Make sure we don't clobber our input
    options['foo'] = 'Bang!'
    assert options_obj == {'foo': 'bar', 'baz': {'bim': 'bop'}, 'ding': ('dong', 'ding', 'dang')}

# Generated at 2022-06-23 14:02:30.073607
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Test:
        def __init__(self):
            self.a = True
            self.b = False

    test = Test()
    global_cli_args = GlobalCLIArgs.from_options(test)

# Generated at 2022-06-23 14:02:34.557195
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(metaclass=_ABCSingleton):
        pass

    class Bar(metaclass=_ABCSingleton):
        pass

    foo_a = Foo()
    foo_b = Foo()
    assert foo_a is foo_b

    bar_a = Bar()
    bar_b = Bar()
    assert bar_a is bar_b

    assert foo_a is not bar_a

# Generated at 2022-06-23 14:02:39.277574
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass

    a1 = A()
    a2 = A()
    assert a1 is a2
    b1 = B()
    assert b1 is a1



# Generated at 2022-06-23 14:02:42.145640
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class cls1(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(cls1, ABCMeta)
    assert isinstance(cls1, Singleton)

# Generated at 2022-06-23 14:02:49.224978
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = GlobalCLIArgs({
        'a': 1,
        'b': {
            'c': 2,
            'd': [3, 4],
            'e': (5, 6),
            'f': {
                'g': 7,
                'h': [8, 9],
                'i': (10, 11),
            },
            'j': ['k', 'l'],
            # Missing tuples
            # Missing dicts
        },
    })
    assert isinstance(a, Mapping)
    assert isinstance(a, Container)
    assert isinstance(a.get('a'), int)
    assert isinstance(a.get('b'), Mapping)
    assert isinstance(a.get('b').get('c'), int)

# Generated at 2022-06-23 14:02:51.623140
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    a = A()
    assert a is A()
    assert a is A()

# Generated at 2022-06-23 14:03:03.250500
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import tempfile
    import os

    from ansible.cli import CLI
    from ansible.config.data import ConfigData
    from ansible.utils import context_objects as co

    global_args = GlobalCLIArgs()

    with tempfile.NamedTemporaryFile(delete=False) as config_file:
        config_file.write(b'[defaults]\n')
        config_file.write(b'inventory = /etc/ansible/hosts\n')
        config_file.flush()
        os.fchmod(config_file.fileno(), 0o600)
        co.GlobalCLIArgs._instance = None
        global_args = GlobalCLIArgs()
        global_args.add_args(dict(config_file=config_file.name))

# Generated at 2022-06-23 14:03:09.298509
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyClass:
        pass
    assert type(MyClass) == type, "MyClass should not have a metaclass"
    class MyClass:
        __metaclass__ = _ABCSingleton
    assert type(MyClass) != type, "MyClass should have a metaclass"
    class MyChildClass(MyClass):
        pass
    MyChildClass()
    assert type(MyChildClass) != type, "MyChildClass should have a metaclass"



# Generated at 2022-06-23 14:03:11.008212
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ABCSingletonTest(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(ABCSingletonTest(), ABCSingletonTest)

# Generated at 2022-06-23 14:03:14.306790
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(_ABCSingleton):
        pass
    class B(_ABCSingleton):
        pass
    a1 = A()
    a2 = A()
    assert a1 is a2
    b1 = B()
    b2 = B()
    assert b1 is b2
    assert a1 is not b1

# Generated at 2022-06-23 14:03:21.782987
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test constructor of class CLIArgs
    """
    # Initialize a test object
    test_list = ['one', 'two', 'three']

    # Convert test dict to an immutable dict
    result = CLIArgs(test_list)

    # Assert result is immutable
    assert isinstance(result, ImmutableDict)

    # Assert result is not a list
    assert not isinstance(result, list)

    # Assert result is convertible to a list
    assert isinstance(result, Sequence)

# Generated at 2022-06-23 14:03:25.322160
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Make sure the constructor of class GlobalCLIArgs works.
    """
    GlobalCLIArgs(vars(()))

# Generated at 2022-06-23 14:03:33.709493
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = {
        "boolean": True,
        "string": "test",
        "tuple": ("tuple", "tuple"),
        "dict": {
            "dict_boolean": True,
            "dict_string": "test",
            "dict_tuple": ("tuple", "tuple"),
            "dict_dict": {
                "dict_dict_boolean": True,
                "dict_dict_string": "test",
                "dict_dict_tuple": ("tuple", "tuple"),
                "dict_dict_dict": {
                    "dict_dict_dict_boolean": True,
                    "dict_dict_dict_string": "test",
                    "dict_dict_dict_tuple": ("tuple", "tuple")
                }
            }
        }
    }

    cl

# Generated at 2022-06-23 14:03:36.490506
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, ABCMeta)
    assert issubclass(_ABCSingleton, Singleton)
    assert issubclass(GlobalCLIArgs, CLIArgs)

# Generated at 2022-06-23 14:03:37.750650
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    assert A() == A()

# Generated at 2022-06-23 14:03:40.717504
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Ensure that multiple calls to the constructor return the same object
    global_cli_args1 = GlobalCLIArgs({'a': 'b'})
    global_cli_args2 = GlobalCLIArgs({'a': 'b'})

    assert global_cli_args1 == global_cli_args2

# Generated at 2022-06-23 14:03:52.312493
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Test that constructor correctly converts Python data types to immutable types"""
    list_data = ['apple', 'pear', 'peach', 'orange']
    dict_data = {'anne': 'ann', 'bob': 'bobby'}
    nested_data = {'key1': [list_data, dict_data], 'key2': set((1, 2, 3))}
    cli_args = CLIArgs(nested_data)

    # Test that list_data and dict_data are not changed when passed through CLIArgs constructor
    list_data[0] = 'mango'
    dict_data['anne'] = 'annie'
    assert list_data == ['mango', 'pear', 'peach', 'orange']
    assert dict_data == {'anne': 'annie', 'bob': 'bobby'}
    # Test

# Generated at 2022-06-23 14:04:04.090526
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli.arguments import Options

    options = Options()
    options.connection = 'local'
    options.module_path = '/path/to/ansible/modules'
    options.forks = 5
    options.become = False
    options.become_method = 'sudo'
    options.become_user = 'root'
    options.check = False
    options.diff = False

    GlobalCLIArgs.from_options(options)
    assert GlobalCLIArgs().get('connection') == 'local'
    assert GlobalCLIArgs().get('module_path') == '/path/to/ansible/modules'
    assert GlobalCLIArgs().get('forks') == 5
    assert GlobalCLIArgs().get('become') == False