

# Generated at 2022-06-23 13:54:11.169568
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test copying of command line arguments

    Test that command line arguments are copied into an instance of class CLIArgs.
    Make sure that the copy is immutable and that it did not modify the original copy.
    """
    import copy
    import random
    import string

    # Generate some random strings
    n_str = random.randint(3, 10)
    str_list = []
    for i in range(n_str):
        str_list.append(''.join(random.choice(string.ascii_lowercase) for x in range(10)))

    # Use a slice of the list of random strings to generate a dictionary
    n_dict = random.randint(1, n_str - 1)
    dict_items = [(str_list[i], str_list[i + 1]) for i in range(n_dict)]


# Generated at 2022-06-23 13:54:17.450108
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Make sure to clone final class so we don't change the namespace of the module
    class CLIArgs(CLIArgs):
        pass
    args = CLIArgs.from_options(dict(one=1, two=2))
    assert isinstance(args, ImmutableDict)
    assert args.get('one') == 1
    assert args.get('two') == 2
    assert args.one == 1
    assert args.two == 2



# Generated at 2022-06-23 13:54:20.081293
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class AAA(object):
        __metaclass__ = _ABCSingleton
    assert type(AAA())

# Generated at 2022-06-23 13:54:28.146206
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    with GlobalCLIArgs.lock:
        args = GlobalCLIArgs({'a': 1, 'b': [2, 3], 'c': 'stuff', 'd': True, 'e': {'f': 4}, 'g': {'h': 5}, 'i': True})
        assert args['a'] == 1
        assert args['b'] == (2, 3)
        assert args['c'] == 'stuff'
        assert args['d'] == True
        assert args['e'] == {'f': 4}
        assert args['g'] == {'h': 5}
        assert args['i'] == True
        assert 'a' in args
        assert 'd' in args
        assert 'g' in args
        assert 'k' not in args
        assert len(args) == 7

# Generated at 2022-06-23 13:54:31.578746
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {'user': 'root', 'ssl': True, 'ssh-key': 'mykey'}
    inst = CLIArgs(args)
    assert isinstance(inst, ImmutableDict)
    assert inst == args



# Generated at 2022-06-23 13:54:39.459915
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABCSingletonTest(_ABCSingleton):
        pass

    # Make sure the metaclass is working
    class _ABCSingletonTest2(_ABCSingletonTest):
        pass

    class _ABCSingletonTest3(object):
        """Shouldn't be using _ABCSingletonTest class as a metaclass when called like this"""
        __metaclass__ = _ABCSingletonTest

    class _ABCSingletonTest4(object):
        """Should be using _ABCSingletonTest class as a metaclass when called like this"""
        __metaclass__ = _ABCSingletonTest
        __metaclass__ = _ABCSingletonTest2

# Generated at 2022-06-23 13:54:48.954904
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-23 13:54:51.453635
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestType(metaclass=_ABCSingleton):
        pass
    TestType()

# Generated at 2022-06-23 13:54:57.433412
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': {'b': ['c', 'd']}})
    assert isinstance(args, CLIArgs)
    assert isinstance(args['a'], ImmutableDict)
    assert isinstance(args['a']['b'], tuple)
    assert args['a']['b'][0] == 'c'

# Generated at 2022-06-23 13:55:00.700124
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # This is not a true unit test as it does not test anything, only that the class starts up ok
    # See https://github.com/ansible/ansible/issues/63575
    assert issubclass(GlobalCLIArgs, CLIArgs)

# Generated at 2022-06-23 13:55:04.817365
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    class TestClass2(object):
        # specify a non-metaclass
        __metaclass__ = _ABCSingleton

    assert TestClass() is TestClass()
    assert TestClass2() is TestClass2()



# Generated at 2022-06-23 13:55:17.690143
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Test for the __init__ method of class GlobalCLIArgs."""
    # Test for normal dictionary
    test_dict = {
        'k1': 'v1',
        'k2': {
            'k21': 'v21',
            'k22': ['v221', 'v222']
        },
        'k3': ['v31', 'v32']
    }
    result = GlobalCLIArgs.from_options(test_dict)
    expected = {
        'k1': 'v1',
        'k2': ImmutableDict({
            'k21': 'v21',
            'k22': ('v221', 'v222')
        }),
        'k3': ('v31', 'v32')
    }
    assert expected == result
    # Test for subclass of dict

# Generated at 2022-06-23 13:55:21.032701
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test __init__ method of GlobalCLIArgs
    """
    args_dict = {'apples': 'oranges'}
    new_obj = GlobalCLIArgs(args_dict)
    assert new_obj == {'apples': 'oranges'}



# Generated at 2022-06-23 13:55:24.450854
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class A(with_metaclass(_ABCSingleton)):
        pass

    class B(A):
        pass

    assert issubclass(B, A)

# Generated at 2022-06-23 13:55:34.813496
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test the constructor of class CLIArgs
    """
    # Build test data and expected result
    test_data = ImmutableDict({'a': 1, 'c': {'d': 2, 'e': [3, 4], 'f': text_type('c'), 'g': None}, 'h': {'i': [5]}})
    expected_result = ImmutableDict({'a': 1, 'c': ImmutableDict({'d': 2, 'e': (3, 4), 'f': text_type('c'), 'g': None}), 'h': ImmutableDict({'i': (5,)})})
    # Test code
    result = CLIArgs(test_data)
    # Test result
    assert result == expected_result


# Generated at 2022-06-23 13:55:41.140587
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import unittest
    class TestCase(unittest.TestCase):
        def test_abc_meta(self):
            """GlobalCLIArgs is a singleton"""
            cli_args = GlobalCLIArgs(dict(a=1, b=1))
            cli_args1 = GlobalCLIArgs(dict(a=2, b=2))
            assert id(cli_args) == id(cli_args1), "GlobalCLIArgs doesn't have a singleton implementation"
    unittest.main(argv=[''], verbosity=2, exit=False)

# Generated at 2022-06-23 13:55:47.723865
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    cli_args = GlobalCLIArgs({
        'foo': 'bar',
        'fizz': 'buzz',
        '_ansible_verbosity': 4,
    })

    assert isinstance(cli_args, GlobalCLIArgs)
    assert cli_args['foo'] == 'bar'
    assert cli_args['fizz'] == 'buzz'
    assert isinstance(cli_args['_ansible_verbosity'], int)

# Generated at 2022-06-23 13:55:51.814189
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton):
        pass
    class Bar(_ABCSingleton):
        pass

    assert Foo() is Foo(), 'Singleton does not work'
    assert Foo() is not Bar(), 'Singleton does not work, should be separate instances for each class'

# Generated at 2022-06-23 13:55:59.663236
# Unit test for constructor of class _ABCSingleton

# Generated at 2022-06-23 13:56:04.069607
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class AC(object):
        __metaclass__ = _ABCSingleton

    class B(metaclass=_ABCSingleton):
        pass

    class C(object):
        __metaclass__ = _ABCSingleton

    assert AC() is AC()
    assert B() is B()
    assert C() is C()

# Generated at 2022-06-23 13:56:08.594082
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.collection_plugins.core import Options
    options = Options()
    options.some_option = 1
    options.other_option = 'one'
    cli_args = CLIArgs.from_options(options)
    assert cli_args.some_option == 1
    assert cli_args.other_option == 'one'

# Generated at 2022-06-23 13:56:19.554047
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Unit test for class _ABCSingleton
    from unittest import TestCase

    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    class C(A, B):
        pass

    class D(B, A):
        pass

    class E(C, D):
        pass

    class F(D, C):
        pass

    class G(E, F):
        pass

    class H(F, E):
        pass

    class I(G, H):
        pass

    class J(H, G):
        pass

    class K(I, J):
        pass

    class L(J, I):
        pass

    class M(K, L):
        pass


# Generated at 2022-06-23 13:56:24.980482
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.errors import AnsibleError
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils._text import to_text
    from six import PY3

    # Create a new instance of the GlobalCLIArgs class

# Generated at 2022-06-23 13:56:33.430427
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.parsing.plugin_docs import read_docstring
    from ansible.utils import module_docs as mod_docs
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 2
    plugin_docs = read_docstring(mod_docs, ignore_errors=True, _plugin_type_filter='module')
    module_info = plugin_docs['module_info']
    assert isinstance(module_info, Mapping)
    cli_args = CLIArgs(module_info)
    assert isinstance(cli_args, ImmutableDict)

# Generated at 2022-06-23 13:56:43.741203
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-23 13:56:49.492566
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    top_level_args = {'version': True, 'debug': False, 'module': 'ping'}
    ansible_config = 'config_path'
    ansible_inventory = 'inventory_path'
    ansible_playbook = 'playbook_path'
    ansible_plugin = ['plugin_dir', 'plugin_dir2']

    ansible_args = {'ansible_config': ansible_config,
                    'ansible_inventory': ansible_inventory,
                    'ansible_playbook': ansible_playbook,
                    'ansible_plugins': ansible_plugin}

    sub_level_args = {'ansible': ansible_args}

    cli_args = {'args': sub_level_args}

    cli_args.update(top_level_args)
    expected_ansible_plugins

# Generated at 2022-06-23 13:56:59.493861
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common._collections_compat import OrderedDict
    from ansible.module_utils.common.collections import frozendict

# Generated at 2022-06-23 13:57:04.087269
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.params = {}
    GlobalCLIArgs({'ANSIBLE_MODULE_ARGS': module.params})

# Generated at 2022-06-23 13:57:05.526388
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import doctest
    doctest.testmod(verbose=False)



# Generated at 2022-06-23 13:57:13.465542
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Test correct behavior of class _ABCSingleton."""

    class MyClass(metaclass=_ABCSingleton):
        """
        Just a dummy class for testing.
        """
        name = 'MyClass'

    obj_1 = MyClass()
    obj_2 = MyClass()
    assert obj_1.name == 'MyClass'  # pylint: disable=no-member
    assert obj_2.name == 'MyClass'  # pylint: disable=no-member
    assert obj_1 is obj_2

# Generated at 2022-06-23 13:57:23.642784
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    context = dict(
        loader=loader,
        variable_manager=variable_manager
    )
    playbook = PlaybookExecutor(
        playbooks=['/home/shayyo/test.yml'],
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader
    )

# Generated at 2022-06-23 13:57:25.688717
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # The below throws "NameError: name 'GlobalCLIArgs' is not defined"
    # args = GlobalCLIArgs()
    pass

# Generated at 2022-06-23 13:57:30.597579
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class MockOptions():
        def __init__(self):
            self.one = 1
            self.two = 2
            self.a = {'b': {'c': 3}}

    foo = CLIArgs.from_options(MockOptions())

    assert foo['one'] == 1
    assert foo['two'] == 2
    assert foo['a']['b']['c'] == 3

# Generated at 2022-06-23 13:57:36.741350
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from collections import OrderedDict
    from ansible.module_utils.common.collections import MutableSequence

    assert type(ImmutableDict([('a', 1)])) == ImmutableDict
    assert type(_make_immutable(ImmutableDict([('a', 1)]))) == ImmutableDict
    assert type(_make_immutable(MutableSequence([(1, 2)]))) == tuple
    assert type(_make_immutable(OrderedDict([('a', 1)]))) == ImmutableDict

    cliargs = CLIArgs.from_options(object())
    assert type(cliargs) == CLIArgs
    assert type(cliargs['a']) == text_type

# Generated at 2022-06-23 13:57:39.272476
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs.from_options(CLIOptions([]))

# Generated at 2022-06-23 13:57:40.242734
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({})
    assert CLIArgs({'foo': 'bar'}) is not None

# Generated at 2022-06-23 13:57:49.802316
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args1 = CLIArgs({'arg1': 'string'})
    assert isinstance(args1['arg1'], text_type)
    assert args1['arg1'] == 'string'

    args2 = CLIArgs({'arg2': [1, 2, 3]})
    assert isinstance(args2['arg2'], Sequence)
    assert args2['arg2'] == (1, 2, 3)

    args3 = CLIArgs({'arg3': {'arg4': 'string', 'arg5': [1, 2, 3]}})
    assert isinstance(args3['arg3'], Mapping)
    assert isinstance(args3['arg3']['arg4'], text_type)
    assert isinstance(args3['arg3']['arg5'], Sequence)

# Generated at 2022-06-23 13:57:56.594258
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'bools': [True, False], 'numbers': [1, 2.0, 3], 'strings': ['hello', 'world']}
    cli_args = CLIArgs(mapping)
    assert cli_args == mapping
    assert cli_args.bools == tuple(mapping['bools'])
    assert cli_args.numbers == tuple(mapping['numbers'])
    assert cli_args.strings == tuple(mapping['strings'])

# Generated at 2022-06-23 13:58:06.994763
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Alpha:
        pass

    class Beta(Alpha):
        pass
    assert isinstance(Alpha, type)
    assert issubclass(Alpha, object)
    assert isinstance(Beta, type)
    assert issubclass(Beta, Alpha)
    assert Beta.__mro__ == (Beta, Alpha, object)

    class Charlie(metaclass=_ABCSingleton):
        pass

    class Delta(Charlie):
        pass

    class Echo(Charlie):
        pass

    assert isinstance(Charlie, type)
    assert issubclass(Charlie, object)
    assert isinstance(Delta, type)
    assert issubclass(Delta, Charlie)
    assert Delta.__mro__ == (Delta, object)
    assert isinstance(Echo, type)
    assert issubclass(Echo, Charlie)
    assert Echo.__

# Generated at 2022-06-23 13:58:18.066746
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class Buggy(Singleton, ABCMeta):
        pass

    class A(Buggy):
        pass

    class B(A):
        pass

    class C(A):
        pass

    def test_instance_method(a):
        return a

    A.test_instance_method = test_instance_method
    B.test_instance_method = test_instance_method
    C.test_instance_method = test_instance_method

    assert A().test_instance_method == B().test_instance_method == C().test_instance_method

    assert A.test_instance_method == B.test_instance_method == C.test_instance_method

    class D(A):
        def test_instance_method(d):
            return d

    assert A().test_instance_method == B().test_instance_method == C

# Generated at 2022-06-23 13:58:30.295238
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils.common._collections_compat import MutableSequence

    class Foo(object):
        pass
    class Bar(Foo, metaclass=_ABCSingleton):
        pass
    class Baz(MutableSequence):
        pass
    class Bat(Baz, metaclass=_ABCSingleton):
        pass

    f1 = Foo()
    f2 = Foo()
    b1 = Bar()
    b2 = Bar()
    z1 = Baz()
    z2 = Baz()
    t1 = Bat()
    t2 = Bat()

    assert id(f1) != id(f2)
    assert id(b1) == id(b2)
    assert id(z1) != id(z2)
    assert id(t1) == id(t2)

# Generated at 2022-06-23 13:58:32.110646
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    A simple unit test to verify that a Singleton based on _ABCSingleton can be created.
    """
    class MySingleton(metaclass=_ABCSingleton):
        pass
    assert MySingleton() is MySingleton()

# Generated at 2022-06-23 13:58:33.755698
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):  # pylint: disable=unused-variable
        pass
    assert Test() is Test()

# Generated at 2022-06-23 13:58:43.643329
# Unit test for constructor of class CLIArgs
def test_CLIArgs():  # pylint: disable=unused-variable
    """
    Make sure the constructor allows text or bytes and converts it to the expected type.

    This unit test doesn't actually use test_options.py fixtures as that would be overkill for
    demonstrating most of what we care about unit testing here.  We just want to make sure that
    the CLIArgs constructor turns everything into immutable types.
    """
    test_string = 'something'
    test_bytes = b'bytes'
    test_int = 7
    test_dict = {'key1': 'value1', 'key2': 'value2'}
    test_dict['key3'] = {'key4': 'value4'}
    test_dict['key5'] = test_dict['key3']

# Generated at 2022-06-23 13:58:54.173388
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    arg = GlobalCLIArgs({})
    try:
        arg['_ansible_version'] = '2.8.1'
        raise Exception('Should not have been able to mutate a CLIArgs object!')
    except TypeError:
        pass
    ret = arg['_ansible_version']
    try:
        arg['_ansible_version'] = '2.8.1'
        raise Exception('Should not have been able to mutate a CLIArgs object!')
    except TypeError:
        pass
    try:
        ret['_ansible_version'] = '2.8.1'
        raise Exception('Should not have been able to mutate a CLIArgs object!')
    except TypeError:
        pass

# Generated at 2022-06-23 13:59:01.834869
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    d1 = GlobalCLIArgs({'foo': {'bar': {'baz': 'buz'}}})

    assert d1 == {'foo': {'bar': {'baz': 'buz'}}}, "GlobalCLIArgs is not immutable."

    d1['foo']['bar']['baz'] = 'new_buz'

    assert d1 == {'foo': {'bar': {'baz': 'buz'}}}, "GlobalCLIArgs is not immutable."

# Generated at 2022-06-23 13:59:07.814244
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import os

    class Options(object):
        pass
    options = Options()
    options.jid = os.getpid()
    options.remote_user = 'matthew'
    options.sudo = True
    options.become = True
    args = GlobalCLIArgs.from_options(options)
    assert args['jid'] == os.getpid()
    assert args['remote_user'] == 'matthew'
    assert args['sudo']
    assert args['become']

# Generated at 2022-06-23 13:59:10.340742
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    c = CLIArgs({"a": 1})
    assert c == {"a": 1}

    d = CLIArgs.from_options(GlobalCLIArgs())
    assert d == GlobalCLIArgs()



# Generated at 2022-06-23 13:59:12.033262
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs.from_options(None)
    assert isinstance(args, GlobalCLIArgs)

# Generated at 2022-06-23 13:59:20.876543
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import types
    import unittest

    class GlobalCLIArgsTest(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            cls.args = GlobalCLIArgs({'one': 'un', 'two': 'deux', 'three': 'trois'})
            cls.orig_sys_modules = sys.modules.copy()

        @classmethod
        def tearDownClass(cls):
            # Remove our test addition to sys.modules to return it to the previous state
            sys.modules = cls.orig_sys_modules


# Generated at 2022-06-23 13:59:24.638844
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test1(object):
        __metaclass__ = _ABCSingleton

    class Test2(object):
        __metaclass__ = _ABCSingleton

    class Test3(object):
        __metaclass__ = _ABCSingleton

    assert id(Test1()) == id(Test2()) == id(Test3())

# Generated at 2022-06-23 13:59:27.908282
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(metaclass=_ABCSingleton):
        pass

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-23 13:59:30.026354
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _SingletonSubclass(metaclass=_ABCSingleton):
        pass
    obj = _SingletonSubclass()
    obj2 = _SingletonSubclass()
    assert obj is obj2
    assert isinstance(obj, _SingletonSubclass)

# Generated at 2022-06-23 13:59:33.462754
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_args = GlobalCLIArgs.instance()
    assert global_args is GlobalCLIArgs.instance()

# Generated at 2022-06-23 13:59:35.050404
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        pass

    assert Test is Test()

# Generated at 2022-06-23 13:59:41.441034
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    # Check conversion of a list
    a = CLIArgs(dict(a=['b', 'c']))
    assert isinstance(a['a'], tuple)

    # Check conversion of a dict
    a = CLIArgs(dict(a=dict(b='c')))
    assert isinstance(a['a'], ImmutableDict)

    # Check conversion of a set
    a = CLIArgs(dict(a=set(['b', 'c'])))
    assert isinstance(a['a'], frozenset)

# Generated at 2022-06-23 13:59:51.654586
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import pytest
    from ansible.module_utils.common.collections import is_immutable
    from collections import namedtuple

    test_data = namedtuple('test_data', 'cls_args cls_kwargs cls_expected_type cls_expected_value')


# Generated at 2022-06-23 14:00:00.155431
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'test_dict': {'test_list': ['a', 'b', 'c'], 'test_set': {'a', 'b'}, 'test_text': 'this_is_a_test'}, 'test_text': 'test'}
    cli_args = CLIArgs(test_dict)
    assert isinstance(cli_args, ImmutableDict)
    for nested_key in test_dict['test_dict']:
        assert isinstance(cli_args['test_dict'][nested_key], Mapping)
    assert isinstance(cli_args['test_text'], text_type)

# Generated at 2022-06-23 14:00:01.679153
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert GlobalCLIArgs() is GlobalCLIArgs()

# Generated at 2022-06-23 14:00:09.421598
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    obj = type('obj', (object,), {'one': 1,
                                  'two': 2,
                                  'three': [1, 2, 3],
                                  'four': {'five': 5},
                                  'six': 6,
                                  'seven': 7})
    gca = GlobalCLIArgs(obj.__dict__)
    assert gca == ImmutableDict(obj.__dict__)
    assert isinstance(gca, GlobalCLIArgs)

# Generated at 2022-06-23 14:00:18.817141
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        host_key_auto_add = 'host_key_auto_add'
        def __init__(self, host_key_auto_add=None):
            self.host_key_auto_add = host_key_auto_add
    options = Options()
    options_dict = vars(options)
    cli_args = CLIArgs(options_dict)
    assert cli_args['host_key_auto_add'] == 'host_key_auto_add'
    cli_args['host_key_auto_add'] = 'Changed value'

# Generated at 2022-06-23 14:00:21.672365
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    gca = GlobalCLIArgs(dict(my_key='my_value'))
    assert gca['my_key'] == 'my_value'

# Generated at 2022-06-23 14:00:27.119279
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {"one": [1, 2, 3],
                 "two": {"four": 4, "five": 5, "six": [1, 2, 3]}}
    test_immutable_dict = CLIArgs(test_dict)

    assert isinstance(test_immutable_dict.get("one"), tuple)
    assert isinstance(test_immutable_dict.get("two"), ImmutableDict)
    assert isinstance(test_immutable_dict.get("two").get("four"), int)
    assert isinstance(test_immutable_dict.get("two").get("five"), int)
    assert isinstance(test_immutable_dict.get("two").get("six"), tuple)

# Generated at 2022-06-23 14:00:30.359232
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Base1(object):
        __metaclass__ = _ABCSingleton
    try:
        class Base2(Base1):
            pass
    except TypeError as e:
        if 'metaclass conflict' not in str(e):
            raise

    class Base2(object):
        __metaclass__ = _ABCSingleton
    class Base1(Base2):
        pass

# Generated at 2022-06-23 14:00:42.697200
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test CLIArgs constructor
    """

    # Make sure we can accept empty list
    cli_args = CLIArgs({})
    assert not cli_args

    # Make sure we can accept empty tuple
    cli_args = CLIArgs({})
    assert not cli_args

    # Make sure we can accept setting this with a dictionary
    cli_args = CLIArgs({"foo": "bar"})
    assert cli_args["foo"] == "bar"

    # Make sure we make all the arguments in the dictionary immutable
    cli_args = CLIArgs({"foo": "bar", "boo": "baz"})
    assert cli_args["foo"] == "bar"
    assert cli_args["boo"] == "baz"

    # Make sure we can handle nested dictionaries
    cli_args

# Generated at 2022-06-23 14:00:51.031577
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    class SubFoo(Foo):
        pass

    test_a = Foo()
    test_b = Foo()
    test_c = SubFoo()

    assert test_a is test_b is test_c

    class Bar(object):
        __metaclass__ = _ABCSingleton

    test_d = Bar()
    test_e = Foo()
    test_f = SubFoo()

    assert test_d is not test_e is not test_f

# Generated at 2022-06-23 14:00:54.124438
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-23 14:00:56.541417
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = GlobalCLIArgs({'a':1})
    b = GlobalCLIArgs({'b':{'c':'c'}})
    assert a == {'a':1}
    assert b == {'b':{'c':'c'}}

# Generated at 2022-06-23 14:01:01.470889
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'arg1': 'value1', 'arg2': 'value2'})
    assert args['arg1'] == 'value1'
    assert args['arg2'] == 'value2'
    # Check to make sure we are immutable
    try:
        args['arg1'] = 'test'
        return False
    except TypeError:
        pass
    return True


# Generated at 2022-06-23 14:01:05.530183
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = dict(foo=1, bar=2, baz=dict(a=2, b=3, c=4))
    cli_args = CLIArgs(test_dict)

    assert cli_args == test_dict
    assert isinstance(cli_args['baz'], ImmutableDict)

# Generated at 2022-06-23 14:01:09.204879
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Arrange
    args = {'one': 1, 'two': 2}

    # Act
    cl = GlobalCLIArgs(args)

    # Assert
    assert cl['one'] == 1
    assert cl['two'] == 2



# Generated at 2022-06-23 14:01:21.373575
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # pylint: disable=unused-variable

    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('-a', '--arg-a', default=None, type=str)
    parser.add_argument('-b', '--arg-b', nargs='*', type=int)
    parser.add_argument('-c', '--arg-c', nargs='+', type=str)
    parser.add_argument('-d', '--arg-d', choices=('a', 'b'), nargs='?', type=str)
    parser.add_argument('-e', '--arg-e', choices=('a', 'b'), nargs='*', type=str)

# Generated at 2022-06-23 14:01:23.503316
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingletonTest(metaclass=_ABCSingleton):
        pass

    class SingletonTestChild(SingletonTest):
        pass

# Generated at 2022-06-23 14:01:31.681721
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import unittest
    import ansible.utils.unsafe_proxy

    class test_GlobalCLIArgs(unittest.TestCase):
        def test_init(self):
            global_args = GlobalCLIArgs()
            # test GlobalCLIArgs()
            self.assertEqual(global_args, GlobalCLIArgs())
            # test GlobalCLIArgs.__init__(self, args_dict)
            GlobalCLIArgs({"verbosity": 0, "ask_vault_pass": False, "ask_pass": False})
            # test GlobalCLIArgs.from_options(options)
            options = ansible.utils.unsafe_proxy.UnsafeProxy({'verbosity': 0, 'ask_vault_pass': False, 'ask_pass': False})
            GlobalCLIArgs.from_options(options)



# Generated at 2022-06-23 14:01:35.772626
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Test GlobalCLIArgs constructor"""
    # First call is to create the object
    GlobalCLIArgs( dict() )
    # Second call is to verify that this is a Singleton
    assert GlobalCLIArgs( dict() ) is GlobalCLIArgs.get()


# Generated at 2022-06-23 14:01:42.937926
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs({'a': 'a', 'b': {'ba': 'ba', 'bb': 'bb'}})
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args['a'] == 'a'
    assert cli_args['b']['ba'] == 'ba'
    assert cli_args['b']['bb'] == 'bb'

    cli_args['b'] = 'b'
    assert cli_args['b'] == 'b'
    assert cli_args['b']['ba'] == 'ba'
    assert cli_args['b']['bb'] == 'bb'

    cli_args['b']['bc'] = 'bc'
    assert cli_args['b'] == 'b'
    assert cli_args

# Generated at 2022-06-23 14:01:51.579708
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert isinstance(CLIArgs({'a': 1}), ImmutableDict)
    assert isinstance(CLIArgs({'a': [1, 2]}), ImmutableDict)
    assert isinstance(CLIArgs({'a': {'b': 1}}), ImmutableDict)
    assert isinstance(CLIArgs({'a': [{'b': 1}]}), ImmutableDict)
    assert GlobalCLIArgs.from_options(None) is GlobalCLIArgs.from_options(None)
    assert CLIArgs.from_options(None) is not GlobalCLIArgs.from_options(None)

# Generated at 2022-06-23 14:01:54.988411
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # pylint: disable=dangerous-default-value
    GlobalCLIArgs.create(mapping={'foo': 'bar'})



# Generated at 2022-06-23 14:01:57.626974
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object):
        pass

    assert id(Test) == id(_ABCSingleton('Test', (Test, ), {}))

# Generated at 2022-06-23 14:02:04.647492
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    # Fixture test data that is meant to represent a copy of parsed CLI arguments.
    # TODO: Make this more like a real copy of parsed CLI arguments.
    ARGS = {
        'listhosts': True,
        'listtasks': True,
        'listtags': True,
        'host_list': True,
        'verbosity': 3,
    }

    GlobalCLIArgs(ARGS)
    GlobalCLIArgs(ARGS)

    try:
        GlobalCLIArgs({})
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-23 14:02:06.281424
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton(_ABCSingleton):
        pass

    assert TestSingleton is TestSingleton()

# Generated at 2022-06-23 14:02:07.182947
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({})

# Generated at 2022-06-23 14:02:08.631535
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_args = GlobalCLIArgs()
    assert isinstance(global_args, ImmutableDict)

# Generated at 2022-06-23 14:02:11.463734
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    c = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'qux': 'quux'})
    assert type(c) == ImmutableDict
    assert c['foo'] == 'bar'
    assert type(c['baz']) == tuple
    assert c['baz'] == (1, 2, 3)
    assert c['qux'] == 'quux'



# Generated at 2022-06-23 14:02:20.556844
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # test a mapping can be passed
    from ansible.module_utils.common.collections import ImmutableDict
    test_dict = ImmutableDict({"test_var": 1})
    cli_args = CLIArgs(test_dict)
    assert cli_args == test_dict
    assert cli_args is not test_dict
    assert isinstance(cli_args, ImmutableDict)

    # test a tuple can be passed
    test_tuple = ("one", "two", "three")
    cli_args = CLIArgs(test_tuple)
    assert cli_args == test_tuple
    assert cli_args is not test_tuple
    assert isinstance(cli_args, tuple)

# Generated at 2022-06-23 14:02:22.518276
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    opt = GlobalCLIArgs({'foo': True})
    assert opt['foo'] == True
    opt['foo'] = False

# Generated at 2022-06-23 14:02:32.662763
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    cli_args = GlobalCLIArgs({'a': 'a', 'b': {'c': 'c'}})
    # Test that the class constructor of GlobalCLIArgs behaves as expected
    assert isinstance(cli_args, GlobalCLIArgs)
    assert isinstance(cli_args, CLIArgs)
    # Test that it contains the keys we expect
    assert cli_args.keys() == set(['a', 'b'])
    # Test that they keys have the correct values
    assert cli_args['a'] == 'a'
    assert cli_args['b'].keys() == set(['c'])
    assert cli_args['b']['c'] == 'c'

# Generated at 2022-06-23 14:02:44.113650
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-23 14:02:50.103080
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import ansible.options
    from ansible.module_utils.common.collections import ImmutableDict

    my_arg_options = ansible.options.Options().parse()[0]

    global_cli_args = GlobalCLIArgs.from_options(my_arg_options)
    assert isinstance(global_cli_args, ImmutableDict)

# Generated at 2022-06-23 14:02:52.882517
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton
    first_instance = Foo()
    second_instance = Foo()
    assert first_instance is second_instance

# Generated at 2022-06-23 14:03:03.390799
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = ImmutableDict({'verbose': True, 'foo': {'bar': {'baz': 'baf'}}})
    args = GlobalCLIArgs(args)
    assert isinstance(args, GlobalCLIArgs)
    assert isinstance(args._data, ImmutableDict)
    assert isinstance(args._data['foo'], ImmutableDict)
    assert isinstance(args._data['foo']['bar'], ImmutableDict)
    assert isinstance(args._data['foo']['bar']['baz'], text_type)
    assert args._data['foo']['bar']['baz'] == 'baf'
    assert args._data['verbose'] is True
    assert args['verbose'] is True

# Generated at 2022-06-23 14:03:07.040081
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Instantiation of `GlobalCLIArgs` should fail because Singleton class.
    try:
        GlobalCLIArgs()
    except TypeError as e:
        pass
    # Instantiation of `CLIArgs` instead should succeed.
    x = CLIArgs({'test': 'this'})

# Generated at 2022-06-23 14:03:14.973476
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel

    # This is the metadata ansible uses for storing command line option data
    options = Sentinel(foo=1, bar=['one', 'two', 'three'])

    # This is the metadata utility we need to wire up an argument parser to
    # GlobalCLIArgs
    d = Display()

    # GlobalCLIArgs should be able to take MetaData and convert it into a singleton
    # global variable holding the metadata
    GlobalCLIArgs.from_options(options)

    # GlobalCLIArgs should return the global metadata no matter what
    assert GlobalCLIArgs() == options

    # After setting the metadata in the GlobalCLIArgs singleton, it should be possible
    # to wire up the data to an argument parser
    parser = d.verbose_arg

# Generated at 2022-06-23 14:03:21.366232
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class FakeOption:
        def __init__(self, d):
            vars(self).update(d)

    options = FakeOption({'foo': 1, 'bar': 2, 'meh': set([1])})
    args = GlobalCLIArgs.from_options(options)
    assert args == {'foo': 1, 'bar': 2, 'meh': frozenset([1])}

# Generated at 2022-06-23 14:03:29.705526
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class _Test(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b

    test_case = {'a': 1, 'b': 'two', 'c': {'d': [1, 2, 3], 'e': {'f': ['apple', 'banana'], 'g': {'h': _Test(1, 2)}}}}
    cli_args = CLIArgs(test_case)
    for k, v in test_case.items():
        assert v == cli_args[k]

# Generated at 2022-06-23 14:03:32.091024
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton(_ABCSingleton):
        pass

    class TestABC(TestSingleton, metaclass=ABCMeta):
        pass

    assert isinstance(TestABC(), TestSingleton)

# Generated at 2022-06-23 14:03:38.192507
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({"str": "string"})
    assert args.keys() == ["str"]
    assert not args.keys() == ["keys"]
    assert args.values() == ["string"]
    assert not args.values() == ["values"]
    assert args["str"] == "string"
    assert not args["str"] == "s"
    assert isinstance(args, ImmutableDict)

# Generated at 2022-06-23 14:03:43.605173
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import os
    import sys

    class FakeOptions(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    fake_options = FakeOptions(
        ansible_module_name='ansible',
        ansible_module_suboption='suboption',
        ansible_module_complex_suboption=[1, 2, 3],
        ansible_module_complex_suboption_with_future=False,
        ansible_module_complex_suboption_with_future__version=(2, 6, 0),
    )
    cli_args = CLIArgs.from_options(fake_options)

    # Test various methods of ImmutableDict
    assert cli_args.get('missing_option') is None

# Generated at 2022-06-23 14:03:54.121034
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test one
    d = {'a': 'A', 'b': 'B', 'c': {'d': 'D', 'e': 'E', 'f': {'g': 'G'}}, 'h': [1, 2, {'i': 'I'}], 'j': set([1, 2, 3])}
    cli_args = CLIArgs(d)
    for key, value in d.items():
        assert key in cli_args
        assert cli_args[key] == value
    assert cli_args == d
    assert cli_args.a == 'A'
    assert cli_args.b == 'B'
    assert cli_args.c == d['c']
    assert cli_args.h == d['h']
    assert cli_args.j == d['j']

# Generated at 2022-06-23 14:04:02.445988
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.args import AnsibleOptions
    options = AnsibleOptions()

    options.verbosity = 1
    options.connection = 'foobar'
    options.module_path = '/dev/foo/bar'
    options.listhosts = False
    options.subset = 'test'
    options.module_name = 'foo_bar'

    args = GlobalCLIArgs.from_options(options)

    # Make sure the returned is a singleton class
    assert GlobalCLIArgs is args.__class__