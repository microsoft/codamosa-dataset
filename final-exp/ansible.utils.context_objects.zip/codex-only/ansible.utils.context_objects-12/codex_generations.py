

# Generated at 2022-06-23 13:54:11.205195
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli import CLI
    from ansible_galaxy import __version__ as galaxy_version

    cli = CLI(args=['galaxy', 'install', 'geerlingguy.java'])
    opt = cli.parser.parse_args()


# Generated at 2022-06-23 13:54:13.705168
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    foo1 = Foo()
    foo2 = Foo()
    assert foo1 is foo2

# Generated at 2022-06-23 13:54:23.701932
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    # options is a Namespace object
    options = pytest.importorskip('ansible.module_utils.common.options').Options(connection='local', forks=10, become=True, become_method=None, become_user='root', check=False, diff=False, inventory='/etc/ansible/hosts', module_path='/usr/local/share/ansible/modules', step=False, verbosity=0, syntax=False, start_at_task=None, vault_password_file=None, inventory_plugins=[])
    g1 = GlobalCLIArgs.from_options(options)
    g2 = GlobalCLIArgs.from_options(options)
    # options is a Namespace object

# Generated at 2022-06-23 13:54:34.238680
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Args:
        pass
    args = Args()
    args.foo = 'foo'
    args.bar = ['bar', 'baz']
    args.baz = {'a': 'b', 'c': 'd'}
    args.boo = set([1, 2, 3])
    args = vars(args)
    from ansible.module_utils.common.collections import ImmutableDict

    gc = GlobalCLIArgs.from_options(args)
    assert isinstance(gc, GlobalCLIArgs)
    assert isinstance(gc, (ImmutableDict))
    assert isinstance(gc, CLIArgs)

# Generated at 2022-06-23 13:54:39.855762
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class C(object):
        __metaclass__ = _ABCSingleton
    class D(C):
        pass
    c1 = C()
    c2 = C()
    assert c1 is c2
    d = D()
    assert c1 is d

# Generated at 2022-06-23 13:54:48.309390
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # make sure that the constructor does not mutate or de-atomize the passed in mapping
    mapping = {'foo': {'bar': []}}
    cargs = CLIArgs(mapping)
    assert cargs == mapping
    assert cargs is not mapping
    assert isinstance(cargs, Mapping)
    assert not isinstance(cargs, MutableMapping)
    assert cargs['foo'] == mapping['foo']
    assert cargs['foo'] is not mapping['foo']
    assert isinstance(cargs['foo'], Mapping)
    assert not isinstance(cargs['foo'], MutableMapping)
    assert cargs['foo']['bar'] == mapping['foo']['bar']
    assert cargs['foo']['bar'] is not mapping['foo']['bar']

# Generated at 2022-06-23 13:54:52.348035
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
    t1 = TestClass()
    t2 = TestClass()
    assert t1 is t2

# Generated at 2022-06-23 13:54:59.602336
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    mutable_dictionary = {'key': 'value'}

    # test that the constructor works properly (must use 'not' since constructor raises TypeError on failure)
    try:
        GlobalCLIArgs(mutable_dictionary)
    except TypeError:
        assert False

    # test that the singleton instance works properly (must use 'not' since constructor raises TypeError on failure)
    try:
        GlobalCLIArgs.singleton(mutable_dictionary)
    except TypeError:
        assert False

# Generated at 2022-06-23 13:55:05.122577
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = dict(
        ansible_ssh_user="kiwi",
        ansible_connection="local",
        ansible_python_interpreter="/usr/bin/python3",
        check=True,
        diff=False,
        extra_vars=['foo=bar', 'bam=baz'],
    )

    cli_args = GlobalCLIArgs(args)

    assert isinstance(cli_args, CLIArgs)

# Generated at 2022-06-23 13:55:09.950202
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # noinspection PyUnusedLocal
    class X(metaclass=_ABCSingleton):
        pass

    # noinspection PyUnusedLocal
    class Y(metaclass=_ABCSingleton):
        pass



# Generated at 2022-06-23 13:55:16.496978
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict

    class MyGlobalCLIArgs(GlobalCLIArgs):
        def __init__(self, mapping):
            self.__dict__ = mapping
    # Confirm new cls is a singleton
    assert MyGlobalCLIArgs is MyGlobalCLIArgs()
    # Confirm constructor is functional
    assert MyGlobalCLIArgs({"a": 1})

# Generated at 2022-06-23 13:55:22.699216
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'key1': text_type('key1value'), 'key2':
               {'key1': text_type('key1value'), 'key2': text_type('key2value')},
               'key3': (text_type('key1value'), text_type('key2value'))}
    cliargs = CLIArgs(mapping)

    assert isinstance(cliargs['key1'], text_type)
    assert isinstance(cliargs['key2'], ImmutableDict)
    assert isinstance(cliargs['key3'], tuple)

# Generated at 2022-06-23 13:55:26.603564
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    # TypeError: Can't instantiate abstract class A with abstract methods __class__
    with A.abstract_class_implementation_error():
        A()

# Generated at 2022-06-23 13:55:32.929118
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_mapping = {'username': 'user', 'password': 'pass'}
    test_object = CLIArgs(test_mapping)

    assert isinstance(test_object, ImmutableDict)
    assert isinstance(test_object, Mapping)
    assert test_object == ImmutableDict(test_mapping)
    assert test_object.get('username') == 'user'
    assert test_object.get('password') == 'pass'

# Generated at 2022-06-23 13:55:41.751019
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs.clear_instance()
    assert GlobalCLIArgs.instance() is None
    import sys
    import optparse
    parser = optparse.OptionParser()
    parser.add_option('--foo', type='int')
    parser.add_option('--bar', type='str')
    args = ['-f', '777', '--bar=baz']
    (options, args) = parser.parse_args(args)
    GlobalCLIArgs.from_options(options)
    assert GlobalCLIArgs.instance() is not None
    assert isinstance(GlobalCLIArgs.instance(), GlobalCLIArgs)
    assert GlobalCLIArgs.from_options(options) is GlobalCLIArgs.instance()
    assert GlobalCLIArgs.instance()['foo'] == 777
    assert GlobalCLIArgs.instance()['bar']

# Generated at 2022-06-23 13:55:45.500862
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_args = GlobalCLIArgs({'foo': 'bar'})
    assert global_args['foo'] == 'bar'
    assert isinstance(global_args, ImmutableDict) is True

# Generated at 2022-06-23 13:55:49.412512
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = set(['-a', '-s', '-q'])
    mapping = {}
    for arg in args:
        mapping[arg] = None
    options = CLIArgs.from_options(type('', (), mapping))
    for arg in args:
        assert arg in options


# Generated at 2022-06-23 13:55:55.775336
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test1(object):
        __metaclass__ = _ABCSingleton
        pass

    class Test2(object):
        __metaclass__ = _ABCSingleton
        pass

    # Test1 is a Singleton already, so we just need to make sure that it is still a Singleton
    # and also is a sub class of ABCMeta
    assert issubclass(Test1, _ABCSingleton)
    assert issubclass(Test1, Singleton)
    assert issubclass(Test1, ABCMeta)

    # This should not be a Singleton class
    assert not issubclass(Test2, Singleton)

# Generated at 2022-06-23 13:55:57.297991
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """ Create a GlobalCLIArgs object before the command line is parsed """
    GlobalCLIArgs()


# Generated at 2022-06-23 13:55:59.875893
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs.set(CLIArgs({"a": 1, "b": 2}))
    assert (GlobalCLIArgs() == {"a": 1, "b": 2})

# Generated at 2022-06-23 13:56:05.868790
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    import sys
    import ansible.constants
    import ansible.module_utils.common.collections

    # a = _GlobalCLIArgs(['a=b', 'c'])
    # assert a == {'a': 'b', 'c': None}

    a = ansible.module_utils.common.collections._GlobalCLIArgs(ansible.constants.DEFAULT_MODULE_PATH)
    assert isinstance(a, dict)

# Generated at 2022-06-23 13:56:08.787937
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.module_utils.common.collections import GlobalCLIArgs

    with pytest.raises(TypeError):
        args = GlobalCLIArgs({'foo': 'bar'})

# Generated at 2022-06-23 13:56:19.105745
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'foo': 'bar',
                    'baz': {'answer': 42,
                            'question': 'which one was the most fun?',
                            'who': [{'name': 'Amy', 'favorite color': 'blue'},
                                    {'name': 'Belle', 'favorite color': 'pink'},
                                    {'name': 'Clara', 'favorite color': 'red'}],
                            'second who': [{'name': 'Alice'},
                                           {'name': 'Beatrice'}]},
                    'boolean': True})

    # test for object membership
    assert 'foo' in args
    assert 'baz' in args

    # test for dictionary membership
    assert 'baz' in args['baz']
    assert 'who' in args['baz']

# Generated at 2022-06-23 13:56:21.526589
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(metaclass=_ABCSingleton):
        pass

    assert A() is A() and B() is B() and A() is not B()

# Generated at 2022-06-23 13:56:33.374215
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {
        'foo': 'this',
        'bar': 'something',
        'baz': {
            'bat': 'matt',
            'tab': 'something else',
            'taz': {
                'rab': 'something even more',
                'rat': 'fuzzy',
                'raw': ['a', 'b', 'c'],
                'ray': ('d', 'e', 'f')
            },
            'tar': ('a', 'b', 'c', {'d': 'D', 'e': 'E', 'f': 'F'})
        },
        'tiz': ('a', 'b', 'c', {'d': 'D', 'e': 'E', 'f': 'F'})
    }
    immutable_args = CLIArgs.from_options(args)

# Generated at 2022-06-23 13:56:43.735239
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    from ansible.module_utils.common.netcommon import ConnectionParameters

    cliargs = CLIArgs.from_options({
        'foo': 123,
        'bar': 456,
        'connection_params': ConnectionParameters(remote_addr='192.0.2.1'),
        'host_list': ['server1', 'server2'],
    })

    assert cliargs == {
        'foo': 123,
        'bar': 456,
        'connection_params': ConnectionParameters(remote_addr='192.0.2.1'),
        'host_list': ['server1', 'server2'],
    }

    assert cliargs['foo'] == 123
    assert cliargs['bar'] == 456
    assert cliargs['connection_params'] == ConnectionParameters(remote_addr='192.0.2.1')

# Generated at 2022-06-23 13:56:52.325381
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    #
    # Check that the init of the object correctly makes the dictionary immutable,
    # and correctly handles sets and sequences
    #

    # Verify that values that are not sequences or sets are left as they were
    original_args = {
        "arg1": "original_value",
        "arg2": "other_value"
    }
    args = CLIArgs(original_args)

    assert args is not original_args
    assert args == original_args
    assert args["arg1"] == original_args["arg1"]
    assert args["arg2"] == original_args["arg2"]
    assert type(args) == dict

    # Verify that sets are made into immutable sets and sets inside of sets are made immutable as well

# Generated at 2022-06-23 13:56:54.863627
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MySingletonClass(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(MySingletonClass(), MySingletonClass)

# Generated at 2022-06-23 13:57:02.583891
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.playbook.play_context import PlayContext

    more_args = {'ask_pass': True, 'module_path': '/path/to/modules'}
    args = dict(more_args)
    args.update({'connection': 'local', 'forks': 10, 'check': True})
    options = PlayContext()
    for key, value in args.items():
        setattr(options, key, value)
    cli_args = CLIArgs.from_options(options)
    assert isinstance(cli_args, ImmutableDict)
    # dictionaries in python 3.6 are ordered
    assert cli_args == more_args



# Generated at 2022-06-23 13:57:11.391830
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {
        'a': {
            'b': [
                'c',
                'd',
            ]
        },
        'e': set([
            'f',
            'g',
            {
                'h': 'i',
                'j': 'k',
            }
        ])
    }
    cli_args = CLIArgs(mapping)
    assert cli_args['a']['b'][1] == 'd'
    assert cli_args['e'].pop() == frozenset(['h', 'i', 'j', 'k'])



# Generated at 2022-06-23 13:57:16.869599
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = dict(a='apple', b='banana', c='cantaloupe')
    args = CLIArgs(mapping)

    assert 'a' in args
    assert 'apple' == args['a']

    assert 'b' in args
    assert 'banana' == args['b']

    assert 'c' in args
    assert 'cantaloupe' == args['c']

    assert len(args) == 3
    #assert args['d'] == []

# Generated at 2022-06-23 13:57:22.698476
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli import CLI
    from ansible.utils.display import Display
    display = Display()
    cli = CLI(args=[], display=display)
    parser = cli.base_parser()

    args = ['--connection', 'test_connection']
    options = parser.parse_args(args)

    # noinspection PyUnresolvedReferences
    global_args = GlobalCLIArgs.from_options(options)
    assert global_args['connection'] == 'test_connection'

# Generated at 2022-06-23 13:57:27.049832
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test1(object):
        __metaclass__ = _ABCSingleton

    class Test2(object):
        __metaclass__ = _ABCSingleton

    class Test3(Test1, Test2):
        pass

    class Test4(Test2, Test1):
        pass

    assert Test3 is Test4

# Generated at 2022-06-23 13:57:34.991740
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs.clear_instance()
    data = dict(one=dict(a=1, b=2), two='b', three=('one', 'two', 'three'))
    test_instance = GlobalCLIArgs(data)
    assert isinstance(test_instance, GlobalCLIArgs)
    assert isinstance(test_instance, dict)
    assert test_instance['one']['a'] == 1
    assert test_instance['one']['b'] == 2
    assert test_instance['two'] == 'b'
    assert test_instance['three'] == ('one', 'two', 'three')
    assert test_instance is GlobalCLIArgs()

# Generated at 2022-06-23 13:57:46.188073
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Set up a test object
    toplevel = {}
    toplevel['aaa'] = 'bbb'
    toplevel['ccc'] = {'ddd': 'eee'}
    toplevel['fff'] = ['ggg', 'hhh']
    toplevel['iii'] = frozenset(['jjj', 'kkk', 'lll'])

    # Construct the test object
    args = CLIArgs(toplevel)

    # Verify that the test object has been constructed correctly
    assert args['aaa'] == 'bbb'
    assert args['ccc']['ddd'] == 'eee'
    assert args['fff'] == ('ggg', 'hhh')
    assert args['iii'] == frozenset(['jjj', 'kkk', 'lll'])

# Generated at 2022-06-23 13:57:51.783361
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils.singleton import Singleton

    assert issubclass(GlobalCLIArgs, Container)
    assert issubclass(GlobalCLIArgs, Mapping)
    assert issubclass(GlobalCLIArgs, Singleton)

    assert isinstance(GlobalCLIArgs(), Mapping)
    assert isinstance(GlobalCLIArgs(), ImmutableDict)
    assert isinstance(GlobalCLIArgs(), GlobalCLIArgs)

# Generated at 2022-06-23 13:57:54.667681
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    obj1 = CLIArgs(vars(parse_args()))
    obj2 = CLIArgs(vars(parse_args()))
    assert obj1 == obj2

# Generated at 2022-06-23 13:58:05.449347
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-23 13:58:06.667860
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 13:58:09.747786
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(metaclass=_ABCSingleton):
        pass

    t1 = TestClass()
    t2 = TestClass()
    assert t1 is t2


# Generated at 2022-06-23 13:58:17.646933
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = ['--foo', 'bar']
    global_cli_args = GlobalCLIArgs.from_options(args)
    assert '--foo' in global_cli_args

    args = ['--foo', 'bar', '--moo', 'mar', '--moo', 'mer']
    global_cli_args = GlobalCLIArgs.from_options(args)
    assert '--foo' in global_cli_args
    assert '--moo' in global_cli_args
    assert global_cli_args['--moo'] == ['mar', 'mer']

# Generated at 2022-06-23 13:58:29.772499
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dictionary = {'key1': [1, 2, 3],
                  'key2': ['a', 'b', 'c'],
                  'key3': {'k1': 1, 'k2': 2, 'k3': 3}}

    mapping = CLIArgs(dictionary)
    assert isinstance(mapping, Mapping)
    assert not isinstance(mapping, Sequence)
    assert not isinstance(mapping, Set)
    assert mapping == dictionary

    # Make sure all the values in the returned mapping are immutable
    for key, value in mapping.items():
        if isinstance(value, Mapping):
            assert isinstance(value, ImmutableDict)
        elif isinstance(value, Sequence):
            assert isinstance(value, tuple)

# Generated at 2022-06-23 13:58:31.326866
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({}) == ImmutableDict({})

# Generated at 2022-06-23 13:58:33.749998
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton
    f1 = Foo()
    f2 = Foo()
    assert f1 is f2

# Generated at 2022-06-23 13:58:35.303167
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert 'ansible-test' in CLIArgs({'ansible-test': 'success'})

# Generated at 2022-06-23 13:58:36.650615
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert GlobalCLIArgs.instance() == GlobalCLIArgs.instance()

# Generated at 2022-06-23 13:58:46.065855
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import copy
    import sys
    import textwrap
    import unittest
    import tempfile

    from ansible.errors import AnsibleFileNotFound
    from ansible.galaxy import Galaxy
    from ansible.galaxy.token import GalaxyToken
    from ansible.galaxy.token_cache import TokenCache
    from ansible.module_utils._text import to_bytes

    # Create a temporary file to use as our fake galaxy yaml file.
    # We really have to have a file or TokenCache will choke on it.
    fake_yaml_file = tempfile.NamedTemporaryFile()

# Generated at 2022-06-23 13:58:56.397366
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.basic import _get_options
    from ansible.module_utils.common.collections import is_iterable, is_sequence

    options = _get_options()
    args = GlobalCLIArgs.from_options(options)

    assert args['log_path'] == options.log_path
    assert args['tree'] == options.tree
    assert args['force_handlers'] == options.force_handlers
    assert args['listtasks'] == options.listtasks
    assert args['listtags'] == options.listtags
    assert args['force_pdb'] == options.force_pdb
    assert args['list_files'] == options.list_files
    assert args['playbook'] == options.playbook
    assert args['start_at'] == options.start_at

# Generated at 2022-06-23 13:59:07.627951
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    # Make the class work like a dict
    class DummyModule:

        def __init__(self, *args, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            print('FAILED: %s %s' % (args, kwargs))

    class Options(object):
        def __init__(self, **kwargs):
            self.__dict__.update(**kwargs)

    dm = DummyModule(
        foo='FOO_VALUE'
    )

    # Use CLIArgs class
    args = CLIArgs(vars(Options(**dm.params)))
    assert args['foo'] == 'FOO_VALUE'
    assert isinstance(args, ImmutableDict)

    # Try to add a new value
    args['thing']

# Generated at 2022-06-23 13:59:15.655046
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test the constructor for class CLIArgs
    """
    test_array = {'test_array': ['this', 'is', 'a', 'test'], 'test_dict': {'this': 'is', 'a': 'test'},
                  'test_str': 'this is a test', 'test_set': set(['this', 'is', 'a', 'test'])}

    cliargs = CLIArgs(test_array)

    assert cliargs == test_array
    assert isinstance(cliargs, ImmutableDict)
    assert isinstance(cliargs.test_array, tuple)
    assert isinstance(cliargs.test_dict, ImmutableDict)
    assert isinstance(cliargs.test_set, frozenset)



# Generated at 2022-06-23 13:59:17.353147
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import doctest
    sys.exit(doctest.testmod()[0])

# Generated at 2022-06-23 13:59:25.867012
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Create the dictionary for command line arguments
    cli_args = {'extra_vars': ['@vars.json', 'var=value'], 'extra_vars_files': ['vars.json'], 'inventory': ['inventory']}

    # Assert that the command line arguments are immutable
    assert isinstance(cli_args, Container) and not isinstance(cli_args, Mapping) and not isinstance(cli_args, Set) and not isinstance(cli_args, Sequence)
    assert isinstance(cli_args['extra_vars'], Container) and not isinstance(cli_args['extra_vars'], Mapping) and not isinstance(cli_args['extra_vars'], Set) and isinstance(cli_args['extra_vars'], Sequence)

# Generated at 2022-06-23 13:59:31.735146
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import json
    from ansible.utils.display import Display

    g = GlobalCLIArgs({'verbosity': 4, 'display': Display()})

    g['verbosity'] = 5

    try:
        g['verbosity'] = 6
    except TypeError:
        pass

    assert g['verbosity'] == 5
    assert json.dumps(g) == '{"verbosity": 5, "display": {}}'
    assert g.get('verbosity') == 5
    assert g.get('doesntexist', 'foo') == 'foo'

# Generated at 2022-06-23 13:59:40.843552
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # pylint: disable=protected-access
    a = GlobalCLIArgs({'a': {'b': 2}})
    assert a == {'a': {'b': 2}}
    assert a['a'] == {'b': 2}
    assert a._store == ImmutableDict({'a': ImmutableDict({'b': 2})})
    assert isinstance(a._store, ImmutableDict)
    assert isinstance(a._store['a'], ImmutableDict)
    assert isinstance(a['a'], ImmutableDict)

    # Check uniqueness of Singleton
    b = GlobalCLIArgs({'a': {'b': 2}})
    assert a == b
    assert a is b
    assert a._store == b._store
    assert a._store['a'] == b._store['a']

# Generated at 2022-06-23 13:59:51.303783
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class _A:
        name = 'test'
        value = 'value'

    class _B:
        dicts = dict(test=_A())
        test_list = [dict(test=_A())]
        test_tuples = tuple(test_list)

    temp = CLIArgs(dict(test_dict=_B()))
    assert(isinstance(temp['test_dict'], ImmutableDict))
    assert(isinstance(temp['test_dict']['dicts'], ImmutableDict))
    assert(isinstance(temp['test_dict']['dicts']['test'], ImmutableDict))
    assert(isinstance(temp['test_dict']['test_list'], tuple))

# Generated at 2022-06-23 13:59:54.995026
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() == A()
    assert B() == B()
    assert A() != B()

# Generated at 2022-06-23 14:00:00.767347
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Dummy(object):
        __metaclass__ = _ABCSingleton
        pass

    dummy_instances = [Dummy(), Dummy()]
    assert dummy_instances[0] is dummy_instances[1]

    # Test that dummy_instances[0] has the same hash as dummy_instances[1]
    assert hash(dummy_instances[0]) == hash(dummy_instances[1])

    # Test that we can use dummy_instances[0] and dummy_instances[1] as a key in a dictionary
    ref_dict = {}
    ref_dict[dummy_instances[0]] = 0
    ref_dict[dummy_instances[1]] = 1
    assert ref_dict[dummy_instances[0]] == ref_dict[dummy_instances[1]]

# Generated at 2022-06-23 14:00:02.425636
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs.from_options(global_options)
    assert args.get('syntax')

# Generated at 2022-06-23 14:00:09.141445
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    obj1 = A()
    obj2 = B()

    assert(obj1 is obj2)

    obj3 = C()

    # fail test if obj1 is equal to obj3 as it would mean that we have 2 _ABCSingleton instances
    assert(obj1 is not obj3)

# Generated at 2022-06-23 14:00:21.873957
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    @add_metaclass(_ABCSingleton)
    class ABCSingletonTest(object):
        def __init__(self, bar):
            self.bar = bar

    ABCSingletonTest(1)

    # This definition portion of this class is straight from the Singleton class definition
    # Using it to test that the Singleton mixin works with the ABCSingleton mixin
    class SingletonTest(ABCSingletonTest):
        _instances = {}

        def __init__(self):
            if self not in self._instances:
                self._instances[self] = super(SingletonTest, self).__init__()

        def __call__(self):
            raise TypeError('Singletons must be accessed through `instance()`.')


# Generated at 2022-06-23 14:00:23.292077
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    a = A()
    b = A()
    assert a is b

# Generated at 2022-06-23 14:00:31.648131
# Unit test for constructor of class CLIArgs
def test_CLIArgs():  # pylint: disable=R0915
    """
    For each possible combination of container types, verify that the
    constructor will convert the containers into immutable containers.

    The first use of a container is a "leaf object" meaning that it has no containers in it.
    The second use of a container has a container in it.
    The third use of a container has an immutable version of the containers in it.

    Do all this in a single method so that the variables stay in scope for things like pylint to
    check for references to unassigned variables.
    """
    # Test that we can call the constructor with a dictionary of immutable containers
    immutable_dict = {}
    immutable_dict['empty'] = {}
    immutable_dict['empty_leaf'] = {}
    immutable_dict['empty_container'] = ImmutableDict()


# Generated at 2022-06-23 14:00:35.877416
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Test_CLIArgs(CLIArgs):
        def __init__(self, mapping):
            super(CLIArgs, self).__init__(mapping)
    Test_CLIArgs.__init__({'test': 'test'})

# Generated at 2022-06-23 14:00:41.743163
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        pass

    options = Options()
    options.one = 1
    options.two = 2

    cli_args = CLIArgs.from_options(options)
    assert cli_args == {"one": 1, "two": 2}
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args, Mapping)



# Generated at 2022-06-23 14:00:45.127242
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {'name': 'bob', 'age': 3}
    instance = CLIArgs(args)
    assert args['name'] == instance['name']
    assert args['age'] == instance['age']

# Generated at 2022-06-23 14:00:55.763390
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    import sys
    import os
    import tempfile

    sys.argv = ['ansible-playbook', '-i', 'inventoryfile', '-l', 'subset', '-e', 'extravars', '-C', '-D', '-M', 'library']
    (fd, output_file) = tempfile.mkstemp()
    os.close(fd)

# Generated at 2022-06-23 14:01:01.507924
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'k1': {'k2': {'k3': 'v3'}}, 'k4': [{'k5': 'v5'}, {'k6': 'v6'}], 'k7': 'v7'}
    args = CLIArgs(mapping)
    assert args == mapping
    assert isinstance(args['k4'], tuple)
    assert isinstance(args['k4'][0], ImmutableDict)
    assert args == mapping

# Generated at 2022-06-23 14:01:05.832476
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--bar', dest='bar', action='store_true')
    parser.add_argument('--baz', dest='baz', action='store_true')
    options = parser.parse_args([])
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-23 14:01:17.982011
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Overriding __new__ to unit test the init of this Singleton class
    class C1(metaclass=_ABCSingleton):
        def __new__(cls):
            return "Return value from __new__ of C1"

    class C2(metaclass=_ABCSingleton):
        def __new__(cls):
            return "Return value from __new__ of C2"

    class C3(C1, C2):
        pass

    assert C1() == "Return value from __new__ of C1"
    assert C2() == "Return value from __new__ of C2"
    assert C3() == "Return value from __new__ of C1"
    assert C1.__mro__ == (C1, _ABCSingleton, object)

# Generated at 2022-06-23 14:01:28.243502
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    import os
    import sys

    # Construct it with a dict
    top = {}
    top['one'] = 1
    top['two'] = 2
    top['three'] = {'a': 'hi', 'b': 'bye'}
    top['four'] = [1, 2]
    test1 = CLIArgs(top)

    # Make sure it is immutable
    with pytest.raises(TypeError):
        one = test1['one']
        one = 5
    with pytest.raises(TypeError):
        test1['one'] = 5
    with pytest.raises(TypeError):
        del test1['one']

    # Should be able to set from options
    import optparse
    nova_option = optparse.Option('--nova', action="store_true", dest="nova", default=False)


# Generated at 2022-06-23 14:01:34.153648
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict

    test_dict = {
        'one': 1,
        'two': 2,
        'three': 3,
    }

    test_args = GlobalCLIArgs(test_dict)
    assert test_args == test_dict
    assert isinstance(test_args, ImmutableDict)

# Generated at 2022-06-23 14:01:39.716682
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    simple_dict = dict()
    simple_dict['a'] = 1
    simple_dict['b'] = 2
    simple_dict['c'] = dict()
    simple_dict['c']['d'] = 3
    simple_dict['c']['e'] = 4
    simple_dict['c']['f'] = [5, 6, 7]

    simple_args = CLIArgs(simple_dict)

    for key in simple_dict.keys():
        assert simple_args[key] == simple_dict[key]

# Generated at 2022-06-23 14:01:44.336868
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Base(object):
        def __init__(self):
            pass

    class X(Base, metaclass=_ABCSingleton):
        pass

    x1 = X()
    x2 = X()
    assert x1 is x2, "Expected singleton"

# Generated at 2022-06-23 14:01:54.131088
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import copy

    import ansible.module_utils.common.collections as collections
    import ansible.module_utils.common.netcommon as netcommon

    # Test data

    # The base command line object
    base_options = netcommon.network_cli_argument_spec().parse_args([])

    # We need to remove the object returned by parse_args() if we are going to copy it
    del base_options._get_args
    del base_options._get_kwargs

    # Use a copy so we don't mess up the original
    options = copy.copy(base_options)

    # Add some arguments which are specific to the GlobalCLIArgs
    options.debug = True
    options.connection = 'network_cli'
    options.timeout = 60


# Generated at 2022-06-23 14:01:59.682447
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Using `assert` statements in a function that doesn't have `self`
    # pylint: disable=no-self-use
    class A(metaclass=_ABCSingleton):
        pass

    class B(metaclass=_ABCSingleton):
        pass

    assert(A() == A())
    assert(B() == B())
    assert(A() != B())

# Generated at 2022-06-23 14:02:05.292575
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({'--connection': 'local', '--module-path': '/path/to/modules'})
    assert args['--connection'] == 'local'
    assert args['--module-path'] == '/path/to/modules'
    assert isinstance(args, CLIArgs)
    assert not isinstance(args, Mapping)
    assert isinstance(args, ImmutableDict)

# Generated at 2022-06-23 14:02:11.752715
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    class C(object):
        __metaclass__ = _ABCSingleton

    assert id(A()) == id(A())
    assert id(B()) == id(B())
    assert id(C()) == id(C())

    assert id(A()) != id(B())
    assert id(B()) != id(C())
    assert id(A()) != id(C())

# Generated at 2022-06-23 14:02:17.587193
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils.six import with_metaclass

    class GlobalCLIArgsSingle(with_metaclass(_ABCSingleton, GlobalCLIArgs)):
        pass

    class GlobalCLIArgsDouble(with_metaclass(_ABCSingleton, GlobalCLIArgsSingle)):
        pass

    assert GlobalCLIArgsDouble is GlobalCLIArgsSingle is GlobalCLIArgs

# Generated at 2022-06-23 14:02:21.201758
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    class B(A):
        pass

    a = A()
    try:
        b = B()
    except TypeError:
        return
    raise AssertionError("_ABCSingleton doesn't work")

# Generated at 2022-06-23 14:02:32.719460
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _Foo(object, metaclass=_ABCSingleton):
        def __init__(self, a):
            self.a = a
    class _Bar(object, metaclass=_ABCSingleton):
        def __init__(self, b):
            self.b = b
    class _Baz(_Foo, _Bar):
        def __init__(self, a, b):
            _Foo.__init__(self, a)
            _Bar.__init__(self, b)
        def __eq__(self, other):
            return self.a == other.a and self.b == other.b
    f1 = _Foo(1)
    f2 = _Foo(2)
    assert f1 is f2
    assert f1 == f2

# Generated at 2022-06-23 14:02:44.157883
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # These tests should all be run inside a function so we can use the same names for the variables
    # defined inside the function.

    # Basic class and function arguments
    class_args = {'a': 1, 'b': 2, 'c': [1, 2, 3], 'd': {'a': 'one'}}
    kwargs = {'e': ['one', 'two', 'three'], 'f': {'one': 1, 'two': 2}}

    # Put all of the tests in a try block so we can catch any exceptions and print out the
    # class_args and kwargs which are used by all the tests so they can be debugged quickly

# Generated at 2022-06-23 14:02:52.763544
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    class B(metaclass=_ABCSingleton):
        pass
    assert A() is A()
    assert B() is B()
    assert A() is not B()
    class C(A):
        pass
    assert C() is C()
    assert C() is not A()
    assert C() is not B()
    class D(B):
        pass
    assert D() is D()
    assert D() is not A()
    assert D() is not B()
    assert D() is not C()

# Generated at 2022-06-23 14:03:00.238004
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Test the constructor which is shared with all MetaSingleton classes.
    import ansible.parsing.plugin_docs

    # Make sure we can't instantiate two of these
    gca1 = GlobalCLIArgs.instance({'verbosity': 2})
    assert gca1 is not None
    with pytest.raises(TypeError) as err:
        gca2 = GlobalCLIArgs.instance({'verbosity': 3})
    assert 'takes no parameters' in str(err)

    # Make sure we can't instantiate one of these and then change it either
    with pytest.raises(TypeError) as err:
        gca3 = GlobalCLIArgs.instance()
        gca3['verbosity'] = 5
    assert 'does not support item assignment' in str(err)

    # Make sure we don't accept anything

# Generated at 2022-06-23 14:03:08.116575
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.collection_loader import all_fragments
    for fragment in all_fragments():
        if not fragment.is_playbook():
            # these are already unit tested by unit tests for connection plugins
            continue

# Generated at 2022-06-23 14:03:09.853353
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    cli_args = GlobalCLIArgs.from_options({'foo':'bar'})
    assert cli_args['foo'] == 'bar'

# Generated at 2022-06-23 14:03:18.478840
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    a = CLIArgs({'a': {'b': {'c': 'eg'},
                       'd': 'ef',
                       'e': ['g', 'h']}})
    assert a == {'a': {'b': {'c': 'eg'},
                      'd': 'ef',
                      'e': ('g', 'h')}}

    b = CLIArgs({'a': {'b': {'c': 'eg'},
                       'd': 'ef',
                       'e': ['g', 'h']}})
    assert a == b

# Generated at 2022-06-23 14:03:26.736765
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {
        'foo': [
            'bar',
        ],
        'spam': {
            'eggs': [
                'bacon',
                'toast',
            ],
        },
    }
    test_dict_copy = dict(test_dict)

    cli_args = CLIArgs(test_dict)
    assert cli_args['foo'][0] == 'bar'
    assert cli_args['spam']['eggs'][1] == 'toast'
    assert cli_args['spam']['eggs'][0] == 'bacon'
    assert test_dict == test_dict_copy  # Did not modify original dict

    # Set an item in the dict

# Generated at 2022-06-23 14:03:34.778021
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': {'b': {'c': 'd'},
                          'e': ['f',
                                'g']},
                   'h': [1, 2, 3],
                   'i': {'j': [4,
                               5,
                               6],
                         'k': {'l': 'm'}}})
    assert args['a']['b']['c'] == 'd'
    assert args['a']['e'][0] == 'f'
    assert args['a']['e'][1] == 'g'
    assert args['h'][0] == 1
    assert args['h'][1] == 2
    assert args['h'][2] == 3
    assert args['i']['j'][0] == 4

# Generated at 2022-06-23 14:03:40.491722
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    d = {'a': 1, 'b': '2', 'c': {'d': '3', 'e': '4', 'f': {'g': '5'}}}
    m = CLIArgs(d)
    assert m['b'] == '2'
    assert m['c']['d'] == '3'
    assert m['c']['f']['g'] == '5'
    return m

# Generated at 2022-06-23 14:03:52.121652
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # The test needs to create a CLIArgs object
    # Run the test from the test/ directory
    import os

    cur_dir = os.getcwd()
    if 'test' in cur_dir:
        # Run from test/ directory
        cur_dir = os.path.split(cur_dir)[0]
    # os.path.join() does not like to join cur_dir and ".."
    cur_dir = cur_dir + "/lib/ansible/module_utils/common"
    os.chdir(cur_dir)

    class MockOptions:
        pass

    # Make a dummy options object to pass to CLIArgs.from_options()
    obj = MockOptions()
    obj.v = 'v'
    obj.verbosity = 2
    obj.vvv = 'vvv'
    obj.private_data_

# Generated at 2022-06-23 14:03:56.611036
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict_ = { 'a': 'a', 'b': 'b'}
    cli_args = CLIArgs(dict_)
    assert cli_args == dict_


# Generated at 2022-06-23 14:03:59.253268
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = ['--version', '2.4']
    obj = GlobalCLIArgs.from_options(options)
    assert obj['version'] == '2.4'

# Generated at 2022-06-23 14:04:04.341423
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # This import is here because test_GlobalCLIArgs is at the bottom of the file
    from ansible.config.args import prepare_to_parse_args, parse_args
    options, args = prepare_to_parse_args()
    options, args = parse_args(options, args)
    ga = GlobalCLIArgs.from_options(options)

    assert isinstance(ga, GlobalCLIArgs)