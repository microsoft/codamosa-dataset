

# Generated at 2022-06-23 13:54:01.595384
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.context import Options
    options = Options({'test_key':'test_value'})
    results = GlobalCLIArgs(vars(options))
    assert results == {'test_key': 'test_value'}
    with pytest.raises(AttributeError):
        results.test_key = 'new_value'

# Generated at 2022-06-23 13:54:12.479727
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.parsing.plugin_docs import read_docstubs
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    loader = DataLoader()
    inv_manager = InventoryManager(loader, None, 'localhost,')

# Generated at 2022-06-23 13:54:18.046139
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    import ansible.utils.argparse as argparse
    args = argparse.DEFAULT_ARGS

    gca = GlobalCLIArgs(args)

    from ansible.cli import CLI
    cli = CLI(args)
    cli.parse()

    assert gca.get("ask_vault_pass") is cli.options.ask_vault_pass

# Generated at 2022-06-23 13:54:24.982070
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test non-singleton GlobalCLIArgs class
    """
    # GlobalCLIArgs is a Singleton class, so this object should be created
    # when the module runs.  The following line is only meant to be executed
    # when running tests.
    global_cli_args = GlobalCLIArgs()

    # There should be no global_cli_args object defined when module is
    # loaded because it is a singleton.
    assert not global_cli_args



# Generated at 2022-06-23 13:54:26.672513
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class X(object):
        __metaclass__ = _ABCSingleton
    a = X()
    b = X()
    assert a is b

# Generated at 2022-06-23 13:54:32.533636
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    display.deprecation_warnings = False
    display.format = 'json'
    display.show_custom_stats = True
    display.settings['warnings'] = False
    display.settings['columns'] = dict(stdout=120)

    # GlobalCLIArgs is a Singleton
    global_cli_args_1 = GlobalCLIArgs({'verbosity': 3, 'display': display})
    assert global_cli_args_1.verbosity == 3
    assert global_cli_args_1['display'].verbosity == 3
    assert global_cli_args_1['display'].deprecation_warnings is False
    assert global_cli_args_1['display'].settings['warnings'] is False

   

# Generated at 2022-06-23 13:54:35.386958
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-23 13:54:46.365464
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test that GlobalCLIArgs is a singleton and that it's constructor works
    """

# Generated at 2022-06-23 13:54:48.787235
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(_ABCSingleton): pass

    a = A()
    b = A()
    assert a is b
    assert isinstance(a, A)
    assert issubclass(A, _ABCSingleton)

# Generated at 2022-06-23 13:54:57.590507
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = ['-a', 'file1', 'file2']
    options = CLIArgs.init_parser().parse_args(args)
    kwargs = {'mapping': vars(options)}
    actual = CLIArgs(**kwargs)

# Generated at 2022-06-23 13:55:02.256680
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.utils.underscored_object import UnderscoredObject
    class MySingleton(UnderscoredObject):  # pylint: disable=unused-variable
        pass
    assert '__metaclass__' in globals()
    assert '_ABCSingleton' in globals()
    assert 'MySingleton' in globals()
    del globals()['MySingleton']
    del globals()['_ABCSingleton']
    del globals()['__metaclass__']

# Generated at 2022-06-23 13:55:04.102363
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton):
        def __init__(self):
            self.FOO = "BAR"

    assert(Foo.FOO == "BAR")



# Generated at 2022-06-23 13:55:16.907091
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import copy
    import sys

    class FakeOptions(object):
        def __init__(self):
            self.silly = "silly"
            self.version = '20'
            self.other = {'a': [1, 2]}

    args = CLIArgs.from_options(FakeOptions())
    assert args['silly'] == "silly"
    assert args['version'] == '20'
    assert args['other']['a'][1] == 2

    args['other']['a'][1] = 3
    assert args['other']['a'][1] == 2

    args['other']['a'].append(4)
    assert len(args['other']['a']) == 3

    args['other']['b'] = 'hello'  # pylint: disable=unsupported

# Generated at 2022-06-23 13:55:24.529564
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    a = GlobalCLIArgs.from_options(GlobalCLIArgs.from_options(GlobalCLIArgs({'a': 1})))
    assert a == GlobalCLIArgs({'a': 1})
    with pytest.raises(TypeError):
        a['a'] = 2
    with pytest.raises(TypeError):
        a.__delitem__('a')
    with pytest.raises(TypeError):
        a.update({'b': 1})
    with pytest.raises(TypeError):
        a.clear()
    with pytest.raises(TypeError):
        a.pop('a')
    with pytest.raises(TypeError):
        a.popitem()
    with pytest.raises(TypeError):
        a.setdefault('a', 1)


# Generated at 2022-06-23 13:55:32.042573
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(B):
        pass

    assert D._abc_registry is D._abc_cache
    assert D._abc_registry is B._abc_registry
    assert D._abc_registry is A._abc_registry
    assert D._abc_registry is C._abc_registry

# Generated at 2022-06-23 13:55:33.860883
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = GlobalCLIArgs({'a': 'b'})
    b = GlobalCLIArgs({'a': 'b'})
    assert a is b

# Generated at 2022-06-23 13:55:42.399575
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Unit test to demonstrate construction of the class GlobalCLIArgs"""
    import unittest

    class GlobalCLIArgsTest(unittest.TestCase):
        def test_constructor(self):
            """Test the construction of a GlobalCLIArgs object"""
            # Without this we get an error "TypeError: metaclass conflict: the
            # metaclass of a derived class must be a (non-strict) subclass of the
            # metaclasses of all its bases"
            from six import add_metaclass

            @add_metaclass(GlobalCLIArgs)
            class TestCLIArgs(ImmutableDict):
                pass

            test_dict = {}
            test_dict['arg1'] = 'arg1'
            test_dict['arg2'] = 'arg2'
            test_cli_args = TestCLI

# Generated at 2022-06-23 13:55:51.669132
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs({'a': 1, 'b': {'c': 2}, 'd': [1, 2, 3]})
    assert isinstance(cli_args, ImmutableDict) and isinstance(cli_args, Mapping)
    assert cli_args == ImmutableDict({'a': 1, 'b': ImmutableDict({'c': 2}), 'd': (1, 2, 3)})
    # If you iterate through the keys, you should get a regular list back
    assert [key for key in cli_args] == ['a', 'b', 'd']
    # If you iterate through the items, you should get a regular list back

# Generated at 2022-06-23 13:55:55.892251
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import GlobalCLIArgs
    temp = GlobalCLIArgs({'a': 1, 'b': {'c': 3, 'd': 4}})
    assert temp['a'] == 1
    assert temp['b']['c'] == 3
    assert temp['b']['d'] == 4

# Generated at 2022-06-23 13:55:57.427881
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object):
        __metaclass__ = _ABCSingleton

    assert Test() is Test()

# Generated at 2022-06-23 13:56:00.934448
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABCSingletonSubclass(object):
        __metaclass__ = _ABCSingleton

    class _ABCSingletonSubclass2(object):
        __metaclass__ = _ABCSingleton

    assert _ABCSingletonSubclass() is _ABCSingletonSubclass()
    assert _ABCSingletonSubclass2() is _ABCSingletonSubclass2()
    assert _ABCSingletonSubclass() is not _ABCSingletonSubclass2()

# Generated at 2022-06-23 13:56:02.249347
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    CLIArgs({'foo': {'bar': 'baz'}, 'one': 1})

# Generated at 2022-06-23 13:56:09.950387
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()

    class C(A):
        pass

    assert issubclass(C, A)
    assert not issubclass(A, C)
    assert A() is C()

    class D(B):
        pass

    assert issubclass(D, B)
    assert not issubclass(B, D)
    assert B() is D()
    assert C() is not D()

# Generated at 2022-06-23 13:56:20.888319
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.dict_transformations import deep_dict_merge
    from ansible.utils.path import unfrackpath
    from ansible.module_utils.six import binary_type
    import sys

    source = {
        'ANSIBLE_FORCE_COLOR': True,
        'ANSIBLE_ROLES_PATH': '/etc/ansible/roles:/home/me/galaxy_roles',
        'PRIVATE_KEY_FILE': [unfrackpath('~/.ssh/id_rsa'), unfrackpath('~/.ssh/id_ecdsa')],
        'verbosity': 3,
        'version': False,
        'syntax-check': True,
    }

    # FIXME: ansible.utils.display._get_terminal_size_raw appears to be broken in Windows

# Generated at 2022-06-23 13:56:27.682831
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(metaclass=_ABCSingleton):
        pass

    a = A()
    a_1 = A()
    assert a is a_1
    assert a == a_1

    # We can compare with instance of other classes with the same metaclass
    b = B()
    assert a != b

    # But we get an error when attempting to compare with instance of different class
    class C(metaclass=type):
        pass

    c = C()
    try:
        a == c
        assert False, "Comparison with instance of different class should have raised an error"
    except TypeError:
        pass

# Generated at 2022-06-23 13:56:29.980221
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({'foo': 'bar'})
    assert args['foo'] == 'bar'

# Generated at 2022-06-23 13:56:32.656732
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    obj = GlobalCLIArgs({'foo': 1, 'bar': 'hello'})
    assert obj == {'foo': 1, 'bar': 'hello'}
    assert isinstance(obj, ImmutableDict)

# Generated at 2022-06-23 13:56:43.456914
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys

    if sys.version_info < (2, 7):
        return

    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common.collections import MutableSequence, MutableSet

    test_data = {
        'mutables': {
            'mutable_string': 'Immutable',
            'mutable_dict': {
                'a': 'Immutable',
                'b': MutableMapping([('c', MutableMapping()),
                                     ('d', 'Immutable')]),
                'list': MutableSequence([MutableSequence([MutableSet([1, 2, MutableSet([1, 2, 3])]),
                                                          MutableSet([1, 2, 3])])]),
            }
        }
    }

# Generated at 2022-06-23 13:56:45.939453
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    import io

    class A(io.IOBase):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    c = B()

# Generated at 2022-06-23 13:56:50.978489
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # create a dictionary
    mapping = {'temp': {1: 'one'}, 'test': {'test': ['a', 'b']}}
    # create instance of class CLIArgs
    cli_args = CLIArgs(mapping)
    # create instance of class ImmutableDict
    ImmutableDict_ = ImmutableDict(mapping)
    # assert comparison of cli_args and ImmutableDict_
    assert cli_args == ImmutableDict_



# Generated at 2022-06-23 13:56:54.618286
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        class Meta(Singleton, ABCMeta):
            pass
    except TypeError:
        pass  # This is what we want to happen

    class Meta(_ABCSingleton):
        pass

    try:
        class X(metaclass=Meta):
            pass
    except TypeError:
        pass  # This is what we want to happen

# Generated at 2022-06-23 13:56:56.427193
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton(object):
        __metaclass__ = _ABCSingleton

    testobj = TestSingleton()
    assert testobj is TestSingleton()

# Generated at 2022-06-23 13:57:03.845752
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import inspect
    import sys
    # Test that the GlobalCLIArgs class can be subclassed.
    # We can't do this directly in test_utils_module_finder because the GlobalCLIArgs class is
    # imported there.
    class SubclassGlobalCLIArgs(GlobalCLIArgs):
        pass
    class SubclassGlobalCLIArgsNoInit(GlobalCLIArgs):
        def __init__(self, *args, **kwargs):
            print("Hello world!")
    sub1 = SubclassGlobalCLIArgs()
    sub2 = SubclassGlobalCLIArgs()
    # Test that the subclasses are singletons.
    assert sys.getrefcount(sub1) == 3
    assert sub1 is sub2
    assert isinstance(sub1, dict)

    # Test that subclasses of GlobalCLIArgs do not inherit the

# Generated at 2022-06-23 13:57:10.932768
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Unit test for class _ABCSingleton
    """
    class TestABC(object):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            self.var = 1

        def update(self, var):
            self.var = var

    a = TestABC()
    b = TestABC()

    assert a.var == 1
    a.update(2)
    assert b.var == 2
    assert a.var == 2

# Generated at 2022-06-23 13:57:11.812283
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options =  ImmutableDict()
    assert GlobalCLIArgs(options)

# Generated at 2022-06-23 13:57:18.354209
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    cliargs = GlobalCLIArgs.from_options(Options({'foo': 'bar'}))

    # Verify that we can't set a value
    try:
        cliargs['dne'] = 'new'
        raise RuntimeError('We set a value on a GlobalCLIArgs object and that should have raised an exception')
    except Exception:
        pass



# Generated at 2022-06-23 13:57:22.092299
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import GlobalCLIArgs

    x = GlobalCLIArgs({'a': 1, 'b': 2})
    assert x['a'] == 1
    assert x['b'] == 2

# Generated at 2022-06-23 13:57:24.370526
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, Singleton)
    assert issubclass(_ABCSingleton, ABCMeta)
    assert issubclass(GlobalCLIArgs, CLIArgs)

# Generated at 2022-06-23 13:57:30.637151
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class TestOptions:
        def __init__(self, args_dict):
            for key, value in args_dict.items():
                setattr(self, key, value)

    test_opts = TestOptions({'repo_url': 'ssh://example.org'})
    args = GlobalCLIArgs.from_options(test_opts)
    # This fails without the _make_immutable call in CLIArgs.__init__
    assert args is args.__dict__['repo_url']

# Generated at 2022-06-23 13:57:33.130994
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class A(object):
        __metaclass__ = _ABCSingleton

    a = A()
    assert a.__class__ is A
    b = A()
    assert b is a


# Generated at 2022-06-23 13:57:45.478606
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

  args = vars(parse_cli_args())
  GlobalCLIArgs(args)


# For backwards compatibility, we expose few arguments in globals.
# This is a "poor man's" solution to minimize the changes required.
# For example, test/runner/__init__.py imports a bunch of args.
# We can easily replace individual arguments with their GlobalCLIArgs neighbours.

J = GlobalCLIArgs.instance()['j']
K = GlobalCLIArgs.instance()['k']
LISTDOTYML = GlobalCLIArgs.instance()['listtasks']
V = GlobalCLIArgs.instance()['v']
VERBOSITY = GlobalCLIArgs.instance()['verbosity']
VAULT_PASSWORD_FILE = GlobalCLIArgs.instance()['vault_password_file']
STDOUT_CALLBACK = GlobalCL

# Generated at 2022-06-23 13:57:53.928781
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-23 13:58:01.594803
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        attr1 = "test"
        attr2 = ImmutableDict({"key1": "value1", "key2": ["value2", "value3"]})
        attr3 = True

    options = Options()
    cli_args = CLIArgs.from_options(options)

    assert cli_args == {"attr1": "test",
                        "attr2": {"key1": "value1", "key2": ("value2", "value3")},
                        "attr3": True}

# Generated at 2022-06-23 13:58:04.919731
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    # Ensure both metaclasses were combined
    assert hasattr(TestClass, '__abstractmethods__')
    assert hasattr(TestClass, '__instance')

# Generated at 2022-06-23 13:58:13.183051
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options:
        pass

    opt = Options()
    opt.shutdown = {'delay': 10, 'timeout': 60}
    opt.foo = 'bar'

    args = CLIArgs.from_options(opt)

    assert isinstance(args, CLIArgs)
    assert isinstance(args['shutdown'], ImmutableDict)
    assert isinstance(args['shutdown']['timeout'], int)
    assert isinstance(args['shutdown']['delay'], int)
    assert isinstance(args['foo'], text_type)

# Generated at 2022-06-23 13:58:22.481231
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import textwrap
    sys.argv = [None, '--flat']
    ex_path = 'ansible-playbook'
    ex_prog = 'ansible-playbook'
    ex_opts = textwrap.dedent("""\
        usage: %(prog)s [options] ...

                    I would really like some help here.

                    I have no idea how to use this thing.

        options:
          -h, --help            show this help message and exit
          --flat                Do something. (default: False)
        """)
    import ansible.playbook.play_context as play_context
    play_context.load_params()
    play_context.PlayContext._load_options(ex_path, ex_prog, ex_opts)
    play_context.PlayContext._merge

# Generated at 2022-06-23 13:58:35.087436
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with no arguments
    # Expect to have no keys in the dictionary
    map_test = {}
    o = CLIArgs(map_test)
    assert len(o) == 0

    # Test with one argument
    # Expect one key in the dictionary
    map_test = {'key1': 'value1'}
    o = CLIArgs(map_test)
    assert len(o) == 1

    # Test with two arguments
    # Expect two keys in the dictionary
    map_test = {'key1': 'value1', 'key2': 'value2'}
    o = CLIArgs(map_test)
    assert len(o) == 2

    # Test with nested dictionary
    # Expect nested dictionary as immutable dict

# Generated at 2022-06-23 13:58:38.656942
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    options = type('options', tuple(), {'foo': 'bar'})()
    assert CLIArgs.from_options(options) == ImmutableDict({'foo': 'bar'})


# Generated at 2022-06-23 13:58:41.394816
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Parent(metaclass=_ABCSingleton):
        pass

    class Child(Parent):
        pass

    parent = Parent()
    child = Child()

    assert parent is child



# Generated at 2022-06-23 13:58:47.954308
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        pass

    class Bar(object):
        pass

    class SingletonFoo(Foo, metaclass=_ABCSingleton):
        pass

    class SingletonBar(Bar, metaclass=_ABCSingleton):
        pass

    assert issubclass(SingletonFoo, Foo)
    assert issubclass(SingletonFoo, Singleton)
    assert issubclass(SingletonBar, Bar)
    assert issubclass(SingletonBar, Singleton)

# Generated at 2022-06-23 13:58:50.494728
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(Foo(), Foo)



# Generated at 2022-06-23 13:58:56.922394
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    opt = {'opt1': {'opt11': 'val11', 'opt12': 'val12'}}
    cli = CLIArgs(opt)
    assert cli['opt1']['opt11'] == 'val11'
    assert cli['opt1']['opt12'] == 'val12'
    opt['opt1']['opt11'] = 'val13'
    assert cli['opt1']['opt11'] == 'val11'
    assert cli['opt1']['opt12'] == 'val12'

# Generated at 2022-06-23 13:59:07.939141
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-23 13:59:16.826587
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({'foo': 'bar'})
    GlobalCLIArgs({'foo': {'bar': 'baz'}})
    GlobalCLIArgs({'foo': ['bar', 'baz', 'bam']})
    GlobalCLIArgs({'foo': ('bar', 'baz', 'bam')})
    GlobalCLIArgs({'foo': {'bar', 'baz', 'bam'}})
    GlobalCLIArgs({'foo': frozenset({'bar', 'baz', 'bam'})})
    GlobalCLIArgs({'foo': ImmutableDict({'bar': 'baz'})})
    GlobalCLIArgs({'foo': {'bar': {'baz': 'bam'}}})

# Generated at 2022-06-23 13:59:19.103482
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(metaclass=_ABCSingleton):
        pass

    class C(A, B):
        pass

test__ABCSingleton()

# Generated at 2022-06-23 13:59:27.342889
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from collections import OrderedDict
    from ansible.module_utils.common._collections_compat import Mapping
    GlobalParameterSingleton_dict = OrderedDict()
    GlobalParameterSingleton_dict['hostfile'] = 'hostfile'
    GlobalParameterSingleton_dict['listhosts'] = 'listhosts'
    GlobalParameterSingleton_dict['subset'] = 'subset'
    GlobalParameterSingleton_dict['module_path'] = None
    GlobalParameterSingleton_dict['extra_vars'] = None
    GlobalParameterSingleton_dict['metadata_path'] = None
    GlobalParameterSingleton_dict['only_tags'] = None
    GlobalParameterSingleton_dict['skip_tags'] = None
    GlobalParameterSingleton_dict['forks'] = None
    GlobalParameterSingleton_dict['timeout'] = None


# Generated at 2022-06-23 13:59:32.339308
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    a1 = A()
    a2 = A()
    assert a1 is a2

    class B(A):
        pass

    b1 = B()
    b2 = B()
    assert b1 is b2
    assert b1 is a1

    class C(object):
        pass

    c1 = C()
    c2 = C()
    assert c1 is not c2

# Generated at 2022-06-23 13:59:33.716517
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class BadSingleton(Singleton, ABCMeta):
        pass



# Generated at 2022-06-23 13:59:41.870635
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # class GlobalCLIArgs is singleton, by using different args should always get the same object
    cli_args1 = GlobalCLIArgs({'a': 1, 'b': 2})
    cli_args2 = GlobalCLIArgs({'a': 3, 'b': 4})
    assert cli_args1 is cli_args2

    # the value of key 'b' should be 4, not 2
    assert cli_args1['b'] == 4

    # __setitem__ will raise TypeError
    try:
        cli_args1['b'] = 3
    except TypeError:
        assert True
    else:
        assert False

    # __delitem__ will raise TypeError
    try:
        del cli_args1['b']
    except TypeError:
        assert True
    else:
        assert False

# Generated at 2022-06-23 13:59:44.222217
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    class B(A):
        pass
    A()
    B()

# Generated at 2022-06-23 13:59:50.464649
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    class C(object):
        __metaclass__ = Singleton

    assert issubclass(A, _ABCSingleton)
    assert issubclass(B, _ABCSingleton)
    assert not issubclass(C, _ABCSingleton)  # because Singleton doesn't inherit from ABCMeta 

test__ABCSingleton()

# Generated at 2022-06-23 13:59:53.379851
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Also tests the __init__ method of class CLIArgs
    temp_dict = {"key1": {"key2": "key3"}}
    GlobalCLIArgs(temp_dict)

# Generated at 2022-06-23 14:00:03.330561
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader)
    var_manager = VariableManager(loader=loader, inventory=inv_manager)

# Generated at 2022-06-23 14:00:13.420857
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Unit test for the CLIArgs class"""
    import sys
    from ansible.cli import CLI
    from ansible.errors import AnsibleError

    # Directly use CLI class to avoid importing anything that might have already been initialized
    # before the unit test was run
    cli_instance = CLI()
    try:
        cli_instance.parse()
    except AnsibleError as e:
        sys.exit(e)

    args = cli_instance.options

    # Check that we can convert the options' dict
    cli_args = CLIArgs.from_options(args)

    # Check that we can not add or change an argument
    try:
        cli_args["something"] = "else"
    except (KeyError, TypeError):
        pass

# Generated at 2022-06-23 14:00:20.599420
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    assert CLIArgs({}) == ImmutableDict()
    assert CLIArgs({'test': {}}) == ImmutableDict({'test': ImmutableDict()})
    assert is_immutable(CLIArgs({'test': {'value': 'immutable'}})['test'])



# Generated at 2022-06-23 14:00:30.474305
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import json
    import sys
    import tempfile

    options = None
    args = ['some', 'args']

    # The simplest use case
    #   Using defaults
    #   No args
    #   No config
    options, args = GlobalCLIArgs.parse(args)
    assert options.__dict__ == {}

    # Test loading a config file
    config_file = tempfile.NamedTemporaryFile(suffix='.cfg')
    config_file.file.write(b"[defaults]\n")
    config_file.file.write(b"one=foo\n")
    config_file.file.write(b"two=bar\n")
    config_file.file.write(b"three=1\n")
    config_file.file.write(b"four=1.1\n")


# Generated at 2022-06-23 14:00:33.734392
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABCSingletonTest(object, metaclass=_ABCSingleton):
        pass
    assert _ABCSingletonTest() is _ABCSingletonTest()

# Generated at 2022-06-23 14:00:36.467285
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSubclass(object):
        __metaclass__ = _ABCSingleton
    
    assert TestSubclass() is TestSubclass()

# Generated at 2022-06-23 14:00:42.438448
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Use it to construct a new class
    class NewTest(_ABCSingleton):
        def __init__(self, msg):
            self.msg = msg

    nt1 = NewTest('one')
    nt2 = NewTest('two')

    assert nt1 is nt2
    assert nt1.msg == 'one'
    assert nt2.msg == 'one'



# Generated at 2022-06-23 14:00:49.477651
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'one': 1, 'two': 'two', 'three': [1, 2, 3], 'four': {'four': 4},
               'five': frozenset([5]), 'six': 'six', 'seven': 7}
    result = CLIArgs(mapping)
    assert isinstance(result, Mapping)
    for key, value in result.items():
        assert mapping[key] is value
    assert result == mapping



# Generated at 2022-06-23 14:00:57.673490
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import os
    test_args = []
    if os.name == 'nt':
        # Replace shell argument escaping with a substitute
        test_args.append("TEST_ANSIBLE_COLLECTIONS_PATH=c:\{test\}")
    else:
        test_args.append("TEST_ANSIBLE_COLLECTIONS_PATH=/{test}")
    global_args = GlobalCLIArgs(test_args)
    test_path = '/{test}'
    if os.name == 'nt':
        test_path = 'c:\{test\}'
    assert global_args.get('TEST_ANSIBLE_COLLECTIONS_PATH') == test_path

# Generated at 2022-06-23 14:01:02.728964
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    x = GlobalCLIArgs({"a": "1", "b": "2"})
    assert x.a == "1"
    assert x.b == "2"
    assert "a" in x.keys()
    assert "b" in x.keys()


# Generated at 2022-06-23 14:01:09.652578
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.parsing.vault import VaultLib
    from ansible.cli import CLI

    parser = CLI.base_parser(
        vault_opts=True,
        async_opts=True,
        output_opts=True,
        runas_opts=True,
        connect_opts=True,
        subset_opts=True,
        check_opts=True,
        diff_opts=True,
        inventory_opts=True,
        runtask_opts=True,
        strategy_opts=True,
        fork_opts=True,
        module_opts=True,
        become_opts=True,
        verbosity_opts=True,
        pipeline_opts=True
    )
    options = parser.parse_args()

    cmd_line_v

# Generated at 2022-06-23 14:01:13.775461
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert _ABCSingleton == _ABCSingleton()
    assert _ABCSingleton == _ABCSingleton
    assert _ABCSingleton is _ABCSingleton()
    assert _ABCSingleton is _ABCSingleton

# Generated at 2022-06-23 14:01:17.115500
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    try:
        GlobalCLIArgs({'test': True})
    except AssertionError:
        pass
    else:
        assert False, "test_GlobalCLIArgs did not throw AssertionError"

# Generated at 2022-06-23 14:01:21.229810
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():  # pylint: disable=redefined-outer-name
    class SingletonABCClass(metaclass=_ABCSingleton):  # pylint: disable=too-few-public-methods
        'Unit test for _ABCSingleton'
    assert SingletonABCClass is SingletonABCClass()

# Generated at 2022-06-23 14:01:27.925057
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli import CLI
    from ansible.module_utils.common._collections_compat import MutableMapping

    parser = CLI.base_parser(
        command_override='',
        runas_opts=True,
        async_opts=True,
        connect_opts=True,
        subset_opts=True,
        check_opts=True,
        runtask_opts=True,
        vault_opts=True,
        fork_opts=True,
        module_opts=True,
        always_positional_arguments=['module_args'],
    )

    # Give it some custom arguments to make sure they are there
    parser.add_argument('--force-color', action='store_true', dest='color', default=None)

# Generated at 2022-06-23 14:01:36.396281
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import pytest
    source = {'ansible_python_interpreter': '/bin/python3', 'connection': 'local', 'private_key_file': ['~/.ssh/id_rsa', '~/.ssh/mykey'], 'vault_password_file': '~/.vault_pass.txt'}
    immutable_args = CLIArgs(source)
    with pytest.raises(KeyError) as excinfo:
        immutable_args['vault_password_file'] = '~/.something_new.txt'
    assert 'Mapping is immutable' in str(excinfo.value)

# Generated at 2022-06-23 14:01:43.294281
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from abc import ABC, abstractmethod

    @add_metaclass(_ABCSingleton)
    class TestABCSingleton(ABC):
        @abstractmethod
        def test(self):
            pass

        @classmethod
        def test_class(cls):
            pass

        @staticmethod
        def test_static():
            pass

    # test singleton:
    a = TestABCSingleton()
    b = TestABCSingleton()
    assert a is b

    # test abstract method:
    try:
        a.test()
    except NotImplementedError:
        pass
    except Exception as e:
        raise e

    # test abc register
    TestABCSingleton.register(int)
    try:
        TestABCSingleton.test_class()
    except TypeError:
        pass

# Generated at 2022-06-23 14:01:53.493183
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABCMeta(_ABCSingleton):
        pass

    class TestABCMetaChild(TestABCMeta):
        pass

    class TestABCMetaChild2(TestABCMeta):
        pass

    class TestABCMetaGrandChild(TestABCMetaChild):
        pass

    class TestSingleton(TestABCMeta, Singleton):
        pass

    # Test ABCMeta
    assert TestABCMeta.register(tuple)
    assert TestABCMeta.register(list)

    # Test Singleton
    # This raises RuntimeError if it fails
    TestSingleton()
    TestSingleton()

    # Test _ABCSingleton
    try:
        TestABCMetaChild()
        TestABCMetaChild()
    except TypeError:
        # _ABCMetaclass should raise TypeError because we're trying to instantiate it again
        pass

# Generated at 2022-06-23 14:01:55.394776
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test1(object):
        __metaclass__ = _ABCSingleton
    class Test2(object):
        __metaclass__ = _ABCSingleton
    assert Test1() is Test2()

# Generated at 2022-06-23 14:02:00.760574
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test1(_ABCSingleton):
        def __init__(self):
            pass

    t1 = Test1()
    t2 = Test1()
    assert t1 is t2, 'Singleton failed to work'

    class Test2(Test1):
        def __init__(self):
            pass

    t3 = Test2()
    assert t1 is t3, 'ABCMeta failed to work'



# Generated at 2022-06-23 14:02:02.527224
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestObject(_ABCSingleton):
        pass

    x = TestObject()
    assert x is TestObject()

# Generated at 2022-06-23 14:02:07.268360
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    cli_args = {'a': 1, 'b': 'b'}
    global_args = GlobalCLIArgs(cli_args)
    assert len(global_args) == 2
    assert global_args['a'] == 1
    assert global_args['b'] == 'b'
    with pytest.raises(TypeError):
        global_args['a'] = 3

# Generated at 2022-06-23 14:02:10.504389
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Test that it is a Singleton ABCMeta
    from ansible.module_utils.common._collections_compat import Sequence

    class MyABCSingleton(Sequence, metaclass=_ABCSingleton):
        pass

    assert issubclass(MyABCSingleton, Sequence)
    assert issubclass(MyABCSingleton, Singleton)

# Generated at 2022-06-23 14:02:17.786331
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    opt = GlobalCLIArgs(dict({"a":1, "b": {"c":2}}))
    assert opt.a == 1
    assert opt.b.c == 2
    try:
        opt.b.c = 10
        raise AssertionError("should not be able to mutate immutable")
    except AttributeError:
        pass
    try:
        opt.a = 10
        raise AssertionError("should not be able to mutate immutable")
    except AttributeError:
        pass

# Generated at 2022-06-23 14:02:18.613473
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({"a": "test"})

# Generated at 2022-06-23 14:02:20.975790
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Bad(_ABCSingleton):
        pass

    assert issubclass(Bad, Singleton)
    assert issubclass(Bad, ABCMeta)

# Generated at 2022-06-23 14:02:32.498110
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """ test constructor of class GlobalCLIArgs"""
    import tempfile
    import shutil
    import os
    import argparse
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook

    tmp_dir = tempfile.mkdtemp()


# Generated at 2022-06-23 14:02:38.448729
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.argparse import (DEFAULT_BASIC_DOC,
                                                      DEFAULT_MODULE_DOC,
                                                      DEFAULT_SUPPORTED_BY_DOC,
                                                      DEFAULT_EXAMPLES_DOC,
                                                      DEFAULT_RETURN_DOC,
                                                      DEFAULT_AUTHOR_DOC,
                                                      DEFAULT_COPYRIGHT_DOC,
                                                      DEFAULT_LICENSE_DOC,
                                                      DEFAULT_VERSION_DOC,
                                                      DEFAULT_STATUS_DOC)
    import ansible.module_utils.basic
    import ansible.module_utils.connection

    # Mock some default command-line arguments

# Generated at 2022-06-23 14:02:45.599434
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_args = {'aaa': 'bbb', 'ccc': {'ddd': 'eee', 'fff': {'ggg': 'hhh'}, 'iii': ['jjj', 'kkk']}, 'lll': ['mmm']}
    assert CLIArgs(test_args) == ImmutableDict({'aaa': 'bbb', 'ccc': ImmutableDict({'ddd': 'eee', 'fff': ImmutableDict({'ggg': 'hhh'}), 'iii': ('jjj', 'kkk')}), 'lll': ('mmm',)})

# Generated at 2022-06-23 14:02:56.228137
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common._collections_compat import MutableSet, MutableSequence, MutableMapping

    # Test the conversion to ImmutableDict

# Generated at 2022-06-23 14:02:57.186041
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """This one is so simple that it needs no tests"""

# Generated at 2022-06-23 14:02:58.955966
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(Test(), Test)

# Generated at 2022-06-23 14:03:08.902557
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    # Construct a mock parser
    parser = argparse.ArgumentParser(add_help=False)

    parser.add_argument('--foo')
    parser.add_argument('--bar')
    parser.add_argument('--baz', default='Baz', action='store')
    parser.add_argument('--fro', default='Fro', action='store')

    # Construct a mock namespace
    namespaces = argparse.Namespace()
    setattr(namespaces, 'foo', 1)
    setattr(namespaces, 'bar', 1)
    setattr(namespaces, 'baz', 1)
    setattr(namespaces, 'fro', 1)

    # Call GlobalCLIArgs

# Generated at 2022-06-23 14:03:13.411275
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test that we can't change GloblCLIArgs object
    """
    options = ImmutableDict({"foo": "bar"})
    options.foo = "baz"
    try:
        options.spam = "eggs"
    except AttributeError:
        pass
    else:
        raise Exception('{} not in {}'.format("foo", options))



# Generated at 2022-06-23 14:03:18.994127
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    global_args = GlobalCLIArgs({'foo': 'bar'})
    global_args_copy = GlobalCLIArgs({'foo': 'bar'})

    assert(global_args == global_args_copy)
    assert(id(global_args) == id(global_args_copy))


# Generated at 2022-06-23 14:03:21.280273
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    a = Foo()
    b = Foo()
    assert a is b

# Generated at 2022-06-23 14:03:25.278587
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_dict = dict()
    test_dict['a'] = 'b'
    a = GlobalCLIArgs(test_dict)
    print(a['a'])



# Generated at 2022-06-23 14:03:33.680366
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli import CLI
    from ansible.config import CLI
    from ansible.parsing.dataloader import DataLoader

    from ansible.errors import AnsibleError
    from ansible.plugins.loader import connection_loader

    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    connection_loader.add_directory(os.path.expanduser("~/ansible/lib/ansible/plugins/connection/"))
    connection_loader.add_directory("/usr/lib/python2.7/site-packages/ansible/plugins/connection/")
    connection_loader.add_directory("/usr/local/lib/python2.7/dist-packages/ansible/plugins/connection/")

    # load config

# Generated at 2022-06-23 14:03:37.227227
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options:
        def __init__(self):
            self.host_key_checking = True
            self.diff = False

    opt = Options()
    GlobalCLIArgs.from_options(opt)


# Generated at 2022-06-23 14:03:42.481310
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    CLIArgs({'a': 1, 'b': 2})

    CLIArgs({'a': 1,
             'b': 2,
             'c': {'x': 11, 'y': 12},
             'd': [31, 32],
             'e': {'z': {'zz': [411, 412]}}})



# Generated at 2022-06-23 14:03:53.441312
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import copy
    import collections
    import sys

    def test_type(test_obj, expected):
        """
        Helper function to test expected types
        """
        assert type(test_obj) == expected
        if sys.version_info >= (3,):
            assert isinstance(test_obj, expected)
        else:
            assert isinstance(test_obj, expected)

    # Create a new instance of the class
    test_dict = {'bool': True, 'string': 'value', 'list': [{'dict': {'key': 'value'}}, 'string'], 'set': set([1, 2, 3]), 'iterable': "iterable string"}
    test_object = CLIArgs(test_dict)

    # Verify that we are using the correct class
    assert isinstance(test_object, CLIArgs)

   

# Generated at 2022-06-23 14:04:01.018170
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # it should be possible to create a class which is a Singleton and an ABCMeta
    # based class

    class ContainerSingleton(_ABCSingleton):
        def __init__(self):
            self.mapping = {}

    # it should be possible to create an instance of this class once
    a = ContainerSingleton()
    del a

    # it should be impossible to create a second instance of this class
    try:
        b = ContainerSingleton()
        del b
    except RuntimeError:
        pass