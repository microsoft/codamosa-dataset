

# Generated at 2022-06-23 13:54:05.111040
# Unit test for constructor of class CLIArgs
def test_CLIArgs():  # noqa
    import sys
    import argparse
    from ansible.module_utils.common._collections_compat import (MutableMapping, MutableSequence, MutableSet)
    from ansible.module_utils.common.collections import MutableDict

    parser = argparse.ArgumentParser()
    parser.add_argument('--test', dest='test', type=int, default=42)
    args = parser.parse_args(sys.argv[1:])
    cli_args = CLIArgs.from_options(args)
    # Test that it is immutable
    try:
        cli_args['test'] = 24
    except AttributeError:
        pass
    else:
        assert False, 'CLIArgs should be immutable, but it isn\'t!'

# Generated at 2022-06-23 13:54:10.136536
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs is not CLIArgs
    args1 = CLIArgs(dict(a=1, b=2))
    args2 = CLIArgs(dict(a=1, b=2))
    args3 = CLIArgs(dict(a=1, c=3))
    assert args1 == args2
    assert args1 != args3
    assert args2 != args3



# Generated at 2022-06-23 13:54:20.985599
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Given that we have a CLIArgs object and a logical operator
    # When I construct a CLIArgs object
    # Then I should get a CLIArgs object
    assert isinstance(CLIArgs({}), CLIArgs)
    assert isinstance(CLIArgs({'a': 1}), CLIArgs)
    assert isinstance(CLIArgs({'a': 1, 'b': [1, 2, 3]}), CLIArgs)
    assert isinstance(CLIArgs({'m': {'a': 1, 'b': [1, 2, 3]}}), CLIArgs)
    # And that it should be immutable
    try:
        CLIArgs({'m': {'a': 1, 'b': [1, 2, 3]}})['m']['a'] = '5'
        assert False
    except TypeError:
        pass

# Generated at 2022-06-23 13:54:23.598086
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test1(with_metaclass(_ABCSingleton, object)):
        pass

    class Test2(with_metaclass(_ABCSingleton, object)):
        pass

    t = Test1()

# Generated at 2022-06-23 13:54:34.162374
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    print('test_GlobalCLIArgs')
    import argparse
    parser = argparse.ArgumentParser(description='fake args')

    # Set up some command line arguments which will go into the CLIArgs
    parser.add_argument('--fake_bool')
    parser.add_argument('--fake_list', nargs='+')
    parser.add_argument('--fake_int', type=int)

    # Not actually parsing args, just making a namespace
    fake_args = parser.parse_args([])

    # Save the CLIArgs
    GlobalCLIArgs.store(CLIArgs.from_options(fake_args))

    # Load the CLIArgs and make sure that we have a GlobalCLIArgs
    loaded_args = GlobalCLIArgs.load()
    assert isinstance(loaded_args, GlobalCLIArgs)
    assert isinstance

# Generated at 2022-06-23 13:54:36.453159
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    temp = {}



# Generated at 2022-06-23 13:54:43.325862
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    my_args = {'foo': 'bar', 'bar': 'baz', 'baz': 'foo'}
    c = CLIArgs(my_args)
    assert c.foo == 'bar'
    assert c.bar == 'baz'
    assert c.baz == 'foo'
    assert c.get('foo') == 'bar'
    assert 'foo' in c
    assert c['foo'] == 'bar'
    assert c.get('f', 'default') == 'default'

# Generated at 2022-06-23 13:54:51.570929
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import os
    import tempfile

    # Create a fake options object
    options = type(str('FakeOptions'), (object,), {})
    options.verbosity = 3

    # Add fake options to a global variable
    global_cli_args = GlobalCLIArgs.from_options(options)

    # Make sure the class is immutable by trying to modify it
    try:
        global_cli_args['verbosity'] = 1
    except TypeError:
        pass
    else:
        assert False, "GlobalCLIArgs is not immutable"

    # Create some test files and directories
    basedir = tempfile.mkdtemp(dir=os.path.dirname(os.path.abspath(__file__)))

# Generated at 2022-06-23 13:54:53.100031
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({'a': 'b'})

# Generated at 2022-06-23 13:54:56.153252
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():  # pylint: disable=function-redefined
    class TestClass(_ABCSingleton):
        pass
    assert isinstance(TestClass(), TestClass)

# Generated at 2022-06-23 13:54:59.504185
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Unit test for constructor of class _ABCSingleton"""
    class TestSingletonClass(object):
        """Valid test singleton class"""
        __metaclass__ = _ABCSingleton

    assert isinstance(TestSingletonClass(), TestSingletonClass)

# Generated at 2022-06-23 13:55:05.494673
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    results = CLIArgs.from_options(dict(a=1, b=2, c=3, d=4))
    assert isinstance(results, CLIArgs)
    assert isinstance(results, ImmutableDict)
    assert 'a' in results
    assert 'a' in results
    assert 'b' in results
    assert 'c' in results
    assert 'd' in results
    assert results['a'] == 1
    assert results['b'] == 2
    assert results['c'] == 3
    assert results['d'] == 4

# Generated at 2022-06-23 13:55:14.389390
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import assertRaisesRegex
    from ansible.module_utils.common.parameters import _make_immutable
    from ansible import constants
    i = _make_immutable(constants.__dict__)
    assert isinstance(i, Mapping)
    assertRaisesRegex(ValueError, 'Not a MutableMapping', lambda: i['BECOME_ASK_PASS'])

# Generated at 2022-06-23 13:55:17.920768
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'one': 1, 'two': 2, 'three': 3}
    args = CLIArgs(test_dict)
    assert args['one'] == 1
    assert args['two'] == 2
    assert args['three'] == 3

# Generated at 2022-06-23 13:55:24.988361
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.config.parser import ConfigParser
    from ansible.cli.arguments import option_helpers as opt_help

    # Normal argument for test
    cli_args = opt_help.get_base_parser()
    parser = ConfigParser(cli_args, os.environ["ANSIBLE_CONFIG"])
    options = parser.parse_args([])
    _test_mutable_option(options)

    # Make sure we have a clean copy
    gc.collect()
    # Sanity check to make sure we really do have only one object of this class
    # This one is just to make sure we get an id of the object.
    cli_args.add_argument('-i', action="store", dest='inventory', help='inventory host path')

# Generated at 2022-06-23 13:55:26.188768
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    x = GlobalCLIArgs.from_options({})

# Generated at 2022-06-23 13:55:35.620744
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # The constructor converts the dict in the object passed in to an
    # ImmutableDict.  We can verify this by checking that the ImmutableDict
    # constructor allows shallow copying but not deep copying.  But we are
    # cheating here because we are assigning to a variable that hides
    # the variable in the GlobalCLIArgs object so we can use the same variable
    # name.
    from ansible.module_utils.common._collections_compat import ImmutableDict
    from copy import copy
    x = ImmutableDict({'a':1})
    y = copy(x)
    z = copy(y)
    y['b'] = [1]
    z['c'] = ['hello']
    y = z
    z['d'] = ['goodbye']
    y = GlobalCLIArgs({'a':1})
   

# Generated at 2022-06-23 13:55:46.586929
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    class B(A):
        pass
    class C(A):
        pass

    assert issubclass(B, A)
    assert issubclass(C, A)
    assert issubclass(C, B)
    assert issubclass(A, object)
    assert issubclass(B, object)
    assert issubclass(C, object)

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert B() is not A()
    assert C() is not B()
    assert A() is not C()

# Generated at 2022-06-23 13:55:48.654299
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class options(object):
        a = 1
    args = CLIArgs.from_options(options)
    assert args['a'] == 1



# Generated at 2022-06-23 13:55:53.104632
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyABCSingleton(metaclass=_ABCSingleton):
        pass

    class MyABCSingletonSubclass(MyABCSingleton):
        pass

    assert isinstance(MyABCSingleton(), MyABCSingletonSubclass)

# Generated at 2022-06-23 13:55:59.097257
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    empty = {}

    # Both GlobalCLIArgs are the same object
    args1 = GlobalCLIArgs(empty)
    args2 = GlobalCLIArgs.from_options(empty)
    assert args1 == args2
    assert args1 is args2
    assert args1.__class__ == GlobalCLIArgs

    # However, it's not the same as non-singleton CLIArgs
    args3 = CLIArgs(empty)
    assert args1 != args3
    assert args1 is not args3
    assert args1.__class__ != args3.__class__

# Generated at 2022-06-23 13:56:01.892646
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABCWithABCSingleton(object):
        __metaclass__ = _ABCSingleton

    # We can't instantiate an ABCMeta class.
    # Crash here if the singleton or ABCMeta code is wrong.
    TestABCWithABCSingleton()

# Generated at 2022-06-23 13:56:06.753675
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Make sure that we have a class which unites the methods of ABCMeta and Singleton
    """
    class _TestABCSingleton(object):
        __metaclass__ = _ABCSingleton
    assert hasattr(_TestABCSingleton, '__init__')
    assert hasattr(_TestABCSingleton, '__call__')

# Generated at 2022-06-23 13:56:16.950645
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # The GlobalCLIArgs new function is just a pass through to make_immutable
    # that is the easy test to do so do it
    test_container = {
        'list': [1, 2, 3, 4],
        'tuple': (1, 2, 3, 4),
        'dict': {'list': [1, 2, 3, 4], 'tuple': (1, 2, 3, 4)},
        'set': {1, 2, 3, 4},
        'binary': b"binary",
        'text': "text"
    }

# Generated at 2022-06-23 13:56:26.619042
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-23 13:56:35.277818
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    args = {'ANSIBLE_CONFIG': "/tmp/nonexistent.cfg"}
    cli_args = CLIArgs(args)

    # make sure the CLIArgs are indeed immutable
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args, Container)
    if not hasattr(__builtins__, "__setattr__"):
        # Python3.7+ uses __setattr__ as the default metaclass.
        # We can't mutate cli_args or else the test will error
        # as it tries to mutate a frozen class
        pass
    else:
        try:
            cli_args.ANSIBLE_CONFIG = '/tmp/nonexistent_new.cfg'
        except TypeError as e:
            pass

# Generated at 2022-06-23 13:56:38.056976
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    mapped = {"foo": "bar"}
    obj = GlobalCLIArgs(mapped)
    assert obj == mapped

# Unit tests for __new__ of class GlobalCLIArgs

# Generated at 2022-06-23 13:56:43.581274
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class D(object):
        __metaclass__ = _ABCSingleton
    d = D()
    e = D()
    assert d is e
    assert issubclass(D, object)
    # assert issubclass(object, D)  # this is True in python2 but not in python3

# Generated at 2022-06-23 13:56:46.030400
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object, metaclass=_ABCSingleton):
        pass

    t1 = Test()
    t2 = Test()

    assert t1 is t2

# Generated at 2022-06-23 13:56:50.719974
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        def __init__(self, server):
            self.server = server

    options = Options("localhost")
    cli_args = CLIArgs(vars(options))
    assert("server" in cli_args)
    assert("server" in cli_args.keys())
    assert("server" in cli_args.attr_names())
    assert("localhost" == cli_args.get("server"))


# Generated at 2022-06-23 13:56:52.905414
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Concrete(_ABCSingleton):
        def _init_instance(self, *args, **kwargs):
            pass
    assert Concrete() is Concrete()

# Generated at 2022-06-23 13:56:55.157364
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    obj = GlobalCLIArgs({'some_key': 'some_val'})
    assert type(obj) is GlobalCLIArgs
    assert obj['some_key'] == 'some_val'



# Generated at 2022-06-23 13:56:59.131321
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.argparser import GlobalCLIArgs as orig_args
    args = CLIArgs(vars(orig_args))

    assert isinstance(args, CLIArgs)
    for key, value in vars(orig_args).items():
        assert args[key] is value
    assert args.keys() == vars(orig_args).keys()
    assert set(args.keys()) == set(vars(orig_args).keys())


# Generated at 2022-06-23 13:57:11.806193
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    The constructor of class abc.ABCMeta does not call the constructor
    of Singleton.  So it is worth having a test to just make sure ABCMeta
    is still called as expected.
    """
    # pylint: disable=too-few-public-methods
    class SingletonSubclass(Singleton):
        @classmethod
        def defined_but_not_implemented(cls):
            """
            This method is just to help us check that the SingletonSubclass
            is not actually a Singleton.
            """
            raise NotImplementedError

    class ABCMetaSubclass(SingletonSubclass, ABCMeta):
        pass

    # This should fail because the SingletonSubclass is not a singleton

# Generated at 2022-06-23 13:57:20.466688
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # This is the first time the singleton has been created.  It will be created as a dict
    x = GlobalCLIArgs()
    assert isinstance(x, dict)

    # A second call will return the same object as before
    y = GlobalCLIArgs()
    assert x == y

    # Make sure no one can replace the singleton with a new dict
    with pytest.raises(TypeError) as excinfo:
        GlobalCLIArgs.__new__(dict)
        assert 'GlobalCLIArgs cannot be instantiated' in str(excinfo.value)

# Generated at 2022-06-23 13:57:23.687532
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(_ABCSingleton, object):
        pass

    class B(_ABCSingleton, object):
        pass

    test_a = A()
    test_b = B()

    # Verify that we can have multiple types of singleton objects
    assert test_a is not test_b

# Generated at 2022-06-23 13:57:33.011193
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test case: empty CLIArgs
    assert CLIArgs({'a': 'b'})._dictionary == {'a': 'b'}

    # Test case: CLIArgs with a list
    assert CLIArgs({'a': [1, 2, 3], 'b': 'c'})._dictionary == {'a': (1, 2, 3), 'b': 'c'}

    # Test case: CLIArgs with a set
    assert CLIArgs({'a': {1, 2, 3}, 'b': 'c'})._dictionary == {'a': frozenset({1, 2, 3}), 'b': 'c'}

    # Test case: CLIArgs with a nested set

# Generated at 2022-06-23 13:57:41.004536
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Simple cases
    args = CLIArgs({'a':1, 'b':2, 'c':3})
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, Mapping)
    assert isinstance(args, Container)
    assert args['a'] == 1
    assert args['b'] == 2
    assert args['c'] == 3
    assert not isinstance(args.keys(), Container)
    assert not isinstance(args.values(), Container)
    assert not isinstance(args.items(), Container)

    # Nested dictionary
    args = CLIArgs({'a':1, 'b':2, 'c':{'d':4, 'e':5}})
    assert isinstance(args['c'], ImmutableDict)
    assert args['c']['d'] == 4

# Generated at 2022-06-23 13:57:43.858432
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class TestClass(object, metaclass=_ABCSingleton):
        pass

    # Instantiate a class using a metaclass
    instance = TestClass()
    assert isinstance(instance, TestClass)

# Generated at 2022-06-23 13:57:46.534190
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    assert A() is A()
    assert B() is B()

# Generated at 2022-06-23 13:57:54.509890
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    # start with an empty option parser
    parser = argparse.ArgumentParser()

    # add options
    parser.add_argument('--test1', action='store_true', help="Test 1")
    parser.add_argument('--test2', action='store_true', help="Test 2")
    parser.add_argument('--test3', default='test3', help="Test 3")
    parser.add_argument('--test4', default='test4', help="Test 4")
    parser.add_argument('--test5', dest='list', action='append',
                        default=['test5a'], help="Test 5")

    # grab the options
    options = parser.parse_args(args=sys.argv[1:])

    # create the singleton
    cli_args = Global

# Generated at 2022-06-23 13:58:03.781547
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {
        'integer': 1,
        'string': 'foo',
        'list': ['bar', 'baz'],
        'dictionary': {'bar': 'baz', 'list': ['foo']},
    }
    copy_mapping = mapping.copy()
    test_object = CLIArgs(mapping)

    for key, value in test_object.items():
        assert isinstance(value, (text_type, binary_type, ImmutableDict, tuple, frozenset))

    for key, value in copy_mapping.items():
        assert isinstance(value, (text_type, binary_type, Mapping, Sequence, Set))

# Generated at 2022-06-23 13:58:15.299422
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import json
    import collections
    from six.moves import configparser

    args = CLIArgs(dict(a=list(range(10)), b=dict(one=1, two=2), c=set("123456")))
    other_args = CLIArgs(dict(a=list(range(5)), b=dict(one=1, two=2), c=set("123456")))

    assert args is not other_args, "Other args is immutable"
    assert args['c'] is not other_args['c'], "Other args is immutable"
    assert args['a'] is not other_args['a'], "Other args is immutable"
    assert args['b'] is not other_args['b'], "Other args is immutable"
    assert args['b']['one'] == other_args['b']['one'] == 1

# Generated at 2022-06-23 13:58:17.547712
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():  # noqa: F811
    class Test(object):
        __metaclass__ = _ABCSingleton

    assert isinstance(Test(), Test)

# Generated at 2022-06-23 13:58:19.188809
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # test initialization of GlobalCLIArgs
    GlobalCLIArgs({})
    GlobalCLIArgs.from_options(None)

# Generated at 2022-06-23 13:58:26.818206
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    def change_args(args):
        args['changed'] = True

    args = {'a': 1, 'b': 2}
    cli_args = GlobalCLIArgs(args)
    assert cli_args['a'] == 1
    assert cli_args['b'] == 2
    try:
        change_args(cli_args)
        assert False, "GlobalCLIArgs should be immutable"
    except TypeError:
        assert True, "Cannot change cli_args"

# Generated at 2022-06-23 13:58:31.475607
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert isinstance(CLIArgs({"test1": 1, "test2": ["test", 123, "test"]}), CLIArgs)
    assert isinstance(GlobalCLIArgs({"test1": 1, "test2": ["test", 123, "test"]}), GlobalCLIArgs)

# Generated at 2022-06-23 13:58:39.613195
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Tests that this is a singleton.
    a = GlobalCLIArgs({'a': {'b': 'c'}})
    b = GlobalCLIArgs({'a': {'b': 'c'}})
    assert a is b
    # Tests that we create an ImmutableDict
    try:
        a['a'] = 'b'
        assert False
    except:
        assert True
    # Tests that we create an ImmutableDict recursively
    try:
        # We have to access the subdictionary inside the ImmutableDict in a very particular way
        # because it attaches a __setattr__ to the normal way of accessing keys in a dict.
        a._dict['a']['b'] = 'd'
        assert False
    except:
        assert True

# Generated at 2022-06-23 13:58:41.048166
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common import CLIARGS
    assert CLIARGS == {}

# Generated at 2022-06-23 13:58:50.556419
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Introduce a temporary Command Line Interface (CLI) parser to provide test values for CLIArgs.
    from ansible.parsing.cli import CLI
    from ansible.errors import AnsibleError

    parser = CLI.base_parser(
        usage='%(prog)s [options]',
        desc="Ansible Standalone Provisioner",
        epilog='Read the Ansible Documentation for more info.',
        env_vars_supported=True,
        become_methods=['sudo', 'su', 'pbrun', 'pfexec', 'runas', 'doas'],
        deprecate_become=True,
    )

    # The CLI parser needs to have a mutually-exclusive group defined for each global command line
    # option in the plugin, so it can parse the command line arguments.  The common Ansible code


# Generated at 2022-06-23 13:58:55.166343
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            self.foo = 0
        def bar(self):
            self.foo += 1

    foo = Foo()
    foo.bar()

    foo2 = Foo()
    assert foo == foo2
    assert foo2.foo == 1

# Generated at 2022-06-23 13:59:06.711680
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from .common import Options
    from .common import CLICommon
    from .common import RawCLIArgs

    options = Options(args=RawCLIArgs([]))
    options.add_value_option(*options._lower_option_names['vault-password-file'])
    options.add_value_option(*options._lower_option_names['list-hosts'])
    options.add_value_option(*options._lower_option_names['list-tasks'])
    options.add_value_option(*options._lower_option_names['list-tags'])
    options.add_value_option(*options._lower_option_names['syntax-check'])
    options.parse()

    options.vault_password_files = ['test.txt']
    options.listhosts = True
    options.listt

# Generated at 2022-06-23 13:59:15.218751
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Instantiate a GlobalCLIArgs object and then try to get a second instance.  The second instance
    should be the same instance as the first.
    """
    import copy
    import os
    import ansible.constants
    import ansible.module_utils.common.arguments
    import ansible.utils.args
    import ansible.utils.module_docs

    expected_version = ansible.constants.VERSION
    expected_config_file = os.path.expanduser(ansible.constants.DEFAULT_CONFIG_FILE)
    expected_subdir = ansible.constants.DEFAULT_ROLES_PATH
    expected_paths = ansible.constants.DEFAULT_MODULE_PATH.split(os.pathsep)
    parser = ansible.module_utils.common.arguments.Arg

# Generated at 2022-06-23 13:59:24.156716
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.display import Display
    import json

    options = Display()
    options.verbosity = 2
    options.json = False
    options.extra_vars = {u'ansible_python_interpreter': u'/usr/bin/python'}
    options.connection = u'ssh'
    options.module_path = None
    options.trees = []
    options.timeout = 10
    options.forks = 5
    options.ask_pass = False
    options.private_key_file = None
    options.remote_user = None
    options.ssh_common_args = None
    options.ssh_extra_args = None
    options.sftp_extra_args = None
    options.scp_extra_args = None
    options.become = False
    options.become_method

# Generated at 2022-06-23 13:59:25.534430
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({'k1': 'v1', 'k2': 'v2'})

# Generated at 2022-06-23 13:59:26.858624
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {'test': {'nested': {}}}
    cli_args = CLIArgs(args)

# Generated at 2022-06-23 13:59:36.660130
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.module_utils.common.collections import is_immutable

    arg_dict = {'test_list': [1, 2, 3], 'test_dict': {'test_key': 'test_value'}, 'test_str': 'testval'}
    GCA = GlobalCLIArgs
    GCA._instances = {}
    GCA.from_options = lambda x: GCA(vars(x))

    GCA.from_options.dict = arg_dict
    global_cli_args = GCA.from_options(GlobalCLIArgs.from_options)

    # Check types match in outer dict
    for key, value in arg_dict.items():
        assert isinstance(value, type(getattr(global_cli_args, key)))

    # Check immutable types in outer dict
   

# Generated at 2022-06-23 13:59:43.206251
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import types

    map = dict(a='b')
    subsubmap = dict(c='d')
    submap = dict(e=map, f=subsubmap)
    map['g'] = submap
    args = CLIArgs(map)
    assert isinstance(args, CLIArgs)
    assert args['a'] == 'b'
    assert args['g']['e']['a'] == 'b'
    assert args['g']['f']['c'] == 'd'

    # we should not be able to modify the map through the CLIArgs object.
    args['a'] = 'c'
    assert args['a'] == 'b'
    args['g']['e']['a'] = 'c'
    assert args['g']['e']['a'] == 'b'
    args

# Generated at 2022-06-23 13:59:47.943479
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    name = 'test'
    value = 'value'
    test_dict = {
        name: value,
    }
    test_args = CLIArgs.from_options(test_dict)
    assert test_dict[name] == value
    assert test_dict[name] == test_args[name]
    assert test_dict == test_args

# Generated at 2022-06-23 13:59:51.714610
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # using a module global as a singleton is not allowed, assert that it can't be done
    class M(ImmutableDict, metaclass=_ABCSingleton):
        pass
    try:
        M()
        assert False  # the constructor should have raised an exception
    except TypeError:
        pass

# Generated at 2022-06-23 13:59:54.942632
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class DummyClass(object):
        __metaclass__ = _ABCSingleton
        def __init__(self):
            self.foo = 1

    assert DummyClass.__abstractmethods__ == set()

# Generated at 2022-06-23 13:59:59.505685
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingletonExample(_ABCSingleton):
        def __init__(self):
            self.example = 'example'

    class ExtendedExample(SingletonExample):
        pass

    a = SingletonExample()
    b = SingletonExample()
    assert a == b
    assert b.example == a.example
    a.example = 'example2'
    assert b.example == a.example

    c = ExtendedExample()
    d = ExtendedExample()
    assert c == d
    assert d.example == c.example
    c.example = 'example2'
    assert d.example == c.example


# Generated at 2022-06-23 14:00:05.108451
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'a': 'b', 'c': (1, 2, 3)}
    args = CLIArgs(mapping)
    assert args['a'] == 'b'
    assert args['c'] == (1, 2, 3)
    assert isinstance(args['c'], tuple)



# Generated at 2022-06-23 14:00:10.326749
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {
        'ANSIBLE_MODULE_ARGS': {
            'one': 'two',
            'three': 4,
            'five': {
                'seven': 8
            }
        }
    }

    assert isinstance(CLIArgs(args), ImmutableDict)
    assert isinstance(GlobalCLIArgs(args), ImmutableDict)

# Generated at 2022-06-23 14:00:13.046719
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(A):
        pass

    assert isinstance(A(), A)
    assert isinstance(B(), A)
    assert isinstance(A(), B)

# Generated at 2022-06-23 14:00:18.365018
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Instantiate a new object of class CLIArgs
    cli_args = CLIArgs({'a': 'b'})
    assert isinstance(cli_args, CLIArgs)
    assert cli_args['a'] == 'b'

# Generated at 2022-06-23 14:00:21.672518
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = ImmutableDict(global_warnings=False, debug=False)
    args = GlobalCLIArgs.from_options(options)
    assert args == options

# Generated at 2022-06-23 14:00:30.898908
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import copy
    import os
    from datetime import datetime
    from pprint import pprint

    def dindex_get(d, i):
        # Helper function for accessing dictionary items without fear of KeyError
        return d[i] if i in d else None

    def to_datetime(ts):
        # Convert unix timestamps to datetime
        return datetime.utcfromtimestamp(ts)

    def to_iso(ts):
        # Convert unix timestamps to iso string
        return to_datetime(ts).isoformat()

    # Create the original data

# Generated at 2022-06-23 14:00:33.953905
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton):
        pass

    f1 = Foo()
    f2 = Foo()
    assert f1 is f2

# Generated at 2022-06-23 14:00:43.431961
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli.arguments import AnsibleCLIArguments
    from ansible.cli import CLI
    cli = CLI(args=['-i', 'localhost,'])
    parser = AnsibleCLIArguments()
    cli.options = parser.parse_args(cli.args, assert_need_root=False)
    global_cli_args = GlobalCLIArgs.from_options(cli.options)
    assert isinstance(global_cli_args, GlobalCLIArgs)
    assert 'inventory' in global_cli_args.keys()
    assert 'localhost,' == global_cli_args['inventory']
    assert hasattr(global_cli_args, 'inventory')

# Generated at 2022-06-23 14:00:53.735039
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():  # pragma: no cover
    class _AbstractSingleton(_ABCSingleton):
        __slots__ = ()

        def __init__(self):
            pass

    class _ConcreteSingleton(_AbstractSingleton):
        __slots__ = ()

        def __init__(self):
            super(_ConcreteSingleton, self).__init__()

    class _AnotherConcreteSingleton(_AbstractSingleton):
        __slots__ = ()

        def __init__(self):
            super(_AnotherConcreteSingleton, self).__init__()

    assert _ConcreteSingleton() is _ConcreteSingleton()
    assert _AnotherConcreteSingleton() is _AnotherConcreteSingleton()
    assert _ConcreteSingleton() is not _AnotherConcreteSingleton()

# Generated at 2022-06-23 14:00:56.855174
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        __metaclass__ = _ABCSingleton

    x = A()
    y = A()
    assert x == y

    z = B()
    assert z != x
    assert z == y

# Generated at 2022-06-23 14:01:07.045580
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils import basic

    # set up argv to avoid getopt error
    basic._ANSIBLE_ARGS = ImmutableDict({'ANSIBLE_MODULE_DEBUG': '', 'ANSIBLE_MODULE_ARGS': ''})

    # set up fake command line args

# Generated at 2022-06-23 14:01:19.187171
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # This one should get converted to be immutable
    simple_dict = {'a': 'b', 'c': 'd'}
    # This one should get converted to be immutable
    nested_dict = {'a': 'b', 'c': {'d': {'e': 'f'}}}
    # This one should get converted to be immutable
    nested_list = [1, 'a', {'b': 'c'}]
    # This one should get converted to be immutable
    nested_set = {1, 'a', {'b': 'c'}}
    # String literal
    simple_str = 'test'
    # Test constructor with no arguments
    test = CLIArgs({})
    assert len(test) == 0

    # Test constructor with a simple dictionary
    test = CLIArgs(simple_dict)

# Generated at 2022-06-23 14:01:22.289979
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABC(object):
        __metaclass__ = _ABCSingleton

    test_1 = TestABC()
    test_2 = TestABC()

    assert test_1 == test_2

# Generated at 2022-06-23 14:01:30.984353
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from unittest import mock
    import copy

    with mock.patch.object(Singleton, '__new__', lambda c, *args, **kwargs: mock.Mock()):
        class A(metaclass=_ABCSingleton):
            pass
        a_instance_1 = A()
        a_instance_2 = A()
        assert a_instance_1 == a_instance_2

    # verify that ABCMeta has copied over
    with mock.patch.object(Singleton, '__new__', lambda c, *args, **kwargs: mock.Mock()):
        class A(metaclass=_ABCSingleton):
            pass
        assert isinstance(A(), A)
        assert not isinstance(object(), A)

    # verify that Singleton has copied over

# Generated at 2022-06-23 14:01:35.276788
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Verify that the GlobalCLIArgs class is working as expected."""
    args = GlobalCLIArgs(dict(a=1, b=2, c=dict(d=3), e=[4, 5, 6]))
    assert isinstance(args, CLIArgs)



# Generated at 2022-06-23 14:01:41.943751
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    m = {'a': 1, 'b': 2, 'c': {1: 'a', 2: 'b'}, 'd': [1, 2, 3]}
    x = CLIArgs(m)
    assert x['a'] == 1
    assert x['b'] == 2
    assert x['c'][1] == 'a'
    assert x['c'][2] == 'b'
    assert x['d'][0] == 1
    assert x['d'][1] == 2
    assert x['d'][2] == 3


# Generated at 2022-06-23 14:01:53.119372
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest

    import ansible.module_utils.common.argparse as argparse

    # We take the system command line args and parse them through the
    # existing argparse parser to get into the form that we want

    parser = argparse.common_parser(desc="Test GlobalCLIArgs",
                                    usage="Test GlobalCLIArgs")

    options, args = parser.parse_known_args(sys.argv)
    global_args = GlobalCLIArgs.from_options(options)

    # Make sure that the resulting object is immutable.
    # You can't test for the "immutable" interface directly, so try
    # to mutate it and catch the exception raised.
    try:
        global_args['foo'] = 'bar'
    except TypeError:
        pass

# Generated at 2022-06-23 14:02:02.945081
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.module_utils.common.argparse import default_arg_spec
    from ansible.module_utils.common.argparse import module_args_spec
    from ansible.module_utils.common.argparse import module_deprecation_warning_spec
    from ansible.module_utils.get_extra_vars import get_extra_vars
    import ansible.module_utils.common.argparse_module as argparse_module
    import ansible.module_utils.common.argparser_loader as argparser_loader
    import ansible.module_utils.common.ansible_arg_spec as ansible_arg_spec

    # These keys are in the ImmutableDict that goes into the GlobalCLIArgs

# Generated at 2022-06-23 14:02:07.441307
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.display import Display
    from ansible.errors import AnsibleError
    from ansible.utils.vars import combine_vars

    display = Display()
    vars = combine_vars(loader=None, vault_password=None, all_vars=None, play=None, include_defaults=False)

    try:
        GlobalCLIArgs(None)
    except AnsibleError as e:
        print(e)
        display.error('Invalid options parsed')



# Generated at 2022-06-23 14:02:09.614937
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    a1 = A()
    assert a1
    a2 = A()
    assert a2 is a1
    assert a1 is A()

# Generated at 2022-06-23 14:02:20.271408
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingletonABC(metaclass=_ABCSingleton):
        pass

    class NonSingletonABC(metaclass=_ABCSingleton):
        def __new__(cls, *args, **kwargs):
            raise RuntimeError("This is a singleton, the constructor should not have been called")

    class SingletonABC2(SingletonABC):
        pass

    class NonSingletonABC2(NonSingletonABC):
        pass

    class NonSingletonOverridesSingleton(SingletonABC):
        def __new__(cls, *args, **kwargs):
            raise RuntimeError("This is a singleton, the constructor should not have been called")

    class SingletonOverridesSingleton(SingletonABC2):
        pass

    class NonSingletonOverridesNonSingleton(NonSingletonABC2):
        pass



# Generated at 2022-06-23 14:02:30.914081
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import pytest
    from ansible.utils.vars import combine_vars
    args = CLIArgs(combine_vars(loader=None, variables=dict(foo='bar')))
    with pytest.raises(AttributeError):
        args.foo = 'something'

    # checking only immutablemapping properties
    assert args.get('foo') == 'bar'
    assert args.keys() == ['foo']
    assert args.values() == ['bar']
    assert args.items() == [('foo', 'bar')]
    assert args.pop('foo', None) == None
    assert args.popitem() == None
    assert args.setdefault('foo', 'baz') == 'bar'



# Generated at 2022-06-23 14:02:31.712008
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({'foo': 'bar'})

# Generated at 2022-06-23 14:02:33.568301
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(metaclass=_ABCSingleton):
        """docstring"""

    assert TestClass.__doc__ == 'docstring'

# Generated at 2022-06-23 14:02:35.880177
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    actual = CLIArgs({'A': 1, 'B': [1, 'A', {'C': 2}]})
    expected = {'A': 1, 'B': (1, 'A', {'C': 2})}
    assert actual == expected

# Generated at 2022-06-23 14:02:36.873595
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, type)

# Generated at 2022-06-23 14:02:42.197164
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Validate that class CLIArgs can accept an input and return the same result."""
    test_input = {
        'host_key_checking': True,
        'update_cache': True,
        'verbosity': 3
    }
    test_output = CLIArgs(test_input)

    assert test_output == test_input

# Generated at 2022-06-23 14:02:53.402123
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    temp = CLIArgs({'a': text_type('value1'),
                    'b': {'b1': text_type('value2'),
                          'b2': text_type('value3')},
                    'c': [{'c1': text_type('value4')},
                          {'c2': text_type('value5')}]})
    assert temp['a'] == text_type('value1')
    assert temp['b']['b1'] == text_type('value2')
    assert temp['b']['b2'] == text_type('value3')
    assert temp['c'][0]['c1'] == text_type('value4')
    assert temp['c'][1]['c2'] == text_type('value5')
    assert temp['b']['b1'] == GlobalCL

# Generated at 2022-06-23 14:03:04.216419
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    import sys

    # Only run unit test for python 3 or greater
    if sys.version_info < (3, 0):
        return

    args = {'forks': 5, 'verbose': True}
    banned_types = (collections.MutableMapping, collections.MutableSequence, collections.MutableSet)
    cli_args = CLIArgs(args)

    # args should be deep copied and made immutable
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args['verbose'] is True
    assert cli_args['forks'] == 5

    # Test that the constructor made everything immutable

# Generated at 2022-06-23 14:03:12.341187
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.text.converters import to_bytes

    # Test that a single immutabledict is returned
    immutable_dict = CLIArgs(dict(a=1, b='foo'))
    assert isinstance(immutable_dict, ImmutableDict)
    assert immutable_dict == dict(a=1, b='foo')

    # Test that nested immutabledict is returned
    immutable_dict = CLIArgs(dict(a=1, b=dict(foo=1)))
    assert isinstance(immutable_dict.get('b'), ImmutableDict)
    assert immutable_dict == dict(a=1, b=dict(foo=1))

    # Test that nested immutable objects are returned

# Generated at 2022-06-23 14:03:13.468938
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyNewClass(object):
        __metaclass__ = _ABCSingleton
    my_new_class = MyNewClass()


# Generated at 2022-06-23 14:03:15.727008
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs()
    assert global_cli_args


# Generated at 2022-06-23 14:03:23.162172
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Make sure that GlobalCLIArgs is Singleton

    Test the singleton nature of GlobalCLIArgs by ensuring that we can't
    create a second instance of GlobalCLIArgs.
    """

    # Create first instance of GlobalCLIArgs
    gcliargs = GlobalCLIArgs(dict())

    # Create second instance of GlobalCLIArgs
    try:
        gcliargs2 = GlobalCLIArgs(dict())
    except RuntimeError:
        pass
    else:
        raise AssertionError("Second instance of GlobalCLIArgs created")

# Generated at 2022-06-23 14:03:26.374631
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(TestClass(), TestClass)


# Generated at 2022-06-23 14:03:30.178633
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class First(_ABCSingleton):
        pass
    class Second(_ABCSingleton):
        pass
    class Third(_ABCSingleton):
        pass
    foo = First()
    bar = Second()
    assert(foo is not bar)
    baz = First()
    assert(foo is baz)



# Generated at 2022-06-23 14:03:37.480444
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    This function is used to test the constructor of class CLIArgs
    """
    cli_args = _make_immutable(dict(var1=dict(var2=dict(var3=['test', 'test1', 'test2']), var4=['test', 'test1', 'test2']), var5=dict(var6=dict(var7=['test', 'test1', 'test2']))))
    result = CLIArgs(cli_args)
    assert cli_args == result

# Generated at 2022-06-23 14:03:42.226668
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    TODO: Remove this test when all the imports are removed.

    This is a test to ensure that the class GlobalCLIArgs is not instantiated outside of the expected
    singleton pattern.
    """
    import pytest
    GlobalCLIArgs.reset()
    with pytest.raises(Exception) as excinfo:
        x = GlobalCLIArgs()
    assert 'Cannot create instance of GlobalCLIArgs outside the get_instance method' in str(excinfo.value)
    assert 'Call GlobalCLIArgs.reset() to avoid' in str(excinfo.value)

# Generated at 2022-06-23 14:03:48.019459
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Dummy1(object):
        __metaclass__ = _ABCSingleton

    class Dummy2(Dummy1):
        pass

    assert isinstance(Dummy1(), Dummy1)
    assert isinstance(Dummy1(), Dummy2)
    assert isinstance(Dummy2(), Dummy1)
    assert isinstance(Dummy2(), Dummy2)

# Generated at 2022-06-23 14:03:56.361628
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # pylint: disable=no-self-argument,protected-access
    class Foo():
        def __init__(self):
            pass

    # dict
    data = {
        'foo': 'bar',
        'baz': 'blah',
        'lorem': {
            'ipsum': 'dolor',
        },
        'seq': [1, 2, 3, 4, 5],
        'set': [1, 2, 3, 4, 5, 4, 3, 2, 1],
        'obj': object(),
        'fooobj': Foo()
    }

    # test constructor
    args = CLIArgs(data)

    # verify none of the data is modifiable

# Generated at 2022-06-23 14:04:02.804270
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # pylint: disable=too-few-public-methods

    @add_metaclass(_ABCSingleton)
    class A(object):  # pylint: disable=too-few-public-methods
        pass

    assert issubclass(A, Singleton)
    assert issubclass(A, ABCMeta)
    assert not issubclass(A, object)
    assert A.__mro__ == (A, Singleton, ABCMeta, object)