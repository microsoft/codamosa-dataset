

# Generated at 2022-06-23 13:54:04.602858
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    try:
        GlobalCLIArgs({'foo': 'bar'})
        assert False, 'We should have had an exception'
    except TypeError:
        pass

    try:
        GlobalCLIArgs.from_options(ImmutableDict())
        assert False, 'We should have had an exception'
    except TypeError:
        pass


if __name__ == '__main__':
    test_GlobalCLIArgs()

# Generated at 2022-06-23 13:54:14.327848
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = {
        'one': {
            'two': {
                'three': [1, 2, 3],
                'four': {
                    'five': True,
                    'six': False,
                    'seven': (1, 2, 3)
                },
                'eight': 'abc'
            },
            'nine': range(3)
        }
    }
    # Try to clobber the internal data
    args['one']['two']['three'].append(4)
    args['one']['two']['four']['seven'] = [4, 5, 6]
    args['one']['nine'] = range(4)

    # Give it to the GlobalCLIArgs constructor and make sure it is not modified
    GlobalCLIArgs(args)

# Generated at 2022-06-23 13:54:18.915181
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = GlobalCLIArgs({'a': '1'})
    assert a['a'] == '1'
    # test for immutability
    try:
        a['b'] = '2'
    except Exception:
        pass
    else:
        assert False, "GlobalCLIArgs is not immutable"



# Generated at 2022-06-23 13:54:30.020525
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class MyOptions():
        def __init__(self):
            self.opt1 = 1
            self.opt2 = "a"
            self.opt3 = [1,2,3,4]
            self.opt4 = {"a": [1,2,3], "b": {"c": [1,2,3,4]}}

    my_options = MyOptions()
    import copy
    my_copy = copy.deepcopy(vars(my_options))
    delattr(my_options, "opt2")

    GlobalCLIArgs.from_options(my_options)
    assert GlobalCLIArgs.instance.opt1 == my_copy["opt1"]
    assert GlobalCLIArgs.instance.opt3 == my_copy["opt3"]

# Generated at 2022-06-23 13:54:39.684386
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {
        'some_str': 'Some string',
        'some_bool': True,
        'some_nested': {
            'foo': 'bar',
            'foos': ['bar1', 'bar2', 'bar3'],
            'bars': {
                'bar1': 'foo1',
                'bar2': 'foo2',
                'bar3': 'foo3'
            }
        }
    }
    cli_args = CLIArgs(args)
    assert cli_args == args
    assert cli_args['some_nested'] == args['some_nested']
    assert cli_args['some_nested']['foos'] == args['some_nested']['foos']
    assert cli_args['some_nested']['foos'][1]

# Generated at 2022-06-23 13:54:42.635410
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(A(), A)
    assert isinstance(A(), _ABCSingleton)

# Generated at 2022-06-23 13:54:47.591254
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class DummyABCSingleton(object):
        __metaclass__ = _ABCSingleton

    class DummyABCSingleton2(DummyABCSingleton):
        pass

    assert issubclass(DummyABCSingleton, Singleton)
    assert issubclass(DummyABCSingleton, ABCMeta)
    assert issubclass(DummyABCSingleton2, Singleton)
    assert issubclass(DummyABCSingleton2, ABCMeta)

# Generated at 2022-06-23 13:54:57.282985
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = ImmutableDict({'a': {'b': [{'c': 'd'}, {'e': 'f'}], 'g': 'h'}, 'i': {'j': {'k': 'l'}}})
    cli_args = CLIArgs(args)
    assert args == cli_args
    assert args['a'] == cli_args['a']
    assert isinstance(cli_args['a'], ImmutableDict)
    assert args['a']['b'] == cli_args['a']['b']
    assert isinstance(cli_args['a']['b'], tuple)
    assert args['a']['b'][0] == cli_args['a']['b'][0]

# Generated at 2022-06-23 13:55:04.144742
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils.common.collections import OrderedDict

    _ABCSingleton.reset()

    with open("testdict.txt", "w") as f_testdict:
        testdict = OrderedDict(a=1, b=2)
        f_testdict.write("testdict = {}".format(testdict))

    from ansible.module_utils.common import load_module_from_file

    testdict = load_module_from_file("testdict", "testdict.txt")

    class ABC_Singleton_Test(object):
        __metaclass__ = _ABCSingleton
        def __init__(self, arg):
            self.arg = arg

    a = ABC_Singleton_Test(testdict)
    b = ABC_Singleton_Test(testdict)


# Generated at 2022-06-23 13:55:08.430820
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyABCSingleton(_ABCSingleton):
        pass
    # tests that MyABCSingleton is a metaclass and can be used to create new classes
    class TestClass(MyABCSingleton):
        pass
    assert TestClass

# Generated at 2022-06-23 13:55:17.112032
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class CLIArgsSubClass(CLIArgs):
        def __init__(self, mapping):
            # pylint: disable=non-parent-init-called
            super(CLIArgsSubClass, self).__init__(mapping)

    assert isinstance({'data': CLIArgsSubClass({1: 1})}, ImmutableDict), 'CLIArgs should inherits from ImmutableDict'
    assert isinstance({'data': CLIArgsSubClass({1: 1})['data']}, ImmutableDict), 'CLIArgs should inherits from ImmutableDict'

# Generated at 2022-06-23 13:55:21.175847
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = GlobalCLIArgs({'one': 1, 'two': 2, 'three': 3})
    assert isinstance(a, GlobalCLIArgs)
    assert a == {'one': 1, 'two': 2, 'three': 3}
    assert a == GlobalCLIArgs({'one': 1, 'two': 2, 'three': 3})

# Generated at 2022-06-23 13:55:25.528294
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass

    assert isinstance(A(), A)
    assert not isinstance(A(), B)
    assert isinstance(B(), B)



# Generated at 2022-06-23 13:55:31.748296
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = {
        "tags": set(["t1", "t2"]),
        "listhosts": False
    }
    a = GlobalCLIArgs(args)
    assert a["listhosts"] == False
    assert a["tags"] == set(["t1", "t2"])
    a["listhosts"] = True
    try:
        a["listhosts"] = False
    except TypeError:
        pass
    else:
        assert False, "Assigning to key in immutable dict should fail"

# Generated at 2022-06-23 13:55:36.685878
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    import argparse
    global_parser = argparse.ArgumentParser(description="foobar")
    global_parser.add_argument('--foo', action='store', dest='foo')
    global_args = global_parser.parse_args(['--foo=bar'])
    global_cli_args = GlobalCLIArgs.from_options(global_args)

    assert global_cli_args == {'foo': 'bar'}

# Generated at 2022-06-23 13:55:49.055533
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    # Test that non-strings are immutable and strings are not
    mapping = {'a': [1, 2],
               'b': (1, 2),
               'c': {'a': 'test', 'b': ['test']},
               'd': frozenset(),
               'e': 'test'}
    cli_args = CLIArgs(mapping)
    assert cli_args == mapping
    assert type(cli_args['a']) == tuple
    assert type(cli_args['b']) == tuple
    assert type(cli_args['c']) == ImmutableDict
    assert type(cli_args['c']['b']) == tuple
    assert type(cli_args['d']) == frozenset
    assert type(cli_args['e']) == text_type

    # Test string keys too
   

# Generated at 2022-06-23 13:55:51.236495
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class Test(_ABCSingleton):
        pass

    assert Test() is Test()

    class Test2(_ABCSingleton):
        def __init__(self):
            pass

    assert Test2() is Test2()

# Generated at 2022-06-23 13:56:00.399426
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    _d = {'list': [1,2,3,4],
          'dict': {'a': 1, 'b': 2},
          'int': 42,
          'set': set([1,2,3,4]),
          'list_of_dicts': [{'list': [1,2,3,4],
                             'dict': {'a': 1, 'b': 2},
                             'int': 42,
                             'set': set([1,2,3,4])},
                            {'list': [5,6,7,8],
                             'dict': {'c': 3, 'd': 4},
                             'int': 43,
                             'set': set([5,6,7,8])},
                            ],
          }
    obj = CLIArgs(_d)


# Generated at 2022-06-23 13:56:08.738198
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Make sure that we have a metaclass which can unambiguously combine ABCMeta and Singleton

    We want ABCMeta to always win because it adds methods to the class dictionary and Singleton
    adds a lot of values into the __dict__ of the class object.
    """
    class TestABCSingleton(_ABCSingleton):
        """Test class for _ABCSingleton"""

    class TestABCMeta(TestABCSingleton, metaclass=ABCMeta):
        """Subclass of TestABCSingleton with ABCMeta as a metaclass"""
        pass

    assert TestABCMeta.__mro__ == (TestABCMeta, object, TestABCSingleton, ABCMeta, object)

# Generated at 2022-06-23 13:56:19.664213
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import ansible.module_utils.facts.system.distribution as distro


# Generated at 2022-06-23 13:56:20.900419
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        pass

    Test()
    Test()

# Generated at 2022-06-23 13:56:22.107337
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton):
        pass

    class Bar(_ABCSingleton):
        pass

    assert Foo is not Bar

# Generated at 2022-06-23 13:56:30.683799
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingletonA(metaclass=_ABCSingleton):
        pass
    class SingletonB(metaclass=_ABCSingleton):
        pass
    class TooManySingletons(SingletonA, SingletonB):
        pass

    assert issubclass(TooManySingletons, SingletonA)
    assert issubclass(TooManySingletons, SingletonB)
    try:
        TooManySingletons()
        assert False
    except RuntimeError:
        pass

# Generated at 2022-06-23 13:56:33.734359
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    string = "foo"
    options = {'name': string}
    target = GlobalCLIArgs(options)
    assert target['name'] == string


# Generated at 2022-06-23 13:56:41.242798
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # pylint: disable=unused-variable
    class Base(object):
        __metaclass__ = _ABCSingleton

        def __init__(self, thing):
            self.thing = thing

    class Sub(Base):
        def __init__(self, thing, other):
            super(Sub, self).__init__(thing)
            self.other = other

    a = Sub(1, 2)
    b = Sub(3, 4)

    assert a is b
    assert a.thing == 1
    assert a.other == 2

# Generated at 2022-06-23 13:56:44.274357
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class X(object):
        __metaclass__ = _ABCSingleton
    class Y(X):
        pass
    assert X() == X()
    assert X() == Y()
    assert Y() == X()

# Generated at 2022-06-23 13:56:50.820778
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    foo_dict = {'foo': 'bar', 'foobar': {'bar': 'baz'}, 'foobars': [{'bar': 'baz'}, 'bar', 'baz']}
    cli_args = CLIArgs(foo_dict)
    assert isinstance(cli_args, Mapping)
    assert cli_args == foo_dict
    assert isinstance(cli_args['foobar'], ImmutableDict)
    assert isinstance(cli_args['foobars'], tuple)
    assert isinstance(cli_args['foobars'][0], ImmutableDict)


# Generated at 2022-06-23 13:56:58.179137
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a_key': 'a_value', 'key_2': {'a': 5, 'b': 7}, 'key_3': [1, 2, 3]})

    # We need to test that a new object was created from the args passed.  So test
    # the _internal is a different object than the args which was passed.
    assert args._internal is not args

    # Test that the object has the correct structure
    assert args._internal == {'a_key': 'a_value', 'key_2': frozenset([('a', 5), ('b', 7)]), 'key_3': (1, 2, 3)}

    # Test that the object is immutable
    try:
        args['key_2'] = 'a_value'
    except TypeError:
        assert True
    else:
        assert False



# Generated at 2022-06-23 13:57:00.040424
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(_ABCSingleton):
        pass

    a = TestClass()
    b = TestClass()
    assert a is b

# Generated at 2022-06-23 13:57:05.526085
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    cliargs = dict(foo="bar", baz=2, quux=True)

    try:
        #pylint: disable=no-member
        GlobalCLIArgs.load(cliargs)
    except AttributeError:
        pass
    assert GlobalCLIArgs(cliargs) is GlobalCLIArgs.get_instance

# Generated at 2022-06-23 13:57:10.655058
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(metaclass=_ABCSingleton):
        pass

    a = A()
    b = B()
    assert a is A()
    assert b is B()
    assert a is not b


# Generated at 2022-06-23 13:57:15.060724
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton(_ABCSingleton):
        def __init__(self):
            pass
    class TestSingleton2(_ABCSingleton):
        def __init__(self):
            pass
    assert TestSingleton() is TestSingleton()
    assert TestSingleton2() is TestSingleton2()
    assert not TestSingleton() is TestSingleton2()

# Generated at 2022-06-23 13:57:21.780454
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    raw_args = {'varterm': {'something': '3', 'boolean': True, 'things': [1, 2, 3]}, 'verbose': False, 'debug': '2'}
    expected_args = {'varterm': {'something': '3', 'boolean': True, 'things': (1, 2, 3)}, 'verbose': False, 'debug': '2'}
    actual_args = CLIArgs(raw_args)
    assert expected_args == actual_args

# Generated at 2022-06-23 13:57:22.315178
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    pass

# Generated at 2022-06-23 13:57:31.764677
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from unittest import mock

    globals = {
        'ANSIBLE_MODULE_ARGS': {'foo': 'bar'},
        'ANSIBLE_MODULE_UTILS': {}
    }
    options = mock.MagicMock()
    options.__dict__ = {'foo': 'bar'}

    original_GlobalCLIArgs = GlobalCLIArgs
    GlobalCLIArgs = GlobalCLIArgs._create(globals)

    mock_from_options = mock.Mock(return_value={'foo': 'bar'})

    with mock.patch('ansible.module_utils.common.cli.CLIArgs.from_options', mock_from_options):
        args = GlobalCLIArgs.from_options(options)

    assert args == {'foo': 'bar'}

# Generated at 2022-06-23 13:57:33.236062
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    cli_args = ["ansible", "--no-log"]
    args = GlobalCLIArgs(cli_args)
    assert args["no_log"]


# Generated at 2022-06-23 13:57:35.593859
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        pass

    assert TestClass is not _ABCSingleton(TestClass)

# Generated at 2022-06-23 13:57:46.740285
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-23 13:57:57.802368
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test ImmutableDict behaviour
    a = CLIArgs({'a': '1', 'b': {'b1': 2}, 'c': [3, 4]})
    assert a['a'] == '1'
    assert a['b']['b1'] == 2
    assert a['c'][0] == 3
    assert a['c'][1] == 4

    # Test error handling
    try:
        a['b']['b2'] = 3
        raise RuntimeError('CLIArgs does not handle nested data structures properly')
    except TypeError:
        pass

    try:
        a['d'] = 5
        raise RuntimeError('CLIArgs does not handle nested data structures properly')
    except TypeError:
        pass


# Generated at 2022-06-23 13:58:06.255415
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # empty cli arguments
    instance1 = GlobalCLIArgs({})
    instance2 = GlobalCLIArgs({})
    assert instance1 is instance2
    # single cli argument
    instance1 = GlobalCLIArgs({"foo": "bar"})
    instance2 = GlobalCLIArgs({"foo": "bar"})
    assert instance1 is instance2
    # multiple cli arguments
    instance1 = GlobalCLIArgs({"foo": "bar", "baz": "qux"})
    instance2 = GlobalCLIArgs({"baz": "qux", "foo": "bar"})
    assert instance1 is instance2


# Generated at 2022-06-23 13:58:17.446791
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import collections
    import copy
    import unparsed_cli_args
    import helper_functions
    import sys

    # Unparsed CLI args to parse
    options = unparsed_cli_args.Options()

    # Set options.  __init__() in class Options created no attributes, so we have to do it.
    options.unparsed_cli_args = ('ansible-playbook',
                                 '--syntax-check',
                                 '--inventory', 'inventory-file',
                                 '--extra-vars', '{"a": "b"}',
                                 '--tags', 'tag1,tag2,tag3')

    # Call parse_args() for command line option
    options.parse_args()

    # Save copy of --extra-vars and --tags
    extra_vars = copy.deep

# Generated at 2022-06-23 13:58:18.756760
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(_ABCSingleton):
        pass

    assert A() is A()

# Generated at 2022-06-23 13:58:29.470950
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Ensure that only one of the class GlobalCLIArgs exists and that the single instance
    is immutable.
    """

    # Create GlobalCLIArgs instances
    global_cli_args_1 = GlobalCLIArgs({'answer': 42})
    global_cli_args_2 = GlobalCLIArgs({'answer': 42})

    assert global_cli_args_1 is global_cli_args_2
    assert global_cli_args_1 == {'answer': 42}
    assert not hasattr(global_cli_args_1, '__setitem__')
    assert not hasattr(global_cli_args_1, '__delitem__')
    assert not hasattr(global_cli_args_1, 'update')

# Generated at 2022-06-23 13:58:34.999921
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class X(object):
        __metaclass__ = _ABCSingleton

    class Y(X):
        pass
    a = X()
    b = X()
    try:
        Y()  # should get TypeError trying to instantiate a subclass of _ABCSingleton
        assert(False)
    except TypeError:
        pass
    assert(a is b)


# Generated at 2022-06-23 13:58:37.438820
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    try:
        GlobalCLIArgs.from_options({})
    except Exception as error:
        assert False, 'error: %s' % error
    assert True

# Generated at 2022-06-23 13:58:38.975413
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs({})

# Generated at 2022-06-23 13:58:42.941386
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Class1(metaclass=_ABCSingleton):
        pass

    class Class2(Class1):
        pass

    assert isinstance(Class2(), Class2)
    assert len(set(Class2.__mro__)) == len(Class2.__mro__)
    assert Class1 is Class2

# Generated at 2022-06-23 13:58:49.540632
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # A metaclass will be created in class declaration and
    # save to __metaclass__ attribute
    metaclass = _ABCSingleton
    assert metaclass.__metaclass__ == ABCMeta, "__metaclass__ should be ABCMeta"

    class A(object):
        __metaclass__ = metaclass

    assert isinstance(A(), A), "A() should be an instance of A"

    a1 = A()
    a2 = A()
    assert a1 is a2, "a1 and a2 should be the same object"

# Generated at 2022-06-23 13:58:52.852748
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # check if cliargs is of class CLIArgs
    cliargs = CLIArgs({'a': 'b', 'c': [1, 2], 'd': {'e': 'f'}})
    assert isinstance(cliargs, CLIArgs)
    # check if cliargs is immutable
    assert isinstance(cliargs, ImmutableDict)

# Generated at 2022-06-23 13:59:04.805270
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    
    # The CLIArgs.__init__() function creates a dictionary that maps 
    # the command line arguments to their values. The dictionary
    # is immutable.
    
    # If dict is empty, then get_ansible_module_kwargs() will return
    # an empty dict.
    a = CLIArgs({})
    assert a.get_ansible_module_kwargs() == {}
    
    # Regular dict must be converted to an immutable dict
    b = CLIArgs({'a':'A', 'b':'B'})
    assert isinstance(b, ImmutableDict)
    assert isinstance(b.get_ansible_module_kwargs(), ImmutableDict)

# Generated at 2022-06-23 13:59:10.786128
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import pytest
    args = {'a': 1, 'b': 2}
    cli_args = CLIArgs(args)
    assert cli_args.__class__ is CLIArgs

    # CLIArgs is immutable
    with pytest.raises(TypeError):
        cli_args['a'] = 3
    assert 'a' in cli_args
    assert cli_args['a'] == 1

    # CLIArgs has containers as immutable as well
    args['c'] = {'d': 3, 'e': 4}
    cli_args = CLIArgs(args)
    assert cli_args.__class__ is CLIArgs
    with pytest.raises(TypeError):
        cli_args['c']['d'] = 5
    assert 'd' in cli_args['c']
    assert cli

# Generated at 2022-06-23 13:59:19.308888
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that we can construct an instance of CLIArgs, and that it will prevent modifications

    Make sure the instance is built, and that it cannot be modified after it is constructed.
    """
    from ansible_collections.testns.testcoll.plugins.module_utils.test_utils.compat import (  # noqa: F401
        unittest,
    )

    class TestCLIArgs(unittest.TestCase):
        def test_make_immutable(self):
            test_dict = {
                'foo': 'bar',
                'baz': ['spam', 'eggs']
            }
            test_input = {
                'some_input': test_dict,
                'more_input': test_dict['baz']
            }

# Generated at 2022-06-23 13:59:20.963082
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Test can create instance of GlobalCLIArgs"""
    args = GlobalCLIArgs(dict())

# Generated at 2022-06-23 13:59:32.056322
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    long = 'a long string'
    short = 'short'
    temp_dict = {'some': {long: {'long': 'dict', 'values': [long, short]}, short: short}, 'thing': [long, short], short: short}
    cli_args = CLIArgs(temp_dict)

    # need to check that all the strings are immutable, then the dicts and then lists
    assert isinstance(temp_dict[short], text_type)
    assert isinstance(temp_dict[short], text_type)

    for long_string in long, temp_dict[long]['long'], temp_dict[short]:
        assert isinstance(long_string, text_type)
        assert not isinstance(long_string, (Mapping, Sequence, Set))


# Generated at 2022-06-23 13:59:33.831164
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli.arguments import options
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-23 13:59:39.085729
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton
        def __init__(self):
            self.x = 1

    class Bar(object):
        __metaclass__ = _ABCSingleton
        def __init__(self, x):
            self.x = x

    assert Foo().x == 1
    assert Foo.instance().x == 1
    assert Bar(2).x == 2
    assert Bar.instance().x == 2

# Generated at 2022-06-23 13:59:46.642956
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # pylint: disable=abstract-class-instantiated
    class Single(object):
        """
        Singleton class for testing _ABCSingleton
        """
        __metaclass__ = _ABCSingleton
        def __init__(self, value=None):
            self.value = value
    # pylint: enable=abstract-class-instantiated

    instance1 = Single()
    instance2 = Single()

    assert instance1 is instance2

# Generated at 2022-06-23 13:59:53.806315
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # noinspection PyMissingConstructor
    class A:
        __metaclass__ = _ABCSingleton

    # noinspection PyMissingConstructor
    class B:
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert not A() is B()
    assert isinstance(A(), object)
    assert isinstance(B(), object)

# Generated at 2022-06-23 14:00:03.006969
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A1(object):
        pass

    assert A1() is A1()
    assert issubclass(A1, Singleton)

    class A2(A1):
        pass

    assert A2() is A2()
    assert A2() is not A1()

    class B1(object):
        __metaclass__ = _ABCSingleton
        pass

    assert B1() is B1()
    assert issubclass(B1, Singleton)
    assert issubclass(B1, ABCMeta)

    class B2(B1):
        pass

    assert B2() is B2()
    assert B2() is not B1()
    assert issubclass(B2, B1)


# Generated at 2022-06-23 14:00:10.054578
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs({'hosts': 'localhost', 'private-key': '~/my_key'})
    print(cli_args['private-key'])  # ~/my_key
    try:
        cli_args['private-key'] = '~/my_other_key'
    except:
        print('Error: CLIArgs is ImmutableDict')
    else:
        raise Exception('Fail: CLIArgs is NOT ImmutableDict')

# Generated at 2022-06-23 14:00:17.457008
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestMeta(metaclass=_ABCSingleton):
        pass
    class TestMeta2(metaclass=_ABCSingleton):
        pass
    a = TestMeta()
    b = TestMeta()
    assert a is b, "_ABCSingleton classes should be singletons"
    c = TestMeta2()
    d = TestMeta2()
    assert c is d, "_ABCSingleton classes should be singletons"

# Generated at 2022-06-23 14:00:24.956127
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class B(object):
        __metaclass__ = _ABCSingleton
        pass

    class D(B):
        pass

    class E(D):
        pass

    assert issubclass(B, Singleton)
    assert issubclass(B, ABCMeta)
    assert issubclass(D, Singleton)
    assert issubclass(D, ABCMeta)
    assert issubclass(E, Singleton)
    assert issubclass(E, ABCMeta)

# Generated at 2022-06-23 14:00:26.771309
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(B):
        pass

    assert A() == B() == C() == A()

# Generated at 2022-06-23 14:00:29.517654
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({'a': 1, 'b': 2, 'c': {1, 2, 3}, 'd': [1, 2, 3]}) == {'a': 1, 'b': 2, 'c': {1, 2, 3}, 'd': (1, 2, 3)}


# Generated at 2022-06-23 14:00:35.615322
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Alpha(object):
        __metaclass__ = _ABCSingleton

    class Beta(Alpha):
        pass

    class Gamma(Alpha):
        pass

    assert(Alpha() == Alpha())
    assert(isinstance(Alpha(), Alpha))
    assert(Alpha() != Beta())
    assert(Alpha() != Gamma())
    assert(Alpha() != object())

# Generated at 2022-06-23 14:00:45.389798
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    arg_mapping = {
        'string': 'a_string',
        'list': ['a_list'],
        'tuple': ('a_tuple'),
        'dict': {'a_key': 'a_value'},
        'mixed_level': {
            'mixed_key': [
                'a_list',
                'string',
                ('a_tuple'),
                {'tuple_key': [
                    'a_list',
                    'string'
                ]}
            ]
        },
        'set': {'a_key', 'a_value'}
    }

    args = CLIArgs(arg_mapping)
    assert args == arg_mapping
    assert isinstance(args.string, text_type)
    assert isinstance(args.list, tuple)
    assert isinstance

# Generated at 2022-06-23 14:00:47.946516
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(metaclass=_ABCSingleton):
        def __init__(self):
            pass

    Test()

# Generated at 2022-06-23 14:00:57.820579
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test this class as if it were a program but in a pythonic way
    """
    from ansible.parsing.vault import VaultLib
    from ansible.utils import plugin_docs


# Generated at 2022-06-23 14:01:05.701762
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mutable_mapping = {
        'key1': 'value1',
        'key2': {
            'key2.1': 'value2.1'
        },
        'key3': [
            'list item1',
            'list item2',
            'list item3'
        ]
    }

    args = CLIArgs(mutable_mapping)

    assert args['key1'] == 'value1'
    assert args['key2']['key2.1'] == 'value2.1'
    assert set(args['key3']) == set(('list item1', 'list item2', 'list item3'))

    # this should fail because the class is immutable

# Generated at 2022-06-23 14:01:13.167319
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class FakeOptions:
        def __init__(self, options):
            for key, value in options.items():
                self.__setattr__(key, value)

    options = FakeOptions({'check': False, 'other': 'option'})

    args = GlobalCLIArgs.from_options(options)

    assert isinstance(args, ImmutableDict)
    assert args['check'] is False
    assert args['other'] == 'option'

# Generated at 2022-06-23 14:01:23.916730
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Test that CLIArgs correctly makes immutable datastructures"""
    import types
    import copy

    test_dict = {
        'some_key': 'some_value',
        'some_list': ['a', 'b', 'c'],
        'some_tuple': ('a', 'b', 'c'),
        'some_dict': {'some_key': 'some_value', 'some_list': ['a', 'b', 'c'], 'some_tuple': ('a', 'b', 'c')},
        'some_set': {'a', 'b', 'c'},
    }
    test_seq = ['a', 'b', 'c']
    test_string = 'abc'
    test_bytes = b'abc'

    # Test mutable data types (strings, bytes and primitives)

# Generated at 2022-06-23 14:01:26.090121
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    assert Foo() is Foo()

# Generated at 2022-06-23 14:01:35.994305
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from collections import namedtuple
    from ansible.utils import context_objects as co
    import types
    import pdb
    #pdb.set_trace()
    class Options(object):
        def __init__(self, **args):
            self.args = args
            for key, value in args.items():
                if not key.startswith("__"):
                    setattr(self, key, value)
        def __getitem__(self, key):
            return self.args[key]
        def __iter__(self):
            return iter(self.args)
        def __len__(self):
            return len(self.args)
        def _getattr_(self, name):
            return getattr(self.args, name)

# Generated at 2022-06-23 14:01:46.462225
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'one': 'two', 'three': {'four': 'five'}, 'six': [7, 8, 9]}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict
    assert test_args['three']['four'] == 'five'
    assert test_args['six'][1] == 8
    assert isinstance(test_args, dict)
    assert not isinstance(test_args, ImmutableDict)
    assert isinstance(test_dict['three'], dict)
    assert not isinstance(test_dict['three'], Mapping)
    assert isinstance(test_dict['six'], list)
    assert not isinstance(test_dict['six'], Sequence)

# Generated at 2022-06-23 14:01:55.166261
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.args_env import values_from_env

    a = {'abc': 'A', 'def': 'B'}
    cli_args = CLIArgs(a)
    assert cli_args.abc == 'A'

# Generated at 2022-06-23 14:01:56.944126
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Base(_ABCSingleton):
        pass

    class Subclass(Base):
        pass

# Generated at 2022-06-23 14:02:02.798479
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.config.data import ConfigData
    from ansible.cliconf.parsers import TaskParser

    def get_options():
        configuration = ConfigData(parser=TaskParser(vars={})).get_configuration_data()
        return configuration

    options = get_options()
    args = GlobalCLIArgs.from_options(options)

    assert args is GlobalCLIArgs()
    assert args == GlobalCLIArgs()
    assert args == CLIArgs(vars(options))

    _assert_immutable(args)



# Generated at 2022-06-23 14:02:04.174499
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _TestClass(_ABCSingleton):
        pass

    assert _TestClass is _TestClass()

# Generated at 2022-06-23 14:02:14.480760
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import tempfile
    import ansible_test._internal.test_utils
    import ansible_test.data
    import ansible.utils.vars
    import ansible.config

    #  Test the private method _make_immutable()
    sequence = [1, 2, 3]
    mapping = {'a': 1, 'b': 2, 'c': 3}
    obj = [sequence, mapping]
    immutable_obj = _make_immutable(obj)
    assert isinstance(immutable_obj, tuple)
    assert isinstance(immutable_obj[0], tuple)
    assert isinstance(immutable_obj[1], ImmutableDict)

    # Run the module under test to populate the GlobalCLIArgs object
    # with test data
    args = ansible_test._internal.test_utils.Argv.from_

# Generated at 2022-06-23 14:02:15.944815
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({'test': 1})['test'] == 1

# Generated at 2022-06-23 14:02:16.503485
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    x = GlobalCLIArgs.from_options(None)

# Generated at 2022-06-23 14:02:23.302761
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.release import __version__
    from ansible.utils.color import stringc
    from ansible.cli import CLI

    ansible_args = ['ansible', '--version']
    cli = CLI(ansible_args)
    # call load_cli_opts method to load options and args.
    cli.load_cli_opts()
    options = cli.get_options()
    # Assert that ansible --version returns __version__ value
    assert options.version == __version__
    cli_args = CLIArgs.from_options(options)
    # Assert that CLIArgs object is created with version value
    assert cli_args['version'] == stringc(__version__, 'green')

# Generated at 2022-06-23 14:02:29.836310
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = vars(GlobalCLIArgs.create_singleton())
    assert(len(args) == 0)
    args['options'] = 1234
    GlobalCLIArgs.create_singleton(args)
    args = vars(GlobalCLIArgs.create_singleton())
    assert(len(args) == 1)
    assert(args['options'] == 1234)



# Generated at 2022-06-23 14:02:34.767138
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyABCSingleton(object, metaclass=_ABCSingleton):
        pass

    class MyABCSingleton2(object, metaclass=_ABCSingleton):
        pass

    assert isinstance(MyABCSingleton(), MyABCSingleton)
    assert isinstance(MyABCSingleton2(), MyABCSingleton2)
    assert not isinstance(MyABCSingleton(), MyABCSingleton2)
    assert not isinstance(MyABCSingleton2(), MyABCSingleton)

# Generated at 2022-06-23 14:02:42.197203
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    options = type('options', (object,), dict(foo=42, bar=None, baz={'a': 'a'}, qux=[True, 2.0, 'three']))
    args = CLIArgs.from_options(options)
    assert args['foo'] == 42
    assert args['bar'] is None
    assert args['baz'] == {'a': 'a'}
    assert args['qux'] == (True, 2.0, 'three')

# Generated at 2022-06-23 14:02:46.596263
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Ensure GlobalCLIArgs can actually hold arbitrary data
    """
    data = {'foo': 'bar',
            'baz': ['quam', 'quux', 'quuz'],
            'corge': {'grault': 'garply'}}
    data_after_ctor = _make_immutable(data)
    args = GlobalCLIArgs(data)

    assert args == data_after_ctor

# Generated at 2022-06-23 14:02:50.988018
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs({})
    assert isinstance(global_cli_args, GlobalCLIArgs)
    assert isinstance(global_cli_args, ImmutableDict)
    assert isinstance(global_cli_args, Mapping)

# Generated at 2022-06-23 14:03:02.616809
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({'a': 1, 'b': "foo"}) == {'a': 1, 'b': 'foo'}

    assert CLIArgs({'a': [1, 2, 3]}) == {'a': (1, 2, 3)}
    assert CLIArgs({'a': (1, 2, 3)}) == {'a': (1, 2, 3)}
    assert CLIArgs({'a': {'b': 3, 'c': 4}}) == {'a': {'b': 3, 'c': 4}}
    assert CLIArgs({'a': {'b': {'c': 4}}}).a == ImmutableDict({'b': ImmutableDict({'c': 4})})

# Generated at 2022-06-23 14:03:08.748464
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest
    from ansible.utils.cliargs import GlobalCLIArgs

    class TestCLIArgs(unittest.TestCase):
        def test_cliargs_is_immutable_dict(self):
            self.assertEqual(immutable_dict_to_string(GlobalCLIArgs), 'GlobalCLIArgs: {}\n')

    def immutable_dict_to_string(immutable_dict):
        old_stdout = sys.stdout
        try:
            sys.stdout = StringIO()
            print(immutable_dict)
            return sys.stdout.getvalue().strip()
        finally:
            sys.stdout = old_stdout

    unittest.main(verbosity=0)

# Generated at 2022-06-23 14:03:19.453362
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton):
        pass

    class Bar(_ABCSingleton):
        pass

    # Singleton classes can only be defined one time
    try:
        class Foo(_ABCSingleton):
            pass
        assert False
    except TypeError:
        pass

    class Foo(_ABCSingleton):
        def __init__(self):
            self.foo = 'foo'

    # Singleton classes have a single instance
    foo_instance_1 = Foo()
    foo_instance_2 = Foo()
    assert foo_instance_1 is foo_instance_2

    # Singleton classes use the first defined init method

# Generated at 2022-06-23 14:03:22.501531
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 1, 'b': 2})
    assert isinstance(args, CLIArgs)
    # test for immutability
    assert isinstance(args, ImmutableDict)
    assert isinstance(args.items(), Mapping)

# Generated at 2022-06-23 14:03:32.685266
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import pytest

    testargs = {
        'a': 1,
        'b': True,
        'c': 'this is a string',
        'd': [1, 'a', True, [1, 2, 3]],
        'e': {'a': 1, 'b': 'j', 'c': [1, 2, 3]},
        'f': set([1, 2, 3]),
        'g': {'a': {'b': set([1, 2, 3])}, 'z': 'abcd'},
    }
    args = CLIArgs(testargs)

    for key, value in testargs.items():
        assert args[key] == value

    with pytest.raises(TypeError):
        args['a'] = 2
    with pytest.raises(TypeError):
        args['a']

# Generated at 2022-06-23 14:03:40.869879
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    temp_dict = {'a': 'b',
                 'c': [1, 2, 3],
                 'd': {'e': [1, 2, 3], 'f': 'g'}}
    temp_immutable_dict = {'a': 'b',
                           'c': (1, 2, 3),
                           'd': ImmutableDict({'e': (1, 2, 3), 'f': 'g'})}
    temp_cli_args = CLIArgs(temp_dict)
    assert temp_cli_args == temp_immutable_dict

# Generated at 2022-06-23 14:03:52.492900
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 'test', 'b': {'c': 'test2', 'd': 3}, 'e': ['test3', 4]}
    text_str_dict = {'a': b'test', 'b': {'c': b'test2', 'd': 3}, 'e': (b'test3', 4)}
    binary_str_dict = {'a': text_type('test'), 'b': {'c': text_type('test2'), 'd': 3}, 'e': (text_type('test3'), 4)}
    cli_args = CLIArgs(test_dict)
    assert(cli_args.a == test_dict['a'])
    assert(isinstance(cli_args.b, ImmutableDict))
    assert(isinstance(cli_args.e, tuple))

# Generated at 2022-06-23 14:04:04.092950
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        pass
    options = Options()
    options.foo = {}
    options.foo['bar'] = ['baz']
    options.foo['bar'].append('hello')
    options.foo['bar'].append('world')
    options.one = 'two'
    options.three = ('four', 'five')
    options.six = {'seven': 'eight'}
    options.six.update({'nine': 'ten'})
    options.eleven = ['twelve']
    options.eleven.append('thirteen')
    options.eleven.append('fourteen')
    options.eleven.append('fifteen')
    options.sixteen = ['seventeen']
    options.sixteen.append('eighteen')
    options.sixteen.append('nineteen')
    options.six