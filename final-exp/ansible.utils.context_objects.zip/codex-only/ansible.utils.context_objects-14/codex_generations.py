

# Generated at 2022-06-23 13:54:01.359877
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        pass
    t = Test()
    t = Test()

# Generated at 2022-06-23 13:54:06.696693
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    sys.argv = []
    args = GlobalCLIArgs({'some': 'thing'})
    # Catch error if __init__ is called again
    cls = GlobalCLIArgs
    cls.__init__ = None
    args = cls({'some': 'thing'})

# Generated at 2022-06-23 13:54:12.532302
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Pass
    a = {'a': '1'}
    b = {'b': '2'}
    c = CLIArgs(dict(a, **b))
    assert c.get('a') == '1'
    assert c.get('b') == '2'
    # Fail
    try:
        c['b'] = '3'
    except TypeError as e:
        assert 'ImmutableDict object does not support item assignment' in str(e)

# Generated at 2022-06-23 13:54:16.560512
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Use one of the many different ways to test for a class being 'named' as a Singleton
    # TODO: Make this into a unit test as soon as we can figure out how to do so
    assert not GlobalCLIArgs.registered_objects

# Generated at 2022-06-23 13:54:24.507497
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SetSingleton(object):
        __metaclass__ = _ABCSingleton
        
        def __init__(self, *args):
            self.vals = set(args)
    
        def __len__(self):
            return len(self.vals)
    
        def __contains__(self, element):
            return element in self.vals
    
    
    s = SetSingleton(1, 2, 3)
    s.vals.add(4)
    
    t = SetSingleton(4, 5, 6)
    
    if len(s) != 4:
        raise Exception('Test failed')
    if len(t) != 3:
        raise Exception('Test failed')

# Generated at 2022-06-23 13:54:26.494869
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_map = {'x': 'y'}
    cli_args = CLIArgs(test_map)
    assert cli_args == test_map



# Generated at 2022-06-23 13:54:32.405020
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from collections import namedtuple

    namespace = {}
    ABCSingleton = _ABCSingleton('ABCSingleton', (object,), namespace)
    class_ = ABCSingleton('Foo', (), {})
    print(class_)
    print(check_singleton(class_))
    instance = class_()
    print(instance)
    print(check_singleton(instance))

    # Check that assigned attributes are stored in instances
    class_.test_attribute = 1
    assert(instance.test_attribute == 1)

    # Check that attributes can be overriden in instances
    instance.test_attribute = 2
    assert(instance.test_attribute == 2)
    assert(class_.test_attribute != 2)

    # Check that instance of class is instance of Singleton
    assert(isinstance(instance, Singleton))

# Generated at 2022-06-23 13:54:41.125110
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {"key1": [1, 2, 3], "key2": {"key3": "val"}, "key4": {"key5": {"key6": [4, 5, 6]}}}
    result = CLIArgs(test_dict)
    assert "key6" in result["key4"]["key5"]
    assert isinstance(result["key4"]["key5"], ImmutableDict)
    assert isinstance(result["key4"]["key5"]["key6"], Sequence)
    assert isinstance(result["key4"], ImmutableDict)
    assert isinstance(result["key2"], ImmutableDict)
    assert isinstance(result["key1"], Sequence)

if __name__ == '__main__':
    import pytest
    pytesttest_CLIArgs()

# Generated at 2022-06-23 13:54:44.021831
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ABCSingleton(object):
        __metaclass__ = _ABCSingleton

    assert isinstance(ABCSingleton(), ABCSingleton)

_global_cli_args = {}


# Generated at 2022-06-23 13:54:44.878407
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton):
        pass

# Generated at 2022-06-23 13:54:47.067823
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton(object):
        __metaclass__ = _ABCSingleton
        pass

    assert TestSingleton is TestSingleton()

# Generated at 2022-06-23 13:54:54.127547
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # pylint: disable=protected-access
    args = {"async": 123, "verbosity": 3}
    GlobalCLIArgs._instance = None
    GlobalCLIArgs._instance = GlobalCLIArgs(args)

# Generated at 2022-06-23 13:55:04.622798
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    input = {
        "s": "abc",
        "d": {
            "k": "v",
            "ka": "va",
        },
        "l": [
            "e1",
            "e2",
        ],
        "set": {
            "e",
            "f",
        },
    }

    args = CLIArgs(input)

    assert args["s"] == "abc"
    assert isinstance(args["d"], ImmutableDict)
    assert args["d"]["k"] == "v"
    assert args["d"]["ka"] == "va"
    assert isinstance(args["l"], tuple)
    assert args["l"][0] == "e1"
    assert args["l"][1] == "e2"

# Generated at 2022-06-23 13:55:12.050790
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # create a dictionary
    mapping = {'a': 1, 'b': 2, 'c': 3, 'd': {'e': 4, 'f': [5, 6]}}
    # Create immutable copy of the mapping
    mapping2 = CLIArgs(mapping)
    assert mapping2 == mapping
    # Verify that access is the same
    assert mapping2['a'] == mapping['a']


# Generated at 2022-06-23 13:55:22.060484
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Bunch(object):
        def __init__(self, **kwds):
            self.__dict__.update(kwds)
    temp_args = GlobalCLIArgs.from_options(Bunch(
        connection='ssh',
        module_path='/tmp/',
        forking=10,
        private_key_file=['a', 'b'],
        other_args=Bunch(become=True, become_user='bob')))

    a = {'connection': 'ssh', 'module_path': '/tmp/', 'forking': 10, 'private_key_file': ('a', 'b')}
    b = temp_args
    assert b == a
    assert isinstance(temp_args, ImmutableDict)

# Generated at 2022-06-23 13:55:25.807125
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    class B(metaclass=_ABCSingleton):
        pass
    assert isinstance(A(), A)
    assert isinstance(B(), B)

# Generated at 2022-06-23 13:55:28.994499
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    args = CLIArgs.from_options(vars(module.params))

    assert args == ImmutableDict()



# Generated at 2022-06-23 13:55:36.961668
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Verify that the CLIArgs class makes any container level elements immutable
    mutable_dict = {'one': 1, 'two': 2, 'three': {1: 1, 2: 2, 3: 3, 4: {4: 4}}}
    test_args = CLIArgs(mutable_dict)

    # Ensure that top level elements are immutable
    assert isinstance(test_args, ImmutableDict)
    assert isinstance(test_args['three'], ImmutableDict)

    # Ensure that nested elements are immutable
    assert isinstance(test_args['three'], ImmutableDict)
    assert isinstance(test_args['three'][4], ImmutableDict)

# Generated at 2022-06-23 13:55:48.055983
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test the constructor of class CLIArgs is working.

    We should get a immutable dictionary back with the same keys
    and values as what we passed in.
    """
    test_dict = {'debug': True, 'something_else': ['one', 'two', 'three']}
    cli_args = CLIArgs(test_dict)

    assert cli_args == test_dict
    assert hasattr(cli_args, 'debug')
    assert hasattr(cli_args, 'something_else')
    assert cli_args.debug == test_dict['debug']
    assert cli_args.something_else == test_dict['something_else']



# Generated at 2022-06-23 13:55:50.850879
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    g = GlobalCLIArgs({'a': 1, 'b': 2})
    assert g.get('a') == 1

# Generated at 2022-06-23 13:55:59.428796
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs.instance({'test':'passed'})
    assert GlobalCLIArgs.instance().get('test') == 'passed'
    assert isinstance(GlobalCLIArgs.instance().get('test'),text_type)
    assert GlobalCLIArgs.instance().get('test') != 'failed'
    assert GlobalCLIArgs.instance().get('test', 'default') == 'passed'
    assert GlobalCLIArgs.instance().get('no key', 'default') == 'default'
    assert GlobalCLIArgs.instance() == {'test': 'passed'}
    assert 'test' in GlobalCLIArgs.instance()
    assert GlobalCLIArgs.instance().keys() == set(['test'])
    assert 'test' in GlobalCLIArgs.instance().keys()

# Generated at 2022-06-23 13:56:02.249587
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    assert isinstance(Foo(), Foo)
    assert isinstance(Foo(), object)
    assert id(Foo()) == id(Foo())

# Generated at 2022-06-23 13:56:05.259855
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Check the constructor of class _ABCSingleton
    """
    # The constructor should not raise an exception
    _ABCSingleton('_ABCSingleton', (object,), {})

# Generated at 2022-06-23 13:56:15.216409
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.options import Options

    input_options = Options(listtags=True, listtasks=True, listhosts=True, syntax=True,
                            connection='smart', module_path=None, forks=100, remote_user='test',
                            private_key_file='/path/to/a/key', ssh_common_args=None,
                            ssh_extra_args=None, sftp_extra_args=None, scp_extra_args=None,
                            become=True, become_method='sudo', become_user='root', verbosity=True,
                            check=False, start_at_task=None, inventory='/path/to/inventory')

    cli_args = CLIArgs.from_options(input_options)
    # test the first element

# Generated at 2022-06-23 13:56:25.438004
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import os
    import sys

    value = {'a': 1, 'b': {'c': 3}}

    if "ANSIBLE_TEST_GLOBALCLIARGS" in os.environ:
        if os.environ.get("ANSIBLE_TEST_GLOBALCLIARGS") == "1":
            args = GlobalCLIArgs(value)
            print("pid=%d, args=%s" % (os.getpid(), args))
            sys.exit(0)
        elif os.environ.get("ANSIBLE_TEST_GLOBALCLIARGS") == "2":
            args = GlobalCLIArgs(value)
            print("pid=%d, args=%s" % (os.getpid(), args))
            sys.exit(1)

# Generated at 2022-06-23 13:56:34.179945
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options:
        pass

    # Define command line options for test
    options = Options()
    options.foo = 'bar'
    options.baz = {'b': 'c'}
    options.qux = [1, 2, 3]

    # Set GlobalCLIArgs to CLIArgs which takes options
    GlobalCLIArgs._instance = CLIArgs.from_options(options)
    cliargs = GlobalCLIArgs()

    # Verify GlobalCLIArgs is a singleton
    assert GlobalCLIArgs._instance is cliargs

    # Verify values set in options were copied to the singleton
    for key, value in vars(options).items():
        assert cliargs[key] == value

# Generated at 2022-06-23 13:56:43.893280
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    real_cli_args = {
        'test': 1,
        'complex': {
            'mapping': {'mapping1': 'value1', 'mapping2': 'value2'},
            'list': ['list_value1', 'list_value2'],
            'set': {'set_value1', 'set_value2'},
        },
        'aliases': None
    }

    cli_args = CLIArgs(real_cli_args)

    assert cli_args['test'] == 1
    assert cli_args['aliases'] is None

    assert isinstance(cli_args['complex'], ImmutableDict)
    assert cli_args['complex']['list'] == ('list_value1', 'list_value2')

# Generated at 2022-06-23 13:56:48.062132
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class X(metaclass=_ABCSingleton):
        pass
    class Y(metaclass=_ABCSingleton):
        pass

    X2 = X()
    assert isinstance(X2, X)
    Y2 = Y()
    assert isinstance(Y2, Y)
    assert isinstance(Y2, X)

# Generated at 2022-06-23 13:56:58.704852
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import os
    import sys
    import tempfile
    import unittest
    from ansible.config.manager import ConfigManager
    from ansible.utils.display import Display
    from ansible.module_utils._text import to_bytes

    try:
        SHOULD_SKIP = bool(os.environ.get('TEST_CHECKMODE_SKIP', ''))
    except AttributeError:
        # Travis CI - environ not defined
        SHOULD_SKIP = False

    if SHOULD_SKIP:
        print('Skipping GlobalCLIArgs tests due to TEST_CHECKMODE_SKIP env variable')
        sys.exit(0)

    class GlobalCLIArgsTestCase(unittest.TestCase):
        def setUp(self):
            my_display = Display()

# Generated at 2022-06-23 13:57:04.770465
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that we can create a new instance of class CLIArgs and that it
    has the expected properties.
    """
    from ansible.cli import CLI
    cli = CLI(args=[])
    options = cli.parse()
    a = CLIArgs.from_options(options)
    assert a['become'] is False

# Generated at 2022-06-23 13:57:08.979941
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.local import LocalAnsibleModule
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.common.parameters as module_params

    module = LocalAnsibleModule(
        argument_spec=dict(
            state=dict(type='str', choices=['present', 'absent'], default='present'),
            name=dict(type='str', required=True),
            attributes=dict(type='dict', required=False),
        )
    )

    params = {
        'state': 'present',
        'name': 'sample',
        'attributes': {}
    }

    params_dump = {
        'state': 'present',
        'name': 'sample',
        'attributes': {}
    }


# Generated at 2022-06-23 13:57:18.795449
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _TestABCSingletonABC(object):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            super(_TestABCSingletonABC, self).__init__()
            self.abc = 1

        def __eq__(self, other):
            return isinstance(other, _TestABCSingletonABC) and self.__dict__ == other.__dict__

        def __ne__(self, other):
            return not self == other

    class _TestABCSingletonSingleton(object):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            super(_TestABCSingletonSingleton, self).__init__()
            self.singleton = 2

        def __eq__(self, other):
            return isinstance(other, _TestABCSingletonSingleton) and self

# Generated at 2022-06-23 13:57:24.511789
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.cli.arguments import optparser
    from ansible.errors import AnsibleOptionsError

    try:
        options, args = optparser.parse_args()
    except AnsibleOptionsError as e:
        optparser.print_help()
        sys.exit(e.args[0])
    loader = DataLoader()
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-23 13:57:29.468116
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    cli_args = dict(
        module_path=['/path/to/ansible/library'],
        connection='smart',
        forks=10,
        become=True,
        become_method='sudo',
        become_user='root',
        check=False,
        diff=False,
    )
    GlobalCLIArgs(cli_args)



# Generated at 2022-06-23 13:57:32.618499
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object, metaclass=_ABCSingleton):
        pass

    class B(A):
        pass

    assert isinstance(A(), A)
    assert isinstance(B(), A)
    assert not isinstance(A(), B)
    assert not isinstance(B(), B)

# Generated at 2022-06-23 13:57:34.907488
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingletonSubClass(object):
        __metaclass__ = _ABCSingleton

    s1 = SingletonSubClass()
    s2 = SingletonSubClass()
    assert s1 is s2

# Generated at 2022-06-23 13:57:42.938564
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(with_metaclass(_ABCSingleton)):
        pass
    class B(with_metaclass(_ABCSingleton)):
        def __init__(self):
            pass
    class C(A):
        pass
        # B(C)  # FAILS, A(B) is preferred, more specific, parent
        # C(B)  # FAILS, A(B) is preferred, more specific parent
    C(A)
    A(B)

# Generated at 2022-06-23 13:57:44.951911
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    g = GlobalCLIArgs._instance()
    assert g._dict == ImmutableDict()

# Generated at 2022-06-23 13:57:46.319139
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert isinstance(CLIArgs({}), ImmutableDict)

# Generated at 2022-06-23 13:57:56.841573
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert CLIArgs({'a': [1, 2, 3], 'b': 2}) == {'a': (1, 2, 3), 'b': 2}
    assert CLIArgs({'a': [1, 2, 3], 'b': {'c': 1, 'd': 2}}) == {'a': (1, 2, 3), 'b': {'c': 1, 'd': 2}}
    assert CLIArgs({'a': [1, 2, 3], 'b': {'c': 1, 'd': {'e': 1, 'f': 2}}}) == {'a': (1, 2, 3), 'b': {'c': 1, 'd': {'e': 1, 'f': 2}}}

   

# Generated at 2022-06-23 13:58:04.866043
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.text.converters import to_bytes
    cli_args = CLIArgs({'ANSIBLE_CONFIG': to_bytes("meow", errors='surrogate_or_strict')})
    assert cli_args['ANSIBLE_CONFIG'] == to_bytes("meow", errors='surrogate_or_strict')

    # Make sure the immutable key is tested because some other tests
    # ensure that we can't modify that key
    assert cli_args.immutable_keys == set(('ANSIBLE_CONFIG',))

# Generated at 2022-06-23 13:58:09.444929
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Unit tests for CLIArgs and GlobalCLIArgs can be found in the tests/unit/module_utils/common
    # directory.  The test_GlobalCLIArgs function is *only* here so that pytest picks up the
    # functions and will execute them when it executes the unit tests.
    pass

# Generated at 2022-06-23 13:58:19.856189
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({
        'bool_true': True,
        'bool_false': False,
        'string': 'string',
        'float': 3.14,
        'int': 3,
        'list': [
            'list_string',
            4,
            False
        ],
        'dict': {
            'dict_string': 'dict_string',
            'dict_int': 5,
            'dict_list': [
                'nested_list_string'
            ]
        }
    })

    assert isinstance(args, CLIArgs)
    assert isinstance(args, Mapping)

    assert args['bool_true'] is True
    assert args['bool_false'] is False
    assert args['string'] == 'string'
    assert args['float'] == 3.14

# Generated at 2022-06-23 13:58:22.670054
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A is B
    assert A() is B()

# Generated at 2022-06-23 13:58:24.570925
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
     # pylint: disable=unused-variable
    gca = GlobalCLIArgs({'foo': 'bar'})
    # pylint: enable=unused-variable

# Generated at 2022-06-23 13:58:32.295929
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'a': 1, 'b': 2}
    my_cli_args = CLIArgs(mapping)
    assert my_cli_args == mapping
    assert not isinstance(my_cli_args['a'], list)
    mapping['c'] = [1, 2, 3]
    my_cli_args = CLIArgs(mapping)
    assert my_cli_args == mapping
    assert not isinstance(my_cli_args['c'], list)



# Generated at 2022-06-23 13:58:41.225391
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    res = CLIArgs({'a': 'str', 'b': {'c': 1, 'd': {'e': 'f'}},
                   'c': ['a', 'b', 'c'], 'd': ('a', 'b', 'c'), 'e': {'a', 'b', 'c'}})
    assert isinstance(res.b, ImmutableDict)
    assert isinstance(res.d, tuple)
    assert isinstance(res.e, frozenset)
    assert res.b['d']['e'] == 'f'
    assert res.c[0] == 'a'
    assert res.c[1] == 'b'
    assert res.c[2] == 'c'
    assert 'a' in res.e
    assert 'b' in res.e

# Generated at 2022-06-23 13:58:45.027177
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options:
        pass

    options = Options()
    options.test = "foo"
    args1 = GlobalCLIArgs.from_options(options)
    args2 = GlobalCLIArgs.from_options(options)
    assert args1 == args2

# Generated at 2022-06-23 13:58:52.051078
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class X(object):
        __metaclass__ = _ABCSingleton
    class Y(object):
        __metaclass__ = _ABCSingleton
    x1 = X()
    x2 = X()
    assert x1 is x2
    assert isinstance(x1, X) and isinstance(x2, X)
    assert not isinstance(x1, Y) and not isinstance(x2, Y)
    y1 = Y()
    y2 = Y()
    assert y1 is y2
    assert isinstance(y1, Y) and isinstance(y2, Y)
    assert not isinstance(y1, X) and not isinstance(y2, X)

# Generated at 2022-06-23 13:58:59.602294
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    r"""
    Test command line arguments are copied in as immutable data structure.
    This test only addresses the case where the CLIArgs object path is set to
    something other than the default path.
    """
    import os
    import tempfile
    import shutil

    fixture_dir = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'test', 'integration', 'cmdline_args')
    src_dir = os.path.join(fixture_dir, 'src')
    dest_dir = tempfile.mkdtemp()


# Generated at 2022-06-23 13:59:04.756208
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs(dict(one="1", two="2", three={'one': 1, 'two': 2}, four=[{'one': 1}, {'two': 2}]))
    assert args.one == "1"
    assert args.two == "2"
    assert isinstance(args.three, ImmutableDict)
    assert args.three.one == 1
    assert args.three.two == 2
    assert isinstance(args.four, tuple)
    assert isinstance(args.four[0], ImmutableDict)
    assert isinstance(args.four[1], ImmutableDict)
    assert args.four[0].one == 1
    assert args.four[1].two == 2
    # test ImmutableDict

# Generated at 2022-06-23 13:59:06.801928
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    c = GlobalCLIArgs({'the_key': 'the value'})
    assert c['the_key'] == 'the value'

# Generated at 2022-06-23 13:59:12.834953
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils import basic
    parser = basic.AnsibleArgumentParser()
    parser.add_argument('--my_option', default='my_option_default_value')
    parser.add_argument('nargs_option', nargs='*')
    options = parser.parse_args([])
    cli_args = GlobalCLIArgs.from_options(options)
    assert type(cli_args) == GlobalCLIArgs
    assert cli_args['my_option'] == 'my_option_default_value'

# Generated at 2022-06-23 13:59:18.973153
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Two classes with different names using _ABCSingleton
    class Test1(object):
        __metaclass__ = _ABCSingleton

    class Test2(object):
        __metaclass__ = _ABCSingleton

    # Creation of a base class is fine
    assert isinstance(Test1(), Test1)

    # But two sub classes with different names is not
    try:
        Test2()
        assert False, "There should only be one metaclass!"
    except TypeError:
        pass



# Generated at 2022-06-23 13:59:30.578192
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # GlobalCLIArgs(mapping) should accept any mapping
    GlobalCLIArgs({})

    # GlobalCLIArgs(mapping) should accept any mapping
    GlobalCLIArgs(dict())

    # GlobalCLIArgs(mapping) should accept any mapping
    GlobalCLIArgs(dict([('a', 1) ]))

    # GlobalCLIArgs(mapping) should accept any mapping
    GlobalCLIArgs(dict([('a', 1), ('b', 2) ]))

    # GlobalCLIArgs(mapping) should accept any mapping
    GlobalCLIArgs(dict([('a', 1), ('b', 2), ('c', 3) ]))

    # GlobalCLIArgs(mapping) should accept any mapping

# Generated at 2022-06-23 13:59:34.534041
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs.from_options(
        type('cli_options', (object,), dict(private=False))
    )
    assert args.private is False



# Generated at 2022-06-23 13:59:40.871876
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class testClass(_ABCSingleton):
        pass
    # Make sure we can only create one instance of the class
    t = testClass()
    t2 = testClass()
    assert(t is t2)
    # Make sure we can't create a subclass of the class
    class subclass(t.__class__):
        pass
    try:
        t3 = subclass()
    except TypeError as e:
        assert(str(e) == 'type \'subclass\' is not an acceptable base type' or str(e) == 'type \'subclass\' is not an acceptable base type')
    else:
        assert(False)

# Generated at 2022-06-23 13:59:47.285786
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert a1 is not None

    b1 = B()
    b2 = B()
    assert b1 is b2
    assert b2 is not None
    assert b2 is not a2

# Generated at 2022-06-23 13:59:54.322664
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Check to make sure that we have access to a any command line args passed in
    """

    # no args passed in
    cli_args = GlobalCLIArgs.from_options(None)
    assert cli_args == {}

    # dict of args passed in
    args = {'a': '1', 'b': '2'}
    cli_args = GlobalCLIArgs.from_options(args)

    assert cli_args == args

# Generated at 2022-06-23 13:59:58.616891
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test init of GlobalCLIArgs class
    """
    dict_args = dict(foo='bar', x=2, y=['z'])
    new_args = CLIArgs(dict_args)
    for key, value in dict_args.items():
        assert new_args[key] == value

# Generated at 2022-06-23 14:00:04.356425
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}
    cliargs = CLIArgs(mapping)

    assert isinstance(cliargs, ImmutableDict)
    assert cliargs == ImmutableDict(mapping)
    assert cliargs['a'] == 1
    assert cliargs['b'] == 2
    assert cliargs['c'] == 3
    assert cliargs['d'] == 4
    assert cliargs['e'] == 5


# Generated at 2022-06-23 14:00:14.132333
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-23 14:00:26.792622
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        pass

    class B(object):
        pass

    class _C(object):
        __metaclass__ = _ABCSingleton

    class D(A, _C):
        pass

    class E(_C, B):
        pass

    class F(_C, B):
        pass

    d = D()
    e = E()
    f = F()

    # d is instance of D and of D's superclasses
    assert isinstance(d, D)
    assert isinstance(d, A)
    assert isinstance(d, _C)

    # e is instance of E and of E's superclasses
    assert isinstance(e, E)
    assert isinstance(e, B)
    assert isinstance(e, _C)

    # d and e are instances of the same class and that class

# Generated at 2022-06-23 14:00:30.046912
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestMeta(object):
        def _foo(self):
            return 'foo'

    class TestSubmeta(TestMeta, object):
        def bar(self):
            return 'bar'

    assert TestMeta._foo(TestMeta()) == 'foo'
    assert TestMeta._foo(TestSubmeta()) == 'foo'

    assert TestSubmeta.bar(TestSubmeta()) == 'bar'

# Generated at 2022-06-23 14:00:32.061422
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = (1, 2, 3)
    GlobalCLIArgs(options)

# Generated at 2022-06-23 14:00:35.348367
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from argparse import Namespace
    from ansible.module_utils.common.collections import ImmutableDict
    options = Namespace(foo=1, bar='baz', quux=True)
    args = GlobalCLIArgs.from_options(options)
    expected_args = ImmutableDict({'foo': 1, 'bar': 'baz', 'quux': True})
    assert args == expected_args

# Generated at 2022-06-23 14:00:40.838541
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # test that a class with _ABCSingleton as its metaclass only allows one instance
    class _TestClass(object):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            pass

    test1 = _TestClass()
    test2 = _TestClass()

    assert(test1 is test2)

# Generated at 2022-06-23 14:00:52.182140
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.cli import CLI
    from ansible.config.loader import ConfigLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    cli = CLI()
    options, args = cli.parse()

    loader = DataLoader()
    variable_manager = VariableManager()
    config_loader = ConfigLoader(loader, os.path.dirname(__file__) + "/../../../")
    config_loader.load_config_files()

    cliargs = CLIArgs.from_options(options)

    assert cliargs.get('inventory') == 'hosts.yml'
    assert cliargs.get('subset') == None
    assert cliargs.get('user') == 'devops'

# Generated at 2022-06-23 14:01:01.213565
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import unittest
    # GlobalCLIArgs ensures that it prevents data from being modified after being set
    # Here we test that it raises an error if you try to update the value of it
    test_dict = {'x': 1, 'y': 2}
    x = GlobalCLIArgs(test_dict)
    x.update({'x': 10})
    y = x.get('x', 0)
    import ansible.module_utils.common.collections
    class GlobalTestArgs(ansible.module_utils.common.collections.GlobalCLIArgs):
        pass
    class TestArgs(ansible.module_utils.common.collections.CLIArgs):
        pass

# Generated at 2022-06-23 14:01:09.061917
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():  # pylint: disable=too-many-boolean-expressions
    # pylint: disable=too-few-public-methods
    class TestSingleton(_ABCSingleton): # pylint: disable=too-many-public-methods
        """
        Provide both a Singleton and an abstract class for testing the _ABCSingleton metaclass
        """
        def __init__(self, value):
            self.value = value

        def get_value(self):
            return self.value

    # Ensure that normal class creation works
    test_object = TestSingleton(1)
    assert test_object.get_value() == 1

    # Second instance should be the same singleton object
    test_object2 = TestSingleton(2)
    assert test_object2.get_value() == 2

# Generated at 2022-06-23 14:01:17.340786
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object):
        __metaclass__ = _ABCSingleton
    try:
        Test.__new__(Test)
        Test.__new__(Test)
    except TypeError:
        raise AssertionError("_ABCSingleton didn't allow one class to be created and raise TypeError")
    try:
        class Test2(object):
            __metaclass__ = _ABCSingleton
    except TypeError:
        raise AssertionError("_ABCSingleton didn't allow another class to be created")

# Generated at 2022-06-23 14:01:26.049133
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
        pass

    class TestClass2(object):
        __metaclass__ = _ABCSingleton
        pass

    class TestClass3(TestClass2):
        pass

    try:
        class TestClass4(TestClass3):
            pass
        raise AssertionError('_ABCSingleton should not allow subclassing from a non-_ABCSingleton subclass')
    except TypeError:
        # We expect a TypeError to be raised since we cannot subclass from
        # a subclass of _ABCSingleton which does not also subclass from
        # _ABCSingleton
        pass

# Generated at 2022-06-23 14:01:29.160549
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    obj = CLIArgs((('key', 'value'), ('key2', ('value1', 'value2')), ('key3', {'key4': 'value3'})))
    assert isinstance(obj, ImmutableDict)
    assert obj.get('key') == 'value'



# Generated at 2022-06-23 14:01:34.796377
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Test the constructor of CLIArgs"""
    cli = CLIArgs({'a': 'b'})
    assert cli['a'] == 'b'
    assert cli.get('a') == 'b'
    # pylint: disable=protected-access
    # ImmutableDict is actually a custom namedtuple so this is safe
    assert cli._fields == ('a',)

# Generated at 2022-06-23 14:01:37.438724
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    assert A() is A() and A() is not B() and B() is B()

# Generated at 2022-06-23 14:01:41.811245
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Test that class _ABCSingleton works as expected
    """
    class TestSingleton(_ABCSingleton):
        """
        A test class for unit testing _ABCSingleton
        """
        def test_method(self):
            """
            A method used to test that _ABCSingleton works
            """
            pass

    test1 = TestSingleton()
    assert test1.test_method
    test2 = TestSingleton()
    assert test1 is test2

# Generated at 2022-06-23 14:01:53.084995
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli import CLI
    cli_args = CLI.base_parser(usage='usage', connect_opts=False, meta_opts=False, runas_opts=False,
                               subset_opts=True, check_opts=False, inventory_opts=False, runtask_opts=True,
                               vault_opts=False, fork_opts=False, module_opts=False, always_positional_args=False)
    cli_args.add_argument('--option_A', dest='option_A', action='store_true', default=False)
    cli_args.add_argument('args', nargs='+')
    options = cli_args.parse_args(['playbook.yaml', '--option_A'])
    GlobalCLIArgs.from_options

# Generated at 2022-06-23 14:02:02.907163
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = GlobalCLIArgs(dict(subsub='subsub', sub=dict(subsub='subsub'), x=dict(xsubsub='xsubsub', xsub=dict(xsubsub='xsubsub'))))
    assert a.subsub == 'subsub'
    assert a.sub.subsub == 'subsub'

    try:
        a.subsub = 'a'
    except TypeError:
        pass
    else:
        assert False, "Exception not raised"

    try:
        d = a.sub
        d['subsub'] = 'a'
        a.sub = d
    except TypeError:
        pass
    else:
        assert False, "Exception not raised"

    assert a.x.xsubsub == 'xsubsub'

# Generated at 2022-06-23 14:02:04.553343
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, Singleton)
    assert issubclass(_ABCSingleton, ABCMeta)



# Generated at 2022-06-23 14:02:05.518097
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({'foo': 'bar'})

# Generated at 2022-06-23 14:02:07.818332
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyClass(object):
        __metaclass__ = _ABCSingleton

    instance1 = MyClass()
    instance2 = MyClass()

    assert instance1 is instance2

# Generated at 2022-06-23 14:02:14.258003
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    ## Test the constructor

    cli_args = CLIArgs(dict(foo="bar"))
    assert cli_args['foo'] == "bar"
    assert cli_args.get('foo') == "bar"
    assert cli_args == {"foo": "bar"}
    try:
        cli_args['foo'] = "bar2"
    except RuntimeError:
        pass
    else:
        assert False
    try:
        cli_args.update(dict(bar="foo"))
    except RuntimeError:
        pass
    else:
        assert False
    try:
        cli_args['other'] = "foo"
    except RuntimeError:
        pass
    else:
        assert False
    cli_args = CLIArgs(dict(foo={'bar': 'baz'}))
    assert cli_

# Generated at 2022-06-23 14:02:22.232966
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_options = GlobalCLIArgs({'option1': 'value1', 'option2': 'value2'})
    assert global_options['option1'] == 'value1'
    assert global_options['option2'] == 'value2'
    assert global_options[b'option1'] == b'value1'
    assert global_options[b'option2'] == b'value2'
    assert global_options == {'option1': 'value1', 'option2': 'value2'}
    assert isinstance(global_options, Mapping)
    assert isinstance(global_options, ImmutableDict)
    assert global_options == GlobalCLIArgs({'option1': 'value1', 'option2': 'value2'})


# Generated at 2022-06-23 14:02:33.415874
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Ensure that the CLIArgs mapping object is immutable

    The CLIArgs object is immutable and should construct as expected.
    """
    cli_args = CLIArgs({
        'one': 1,
        'two': '2',
        'three': [1, 2, 3],
        'four': [{'dict': 'one', 'two': 'three'}],
        'six': {'one': 'two', 'two': 'three'},
    })
    # these should throw an error
    with pytest.raises(TypeError):
        cli_args['seven'] = 7
    with pytest.raises(TypeError):
        cli_args['three'].append(4)
    with pytest.raises(TypeError):
        cli_args['four'][0]['dict'] = 'four'

# Generated at 2022-06-23 14:02:44.550158
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils import basic
    import collections
    import optparse
    parser = optparse.OptionParser()
    parser.add_option("--foo", dest="foo")
    (options, args) = parser.parse_args(["--foo", "bar"])

    keep_singleton_class_values = GlobalCLIArgs.__dict__
    GlobalCLIArgs.__init__(None, basic.AnsibleModule(argument_spec=dict(), supports_check_mode=False).params)
    assert keep_singleton_class_values == GlobalCLIArgs.__dict__ # __init__ should not have change the singleton class
    assert isinstance(GlobalCLIArgs.foo, collections.Hashable) # foo should be a hashable object
    assert 'bar' == GlobalCLIArgs.foo # foo should be set to '

# Generated at 2022-06-23 14:02:51.755311
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {1: 'one', 2: 'two', 3: {4: 'four', 9: 'nine'}, 5: ['five']}
    a = CLIArgs(test_dict)
    assert a[1] == 'one'
    assert a[2] == 'two'
    assert a[3] == ImmutableDict({4: 'four', 9: 'nine'})
    assert a[5] == ['five']

# Generated at 2022-06-23 14:02:56.496396
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    A()
    with pytest.raises(TypeError):
        A()  # check singleton restriction



# Generated at 2022-06-23 14:03:00.683294
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    toplevel = {
        'foo': 10,
        'bar': False,
        'baz': {
            'baz1': 'baz1',
            'baz2': 20,
        },
    }

    args = CLIArgs(toplevel)

    assert args == toplevel

# Generated at 2022-06-23 14:03:01.627075
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        pass
    assert isinstance(Test(), Test)

# Generated at 2022-06-23 14:03:08.051928
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options:
        pass
    options = Options()
    options.verbosity = 5
    options.foo = "bar"
    options.baz = [1, 2, 3, 4]

    a = GlobalCLIArgs.from_options(options)
    assert a.verbosity == 5
    assert a.baz == (1, 2, 3, 4)
    assert a.foo == "bar"
    # Test that it's immutable
    try:
        a.foo[0] = 'x'
        raise AssertionError("GlobalCLIArgs should be immutable")
    except TypeError:
        pass

# Generated at 2022-06-23 14:03:09.507535
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    obj = GlobalCLIArgs({'test': 'value'})
    assert obj['test'] == 'value'

# Generated at 2022-06-23 14:03:11.423487
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    instance = GlobalCLIArgs.from_options(None)
    assert isinstance(instance, GlobalCLIArgs)


# Generated at 2022-06-23 14:03:13.551606
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    expected_dict = {'flag1': 'value1', 'flag2': 'value2'}
    result_dict = CLIArgs(expected_dict)
    assert result_dict == expected_dict

# Generated at 2022-06-23 14:03:24.242850
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # noinspection PyPep8Naming
    class FakeOptions(object):
        test_dict = {'a': 0, 'b': 1, 'c': {0: 0, 1: 1, 'F': 'G'}, 'd': ['e']}
        ansible_connection = 'winrm'
        ansible_winrm_transport = 'kerberos'
        ansible_winrm_kerberos_delegation = True
        ansible_winrm_server_cert_validation = 'ignore'
        ansible_winrm_connection_timeout = 30
        ansible_winrm_operation_timeout = 15
        ansible_winrm_read_timeout = 15
        ansible_winrm_message_encryption = 'auto'

    # test instantiation and type(s) of values in GlobalCLIArgs with a

# Generated at 2022-06-23 14:03:26.161724
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    assert A.__subclasshook__(A)
    assert A.__subclasshook__(object)

# Generated at 2022-06-23 14:03:32.440086
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli import CLI
    from ansible.config import CLI as CLI_Config
    from ansible.utils.display import Display

    display = Display()
    config = CLI_Config(display, [])
    cli = CLI(config, display)
    cli.parse()
    args = GlobalCLIArgs.from_options(cli.options)

    assert args == cli.options, 'GlobalCLIArgs(%s) != CLI.options(%s)' % (args, cli.options)


GLOBAL_ARGS = GlobalCLIArgs({})



# Generated at 2022-06-23 14:03:38.355184
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    class Bar(Foo):
        pass

    assert isinstance(Foo(), Foo)
    assert isinstance(Foo(), Bar)

    assert isinstance(Bar(), Foo)
    assert isinstance(Bar(), Bar)

    assert isinstance(Foo(), object)
    assert isinstance(Bar(), object)

    assert Foo() is Bar()

# Generated at 2022-06-23 14:03:42.089675
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args1 = CLIArgs({"a": 1, "b": ["x", "y"], "c": {"c1": [1, 2]}})
    assert isinstance(args1, Mapping)
    assert isinstance(args1["b"], Sequence)
    assert isinstance(args1["b"][0], text_type)
    assert isinstance(args1["c"], Mapping)
    assert isinstance(args1["c"]["c1"], Sequence)


# Generated at 2022-06-23 14:03:53.204987
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-23 14:03:59.165418
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(_ABCSingleton):
        pass
    # Instantiate singleton
    A()
    # Create second singleton conflicting with previously instantiated singleton
    try:
        class B(_ABCSingleton):
            pass
        B()
    except TypeError:
        pass
    else:
        raise AssertionError('TypeError not raised when creating conflicting singleton')