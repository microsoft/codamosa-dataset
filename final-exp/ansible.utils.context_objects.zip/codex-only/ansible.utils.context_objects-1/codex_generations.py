

# Generated at 2022-06-23 13:54:05.136751
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.dict_transformations import _dict_merge
    class Options:
        def __init__(self, kwargs):
            self.__dict__ = {}
            self.__dict__.update(kwargs)

    # Refs: https://github.com/ansible/ansible/pull/47651
    # Tests:
    #     - Immutable Mapping
    #     - List as arguments
    #     - Boolean value
    #     - None value
    #     - dict within dict
    #     - list within dict
    #     - list within list
    #     - dict within list
    #     - set within dict
    #     - set within list
    #     - set within set
    #     - immutable dict within dict
    #     - immutable dict within list
    #     - immutable

# Generated at 2022-06-23 13:54:07.882697
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        def __init__(self, x):
            self.x = x

    a = A(1)
    b = A(2)
    assert a == b
    assert a is b
    assert a.x == 1
    assert b.x == 1

# Generated at 2022-06-23 13:54:10.101787
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert(TestClass is TestClass())



# Generated at 2022-06-23 13:54:20.984871
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # dict
    dict_args = {'key': ['val1', 'val2'], 'a': ['b', 'c']}
    immutable_dict_args = CLIArgs(dict_args)
    assert isinstance(immutable_dict_args, dict)
    assert isinstance(immutable_dict_args, Mapping)
    assert isinstance(immutable_dict_args, Sequence)
    assert isinstance(immutable_dict_args, Set)
    assert isinstance(immutable_dict_args, Container)
    assert isinstance(immutable_dict_args['key'], tuple)
    assert isinstance(immutable_dict_args['a'], tuple)
    assert immutable_dict_args['key'] == ('val1', 'val2')
    assert immutable_dict_args['a'] == ('b', 'c')
   

# Generated at 2022-06-23 13:54:31.370670
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    See if we can create a mutable version of CLIArgs
    """
    test_dict = {
        'one': 1,
        'two': [2, 3],
        'three': {'nested': 3}
    }
    x = CLIArgs(test_dict)
    assert x.one == 1
    assert x.two[0] == 2
    assert x.two[1] == 3
    # It's OK to change a value in the original dict
    test_dict['one'] = 'one'
    assert x.one == 1
    # It's not OK to change the original type of a value
    test_dict['two'] = 'two'
    assert x.two[0] == 2
    # It's not OK to change a value deep in the object
    test_dict['three']['nested']

# Generated at 2022-06-23 13:54:38.446492
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {'a': 'b', 'c': ['d', 'e'], 'f': {'g': 'h'}, 'i': {'j': ['k', 'l', 'm']}}
    args = CLIArgs(args)
    assert isinstance(args, ImmutableDict)
    assert isinstance(args['f'], ImmutableDict)
    assert isinstance(args['i'], ImmutableDict)
    assert isinstance(args['c'], tuple)
    assert isinstance(args['i']['j'], tuple)

# Generated at 2022-06-23 13:54:44.163767
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton(_ABCSingleton):
        pass

    class TestSingleton2(_ABCSingleton):
        pass

    class TestSingleton3(_ABCSingleton):
        pass

    assert isinstance(TestSingleton, _ABCSingleton)
    assert isinstance(TestSingleton2, _ABCSingleton)
    assert isinstance(TestSingleton3, _ABCSingleton)

# Generated at 2022-06-23 13:54:51.253435
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton
        def __init__(self, a):
            self.a = a

        def __eq__(self, other):
            return self.a == other.a

    x = Foo(a=3)
    y = Foo(a=4)
    assert x == y
    assert y == x
    assert x is y
    assert y is x

    class Bar(object):
        __metaclass__ = _ABCSingleton

    z = Bar()
    t = Bar()
    assert z is t
    assert z == t
    assert z is not None
    assert z is not 3
    assert z is not 'foo'
    assert z is not object
    assert z is not Bar
    assert z is not ImmutableDict
    assert z is not CLIArgs

# Generated at 2022-06-23 13:55:02.873062
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Verify that the GlobalCLIArgs class makes args immutable as expected

    This is a unit test for the constructor of GlobalCLIArgs.  It will not run in the installer tests
    because the installer will not have the `pytest` framework installed.
    """

    # The simplest and easiest way is to instantiate the class with a simple set of arguments
    test_args = GlobalCLIArgs({'one': 1, 'two': 2})
    assert test_args['one'] == 1
    assert test_args['two'] == 2

    # Mutating an immutable should raise an exception
    try:
        test_args['one'] = 11
    except AssertionError:
        # We caught an error as expected
        pass
    # We should not have mutated the args
    assert test_args['one'] == 1

    # More complex cases are tested in

# Generated at 2022-06-23 13:55:09.220407
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # a non-empty dictionary
    args = {"foo": "bar", "baz": "qux"}
    # call the constructor
    orig = GlobalCLIArgs(args)
    # check that the result is an object of type ImmutableDict
    assert(isinstance(orig, ImmutableDict))
    # check that the result is an object of type GlobalCLIArgs
    assert(isinstance(orig, GlobalCLIArgs))
    # check that the result is an singleton
    with pytest.raises(TypeError):
        GlobalCLIArgs()  # noqa; pylint: disable=no-value-for-parameter

# Generated at 2022-06-23 13:55:19.695985
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = ImmutableDict({
        'number': 42,
        'string': 'hello',
        'list': ['a', 'b'],
        'dict': {'key': 'value', 'key2': 'value2'},
        'set': {'a', 'b'},
    })
    cli_args = CLIArgs(args)
    assert cli_args.number == 42
    assert cli_args.string == 'hello'
    assert cli_args.list == ('a', 'b')
    assert cli_args.dict == ImmutableDict({'key': 'value', 'key2': 'value2'})
    assert cli_args.set == frozenset({'a', 'b'})

# Generated at 2022-06-23 13:55:22.676050
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _Foo(_ABCSingleton):
        pass
    assert(_Foo is _Foo())

# Generated at 2022-06-23 13:55:31.828344
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    a = GlobalCLIArgs.from_options(None)
    assert a is GlobalCLIArgs()
    assert a is GlobalCLIArgs.instance
    assert isinstance(a['_ansible_vault_password'], AnsibleUnsafeText)
    try:
        a['_ansible_vault_password'] = b"secret"
        raise Exception("This should raise a TypeError")
    except TypeError:
        pass
    assert a['_ansible_vault_password'] != b"secret"

# Generated at 2022-06-23 13:55:35.009161
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MetaClassA(metaclass=_ABCSingleton):
        pass

    class MetaClassB(metaclass=_ABCSingleton):
        pass

    class MetaClassC(MetaClassA, MetaClassB):
        pass



# Generated at 2022-06-23 13:55:38.109189
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # GlobalCLIArgs is a Singleton so it needs to be instantiated manually
    GlobalCLIArgs.__new__(GlobalCLIArgs, {"a": {"b": 1, "c": [1, 2, 3]}, "b": [1, 2, 3]})

# Generated at 2022-06-23 13:55:49.736401
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import StringIO
    import tempfile

    # add/set debug options
    sys.argv = [sys.argv[0]] + ['--debug', '1', '--debug-strategy', 'linear']

    # add other non-debug and non-ansible-config specific options
    tmpfd, tmpfile = tempfile.mkstemp()
    out = StringIO()
    sys.argv += ['--version', '--list-hosts', '--list-tags', '--list-tasks', '--metric', '--extra-vars', 'foo=bar', '--diff', '-i', tmpfile, '-e', '@' + tmpfile]

# Generated at 2022-06-23 13:55:51.236853
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs(dict(foo="bar"))
    assert isinstance(args, CLIArgs)
    assert args["foo"] == "bar"

# Generated at 2022-06-23 13:56:00.399702
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dictionary = {'test1': 'some_value', 'test2': {'test3': 'some_value', 'test4': {}} }
    cli_args = CLIArgs(dictionary)
    assert(cli_args['test1'] == 'some_value')
    # test2 is a dictionary that should also be immutable
    assert(cli_args['test2']['test3'] == 'some_value')
    # also make sure that trying to modify it fails
    try:
        cli_args['test2']['test3'] = 'some_other_value'
        assert(False)
    except TypeError:
        assert(True)
    # test3 is a dictionary that should also be immutable
    assert(len(cli_args['test2']['test4'].keys()) == 0)
    # also make sure

# Generated at 2022-06-23 13:56:05.310551
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {"a": 1, "b": {"c": 2, "d": [3, 4]}}
    args = CLIArgs(mapping)
    assert isinstance(args, Mapping)
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, CLIArgs)
    assert args == mapping
    assert "a" in args

# Generated at 2022-06-23 13:56:12.157757
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # dict1 is a dict.
    dict1 = {'a': {'b': 'c'}}
    # dict2 is a dict, even though it looks like a list of key, value pairs
    dict2 = {'a': 'b', 'c': 'd'}
    # dict3 is a dict.
    dict3 = {'a': {'b': 'c', 'd': 'e'}}
    GlobalCLIArgs(dict1)
    GlobalCLIArgs(dict2)
    GlobalCLIArgs(dict3)

# Generated at 2022-06-23 13:56:14.562705
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, ABCMeta)
    assert issubclass(_ABCSingleton, Singleton)

# Generated at 2022-06-23 13:56:23.658489
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.basic import AnsibleModule
    args = CLIArgs.from_options(AnsibleModule.parse_args([]))
    assert args['basic_module_arguments'] == {
        '_ansible_debug': False,
        '_ansible_diff': False,
        '_ansible_keep_remote_files': False,
        '_ansible_module_name': 'setup',
        '_ansible_no_log': False,
        '_ansible_verbosity': 0,
        '_uses_shell': False,
        'CHECKMODE': False,
        '_uses_delegate': True
    }

# Generated at 2022-06-23 13:56:33.562316
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that it works properly when different types of data structures are passed in
    args = CLIArgs({"parameter": {"a": "b"}, "a": "b", "c": [1, 2, 3], "d": [{"e": "f"}, 2, 3], "g": {"h": [1, 3, 3]}})
    assert args['parameter'] == ImmutableDict({"a": "b"})
    assert args['a'] == "b"
    assert args['c'] == (1, 2, 3)
    assert args['d'] == ([ImmutableDict({"e": "f"}), 2, 3])
    assert args['g'] == ImmutableDict({"h": (1, 3, 3)})

# Generated at 2022-06-23 13:56:41.742738
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    a = _ABCSingleton()
    b = _ABCSingleton()

    assert a is b
    assert a == b

    c = _ABCSingleton()

    assert a is c
    assert a == c

    class Foo(_ABCSingleton):
        def bar(self):
            pass

    class Bar(_ABCSingleton):
        def bar(self):
            pass

    foo = Foo()
    bar = Bar()

    assert foo is not bar
    assert foo != bar

    class Foo1(Foo):
        pass

    foo1 = Foo1()

    assert foo is not foo1
    assert foo != foo1

# Generated at 2022-06-23 13:56:44.368908
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({})
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, GlobalCLIArgs)


# Generated at 2022-06-23 13:56:48.764181
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Dummy1(object):
        __metaclass__ = _ABCSingleton

    class Dummy2(Dummy1, object):
        pass

    class Dummy3(Dummy1, object):
        pass

    assert Dummy2() is Dummy2()
    assert Dummy3() is Dummy3()
    assert Dummy2() is not Dummy3()

# Generated at 2022-06-23 13:56:52.563098
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Base(object):
        __metaclass__ = _ABCSingleton

    class Derived(Base):
        pass

    assert Base() is Base()
    assert Derived() is Derived()
    assert Base() is not Derived()

# Generated at 2022-06-23 13:56:54.839164
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    d = {'a': {'b': {'c': {'d': 'e'}}}}
    cli_args = CLIArgs(d)
    assert d == cli_args


# Generated at 2022-06-23 13:56:58.874191
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    a = TestClass()
    b = TestClass()

    # Check that they are linked
    assert id(a) == id(b)

    # ABCMeta based classes are still new-style and able to be subclassed
    class TestSubClass(TestClass):
        pass

    assert issubclass(TestSubClass, TestClass)

    c = TestSubClass()
    assert id(c) != id(a)

# Generated at 2022-06-23 13:57:04.163814
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ABCSingletonTest(object):
        __metaclass__ = _ABCSingleton
        def __init__(self):
            self.test = True

    test1 = ABCSingletonTest()
    assert test1.test
    assert test1 is ABCSingletonTest()

# Generated at 2022-06-23 13:57:05.629929
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class First(metaclass=_ABCSingleton):
        pass

    class Second(metaclass=_ABCSingleton):
        pass

    assert First() == First()
    assert First() is not Second()

# Generated at 2022-06-23 13:57:09.903744
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.context_objects import AnsibleCLIArgs
    args = AnsibleCLIArgs()
    if not isinstance(args.args, CLIArgs):
        raise AssertionError("CLIArgs() constructor does not return instances of class CLIArgs")

# Generated at 2022-06-23 13:57:14.582315
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            pass

    a = Foo()
    a.attr = 42
    b = Foo()
    assert b.attr == 42
    b.attr2 = "Lorem ipsum"
    assert b.attr2 == "Lorem ipsum"
    assert a.attr == 42
    assert a.attr2 == "Lorem ipsum"
    try:
        a.attr2 = "dolor sit amet"
    except AttributeError:
        pass
    else:
        raise ValueError("Unable to set attribute which should not exist")

# Generated at 2022-06-23 13:57:19.499117
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Make an instance of GlobalCLIArgs with a dict that is mutable

    This should generate an exception
    """
    test_dict = {'foo': {'bar': 'blah'}, 'spam': ['eggs', 'ham']}
    try:
        GlobalCLIArgs(test_dict)
    except TypeError:
        pass
    else:
        raise RuntimeError("Unable to catch exception")

# Generated at 2022-06-23 13:57:28.895062
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest
    from ansible.module_utils.common._collections_compat import Mapping, Sequence, Set

    class TestCLIArgs(unittest.TestCase):

        def setUp(self):
            self.argv = sys.argv[:]

        def tearDown(self):
            sys.argv = self.argv

        def test_GlobalCLIArgs(self):
            sys.argv = ['setup.py', '-c', 'test.ansible.cfg', '-e', 'inject_foo=bar']
            from ansible.config.manager import ConfigManager
            from ansible.utils.display import Display
            from ansible.cli.adhoc import AdHocCLI

            display = Display()

# Generated at 2022-06-23 13:57:30.848929
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    assert A() is B()

# Generated at 2022-06-23 13:57:39.316770
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import collections
    import copy
    import datetime
    import os
    import re
    import yaml
    import sys
    import types

    # This is the data we use to test that we don't allow modification of
    # the GlobalCLIArgs container
    test_data = dict(
        opt_one=42,
        opt_two='hello',
        opt_three=False,
        opt_four=[42, 'string'],
        opt_five={'key': 'value'},
    )

    # Test that read-only copies of the container do not allow
    # modification.  Test each of the standard types found in the container.

# Generated at 2022-06-23 13:57:43.248245
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    __metaclass__ = _ABCSingleton
    class myclass(object):
        pass
    mc1 = myclass()
    mc2 = myclass()
    assert mc1 is mc2, 'Singleton not working'

# Generated at 2022-06-23 13:57:46.895086
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _Foo(object, metaclass=_ABCSingleton):
        def __init__(self, a, b):
            super(_Foo, self).__init__(a, b)
    _Foo(10, 20)

# Generated at 2022-06-23 13:57:58.068538
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import unittest
    from ansible.module_utils.common.collections import AnsibleModuleArgs
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.test_cli_args import \
        mock_args

    class TestGlobalCLIArgsInitialization(unittest.TestCase):
        def test_init(self):
            args = GlobalCLIArgs.from_options(mock_args)
            self.assertTrue(isinstance(args, GlobalCLIArgs))
            self.assertTrue('connection' in args)
            self.assertTrue('remote_user' in args)
            self.assertTrue(isinstance(args['connection'], ImmutableDict))
            self.assertTrue(isinstance(args['remote_user'], text_type))

# Generated at 2022-06-23 13:58:00.082035
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    @add_metaclass(_ABCSingleton)
    class Object1(ABCMeta):
        pass

    @add_metaclass(_ABCSingleton)
    class Object2(Object1):
        pass

    assert Object1() is Object1()
    assert Object2() is Object2()
    assert Object2() is Object1()

# Generated at 2022-06-23 13:58:03.949760
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    class Bar(object):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            pass

    assert Foo is Foo()
    assert Bar is Bar()
    assert Foo is not Bar

# Generated at 2022-06-23 13:58:15.553107
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Non-container
    assert CLIArgs({'b': 1}).get('b') == 1
    assert CLIArgs({'b': None}).get('b') is None
    # Dict type
    assert isinstance(CLIArgs({'a': {'b': 1}}).get('a'), ImmutableDict)
    assert CLIArgs({'a': {'b': 1}}).get('a').get('b') == 1
    assert isinstance(CLIArgs({'a': {'b': {'c': None}}}).get('a').get('b'), ImmutableDict)
    assert CLIArgs({'a': {'b': {'c': None}}}).get('a').get('b').get('c') is None
    # List type

# Generated at 2022-06-23 13:58:23.033221
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    c = CLIArgs.from_options({'option': 'a', 'integer': 1, 'nested': {'option': 'b'}})
    if c['option'] != 'a' or c['integer'] != 1 or c['nested']['option'] != 'b':
        raise AssertionError("c doesn't have expected values after CLIArgs.__init__()")
    if isinstance(c, dict):
        raise AssertionError("c is not an immutable dict after CLIArgs.__init__()")
    if isinstance(c['nested'], dict):
        raise AssertionError("c['nested'] is not an immutable dict after CLIArgs.__init__()")

# Generated at 2022-06-23 13:58:33.054177
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    options = ImmutableDict(
        one=ImmutableDict(
            a=1,
            b=2,
            c=3,
        ),
        two=ImmutableDict(
            d=4,
            e=5,
            f=6,
        )
    )
    cli_args = CLIArgs.from_options(options)
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args['one'], ImmutableDict)
    assert isinstance(cli_args['two'], ImmutableDict)



# Generated at 2022-06-23 13:58:36.455202
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # The first instance was created as a side effect of importing this module
    # It should be the same as the one we try to create
    instance = _ABCSingleton._ABCSingleton__instance
    assert isinstance(instance, _ABCSingleton)



# Generated at 2022-06-23 13:58:41.467684
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.cli.arguments import Options
    options = Options()
    options.connection = 'local'
    options.module_path = '/a'
    mapping = vars(options)
    cli_args = CLIArgs(mapping)
    assert(cli_args['connection'] == 'local')
    assert(cli_args['module_path'] == '/a')

# Generated at 2022-06-23 13:58:50.932812
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    a = CLIArgs({'a': 1, 'b': {'c': 3, 'd': 4}, 'e': [5, 6], 'f': {7, 8, 9}, 'g': (10, 11)})
    assert a.a == 1
    assert a.b.c == 3
    assert a.b.d == 4
    assert a.e[0] == 5
    assert a.e[1] == 6
    assert len(a.f) == 3
    assert len(a.g) == 2

    a = CLIArgs(command_line=['a=1', 'b={"c":3}', 'e=[5,6]', 'f={7,8,9}'])
    assert a.a == 1
    assert a.b.c == 3
    assert a.e[0] == 5
   

# Generated at 2022-06-23 13:58:53.852326
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        pass
    assert issubclass(Test, Singleton)
    assert issubclass(Test, ABCMeta)
    assert issubclass(Test, type)

# Generated at 2022-06-23 13:59:02.586729
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Unit test for constructor of _ABCSingleton()."""

    class TestClass(_ABCSingleton):
        pass

    class TestClass2(_ABCSingleton):
        pass

    assert TestClass('foo') is not TestClass('foo')
    assert TestClass('foo') == TestClass('foo')
    assert TestClass('foo') is TestClass('foo')
    assert TestClass('foo') is TestClass('foo')

    assert TestClass('foo') is not TestClass2('foo')
    assert TestClass('foo') != TestClass2('foo')


# Generated at 2022-06-23 13:59:07.722147
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    parser = argparse.ArgumentParser()

    parser.add_argument('--version', action='version', version="this is a test")
    args = parser.parse_args(args=[])
    my_args = GlobalCLIArgs.from_options(args)
    print(my_args)

if __name__ == '__main__':
    test_GlobalCLIArgs()

# Generated at 2022-06-23 13:59:16.014202
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        pass

    options = Options()
    options.some_key = text_type('some_value')
    options.some_list = ['a', 'b', 'c']
    options.some_dict = {'d': text_type('e'), 'f': {'g': text_type('h')}}

    cli_args = CLIArgs.from_options(options)

    assert cli_args.get('some_key') == text_type('some_value')
    assert cli_args['some_key'] == text_type('some_value')

    assert cli_args.get('some_list') == ('a', 'b', 'c')
    assert cli_args['some_list'] == ('a', 'b', 'c')


# Generated at 2022-06-23 13:59:21.254955
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli import CLI
    from ansible.errors import AnsibleError
    cli = CLI(args=['--module-path'])
    parser, __ = cli.parse()
    options = parser.parse_args([])
    try:
        args = GlobalCLIArgs(options)
        assert args.get('module_path')
    except AnsibleError:
        raise AssertionError("GlobalCLIArgs cannot be initialized")

# Generated at 2022-06-23 13:59:28.634156
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Verify that we can combine singleton with an abstract base class"""
    class A(object):
        pass

    class B(A):
        pass

    try:
        bad_singleton = _ABCSingleton('test', (), {})
    except Exception as e:
        # should raise TypeError because it needs a class
        assert isinstance(e, TypeError)

    abcsingleton = _ABCSingleton('test', (A,), {})
    assert issubclass(abcsingleton, A)
    assert abcsingleton is abcsingleton()

    abcsingleton = _ABCSingleton('test', (B,), {})
    assert issubclass(abcsingleton, B)
    assert abcsingleton is abcsingleton()



# Generated at 2022-06-23 13:59:38.056204
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    options = type('args', (object,), {'foo': [], 'bar': 1, 'baz': ['one', 'two', 'three'], 'zab': {'some': 'value', 'another': 1}})()

    # Simple test case with no nested structures
    cli_args = CLIArgs.from_options(options)

    assert isinstance(cli_args, CLIArgs)
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args['foo'] == []
    assert cli_args['bar'] == 1
    assert cli_args['baz'] == ('one', 'two', 'three')
    assert cli_args['zab']['some'] == 'value'
    assert cli_args['zab']['another'] == 1

# Generated at 2022-06-23 13:59:42.478822
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    module_args = {'ANSIBLE_MODULE_ARGS': None, 'ANSIBLE_MODULE_CONSTANTS': None}
    options = type('name', (object,), module_args)
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-23 13:59:50.802696
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {
        'arg1': 'text_type',
        'arg2': 10,
        'arg3': [1, 2, 3],
        'arg4': {'arg5': 'text_type',
                 'arg6': ['one', 'two'],
                 'arg7': {'arg8': 'text_type',
                          'arg9': ['three', 'four']
                         }
                }
    }

    cli_args = CLIArgs(mapping)
    for key, value in mapping.items():
        assert cli_args[key] == _make_immutable(value)



# Generated at 2022-06-23 14:00:00.957196
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from inspect import isclass
    from ansible.module_utils.common.collections import GlobalCLIArgs
    assert isclass(GlobalCLIArgs)
    with pytest.raises(TypeError) as excinfo:
        GlobalCLIArgs()
    assert 'Cannot create instance of singleton class GlobalCLIArgs' in str(excinfo.value)
    assert not GlobalCLIArgs.instance
    GlobalCLIArgs.instance = GlobalCLIArgs({'test': 'value'})
    assert GlobalCLIArgs.instance
    with pytest.raises(TypeError) as excinfo:
        GlobalCLIArgs.instance = None
    assert 'Read-only attribute' in str(excinfo.value)
# end of test_GlobalCLIArgs()

# Generated at 2022-06-23 14:00:11.167792
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        def __init__(self):
            pass

    class B(A, metaclass=_ABCSingleton):
        pass

    class C(A, metaclass=_ABCSingleton):
        pass

    class D(B, C):
        pass

    class E(B, C):
        pass

    class F(B, C):
        pass

    class G(B, F):
        pass

    class H(G):
        pass

    class I(G):
        pass

    assert B() is B()
    assert C() is C()
    assert D() is D()
    assert E() is E()
    assert F() is F()
    assert G() is G()
    assert H() is H()
    assert I() is I()

# Generated at 2022-06-23 14:00:23.877550
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Unit test for class GlobalCLIArgs"""
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--file', dest='file', type=str, required=True)
    parser.add_argument('--number', dest='number', default=59, type=int)
    parser.add_argument('--foo', dest='foo', type=str, action='append', required=True)
    options = parser.parse_args([
        '--file', '/tmp/abc.txt',
        '--foo', 'abc',
        '--foo', 'def',
        '--foo', 'ghi'
    ])
    options = vars(options)
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-23 14:00:25.804383
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(A):
        pass

    class C(A):
        pass

    a = A()
    b = B()
    c = C()

    assert hash(a) == hash(b) == hash(c)

# Generated at 2022-06-23 14:00:31.909391
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnicode
    GlobalCLIArgs(
        AnsibleMapping(
            [(
                AnsibleUnicode("test"),
                AnsibleMapping([
                    (
                        AnsibleUnicode("test"),
                        AnsibleSequence([
                            AnsibleUnicode("test"),
                            AnsibleMapping([
                                (
                                    AnsibleUnicode("test"),
                                    AnsibleUnicode("test")
                                )
                            ])
                        ])
                    )
                ])
            )])
    )

# Generated at 2022-06-23 14:00:34.215902
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class X(object):
        __metaclass__ = _ABCSingleton
    theOne = X()

# Generated at 2022-06-23 14:00:44.792863
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.inventory import Inventory
    from ansible.utils.boolean import boolean
    from ansible.executor.playbook_executor import PlaybookExecutor

    dataloader = DataLoader()
    loader = dataloader.set_basedir('/tmp')
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list='/tmp/file')


# Generated at 2022-06-23 14:00:50.624301
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    payload = {'one': 'two', 'three': [1, 2, 3], 'four': {'five': 'six'}, 'seven': {'eight': 'nine'}, 'ten': {1, 2, 3}}
    cli_args = CLIArgs(payload)
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args == payload



# Generated at 2022-06-23 14:00:54.078182
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert GlobalCLIArgs is GlobalCLIArgs()
    # Should be protected as a singleton
    try:
        GlobalCLIArgs()
    except RuntimeError:
        pass
    else:
        raise AssertionError("GlobalCLIArgs object is not protected as a Singleton")

# Generated at 2022-06-23 14:01:03.196768
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs.from_options(type('', (), {'v':True})) == {'v':True}
    assert CLIArgs.from_options(type('', (), {'vv':True})) == {'vv':True}
    assert CLIArgs.from_options(type('', (), {'vvv':True})) == {'vvv':True}
    assert CLIArgs.from_options(type('', (), {'vvv':True, 'vv':True})) == {'vvv':True, 'vv':True}
    assert CLIArgs.from_options(type('', (), {'vvv':True, 'vv':False})) == {'vvv':True, 'vv':False}

# Generated at 2022-06-23 14:01:09.459738
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import DefaultAttrDict
    from ansible.module_utils.basic import AnsibleModule

    args = {
        'test': 'test',
        'test_list': ['1', '2', '3'],
        'test_dict': {'one': 'ONE', 'two': 'TWO'},
    }

    module = AnsibleModule(**args)
    options = module.parse_args()
    module.exit_json(changed=False, meta=DefaultAttrDict(
        dict=GlobalCLIArgs.from_options(options),
        fail_on_missing_delegate_facts=to_text(False),
    ))

# Generated at 2022-06-23 14:01:21.571831
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # pylint: disable=protected-access
    mapping = {'a': 'a', 'b': 'b'}
    args = CLIArgs(mapping)

    # Check internal structure
    assert args._ds == ImmutableDict(mapping)
    # Check the object behaviour
    assert args['a'] == 'a'
    assert args['b'] == 'b'
    # Check that the same object is returned on multiple calls
    assert id(CLIArgs(mapping)) == id(args)

    # Check that __eq__ works
    assert args == ImmutableDict(mapping)

    # Check that objects inside the structure are made immutable
    mapping = {'a': {'a1': 'a1', 'a2': 'a2'}, 'b': 'b'}
    args = CLIArgs(mapping)


# Generated at 2022-06-23 14:01:23.065293
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({'test': 'value'})
    assert args['test'] == 'value'


# Generated at 2022-06-23 14:01:26.987895
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        """Test if metaclass based classes override class based Singleton classes."""
    class B(A, metaclass=_ABCSingleton):
        """Test if metaclass based classes override class based Singleton classes."""

# Generated at 2022-06-23 14:01:30.927332
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ExampleMeta(Singleton, ABCMeta):
        pass

    class Example(metaclass=ExampleMeta):
        pass

    class ExampleSubclass(Example):
        pass

    x = Example()
    y = Example()
    assert x is y
    assert x is not Example()

    x = ExampleSubclass()
    y = ExampleSubclass()
    assert x is y
    assert x is not Example()

# Generated at 2022-06-23 14:01:40.345666
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Test the CLIArgs class"""
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.collections import is_sequence

    # Create a mutable dict and make it into an immutable dict
    dict_obj = dict(a=dict(b=1))
    immutable_dict = CLIArgs(dict_obj)
    assert isinstance(immutable_dict, ImmutableDict)
    assert isinstance(immutable_dict['a'], ImmutableDict)

    # Make sure it is indeed immutable
    try:
        immutable_dict['a'] = 2
    except TypeError:
        pass
    else:
        raise AssertionError('Expected the dict to be an immutable dict and not a regular dict')

    # Make sure a new object is created in the process

# Generated at 2022-06-23 14:01:46.510403
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options:
        def __init__(self, d):
            self.__dict__.update(d)

    d = {"verbosity": 10, "key": "value"}
    options = Options(d)
    cliargs = CLIArgs.from_options(options)
    assert cliargs == {"verbosity": 10, "key": "value"}



# Generated at 2022-06-23 14:01:52.397453
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'abc': 123, 'def': 456}
    args = CLIArgs(test_dict)
    assert args['abc'] == 123 and args['def'] == 456
    try:
        args['abc'] = 123
    except TypeError:
        pass
    except:
        raise AssertionError("Unexpected error")
    else:
        raise AssertionError("expected Attribute error")



# Generated at 2022-06-23 14:02:02.687219
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import pytest
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.utils.context_objects import CLIArgs

    test_args_dict = dict(a='a', b='b', c='c', d=1, e=2, f=3, g='g', h=['h1', 'h2', 'h3'])
    test_args = CLIArgs(test_args_dict)

    # Test that each key in the dict is in the CLIArgs
    for key in test_args:
        assert key in test_args_dict

    # Test that each value in the dict is the same value in the CLIArgs
    for key, value in test_args.items():
        assert value == test_args_dict[key]

    # Test that the object is immutable

# Generated at 2022-06-23 14:02:08.039759
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {"1": "one", "2": "two", "3": "three"}
    test_immutable = CLIArgs(test_dict)
    try:
        test_immutable["1"] = "One"
    except TypeError:
        pass

    try:
        test_immutable.update({"1": "One"})
    except TypeError:
        pass

    assert(test_immutable.get("1") == "one")

# Generated at 2022-06-23 14:02:18.785915
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.dict_transformations import dict_merge

    # we need to have some values that have been frozen,
    # but we can't just use ImmutableDict.from_mutable()
    # in case the object was already frozen by the
    # ImmutableDict constructor

# Generated at 2022-06-23 14:02:20.795805
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    A()
    A()

# Generated at 2022-06-23 14:02:29.836339
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        pass
    options = Options()
    options.foo = 'bar'
    options.baz = dict(a=1, b=2)
    options.qux = [1, 2, 3]
    args = CLIArgs.from_options(options)
    assert args
    assert args.foo == 'bar'
    assert args.baz.a == 1
    assert args.baz.b == 2
    assert args.qux[0] == 1
    assert args.qux[1] == 2
    assert args.qux[2] == 3

# Generated at 2022-06-23 14:02:37.121851
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-23 14:02:46.839943
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Check that CLIArgs is behaving as expected when creating
    """
    toplevel = {
        'debug': True,
        'connection': 'smart',
        'module_path': '/usr/local/ansible/modules'
    }
    sublevel = {
        'password': 'abc',
        'hostname': 'controller'
    }
    toplevel['sub'] = sublevel
    cliargs = CLIArgs(toplevel)
    assert cliargs == ImmutableDict(toplevel)
    assert cliargs.sub == ImmutableDict(sublevel)
    assert cliargs.sub.password == 'abc'
    assert cliargs.sub.hostname == 'controller'
    assert isinstance(cliargs, ImmutableDict)

# Generated at 2022-06-23 14:02:50.698150
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        pass
    options = Options()
    options.foo = 'bar'
    args = GlobalCLIArgs.from_options(options)
    assert args['foo'] == 'bar'

# Generated at 2022-06-23 14:02:56.860660
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert id(A()) == id(A())
    assert id(B()) == id(B())
    assert id(A()) != id(B())



# Generated at 2022-06-23 14:03:00.682903
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Alpha(_ABCSingleton):
        pass

    assert issubclass(Alpha, Singleton)
    assert issubclass(Alpha, ABCMeta)
    class Beta():
        pass

    assert not issubclass(Beta, Singleton)
    assert not issubclass(Beta, ABCMeta)

# Generated at 2022-06-23 14:03:03.492631
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test:
        __metaclass__ = _ABCSingleton

    class Test2(Test):
        pass

    Test()
    with pytest.raises(TypeError):
        Test2()

# Generated at 2022-06-23 14:03:05.603458
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class SomeObject(object):
        pass

    assert(GlobalCLIArgs.from_options(SomeObject()))

# Generated at 2022-06-23 14:03:08.998146
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, type)
    assert issubclass(GlobalCLIArgs, CLIArgs)
    assert not issubclass(GlobalCLIArgs, ImmutableDict)  # Singleton means that GlobalCLIArgs is not a subclass of ImmutableDict or other non-Singleton abstract base classes

# Generated at 2022-06-23 14:03:20.172117
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Simple test of CLIArgs class constructor"""
    # GIVEN:
    #   Uninitialized CLIArgs object
    item = CLIArgs({})

    # WHEN:
    #   object is initialized with a dictionary
    #   and the object is converted to a dictionary
    #   and the object is checked to make sure the conversion happened
    item = CLIArgs({'a': 'b', 'c': [1, 2, 3]})
    result = dict(item)

    # THEN:
    #   conversion from dict to ImmutableDict worked
    assert isinstance(result, ImmutableDict)

    # WHEN:
    #   object is initialized with a dictionary
    #   and the object is converted to a list
    #   and the object is checked to make sure the conversion happened

# Generated at 2022-06-23 14:03:28.710713
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils._text import to_bytes
    d = {'foo': 1, 'bar': {'baz': 'bang', 'bla': 'blip'}, to_bytes('foobar', 'ascii'): {'abc': to_bytes('123', 'ascii')}}
    c = CLIArgs(d)
    assert isinstance(c, ImmutableDict)
    assert c.foo == 1
    assert c.bar.baz == 'bang'
    assert c[to_bytes('foobar', 'ascii')].abc == to_bytes('123', 'ascii')

# Generated at 2022-06-23 14:03:34.993364
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    options, args = parser.parse_known_args(['--foo=bar', '--unknown=xyz'])
    assert is_immutable(GlobalCLIArgs.from_options(options))

# Generated at 2022-06-23 14:03:36.928452
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _A(metaclass=_ABCSingleton):
        pass

    assert id(_A()) == id(_A())

# Generated at 2022-06-23 14:03:42.574767
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingletonABC(object):
        """
        Unit test class for _ABCSingleton class
        """
        __metaclass__ = _ABCSingleton

    class SingletonBase(object):
        """
        Unit test class for _ABCSingleton class
        """
        __metaclass__ = Singleton

    assert not issubclass(SingletonABC, SingletonBase)

# Generated at 2022-06-23 14:03:53.479447
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    # test parent class
    assert issubclass(CLIArgs, ImmutableDict)
    assert issubclass(CLIArgs, Mapping)

    # test __init__
    # when given an 'mapping' argument, it tries to convert it into an
    # 'ImmutableDict' object.
    # but if mapping has an 'ImmutableDict' object element,
    # it should be skipped to convert.
    test_dict = {
        'k1': 'v',
        'k2': ImmutableDict({'k2.1': 'v2.1'}),
        'k3': ['a', 'b', 'c'],
    }
    cli_args = CLIArgs(test_dict)
    # '__init__' has been called, it will set values to each element using 'super'.

# Generated at 2022-06-23 14:03:55.297760
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    globals()['GlobalCLIArgs'].__new__(GlobalCLIArgs)

# Generated at 2022-06-23 14:03:58.768507
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(Foo(), Foo)
    second_inst = Foo()
    assert second_inst is Foo.instance()