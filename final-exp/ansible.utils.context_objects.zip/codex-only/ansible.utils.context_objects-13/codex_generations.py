

# Generated at 2022-06-23 13:54:06.298051
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.basic import AnsibleModule

    parser = AnsibleModule._create_parser()
    (options, args) = parser.parse_args()
    args = CLIArgs.from_options(options)

    assert is_immutable(args["module_path"])
    assert is_immutable(args["forks"])

# Generated at 2022-06-23 13:54:09.634934
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    class C(A, B):
        pass

    assert A is B
    assert A is C

# Generated at 2022-06-23 13:54:20.891158
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test construction of CLIArgs object

    Confirm that we recursively convert mutable data types into immutable ones

    :return: Empty array if test succeeded or message if it fails
    """

    import json
    import tempfile
    import ansible.module_utils.common.argparse as argparse

    # Create a temporary file to hold our json input
    tempdir = tempfile.mkdtemp()
    with open(tempdir + "/my_json_file", "w") as f:
        f.write('{"list": [1, 2, "string"], "dict": {"key1": "value1", "key2": "value2", "list2": [1, "two"]}, "string": "blah"}')

    # Create a temporary file to hold our ini input

# Generated at 2022-06-23 13:54:22.938033
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
   myArgs = CLIArgs.from_options(['-m', 'shell', '-a', 'ls -l'])
   assert True == myArgs['check']

# Generated at 2022-06-23 13:54:33.667465
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    fake_options = {'a': 1, 'b': 2, 'c': 3}
    assert CLIArgs(fake_options).to_dict() == {'a': 1, 'b': 2, 'c': 3}

    fake_options = {'a': 1, 'b': 2, 'c': [1, 2, 3]}
    assert CLIArgs(fake_options).to_dict() == {'a': 1, 'b': 2, 'c': (1, 2, 3)}

    fake_options = {'a': 1, 'b': 2, 'c': [1, 2, [3, 4]]}
    assert CLIArgs(fake_options).to_dict() == {'a': 1, 'b': 2, 'c': (1, 2, (3, 4))}


# Generated at 2022-06-23 13:54:35.425210
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'test_key': ['test_value', 12]}
    args = CLIArgs(test_dict)
    assert args == {'test_key': ('test_value', 12)}
    assert 'test_key' in args
    assert all([isinstance(val, tuple) for val in args.values()])

# Generated at 2022-06-23 13:54:37.862465
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, ABCMeta)
    assert issubclass(_ABCSingleton, Singleton)

# Generated at 2022-06-23 13:54:43.843747
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABCMetaclass(_ABCSingleton):
        pass

    class TestABCClassWithMetaclass(object):
        __metaclass__ = TestABCMetaclass

    assert TestABCMetaclass('a', (TestABCMetaclass, ), {}) == TestABCMetaclass('a', (TestABCMetaclass, ), {})


GlobalCLIArgs()  # For testing just the GlobalCLIArgs class

# Generated at 2022-06-23 13:54:46.068795
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options:
        def __init__(self):
            self.foo = "bar"

    options = Options()
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-23 13:54:51.198872
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Assert that GlobalCLIArgs() fails because it is a Singleton
    emsg = 'GlobalCLIArgs() is a singleton and should only ever be referenced with GlobalCLIArgs.instance()'
    try:
        GlobalCLIArgs()
    except RuntimeError as e:
        assert str(e) == emsg
    except Exception as e:
        assert False, 'Unexpected exception in GlobalCLIArgs, {}'.format(e)
    else:
        assert False, 'Expected exception not raised in GlobalCLIArgs'

# Generated at 2022-06-23 13:54:54.859967
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _Singleton(object):
        __metaclass__ = _ABCSingleton
    assert 1 == len(set([_Singleton, _Singleton()]))

# Generated at 2022-06-23 13:55:04.502457
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test setting the __init__ method of CLIArgs
    # 1. ValueError when 'mapping' is empty
    # 2. TypeError when 'mapping' is not dict
    # 3. set 'self.__data' as {u'key': u'value'} when 'mapping' is {u'key': u'value'}
    try:
        a = CLIArgs({})
    except ValueError:
        pass
    else:
        pass
    try:
        a = CLIArgs('abc')
    except TypeError:
        pass
    else:
        pass
    a = CLIArgs({u'key': u'value'})
    assert a.__data == {u'key': u'value'}


# Generated at 2022-06-23 13:55:10.227739
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs.instance('connections', 'ssh')
    assert isinstance(args, CLIArgs)
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, Mapping)
    assert isinstance(args['connections'], text_type)



# Generated at 2022-06-23 13:55:21.060383
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    # simplest reference case
    class C(dict):
        pass

    class D(dict):
        pass

    c = C()
    d = D()
    args = CLIArgs({'foo': c, 'bar': d})
    assert(isinstance(args, dict))
    assert(args is not c)
    assert(args is not d)
    assert(args['foo'] is c)
    assert(args['bar'] is d)

    # the __dict__ of a class is a dictionary, and so it is a dict
    class E(object):
        pass

    e = E()
    e.foo = {'bar': 'baz'}
    args = CLIArgs({'foo': [e.foo]})
    assert(isinstance(args, dict))
    assert(args is not e.foo)

# Generated at 2022-06-23 13:55:25.806464
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    args = parser.parse_args()
    global_args = GlobalCLIArgs.from_options(args)
    assert global_args['verbosity'] == 0
    assert isinstance(global_args, ImmutableDict)

# Generated at 2022-06-23 13:55:30.555218
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object, metaclass=_ABCSingleton):
        pass

    class B(object, metaclass=_ABCSingleton):
        pass

    try:
        class C(A, B):
            pass
    except TypeError as e:
        assert str(e).startswith("Cannot create a consistent method resolution")
    else:
        assert False, "_ABCSingleton did not enforce unambiguous hierarchy"

# Generated at 2022-06-23 13:55:34.448530
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    d = {'a': 'b'}
    c = CLIArgs(d)
    assert c == d
    assert c.a == 'b'
    assert c['a'] == 'b'
    assert isinstance(c, ImmutableDict)



# Generated at 2022-06-23 13:55:35.441566
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert GlobalCLIArgs({})

# Generated at 2022-06-23 13:55:48.311402
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.text.converters import window_to_line_output
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    import json
    import types

    # Test the CLIArgs constructor to ensure that it can handle all common data types
    # without error. It also tests the handling of creating frozen dicts of non-mutable data types.

# Generated at 2022-06-23 13:55:58.111500
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import json
    import datetime
    import random

    test_dict = {
        'a': ['b', 'c', [1, 2, 3], {'d': ['e', 'f'], 'g': 'h'}],
        'z': 42,
        'json': json,
        'datetime': datetime,
        'random': random,
        'bad': set()
    }

    # Should error becuase sets aren't immutable
    try:
        CLIArgs(test_dict)
    except TypeError:
        pass
    else:
        assert False

    test_dict.pop('bad')

    cli_args = CLIArgs(test_dict)

    assert cli_args == test_dict
    assert cli_args.get('z') == 42
    assert cli_args.get('a')

# Generated at 2022-06-23 13:56:07.410642
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        """
        Class A to be used as test code for _ABCSingleton
        """
        def __init__(self):
            """
            Initialize instance variables
            """
            self.test_variable = "test_value"

    class B(object):
        """
        Class B to be used as test code for _ABCSingleton
        """
        def __init__(self):
            """
            Initialize instance variables
            """
            self.test_variable = "wrong_value"

    def test_function():
        """
        Function that tests _ABCSingleton constructor
        """
        class C(A, B, metaclass=_ABCSingleton):
            """
            Class C as Metaclass for new subclass
            """

        # test that class A overrides class B
        instance_c = C

# Generated at 2022-06-23 13:56:12.198829
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    instance1 = GlobalCLIArgs.instance({'foo':'bar'})
    instance2 = GlobalCLIArgs.instance({'foo':'bar'})
    assert id(instance1) == id(instance2)
    instance1 = GlobalCLIArgs.instance({'foo':'baz'})
    assert id(instance1) == id(instance2)

# Generated at 2022-06-23 13:56:21.842254
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    def get_global_cli_args():
        import sys
        import argparse

        parser = argparse.ArgumentParser()
        parser.add_argument("debug", choices=["on", "off"])
        parser.add_argument("--inventory", type=str, default="test/test_inventories/test_inventory")

        return GlobalCLIArgs.from_options(parser.parse_args(sys.argv[1:]))

    # Get the global cli args and ensure that it is consistent with the object type
    global_cli_args = get_global_cli_args()
    assert isinstance(global_cli_args, GlobalCLIArgs)
    assert isinstance(global_cli_args, CLIArgs)
    assert isinstance(global_cli_args, ImmutableDict)

# Generated at 2022-06-23 13:56:24.719506
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    obj = GlobalCLIArgs(dict(foo="bar"))
    assert obj.get("foo") == "bar"

# Generated at 2022-06-23 13:56:31.018517
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    a = CLIArgs({'a':1})
    assert isinstance(a, ImmutableDict)
    assert a['a'] == 1
    assert a.get('a') == 1
    assert a.a == 1
    assert a.get('b') == None
    assert a.b == None
    assert 'a' in a
    assert 'b' not in a


# Generated at 2022-06-23 13:56:35.602452
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class AAA(object):
        __metaclass__ = _ABCSingleton
    assert issubclass(AAA, ABCMeta)
    a1 = AAA()
    a2 = AAA()
    assert a1 is a2

# Generated at 2022-06-23 13:56:41.844870
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Does the __init__ method do what we expect?
    mapping = {'foo': 'f', 'bar': 'b'}
    test = GlobalCLIArgs(mapping)
    assert test['foo'] == 'f'
    # Exercise the _make_immutable function
    test['bar'] = {'a': 'b'}
    assert test['bar'] == ImmutableDict({'a': 'b'})
    # And the decorator
    assert isinstance(test, GlobalCLIArgs)



# Generated at 2022-06-23 13:56:50.720696
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import argparse

    parser = argparse.ArgumentParser(description="Self Test")
    parser.add_argument('--foo', action='store_true', default=False)
    parser.add_argument('--bar', action='store_true', default=False)

    a = parser.parse_args(['--foo'])
    b = parser.parse_args(['--foo', '--bar'])
    c = parser.parse_args(['--bar'])

    assert a == CLIArgs(vars(a)).mutable

    # Different entries in different orders is also a failure
    bad = CLIArgs(vars(b)).mutable
    bad['foo'] = False
    assert a != bad

    # Immutability test
    d = CLIArgs(vars(c))

# Generated at 2022-06-23 13:56:54.692966
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test normal use
    test_data = {'a': 1, 'b': 2, 'c': 'three', 'd': (1, 2, 3)}
    test_object = CLIArgs(test_data)
    assert isinstance(test_object, ImmutableDict)
    assert isinstance(test_object, CLIArgs)
    assert test_object == test_data



# Generated at 2022-06-23 13:56:59.201891
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    cli_args = GlobalCLIArgs({'foo': 'bar'})
    assert cli_args['foo'] == 'bar'
    # Should not be able to change the underlying data
    try:
        cli_args['foo'] = 'baz'
        assert False, 'Able to change a GlobalCLIArgs value'
    except TypeError:
        pass

# Generated at 2022-06-23 13:57:05.574550
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert(A() == B())
    assert(A() == C())
    assert(B() == C())


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-23 13:57:16.071433
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # This can't be in the tests directory because it causes cycle import issues
    # It is based around the fact that the GlobalCLIArgs constructor is only called once
    # and each time after it is called it will return the same object.  The constructor
    # also calls setattr on it's self to create a self.extras attribute which stores
    # a copy of the args it was passed.  So we can check that the constructor is working
    # by checking that self.extras is the same as what was passed to the constructor
    # on the first call but not on the second.  It should always be equal to the
    # first value.  This also tests that the _make_immutable method is working as
    # expected.
    # Note that this test is dependent on the Singleton __new__ method and the
    # CLIArgs constructor.
    import copy

# Generated at 2022-06-23 13:57:20.005819
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestContainer1(object):
        __metaclass__ = _ABCSingleton
    class TestContainer2(object):
        __metaclass__ = _ABCSingleton
    assert TestContainer1() is TestContainer1()
    assert TestContainer1() is not TestContainer2()



# Generated at 2022-06-23 13:57:22.698568
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _SingletonTestClass(object):
        __metaclass__ = _ABCSingleton
    new_class = _SingletonTestClass()
    assert new_class is _SingletonTestClass()

# Generated at 2022-06-23 13:57:29.509157
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    data = dict(foo=123, bar=dict(baz='spam'))
    args = CLIArgs(data)
    assert args.foo == 123
    assert args.bar.baz == 'spam'
    assert isinstance(args, ImmutableDict)
    assert isinstance(args.bar, ImmutableDict)
    assert isinstance(args.bar, Mapping)
    assert isinstance(args.bar, Container)
    assert not isinstance(args.bar, Sequence)
    assert not isinstance(args.bar, Set)

# Generated at 2022-06-23 13:57:30.993420
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli.arguments import options
    GlobalCLIArgs(vars(options))

# Generated at 2022-06-23 13:57:37.788936
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # This is a unit test for the class GlobalCLIArgs.
    from ansible.module_utils._text import to_bytes

    class ParseArgsTest(object):
        def __init__(self):
            self.foo = 'bar'
            self.bam = {'boom': 'pow'}

    args = ParseArgsTest()
    global_cli_args = GlobalCLIArgs.from_options(args)

    # Test 1.
    # Verify we saved the args
    assert global_cli_args.foo == 'bar'
    assert global_cli_args.bam.boom == 'pow'

    # Test 2.
    # Verify that we cannot change the args

# Generated at 2022-06-23 13:57:47.119429
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    original_args = {'foo': 'bar', 'ham': {'spam': 'eggs', 'spam2': ('eggs', 'eggs2')}}
    new_args = CLIArgs(original_args)
    assert new_args.get('foo') == 'bar'
    assert new_args.get('ham') == {'spam': 'eggs', 'spam2': ('eggs', 'eggs2')}
    assert not isinstance(new_args.get('ham'), ImmutableDict)
    assert isinstance(new_args.get('ham').get('spam2'), Sequence)
    assert isinstance(new_args.get('ham').get('spam2'), tuple)
    assert not isinstance(new_args.get('ham').get('spam2'), list)

# Generated at 2022-06-23 13:57:58.540209
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import os
    import sys
    from argparse import Namespace

    # Make a fake class that we can use in place of argparse.Namespace
    class FakeNamespace(object):
        def __init__(self, *args, **kwargs):
            pass

        def __setitem__(self, key, value):
            setattr(self, key, value)

    options = FakeNamespace()
    options['become'] = False
    options['become_user'] = None
    options['connection'] = 'smart'
    options['extra_vars'] = []
    options['flush_cache'] = None
    options['force_handlers'] = False
    options['inventory'] = []
    options['listhosts'] = None
    options['listtags'] = None
    options['listtasks'] = None

# Generated at 2022-06-23 13:58:03.237373
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {
        'key': 'value',
        'key1': 'value1'
    }
    cli_args = CLIArgs(args)

    assert cli_args['key'] == 'value'
    assert cli_args['key1'] == 'value1'



# Generated at 2022-06-23 13:58:08.424316
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.basic import AnsibleModule
    ansible_module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    global_vars = GlobalCLIArgs.from_options(ansible_module.get_parsed_cli_args())
    assert global_vars is not None
    assert len(global_vars) > 0

# Generated at 2022-06-23 13:58:19.188858
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    def set_args(args, *argv):
        args.reset()
        args.parse_args(argv)

    def check_args(argv):
        args = GlobalCLIArgs()
        assert args == ImmutableDict(), "args should be empty"
        set_args(args, *argv)
        assert args, "args shouldn't be empty"

    def check_args_not_empty(argv):
        args = GlobalCLIArgs()
        assert args == ImmutableDict(), "args should be empty"
        set_args(args, *argv)
        assert args, "args shouldn't be empty"
        args2 = GlobalCLIArgs()
        assert args2 != ImmutableDict(), "args should not be empty"
        assert args == args2, "args should be equal"


# Generated at 2022-06-23 13:58:23.506982
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    def set_args(args):
        GlobalCLIArgs.instance = GlobalCLIArgs(args)

    def get_args():
        return GlobalCLIArgs.instance

    set_args({'connection': 'smart', 'subset': 'all'})
    args = get_args()
    assert isinstance(args, ImmutableDict)
    assert not args.get('connection') == 'docker'

# Generated at 2022-06-23 13:58:25.908866
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _Test(_ABCSingleton):
        def __init__(self, value):
            self.value = value

    room = _Test(value='room')
    closer = _Test(value='closer')

    assert room is closer
    assert room.value == closer.value

# Generated at 2022-06-23 13:58:37.157944
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.encrypt import _get_encrypt_secret
    import ansible.constants as C
    import ansible.utils.vault as vault

    vault.VaultLib.get_vault_secrets = lambda x: VaultSecrets()

    class CLIArgsClass():
        pass

    class VaultSecrets():
        def get_secret(self, password):
            return u'testpass'

    # Create the object to be added to the GlobalCLIArg object
    cli_args = CLIArgsClass()
    cli_args.become_ask_pass = 'test'
    cli_args.vault_password = 'testpass'

# Generated at 2022-06-23 13:58:45.969275
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # test if CLIArgs is implemented correctly
    class A:
        def __init__(self):
            self.x = {'a': 1, 'b': [1, 2, 'c'], 'd': {'x': 1, 'y': 'z'}}
    a = A()
    args = CLIArgs(a.x)
    assert args is not None
    assert args == a.x
    assert args.__class__ == ImmutableDict
    assert args['a'] == 1
    assert args['b'] == (1, 2, 'c')
    assert args['d'] == ImmutableDict({'x': 1, 'y': 'z'})

# Generated at 2022-06-23 13:58:50.494424
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    A correct implementation of _ABCSingleton should have a dict
    """
    class TestClass(metaclass=_ABCSingleton):
        pass
    assert isinstance(TestClass().__dict__, dict)
    assert TestClass() is TestClass()
    assert TestClass().__dict__ is TestClass().__dict__

# Generated at 2022-06-23 13:58:53.570292
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    try:
        _ = CLIArgs({})
    except Exception as e:
        assert False, ('test_CLIArgs(): ' 'raised %s' % (e))

# Generated at 2022-06-23 13:59:00.675857
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Ensure that the metaclass has no bugs"""
    # pylint: disable=too-few-public-methods
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    # pylint: enable=too-few-public-methods

    assert A is B, "B should have been created as a Singleton version of A"

# Generated at 2022-06-23 13:59:10.261753
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import pytest


# Generated at 2022-06-23 13:59:18.883699
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    cli_args = CLIArgs({'a': 1, 'b': 2})
    assert isinstance(cli_args, CLIArgs)
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args.get('a') == 1
    assert cli_args.get('b') == 2
    assert isinstance(cli_args, Mapping)
    assert isinstance(cli_args, Container)
    GlobalCLIArgs.clear()
    GlobalCLIArgs._singleton_instance = None
    try:
        cli_args2 = GlobalCLIArgs({'a': 1, 'b': 2})
    except TypeError as e:
        assert str(e) == 'TypeError: Cannot override immutable object of type GlobalCLIArgs'
    except Exception as e:
        assert isinstance(e, TypeError)



# Generated at 2022-06-23 13:59:26.700093
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({u'foo': True})
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, Singleton)
    assert isinstance(args, _ABCSingleton)
    assert isinstance(args, GlobalCLIArgs)
    assert isinstance(args, CLIArgs)
    assert args[u'foo'] is True
    with pytest.raises(TypeError):
        args[u'bar'] = False

# Generated at 2022-06-23 13:59:36.515715
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.cli.arguments import options
    cli_args = CLIArgs.from_options(options)

# Generated at 2022-06-23 13:59:43.117198
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class testclass:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    # Test singleton class
    class testclass1(object, metaclass=_ABCSingleton):
        pass

    # Test class in Class CLIArgs
    class testclass2():
        pass

    class testclass3(testclass2):
        def __init__(self, a, b):
            self.a = a
            self.b = b

    class testclass4(testclass2):
        def __init__(self, a, b):
            self.a = a
            self.b = b

    class testclass5(testclass2):
        def __init__(self, a, b):
            self.a = a
            self.b = b

    # test Class CLI

# Generated at 2022-06-23 13:59:51.269456
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # test dictionary with nested dictionary, list, and tuple, and string, int
    mydict = {'stringkey':'stringval', 'listkey':['listval1','listval2'],
              'tuplekey':('tupleval1','tupleval2'), 'intkey': 1,
              'dictkey': {'dictval1':1, 'dictval2':2}
              }
    myarg = GlobalCLIArgs(mydict)
    assert(myarg == mydict)
    # test that GlobalCLIArgs does not allow setting key
    mydict['stringkey'] = 'newstring'
    assert(myarg != mydict)

# Generated at 2022-06-23 13:59:53.837329
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Test that CLIArgs behaves as expected"""
    args = CLIArgs({'param1': 'first arg', 'param2': [1, 2, 3]})

    assert args['param1'] == 'first arg'
    assert args['param2'] == (1, 2, 3)

    with pytest.raises(AttributeError, message='Fail to prevent mutation'):
        args['param1'] = 'second arg'


# Generated at 2022-06-23 14:00:01.281925
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    arg1 = 'testArg1'
    arg2 = 'testArg2'
    options = ImmutableDict(arg1=arg1, arg2=arg2)
    cliArgs = GlobalCLIArgs.from_options(options)
    assert cliArgs == options
    # Make sure it is a singleton
    from ansible.utils.singleton import SingletonError
    try:
        cliArgs2 = GlobalCLIArgs(options)
    except SingletonError:
        pass
    else:
        pytest.fail('GlobalCLIArgs is not a Singleton')

# Generated at 2022-06-23 14:00:06.248310
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    test_instance_1 = TestClass()
    test_instance_2 = TestClass()
    assert test_instance_1 is test_instance_2
    assert isinstance(test_instance_1, ABCMeta)
    assert isinstance(test_instance_1, Singleton)

# Generated at 2022-06-23 14:00:12.795565
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    assert isinstance(A(), A)
    assert isinstance(A(), B)
    assert isinstance(B(), A)

    class C(object):
        __metaclass__ = _ABCSingleton

    try:
        class D(A, C):
            pass
        # if we get here, there was no ambiguous multuple inheritance error
        raise AssertionError('Should have been an error')
    except TypeError:
        pass

# Generated at 2022-06-23 14:00:17.232702
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # pylint: disable=too-few-public-methods
    class MetaClass(metaclass=_ABCSingleton):
        pass
    MetaClass()

# Generated at 2022-06-23 14:00:26.278095
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Initialization
    cli_args = ImmutableDict({'ANSIBLE_KEEP_REMOTE_FILES': True, 'ANSIBLE_REMOTE_TEMP': '/home/ansible/tmp', 'C': True})
    # Action on Module
    cli_args = GlobalCLIArgs.from_options(cli_args)
    assert cli_args['ANSIBLE_KEEP_REMOTE_FILES'] == True
    assert cli_args['ANSIBLE_REMOTE_TEMP'] == '/home/ansible/tmp'
    assert cli_args['C'] == True


# Generated at 2022-06-23 14:00:29.540907
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = ImmutableDict(foo='bar')
    args = GlobalCLIArgs.from_options(options)
    assert isinstance(args, CLIArgs)
    assert isinstance(args, GlobalCLIArgs)
    assert isinstance(args, ImmutableDict)
    assert args == options

# Generated at 2022-06-23 14:00:33.734618
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Make a GlobalCLIArgs object to test the constructor"""
    a = GlobalCLIArgs({'a': True})


if __name__ == '__main__':
    test_GlobalCLIArgs()

# Generated at 2022-06-23 14:00:37.286928
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.executor.playbook_executor import PlaybookExecutor
    pex = PlaybookExecutor()
    pex.run()

    assert isinstance(pex._tqm._options, CLIArgs)

# Generated at 2022-06-23 14:00:39.222333
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs(dict())
    assert not global_cli_args

# Generated at 2022-06-23 14:00:45.362919
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Smoke test the GlobalCLIArgs class is immutable.
    """
    import pytest
    import ansible.constants as C

    # pylint: disable=protected-access
    args = GlobalCLIArgs._GlobalCLIArgs__instance = None
    try:
        a = GlobalCLIArgs(vars(C))
        a['connection'] = 'local'
        with pytest.raises(AttributeError):
            a['become'] = False
    finally:
        GlobalCLIArgs._GlobalCLIArgs__instance = args

# Generated at 2022-06-23 14:00:49.577178
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class FooSingleton(_ABCSingleton):
        pass

    # Instances should be the same when using the same metaclass
    foo = FooSingleton()
    foo_second = FooSingleton()
    assert foo is foo_second

# Generated at 2022-06-23 14:00:54.564308
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import yaml
    example_arg_dict = {
        'one': None,
        'two': [1, 2, 3],
        'three': [
            {'four': {
                'five': 5,
                'six': 6
            }},
            7
        ],
        'eight': {
            'nine': 9
        }
    }
    GlobalCLIArgs(example_arg_dict)

# Generated at 2022-06-23 14:01:01.546056
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class DummyOptions(object):
        pass

    # Test that we are properly setting __slots__
    options = DummyOptions()
    options.foo = 'bar'
    options.baz = 123
    args = GlobalCLIArgs.from_options(options)
    assert args['foo'] == 'bar'
    assert args['baz'] == 123

    # Test that we prevent extra attributes
    try:
        args.foobar = 'baz'
    except AttributeError:
        pass
    else:
        assert False, "we allowed assigning a new attribute to an immutable object!"

# Generated at 2022-06-23 14:01:05.870650
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class X(object):
        __metaclass__ = _ABCSingleton
        def __init__(self, x):
            self.x = x
    x1 = X('foo')
    x2 = X('bar')
    assert id(x1) == id(x2)
    assert x1.x == x2.x == 'foo'

# Generated at 2022-06-23 14:01:08.593752
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class ChildClass(object):
        __metaclass__ = _ABCSingleton

    c1 = ChildClass()
    c2 = ChildClass()
    assert c1 is c2

# Generated at 2022-06-23 14:01:18.325736
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ABCSingleton(_ABCSingleton):
        pass

    class ABCSingletonA(ABCSingleton):
        pass

    class ABCSingletonB(ABCSingleton):
        pass

    assert isinstance(ABCSingleton(), ABCSingleton)
    assert isinstance(ABCSingletonA(), ABCSingletonA)
    assert not isinstance(ABCSingletonA(), ABCSingleton)
    assert isinstance(ABCSingletonB(), ABCSingletonB)
    assert not isinstance(ABCSingletonB(), ABCSingleton)
    assert isinstance(ABCSingletonA(), Singleton)
    assert isinstance(ABCSingletonB(), Singleton)

# Generated at 2022-06-23 14:01:25.453119
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    g = GlobalCLIArgs()
    g.update({'foo': {'bar': {'baz': [1, 2, 3]}}})
    # FIXME: Collection.update has changed args for 2.8.  This will trivially
    #  fail on a 2.8 build.  Need to fix test when we update our minimum
    #  version to 2.8
    #
    # Expected:
    #  Calling update() with a non-dict as the argument is deprecated
    #  For example:
    #    update({"foo": "bar"})
    #  Should be written as:
    #    update(foo="bar")
    g.update(new_key='new_value')

# Generated at 2022-06-23 14:01:27.929613
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = [(u'--foo', u'bar'), (u'--baz', u'qux')]

    cli_args = CLIArgs.from_options(args)
    assert cli_args == {u'foo': u'bar', u'baz': u'qux'}

# Generated at 2022-06-23 14:01:33.329637
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Try to create a new instance of class GlobalCLIArgs
    try:
        GlobalCLIArgs()
    except TypeError:
        # TypeError is raised if we create a new instance of
        # class GlobalCLIArgs.
        pass
    else:
        # GlobalCLIArgs always a singleton so
        # the code should raise TypeError
        assert False

# Generated at 2022-06-23 14:01:39.699233
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyMeta(type):
        pass

    class MyClass(metaclass=MyMeta):
        pass

    class MyClass2(metaclass=MyMeta):
        pass

    class MySingleton(metaclass=_ABCSingleton, bases=(MyClass,)):
        pass

    class MySingleton2(metaclass=_ABCSingleton, bases=(MyClass,)):
        pass
    class MySingleton3(metaclass=_ABCSingleton, bases=(MyClass2,)):
        pass

    class MySingleton4(metaclass=_ABCSingleton, bases=(MyClass,)):
        pass

    class MySingleton5(metaclass=_ABCSingleton, bases=(MyClass,)):
        pass


# Generated at 2022-06-23 14:01:44.283150
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs({'a': 1})

    assert isinstance(global_cli_args, GlobalCLIArgs)
    assert isinstance(global_cli_args, CLIArgs)
    assert isinstance(global_cli_args, ImmutableDict)

# Generated at 2022-06-23 14:01:49.773437
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(str, metaclass=_ABCSingleton):
        pass
    class B(str, metaclass=_ABCSingleton):
        pass
    assert A("abc") == A("abc")
    assert A("abc") is A("abc")
    assert A("def") == B("def")
    assert A("def") is B("def")

# Generated at 2022-06-23 14:01:54.073087
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    class FakeOpts():
        def __init__(self):
            self.foo = 'bar'
            self.baz = 'quz'

    GlobalCLIArgs.from_options(FakeOpts())

# Generated at 2022-06-23 14:02:03.548432
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ClassShouldntWork(metaclass=_ABCSingleton):
        pass

    with pytest.raises(TypeError):
        ClassShouldntWork()

    class ClassShouldntWork2(object, metaclass=_ABCSingleton):
        pass

    with pytest.raises(TypeError):
        ClassShouldntWork2()



# Generated at 2022-06-23 14:02:09.623577
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Regular constructor
    DEFAULT_VERBOSITY = 0
    args = CLIArgs({'verbosity': DEFAULT_VERBOSITY})
    assert args['verbosity'] == 0

    # from_options constructor
    from ansible.cli import CLI
    options = CLI.base_parser(use=['connection', 'inventory', 'module', 'vars'], desc="test").parse_args(['-vvv'])
    args = CLIArgs.from_options(options)
    assert args['verbosity'] == 3



# Generated at 2022-06-23 14:02:11.660645
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Dummy1:
        pass

    class Dummy2(Dummy1):
        pass


# Generated at 2022-06-23 14:02:21.565040
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'foo': ['a', 'b', 'c'], 'bar': {'baz': True}}
    args = CLIArgs(mapping)
    # Check that CLIArgs is immutable
    assert args['foo'] == ['a', 'b', 'c']
    assert args['bar']['baz']
    try:
        args['foo'] = ['b', 'c', 'd']
    except TypeError:
        assert True
    else:
        assert False
    # Check that CLIArgs is a container wrapper
    # Test the __getitem__ function of the wrapper
    assert args['bar']['baz']
    # Test the __len__ function of the wrapper
    assert len(args) == 2
    # Test the __contains__ function of the wrapper
    assert 'bar' in args
    # Test the __iter__

# Generated at 2022-06-23 14:02:32.906966
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import os
    from ansible.config.manager import ConfigManager
    from ansible.executor.cli.cli import get_cli_arg_parser

    parser = get_cli_arg_parser()

    # Put in some pretend command line arguments
    args = parser.parse_args()
    args.connection = 'local'
    args.module_path = [os.path.dirname(__file__)]
    args.inventory = './tests/unit/inventory'
    args.become = False
    args.become_method = 'sudo'
    args.become_user = 'admin'
    args.become_ask_pass = False
    args.remote_user = 'root'
    args.listhosts = False
    args.syntax = False
    args.check = False
    args.diff = False
    args

# Generated at 2022-06-23 14:02:37.069681
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli.arguments import CLIArgumentParser
    parser = CLIArgumentParser()
    options = parser.parse_args(args=[])
    args = GlobalCLIArgs.from_options(options)



# Generated at 2022-06-23 14:02:45.140734
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dictionary = {'foo': {'bar': 'baz', 'qux': [1, 2, 3], 'baz': {'spam': 'eggs'}},
                  'spam': set(['eggs', 'spam'])}
    args = CLIArgs(dictionary)

    assert(args['foo']['bar'] == 'baz')
    assert(isinstance(args['foo']['qux'], tuple))
    assert(args['foo']['qux'][1] == 2)
    assert(args['spam'] == set(['spam', 'eggs']))


# Generated at 2022-06-23 14:02:50.547228
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.argparse import Options
    option = Options()
    option.test = 1
    option.foo = 'bar'
    test_object = GlobalCLIArgs.from_options(option)
    assert test_object == {'test': 1, 'foo': 'bar'}

# Generated at 2022-06-23 14:02:56.443360
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs.__new__(CLIArgs, {"a": ["b"]}) == {"a": ("b",)}
    assert CLIArgs.__new__(CLIArgs, {"a": {"b": "c"}}) == {"a": ImmutableDict({"b": "c"})}
    assert CLIArgs.__new__(CLIArgs, {"a": ["b", {"c": "d"}]}) == {"a": ("b", ImmutableDict({"c": "d"}))}



# Generated at 2022-06-23 14:03:00.632879
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingletonSingleton(_ABCSingleton):
        pass

    class SingletonABCMeta(_ABCSingleton):
        pass

    assert issubclass(SingletonSingleton.__class__, Singleton)
    assert issubclass(SingletonABCMeta.__class__, ABCMeta)



# Generated at 2022-06-23 14:03:05.192755
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestDummy(object):
        __metaclass__ = _ABCSingleton

    test_obj_1 = TestDummy()
    test_obj_2 = TestDummy()
    assert(test_obj_1 == test_obj_2)
    assert(test_obj_1 is test_obj_2)


# Generated at 2022-06-23 14:03:10.148323
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingletonClassA(object, metaclass=_ABCSingleton):
        pass

    class SingletonClassB(object, metaclass=_ABCSingleton):
        pass

    a = SingletonClassA()
    b = SingletonClassB()
    assert(a is not b)
    a1 = SingletonClassA()
    b1 = SingletonClassB()
    assert(a is a1)
    assert(b is b1)

# Generated at 2022-06-23 14:03:14.045366
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options:
        pass
    options = Options()
    options.foo = 'bar'
    options.baz = 1
    options.whiz = True

    global_args = GlobalCLIArgs.from_options(options)
    assert global_args.foo == 'bar'
    assert global_args.baz == 1
    assert global_args.whiz is True

    try:
        global_args.foo = 'baz'
    except TypeError:
        # Good!
        pass
    else:
        assert False, "Should not be able to modify GlobalCLIArgs object!"

# Generated at 2022-06-23 14:03:24.650544
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class FakeOpts(object):
        def __init__(self, opts):
            self.__dict__.update(opts)
    options = FakeOpts({'a': 1,
                        'b': '2',
                        'c': [1, 2],
                        'd': set([1, 2, 3]),
                        'e': {'e1': 1, 'e2': 2, 'e3': 3},
                        'f': (1, 2, 3, 4, 5),
                        'g': frozenset([1, 2, 3]),
                        'h': '\u2665'})

# Generated at 2022-06-23 14:03:32.687148
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from collections import OrderedDict

    assert not isinstance(CLIArgs({'foo': 1}), Singleton)

    foo = object()
    bar = object()
    mutable = OrderedDict([('foo_list', ['bar', 'baz', 'qux']), ('foo_foo_dict', {'foo_bar': foo, 'bar_bar': bar}), ('baz', 'qux')])
    immutable = ImmutableDict([('foo_list', ('bar', 'baz', 'qux')), ('foo_foo_dict', ImmutableDict([('foo_bar', foo), ('bar_bar', bar)])), ('baz', 'qux')])
    assert CLIArgs(mutable) == immutable



# Generated at 2022-06-23 14:03:38.332123
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class AbstractClass(object):
        __metaclass__ = _ABCSingleton

        @classmethod
        def __subclasshook__(cls, subclass):
            # All classes are an instance of this abstract class
            return True
    class ConcreteClass(AbstractClass):
        pass
    assert issubclass(ConcreteClass, AbstractClass)
    assert ConcreteClass() is ConcreteClass()

# Generated at 2022-06-23 14:03:48.725246
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options():
        def __init__(self):
            self.foo = 'foo'
            self.bar = 'bar'
            self.list = [1, 2, 3]
            self.dict = { 'foo': 'foo', 'bar': 'bar'}

    dict_cli_args = CLIArgs.from_options(Options())

    assert dict_cli_args['foo'] == 'foo'
    assert dict_cli_args['bar'] == 'bar'
    assert dict_cli_args['list'] == (1, 2, 3)
    assert dict_cli_args['dict'] == ImmutableDict({ 'foo': 'foo', 'bar': 'bar'})

# Generated at 2022-06-23 14:03:56.593452
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options:
        pass

    opts = Options()
    opts.hello = ["world", "bye", "world"]
    opts.bye = {"hello": ["world", "bye", "world"]}
    opts.stuff = {"hello": ["world", {"hello": "bye"}]}
    opts.more_stuff = "bye"
    opts.pointless = None
    opts.list_of_list = [["hello", "world"], ["hello", "bye"], ["hello", "world"]]
    opts.list_of_list_with_dict = [["hello", {"hello": "bye"}]]

    args = CLIArgs.from_options(opts)


# Generated at 2022-06-23 14:04:05.880265
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import yaml
    parser = GlobalCLIArgs._get_parser()
    try:
        # Remove the help option as it has a special case handler in the underlying optparse
        # implementation that won't handle being called twice.  This breaks some of the tests
        # in module_utils/common/argparse.py:ArgumentParser
        parser.remove_option('-h')
        parser.remove_option('--help')
        args = '--connection=ssh --host=hostname --inventory=/file1.yaml,/file2.yaml --list-hosts --module-name=module --module-path=/path/to/modules --user=user --verbosity=3'
        args = parser.parse_args(args.split())
    except:
        # Fail out of the test with full stack trace
        raise