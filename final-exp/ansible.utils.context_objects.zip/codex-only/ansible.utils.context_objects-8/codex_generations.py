

# Generated at 2022-06-23 13:54:07.524097
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict

    assert isinstance(CLIArgs({'test': 'value'}), ImmutableDict)
    assert isinstance(CLIArgs({'test': 'value'}), CLIArgs)

    assert isinstance(GlobalCLIArgs({'test': 'value'}), ImmutableDict)
    assert isinstance(GlobalCLIArgs({'test': 'value'}), CLIArgs)
    assert isinstance(GlobalCLIArgs({'test': 'value'}), GlobalCLIArgs)

# Generated at 2022-06-23 13:54:09.294498
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Unit test to ensure that GlobalCLIArgs can be created."""
    GlobalCLIArgs()

# Generated at 2022-06-23 13:54:20.750228
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import collections
    import sys

    normal_dict = {
        'a': 1,
        'b': 2,
        'c': [1, 2, 3],
        'd': {
            'A': 1,
            'B': 2,
            'C': [1, 2, 3],
        },
    }

    args = GlobalCLIArgs(normal_dict)

    if sys.version_info[0] < 3:
        assert isinstance(args, collections.Hashable)
        assert isinstance(args, collections.Iterable)
        assert isinstance(args, collections.Mapping)
        assert isinstance(args, collections.MutableMapping)
        assert isinstance(args, collections.MutableSequence)
        assert isinstance(args, collections.MutableSet)

# Generated at 2022-06-23 13:54:22.072317
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = ImmutableDict()
    GlobalCLIArgs(options)


# Generated at 2022-06-23 13:54:24.237926
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass



# Generated at 2022-06-23 13:54:34.539512
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():  # pylint: disable=missing-docstring
    import inspect
    import pytest

    # Adding a new field to the this class is not a backwards compatible change
    fields = {"_args", "_instance", "_is_initialized"}
    new_fields = set(GlobalCLIArgs.__dict__.keys()) - fields
    assert not new_fields, '__init__ has new fields: {}'.format(', '.join(new_fields))

    # Adding a new arg to the constructor is a backwards compatible change
    constructor_args = inspect.getargspec(GlobalCLIArgs.__init__)
    assert constructor_args.args == ['self', 'args'], '__init__ has new arguments: {}'.format(', '.join(constructor_args.args))

# Generated at 2022-06-23 13:54:46.234389
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test for a single key-value pair nested in a dictionary
    dictionary = {'name': 'Python'}
    assert _make_immutable(dictionary) == ImmutableDict({'name': 'Python'})

    # Test for a single key-value pair nested in a dictionary
    dictionary = {'a': 1, 'b': 2, 'c': 3}
    assert _make_immutable(dictionary) == ImmutableDict({'a': 1, 'b': 2, 'c': 3})

    # Test for two key-value pairs nested in a dictionary
    dictionary = {'a': {'b': 2}, 'b': 2}
    assert _make_immutable(dictionary) == ImmutableDict({'a': ImmutableDict({'b': 2}), 'b': 2})

    # Test for a single key-value

# Generated at 2022-06-23 13:54:48.241811
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_args = GlobalCLIArgs({'foo': 'bar'})
    assert isinstance(global_args, GlobalCLIArgs)

# Generated at 2022-06-23 13:54:57.533246
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options:
        v = 1
        b = True
        s = "spam"
        D = (1,2,3)
        I = {1:1, 2:4, 3:9}

    # Make sure instantiations behave as expected
    gcli = GlobalCLIArgs()
    gcli.update(CLIArgs.from_options(Options()))

    assert gcli.get("v") == 1
    assert gcli.get("b") is True
    assert gcli.get("s") == "spam"
    assert gcli.get("D") == (1,2,3)
    assert gcli.get("I") == ImmutableDict({1:1, 2:4, 3:9})

    # Ensure it is immutable
    with pytest.raises(TypeError):
        gcli["v"]

# Generated at 2022-06-23 13:55:01.429732
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    assert B() is B()
    assert A() is not B()
    assert isinstance(A(), A)
    assert isinstance(B(), B)
    assert isinstance(A(), B)

# Generated at 2022-06-23 13:55:04.503056
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestA(metaclass=_ABCSingleton):
        pass
    class TestB(metaclass=_ABCSingleton):
        pass
    TestA()
    TestB()

# Generated at 2022-06-23 13:55:11.093457
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class NonSingleton(object):
        pass

    class Singleton(object):
        __metaclass__ = _ABCSingleton

    class Concrete(object):
        pass

    class Abstract(object):
        __metaclass__ = ABCMeta

    class ConcreteSingleton(object):
        __metaclass__ = _ABCSingleton

    class AbstractSingleton(object):
        __metaclass__ = _ABCSingleton

    class NoOverride(object):
        __metaclass__ = _ABCSingleton

    class Override(object):
        __metaclass__ = _ABCSingleton

        @classmethod
        def __subclasshook__(cls, C):
            return True

    class First(object):
        """This should be the first metaclass"""
        __metaclass__ = _ABCSingleton


# Generated at 2022-06-23 13:55:21.652151
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = ImmutableDict({'a': 1, 'b': 'b_value'})
    b = ImmutableDict({'d': 2, 'c': 3})
    c = ImmutableDict({'d': a, 'x': b})
    d = ImmutableDict({'c': text_type('test'), 'z': binary_type(b'bin')})
    e = ImmutableDict({'y': c})
    f = ImmutableDict({'z': d})
    g = ImmutableDict({'abc': e, 'def': f})
    h = ImmutableDict({'a': 1, 'b': text_type('b_value'), 'c': set([1, 2, 3])})

# Generated at 2022-06-23 13:55:30.007095
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {
        'foo': 'bar',
        'baz': {'quz': 'quu', 'corge': [1, 2]},
    }
    toplevel = {
        'foo': 'bar',
        'baz': ImmutableDict({'quz': 'quu', 'corge': tuple([1, 2])}),
    }
    _cli_args = CLIArgs(args)
    assert _cli_args == toplevel


# Generated at 2022-06-23 13:55:38.561831
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class FakeOptionParser(object):
        def __init__(self, **values):
            self.values = values

        def __getattr__(self, item):
            return self.values[item]

    fake_parser = FakeOptionParser(base_path='/fake/path', check=True, diff=False,
                                   connection='fakeconnection', forks=10, extra_vars=['one', 'two'])

    args = GlobalCLIArgs.from_options(fake_parser)

    assert args == {
        'base_path': '/fake/path',
        'check': True,
        'diff': False,
        'connection': 'fakeconnection',
        'forks': 10,
        'extra_vars': ('one', 'two'),
    }

# Generated at 2022-06-23 13:55:48.802588
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import pytest

    mapping = {
        'first': {
            'second': {
                'third': 'test',
            },
        },
    }
    obj = CLIArgs(mapping)

    with pytest.raises(TypeError):
        # Can't change immutable dictionary.
        obj['first'] = 1234

    assert obj['first']['second']['third'] == 'test'

    mapping2 = {
        'first': {
            'second': {
                'third': 'test',
            },
        },
    }
    obj2 = CLIArgs(mapping2)

    assert obj == obj2


# Unit tests for subclass of CLIArgs, GlobalCLIArgs

# Generated at 2022-06-23 13:55:53.262701
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestOne(object):
        __metaclass__ = _ABCSingleton

    class TestTwo(TestOne):
        pass

    a = TestOne()
    b = TestTwo()
    assert a is b



# Generated at 2022-06-23 13:55:58.602352
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.args import AnsibleOptions
    options = AnsibleOptions()
    options.connection = 'local'
    options.become = 'root'
    options.module_path = 'test_module_path'
    options.check = False

    args = GlobalCLIArgs.from_options(options)
    assert args.connection == 'local'
    assert args.become == 'root'
    assert args.module_path == 'test_module_path'
    assert args.check is False

# Generated at 2022-06-23 13:56:03.857930
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'a': ['1', '2', '3'],
               'b': ['4', '5', '6'],
               'c': {'d': 7, 'e': 8, 'f': {'g': 9, 'h': 10}}}
    args = CLIArgs(mapping)
    assert(args['a'] == ('1', '2', '3'))
    assert(args['b'] == ('4', '5', '6'))
    assert(len(args['c']) == 3)
    assert(args['c']['d'] == 7)
    assert(args['c']['e'] == 8)
    assert(len(args['c']['f']) == 2)
    assert(args['c']['f']['g'] == 9)

# Generated at 2022-06-23 13:56:07.508418
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    options = type('', (), {})
    options.foo = 'bar'
    GlobalCLIArgs(vars(options))
    assert GlobalCLIArgs({'foo': str('bar')}) == GlobalCLIArgs.from_options(options)
    sys.exit(0)


if __name__ == "__main__":
    test_GlobalCLIArgs()

# Generated at 2022-06-23 13:56:10.908071
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    immutable_dict = _make_immutable({5: 'a'})
    assert isinstance(immutable_dict, ImmutableDict)
    assert immutable_dict == {5: 'a'}
    assert not isinstance(immutable_dict, dict)

# Generated at 2022-06-23 13:56:17.211792
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton(object):
        __metaclass__ = _ABCSingleton

    # Create and check the first instance
    instance1 = TestSingleton()
    assert id(instance1) == id(TestSingleton())

    # Create and check the second instance
    instance2 = TestSingleton()
    assert id(instance2) == id(TestSingleton())

    # Make sure first instance equals the second instance
    assert id(instance1) == id(instance2)

# Generated at 2022-06-23 13:56:26.828504
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """ Unit test for constructor of class GlobalCLIArgs"""

# Generated at 2022-06-23 13:56:35.356396
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Verify that the constructor converts everything to immutable data
    """
    mapping = {
        'alpha': 'one',
        'beta': ['one', 'two'],
        'gamma': {
            'sub_one': 'one',
            'sub_two': ['one', 'two'],
            'sub_three': {
                'subsub_one': 'one',
                'subsub_two': ['one', 'two'],
                'subsub_three': {'subsubsub_one': 'one'},
            },
        },
    }
    immutable = CLIArgs(mapping)
    assert immutable.alpha == 'one'
    assert immutable.beta == ('one', 'two')
    assert immutable.gamma.sub_one == 'one'

# Generated at 2022-06-23 13:56:38.952218
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import doctest

    # For now we have this macro to let doctests run when you don't have
    # a terminal, such as when built from readthedocs
    # TODO: how to handle this better?
    if sys.__stdout__.isatty():
        doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-23 13:56:47.324419
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    The class _ABCSingleton is a class, so we can do a simple test of it here
    """
    class MetaTestClass(object):
        """A class for use in testing the _ABCSingleton class"""
        __metaclass__ = _ABCSingleton

    # Try to instantiate two instances of the class.  It should be a singleton,
    # so the second instantiation should return the first
    instance_1 = MetaTestClass()
    instance_2 = MetaTestClass()

    # Throw an error if the two are not the same
    assert instance_1 == instance_2

# Generated at 2022-06-23 13:56:55.904407
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.six.moves import builtins
    if hasattr(builtins, '__test__'):
        del builtins.__test__

    cli_args = GlobalCLIArgs.from_options(implemented_options)

    for key, value in implemented_options.items():
        try:
            assert cli_args[key] == value
        except AssertionError:
            raise AssertionError("Error, key %s is not value %s but is %s" % (key, value, cli_args[key]))


# Generated at 2022-06-23 13:57:03.571902
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import ansible.config as config
    import ansible.constants as constants
    import ansible.cli. CLI as CLI
    parser = CLI.base_parser(constants.DEFAULT_MODULE_PATH, 'test version')
    # This should be the only line needed to setup the args
    GlobalCLIArgs.from_options(parser.parse_args([]))
    # This should succeed because there is only one instance of GlobalCLIArgs
    # Try to create a new instance of GlobalCLIArgs
    args = GlobalCLIArgs({"foo": "bar"})
    # Check to see if there are different instances of GlobalCLIArgs
    assert id(GlobalCLIArgs()) is not id(args)
    # Check that the new instance is a copy of the original instance
    assert GlobalCLIArgs() == args
    # Check that the new instance

# Generated at 2022-06-23 13:57:06.663961
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    gca = GlobalCLIArgs(dict(foo='bar'))
    assert gca == dict(foo='bar')
    assert gca != dict(bar='foo')
    assert gca.foo == 'bar'
    pytest.raises(AttributeError, getattr, gca, 'bar')
    pytest.raises(TypeError, gca.__setitem__, 'foo', 'baz')
    pytest.raises(TypeError, gca.__delitem__, 'foo')

# Generated at 2022-06-23 13:57:10.984283
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({'one': '1'})

    # Test the __contains__ of the ImmutableDict class
    assert 'one' in args

    # Test the __getitem__ of the ImmutableDict class
    assert args['one'] == '1'

# Generated at 2022-06-23 13:57:20.743820
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import inspect
    from ansible.config.manager import ConfigManager

    # Since this is a Singleton, this code won't actually run in normal operations.  Only during
    # unit testing.
    #
    # If the class's __init__() method is called, then it's not a Singleton.
    #
    # We store the GlobalCLIArgs object in __globals__ so as not to hold a reference to it in the
    # unit test code.  Otherwise, weak references (used by the Singleton class) don't work.

    # Test that we actually have only one singleton instance.  The following code should create
    # exactly two instances, the singleton and the one we create here.
    #
    # Constructor, __init__() method, of GlobalCLIArgs is private.  So we have to get it from the


# Generated at 2022-06-23 13:57:30.239714
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import os
    import inspect
    import ansible.cli.adhoc

    # Make sure we are in the same directory as that of ansible-adhoc
    adhoc = os.path.dirname(inspect.getfile(ansible.cli.adhoc))
    os.chdir(adhoc)

    # Temporary file to pass as an option to ansible-adhoc
    fd, path = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as tmp:
        tmp.write('#!/usr/bin/python\n')
        tmp.write('import sys\n')
        tmp.write('print(sys.argv)')

    # Parsing command line arguments

# Generated at 2022-06-23 13:57:32.026626
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    with pytest.raises(AttributeError):
        GlobalCLIArgs(dict())

# Generated at 2022-06-23 13:57:40.314504
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Unit test for constructor of class GlobalCLIArgs

    # Set up with some test data
    data = {'ANSIBLE_REMOTE_TEMP': '/tmp/uktbgscwch',
            'ANSIBLE_REMOTE_USER': 'root',
            'ANSIBLE_RETRY_FILES_ENABLED': False,
            'ANSIBLE_SSH_ARGS': '',
            'ANSIBLE_TAGS': '',
            'ANSIBLE_VAULT_PASSWORD_FILE': '/etc/ansible/vault.key',
            'ANSIBLE_VERBOSITY': 0,
            'ANSIBLE_VERSION': '2.7.10',
            'ANSIBLE_VERSION_MAJOR': '2'}
    test_object = GlobalCLIArgs(data)

    # Ensure that the object is of the expected type


# Generated at 2022-06-23 13:57:47.020920
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass

    assert issubclass(A, Singleton)
    assert issubclass(A, ABCMeta)
    assert issubclass(A, A)
    assert issubclass(A, B)
    assert issubclass(A, C)
    assert issubclass(B, A)
    assert issubclass(B, B)
    assert issubclass(C, A)
    assert issubclass(C, C)

# Generated at 2022-06-23 13:57:50.256856
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(metaclass=_ABCSingleton):
        pass

    class C(A, B):
        pass

    class D(B, A):
        pass

    assert C is D

# Generated at 2022-06-23 13:57:51.742619
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    with pytest.raises(TypeError):
        args = GlobalCLIArgs(dict(a=1))

# Generated at 2022-06-23 13:57:58.427316
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    x = CLIArgs.from_options(ImmutableDict({'key1': 'value1', 'key2': ['element1', 'element2']}))
    assert isinstance(x, CLIArgs)

    assert x.get('key1') == 'value1'

    tl = x.get('key2', 'default')
    assert tl[0] == 'element1'
    assert tl[1] == 'element2'


# Generated at 2022-06-23 13:58:07.972781
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Unit test for constructor of class CLIArgs
    """
    assert CLIArgs({}) == {}
    assert CLIArgs({"x": "1"}) == {"x": "1"}
    assert CLIArgs({"x": {"y": "1"}}) == {"x": {"y": "1"}}
    assert CLIArgs({"x": {"y": {"z": "1"}}}) == {'x': {'y': {'z': '1'}}}

    # Check it converts mutable types to immutable types
    assert isinstance(CLIArgs({"x": "1"})["x"], text_type)
    assert isinstance(CLIArgs({"x": {'y': '1'}})["x"], ImmutableDict)

# Generated at 2022-06-23 13:58:12.808043
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Test that _ABCSingleton can be instantiated.

    This test is not really testing the correctness of the class.  It is only here to trigger a
    failure if the class cannot be instantiated.
    """
    class TestSingleton(_ABCSingleton):
        pass
    obj = TestSingleton()

# Generated at 2022-06-23 13:58:17.500585
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class NondescriptiveClassNameA(object):
        __metaclass__ = _ABCSingleton
    class NondescriptiveClassNameB(object):
        __metaclass__ = _ABCSingleton

    assert(NondescriptiveClassNameA() == NondescriptiveClassNameB())



# Generated at 2022-06-23 13:58:20.139551
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = ImmutableDict()
    options = options.copy()
    options = CLIArgs.from_options(options)
    options = GlobalCLIArgs(options)



# Generated at 2022-06-23 13:58:23.470859
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABCSingletonTest(object):
        __metaclass__ = _ABCSingleton
        def __init__(self):
            self.data = 'data'

    a = _ABCSingletonTest()
    b = _ABCSingletonTest()
    assert(id(a) == id(b))



# Generated at 2022-06-23 13:58:30.282019
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Import this locally so we get the right version of the class
    from ansible.module_utils.common.arguments import _ABCSingleton
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    assert B() is B()

# Generated at 2022-06-23 13:58:37.157880
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Make sure new is not listed as a valid method on the class
    assert not hasattr(GlobalCLIArgs, 'new')

    # Make sure we can get the same instance every time
    a = GlobalCLIArgs({'hi': 'there'})
    assert a is GlobalCLIArgs({'hi': 'there'})

    # Make sure we can't create a new instance of the class
    try:
        b = CLIArgs({'hi': 'there'})
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-23 13:58:42.451680
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    def take_takes_a_ABCSingleton(foo, bar):
        return bar

    class Foo(object):
        """Implement the same interface as object so we can pass it to take_takes_a_ABCSingleton"""
        pass

    class Bar(_ABCSingleton, object):
        pass

    take_takes_a_ABCSingleton(Foo(), Bar())

# Generated at 2022-06-23 13:58:46.851277
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test CLIArgs constructor directly.  GlobalCLIArgs is a singleton, and the
    # GlobalCLIArgs class is not exposed to pytest, so this is the only way to
    # test the code.
    cli_args = CLIArgs({})
    assert isinstance(cli_args, ImmutableDict)

# Generated at 2022-06-23 13:58:56.616221
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options:
        def __init__(self, d):
            for k, v in d.items():
                setattr(self, k, v)

    d = {'a': 'hello',
         'b': 1,
         'c': ['hello', 'world'],
         'd': {'1': 'hello', '2': 'world'},
         'e': 1,
         'g': ['hello', 'world'],
         'h': {'1': 'hello', '2': 'world'},
         }

    options = Options(d)

    global_cli_args = GlobalCLIArgs.from_options(options)

    for k, v in d.items():
        assert v == global_cli_args[k]



# Generated at 2022-06-23 13:59:02.369810
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs works as expected and that run_async_playbook isn't
    inadvertently storing and reading that flag in a different way
    """
    play_context = dict(remote_user='user')
    cliargs = CLIArgs(play_context)
    assert cliargs['remote_user'] == 'user'



# Generated at 2022-06-23 13:59:11.533648
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.vars import combine_vars
    """
    Test to check if the constructor of CLIArgs works as intended.
    """

# Generated at 2022-06-23 13:59:17.518232
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    data = {u'a': u'1', u'b': [u'2', u'3'], u'c': {u'c1': [u'4', u'5']}}
    imm_data = CLIArgs(data)
    assert imm_data[u'a'] == u'1'
    assert isinstance(imm_data[u'b'], tuple)
    assert isinstance(imm_data[u'c'], ImmutableDict)



# Generated at 2022-06-23 13:59:19.907610
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton(_ABCSingleton):
        pass

    a = TestSingleton()
    b = TestSingleton()
    assert a is b



# Generated at 2022-06-23 13:59:24.714713
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    import ansible.config.base
    from ansible.module_utils.common.params import extract_args

    config = ansible.config.base.ConfigData('test_config.cfg', [], False)
    options = extract_args(config)
    argv = ['/bin/python', 'ansible-playbook', '--version']
    args = GlobalCLIArgs.from_options(options.parse_args(argv))
    assert args

# Generated at 2022-06-23 13:59:35.025638
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    import unittest

    class Test(object):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            self.a = 1
            self.b = 2

        def __getattr__(self, attr):
            # Allows us to test that different instances of the same class with their own attributes
            # are still different objects.
            return self.__dict__[attr]

        # Explicity define a __str__ and __repr__ so that we can test if the expected instance is
        # returned by applying these built-in functions.  If we don't do this then we will get an
        # exception when unittest.mock.patch does it for us.
        def __str__(self):
            return 'Test'

        def __repr__(self):
            return 'Test'


# Generated at 2022-06-23 13:59:38.208266
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _AS1(object):
        __metaclass__ = _ABCSingleton

    class _AS2(object):
        __metaclass__ = _ABCSingleton

    as1 = _AS1()
    as2 = _AS2()
    assert as1 == as2


# Generated at 2022-06-23 13:59:43.508561
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = Singleton

    class Bar(object, metaclass=_ABCSingleton):
        pass

    class Baz(Bar):
        pass

    assert Foo() == Foo()
    assert Bar() == Bar()
    assert Baz() == Baz()
    assert Bar() == Baz()

# Generated at 2022-06-23 13:59:53.557549
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    This is a unit test to check for the proper construction of CLIArgs objects
    """
    args = {'a': 'b', 'c': 'd'}
    args_copy = {'a': 'b', 'c': 'd'}
    cliargs = CLIArgs(mapping=args)
    assert cliargs == args_copy
    assert cliargs == ImmutableDict(args)

    # Make sure that we correctly convert inside containers
    args = {'a': {'a1': 'b1', 'a2': 'b2'}}
    args_copy = {'a': {'a1': 'b1', 'a2': 'b2'}}
    cliargs = CLIArgs(mapping=args)
    assert cliargs == args_copy

# Generated at 2022-06-23 13:59:58.063393
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class a(object):
        __metaclass__ = _ABCSingleton

    class b(object):
        __metaclass__ = _ABCSingleton

    import pytest
    with pytest.raises(TypeError):
        a()
    with pytest.raises(TypeError):
        b()

    class c(a):
        pass

    from ansible.utils.singleton import SingletonError
    with pytest.raises(SingletonError):
        a()

# Generated at 2022-06-23 14:00:05.556516
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-23 14:00:12.310498
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    @add_metaclass(_ABCSingleton)
    class Foo(object):
        def __init__(self):
            self.x = 1
            self.y = 2

        def get_x(self):
            return self.x

        def get_y(self):
            return self.y

    class Bar(Foo):
        def __init__(self):
            super(Bar, self).__init__()
            self.z = 3

        def get_z(self):
            return self.z

    assert Bar() == Bar()



# Generated at 2022-06-23 14:00:25.726324
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    # Call the constructor
    GlobalCLIArgs({
        'foo': 1,
        'bar': 2,
        'baz': [3, 4, 5],
    })

    # Check that it set the variables correctly.  Using the fact that we are using a singleton
    # here to check that it is both setting the variables correctly, and only setting them once.
    # GlobalCLIArgs().__dict__ should have the same values as vars(options)
    options = {}
    options['foo'] = 1
    options['bar'] = 2
    options['baz'] = [3, 4, 5]
    assert GlobalCLIArgs().__dict__ == vars(options)

    # Check that it is immutable
    assert isinstance(GlobalCLIArgs().foo, int)
    assert isinstance(GlobalCLIArgs().bar, int)


# Generated at 2022-06-23 14:00:32.288993
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest

    options = pytest.Mock()
    options.debug = 'debug'
    cli_args = GlobalCLIArgs.from_options(options)
    assert isinstance(cli_args, GlobalCLIArgs)
    assert cli_args['debug'] == 'debug'

    # Ensure that we can't change the dict
    with pytest.raises(TypeError):
        cli_args['debug'] = 'changed'

    # Ensure that we can't change the dict if we access it through a key

# Generated at 2022-06-23 14:00:34.300596
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        def __init__(self, **values):
            self.__dict__ = values

    options = Options(foo='bar')
    parser = CLIArgs(options)
    assert parser['foo'] == 'bar'

# Generated at 2022-06-23 14:00:37.432667
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton
    f1 = Foo()
    f2 = Foo()
    assert f1 is f2

# Generated at 2022-06-23 14:00:40.250168
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    class TestClass2(TestClass):
        pass

    obj1 = TestClass()
    obj2 = TestClass()
    assert obj1 is obj2, "_ABCSingleton isn't a Singleton"
    obj3 = TestClass2()
    assert obj1 is obj3, "_ABCSingleton isn't a Singleton"

# Generated at 2022-06-23 14:00:51.354453
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.facts.system.distribution.freebsd import OpenBSD
    from ansible.module_utils.facts.system.distribution.freebsd import FreeBSD
    from ansible.module_utils.facts.system.distribution.freebsd import NetBSD
    from ansible.module_utils.facts.system.distribution.freebsd import DragonFlyBSD
    from ansible.module_utils.facts.system.distribution.freebsd import Darwin
    cli_args = CLIArgs.from_options(OpenBSD())
    assert isinstance(cli_args, ImmutableDict)
    assert is_iterable(cli_args)

# Generated at 2022-06-23 14:01:00.893717
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common._collections_compat import (Sequence, Set)
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.unsafe_proxy import UnsafeProxy

    class MyDict(UnsafeProxy, ImmutableDict):
        """A subclass of ImmutableDict"""
        pass

    class MyList(UnsafeProxy, Sequence):
        """A subclass of Sequence"""
        pass

    class MySet(UnsafeProxy, Set):
        """A subclass of Set"""
        pass


# Generated at 2022-06-23 14:01:03.463148
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs.from_options(Singleton.LoadVariables.options)
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args['start_at_task'] == 'some_task'


# Generated at 2022-06-23 14:01:05.643906
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    reference_dict = {'hello': {'world': 'and friends'}}
    args = CLIArgs(reference_dict)

    assert args == reference_dict


# Generated at 2022-06-23 14:01:17.836284
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'text_a': 'hello',
               'text_b': 'goodbye',
               'int_a': 233,
               'int_b': 80380,
               'float_a': 2.33,
               'float_b': 80.380,
               'bool_a': True,
               'bool_b': False,
               'list': ['hello', 'goodbye'],
               'tuple': ('hello', 'goodbye'),
               'set': {'hello', 'goodbye'},
               'dict': {'hello': 111, 'goodbye': 222},
               }
    args = CLIArgs(mapping)
    assert isinstance(args, ImmutableDict)
    # Make sure things are immutable
    assert isinstance(args['text_a'], text_type)

# Generated at 2022-06-23 14:01:28.165074
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    pos_args = {'verbosity': True, 'foo': 'bar', 'n': '1000'}
    kwargs = {'baz': 'spam'}
    args = CLIArgs(pos_args)
    # Check that it is an ImmutableDict
    assert isinstance(args, ImmutableDict)

    # Check that we can't add an attribute to it
    try:
        args.test = 'testing'
    except AttributeError:
        pass
    except:
        raise
    else:
        raise AssertionError('Should not be able to add an attribute.')

    # Check that we can't delete an attribute
    try:
        del args.test
    except AttributeError:
        pass
    except:
        raise

# Generated at 2022-06-23 14:01:38.611725
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {
        'foo': 'bar',
        'baz': {
            'one': 1,
            'two': 2,
            'three': 'three'
        }
    }
    args = CLIArgs(test_dict)
    assert args == test_dict
    assert args.baz == test_dict['baz']
    assert args.baz.three == test_dict['baz']['three']

    # Ensure arguments are immutable
    try:
        args.immutable_value = 'this should error'
        assert False, 'Should never get here'
    except Exception as ex:
        assert str(ex) == "AnsibleOptions objects do not support item assignment"


# Generated at 2022-06-23 14:01:41.807015
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    obj = CLIArgs({'key': 'value'})
    assert isinstance(obj, ImmutableDict)
    assert isinstance(obj, CLIArgs)
    assert isinstance(obj, Mapping)
    obj['key'] = 'value'

# Generated at 2022-06-23 14:01:47.333252
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object, metaclass=_ABCSingleton):
        def __init__(self, value):
            self.value = value

    t1 = Test(1)
    t2 = Test(2)

    assert t1.value == 1
    assert t2.value == 2

# Generated at 2022-06-23 14:01:53.492819
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    #_make_immutable()
    x = {'a':[1,2,3], 'b':{'c':'d', 'e':['f', 'g']}, 'h': set('ij')}
    x = CLIArgs(x)
    assert x['a'] == (1,2,3)
    assert x['b'] == ImmutableDict({'c': 'd', 'e': ('f', 'g')})
    assert x['h'] == frozenset(('i', 'j'))



# Generated at 2022-06-23 14:01:56.147493
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'a': 'b'}
    args = CLIArgs(mapping)
    assert isinstance(args, ImmutableDict)
    assert args == ImmutableDict(mapping)


if __name__ == '__main__':
    # Simple test for CLIArgs constructor
    test_CLIArgs()

# Generated at 2022-06-23 14:02:04.700710
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.six import PY2
    from ansible.module_utils.common.text.converters import to_text
    import ansible
    # Make sure GlobalCLIArgs is a singleton
    a = GlobalCLIArgs({'ansible_version': ansible.__version__})
    b = GlobalCLIArgs({'ansible_version': ansible.__version__})
    assert a is b
    assert a == b
    # Make sure it's immutable
    if PY2:
        # py2 has a bad habit of assuming str is text_type ... this assumes you are using ascii
        # compatbile locale and that unicode is utf-8 (a good assumption most of the time)
        good_unicode = u'\xe9\x9c\x8d'
        bad_

# Generated at 2022-06-23 14:02:15.150018
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    raw_options = dict(
        foo="bar",
        list1=["bar", "baz"],
        list2=[dict(a="a", b="b"), dict(c="c", d="d")],
        dict1=dict(a="1", b="2", c="3"),
    )
    options = CLIArgs(raw_options)
    assert options.foo == "bar"
    assert options.list1 == ("bar", "baz")
    assert options.list2 == (({"a": "a", "b": "b"}, {"c": "c", "d": "d"}))
    assert options.dict1 == {"a": "1", "b": "2", "c": "3"}
    # options should be immutable
    with pytest.raises(TypeError):
        options.foo = "baz"

# Generated at 2022-06-23 14:02:23.213522
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    import datetime

    class TestCLIArgs(GlobalCLIArgs):
        def __init__(self, *args, **kwargs):
            return super(TestCLIArgs, self).__init__(*args, **kwargs)

    try:
        a = TestCLIArgs({})
        b = TestCLIArgs({})
    except RuntimeError:
        pytest.fail("Can not instantiate GlobalCLIArgs")
    else:
        assert isinstance(a, GlobalCLIArgs)
        assert isinstance(b, GlobalCLIArgs)

    try:
        c = TestCLIArgs(datetime.datetime.now())
    except (ValueError, TypeError) as e:
        assert isinstance(e, TypeError)

# Generated at 2022-06-23 14:02:34.135138
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Make a known test set of CLI args
    cli_args = {'foo': 'bar',
                'baz': 'bizzle',
                'nested': {'dict': 'is_nested'},
                'nested_list': ['is_nested']}
    # Not immutable yet
    assert not isinstance(cli_args, ImmutableDict)
    assert not isinstance(cli_args['nested'], ImmutableDict)
    assert not isinstance(cli_args['nested_list'], (tuple, frozenset))
    # Make it immutable
    cli_args_immutable = GlobalCLIArgs(cli_args)
    assert isinstance(cli_args_immutable, ImmutableDict)
    assert isinstance(cli_args_immutable['nested'], ImmutableDict)


# Generated at 2022-06-23 14:02:40.939239
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Test behaviour of GlobalCLIArgs constructor"""
    args = {"version": True, "help": True, "debug": True}
    new_instance = GlobalCLIArgs(args)
    assert "version" in new_instance
    assert "help" in new_instance
    assert "debug" in new_instance
    assert new_instance["version"] is True
    assert new_instance["help"] is True
    assert new_instance["debug"] is True

# Generated at 2022-06-23 14:02:45.295072
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    g = GlobalCLIArgs({'a': 1, 'b': 2})
    assert hash(g) == hash(GlobalCLIArgs({'a': 1, 'b': 2}))
    assert g == GlobalCLIArgs({'a': 1, 'b': 2})
    assert g == GlobalCLIArgs.from_options(g)

# Generated at 2022-06-23 14:02:46.274328
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({})

# Generated at 2022-06-23 14:02:50.393038
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Base(object):
        __metaclass__ = _ABCSingleton

    class Derived(Base):
        pass

    assert Base() is Base()
    assert Derived() is Derived()

# Generated at 2022-06-23 14:02:52.391733
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Base(object):
        pass
    class Sub(Base):
        pass
    x = Sub()
    Base.assert_is_instance(x)

# Generated at 2022-06-23 14:02:57.570541
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    a = A()
    b = B()
    assert b is a

# Generated at 2022-06-23 14:02:59.248380
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = ImmutableDict({'module_path': '/dev/null'})
    single_instance = GlobalCLIArgs.from_options(options)
    assert single_instance is not None

# Generated at 2022-06-23 14:03:01.373033
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class TestGlobalCLIArgs(GlobalCLIArgs):
        pass
    TestGlobalCLIArgs([])
    TestGlobalCLIArgs([], [])

# Generated at 2022-06-23 14:03:04.762324
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestOne(_ABCSingleton):
        pass

    try:
        class TestTwo(_ABCSingleton):
            pass
    except TypeError:
        pass
    else:
        assert False

# Generated at 2022-06-23 14:03:12.477038
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    import sys
    import unittest

    # A simple metaclass that counts how many times the class is instantiated
    class CountingMetaType(type):
        instance_count = 0

        def __call__(cls, *args, **kwargs):
            cls.instance_count += 1
            return type.__call__(cls, *args, **kwargs)

    # Enable asserting that only one instance of the class is ever instantiated
    class GlobalCLIArgsTest(GlobalCLIArgs):
        __metaclass__ = CountingMetaType

    # Test data
    if sys.version_info[0] == 2:
        test_data = ImmutableDict(dict(a='b'))
    else:
        test_data = ImmutableDict(a='b')

    # Run test

# Generated at 2022-06-23 14:03:15.785395
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class b(object):
        pass

    class foo(b, ImmutableDict):
        pass

    class bar(ImmutableDict, b):
        pass

    class baz(ImmutableDict, b):
        __metaclass__ = _ABCSingleton
        pass

    # Should not throw exceptions
    foo()
    bar()
    baz()

# Generated at 2022-06-23 14:03:17.228903
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs.set(CLIArgs(DummyOptions()))

# Generated at 2022-06-23 14:03:26.520446
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Singletoned(metaclass=_ABCSingleton):
        pass

    t = Singletoned()
    if not hasattr(Singletoned, '__abstractmethods__'):
        # Python 3 does not have __abstractmethods__ on types
        raise Exception('__abstractmethods__ should be set')
    if t.__abstractmethods__ is not frozenset():
        raise Exception('t.__abstractmethods__ is {}'.format(t.__abstractmethods__))
    if not issubclass(Singletoned, Singleton):
        raise Exception('Singletoned must be a subclass of Singleton')
    if not isinstance(t, Singletoned):
        raise Exception('t is not an instance of Singletoned')

# Generated at 2022-06-23 14:03:36.090910
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Demonstrate how to inherit from both ABCMeta and Singleton

    Demonstrate how inheritance order works when inheriting from Singleton and ABCMeta
    """
    class Example(object):
        """
        Example class with a custom metaclass that combines ABCMeta and Singleton
        """
        pass

    class ExampleMetaclass(_ABCSingleton):
        """
        Custom metaclass that combines ABCMeta and Singleton
        """
        __instance = None

    # Our custom metaclass should have both ABCMeta and Singleton in its tree of bases
    assert _ABCSingleton in ExampleMetaclass.__bases__
    assert ABCMeta in ExampleMetaclass.__mro__
    assert Singleton in ExampleMetaclass.__mro__

    # __bases__ is a tuple and we don't want to modify it directly

# Generated at 2022-06-23 14:03:42.484556
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils.display import Display
    from ansible.cli.arguments import option_helpers as opt_help

    init = collections.defaultdict(str,
                           foo = 'bar',
                           bar = [1, '2'],
                           baz = True)
    ansible_args = CLIArgs(init)

    display = Display()
    option_collection = opt_help.create_parser(display)

    args = option_collection.parse_args(args=['--foo', 'baz'])

    ansible_args2 = CLIArgs.from_options(args)

    # Check that both arguments work the same
    assert ansible_args == ansible_args2

    # Check that the arguments are ImmutableD

# Generated at 2022-06-23 14:03:53.440337
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.shlex import shlex_split
    from ansible.cli.arguments import option_helpers as opt_help

    parser = opt_help.add_args(opt_help.base_parser(constants=opt_help.make_constants()))

    cli_args = ('-i localhost, -m ping --connection=paramiko --forks=5 -vvv '
                '--extra-vars extra1=value1 --extra-vars extra2=value2').split()
    args = parser.parse_args(shlex_split(cli_args))
    cli_args = CLIArgs.from_options(args)

    assert isinstance(cli_args, CLIArgs)
    assert isinstance(cli_args, ImmutableDict)

# Generated at 2022-06-23 14:04:03.002456
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_args = GlobalCLIArgs({'foo': 'bar', 'baz': {'bak': [1, 2, 3]}})
    assert isinstance(global_args['baz'], ImmutableDict)  # from the inner _make_immutable
    assert isinstance(global_args['baz']['bak'], tuple)  # from the inner _make_immutable
    # GlobalCLIArgs should be a singleton so trying to create a second instance should fail
    try:
        GlobalCLIArgs({'foo': 'bar', 'baz': {'bak': [1, 2, 3]}})
    except TypeError:
        assert True