

# Generated at 2022-06-23 13:54:05.455208
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    # Instance, because it is a singleton.
    assert isinstance(A, A)
    assert isinstance(B, A)

# Generated at 2022-06-23 13:54:14.726162
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that the CLIArgs constructor properly makes a container immutable.

    This is a basic test but it will show how to use the constructor properly and shows how to
    test it.
    """
    cli_args = CLIArgs({'a': 1})
    assert isinstance(cli_args, ImmutableDict)

    # Test that __setitem__ and __delitem__ are gone
    with pytest.raises(TypeError) as err:
        cli_args['a'] = 2
    assert "object does not support item assignment" in str(err.value)

    with pytest.raises(TypeError) as err:
        del cli_args['a']
    assert "object does not support item assignment" in str(err.value)

    # Test that __setattr__ is gone so we can't mutate the object
   

# Generated at 2022-06-23 13:54:24.459962
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs({'hello': 'world', 'nested': {'a': 1, 'b': 2, 'c': 3}, 'list': [1, 2, 3]})

    assert isinstance(global_cli_args, ImmutableDict)
    assert isinstance(global_cli_args, GlobalCLIArgs)
    assert isinstance(global_cli_args, CLIArgs)
    assert isinstance(global_cli_args, Singleton)

    # these are the same things that construction normally does
    global_cli_args2 = GlobalCLIArgs({'hello': 'world', 'nested': {'a': 1, 'b': 2, 'c': 3}, 'list': [1, 2, 3]})
    assert global_cli_args is global_cli_args2

# Generated at 2022-06-23 13:54:28.081112
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils.six import with_metaclass
    class Test(_ABCSingleton):
        pass

    class Other(with_metaclass(Test, object)):
        pass

    x = Test()
    y = Test()
    assert id(x) == id(y)
    z = Other()
    assert id(z) == id(y)

# Generated at 2022-06-23 13:54:33.832189
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABCSingletonTest(object):
        __metaclass__ = _ABCSingleton

    # It is an error to create more than one instance of _ABCSingletonTest
    _ABCSingletonTest()
    # The second attempt to create an instance will from a TypeError
    try:
        _ABCSingletonTest()
    except TypeError:
        pass
    else:
        assert False, "Creating more than one instance of a singleton should fail"

# Generated at 2022-06-23 13:54:35.319156
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class TempCLIArgs(GlobalCLIArgs):
        pass

    args = TempCLIArgs(dict(foo='bar'))
    assert args.foo == 'bar'
    assert isinstance(args, GlobalCLIArgs)



# Generated at 2022-06-23 13:54:46.331710
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli.arguments import option_helpers
    from ansible.module_utils.six import iteritems
    from ansible.plugins.loader import find_plugins
    from ansible.utils.collection_loader import get_collection_name

    options = option_helpers.parse()
    collection_name = get_collection_name(options=options)
    collection_name = collection_name or 'ansible_collections.ansible'
    find_plugins(options, collection_name)
    singleton = GlobalCLIArgs.get_instance(from_options=options)

    # check if objects inside of it are immutable
    for key, value in iteritems(singleton):
        if isinstance(value, (list, set, tuple, dict)):
            assert isinstance(value, (ImmutableDict, tuple, frozenset))

# Generated at 2022-06-23 13:54:53.108151
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class MyClass(object):
        def __repr__(self):
            return '<MyClass: Test>'

        def __hash__(self):
            return id(self)

        def __eq__(self, other):
            return self is other

    obj1 = MyClass()
    obj2 = MyClass()
    assert obj1 is not obj2

    test_dict = {
        'one': 'two',
        'three': (obj1, obj2),
        'five': {'six': set((obj1, obj2)), 'seven': (obj1, obj2)},
    }
    cli_args = CLIArgs(test_dict)
    assert cli_args.one == 'two'
    assert cli_args.three == ('<MyClass: Test>', '<MyClass: Test>')

   

# Generated at 2022-06-23 13:54:54.900686
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert not hasattr(GlobalCLIArgs, '__dict__')

# Generated at 2022-06-23 13:54:57.480063
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Test GlobalCLIArgs is a Singleton
    options = object()

# Generated at 2022-06-23 13:55:06.718922
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.hashing import md5s
    from ansible.module_utils.common.validation import checkForValidParameters
    class Options(object):
        pass
    options = Options()
    options.verbosity = 3
    options.foo = set([1, 2, 3])
    options.bar = md5s("ABC", "DEF")

    # Check that we can't mutate things we've already created
    GlobalCLIArgs.clear_instance()
    args = GlobalCLIArgs.from_options(options)
    assert args.get('verbosity') == 3
    assert args.get('foo') == set([1, 2, 3])
    assert args.get('bar').hexdigest() == '5a5ebd8fd89700b9b0eeb36c7ff3d3a5'

    #

# Generated at 2022-06-23 13:55:19.040699
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import types

    options = types.SimpleNamespace(argument1=1, argument2='two', argument3=['three'])
    GlobalCLIArgs.from_options(options)

    class Foo(object):
        _instances = []

    # Custom exception class to distinguish from exceptions thrown by other test functions.
    class TestException(Exception):
        pass

    # Verify that GlobalCLIArgs only creates a single instance.
    # This was previously failing and causing an error when running tests.
    # See issue #47767
    try:
        GlobalCLIArgs.from_options(options)
        if GlobalCLIArgs().__dict__['_instances']:
            raise TestException('GlobalCLIArgs created more than one instance.')
    except TestException:
        print('Test failed')
        sys.exit(1)

# Generated at 2022-06-23 13:55:23.671237
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_global_cli_args = GlobalCLIArgs.from_options(object())
    assert test_global_cli_args is not None, "GlobalCLIArgs from_options() failed to create object"



# Generated at 2022-06-23 13:55:30.884845
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABCSingleton(object):
        __metaclass__ = _ABCSingleton

        def __init__(self, test_arg):
            self.test_arg = test_arg

    obj_a = TestABCSingleton("test_arg_a")
    obj_b = TestABCSingleton("test_arg_b")
    assert obj_a.test_arg == obj_b.test_arg == "test_arg_a"

# Generated at 2022-06-23 13:55:38.917378
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.parsing.plugin_docs import get_docstring
    from ansible.plugins.cache import BaseFileCacheModule
    if GlobalCLIArgs.instance() is None:
        GlobalCLIArgs.set_instance(GlobalCLIArgs({}))
    PluginDocsCLIArgs = GlobalCLIArgs.instance()
    PluginDocsCLIArgs['all_plugins'] = True
    PluginDocsCLIArgs['cache_plugin'] = True
    docs = get_docstring(BaseFileCacheModule, verbose=PluginDocsCLIArgs['verbosity'],
                         show_all=PluginDocsCLIArgs['all_plugins'])
    assert docs

test_GlobalCLIArgs()

# Generated at 2022-06-23 13:55:42.334635
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        pass
    t1 = Test()
    t2 = Test()
    assert t1 is t2, 'ABCMeta should have prevented creation of a second instance'

# Generated at 2022-06-23 13:55:49.876157
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    options = {'a': 'b', 'c': ['d', 5, {'e': 6}]}
    cli_args = CLIArgs(options)
    assert cli_args['a'] == 'b'
    assert cli_args['c'][0] == 'd'
    assert cli_args['c'][1] == 5
    assert cli_args['c'][2]['e'] == 6
    # Test that the dict returned by vars is truly immutable
    assert cli_args['c'][2]['e'] != 6.1


# Generated at 2022-06-23 13:55:52.959598
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    opts = argparse.Namespace()
    opts.c = {'d': 'e'}
    g = GlobalCLIArgs.from_options(opts)
    assert g == {'c': {'d': 'e'}}

# Generated at 2022-06-23 13:55:59.283203
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    # create the command line parser
    parser = argparse.ArgumentParser()
    # add the command line arguments
    parser.add_argument('-f', help='name of configuration file', nargs='?', type=argparse.FileType('r'),
                        metavar='filename', default=sys.stdin, dest="filename")
    # parse the command line arguments
    options = parser.parse_args()
    globalcliargs = GlobalCLIArgs.from_options(options)
    assert(globalcliargs['filename'] == sys.stdin)

# Generated at 2022-06-23 13:56:02.530590
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    try:
        class C(A, B):
            pass
    except TypeError as e:
        assert "metaclass conflict" in str(e)

# Generated at 2022-06-23 13:56:08.635296
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a':'a', 'b':'b', 'c':'c'}
    cli_args = CLIArgs(test_dict)
    assert cli_args.a == 'a'
    assert cli_args.b == 'b'
    assert cli_args.c == 'c'
    for key, value in cli_args.items():
        assert value == test_dict[key]

# Generated at 2022-06-23 13:56:11.230684
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyClass(object):
        __metaclass__ = _ABCSingleton

    class OtherClass(object):
        __metaclass__ = _ABCSingleton

    assert MyClass is OtherClass

# Generated at 2022-06-23 13:56:21.359550
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test constructor of CLIArgs

    This will test the constructor of cliargs and test if the
    different type of mutable data are converted in immutable
    data.

    :return: None
    """
    options_dict = dict(
        ansible_python_interpreter="/usr/bin/python",
        ansible_ssh_user="john",
        ansible_ssh_pass="doe",
        tags=["sometag"],
        list=[1, 2]
    )
    cliargs = CLIArgs.from_options(options_dict)

    # test that dictionary was converted to ImmutableDict
    assert isinstance(cliargs, ImmutableDict)

    # test that the list type was converted
    assert isinstance(cliargs['list'], tuple)

    # test that the set type was converted

# Generated at 2022-06-23 13:56:25.577528
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Should not raise exceptions
    GlobalCLIArgs({})
    try:
        GlobalCLIArgs.__init__({})
    except NotImplementedError:
        pass
    except Exception as e:
        raise e

# Generated at 2022-06-23 13:56:28.887361
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABCSingletonTest(object):
        __metaclass__ = _ABCSingleton
    assert issubclass(_ABCSingletonTest, _ABCSingleton)

# Generated at 2022-06-23 13:56:35.815134
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Unit test for constructor of class CLIArgs
    """
    toplevel = {'update': {'name': ['foo']}, 'extra': {'paths': [['/foo/bar']]}}
    args = CLIArgs(toplevel)

    assert isinstance(args, Mapping)
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, CLIArgs)

    assert isinstance(args.get('update'), Mapping)
    assert isinstance(args.get('update'), ImmutableDict)
    assert isinstance(args.get('update'), CLIArgs)

    assert isinstance(args.get('update').get('name'), Sequence)
    assert isinstance(args.get('update').get('name'), tuple)

# Generated at 2022-06-23 13:56:45.428682
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from collections import namedtuple
    class Opts(namedtuple('Opts', ('foo', 'bar', 'baz'))):
        pass
    opts = Opts(foo='hello', bar=('a', 'b', 'c'), baz=(('a', 'b'), ('c', 'd')))
    args = CLIArgs.from_options(opts)
    assert isinstance(args, CLIArgs)
    assert isinstance(args['foo'], str)
    assert isinstance(args['bar'], tuple)
    assert isinstance(args['baz'], tuple)
    assert isinstance(args['bar'][0], str)
    assert isinstance(args['bar'][1], str)

# Generated at 2022-06-23 13:56:48.101738
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        pass
    class Test2(_ABCSingleton):
        pass
    assert Test() is Test()
    assert Test2() is Test2()
    assert Test() is not Test2()

# Generated at 2022-06-23 13:56:54.423723
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Declare arguments as a dict
    arguments = {"ansible_connection": "network_cli"}
    arguments = _make_immutable(arguments)

    args_obj = CLIArgs(arguments)
    assert isinstance(args_obj, ImmutableDict)
    # Accessing the value will return the type frozenset
    assert isinstance(args_obj["ansible_connection"], frozenset)

# Generated at 2022-06-23 13:57:02.748211
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-23 13:57:05.474979
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import ansible.constants as C
    C.FOO = 'bar'
    C.BAR = 'foo'
    args = CLIArgs.from_options(C)

# Generated at 2022-06-23 13:57:08.456055
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class test1(object):
        __metaclass__ = _ABCSingleton
    class test2(test1):
        pass
    test2()

# Generated at 2022-06-23 13:57:09.054753
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    pass

# Generated at 2022-06-23 13:57:14.794893
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'hello': 'world', 'goodbye': {'inner': 'dict'}, 'numbers': [1, 2, 3, 4, 5]})
    assert type(args) is CLIArgs
    assert args.get('hello') == 'world'
    assert args.get('goodbye').get('inner') == 'dict'
    assert args.get('numbers') == (1,2,3,4,5)

# Generated at 2022-06-23 13:57:24.839150
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class test_class(object):
        __metaclass__ = _ABCSingleton
    try:
        # Cannot directly create an instance of Singleton.
        test_class()
    except TypeError:
        pass
    try:
        # Cannot instantiate a derived class more than once.
        test_class()
        test_class()
    except TypeError:
        pass
    class test_class_metaclass_conflict(object):
        __metaclass__ = _ABCSingleton
        __metaclass__ = ABCMeta
    try:
        # Cannot directly create an instance of Singleton.
        test_class_metaclass_conflict()
    except TypeError:
        pass

# Generated at 2022-06-23 13:57:28.381645
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        pass

    option1 = Options()
    option1.foo = 'foo'

    global_cli_args = GlobalCLIArgs.from_options(option1)
    assert global_cli_args['foo'] == 'foo'

# Generated at 2022-06-23 13:57:33.629385
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    class B(A):
        pass
    assert isinstance(A(), A)
    assert isinstance(A(), B)
    assert isinstance(B(), A)
    assert isinstance(B(), B)
    a = A()
    b = B()
    assert a is b
    assert B is A



# Generated at 2022-06-23 13:57:45.558427
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({}) == {}
    assert CLIArgs({'foo': b'bar'}) == {'foo': b'bar'}
    assert CLIArgs({'foo': 'bar'}) == {'foo': 'bar'}
    assert CLIArgs({'foo': u'bar'}) == {'foo': u'bar'}
    assert CLIArgs({'foo': {'bar': u'baz'}}) == {'foo': {'bar': u'baz'}}
    assert CLIArgs({'foo': ['bar', u'baz']}) == {'foo': ('bar', u'baz')}
    assert CLIArgs({'foo': ['bar', ['baz', u'qux']]}) == {'foo': ('bar', ('baz', u'qux'))}

# Generated at 2022-06-23 13:57:49.041555
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    testdict = dict(option_a = 'apple', option_b = 'banana', option_c = 'cantalope')
    args = CLIArgs(testdict)
    assert isinstance(args, ImmutableDict)
    assert args == testdict


# Generated at 2022-06-23 13:57:50.781305
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(A):
        pass

    A()
    B()

# Generated at 2022-06-23 13:58:01.307720
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    class B(A):
        pass
    assert B() is B()
    # TODO: fix this once we have a working context system then we can use it to verify this still works with context
    # class C(B):  # noqa: F811
    #     pass
    # C.register('b', B)
    # c_b = C('b')
    # assert c_b is c_b  # make sure the global singleton is the same object from c_b
    # assert c_b is B()  # make sure c_b is a unique object from B()


# Generated at 2022-06-23 13:58:09.543090
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # The class should return the same object when called a second time
    a1 = GlobalCLIArgs.from_options({})
    a2 = GlobalCLIArgs.from_options({})
    assert a1 is a2

    b1 = GlobalCLIArgs.from_options({'foo': 'bar'})
    b2 = GlobalCLIArgs.from_options({'foo': 'bar'})
    assert b1 is b2

    # The class should not return the same object when called with different data
    b2 = GlobalCLIArgs.from_options({'foo': 'bar', 'baz': 'qux'})
    b3 = GlobalCLIArgs.from_options({'foo': 'bar', 'baz': 'qux'})
    assert b2 is b3

    # Even though the contents might be considered equal, the class should

# Generated at 2022-06-23 13:58:15.907408
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.cli.arguments import options
    from ansible.module_utils.common._collections_compat import Mapping
    cmd_args = vars(options)
    assert isinstance(cmd_args, Mapping), "Expecting a mapping"
    args = CLIArgs(cmd_args)
    assert isinstance(args, ImmutableDict), "Expecting an immutable dict"
    assert isinstance(args, Mapping), "Expecting a mapping"

# Generated at 2022-06-23 13:58:18.451402
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    ABCSingleton = _ABCSingleton('ABCSingleton', (object, ), {})
    x = ABCSingleton()
    y = ABCSingleton()
    assert(x == y)

# Generated at 2022-06-23 13:58:23.471375
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    import _GlobalCLIArgs_test
    if not hasattr(_GlobalCLIArgs_test, "__loader__"):
        return True

    parser = argparse.ArgumentParser()
    parser.add_argument('-k', '--ask-pass', action='store_true')
    args = parser.parse_args()
    cli_args = GlobalCLIArgs.from_options(args)
    return cli_args.ask_pass

# Generated at 2022-06-23 13:58:25.586183
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _Test(GlobalCLIArgs):
        pass

# Generated at 2022-06-23 13:58:28.827240
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton(object, metaclass=_ABCSingleton):
        pass
    x = TestSingleton()
    y = TestSingleton()
    assert x is y

# Generated at 2022-06-23 13:58:31.970280
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class A(metaclass=_ABCSingleton):
        pass

    class B(A):
        pass

    assert A is B
    assert A() is B()



# Generated at 2022-06-23 13:58:40.456765
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import copy
    import json

    # Define a dict that has string, dict, list, and set in it.
    my_mapping = {'key1': 'value1', 'key2': 'value2', 'key3': {'key4': 'value4', 'key5': {'key6': 'value6'}}, 'key7': ['value7', 'value8'], 'key9': {'value9', 'value10'}}
    my_dict = copy.deepcopy(my_mapping)
    my_mapping = CLIArgs(my_mapping)

    assert isinstance(my_mapping, CLIArgs)
    assert isinstance(my_mapping['key1'], text_type)
    assert isinstance(my_mapping['key2'], text_type)

# Generated at 2022-06-23 13:58:42.068998
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class X(metaclass=_ABCSingleton):
        pass
    X()

# Generated at 2022-06-23 13:58:46.862773
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import collections
    foo = GlobalCLIArgs(collections.ImmutableDict({'a': 1}))
    assert isinstance(foo, GlobalCLIArgs)
    assert foo.a == 1
    try:
        foo['a'] = 2
        assert False, "should not be able to modify foo"
    except TypeError:
        pass

# Generated at 2022-06-23 13:58:56.024202
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs.from_options(GlobalCLIArgs.from_options(GlobalCLIArgs.from_options(dict(one=1, two=2))))
    assert cli_args.get('one') == 1
    assert cli_args.get('two') == 2
    assert cli_args.get('three') is None
    try:
        toplevel = cli_args['three']
        assert False
    except KeyError:
        pass
    try:
        cli_args['toplevel'] = 3
        assert False
    except TypeError:
        pass


if __name__ == "__main__":
    test_CLIArgs()

# Generated at 2022-06-23 13:59:00.676081
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    with pytest.raises(CLIArgsError) as test:
        GlobalCLIArgs.__new__(GlobalCLIArgs)
    assert "subclass of GlobalCLIArgs must call it's parent's constructor" in test.value



# Generated at 2022-06-23 13:59:06.192113
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={'var1': {'type': 'str'}, 'var2': {'type': 'str'}})
    args = GlobalCLIArgs(vars(module.params))
    assert args is not None
    assert args['var1'] == 'version'
    assert args['var2'] == 'value'

# Generated at 2022-06-23 13:59:14.811498
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common.collections import ImmutableDict

    cli_args = CLIArgs(dict(become=dict(ask_pass=True),
                            become_user='test_user',
                            connection='local',
                            forks=10,
                            inventory=DataLoader(),
                            module_path=['/tmp/ansible_modules'],
                            module_path_plugins_name='test_plugins'))
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args["become"], ImmutableDict)
    assert isinstance(cli_args["inventory"], DataLoader)
    assert isinstance(cli_args["module_path"], tuple)

# Generated at 2022-06-23 13:59:18.028867
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cmd_args = {'foo': 'bar', 'bar': 'baz'}
    cli_args = CLIArgs(cmd_args)
    assert cli_args == cmd_args
    assert cli_args is not cmd_args

# Generated at 2022-06-23 13:59:26.437345
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {
        'verbosity': True,
        'connection': 'local',
        'inventory': ['/etc/ansible/hosts'],
        'inventory_two': [['/etc/ansible/hosts', '/etc/ansible/hosts2']],
        'inventory_three': {
            'inventory_var_1': ['/etc/ansible/hosts'],
            'inventory_var_2': ['/etc/ansible/hosts2'],
        }
    }
    test_cli_args = CLIArgs(test_dict)
    assert test_cli_args == ImmutableDict(test_dict)
    assert test_cli_args != test_dict
    assert isinstance(test_cli_args['inventory'], tuple)

# Generated at 2022-06-23 13:59:32.166860
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Set up
    options = {}

    # Test an empty set of options, should return an empty CLIArgs object
    options = {}
    cli_args = CLIArgs(options)
    expected = ImmutableDict()
    assert cli_args == expected

    # Test a simple set of options
    options = {'a': "a's value", 'b': "b's value"}
    cli_args = CLIArgs(options)
    expected = ImmutableDict({'a': "a's value", 'b': "b's value"})
    assert cli_args == expected

    # Test a set of options that include a list
    options = {'a': "a's value", 'l': ["list", "values"]}
    cli_args = CLIArgs(options)

# Generated at 2022-06-23 13:59:38.198284
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    x = CLIArgs({'a': 1, 'b': {1, 2}, 'c': [1, 2], 'd': {'e': 3, 'f': {4, 5}}})
    assert x['a'] == 1
    assert x['b'] == frozenset([1, 2])
    assert x['c'] == tuple([1, 2])
    assert x['d']['e'] == 3
    assert x['d']['f'] == frozenset([4, 5])

# Generated at 2022-06-23 13:59:43.970412
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Ensure object returned by _ABCSingleton is the same object
    """
    # pylint: disable=unused-variable
    class Example(_ABCSingleton):
        # pylint: disable=no-init
        pass

    ex1 = Example()
    ex2 = Example()

    assert ex1 is ex2


# Generated at 2022-06-23 13:59:50.040393
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    d1 = {'a': 1, 'b': 2}
    d2 = {'1': d1, '2': 3}
    d3 = {'alpha': d2, 'beta': 4}

    cli_args = CLIArgs(d3)

    assert cli_args['alpha']['1']['a'] == 1
    assert isinstance(cli_args['alpha']['1'], ImmutableDict)

# Generated at 2022-06-23 13:59:52.987221
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    TestClassOne = TestClass
    TestClassTwo = TestClass

    assert TestClassOne is TestClassTwo

# Generated at 2022-06-23 14:00:03.049360
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    options = Options(foo='bar', baz='buzz', nested=Options(one=1, two=2, three=Options(alpha=0, beta=1, gamma=2)))

    assert isinstance(CLIArgs(vars(options)), dict)
    assert isinstance(CLIArgs.from_options(options), dict)

    my_args = CLIArgs.from_options(options)

    assert isinstance(my_args, CLIArgs)
    assert my_args == {'foo': 'bar', 'baz': 'buzz', 'nested': {'one': 1, 'two': 2, 'three': {'alpha': 0, 'beta': 1, 'gamma': 2}}}

# Generated at 2022-06-23 14:00:05.458166
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    assert issubclass(A, _ABCSingleton)

# Generated at 2022-06-23 14:00:14.270256
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import unittest
    import sys

    class TestCLIArgs(unittest.TestCase):
        def test_constructor(self):
            args = {
                'foo': 'bar',
                'baz': [
                    'a',
                    'b',
                    'c',
                ],
                'fizz': {
                    'buzz': 'wizz',
                },
                'hello': [
                    {
                        'foo': 'bar',
                    }
                ]
            }
            cliargs = CLIArgs(args)
            self.assertEqual(cliargs.get('foo'), 'bar')
            self.assertEqual(list(cliargs.get('baz')), ['a', 'b', 'c'])
            self.assertIsInstance(cliargs.get('baz'), ImmutableDict)
           

# Generated at 2022-06-23 14:00:18.235427
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    # Derive class from _ABCSingleton.
    class MyABCSingletonClass(_ABCSingleton):
        pass

    # Check if MyABCSingletonClass is a subclass of ABCMeta.
    assert issubclass(MyABCSingletonClass, ABCMeta)

    # Check if MyABCSingletonClass is a subclass of Singleton.
    assert issubclass(MyABCSingletonClass, Singleton)

    # Check if MyABCSingletonClass is a subclass of _ABCSingleton.
    assert issubclass(MyABCSingletonClass, _ABCSingleton)

    # Check if MyABCSingletonClass is not a subclass of dict.
    assert not issubclass(MyABCSingletonClass, dict)


# Generated at 2022-06-23 14:00:22.374952
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    globalcliargs = GlobalCLIArgs({"test":'test'})
    assert globalcliargs["test"] == 'test'
    globalcliargs["test"] = "changed"
    assert globalcliargs["test"] == 'test'

# Generated at 2022-06-23 14:00:31.267936
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    '''
    Ensure when we construct a GlobalCLIArgs object its contents are immutable
    '''

    mutable_data = {
        'a': 'a',
        'b': [1, 2, 3],
        'c': {
            'd': 'd',
            'e': {'f': 'f'},
        },
    }

    args_obj = GlobalCLIArgs(mutable_data)

    assert args_obj._mapping is args_obj

    # Ensure we didn't modify the original data
    # pylint: disable=protected-access
    assert args_obj._mapping['a'] == 'a'
    assert args_obj._mapping['b'] == (1, 2, 3)
    assert args_obj._mapping['c']['d'] == 'd'
    assert args_obj._

# Generated at 2022-06-23 14:00:39.689807
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    _ABCSingleton(Singleton, ABCMeta) is a metaclass which sets up __instance to be set to None
    as needed for Singleton.  The only thing that should be needed for unit testing is that
    the class sets up __instance as needed by Singleton.  Once that is working, this unit test is
    thus redundant as the rest of Singleton will be tested by the unit test for CLIArgs.
    """
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert TestClass.__instance is None

# Generated at 2022-06-23 14:00:46.867873
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli import CLI
    from ansible.cli.arguments import (options as cli_options, ansible_options,
        connection_options, deprecated_options, meta_options, runas_options,
        subset_options, vault_options, module_options, check_options,
        inventory_options, become_options, runtask_options, ssh_options,
        module_framework_options, fork_options)

# Generated at 2022-06-23 14:00:57.099625
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    arg = CLIArgs(dict(foo='bar'))
    assert arg.foo == 'bar'
    arg2 = ImmutableDict(dict(bar='baz'))
    arg3 = CLIArgs(dict(foo=arg2))
    assert arg3.foo == arg2
    arg4 = CLIArgs(dict(foo=set([1, 2])))
    assert arg4.foo == set([1, 2])
    arg5 = CLIArgs(dict(foo=dict(bar='baz')))
    assert arg5.foo == dict(bar='baz')
    arg6 = ImmutableDict(dict(foo=set([1, 2])))
    arg7 = CLIArgs(dict(foo=arg6))
    assert arg7.foo == arg6

# Generated at 2022-06-23 14:01:07.310955
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.constants import DEFAULT_BECOME_CONNECTION, DEFAULT_BECOME_METHOD, DEFAULT_BECOME_USER, DEFAULT_FORKS, DEFAULT_VERBOSITY
    from ansible.utils.display import Display
    from ansible.plugins.loader import become_loader

    display = Display()
    display.verbosity = DEFAULT_VERBOSITY

    become = become_loader.get(
        DEFAULT_BECOME_METHOD,
        DEFAULT_BECOME_USER,
        DEFAULT_BECOME_CONNECTION,
        become_pass=None
    )


# Generated at 2022-06-23 14:01:15.391360
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-23 14:01:18.329673
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Unit test for constructor of class GlobalCLIArgs"""
    x = GlobalCLIArgs({'a': 1})
    assert x.a == 1


# Generated at 2022-06-23 14:01:22.380938
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # pylint: disable=missing-docstring
    class singleton_test1(object):
        __metaclass__ = _ABCSingleton
    class singleton_test2(singleton_test1):
        pass

    assert singleton_test1 is singleton_test2

# Generated at 2022-06-23 14:01:27.362281
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Test that _ABCSingleton correctly combines ABCMeta and Singleton.

    This should be put into a unit test module.  See #50433.
    """
    @add_metaclass(_ABCSingleton)
    class TestABCSingleton(object):
        pass

    assert isinstance(TestABCSingleton, ABCMeta)
    assert issubclass(TestABCSingleton, Singleton)

# Generated at 2022-06-23 14:01:37.687361
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Check that strings are strings
    assert type(CLIArgs(dict(x="a"))["x"]) is text_type

    # Check that lists are tuples
    assert type(CLIArgs(dict(x=["a", "b"]))["x"]) is tuple

    # Check that sets are frozensets
    assert type(CLIArgs(dict(x={"a", "b"}))["x"]) is frozenset

    # Check that nested list are tuples
    assert type(CLIArgs(dict(x=["a", ["b", "c"]]))["x"]) is tuple

    # Check that nested sets are frozensets
    assert type(CLIArgs(dict(x={"a", ("b", "c")}))["x"]) is frozenset

    # Check that dicts are ImmutableDicts


# Generated at 2022-06-23 14:01:40.986033
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    d = CLIArgs(dict(a=1, b=2, c=3))
    assert isinstance(d["a"], int)
    assert d["b"] == 2
    assert d["c"] == 3

# Generated at 2022-06-23 14:01:52.512930
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import warnings

    try:
        GlobalCLIArgs()
    except TypeError:
        pass
    else:
        raise Exception("GlobalCLIArgs.__init__() should have raised TypeError")

    options = GlobalCLIArgs.from_options(GlobalCLIArgs.make_options())

    # Make sure we don't clobber stderr when we try to print the options
    stderr_fd = sys.stderr
    try:
        sys.stderr = open('/dev/null')
        options.print_help()
    except AttributeError:
        raise Exception("GlobalCLIArgs.from_options did not produce an options object")
    finally:
        sys.stderr = stderr_fd


# Generated at 2022-06-23 14:02:02.687215
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import zlib
    import bz2
    import os
    import types
    import sys
    import tempfile

    args = {
        'module_path': set([
            './modules',
            '/test/ansible/lib/ansible/modules/test_module_2',
            '/test/ansible/lib/ansible/modules/test_module_1',
        ]),
        'module_language': 'ps',
        'check': False,
        'module_name': 'test_module',
        'module_args': 'name=value',
        'module_arg_spec': {
            'name': {'type': 'str', 'required': False},
        },
    }

    a1 = GlobalCLIArgs.from_options(args)
    a2 = GlobalCLIArgs.from_options(args)

# Generated at 2022-06-23 14:02:06.556915
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    x = CLIArgs({'key1': {'key2': 'val2'}, 'key3': [1, 2, 3]})
    assert isinstance(x, ImmutableDict)
    assert isinstance(x['key1'], ImmutableDict)
    assert isinstance(x['key3'], tuple)
    assert isinstance(x['key3'][1], int)

# Generated at 2022-06-23 14:02:13.263896
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.cli import CLI
    from ansible.utils.path import unfrackpath

    cli = CLI(args=['--list-hosts=[u\'localhost\', u\'127.0.0.1\']'])
    options = cli.parse()
    vars_options = vars(options)
    loader = DataLoader()
    inventory = loader.load_inventory(host_list=unfrackpath(vars_options['host_file']),
                                      group_list=unfrackpath(vars_options['inventory']),
                                      path_list=vars_options['module_path'] or [])
    inventory.subset(vars_options['subset'])


# Generated at 2022-06-23 14:02:22.134026
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton(_ABCSingleton):
        def __init__(self):
            super(TestSingleton, self).__init__()
            self.x = 'test'
            self.y = 'test'

    class TestSingleton2(_ABCSingleton):
        def __init__(self):
            super(TestSingleton2, self).__init__()
            self.x = 'test'
            self.y = 'test'

    assert(TestSingleton() is TestSingleton())
    assert(TestSingleton() == TestSingleton())
    assert(TestSingleton() is not TestSingleton2())
    assert(TestSingleton() != TestSingleton2())
    assert(TestSingleton2() is not TestSingleton())
    assert(TestSingleton2() != TestSingleton())

# Generated at 2022-06-23 14:02:33.338598
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # pylint: disable=unsubscriptable-object
    # pylint: disable=protected-access
    test_dict = {'first_level': 'first level',
                 'second_level': {'third_level': 'third level'},
                 'fourth_level': [{'fifth_level': 'fifth level', 'sixth_level': ['seventh_level']}],
                 'eighth_level': ['ninth_level'],
                 'tenth_level': frozenset(['eleventh_level', 12])}

    input_dict = _make_immutable(test_dict)
    cli_args = CLIArgs(input_dict)
    assert cli_args == input_dict and cli_args is not input_dict

# Generated at 2022-06-23 14:02:44.197579
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.compat.argparser import Parser
    import argparse

    parser = Parser()
    parser.add_argument("--test", default='test', type=str)

    # Call parse_args once so that GlobalCLIArgs gets populated
    args = parser.parse_args([])
    assert isinstance(GlobalCLIArgs, GlobalCLIArgs)

    # Call parse_args again to trigger the case where the CLIArgs is updated with new data
    parser.parse_args(['--test', 'new_test'])
    assert GlobalCLIArgs["test"] == 'new_test'

    # Ensure that the parser is in a sane state for any remaining tests
    parser.parse_args([])
    assert isinstance(GlobalCLIArgs, GlobalCLIArgs)

# Generated at 2022-06-23 14:02:50.698805
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    cli_args = GlobalCLIArgs(dict(foo='bar', baz=True))

    assert isinstance(cli_args, ImmutableDict)
    assert 'foo' in cli_args
    assert 'baz' in cli_args
    assert cli_args['foo'] == 'bar'
    assert cli_args['baz'] is True

# Generated at 2022-06-23 14:02:59.204013
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # pylint: disable=redefined-outer-name
    class MyDummyArgs():
        def __init__(self, a=1, b=2, c=3):
            self.a = a
            self.b = b
            self.c = c

    dummy_args = MyDummyArgs()
    args = GlobalCLIArgs.from_options(dummy_args)
    assert args['a'] == 1
    assert args['b'] == 2
    assert args['c'] == 3

# Generated at 2022-06-23 14:03:05.427453
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(metaclass=_ABCSingleton):
        def __init__(self, bar):
            self.bar = bar

        def __repr__(self):
            return 'Foo(bar=%s)' % self.bar

    x = Foo('baz')
    y = Foo('qux')
    assert id(x) == id(y)
    assert isinstance(x, Foo)
    assert isinstance(x, Singleton)

# Generated at 2022-06-23 14:03:09.275838
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyClass(object):
        __metaclass__ = _ABCSingleton
        pass

    class MyClass2(object):
        __metaclass__ = _ABCSingleton
        pass

    class MyClass3(object):
        __metaclass__ = _ABCSingleton
        pass

    my_class_instance = MyClass()

# Generated at 2022-06-23 14:03:16.963706
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    options_dict = {'ask_vault_pass': False, 'connection': 'smart', 'extra_vars': [], 'help': False, 'listhosts': None,
                    'listtasks': None, 'module_path': None, 'new_vault_password_file': None, 'one_line': None,
                    'output_file': None, 'poll_interval': 15, 'private_key_file': None, 'skip_tags': [],
                    'start_at_task': None, 'step': None, 'tags': [], 'timeout': None, 'tree': None,
                    'vault_password_file': None, 'verbosity': 0}

# Generated at 2022-06-23 14:03:18.305821
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    pass

# Generated at 2022-06-23 14:03:28.402065
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import types
    import copy
    import collections
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var

    # Input

# Generated at 2022-06-23 14:03:35.637820
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.module_utils.common.collections import MutableMapping, MutableSequence, MutableSet

    # Test init empty set
    cliargs = GlobalCLIArgs(dict())
    assert cliargs == {}
    assert type(cliargs) == CLIArgs
    assert isinstance(cliargs, ImmutableDict)
    assert not isinstance(cliargs, MutableMapping)
    # Test init simple set
    cliargs = GlobalCLIArgs(dict(a=1, b=2))
    assert cliargs == {'a': 1, 'b': 2}
    assert type(cliargs) == CLIArgs
    assert isinstance(cliargs, ImmutableDict)
    assert not isinstance(cliargs, MutableMapping)
    # Test init mutable container

# Generated at 2022-06-23 14:03:38.072909
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    class Bar(object):
        __metaclass__ = _ABCSingleton

    assert Bar() == Bar()
    assert Foo() == Foo()
    assert Foo() != Bar()

# Generated at 2022-06-23 14:03:42.959442
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        # pylint: disable=unused-variable
        class Foo(object, metaclass=_ABCSingleton):
            pass
        # pylint: enable=unused-variable
        assert False, "Foo didn't fail to instantiate like intended"
    except TypeError:
        pass

# Generated at 2022-06-23 14:03:45.295158
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
        pass

    assert A() is A()  # ok, checks out

# Generated at 2022-06-23 14:03:51.180707
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = ['--force', '--name', 'Fred']
    (options, args) = GlobalCLIArgs.parser().parse_args(args)
    options.check_invalid_arguments(args, False)
    options.remote_user = 'Bob'
    print(options)
    global_args = GlobalCLIArgs.from_options(options)
    print(global_args)

# Generated at 2022-06-23 14:03:54.049881
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    obj = {"a": {"b": ["c", "d"]}}
    cli_args = CLIArgs(obj)
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args == obj



# Generated at 2022-06-23 14:04:00.974645
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # pylint: disable=protected-access

    # With no attributes
    g1 = GlobalCLIArgs.from_options(CLIArgs({}))

    # With some attributes
    g2 = GlobalCLIArgs.from_options(CLIArgs({'field1': 'value1'}))

    # Check the values of the attributes
    assert g1.field1 == g2.field1, "Failed in GlobalCLIArgs constructor"