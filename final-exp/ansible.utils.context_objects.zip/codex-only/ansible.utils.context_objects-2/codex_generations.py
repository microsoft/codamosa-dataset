

# Generated at 2022-06-23 13:53:59.676380
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({'a': 1, 'b': 2})
    args1 = GlobalCLIArgs({'c': 3})
    assert args == args1

# Generated at 2022-06-23 13:54:05.554767
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    class B(A):
        pass
    class C(B):
        pass
    class D(A):
        pass
    assert D() is D()
    assert isinstance(D(), A)
    assert issubclass(D, A)

# Generated at 2022-06-23 13:54:14.806733
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-23 13:54:17.595064
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs({'foo': {'bar': 1}})
    assert cli_args == {'foo': {'bar': 1}}

# Generated at 2022-06-23 13:54:19.307310
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({'hello': 'world'})

# Generated at 2022-06-23 13:54:29.873250
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {
        'text': 'test',
        'list': [1, 2, 3],
        'dict': {'1': 1, '2': 2},
        'set': {1, 2, 3},
        'tuple': (1, 2, 3),
        'string': '1',
    }
    args = CLIArgs(test_dict)
    assert args['text'] == 'test'
    assert args['list'] == [1, 2, 3]
    assert args['dict'] == ImmutableDict({'1': 1, '2': 2})
    assert args['set'] == frozenset({1, 2, 3})
    assert args['tuple'] == (1, 2, 3)
    assert args['string'] == '1'

# Generated at 2022-06-23 13:54:35.091277
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import ansible.module_utils.common.argparse as argparse
    import ansible.module_utils.common.collections as collections

    opts = argparse.GlobalCLIOptions()
    # call the parse_args and store the values
    opts.parse_args(args=[])

    gca = GlobalCLIArgs.from_options(opts)
    assert isinstance(gca, collections.CLIArgs)



# Generated at 2022-06-23 13:54:39.682996
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options:
        something = "list: item"

    cli_args = GlobalCLIArgs.from_options(Options)
    assert not cli_args.changed
    assert cli_args['something'] == "list: item"

# Generated at 2022-06-23 13:54:41.654045
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    gca = GlobalCLIArgs.instance()
    assert True

# Generated at 2022-06-23 13:54:46.623423
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'test': 'value'})
    assert args['test'] == 'value'
    # Make sure that it is immutable
    try:
        args['test'] = 'othervalue'
    except TypeError:
        pass
    else:
        assert False, "args should not be modifiable"
    # Make sure that it still stores the original value
    assert args['test'] == 'value'


# Generated at 2022-06-23 13:54:48.102021
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(metaclass=_ABCSingleton):
        pass

    Test()

# Generated at 2022-06-23 13:54:57.488064
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import unittest

    class TestGlobalCLIArgs(unittest.TestCase):
        def test(self):
            import collections

            options = collections.namedtuple('Options', 'hello')
            options.hello = 'world'
            args = GlobalCLIArgs.from_options(options)
            self.assertTrue(isinstance(args, CLIArgs))
            self.assertTrue(isinstance(args, Mapping))
            self.assertTrue(isinstance(args, Container))
            self.assertEqual(args['hello'], 'world')

    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    suite.addTests(loader.loadTestsFromModule(TestGlobalCLIArgs()))
    unittest.TextTestRunner(verbosity=3).run(suite)

# Generated at 2022-06-23 13:55:03.967795
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({}) == {}
    assert CLIArgs({'a': 'b'}) == {'a': 'b'}
    assert CLIArgs({'a': []}) == {'a': ()}
    assert CLIArgs({'a': {}}) == {'a': ImmutableDict()}
    assert CLIArgs({'a': {'b': {'c': 'd'}}}) == {'a': ImmutableDict({'b': ImmutableDict({'c': 'd'})})}
    assert CLIArgs({'a': 'b', 'c': [{'d': 'e'}, 'f']}) == {'a': 'b', 'c': (ImmutableDict({'d': 'e'}), 'f')}

# Generated at 2022-06-23 13:55:16.692572
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    a_dict = {'foo': 'bar', 'baz': [1, 2, 3], 'qux': (1, 2, 3), 'quux': True}
    an_ordered_dict = collections.OrderedDict(a_dict)
    a_named_tuple = collections.namedtuple('baz', ['x', 'y', 'z'])(1, 2, 3)
    cli_args = CLIArgs(a_dict)
    assert isinstance(cli_args, Mapping)
    assert cli_args == a_dict
    cli_args = CLIArgs(an_ordered_dict)
    assert isinstance(cli_args, Mapping)
    assert cli_args == a_dict
    cli_args = CLIArgs(a_named_tuple._asdict())

# Generated at 2022-06-23 13:55:22.676423
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    temp_dict = {'1': 1, '2': 2, '3': 3}
    result = CLIArgs(temp_dict)
    if result != temp_dict:
        raise AssertionError("CLIArgs should be {0} but is {1}".format(temp_dict, result))
    if not isinstance(result, ImmutableDict):
        raise AssertionError("CLIArgs should be ImmutableDict but is {0}".format(type(result)))

# Generated at 2022-06-23 13:55:31.473649
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # use same file as in AnsibleModule test
    # Ensure the argument parser is run to get the default values
    import ansible.cli.galaxy
    ansible.cli.galaxy.GalaxyCLI.setup_vars()
    # Get the options
    options = ansible.cli.galaxy.GalaxyCLI.base_parser(usage="%prog some usage text").parse_args([])
    # Ensure the constructor creates an immutable dict and passes the base dict
    assert isinstance(GlobalCLIArgs.from_options(options), ImmutableDict)

# Generated at 2022-06-23 13:55:34.727933
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    assert A() == A()
    assert B() == B()
    assert A() != B()


# Generated at 2022-06-23 13:55:40.467772
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton):
        pass
    class Bar(_ABCSingleton):
        pass
    class Baz(Foo):
        pass

    foo_one = Foo()
    foo_two = Foo()
    assert foo_one is foo_two
    assert foo_one is Foo()

    bar = Bar()
    assert bar is Bar()
    assert bar is not foo_one

    # Doesn't preserve meta-ness of parent
    with pytest.raises(TypeError):
        baz = Baz()


# Generated at 2022-06-23 13:55:47.890524
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    test_args = {'a': 1, 'b': [1, 2], 'c': {1: 2}, 'd': {1, 2}}
    temp_object = CLIArgs(test_args)
    assert isinstance(temp_object, ImmutableDict)
    assert temp_object['a'] == 1
    assert isinstance(temp_object['b'], tuple)
    assert isinstance(temp_object['c'], ImmutableDict)
    assert isinstance(temp_object['d'], frozenset)

# Generated at 2022-06-23 13:55:52.660141
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'foo': 1, 'bar': {'baz': 2}})
    assert isinstance(args, ImmutableDict)
    assert args['foo'] == 1
    assert args['bar']['baz'] == 2
    assert args.get('foobar') is None

# Generated at 2022-06-23 13:56:00.424364
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    CLIArgs = commandline.CLIArgs({'a': 1, 'b': 2, 'd': {'x': 3, 'y': 4}, 'l': [5, 6]})
    assert(CLIArgs['a'] == 1)
    assert(CLIArgs['b'] == 2)
    assert(CLIArgs.d['x'] == 3)
    assert(CLIArgs.d['y'] == 4)
    assert(CLIArgs.l[0] == 5)
    assert(CLIArgs.l[1] == 6)
    assert(isinstance(CLIArgs.d, commandline.ImmutableDict))
    assert(isinstance(CLIArgs.l, tuple))


# Generated at 2022-06-23 13:56:08.122418
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-23 13:56:18.264155
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import unittest

    import collections

    class GlobalCLIArgs_Test(unittest.TestCase):
        def test_Constructor(self):
            args = GlobalCLIArgs({'a': 'ordinary', 'b': 'mutable', 'c': ['mutable', 'sequence']})
            with self.assertRaises(TypeError):
                args['a'] = 'attempt to modify immutable'
            with self.assertRaises(TypeError):
                args['b'] = 'attempt to modify immutable'
            with self.assertRaises(TypeError):
                args['c'][0] = 'attempt to modify immutable'

            with self.assertRaises(TypeError):
                GlobalCLIArgs({'a': ['mutable', 'sequence']})

# Generated at 2022-06-23 13:56:22.587155
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Test singleton by creating class with metaclass _ABCSingleton

    Note: test is in this file because only this file imports _ABCSingleton.
    """

    class Single(object):
        """
        Singleton class with _ABCSingleton as its metaclass
        """
        __metaclass__ = _ABCSingleton

    first = Single()
    second = Single()
    assert first is second

# Generated at 2022-06-23 13:56:28.055896
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'foo': 1, 'bar': 2, 'baz': 3}
    cli_args = CLIArgs(mapping)
    assert cli_args.foo == 1
    assert cli_args.bar == 2
    assert cli_args.baz == 3

# Generated at 2022-06-23 13:56:33.430050
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Basic test of the CLIArgs class

    The test consists of changing a nested value and ensuring that the result is a reference error
    """

    args = CLIArgs({'first': {'second': 'value'}})
    try:
        args['first']['second'] = 'change'
        raise AssertionError('args changed')
    except TypeError:
        pass

# Generated at 2022-06-23 13:56:43.736101
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs(dict(
        test1=dict(
            list=['a', 'b', 'c'],
            int=1,
        ),
        test2=dict(
            list=['d', 'e', 'f'],
            int=2,
        ),
    ))

    assert args['test1']['list'] == ('a', 'b', 'c')
    assert args['test1']['int'] == 1
    assert args['test2']['list'] == ('d', 'e', 'f')
    assert args['test2']['int'] == 2

    args['test1']['list'] = ('x', 'y', 'z')
    assert args['test1']['list'] == ('a', 'b', 'c')

    args['test1']['int'] = 5

# Generated at 2022-06-23 13:56:47.783671
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    class A2(A):
        pass
    assert A2() is A2()
    assert A2() is A()

    class B(object):
        __metaclass__ = _ABCSingleton

    assert B() is B()
    assert B() is not A()
    assert B() is not A2()

# Generated at 2022-06-23 13:56:58.565366
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # This test only works if we make an immutable copy of the cli args.  If we make a non-immutable
    # copy of the cli args, then this test will fail because we can no longer modify the dict that
    # has been constructed to use as the basis for this test.
    import os
    import argparse

    parser = argparse.ArgumentParser(description="test description")
    parser.add_argument('--test1', default=None, help='test1 help')
    parser.add_argument('--test2', default=None, help='test2 help')
    parser.add_argument('--test3', default=None, help='test3 help')
    parser.add_argument('--test4', type=int, default=1, help="test4 help")

# Generated at 2022-06-23 13:57:11.121464
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test for creating a new args structure
    args = CLIArgs({
        'argument_a': True,
        'argument_b': False,
        'argument_c': {
            'argument_1': 'a',
            'argument_2': 'b',
            'argument_3': 'c',
        },
        'argument_d': [
            'a',
            'b',
            'c',
        ],
    })
    assert args['argument_a'] is True
    assert args['argument_b'] is False
    assert args['argument_c']['argument_1'] == 'a'
    assert args['argument_c']['argument_2'] == 'b'
    assert args['argument_c']['argument_3'] == 'c'

# Generated at 2022-06-23 13:57:20.784077
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from collections import OrderedDict
    from ansible.utils.collection_loader import AnsibleCollectionConfig

    try:
        a = GlobalCLIArgs.from_options(AnsibleCollectionConfig())
    except TypeError:
        # TypeError: invalid input for ImmutableDict: unordered dict
        pass
    else:
        assert False, "should raise TypeError"

    a = GlobalCLIArgs.from_options(AnsibleCollectionConfig(mapping=[('k1', 'v1'), ('k2', 'v2')]))
    assert a.get('k1') == 'v1'
    assert a.get('k2') == 'v2'
    assert a.get('k3', 'v3') == 'v3'

    assert a.get('k1_seq') is None

# Generated at 2022-06-23 13:57:25.087885
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class MockOptions(object):
        def __init__(self, mapping):
            self.__dict__.update(mapping)

    gca = GlobalCLIArgs.from_options(MockOptions({'extra_var': 'foo', 'module_args': [1, 2, 3]}))
    assert isinstance(gca, ImmutableDict)

# Generated at 2022-06-23 13:57:34.772602
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli import CLI
    from ansible.module_utils._text import to_bytes

    # NOTE:  Do not import ansible.module_utils.common.dict_transformations to prevent circular import
    def transform_dict(d, key_map):
        """
        Rename dict keys.

        :kw key_map: Mapping of old key to new key name
        :return: New dict with renamed keys
        """
        # We want to iterate over the values of the dict to prevent the
        # side-effect of changing the dict while iterating over it that
        # would occur with dict.iteritems()
        return dict((key_map.get(k, k), v) for k, v in d.items())


# Generated at 2022-06-23 13:57:46.328150
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils import common as cliargs
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.collections import ImmutableDict


# Generated at 2022-06-23 13:57:56.841196
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        def __init__(self, **kwds):
            self.__dict__.update(kwds)

    for args in [
        ['a', 'b', 'c'],
        {'a': 'b', 'c': 'd'},
        Options(a='b', c='d'),
    ]:
        assert isinstance(CLIArgs.from_options(args), CLIArgs)
        assert isinstance(CLIArgs.from_options(args), ImmutableDict)
        assert not isinstance(CLIArgs.from_options(args), Mapping)   # Should be a concrete class
        assert not isinstance(CLIArgs.from_options(args), Sequence)  # Should be a concrete class
        assert not isinstance(CLIArgs.from_options(args), Set)       # Should be a

# Generated at 2022-06-23 13:58:04.543031
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _TestABCSingleton(_ABCSingleton):
        pass

    class _TestABCSingleton2(_TestABCSingleton):
        pass

    assert not issubclass(_TestABCSingleton, ABCMeta), "_ABCSingleton does not inherit from ABCMeta"
    assert issubclass(_TestABCSingleton, Singleton), "_ABCSingleton inherits from Singleton"
    assert issubclass(_TestABCSingleton2, _TestABCSingleton), "_ABCSingleton is subclassable"


GlobalCLIArgs.update_global(CLIArgs({}))



# Generated at 2022-06-23 13:58:14.045527
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _WrongABCMeta(ABCMeta, Singleton):
        pass

    class _ABCSingleton2(Singleton, ABCMeta):
        pass

    class _ABCSingleton3(object, metaclass=_ABCSingleton):
        pass

    class _ABCSingleton4(object, metaclass=_ABCSingleton2):
        pass

    class _ABCSingleton5(object, metaclass=_WrongABCMeta):
        pass

    assert isinstance(_ABCSingleton3(), _ABCSingleton3)
    assert isinstance(_ABCSingleton4(), _ABCSingleton4)
    assert not isinstance(_ABCSingleton5(), _WrongABCMeta)

# Generated at 2022-06-23 13:58:23.145551
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test construction of immutable nested dictionaries
    cli_input = {
        'list_options': ['--list'],
        'list_option': {
            'list_option': 'list_value',
        },
        'list_option_sequence': ['sequence_value1', 'sequence_value2'],
        'list_option_set': set(['set_value1', 'set_value2']),
        'list_option_mapping': {
            'mapping_key1': 'mapping_value1',
            'mapping_key2': 'mapping_value2',
        },
        'list_option_direct': 'direct_value',
    }
    cli_args = CLIArgs(cli_input)

# Generated at 2022-06-23 13:58:28.973545
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Unit test to verify that GlobalCLIArgs() returns expected output
    """
    class Options:
        pass

    options = Options()
    options.inventory = ['host_one', 'host_two']
    options.host_pattern = 'host_three'
    options.check = 'y'
    options.vault_password_files = ['password_file.txt']
    options.vault_password_file = 'password_file.txt'
    options.force_handlers = 'n'
    options.step = 'y'
    options.start_at_task = 'step_one'
    options.step_args = ['step_args']
    options.syntax = 'y'
    options.diff = 'y'
    options.listtasks = 'y'
    options.listtags = 'y'
   

# Generated at 2022-06-23 13:58:33.928822
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(A):
        pass

    class C(A):
        pass

    b1 = B()
    b2 = B()
    c1 = C()
    assert b1 is b2
    assert b1 is not c1



# Generated at 2022-06-23 13:58:35.804378
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class EmptyABCSingleton(metaclass=_ABCSingleton):
        pass

    EmptyABCSingleton()

# Generated at 2022-06-23 13:58:45.358885
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    mapping = {'hello': 'world', 'number': 32, 'boolean': True, 'none': None, 'list': [1, 2],
               'dict': {'a_key': 'a_value'}, 'set': {1, 2, 3}}
    mapping_copy = mapping.copy()
    cli_args = CLIArgs(mapping)

    # Make sure constructor worked
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args == mapping_copy

    # Make sure original is not modified
    assert mapping == mapping_copy

    # Make sure normal access works
    assert cli_args['hello'] == 'world'
    assert cli_args['number'] == 32
    assert cli_args['boolean'] is True
    assert cli_args['none'] is None
    assert cli_

# Generated at 2022-06-23 13:58:53.221792
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from collections import OrderedDict
    cli_args1 = {
        'key1': 'value1',
        'key2': 'value2',
        'key3': 'value3',
        'key4': 'value4',
        'key5': 'value5',
        'key6': 'value6',
    }
    cli_args2 = OrderedDict(cli_args1)
    # Create class CLIArgs instance.
    cli_args = CLIArgs(cli_args1)
    # Check the type of object.
    assert isinstance(cli_args, CLIArgs)
    # Check the length of object.
    assert len(cli_args) == 6
    # Check the items in object.
    assert cli_args['key1'] == cli_args1['key1']
    assert cli

# Generated at 2022-06-23 13:59:00.779770
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class TesterCLIArgs(CLIArgs):
        def __init__(self):
            super(TesterCLIArgs, self).__init__(vars({}))
        @classmethod
        def from_options(cls, options):
            return cls()

    # Make sure GlobalCLIArgs is a singleton
    test_args = TesterCLIArgs()
    assert(TesterCLIArgs is test_args)

# Generated at 2022-06-23 13:59:02.319925
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton):
        pass
    assert Foo() is Foo()

# Generated at 2022-06-23 13:59:10.502821
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        pass

    options = Options()
    options.a = 1
    options.b = [1, 2, 3]
    options.c = {'d': 1, 'e': 2}
    expected = {'a': 1, 'b': (1, 2, 3), 'c': ImmutableDict({'d': 1, 'e': 2})}

    args = GlobalCLIArgs.from_options(options)
    assert args == expected
    assert args.a == 1
    assert args.b == (1, 2, 3)
    assert isinstance(args.c, ImmutableDict)
    assert args.c.d == 1
    assert args.c.e == 2

# Generated at 2022-06-23 13:59:19.112634
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # check if constructor produce correct result
    assert CLIArgs({'foo': 'bar'}) == {'foo': 'bar'}
    assert CLIArgs({'foo': 'bar', 'baz': 'qux'}) == {'foo': 'bar', 'baz': 'qux'}
    assert CLIArgs({'foo': {'bar': 'baz'}, 'baz': 'qux'}) == {'foo': {'bar': 'baz'}, 'baz': 'qux'}
    assert CLIArgs({'foo': ['bar', 'baz']}) == {'foo': ('bar', 'baz')}
    assert CLIArgs({'foo': ['bar', {'baz': 'qux'}]}) == {'foo': ('bar', {'baz': 'qux'})}

# Generated at 2022-06-23 13:59:23.218179
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """GlobalCLIArgs is a Singleton and CLIArgs can be used to create a GlobalCLIArgs"""
    options = ImmutableDict()
    a = CLIArgs(options)
    b = GlobalCLIArgs(options)
    assert a != b
    assert type(a) == CLIArgs
    assert type(b) == GlobalCLIArgs

# Generated at 2022-06-23 13:59:25.272907
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    class B(A):
        pass
    assert issubclass(B, A) and B().__class__ == A

# Generated at 2022-06-23 13:59:31.445243
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.playbook import Playbook
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import base64
    password = base64.b64decode(b'cmFuZG9tY2hhbm5lbA==')
    password = password.decode('utf-8')
    pbex = PlaybookExecutor()
    pbex.subset = 'all'
    play = Playbook()
    vault = AnsibleVaultEncryptedUnicode(string='Vault Encrypted Text')
    play.vars_files = ['group_vars/all']
    play.vars = {'password_hash': vault}

# Generated at 2022-06-23 13:59:40.812173
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    def list_of_keys(d):
        return list(d.__dict__.keys())

    class A(metaclass=_ABCSingleton):
        def __init__(self):
            self.a = 1

    assert A().a == 1
    assert hasattr(A(), '__new__')
    assert A().__new__ is A.__new__
    assert hasattr(A(), '__init__')
    assert A().__init__ is A.__init__
    assert len(list_of_keys(A())) == 0
    assert len(list_of_keys(A)) == 2

    class B(metaclass=_ABCSingleton):
        def __init__(self):
            self.b = 2

    assert B().b == 2
    assert hasattr(B(), '__new__')
   

# Generated at 2022-06-23 13:59:45.259429
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
        pass

    a = A()

    class B(object):
        __metaclass__ = _ABCSingleton
        pass

    b = B()
    assert a is b


# Generated at 2022-06-23 13:59:52.794165
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs(dict(a=dict(b='c'), d=('e', 'f')))
    assert args == dict(a=dict(b='c'), d=('e', 'f'))
    assert args.a.b == 'c'
    assert args.d == ('e', 'f')
    assert isinstance(args.a, ImmutableDict)
    assert isinstance(args.d, tuple)
    try:
        args.a.b = 'd'
    except AttributeError:
        pass
    else:
        raise Exception('Failed to catch mutating assignment!')


# Generated at 2022-06-23 14:00:02.937728
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common._collections_compat import Sequence
    mutable_dict = {
        u'logo': u'https://www.ansible.com/favicon.ico',
        'internal': False,
        'list': [1, 2, 3],
        'list_of_dict': [{u'a': 1}, {u'b': 2}],
        u'string': u'some string',
        'int': 1,
        'float': 1.0,
        'dict': {u'x': 1},
    }
    immutable_dict = _make_immutable(mutable_dict)
    cli_args = CLIArgs(mutable_dict)
    assert isinstance(cli_args, Mapping)
    assert cli_args == immutable_dict

# Generated at 2022-06-23 14:00:08.530042
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class Dummy(ImmutableDict):
        __metaclass__ = _ABCSingleton

        def __init__(self, mapping):
            super(Dummy, self).__init__(mapping)

    x = Dummy({'a': 1})
    y = Dummy({'a': 2})
    assert x is y

# Generated at 2022-06-23 14:00:15.618531
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingletonA(object):
        pass

    class SingletonB(object):
        pass

    class SingletonC(object):
        pass

    class SingletonD(object):
        pass

    class SingletonE(SingletonC):
        pass

    class SingletonF(SingletonC):
        pass

    class SingletonG(SingletonC):
        pass

    # A, B, C, and D all have the same class and aren't related
    assert SingletonA().__class__ == SingletonB().__class__
    assert SingletonA().__class__ == SingletonC().__class__
    assert SingletonA().__class__ == SingletonD().__class__
    assert SingletonA() is not SingletonB()
    assert SingletonA() is not SingletonC()
    assert SingletonA() is not Sing

# Generated at 2022-06-23 14:00:20.716809
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    toplevel = {'foo': 'bar', 'baz': 1, 'bat': [1, 2, 3, 4]}
    assert GlobalCLIArgs(toplevel) == GlobalCLIArgs(toplevel)
    assert isinstance(GlobalCLIArgs(toplevel), GlobalCLIArgs)



# Generated at 2022-06-23 14:00:29.995929
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import json

    test_dict = {
        'key1': [{'key2': [{'key3': ['key4']}]}],
        'key4': [{'key5': 'key6'}],
        'key7': set(['key8']),
    }

    expected = json.dumps({
        'key1': [{'key2': [{'key3': ('key4',)}]}],
        'key4': [{'key5': 'key6'}],
        'key7': ('key8',)
    }, sort_keys=True)

    cli_args = CLIArgs(test_dict)
    actual = json.dumps(dict(cli_args), sort_keys=True)
    assert actual == expected

# Generated at 2022-06-23 14:00:42.437884
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest

    args = GlobalCLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'quux': {'quuux': 'quuuux'}})

    # The constructor should make a deep copy of the given object and make it immutable
    with pytest.raises(AttributeError):
        del args['foo']
    with pytest.raises(AttributeError):
        args['baz'] = 'new'
    with pytest.raises(AttributeError):
        del args['quux']['quuux']

    # The constructor should recursively make a deep copy of the given object and make it immutable
    assert isinstance(args, ImmutableDict)
    assert isinstance(args['baz'], tuple)
    assert isinstance(args['quux'], ImmutableDict)

# Generated at 2022-06-23 14:00:45.498608
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABC(object):
        __metaclass__ = _ABCSingleton

    assert isinstance(TestABC(), TestABC)
    assert TestABC() is TestABC()

# Generated at 2022-06-23 14:00:52.762996
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_mapping = {
        'one': 1,
        'two': ['a', 'b'],
        'three': {'c': 'd'},
        'four': {1, 2, 3},
        'five': 'f',
        'six': b'six'
    }
    cli_args = CLIArgs(test_mapping)

    for key, value in test_mapping.items():
        assert cli_args[key] == _make_immutable(value)



# Generated at 2022-06-23 14:01:02.345012
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from collections import namedtuple
    from ansible.utils.display import Display
    from ansible.module_utils.common.collections import ImmutableDict

    class Options(object):
        def __init__(self, verbosity=0, dummy=3):
            self.verbosity = verbosity
            self.dummy = dummy

        def __repr__(self):
            return "Options(verbosity=%r, dummy=%r)" % (self.verbosity, self.dummy)

        def __str__(self):
            return repr(self)

    global_cli_args = GlobalCLIArgs.from_options(Options())
    assert type(global_cli_args) is ImmutableDict

# Generated at 2022-06-23 14:01:04.931286
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Unit test for class _ABCSingleton."""

    class TestClass(metaclass=_ABCSingleton):
        pass

    # test that class instantiates
    obj = TestClass()

# Generated at 2022-06-23 14:01:10.009960
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Option(dict):
        def __init__(self, arg_value):
            self.arg_value = arg_value

        def __getattr__(self, name):
            return self[name]

    options = Option({'foo': 'bar', 'baz': 'bat'})
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-23 14:01:12.852770
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyClass(object):
        __metaclass__ = _ABCSingleton
    assert MyClass() is MyClass()

# Generated at 2022-06-23 14:01:23.645622
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = dict(a=1, b='foo', c=dict(d=dict(e=2, f='foo')))
    args = CLIArgs(mapping)
    assert args['a'] == 1
    assert args['b'] == 'foo'
    assert isinstance(args['c'], ImmutableDict)
    assert args['c']['d']['e'] == 2
    assert args['c']['d']['f'] == 'foo'
    # Test the special case of strings
    assert isinstance(args['b'], text_type)
    assert isinstance(args['c']['d']['f'], text_type)
    # Test that we can't modify the dict
    try:
        args['b'] = 'bar'
    except Exception as e:
        pass

# Generated at 2022-06-23 14:01:26.862337
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _SingletonTest(metaclass=_ABCSingleton):
        pass

    class _SingletonTest2(_SingletonTest):
        pass

    assert _SingletonTest() is not _SingletonTest2()

# Generated at 2022-06-23 14:01:29.852420
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
        def __init__(self):
            if not hasattr(self, 'test'):
                self.test = 'test'
    a = A()
    assert a.test == 'test'

# Generated at 2022-06-23 14:01:38.074167
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # should be able to create and destroy several GlobalCLIArgs objects
    for _i in range(10):
        _GlobalCLIArgs = GlobalCLIArgs({'a': 1})
        _GlobalCLIArgs = None

    # should be able to modify the contents of the immutable dict
    # contained inside of GlobalCLIArgs
    _GlobalCLIArgs = GlobalCLIArgs({'a': 1})
    _GlobalCLIArgs['b'] = 2

    # should not be able to modify the contents of the immutable dict
    # contained inside of GlobalCLIArgs
    with pytest.raises(TypeError):
        _GlobalCLIArgs['a'] = 1

# Generated at 2022-06-23 14:01:39.171200
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({})
    assert isinstance(args, GlobalCLIArgs)

# Generated at 2022-06-23 14:01:44.120900
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import os
    import sys
    import tempfile

    sys.argv = [__file__, '--vault-password-file', os.path.join(tempfile.gettempdir(), '__foo__test__file__')]
    from ansible.cli import CLI as MockCLI
    MockCLI(args=sys.argv[1:]).parse()
    assert os.path.exists(GlobalCLIArgs()['vault_password_file'])
    with open(GlobalCLIArgs()['vault_password_file']) as FP:
        assert FP.read()

    os.unlink(GlobalCLIArgs()['vault_password_file'])

# Generated at 2022-06-23 14:01:54.005173
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_sequence, is_set
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.six import binary_type, text_type
    from ansible.module_utils.six.moves import UserDict
    from ansible.utils.display import Display
    import collections
    import sys

    # Create a test dictionary with all the different types of elements that might exist

# Generated at 2022-06-23 14:02:03.649203
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from io import StringIO
    from ansible.config.manager import ConfigManager
    test_args = StringIO()
    test_args.write("--become-method=sudo\n")
    test_args.write("--become-user=root\n")
    test_args.seek(0)
    config_manager = ConfigManager(args=test_args)
    config_manager.parse()
    options = config_manager.options
    gargs = GlobalCLIArgs.from_options(options)
    assert gargs['become_method'] == 'sudo'
    assert gargs['become_user'] == 'root'

    # getattr makes sure that we can access gargs as if it was a dictionary

# Generated at 2022-06-23 14:02:07.528173
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Suppress pycodestyle F811 because we are testing the Singleton functionality
    class TestA(object):  # noqa: F811
        __metaclass__ = _ABCSingleton

    class TestB(TestA):
        pass

    class TestC(TestB):
        pass

    assert TestA() is TestA()
    assert TestA() is TestB()
    assert TestA() is TestC()
    assert TestB() is TestC()

# Generated at 2022-06-23 14:02:09.702730
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        def __init__(self):
            pass
    A()
    assert(issubclass(A, Singleton))

# Generated at 2022-06-23 14:02:20.344878
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SimpleContainer(object):
        pass

    class SimpleContainerABC(object):
        __metaclass__ = ABCMeta
        pass

    class SimpleContainerSingleton(object):
        __metaclass__ = Singleton
        pass

    class SimpleContainerABCSingleton(_ABCSingleton):
        __metaclass__ = Singleton
        pass

    # Verify that we can create a metaclass of metaclasses without the metaclasses interfering with each other
    assert isinstance(SimpleContainer, object)
    assert isinstance(SimpleContainerABC, object)
    assert isinstance(SimpleContainerSingleton, object)
    assert isinstance(SimpleContainerABCSingleton, object)
    assert isinstance(SimpleContainerABCSingleton, Singleton)
    assert isinstance(SimpleContainerABCSingleton, ABCMeta)


# Generated at 2022-06-23 14:02:22.776612
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABCSingletonTest(object):
        __metaclass__ = _ABCSingleton
        pass

    _ABCSingletonTest()

# Generated at 2022-06-23 14:02:26.506112
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
    assert type(TestClass()) == TestClass
    assert TestClass() == TestClass()


# Generated at 2022-06-23 14:02:32.704182
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.dictdiffer import DictDiffer, dot_lookup, set_default
    from ansible.utils.hashing import hash_vars

    global_cli_args = GlobalCLIArgs(dict(foo='bar'))

    assert global_cli_args.foo == 'bar'

    DictDiffer = DictDiffer
    dot_lookup = dot_lookup
    set_default = set_default
    hash_vars = hash_vars

# Generated at 2022-06-23 14:02:35.139002
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    my_args = GlobalCLIArgs({"foo": "bar"})
    assert my_args["foo"] == u"bar"

# Generated at 2022-06-23 14:02:45.939916
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Verify that constructor throws exception for an object which is not an ImmutableMapping nor Mapping
    class A(object):
        def __init__(self):
            pass

    class B(object):
        def __init__(self):
            pass

    class C(object):
        def __init__(self):
            pass

    obj_a = A()
    obj_b = B()
    obj_c = C()

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.parsing.ajson import AnsibleJSONEncoder

    ansible_json_encoder = AnsibleJSONEncoder()
    obj_json_text = ansible_json_encoder.encode(obj_a)

# Generated at 2022-06-23 14:02:56.518311
# Unit test for constructor of class _ABCSingleton

# Generated at 2022-06-23 14:02:58.248821
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    A()
    class B(A):
        pass
    B()
test__ABCSingleton()

# Generated at 2022-06-23 14:03:08.135442
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from collections import OrderedDict
    from ansible.module_utils._text import to_bytes, to_text

    def check_immutable(obj):
        """Check a container for immutability"""
        if isinstance(obj, (text_type, binary_type)):
            # Strings first because they are also sequences
            return
        elif isinstance(obj, Mapping):
            for key, value in obj.items():
                if isinstance(value, Container):
                    check_immutable(value)
        elif isinstance(obj, Set):
            for value in obj:
                if isinstance(value, Container):
                    check_immutable(value)
        elif isinstance(obj, Sequence):
            for value in obj:
                if isinstance(value, Container):
                    check_immutable(value)

    #

# Generated at 2022-06-23 14:03:09.509344
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(metaclass=_ABCSingleton):
        def __init__(self):
            self.a = 1
    o = Test()
    assert o.a == 1
    assert o is Test()

# Generated at 2022-06-23 14:03:17.209894
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("-a", "--aaa", dest="aaa", type=str, default=None, action='append')
    parser.add_argument("-b", "--bbb", dest="bbb", type=str, default=None, action='append')
    cli_args = parser.parse_args(["-a", "1", "-b", "2", "-a", "3"])

    obj = GlobalCLIArgs.from_options(cli_args)
    assert obj.get('aaa') == ["1", "3"]
    assert not isinstance(obj.get('aaa'), mutable_type)
    assert obj.get('bbb') == ["2"]
    assert not isinstance(obj.get('bbb'), mutable_type)

    #

# Generated at 2022-06-23 14:03:26.521187
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # First, let's see if the constructor accepts a dictionary
    dictionary = {
        'a': 1,
        'b': '2',
        'c': [3],
        'd': {'x': "4"}
    }
    global_cli_args = GlobalCLIArgs(dictionary)

    # Let's see if the constructed objects are equal
    assert(global_cli_args.a == 1)
    assert(global_cli_args.b == '2')
    assert(global_cli_args.c[0] == 3)
    assert(global_cli_args.d.x == '4')

    # Next, let's see if the constructor accepts a AnsibleOptionParser
    # TODO: Implement this test
    # Finally, let's try to assign a new value to the attribute (immutable)

# Generated at 2022-06-23 14:03:27.422910
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert GlobalCLIArgs({'foo': 'bar'})  # nosec

# Generated at 2022-06-23 14:03:37.575058
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI

    from ansible.errors import AnsibleError, AnsibleOptionsError
    from ansible.utils.display import Display
    from ansible.utils.path import unfrackpath

    display = Display()

    # Global args - ignore these to avoid circular imports
    # Bare base classes are fine
    from ansible.options import Options
    from ansible.constants import DEFAULT_MODULE_PATH


# Generated at 2022-06-23 14:03:39.431220
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = {'dest': 'hostname'}
    GlobalCLIArgs.from_options(args)
    pass

# Generated at 2022-06-23 14:03:51.277218
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import collections
    import ansible.constants as C
    import ansible.module_utils.common.arguments as CLIC
    import ansible.utils.display as Display
    # Create a copy of the variables that are stored in the ansible.constants module
    args = collections.namedtuple('args', C.__all__)(*[getattr(C, arg) for arg in C.__all__])
    # Create a dummy display class to satisfy the arguments class
    disp = Display.Display()
    disp.verbosity = 2
    # Use the arguments class to fill in command line arguments
    args = CLIC.parse_arguments([], args, disp)
    # Create and use the singleton to store arguments
    GlobalCLIArgs.from_options(args)
    # Clear the singleton's values to avoid interaction with other cases
    Global

# Generated at 2022-06-23 14:03:53.558117
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):  # pylint: disable=abstract-class-little-used
        pass

    a = Test()
    b = Test()
    assert a == b

# Generated at 2022-06-23 14:03:59.380681
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    args = GlobalCLIArgs({'a': 1, 'b': {'c': 2, 'd': 3}})
    assert args['a'] == 1
    assert args['b']['c'] == 2
    assert args['b']['d'] == 3
    with pytest.raises(KeyError, match=r'e'):
        args['e']