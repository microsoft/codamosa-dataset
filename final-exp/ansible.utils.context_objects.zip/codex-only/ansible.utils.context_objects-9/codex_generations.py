

# Generated at 2022-06-23 13:54:03.825199
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _A(object, metaclass=_ABCSingleton):
        pass

    class _B(_A):
        pass

    class _C(_A):
        pass

    class _D(_B, _C):
        pass

# Generated at 2022-06-23 13:54:14.177875
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import os


# Generated at 2022-06-23 13:54:24.052450
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Test data
    data_dict = dict(test_key=dict(test_innerkey=True))
    data = {'ANSIBLE_CONFIG': 'test_config',
            'ANSIBLE_CHECK': True,
            'ANSIBLE_CALLBACK_WHITELIST': 'test_callback_whitelist',
            'ANSIBLE_STDOUT_CALLBACK': 'test_stdout_callback',
            'ANSIBLE_CALLBACK_PLUGINS': data_dict,
            'ANSIBLE_LIST_TASKS': True,
            'ANSIBLE_LIST_TAGS': True,
            'ANSIBLE_VERBOSITY': '1'}

    # Construct the class
    data_instance = GlobalCLIArgs(data)

    # We want only one instance of the GlobalCLIArgs
    data_instance1 = GlobalCLI

# Generated at 2022-06-23 13:54:27.917058
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        pass

    class Bar(Foo):
        __metaclass__ = _ABCSingleton

    b1 = Bar()
    b2 = Bar()
    assert b1 == b2
    assert b1 is b2

# Generated at 2022-06-23 13:54:35.936349
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import types
    import sys

    with types.ModuleType(__name__) as mod:
        sys.modules[__name__] = mod
        instance1 = GlobalCLIArgs({'foo': 'bar'})
        instance2 = GlobalCLIArgs({'baz': 'qux'})

        assert instance1 is instance2
        # Check the value of the singleton instance's key is the last given value
        assert instance1['foo'] == 'bar'
        assert instance2['foo'] == 'bar'
        assert instance1['baz'] == 'qux'
        assert instance2['baz'] == 'qux'

# Generated at 2022-06-23 13:54:46.893061
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import os
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    # Create a test loader because options.connection_loader doesn't like None
    loader = DataLoader()  # Supply a fake file
    options = PlayContext()
    loader.set_basedir(os.getcwd())

# Generated at 2022-06-23 13:54:50.160920
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        pass
    cli_args = GlobalCLIArgs.from_options(Options())

# Generated at 2022-06-23 13:54:57.826834
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test for Mapping
    dict1 = {'a': 1, 'b': 2, 'c': 3}
    dict2 = CLIArgs({'a': 1, 'b': 2, 'c': 3})
    assert dict1 == dict2
    assert dict1 is not dict2
    dict1['a'] = 10
    dict1['b'] = 20
    dict1['c'] = 30
    assert dict1 != dict2

    # Test for Sequence
    tuple1 = (1, 2, 3)
    tuple2 = CLIArgs({'a': 1, 'b': 2, 'c': 3})
    assert dict1 == dict2
    assert dict1 is not dict2
    dict1['a'] = 10
    dict1['b'] = 20
    dict1['c'] = 30
    assert dict1 != dict2

    # Test

# Generated at 2022-06-23 13:55:00.008693
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingletonSubclass(with_metaclass(_ABCSingleton)):
        pass

    assert isinstance(SingletonSubclass(), SingletonSubclass)

# Generated at 2022-06-23 13:55:05.754293
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test the constructor of class CLIArgs
    """
    result = CLIArgs({'k1': {'k2': {'k3': 'v1'}}})
    assert isinstance(result, ImmutableDict)
    assert {'k1': {'k2': {'k3': 'v1'}}} == result
    assert isinstance(result['k1'], ImmutableDict)
    assert isinstance(result['k1']['k2'], ImmutableDict)

# Generated at 2022-06-23 13:55:18.310555
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert CLIArgs({'a': [1, 2], 'b': 2}) == {'a': (1, 2), 'b': 2}
    assert CLIArgs({'a': [1, 2], 'b': {'c': 3}}) == {'a': (1, 2), 'b': {'c': 3}}
    assert CLIArgs({'a': [1, 2], 'b': {'c': {'d': 4}}}) == {'a': (1, 2), 'b': {'c': {'d': 4}}}

# Generated at 2022-06-23 13:55:25.152603
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import unittest

    class TestCLIArgs(unittest.TestCase):
        def test_constructor(self):
            cli_args = {
                'no_log': False,
                'become_ask_pass': True,
                'start_at_task': 'web-setup',
                'vault_password_file': '/etc/my_vault_password',
                'extra_vars': ['ansible_user=holmes'],
                'inventory': ['local,', 'staging,'],
            }
            cli_args = CLIArgs(cli_args)

            self.assertIsInstance(cli_args, CLIArgs)
            self.assertIsInstance(cli_args, Mapping)

            self.assertIsInstance(cli_args['no_log'], bool)

# Generated at 2022-06-23 13:55:29.152802
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Test to make sure GlobalCLIArgs is a singleton
    global_instance = GlobalCLIArgs({'hello': 'world'})
    global_instance_double = GlobalCLIArgs({'hello': 'not world'})
    assert id(global_instance) == id(global_instance_double)

# Generated at 2022-06-23 13:55:33.215861
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _Test(metaclass=_ABCSingleton):
        pass

    assert isinstance(_Test().__class__, ABCMeta)
    _Test()
    try:
        _Test()
        assert False, "Should not be able to create a second instance of a Singleton"
    except TypeError:
        assert True

# Generated at 2022-06-23 13:55:41.989145
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = GlobalCLIArgs({})
    b = GlobalCLIArgs({'a': 1})
    c = GlobalCLIArgs({'a': 1, 'b': '2'})
    d = GlobalCLIArgs({'a': ['1', '2']})
    e = GlobalCLIArgs({'a': {'b': '1'}})

    assert isinstance(a, ImmutableDict)
    assert isinstance(b, ImmutableDict)
    assert isinstance(c, ImmutableDict)
    assert isinstance(d, ImmutableDict)
    assert isinstance(e, ImmutableDict)

    assert isinstance(a, GlobalCLIArgs)
    assert isinstance(b, GlobalCLIArgs)
    assert isinstance(c, GlobalCLIArgs)

# Generated at 2022-06-23 13:55:48.137385
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    sys.argv.append('-m setup')
    with CLI.CLIBase() as cli_base:
        cli_base.parse()
        try:
            a = GlobalCLIArgs(vars(cli_base))
        except TypeError:
            assert False # Should always work
        else:
            assert True # Should always work

# Generated at 2022-06-23 13:55:54.451392
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Access global data structure GlobalCLIArgs
    global_args1 = GlobalCLIArgs({'a': 1})

    # Access global data structure GlobalCLIArgs second time
    # and cause SingletonError exception
    try:
        global_args2 = GlobalCLIArgs({'b': 2})
    except SingletonError:
        try:
            assert global_args1 == global_args2
        except:
            pass

# Generated at 2022-06-23 13:56:00.274395
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Smoke test the GlobalCLIArgs object

    Since it is a Singleton, if we can construct it and assign it, we can construct it again
    and the two references will point to the same object.
    """
    # pylint: disable=protected-access
    assert GlobalCLIArgs._GlobalCLIArgs__instance is None
    test_object = GlobalCLIArgs({u'foo': u'bar'})
    assert test_object._GlobalCLIArgs__instance is not None
    assert test_object == GlobalCLIArgs._GlobalCLIArgs__instance
    assert test_object is GlobalCLIArgs._GlobalCLIArgs__instance
    # pylint: enable=protected-access

# Generated at 2022-06-23 13:56:10.586045
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({}) == ImmutableDict({})
    assert CLIArgs({'a': 1}) == ImmutableDict({'a': 1})
    assert CLIArgs({'a': 1, 'b': 2}) == ImmutableDict({'a': 1, 'b': 2})
    assert CLIArgs({'a': 1, 'b': [1, 2]}) == ImmutableDict({'a': 1, 'b': [1, 2]})
    assert CLIArgs({'a': 1, 'b': (1, 2)}) == ImmutableDict({'a': 1, 'b': (1, 2)})
    assert CLIArgs({'a': 1, 'b': {'c': 3}}) == ImmutableDict({'a': 1, 'b': {'c': 3}})

# Generated at 2022-06-23 13:56:13.253179
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        pass

    assert type(A) is _ABCSingleton
    assert A is _ABCSingleton

# Generated at 2022-06-23 13:56:17.209643
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
    try:
        obj1 = TestClass()
        obj2 = TestClass()
    except:
        raise AssertionError("Could not create singleton object")
    assert obj1 is obj2

# Generated at 2022-06-23 13:56:21.323451
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Make sure that GlobalCLIArgs is enforced as a Singleton
    """
    first = GlobalCLIArgs({'foo': 'bar'})
    second = GlobalCLIArgs({'foo': 'baz'})

    assert first is second
    assert first == {'foo': 'baz'}

# Generated at 2022-06-23 13:56:23.630528
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    s = GlobalCLIArgs()
    assert isinstance(s, GlobalCLIArgs)


# Generated at 2022-06-23 13:56:24.672610
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    CLIArgs(dict())

# Generated at 2022-06-23 13:56:34.504374
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    __import__('ansible.cli.cli')

    new_parent_args_dict = {'scp_extra_args': '-C'}
    new_args_dict = {'playbook': '/home//playbook', 'syntax': False, 'help': False, 'version': False, 'connection': 'smart', 'timeout': 10, 'inventory': '/home/', 'forks': 10, 'remote_user': None, 'private_key_file': None, 'ssh_common_args': '', 'ssh_extra_args': '', 'sftp_extra_args': '', 'scp_extra_args': '-C', 'become': None, 'become_method': None, 'become_user': None, 'verbosity': 0, 'check': False}

    # Generated with:
    # echo "copy.

# Generated at 2022-06-23 13:56:42.191582
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = {'version_check': True,
            'version_check_extra': True,
            'become_ask_pass': True,
            'ask_vault_pass': True,
            'ask_sudo_pass': True,
            'ask_su_pass': True,
            'become_method': 'sudo',
            'become_user': 'root',
            'ask_pass': True,
            'private_key_file': ['/home/user/.ssh/id_rsa'],
            'verbosity': 0}
    GlobalCLIArgs(args)

# Generated at 2022-06-23 13:56:51.050368
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import copy
    from ansible.module_utils.basic import AnsibleModule

    ansible_options = AnsibleModule(
        argument_spec={
            'ansible_string': {'type': 'str', 'default': 'hello'},
            'ansible_list': {'type': 'list', 'default': ['world']},
            'ansible_dict': {'type': 'dict', 'default': {'ok': 'bye'}},
        },
        check_invalid_arguments=False,
        bypass_checks=True,
        no_log=True,
    ).params

    test_string = 'hello'
    test_list = ['world']
    test_dict = {'ok': 'bye'}

    test_args = GlobalCLIArgs.from_options(ansible_options)
    assert test_args

# Generated at 2022-06-23 13:56:53.524599
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'alpha': 'a', 'beta': 'b', 'gamma': [[[], []]]}
    test = CLIArgs(test_dict)
    assert test == ImmutableDict(test_dict)

# Generated at 2022-06-23 13:56:59.575940
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyABCSingleton(metaclass=_ABCSingleton):
        pass

    class MyABCSingleton2(metaclass=_ABCSingleton):
        pass

    class FirstInstance(MyABCSingleton):
        pass

    class SecondInstance(MyABCSingleton):
        pass

    assert(FirstInstance() is FirstInstance())
    assert(FirstInstance() is not SecondInstance())
    assert(FirstInstance() is not FirstInstance.__new__(MyABCSingleton2))

# Generated at 2022-06-23 13:57:01.702033
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-23 13:57:12.455619
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test the GlobalCLIArgs constructor

    Check that is_docker() is present in the class, and that it is not implemented, so
    that the class is abstract.

    Check that the class cannot be instantiated, since it is abstract.

    The test passes if the constructor attempts to call is_docker() and then raises
    a TypeError exception, which is the expected behaviour for an abstract class.

    >>> g = GlobalCLIArgs({})
    Traceback (most recent call last):
    ...
    TypeError: Can't instantiate abstract class GlobalCLIArgs with abstract methods is_docker
    """
    pass

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 13:57:16.944820
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, ABCMeta)
    assert issubclass(_ABCSingleton, Singleton)
    assert _ABCSingleton is not ABCMeta
    assert _ABCSingleton is not Singleton

# Generated at 2022-06-23 13:57:19.568542
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class test(object, metaclass=_ABCSingleton):
        pass

    assert issubclass(test, Singleton)
    assert issubclass(test, ABCMeta)

# Generated at 2022-06-23 13:57:29.918763
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils.common.collections import AttributeDict
    from ansible.module_utils.six import with_metaclass

    class Example(_ABCSingleton):
        def __init__(self, **kwargs):
            self.data = AttributeDict(kwargs)

        def __str__(self):
            return str(self.data)

    class ExampleMeta(with_metaclass(_ABCSingleton, ABCMeta)):
        def __init__(self):
            self.data = AttributeDict()

    try:
        Example(one=1, two=2, three=3)
    except TypeError:
        # This is what we want.  We want ABCMeta to be able to complain that the class is abstract,
        # but not have that complaint take precedence over the Singleton complaint.
        pass

# Generated at 2022-06-23 13:57:38.469321
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({}) == {}
    assert CLIArgs({'one': 1}) == {'one': 1}
    assert CLIArgs({'one': 1, 'two': 2}) == {'one': 1, 'two': 2}
    assert CLIArgs({'one': [1, 2, 3], 'two': (1, 2, 3)}) == {'one': (1, 2, 3), 'two': (1, 2, 3)}
    assert CLIArgs({
        'one': {'two': 2},
        'three': {'four': 4},
        'five': (1, {'six': 6})
    }) == {
        'one': {'two': 2},
        'three': {'four': 4},
        'five': (1, {'six': 6})
    }

# Generated at 2022-06-23 13:57:44.171090
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Unit test CLIArgs constructor"""
    original_dict = {u'foo': u'bar', u'baz': u'qux'}
    cli_args = CLIArgs(original_dict)

    assert cli_args[u'foo'] == u'bar'
    assert cli_args[u'baz'] == u'qux'

    with pytest.raises(TypeError):
        cli_args[u'new_key'] = u'new_value'



# Generated at 2022-06-23 13:57:53.029021
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # test non-container case
    mapping = {'a': 'b'}
    result = CLIArgs(mapping)
    assert mapping == result
    assert mapping is not result

    # test sequential container case
    mapping = {'a': [1, 2, 3, 4], 'b': [5, 6, 7, 8]}
    result = CLIArgs(mapping)
    assert mapping == result
    assert mapping is not result
    for i, v1 in enumerate(mapping['a']):
        assert v1 == mapping['a'][i]
        assert v1 != result['a'][i]

    # test mapping container case

# Generated at 2022-06-23 13:57:58.732902
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import os
    import ansible.utils.path
    from ansible.errors import AnsibleOptionsError
    orig_0 = sys.argv[0]

# Generated at 2022-06-23 13:58:00.899456
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    try:
        GlobalCLIArgs()
    except Exception as e:
        print(e)

# Generated at 2022-06-23 13:58:09.085717
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Test the GlobalCLIArgs singleton class"""

    class FakeOptions(object):
        """Helper class used to initialize GlobalCLIArgs singleton class"""
        # pylint: disable=too-few-public-methods
        verbosity = 0
        inventory = None
        subset = None

    option_singleton = GlobalCLIArgs.from_options(FakeOptions())
    assert isinstance(option_singleton, GlobalCLIArgs)
    assert option_singleton.verbosity == 0
    assert option_singleton.inventory is None
    assert option_singleton.subset is None

    # Test an actual GlobalCLIArgs object
    # Need to import this here because ansible.cli.CLI.options is not available until CLI.setup
    from ansible.cli import CLI

# Generated at 2022-06-23 13:58:19.567884
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    opts = {'a': 0,
            'b': False,
            'c': 'c',
            'd': {'e': 'e', 'f': 0},
            'g': ['g', 'h', 'i', 0],
            'j': frozenset(['j', 'k']),
            'l': u'\u0061',
            'm': b'\xc3\xa9',
            'n': ['\u0061', u'\xe9', '\xc3\xa9']
            }

# Generated at 2022-06-23 13:58:24.091370
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    args = parser.parse_args([])
    assert args.foo is None
    cli_args = GlobalCLIArgs.from_options(args)
    assert cli_args.foo is None
    cli_args = GlobalCLIArgs.from_options(cli_args)
    assert cli_args.foo is None

# Generated at 2022-06-23 13:58:35.966614
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import os

    # For this unit test to run correctly, you must run the tests with a particular environment variable
    # set.  Even if you do not, this is just testing code paths, so the unit test does not need to run
    # for real testing.
    if 'ANSIBLE_UNIT_TESTING' not in os.environ:
        return

    gls = GlobalCLIArgs({'foo': 'bar', 'baz': 'qux'})
    assert gls['foo'] == 'bar'
    assert gls['baz'] == 'qux'
    assert gls.get('foo') == 'bar'
    assert gls.get('baz') == 'qux'
    assert gls.get('does_not_exist') is None
    globals()['test_GlobalCLIArgs_obj'] = gls


# Generated at 2022-06-23 13:58:45.461540
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that constructor of class CLIArgs works properly
    data1 = {'a': 1, 'b': text_type('abc'), 'c': 'abc'}
    data2 = {'d': {'a': 1}, 'e': {'b': 2}, 'f': [{'a': 1}, 2, '3']}
    data3 = {'g': {'hello': 'world'}, 'h': [1, 2, 3]}
    data = dict(data1, **data2, **data3)

    args = CLIArgs(data)

    # Make sure the keys show up properly
    assert set(args.keys()) == set(data.keys())

    # Make sure the contents of the dict match
    for key, value in data1.items():
        assert args[key] == value

# Generated at 2022-06-23 13:58:53.303855
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test that GlobalCLIArgs is a singleton
    """
    args1 = CLIArgs({u'a': b'b', u'c': b'd'})
    assert args1 == {u'a': b'b', u'c': b'd'}
    args2 = CLIArgs.from_options(ImmutableDict({u'a': b'b', u'c': b'd'}))
    assert args2 == {u'a': b'b', u'c': b'd'}

    gargs1 = GlobalCLIArgs({u'a': u'b', u'c': u'd'})
    assert gargs1 == {u'a': u'b', u'c': u'd'}

# Generated at 2022-06-23 13:58:57.993495
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        pass

    class FooSingleton(_ABCSingleton, Foo):
        pass

    class Bar(FooSingleton):
        pass

    bar = Bar()
    bar2 = Bar()
    assert bar == bar2

# Generated at 2022-06-23 13:59:04.033395
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    class B(A):
        pass
    assert issubclass(B, A)
    class C(metaclass=_ABCSingleton):
        pass

# Generated at 2022-06-23 13:59:05.433058
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    b = _make_immutable(dict(a=1, b=2))
    a = GlobalCLIArgs(b)
    assert isinstance(a, GlobalCLIArgs)
    assert a == b

# Generated at 2022-06-23 13:59:06.494220
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    gca1 = GlobalCLIArgs.from_options(None)
    assert gca1 is GlobalCLIArgs.from_options(None)

# Generated at 2022-06-23 13:59:15.049753
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import json

    class FakeOptions:
        def __init__(self, mapping):
            for key, value in mapping.items():
                setattr(self, key, value)


# Generated at 2022-06-23 13:59:21.753530
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test1(object):
        __metaclass__ = _ABCSingleton

    class Test2(Test1):
        pass

    class Test3(Test2):
        pass

    class Test4(Test2):
        pass

    t1 = Test1()
    t2 = Test2()
    t3 = Test3()
    t4 = Test4()

    assert t1 is t2
    assert t1 is t3
    assert t1 is t4
    assert t2 is t3
    assert t2 is t4
    assert t3 is t4

# Generated at 2022-06-23 13:59:29.244824
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test storing the mapping
    mapping = {
        "test": [1, 2, 3],
        "test2": (1, 2, 3),
        "test3": {1, 2, 3},
        "test4": {"1": 1, "2": 2, "3": 3},
        "test5": {"1": 1, "2": [1, 2, 3, {"4": 4}]},
    }
    # Check that the mapping was stored correctly
    toplevel = CLIArgs(mapping)
    assert toplevel == mapping

    # Check that all the elements were converted to immutable data types
    for value in toplevel.values():
        assert isinstance(value, (text_type, binary_type, frozenset, tuple, ImmutableDict))

    # Check that items that were immutable were not converted

# Generated at 2022-06-23 13:59:38.487212
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.display import Display
    display = Display()

# Generated at 2022-06-23 13:59:44.962209
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(GlobalCLIArgs, Singleton)
    assert issubclass(GlobalCLIArgs, Container)
    assert issubclass(GlobalCLIArgs, Mapping)
    assert isinstance(GlobalCLIArgs(), GlobalCLIArgs)
    assert issubclass(GlobalCLIArgs, ABCMeta)
    assert issubclass(GlobalCLIArgs, Singleton)

# Generated at 2022-06-23 13:59:47.471303
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        @add_metaclass(_ABCSingleton)
        class Bar(object):
            pass
    assert Foo.Bar() == Foo.Bar()

# Generated at 2022-06-23 13:59:53.981506
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {
        'foo': 'bar',
        'baz': {
            'frob': [
                1,
                'qux',
                {
                    'yuck': [
                        'what',
                        {
                            'huh': [
                                'you',
                                'are',
                                'so',
                                'deep',
                            ],
                        },
                    ]
                }
            ],
        },
    }

    x = CLIArgs(test_dict)
    assert x == test_dict

# Generated at 2022-06-23 13:59:55.150188
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert id(GlobalCLIArgs({})) == id(GlobalCLIArgs({}))

# Generated at 2022-06-23 14:00:04.233846
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': {'b': {3: 4, 'c': 5}}})
    assert isinstance(args, ImmutableDict)
    assert isinstance(args['a'], ImmutableDict)
    assert isinstance(args['a']['b'], ImmutableDict)
    assert isinstance(args['a']['b'][3], int)
    assert isinstance(args['a']['b']['c'], int)
    assert args == {'a': {'b': {3: 4, 'c': 5}}}

    # Test that we can't change the dictionaries we get back
    with pytest.raises(TypeError, match="'CLIArgs' object does not support item assignment"):
        args['a'] = 3

# Generated at 2022-06-23 14:00:11.206515
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable

    args = CLIArgs({'a': [1, 2, 3], 'c': {'b': 4, 'c': 5}})
    assert args == {'a': (1, 2, 3), 'c': {'b': 4, 'c': 5}}
    assert is_immutable(args)
    assert is_immutable(args['c'])
    assert is_immutable(args['a'])



# Generated at 2022-06-23 14:00:24.721245
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        def __init__(self, **kwargs):
            for name, value in kwargs.items():
                setattr(self, name, value)


# Generated at 2022-06-23 14:00:29.789012
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    opts = {'a': 1, 'b': 2}
    args = CLIArgs.from_options(opts)
    assert repr(args) == repr(ImmutableDict(opts))

    opts = {'a': {'b': [1, 2, 3]}}
    args = CLIArgs.from_options(opts)
    assert repr(args) == repr(ImmutableDict(opts))


# Generated at 2022-06-23 14:00:34.878872
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Ensure that when a CLIArgs object is created, it is an ImmutableDict object.
    """
    cli_args = CLIArgs({'test': True, 'debug': False})
    assert isinstance(cli_args, ImmutableDict)


# Generated at 2022-06-23 14:00:44.074913
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class TestOptions(object):
        test1 = 'value1'
        test2 = 'value2'
        test3 = ['value3']
        test4 = ['value4']
    options = TestOptions()
    args = GlobalCLIArgs.from_options(options)
    assert isinstance(args, GlobalCLIArgs)
    assert args['test1'] == 'value1'
    assert args['test2'] == 'value2'
    assert len(args['test3']) == 1
    assert args['test3'][0] == 'value3'
    assert len(args['test4']) == 1
    assert args['test4'][0] == 'value4'

# Generated at 2022-06-23 14:00:55.223175
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Unit test for CLIArgs class

    Use this function to unit test the CLIArgs class.
    The function will be called automatically when this module is run as a script.
    """
    # Setup
    from collections import OrderedDict
    from ansible.module_utils.basic import AnsibleModule

    def check_function(test_case_name, args, expected_result):
        """Check this function
        """
        # Setup
        args = OrderedDict(args)

        # When: Run function
        result = AnsibleModule(argument_spec=args).params

        # Then:
        print(test_case_name + ": Assertion")
        assert result == expected_result

    # Given:
    print("test_CLIArgs: Given")

    # When:

# Generated at 2022-06-23 14:00:58.101092
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    data = {'a': {'b': {'c': 'd'}}}
    cli_args = CLIArgs(data)
    assert(isinstance(cli_args, CLIArgs))


# Generated at 2022-06-23 14:01:00.512041
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():  # noqa: D103
    class Foo(object, metaclass=_ABCSingleton):
        pass

    class Bar(Foo):
        pass
    assert Bar == Foo

# Generated at 2022-06-23 14:01:07.723018
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Unit test for CLIArgs.

    :return:
    """
    mutable = {
            'one': {
                'two': {
                    'three': [
                        1,
                        [2, 3],
                        {4: 5}
                    ]
                }
            }
        }
    cli_args = CLIArgs(mutable)
    assert(isinstance(cli_args, CLIArgs))
    assert(cli_args == mutable)
    # This should not be mutable
    with pytest.raises(TypeError):
        cli_args['one'] = 'two'

# Generated at 2022-06-23 14:01:10.731551
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    assert issubclass(A, ABCMeta)
    assert issubclass(A, Singleton)

# Generated at 2022-06-23 14:01:13.577529
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert isinstance(_ABCSingleton, Singleton)
    assert isinstance(_ABCSingleton, ABCMeta)

# Generated at 2022-06-23 14:01:18.784554
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # pylint: disable=protected-access
    # Ensure internal representation is immutable
    assert GlobalCLIArgs._cached_instances['_GlobalCLIArgs__singleton_instance']._toplevel == GlobalCLIArgs._cached_instances['_GlobalCLIArgs__singleton_instance']._toplevel.copy()

# Generated at 2022-06-23 14:01:23.371116
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class class1(metaclass=_ABCSingleton):
        pass
    # No need to create an instance of class1, _ABCSingleton will do it.
    # But we need to call __init__().
    class1()
    return True

# This is a instance
cli_args = GlobalCLIArgs(ImmutableDict({}))

# Generated at 2022-06-23 14:01:31.609930
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.errors import AnsibleError
    from ansible.parsing.utils.addresses import parse_address

    try:
        GlobalCLIArgs.__instance
    except AttributeError:
        GlobalCLIArgs.__instance = object.__new__(GlobalCLIArgs)
        GlobalCLIArgs.__instance.__init__({})
    except AnsibleError:
        GlobalCLIArgs.__instance = object.__new__(GlobalCLIArgs)
        GlobalCLIArgs.__instance.__init__({})

    # Check the correct type
    assert isinstance(GlobalCLIArgs.__instance, GlobalCLIArgs)

    # After init, GlobalCLIArgs.__instance should be immutable
    try:
        GlobalCLIArgs.__instance[0] = 'some value'
    except TypeError:
        pass

# Generated at 2022-06-23 14:01:37.725481
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class FakeOptions(object):
        pass

    fake_options = FakeOptions()
    fake_options.foo = 1
    fake_options.bar = "two"

    g = GlobalCLIArgs.from_options(fake_options)
    assert (g.get("foo") == 1)
    assert (g.get("bar") == "two")
    try:
        g["foo"] = 2
    except TypeError as e:
        assert "does not support item assignment" in str(e)

# Generated at 2022-06-23 14:01:39.618420
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert id(GlobalCLIArgs()) == id(GlobalCLIArgs())


# Generated at 2022-06-23 14:01:49.043350
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 'A', 'b': {'c': 'C', 'd': {'e': 'E'}}, 'f': [{'g': 'G'}, {'h': 'H'}]})
    assert isinstance(args, ImmutableDict)
    assert args == ImmutableDict({'a': 'A', 'b': ImmutableDict({'c': 'C', 'd': ImmutableDict({'e': 'E'})}), 'f': (ImmutableDict({'g': 'G'}), ImmutableDict({'h': 'H'}))})

# Generated at 2022-06-23 14:01:54.655559
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Test CLIArgs __init__ method."""
    test_dict = {'test': 'test_value'}
    test_obj = CLIArgs(test_dict)

    assert test_obj is not test_dict
    assert test_obj == test_dict


# Unit tests for _make_immutable

# Generated at 2022-06-23 14:01:58.579461
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    class B(A):
        pass
    class C(A):
        pass
    b = B()
    c = C()
    assert b is not c

# Generated at 2022-06-23 14:02:01.716465
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = dict(foo=dict(bar=42))
    cliargs_obj = CLIArgs(mapping)
    first_value = cliargs_obj['foo']['bar']
    assert first_value == 42

# Generated at 2022-06-23 14:02:09.303541
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    _cli_args = CLIArgs(dict(test=1,test2=2,test3=3))

    assert isinstance(_cli_args, ImmutableDict)
    assert isinstance(_cli_args, Mapping)
    assert isinstance(_cli_args, CLIArgs)

    assert isinstance(_cli_args['test'], int)
    assert isinstance(_cli_args['test2'], int)
    assert isinstance(_cli_args['test3'], int)

    assert _cli_args['test'] == 1
    assert _cli_args['test2'] == 2
    assert _cli_args['test3'] == 3

# Generated at 2022-06-23 14:02:10.285618
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        pass

    assert isinstance(Test(), Test)

# Generated at 2022-06-23 14:02:15.298732
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Unit test for _ABCSingleton metaclass"""

    class Foo(object):
        """Dummy class to test _ABCSingleton metaclass"""
        __metaclass__ = _ABCSingleton

    foo = Foo()
    assert(foo is Foo())
    assert(repr(foo) == '<Foo>')

# Generated at 2022-06-23 14:02:23.301886
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils._text import to_text
    import json

    # Test basic types
    my_dict = {'str': 'str',
               'int': 1,
               'float': 1.0,
               'bool': True,
               'list': [1, 2, 3],
               'tuple': (1, 2, 3),
               'set': {1, 2, 3},
               'dict': {'a': 1, 'b': 2, 'c': 3},
               'binary': b'str',
               'unicode': to_text('str')}

    my_immutable_dict = CLIArgs(my_dict)

    assert(my_immutable_dict == my_dict)
    assert(isinstance(my_immutable_dict, ImmutableDict))

# Generated at 2022-06-23 14:02:27.854894
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common._collections_compat import Mapping
    gargs = GlobalCLIArgs({'v': True, 'k': 'v'})
    assert isinstance(gargs, Mapping)

# Generated at 2022-06-23 14:02:32.538961
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    assert A.__new__ == B.__new__
    assert C.__new__ == D.__new__
    assert A.__new__ == D.__new__

# Generated at 2022-06-23 14:02:43.605276
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that all we need for the constructor of class CLIArgs is a Mapping
    """
    from ansible.utils.vars import combine_vars
    # The test harness calls us as a function, so ignore the 'self' parameter from pylint.
    # pylint: disable=no-self-use
    cli_args = {'one': '1', 'two': '2', 'three': '3'}
    args = CLIArgs({'vars': cli_args})
    combined_vars = combine_vars(None, cli_args)
    combined_vars = _make_immutable(combined_vars)

    assert isinstance(args['vars'], ImmutableDict)
    assert args['vars'] == combined_vars

# Generated at 2022-06-23 14:02:52.962670
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # type: () -> None
    inner_dict = {'key1': 'value1', 'key2': 'value2'}
    test_dict = {'key1': 'value1', 'key2': 'value2', 'key3': inner_dict}
    cli_args = CLIArgs(test_dict)

    assert isinstance(cli_args, dict)
    assert cli_args == test_dict
    assert isinstance(cli_args['key3'], ImmutableDict)
    assert cli_args['key3'] == inner_dict
    assert isinstance(cli_args['key3']['key1'], text_type)



# Generated at 2022-06-23 14:03:02.261267
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils.common.collections import MutableSet, MutableSequence
    class Container1(MutableSet):
        pass

    class Mutable1(MutableSequence):
        pass

    class Container2(MutableSet):
        pass

    class Mutable2(MutableSequence):
        pass

    class Container3(Container1, Container2):
        pass

    class Mutable3(Mutable1, Mutable2):
        pass


if __name__ == '__main__':
    # Run the unit test if started directly
    test__ABCSingleton()  # pylint: disable=no-value-for-parameter

# Generated at 2022-06-23 14:03:06.291697
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'one': 1, 'two': 2, 'three': [1, 2, 3]}
    cli_args = CLIArgs(mapping)
    assert cli_args.one == 1
    assert cli_args.two == 2
    assert cli_args.three == (1, 2, 3)

# Generated at 2022-06-23 14:03:14.375752
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """The constructor of class CLIArgs makes a copy of its parameter in an immutable form.
    Also, it converts the top level items to immutable.
    """
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('-k', '--key1')
    parser.add_argument('-g', '--group1')
    args = parser.parse_args([])
    args.key1 = 'value'
    args.group1 = ['a', 'b', 'c']

    args = CLIArgs(vars(args))
    assert args.key1 == 'value'
    assert args.group1 == ('a', 'b', 'c')
    del args.group1
    assert args.group1 == ()
    args.group1 += ('d',)
    assert args.group1 == ()
    args

# Generated at 2022-06-23 14:03:24.789444
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class A(object):
        pass
    a = A()
    a.x = "Hellow"
    a.y = True
    a.z = False
    a.b = [{'a': 1, 'b': 2, 'c': 3}, {'a': 4, 'b': {'a': 5, 'b': 6}}]
    a.c = 1.1
    a.d = 1
    a.e = {1,2,3}
    a.f = (1,2,3,{'a': 1, 'b': 2, 'c': 3},{1,2,3})
    a.g = [1,2,3,{'a': 1, 'b': 2, 'c': 3},{1,2,3}]
    b = CLIArgs(vars(a))
   

# Generated at 2022-06-23 14:03:29.705062
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'first_key': 'first_value',
                 'second_key': 'second_value',
                 'third_key': {'fourth_key': 'fourth_value'},
                 'fifth_key': ['sixth_value', 'seventh_value']}
    cli_args = CLIArgs(test_dict)
    assert cli_args == test_dict


# Generated at 2022-06-23 14:03:31.514447
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        pass

    assert(issubclass(Test, Singleton))
    assert(issubclass(Test, ABCMeta))

# Generated at 2022-06-23 14:03:36.037741
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 1, 'b': 2, 'c': {'d': {'e': [1, 2, 3]}}})
    assert args.a == 1
    assert args.b == 2
    assert args.c.d.e == (1, 2, 3)

# Generated at 2022-06-23 14:03:47.631386
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import random
    x = random.randint(1,10)
    y = random.randint(1,10)

    args = {
        'x': x,
        'y': y,
        'z': [random.randint(1,10) for i in range(1,10)],
        't': {"x":x, "y":y},
        's': set([x, y]),
    }

    # only one of these exist per program as it is for global context
    cli_args = CLIArgs(args)
    cli_args_2 = CLIArgs(args)

    assert cli_args == cli_args_2
    assert cli_args_2.x == x
    assert cli_args_2.y == y

# Generated at 2022-06-23 14:03:56.193505
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import argparse
    parser = argparse.ArgumentParser(description='Argparse test')
    parser.add_argument('--one', action='store_true')
    parser.add_argument('--two', type=int)
    parser.add_argument('--three', nargs=2, type=int)
    parser.add_argument('--four', nargs='*', type=int)
    parser.add_argument('--five', nargs='+', type=int)
    args = parser.parse_args(['--one', '--two', '47', '--three', '1', '2', '--four', '3', '4', 
        '--five', '3', '4'])
    args = CLIArgs.from_options(args)
    assert args['one']
    assert args['two'] == 47
   

# Generated at 2022-06-23 14:03:59.510564
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import ansible.utils.args
    args = ansible.utils.args.parse_args([])
    _GlobalCLIArgs = GlobalCLIArgs.from_options(args)
    assert type(_GlobalCLIArgs) == GlobalCLIArgs

    args2 = ansible.utils.args.parse_args(["-a", "ls"])
    _GlobalCLIArgs2 = GlobalCLIArgs.from_options(args2)
    assert _GlobalCLIArgs == _GlobalCLIArgs2