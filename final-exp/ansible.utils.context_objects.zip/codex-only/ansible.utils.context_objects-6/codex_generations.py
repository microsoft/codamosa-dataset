

# Generated at 2022-06-23 13:54:11.240422
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    # Parse args of current program
    parser = argparse.ArgumentParser()
    parser.add_argument('key_to_delete', action='store', nargs=1)
    options, _ = parser.parse_known_args(sys.argv[1:])
    args = GlobalCLIArgs.from_options(options)
    # Ensure constructor of class GlobalCLIArgs works
    assert isinstance(args, GlobalCLIArgs)
    assert isinstance(args, CLIArgs)
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, dict)
    # Ensure values are immutable
    try:
        args['other'] = 1
    except TypeError:
        assert True
    else:
        assert False, 'args[key] should be immutable'

# Generated at 2022-06-23 13:54:12.533877
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(metaclass=_ABCSingleton): pass
    f = Foo()

# Generated at 2022-06-23 13:54:14.391702
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ABCSingletonTestcase(object):
        __metaclass__ = _ABCSingleton

    ABCSingletonTestcase()

# Generated at 2022-06-23 13:54:16.134203
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert hasattr(_ABCSingleton, '__isabstractmethod__')

# Generated at 2022-06-23 13:54:19.787412
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    # Now test the Singleton part of the _ABCSingleton
    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-23 13:54:21.923153
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({'foo': 'bar'})  # Call the __init__ method
    assert args['foo'] == 'bar'

# Generated at 2022-06-23 13:54:29.285262
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from argparse import Namespace
    from ansible.module_utils.six import b
    args = Namespace()
    args.foo = [b"bar", b"baz"]
    args.bar = b"qux"
    args.baz = {u"quux": u"corge", u"grault": u"garply"}
    args.qux = b"waldo"
    args.quux = [u"fred", u"plugh", u"xyzzy", u"thud"]

    global_cli_args = GlobalCLIArgs.from_options(args)
    assert global_cli_args
    assert isinstance(global_cli_args, dict)
    assert global_cli_args["foo"] == (b"bar", b"baz")

# Generated at 2022-06-23 13:54:32.589400
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_dict = dict(key_1="value_1", key_2="value_2")
    test_singleton = GlobalCLIArgs(test_dict)
    assert isinstance(test_singleton, GlobalCLIArgs)

# Generated at 2022-06-23 13:54:34.503178
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert(A() == A())
    assert(B() == B())
    assert(A() != B())


# Unit tests for make_immutable

# Generated at 2022-06-23 13:54:46.218272
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    import ansible.module_utils.facts as facts
    from ansible.module_utils.facts.collector import get_collection_functions
    from ansible.module_utils.facts.system import distro

    # Smoke test for the collector
    for name, func in get_collection_functions(facts.collector.FactsCollector()).iteritems():
        if isinstance(func, collections.Callable) and not name.startswith('_'):
            func()

    # Smoke test for the system module
    distro.collect()

    opts = CLIArgs.from_options(facts.collector._get_options())
    assert isinstance(opts, CLIArgs)
    assert opts.get('test') is None

    # Test cloning of iterables

# Generated at 2022-06-23 13:54:53.089618
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.standard import AnsibleModule
    module = AnsibleModule(argument_spec=dict(
        foo=dict(type='str', default='bar'),
        baz=dict(type='list', default=['qux'])),
    )
    options = module.params
    instance = GlobalCLIArgs.from_options(options)
    assert instance == {'baz': ('qux',), 'foo': 'bar'}
    assert isinstance(instance, ImmutableDict)
    assert isinstance(instance, CLIArgs)
    assert isinstance(instance, GlobalCLIArgs)
    assert isinstance(instance['foo'], text_type)
    assert isinstance(instance['baz'], tuple)
    assert isinstance(instance['baz'][0], text_type)

# Generated at 2022-06-23 13:55:04.057617
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs.from_options(ImmutableDict()) == ImmutableDict()
    assert CLIArgs.from_options(ImmutableDict({
        "a": "a",
        "b": 2,
        "c": {
            "d": "d",
            "e": [1, 2, 3]
        }
    })) == ImmutableDict({
        "a": "a",
        "b": 2,
        "c": ImmutableDict({
            "d": "d",
            "e": (1, 2, 3)
        })
    })

# Generated at 2022-06-23 13:55:16.788623
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    original = {
        'list': [0, 1, 2, 3],
        'dict': {'a': 1, 'b': 2, 'c': 3},
        'tuple': (0, 1, 2, 3),
        'text': text_type("hello"),
        'binary': binary_type('\0'),
        'set': set([0, 1, 2, 3]),
    }
    args = CLIArgs(original)

    assert args['list'] == (0, 1, 2, 3)
    assert args['dict'] == ImmutableDict(original['dict'])
    assert args['tuple'] == (0, 1, 2, 3)
    assert args['text'] == 'hello'
    assert args['binary'] == b'\x00'

# Generated at 2022-06-23 13:55:23.588651
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options:
        pass
    options = Options()
    options.foo = {'a': {'b': 'hello'}}
    args = GlobalCLIArgs.from_options(options)
    assert args is GlobalCLIArgs.instance()
    # Making sure that immutable stuff is immutable
    assert isinstance(args['foo'], ImmutableDict)
    assert isinstance(args['foo']['a'], ImmutableDict)
    assert args['foo']['a']['b'] == 'hello'
    try:
        args['foo']['a']['b'] = 'goodbye'
    except TypeError:
        assert True
    else:
        assert False

# Generated at 2022-06-23 13:55:28.149055
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        # pylint: disable=unused-variable
        class A(object, metaclass=_ABCSingleton):  # noqa
            pass
    except TypeError:
        raise

# Generated at 2022-06-23 13:55:34.319204
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    g_args = GlobalCLIArgs({'a': 1, 'b': 2, 'c': 3})
    assert g_args
    assert isinstance(g_args, GlobalCLIArgs)
    assert isinstance(g_args, ImmutableDict)
    assert g_args == {'a': 1, 'b': 2, 'c': 3}
    assert g_args.get('a') == 1
    assert g_args.get('d') is None
    assert g_args['a'] == 1
    assert g_args['d']

# Generated at 2022-06-23 13:55:42.718297
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader

    args = ['-a', 'ls', '-v', '-m', 'setup', '-i', 'localhost,', '-e', '"ansible_python_interpreter=/tmp/doesnotexist"', '-e', '@myvars.yml']
    options = CLIArgs.from_options(DataLoader().load_from_file(args))

    # Test 1: Test that the constructor accepts all types correctly
    # TODO: Test dict, list, and set
    cls = GlobalCLIArgs
    assert isinstance(cls, _ABCSingleton)
    assert issubclass(cls, ImmutableDict)
   

# Generated at 2022-06-23 13:55:45.150607
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    empty = dict()
    # This will raise an error if the constructor changes
    assert GlobalCLIArgs(empty)

# Generated at 2022-06-23 13:55:47.438374
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    opt = GlobalCLIArgs({})
    assert isinstance(opt, GlobalCLIArgs)
    assert isinstance(opt, ImmutableDict)

# Generated at 2022-06-23 13:55:53.023061
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert GlobalCLIArgs != CLIArgs
    assert issubclass(GlobalCLIArgs, CLIArgs)
    assert isinstance(GlobalCLIArgs.from_options({'foo': 1}), GlobalCLIArgs)
    assert isinstance(GlobalCLIArgs.from_options({'foo': 1}), CLIArgs)
# end test_GlobalCLIArgs

# Generated at 2022-06-23 13:55:55.446904
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Ensure that _ABCSingleton works as expected"""
    global abc
    abc_type = ABCMeta('ABCSingletonTest', (object,), {})
    abc = abc_type()

# Generated at 2022-06-23 13:55:56.924080
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    a = A()

# Generated at 2022-06-23 13:55:59.471764
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    b = B()
    a = A()
    assert b == a

# Generated at 2022-06-23 13:56:07.667053
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Example of testing CLIArgs constructor with an object that contains structures that it should
    recursively make immutable
    """
    class Options(object):
        """
        A class that has attributes that are mutable
        """
        def __init__(self, foo=1, bar=2, baz={'one': [1, 2, 3], 'two': ['a', 'b', 'c']}):
            self.foo = foo
            self.bar = bar
            self.baz = baz

    options = Options()

    test_tuple = (options, options, options)
    test_dict = {'one': [options, options, options], 'two': {'a': options, 'b': options, 'c': options}}
    test_set = {options, options, options}

    options.foo = test_tuple

# Generated at 2022-06-23 13:56:18.623718
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    data = {'k1': {'k2': {'k3': 'v1'}},
            'k4': set(['v2', 'v3']),
            'k5': ('v4', 'v5',),
            'k6': 'v6',
           }
    instance = CLIArgs(data)
    assert isinstance(instance, ImmutableDict)
    assert isinstance(instance, (Mapping,))
    assert isinstance(instance['k1'], ImmutableDict)
    assert isinstance(instance['k1'], (Mapping,))
    assert isinstance(instance['k1']['k2'], ImmutableDict)
    assert isinstance(instance['k1']['k2'], (Mapping,))
    assert isinstance(instance['k4'], frozenset)


# Generated at 2022-06-23 13:56:21.526975
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # test init the object without param
    cliargs = CLIArgs(dict())
    assert cliargs
    # test init the object with param
    cliargs = CLIArgs(dict(k='v'))
    assert cliargs


# Generated at 2022-06-23 13:56:26.669980
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() == A()
    assert B() == B()
    assert A() != B()


# Generated at 2022-06-23 13:56:31.115027
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
    # two tests in one:
    # 1) Should not raise an exception
    # 2) Should return the same object
    assert TestClass() is TestClass()

# Generated at 2022-06-23 13:56:42.284152
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import collections
    import sys
    import copy

    if sys.version_info[0] == 2:
        # Python 2 uses a different approach so we have a separate test for it.
        # noinspection PyUnresolvedReferences
        from ansible.module_utils.common._collections_compat import PY3

        if PY3:
            return

    from ansible.plugins.loader import get_all_plugin_loaders

    # cli options
    from ansible.module_utils.common.options import list_deprecated_args

    gca = GlobalCLIArgs(list_deprecated_args(get_all_plugin_loaders()))

# Generated at 2022-06-23 13:56:44.132680
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    a = _ABCSingleton()
    b = _ABCSingleton()
    assert a is b

# Generated at 2022-06-23 13:56:51.008483
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict = {'a': 1, 'b': [1, 2], 'c': {'a': 1}}
    cli_args = CLIArgs(dict)
    assert cli_args == dict
    assert isinstance(cli_args, Mapping) and isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args['b'], Sequence) and isinstance(cli_args['b'], tuple)
    assert isinstance(cli_args['c'], Mapping) and isinstance(cli_args['c'], ImmutableDict)


if __name__ == '__main__':
    test_CLIArgs()

# Generated at 2022-06-23 13:56:51.927608
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({'test': 1})

# Generated at 2022-06-23 13:56:55.655918
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(_ABCSingleton):
        pass
    # test that we get a type error when attempting to have a second class of the same type
    try:
        class AnotherTestClass(_ABCSingleton):
            pass
        assert False, "We should not be able to have more than one singleton class of the same type"
    except TypeError:
        # This is the correct behavior
        pass

# Generated at 2022-06-23 13:57:01.717110
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class options:
        ansible_check_mode = True
        ansible_diff_mode = True
        action_plugins = '/path/to/action/plugins'
        inventory = '/path/to/inventory'
        lookup_plugins = '/path/to/lookup/plugins'
        module_path = '/path/to/modules'
        new_vault_password_file = 'new_vault_password_file'
        quiet = True
        roles_path = '/path/to/roles'
        test = True
        vault_password_file = '/path/to/vault_password_file'
    args = GlobalCLIArgs.from_options(options)

    assert not isinstance(args, type(None))
    assert isinstance(args, GlobalCLIArgs)

# Generated at 2022-06-23 13:57:05.989802
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-23 13:57:08.034762
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class X(_ABCSingleton):
        pass
    X()

# Generated at 2022-06-23 13:57:13.659030
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    c = CLIArgs({'a': 1, 'b': [2, 3], 'c': {'d': 4, 'e': [5, 6, 7]}})
    assert c['a'] == 1
    assert c['b'] == (2, 3)
    assert c['c']['d'] == 4
    assert c['c']['e'] == (5, 6, 7)



# Generated at 2022-06-23 13:57:23.955557
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        pass

    opts = Options()
    opts.foo = 1
    opts.bar = 2

    opts.a_dict = {'b': 'c'}
    opts.a_dict['d'] = 'e'
    opts.a_dict['f'] = {'g': 'h'}
    opts.a_dict['f']['i'] = 'j'

    opts.a_list = [1, 2, 3]

    opts.a_set = set()
    opts.a_set.add('c')
    opts.a_set.add('d')
    opts.a_set.add('e')

    # The input has a mutable container inside a mutable container
    # The input also has a mutable container with a mutable

# Generated at 2022-06-23 13:57:32.219138
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {
        "one": "two",
        "list": [1, 2, 3, 4],
        "set": [1, 2, 3, 4],
        "dict": {
            "a": "b",
            "c": "d",
        }
    }
    cli_args = CLIArgs(args)
    assert cli_args['one'] == "two"
    assert cli_args['list'] == (1, 2, 3, 4)
    assert cli_args['set'] == frozenset([1, 2, 3, 4])
    assert cli_args['dict'] == ImmutableDict({
        "a": "b",
        "c": "d",
    })

# Generated at 2022-06-23 13:57:35.034388
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(metaclass=_ABCSingleton):
        pass

    a = A()
    b = B()

    assert a is not A()
    assert a is not B()
    assert A() is not B()

# Generated at 2022-06-23 13:57:44.990787
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common._collections_compat import MutableMapping
    # Create a mutable mapping for testing
    mapping = MutableMapping()
    mapping['key_1'] = 1
    mapping['key_2'] = 2
    mapping['key_3'] = 3
    mapping['key_4'] = 4
    mapping['key_5'] = 5
    # Test constructor
    obj = CLIArgs(mapping)
    assert obj == {'key_1': 1, 'key_2': 2, 'key_3': 3, 'key_4': 4, 'key_5': 5}



# Generated at 2022-06-23 13:57:53.563349
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    # For example, dictionary as argument
    options = {'subdir': 'subdir', 'module_path': ['module_path'], 'force': False, 'module_name': ['module_name']}
    options_args = CLIArgs(options)
    assert options_args.__class__.__name__ == "ImmutableDict"
    assert options_args.subdir == "subdir"
    assert options_args.module_path == ["module_path"]
    assert options_args.force == False
    assert options_args.module_name == ["module_name"]

    # For example, list as argument
    options = [('subdir', 'subdir'), ('module_path', ['module_path']), ('force', False), ('module_name', ['module_name'])]
    options_args = CLIArgs(options)
   

# Generated at 2022-06-23 13:57:55.757950
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(metaclass=_ABCSingleton):
        pass

    class Bar(Foo):
        pass

# Generated at 2022-06-23 13:58:03.644647
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(metaclass=_ABCSingleton):
        def __init__(self):
            self.value = 0

        def inc(self):
            self.value += 1

    f1 = Foo()
    f2 = Foo()
    f1.inc()
    assert f1.value == 1
    assert f2.value == 1

    class Bar(Foo):
        pass

    bar1 = Bar()
    bar2 = Bar()
    bar1.inc()
    assert bar1.value == 1
    assert bar2.value == 1

# Generated at 2022-06-23 13:58:06.872798
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ABCSingleton2(_ABCSingleton):
        pass
    class ABCSingleton3(ABCSingleton2):
        pass

    assert issubclass(ABCSingleton3, ABCSingleton2)

# Generated at 2022-06-23 13:58:09.087170
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    options = "Some Options"
    assert options == CLIArgs.from_options(options)



# Generated at 2022-06-23 13:58:12.966178
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    class Bar(Foo):
        pass

    class Baz(Foo):
        pass

    assert Foo() is Bar()
    assert Foo() is Baz()



# Generated at 2022-06-23 13:58:20.708298
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """ Make sure we have a metaclass that combines the best of both"""
    # pylint: disable=no-init

    class TestSingleton(_ABCSingleton, object):
        pass

    class TestSingleton2(_ABCSingleton, object):
        def __init__(self, value):
            self.value = value

    instance1 = TestSingleton()
    instance2 = TestSingleton()
    assert instance1 is instance2

    try:
        instance1 = TestSingleton2(1)
        instance2 = TestSingleton2()
        assert False, 'Should not allow a Singleton to be constructed without all required arguments'
    except TypeError:
        pass

# Generated at 2022-06-23 13:58:22.806142
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs({'test_key': 'test_value'})
    assert global_cli_args['test_key'] == 'test_value'

# Generated at 2022-06-23 13:58:34.910357
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import argparse
    thing = argparse.Namespace(
        foo='bar',
        baz=['blah', 'yadda'],
        qux={'one': 1, 'two': 2},
    )

    # Test that the parsed arguments got converted to an immutable copy
    args = CLIArgs.from_options(thing)
    assert args['foo'] == 'bar'
    assert args['baz'] == ('blah', 'yadda')
    assert args['qux'] == ImmutableDict({'one': 1, 'two': 2})

    # Make sure the original object is untouched
    assert thing.foo == 'bar'
    assert thing.baz == ['blah', 'yadda']
    assert thing.qux == {'one': 1, 'two': 2}

# Generated at 2022-06-23 13:58:45.605354
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that CLIArgs correctly rejects a dictionary that contains a list
    testInvalidDict = {'foo': 'bar', 'baz': [1, 2, 3]}
    try:
        testObj = CLIArgs(testInvalidDict)
    except:
        # Expected behavior on invalid input
        pass
    else:
        # Unexpected behavior on invalid input
        raise Exception('CLIArgs should have rejected the input dictionary but didn\'t.')
    # Test that CLIArgs doesn't reject a dictionary that contains a tuple
    testValidDict = {'foo': 'bar', 'baz': (1, 2, 3)}
    testObj = CLIArgs(testValidDict)
    # Test that the type of the object returned is the class CLIArgs
    testObjType = type(testObj)
    if testObjType != CLIArgs:
        raise

# Generated at 2022-06-23 13:58:49.220428
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs.from_options(options=dict(a=1,
                                                   b='c'))
    assert isinstance(args, GlobalCLIArgs)
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, dict)
    assert args['b'] == 'c'

# Generated at 2022-06-23 13:58:56.683369
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABCSingletonChild(GlobalCLIArgs, object, metaclass=_ABCSingleton):
        def __init__(self, *args, **kwargs):
            super(type(self), self).__init__(*args, **kwargs)

    one = _ABCSingletonChild()
    two = _ABCSingletonChild()

    assert one is two

    # Make sure we can still get access to the __init__ for a class that inherits from this class.
    three = _ABCSingletonChild({'one': 1, 'two': 2})
    assert three.one == 1
    assert three.two == 2

# Generated at 2022-06-23 13:58:59.840233
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs({'foo': 'bar'})
    assert isinstance(global_cli_args, dict)

# Generated at 2022-06-23 13:59:03.442411
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    try:
        foo = GlobalCLIArgs()
        assert False
    except TypeError as e:
        assert "Can't instantiate abstract class GlobalCLIArgs with abstract methods" in str(e)

# Generated at 2022-06-23 13:59:12.573177
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with normal parameter
    args = CLIArgs({"a": "b"})
    # Test if the property of ImmutableDict is used
    assert args.a == args[b'a']

    try:
        args['a'] = "c"
    except:
        assert True
    else:
        assert False
    # Test with nested container
    args = CLIArgs({"a": {"b": "c"}})
    assert args.a.b == args[b'a'][b'b']

    try:
        args['a']['b'] = "c"
    except:
        assert True
    else:
        assert False

    # Test with list
    args = CLIArgs({"a": ["b", 1, {"c": "d"}]})

# Generated at 2022-06-23 13:59:21.960135
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert isinstance(CLIArgs({1: 2}), Container)
    assert isinstance(CLIArgs({1: 2}), Mapping)
    assert isinstance(CLIArgs({1: 2}), CLIArgs)
    assert isinstance(CLIArgs({1: 2}), ImmutableDict)
    toplevel = {1: 2}
    for key, value in toplevel.items():
        assert key == 1
        assert value == 2
    assert isinstance(CLIArgs.from_options({1: 2}), Container)
    assert isinstance(CLIArgs.from_options({1: 2}), Mapping)
    assert isinstance(CLIArgs.from_options({1: 2}), CLIArgs)
    assert isinstance(CLIArgs.from_options({1: 2}), ImmutableDict)
   

# Generated at 2022-06-23 13:59:29.415603
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import unittest
    class TestGlobalCLIArgs(unittest.TestCase):
        def test_immutability(self):
            from ansible.module_utils.common.collections import ImmutableDict
            from ansible.module_utils.common.args import GlobalCLIArgs
            g = GlobalCLIArgs.from_options(object())
            self.assertRaises(TypeError, g.__setitem__, 'key', 'value')
            self.assertRaises(AttributeError, setattr, g, 'key', 'value')
            self.assertRaises(AttributeError, setattr, g, 'items', 'value')
            self.assertRaises(AttributeError, setattr, g, 'iteritems', 'value')
            self.assertRaises(AttributeError, setattr, g, 'values', 'value')
           

# Generated at 2022-06-23 13:59:38.574939
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.vars import AnsibleVars
    from ansible.module_utils.six.moves import configparser
    import sys
    import tempfile
    import pytest

    config = configparser.ConfigParser()
    config.add_section('ssh_connection')
    config.set('ssh_connection', 'ssh_args', '-p 123')
    config.set('ssh_connection', 'pipelining', 'True')

    temp_file = tempfile.NamedTemporaryFile()
    config.write(temp_file)
    temp_file.flush()


# Generated at 2022-06-23 13:59:50.238963
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    foo = {}
    foo['bar'] = {}
    foo['bar']['baz'] = [1, 2, 3, 4, 5]
    foo['bar']['baz'][2] = [6, 7, 8, 9]
    foo['bar']['baz'][2][2] = [10, 11, 12, 13]
    foo['bar']['baz'][2][2][2] = [14, 15, 16, 17]
    foo['bar']['baz'][2][2][2][2] = "spam"

    args = CLIArgs(foo)
    assert isinstance(args, ImmutableDict)
    assert isinstance(args['bar'], ImmutableDict)
    assert isinstance(args['bar']['baz'], tuple)
    assert isinstance

# Generated at 2022-06-23 13:59:53.102659
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    with pytest.raises(TypeError):
        # do not allow direct instantiation of GlobalCLIArgs
        cli = GlobalCLIArgs({})

# Generated at 2022-06-23 14:00:01.679349
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Unit test for the class _ABCSingleton"""
    def assert_type_error(subclass):
        """Assert the subclass raises a type error"""
        try:
            subclass()
        except TypeError as type_error:
            assert 'Can\'t instantiate' in str(type_error)
            return
        assert False, 'TypeError not raised'

    class TestSingleton(_ABCSingleton):
        """Simple non-metaclass test"""

    class TestABCMeta(ABCMeta):
        """Simple non-singleton test"""

    # Singleton can instantiate
    assert isinstance(TestSingleton(), TestSingleton)

    # ABCMeta classes can instantiate
    assert isinstance(TestABCMeta(), TestABCMeta)

    # ABCMeta classes can't instantiate subclasses that have ABCMeta as a base class
    assert_type_error

# Generated at 2022-06-23 14:00:02.226408
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    pass

# Generated at 2022-06-23 14:00:06.193920
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    opt = MockOptions()
    global_args = GlobalCLIArgs.from_options(opt)
    assert global_args == opt.__dict__
    assert opt.__dict__ == GlobalCLIArgs(vars(opt)).data


# Generated at 2022-06-23 14:00:14.634552
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import GlobalCLIArgs
    arg_dict = {
        'foo': 'bar',
        'num': 1,
        'list': [1, 2, 3],
        'dict': {'foo': 'bar'},
        'sortedset': sortedset([1, 2, 3]),
        'frozenset': frozenset([1, 2, 3]),
        'tuple': tuple([1, 2, 3]),
    }
    global_args = GlobalCLIArgs(arg_dict)
    for key, value in arg_dict.items():
        if key == 'tuple':
            # Converting list to tuple
            assert isinstance(global_args[key], tuple)

# Generated at 2022-06-23 14:00:17.232553
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class test1(metaclass=_ABCSingleton):
        pass

    class test2(test1):
        pass

# Generated at 2022-06-23 14:00:28.431322
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Verify no ambiguity between mro of Singleton and ABCMeta
    class Foo(Singleton, ABCMeta):
        pass

    # Verify there is no ambiguity between mro of _ABCSingleton and ABCMeta
    class Foo(_ABCSingleton, ABCMeta):
        pass

    class Bar(_ABCSingleton):
        pass

    class Baz(_ABCSingleton):
        pass

    class Spam(_ABCSingleton):
        pass

    # Verify Singelton is an instance of _ABCSingleton
    assert isinstance(Singleton, _ABCSingleton)

    # Verify GlobalCLIArgs is an instance of _ABCSingleton
    assert isinstance(GlobalCLIArgs, _ABCSingleton)

    # Altering Spam to be like Singleton and ABCMeta to verify that the order of the mro is preserved
    # so there is no ambiguity between Singleton and ABC

# Generated at 2022-06-23 14:00:30.702010
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()

# Generated at 2022-06-23 14:00:38.223118
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(CLIArgs, Singleton)
    assert isinstance(GlobalCLIArgs, Singleton)
    assert isinstance(GlobalCLIArgs, ABCMeta)
    assert GlobalCLIArgs._abc_cache is not None
    assert GlobalCLIArgs._abc_negative_cache is not None
    assert GlobalCLIArgs._abc_negative_cache_version is not None
    assert GlobalCLIArgs._abc_registry is not None

# Generated at 2022-06-23 14:00:46.346772
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.parsing.vault import VaultLib

    vault_id = 'test_id'
    vault_secret = VaultLib.gen_secret()

    vault_secrets = {vault_id: vault_secret}

    args = GlobalCLIArgs({})
    assert(args is not None)
    assert(len(args) == 0)

    args = GlobalCLIArgs({'vault_pass': 'fake_pass'})
    assert(args is not None)
    assert(len(args) == 1)
    assert(args.get('vault_pass') == 'fake_pass')

    args = GlobalCLIArgs({'vault_secrets': vault_secrets})
    assert(args is not None)
    assert(len(args) == 1)

# Generated at 2022-06-23 14:00:50.982257
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    try:
        CLIArgs(dict(foo='bar', baz='qux'))
    except NotImplementedError:
        pass
    else:
        raise AssertionError('CLIArgs constructor should convert dicts to ImmutableDict')



# Generated at 2022-06-23 14:00:51.951202
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    pass



# Generated at 2022-06-23 14:01:01.432739
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-23 14:01:04.520670
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class test_abc(metaclass=_ABCSingleton):
        pass

    class test_abc2(test_abc):
        pass

    class test_abc3(test_abc):
        pass

# Generated at 2022-06-23 14:01:08.062677
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # The root namespace of the program will already have an instance of this, so we can't test
    # that the constructor works.  So we make up a random class and get it to make an instance for
    # us.
    class DummyClass(object):
        __metaclass__ = _ABCSingleton
        pass

    assert isinstance(DummyClass(), DummyClass)

# Generated at 2022-06-23 14:01:20.426887
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping_input = {
        'some_bool': True,
        'some_str': 'str value',
        'some_int': 42,
        'some_list': ['one', 'two', 'three'],
        'some_dict': {
            'key1': 'value1',
            'key2': 'value2',
            'key3': 'value3',
        }
    }
    mapping_output = {
        'some_bool': True,
        'some_str': 'str value',
        'some_int': 42,
        'some_list': ('one', 'two', 'three'),
        'some_dict': ImmutableDict({
            'key1': 'value1',
            'key2': 'value2',
            'key3': 'value3',
        })
    }
    args

# Generated at 2022-06-23 14:01:29.853140
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'key':'value', 'list':[1,1,2,3,3,3,4], 'key2':'list', 'tuple':(1,2,3,'string'), 'dict':{'key':'value'}, 'set':frozenset([1,1,1,2,2,2,3,3,3,4,5,6]), 'frozen_set':frozenset([1,1,1,2,2,2,3,3,3,4,5,6]), 'text':text_type('some text'), 'binary':binary_type('some bytes')}
    test_object = CLIArgs(test_dict)
    assert isinstance(test_object, ImmutableDict)
    assert isinstance(test_object['dict'], ImmutableDict)

# Generated at 2022-06-23 14:01:32.780868
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest

    try:
        GlobalCLIArgs()
        pytest.fail('Should not be able to create a GlobalCLIArgs object')
    except TypeError:
        pass

# Generated at 2022-06-23 14:01:36.978811
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    args = parser.parse_args()
    args_dict = vars(args)
    cli_args = CLIArgs(args_dict)
    assert len(args_dict) == len(cli_args)
    assert len(cli_args) == 0

# Generated at 2022-06-23 14:01:40.649936
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton):
        pass
    foo = Foo()
    assert isinstance(foo, Foo)
    assert issubclass(Foo, ABCMeta)
    assert issubclass(Foo, Singleton)

# Generated at 2022-06-23 14:01:45.536738
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 1, 'b': 2, 'c': 'test', 'd': {'inner': 'dict'}}
    cli_args = CLIArgs(test_dict)
    assert cli_args == test_dict


# Generated at 2022-06-23 14:01:54.704744
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABCSingletonTest(_ABCSingleton):
        """
        class to use for testing class _ABCSingleton
        """

    class _ABCSingletonTestSubclass(_ABCSingletonTest):
        """
        class to use for testing class _ABCSingleton
        """
        pass

    class NormalClass(object):
        """
        class to use for testing class _ABCSingleton
        """
        pass

    class NormalSubclass(NormalClass):
        """
        class to use for testing class _ABCSingleton
        """
        pass

    # Make sure class _ABCSingletonTest and its subclass _ABCSingletonTestSubclass are both singletons
    # and have the correct types
    assert _ABCSingletonTest() is _ABCSingletonTest()
    assert _ABCSingletonTestSubclass() is _ABCSingletonTestSubclass()
   

# Generated at 2022-06-23 14:01:57.561067
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    foo = GlobalCLIArgs({'a':1, 'b': {'c': 2, 'd': {'e': 3}}})
    bar = GlobalCLIArgs({'a':1, 'b': {'c': 2, 'd': {'e': 4}}})
    assert foo == bar

# Generated at 2022-06-23 14:02:01.311236
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class TestArgs(GlobalCLIArgs):
        def __init__(self, mapping):
            super(TestArgs, self).__init__(mapping)

    args = TestArgs(dict(quiet=True))
    assert args.quiet is True, "Failed to load value"

# Generated at 2022-06-23 14:02:07.616168
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    data = {'a': 'b', 'c': {'d': 'e'}, 'f': ['g', 'h']}
    immutable_data = CLIArgs(data)
    for key, value in data.items():
        assert value == immutable_data[key]
    assert immutable_data['a'] == 'b'
    assert immutable_data['c']['d'] == 'e'
    assert immutable_data['f'][0] == 'g'
    assert immutable_data['f'][1] == 'h'

# Generated at 2022-06-23 14:02:18.372046
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    a = CLIArgs({'a': 1,
                 'b': {'c': 2, 'd': [3, 4], 'e': {'f': [5, 6]}},
                 'g': [7, 8],
                 'h': [{'i': 9}]})
    assert a['a'] == 1
    assert a['b']['c'] == 2
    assert a['b']['d'][0] == 3
    assert a['b']['e']['f'][0] == 5
    assert a['g'][0] == 7
    assert a['h'][0]['i'] == 9

    # Make sure dict can't be added to
    try:
        a['b']['c'] = 12
    except TypeError:
        assert True
    else:
        assert False

   

# Generated at 2022-06-23 14:02:30.254849
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    This is basically a sanity check that the metaclass works as intended.
    """
    # pylint: disable=too-few-public-methods,too-many-instance-attributes
    # pylint: disable=abstract-method
    class TestABC(object):
        """
        A simple test class to make sure the metaclass works as expected.
        """
        __metaclass__ = _ABCSingleton

        def __init__(self, data):
            self.data = data
            self.initial_value = data
            # pylint: disable=anomalous-backslash-in-string
            self.unicode_string = u'\u1234'
            self.byte_string = b'\x12\x34'

# Generated at 2022-06-23 14:02:40.490048
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.basic import AnsibleModule
    import types

    class Options(object):
        def __init__(self):
            self.option1 = 1
            self.option2 = ''
            self.option3 = None

    options = Options()
    changed_options = CLIArgs.from_options(options)

    assert changed_options['option1'] == 1
    assert changed_options['option2'] == ''
    assert changed_options['option3'] is None

    options = Options()
    options.option1 = types.SimpleNamespace()
    options.option1.value = 1
    options.option2 = ''
    options.option3 = None
    changed_options = CLIArgs.from_options(options)

    assert changed_options['option1'].value == 1
    assert changed_options['option2']

# Generated at 2022-06-23 14:02:42.530421
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _SingletonExample(_ABCSingleton):
        pass

    assert isinstance(_SingletonExample(), _SingletonExample)

# Generated at 2022-06-23 14:02:46.305808
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        def __init__(self, **kwargs):
            self.__dict__.update({k: v for k, v in kwargs.items()})
    options = Options(foo='bar')
    args = GlobalCLIArgs.from_options(options)
    assert args.get('foo') == 'bar'

# Generated at 2022-06-23 14:02:48.299010
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs.from_options(GlobalCLIArgs())
    assert args

# Generated at 2022-06-23 14:02:51.754989
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(metaclass=_ABCSingleton):
        pass

    assert A() is A()
    assert A() is not B()

# Generated at 2022-06-23 14:02:54.972816
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(metaclass=_ABCSingleton):
        pass

    assert Foo is Foo()
    assert Foo is Foo()
    assert Foo() is Foo()

# Generated at 2022-06-23 14:02:58.656304
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _TestSingleton(_ABCSingleton):

        pass

    x = _TestSingleton()
    y = _TestSingleton()
    z = _TestSingleton()
    assert x == y == z



# Generated at 2022-06-23 14:03:00.871357
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    a = A()
    b = A()
    assert a is b

# Generated at 2022-06-23 14:03:04.120758
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    params = CLIArgs(dict(key='value'))
    assert isinstance(params, GlobalCLIArgs)
    assert isinstance(params, ImmutableDict)



# Generated at 2022-06-23 14:03:12.341290
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test constructor
    options = {}
    options['list'] = ['a', 'b', 'c']
    options['boolean'] = False
    options['number'] = 10
    options['string'] = 'test string'
    options['string_list'] = ['a', 'b', 'c']
    options['dict'] = {'key10': 'value10', 'key20': 'value20'}

    cli_args = CLIArgs.from_options(options)
    assert isinstance(cli_args, CLIArgs)
    assert isinstance(cli_args['list'], tuple)
    assert isinstance(cli_args['string_list'], tuple)
    assert isinstance(cli_args['dict'], ImmutableDict)

    # Test Type Checking
    expected_type_exception = None

# Generated at 2022-06-23 14:03:18.715119
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # input is a list of tuples that contains command line options
    data = (
        ('--inventory', 'inventory/'),
        ('--connection', 'local'),
        ('--module-path', 'lib/ansible/modules/extras:lib/ansible/modules/'),
        ('--extra-vars', '"hosts=host1,host2"'),
        ('--check', 'True'),
        ('--diff', 'True'),
        ('--list-hosts', 'True'),
        ('--list-tasks', 'True'),
        ('--list-tags', 'True'),
        ('--syntax-check', 'True')
    )

    # create CLIArgs object with the given data
    cli = CLIArgs.from_options(data)
    # this test is to check if the resulting object is immutable

# Generated at 2022-06-23 14:03:26.907292
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    # Use these as immutable objects can't be constructed from mutable ones
    mutable_dict = {'a': 1, 'b': {'c': 2, 'd': [3, 4, 5]}, 'c': (1, 2)}
    mutable_dict_copy = {'a': 1, 'b': {'c': 2, 'd': [3, 4, 5]}, 'c': (1, 2)}

    cli_args = CLIArgs(mutable_dict)

    assert cli_args == mutable_dict_copy
    assert isinstance(cli_args.b, ImmutableDict)
    assert cli_args.b == mutable_dict_copy['b']
    assert isinstance(cli_args['b'], ImmutableDict)
    assert cli_args['b'] == mutable_dict_copy

# Generated at 2022-06-23 14:03:31.656782
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({'a': 'A', 'b': {'b1': 1, 'b2': {'b21': 21, 'b22': 22}}})
    assert isinstance(args, ImmutableDict)
    assert args == ImmutableDict({'a': 'A', 'b': ImmutableDict({'b1': 1, 'b2': ImmutableDict({'b21': 21, 'b22': 22})})})

# Generated at 2022-06-23 14:03:43.346135
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # test for values
    value = 'my_value'
    # test for keys
    key = 'my_key'
    # test dictionary
    dictionary = {key: value}
    # test for text type
    text_value = 'my_text_value'
    # values for list
    list_values = ['my_first_value', 'my_second_value', 'my_last_value']
    # test for tuple
    tuple_value = tuple(list_values)
    # test for set
    set_value = set(list_values)
    # test for Sequence
    seq_value = list(list_values)
    # test for MutableMapping
    mutable_mapping = {'dict_key': 'dict_value'}
    # test for MutableSet

# Generated at 2022-06-23 14:03:46.623035
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert not hasattr(CLIArgs, '_ImmutableDict__changes') # this indicates that we're immutable
    assert CLIArgs is not ImmutableDict
    assert CLIArgs == ImmutableDict



# Generated at 2022-06-23 14:03:50.592534
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class DummyClass(object):
        __metaclass__ = _ABCSingleton
    e1 = DummyClass()
    e2 = DummyClass()
    # Make sure that there is no error
    assert e1 is e2

# Generated at 2022-06-23 14:03:52.310934
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cliargs = CLIArgs.from_options(dict())
    assert cliargs



# Generated at 2022-06-23 14:04:04.089283
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    special_dict = {
        'none_value': None,
        'string_value': 'string_value',
        'iterable_value': ['item1', 'item2'],
        'mapping_value': {'key1': 'value1'},
        'nested_dict': {
            'nested_string': 'nested_string',
            'nested_iterable': ['nested_item1', 'nested_item2'],
            'nested_mapping': {
                'nested_key1': 'nested_value1',
            },
        },

    }
    cli_args = CLIArgs(special_dict)
    assert cli_args['none_value'] is None
    assert cli_args['string_value'] == 'string_value'