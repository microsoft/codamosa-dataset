

# Generated at 2022-06-23 13:54:05.906911
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class A(metaclass=_ABCSingleton):
        pass

    class B(A):
        pass

    class C(A):
        pass

    assert A() is A()
    assert isinstance(A(), A)
    assert isinstance(B(), A)
    assert A() is not B()
    assert B() is not C()

# Generated at 2022-06-23 13:54:14.338546
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # pylint: disable=protected-access
    test_dict = {'a': 'a', 'b': ['b', [1, 2], {'c': 'c'}], 'd': {'e': [3, 4]}}
    test_immutable_dict = _make_immutable(test_dict)
    cli_args = CLIArgs(test_dict)
    assert cli_args == test_immutable_dict
    assert cli_args._mapping == test_immutable_dict
    assert cli_args._data == test_immutable_dict
    assert isinstance(cli_args._mapping, ImmutableDict)
    assert isinstance(cli_args._data, ImmutableDict)

# Generated at 2022-06-23 13:54:24.177834
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import os
    argv = ['ansible-playbook', 'some_name', '-i', 'some_inventory', '-c', 'some_connection', '-v', '-v', '--extra-vars', '"{"some_key": "some_value"}"']

    from ansible.parsing.dataloader import DataLoader
    from ansible.cli.arguments import optparser
    from ansible.utils.vars import load_extra_vars

    # Do the parsing
    options, args = optparser.parse_args(argv)

    # Fill in some structural information which optparse does not fill for us
    options.inventory = 'some_inventory'
    options.connection = 'some_connection'

    # Convert options into a dict so we can make it immutable
    options = vars(options)

   

# Generated at 2022-06-23 13:54:26.172224
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton):
        pass
    class Bar(Foo, object):
        pass
    assert Foo() is Foo()
    assert Bar() is Bar()

# Generated at 2022-06-23 13:54:28.774436
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Ensure the _ABCSingleton class works as expected"""
    class test_abc_meta(metaclass=_ABCSingleton):
        """Example class to test the metaclass with"""
        pass

    assert isinstance(test_abc_meta, _ABCSingleton)



# Generated at 2022-06-23 13:54:38.814909
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import tempfile
    import argparse
    # Setup command line arguments
    parser = argparse.ArgumentParser(description='description')
    parser.add_argument('-a', action="store_true")
    parser.add_argument('-b', action="store_false")
    parser.add_argument('-c', action="count")
    parser.add_argument('-d', type=int)
    parser.add_argument('-e', nargs="+")
    parser.add_argument('-f', nargs="+", type=int)

# Generated at 2022-06-23 13:54:46.364748
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.path import get_module_path
    from ansible.tox.reproduce import get_args
    from ansible.cli import CLI
    cli = CLI(None)
    options, args = cli.parse()
    cliargs = CLIArgs.from_options(options)
    assert args == cliargs['args']
    assert options.vault_password_file == cliargs.get('vault_password_file')
    assert options.module_path == cliargs.get('module_path')
    assert get_args() == cliargs

# Generated at 2022-06-23 13:54:52.107729
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common._collections_compat import (MutableMapping)
    from ansible.module_utils.common.collections import MutableSequence

    # One level deep
    obj = CLIArgs({
        "int": 3,
        "string": "four",
        "bool": True,
        "list": ["one", "two", "three"],
        "dict": {
            "one": "two",
            "three": "four",
        },
    })

    assert isinstance(obj, Mapping)
    assert obj.int == 3
    assert obj.string == "four"
    assert obj.bool
    assert isinstance(obj.list, Sequence)
    assert isinstance(obj.dict, Mapping)

    # Two levels deep

# Generated at 2022-06-23 13:54:59.874381
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable

    x = {'a': 1, 'b': {'c': [1, 2, 3]}}
    y = CLIArgs(x)
    assert isinstance(y, CLIArgs)
    assert is_immutable(y)
    assert is_immutable(y['b'])
    assert is_immutable(y['b']['c'])
    assert y['a'] == 1
    assert y['b']['c'][0] == 1

# Generated at 2022-06-23 13:55:08.675413
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli import CLI
    from ansible.utils.display import Display
    from ansible import context

    args = CLI.base_parser(
        usage="%prog [options]",
        connect_opts=True,
        meta_opts=True,
        runas_opts=True,
        subset_opts=True,
        check_opts=True,
        runtask_opts=True,
        vault_opts=True,
        fork_opts=True,
        module_opts=True,
        desc="Ansible Ad-Hoc Utility")
    (options, args) = CLI.parse(args)
    display = Display()
    context.CLIARGS = CLIArgs.from_options(options)
    assert context.CLIARGS == GlobalCLIArgs()

# Generated at 2022-06-23 13:55:20.194274
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    import pytest

    class TestA(metaclass=_ABCSingleton):
        def __init__(self, key, value):
            self.a = {key: value}

    class TestB(metaclass=_ABCSingleton):
        def __init__(self, key, value):
            self.b = {key: value}

    a1 = TestA('key', 'value')
    b1 = TestB('key', 'value')
    assert a1 == b1
    pytest.raises(TypeError, TestA, 'key', 'value')
    pytest.raises(TypeError, TestB, 'key', 'value')
    assert a1.__class__.__name__ == 'ABCMeta'
    assert b1.__class__.__name__ == 'ABCMeta'
    pytest.raises

# Generated at 2022-06-23 13:55:24.660173
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a':'b', 'c':'d'}
    cli_args = CLIArgs(test_dict)
    assert cli_args == test_dict
    assert cli_args is not test_dict


# Generated at 2022-06-23 13:55:29.575872
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABCSingleton(_ABCSingleton):
        pass

    class TestABCSingleton2(_ABCSingleton):
        pass

    assert TestABCSingleton == TestABCSingleton2
    assert id(TestABCSingleton) == id(TestABCSingleton2)

# Generated at 2022-06-23 13:55:34.126353
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    This method is a unit test for the class GlobalCLIArgs.
    """
    # Verify that duplicate GlobalCLIArgs instances are the same
    cli_args = GlobalCLIArgs({'foo': 'bar', 'baz': 7})
    assert cli_args is GlobalCLIArgs({'foo': 'bar', 'baz': 7})

# Generated at 2022-06-23 13:55:42.594671
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    class Options:
        test_var = 'test'

    args = CLIArgs.from_options(Options())
    assert isinstance(args, CLIArgs)
    assert isinstance(args, ImmutableDict)
    assert args['test_var'] == 'test'

    try:
        args['new_key'] = 'new_value'
    except TypeError:
        assert True
    else:
        assert False, 'Expected TypeError was not thrown'

    try:
        args['test_var'] = 'changed_value'
    except TypeError:
        assert True
    else:
        assert False, 'Expected TypeError was not thrown'

    assert len(args) == 1
    assert 'test_var' in args

# Generated at 2022-06-23 13:55:46.681626
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs({"a": {"b": ["c"]}})
    assert cli_args["a"]["b"][0] == "c"
    cli_args["a"]["b"][0] = "d"

# Generated at 2022-06-23 13:55:56.372616
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton(object):
        __metaclass__ = _ABCSingleton

        def get_singleton(self):
            return self

    class TestSingletonDerived(TestSingleton):
        pass

    # No questions asked, the singleton's class should be the same as the class of the instance
    assert TestSingleton().__class__ == TestSingleton
    assert TestSingleton().get_singleton().__class__ == TestSingleton

    # The derived class's class should not be the parent class
    assert TestSingletonDerived().__class__ == TestSingletonDerived
    assert TestSingletonDerived().get_singleton().__class__ == TestSingletonDerived

    # But they should all be instances of their parent class
    assert isinstance(TestSingletonDerived(), TestSingleton)

# Generated at 2022-06-23 13:56:06.485276
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # pylint: disable=unused-variable
    class Options(object):
        def __init__(self, **args):
            self.__dict__.update(args)
        def __iter__(self):
            return iter(self.__dict__)
        def __repr__(self):
            return repr(self.__dict__)
        def __getitem__(self, key):
            return getattr(self, key)

    # pylint: disable=assignment-from-no-return

# Generated at 2022-06-23 13:56:11.065623
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class T(_ABCSingleton, object):
        pass
    assert issubclass(T, Singleton)
    assert issubclass(T, ABCMeta)

    class T(_ABCSingleton, object, metaclass=ABCMeta):
        pass
    assert issubclass(T, Singleton)
    assert issubclass(T, ABCMeta)

# Generated at 2022-06-23 13:56:15.121146
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        option1 = 'value1'

    options = Options()

    cliargs = CLIArgs.from_options(options)

    assert cliargs.get('option1') == options.option1


# Generated at 2022-06-23 13:56:23.174995
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {"connection": "local", "module_path": "/somewhere"}
    cli_args = CLIArgs(args)
    assert cli_args.get("connection") == "local"
    assert cli_args.get("module_path") == "/somewhere"

    # Make sure it is immutable
    assert isinstance(cli_args, ImmutableDict)
    try:
        cli_args["connection"] = "ssh"
        assert False, "ImmutableDict.__setitem__ did not throw exception"
    except TypeError:
        pass


# Generated at 2022-06-23 13:56:25.320257
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs({})
    assert cli_args == {}

# Generated at 2022-06-23 13:56:34.691810
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.cli import CLI
    from ansible.config.manager import ConfigManager
    from ansible.module_utils.common.collections import ImmutableDict
    import os
    import tempfile
    import shutil
    _temp_dir = None

    _temp_dir = tempfile.mkdtemp(prefix='ansible_test_cli_args_')

    # Make a custom, working config file to read
    config_file_path = os.path.join(_temp_dir, 'ansible.cfg')

# Generated at 2022-06-23 13:56:44.224413
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs(None) == {}
    assert CLIArgs({'abc': [1, 2, 3]}) == {'abc': (1, 2, 3)}
    assert CLIArgs({'abc': [1, 2, {'def': 4}]}) == {'abc': (1, 2, {'def': 4})}
    assert CLIArgs({'abc': [1, 2, {'def': 4}]}) == {'abc': (1, 2, {'def': 4})}
    assert CLIArgs({'abc': {'def': {'ghi': 5}}}) == {'abc': {'def': {'ghi': 5}}}

# Generated at 2022-06-23 13:56:47.324482
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs(dict(a=1, b=2))

    assert global_cli_args is GlobalCLIArgs()
    assert global_cli_args['a'] == 1
    assert global_cli_args['b'] == 2

# Generated at 2022-06-23 13:56:55.904262
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs(ImmutableDict({
        'x': 1,
        'y': 'string',
        'z': ['X', 'Y', 'Z', 1, 2, 3],
        'a': {
            'aa': [1,2,3],
            'ab': 'test',
        }
    }))

    assert isinstance(args['x'], int)
    assert isinstance(args['y'], text_type)
    assert isinstance(args['z'], tuple)
    assert isinstance(args['a'], ImmutableDict)

# Generated at 2022-06-23 13:57:04.950506
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.module_utils.common.argparse import MockArgumentParser

    parser = MockArgumentParser(description="Test GlobalCLIArgs")

    with pytest.raises(TypeError) as excinfo:
        GlobalCLIArgs(parser.add_mutually_exclusive_group())
    assert "a mapping" in str(excinfo.value)

    GlobalCLIArgs(dict())
    with pytest.raises(TypeError) as excinfo:
        GlobalCLIArgs(dict())
    assert "Cannot re-initialize" in str(excinfo.value)

# Generated at 2022-06-23 13:57:15.314638
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {'test': {'test1': 5, 'test2': 'test', 'test3': [1,2,3]}, 'test2': {'test4': [4,5,6,7]}}
    cli_args = CLIArgs(args)
    assert cli_args['test']['test1'] == 5
    assert cli_args['test']['test2'] == 'test'
    assert cli_args['test']['test3'] == (1,2,3)
    assert cli_args['test2']['test4'] == (4,5,6,7)
    assert cli_args['test']['test4'] == {} # key not present
    assert cli_args['test3'] == {} # key not present

# Generated at 2022-06-23 13:57:21.138553
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'foo': [(1, 2), 3], 'bar': 'baz'})
    # These attributes should all be ImmutableDict
    assert isinstance(args, ImmutableDict)
    assert isinstance(args['foo'], tuple)
    assert isinstance(args['foo'][0], tuple)
    # This attribute should be a string
    assert isinstance(args['bar'], text_type)



# Generated at 2022-06-23 13:57:24.908595
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Initialize GlobalCLIArgs
    GlobalCLIArgs({})
    # Check GlobalCLIArgs can be "pickled"
    import pickle
    p = pickle.dumps(GlobalCLIArgs({}))
    unpickled = pickle.loads(p)
    assert unpickled is GlobalCLIArgs({})

# Generated at 2022-06-23 13:57:34.038515
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.utils.display import Display

    display = Display()

    def fake_command_line(**kwargs):
        """
        Create and return a fake command line

        This is used for testing so we can fake out command line arguments.  It returns a class
        instance which looks like the "args" namespace object returned by the argument parser.
        """
        class FakeOptions:
            """Fake a namespace object for command line arguments"""
            pass
        for key, value in kwargs.items():
            setattr(FakeOptions, key, value)
        return FakeOptions

    def _print_fake_command_line(options):
        """
        Pretty print a fake command line arguments

        Used for debugging what a test is passing to fake_command_line
        """

# Generated at 2022-06-23 13:57:37.765356
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    a = A()
    b = A()
    assert a is b

# Generated at 2022-06-23 13:57:46.414745
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    The call to ImmutableDict in CLIArgs is actually an idempotent operation and this module
    doesn't have any duplicate keys in the data structure.  But it is very possible for the
    instantiation of CLIArgs to get a dictionary with duplicate keys from somewhere else and
    then that call to ImmutableDict would turn it into a set and lose data.  At least this test
    should catch that.  It's a pretty simple test though.
    """
    test_input = {'testcase': 1,
                  'testcase2': 2}

    test_args = CLIArgs(test_input)
    assert isinstance(test_args, CLIArgs)
    assert test_args['testcase'] == 1
    assert test_args['testcase2'] == 2

# Generated at 2022-06-23 13:57:54.426468
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('-i', '--inventory', dest='inventory_file')
    parser.add_argument('-f', '--forks', dest='forks')
    parser.add_argument('--config', dest='cfg_file')
    parser.add_argument('-o', '--once', dest='once')
    parser.add_argument('-C', '--connection')
    parser.add_argument('--ask-pass', dest='ask_pass')
    parser.add_argument('--ask-vault-pass', dest='ask_vault_pass')
    parser.add_argument('--vault-id', dest='vault_ids')
    parser.add_argument('--vault-password-file', dest='vault_password_files')


# Generated at 2022-06-23 13:58:00.862459
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        ansible_foo = 'bar'
        ansible_baz = [1, 2, 3]

    mapping = vars(Options())
    args = CLIArgs(mapping)

    assert args.ansible_foo == 'bar'
    assert args.ansible_baz == (1, 2, 3)

# Unit test to ensure that CLIArgs is not a singleton

# Generated at 2022-06-23 13:58:03.186480
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(Singleton):
        __metaclass__ = _ABCSingleton

    test = TestClass()
    assert test is TestClass()

# Generated at 2022-06-23 13:58:14.198248
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-23 13:58:18.971586
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 1, 'b': '2'}
    test_object = CLIArgs(test_dict)
    assert test_object['a'] == 1
    assert test_object['b'] == '2'
    assert test_object == test_dict
    test_object['a'] = 2
    assert test_object['a'] == 1

# Generated at 2022-06-23 13:58:21.795181
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {"a": [1, 2, 3], "b": {"c": "d"}}
    cli_args = CLIArgs(test_dict)

    assert isinstance(cli_args, ImmutableDict)


# Generated at 2022-06-23 13:58:24.682014
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    inp = dict(a=1)
    out = CLIArgs(inp)
    assert out == inp


# Generated at 2022-06-23 13:58:29.868605
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyABC(object):
        """Test metaclass composition of ABCMeta and Singleton"""
        __metaclass__ = _ABCSingleton

    class A(MyABC):
        pass

    class B(A):
        pass

    class C(B):
        pass

    A()
    B()
    C()

# Generated at 2022-06-23 13:58:34.025858
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # pylint: disable=unused-variable
    @add_metaclass(_ABCSingleton)
    class A(object):
        pass

    class B(object):
        __metaclass__ = _ABCSingleton

    # pylint: enable=unused-variable

# Generated at 2022-06-23 13:58:42.528493
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class FooSingleton(object):
        __metaclass__ = _ABCSingleton

    # Verify that we're using the metaclass
    assert issubclass(type(FooSingleton), _ABCSingleton)
    assert issubclass(FooSingleton, _ABCSingleton)

    # Ensure that FooSingleton is a concrete class
    assert not isinstance(FooSingleton, type)

    # Verify that we can instantiate FooSingleton
    assert not isinstance(FooSingleton(), FooSingleton)

    # Verify that ABCMeta doesn't allow FooSingleton to be instantiated
    assert issubclass(FooSingleton, _ABCSingleton)



# Generated at 2022-06-23 13:58:46.601738
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Call the constructor of _ABCSingleton
    """
    test_class = type('test_class', (_ABCSingleton, ), {})
    test_instance = test_class()
    assert test_instance is not None, "The constructor of _ABCSingleton is not called"

# Generated at 2022-06-23 13:58:50.402541
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = {'diff': True, 'connection': 'local'}
    GlobalCLIArgs(args)


# TODO: implement a Context class which can hold both GlobalCLIArgs and also some other data
#       The context should be able to pretend to be running with whichever CLI flags you want
#       This would allow us to perhaps simplify some modules and add some consistency too

# Generated at 2022-06-23 13:58:53.887803
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # verify that the constructor of GlobalCLIArgs will pass the unittest
    from ansible.config.manager import ConfigManager
    parser = ConfigManager(True).get_plugin_options('cli')
    (options, args) = parser.parse_args()
    inst = GlobalCLIArgs.from_options(options)
    # The constructor of GlobalCLIArgs will pass if this line is reached
    assert inst is not None

# Generated at 2022-06-23 13:59:03.781570
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes
    cliargs = CLIArgs({'list': ['foo', 'bar', 'baz'], 'boolean': True, 'int': 42, 'string': 'string'})
    assert isinstance(cliargs, ImmutableDict)
    assert cliargs['list'] == tuple(['foo', 'bar', 'baz'])
    assert cliargs['boolean'] is True
    assert cliargs['int'] is 42
    assert cliargs['string'] == to_bytes('string')

# Generated at 2022-06-23 13:59:08.069478
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = type('Options', (object,), dict(verbosity=3, private_key_file='/path/to/key'))()
    global_args = GlobalCLIArgs.from_options(options)
    assert global_args['verbosity'] == 3
    assert global_args['private_key_file'] == '/path/to/key'

# Generated at 2022-06-23 13:59:18.403512
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Create a real 'argparse.Namespace' object from real argparse code
    # 'argparse' is Python standard library, so name is always defined
    import argparse
    # At some point, we'll need to create a real command line so that
    # we can test the CLIArgs and GlobalCLIArgs classes with real arguments.
    # For now, just set up a fake object that looks like a real
    # 'argparse.Namespace' created by the argparse library.
    test_options = argparse.Namespace()
    test_options.host_key_checking = True
    test_options.check = True
    test_options.diff = True
    test_options.force_handlers = True
    test_options.flush_cache = True
    test_options.list_hosts = True

# Generated at 2022-06-23 13:59:26.700479
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test immutable dict
    test_dict = {"a": 1, "b": {"c": 2}}
    cli_args_list = CLIArgs(test_dict)
    assert isinstance(cli_args_list, ImmutableDict)
    # test mutability. If the dictionary is immutable, the assertion will cause error
    cli_args_list["a"] = "test"
    cli_args_list["b"]["c"] = "test"


# Generated at 2022-06-23 13:59:29.203593
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # pylint: disable=unused-variable
    # create a singleton instance of GlobalCLIArgs
    global_cli_args = GlobalCLIArgs({'a': 'b'})
    # create another singleton instance of GlobalCLIArgs
    global_cli_args = GlobalCLIArgs({'c': 'd'})

    # expect both singleton instances to be the same instance
    assert global_cli_args == GlobalCLIArgs({'c': 'd'})



# Generated at 2022-06-23 13:59:34.172557
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        pass

    class Test2(Test):
        pass

    assert Test() == Test()
    assert Test2() == Test2()

# Generated at 2022-06-23 13:59:39.796590
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_arg = GlobalCLIArgs({'a': 1, 'b': 2})
    assert test_arg['a'] == 1
    assert test_arg['b'] == 2

    try:
        test_arg_2 = GlobalCLIArgs({'a': 1, 'b': 2})
    except AttributeError:
        pass
    else:
        raise RuntimeError('GlobalCLIArgs should only be instantiated once')

if __name__ == '__main__':
    test_GlobalCLIArgs()

# Generated at 2022-06-23 13:59:50.951948
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingletonTest(_ABCSingleton):
        """Singleton to test _ABCSingleton"""
        pass

    # test that we can only have one SingletonTest
    SingletonTest()
    try:
        SingletonTest()
    except RuntimeError:
        pass
    else:
        assert False, "We should only be able to have one SingletonTest"

    # test that we can have multiple normal classes with the same name
    class NormalTest(object):
        """Normal class with the same name as SingletonTest"""
        pass
    _ = NormalTest()
    _ = NormalTest()

    # test that we can have multiple normal classes with the same name and a
    # different parent
    class NormalTest2(_ABCSingleton, object):
        """Normal class with the same name and different parent as SingletonTest"""
        pass
    _ = Normal

# Generated at 2022-06-23 13:59:53.431740
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingletonTestClass(metaclass=_ABCSingleton):
        pass

    assert SingletonTestClass() is SingletonTestClass()

# Generated at 2022-06-23 14:00:00.910249
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    foo = {'foo': {'bar': 'baz'}, 'abc': ['def', 'ghi', 'jkl']}
    cliargs = CLIArgs(foo)
    assert cliargs['foo']['bar'] == 'baz'
    assert cliargs['abc'][0] == 'def'
    assert cliargs['abc'][1] == 'ghi'
    assert cliargs['abc'][2] == 'jkl'
    foo['foo']['bar'] = 'changed'
    assert cliargs['foo']['bar'] == 'baz'

# Generated at 2022-06-23 14:00:03.258358
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Dummy(object):
        pass
    _ABCSingleton(Dummy.__name__, Dummy.__bases__, dict(Dummy.__dict__))

# Generated at 2022-06-23 14:00:07.112963
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({"one": 1, "two": 2})
    assert args["one"] == 1
    assert args["two"] == 2
    assert not args.args_to_datastructure


# Generated at 2022-06-23 14:00:09.332218
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    options = 'options'
    cli_args = CLIArgs.from_options(options)
    assert options == cli_args

# Generated at 2022-06-23 14:00:13.117463
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Check that we can make a new class which is a Singleton and an ABC
    """
    @add_metaclass(_ABCSingleton)
    class NewSingleton(Container):
        pass

    # Make sure we can create a new object
    instance1 = NewSingleton()
    instance2 = NewSingleton()

    assert instance1 is instance2

# Generated at 2022-06-23 14:00:15.985085
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _Example(_ABCSingleton):
        pass

    assert _Example() is _Example()

# Generated at 2022-06-23 14:00:27.198851
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    try:
        class_copy_1 = GlobalCLIArgs({'a': {'b': 'c'}})
        class_copy_2 = GlobalCLIArgs({'a': {'b': 'c', 'd': 'e'}})
        class_copy_2.a['f'] = 'g'
        class_copy_3 = GlobalCLIArgs({'a': {'b': 'c', 'd': 'e'}})
    except AttributeError as e:
        raise AssertionError("GlobalCLIArgs construction should not fail: %s" % to_text(e))

    if not isinstance(class_copy_1.a, ImmutableDict):
        raise AssertionError("GlobalCLIArgs constructor from dict should return ImmutableDict")

# Generated at 2022-06-23 14:00:30.635444
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        pass

    options = Options()

    options.connection = 'smart'
    options.module_path = None

    cli_args = GlobalCLIArgs.from_options(options)

    assert isinstance(cli_args, GlobalCLIArgs)
    assert cli_args['connection'] == 'smart'
    assert cli_args['module_path'] is None



# Generated at 2022-06-23 14:00:34.324540
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({})
    GlobalCLIArgs({'a': 1})
    GlobalCLIArgs({'a': 1, 'b': 2})



# Generated at 2022-06-23 14:00:43.675627
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABCSingleton(object):
        __metaclass__ = _ABCSingleton

    class TestABCSingletonSubclass(TestABCSingleton):
        pass

    class TestSingleton(object):
        __metaclass__ = Singleton

    class TestSingletonSubclass(TestSingleton):
        pass

    class TestABCMeta(object):
        __metaclass__ = ABCMeta

    class TestABCMetaSubclass(TestABCMeta):
        pass

    class TestSingletonSubclassOfABCMeta(TestABCMeta, TestSingleton):
        pass

    class TestABCSingletonSubclassOfABCMetaSubclass(TestABCMetaSubclass, TestABCSingleton):
        pass

# Generated at 2022-06-23 14:00:50.178429
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {"test_key1": [1], "test_key2": {"dict_key": "test_value"}}
    test_cli = CLIArgs(test_dict)
    assert isinstance(test_cli, ImmutableDict)
    assert test_cli["test_key1"] == (1,)
    assert test_cli["test_key2"]["dict_key"] == "test_value"

# Generated at 2022-06-23 14:00:59.706421
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class MyMappingClass(Mapping):
        def __init__(self):
            self.subdict = {'subkey1': 'subvalue1', 'subkey2': 'subvalue2'}
            self.sublist = ['sublistvalue1', 'sublistvalue2']
        def __getitem__(self, item):
            return {'subdict': self.subdict, 'sublist': self.sublist}[item]
        def __iter__(self):
            return iter(['subdict', 'sublist'])
        def __len__(self):
            return len(['subdict', 'sublist'])

# Generated at 2022-06-23 14:01:06.964319
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    class MockOptions:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

# Generated at 2022-06-23 14:01:12.363725
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class B:
        pass
    class A(metaclass=_ABCSingleton):
        pass
    assert isinstance(A(), A)
    assert not isinstance(B(), A)
    class C(metaclass=_ABCSingleton):
        pass
    assert not isinstance(C(), A)

# Generated at 2022-06-23 14:01:17.440148
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Unit test for constructor of class _ABCSingleton.

    Creates a class that inherits from both Singleton and ABCMeta.
    This is to ensure that this class is callable and does not raise an
    exception.
    """
    class TestABCSingleton(_ABCSingleton):
        pass

    assert TestABCSingleton is not None

# Generated at 2022-06-23 14:01:20.770224
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args1 = GlobalCLIArgs({'a': 1})
    args2 = GlobalCLIArgs({'a': 1})
    assert args1 is args2
    GlobalCLIArgs.reset()
    args3 = GlobalCLIArgs({'a': 1})
    args4 = GlobalCLIArgs({'a': 1})
    assert args3 is args4
    assert args1 is not args3

# Generated at 2022-06-23 14:01:22.966316
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    assert isinstance(A(), A)
    assert A() is A()

# Generated at 2022-06-23 14:01:31.388425
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs.instance = None

    arglist = [
        "ansible-playbook",
        "--extra-vars",
        "a=b",
        "--extra-vars",
        "c=d",
        "--extra-vars",
        "e=fghi",
        "--extra-vars",
        "j=k",
        "--extra-vars",
        "l=m"
    ]

# Generated at 2022-06-23 14:01:34.796548
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils.six import with_metaclass

    class test(with_metaclass(_ABCSingleton, object)):
        pass

    second = test()
    assert test() is second

# Generated at 2022-06-23 14:01:42.375668
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import ansible.cli
    from ansible.module_utils.six import StringIO
    from ansible.config.manager import ConfigManager, ConfigData, CLIConfigLoader, ConfigLoader

    # First create a temp config file with multiple pieces of information
    config_file1 = """
[defaults]
inventory = /etc/ansible/hosts
remote_tmp = $HOME/.ansible/tmp
local_tmp = $HOME/.ansible/tmp

[ssh_connection]
retries = 10
"""
    config_file2 = """
[defaults]
inventory = /etc/ansible/hosts
remote_tmp = $HOME/.ansible/tmp
local_tmp = $HOME/.ansible/tmp

[ssh_connection]
retries = 10
"""

    # Create a file like object for our config file
    output = String

# Generated at 2022-06-23 14:01:52.690254
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils.common.text.converters import to_text
    class TestDef(object, metaclass=_ABCSingleton):
        def __init__(self, foo, bar):
            self.foo = foo
            self.bar = bar
            super(TestDef, self).__init__()

        def __str__(self):
            return to_text('{} {}').format(self.foo, self.bar)

    i1 = TestDef('test1', 123)
    i2 = TestDef('test2', 456)

    assert TestDef is i1
    assert TestDef is i2
    assert TestDef is i1 is i2

    assert 'test2 456' == str(i1) == str(i2)

# Generated at 2022-06-23 14:01:56.596748
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict

    assert isinstance(CLIArgs(_make_immutable({'key': 'value'})), CLIArgs)



# Generated at 2022-06-23 14:01:59.229454
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingletonClass(_ABCSingleton):
        pass
    c1 = SingletonClass()
    c2 = SingletonClass()

    assert c1 is c2

# Generated at 2022-06-23 14:02:01.671849
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = ImmutableDict({'foo': 'bar'})
    args = GlobalCLIArgs(options)
    assert args == options

# Generated at 2022-06-23 14:02:11.406566
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import os
    import tempfile
    import unittest

    class TestCLIArgs(unittest.TestCase):
        """Unit test for CLIArgs"""

        def test_init(self):
            """Unit test to verify CLIArgs init"""
            test_dict = {
                'foo': 'bar',
                'baz': 'fud',
                'a': {
                    'b': {
                        'c': 'd'
                    },
                },
                'b': ['c', 'd', 'f'],
            }
            test_cliargs = CLIArgs(test_dict)
            self.assertDictEqual(test_dict, test_cliargs)

        def test_from_options(self):
            """Unit test to verify from_options()"""
            from ansible.cli.arguments import option_helpers



# Generated at 2022-06-23 14:02:14.374970
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = GlobalCLIArgs({'1': 1})
    assert isinstance(a, CLIArgs)
    assert a['1'] == 1


# Generated at 2022-06-23 14:02:21.763965
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that the constructor for class CLIArgs copies the values of any container into immutable
    versions.
    """

    # Make a simple mutable struct
    mutable_struct = {}
    mutable_struct['a'] = {'b': 'c'}
    mutable_struct['d'] = ['e', 'f', 'g']
    mutable_struct['h'] = 'i'

    # Create a CLIArgs instance and make sure the values are immutable
    temp = CLIArgs(mutable_struct)
    assert isinstance(temp['a'], ImmutableDict)
    assert isinstance(temp['d'], tuple)
    assert isinstance(temp['h'], text_type)

# Generated at 2022-06-23 14:02:33.064316
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import collections
    import mock
    import unittest2 as unittest

    class MockOptParse(object):
        def __init__(self, *_args, **_kwargs):
            self.MOCK_OPTIONS = collections.namedtuple('MockOptions', ['opt1', 'opt2', 'opt3'])
            self.MOCK_OPTIONS.opt1 = True
            self.MOCK_OPTIONS.opt2 = ['test1', 'test2']
            self.MOCK_OPTIONS.opt3 = ['test3', 'test4']


# Generated at 2022-06-23 14:02:35.180699
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    GlobalCLIArgs(None)

    GlobalCLIArgs(ImmutableDict())



# Generated at 2022-06-23 14:02:39.181987
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args_dict = {"foo": 1, "bar": [1, 2]}
    cli_args = GlobalCLIArgs(args_dict)
    assert cli_args == args_dict



# Generated at 2022-06-23 14:02:47.792399
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import GlobalCLIArgs
    import argparse
    parser = argparse.ArgumentParser(fromfile_prefix_chars='@')
    parser.add_argument('-p', '--password')
    parser.add_argument('-u', '--username')
    parser.add_argument('-t', '--timeout')
    parser.add_argument('--vault-password-file')
    parser.add_argument('-v', '--verbose')
    parser.add_argument('arg1')
    parser.add_argument('arg2')
    options = parser.parse_args(['-u', 'foo', '-p', 'bar', '-t', '120', '-v', 'arg1', 'arg2'])

# Generated at 2022-06-23 14:02:50.059440
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    temp = CLIArgs({"a": 100})
    assert temp["a"] == 100


# Generated at 2022-06-23 14:02:54.357854
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABCSingletonTest(_ABCSingleton):
        def __init__(self):
            pass

    assert _ABCSingletonTest() is _ABCSingletonTest()
    assert _ABCSingletonTest() is _ABCSingletonTest()

# Generated at 2022-06-23 14:03:05.151806
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class MyOptions(object):
        def __init__(self, **kwargs):
            for key, val in kwargs.items():
                setattr(self, key, val)


# Generated at 2022-06-23 14:03:09.626802
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs.register(dict(foo='bar'))
    assert GlobalCLIArgs().get('foo') == 'bar'
    # Check that we can't modify it
    try:
        GlobalCLIArgs().update(dict(foo='foo'))
    except AttributeError:
        assert True
    else:
        assert False
    GlobalCLIArgs.reset()

# Generated at 2022-06-23 14:03:10.841106
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class MyObject(_ABCSingleton):
        pass

    assert isinstance(MyObject(), MyObject)

# Generated at 2022-06-23 14:03:12.572273
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs.from_options({"a": 1})
    assert args == {"a": 1}

# Generated at 2022-06-23 14:03:21.740780
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        pass

        def __setattr__(self, option_name, value):
            self.__dict__[option_name] = value

    options = Options()
    options.b = "test_string"
    options.a = [{'a': 'test_string2'}, 'test_string3']

    args = GlobalCLIArgs.from_options(options)

    assert args['b'] == 'test_string'
    assert args['a'][1] == 'test_string3'
    assert not args['a'].__setattr__

# Generated at 2022-06-23 14:03:26.762392
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'one': 1, 'two': 2}
    args = CLIArgs(mapping)
    assert isinstance(args, ImmutableDict)
    assert args == ImmutableDict(mapping)
    assert isinstance(args['one'], int)


# Generated at 2022-06-23 14:03:36.489953
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = dict(key1=1, key2='2', key3=['a', 'b', 'c'], key4=dict(key5='5', key6=[1, 2, 3]))
    test_dict_copy = test_dict.copy()
    test_cliargs = CLIArgs(test_dict)
    assert test_dict is not test_cliargs
    assert isinstance(test_cliargs, CLIArgs)
    assert isinstance(test_cliargs, ImmutableDict)
    assert isinstance(test_cliargs, Mapping)
    for key, value in test_dict.items():
        assert key in test_cliargs
        assert value is not test_cliargs[key]
        assert value == test_cliargs[key]
    assert test_dict_copy == test_dict

# Generated at 2022-06-23 14:03:48.120551
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        pass
    class B(object, metaclass=_ABCSingleton):
        pass
    class C(A, metaclass=_ABCSingleton):
        pass
    class D(B, metaclass=_ABCSingleton):
        pass
    class E(A, B, metaclass=_ABCSingleton):
        pass
    class F(B, A, metaclass=_ABCSingleton):
        pass
    class G(C, A, metaclass=_ABCSingleton):
        pass
    class H(D, A, B, E, F, G, metaclass=_ABCSingleton):
        pass
    class I(A, B, C, D, E, F, G, H, metaclass=_ABCSingleton):
        pass

# Generated at 2022-06-23 14:03:54.564375
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # pylint: disable=unused-variable
    # pylint: disable=anomalous-backslash-in-string
    class Options(object):
        def __init__(self, testarg1, testarg2):
            self.testarg1 = testarg1
            self.testarg2 = testarg2
        def _get_kwargs(self):
            return vars(self)

    args = CLIArgs.from_options(Options("test1", "test2"))
    assert args.testarg1 == "test1"

# Generated at 2022-06-23 14:03:57.883532
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({'a': 1})
    assert isinstance(args, GlobalCLIArgs)


# Generated at 2022-06-23 14:04:06.560125
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    mapping = {'one': 1, 'two': 2, 'three': 'three', 'my_list': [1, 2, 3]}
    args = GlobalCLIArgs(mapping)
    assert type(args) == GlobalCLIArgs
    assert type(args['one']) == int
    assert type(args['two']) == int
    assert type(args['three']) == text_type
    assert type(args['my_list']) == tuple
    assert type(args['my_list'][0]) == int
    assert args['my_list'] != (1, 2, 3)
    assert args != mapping
    assert args._mapping != mapping
    assert args._mapping == {'one': 1, 'two': 2, 'three': 'three', 'my_list': (1, 2, 3)}