

# Generated at 2022-06-23 13:54:11.833720
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.six.moves import mock

    mock_options = mock.MagicMock()
    mock_options.config_file = '/path/to/cli_config'
    mock_options.module_path = '/path/to/module_path'
    mock_options.connection = 'local'

    mock_conf = mock.MagicMock()
    mock_conf.DEFAULT_BECOME_METHOD = 'sudo'
    mock_conf._load_name_based_options.return_value = {'connection': 'ssh'}


# Generated at 2022-06-23 13:54:14.502116
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestOne(object):
        __metaclass__ = _ABCSingleton
    class TestTwo(object):
        __metaclass__ = _ABCSingleton
    TestOne()
    TestTwo()

# Generated at 2022-06-23 13:54:24.313980
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        def __init__(self):
            self.foo = 'bar'
            self.baz = ['qux', 'quux', 'quuux']
            self.corge = {'grault': 'garply', 'waldo': 'fred'}
            self.xyzzy = {'thud': ['foo', 'bar', 'baz', 'qux']}

        def __getitem__(self, key):
            return getattr(self, key)

        def __contains__(self, key):
            return hasattr(self, key)

        def keys(self):
            return [key for key in dir(self) if not key.startswith('__')]

    opt = Options()
    cli_args = CLIArgs.from_options(opt)

# Generated at 2022-06-23 13:54:33.316339
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs(dict(a=1, b=2))
    assert repr(args) == "ImmutableDict({'a': 1, 'b': 2})"
    try:
        args["c"] = 3
        raise RuntimeError("Expected a TypeError")
    except TypeError:
        pass
    args = CLIArgs(dict(d={1: 2}))
    assert repr(args) == "ImmutableDict({'d': ImmutableDict({1: 2})})"
    try:
        args["d"][2] = 3
        raise RuntimeError("Expected a TypeError")
    except TypeError:
        pass



# Generated at 2022-06-23 13:54:39.841443
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Verify behaviour of class _ABCSingleton

    This test verifies that the metaclass lookup results in _ABCSingleton and that the Singleton
    behaviour still works when using _ABCSingleton
    """

    @add_metaclass(_ABCSingleton)
    class DummyClass:
        pass

    d1 = DummyClass()
    d2 = DummyClass()
    assert id(d1) == id(d2)
    assert isinstance(d1, DummyClass)
    assert isinstance(d2, DummyClass)

# Generated at 2022-06-23 13:54:42.360595
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABCSingleton(object):
        __metaclass__ = _ABCSingleton
    assert(isinstance(TestABCSingleton(), TestABCSingleton))

# Generated at 2022-06-23 13:54:48.273249
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.cli import CLI
    cli = CLI(args=None)
    options = cli.parse()
    args = GlobalCLIArgs.from_options(options)
    assert isinstance(args, GlobalCLIArgs)
    with pytest.raises(ValueError):
        # Updating GlobalCLIArgs is not allowed
        args["help"] = False
    with pytest.raises(ValueError):
        # Updating GlobalCLIArgs is not allowed
        args.update(dict(help=False))

# Generated at 2022-06-23 13:54:55.705028
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs.from_options(None)
    assert isinstance(args, Mapping)
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, CLIArgs)
    assert not isinstance(args, GlobalCLIArgs)
    args = CLIArgs.from_options(GlobalCLIArgs.from_options(None))
    assert isinstance(args, Mapping)
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, CLIArgs)
    assert not isinstance(args, GlobalCLIArgs)

# Generated at 2022-06-23 13:54:56.212923
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = GlobalCLIArgs.from_options(object())

# Generated at 2022-06-23 13:55:05.827378
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.cli.arguments import BaseCLIArguments as X
    from ansible.module_utils.common.collections import ImmutableDict as Y
    # Reference 'X' using the metaclass so that the metaclass' __call__
    # method is invoked.
    base_args = X()
    # We need to use the metaclass to create a new 'B' subclass of the
    # metaclass created '_ABCSingleton' with the same __call__ method as
    # 'X' and the same __new__ method as 'Y', and then reference 'B' using
    # the metaclass so that the metaclass' __call__ method is invoked.

# Generated at 2022-06-23 13:55:17.162114
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    input_dict = {
        'a': 0,
        'b': {
            'c': 0,
            'd': [
                0,
                {
                    'e': 0,
                    'f': [0, 1]
                }
            ]
        }
    }
    args = CLIArgs(input_dict)
    assert args == input_dict
    assert isinstance(args, ImmutableDict)
    assert isinstance(args.get('b'), ImmutableDict)
    assert isinstance(args.get('b').get('d')[1], ImmutableDict)
    assert isinstance(args.get('b').get('d')[1].get('f'), tuple)



# Generated at 2022-06-23 13:55:24.641996
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import unittest
    import argparse

    class TestCLIArgs(unittest.TestCase):
        def test_CLIArgs_constructor_normal(self):
            ''' Test normal instantiation of a CLIArgs object. '''
            test_parser = argparse.ArgumentParser()
            test_parser.add_argument("--foo")
            test_parser.add_argument("--bar")
            test_parser.add_argument("--baz")

            test_args = test_parser.parse_args([])
            cli_args = CLIArgs.from_options(test_args)

            self.assertEqual(cli_args, {'bar': None, 'foo': None, 'baz': None})


# Generated at 2022-06-23 13:55:35.218461
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # test toplevel changes
    args = CLIArgs(dict(a=1, b=2))
    assert args == ImmutableDict({'a': 1, 'b': 2})
    args2 = CLIArgs.from_options(args)
    assert args == args2

    args3 = CLIArgs(dict(c=3))
    assert args3 == ImmutableDict({'c': 3})
    # this is a bit of a strange test.  It is ensuring that the objects aren't changing without
    # being changed.
    assert args == ImmutableDict({'a': 1, 'b': 2})

    # test that the results are immutable
    args['a'] = 3
    assert args == ImmutableDict({'a': 1, 'b': 2})
    # also test that we're not going to get an unexpected error

# Generated at 2022-06-23 13:55:46.233062
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        pass
    options = Options()
    options.stochastic = True
    options.foo = 'bar bar'
    options.b = False
    options.baz = 'baz'

    cli_args = CLIArgs.from_options(options)
    assert cli_args == ImmutableDict(stochastic=True, foo='bar bar', b=False, baz='baz')
    options.baz = 'baz baz'
    assert cli_args != ImmutableDict(stochastic=True, foo='bar bar', b=False, baz='baz baz')

# Generated at 2022-06-23 13:55:53.882183
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import collections
    import os


# Generated at 2022-06-23 13:55:58.730356
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = {'k1': 'v1', 'k2': 'v2', 'k3': 'v3'}
    cli_args = GlobalCLIArgs.from_options(args)
    assert cli_args.k1 == args.k1
    assert cli_args.k2 == args.k2
    assert cli_args.k3 == args.k3
    #args.k2 = 'v2.5'
    #assert cli_args.k2 != args.k2

# Generated at 2022-06-23 13:56:08.941520
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import connection_loader, action_loader

    loader = DataLoader()
    play = Play().load({
        'name': 'test play',
        'hosts': 'localhost',
        'gather_facts': 'no',
        'tasks': [
            {'action': {'module': 'debug', 'args': {'msg': 'hello world'}}}
        ]},
        variable_manager=None,
        loader=loader,
        connection_loader=connection_loader,
        action_loader=action_loader,
    )

    play_context = play.get_default_vars()

    assert isinstance(play_context, CLIArgs)

    # test whether play_context is

# Generated at 2022-06-23 13:56:19.310684
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Subclass1(metaclass=_ABCSingleton):
        def __init__(self):
            pass

    class Subclass2(metaclass=_ABCSingleton):
        def __init__(self):
            pass

    class Subclass3(Subclass1, Subclass2):
        def __init__(self):
            pass

    class Subclass4(Subclass1, Subclass2):
        def __init__(self):
            pass

    assert issubclass(Subclass1, Singleton)
    assert issubclass(Subclass2, Singleton)
    assert issubclass(Subclass3, Singleton)
    assert issubclass(Subclass4, Singleton)
    assert issubclass(Subclass1, ABCMeta)
    assert issubclass(Subclass2, ABCMeta)
    assert issubclass

# Generated at 2022-06-23 13:56:22.565313
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABCSingleton(_ABCSingleton):
        pass

    class TestABCSingleton2(_ABCSingleton):
        pass

    assert TestABCSingleton() is TestABCSingleton()
    assert TestABCSingleton() is TestABCSingleton2()

# Generated at 2022-06-23 13:56:25.941758
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_args = GlobalCLIArgs({'foo': 'bar'})
    assert isinstance(global_args, GlobalCLIArgs)

# Generated at 2022-06-23 13:56:31.534410
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    input_dict = {"a": 1, "b": "two", "c": [1, 2], "d": (1, 2), "e": {"a": 1}, "f": set([1, 2])}
    cli_args_obj = CLIArgs(input_dict)
    assert input_dict == cli_args_obj

# Generated at 2022-06-23 13:56:42.652652
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.config.data import ConfigData
    from ansible.config.manager import ConfigManager


# Generated at 2022-06-23 13:56:47.411189
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo1:
        __metaclass__ = _ABCSingleton
    class Foo2(Foo1):
        pass
    class Foo3:
        __metaclass__ = _ABCSingleton
    try:
        class Foo4(Foo1, Foo3):
            pass
    except TypeError:
        pass
    else:
        raise AssertionError()

# Generated at 2022-06-23 13:56:53.302332
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.base_executable import CLI
    g = CLI.parse([])
    parsed = CLIArgs(vars(g))
    assert not parsed.get('ask_vault_pass')

    # should not be able to change the value
    try:
        parsed['ask_vault_pass'] = True
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-23 13:56:56.813289
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton(): # pylint: disable=no-self-use
    """Unit test for constructor of class _ABCSingleton"""
    class Foo(object, metaclass=_ABCSingleton):
        pass

    assert Foo() is Foo()



# Generated at 2022-06-23 13:57:04.049599
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    '''Test CLIArgs'''
    import sys
    import os
    import collections
    import unittest

    import ansible.utils.unsafe_proxy
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils.common.collections import ImmutableDict

    if sys.version_info < (2, 7):
        import unittest2 as unittest

    class TestCLIArgs(unittest.TestCase):

        def test_type_CLIArgs(self):
            '''Test type of CLIArgs'''
            cli_args = CLIArgs(dict(test_cli_args=dict(test_dict=dict(test_key='test_value'))))
            self.assertIsInstance(cli_args, (CLIArgs, ImmutableDict))


# Generated at 2022-06-23 13:57:08.462417
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Quick and dirty test to prove that _ABCSingleton is a valid metaclass

    This test uses the GlobalCLIArgs class here as an example of how to use this.
    """
    from ansible.release import __version__
    from ansible.utils.display import Display

    class GlobalExample(GlobalCLIArgs):
        """Dummy class to tests whether the _ABCSingleton behaves as expected"""
        def __init__(self, data):
            self._mydata = data

        def get_data(self):
            return self._mydata

    g_example_instance = GlobalExample('A')
    display = Display()
    display.display(g_example_instance)
    assert g_example_instance.get_data() == 'A'

    # Create a second instance which is really the same instance under the covers
    g_

# Generated at 2022-06-23 13:57:10.782109
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class AAA(metaclass=_ABCSingleton):
        pass

    class BBB(AAA):
        pass

    AAA()
    BBB()

# Generated at 2022-06-23 13:57:20.546367
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Verify that the constructor of class CLIArgs works as expected
    """

# Generated at 2022-06-23 13:57:24.963224
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict = {'age': 2, 'children': None, 'name': 'Alfred'}
    cli_args = CLIArgs(dict)

    assert cli_args.__class__ == GlobalCLIArgs
    assert cli_args['age'] == 2
    assert cli_args['children'] is None
    assert cli_args['name'] == 'Alfred'

# Generated at 2022-06-23 13:57:34.075412
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Main testing method
    def test_str(strs1, strs2):
        if strs1 != strs2:
            print("\nERROR in test_str")
            print("Strings are not equal.\n")
            print("Expected: %s\n" % strs1)
            print("Actual:   %s\n" % strs2)

    def test_dict(before, after):
        if before != after:
            print("\nERROR in test_dict")
            print("Dictionaries are not equal.\n")
            print("Expected: %s\n" % before)
            print("Actual:   %s\n" % after)

    def test_list(before, after):
        if before != after:
            print("\nERROR in test_list")
            print

# Generated at 2022-06-23 13:57:46.045419
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import pytest

    from ansible.module_utils.common.collections import is_immutable

    test_dict = {"a": "b"}
    assert is_immutable(test_dict) == False

    test_list = ["a", "b"]
    assert is_immutable(test_list) == False

    test_set = set(["a", "b"])
    assert is_immutable(test_set) == False

    test_dict = {"a": {"b": "c", "d": {"e": "f"}}}
    assert is_immutable(test_dict) == False

    test_mut_dict = CLIArgs(test_dict)
    assert is_immutable(test_mut_dict) == True
    assert is_immutable(test_mut_dict["a"]) == True
    assert is_imm

# Generated at 2022-06-23 13:57:56.021804
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs({'foo': 'bar', 'biz': {'baz': ['ok']}, 'buh': ['bud', 'bum']})
    if not cli_args.foo == 'bar':
        raise Exception("foo is %s, expected %s" % (cli_args.foo, 'bar'))
    if not cli_args.biz.baz == ('ok',):
        raise Exception("biz.baz is %s, expected %s" % (cli_args.biz.baz, ('ok',)))
    if not cli_args.buh == ('bud', 'bum'):
        raise Exception("buh is %s, expected %s" % (cli_args.buh, ('bud', 'bum')))

# Generated at 2022-06-23 13:58:04.866230
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class X(object, metaclass=_ABCSingleton):
        pass

    class Y(X):
        pass

    class Z(Y):
        pass

    x_1 = X()
    x_2 = X()
    assert x_1 is x_2
    assert x_1.__class__ is X

    y_1 = Y()
    y_2 = Y()
    assert y_1 is y_2
    assert y_1.__class__ is Y

    z_1 = Z()
    z_2 = Z()
    assert z_1 is z_2
    assert z_1.__class__ is Z

# Generated at 2022-06-23 13:58:16.369988
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global __file__
    import sys
    __file__ = sys.argv[0]
    import os
    os.environ['ANSIBLE_CONFIG'] = __file__
    del os
    del sys
    # This will parse the command line args into a namespace and then convert that into a dictionary
    from ansible.config.manager import ConfigManager
    config_manager = ConfigManager(args=None)
    config_manager.get_config_data()
    from ansible.cli.cli import CLI
    cli_args = CLI.base_parser(config_manager)
    # This will make sure that GlobalCLIArgs is a singleton
    cli_args = GlobalCLIArgs(cli_args)
    cli_args = GlobalCLIArgs(cli_args)
    assert cli_args is not None

# Generated at 2022-06-23 13:58:18.505473
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    a = Foo()
    b = Foo()
    assert a is b

# Generated at 2022-06-23 13:58:22.008782
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        def __init__(self, args):
            self.args = args
    options = Options({'a':'Foo', 'b':'Bar'})
    args = GlobalCLIArgs.from_options(options)
    assert args == options.args


# Generated at 2022-06-23 13:58:27.134765
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args_dict = {
        'a': 'A',
        'b': {
            'b1': 'B1',
            'b2': 'B2',
            'b3': ['a', {'b': 'c', 'd': 'e'}]
        }
    }
    cliargs = CLIArgs(args_dict)
    assert isinstance(cliargs, Mapping)
    assert isinstance(cliargs['b'], Mapping)
    assert isinstance(cliargs['b']['b3'], Sequence)
    assert isinstance(cliargs['b']['b3'][1], Mapping)

# Generated at 2022-06-23 13:58:37.897029
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # cmd line args as received from optparse
    from optparse import Values
    v = Values()
    v.listtags = False
    v.listtasks = False
    v.syntax = False
    v.vault_password_file = None
    v.tags = None
    v.skip_tags = None
    v.force_handlers = None
    v.start_at_task = None
    v.step = None
    v.diff = None
    v.private_key_file = None
    v.remote_user = u'root'
    v.verbose = False
    v.connection = u'local'
    v.timeout = 10
    v.ssh_common_args = None
    v.ssh_extra_args = None
    v.sftp_extra_args = None
    v.sc

# Generated at 2022-06-23 13:58:39.811367
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestMeta(object):
        __metaclass__ = _ABCSingleton
        pass

# Generated at 2022-06-23 13:58:41.265637
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs(dict(a=1, b=2))

# Generated at 2022-06-23 13:58:50.749642
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({}) == ImmutableDict({})
    assert CLIArgs({"a": "a"}) == ImmutableDict({"a": "a"})
    assert CLIArgs({"a": "a", "b": "b"}) == ImmutableDict({"a": "a", "b": "b"})
    assert CLIArgs({"a": 1, "b": 2}) == ImmutableDict({"a": 1, "b": 2})

    # Lists
    assert CLIArgs({"a": [1, 2, 3]}) == ImmutableDict({"a": (1, 2, 3)})
    assert CLIArgs({"a": ["a"]}) == ImmutableDict({"a": ("a",)})
    assert CLIArgs({"a": []}) == ImmutableDict({"a": ()})

    #

# Generated at 2022-06-23 13:58:58.927553
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Unit test for constructor of class GlobalCLIArgs
    # GIVEN a set of command line switches
    options = ImmutableDict(dict(
        module_path='/path/to/modules/',
        inventory='/path/to/inventory',
        forks='10',
        ask_become_pass='False',
        flush_cache='no',
        connection='ssh',
        listhosts='no',
        become_user='nobody',
        verbosity='1',
        private_key_file='IdentityFile',
        diff='yes',
        nocolor='0',
        timeout='10',
        output_file='None',
        one_line='no',
        tree='None',
        module_path='/path/to/modules'))
    # WHEN parsing the arguments

# Generated at 2022-06-23 13:59:04.163780
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(B):
        pass

    assert issubclass(B, A)
    assert issubclass(C, A)
    assert issubclass(C, B)
    assert not issubclass(A, B)
    assert not issubclass(A, C)
    assert not issubclass(B, C)

    assert isinstance(A(), A)
    assert isinstance(B(), A)
    assert isinstance(C(), A)
    assert isinstance(C(), B)

    assert A() is A()
    assert B() is B()
    assert C() is C()

    assert B() is not A()
    assert C() is not A()
    assert C() is not B()


# Generated at 2022-06-23 13:59:06.767052
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    argv = GlobalCLIArgs({'args': ['h', 'v']})
    assert isinstance(argv['args'], tuple)
    assert isinstance(argv, CLIArgs)
    assert isinstance(argv, Mapping)

# Generated at 2022-06-23 13:59:08.759240
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class DummySingletonClass(metaclass=_ABCSingleton):
        pass

    assert DummySingletonClass() == DummySingletonClass()

# Generated at 2022-06-23 13:59:16.935589
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs.from_options(Mapping({
        'foo':'bar',
        'answer':42,
        'list':[1,2,3,4],
        'sublist': [
            {'key1':'value1'},
            {'key2':'value2'}
        ]
    }))
    assert isinstance(cli_args, CLIArgs)
    assert cli_args == {
        'foo': 'bar',
        'answer': 42,
        'list': (1,2,3,4),
        'sublist': (
            ImmutableDict({'key1': 'value1'}),
            ImmutableDict({'key2': 'value2'})
        )
    }

# Generated at 2022-06-23 13:59:22.886392
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = {'help': False, 'diff': True, 'module_name': 'ping', 'module_args': None}
    cli_args['connection'] = {'local': True, 'unix_socket': None}
    cli_args['connection']['url'] = None
    cli_args['connection']['network_os'] = None
    cli_args['connection']['transport'] = None
    cli_args['connection']['remote_addr'] = None
    cli_args['connection']['port'] = 22
    cli_args['connection']['timeout'] = 10
    cli_args['connection']['host_key_checking'] = True
    cli_args['connection']['private_key_file'] = '~/.ssh/id_rsa'


# Generated at 2022-06-23 13:59:26.574297
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyClass(metaclass=_ABCSingleton):
        pass

    assert MyClass() is MyClass()
    assert isinstance(MyClass(), MyClass)

# Generated at 2022-06-23 13:59:30.877003
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert issubclass(CLIArgs, Mapping)
    assert issubclass(CLIArgs, Container)
    assert not issubclass(CLIArgs, Set)
    assert not issubclass(CLIArgs, Sequence)
    assert not issubclass(CLIArgs, Singleton)
    assert isinstance(CLIArgs({}), CLIArgs)
    assert not isinstance(CLIArgs({}), GlobalCLIArgs)
    assert isinstance(CLIArgs({}), Mapping)
    assert isinstance(CLIArgs({}), Container)
    assert not isinstance(CLIArgs({}), Set)
    assert not isinstance(CLIArgs({}), Sequence)
    assert not isinstance(CLIArgs({}), Singleton)


# Generated at 2022-06-23 13:59:36.927971
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    module1 = ImmutableDict({'foo': 'bar'})
    module2 = ImmutableDict({'baz': 'qux'})
    args = CLIArgs({'module': module1, 'other': module2})
    assert args['module'] == module1
    assert args['other'] == module2
    assert 'module' in args
    assert 'other' in args

# Generated at 2022-06-23 13:59:38.447844
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # This test is only so that pytest will pick up this file as a module to test
    assert True

# Generated at 2022-06-23 13:59:42.222952
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingletonAndMetaclass(object):
        __metaclass__ = _ABCSingleton

    assert SingletonAndMetaclass() == SingletonAndMetaclass()

# Generated at 2022-06-23 13:59:51.996688
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # pylint: disable=unused-variable,unused-argument
    def _get_options(names, default_values=None, types=None, aliases=None, raw_args=None, **kwargs):
        # pylint: disable=unused-variable,too-many-locals
        """
        Just hard wire the options we use so we can test it out
        """
        options = ImmutableDict()
        if default_values is None:
            default_values = {}
        if types is None:
            types = {}
        if aliases is None:
            aliases = {}

        # Make a copy of raw_args so we can modify it
        if raw_args is None:
            raw_args = []
        else:
            raw_args = raw_args[:]


# Generated at 2022-06-23 13:59:53.102396
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    pass


# Generated at 2022-06-23 14:00:03.135836
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    def my_exit():
        raise Exception('dead')

    import sys
    temp_exit = sys.exit

    # test default parser
    try:
        sys.exit = my_exit
        GlobalCLIArgs.clear_instance()
        GlobalCLIArgs()
    except Exception:
        pass
    finally:
        sys.exit = temp_exit

    # test custom parser

# Generated at 2022-06-23 14:00:08.279539
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Check that everyone is talking about the same instance
    assert GlobalCLIArgs() == GlobalCLIArgs()
    # Ensure that __new__ is actually creating objects
    assert GlobalCLIArgs() is not None
    # Ensure that __new__ is actually creating objects
    assert GlobalCLIArgs() != "a"

# Generated at 2022-06-23 14:00:12.259194
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    class E(object):
        __metaclass__ = _ABCSingleton

    assert issubclass(B, A)
    assert issubclass(C, A)
    assert issubclass(D, A)
    assert issubclass(E, object)
    assert isinstance(A(), object)
    assert isinstance(B(), object)
    assert isinstance(C(), object)
    assert isinstance(D(), object)
    assert isinstance(E(), object)

# Generated at 2022-06-23 14:00:25.683835
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    arguments = CLIArgs({'a': '1', 'b': '2'})
    assert arguments['a'] == '1'
    assert arguments['b'] == '2'

    # Ensure items are immutable
    try:
        arguments['a'] = '3'
        raise AssertionError("Expected to raise TypeError because CLIArgs is immutable")
    except TypeError:
        pass

    try:
        arguments['c'] = '3'
        raise AssertionError("Expected to raise TypeError because CLIArgs is immutable")
    except TypeError:
        # Make sure the value we tried to set didn't exist
        assert 'c' not in arguments

    # Ensure the object itself is immutable

# Generated at 2022-06-23 14:00:27.772644
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = GlobalCLIArgs('a')
    b = GlobalCLIArgs('b')
    assert a is b, "Only one instance of GlobalCLIArgs"

# Generated at 2022-06-23 14:00:30.932903
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {"module": "testmodule", "args": "testarg"}
    cli_args = CLIArgs(test_dict)
    assert(isinstance(cli_args, ImmutableDict))
    assert(isinstance(cli_args, CLIArgs))
    assert(isinstance(cli_args, Mapping))
    assert(cli_args == test_dict)



# Generated at 2022-06-23 14:00:33.916266
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import mock
    import os
    import sys

    # We need to fake command line arguments to make sure it gets initialized
    with mock.patch.object(sys, 'argv', ['whatever']):
        with mock.patch.object(os, 'environ', {}):
            args = GlobalCLIArgs.get_instance()

    assert isinstance(args, GlobalCLIArgs)



# Generated at 2022-06-23 14:00:37.084910
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object):
        __metaclass__ = _ABCSingleton
    test1 = Test()
    test2 = Test()
    assert test1 is test2

# Generated at 2022-06-23 14:00:38.494430
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class X(object):
        __metaclass__ = _ABCSingleton

    class Y(X):
        pass
    x = X()
    y = Y()
    assert x is y

# Generated at 2022-06-23 14:00:43.954743
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # The lines below are expected to fail with a TypeError
    # class ABC(object, metaclass=_ABCSingleton):
    #     pass

    # The lines below are expected to raise an exception
    # class A(ABC):
    #     pass
    # class B(ABC):
    #     pass
    assert isinstance(_ABCSingleton, ABCMeta)
    assert isinstance(_ABCSingleton, Singleton)

# Generated at 2022-06-23 14:00:48.920404
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': {'b': {'c': 'd'}}}
    test_obj = CLIArgs(test_dict)
    assert test_dict['a'] is not test_obj['a']
    assert test_dict['a']['b'] is not tes

# Generated at 2022-06-23 14:00:53.210382
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        pass
    options = Options()
    options.server = 'dev-server.local'
    options.user = 'joe'

    # The expected output using cli parser
    cli_dict = {'server': 'dev-server.local',
                'user': 'joe'}

    # Check if all expected cli args exist in our GlobalCLIArgs object
    assert all(k in vars(GlobalCLIArgs.from_options(options)) for k in cli_dict.keys())
    assert all(vars(GlobalCLIArgs.from_options(options))[key] == value for key, value in cli_dict.items())
    assert GlobalCLIArgs.from_options(options).server == cli_dict.get('server')

# Generated at 2022-06-23 14:01:03.307965
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class DummyOptions(object):
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    # These values should not be mutable

# Generated at 2022-06-23 14:01:09.826553
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_list = [4, 1, 2]
    test_dict = {'a': 1, 'b': 2, 'c': 3}

    test_args = GlobalCLIArgs(test_dict)

    assert test_args['a'] == 1
    assert test_args['b'] == 2
    assert test_args['c'] == 3

    # Make sure nothing was changed by the creation of the args
    assert test_dict['a'] == 1
    assert test_dict['b'] == 2
    assert test_dict['c'] == 3

    # Add test_list to test_dict so we can see it get turned into a tuple
    test_dict['d'] = test_list

    test_args = GlobalCLIArgs(test_dict)

    assert test_args['a'] == 1
    assert test_args['b'] == 2

# Generated at 2022-06-23 14:01:10.883298
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert GlobalCLIArgs() is GlobalCLIArgs()

# Generated at 2022-06-23 14:01:14.569388
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test_ABCSingleton(object):
        __metaclass__ = _ABCSingleton
        pass

    assert Test_ABCSingleton() is Test_ABCSingleton()

# Generated at 2022-06-23 14:01:21.844021
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import argparse
    parser = argparse.ArgumentParser()

    parser.add_argument("--foo_arg", type=int, default=1)
    parser.add_argument("--bar_arg", default="a")

    options = parser.parse_args([])
    global_cli_args = GlobalCLIArgs.from_options(options)

    assert global_cli_args.foo_arg == options.foo_arg
    assert global_cli_args.bar_arg == options.bar_arg

# Generated at 2022-06-23 14:01:26.219315
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class test_class(object):
        __metaclass__ = _ABCSingleton

    obj1 = test_class()

    try:
        obj2 = test_class()
    except TypeError:
        # If you get here, the constructor is broken
        assert False

    assert obj1 is obj2

# Generated at 2022-06-23 14:01:36.132171
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    #
    # Test module internal function: _make_immutable
    #
    assert _make_immutable("abc") == "abc"
    assert _make_immutable(("a", "b", "c")) == ("a", "b", "c")
    assert _make_immutable(("a", ("b", "c"), "d")) == ("a", ("b", "c"), "d")
    assert _make_immutable(("a", ("b", ("c", "d")), "e")) == ("a", ("b", ("c", "d")), "e")
    assert _make_immutable(set([1, 2, 3])) == frozenset([1, 2, 3])
    assert _make_immutable({"a": "1", "b": "2", "c": "3"}) == ImmutableDict

# Generated at 2022-06-23 14:01:39.699103
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    data = {"cache": True, "connection": "local", "module_path": "/opt/ansible/modules"}
    args = CLIArgs(data)
    assert args == data
    assert isinstance(args, ImmutableDict)



# Generated at 2022-06-23 14:01:43.878552
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Create object
    key = 'key'
    value = 'value'
    mapping = {key: value}
    obj = CLIArgs(mapping)

    # Validate the result
    assert obj[key] == value



# Generated at 2022-06-23 14:01:46.460253
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object, metaclass=_ABCSingleton):
        pass
    assert isinstance(A, _ABCSingleton)

# Generated at 2022-06-23 14:01:55.165112
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import os
    import unittest
    from ansible.utils import context_objects as co

    class TestGlobalCLIArgs(unittest.TestCase):
        def setUp(self):
            co.GlobalCLIArgs.clear_singleton()
            co.GlobalCLIArgs._GlobalCLIArgs__instance = None

        def test_init_args(self):
            temp_cls = co.GlobalCLIArgs(dict(f=1, b=2, c=dict(d=3, e=4)))
            self.assertEqual(repr(temp_cls), 'GlobalCLIArgs({\'f\': 1, \'b\': 2, \'c\': ImmutableDict({\'e\': 4, \'d\': 3})})')

# Generated at 2022-06-23 14:01:59.640919
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _Foo(object):
        __metaclass__ = _ABCSingleton

    class _Bar(_Foo):
        pass

    class _Baz(_Foo):
        pass

    assert _Foo() == _Bar() == _Baz()
    assert _Foo() is _Bar() is _Baz()

# Generated at 2022-06-23 14:02:02.439447
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _Test(_ABCSingleton):
        pass
    t1 = _Test()
    t2 = _Test()
    assert t1 is t2



# Generated at 2022-06-23 14:02:09.542540
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class SingletonABC(object, metaclass=_ABCSingleton):
        pass

    class SingletonABC2(metaclass=_ABCSingleton):
        pass

    class JustABC(object, metaclass=ABCMeta):
        pass

    class JustABC2(metaclass=ABCMeta):
        pass

    class JustABC3(object, metaclass=_ABCSingleton):
        pass

    class JustSingleton(metaclass=Singleton):
        pass

    class JustSingleton2(object, metaclass=Singleton):
        pass

    class JustSingleton3(object):
        pass

# Generated at 2022-06-23 14:02:12.807855
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Create a subclass and instantiate it to ensure that it acts as both a Singleton and a metaclass
    """
    class Dummy(_ABCSingleton):
        def __init__(self, x):
            self.x = x
    a = Dummy(1)
    b = Dummy(2)
    assert a is b
    assert a.x == b.x == 1

# Generated at 2022-06-23 14:02:19.651705
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    A unit test for constructor of class _ABCSingleton
    """
    class ABCSingleton_test(object):
        # meta class __init__ is called before the class object is created
        def __init__(self):
            print("initABCSingleton_test")

    ABCSingleton_test_1 = ABCSingleton_test()
    ABCSingleton_test_2 = ABCSingleton_test()
    assert ABCSingleton_test_1 is ABCSingleton_test_2, "instance of ABCSingleton_test should be singleton"

# Generated at 2022-06-23 14:02:31.654154
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Test the GlobalCLIArgs(), it should be immutable
    class Myoption(object):
        pass

    opt = Myoption()
    opt.debug = True
    opt.action = 'ping'
    opt.module_name = 'ping'
    opt.module_path = '/bin/ping'
    opt.module_arguments = {'target': 'test_host'}

    global_values = GlobalCLIArgs.from_options(opt)
    assert global_values['debug'] is True
    assert global_values['action'] == 'ping'
    assert global_values['module_name'] == 'ping'
    assert global_values['module_path'] == '/bin/ping'
    assert global_values['module_arguments']['target'] == 'test_host'

    # Assert the GlobalCLIArgs is immutable
   

# Generated at 2022-06-23 14:02:42.578569
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Create some classes to use for testing
    class Foo(object):
        __metaclass__ = _ABCSingleton

    class Bar(Foo):
        __metaclass__ = Singleton

    class Bar(Foo):
        __metaclass__ = _ABCSingleton

    class Baz(Bar):
        pass

    # Ensure that _ABCSingleton uses Singleton's _abc_registry attribute
    assert(hasattr(Foo, '_abc_registry'))
    assert(Foo._abc_registry is None)
    assert(hasattr(Bar, '_abc_registry'))
    assert(Bar._abc_registry is None)
    assert(hasattr(Baz, '_abc_registry'))
    assert(Baz._abc_registry is None)

    # Make sure the singleton is working

# Generated at 2022-06-23 14:02:44.586856
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert not hasattr(GlobalCLIArgs, '__new__') or GlobalCLIArgs.__new__ == Singleton.__new__



# Generated at 2022-06-23 14:02:55.515713
# Unit test for constructor of class CLIArgs
def test_CLIArgs(): # pylint: disable=no-member
    CLIArgs(dict())
    CLIArgs(dict(a=0))
    CLIArgs(dict(a=1, b=2))
    CLIArgs(dict(a=dict(b=2)))
    CLIArgs(dict(a=dict(b=2, c=3)))
    CLIArgs(dict(a=dict(b=2, c=3, d=dict())))
    CLIArgs(dict(a=dict(b=2, c=3, d=dict(e=1))))
    CLIArgs(dict(a=dict(b=text_type())))
    CLIArgs(dict(a=dict(b=text_type('Z'))))
    CLIArgs(dict(a=dict(b=binary_type())))

# Generated at 2022-06-23 14:03:06.000406
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'a': text_type('b'), 'c': {'1': 1, '2': 2, '3': ImmutableDict({'a': 1, 'b': 2})}, 'd': [1,2,3]}
    mapping = _make_immutable(mapping)
    args = CLIArgs(mapping)
    assert args == mapping, "The result of make immutable is the same as the input"
    assert isinstance(args, ImmutableDict), "The result of make immutable is an ImmutableDict"
    assert isinstance(args['c'], ImmutableDict), "The result of make immutable on a dict is an ImmutableDict"
    assert isinstance(args['c']['3'], ImmutableDict), "The result of make immutable on a nested dict is an ImmutableDict"
    assert isinstance

# Generated at 2022-06-23 14:03:13.622505
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils.common._collections_compat import _ABCSingleton, OrderedDict
    class Bar(_ABCSingleton):
        def __init__(self):
            self._bar = OrderedDict()
            self._update({"baz": "baz"})

        def _update(self, kwargs):
            self._bar.update(kwargs)

    class Foo(_ABCSingleton):
        def __init__(self):
            self._foo = OrderedDict()
            self._update({"bar": Bar()})

        def _update(self, kwargs):
            self._foo.update(kwargs)

    foo = Foo()
    bar = foo.bar
    foo.bar.baz

# Generated at 2022-06-23 14:03:18.669540
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # This should work even though the name is not very descriptive of what it is doing
    class MyClass(_ABCSingleton, object):
        pass
    first_instance = MyClass()
    second_instance = MyClass()
    assert first_instance is second_instance


# Generated at 2022-06-23 14:03:24.685158
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Make sure that CLIArgs returns a hashable structure with all the same data that got passed in.
    """
    test_dict = {
        'a': 1,
        'b': '2',
        'c': [3],
    }

    result = CLIArgs(test_dict)

    assert isinstance(result, ImmutableDict)
    assert isinstance(result['c'], tuple)
    assert result == test_dict
    assert result is not test_dict



# Generated at 2022-06-23 14:03:26.009581
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    obj = CLIArgs({"foo": True})
    assert obj.get("foo") is True

# Generated at 2022-06-23 14:03:34.151144
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('-a', action='store', default='foo')
    parser.add_argument('-b', action='store_true')
    parser.add_argument('-c', action='store_false')
    parser.add_argument('-d', action='store_const', const='bar')
    parser.add_argument('-e', action='append', default='egg,spam')

    options = parser.parse_args(['-a', 'bar', '-b', '-c', '-d', '-e', 'foo'])
    global_cli_args = GlobalCLIArgs.from_options(options)

    assert options.a == 'bar'
    assert options.b is True
    assert options.c is False
    assert options.d

# Generated at 2022-06-23 14:03:45.301018
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Test for empty constructor of class GlobalCLIArgs"""
    # pylint: disable=unused-variable

# Generated at 2022-06-23 14:03:55.222691
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.cli.arguments import Options

    # Boolean arguments
    options = Options()
    options.connection = "ssh"
    options.module_path = None
    options.forks = 10
    options.become = False
    options.become_method = "sudo"
    options.become_user = "root"
    options.check = False
    options.diff = False
    cli_args = CLIArgs.from_options(options)

    assert(cli_args["connection"] == "ssh")
    assert(cli_args["module_path"] is None)
    assert(cli_args["forks"] == 10)
    assert(cli_args["become"] is False)
    assert(cli_args["become_method"] == "sudo")

# Generated at 2022-06-23 14:04:05.100430
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options:
        def __init__(self):
            self.mapping = {}

    example = Options()
    example_dict = ['name', 'dave']
    example_sequence = ['boy', 'girl']
    example_set = set(['hello', 'world'])
    example.mapping['list'] = example_dict
    example.mapping['multiple_list'] = [example_dict, example_sequence, example_set]
    example.mapping['nested_dict'] = {'keys': example_dict}
    example.mapping['nested_list'] = [example_set, {'tuple': tuple(['foo', 'bar'])}]
    example_object = CLIArgs.from_options(example)
    assert example_object == example.mapping