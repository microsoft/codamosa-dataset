

# Generated at 2022-06-25 13:00:45.062638
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert(issubclass(_ABCSingleton, MetaclassHelper))


# Generated at 2022-06-25 13:00:48.186698
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = GlobalCLIArgs()
    global_c_l_i_args_1 = GlobalCLIArgs()
    assert global_c_l_i_args_0 == global_c_l_i_args_1



# Generated at 2022-06-25 13:00:57.190532
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-25 13:01:04.263352
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict_1 = {'foo': 'bar', 'var': '200', 'a': ['1', '2', '3'], 'are': ['they', 'all', 'numbers'], 'd': {'g': ['n', 'm'], 'h': ['o', 'p', 'q']}, 'a1': {'d1': ['g1', 'h1']}}
    result_of_CLIArgs = CLIArgs(dict_1)
    print("Result of CLIArgs: " + str(result_of_CLIArgs))




# Generated at 2022-06-25 13:01:05.800904
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    int_0 = -572
    _ABCSingleton(int_0)



# Generated at 2022-06-25 13:01:12.579368
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    c_l_i_args_0 = CLIArgs({"f": "hello"})
    assert c_l_i_args_0.get("f") == "hello"
    c_l_i_args_1 = CLIArgs({"f": "Hello", "g": "hello"})
    assert c_l_i_args_1.get("f") == "Hello"
    assert c_l_i_args_1.get("g") == "hello"
    c_l_i_args_2 = CLIArgs({})
    assert c_l_i_args_2.get("f") is None
    c_l_i_args_3 = CLIArgs({"f": [1, 2, 3]})
    assert c_l_i_args_3.get("f") == (1, 2, 3)


# Generated at 2022-06-25 13:01:14.267585
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    empty_dict = {}
    g_c_l_i_args_0 = GlobalCLIArgs(empty_dict)

# Generated at 2022-06-25 13:01:21.943860
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_values = [int, str, bool, bytes, list, tuple, set, dict]
    for type_to_test in test_values:
        cli_args_0 = CLIArgs(type_to_test)
        test_result = isinstance(cli_args_0, Singleton)
        if test_result != True:
            raise AssertionError("result %s does not match expected result %s" % (test_result, True))
        test_result = isinstance(cli_args_0, ABCMeta)
        if test_result != True:
            raise AssertionError("result %s does not match expected result %s" % (test_result, True))

# Generated at 2022-06-25 13:01:26.229276
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    int_0 = -572
    c_l_i_args_0 = GlobalCLIArgs(int_0)

if __name__ == '__main__':
    import sys
    import traceback
    try:
        test_case_0()
    except Exception as ex:
        print('test_case_0 threw an exception')
        traceback.print_exc(file=sys.stdout)
    print('Test finished.')

# Generated at 2022-06-25 13:01:34.233519
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    # Todo: This test should be rewritten, but for some reason it is failing with the error:
    # TypeError: Error when calling the metaclass bases
    #     type '_GlobalCLIArgs' is not an acceptable base type

    class _GlobalCLIArgs(GlobalCLIArgs):

        def __init__(self):
            super(_GlobalCLIArgs, self).__init__(None)
            self.values = CLIArgs(None)

        def set_cli_args(self, values):
            self.values = values

        def __getitem__(self, item):
            return self.values[item]

        def __setitem__(self, key, value):
            self.values[key] = value

    _global_cli_args_0 = _GlobalCLIArgs()
    _global_cli_args_0.set

# Generated at 2022-06-25 13:01:37.933450
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 13:01:47.860749
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    import unittest
    from ansible.module_utils.common.collections import CLIArgs
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.module_utils.common.collections import _ABCSingleton
    class TestCase__ABCSingleton(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test__abc_meta_class_meta_class(self):
            self.assertEqual(
                type(CLIArgs).__mro__[1],
                _ABCSingleton,
            )
            self.assertEqual(
                type(GlobalCLIArgs).__mro__[1],
                _ABCSingleton,
            )


# Generated at 2022-06-25 13:01:50.255004
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    with pytest.raises(TypeError):
        test_case_0()



# Generated at 2022-06-25 13:01:51.628783
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    _ABCSingleton()

# Generated at 2022-06-25 13:01:53.678015
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    int_0 = -572
    global_c_l_i_args_0 = GlobalCLIArgs(int_0)

# Generated at 2022-06-25 13:01:59.628530
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs(0) == {}
    assert CLIArgs(0).__class__.__name__ == 'CLIArgs'
    assert CLIArgs(1) == {}
    assert CLIArgs(1).__class__.__name__ == 'CLIArgs'
    assert CLIArgs(-1) == {}
    assert CLIArgs(-1).__class__.__name__ == 'CLIArgs'

#Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-25 13:02:02.200181
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    c_l_i_args_0 = CLIArgs({"a": 3})
    assert isinstance(c_l_i_args_0, CLIArgs)



# Generated at 2022-06-25 13:02:08.901147
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-25 13:02:10.164635
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = GlobalCLIArgs

# Generated at 2022-06-25 13:02:11.859675
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    try:
        test_case_0()
    except Exception:
        assert False


# Generated at 2022-06-25 13:02:16.526328
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.errors import AnsibleError
    # Test first use
    test_case_0()
    # Test second use, should fail with an AnsibleError
    test_case_0()


# Generated at 2022-06-25 13:02:20.920440
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Should be a singleton stored in the class
    original_args = GlobalCLIArgs({"a": "b"})
    assert original_args is GlobalCLIArgs(None)
    # Test with different args, should still be the same
    GlobalCLIArgs({"c": "d"})
    assert original_args is GlobalCLIArgs(None)



# Generated at 2022-06-25 13:02:23.048054
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_a = CLIArgs({'a':'b'})
    assert test_a.__len__() == 1



# Generated at 2022-06-25 13:02:31.878680
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    a_b_c_singleton_1 = _ABCSingleton()
    a_b_c_singleton_2 = _ABCSingleton()
    assert a_b_c_singleton_1 is a_b_c_singleton_2
    test_dict = {'a': 1, 'b': '2', 'c': ['3', '4']}
    cli_args_1 = CLIArgs(test_dict)
    cli_args_2 = CLIArgs(test_dict)
    assert cli_args_1 is not cli_args_2


# Generated at 2022-06-25 13:02:38.557073
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # This should return the same object
    a_b_c_singleton_0 = _ABCSingleton()
    a_b_c_singleton_1 = _ABCSingleton()
    print(a_b_c_singleton_0)
    print(a_b_c_singleton_1)
    assert a_b_c_singleton_0 is a_b_c_singleton_1
    # This should fail with TypeError
    try:
        a_b_c_singleton_2 = _ABCSingleton()
    except TypeError:
        print("Caught TypeError, cannot instantiate Singleton multiple times")
        assert True

#Unit Test for constructors of class GlobalCLIArgs

# Generated at 2022-06-25 13:02:46.147006
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    
    # test whether it is a singleton.
    gca = GlobalCLIArgs()
    gca1 = GlobalCLIArgs()
    assert gca is gca1

    # test constructor.
    test = 1
    op = type('options', (object,), {'test': test})()
    global_cli_args = GlobalCLIArgs(op)
    assert global_cli_args['test'] == test
    global_cli_args['test'] = 0
    assert global_cli_args['test'] == test

# Generated at 2022-06-25 13:02:50.938753
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    a_b_c_singleton_0 = _ABCSingleton()
    a_b_c_singleton_1 = _ABCSingleton()
    assert a_b_c_singleton_0 == a_b_c_singleton_1, "singleton does not work"
    assert a_b_c_singleton_0 is a_b_c_singleton_1, "singleton does not work"


# Generated at 2022-06-25 13:02:51.899805
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()



# Generated at 2022-06-25 13:02:56.484806
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class MockOptions(object):
        foo = 123

    global_cli_args_0 = _make_immutable(GlobalCLIArgs.from_options(MockOptions))
    assert type(global_cli_args_0) is ImmutableDict
    assert global_cli_args_0 == ImmutableDict({u'foo': 123})

test_case_0()
test_GlobalCLIArgs()

# Generated at 2022-06-25 13:02:57.533747
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert (test_case_0)

# Generated at 2022-06-25 13:03:08.337471
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a_int = 572
    a_float = 572.636
    a_list = [572, 'a']
    a_dict = {'a_int': a_int, 'a_float': a_float, 'a_list': a_list}
    a_list.append(a_dict)

    instance_0 = GlobalCLIArgs(a_dict)
    instance_1 = GlobalCLIArgs(a_dict)
    assert instance_0 is instance_1

    instance_0['a_int'] = a_int + 10
    assert instance_0['a_int'] == a_int
    instance_0['a_float'] = a_float + 10.0
    assert instance_0['a_float'] == a_float
    instance_0['a_list'].append('b')
    assert instance

# Generated at 2022-06-25 13:03:17.494124
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert issubclass(CLIArgs, Mapping)
    assert issubclass(CLIArgs, Container)
    assert not (issubclass(CLIArgs, Sequence))
    assert not (issubclass(CLIArgs, Set))
    assert not (issubclass(CLIArgs, Singleton))
    assert not (issubclass(CLIArgs, ABCMeta))
    assert not (issubclass(CLIArgs, object))

    mapping_0 = {}
    mapping_0['$'] = {}
    mapping_0['$']['$'] = {}
    mapping_0['$']['$']['$'] = {}
    mapping_0['$']['$']['$']['$'] = {}

# Generated at 2022-06-25 13:03:26.822618
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    c_l_i_args_0 = GlobalCLIArgs(ImmutableDict({'allow_unsupported_hardware': False, 'become': True, 'become_ask_pass': False, 'become_method': u'sudo', 'become_user': None, 'connection': u'local', 'diff': False, 'extra_vars': [], 'flush_cache': None, 'force_handlers': False, 'forks': 5, 'host_key_checking': True, 'inventory': [], 'module_path': None, 'output_file': None, 'playbook': None, 'private_key_file': [], 'timeout': 10, 'user': None}))

# Generated at 2022-06-25 13:03:36.501167
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # object is not instance of class CLIArgs
    CLIArgs(None)
    # object is not instance of class CLIArgs
    CLIArgs(int)
    # object is not instance of class CLIArgs
    CLIArgs(True)
    # object is not instance of class CLIArgs
    CLIArgs(str)
    # object is not instance of class CLIArgs
    CLIArgs(dict)
    # object is not instance of class CLIArgs
    CLIArgs(set)
    # object is not instance of class CLIArgs
    CLIArgs(tuple)
    # int_value is not an instance of class CLIArgs
    CLIArgs(int)
    # float_value is not an instance of class CLIArgs
    CLIArgs(float)
    # dict_value is not an instance of class CLIArgs
    CLIArgs(dict)
    # list_value is not an instance

# Generated at 2022-06-25 13:03:37.376615
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()

# Generated at 2022-06-25 13:03:43.345493
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-25 13:03:44.167823
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_case_0()


# Generated at 2022-06-25 13:03:54.468040
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse

    if sys.version_info[0] > 2:
        # Python 3
        std_in_0 = b'stdin_value'
    else:
        # Python 2
        std_in_0 = 'stdin_value'

    problems_0 = []

    parser_0 = argparse.ArgumentParser()

    parser_0.add_argument("-a", "--ansible-cfg", default=None, dest="ansible_cfg",
                          help="Specify ansible config file", metavar="PATH", nargs=1)
    parser_0.add_argument("-k", "--ask-pass", action="store_true", default=False, dest="ask_pass",
                          help="Ask for connection password")

# Generated at 2022-06-25 13:03:58.549966
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Test with valid inputs for class _ABCSingleton
    test__ABCSingleton_0()



# Generated at 2022-06-25 13:04:01.148647
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    int_0 = -572
    c_l_i_args_0 = CLIArgs(int_0)
    assert c_l_i_args_0._opts == int_0

# Generated at 2022-06-25 13:04:07.257064
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        _ABCSingleton(None, None, None)
    except TypeError:
        pass


# Generated at 2022-06-25 13:04:12.479212
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    int_0 = -572
    # The constructor raises a maximum recursion error.
    try:
        CLIArgs_instance = CLIArgs(int_0)
    except RuntimeError as error_inst_0:
        # __init__() takes exactly 1 argument (2 given)
        assert error_inst_0.args[0] == "global_cli_args.py:63: RuntimeError: maximum recursion depth exceeded while calling a Python object"



# Generated at 2022-06-25 13:04:21.611709
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Raise a type error exception when all of the following conditions are true,
    1. The given object is not a mapping type
    2. The given object is not a sequence type
    3. The given object is not a set type
    4. The given object is not a string type
    5. The given object is not a unicode type
    """
    int_0 = 453
    try:
        c_l_i_args_0 = CLIArgs(int_0)
    except TypeError as exception:
        # Verify exception raised
        pass
    else:
        # Report unexpected exception
        raise AssertionError("Raise exception not working")

    str_0 = "mvhVtIt0Mtbb"

# Generated at 2022-06-25 13:04:31.321098
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test #1
    mapping = {
        'val_0': '',
        'val_1': '',
        'val_2': '',
    }
    CLIArgs.from_options(mapping)

    # Test #2
    mapping = {
        'val_0': '',
        'val_1': '',
        'val_2': '',
    }
    CLIArgs.from_options(mapping)

    # Test #3
    mapping = {
        'val_0': '',
        'val_1': '',
        'val_2': '',
    }
    CLIArgs.from_options(mapping)

    # Test #4
    mapping = {
        'val_0': '',
        'val_1': '',
        'val_2': '',
    }

# Generated at 2022-06-25 13:04:33.676193
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_case_0()

if __name__ == "__main__":
    # Run the unit tests
    test_CLIArgs()

# Generated at 2022-06-25 13:04:43.048104
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.module_utils.common.params import _get_correct_argspec
    from ansible.cli import CLI

    argspec = _get_correct_argspec(False)
    (options, args) = CLI.parser.parse_args(['-vvvv'])
    obj = CLIArgs.from_options(options)
    assert obj['verbosity'] == 4
    assert obj['tree'] == None
    assert obj['host_key_checking'] == True
    assert obj['debug'] == False
    assert obj['connection'] == 'smart'
    assert obj['module_path'] == None
    assert obj['forks'] == 5
    assert obj['remote_user'] == 'root'
    assert obj['private_key_file'] == None
    assert obj['ssh_common_args'] == None

# Generated at 2022-06-25 13:04:44.150383
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    abc_singleton_0 = _ABCSingleton()


# Generated at 2022-06-25 13:04:51.128721
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Create new instance of CLIArgs class using the _ABCSingleton metaclass
    GlobalCLIArgs_singleton_0 = GlobalCLIArgs(dict)

    # Assert that the created instance of CLIArgs is of type _ABCSingleton
    assert isinstance(GlobalCLIArgs_singleton_0, _ABCSingleton)

    # Assert that the created instance of CLIArgs is of type ImmutableDict
    assert isinstance(GlobalCLIArgs_singleton_0, ImmutableDict)

    # Confirm the class immutable
    assert GlobalCLIArgs_singleton_0.__class__ == GlobalCLIArgs

    # Confirm the class immutable
    assert GlobalCLIArgs_singleton_0.__class__ is GlobalCLIArgs


# Generated at 2022-06-25 13:05:02.398306
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.display import Display
    from ansible.parsing.dataloader import DataLoader
    from test.support.fixtures import ParserFixture
    from ansible.cli import CLI
    options = ParserFixture.parser.parse_args(['--tree', './tree', '--connection', 'ssh'])
    # options = CLI.base_parser(
    #     constants.DEFAULT_MODULE_PATH,
    #     constants.DEFAULT_MODULE_NAME,
    #     constants.DEFAULT_MODULE_ARGS,
    #     True
    # ).parse_args(['--tree', './tree', '--connection', 'ssh'])
    display = Display()
    loader = DataLoader()
    new_object = CLIArgs.from_options(options)
    # loader.load_

# Generated at 2022-06-25 13:05:11.484531
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    c_l_i_args_0 = GlobalCLIArgs()
# print(vars(GlobalCLIArgs()))
# vars_0 = vars(GlobalCLIArgs())
# print(type(vars_0))
# print(isinstance(vars_0, dict))

from ansible.cli import CLI
cli_0 = CLI(None)
from ansible.config.base import ConfigCLI
config_cli_0 = ConfigCLI()
from ansible.config.base import ConfigCLI
config_cli_1 = ConfigCLI()
cli_1 = CLI(None)
from ansible.playbook.play_context import PlayContext
play_context_0 = PlayContext()
from ansible.playbook.play_context import PlayContext
play_context_1 = PlayContext()
play_context_1.become

# Generated at 2022-06-25 13:05:18.084219
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-25 13:05:19.771089
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()


if __name__ == "__main__":

    test_case_0()

# Generated at 2022-06-25 13:05:26.233415
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    int_0 = 21
    c_l_i_args_0 = CLIArgs(int_0)
    assert c_l_i_args_0.get('21') == None
    int_1 = 71
    c_l_i_args_1 = CLIArgs(int_1)
    assert c_l_i_args_1.get('71') == None
    int_2 = 81
    c_l_i_args_2 = CLIArgs(int_2)
    assert c_l_i_args_2.get('81') == None
    int_3 = -9
    c_l_i_args_3 = CLIArgs(int_3)
    assert c_l_i_args_3.get('-9') == None
    int_4 = 38
    c_l_i_args_4

# Generated at 2022-06-25 13:05:34.961074
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    as_dict = {}
    as_dict['become'] = 'True'
    as_dict['become_ask_pass'] = 'False'
    as_dict['become_flags'] = '-S -n -K'
    as_dict['become_method'] = 'become_method'
    as_dict['become_methods'] = 'become_methods'
    as_dict['become_password'] = 'password'
    as_dict['become_user'] = 'user'
    as_dict['become_user_method'] = 'user_method'
    as_dict['bin_ansible_callbacks'] = 'bin_ansible_callbacks'
    as_dict['check'] = 'True'
    as_dict['check_mode'] = 'True'

# Generated at 2022-06-25 13:05:43.333872
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Set up a couple scenarios to test our constructor on
    class_mapping = {'one': 1, 'two': 2, 'three': 3, 'four': 4}
    class_dictionary = {'one': 1, 'two': 2, 'three': 3, 'four': 4}
    class_list = ['one', 'two', 'three', 'four']
    class_tuple = ('one', 'two', 'three', 'four')
    class_set = {'one', 'two', 'three', 'four'}
    class_string = "one,two,three,four"

    # Try to make a CLIArgs object with all of our scenarios
    c_l_i_args_0 = CLIArgs(class_mapping)
    c_l_i_args_1 = CLIArgs(class_dictionary)
    c_

# Generated at 2022-06-25 13:05:44.268981
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_case_0()

# Generated at 2022-06-25 13:05:46.198817
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        _ABCSingleton()
    except TypeError:
        assert True
    except Exception:
        assert False



# Generated at 2022-06-25 13:05:55.137626
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    int_0 = 3042
    int_1 = 783
    int_2 = 783
    # Tuple of classes, will become our signature
    signature = (int_0, int_1, int_2)

    # Create a class with signature and _ABCSingleton as its metaclass
    int_3 = -328
    int_4 = -328
    int_5 = -328
    signature_0 = (int_3, int_4, int_5)
    assert signature_0 not in GlobalCLIArgs.__metaclass__.Dict.keys()
    class_0 = _ABCSingleton(signature_0, ())

    # Confirm the class was added to the metaclass' Dict, and create an instance of it

# Generated at 2022-06-25 13:05:57.268295
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    print("test case:" + __name__)
    test_case_0()


if __name__ == '__main__':
    test__ABCSingleton()

# Generated at 2022-06-25 13:06:07.997678
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, Singleton)
    assert issubclass(_ABCSingleton, ABCMeta)
    assert not issubclass(_ABCSingleton, Container)
    assert not issubclass(_ABCSingleton, Mapping)
    assert not issubclass(_ABCSingleton, Sequence)
    assert not issubclass(_ABCSingleton, Set)
    assert not issubclass(_ABCSingleton, object)
    assert not issubclass(type, _ABCSingleton)
    assert not issubclass(int, _ABCSingleton)
    assert not issubclass(str, _ABCSingleton)
    assert not issubclass(object, _ABCSingleton)


# Generated at 2022-06-25 13:06:22.522390
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    int_0 = -572
    c_l_i_args_0 = CLIArgs(int_0)
    c_l_i_args_1 = CLIArgs(int_0)
    assert c_l_i_args_0 is c_l_i_args_1


# Generated at 2022-06-25 13:06:26.267242
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    int_0 = -572
    c_l_i_args_0 = CLIArgs(int_0)
    return c_l_i_args_0
# Constructor test for class CLIArgs

# Generated at 2022-06-25 13:06:31.706184
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Check that an exception is in fact raised when a non-None value is passed in as the second
    # parameter.
    try:
        # If the second parameter is None like it should be, no exception is raised
        c = _ABCSingleton(None, None)
        # If the second parameter is not None, then an exception is raised.
        c = _ABCSingleton(None, 1)
    except TypeError:
        ok = True
    except Exception:
        pass


# Generated at 2022-06-25 13:06:39.213705
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils.common.collections import _ABCSingleton
    import types
    import six

    # Test with a ABCMeta class
    class ABCMetaClass(six.with_metaclass(_ABCSingleton, object)):
        pass

    assert isinstance(ABCMetaClass, object)
    assert issubclass(ABCMetaClass, object)
    assert isinstance(type(ABCMetaClass), _ABCSingleton)
    assert issubclass(type(ABCMetaClass), _ABCSingleton)

    # Test with a Singleton class
    class SingletonClass(six.with_metaclass(_ABCSingleton, object)):
        __metaclass__ = Singleton

    assert isinstance(SingletonClass, object)
    assert issubclass(SingletonClass, object)

# Generated at 2022-06-25 13:06:45.357440
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    int_0 = -572
    c_l_i_args_0 = CLIArgs(int_0)

    # Check type of __dict__ of class
    if hasattr(c_l_i_args_0, '__dict__'):
        if not isinstance(c_l_i_args_0.__dict__, dict):
            raise AssertionError("Type is not dict for __dict__")

    # Check type of __weakref__ of class
    if hasattr(c_l_i_args_0, '__weakref__'):
        if not isinstance(c_l_i_args_0.__weakref__, None.__class__):
            raise AssertionError("Type is not NoneType for __weakref__")

    # Check type of __hash__ of class

# Generated at 2022-06-25 13:06:45.916924
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    pass


# Generated at 2022-06-25 13:06:51.109403
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("-mp")
    parser.add_argument("-fa")
    parser.add_argument("-k")
    parser.add_argument("-K")
    parser.add_argument("-a")
    parser.add_argument("-A")
    parser.add_argument("-B")
    parser.add_argument("-C")
    parser.add_argument("-D")
    parser.add_argument("-E")
    parser.add_argument("-F")
    parser.add_argument("-H")
    parser.add_argument("-i")
    parser.add_argument("-T")
    parser.add_argument("-t")
    parser.add_argument("-U")

# Generated at 2022-06-25 13:06:52.996522
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_case_0()


# Generated at 2022-06-25 13:06:54.971181
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    _ABCSingleton_0 = _ABCSingleton()



# Generated at 2022-06-25 13:06:57.465901
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({"a": "b"})
    assert args == {"a": "b"}
    assert args["a"] == "b"


# Generated at 2022-06-25 13:07:25.381485
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    int_0 = -572
    c_l_i_args_0 = CLIArgs(int_0)
    assert isinstance(c_l_i_args_0, CLIArgs)



# Generated at 2022-06-25 13:07:27.370001
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    int_0 = 0
    global_c_l_i_args_0 = GlobalCLIArgs(int_0)
# End of test_GlobalCLIArgs

# Generated at 2022-06-25 13:07:29.659446
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    int_0 = -572
    global_cli_args_0 = GlobalCLIArgs()


if __name__ == '__main__':
    test_case_0()
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:07:36.158023
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    global value_abc_0
    global value_abc_1
    value_abc_0 = None
    value_abc_1 = None
    class _Singleton_0(_ABCSingleton):
        def __init__(self, value):
            self.value = value

        def __eq__(self, other):
            return self.value == other.value

    value_abc_0 = _Singleton_0(5)
    value_abc_1 = _Singleton_0(6)
    assert(value_abc_0 is value_abc_1)

# Generated at 2022-06-25 13:07:43.191799
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    int_0 = -35
    bool_1 = False
    long_0 = -9223372036854775808
    float_0 = 9.89791368e+36
    str_0 = 'UNQz_:pdG$4)4n4*cj=^'
    #State of object before and after method execution
    assert (not hasattr(test__ABCSingleton, '__metaclass__'))
    #Call the method
    #_abc_singleton_0 = _ABCSingleton()
    #assert (hasattr(test__ABCSingleton, '__metaclass__'))
    #Check the new state of the object
    return


# Generated at 2022-06-25 13:07:51.379713
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    print("\nUnit Test for CLIArgs")

    int_0 = -848
    list_0 = [int_0, 't', ['B', 919, 'd'], 'qjk', ['a', 7, 'h'],'j', 'jC', ['r', 32, 'J'], 'xo', 'Kq']
    list_1 = [int_0, 'K', 'r', ['r', 7, 'K'], 'F', 'oW', ['N', 7, 'n'], 'k', 'dQ', ['g', 7, 'x'], 'b', 'h', ['C', 7, 'y'], 'e', 'o']

# Generated at 2022-06-25 13:07:52.773956
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    print('test_GlobalCLIArgs')
    int_0 = -572
    c_l_i_args_0 = GlobalCLIArgs(int_0)

# Generated at 2022-06-25 13:07:57.623936
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from nose2.tools import params
    from nose2.tools.such import it
    from ansible.module_utils.common.collections import ImmutableDict
    # No of params: 1
    # param type: Mapping
    @params(('int_0',))
    def test_check(arg_name):
        arg = arg_name
        if arg == 'int_0':
            c_l_i_args_0 = CLIArgs(int_0)
        else:
            raise Exception('unexpected argument:' + arg)

        yield test_check

CLIArgs()

# Generated at 2022-06-25 13:08:00.064398
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    instance = CLIArgs({'a':1,'b':2})
    assert (instance==ImmutableDict({'a':1,'b':2}))


# Generated at 2022-06-25 13:08:00.595328
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs()

# Generated at 2022-06-25 13:08:53.670897
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    int_0 = -572
    c_l_i_args_0 = CLIArgs(int_0)


# Generated at 2022-06-25 13:09:02.012258
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict_0 = {}
    dict_0['key1'] = 'value1'
    dict_0['key2'] = 'value2'
    dict_0['key3'] = 'value3'
    dict_1 = {}
    dict_1['key2'] = 'value2'
    dict_1['key1'] = 'value1'
    dict_1['key3'] = 'value3'
    dict_2 = {}
    dict_2['key2'] = 'value2'
    dict_2['key3'] = 'value3'
    dict_2['key1'] = 'value1'
    dict_3 = {}
    dict_3['key1'] = 'value1'
    dict_3['key2'] = 'value2'
    dict_3['key3'] = 'value3'
    dict_

# Generated at 2022-06-25 13:09:06.288275
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    int_0 = 1
    str_0 = "str"
    list_0 = [1, 1, 2, 3]
    dict_0 = {str_0: list_0}
    set_0 = {int_0, str_0}
    # Constructor for CLIArgs with arguments:
    # CLIArgs(mapping)
    # tests if all are the same type
    mapping_0 = ImmutableDict({int_0 : int_0,
                               str_0 : str_0,
                               list_0: list_0,
                               dict_0: dict_0,
                               set_0: set_0})
    c_l_i_args_0 = CLIArgs(mapping_0)

# Generated at 2022-06-25 13:09:10.060585
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert issubclass(GlobalCLIArgs, _ABCSingleton)
    assert issubclass(GlobalCLIArgs, CLIArgs)
    assert hasattr(GlobalCLIArgs, '__init__')
    assert isinstance(GlobalCLIArgs.__init__, object)
    assert hasattr(GlobalCLIArgs, '__new__')
    assert isinstance(GlobalCLIArgs.__new__, object)



# Generated at 2022-06-25 13:09:20.021581
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Make sure it is a metaclass
    assert issubclass(_ABCSingleton, type)

    # Make sure we can make immutable containers
    args_dict = {
        'foo': 'bar',
        'bar': ['a', 'b', 'c'],
        'baz': {'gronk': 'spit', 'spit': ['flam', 'blam']},
    }
    args_immutable = _make_immutable(args_dict)
    assert isinstance(args_immutable, ImmutableDict)
    for key, value in args_dict.items():
        if isinstance(value, dict):
            assert isinstance(args_immutable[key], ImmutableDict)
        elif isinstance(value, list):
            assert isinstance(args_immutable[key], tuple)

# Generated at 2022-06-25 13:09:23.802556
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    int_0 = -572
    c_l_i_args_0 = CLIArgs(int_0)
    assert isinstance(c_l_i_args_0, ImmutableDict), "'assert' failed at the end of test for CLIArgs()"


# Generated at 2022-06-25 13:09:25.898755
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    int_0 = -572
    c_l_i_args_0 = CLIArgs(int_0)



# Generated at 2022-06-25 13:09:33.926754
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    int_0 = -572
    c_l_i_args_0 = CLIArgs(int_0)
    int_1 = -723
    float_0 = -9.23
    str_0 = 'A+'
    str_1 = 'foo'
    str_2 = 'A'
    str_3 = 'A'
    str_4 = 'A'
    str_5 = 'A'
    str_6 = 'A'
    str_7 = 'A'
    str_8 = 'A'
    str_9 = 'A'
    str_10 = 'A'
    str_11 = 'A'
    str_12 = 'A'
    str_13 = 'A'
    str_14 = 'A'
    str_15 = 'A'
    str_16 = 'A'

# Generated at 2022-06-25 13:09:35.003234
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    c_l_i_args_0 = GlobalCLIArgs({})



# Generated at 2022-06-25 13:09:42.924248
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = GlobalCLIArgs()
    global_c_l_i_args_1 = GlobalCLIArgs()
    assert (global_c_l_i_args_0 is global_c_l_i_args_1)
    #
    # compare the id of the two instances, they should be the same
    #
    c_l_i_args_0 = CLIArgs()
    assert (id(c_l_i_args_0) == id(global_c_l_i_args_0))


if __name__ == '__main__':
    test_case_0()
    test_GlobalCLIArgs()