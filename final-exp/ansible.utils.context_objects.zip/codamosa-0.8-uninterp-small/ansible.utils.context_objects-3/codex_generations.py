

# Generated at 2022-06-25 13:00:45.012786
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    obj = GlobalCLIArgs(b"\xee\x8f\xb4\xaf\x144'\xd5\x9f\xed\x19\x03")
    assert obj
    assert obj.as_dict()
    assert obj.as_dict(True)

# Generated at 2022-06-25 13:00:46.403610
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Test with args
    test_case_0()



# Generated at 2022-06-25 13:00:50.779535
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
  try:
    bytes_0 = b'\x9d\\\xe8\xa5Mj\x1cd\xf1Ns:\xdc'
    c_l_i_args_0 = CLIArgs(bytes_0)
    assert type(c_l_i_args_0) == CLIArgs
  except:
    assert False


# Generated at 2022-06-25 13:00:52.146818
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert_raises(TypeError, CLIArgs, 7)


# Generated at 2022-06-25 13:00:57.844540
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    c_l_i_args_0 = CLIArgs({'b': '\x9d\\\xe8\xa5Mj\x1cd\xf1Ns:\xdc', 'c': -73, 'd': '', 'e': -85, 'f': -81, 'g': 'yu', 'h': 'px', 'i': 'm\x17"j'})
    assert isinstance(GlobalCLIArgs.from_options(c_l_i_args_0), GlobalCLIArgs)
    assert GlobalCLIArgs.from_options(c_l_i_args_0) == c_l_i_args_0


# Generated at 2022-06-25 13:01:00.443241
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, ABCMeta)
    assert issubclass(_ABCSingleton, Singleton)


# Generated at 2022-06-25 13:01:01.538948
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    d_c_l_i_args_0 = _ABCSingleton()




# Generated at 2022-06-25 13:01:02.846294
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    with pytest.raises(Exception):
        _ABCSingleton()


# Generated at 2022-06-25 13:01:06.272030
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bytes_0 = b'\x9d\\\xe8\xa5Mj\x1cd\xf1Ns:\xdc'
    c_l_i_args_0 = CLIArgs(bytes_0)
    # TODO: I'm not sure why this isn't working.  You'd think it'd fail to build if it's not a dict.
    # assert False


# Generated at 2022-06-25 13:01:10.255774
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    c_l_i_args_0 = CLIArgs()
    bytes_0 = b'\x9d\\\xe8\xa5Mj\x1cd\xf1Ns:\xdc'
    c_l_i_args_0 = CLIArgs(bytes_0)


# Generated at 2022-06-25 13:01:14.445339
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_GlobalCLIArgs = GlobalCLIArgs.from_options({'foo': 'bar'})
    assert test_GlobalCLIArgs['foo'] == 'bar'

# Generated at 2022-06-25 13:01:16.828667
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    obj = GlobalCLIArgs({'a': 'b', 'c': 'd'})
    assert obj['a'] == 'b'
    assert obj['c'] == 'd'

# Generated at 2022-06-25 13:01:18.102193
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert _ABCSingleton() == _ABCSingleton()


# Generated at 2022-06-25 13:01:21.861547
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class args:
        test = None

    testargs = args()
    testargs.test = "test"

    cliargs = CLIArgs(vars(testargs))
    print(cliargs.test)
    assert cliargs.test == "test"
    # assert cliargs.test == "test"

# Generated at 2022-06-25 13:01:23.939335
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    try:
        x = CLIArgs({'a':'b', 'c':'d'})
    except TypeError:
        assert False
    else:
        assert True



# Generated at 2022-06-25 13:01:28.840203
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    '''
    A test for the CLIArgs constructor.
    '''
    options = ImmutableDict({'A': 'a', 'B': [1, 2, 3], 'C': [{'D': 4, 'E': [1, 2, 3]}]})
    c = CLIArgs.from_options(options)
    for key, value in options.items():
        assert c[key] == value



# Generated at 2022-06-25 13:01:30.140502
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs({'connection': 'local'})
    assert isinstance(global_cli_args, GlobalCLIArgs)



# Generated at 2022-06-25 13:01:35.110398
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    try:
        test_dict = {}
        test_clinum = CLIArgs(test_dict)
    except:
        assert False, 'Error: Cannot create instance'

# Generated at 2022-06-25 13:01:40.875483
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    gc = GlobalCLIArgs({'a1': 'b1', 'a2': {'b2': 'c2'}, 'a3': ['b3', 'c3']})
    assert gc.get('a2').get('b2') == 'c2'
    assert gc.get('a3')[1] == 'c3'
    gc.get('a1') == 'b1'

# Generated at 2022-06-25 13:01:45.357680
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_case_0()
    test_dict = {'a': 'a', 'b': 'b'}
    cliargs = CLIArgs(test_dict)
    assert isinstance(cliargs, Container) and isinstance(cliargs, Mapping) and isinstance(cliargs, Sequence)


# Generated at 2022-06-25 13:01:50.114554
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    a_b_c_singleton_0 = CLIArgs()


# Generated at 2022-06-25 13:01:54.793144
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {"arg1": 1, "arg2": [1, 2, 3], "arg3": {"foo": "bar"}, "arg4": "str"}
    cli_args = CLIArgs(args)
    assert cli_args == args


# Generated at 2022-06-25 13:01:58.644260
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    a = CLIArgs({'a': 1, 'b': 2})
    try:
        a['c'] = 3
    except Exception:
        print("Success! CLIArgs is immutable dict.")
    else:
        print("Fail! CLIArgs class is not immutable dict.")


# Generated at 2022-06-25 13:02:00.466506
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    CLIArgs({'key1': 'value1', 'key2': 'value2'})



# Generated at 2022-06-25 13:02:04.212277
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    a_b_c_singleton_0 = _ABCSingleton()
    a_b_c_singleton_1 = _ABCSingleton()
    assert a_b_c_singleton_0 == a_b_c_singleton_1

# Generated at 2022-06-25 13:02:05.445185
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    options = CLIArgs(vars(options))
    assert options


# Generated at 2022-06-25 13:02:06.661710
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    a_b_c_singleton = _ABCSingleton()



# Generated at 2022-06-25 13:02:09.382911
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils.common._collections_compat import Mapping
    global_cli_args = GlobalCLIArgs.from_options(Mapping())


# Generated at 2022-06-25 13:02:16.524256
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-25 13:02:18.600335
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    toplevel = {'my_argument': 1}
    assert CLIArgs(toplevel) == toplevel


# Generated at 2022-06-25 13:02:23.530796
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'foo':'bar', 'fizz':'buzz'}
    test_dict = CLIArgs(mapping)
    assert(isinstance(test_dict, dict))
    assert(test_dict['foo'] == 'bar')


# Generated at 2022-06-25 13:02:34.791343
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test that the constructor sets class attributes correctly
    """
    GlobalCLIArgs_0 = GlobalCLIArgs.from_options(ImmutableDict(a=1, b=2))
    GlobalCLIArgs_1 = GlobalCLIArgs.from_options(ImmutableDict(a=1, b=2))
    GlobalCLIArgs_2 = GlobalCLIArgs.from_options(ImmutableDict(c=3, d=4))

    # Test that the two instances are equal
    assert GlobalCLIArgs_0 == GlobalCLIArgs_1

    # Test that the two instances are not equal
    assert GlobalCLIArgs_0 != GlobalCLIArgs_2

    # Test that the two instances are the same object
    assert GlobalCLIArgs_0 is GlobalCLIArgs_1

    # Test that the two instances are not

# Generated at 2022-06-25 13:02:35.738755
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()



# Generated at 2022-06-25 13:02:40.753520
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a_b_c_singleton_0 = _ABCSingleton()
    GlobalCLIArgs()
    # AssertionError: Cannot re-initialize singleton GlobalCLIArgs.
    GlobalCLIArgs.__init__(1)



# Generated at 2022-06-25 13:02:41.747678
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()



# Generated at 2022-06-25 13:02:50.891228
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping_0 = {
        'a': {
            'b': {
                'c': 1,
                'd': [0, 1, 2],
                'e': {
                    'f': 0,
                    'g': 1
                }
            }
        },
        'h': None,
        'i': 'string',
        'j': 2
    }
    mapping_1 = {
        'a': {
            'b': {
                'c': 1,
                'd': (0, 1, 2),
                'e': {
                    'f': 0,
                    'g': 1
                }
            }
        },
        'h': None,
        'i': 'string',
        'j': 2
    }

    assert CLIArgs(mapping_0) == mapping_1

# Unit test

# Generated at 2022-06-25 13:02:53.159940
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs({'one': 1, 'two': '2'})
    assert global_cli_args == {'one': 1, 'two': '2'}

# Generated at 2022-06-25 13:02:54.993491
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_CLIArgs_object = CLIArgs({'key': 'value'})
    assert test_CLIArgs_object['key'] == 'value'



# Generated at 2022-06-25 13:02:57.522383
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs({'a': 'b', 'c': {'d': 'e'}})
    assert cli_args['a'] == 'b'
    assert cli_args['c'] == {'d': 'e'}


# Generated at 2022-06-25 13:03:04.163268
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    dict_mapping = {"key_1": "value_1", "key_2": "value_2", "key_3": "value_3"}
    global_cli_args = GlobalCLIArgs(dict_mapping)
    assert global_cli_args["key_1"] == "value_1", "Failed to retrieve value from key"
    assert global_cli_args["key_2"] == "value_2", "Failed to retrieve value from key"
    assert global_cli_args["key_3"] == "value_3", "Failed to retrieve value from key"


# Generated at 2022-06-25 13:03:10.961856
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args_0 = GlobalCLIArgs([])
    assert isinstance(global_cli_args_0, GlobalCLIArgs)
    assert isinstance(global_cli_args_0, CLIArgs)
    assert isinstance(global_cli_args_0, ImmutableDict)

test_case_0()
test_GlobalCLIArgs()

# Generated at 2022-06-25 13:03:11.813785
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()


# Generated at 2022-06-25 13:03:16.234107
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_data = {"test_key": "test_value"}
    cli_args = CLIArgs(test_data)
    assert(cli_args["test_key"] == "test_value")
    try:
        cli_args["test_key"] = "test_value1"
        assert(False)
    except TypeError:
        assert(True)



# Generated at 2022-06-25 13:03:17.217238
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()

# Generated at 2022-06-25 13:03:19.314925
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    a_b_c_singleton_0 = _ABCSingleton()
    assert callable(a_b_c_singleton_0)



# Generated at 2022-06-25 13:03:19.959466
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert GlobalCLIArgs({})



# Generated at 2022-06-25 13:03:24.688742
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from unittest.mock import MagicMock

    mock_metaclass = MagicMock()

    class TestClass_0(_ABCSingleton, metaclass=mock_metaclass):
        pass

    assert mock_metaclass.call_count == 1
    assert isinstance(TestClass_0, (Singleton, ABCMeta))



# Generated at 2022-06-25 13:03:27.637668
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        singleton_0 = _ABCSingleton()
    except TypeError as e:
        assert(False)
    assert(isinstance(singleton_0, _ABCSingleton))


# Generated at 2022-06-25 13:03:30.496074
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        _ABCSingleton()
    except TypeError as e:
        assert("Can't instantiate abstract class _ABCSingleton with "
               "abstract methods __instancecheck__") in str(e)

# Generated at 2022-06-25 13:03:33.232722
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs({'a': 0, 'b': 1})
    assert(cli_args['a'] == 0 and cli_args['b'] == 1)


# Generated at 2022-06-25 13:03:46.157090
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a_GlobalCLIArgs = GlobalCLIArgs()
    assert isinstance(a_GlobalCLIArgs, GlobalCLIArgs)
    # Test isinstance(Singleton, ABCMeta)
    assert isinstance(a_GlobalCLIArgs, Singleton)
    assert isinstance(a_GlobalCLIArgs, ABCMeta)
    # Test isinstance(GlobalCLIArgs, ImmutableDict)
    assert isinstance(a_GlobalCLIArgs, GlobalCLIArgs)
    assert isinstance(a_GlobalCLIArgs, ImmutableDict)
    # Test isinstance(GlobalCLIArgs, Mapping)
    assert isinstance(a_GlobalCLIArgs, Mapping)
    # Test isinstance(Singleton, Mapping)
    assert isinstance(a_GlobalCLIArgs, Mapping)
    # Test isinstance(ImmutableD

# Generated at 2022-06-25 13:03:49.754456
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    CLIArgs_object = CLIArgs({'a': '1', 'b': '2', 'c': '3'})
    assert(type(CLIArgs_object) == CLIArgs)


# Generated at 2022-06-25 13:03:58.474296
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert issubclass(CLIArgs, ImmutableDict) is True
    assert isinstance(CLIArgs(ImmutableDict({'a': {'b': {'c': {'d': 10}}}})), ImmutableDict)
    assert CLIArgs(ImmutableDict({'a': {'b': {'c': {'d': 10}}}})) == ImmutableDict({'a': {'b': {'c': {'d': 10}}}})
    assert CLIArgs(ImmutableDict({'a': {'b': {'c': {'d': 10}}}})).a.b.c.d == 10

# Generated at 2022-06-25 13:04:05.036317
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a_b_c_singleton_0 = _ABCSingleton()
    test_options = [{"ansible-playbook": "Testing Class GlobalCLIArgs"}, \
                    {"ansible-playgram": "Testing Class GlobalCLIArgs"}]
    for test_option in test_options:
        try:
            a_b_c_singleton_1 = a_b_c_singleton_0(test_option)
            assert isinstance(a_b_c_singleton_1, GlobalCLIArgs)
        except TypeError:
            assert True


# Generated at 2022-06-25 13:04:06.250369
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert (_ABCSingleton() is _ABCSingleton())


# Generated at 2022-06-25 13:04:09.784383
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {"string_key": "string_value"}
    a_cli_args_0 = CLIArgs(mapping)
    if a_cli_args_0["string_key"] != "string_value":
        raise ValueError("Mapping was not passed correctly to CLIArgs.__init__")


# Generated at 2022-06-25 13:04:13.357957
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()
    # Create a new object and check if it is strictly the same as the toplevel object
    a_b_c_singleton_1 = _ABCSingleton()
    assert a_b_c_singleton_1 is _ABCSingleton()


# Generated at 2022-06-25 13:04:22.397991
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs({"a": 1, "b": 2, "c": 3})
    assert cli_args['a'] == 1
    try:
        cli_args['a'] = 2
    except TypeError:
        pass
    else:
        assert False, "TypeError expected"
    assert cli_args['a'] == 1
    try:
        del cli_args['a']
    except TypeError:
        pass
    else:
        assert False, "TypeError expected"
    assert cli_args['a'] == 1
    try:
        cli_args['e'] = 5
    except TypeError:
        pass
    else:
        assert False, "TypeError expected"

# Generated at 2022-06-25 13:04:23.683087
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # GlobalCLIArgs.__init__()
    new_GlobalCLIArgs = GlobalCLIArgs()


# Generated at 2022-06-25 13:04:32.144782
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    print('\nin test_GlobalCLIArgs')
    test_map = {'one': 1, 'two': "two", 'three': 3.14}
    test_data = CLIArgs(test_map)
    print(type(test_data))
    print(test_data)
    # print(test_data.__dict__)
    print(test_data['one'])
    print(test_data['two'])
    print(test_data['three'])
    # test_data['one'] = "modified"  # will raise exception
    # del test_data['one']    # will raise exception



# Generated at 2022-06-25 13:04:39.858937
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Test case for creating an instance of class _ABCSingleton.

    """
    a_b_c_singleton_0 = _ABCSingleton()
    assert True

# Generated at 2022-06-25 13:04:40.868066
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()


# Generated at 2022-06-25 13:04:42.123910
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs(vars(options))


# Generated at 2022-06-25 13:04:45.773508
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs.from_options(['a', 'b', 'c'])

# Generated at 2022-06-25 13:04:50.281672
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    my_cli = CLIArgs({'foo': 'bar'})
    assert my_cli['foo'] == 'bar'
    assert my_cli.foo == 'bar'
    assert 'foo' in my_cli
    assert list(my_cli.keys()) == ['foo']
    my_cli['foo'] = 'baz'  # This is not allowed because CLIArgs is immutable



# Generated at 2022-06-25 13:04:52.334850
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs.from_options(None)
    assert isinstance(global_cli_args, GlobalCLIArgs)

# Generated at 2022-06-25 13:05:03.515548
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    import sys
    import unittest

    class _ABCSingletonTests(unittest.TestCase):
        def test_1_init(self):
            a_b_c_singleton_1 = _ABCSingleton()
            a_b_c_singleton_2 = _ABCSingleton()
            a_b_c_singleton_3 = _ABCSingleton()
            a_b_c_singleton_4 = _ABCSingleton()
            a_b_c_singleton_5 = _ABCSingleton()
            self.assertIsInstance(a_b_c_singleton_1, ABCMeta)
            self.assertIsInstance(a_b_c_singleton_2, Singleton)
            self.assertIsInstance(a_b_c_singleton_3, _ABCSingleton)

# Generated at 2022-06-25 13:05:07.759141
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_case_0()
    args = {'connection': 'network_cli', 'val': 'test_value', 'host': 'kvm_host'}
    cli_args = CLIArgs(args)
    assert isinstance(cli_args, (text_type, binary_type))


# Generated at 2022-06-25 13:05:08.372802
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()



# Generated at 2022-06-25 13:05:15.729871
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a_dict = {'a': 2, 'b': 3}
    a_dict_00 = {'a': 2, 'b': 3}
    a_dict_01 = {'b': 3, 'a': 2}
    a_dict_02 = {'a': 4, 'b': 3}

    a = GlobalCLIArgs(a_dict)
    b = GlobalCLIArgs(a_dict)
    c = GlobalCLIArgs(a_dict_00)
    d = GlobalCLIArgs(a_dict_01)
    e = GlobalCLIArgs(a_dict_02)

    assert a is b
    assert d is a
    assert c is a
    assert a is not e

    assert not (a == b)
    assert not (a == c)
    assert not (a == d)

# Generated at 2022-06-25 13:05:24.019186
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    a_b_c_singleton_1 = _ABCSingleton()
    a_b_c_singleton_2 = _ABCSingleton()
    assert (a_b_c_singleton_1 is a_b_c_singleton_2)


# Generated at 2022-06-25 13:05:27.278068
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Unit test for constructor of class GlobalCLIArgs
    GlobalCLIArgs({"hello": "world"})
    GlobalCLIArgs({})
    GlobalCLIArgs({"hello": "world", "argv": []})

    # Unit test for function GlobalCLIArgs.from_options
    args = GlobalCLIArgs.from_options(options=object())
    assert isinstance(args, GlobalCLIArgs)
    assert isinstance(args, ImmutableDict)


# Generated at 2022-06-25 13:05:29.905059
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    a = CLIArgs({"a": "A", "b": "B", "c": "C"},)
    assert a.a == "A"
    assert a.b == "B"
    assert a.c == "C"


# Generated at 2022-06-25 13:05:34.284306
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    grp = GlobalCLIArgs()
    grp['x'] = 1
    assert grp['x'] == 1, 'Grp not set correctly'
    assert grp[1] == 2, 'Grp not set correctly'


if __name__ == '__main__':
    test_case_0()
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:05:42.685445
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # testing a_b_c_singleton_0, a_b_c_singleton_1, a_b_c_singleton_2
    a_b_c_singleton_0 = _ABCSingleton()
    a_b_c_singleton_1 = _ABCSingleton()
    a_b_c_singleton_2 = _ABCSingleton()
    # test that the three objects are in fact the same
    assert a_b_c_singleton_0 is a_b_c_singleton_1
    assert a_b_c_singleton_1 is a_b_c_singleton_2
    # test that we can actually add a function to the metaclass
    def test_func(self, stuff):
        return stuff * self

# Generated at 2022-06-25 13:05:51.519471
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    mapping = {}
    mapping['one'] = 'two'
    mapping['three'] = {}
    mapping['three']['four'] = 'five'
    mapping['a'] = ['b', 'c']
    mapping['a'].append('d')
    mapping['a'].append({'e': 'f'})
    # Note: The following line will be overwritten in play_context.py when the GlobalCLIArgs
    # object is instantiated.  The ACLIArgs class should be used instead of GlobalCLIArgs if you
    # want to instantiate a CLIArgs object with different command line arguments in a separate
    # context.
    # Caching the CLIArgs variable allows us to spot whether any code is using the
    # GlobalCLIArgs variable from this module instead of the play_context.py module.
    global_cli_args = GlobalCL

# Generated at 2022-06-25 13:06:03.318752
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test 1: Create mutable dict and convert it by constructor
    a_b_c_dict_0 = {"a": "test_CLIArgs_0", "b": "test_CLIArgs_1"}
    a_b_c_dict_1 = {"c": "test_CLIArgs_2"}
    a_b_c_dict_0.update(a_b_c_dict_1)
    a_b_c_cliargs_0 = CLIArgs(a_b_c_dict_0)
    assert (type(a_b_c_cliargs_0) == ImmutableDict)

    # Test 2: Create immutable dict and convert it by constructor
    a_b_c_dict_0 = {"a": "test_CLIArgs_0", "b": "test_CLIArgs_1"}
   

# Generated at 2022-06-25 13:06:06.419135
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    temp_dict = {"a": 1, "b": 2, "c": 3}
    global_cli_args = GlobalCLIArgs(temp_dict)

    assert global_cli_args["a"] == 1



# Generated at 2022-06-25 13:06:07.308536
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()

# Generated at 2022-06-25 13:06:10.535711
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs({'a': 1, 'b': 2, 'c': 3})
    assert global_cli_args.a == 1
    assert global_cli_args.b == 2
    assert global_cli_args.c == 3

# Generated at 2022-06-25 13:06:27.898301
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a_b_c_singleton_0 = _ABCSingleton()
    # Initializing object of class 'GlobalCLIArgs'
    global_cli_args_0 = GlobalCLIArgs(Mapping())
    # Asserting that the 'GlobalCLIArgs' object is of class 'GlobalCLIArgs'
    assert isinstance(global_cli_args_0, GlobalCLIArgs)


# Generated at 2022-06-25 13:06:33.471064
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    empty_dict = {}
    empty_mapping = Mapping()

    test_dict = {'a': 1}
    test_mapping = Mapping({'a': 1})

    # Pass empty dict
    assert(CLIArgs({}) == empty_mapping)
    assert(CLIArgs({}) == empty_dict)

    # Pass dict with value
    assert(CLIArgs(test_dict) == test_mapping)
    assert(CLIArgs(test_mapping) == test_dict)


# Generated at 2022-06-25 13:06:36.793071
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    cli_args = GlobalCLIArgs.from_options(GlobalCLIArgs({'a':1,'b':2}))
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args, GlobalCLIArgs)
    assert cli_args == ImmutableDict({'a':1,'b':2})

# Unit tests for _make_immutable

# Generated at 2022-06-25 13:06:43.923763
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a_b_c_singleton_0 = _ABCSingleton()
    a_b_c_singleton_1 = _ABCSingleton()
    assert a_b_c_singleton_0 == a_b_c_singleton_1
    # allow creation of singleton once
    global_cli_args_0 = GlobalCLIArgs.from_options(dict())
    global_cli_args_1 = GlobalCLIArgs.from_options(dict())
    assert global_cli_args_0 == global_cli_args_1
    # allow modification of singleton
    global_cli_args_mutable = dict()
    global_cli_args_mutable['a'] = 'b'
    global_cli_args_0 = GlobalCLIArgs.from_options(global_cli_args_mutable)
    # verify check

# Generated at 2022-06-25 13:06:50.388248
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs({"key_1": "value_1"})
    assert cli_args["key_1"] == "value_1"
    assert cli_args.get("key_1") == "value_1"
    # Check that the dict can not be mutated
    try:
        cli_args["key_1"] = "value_2"
    except TypeError:
        assert True
    # Check that the dict is immutable
    assert cli_args["key_1"] == "value_1"
    # Check that the dict can not be deleted
    try:
        del cli_args["key_1"]
    except TypeError:
        assert True
    # Check that the dict is still there
    assert cli_args["key_1"] == "value_1"


# Generated at 2022-06-25 13:07:02.183463
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_data = {"a": "a", "b": "b", "c": "c"}
    test_data2 = {1: "a", 2: "b", 3: "c"}
    test_data3 = {"a": 1, "b": 2, "c": 3}
    test_data4 = {"a": "a", 4: "b", 3: {"a": "a", "b": "b", "c": "c"}}

# Generated at 2022-06-25 13:07:03.180567
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()



# Generated at 2022-06-25 13:07:05.675484
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a_b_c_singleton_0 = _ABCSingleton()

    # This is a normal __init__ for an object
    assert GlobalCLIArgs().__init__(1) == None


# Generated at 2022-06-25 13:07:09.536552
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mock_cli_args = {'test_key1': 'test_value1', 'test_key2': 'test_value2'}
    parsed_args = CLIArgs(mock_cli_args)
    assert parsed_args.test_key1 == 'test_value1'
    assert parsed_args.test_key2 == 'test_value2'


# Generated at 2022-06-25 13:07:11.322543
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {"a": 1}
    test_cli_args = CLIArgs(test_dict)
    assert len(test_dict) == len(test_cli_args)


# Generated at 2022-06-25 13:07:38.750011
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    a_b_c_singleton = _ABCSingleton()



# Generated at 2022-06-25 13:07:40.211079
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    cls = _ABCSingleton()
    assert(not cls.__instance)


# Generated at 2022-06-25 13:07:43.125244
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args_1 = CLIArgs({'a': 1, 'b': '2', })
    assert cli_args_1['a'] == 1
    assert cli_args_1['b'] == '2'


# Generated at 2022-06-25 13:07:43.988506
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs



# Generated at 2022-06-25 13:07:46.403917
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    print("\nTest constructor of class _ABCSingleton")
    test_case_0()
    print("End of test constructor of class _ABCSingleton")


# Generated at 2022-06-25 13:07:47.628724
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, ABCMeta)
    assert issubclass(_ABCSingleton, Singleton)
    assert _ABCSingleton is not ABCMeta
    assert _ABCSingleton is not Singleton


# Generated at 2022-06-25 13:07:52.825739
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    #options = vars(argparse.ArgumentParser().parse_args())
    parser = argparse.ArgumentParser(description="test")
    parser.add_argument('--debug', default="False", type=str, dest='debug', help="enable debug")
    parser.add_argument('--foo', default="None", type=str, dest='foo', help="foo help")
    args = vars(parser.parse_known_args()[0])
    options = args
    print("options: " + str(options))
    test_GlobalCLIArgs = GlobalCLIArgs(options)
    assert isinstance(test_GlobalCLIArgs, GlobalCLIArgs)


# Generated at 2022-06-25 13:07:55.160936
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test class GlobalCLIArgs
    """
    test_class = GlobalCLIArgs({})
    assert isinstance(test_class, ImmutableDict)
    assert '__class__' in test_class

# Generated at 2022-06-25 13:07:59.592421
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    test_dict = {"test_key_0": "test_value_0",
                 "test_key_1": "test_value_1"}
    test_cliargs = CLIArgs(test_dict)
    assert test_cliargs['test_key_0'] == 'test_value_0'
    assert test_cliargs['test_key_1'] == 'test_value_1'
    assert len(test_cliargs) == 2

# Generated at 2022-06-25 13:08:02.846046
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = _make_immutable(dict(key1="value1", key2=2, key3=dict(key4="value4")))
    cli_args = CLIArgs(test_dict)
    assert cli_args == test_dict



# Generated at 2022-06-25 13:08:39.554318
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert hasattr(CLIArgs, 'from_options')
    # Create an instance of class CLIArgs using constructor
    c_l_i_args_0 = CLIArgs(b'\xcc\x1a\xa0\x1f\xd2\xeb\xe6\xd5\x8a\x88\xac\xb6\x1e\xa1')
    assert isinstance(c_l_i_args_0, CLIArgs)
    assert isinstance(c_l_i_args_0, Mapping)
    assert hasattr(c_l_i_args_0, '__call__')

# Generated at 2022-06-25 13:08:46.032136
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bytes_0 = b'x\x9d\\\xe8\xa5Mj\x1cd\xf1Ns:\xdc'
    c_l_i_args_0 = CLIArgs(bytes_0)
    str_0 = str(c_l_i_args_0)
    assert str_0 == "ImmutableDict({b'x\\xe9\\\\\\xe8\\xa5Mj\\x1cd\\xf1Ns:\\xdc': b'x\\xe9\\\\\\xe8\\xa5Mj\\x1cd\\xf1Ns:\\xdc'})"
    str_1 = repr(c_l_i_args_0)

# Generated at 2022-06-25 13:08:50.501078
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bytes_0 = b'\x9d\\\xe8\xa5Mj\x1cd\xf1Ns:\xdc'
    g_c_l_i_args_0 = GlobalCLIArgs(vars(bytes_0))
# Test case for function _make_immutable

# Generated at 2022-06-25 13:08:56.481188
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {'a': 1, 'b': 2, 'c': 3}
    c_l_i_args_0 = CLIArgs(args)
    temp_dict_0 = {}
    for key, value in args.items():
        if isinstance(value, Container):
            temp_dict_0[key] = _make_immutable(value)
        else:
            temp_dict_0[key] = value

    assert c_l_i_args_0 == temp_dict_0



# Generated at 2022-06-25 13:08:58.861038
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    c_l_i_args_0 = CLIArgs()
    global_c_l_i_args_0 = GlobalCLIArgs()
    pass

# Generated at 2022-06-25 13:09:03.698888
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    bytes_0 = b'\x9d\\\xe8\xa5Mj\x1cd\xf1Ns:\xdc'
    _abc_singleton_0 = _ABCSingleton()


# Generated at 2022-06-25 13:09:10.911971
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bytes_0 = b'\x9d\\\xe8\xa5Mj\x1cd\xf1Ns:\xdc'
    c_l_i_args_0 = CLIArgs(bytes_0)
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_

# Generated at 2022-06-25 13:09:13.786403
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {'c': ['c'], 'a': 'a'}
    c_l_i_args_0 = CLIArgs(args)
    assert c_l_i_args_0 == args

# Generated at 2022-06-25 13:09:23.887612
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.config import read_config_file
    from ansible.cli import CLI
    from ansible.cli.arguments import option_helpers as opt_help
    from ansible.constants import CLIConstants

    my_cli_constant = CLIConstants()
    my_cli = CLI(constants=my_cli_constant)
    my_cli_args = my_cli.parse()
    config_args = read_config_file(my_cli_args.config_file)
    config_args = opt_help.merge_vars_files(config_args)
    config_args = opt_help.merge_vars(config_args)
    # Constructor of GlobalCLIArgs
    GlobalCLIArgs.from_options(my_cli_args)

# Generated at 2022-06-25 13:09:24.763765
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert True



# Generated at 2022-06-25 13:10:23.477436
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test constructor of class CLIArgs
    c_l_i_args_0 = CLIArgs(set(['c1', 'c2', 'c2', 'c3', 'c7', 'c6', 'c6', 'c6', 'c6', 'c6']))
    # Test instance of class CLIArgs
    assert isinstance(c_l_i_args_0, CLIArgs)
    # Test convertibility to ImmutableDict
    assert isinstance(c_l_i_args_0, ImmutableDict)
    # Test that the set is indeed converted to tuple inside
    assert isinstance(c_l_i_args_0.keys(), tuple)

if __name__ == "__main__":
    test_case_0()
    test_CLIArgs()

# Generated at 2022-06-25 13:10:34.578742
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bytes_0 = b'\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    c_l_i_args_0 = GlobalCLIArgs(bytes_0)
    bytes_1 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'