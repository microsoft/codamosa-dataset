

# Generated at 2022-06-25 13:00:45.428653
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bytes_0 = b'\xef\xe1\x7f'
    cli_args_0 = CLIArgs(bytes_0)


# Generated at 2022-06-25 13:00:49.977201
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = ImmutableDict({'test_key': 'test_value'})
    cli_args_1 = CLIArgs(mapping)
    keys = cli_args_1.keys()
    assert keys == set(['test_key']), keys
    values = cli_args_1.values()
    assert values == ('test_value', ), values


# Generated at 2022-06-25 13:00:51.025182
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()


# Generated at 2022-06-25 13:00:53.459066
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bytes_0 = b'\xef\xe1\x7f'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)


# Generated at 2022-06-25 13:00:55.697376
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Command line arguments.
    bytes_0 = b'\xef\xe1\x7f'
    cliArgs_0 = CLIArgs(bytes_0)


# Generated at 2022-06-25 13:00:58.831929
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    _abc_singleton_0 = _ABCSingleton()


if __name__ == '__main__':
    test_case_0()
    test__ABCSingleton()

# Generated at 2022-06-25 13:01:03.832568
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class test1(metaclass=_ABCSingleton):
        pass
    test2 = test1()
    assert(len(test1) == 1)
    assert(repr(test1) == '<class \'test1\'>')
    assert(len(test2) == 1)
    assert(repr(test2) == '<test1 object>')


# Generated at 2022-06-25 13:01:05.056673
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert hasattr(_ABCSingleton, '__init__') == True


# Generated at 2022-06-25 13:01:08.644001
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bytes_0 = b'\xef\xe1\x7f'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)


if __name__ == '__main__':
    test_case_0()
    test_GlobalCLIArgs()
    print('All tests completed successfully!')

# Generated at 2022-06-25 13:01:11.571767
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        test_case_1()
        test_case_0()
        raise Exception('Unit test _ABCSingleton failed')
    except Exception as e:
        pass


# Generated at 2022-06-25 13:01:15.151407
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()



# Generated at 2022-06-25 13:01:17.945507
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    b0 = _ABCSingleton()
    import inspect
    print (inspect.isclass(_ABCSingleton))
    assert b0.__bases__ == (Singleton, ABCMeta)


# Generated at 2022-06-25 13:01:19.276820
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # testing that the constructor works properly
    assert test_case_0() is None

# Generated at 2022-06-25 13:01:20.923747
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    with open('options.txt', 'r') as f:
        for line in f:
            pass


# Generated at 2022-06-25 13:01:24.218813
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Check that __init__ sets flags to the correct values
    flag_dict = {'foo_flag': True, 'bar_flag': False}
    test_obj = GlobalCLIArgs(flag_dict)

    assert test_obj == flag_dict


# Generated at 2022-06-25 13:01:29.818418
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-25 13:01:36.002641
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    a_b_c_singleton0 = _ABCSingleton()

    assert(id(a_b_c_singleton0) == id(_ABCSingleton()))
    assert(isinstance(a_b_c_singleton0, Singleton))


# Generated at 2022-06-25 13:01:38.639585
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    CLIArgs_0 = CLIArgs({"c": "I am c"})
    assert CLIArgs_0.get("c") == "I am c"


# Generated at 2022-06-25 13:01:48.365201
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    import six
    # Test case: no options, no positional arguments
    class ABCSingletonClass_0(GlobalCLIArgs):
        def __init__(self):
            super(_ABCSingleton, self).__init__()
    a_b_c_singleton_0 = ABCSingletonClass_0()
    assert(a_b_c_singleton_0)
    # Test case: one option, no positional arguments
    with six.assertRaisesRegex(AssertionError, 'required positional argument'):
        class ABCSingletonClass_1(GlobalCLIArgs):
            def __init__(self, positional_argument):
                super(_ABCSingleton, self).__init__()
        a_b_c_singleton_1 = ABCSingletonClass_1()
    # Test case: one option and positional argument

# Generated at 2022-06-25 13:01:55.849745
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'a': 1, 'b': 2, 'c': 3}
    cli_args = CLIArgs(mapping)
    assert isinstance(cli_args, CLIArgs)

    mapping['d'] = 4
    assert 'd' not in cli_args
    assert isinstance(cli_args, CLIArgs)



# Generated at 2022-06-25 13:02:01.076091
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bytes_0 = b'\xef\xe1\x7f'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)
    assert isinstance(global_c_l_i_args_0, CLIArgs)


# Generated at 2022-06-25 13:02:10.772196
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert callable(CLIArgs)
    bytes_0 = b'\xa9\xfa\xb2\xcc\xce\xf1\x04\xc8\x84\x02\x0b\x85\x9a\xdf\xfc\xb1\xf7\xcc\xfe\xdd\xa2\xfe\x9a\x0c\x00\xba\xbb'
    int_0 = 0
    bytes_1 = b'\x8b\xdb\x05\xd2\xc0\x8e\x90\x1e\x1a\x9e\x01\x02\x15\x99\x9e\xc3\x92'

# Generated at 2022-06-25 13:02:14.753714
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bytes_0 = b'\x5c\x89\xc0'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)
#     print (global_c_l_i_args_0)


if __name__ == "__main__":
    test_case_0()
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:02:24.516727
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bytes_0 = b'\xef\xe1\x7f'
    c_l_i_args_0 = CLIArgs(bytes_0)
    bytes_1 = b'\xef\xe1\x7f'
    c_l_i_args_1 = CLIArgs(bytes_1)
    pytest.assume(c_l_i_args_0 == c_l_i_args_0)
    pytest.assume(c_l_i_args_0 != c_l_i_args_1)
    pytest.assume(c_l_i_args_0.items() is not c_l_i_args_0)

if __name__ == '__main__':
    import pytest
    pytest.main(['-xrf'])

# Generated at 2022-06-25 13:02:27.827249
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bytes_0 = b'\xef\xe1\x7f'
    global_c_l_i_args_0 = CLIArgs(bytes_0)


# Generated at 2022-06-25 13:02:33.323585
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import GlobalCLIArgs
    bytes_0 = b'\xef\xe1\x7f'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)
    with pytest.raises(TypeError):
        GlobalCLIArgs(b'\xef\xe1\x7f')


# Generated at 2022-06-25 13:02:35.690932
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bytes_0 = b'\xef\xe1\x7f'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)


# Generated at 2022-06-25 13:02:36.805609
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    pass



# Generated at 2022-06-25 13:02:46.587316
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bytes_0 = b'\xef\xe1\x7f'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)
    # AssertionError: Expected singleton object GlobalCLIArgs, got <__main__.GlobalCLIArgs object at 0x00000...>
    #     global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)
    # AssertionError: Expected singleton object GlobalCLIArgs, got <__main__.GlobalCLIArgs object at 0x00000...>
    #    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)

# Generated at 2022-06-25 13:02:50.859506
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bytes_0 = b'\x7f\xef\xe1'
    global_c_l_i_args_0 = CLIArgs.from_options(bytes_0)

    assert isinstance(global_c_l_i_args_0, GlobalCLIArgs)

    assert isinstance(global_c_l_i_args_0, ImmutableDict)

test_case_0()

# Generated at 2022-06-25 13:02:55.247749
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    b'this test needs to be written'


# Generated at 2022-06-25 13:03:00.024248
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    bytes_0 = b'\xef\xe1\x7f'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)
    temp_dunder_0 = global_c_l_i_args_0.__dict__
    assert temp_dunder_0['_ABCSingleton__instance'] == global_c_l_i_args_0


# Generated at 2022-06-25 13:03:06.572627
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bytes_0 = b'\xef\xe1\x7f'
    cli_args_0 = CLIArgs.from_options(bytes_0)
    bytes_1 = b'\xef\xe1\x7f'
    cli_args_1 = CLIArgs(bytes_1)
    bytes_2 = b'\xef\xe1\x7f'
    cli_args_2 = CLIArgs(bytes_2)
    assert repr(cli_args_0) == repr(cli_args_1) == repr(cli_args_2)


# Generated at 2022-06-25 13:03:13.447451
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    module_path = 'tests/module_utils/arguments.py'

    # If a value from the command line is intended to be a list, it is stored with comma
    # separated values.  You need to make sure that your test uses a comma separated argument
    # when setting up your CLIArgs so that it behaves the same as the CLIArgs that Ansible
    # would create when parsing command line options.
    bytes_0 = b'./hacking/env-setup -q'
    global_c_l_i_args_0 = GlobalCLIArgs.from_options(bytes_0)

# Generated at 2022-06-25 13:03:15.662252
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bytes_0 = b'\xef\xe1\x7f'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)


# Generated at 2022-06-25 13:03:22.215743
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    bytes_0 = b'\xef\xe1\x7f'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)
    assert isinstance(global_c_l_i_args_0, Singleton)

    # Test __init__()
    bytes_0 = b'\xef\xe1\x7f'
    global_c_l_i_args_0 = CLIArgs(bytes_0)
    assert isinstance(global_c_l_i_args_0, ImmutableDict)


# Generated at 2022-06-25 13:03:23.464230
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    new_instance = _ABCSingleton()


# Generated at 2022-06-25 13:03:25.732989
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        _ABCSingleton()
    except:
        pass
    else:
        assert 0, 'Failed to create instance of _ABCSingleton'


# Generated at 2022-06-25 13:03:27.559369
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 13:03:33.621041
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    m_0 = {}
    global_c_l_i_args_0 = GlobalCLIArgs(m_0)
    assert isinstance(global_c_l_i_args_0, GlobalCLIArgs)
    assert isinstance(global_c_l_i_args_0, CLIArgs)
    assert isinstance(global_c_l_i_args_0, ImmutableDict)
    assert len(global_c_l_i_args_0) == 0


# Generated at 2022-06-25 13:03:41.298322
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_case_0()
    print('GlobalCLIArgs class constructor test cases run')

if __name__ == "__main__":
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:03:46.896419
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bytes_0 = b'\xef\xe1\x7f'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)

if __name__ == '__main__':
    import sys
    import unittest
    suite = unittest.TestLoader().loadTestsFromTestCase(locals()[sys.argv[1]])
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-25 13:03:55.464774
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bytes_0 = b'\xef\xe1\x7f'
    global_c_l_i_args_0 = GlobalCLIArgs.__new__(GlobalCLIArgs)
    # Assert instance creation
    assert isinstance(global_c_l_i_args_0, GlobalCLIArgs)
    # Assert __init__()
    assert hasattr(global_c_l_i_args_0, '__init__')
    assert callable(global_c_l_i_args_0.__init__)
    # Call __init__()
    global_c_l_i_args_0.__init__(bytes_0)



# Generated at 2022-06-25 13:04:05.967986
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    global_c_l_i_args_0 = GlobalCLIArgs(b'\xef\xe1\x7f')
    # __init__()
    # TODO: Improve
    # assert_equal(expected, _ABCSingleton.__init__(*args, **kwargs))
    # assert_equal(expected, _ABCSingleton.__new__(S, *args, **kwargs))
    # assert_equal(expected, _ABCSingleton.__reduce__())
    # assert_equal(expected, _ABCSingleton.__reduce_ex__(protocol))
    # assert_equal(expected, _ABCSingleton.__repr__())
    # assert_equal(expected, _ABCSingleton.__setstate__(state))
    # assert_equal(expected, _ABCSingleton.__sizeof__())


# Generated at 2022-06-25 13:04:08.225439
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bytes_0 = b'd\xbc'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)


# Generated at 2022-06-25 13:04:12.174651
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bytes_0 = b'\xef\xe1\x7f'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)


if __name__ == '__main__':
    import sys
    import pytest

    pytest.main(list(sys.argv))

# Generated at 2022-06-25 13:04:21.335434
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-25 13:04:30.870543
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.display import Display
    display = Display()
    # Create a Mock Display object to test passing options to CLIArgs
    class Display(Display):
        def __init__(self):
            self.verbosity = 0
            self.debug = False
            self.deprecated = True
            self.verbose = True
            self.deprecate_on_update = False
            self.verbose_on_update = True
            self.base_url = 'https://example.com'
            self.pass_fail_on_change = False
            self.timeout = 45

    display_0 = Display()
    # Create a Mock Options object that doesn't require argparse to create
    class Options(object):
        def __init__(self, display):
            self.verbosity = display.verbosity

# Generated at 2022-06-25 13:04:35.517928
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    bytes_0 = b'\xef\xe1\x7f'
    bytes_1 = b'\xef\x08\x7f'
    b_1 = _ABCSingleton()
    b_2 = _ABCSingleton(bytes_0)
    b_3 = _ABCSingleton(bytes_1)


# Generated at 2022-06-25 13:04:37.901391
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bytes_0 = b'\xef\xe1\x7f'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)

# Generated at 2022-06-25 13:04:51.684665
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Test for subclass of Meta
    assert issubclass(_ABCSingleton, ABCMeta), "Check if the class _ABCSingleton is a subclass of ABCMeta"


# Generated at 2022-06-25 13:04:55.723187
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bytes_0 = b'\xef\xe1\x7f'
    int_0 = 4
    dict_0 = {bytes_0: int_0}
    global_c_l_i_args_0 = GlobalCLIArgs(dict_0)

# Generated at 2022-06-25 13:04:58.881485
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    exit_code, output = get_exception_exit_code_and_output(test_case_0)
    assert exit_code == 0

# Generated at 2022-06-25 13:05:00.369970
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    assert isinstance(_ABCSingleton, type) == True


# Generated at 2022-06-25 13:05:03.153740
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    bytes_1 = b'\xe6\x85\x91'
    _ABCSingleton_1 = _ABCSingleton(bytes_1)
    assert _ABCSingleton_1._instance is None


# Generated at 2022-06-25 13:05:06.748990
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bytes_0 = b'\xef\xe1\x7f'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)
    assert True # TODO: implement your test here



# Generated at 2022-06-25 13:05:08.971992
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bytes_0 = b'\xef\xe1\x7f'
    cli_args_0 = GlobalCLIArgs(bytes_0)
    
    assert (cli_args_0.get(b'\xef\xe1\x7f'))



# Generated at 2022-06-25 13:05:16.903435
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils import cli_args
    from ansible.module_utils.common.collections import ImmutableDict
    global_c_l_i_args_0 = cli_args.GlobalCLIArgs(b'\xef\xe1\x7f')
    assert isinstance(global_c_l_i_args_0, cli_args.CLIArgs)
    assert isinstance(global_c_l_i_args_0, ImmutableDict)



# Generated at 2022-06-25 13:05:21.698127
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Test with a class that inherits from _ABCSingleton
    class class_with_metaclass(with_metaclass(_ABCSingleton)):
        pass
    # Test with a class that inherits from _ABCSingleton, but also implements __eq__
    class class_with_metaclass2(with_metaclass(_ABCSingleton)):
        def __eq__(self, other):
            return True


# Generated at 2022-06-25 13:05:22.275732
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
  test_case_0()


# Generated at 2022-06-25 13:06:08.579888
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    print('Testing GlobalCLIArgs init')
    bytes_0 = b'\xef\xe1\x7f'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)
    # Test for the presence of an exception
    try:
        global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)
    except:
        print('Exception caught')
    finally:
        print('Complete')
    # Test for the presence of an exception
    try:
        global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)
    except:
        print('Exception caught')
    finally:
        print('Complete')
    # Test for the presence of an exception

# Generated at 2022-06-25 13:06:12.856994
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bytes_0 = b'\xde\xd3\x13\xca\xf3'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)
    global_c_l_i_args_0 = GlobalCLIArgs.from_options(None)
    assert len(global_c_l_i_args_0) == 0


# Generated at 2022-06-25 13:06:13.863978
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert GlobalCLIArgs is CLIArgs


# Generated at 2022-06-25 13:06:22.650413
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    bytes_1 = b'\x16\x88\x80\xb7\x93\xcf'
    cli_args_1 = CLIArgs(bytes_1)
    assert cli_args_1.get_headers() == '\x16\x88\x80\xb7\x93\xcf'
    cli_args_2 = CLIArgs(['\x11\xaf\x91\xaf\xaf\xaf\xaf\xaf\xaf'])
    assert cli_args_2.get_headers() == '\x11\xaf\x91\xaf\xaf\xaf\xaf\xaf\xaf'

# Generated at 2022-06-25 13:06:28.452504
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict_0 = {'q': {'f': 'u', 'r': ['r', [{'v': 'h'}], 'j', ['z', ['d', {'w': 'x'}]]]}, 'm': 's', 'g': 'a'}
    cli_args_0 = CLIArgs(dict_0)
    assert cli_args_0 is not None


# Generated at 2022-06-25 13:06:30.091985
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bytes_0 = b'\xef\xe1\x7f'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)
    # from_options


# Generated at 2022-06-25 13:06:31.842177
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()

if __name__ == '__main__':
    test__ABCSingleton()

# Generated at 2022-06-25 13:06:34.234479
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bytes_0 = b'\xef\xe1\x7f'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 13:06:38.109429
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bytes_0 = b'\xef\xe1\x7f'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)
    assert isinstance(global_c_l_i_args_0.__class__, type)
    assert len(global_c_l_i_args_0) == 3
    assert global_c_l_i_args_0 != {'\xef': '\xe1', 'e': '\x7f'}



# Generated at 2022-06-25 13:06:42.297326
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    with pytest.raises(TypeError):
        GlobalCLIArgs(7)
    with pytest.raises(TypeError):
        GlobalCLIArgs({})
    with pytest.raises(TypeError):
        GlobalCLIArgs(None)
    with pytest.raises(TypeError):
        GlobalCLIArgs(True)
    with pytest.raises(TypeError):
        GlobalCLIArgs(GlobalCLIArgs)


# Generated at 2022-06-25 13:07:35.094471
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # TODO: Check args
    cli_args_0 = GlobalCLIArgs()

test_case_0()
test_GlobalCLIArgs()

# Generated at 2022-06-25 13:07:38.921114
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    try:
        print("in test_CLIArgs()")
        s = b'\xef\xe1\x7f'
        options = CLIArgs(s)
        print(type(options))
    except Exception as ex:
        print("test_CLIArgs()  Exception: " + ex.__str__())


# Generated at 2022-06-25 13:07:40.054442
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    abc_singleton_0 = _ABCSingleton()


# Generated at 2022-06-25 13:07:48.586965
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.parsing.utils.sensible_yaml import sensible_yaml_representer
    from ansible.utils.vars import combine_vars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    to_text(161803398)
    cli_args_0 = {}
    to_text(cli_args_0)
    sensible_yaml_representer()
    combine_vars()
    AnsibleUnsafeText()
    immutable_dict_0 = ImmutableDict(cli_args_0)

# Generated at 2022-06-25 13:07:49.935399
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert isinstance(test_case_0, _ABCSingleton)

test__ABCSingleton()

# Generated at 2022-06-25 13:07:53.699574
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    bytes_0 = b'\xef\xe1\x7f'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)
    # There is no function to test __new__, so just make sure the object is created and it is a
    # GlobalCLIArgs object
    assert isinstance(global_c_l_i_args_0, GlobalCLIArgs)
    assert isinstance(global_c_l_i_args_0, ImmutableDict)

test__ABCSingleton()


# Generated at 2022-06-25 13:08:01.419039
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bytes_0 = b'\xef\xe1\x7f'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)
    assert global_c_l_i_args_0.get_dict() == bytes_0

    bytes_1 = b'\x7f\xe1\x90\x1c\x46\x97'
    global_c_l_i_args_1 = GlobalCLIArgs(bytes_1)
    assert global_c_l_i_args_1.get_dict() == bytes_1

    bytes_2 = b'\x7f\xe1\x90\x1c\x46\x97'
    global_c_l_i_args_2 = GlobalCLIArgs(bytes_2)
    assert global_c_l

# Generated at 2022-06-25 13:08:02.792396
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bytes_0 = b'\xef\xe1\x7f'
    global_cl_i_args_0 = CLIArgs(bytes_0)


# Generated at 2022-06-25 13:08:08.967886
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Test instantiation of class GlobalCLIArgs.
    print('Called test_GlobalCLIArgs')
    bytes_0 = b'\xef\xe1\x7f'
    # TypeError: 'str' object does not support item assignment
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)
    # TODO: Verify that every argument is of the right type
    # Constructor of GlobalCLIArgs should be working by this point
    pass


# Generated at 2022-06-25 13:08:16.130586
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bytes_0 = b'\xe1]\xcc\xe4\x01\xa9\x8d\x0c\x89>T\xe1\xc7\x85\x82\xe0\x1a\x8f\xe2\x85\xac\x82\x8f\x8a\x1d\x9f\x8a\x1d\x9f\x8a\x1d'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)

if __name__ == '__main__':
    test_case_0()
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:10:03.212145
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bytes_0 = b'\xef\xe1\x7f'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)


test_case_0()

# Generated at 2022-06-25 13:10:06.534810
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import MutableMapping
    from ansible.module_utils.common.json_utils import raw_dict as _raw_dict
    test_case_0()

if __name__ == '__main__':
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:10:12.153373
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bytes_0 = b'\xef\xe1\x7f'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)
    # assert global_c_l_i_args_0 == <object object at 0x798caf8>, "The objecs are not equal"

# Generated at 2022-06-25 13:10:13.417848
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bytes_0 = b'\xe4'
    c_l_i_args_0 = CLIArgs(bytes_0)


# Generated at 2022-06-25 13:10:14.722259
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test for class GlobalCLIArgs
    global_c_l_i_args_0 = test_case_0()


# Generated at 2022-06-25 13:10:15.929719
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    opts = dict(start_at_task='main')
    cli_args_0 = CLIArgs(opts)


# Generated at 2022-06-25 13:10:17.777606
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, Singleton)
    assert issubclass(_ABCSingleton, ABCMeta)



# Generated at 2022-06-25 13:10:20.745309
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bytes_0 = b'\xef\xe1\x7f'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)
    bytes_1 = b'\xee\xed\xde'
    c_l_i_args_0 = GlobalCLIArgs(bytes_1)


# Generated at 2022-06-25 13:10:22.515544
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bytes_0 = b'\xef\xe1\x7f'
    cli_args_0 = CLIArgs(bytes_0)

test_CLIArgs()

# Generated at 2022-06-25 13:10:23.578058
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert isinstance(_ABCSingleton(GlobalCLIArgs), Singleton)