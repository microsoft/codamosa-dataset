

# Generated at 2022-06-25 13:00:44.004088
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    bytes_0 = b'\x9d\xbe\x8c\xcf'
    _a_b_c_singleton_0 = _ABCSingleton(bytes_0)


# Generated at 2022-06-25 13:00:49.786244
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    bytes_0 = b'\x81\x80\x9f\x9c'
    _abc_singleton_0 = _ABCSingleton(bytes_0)

    bytes_0 = b'\x9e\x84\x99\x8f'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)
    global_c_l_i_args_1 = GlobalCLIArgs(bytes_0)



# Generated at 2022-06-25 13:00:58.234903
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping_0 = {'P': 6, '=\x1e3\x0b6@\x1d\x1c\x0bT\x16\x17\x0f\x1a\x1b\x0c\x19\x1d\x17\x0f\x1a\x1b\x0c\x19': 62, 'r': 28}
    cli_args_0 = CLIArgs(mapping_0)
    assert (cli_args_0 == mapping_0)
    mapping_1 = {}
    cli_args_1 = CLIArgs(mapping_1)
    assert (cli_args_1 == mapping_1)
    dict_0 = {'1': '', '2': '2', '3': '3'}

# Generated at 2022-06-25 13:01:07.796250
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton):
        pass

    class Bar(_ABCSingleton):
        pass

    with pytest.raises(AssertionError):
        class Baz(_ABCSingleton):
            pass

    with pytest.raises(AssertionError):
        class Baz(_ABCSingleton):
            pass

        class Foobar(_ABCSingleton):
            pass



# Generated at 2022-06-25 13:01:11.534892
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    print("Unit test for constructor GlobalCLIArgs")
    bytes_0 = b'\xd9\xe5\x83\x8c'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)

test_GlobalCLIArgs()

# Generated at 2022-06-25 13:01:14.987066
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Create a _ABCSingleton object for testing
    test_obj = _ABCSingleton()
    # Get the value of $__instance
    test_value = test_obj.__instance
    # Check if the test_value is None
    assert test_value is None



# Generated at 2022-06-25 13:01:17.702472
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bytes_0 = b'\xd9\xe5\x83\x8c'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)



# Generated at 2022-06-25 13:01:20.482354
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bytes_0 = b'\xd9\xe5\x83\x8c'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)


# Generated at 2022-06-25 13:01:21.383837
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_case_0()


# Generated at 2022-06-25 13:01:30.050560
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # instantiating GlobalCLIArgs object for bytes_0
    bytes_0 = b'\xd9\xe5\x83\x8c'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)
    # making it immutable
    global_c_l_i_args_0 = _make_immutable(global_c_l_i_args_0)
    # instantiating GlobalCLIArgs object for bytes_1
    bytes_1 = b'\xce\x85\x7f\x8f\x83\x9c\x88'
    global_c_l_i_args_1 = GlobalCLIArgs(bytes_1)
    # making it immutable

# Generated at 2022-06-25 13:01:46.100155
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict_0 = {'nR1!u': 'Vse@b', 'K*V{h': 'Y6U*A', 'lX6T': '_j0$s', 'eW|}': '!s]-R'}
    c_l_i_args_2 = CLIArgs(dict_0)
    dict_1 = {'rM': 'nR1!u', 'Xo)': 'K*V{h', 'eW|}': 'lX6T', 'vZ': 'eW|}'}
    c_l_i_args_3 = CLIArgs(dict_1)
    c_l_i_args_4 = CLIArgs(dict_1)

# Generated at 2022-06-25 13:01:49.696828
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert all(hasattr(__metaclass__, attr) for attr in ('__abstractmethods__', '__instancecheck__', '__subclasscheck__'))


# Generated at 2022-06-25 13:02:01.601512
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    dict_0 = {'a': 1}
    c_l_i_args_0 = CLIArgs(dict_0)
    c_l_i_args_0.from_options(c_l_i_args_0)
    c_l_i_args_0 = dict_0
    global_c_l_i_args_0 = GlobalCLIArgs()
    assert isinstance(global_c_l_i_args_0, GlobalCLIArgs)
    # Test to see if the Singleton works
    global_c_l_i_args_1 = GlobalCLIArgs()
    assert id(global_c_l_i_args_0) == id(global_c_l_i_args_1)
    assert isinstance(global_c_l_i_args_0, GlobalCLIArgs)


# Generated at 2022-06-25 13:02:11.065436
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    global_c_l_i_args_0 = GlobalCLIArgs()
    global_c_l_i_args_1 = GlobalCLIArgs()
    # Make sure it's a singleton
    assert global_c_l_i_args_0 is global_c_l_i_args_1
    # Make sure __new__ was called (used by Singleton class)
    assert global_c_l_i_args_0 is not global_c_l_i_args_1
    # Make sure __init__ wasn't called (used by Singleton class)
    assert global_c_l_i_args_0 == global_c_l_i_args_1
    # Make sure we can call superclass methods from a subclass (used by Singleton class)
    assert global_c_l_i_args_0.__class

# Generated at 2022-06-25 13:02:12.066066
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()



# Generated at 2022-06-25 13:02:13.951257
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    print("Testing construction")
    test_case_0()


# Generated at 2022-06-25 13:02:15.700110
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    with pytest.raises(TypeError):
        _ABCSingleton()


# Generated at 2022-06-25 13:02:19.393800
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    global _ABCSingleton
    global CLIArgs
    global ImmutableDict
    global type

    # Test if object is singleton

    # Test if object is of correct type
    assert isinstance(c_l_i_args_0, c_l_i_args_0.__class__)


# Generated at 2022-06-25 13:02:20.962784
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    # Construction of object is tested by all other tests
    # test_case_0()
    pass

# Generated at 2022-06-25 13:02:26.954867
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Resetting the singleton
    GlobalCLIArgs.__init__(GlobalCLIArgs)
    c_l_i_args_0 = GlobalCLIArgs.__new__(GlobalCLIArgs)
    c_l_i_args_0.__init__()
    # Create an instance of GlobalCLIArgs without new keyword
    assert True


# Generated at 2022-06-25 13:02:42.926036
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    global_c_l_i_args_0 = GlobalCLIArgs(dict_0)

if __name__ == '__main__':
    test__ABCSingleton()
    test_case_0()

# Generated at 2022-06-25 13:02:46.387681
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    global_c_l_i_args_0 = GlobalCLIArgs(dict_0)

# Generated at 2022-06-25 13:02:47.690834
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_case_0()

# Generated at 2022-06-25 13:02:48.667111
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    _ABCSingleton()


# Generated at 2022-06-25 13:02:53.175381
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    c_l_i_args_0 = CLIArgs(dict_0)

    # Testing if an object is an instance of a class
    assert isinstance(c_l_i_args_0, CLIArgs)


# Generated at 2022-06-25 13:03:02.230911
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    dict_0 = {'DUZcO': (0 + 1), 'NUj': '0v(TmtgV8%cS#', 'B7Y2X9': (((8 + 8) + 8) + 8), 'TcT': 'Vu%S{G<7RQ+9}A', 'WhGC3': 'nJ#s<o6d+w[-J2', 'z': '@YU6X>E6,b%6^:', 'p': ('@>|/' + '|$/O'), 'pO': ('X_us' + 'BY5]5,5~'), 'K': ('b' + '|' + '~')}
    global_c_l_i_args_0 = GlobalCLIArgs(dict_0)

# Generated at 2022-06-25 13:03:06.077757
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    GlobalCLIArgs(dict_0)

if __name__ == '__main__':
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:03:12.076711
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    c_l_i_args_0 = CLIArgs.from_options(dict_0)
    c_l_i_args_1 = CLIArgs(dict_0)

# Unit tests for CLIArgs
if __name__ == '__main__':
    test_CLIArgs()
    test_case_0()

# Generated at 2022-06-25 13:03:13.874405
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = GlobalCLIArgs()


# Generated at 2022-06-25 13:03:15.420242
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()

if __name__ == '__main__':
    test__ABCSingleton()

# Generated at 2022-06-25 13:03:27.387426
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_case_0()
    return None

# Generated at 2022-06-25 13:03:37.044355
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.cli.arguments import AnsibleCLIArguments
    from ansible.constants import DEFAULT_MODULE_NAME
    from ansible.config.manager import ConfigManager
    from ansible.utils.display import Display

    config_manager = ConfigManager(config_data={})
    display_options = Display(verbosity=0, log_only=False, nocolor=False, show_custom_stats=False)
    ansible_cli_arguments = AnsibleCLIArguments(args=[], options=config_manager, display=display_options, connection_options={}, runas_opts={})

# Generated at 2022-06-25 13:03:39.962757
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    c_l_i_args_0 = CLIArgs(dict_0)


# Generated at 2022-06-25 13:03:41.263335
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    dict_0 = {}
    global_c_l_i_args_0 = GlobalCLIArgs(dict_0)

# Generated at 2022-06-25 13:03:46.855993
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    c_l_i_args_0 = CLIArgs(dict_0)
    global_c_l_i_args_0 = GlobalCLIArgs(dict_0)


if __name__ == '__main__':
    test_case_0()
    test__ABCSingleton()

# Generated at 2022-06-25 13:03:52.151414
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    global_c_l_i_args_0 = GlobalCLIArgs(dict_0)
    global_c_l_i_args_0.from_options(dict_0)

# Generated at 2022-06-25 13:03:53.172513
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_case_0()

# Generated at 2022-06-25 13:03:56.345503
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    c_l_i_args_0 = GlobalCLIArgs(dict_0)

# Generated at 2022-06-25 13:03:59.669216
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    bool_0 = True
    c_l_i_args_0 = _ABCSingleton()
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    c_l_i_args_0 = CLIArgs(dict_0)


# Generated at 2022-06-25 13:04:02.749336
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    c_l_i_args_0 = CLIArgs(dict_0)



# Generated at 2022-06-25 13:04:13.864324
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    obj = _ABCSingleton
    try:
        obj.__init__()
    except NotImplementedError:
        pass


# Generated at 2022-06-25 13:04:22.827286
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    global_c_l_i_args_0 = GlobalCLIArgs()
    global_c_l_i_args_0 = GlobalCLIArgs()
    global_c_l_i_args_0 = GlobalCLIArgs()
    global_c_l_i_args_0 = GlobalCLIArgs()
    global_c_l_i_args_0 = GlobalCLIArgs()
    global_c_l_i_args_0 = GlobalCLIArgs()
    global_c_l_i_args_0 = GlobalCLIArgs()
    global_c_l_i_args_0 = GlobalCLIArgs()
    global_c_l_i_args_0 = GlobalCLIArgs()
    global_c_l_i_args_0 = GlobalCLIArgs()
    global_c_l_i_

# Generated at 2022-06-25 13:04:33.494606
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-25 13:04:34.461494
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    pass


# Generated at 2022-06-25 13:04:43.707476
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    dict_0 = {'description': {}}
    global_cli_args_0 = GlobalCLIArgs(dict_0)
    assert isinstance(global_cli_args_0, dict)
    assert isinstance(global_cli_args_0, Mapping)
    assert isinstance(global_cli_args_0, Container)
    assert isinstance(global_cli_args_0, CLIArgs)
    assert isinstance(global_cli_args_0, GlobalCLIArgs)
    # Assert that GlobalCLIArgs can be used as a data type
    dict_1 = {'description': {}}
    assert dict_0 is not dict_1
    global_cli_args_1 = GlobalCLIArgs(dict_1)
    assert isinstance(global_cli_args_1, dict)

# Generated at 2022-06-25 13:04:45.090659
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    global_c_l_i_args_0 = GlobalCLIArgs(dict())


# Generated at 2022-06-25 13:04:46.130615
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    pass


# Generated at 2022-06-25 13:04:49.138844
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Setup the test variables
    expected_value = None
    actual_value = None
    # Setup the test case
    # Perform the test
    actual_value = _ABCSingleton()
    # Verify the results
    assert expected_value == actual_value


# Generated at 2022-06-25 13:04:56.102572
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-25 13:05:04.467026
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Object0(metaclass=_ABCSingleton):
        def __init__(Object0_self, arg0=0):
            Object0_self.__bool_0 = bool()
            Object0_self.__bool_0 = arg0
            Object0_self.__bool_0 = bool()
            Object0_self.__bool_0 = arg0
        def __Object0_0_call(Object0_self, arg0=0):
            return int()
        def __Object0_1_call(Object0_self, arg0=0):
            return int()
    Object0()


# Generated at 2022-06-25 13:05:26.201259
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, ABCMeta)


# Generated at 2022-06-25 13:05:29.485242
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    global_c_l_i_args_0 = GlobalCLIArgs(dict_0)


# Generated at 2022-06-25 13:05:33.155700
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Create an object of Singleton, ABCMeta and _ABCSingleton classes
    obj_0 = Singleton()
    obj_1 = ABCMeta()
    obj_2 = _ABCSingleton()

    # Call the constructor of _ABCSingleton
    _ABCSingleton()


# Generated at 2022-06-25 13:05:38.642560
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'t_0': 'a', 't_1': 'b', 't_2': 'c'}

    toplevel = {}
    for key, value in mapping.items():
        toplevel[key] = _make_immutable(value)

    # Immutability test
    assert ImmutableDict(toplevel) == CLIArgs(mapping)
    try:
        mapping['t_0'] = 'd'
        assert False
    except TypeError:
        pass

    # Singleton test
    assert CLIA

# Generated at 2022-06-25 13:05:43.074120
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    def __init__(self, mapping):
        toplevel = {}
        for key, value in mapping.items():
            toplevel[key] = _make_immutable(value)
        super(CLIArgs, self).__init__(toplevel)
    cli_args_0 = CLIArgs(dict(kwarg_1='value_1'))
    return

# Generated at 2022-06-25 13:05:45.041748
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    dict_0 = {'a': 1}
    c_l_i_args_0 = GlobalCLIArgs(dict_0)


# Generated at 2022-06-25 13:05:49.087406
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Testing if __init__() raises a TypeError when called with incorrect types
    with pytest.raises(TypeError):
        cliargs = CLIArgs(bool())

    # Testing if __init__() raises a ValueError when called with incorrect values
    with pytest.raises(ValueError):
        cliargs = CLIArgs(dict())


# Generated at 2022-06-25 13:05:55.853710
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict_0 = {'v5PC$|W8N2': ':kxp^C@7!|>B9u', 'l1]6UH': 'E_e)_=', 'kzR'.decode('rot13'): True, 'a0q3,x1<2'.decode('rot13'): 'c%r?X9{', 'jyPm'.decode('rot13'): False}
    c_l_i_args_0 = CLIArgs(dict_0)
    assert c_l_i_args_0 is not None



# Generated at 2022-06-25 13:05:56.682916
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()

# Generated at 2022-06-25 13:06:03.021105
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    global_c_l_i_args_0 = GlobalCLIArgs.instance(dict_0)

# Generated at 2022-06-25 13:06:49.102746
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    dict_0 = {'foo': 'bar'}
    GlobalCLIArgs(dict_0)

# Generated at 2022-06-25 13:06:54.342724
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    c_l_i_args_0 = CLIArgs(dict_0)


# Generated at 2022-06-25 13:07:00.202341
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    c_l_i_args_0 = CLIArgs(dict_0)

    # TODO: implement assertGreaterEqual
    # assertGreaterEqual(len(c_l_i_args_0), 4)


# Generated at 2022-06-25 13:07:02.282204
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    _ABCSingleton.__singleton_lock__ = 0
    try:
        test_case_0()
    except:
        raise RuntimeError



# Generated at 2022-06-25 13:07:03.304522
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_case_0()

# Generated at 2022-06-25 13:07:05.804877
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    # Test no exception is raised
    _ABCSingleton(
        '_ABCSingletonMeta',
        (object,),
        {
            'metaclass': _ABCSingleton
        }
    )



# Generated at 2022-06-25 13:07:06.998650
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    abc_singleton_0 = _ABCSingleton()


import re

# Generated at 2022-06-25 13:07:09.809178
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    c_l_i_args_0 = CLIArgs(dict_0)


# Generated at 2022-06-25 13:07:11.882740
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import argparse
    c_l_i_args_0 = GlobalCLIArgs.from_options(argparse.Namespace())

if __name__ == '__main__':
    test_CLIArgs()

# Generated at 2022-06-25 13:07:12.578479
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    obj = _ABCSingleton()


# Generated at 2022-06-25 13:08:52.747123
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    global_cli_args_0 = GlobalCLIArgs(0)
    global_cli_args_1 = GlobalCLIArgs(0)
    assert global_cli_args_0 is global_cli_args_1


# Generated at 2022-06-25 13:08:59.825876
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    c_l_i_args_0 = CLIArgs(dict_0)


if __name__ == '__main__':
    import sys
    if sys.argv[1] == "1":
        test_case_0()
    elif sys.argv[1] == "2":
        test_CLIArgs()
    else:
        print("Nothing to do")
        exit(1)

# Generated at 2022-06-25 13:09:06.091353
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    toplevel = {}
    for key, value in mapping.items():
        toplevel[key] = _make_immutable(value)
    _ABCSingleton(toplevel)


# Generated at 2022-06-25 13:09:11.799270
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-25 13:09:15.538240
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    global_c_l_i_args_0 = GlobalCLIArgs(dict_0)


# Generated at 2022-06-25 13:09:19.889241
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Assert if the class can construct
    # Assert if the class is a subclass of Singleton
    # Assert if the class is a subclass of ABCMeta
    # Assert if the class is a subclass of Singleton
    # Assert if the class is a subclass of ABCMeta
    pass


# Generated at 2022-06-25 13:09:21.143034
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    instance = _ABCSingleton()
    return instance


# Generated at 2022-06-25 13:09:23.543934
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Check if the constructor is as expected
    mapping = {}
    assert isinstance(CLIArgs(mapping), ImmutableDict)


# Generated at 2022-06-25 13:09:29.400570
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    a = {}
    assert isinstance(CLIArgs(a), ImmutableDict)
    assert not isinstance(CLIArgs(a), Mapping)
    assert isinstance(CLIArgs(a), CLIArgs)
    assert not isinstance(CLIArgs(a), GlobalCLIArgs)
    assert not isinstance(GlobalCLIArgs(a), CLIArgs)
    assert isinstance(GlobalCLIArgs(a), GlobalCLIArgs)
    assert GlobalCLIArgs(a) is GlobalCLIArgs(a)

# Generated at 2022-06-25 13:09:36.108021
# Unit test for constructor of class GlobalCLIArgs