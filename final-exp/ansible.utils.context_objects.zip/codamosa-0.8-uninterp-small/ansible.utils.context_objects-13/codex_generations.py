

# Generated at 2022-06-25 13:00:48.734579
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common._collections_compat import namedtuple
    from ansible.module_utils.six import PY3
    if PY3:
        import builtins
        mydir = builtins.__dict__.get('__mydir__')
    else:
        mydir = __mydir__
    test_case_0()

if __name__ == '__main__':
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:00:49.752161
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()


# Generated at 2022-06-25 13:00:52.011712
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bytes_0 = None
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)



# Generated at 2022-06-25 13:00:58.624539
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    bytes_0 = None
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)

    # verify the fields in GlobalCLIArgs

    # Verify that __dict__ does not exist before __init__() is called.
    try:
        bytes_0 = GlobalCLIArgs.__dict__
    except AttributeError:
        pass
    else:
        raise AssertionError("GlobalCLIArgs has a __dict__ attribute before __init__() is called.")

    # Verify that we can set the requested attribute
    GlobalCLIArgs.__setattr__("attr_0", "attrib_0")
    attrib_0 = GlobalCLIArgs.__getattr__("attr_0")
    assert attrib_0 == "attrib_0"

    # Verify that we can dynamically create a new attribute
   

# Generated at 2022-06-25 13:01:00.685441
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bytes_1 = None
    cli_args_0 = CLIArgs(bytes_1)


# Generated at 2022-06-25 13:01:03.170026
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert isinstance(_ABCSingleton(
        '_ABCSingleton',
        (Singleton, ABCMeta),
        {}
    ), ABCMeta)


# Generated at 2022-06-25 13:01:04.981510
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bytes_0 = None
    cliargs_1 = CLIArgs(bytes_0)
    return

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 13:01:08.064248
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class test___ABCSingleton(_ABCSingleton):
        def __init__(self, *args, **kwargs):
            super(test___ABCSingleton, self).__init__(*args, **kwargs)
    test___ABCSingleton()



# Generated at 2022-06-25 13:01:09.482496
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    _ABCSingleton_0 = _abcSingleton()


# Generated at 2022-06-25 13:01:11.534320
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = CLIArgs(dict(a=1, b=2))
    global_c_l_i_args_0 = GlobalCLIArgs(args)

# Generated at 2022-06-25 13:01:24.045000
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    x = CLIArgs({1: 'a', 2: 'b'})
    assert x.get(1) == 'a'
    assert x.get(2) == 'b'
    assert x.get(3) == None
    assert x[1] == 'a'
    try:
        x[1] = 'c'
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-25 13:01:25.363230
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    print("\n===test__ABCSingleton===")
    test_case_0()


# Generated at 2022-06-25 13:01:33.757121
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    print('In GlobalCLIArgs.test_GlobalCLIArgs')

# Generated at 2022-06-25 13:01:34.722558
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_0 = GlobalCLIArgs.from_options(None)
    assert isinstance(test_0, GlobalCLIArgs)


# Generated at 2022-06-25 13:01:39.689163
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    str_0 = '__mydir__'
    str_1 = '__mydir__.__mydir__'
    dict_0 = dict()
    dict_0['__mydir__'] = '__mydir__'
    dict_0['__mydir__.__mydir__'] = '__mydir__.__mydir__'

    obj = CLIArgs(dict_0)
    obj.__init__(dict_0)
    # obj.from_options(dict_0) # TypeError: from_options() takes 1 positional argument but 2 were given
    # obj.__init__(dict_0) # TypeError: __init__() takes 1 positional argument but 2 were given
    # obj.from_options(dict_0) # TypeError: from_options() takes 1 positional argument but 2 were given


# Generated at 2022-06-25 13:01:47.638128
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    print("test_GlobalCLIArgs")
    str_1 = '__mydir__'

# Generated at 2022-06-25 13:01:50.808487
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    print('TestCase: ' + test_case_0.__name__)
    print('Constructor of class _ABCSingleton')


# Generated at 2022-06-25 13:02:01.693506
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()
    # Create an instance of the MetaSingleton class
    obj_0 = _ABCSingleton()
    # __init__ function of the MetaSingleton class
    test_case_0()
    # Access instance attributes
    # Return the value of the instance attribute 'a'.
    # a = obj_0.a
    # Compare the value of the instance attribute 'a'
    # with __mydir__.
    # assert a == __mydir__
    # Return the value of the instance attribute 'b'.
    # b = obj_0.b
    # Compare the value of the instance attribute 'b'
    # with __mydir__.
    # assert b == __mydir__
    # Return the value of the instance attribute 'c'.
    # c = obj_0.c
    # Compare the value of the instance

# Generated at 2022-06-25 13:02:03.251412
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    print("Unit test for constructor of class _ABCSingleton")
    a = _ABCSingleton()


# Generated at 2022-06-25 13:02:06.125852
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_options = Container(a=1, b=2, c=3)
    args_0 = CLIArgs.from_options(test_options)
    assert args_0 == test_options


# Generated at 2022-06-25 13:02:17.285684
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    str_0 = '__mydir__'
    # Test for case where __instance is not defined
    # Source code: class _ABCSingleton(Singleton, ABCMeta):
    # Test for case where instance is not defined
    # Source code: class _ABCSingleton(Singleton, ABCMeta):
    # Test for case where __instance is not defined
    # Source code: class _ABCSingleton(Singleton, ABCMeta):
    # Test for case where my_class is not defined
    # Source code: class _ABCSingleton(Singleton, ABCMeta):
    # Test for case where arguments is not defined
    # Source code: class _ABCSingleton(Singleton, ABCMeta):
    # Test for case where __instance is not defined
    # Source code: class _ABCSingleton(Singleton, ABCMeta):
    # Test for case where instance is

# Generated at 2022-06-25 13:02:25.230867
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import copy
    from optparse import Values
    from ansible.module_utils.common.collections import ImmutableDict

    inp = {'test': ['abc', 'def']}
    # Create an instance of Options for testing
    options = Values()
    for key, value in inp.items():
        options[key] = value
    obj = CLIArgs.from_options(options)
    import pdb; pdb.set_trace()
    assert obj['test'] == ['abc', 'def']
    try:
        obj['test'] = ['123', '456']
        assert False
    except TypeError:
        pass



# Generated at 2022-06-25 13:02:30.328689
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    param_dict_1 = {'a': 0, 'b': '__mydir__', 'g': 0, 'd': 0, 'e': 0, 'f': 0}
    instance_1 = CLIArgs(param_dict_1)
    assert isinstance(instance_1, CLIArgs)


# Generated at 2022-06-25 13:02:33.621323
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        obj_ = ImmutableDict()
    except Exception as e:
        print('Exception:', e)
    else:
        if obj_:
            print('Test passed')
        else:
            print('Test failed')


# Generated at 2022-06-25 13:02:35.654056
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    str_0 = '__mydir__'
    #assert CLIArgs(str_0) == ...
    pass


# Generated at 2022-06-25 13:02:47.222686
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    print("test_CLIArgs")
    # Args
    args = {}
    args['test_arg'] = 'test_arg_value'
    # Test case
    test_case_0()

    cli_args = CLIArgs(args)

    print("cli_args '"+str(cli_args)+"'")
    print("len '"+str(len(cli_args))+"'")
    for key in cli_args:
        print("key '"+str(key)+"' value '"+str(cli_args[key])+"'")

    print("type(cli_args) '"+str(type(cli_args))+"'")
    assert(isinstance(cli_args, cli_args.__class__))
    assert(len(cli_args) == 1)

# Generated at 2022-06-25 13:02:50.407329
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'foo': [], 'bar': {'baz': 'qux'}}
    cli_args = CLIArgs(mapping)
    assert cli_args.foo == []
    assert cli_args.bar == {'baz': 'qux'}


# Generated at 2022-06-25 13:02:57.593301
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # create a CLIArgs object by using its constructor
    from ansible.cli import CLI
    from ansible.parsing.dataloader import DataLoader
    # from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    # from ansible.errors import AnsibleError

# Generated at 2022-06-25 13:03:01.334295
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    try:
        str_0 = '__mydir__'
    except Exception as err:
        raise AssertionError("'GlobalCLIArgs' constructor raises Exception when passing: " + str(err))

if __name__ == '__main__':
    test_case_0()
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:03:02.937726
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Test that instances of GlobalCLIArgs can be instantiated
    obj = GlobalCLIArgs(list())


# Generated at 2022-06-25 13:03:08.173419
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Test that constructor raises TypeError when one parameter is passed
    try:
        with pytest.raises(TypeError):
            _ABCSingleton(float_0)
    except Exception as e:
        raise Exception('Unit test for constructor of class _ABCSingleton failed')


# Generated at 2022-06-25 13:03:10.698626
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    obj = _ABCSingleton("test__ABCSingleton")
    assert isinstance(obj, _ABCSingleton)
    assert obj.__class__ is _ABCSingleton


# Generated at 2022-06-25 13:03:12.884750
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    print('===Test Function for class "CLIArgs"===')
    print('===constructor of class "CLIArgs"===')
    test_case_0()

# Generated at 2022-06-25 13:03:21.820463
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    a = CLIArgs({'a', 'b', 'c'})
    b = CLIArgs({'a', 'b', 'c'})
    assert a == b
    assert not a is b
    c = CLIArgs({'a', 'b', 'c'})
    d = CLIArgs({'a', 'b', 'c'})
    e = CLIArgs({'a', 'b', 'c'})
    f = CLIArgs({'a', 'b', 'c'})
    assert a == c and b == d
    assert a == e and b == f
    assert not a == d and not a == f
    assert not a is c and not b is d
    assert not a is e and not b is f
    g = CLIArgs({'a', 'b', 'c', 'd'})
    assert not a == g
   

# Generated at 2022-06-25 13:03:30.071628
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    init_dict = {
        'key1': 'value1',
        'key2': 'value2',
        'key3': {
            'nested1': 'value3',
            'nested2': ['anothervalue1', 'anothervalue2']
        }
    }

    # Create a new CLIArgs
    result = CLIArgs(init_dict)

    # Validate that the constructor doesn't modify the input
    assert result is not init_dict
    assert result == init_dict

    # Validate that the input isn't mutable
    for key in init_dict:
        assert isinstance(init_dict[key], (ImmutableDict, tuple))



# Generated at 2022-06-25 13:03:31.274915
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert issubclass(GlobalCLIArgs, ImmutableDict)

# Generated at 2022-06-25 13:03:32.717799
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert isinstance(CLIArgs(float_0), CLIArgs)



# Generated at 2022-06-25 13:03:33.587683
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    obj = _ABCSingleton()


# Generated at 2022-06-25 13:03:34.425032
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert True


# Generated at 2022-06-25 13:03:36.252770
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    g_c_l_i_args_0 = GlobalCLIArgs()

# Generated at 2022-06-25 13:03:42.580634
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    import AnsiballZ_ansible

    # we need to initialize AnsiballZ_ansible before using it
    AnsiballZ_ansible.main()
    AnsiballZ_ansible.init()
    assert AnsiballZ_ansible.AnsiballZRuntimeGlobals().DEFAULT_MODULE_PATH == AnsiballZ_ansible.AnsiballZRunne

# Generated at 2022-06-25 13:03:44.245587
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    float_0 = 512.0
    c_l_i_args_0 = GlobalCLIArgs(float_0)

# Generated at 2022-06-25 13:03:54.549288
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils.common._collections_compat import Mapping, Sequence, Set

    # Test for method __init__ with valid arguments
    test_case_0()

    # Test for method __init__ with non-Container data type for mapping
    with pytest.raises(TypeError):
        CLIArgs.from_options(1.0)
    with pytest.raises(TypeError):
        CLIArgs.from_options(b'This is a string')
    with pytest.raises(TypeError):
        CLIArgs.from_options(u'This is a string')

    # Test for method __init__ with Container data type for mapping
    with pytest.raises(TypeError):
        CLIArgs.from_options(Mapping())
    with pytest.raises(TypeError):
        CLIArgs.from_

# Generated at 2022-06-25 13:04:01.051556
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    list_0 = ['hello', 'world']
    dict_0 = {'a': 3, 'b': 4}
    mixed_container_0 = _make_immutable(list_0)
    mixed_container_1 = _make_immutable(dict_0)
    mixed_container_2 = _make_immutable(mixed_container_0)
    mixed_container_3 = _make_immutable(mixed_container_1)
    mixed_container_4 = _make_immutable(mixed_container_2)
    mixed_container_5 = _make_immutable(mixed_container_3)
    c_l_i_args_0 = CLIArgs.from_options(mixed_container_4)



# Generated at 2022-06-25 13:04:03.272338
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 512.0
    assert (type(CLIArgs(float_0)) is CLIArgs)


# Generated at 2022-06-25 13:04:04.146089
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    fp = GlobalCLIArgs()

# Generated at 2022-06-25 13:04:05.339768
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    c_l_i_args_0_0 = GlobalCLIArgs({})


# Generated at 2022-06-25 13:04:14.410721
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from _ast import UAdd, UnaryOp, mod
    from _ast import Is, Store
    from _ast import Lt, Gt, LShift, RShift, BitOr, BitXor, BitAnd, Not, UAdd, NotEq, USub, Eq, In, IsNot, NotIn
    import _ast
    import sys
    import ast
    import re

    f = open("ansible/cli/galaxy/__init__.py")
    contents = f.read()
    t = ast.parse(contents)
    l = t.body
    def check_stores(stores, left, right):
        if(stores.__class__.__name__ == "Store"):
            #print("store" , stores.__class__.__name__)
            check_stores(stores.value, left, right)
       

# Generated at 2022-06-25 13:04:15.896107
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args_0 = GlobalCLIArgs(None)


# Generated at 2022-06-25 13:04:24.001961
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert hasattr(GlobalCLIArgs(), "from_options")
    assert hasattr(GlobalCLIArgs(), "__init__")
    assert hasattr(GlobalCLIArgs(), "__repr__")
    assert hasattr(GlobalCLIArgs(), "__str__")
    assert hasattr(GlobalCLIArgs(), "__eq__")
    assert hasattr(GlobalCLIArgs(), "__ne__")
    assert hasattr(GlobalCLIArgs(), "__bool__")
    assert hasattr(GlobalCLIArgs(), "__contains__")
    assert hasattr(GlobalCLIArgs(), "__len__")
    assert hasattr(GlobalCLIArgs(), "__getitem__")
    assert hasattr(GlobalCLIArgs(), "__iter__")
    assert hasattr(GlobalCLIArgs(), "items")

# Generated at 2022-06-25 13:04:31.418488
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test__ABCSingleton_Metaclass_0 = _ABCSingleton
    assert test__ABCSingleton_Metaclass_0

# Generated at 2022-06-25 13:04:34.508332
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    a = _ABCSingleton()
    b = _ABCSingleton()
    assert a is b
    try:
        assert a == b
    except TypeError:
        pass


# Generated at 2022-06-25 13:04:36.988727
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    test_case_0()
    test_case_1()
    test_case_2()

CLIArgs().from_options()


# Generated at 2022-06-25 13:04:39.911698
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    temp_0 = {}
    c_l_i_args_0 = GlobalCLIArgs.from_options(temp_0)


test_case_0()
test_GlobalCLIArgs()

# Generated at 2022-06-25 13:04:47.276491
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    cli_args_0 = CLIArgs({
        'debug': True,
        'check_mode': True,
        'force': True
    })
    #make sure the class is a type singleton
    assert GlobalCLIArgs() is GlobalCLIArgs()
    #make sure the class is a class singleton
    assert cli_args_0 is GlobalCLIArgs()
    #now test the Args() is the same as the GlobalCLIArgs()
    assert cli_args_0 is GlobalCLIArgs()
    #assert False


# Generated at 2022-06-25 13:04:49.305352
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    d_0 = {'verbose': 'yes'}
    global_cli_args_0 = GlobalCLIArgs(d_0)

test_GlobalCLIArgs()

# Generated at 2022-06-25 13:04:51.801162
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert isinstance(object, _ABCSingleton)
    assert isinstance(GlobalCLIArgs, _ABCSingleton)
    assert GlobalCLIArgs != CLIArgs
    assert GlobalCLIArgs is CLIArgs

# Generated at 2022-06-25 13:04:53.489917
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    obj = _ABCSingleton()
    assert isinstance(obj, type)


# Generated at 2022-06-25 13:04:55.411126
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    abc_singleton_0 = _ABCSingleton()


# Generated at 2022-06-25 13:04:58.549140
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert isinstance(_ABCSingleton(), _ABCSingleton)
    assert isinstance(test_case_0(), test_case_0)

# Generated at 2022-06-25 13:05:13.216378
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    with pytest.raises(TypeError):
        _abc_singleton_0 = _ABCSingleton()


# Generated at 2022-06-25 13:05:21.698447
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Verify that exception is thrown when creating a class that uses
    # _ABCSingleton as its metaclass, with a non-abstract method.  This
    # should raise an exception because _ABCSingleton is a subclass
    # of ABCMeta, which requires that all abstract methods be
    # overridden.

    class __Example(object):
        __metaclass__ = _ABCSingleton

        def __new__(cls):
            return object.__new__(cls)

    try:
        __Example()
    except TypeError:
        return


# Generated at 2022-06-25 13:05:22.746871
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    c = _ABCSingleton()
    assert isinstance(c, _ABCSingleton)


# Generated at 2022-06-25 13:05:23.985519
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    c_l_i_args_0 = CLIArgs(float_0)



# Generated at 2022-06-25 13:05:24.711520
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    _ABCSingleton();


# Generated at 2022-06-25 13:05:26.604598
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    try:
        GlobalCLIArgs()
    except NotImplementedError:
        pass
    else:
        assert False



# Generated at 2022-06-25 13:05:28.055265
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 512.0
    assert type(GlobalCLIArgs.from_options(float_0)) is CLIArgs

# Generated at 2022-06-25 13:05:29.167969
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert isinstance(GlobalCLIArgs(), GlobalCLIArgs) is True


# Generated at 2022-06-25 13:05:37.850641
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 512.0
    mapping_0 = {'b': float_0, 'Z': float_0, 'c': float_0, 'z': float_0, 'N': float_0}
    global_c_l_i_args_1 = GlobalCLIArgs(mapping_0)
    assert_equal(global_c_l_i_args_1.keys(), ['z', 'b', 'c', 'N', 'Z'])

if __name__ == '__main__':
    # This line would fail since CLIArgs is immutable
    # c_l_i_args_0 = CLIArgs({'a':'b'})
    # c_l_i_args_0['a'] = 3
    float_0 = 512.0

# Generated at 2022-06-25 13:05:46.871037
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    global_cli_arg = GlobalCLIArgs.instance()
    if not isinstance(global_cli_arg, CLIArgs):
        raise ValueError("Expected type CLIArgs, got: " + type(global_cli_arg).__name__)
    if not isinstance(global_cli_arg, GlobalCLIArgs):
        raise ValueError("Expected type GlobalCLIArgs, got: " + type(global_cli_arg).__name__)

    # Singleton class, so this should fail
    try:
        global_cli_arg_2 = CLIArgs.instance()
        raise ValueError("Called GlobalCLIArgs.instance() as CLIArgs, should not be possible")
    except TypeError:
        pass

    # Test immutability

# Generated at 2022-06-25 13:06:10.456771
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()

# Generated at 2022-06-25 13:06:11.265306
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()

# Generated at 2022-06-25 13:06:12.368475
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = GlobalCLIArgs()

# Generated at 2022-06-25 13:06:15.957327
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = GlobalCLIArgs()
    # GlobalCLIArgs is not callable
    try:
        class_0 = GlobalCLIArgs()
        failure_0 = False
    except TypeError:
        failure_0 = True
    assert failure_0

# Generated at 2022-06-25 13:06:17.798069
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 817.0
    c_l_i_args_0 = CLIArgs(float_0)


# Generated at 2022-06-25 13:06:21.642493
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    # Set this function's docstring as the bookmark name
    test_name = '"{}" ({})'.format(test_case_0.__name__, test_case_0.__doc__)
    # Call the function that collects and check the coverage report
    report_cov(test_name, test_case_0)

# Generated at 2022-06-25 13:06:23.212435
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = GlobalCLIArgs(GlobalCLIArgs(True))

# Generated at 2022-06-25 13:06:26.263250
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = [3,4,5]
    cliargs = GlobalCLIArgs.from_options(args)


# Generated at 2022-06-25 13:06:28.859158
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    g_c_l_i_args_0 = GlobalCLIArgs()

if __name__ == "__main__":
    test_GlobalCLIArgs()
    print("Test Successful")

# Generated at 2022-06-25 13:06:31.951452
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # print('\n==== test_CLIArgs start ====')
    # print('==== test_CLIArgs end ====\n')
    try:
        test_case_0()
    except TypeError:
        pass


# Generated at 2022-06-25 13:07:27.380192
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    float_0 = 512.0
    c_l_i_args_0 = CLIArgs(float_0)
    assert c_l_i_args_0.__class__.__name__ == 'CLIArgs'
    assert CLIArgs.__init__.__annotations__.values == c_l_i_args_0.__class__.__annotations__.values
    assert type(c_l_i_args_0) is not object


# Generated at 2022-06-25 13:07:29.649051
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    tuple_0 = ()
    global_c_l_i_args_0 = GlobalCLIArgs(tuple_0)
    assert global_c_l_i_args_0 is not None


# Generated at 2022-06-25 13:07:33.745656
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert_equal(type(_ABCSingleton), _ABCSingleton, 'Not equal: Instance of class _ABCSingleton is not equal to _ABCSingleton')
    assert_equal(_ABCSingleton.__bases__, (Singleton, ABCMeta), 'Not equal: Error in bases of class _ABCSingleton')


# Generated at 2022-06-25 13:07:36.313889
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    float_0 = 512.0
    obj_0 = _ABCSingleton.from_options(float_0)
    assert obj_0 is _ABCSingleton.from_options(float_0)

# Generated at 2022-06-25 13:07:38.100378
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert hasattr(_ABCSingleton, "__init__")
    assert hasattr(_ABCSingleton, "__call__")



# Generated at 2022-06-25 13:07:40.252373
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 512.0
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)



test_GlobalCLIArgs()

# Generated at 2022-06-25 13:07:42.180261
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, ABCMeta)
    assert issubclass(_ABCSingleton, Singleton)


# Generated at 2022-06-25 13:07:46.053120
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mock_ = ImmutableDict({'test1': dict({1: 2, 'test3': 4, })})
    cli_args = CLIArgs(mock_)
    assert cli_args['test1'][1] == 2
    assert cli_args['test1']['test3'] == 4



# Generated at 2022-06-25 13:07:49.187889
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Call static method from_options
    float_0 = float()
    result_0 = GlobalCLIArgs.from_options(float_0)


if __name__ == '__main__':
    test_case_0()
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:07:56.324996
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    This will test for edge cases for the class CLIArgs
    """
    test_num = 1

    # Test Case illegal_type_0:
    # check exception thrown when illegal type is passed to constructor
    print("Test Case %d: " % test_num, end="")
    test_num += 1
    illegal_type_0 = 0
    try:
        c_l_i_args_0 = CLIArgs(illegal_type_0)
    except Exception as e:
        print("Passed")
        assert type(e).__name__ == "TypeError"
    else:
        print("Failed")

    # Test Case container_in_dict_0:
    # check that constructor works with container in dict
    print("Test Case %d: " % test_num, end="")
    test_num += 1
   

# Generated at 2022-06-25 13:09:42.245210
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert issubclass(CLIArgs, ImmutableDict)
    assert isinstance(CLIArgs(float_0), ImmutableDict)
    assert isinstance(CLIArgs, _ABCSingleton)


# Generated at 2022-06-25 13:09:47.885760
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    i_dict_0 = {'hello': 'world', 'goodbye': 'cruel world'}
    global_c_l_i_args_0 = GlobalCLIArgs(i_dict_0)


if __name__ == '__main__':
    # test_GlobalCLIArgs()

    # More of a type check than a unit test
    float_0 = 512.0
    c_l_i_args_0 = CLIArgs(float_0)

    test_case_0()
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:09:54.261921
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # initialize the variables to a set of values
    string_0 = "abcdefghijklmnopqrstuvwxyz"
    string_1 = "abcdefghijklmnopqrstuvwxyz"
    string_2 = "abcdefghijklmnopqrstuvwxyz"
    string_3 = "abcdefghijklmnopqrstuvwxyz"
    string_4 = "abcdefghijklmnopqrstuvwxyz"
    mapping_0 = dict()
    mapping_1 = dict()
    mapping_0[string_0] = string_1
    mapping_1[string_2] = string_3
    c_l_i_args_0 = CLIArgs(mapping_0)

    # call the function
    result = c_l_i

# Generated at 2022-06-25 13:09:57.299324
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    c_l_i_args = CLIArgs.from_options(options_0)
    assert c_l_i_args == {"success": True, "msg": "Hello world 1"}



# Generated at 2022-06-25 13:10:00.742760
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_1 = 512.0
    global_c_l_i_args_0 = GlobalCLIArgs(float_1)
    assert ((global_c_l_i_args_0 is not None) is True)
    assert (isinstance(global_c_l_i_args_0, GlobalCLIArgs) is True)


# Generated at 2022-06-25 13:10:04.166201
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_1 = 512.0
    c_l_i_args_0 = CLIArgs(float_1)
    assert c_l_i_args_0.items() == frozenset({})



# Generated at 2022-06-25 13:10:08.342050
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping_0 = {'key_0': 2, 'key_1': 'value_1'}
    toplevel_0 = {}

# Generated at 2022-06-25 13:10:09.559427
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    pass



# Generated at 2022-06-25 13:10:12.892546
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    float_0 = 512.0
    c_l_i_args_0 = CLIArgs(float_0)
    # Constructor of class 'GlobalCLIArgs' called with values out of bounds
    c_l_i_args_1 = GlobalCLIArgs.from_options(float_0)

# Generated at 2022-06-25 13:10:14.337564
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 512.0
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)