

# Generated at 2022-06-25 13:00:47.313079
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    tuple_0 = None
    global_c_l_i_args_0 = GlobalCLIArgs(tuple_0)
    assert global_c_l_i_args_0.__class__ == GlobalCLIArgs
    global_c_l_i_args_1 = GlobalCLIArgs(tuple_0)
    assert global_c_l_i_args_1.__class__ == GlobalCLIArgs
    assert global_c_l_i_args_0 == global_c_l_i_args_1

# Generated at 2022-06-25 13:00:48.206825
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test__ABCSingleton_0()

# Generated at 2022-06-25 13:00:50.453295
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    abc_singleton_0 = _ABCSingleton()
    assert isinstance(abc_singleton_0, type)



# Generated at 2022-06-25 13:00:52.921513
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    tuple_0 = None
    global_c_l_i_args_0 = GlobalCLIArgs(tuple_0)

#Unit test fpr constructor of class CLIArgs

# Generated at 2022-06-25 13:00:53.713606
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    singleton_0 = None


# Generated at 2022-06-25 13:00:54.960034
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = GlobalCLIArgs()

# Generated at 2022-06-25 13:01:02.485326
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils import basic
    module = basic.AnsibleModule(argument_spec=dict(test=dict(type='str')))
    module.params['test'] = "hi"
    cli_args = CLIArgs.from_options(module.params)

    assert cli_args['test'] == "hi"
    assert cli_args == ImmutableDict(dict(test='hi'))
    assert not cli_args is module.params


# Generated at 2022-06-25 13:01:10.477498
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Mock command line arguments
    tuple_0 = {'option_e_no_log': 'True', 'action': 'ping', 'option_a': 'flag', 'option_e': 'implicit_yes', 'option_b': 'flag', 'option_c': 'value', 'option_d': 'value'}
    # Create the object
    c_l_i_args_0 = CLIArgs(tuple_0)
    # Check the value of the first attribute
    assert c_l_i_args_0['option_e_no_log'] == 'True'
    # Check the value of the second attribute
    assert c_l_i_args_0['action'] == 'ping'
    # Check the value of the third attribute
    assert c_l_i_args_0['option_a'] == 'flag'
    #

# Generated at 2022-06-25 13:01:12.453242
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Use isinstance to ensure that class GlobalCLIArgs is a class
    assert isinstance(GlobalCLIArgs, object)


# Generated at 2022-06-25 13:01:21.666797
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping_0 = {'yea': 5, 'meh': 'meh', 'cheese': 'meh', 'zap': 'meh', 'yeah': 'meh', 'yo': 'meh', 'yup': 'meh', 'yeh': 'meh'}
    cli_args_0 = CLIArgs(mapping_0)
    assert cli_args_0['yea'] == 5
    assert cli_args_0['meh'] == 'meh'
    assert cli_args_0['cheese'] == 'meh'
    assert cli_args_0['zap'] == 'meh'
    assert cli_args_0['yeah'] == 'meh'
    assert cli_args_0['yo'] == 'meh'

# Generated at 2022-06-25 13:01:26.773383
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    global_c_l_i_args_1 = CLIArgs(dict(vars()))



# Generated at 2022-06-25 13:01:31.777455
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    global_c_l_i_args_1 = GlobalCLIArgs({'a': 1})
    global_c_l_i_args_2 = GlobalCLIArgs({'a': 1, 'b': 2})
    assert global_c_l_i_args_1 == {'a': 1}
    assert global_c_l_i_args_2 == {'a': 1, 'b': 2}


# Generated at 2022-06-25 13:01:38.400724
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    cli_args_0 = CLIArgs()
    cli_args_1 = CLIArgs()

    global_c_l_i_args_0 = GlobalCLIArgs()
    global_c_l_i_args_1 = GlobalCLIArgs()

    # assert that the singleton works
    assert(global_c_l_i_args_0 is global_c_l_i_args_1)

    # assert that the non-singleton works
    assert(cli_args_0 is not cli_args_1)

# Generated at 2022-06-25 13:01:40.363490
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = GlobalCLIArgs()


# Generated at 2022-06-25 13:01:43.126078
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    global_c_l_i_args_0 = GlobalCLIArgs()
    assert isinstance(global_c_l_i_args_0, GlobalCLIArgs)


# Generated at 2022-06-25 13:01:45.399343
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    try:
        GlobalCLIArgs()
        result = True
    except:
        result = False
    assert result



# Generated at 2022-06-25 13:01:47.246685
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    result = CLIArgs(dict(a=1, b=2)).keys()
    assert sorted(result) == ['a', 'b']


# Generated at 2022-06-25 13:01:49.736000
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()


# Generated at 2022-06-25 13:02:01.602372
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_args = {'verbosity': 1}
    assert _make_immutable(test_args) == {'verbosity': 1}

    test_args = {'verbosity': 1, 'foo': ImmutableDict({'bar': 'baz'})}
    assert _make_immutable(test_args) == {'verbosity': 1, 'foo': {'bar': 'baz'}}

    test_args = {'verbosity': 1, 'foo': {'bar': 'baz'}}
    assert _make_immutable(test_args) == {'verbosity': 1, 'foo': {'bar': 'baz'}}

    # tuples are not containers
    test_args = {'verbosity': 1, 'foo': {'bar': (1, 2, 3)}}

# Generated at 2022-06-25 13:02:11.062776
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    global_c_l_i_args_0 = GlobalCLIArgs()
    assert isinstance(global_c_l_i_args_0, GlobalCLIArgs), "Object is not of type GlobalCLIArgs, a subclass of _ABCSingleton.  Got %r" % type(global_c_l_i_args_0)
    assert isinstance(global_c_l_i_args_0, ImmutableDict), "Object is not of type ImmutableDict, a subclass of _ABCSingleton.  Got %r" % type(global_c_l_i_args_0)

# Generated at 2022-06-25 13:02:28.024683
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    global_c_l_i_args_0 = GlobalCLIArgs()
    assert global_c_l_i_args_0.__class__.__name__ == 'GlobalCLIArgs'
    assert isinstance(global_c_l_i_args_0, GlobalCLIArgs)
    assert isinstance(global_c_l_i_args_0, Singleton)
    assert isinstance(global_c_l_i_args_0, ImmutableDict)
    assert isinstance(global_c_l_i_args_0, Mapping)
    assert isinstance(global_c_l_i_args_0, Container)

if __name__ == '__main__':
    test__ABCSingleton()

# Generated at 2022-06-25 13:02:30.036876
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = GlobalCLIArgs()


# Generated at 2022-06-25 13:02:33.023424
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_map = {'1': 1, '2': 2}
    test_cli_args = CLIArgs(test_map)
    assert(test_cli_args.items() == test_map.items())

# Generated at 2022-06-25 13:02:35.414180
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    global_c_l_i_args = GlobalCLIArgs()
    assert GlobalCLIArgs is global_c_l_i_args.__class__.__call__

# Generated at 2022-06-25 13:02:40.644544
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = GlobalCLIArgs()
    assert isinstance(global_c_l_i_args_0, GlobalCLIArgs)
    assert isinstance(global_c_l_i_args_0, ImmutableDict)


# Generated at 2022-06-25 13:02:42.876520
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    global_cli_args_0 = GlobalCLIArgs()
    global_cli_args_1 = GlobalCLIArgs()
    assert id(global_cli_args_0) == id(global_cli_args_1)



# Generated at 2022-06-25 13:02:51.710214
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.display import Display
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.utils.vars import combine_vars

    # Create a Display instance for testing
    test_display = Display()
    test_display._verbosity = 2

    # Create a DataLoader instance for testing
    test_loader = DataLoader(None)

    # Create a combination of default and
    test_vars = combine_vars(loader=test_loader, variables={'b': '2'}, include_role_vars=False,
                             include_vars=False, vault_password=None)

# Generated at 2022-06-25 13:02:57.100863
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Initializing the class
    global_c_l_i_args_0 = GlobalCLIArgs()
    temp_argv = ['ansible', '--version']
    # Initializing the class
    global_c_l_i_args_1 = GlobalCLIArgs()
    # Accessing an attribute of an instance.
    assert global_c_l_i_args_0.__class__._instance is global_c_l_i_args_1._instance



# Generated at 2022-06-25 13:03:01.494407
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, Singleton)
    assert issubclass(_ABCSingleton, ABCMeta)
    assert issubclass(GlobalCLIArgs, CLIArgs)
    assert issubclass(GlobalCLIArgs, Singleton)
    assert issubclass(GlobalCLIArgs, ABCMeta)
    assert issubclass(_ABCSingleton, type)


# Generated at 2022-06-25 13:03:02.780087
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    abc_singleton = _ABCSingleton()


# Generated at 2022-06-25 13:03:09.282612
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()

# Generated at 2022-06-25 13:03:10.399502
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    _ABCSingleton_0 = _ABCSingleton()

# Generated at 2022-06-25 13:03:13.487215
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    print('\033[1;37;41m Running CLIArgs Test... \033[0m')
    print('\033[1;37;41m Currently, we do not have a test for CLIArgs... \033[0m')


# Generated at 2022-06-25 13:03:17.453979
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs({"a": 1, "b": 2, "c": {"c1": "value1", "c2": "value2"}})
    assert cli_args == {"a": 1, "b": 2, "c": {"c1": "value1", "c2": "value2"}}



# Generated at 2022-06-25 13:03:26.765974
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    global_c_l_i_args_1 = GlobalCLIArgs()
    global_c_l_i_args_2 = GlobalCLIArgs()
    assert GlobalCLIArgs() is not None, "Failed case #0 of test__ABCSingleton"
    assert global_c_l_i_args_1 is global_c_l_i_args_2, "Failed case #1 of test__ABCSingleton"
    assert global_c_l_i_args_1 is not None, "Failed case #2 of test__ABCSingleton"
    assert global_c_l_i_args_2 is not None, "Failed case #3 of test__ABCSingleton"

# Generated at 2022-06-25 13:03:27.687422
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()

# Generated at 2022-06-25 13:03:28.556619
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    pass # Constructor call passed

# Generated at 2022-06-25 13:03:32.950889
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with non-empty mapping
    mapping = {
        'test_prop_0': 'test_value_0',
        'test_prop_1': 'test_value_1',
        'test_prop_2': 'test_value_2',
    }
    cli_args_0 = CLIArgs(mapping)


# Generated at 2022-06-25 13:03:36.473123
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    t_mapping_0 = {'foo': 'bar'}
    cli_args_0 = CLIArgs(t_mapping_0)

    # Calling the instance method __init__() of class CLIArgs
    # No error


# Generated at 2022-06-25 13:03:40.028575
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible import constants as C
    global_c_l_i_args = GlobalCLIArgs()
    assert global_c_l_i_args.get('connection') == C.DEFAULT_TRANSPORT
    assert global_c_l_i_args.get('module_path') == C.DEFAULT_MODULE_PATH


# Generated at 2022-06-25 13:03:50.935765
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert GlobalCLIArgs()
    GlobalCLIArgs.instance = None

# Generated at 2022-06-25 13:03:52.150106
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs()

# Generated at 2022-06-25 13:03:55.623454
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    tuple_0 = None
    global_c_l_i_args_0 = GlobalCLIArgs(tuple_0)


if __name__ == '__main__':
    import sys
    import pdb
    pdb.set_trace()
    sys.exit(0)

# Generated at 2022-06-25 13:04:02.040511
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    tuple_1 = {'foo': 1, 'bar': 2}
    c_l_i_args_1 = CLIArgs(tuple_1)
    assert c_l_i_args_1 == {'foo': 1, 'bar': 2}

    tuple_2 = {'foo': [1, 2, 3]}
    c_l_i_args_2 = CLIArgs(tuple_2)
    assert c_l_i_args_2 == {'foo': (1, 2, 3)}

    tuple_3 = {'sets': {'foo', 'bar'}}
    c_l_i_args_3 = CLIArgs(tuple_3)
    assert c_l_i_args_3 == {'sets': frozenset(('foo', 'bar'))}


# Generated at 2022-06-25 13:04:10.268643
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    dict_0 = {
        '__ansible_module_name': 'AnsibleModule',
        '__ansible_module_version': '2.5.1',
        '__ansible_verbosity': 0,
    }
    cli_args_0 = CLIArgs(dict_0)
    global_cli_args_0 = GlobalCLIArgs.from_options(cli_args_0)

    # Test if we can create another GlobalCLIArgs instance
    global_cli_args_1 = GlobalCLIArgs.from_options(dict_0)
    assert global_cli_args_0 == global_cli_args_1
    assert global_cli_args_0 is global_cli_args_1

# Generated at 2022-06-25 13:04:13.946729
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    tuple_0 = None
    c_l_i_args_0 = CLIArgs(tuple_0)


from ansible.module_utils.common.ansible_module import MockAnsibleModule
from ansible.module_utils.six import string_types

from ansible.module_utils import basic



# Generated at 2022-06-25 13:04:16.193117
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert not hasattr(_ABCSingleton, '_instance')
    assert issubclass(_ABCSingleton, Singleton)


# Generated at 2022-06-25 13:04:19.277514
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    tuple_1 = {'test_key':'test_value'}
    c_l_i_args_1 = CLIArgs(tuple_1)
    assert c_l_i_args_1.get('test_key') == 'test_value'

# Generated at 2022-06-25 13:04:20.492677
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    c_l_i_args_0 = CLIArgs(None)


# Generated at 2022-06-25 13:04:22.579425
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    metaclass_0 = getattr(test_case_0, '__class__', None)
    test_case_0._ABCSingleton(metaclass_0)


# Generated at 2022-06-25 13:04:33.537747
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args_0 = GlobalCLIArgs()
    print(global_cli_args_0)

test_GlobalCLIArgs()

# Generated at 2022-06-25 13:04:35.697718
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    tuple_0 = None
    _abcsingleton_0 = _ABCSingleton(tuple_0)


# Generated at 2022-06-25 13:04:36.989189
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = GlobalCLIArgs(CLIArgs)

# Generated at 2022-06-25 13:04:40.301475
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, Singleton)
    assert issubclass(_ABCSingleton, ABCMeta)
    assert _ABCSingleton

if __name__ == '__main__':
    test_case_0()
    test__ABCSingleton()

# Generated at 2022-06-25 13:04:41.915556
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    tuple_0 = None
    global_c_l_i_args_0 = GlobalCLIArgs(tuple_0)

# Generated at 2022-06-25 13:04:51.362905
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Arrange
    dict_0 = {'a': 1, 'b': 2, 'c': 3}

    # Act
    global_c_l_i_args_0 = GlobalCLIArgs(dict_0)
    global_c_l_i_args_1 = GlobalCLIArgs(dict_0)

    # Assert
    assert(global_c_l_i_args_0 == global_c_l_i_args_1)
    assert(global_c_l_i_args_0 is global_c_l_i_args_1)


test_case = __name__ + ':test_GlobalCLIArgs'
# Allow unit testing of this file
if __name__ == '__main__':
    import sys
    sys.path.insert(0, '.')

# Generated at 2022-06-25 13:05:00.735857
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_args = {'a': 1, 'b': {'c': 2, 'd': [3, 4, 5], 'e': {'f': [6, 7, 8], 'g': {'h': 9}}}}

# Generated at 2022-06-25 13:05:02.442333
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert isinstance(_ABCSingleton, Singleton)
    assert isinstance(_ABCSingleton, ABCMeta)


# Generated at 2022-06-25 13:05:03.727765
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Test for __init__
    test_case_0()



# Generated at 2022-06-25 13:05:06.273676
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    try:
        test_case_0()
    except Exception as e:
        print('Error in class CLIArgs')
        raise e

# Generated at 2022-06-25 13:05:25.457192
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    c_l_i_args_0 = GlobalCLIArgs(tuple_0)


# Generated at 2022-06-25 13:05:26.456178
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    obj = _ABCSingleton()
    assert isinstance(obj, _ABCSingleton)



# Generated at 2022-06-25 13:05:27.650762
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class_0 = _ABCSingleton()



# Generated at 2022-06-25 13:05:28.755914
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    c_l_i_args_0 = GlobalCLIArgs()

# Generated at 2022-06-25 13:05:30.212149
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert isinstance(_ABCSingleton, Singleton)
    assert isinstance(_ABCSingleton, ABCMeta)

# Generated at 2022-06-25 13:05:34.283625
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    _abc_singleton_0 = _ABCSingleton()
    assert _abc_singleton_0._abc_registry == set()
    assert _abc_singleton_0._abc_cache == set()
    assert _abc_singleton_0._abc_negative_cache == set()


# Generated at 2022-06-25 13:05:36.047102
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    tuple_0 = None
    global_c_l_i_args_0 = GlobalCLIArgs(tuple_0)


# Generated at 2022-06-25 13:05:44.639400
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    x = GlobalCLIArgs
    x.a_mutable_list = [1, 2, 3]
    self.assertEqual(x.a_mutable_list.__class__, list)
    x.a_mutable_list.append(4)
    x.a_mutable_list.append(5)
    self.assertEqual(x.a_mutable_list, [1, 2, 3, 4, 5])
    x.a_mutable_dict = {'A': 'a', 'B': 'b'}
    self.assertEqual(x.a_mutable_dict.__class__, dict)
    x.a_mutable_dict.update({'C': 'c'})

# Generated at 2022-06-25 13:05:46.524691
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    tuple_1 = None
    global_c_l_i_args_0 = GlobalCLIArgs(tuple_1)


# Generated at 2022-06-25 13:05:55.396722
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from test.support import captured_stdout
    from types import MethodType

    class TestClass(_ABCSingleton):
        pass

    # Make sure that metaclass is a subclass of ABCMeta
    assert issubclass(_ABCSingleton, ABCMeta)

    # Make sure that metaclass is a subclass of Singleton
    assert issubclass(_ABCSingleton, Singleton)

    # Try to initialize instance of class TestClass
    with captured_stdout():
        test_class_0 = TestClass()
        test_class_1 = TestClass()

    # Make sure that instance of class TestClass is a valid instance
    assert type(test_class_0) == TestClass

    # Check if test_class_0 is the instance of TestClass
    assert test_class_0 == TestClass.instance()

    # Check if test_class_1 is

# Generated at 2022-06-25 13:06:32.578821
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    cls = _ABCSingleton('name', (), {})

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 13:06:33.283488
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs()


# Generated at 2022-06-25 13:06:33.740860
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert type(_ABCSingleton) == type

# Generated at 2022-06-25 13:06:34.868670
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    tuple_0 = None
    c_l_i_args_0 = CLIArgs(tuple_0)
    print(c_l_i_args_0)

# Generated at 2022-06-25 13:06:40.731760
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test 0 is in test_case_0
    # Test 1
    test_dict_1 = ImmutableDict((('a', 'b'), ))
    c_l_i_args_1 = CLIArgs(test_dict_1)
    assert c_l_i_args_1['a'] == 'b'
    # Test 2
    test_dict_2 = ImmutableDict((('a', 'b'), ))
    test_dict_1 = ImmutableDict((('c', test_dict_2), ))
    c_l_i_args_1 = CLIArgs(test_dict_1)
    assert c_l_i_args_1['c']['a'] == 'b'
    # Test 3
    test_set_3 = frozenset(('a', 'b'))
    test_dict_3

# Generated at 2022-06-25 13:06:43.960024
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    message = 'Argument tuple_0 must be of type tuple\n'
    with pytest.raises(TypeError) as excinfo:
        test_case_0()
    assert message in str(excinfo.value)



# Generated at 2022-06-25 13:06:46.882099
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    tuple_0 = None
    c_l_i_args_0 = CLIArgs(tuple_0)
    assert c_l_i_args_0 == None
    assert c_l_i_args_0 != []


# Generated at 2022-06-25 13:06:57.653049
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with an empty mapping
    tuple_0 = {}
    c_l_i_args_0 = CLIArgs(tuple_0)
    # Test with a non-empty mapping
    tuple_1 = {
        'key_0': 0,
        'key_1': 1
    }
    c_l_i_args_1 = CLIArgs(tuple_1)
    # Test with immutable objects
    str_1 = 'nt'
    list_0 = [
        'sh',
        0,
        1
    ]
    bool_0 = False
    dict_1 = {
        'key_0': 't',
        'key_1': 2
    }
    tuple_2 = (
        True,
        3,
        dict_1
    )

# Generated at 2022-06-25 13:06:59.218690
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs()


# Generated at 2022-06-25 13:07:05.675886
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Case 0
    tuple_0 = None
    c_l_i_args_0 = GlobalCLIArgs(tuple_0)
    assert isinstance(c_l_i_args_0, GlobalCLIArgs), "isinstance instance 0: {0}".format(repr(c_l_i_args_0))
    if sys.version_info < (3,):
        assert isinstance(c_l_i_args_0, ImmutableDict), "isinstance instance 0: {0}".format(repr(c_l_i_args_0))

# Generated at 2022-06-25 13:08:29.010811
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Make sure we can create a singleton class
    g_c_l_i_args_0 = GlobalCLIArgs(None)
    try:
        g_c_l_i_args_1 = GlobalCLIArgs(None)
    except:
        exception = True
    assert exception


# Generated at 2022-06-25 13:08:30.055260
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args_0 = GlobalCLIArgs()


# Generated at 2022-06-25 13:08:39.960093
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Test the calling of the constructor GlobalCLIArgs with a simple instance of dict()
    dict_0 = dict()
    dict_0["list_0"] = dict()
    dict_0["list_0"]["list_0"] = dict()
    dict_0["list_0"]["list_0"]["str_0"] = "str_0"
    dict_0["list_0"]["list_0"]["str_1"] = "str_1"
    dict_0["list_0"]["list_0"]["str_2"] = "str_2"
    dict_0["list_0"]["list_1"] = dict()
    dict_0["list_0"]["list_1"]["str_3"] = "str_3"

# Generated at 2022-06-25 13:08:42.186579
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    tuple_0 = None
    global_c_l_i_args_0 = GlobalCLIArgs(tuple_0)

# Generated at 2022-06-25 13:08:45.859380
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    tuple_0 = None
    c_l_i_args_0 = CLIArgs(tuple_0)
    assert(c_l_i_args_0 is not None)
    assert(isinstance(c_l_i_args_0, CLIArgs))


# Generated at 2022-06-25 13:08:47.076767
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_case_0()
    return None


# Generated at 2022-06-25 13:08:48.049498
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_case_0()


# Generated at 2022-06-25 13:08:58.070476
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-25 13:08:59.825658
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    tuple_0 = None
    c_l_i_args_1 = CLIArgs(tuple_0)


# Generated at 2022-06-25 13:09:10.566687
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.cli import CLI

    cli = CLI(args=[])
    loader, inventory, variable_manager = cli.playbook_loader()
    pbex = PlaybookExecutor(playbooks=[], inventory=inventory, variable_manager=variable_manager, loader=loader, options=ImmutableDict(), passwords={})
    global_cli_args_1 = GlobalCLIArgs()
    global_cli_args_2 = GlobalCLIArgs()