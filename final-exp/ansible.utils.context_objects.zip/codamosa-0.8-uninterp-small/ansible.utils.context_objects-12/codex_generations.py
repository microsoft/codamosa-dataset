

# Generated at 2022-06-25 13:00:45.710577
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import datetime
    pytest_plugins = sys._C_API.Py_GetGlobalVariables()
    pytest_plugins.global_c_l_i_args_0 = GlobalCLIArgs(
        'flatpak')

if __name__ == "__main__":
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:00:47.207190
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        _ABCSingleton()
    except TypeError:
        assert False



# Generated at 2022-06-25 13:00:49.604366
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    with Singleton():
        with Singleton():
            p = Singleton()
            assert p.__class__.__mro__[3] == Singleton


# Generated at 2022-06-25 13:00:51.862725
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_1 = 1262.076
    cli_args_0 = CLIArgs(float_1)


# Generated at 2022-06-25 13:00:52.822786
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    return


# Generated at 2022-06-25 13:00:53.960192
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    int_0 = 8
    _ABCSingleton(int_0)


# Generated at 2022-06-25 13:00:57.740205
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from unittest import TestCase
    from unittest import mock

    class TestABCSingleton(metaclass=_ABCSingleton):
        def __init__(self, x):
            self.x = x

    with TestCase().assertRaises(TypeError):
        TestABCSingleton(0, x=0)

    with TestCase().assertRaises(TypeError):
        TestABCSingleton(x=0)



# Generated at 2022-06-25 13:01:01.169401
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 1262.076
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)



if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 13:01:03.031440
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 1262.076
    cli_args_0 = CLIArgs(float_0)
    assert cli_args_0.__init__(cli_args_0) is None



# Generated at 2022-06-25 13:01:04.307826
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_0_case_0(() for _ in range(987))



# Generated at 2022-06-25 13:01:08.686769
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert not hasattr(_ABCSingleton(), '__init__')
    assert callable(getattr(_ABCSingleton(), '__new__'))
    assert True


# Generated at 2022-06-25 13:01:12.905176
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 1262.076
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)
    assert type(global_c_l_i_args_0) == GlobalCLIArgs
    assert isinstance(global_c_l_i_args_0, GlobalCLIArgs)


# Generated at 2022-06-25 13:01:14.648828
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()

if __name__ == '__main__':
    test__ABCSingleton()

# Generated at 2022-06-25 13:01:16.684892
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 1262.076
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)


# Generated at 2022-06-25 13:01:20.481672
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import random

    a = random.randint(1, 1000)
    b = random.randint(1, 1000)

    d = {b: a}

    c = CLIArgs(d)

    assert c[b] == a
    assert d == c


test_case_0()
test_CLIArgs()

# Generated at 2022-06-25 13:01:22.385875
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 1262.076
    global_c_l_i_args_0 = CLIArgs(float_0)

# Generated at 2022-06-25 13:01:31.131554
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    arg_dict = {
        'bool': True,
        'int': 12,
        'list': ['a', 'b', 'c'],
        'dict': {'a': 1, 'b': 2, 'c': 3},
        'set': {'a', 'b', 'c'},
    }
    instance = GlobalCLIArgs(arg_dict)
    assert(instance.bool == True)
    assert(instance.int == 12)
    assert(instance.list == ('a', 'b', 'c'))
    assert(instance.dict == ImmutableDict({'a': 1, 'b': 2, 'c': 3}))
    assert(instance.set == frozenset({'a', 'b', 'c'}))

    assert(isinstance(GlobalCLIArgs(arg_dict), GlobalCLIArgs))

# Generated at 2022-06-25 13:01:37.122540
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 1262.076
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)
    assert global_c_l_i_args_0.get_data() == 1262.076

# Generated at 2022-06-25 13:01:38.883787
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    obj = _ABCSingleton
    param_0 = {}
    obj(param_0)



# Generated at 2022-06-25 13:01:48.512405
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.six import assertCountEqual
    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock
    immutabledict_0 = ImmutableDict({"x": "y"})
    float_0 = 1262.076
    mapping_0 = {'b': 'm', 'c': immutabledict_0, 'a': float_0}
    immutabledict_1 = ImmutableDict(mapping_0)
    bool_0 = bool(immutabledict_1)
    assert bool_0
    args = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    # Constructor test case
    test_case_0 = CLIArgs(args)
    # Make sure the

# Generated at 2022-06-25 13:01:54.793497
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_1 = 1262.076
    global_c_l_i_args_0 = GlobalCLIArgs(float_1)
    # Assert that GlobalCLIArgs(float) produces no errors
# test_case_0()

# Generated at 2022-06-25 13:01:55.753171
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_case_0()
    

# Generated at 2022-06-25 13:02:01.988131
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    print("Testing GlobalCLIArgs")
    assert(GlobalCLIArgs(1) == GlobalCLIArgs(1))
    assert(GlobalCLIArgs(1) is GlobalCLIArgs(1))
    assert(GlobalCLIArgs(1) != GlobalCLIArgs(2))
    assert(GlobalCLIArgs(1) is not GlobalCLIArgs(2))
    assert(GlobalCLIArgs(1).__dict__ == GlobalCLIArgs(1).__dict__)


# Generated at 2022-06-25 13:02:06.858125
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    float_1 = 1262.076
    global_c_l_i_args_1 = GlobalCLIArgs(float_1)
    # Use a static method from the Singleton class
    _ABCSingleton._reset_instances()
    float_2 = 1262.076
    global_c_l_i_args_2 = GlobalCLIArgs(float_2)
    return


# Generated at 2022-06-25 13:02:09.257018
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    _ABCSingleton_0 = _ABCSingleton
    assert _ABCSingleton_0.__name__ == '_ABCSingleton'


# Generated at 2022-06-25 13:02:13.807394
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    c_l_i_args_1 = CLIArgs(1)
    assert isinstance(c_l_i_args_1, CLIArgs)
    assert isinstance(c_l_i_args_1, ImmutableDict)
    # Check if the static method from_options has been defined
    assert callable(getattr(CLIArgs, 'from_options', None))



# Generated at 2022-06-25 13:02:22.954579
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args0 = CLIArgs({'force': True, 'diff': False, 'check': True, 'tags': ['all', 'pre_tasks'], 'syntax': True, 'skip_tags': ['never']})
    assert isinstance(cli_args0, CLIArgs) == True
    assert cli_args0.get('force') == True
    assert cli_args0.get('diff') == False
    assert cli_args0.get('check') == True
    assert isinstance(cli_args0.get('tags'), list) == True
    assert cli_args0.get('tags')[0] == 'all'
    assert cli_args0.get('tags')[1] == 'pre_tasks'
    assert cli_args0.get('syntax') == True

# Generated at 2022-06-25 13:02:24.127319
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    pass


# Generated at 2022-06-25 13:02:25.325814
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert _ABCSingleton()

# Generated at 2022-06-25 13:02:33.834774
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    single_0 = _ABCSingleton()
    assert single_0.isMutable() is False
    assert single_0.isNotMutable() is True
    assert single_0.isMapping() is False
    assert single_0.isNotMapping() is True
    assert single_0.isSequence() is False
    assert single_0.isNotSequence() is True
    assert single_0.isHashable() is False
    assert single_0.isNotHashable() is True
    assert single_0.isContainer() is False
    assert single_0.isNotContainer() is True


# Generated at 2022-06-25 13:02:40.805467
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    c_l_i_args_0 = GlobalCLIArgs.instance()
    c_l_i_args_0.__class__.__name__
    c_l_i_args_0.instance()


# Generated at 2022-06-25 13:02:41.599537
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()



# Generated at 2022-06-25 13:02:42.835929
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    _ABCSingleton()


# Generated at 2022-06-25 13:02:44.946107
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    try:
        test_case_0()
    except:
        print ("test failed")
    else:
        print ("test passed")

# Generated at 2022-06-25 13:02:46.824496
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 1262.076
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)


# Generated at 2022-06-25 13:02:49.252444
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 1262.076
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)
# End of test_GlobalCLIArgs



# Generated at 2022-06-25 13:02:50.112558
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_case_0()


# Generated at 2022-06-25 13:02:57.402309
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-25 13:02:58.747408
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    float_0 = 1262.076
    _ABCSingleton_0 = _ABCSingleton(float_0)


# Generated at 2022-06-25 13:03:07.967682
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from collections import Mapping, Sequence, Set, MutableMapping, MutableSequence, MutableSet
    from ansible.module_utils.common.collections import ImmutableDict

    dict_0 = {u'foo': u'bar', u'baz': 'qux'}

    cli_args_0 = CLIArgs(dict_0)
    # Check that cli_args_0 is a ImmutableDict
    assert isinstance(cli_args_0, ImmutableDict)

    list_0 = ['foo']

    cli_args_1 = CLIArgs(list_0)
    # Check that cli_args_1 is a tuple
    assert isinstance(cli_args_1, tuple)

    set_0 = {'foo'}

    cli_args_2 = CLIArgs(set_0)


# Generated at 2022-06-25 13:03:15.700830
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 843.947
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)


if __name__ == '__main__':
    test_case_0()
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:03:18.612910
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 1262.076
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)
    assert isinstance(global_c_l_i_args_0, ImmutableDict)


# Generated at 2022-06-25 13:03:20.390437
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 1262.076
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)

# Generated at 2022-06-25 13:03:30.073389
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 1262.076
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)
    float_1 = -1110.5
    global_c_l_i_args_1 = GlobalCLIArgs(float_1)
    float_2 = -1110.5
    global_c_l_i_args_2 = GlobalCLIArgs(float_2)
    assert id(global_c_l_i_args_0) == id(global_c_l_i_args_1)
    assert id(global_c_l_i_args_0) == id(global_c_l_i_args_2)
    assert id(global_c_l_i_args_1) == id(global_c_l_i_args_2)



# Generated at 2022-06-25 13:03:30.963515
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_case_0()


# Generated at 2022-06-25 13:03:33.031207
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    float_0 = 1262.076
    _ABCSingleton_0 = _ABCSingleton(float_0)


# Generated at 2022-06-25 13:03:34.872334
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 1262.076
    global_c_l_i_args_0 = CLIArgs(float_0)


# Generated at 2022-06-25 13:03:36.293722
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()


# Generated at 2022-06-25 13:03:38.141042
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    float_0 = 1262.076
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)


# Generated at 2022-06-25 13:03:40.349115
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    float_0 = 1262.076
    global_c_l_i_args_0 = _ABCSingleton(float_0)
    assert isinstance(global_c_l_i_args_0, _ABCSingleton)


# Generated at 2022-06-25 13:03:52.277285
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 1262.076
    global_c_l_i_args_0 = CLIArgs(float_0)

if __name__ == '__main__':
    test_CLIArgs()

# Generated at 2022-06-25 13:03:54.704863
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    global_c_l_i_args_0 = GlobalCLIArgs.get_instance()
    global_c_l_i_args_0.__init__()


# Generated at 2022-06-25 13:03:56.498404
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 1262.076
    global_c_l_i_args_0 = CLIArgs(float_0)


# Generated at 2022-06-25 13:03:58.296862
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Too many arguments for method test_case_0
    with raises(TypeError):
        test_case_0()


# Generated at 2022-06-25 13:04:00.007083
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    global_c_l_i_args_0 = CLIArgs(dict())



# Generated at 2022-06-25 13:04:04.755299
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Test if number of arguments is correct
    if len(argv) != 2:
        print("TEST CASE 0 FAILED")
        return
    # Test if result is correct
    if test_case_0() == 0:
        print("TEST CASE 0 PASSED")
        return
    else:
        print("TEST CASE 0 FAILED")
        return

test_GlobalCLIArgs()

# Generated at 2022-06-25 13:04:07.376438
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {}
    obj_0 = CLIArgs(mapping)
    if obj_0.value == {}:
        print('PASS')
    else:
        print('FAIL')


# Generated at 2022-06-25 13:04:11.253153
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 1262.076
    # initialization of class
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)
    # verification of class attributes
    assert isinstance(global_c_l_i_args_0, Singleton)


# Generated at 2022-06-25 13:04:13.156001
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 1262.076
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)


# Generated at 2022-06-25 13:04:14.922593
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_1 = 1262.076
    assert CLIArgs(float_1)



# Generated at 2022-06-25 13:04:44.544411
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = -66.94848630498835
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)
    mapping_0 = {}
    cli_args_0 = CLIArgs(mapping_0)
    assert cli_args_0 is not global_c_l_i_args_0


# Generated at 2022-06-25 13:04:46.206396
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 13:04:53.585548
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 1262.076
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)
    assert isinstance(global_c_l_i_args_0, GlobalCLIArgs)
    assert isinstance(global_c_l_i_args_0, CLIArgs)
    assert isinstance(global_c_l_i_args_0, ImmutableDict)
    assert isinstance(global_c_l_i_args_0, Mapping)
    assert isinstance(global_c_l_i_args_0, Container)
    assert isinstance(global_c_l_i_args_0, object)
    assert done


# Generated at 2022-06-25 13:04:58.318151
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 1262.076
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)


if __name__ == '__main__':
    test_case_0()
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:05:00.551696
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_case_0()

# Unit Test the file, run this by calling the below
# python -m ansible.module_utils.common.arguments

# Generated at 2022-06-25 13:05:03.687762
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        obj = _ABCSingleton()
    except Exception as e:
        assert False, f"Exception thrown: {e}"
    else:
        assert True, "Constructor for _ABCSingleton returned without error"


# Generated at 2022-06-25 13:05:08.583404
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = 'ab'
    b = GlobalCLIArgs({a: 'z', 'xx': {a: 2, 'yy': [{a: 'x'}]}})
    assert isinstance(b, CLIArgs)


if __name__ == '__main__':
    import sys
    import pytest

    pytest.main([__file__] + sys.argv[1:])

# Generated at 2022-06-25 13:05:10.193968
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 1262.076
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)

# Generated at 2022-06-25 13:05:17.049730
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    try:
        # Initialize an object of type CLIArgs with a string object
        float_1 = 1262.076
        global_c_l_i_args_0 = GlobalCLIArgs(float_1)
    except ValueError as error_msg:
        print(error_msg)

if __name__ == '__main__':
    test_case_0()
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:05:24.573578
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 1262.076
    global_cli_args_0 = GlobalCLIArgs(float_0)
    assert type is type(global_cli_args_0)
    assert isinstance(global_cli_args_0, GlobalCLIArgs)
    assert isinstance(global_cli_args_0, ImmutableDict)
    assert isinstance(global_cli_args_0, Mapping)
    assert len(global_cli_args_0) == 1
    assert global_cli_args_0[0] == float_0
    assert global_cli_args_0 == float_0
    assert float_0 == global_cli_args_0

if __name__ == '__main__':
    test_case_0()
    test_GlobalCLIArgs()
    print('test success')

# Generated at 2022-06-25 13:06:00.649039
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_case_0()

if __name__ == '__main__':
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:06:03.490227
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 1262.076
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)



# Generated at 2022-06-25 13:06:05.083598
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    global_c_l_i_args_0 = GlobalCLIArgs.from_options({})


# Generated at 2022-06-25 13:06:07.191419
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert (Singleton.__class__.__mro__[0] == _ABCSingleton) # Singleton is first in method resolution order


# Generated at 2022-06-25 13:06:08.422540
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Just make it to the end of the class' constructor
    assert True

# Generated at 2022-06-25 13:06:14.633487
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    '''constructor of class _ABCSingleton'''
    global_c_l_i_args_0 = GlobalCLIArgs(1)
    global_c_l_i_args_1 = GlobalCLIArgs(2)
    global_c_l_i_args_2 = GlobalCLIArgs(3)
    assert global_c_l_i_args_0 is global_c_l_i_args_1
    assert global_c_l_i_args_1 is global_c_l_i_args_2
    assert global_c_l_i_args_2 is global_c_l_i_args_0


if __name__ == '__main__':
    test__ABCSingleton()

# Generated at 2022-06-25 13:06:15.161577
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert True

# Generated at 2022-06-25 13:06:20.584135
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Type check for function: constructor of class CLIArgs
    float_0 = 0.0
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)
    int_0 = 0
    global_c_l_i_args_1 = GlobalCLIArgs(int_0)
    dict_0 = {}
    global_c_l_i_args_2 = GlobalCLIArgs(dict_0)


test_CLIArgs()

# Generated at 2022-06-25 13:06:25.352343
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, Singleton)
    assert issubclass(_ABCSingleton, ABCMeta)
    assert not issubclass(type, _ABCSingleton)
    assert _ABCSingleton.__class__ is ABCMeta
    assert not hasattr(_ABCSingleton, 'abc')


# Generated at 2022-06-25 13:06:26.923631
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = GlobalCLIArgs()


test_case_0()

# Generated at 2022-06-25 13:07:47.348382
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_case_0()

if __name__ == '__main__':
    import sys
    import pytest
    rc = pytest.main(sys.argv[1:])
    exit(rc)

# Generated at 2022-06-25 13:07:48.473245
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 1262.076
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)


# Generated at 2022-06-25 13:07:51.074379
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    # Call constructor using positional arguments
    CLI_Args_0 = CLIArgs(float_0)

    # Call constructor using keyword arguments
    # Pass the following arguments:
    #   mapping = float_0
    CLI_Args_1 = CLIArgs(mapping=float_0)


# Generated at 2022-06-25 13:07:52.413377
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    global_c_l_i_args_0 = _ABCSingleton(1262.076)


# Generated at 2022-06-25 13:07:54.061150
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 1262.076
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)


# Generated at 2022-06-25 13:07:55.585866
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 1262.076
    cli_args_1 = CLIArgs(float_0)


# Generated at 2022-06-25 13:08:02.014219
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    try:
        import __main__
        if hasattr(__main__, '__file__'):
            sys.stderr.write('FATAL: You must run this through the ansible-test code path to use the CLI args test\n')
            sys.exit(1)
    except Exception:
        sys.stderr.write('FATAL: You must run this through the ansible-test code path to use the CLI args test\n')
        sys.exit(1)

    test_case_0()
    test_case_1()


if __name__ == '__main__':
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:08:10.500945
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 1262.076
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)

if __name__ == "__main__":
    import sys
    import logging
    logging.basicConfig(
        format='%(levelname)s:%(message)s', level=logging.DEBUG)
    logging.debug("Running tests for cliargs")
    if len(sys.argv) > 1:
        logging.debug("Setting up argument parsing")
        sys.argv = sys.argv[:1]
        test_case_0()
    test_GlobalCLIArgs()
    logging.debug("Done running tests for cliargs")

# Generated at 2022-06-25 13:08:14.237970
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert isinstance(_ABCSingleton, ABCMeta)
    assert isinstance(_ABCSingleton, type)
    assert issubclass(_ABCSingleton, type)
    assert issubclass(_ABCSingleton, ABCMeta)
    assert issubclass(_ABCSingleton, Singleton)
    assert callable(_ABCSingleton)


# Generated at 2022-06-25 13:08:16.140185
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 1262.076
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)
