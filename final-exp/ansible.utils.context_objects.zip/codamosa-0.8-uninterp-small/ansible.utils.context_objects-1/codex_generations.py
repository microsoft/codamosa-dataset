

# Generated at 2022-06-25 13:00:44.269561
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    try:
        # Initialize with 0
        test_case_0()
    except Exception as exception:
        # Print out the exception
        print(exception)
        return

# Generated at 2022-06-25 13:00:45.215039
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()

# Generated at 2022-06-25 13:00:47.596873
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = GlobalCLIArgs()
    assert isinstance(global_c_l_i_args_0, GlobalCLIArgs)


# Generated at 2022-06-25 13:00:49.648960
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_case_0()
    return True

if __name__ == '__main__':
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:00:51.906569
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    with pytest.raises(TypeError):
        _ABCSingleton.__call__(_ABCSingleton)


# Generated at 2022-06-25 13:00:55.546388
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = -3364.8
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)

    float_0 = -3364.8
    cli_args_0 = CLIArgs(float_0)


if __name__ == '__main__':
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:00:58.219916
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = -3364.8
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)

# Generated at 2022-06-25 13:01:02.801779
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # There are no valid C++ types for the argument(s) of GlobalCLIArgs::GlobalCLIArgs.
    # Use GlobalCLIArgs::GlobalCLIArgs(float) instead.
    #test_case_0()
    pass

if __name__ == '__main__':
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:01:09.154097
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = -3364.8
    dict_0 = {-6106.4: float_0, 'n}': {'#us>`': {'': '', '5zH-': []}, 'v': ''}, ' ': '', '7': {'j': {'2': ''}, 'x': float_0}, float_0: float_0, ' ': '7', float_0: float_0, float_0: float_0}
    cli_args_0 = CLIArgs(dict_0)
    assert cli_args_0.__class__ == CLIArgs



# Generated at 2022-06-25 13:01:10.442590
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class_0 = _ABCSingleton()


# Generated at 2022-06-25 13:01:14.530466
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    _ABCSingleton()



# Generated at 2022-06-25 13:01:23.478370
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_0 = None
    global_c_l_i_args_0 = GlobalCLIArgs(bool_0)
    str_0 = "7J|th=yI]^U="
    str_1 = "["
    str_2 = "Tm>Mj"
    str_3 = "Ti{Q+."
    str_4 = "^]V7Z"
    str_5 = "|M?#}"
    str_6 = "J{Y?]"
    str_7 = "rq3|T"
    str_8 = "\\JLuR"
    str_9 = "l+\\`"
    str_10 = "A(}8"
    str_11 = "q3t+"
    str_12 = "1k^"
    str_13 = "8w]"

# Generated at 2022-06-25 13:01:28.014303
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_0 = None
    global_c_l_i_args_0 = GlobalCLIArgs(bool_0)
    bool_1 = None
    global_c_l_i_args_1 = GlobalCLIArgs(bool_1)
    assert global_c_l_i_args_0 == global_c_l_i_args_1


# Generated at 2022-06-25 13:01:31.623429
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    # Create an instance of class _ABCSingleton
    abcsingleton_0 = _ABCSingleton()

    # Try to create an instance of class _ABCSingleton
    try:
        Singleton()
    except TypeError as exception:
        assert True
    else:
        assert False



# Generated at 2022-06-25 13:01:36.171028
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args_0 = GlobalCLIArgs()
    assert True if global_cli_args_0 else False


# Generated at 2022-06-25 13:01:37.875191
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = None
    c_l_i_args_0 = CLIArgs(bool_0)


# Generated at 2022-06-25 13:01:39.393433
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert isinstance(CLIArgs, object)


# Generated at 2022-06-25 13:01:45.522179
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args_0 = GlobalCLIArgs(bool)
    assert isinstance(args_0, CLIArgs)
    bool_0 = bool
    c_l_i_args_0 = CLIArgs(bool_0)
    str_0 = 'Test'
    c_l_i_args_1 = CLIArgs(str_0)
    assert c_l_i_args_0 == c_l_i_args_1


# Generated at 2022-06-25 13:01:46.517793
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_0 = None
    global_c_l_i_args_0 = GlobalCLIArgs(bool_0)


# Generated at 2022-06-25 13:01:48.100514
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Test with default parameter values
    obj = _ABCSingleton()



# Generated at 2022-06-25 13:01:53.726249
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_0 = None
    global_c_l_i_args = GlobalCLIArgs(bool_0)


# Generated at 2022-06-25 13:02:03.990829
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-25 13:02:06.579023
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = {}
    c_l_i_args_0 = CLIArgs(bool_0)
    assert c_l_i_args_0 != None # constructed object should not be None



# Generated at 2022-06-25 13:02:08.598526
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_0 = None
    global_c_l_i_args_0 = GlobalCLIArgs(bool_0)

# Generated at 2022-06-25 13:02:16.169753
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs_class = GlobalCLIArgs()
    GlobalCLIArgs_class = GlobalCLIArgs()
    c_l_i_args_1 = CLIArgs(bool)
    global_c_l_i_args_0 = GlobalCLIArgs(c_l_i_args_1)

# Example of using GlobalCLIArgs in context
# def test_GlobalCLIArgs():
#     try:
#         from ansible.module_utils.ansible_release import __version__ as version
#         c_l_i_args_1 = CLIArgs(bool)
#         GlobalCLIArgs(c_l_i_args_1)
#     except Exception as exception_func:
#         print(exception_func)


if __name__ == '__main__':
    test_case_0()
   

# Generated at 2022-06-25 13:02:19.231004
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class_0 = CLIArgs(dict())
    class_1 = CLIArgs(dict(list()))
    assert class_1.from_options(dict())
    assert class_1.from_options(dict(list()))


# Generated at 2022-06-25 13:02:22.303430
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    arg1 = {'connection': 'local', 'foo': 'bar', 'module_path': '/home/neha/ansible/library'} 
    global_c_l_i_args_0 = GlobalCLIArgs(arg1)

# Generated at 2022-06-25 13:02:23.672608
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    init_0 = GlobalCLIArgs()


# Generated at 2022-06-25 13:02:24.944536
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_case_0()


# Generated at 2022-06-25 13:02:27.063392
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert False # TODO: implement your test here


# Generated at 2022-06-25 13:02:35.739168
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    pass



# Generated at 2022-06-25 13:02:38.133893
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Test for class _ABCSingleton
    obj_0 = _ABCSingleton()


# Generated at 2022-06-25 13:02:48.646519
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from types import MethodType

    class A(metaclass=_ABCSingleton):
        def f(self):
            pass

        def g(self, x):
            return x + 1

    # class A is a subclass of Singleton
    assert issubclass(A, Singleton)

    # class A is a subclass of ABCMeta
    assert issubclass(A, ABCMeta)

    # the __new__ method of ABCMeta is properly overridden
    assert A.__new__.__func__ is ABCMeta.__new__.__func__

    # the __classcell__ attribute of ABCMeta is properly inherited
    assert A.__classcell__ is ABCMeta.__classcell__

    # check that the __new__ method of Singleton is properly overridden
    assert A.__new__.__func__ is Singleton.__new__.__

# Generated at 2022-06-25 13:02:50.401392
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = None
    c_l_i_args_0 = CLIArgs(bool_0)


# Generated at 2022-06-25 13:02:55.673554
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    ca_gs_gsb_0 = GlobalCLIArgs()
    assert isinstance(ca_gs_gsb_0, GlobalCLIArgs)
    ca_gs_gsb_1 = GlobalCLIArgs()
    assert ca_gs_gsb_0 is ca_gs_gsb_1
    assert isinstance(ca_gs_gsb_0, ImmutableDict)
    assert isinstance(ca_gs_gsb_1, ImmutableDict)


# Generated at 2022-06-25 13:02:57.296366
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_0 = None
    global_c_l_i_args_0 = GlobalCLIArgs(bool_0)

# Generated at 2022-06-25 13:03:00.024118
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    c_l_i_args_1 = CLIArgs(None)
    bool_1 = isinstance(c_l_i_args_1, _ABCSingleton)
    assert bool_1 is True


# Generated at 2022-06-25 13:03:09.063753
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # from ansible.module_utils.common._collections_compat import Mapping
    # from ansible.module_utils.common.collections import ImmutableDict

    # Initialize a mapping
    mapping = {"test": True}
    c_l_i_args_1 = CLIArgs(mapping)
    assert isinstance(c_l_i_args_1, Mapping)
    assert isinstance(c_l_i_args_1, ImmutableDict)
    assert len(c_l_i_args_1) == 1
    assert c_l_i_args_1["test"]

    # Initialize a non-mapping
    c_l_i_args_2 = CLIArgs("a string")
    assert isinstance(c_l_i_args_2, Mapping)

# Generated at 2022-06-25 13:03:11.241702
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # implement the actual test for this method here
    assert True

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 13:03:12.443290
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert isinstance(GlobalCLIArgs(), GlobalCLIArgs)


# Generated at 2022-06-25 13:03:25.154015
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_0 = None
    global_c_l_i_args_0 = GlobalCLIArgs(bool_0)
    return global_c_l_i_args_0

# Generated at 2022-06-25 13:03:27.433310
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    global bool_0
    bool_0 = False
    c_l_i_args_0 = CLIArgs(bool_0)

# Generated at 2022-06-25 13:03:32.497109
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = vars(dict(action='store_true'))
    options1 = vars(dict(action='store_true', help='help'))
    cli_args_object = CLIArgs(options)
    global_cli_args_object = GlobalCLIArgs(options1)

if __name__ == '__main__':
    test_case_0()
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:03:40.937292
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    import ansible.constants as C
    options = C.config.command_defaults

    loader = DataLoader()  # Takes care of finding and reading yaml, json and ini files
    passwords = dict()

    # Instantiate our ResultCallback for handling results as they come in
    results_callback = ResultCallback()

    # create inventory and pass to var manager
    inventory = InventoryManager(loader=loader, sources=['localhost'])

# Generated at 2022-06-25 13:03:48.533196
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_0 = GlobalCLIArgs()
    bool_1 = GlobalCLIArgs()
    assert bool_0 is bool_1, 'Expected GlobalCLIArgs() is GlobalCLIArgs(), but got: %s' % (repr(bool_0))
    assert bool_0 is not bool_1, 'Expected GlobalCLIArgs() is not GlobalCLIArgs(), but got: %s' % (repr(bool_0))


if __name__ == "__main__":
    import sys
    import nose2

    sys.argv.append('-v')
    nose2.main()

# Generated at 2022-06-25 13:03:49.682222
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    obj = _ABCSingleton()


# Generated at 2022-06-25 13:03:51.269539
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = None
    c_l_i_args_0 = CLIArgs(bool_0)


# Generated at 2022-06-25 13:03:54.468097
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # We don't know if we are getting the right default right now.  The default is
    # the current command line arguments so we can't currently test the default
    # We do know that we don't crash
    GlobalCLIArgs()


# Generated at 2022-06-25 13:03:58.562658
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = None
    c_l_i_args_0 = CLIArgs(bool_0)

# Generated at 2022-06-25 13:04:03.800352
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    c_l_i_args_0 = CLIArgs(None)
    global_c_l_i_args_0 = GlobalCLIArgs(None)
    temp_value = isinstance(c_l_i_args_0, _ABCSingleton)
    temp_value_1 = isinstance(global_c_l_i_args_0, _ABCSingleton)
    print(temp_value)
    print(temp_value_1)


# Generated at 2022-06-25 13:04:28.460191
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, Singleton)
    assert issubclass(_ABCSingleton, ABCMeta)
    assert isinstance(_ABCSingleton, type)
    assert _ABCSingleton is _ABCSingleton

# Generated at 2022-06-25 13:04:38.169132
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_1 = None
    c_l_i_args_0 = CLIArgs(bool_1)
    assert c_l_i_args_0.data == {}
    with raises(Exception):
        c_l_i_args_0._data
    with raises(Exception):
        c_l_i_args_0._data = 'my_dict'
    with raises(Exception):
        c_l_i_args_0._data = set()
    with raises(Exception):
        c_l_i_args_0._data = {}
    with raises(Exception):
        c_l_i_args_0.data = {}
    # Assigning to member 'data' of immutable object
    # with raises(Exception):
    #     c_l_i_args_0.data = set()
    # Assigning to

# Generated at 2022-06-25 13:04:40.759617
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        _ABCSingleton_0 = _ABCSingleton()
    except TypeError as e:
        assert '__call__' in str(e)


# Generated at 2022-06-25 13:04:43.592940
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        _ABCSingleton_instance_0 = _ABCSingleton()
    except Exception as e:
        _ABCSingleton_instance_0 = None
    assert _ABCSingleton_instance_0 is not None



# Generated at 2022-06-25 13:04:45.477637
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    temp = _ABCSingleton()


# Generated at 2022-06-25 13:04:46.991111
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Test with default
    bool_0 = GlobalCLIArgs()
    assert bool_0 is not None

# Generated at 2022-06-25 13:04:47.774771
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # TODO: implement
    pass


# Generated at 2022-06-25 13:04:50.530735
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = None
    c_l_i_args_0 = CLIArgs(bool_0)
    
if __name__ == '__main__':
    test_CLIArgs()

# Generated at 2022-06-25 13:04:53.447629
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_0 = None
    global_c_l_i_args_0 = GlobalCLIArgs(bool_0)
    return (global_c_l_i_args_0)


# Generated at 2022-06-25 13:04:55.723752
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = None
    c_l_i_args_0 = CLIArgs(bool_0)


# Generated at 2022-06-25 13:05:47.500310
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # bool_0 = None
    options_0 = set()


    # python2.7 function with error
    # c_l_i_args_0 = CLIArgs.from_options(options_0)
    c_l_i_args_0 = CLIArgs(options_0)
    # c_l_i_args_0.__init__(bool_0)
    c_l_i_args_1 = CLIArgs(c_l_i_args_0)



# Generated at 2022-06-25 13:05:50.766242
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_0 = None
    c_l_i_args_0 = GlobalCLIArgs(bool_0)


if __name__ == '__main__':
    test_case_0()
    # Unit test GlobalCLIArgs
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:05:52.209630
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = None
    c_l_i_args_0 = CLIArgs(bool_0)


# Generated at 2022-06-25 13:06:04.182961
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Instantiation of class _ABCSingleton with args foo
    _1 = _ABCSingleton(foo='foo')
    assert _1.__base__ is Singleton
    assert _1.__doc__ is None
    assert _1.__metaclass__ is ABCMeta
    assert _1.__module__ == 'ansible.module_utils.basic.common'
    _2 = _ABCSingleton(foo='foo')
    assert _1 is not _2
    assert _2.__base__ is Singleton
    assert _2.__doc__ is None
    assert _2.__metaclass__ is ABCMeta
    assert _2.__module__ == 'ansible.module_utils.basic.common'
    # Instantiation of class _ABCSingleton with args foo, bar

# Generated at 2022-06-25 13:06:12.719360
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Testing the constructor allowing a simple dict
    dict_0 = {"key_0": "value_0", "key_1": "value_1"}
    c_l_i_args_0 = CLIArgs(dict_0)

    # Testing the constructor allowing a dict with a nested dict
    dict_1 = {"key_0": "value_0", "key_1": {"key_0": "value_0", "key_1": "value_1"}}
    c_l_i_args_1 = CLIArgs(dict_1)

    # Testing the constructor allowing a dict with a nested list with a dict

# Generated at 2022-06-25 13:06:14.413808
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_0 = None
    global_c_l_i_args_0 = GlobalCLIArgs(bool_0)

# Generated at 2022-06-25 13:06:19.984339
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    def test__ABCSingleton_0():
        abcsingleton_0 = _ABCSingleton()

    def test__ABCSingleton_1():
        abcsingleton_0 = _ABCSingleton(bool_0)

    bool_0 = None
    try:
        test__ABCSingleton_0()
    except TypeError as error:
        print(error)
    try:
        test__ABCSingleton_1()
    except TypeError as error:
        print(error)


# Generated at 2022-06-25 13:06:22.998492
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    print('\nRunning test_CLIArgs')
    assert CLIArgs({'k0': 'v0'}) is not None
    assert CLIArgs(None) is not None
    print('\nPass\n')


# Generated at 2022-06-25 13:06:26.062235
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Create a new GlobalCLIArgs object
    global_c_l_i_args_0 = GlobalCLIArgs(dict)

# Generated at 2022-06-25 13:06:28.346254
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    dict_1 = dict()
    ansible_wrapper = GlobalCLIArgs.from_options(dict_1)
    assert ansible_wrapper is not None


# Generated at 2022-06-25 13:08:13.339664
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert hasattr(_ABCSingleton, '__new__')


# Generated at 2022-06-25 13:08:15.546177
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        assert True
    except AssertionError as ae:
        raise AssertionError('Assertion failed in test_case_0')


# Generated at 2022-06-25 13:08:17.193785
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    param0 = {"key0": "value0", "key1": "value1"}
    test_case_0(param0)

# Generated at 2022-06-25 13:08:17.961073
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert True


# Generated at 2022-06-25 13:08:19.264200
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = None
    c_l_i_args_0 = CLIArgs(bool_0)


# Generated at 2022-06-25 13:08:22.578328
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    tuple_0 = ()
    set_0 = set(tuple_0)
    dict_0 = dict((frozenset(set_0), 7))
    list_0 = list(dict_0)
    dict_1 = dict((frozenset(set_0), 7))
    list_1 = list(dict_1)
    global_c_l_i_args_0 = GlobalCLIArgs(list_1)

# Generated at 2022-06-25 13:08:23.520217
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = None
    c_l_i_args_0 = CLIArgs(bool_0)



# Generated at 2022-06-25 13:08:25.547257
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_0 = None
    global_c_l_i_args_0 = GlobalCLIArgs(bool_0)

# Generated at 2022-06-25 13:08:33.281244
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.utils.singleton import Singleton
    from collections import OrderedDict
    from copy import deepcopy
    from test.support.script_helper import assert_python_ok
    from types import ClassType, ModuleType
    # Check that _ABCSingleton is a (old style) class
    assert isinstance(_ABCSingleton, ClassType)
    # Example bool_0
    bool_0 = None
    # Example c_l_i_args_0
    c_l_i_args_0 = CLIArgs(bool_0)
    # Example c_l_i_args_1
    c_l_i_args_1 = deepcopy(c_l_i_args_0)
    c_l_i_args_1 = GlobalCLIArgs.from_options(c_l_i_args_1)

# Generated at 2022-06-25 13:08:35.909967
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_0 = GlobalCLIArgs()
