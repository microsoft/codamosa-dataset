

# Generated at 2022-06-25 13:00:51.074959
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = GlobalCLIArgs()
    assert isinstance(global_c_l_i_args_0, GlobalCLIArgs)
    assert global_c_l_i_args_0.__class__.__name__ == 'GlobalCLIArgs'
    global_c_l_i_args_1 = GlobalCLIArgs(**{'a': 1, 'b': 2})
    assert isinstance(global_c_l_i_args_1, GlobalCLIArgs)
    assert global_c_l_i_args_1.__class__.__name__ == 'GlobalCLIArgs'


# Generated at 2022-06-25 13:00:55.583252
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    data_mapping = {
        'extra-vars': ('one', 'two', 'three'),
        'tags': ('one', 'two', 'three'),
        'skip-tags': ('one', 'two', 'three')
    }

    cli_args = CLIArgs(data_mapping)
    for key, value in data_mapping.items():
        assert value == cli_args[key]



# Generated at 2022-06-25 13:01:03.305707
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    print("Test constructor of class CLIArgs")
    bytes_1 = b'\x8f\xc8\x1d\xbc\xddG\xdd6\xdah\xc4\x82\xbc\x1a\x04\xfb\xf8\nZ'
    toplevel_1 = {}
    for key, value in bytes_1.items():
        toplevel_1[key] = _make_immutable(value)
    cli_args_0 = CLIArgs(toplevel_1)




# Generated at 2022-06-25 13:01:11.013600
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test case 1:
    bytes_0 = b'\x8f\xc8\x1d\xbc\xddG\xdd6\xdah\xc4\x82\xbc\x1a\x04\xfb\xf8\nZ'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)
    assert isinstance(global_c_l_i_args_0, GlobalCLIArgs)
    assert issubclass(GlobalCLIArgs, ImmutableDict)
    assert issubclass(GlobalCLIArgs, Container)
    assert issubclass(GlobalCLIArgs, Mapping)
    assert issubclass(GlobalCLIArgs, Sequence)
    assert issubclass(GlobalCLIArgs, object)

# Generated at 2022-06-25 13:01:15.839177
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils.common._collections_compat import (Container, Mapping, Sequence, Set)
    from ansible.utils.singleton import Singleton
    # ABCMeta arguments (kwargs only)
    # Singleton arguments (kwargs only)
    def test_class_creation():
        class GlobalCLIArgs(CLIArgs):
            pass
    test_class_creation()



# Generated at 2022-06-25 13:01:20.124208
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bytes_0 = b'\x8f\xc8\x1d\xbc\xddG\xdd6\xdah\xc4\x82\xbc\x1a\x04\xfb\xf8\nZ'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)


# Generated at 2022-06-25 13:01:27.468430
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from unittest import TestCase as A

# Generated at 2022-06-25 13:01:28.367617
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs.__init__


# Generated at 2022-06-25 13:01:34.612191
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bytes_0 = b'\x8f\xc8\x1d\xbc\xddG\xdd6\xdah\xc4\x82\xbc\x1a\x04\xfb\xf8\nZ'
    global_c_l_i_args_0 = GlobalCLIArgs(bytes_0)

# Generated at 2022-06-25 13:01:35.711533
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    _ABCSingleton()


# Generated at 2022-06-25 13:01:41.793848
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Arrange
    # Act
    # Assert
    assert issubclass(_ABCSingleton, type)



# Generated at 2022-06-25 13:01:44.002879
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    int_0 = 200
    global_cli_args_0 = GlobalCLIArgs(int_0)


# Generated at 2022-06-25 13:01:50.078817
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    arg0 = object()
    arg1 = object()
    arg2 = object()
    arg3 = object()
    arg4 = object()
    arg5 = object()
    arg6 = object()

    _AB_C_Singleton_0 = _ABCSingleton(arg0, arg1, arg2, arg3, arg4, arg5, arg6)
    assert(_AB_C_Singleton_0 == _ABCSingleton())

    _AB_C_Singleton_1 = _ABCSingleton(arg0, object(), object(), object(), object(), object(), object())
    assert(_AB_C_Singleton_0 == _AB_C_Singleton_1)


# Generated at 2022-06-25 13:02:01.094579
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Test with a class that does not inherit from ABCMeta as a parent
    class Example_ABCSingleton_0(_ABCSingleton):
        pass

    class Example_ABCSingleton_0_0(Example_ABCSingleton_0):
        pass

    assert type(Example_ABCSingleton_0) == _ABCSingleton
    assert issubclass(Example_ABCSingleton_0, object)

    # Test with a class that inherit from ABCMeta as a parent
    class Example_ABCSingleton_1(ABCMeta):
        pass

    class Example_ABCSingleton_1_0(Example_ABCSingleton_1):
        pass

    assert type(Example_ABCSingleton_1) == _ABCSingleton
    assert issubclass(Example_ABCSingleton_1, object)

# Generated at 2022-06-25 13:02:03.767036
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    try:
        test_case_0()
    except TypeError as e:
        print(e)
    except Exception as e:
        print(e)



# Generated at 2022-06-25 13:02:05.362947
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    int_0 = 200
    c_l_i_args_0 = CLIArgs(int_0)


# Generated at 2022-06-25 13:02:14.323018
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Test for class GlobalCLIArgs
    # Test for normal operation
    # Test for creation of first instance of GlobalCLIArgs class

    # Attempt to create an instance of class GlobalCLIArgs
    try:
        g_c_l_i_args_0 = GlobalCLIArgs(200)
    except:
        assert False, "Could not create an instance of GlobalCLIArgs"

    # Test for preventing creation of subsequent instances of class GlobalCLIArgs
    # Attempt to create a second instance of class GlobalCLIArgs
    try:
        g_c_l_i_args_1 = GlobalCLIArgs(300)
    except:
        assert False, "Could not create an instance of GlobalCLIArgs"

# Generated at 2022-06-25 13:02:18.384952
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Skip test as python < 2.7 does not support metaclass syntax
    if not hasattr(CLIArgs, '__metaclass__'):
        return

    assert issubclass(type(GlobalCLIArgs), ABCMeta)
    assert isinstance(type(GlobalCLIArgs), _ABCSingleton)



# Generated at 2022-06-25 13:02:21.352082
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    int_0 = 200
    c_l_i_args_0 = CLIArgs(int_0)
    global_c_l_i_args_1 = GlobalCLIArgs(c_l_i_args_0)


# Generated at 2022-06-25 13:02:22.401658
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert callable(_ABCSingleton)

# Generated at 2022-06-25 13:02:30.086623
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert (issubclass(_ABCSingleton, Singleton))
    assert (issubclass(_ABCSingleton, ABCMeta))


# Generated at 2022-06-25 13:02:32.382677
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cliargs = CLIArgs({"test":"test"})
    assert cliargs.test == "test"

#test CLIArgs.from_options

# Generated at 2022-06-25 13:02:33.962343
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    _GlobalCLIArgs = GlobalCLIArgs()
    assert _GlobalCLIArgs


# Generated at 2022-06-25 13:02:37.288510
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Make sure that the type of the constructed object is the same as that of the class
    assert type(_ABCSingleton()) is _ABCSingleton
    assert issubclass(type(_ABCSingleton()), Singleton)
    assert issubclass(type(_ABCSingleton()), ABCMeta)


# Generated at 2022-06-25 13:02:42.474405
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    int_0 = 200
    c_l_i_args_0 = CLIArgs(int_0)

# Generated at 2022-06-25 13:02:45.324150
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    int_0 = 200
    c_l_i_args_0 = CLIArgs(int_0)
    boolean_0 = c_l_i_args_0 == int_0
    assert boolean_0



# Generated at 2022-06-25 13:02:49.200320
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    int_0 = 200
    global_c_l_i_args_0 = GlobalCLIArgs(int_0)

if __name__ == "__main__":
    # Run all Unit Tests
    test_case_0()
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:02:51.367709
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    from ansible.cli.arguments import OptionsParser

    options = OptionsParser()

    # Assert CLIArg properties
    assert options



# Generated at 2022-06-25 13:02:56.630756
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Case 0: Before instantiation
    c_l_i_args_0 = GlobalCLIArgs()
    # Case 1: After instantiation
    c_l_i_args_1 = GlobalCLIArgs()
    # Case 2: After set atribute
    GlobalCLIArgs.set_instance(dict())
    c_l_i_args_2 = GlobalCLIArgs()
    # Case 3: After del atribute
    del GlobalCLIArgs._GlobalCLIArgs__instance

# Generated at 2022-06-25 13:03:00.232759
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    int_0 = 200
    c_l_i_args_0 = CLIArgs(int_0)
    assert c_l_i_args_0.__class__ == CLIArgs
    assert c_l_i_args_0 == int_0


# Generated at 2022-06-25 13:03:10.285533
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    example = _ABCSingleton()
    assert (type(example) == _ABCSingleton)


# Generated at 2022-06-25 13:03:11.161332
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    CLIArgs(1)


# Generated at 2022-06-25 13:03:16.548284
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    int_0 = 200
    c_l_i_args_0 = CLIArgs(int_0)
    ansible_config_0 = ansible.config.default_config._load_config_file('/etc/ansible/ansible.cfg')
    options_0 = ansible.config.manager.load_cli_options(ansible_config_0)
    c_l_i_args_1 = CLIArgs.from_options(options_0)



# Generated at 2022-06-25 13:03:18.459048
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    g_c_l_i_args_0 = GlobalCLIArgs()
    assert str(g_c_l_i_args_0)


# Generated at 2022-06-25 13:03:19.581588
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert(isinstance(GlobalCLIArgs(), GlobalCLIArgs))

# Generated at 2022-06-25 13:03:29.403985
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    int_0 = 200
    global_cli_args_0 = GlobalCLIArgs(int_0)
    # Check if instance is of type GlobalCLIArgs
    if not isinstance(global_cli_args_0, GlobalCLIArgs):
        raise Exception("Failed due to incorrect type of GlobalCLIArgs")
    # Check if instance is of type CLIArgs
    if not isinstance(global_cli_args_0, CLIArgs):
        raise Exception("Failed due to incorrect type of CLIArgs")
    # Check if instance is of type dict
    if not isinstance(global_cli_args_0, dict):
        raise Exception("Failed due to incorrect type of dict")

# Run test case
if __name__ == "__main__":
    test_case_0()
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:03:34.155140
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # create an instance of GlobalCLIArgs
    g_c_l_i_args_0 = GlobalCLIArgs(0)
    # create another instance of GlobalCLIArgs
    g_c_l_i_args_1 = GlobalCLIArgs(1)
    # check if they are the same
    assert g_c_l_i_args_0 is g_c_l_i_args_1

# Generated at 2022-06-25 13:03:36.338870
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    int_0 = 200
    c_l_i_args_0 = CLIArgs(int_0)


# Generated at 2022-06-25 13:03:39.103169
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    int_0 = 200
    c_l_i_args_0 = CLIArgs(int_0)
    c_l_i_args_0 = GlobalCLIArgs.from_options(c_l_i_args_0)


# Generated at 2022-06-25 13:03:40.381811
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args_0 = GlobalCLIArgs.from_options(None)
    assert(args_0 == {})

# Generated at 2022-06-25 13:03:59.352183
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Try to create an instance of CLIArgs
    c_l_i_args_1 = CLIArgs({'a': 'a', 'b': 'b', 'c': 'c'})
    # Check if the object is an instance of CLIArgs
    assert isinstance(c_l_i_args_1, CLIArgs)
    # Check if the object is an instance of ImmutableDict
    assert isinstance(c_l_i_args_1, ImmutableDict)



# Generated at 2022-06-25 13:04:00.285078
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    pass


# Generated at 2022-06-25 13:04:02.710301
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args_0 = GlobalCLIArgs({'a': 100})
    print(global_cli_args_0)
    assert global_cli_args_0 == {'a': 100}



# Generated at 2022-06-25 13:04:05.210555
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Create instance of the class
    global_cl_i_args_0 = GlobalCLIArgs()


test_case_0()
test_GlobalCLIArgs()

# Generated at 2022-06-25 13:04:08.785980
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, Singleton)
    assert hasattr(_ABCSingleton.__new__, '__call__')
    assert hasattr(_ABCSingleton.__call__, '__func__')
    assert callable(_ABCSingleton.__call__.__func__)


# Generated at 2022-06-25 13:04:11.706095
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping0 = dict()
    # Call function 'CLIArgs'
    return_value = CLIArgs(mapping0)
    assert isinstance(return_value, CLIArgs)


# Generated at 2022-06-25 13:04:16.654011
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    gbl_c_l_i_args_0 = GlobalCLIArgs({'a': 'b'})
    gbl_c_l_i_args_1 = GlobalCLIArgs({'a': 'b'})
    assert gbl_c_l_i_args_0 is gbl_c_l_i_args_1


test_case_0()
test_GlobalCLIArgs()

# Generated at 2022-06-25 13:04:23.618491
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=str, dest='source')
    parser.add_argument('--destination', type=str, dest='destination')
    options = parser.parse_args(['--source', 'input_file.txt', '--destination', 'output_file.txt'])

    try:
        global_cli_args = GlobalCLIArgs.from_options(options)
    except Exception:
        raise
    else:
        assert global_cli_args['source'] == 'input_file.txt'
        assert global_cli_args['destination'] == 'output_file.txt'

# Generated at 2022-06-25 13:04:27.687141
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = 'foo'
    b = 1
    c_l_i_args_0 = CLIArgs({a: b})
    global_c_l_i_args_0 = GlobalCLIArgs()

# Generated at 2022-06-25 13:04:28.634834
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs



# Generated at 2022-06-25 13:04:45.128597
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    _ = GlobalCLIArgs(1)
    assert True

# Generated at 2022-06-25 13:04:46.501722
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    int_1 = 200
    global_c_l_i_args_0 = GlobalCLIArgs(int_1)
    assert(global_c_l_i_args_0.from_options(int_1) == GlobalCLIArgs(int_1))



# Generated at 2022-06-25 13:04:47.838607
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    int_0 = 200
    c_l_i_args_0 = CLIArgs(int_0)


# Generated at 2022-06-25 13:04:50.614564
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    with pytest.raises(AssertionError) as err:
        test_case_0()
    assert "non-mapping" in str(err.value)


# Generated at 2022-06-25 13:04:52.153209
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    new_instance = _ABCSingleton()


# Generated at 2022-06-25 13:05:03.327003
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    g_c_l_i_args_0 = GlobalCLIArgs({'a': 'd', 'c': 'b'})
    assert isinstance(g_c_l_i_args_0, GlobalCLIArgs)
    assert isinstance(g_c_l_i_args_0, ImmutableDict)
    assert isinstance(g_c_l_i_args_0, CLIArgs)
    assert isinstance(g_c_l_i_args_0, Singleton)
    assert isinstance(g_c_l_i_args_0, Mapping)
    assert not isinstance(g_c_l_i_args_0, Container)
    assert not isinstance(g_c_l_i_args_0, Sequence)

# Generated at 2022-06-25 13:05:12.213295
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import copy

    # construct a dict
    dict0 = {}
    dict0['a'] = 100
    dict0['b'] = 'c'
    dict0['d'] = {}
    dict0['d']['e'] = []
    dict0['d']['e'].append(100)
    dict0['d']['e'].append(101)
    dict0['d']['f'] = 'h'
    dict0['d']['g'] = {}
    dict0['d']['g']['h'] = 'k'
    dict0['d']['g']['l'] = {}
    dict0['d']['g']['l']['m'] = 'n'
    dict0['d']['g']['l']['q'] = 'p'

# Generated at 2022-06-25 13:05:16.303392
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common._collections_compat import Mapping
    x = 439
    y = 267
    z = 671
    
    immut_dict0 = {'bb': 444, 'aa': x, 'dd': y, 'cc': z}
    print('immut_dict0: ' + str(immut_dict0))
    
    cli_args0 = CLIArgs(immut_dict0)
    print('cli_args0: ' + str(cli_args0))
    print('type(cli_args0): ' + str(type(cli_args0)))
    
    assert cli_args0._data is not None, 'cli_args0._data is None'

# Generated at 2022-06-25 13:05:17.626650
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    gc_a_0 = GlobalCLIArgs._instance


# Generated at 2022-06-25 13:05:22.323697
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    print("TESTING CLARGS")
    int_0 = 200
    c_l_i_args_0 = CLIArgs(int_0)

    c_l_i_args_0_dict = c_l_i_args_0._mapping

    assert isinstance(c_l_i_args_0_dict, dict)
    assert isinstance(c_l_i_args_0_dict[int], int)


# Generated at 2022-06-25 13:06:02.068114
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    p_obj_0 = _ABCSingleton()


# Generated at 2022-06-25 13:06:04.183053
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert not hasattr(GlobalCLIArgs, '__new__')
    assert not hasattr(GlobalCLIArgs, '__init__')


# Generated at 2022-06-25 13:06:10.303909
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    #  Test CLIArgs.__init__
    GlobalCLIArgs({})
    #  Test all branch of CLIArgs.__init__
    GlobalCLIArgs({'one':1,'two':2,'three':3,'four':4,'five':5})
    #  Test CLIArgs.from_options
    GlobalCLIArgs.from_options({})
    #  Test all branch of CLIArgs.from_options
    GlobalCLIArgs.from_options({'one':1,'two':2,'three':3,'four':4,'five':5})

# Generated at 2022-06-25 13:06:12.616095
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    abc_singleton_0 = _ABCSingleton()
    assert len(abc_singleton_0) == 0, 'Failed to create object of class _ABCSingleton'



# Generated at 2022-06-25 13:06:21.591920
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    # Verify that a string cannot be passed in as an argument to the constructor.
    try:
        str_0 = "This test string should fail"
        c_l_i_args_0 = CLIArgs(str_0)
        assert False
    except TypeError:
        assert True

    try:
        dict_0 = {"key_0": "value_0", "key_1": "value_1"}
        c_l_i_args_0 = CLIArgs(dict_0)
        assert True
    except TypeError:
        assert False

    class_name = "CLIArgs"
    method_name = "__init__"

    # Verify that an empty dictionary is not passed in as an argument to the constructor

# Generated at 2022-06-25 13:06:31.589067
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_cases = [
        # test case 0:
        {
            'test_case': 0,
            'expected': "TypeError"
        },
        # test case 1:
        {
            'test_case': 1,
            'expected': "NameError"
        },
        # test case 2:
        {
            'test_case': 2,
            'expected': "TypeError"
        },
        # test case 3:
        {
            'test_case': 3,
            'expected': "TypeError"
        },
        # test case 4:
        {
            'test_case': 4,
            'expected': "TypeError"
        },
        # test case 5:
        {
            'test_case': 5,
            'expected': "TypeError"
        }
    ]


# Generated at 2022-06-25 13:06:34.493104
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    int_0 = 200
    c_l_i_args_0 = CLIArgs(int_0)
    int_1 = 200
    c_l_i_args_1 = CLIArgs(int_1)
    assert c_l_i_args_0 == c_l_i_args_1

# Generated at 2022-06-25 13:06:35.457745
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Test a normal use case
    c_l_i_args_0 = GlobalCLIArgs()


# Generated at 2022-06-25 13:06:36.762342
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, Singleton)
    assert issubclass(_ABCSingleton, ABCMeta)


# Generated at 2022-06-25 13:06:38.071743
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    int_0 = 200
    c_l_i_args_0 = CLIArgs(int_0)


# Generated at 2022-06-25 13:08:04.512669
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Test whether constructor of class GlobalCLIArgs works
    int_0 = 200
    g_c_l_i_args_0 = GlobalCLIArgs(int_0)
    assert(g_c_l_i_args_0 == 200)

    # Test whether singleton works (constructor of class GlobalCLIArgs only creates one copy)
    int_1 = 200
    g_c_l_i_args_1 = GlobalCLIArgs(int_1)
    assert(id(g_c_l_i_args_0) == id(g_c_l_i_args_1))

if __name__ == "__main__":
    test_case_0()
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:08:07.028103
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    c_l_i_args_0 = GlobalCLIArgs({})
    assert c_l_i_args_0


if __name__ == "__main__":
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:08:12.626106
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    g_c_l_i_args_0 = GlobalCLIArgs(1)
    x_0 = g_c_l_i_args_0.__init__(g_c_l_i_args_0)
    g_c_l_i_args_1 = GlobalCLIArgs(1)
    x_1 = g_c_l_i_args_0.__del__(g_c_l_i_args_1)

# Generated at 2022-06-25 13:08:13.495947
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    pass


# Generated at 2022-06-25 13:08:14.904684
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    try:
        test_case_0()
    except:
        return False
    return True


# Generated at 2022-06-25 13:08:17.300854
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    # Run the constructor and make sure no exceptions are thrown.
    _ABCSingleton(
        '_ABCSingleton',
        ('Singleton', 'ABCMeta'),
        {}
    )


# Generated at 2022-06-25 13:08:21.898709
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    '''
    Constructor of class CLIArgs_0
    '''
    int_0 = 200
    c_l_i_args_0 = CLIArgs(int_0)
    print('toplevel')
    print(c_l_i_args_0.toplevel)

    print('instance of CLIArgs')
    print(isinstance(c_l_i_args_0, CLIArgs))


# Generated at 2022-06-25 13:08:23.583085
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    result_0 = GlobalCLIArgs
    result_1 = GlobalCLIArgs()
    result_2 = GlobalCLIArgs(set())



# Generated at 2022-06-25 13:08:24.955796
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    pass


# Generated at 2022-06-25 13:08:27.131203
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Run it so we see the error (if there is one)
    test_case_0()
if __name__ == '__main__':
    test__ABCSingleton()