

# Generated at 2022-06-25 13:00:51.214360
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = ImmutableDict({'a': 1, 'b': 2, 'c': [1, 2, 3], 'd': {'a': 'x', 'b': 'y', 'c': 'z'}})
    assert isinstance(args, Mapping)
    assert isinstance(args, Container)
    assert isinstance(args, ImmutableDict)
    assert args['a'] == 1
    assert args['b'] == 2
    assert isinstance(args['c'], Container)
    assert isinstance(args['c'], Sequence)
    assert args['c'][0] == 1

    assert isinstance(args['d'], Container)
    assert isinstance(args['d'], Mapping)
    assert args['d']['a'] == 'x'
    assert args['d']['b'] == 'y'

# Generated at 2022-06-25 13:00:54.658535
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils.common._collections_compat import (Container, Mapping, Sequence, Set)
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils.singleton import Singleton

    # Test does not apply
    pass

# Generated at 2022-06-25 13:00:57.546469
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    c_l_i_args_0 = None
    global_c_l_i_args_0 = GlobalCLIArgs(c_l_i_args_0)
    assert (isinstance(global_c_l_i_args_0, GlobalCLIArgs))



# Generated at 2022-06-25 13:01:07.264722
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_mapping = {'a': 3, 'b': 4, 'c': 5}
    c_l_i_args = CLIArgs(test_mapping)
    assert c_l_i_args == test_mapping
    assert c_l_i_args.a == 3
    assert c_l_i_args.b == 4
    assert c_l_i_args.c == 5
    test_mapping_2 = {'a': 5, 'b': 7, 'c': 10}
    c_l_i_args_2 = CLIArgs(test_mapping_2)
    assert c_l_i_args_2 == test_mapping_2
    assert c_l_i_args_2.a == 5
    assert c_l_i_args_2.b == 7
    assert c

# Generated at 2022-06-25 13:01:11.534512
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = {'foo': 'bar', 'baz': 'qux'}
    cli_args = CLIArgs(args)
    global_cli_args = GlobalCLIArgs(args)
    assert cli_args == global_cli_args

#validate that global object is a singleton

# Generated at 2022-06-25 13:01:15.598799
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Instance 0
    instance_0 = _ABCSingleton()
    assert __name__ + '.test__ABCSingleton()' == instance_0.__module__

    # Instance 1
    instance_1 = _ABCSingleton()
    assert __name__ + '.test__ABCSingleton()' == instance_1.__module__


# Generated at 2022-06-25 13:01:20.923844
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Create a class for use in test
    class _ABCSingletonTest(_ABCSingleton):
        def __init__(self):
            pass

    # Construct the class and check singleton
    a = _ABCSingletonTest()
    b = _ABCSingletonTest()
    c = _ABCSingletonTest.__new__(_ABCSingletonTest)
    assert(a is b)
    assert(a is not c)



# Generated at 2022-06-25 13:01:22.172690
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()

# Generated at 2022-06-25 13:01:28.158061
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class DictObj(dict):
        pass

    obj = DictObj()
    obj['n'] = 'name'
    obj['h'] = 'host'
    obj['u'] = 'user'
    obj['p'] = 'password'
    obj['g'] = 'group'
    c_l_i_args_1 = CLIArgs(obj)
    # Test for immutable

# Generated at 2022-06-25 13:01:29.720628
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    print("Test function 'test__ABCSingleton'")
    test_case_0()


# Generated at 2022-06-25 13:01:38.164114
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict_0 = {'false': False, 'true': True}
    c_l_i_args_0 = CLIArgs(dict_0)
    assert c_l_i_args_0.__init__(dict_0) == None



# Generated at 2022-06-25 13:01:47.986879
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    dict_0 = dict()
    dict_0 = {
        'key_0': 'value_0',
        'key_1': 'value_1',
        'key_2': 'value_2',
        'key_3': 'value_3'
    }
    c_l_i_args_0 = CLIArgs(dict_0)

    test__ABCSingleton.last_exception = None
    try:
        # Warning: del() is (ab)used
        del(c_l_i_args_0['key_0'])
    except TypeError as err:
        test__ABCSingleton.last_exception = err
    assert not test__ABCSingleton.last_exception

    c_l_i_args_0['key_0'] = 'value_0'
    val_0 = c_

# Generated at 2022-06-25 13:01:51.200463
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        test_case_0()
    except Exception as e:
        print(e)
    else:
        print('[PASS]')


# Generated at 2022-06-25 13:01:58.832729
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    c_l_i_args_0 = CLIArgs(dict_0)
    assert isinstance(c_l_i_args_0, Container) is True
    assert isinstance(c_l_i_args_0, Mapping) is True
    assert isinstance(c_l_i_args_0, Sequence) is True
    assert isinstance(c_l_i_args_0, Set) is False


# Generated at 2022-06-25 13:02:04.164790
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    arg_dictionary = {
        'foo': 'bar',
        'one': True,
        'two': False
    }

    global_arg = CLIArgs(arg_dictionary)

    # Test constructor
    assert isinstance(global_arg, GlobalCLIArgs)
    assert isinstance(global_arg, CLIArgs)
    assert isinstance(global_arg, ImmutableDict)


# Generated at 2022-06-25 13:02:06.740877
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    c_l_i_args_0 = CLIArgs(dict_0)


# Generated at 2022-06-25 13:02:09.826403
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    c_l_i_args_0 = CLIArgs(dict_0)


# Generated at 2022-06-25 13:02:13.089349
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    c_l_i_args_0 = CLIArgs(dict_0)


if __name__ == '__main__':
    test_CLIArgs()

# Generated at 2022-06-25 13:02:15.727809
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    c_l_i_args_0 = CLIArgs(dict_0)


# Generated at 2022-06-25 13:02:17.268406
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton('test__ABCSingleton', (object,), {}), _ABCSingleton)

# Generated at 2022-06-25 13:02:25.765089
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()

if __name__ == '__main__':
    test__ABCSingleton()

# Generated at 2022-06-25 13:02:36.210219
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Mock the module 'argparse'
    mock_module_argparse = Mock(['Namespace'])
    # The Mock object for 'o'
    mock_o_0 = Mock()
    mock_o_0.__getitem__.side_effect = lambda key: mock_o_0
    mock_o_0.__repr__.return_value = 'mock_o_0'
    mock_o_0.__setitem__.side_effect = lambda key, value: mock_o_0
    mock_o_0.__len__.return_value = 0
    # Generate an intger to mock the object 'len(mock_o_0)'
    temp_len = random.randint(0, 100)
    # Mock the object 'len(mock_o_0)'
    mock_len_0

# Generated at 2022-06-25 13:02:41.459293
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        test_case_0()
    except TypeError as e:
        msg = 'Got unexpected exception\n  Exception: {}\n'.format(e)
    print('Test finished')

if __name__ == '__main__':
    test__ABCSingleton()

# Generated at 2022-06-25 13:02:43.453238
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_case_0()

if __name__ == '__main__':
    test_CLIArgs()

# Generated at 2022-06-25 13:02:46.824858
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    c_l_i_args_0 = CLIArgs({})
    c_l_i_args_1 = GlobalCLIArgs()
    assert c_l_i_args_1.args is c_l_i_args_0.args


# Generated at 2022-06-25 13:02:48.003467
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    # Instantiate class GlobalCLIArgs
    class_instance = GlobalCLIArgs()

# Generated at 2022-06-25 13:02:49.918696
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict_0 = {}
    c_l_i_args_0 = CLIArgs(dict_0)


# Generated at 2022-06-25 13:02:52.015245
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    dict_0 = {}
    global_cli_args_0 = GlobalCLIArgs(dict_0)

if __name__ == "__main__":
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:02:52.829638
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    l = _ABCSingleton()


# Generated at 2022-06-25 13:02:58.627106
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict_0 = {'list_0': ['1', 'list_0'], 'dict_0': {'key_0': 'value_0'}, 'set_0': set([]), 'tuple_0': ('text_0', 'text_0', 'tuple_0')}
    if isinstance(_make_immutable(dict_0), dict):
        raise "AssertionError()"
    c_l_i_args_0 = CLIArgs(dict_0)


# Generated at 2022-06-25 13:03:02.703893
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    c_l_i_args_0 = CLIArgs(dict_0)



# Generated at 2022-06-25 13:03:05.062854
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    c_l_i_args_0 = CLIArgs(dict_0)


# Generated at 2022-06-25 13:03:07.115023
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    print("Testing CLIArgs")
    print("CLIArgs:")
    test_case_0()


# Generated at 2022-06-25 13:03:11.118757
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    dict_0 = {}
    # Call method of super class
    c_l_i_args_0 = GlobalCLIArgs(dict_0)

# Run the following if this script is the main program
if __name__ == '__main__':
    test_case_0()
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:03:16.205519
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # first test
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    c_l_i_args_0 = CLIArgs(dict_0)
    assert c_l_i_args_0.get(bool_0,bool_0) == bool_0
    assert c_l_i_args_0.keys() == dict_0.keys()


# Generated at 2022-06-25 13:03:18.775585
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    options_0 = None
    c_l_i_args_1 = CLIArgs.from_options(options_0)
    assert_equal(len(c_l_i_args_1), 0)


# Generated at 2022-06-25 13:03:26.424566
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    c_l_i_args_0 = CLIArgs(dict_0)
    global_c_l_i_args_0 = GlobalCLIArgs(dict_0)
    assert c_l_i_args_0 == global_c_l_i_args_0
    assert isinstance(global_c_l_i_args_0, CLIArgs)
    assert global_c_l_i_args_0 == dict_0
    assert global_c_l_i_args_0 == c_l_i_args_0

# Generated at 2022-06-25 13:03:31.356156
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    print("Constructor of class GlobalCLIArgs")
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    a_a_a_0 = CLIArgs(dict_0)
    global_c_l_i_args_0 = GlobalCLIArgs(a_a_a_0)

test_case_0()
test_GlobalCLIArgs()

# Generated at 2022-06-25 13:03:32.456663
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_case_0()

# Generated at 2022-06-25 13:03:36.261367
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test__ABCSingleton_0 = test_case_0()

if __name__ == '__main__':
    # noinspection PyUnresolvedReferences
    import pytest
    pytest.main(args=[__file__])
    test__ABCSingleton()

# Generated at 2022-06-25 13:03:43.486039
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    from ansible.cli import CLI
    cli_0 = CLI(dict_0)

    bool_0 = _make_immutable(bool_0)
    bool_1 = _make_immutable(bool_0)
    bool_2 = _make_immutable(bool_1)
    bool_3 = _make_immutable(bool_2)
    bool_4 = _make_immutable(bool_3)
    bool_5 = _make_immutable(bool_4)
    bool_6 = _make_immutable(bool_5)
    bool_7 = _make_immutable(bool_6)
    bool_8 = _make_immutable(bool_7)
    bool_

# Generated at 2022-06-25 13:03:44.637861
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    metaclass_0 = _ABCSingleton()


# Generated at 2022-06-25 13:03:45.649448
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    pass


# Generated at 2022-06-25 13:03:55.774183
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-25 13:03:56.952424
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_case_0()

# noinspection PyTypeChecker

# Generated at 2022-06-25 13:04:01.565393
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    dict_1 = {}
    g_l_i_args_0 = GlobalCLIArgs(dict_1)
    dict_2 = {}
    g_l_i_args_1 = GlobalCLIArgs(dict_2)
    g_l_i_args_1_data = id(g_l_i_args_1)
    g_l_i_args_0_data = id(g_l_i_args_0)
    assert g_l_i_args_1_data == g_l_i_args_0_data



# Generated at 2022-06-25 13:04:04.138979
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    c_l_i_args_0 = GlobalCLIArgs()
    assert c_l_i_args_0.__class__ == GlobalCLIArgs

# Generated at 2022-06-25 13:04:13.116174
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils import basic
    from ansible.module_utils.common.compat import argparse

    parser = argparse.ArgumentParser(prog=__name__)
    parser.add_argument('-a', '--arga', action='store_true')
    parser.add_argument('-b', '--argb', action='store_true')
    parser.add_argument('-c', '--argc', action='store_true')
    parser.add_argument('-d', '--argd', action='store_true')
    args_0 = parser.parse_args()
    setattr(args_0, 'arga', True)
    setattr(args_0, 'argb', True)
    setattr(args_0, 'argc', True)

# Generated at 2022-06-25 13:04:14.934663
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        _ABCSingleton()
    except Exception:
        assert False



# Generated at 2022-06-25 13:04:16.931725
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    instance = _ABCSingleton()
    assert isinstance(instance, Singleton)
    assert isinstance(instance, ABCMeta)



# Generated at 2022-06-25 13:04:21.878391
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # noinspection PyCallByClass
    global_cli_args_0 = GlobalCLIArgs()
    print(GlobalCLIArgs.__new__.__defaults__)


# Generated at 2022-06-25 13:04:29.580050
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Test 1
    try:
        GlobalCLIArgs()
    except RuntimeError:
        pass
    except TypeError:
        pass
    else:
        assert 0, "Unexpected behavior"
    # Test 2
    try:
        GlobalCLIArgs()
    except RuntimeError:
        pass
    except TypeError:
        pass
    else:
        assert 0, "Unexpected behavior"
    # Test 3
    try:
        GlobalCLIArgs()
    except RuntimeError:
        pass
    except TypeError:
        pass
    else:
        assert 0, "Unexpected behavior"



# Generated at 2022-06-25 13:04:30.541043
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    pass


# Generated at 2022-06-25 13:04:35.916754
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test__ABCSingleton_0()
    test__ABCSingleton_1()
    test__ABCSingleton_2()
    test__ABCSingleton_3()
    test__ABCSingleton_4()
    test__ABCSingleton_5()
    test__ABCSingleton_6()
    test__ABCSingleton_7()
    test__ABCSingleton_8()
    test__ABCSingleton_9()


# Generated at 2022-06-25 13:04:39.909860
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    global_c_l_i_args_0 = GlobalCLIArgs(dict_0)
    assert isinstance(global_c_l_i_args_0, GlobalCLIArgs)

# Generated at 2022-06-25 13:04:40.897666
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    pass


# Generated at 2022-06-25 13:04:41.811278
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert('__abstractmethods__' in dir(_ABCSingleton)), "Assertion failed"


# Generated at 2022-06-25 13:04:47.062589
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    c_l_i_args_0 = GlobalCLIArgs(dict_0)

# Generated at 2022-06-25 13:04:51.193127
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
        Test case for GlobalCLIArgs
    """
    from ansible.cli.arguments import options
    g_c_l_i_args_0 = GlobalCLIArgs.from_options(options)
    assert True == isinstance(g_c_l_i_args_0, GlobalCLIArgs)
    assert True == isinstance(g_c_l_i_args_0, CLIArgs)

if __name__ == "__main__":
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:04:53.576343
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_a_0 = GlobalCLIArgs()

if __name__ == '__main__':
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:05:03.907459
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    c_l_i_args_0 = CLIArgs(dict_0)


# Generated at 2022-06-25 13:05:07.425485
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    #Step 0
    assert CLIArgs({'a': 1}).immutable, "CLIArgs instance should be immutable"
    assert not CLIArgs({'b': 2}).mutable, "CLIArgs instance should not be mutable"


# Generated at 2022-06-25 13:05:14.197299
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    c_l_i_args_0 = CLIArgs(dict_0)
    # Assert that the content of the ImmutableDict returned by the constructor is correct
    assert c_l_i_args_0[True] is True
    assert c_l_i_args_0[True] is True


# Generated at 2022-06-25 13:05:15.984594
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        test_case_0()
    except Exception as e:
        print("An exception occurred")
        print(e)


# Generated at 2022-06-25 13:05:20.711114
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    dict_0 = {'p_jt_i_ouyb_t_qgz': False, 'j_o_a_xlv_s_w_j_s_i': True}
    _global_c_l_i_args_0 = GlobalCLIArgs.from_options(dict_0)
    assert isinstance(_global_c_l_i_args_0, GlobalCLIArgs)

# Generated at 2022-06-25 13:05:24.545260
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    c_l_i_args_1 = CLIArgs({})
    c_l_i_args_2 = CLIArgs({})

    assert c_l_i_args_1 == c_l_i_args_2
    c_l_i_args_1['a'] = 'b'
    try:
        c_l_i_args_2['a'] = 'b'
    except TypeError:
        pass
    else:
        assert False

# Generated at 2022-06-25 13:05:25.622336
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()



# Generated at 2022-06-25 13:05:27.944244
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    c_l_i_args_0 = CLIArgs(dict_0)


# Generated at 2022-06-25 13:05:31.782474
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert isinstance(_ABCSingleton(object.__name__, object.__bases__, dict()), object)

    # Test for multiple inheritance.
    assert issubclass(_ABCSingleton(object.__name__, object.__bases__, dict()), object)
    assert isinstance(GlobalCLIArgs(), GlobalCLIArgs)


# Generated at 2022-06-25 13:05:37.094080
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Make sure we don't create a new object if we are calling it for the first time
    global_c_l_i_args_0 = GlobalCLIArgs()
    global_c_l_i_args_1 = GlobalCLIArgs()
    assert global_c_l_i_args_0 is global_c_l_i_args_1


if __name__ == "__main__":
    test_case_0()
    test__ABCSingleton()

# Generated at 2022-06-25 13:05:48.190437
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    cli_args_0 = GlobalCLIArgs()
    assert isinstance(cli_args_0, Container)


# Generated at 2022-06-25 13:05:56.884259
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    c_l_i_args_0 = CLIArgs(dict_0)
    # Test for raising an error when trying to create an instance of the class
    with pytest.raises(TypeError) as excinfo:
        c_l_i_args_0 = CLIArgs(dict_0)
    with pytest.raises(TypeError) as excinfo:
        c_l_i_args_0 = CLIArgs(dict_0)

    str_0 = 'kayak'
    dict_0 = {str_0: str_0, str_0: str_0}
    c_l_i_args_0 = CLIArgs(dict_0)

# Generated at 2022-06-25 13:06:03.676304
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    c_l_i_args_0 = CLIArgs(dict_0)
    c_l_i_args_0.__init__(dict_0)


# Generated at 2022-06-25 13:06:07.096501
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    instance_0 = _ABCSingleton()
    assert hasattr(instance_0, '_Singleton__instance')
    assert hasattr(instance_0, '_register')
    assert hasattr(instance_0, '__abstractmethods__')


# Generated at 2022-06-25 13:06:10.342264
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    cliargs_0 = CLIArgs({
        'var1': 'value1',
        'var2': 'value2'
    })

    g_c_l_i_args_0 = GlobalCLIArgs.from_options(cliargs_0)



# Generated at 2022-06-25 13:06:16.074791
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    dict_0 = {'ls': '#v{t|R', '*k[`C': '8PQX9y', 'e5l5': '_F&!|+x', 'Jk}j': 'A:p\x7f9', '#}ok': 'B6k%U6'}
    global_c_l_i_args_0 = GlobalCLIArgs(dict_0)
    assert global_c_l_i_args_0['ls'] == '#v{t|R'
    assert global_c_l_i_args_0['*k[`C'] == '8PQX9y'
    assert global_c_l_i_args_0['e5l5'] == '_F&!|+x'
    assert global_c_l_i_args_

# Generated at 2022-06-25 13:06:26.145229
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict_0 = {'foo': 'bar', True: False, 0: 1, 0.0: 1.1, '1': 3, '0': 4, }
    dict_1 = dict_0.copy()
    dict_1[True] = False
    dict_2 = dict_1.copy()
    dict_2[0.0] = 1.1
    dict_3 = dict_2.copy()
    dict_3[0] = 1
    dict_4 = dict_3.copy()

# Generated at 2022-06-25 13:06:27.771061
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = {'option': 'value'}
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-25 13:06:31.142236
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Test attribute an_attribute of class _ABCSingleton
    assert '_ABCSingleton' == _ABCSingleton.__name__
    # Test attribute an_attribute of class _ABCSingleton
    assert 'ABCMeta' == _ABCSingleton.__base__.__name__


# Generated at 2022-06-25 13:06:33.251445
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()

if __name__ == '__main__':
    CLIArgs.test_case_0()
    CLIArgs.test__ABCSingleton()
    test_case_0()
    test__ABCSingleton()

# Generated at 2022-06-25 13:06:57.242388
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = GlobalCLIArgs()
    global_c_l_i_args_0 = GlobalCLIArgs()

if __name__ == '__main__':
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:07:02.313813
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    global_c_l_i_args_0 = GlobalCLIArgs(dict_0)
    assert global_c_l_i_args_0 == {}, "unexpected value for global_c_l_i_args_0"


# Generated at 2022-06-25 13:07:04.622561
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        _ABCSingleton()
    except Exception:
        assert False, 'Unexpected exception raised during instantiation of class _ABCSingleton'


# Generated at 2022-06-25 13:07:07.704263
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_1 = False
    bool_2 = True
    str_0 = str()
    dict_1 = {str_0: bool_1, bool_1: bool_2}
    c_l_i_args_0 = CLIArgs(dict_1)


# Generated at 2022-06-25 13:07:13.141201
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Using an ABCMeta derived class
    class A(object):
        __metaclass__ = _ABCSingleton

    # Instantiating class once
    instance_1 = A()
    # Instantiating class twice
    instance_2 = A()

    assert isinstance(A(), A)
    assert isinstance(A(), object)
    assert issubclass(A, object)
    assert isinstance(A(), _ABCSingleton)
    assert issubclass(A, _ABCSingleton)
    assert instance_1 == instance_2
    assert instance_2 == instance_1
    assert isinstance(instance_1, A)
    assert isinstance(instance_1, _ABCSingleton)
    assert isinstance(instance_1, object)
    assert isinstance(instance_2, A)

# Generated at 2022-06-25 13:07:18.300198
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    global_c_l_i_args_0 = GlobalCLIArgs(dict_0)

if __name__ == '__main__':
    import os
    import sys

    if os.path.exists('/tmp/ansible_collections'):
        sys.path.insert(0, '/tmp/ansible_collections')

    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.common.arguments import (
        RawDescriptionDefaultHelpFormatter,
        RawTextHelpFormatter,
        AnsibleArgumentParser,
    )

    parser = AnsibleArg

# Generated at 2022-06-25 13:07:19.058165
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()


# Generated at 2022-06-25 13:07:21.352657
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict_2 = {'a': 'b', 'c': 'd'}
    c_l_i_args_0 = CLIArgs(dict_2)
    assert c_l_i_args_0['a'] == 'b' and c_l_i_args_0['c'] == 'd'


# Generated at 2022-06-25 13:07:22.269195
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Setup
    v_0 = _ABCSingleton()



# Generated at 2022-06-25 13:07:26.285514
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # String, String -> CLIArgs
    # Tests that CLIArgs is created correctly
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    c_l_i_args_0 = CLIArgs(dict_0)
    assert isinstance(c_l_i_args_0, CLIArgs)



# Generated at 2022-06-25 13:08:15.505535
# Unit test for constructor of class _ABCSingleton

# Generated at 2022-06-25 13:08:17.121360
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Create an instance of class _ABCSingleton
    _abc_singleton_0 = _ABCSingleton()


# Generated at 2022-06-25 13:08:21.439224
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # 1st call to _ABCSingleton()
    test_singleton_0 = _ABCSingleton()

    # 2nd call to _ABCSingleton()
    test_singleton_1 = _ABCSingleton()

    # test if both calls to _ABCSingleton() are the same object
    if (test_singleton_0 != test_singleton_1):
        raise Exception("Object returned by 2nd call to _ABCSingleton() does not match the object returned by 1st call to _ABCSingleton().")


# Generated at 2022-06-25 13:08:24.333768
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    global_c_l_i_args_0 = GlobalCLIArgs(dict_0)

# Generated at 2022-06-25 13:08:29.176783
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    bool_0 = True
    c_l_i_args_0 = CLIArgs({})
    assert bool_0 is True
    assert isinstance(c_l_i_args_0, ImmutableDict)
    assert isinstance(c_l_i_args_0, CLIArgs)
    assert isinstance(c_l_i_args_0, Mapping)
    assert not isinstance(c_l_i_args_0, Singleton)



# Generated at 2022-06-25 13:08:31.489634
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
  bool_0 = True
  dict_0 = {bool_0: bool_0, bool_0: bool_0}
  c_l_i_args_0 = CLIArgs(dict_0)



# Generated at 2022-06-25 13:08:41.091916
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_0 = GlobalCLIArgs.from_options(False)
    GlobalCLIArgs.from_options(False)
    GlobalCLIArgs.from_options(False)
    GlobalCLIArgs.from_options(False)
    bool_0 = GlobalCLIArgs(True)
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    GlobalCLIArgs.from_options(dict_0)
    c_l_i_args_0 = CLIArgs.from_options(dict_0)
    c_l_i_args_1 = CLIArgs(dict_0)
    bool_1 = bool_1
    c_l_i_args_2 = CLIArgs(bool_1)

test_case_0()
test_GlobalCLIArgs()

# Generated at 2022-06-25 13:08:43.032054
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    dict_0 = dict()
    global_c_l_i_args_0 = GlobalCLIArgs(dict_0)


# Function to test CLIArgs.from_options

# Generated at 2022-06-25 13:08:52.871035
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_10 = False
    dict_10 = {bool_10: bool_10, bool_10: bool_10}
    global_c_l_i_args_0 = GlobalCLIArgs()
    global_c_l_i_args_1 = GlobalCLIArgs()
    assert global_c_l_i_args_0 is global_c_l_i_args_1
    global_c_l_i_args_0 = GlobalCLIArgs(dict_10)
    bool_2 = bool_10
    dict_2 = {bool_2: bool_2, bool_2: bool_2}
    global_c_l_i_args_0 = GlobalCLIArgs(dict_2)
    bool_2 = True

# Generated at 2022-06-25 13:08:55.815830
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    global_c_l_i_args_0 = GlobalCLIArgs(dict_0)

# Generated at 2022-06-25 13:10:34.280881
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    list_0 = ['4', '9', 'u', 'd']
    global_c_l_i_args_0 = GlobalCLIArgs(list_0)
    global_c_l_i_args_0 = GlobalCLIArgs(list_0)
    global_c_l_i_args_0 = GlobalCLIArgs(list_0)
    global_c_l_i_args_0 = GlobalCLIArgs(list_0)
    global_c_l_i_args_0 = GlobalCLIArgs(list_0)
    global_c_l_i_args_0 = GlobalCLIArgs(list_0)
    global_c_l_i_args_0 = GlobalCLIArgs(list_0)

# Generated at 2022-06-25 13:10:37.251486
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    c_l_i_args_0 = CLIArgs(dict_0)


if __name__ == "__main__":
    test_CLIArgs()