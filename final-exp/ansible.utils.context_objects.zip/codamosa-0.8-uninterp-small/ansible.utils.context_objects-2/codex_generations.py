

# Generated at 2022-06-25 13:00:48.161260
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_case_0()

if __name__ == '__main__':
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:00:51.169342
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = -802.04241
    global_c_l_i_args_0 = CLIArgs(float_0)
    return global_c_l_i_args_0


# Generated at 2022-06-25 13:00:51.919715
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()

# Generated at 2022-06-25 13:00:53.928162
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_1 = 140.166
    global_c_l_i_args_1 = GlobalCLIArgs(float_1)


# Generated at 2022-06-25 13:00:56.119395
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.path import makedirs_safe

    makedirs_safe("/home/keith/fake_dir/fake_dir2")

test_CLIArgs()

# Generated at 2022-06-25 13:00:58.945588
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_1 = 12.8594
    global_c_l_i_args_0 = GlobalCLIArgs(float_1)

test_GlobalCLIArgs()

# Generated at 2022-06-25 13:01:01.371502
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = -802.04241
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)


# Generated at 2022-06-25 13:01:02.710610
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert isinstance(GlobalCLIArgs(), GlobalCLIArgs)


# Generated at 2022-06-25 13:01:03.416616
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Not Implemented
    pass



# Generated at 2022-06-25 13:01:05.306473
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = -802.04241
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)


# Generated at 2022-06-25 13:01:11.096192
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    c_l_i_args_1 = GlobalCLIArgs
    c_l_i_args_2 = GlobalCLIArgs
    c_l_i_args_1 is c_l_i_args_2


# Generated at 2022-06-25 13:01:12.692980
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    try:
        assert GlobalCLIArgs()
    except AssertionError as err:
        print(err)


# Generated at 2022-06-25 13:01:18.798375
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    g_c_l_i_args_0 = GlobalCLIArgs()
    assert g_c_l_i_args_0.__class__.__name__ == 'GlobalCLIArgs'
    assert g_c_l_i_args_0.__dict__.__class__.__name__ == 'ImmutableDict'

# Unit test of _ABCSingleton
# This test assumes that no other instance of _ABCSingleton has been created by the time
# the test is run.

# Generated at 2022-06-25 13:01:26.693175
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    str_0 = 'Collection(s)'
    list_0 = ['C', 'o', 'l', 'l', 'e', 'c', 't', 'i', 'o', 'n', '(', 's', ')']
    set_0 = {'n', 's', ')', 'i', 't', 'e', 'l', '(', 'o', 'c', 'C'}
    tup_0 = ('s', ')', '(', 'n', 'C', 'o', 'e', 'l', 'i', 'c', 't', 't', 'o')

# Generated at 2022-06-25 13:01:33.608597
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    str_1 = 'Collection(s)'
    c_l_i_args_1 = CLIArgs(str_1)
    c_l_i_args_1 = GlobalCLIArgs.from_options(c_l_i_args_1)
    cls = CLIArgs
    cls_type = type(cls)
    is_singleton = GlobalCLIArgs.is_singleton
    is_instantiable = GlobalCLIArgs.is_instantiable
    test_key = id(GlobalCLIArgs)
    test_val = 'Singleton'
    assert test_key != test_val, 'Unit test for _ABCSingleton failed!'


# Generated at 2022-06-25 13:01:34.145529
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert GlobalCLIArgs()

# Generated at 2022-06-25 13:01:35.441701
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    str_0 = 'Collection(s)'
    c_l_i_args_0 = CLIArgs(str_0)


# Generated at 2022-06-25 13:01:38.542790
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    str_0= 'Collection(s)'
    class_instance_0 = GlobalCLIArgs(str_0)


# Compilation of classes GlobalCLIArgs and test_GlobalCLIArgs (constructor)

# Generated at 2022-06-25 13:01:41.297279
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    print("Unit test for constructor of class GlobalCLIArgs")
    test_case_0()

if __name__ == '__main__':
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:01:48.682968
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli.argparse import parse_cli_args
    cmdline = '--diff --limit localhost'
    options, args = parse_cli_args(cmdline.split())
    cliargs = GlobalCLIArgs.from_options(options)

    # Verify that expected key exists in the dictionary
    assert 'diff' in cliargs

    # Verify that the value of the expected key is as expected
    assert cliargs['diff'] == True

    # Verify that expected key exists in the dictionary
    assert 'limit' in cliargs

    # Verify that the value of the expected key is as expected
    assert cliargs['limit'] == 'localhost'

# Generated at 2022-06-25 13:01:59.995964
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = GlobalCLIArgs()
    global_c_l_i_args_1 = GlobalCLIArgs()
    if id(global_c_l_i_args_0) != id(global_c_l_i_args_1):
        print(False)
        pass
    else:
        print(True)

if __name__ == '__main__':
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:02:03.767558
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, Singleton)
    assert issubclass(_ABCSingleton, ABCMeta)
    # Constructor test case
    try:
        _ABCSingleton()
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 13:02:06.040832
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        type('_ABCSingleton_test', (_ABCSingleton,), {})
    except:
        print("ERROR: Unit test for _ABCSingleton failed")


# Generated at 2022-06-25 13:02:08.732615
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = "Collection(s)"
    assert CLIArgs(args) is not None and CLIArgs(args) is not False, 'constructor of class CLIArgs failed'

# Generated at 2022-06-25 13:02:10.000607
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    b_0 = _ABCSingleton()


# Generated at 2022-06-25 13:02:13.829605
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    try:
        # No argument constructor, so failure for more than zero arguments
        str_0 = 'Collection(s)'
        c_l_i_args_0 = CLIArgs(str_0)
        assert (False)
    except TypeError as err:
        # Expected to fail, so no error
        pass


# Generated at 2022-06-25 13:02:15.895197
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABCSingleton0(Singleton, ABCMeta):
        pass
    _ABCSingleton0(str, str, **{})


# Generated at 2022-06-25 13:02:19.935436
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    o_p_t_i_o_n_s_0 = 1
    g_l_o_b_a_l_c_l_i_a_r_g_s_0 = GlobalCLIArgs.from_options(o_p_t_i_o_n_s_0)

test_GlobalCLIArgs()

# Generated at 2022-06-25 13:02:23.094047
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    try:
        str_0 = 'Collection(s)'
        c_l_i_args_0 = CLIArgs(str_0)
    except:
        print('Found issue(s) when testing CLIArgs constructor')
        raise


# Generated at 2022-06-25 13:02:25.231006
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Test instance creation of class _ABCSingleton.
    # Variable(s) initialization
    test_case_0()

# Generated at 2022-06-25 13:02:37.047800
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    temp_new_instance_0 = _ABCSingleton.__new__(_ABCSingleton)
    temp_new_instance_0.__init__()
    assert temp_new_instance_0



# Generated at 2022-06-25 13:02:40.813862
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    try:
        print("Entering test_CLIArgs")
        test_case_0()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 13:02:43.004647
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    str_0 = 'Collection(s)'
    instance_0 = GlobalCLIArgs.from_options(str_0)


if __name__ == '__main__':
    test_case_0()
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:02:47.893270
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    str_0 = 'Collection(s)'
    str_1 = 'GlobalCLIArgs'
    str_2 = 'Container'
    str_3 = 'from_options'
    str_4 = 'from_options'
    str_5 = 'test_GlobalCLIArgs'
    str_6 = 'test_GlobalCLIArgs'
    cli_args_0 = GlobalCLIArgs(str_0)


# Generated at 2022-06-25 13:02:49.575736
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    str_0 = 'Collection(s)'
    c_l_i_args_0 = CLIArgs.from_options(str_0)



# Generated at 2022-06-25 13:02:51.563018
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    str_0 = 'Collection(s)'
    GlobalCLIArgs(str_0)


# Generated at 2022-06-25 13:02:54.663488
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    c_l_i_args_0 = CLIArgs('test_string')
    assert c_l_i_args_0.__dict__ == ImmutableDict({'_data': 'test_string'})

test_case_0()

# Generated at 2022-06-25 13:02:56.385050
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    str_0 = 'Collection(s)'
    c_l_i_args_0 = CLIArgs(str_0)


# Generated at 2022-06-25 13:03:05.178749
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from collections import Mapping, MutableMapping
    from ansible.module_utils.parsing.convert_bool import BOOLEANS
    from ansible.module_utils.common.dict_transformations import merge_hash

    dct_0 = {}

# Generated at 2022-06-25 13:03:07.209870
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    for i in range(10):
        obj = _ABCSingleton()
        assert obj is not None


# Generated at 2022-06-25 13:03:27.442659
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    pass



# Generated at 2022-06-25 13:03:29.612673
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    str_0 = 'Collection(s)'
    c_l_i_args_0 = CLIArgs(str_0)



# Generated at 2022-06-25 13:03:31.153174
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    str0 = 'Collection(s)'
    CLI0 = CLIArgs(str0)


# Generated at 2022-06-25 13:03:32.912425
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    abc_singleton_0 = _ABCSingleton()
    assert abc_singleton_0


# Generated at 2022-06-25 13:03:36.043663
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    str_0 = 'Command line options'
    global_c_l_i_args_0 = GlobalCLIArgs(str_0)


test_case_0()
test_GlobalCLIArgs()

# Generated at 2022-06-25 13:03:38.575877
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    str_1 = 'Collection(s)'
    c_l_i_args_1 = CLIArgs(str_1)
    assert c_l_i_args_1 == 'Collection(s)'


# Generated at 2022-06-25 13:03:39.379671
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    x = _ABCSingleton()


# Generated at 2022-06-25 13:03:48.628964
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.utils.collection_loader._collection_finder import _find_collections
    import os
    import os.path
    import sys
    import tempfile
    # Create temporary directory
    tmpdir = tempfile.mkdtemp(prefix='ansible-test-GlobalCLIArgs-')
    # Create the collection config file
    fd, coll_config_filename = tempfile.mkstemp(prefix='ansible-collection-config-', dir=tmpdir)
    coll_config_file = os.fdopen(fd, 'w')
    coll_config_file.write('collections_paths:\n  - "%s"\n' % tmpdir)
    coll_config_file.close()
    # Create the test collection
    collection_0 = Ansible

# Generated at 2022-06-25 13:03:50.450217
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    str_0 = 'Collection(s)'
    c_l_i_args_0 = CLIArgs(str_0)

# Generated at 2022-06-25 13:03:52.458717
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    str_0 = 'Collection(s)'
    global_c_l_i_args_0 = GlobalCLIArgs(str_0)


# Generated at 2022-06-25 13:04:20.959439
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test CLIArgs constructor without args

    cli_args = CLIArgs({})
    assert cli_args == {}, "Failed to create empty dict"
    assert cli_args.__class__.__name__ == 'ImmutableDict', "Dict improperly constructed"

    # Test CLIArgs constructor with args
    cli_args = CLIArgs({'arg_one': 1, 'arg_two': [2, 3]})
    assert cli_args == {'arg_one': 1, 'arg_two': [2, 3]}, "Args improperly stored"
    assert cli_args.__class__.__name__ == 'ImmutableDict', "Dict improperly constructed"

    # Test CLIArgs constructor with a dict containing a dict

# Generated at 2022-06-25 13:04:22.538716
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    print("\nTesting constructor of class CLIArgs.")
    print("\nTest case 0: ")
    test_case_0()
    print("Test case 0: pass")
    return True



# Generated at 2022-06-25 13:04:25.718717
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import random
    import string

    global_cli_args = GlobalCLIArgs({"foo": "bar"})
    assert global_cli_args["foo"] == "bar"

# Generated at 2022-06-25 13:04:28.679196
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    str_0 = 'Collection(s)'
    c_l_i_args_0 = CLIArgs(str_0)
    assert c_l_i_args_0 == str_0


# Generated at 2022-06-25 13:04:33.587148
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import GlobalCLIArgs
    str_0 = 'Collection(s)'
    g_c_l_i_args_0 = GlobalCLIArgs(str_0)
    assert isinstance(g_c_l_i_args_0, ImmutableDict)

# Generated at 2022-06-25 13:04:35.743823
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class_one = _ABCSingleton()
    class_two = _ABCSingleton()
    assert class_one is class_two


# Generated at 2022-06-25 13:04:37.034105
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs('Collection(s)') is not None


# Generated at 2022-06-25 13:04:41.068364
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert 'CLIArgs' == CLIArgs.__name__
    str_0 = 'Collection(s)'
    instance_0 = CLIArgs(str_0)
    assert isinstance(instance_0, CLIArgs)
    assert instance_0.__name__ == 'CLIArgs'



# Generated at 2022-06-25 13:04:42.291305
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    _abc_singleton_0 = _ABCSingleton()


# Generated at 2022-06-25 13:04:46.396199
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    str_0 = 'Collection(s)'
    c_l_i_args_0 = GlobalCLIArgs(str_0)

# Generated at 2022-06-25 13:05:31.467606
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    str_0 = 'Collection(s)'
    global_c_l_i_args_0 = GlobalCLIArgs(str_0)

# print(test_case_0(), test_GlobalCLIArgs())

# Generated at 2022-06-25 13:05:32.775796
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert isinstance(_ABCSingleton, type)



# Generated at 2022-06-25 13:05:34.682699
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    obj_0 = _ABCSingleton()
    obj_1 = _ABCSingleton()
    assert obj_0 is obj_1



# Generated at 2022-06-25 13:05:35.813231
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    str_0 = 'Collection(s)'
    GlobalCLIArgs(str_0)

# Generated at 2022-06-25 13:05:36.904707
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 13:05:38.602208
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    str_0 = 'Collection(s)'
    g_c_l_i_args_0 = GlobalCLIArgs(str_0)

# Generated at 2022-06-25 13:05:41.290373
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    x = GlobalCLIArgs('Collection(s)')
    assert x == {'a': {'n': 's'}, 'b': {'e': {'l': 's'}}}


# Generated at 2022-06-25 13:05:43.220491
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    obj = _ABCSingleton()
    assert isinstance(obj, ABCMeta)
    assert isinstance(obj, Singleton)



# Generated at 2022-06-25 13:05:47.421106
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict_0 = {
        u"os_auth_plugin": u"password"
    }
    class_0 = CLIArgs(dict_0)
    assert (class_0.__dict__.keys() == dict_0.keys())
    assert (class_0.__class__.__name__ == "CLIArgs")


# Generated at 2022-06-25 13:05:54.774961
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert isinstance(str_0, (text_type, binary_type))
    assert isinstance(str_0, (text_type, binary_type))
    assert isinstance(str_0, (text_type, binary_type))
    assert isinstance(c_l_i_args_0, ImmutableDict)
    assert isinstance(c_l_i_args_0, ImmutableDict)
    assert isinstance(c_l_i_args_0, ImmutableDict)
    assert not isinstance(c_l_i_args_0, Container)
    assert not isinstance(c_l_i_args_0, Container)


# Generated at 2022-06-25 13:07:31.713123
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    g_c_l_i_args = GlobalCLIArgs
    return True

# Generated at 2022-06-25 13:07:41.051318
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    str_0 = 'No unit test available yet.  This is a fragment of code that will be the unit test'
    _ABCSingleton_0 = _ABCSingleton(str_0)
    assert _ABCSingleton_0 is not None, 'Unable to create object type: _ABCSingleton'
    assert _ABCSingleton_0._abc_registry is not None, 'Unable to create object type: _ABCSingleton'
    assert _ABCSingleton_0._abc_cache is not None, 'Unable to create object type: _ABCSingleton'
    assert _ABCSingleton_0._abc_negative_cache is not None, 'Unable to create object type: _ABCSingleton'
    assert _ABCSingleton_0._abc_negative_cache_version is not None, 'Unable to create object type: _ABCSingleton'
   

# Generated at 2022-06-25 13:07:41.898816
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()

# Generated at 2022-06-25 13:07:43.344550
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    g_c_l_i_args_0 = GlobalCLIArgs()


# Generated at 2022-06-25 13:07:45.810624
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    str_0 = 'Collection(s)'
    c_l_i_args_0 = CLIArgs(str_0)
    assert c_l_i_args_0.lookup('s') is False


# Generated at 2022-06-25 13:07:49.299763
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    print("test_CLIArgs")
    str_0 = 'Collection(s)'
    c_l_i_args_0 = CLIArgs(str_0)
    assert c_l_i_args_0 is not None
    assert isinstance(c_l_i_args_0, CLIArgs)


# Generated at 2022-06-25 13:07:54.868935
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    with pytest.raises(TypeError):
        GlobalCLIArgs('0')
    assert isinstance(GlobalCLIArgs(None), GlobalCLIArgs)
    with pytest.raises(TypeError):
        GlobalCLIArgs(0)
    with pytest.raises(TypeError):
        GlobalCLIArgs(True)
    with pytest.raises(TypeError):
        GlobalCLIArgs(False)
    with pytest.raises(TypeError):
        GlobalCLIArgs(())
    with pytest.raises(TypeError):
        GlobalCLIArgs([])
    with pytest.raises(TypeError):
        GlobalCLIArgs({})
    assert isinstance(GlobalCLIArgs(None), GlobalCLIArgs)


# Generated at 2022-06-25 13:07:56.553568
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = 'Littlest Pet Shop'
    test_global_cli_args = GlobalCLIArgs.from_options(options)
    assert test_global_cli_args == options

# Generated at 2022-06-25 13:07:57.588531
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert 'str_0' == 'str_0'


# Generated at 2022-06-25 13:07:59.706987
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = GlobalCLIArgs()
    global_c_l_i_args_1 = GlobalCLIArgs()