

# Generated at 2022-06-25 13:00:43.599460
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 508.625
    c_l_i_args_0 = CLIArgs(float_0)


# Generated at 2022-06-25 13:00:47.899297
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Constructor for GlobalCLIArgs, which is safe and repeatable.
    """
    float_0 = 508.625
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)
    assert_equals(global_c_l_i_args_0, float_0)


# Generated at 2022-06-25 13:00:53.104387
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # The type of test__ABCSingleton should be _ABCSingleton
    assert type(test__ABCSingleton) == _ABCSingleton
    # Check test__ABCSingleton is a subclass of ABCMeta
    assert issubclass(test__ABCSingleton, ABCMeta)
    # Check test__ABCSingleton is a subclass of Singleton
    assert issubclass(test__ABCSingleton, Singleton)

# Generated at 2022-06-25 13:00:55.374927
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Test the __metaclass__ of class CLIArgs is _ABCSingleton
    assert CLIArgs.__metaclass__ == _ABCSingleton



# Generated at 2022-06-25 13:00:58.831755
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys

    # Test the constructor of class GlobalCLIArgs
    c_l_i_args_0 = GlobalCLIArgs(sys.argv)


# Generated at 2022-06-25 13:01:04.522971
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils.common.collections import _ABCSingleton
    from ansible.module_utils.common.collections import CLIArgs
    from ansible.module_utils.common.collections import GlobalCLIArgs
    c_l_i_args_0 = CLIArgs(17)
    g_l_o_b_a_l_c_l_i_args_0 = GlobalCLIArgs(5)


# Generated at 2022-06-25 13:01:05.885619
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        test_case_0()
    except TypeError:
        pass


# Generated at 2022-06-25 13:01:08.113880
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = GlobalCLIArgs()
    global_c_l_i_args_0.from_options(None)


# Generated at 2022-06-25 13:01:12.332427
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_passed = True
    test_GlobalCLIArgs_0 = GlobalCLIArgs()

    if test_GlobalCLIArgs_0 is None:
        test_passed = False

    return test_passed


test_cases = [
    test_case_0,
    test_GlobalCLIArgs
]



# Generated at 2022-06-25 13:01:14.775656
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    cli_args_1 = GlobalCLIArgs()
    cli_args_2 = GlobalCLIArgs()
    assert cli_args_1 == cli_args_2



# Generated at 2022-06-25 13:01:20.261345
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_method = _ABCSingleton.__new__
    obj = test_method(None, None, None, None)
    assert isinstance(obj, _ABCSingleton)


# Generated at 2022-06-25 13:01:22.857276
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    a = _ABCSingleton()
    a.__instancecheck__(int)
    a.__subclasscheck__(int)
    a.__subclasscheck__(object)



# Generated at 2022-06-25 13:01:25.666681
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs()
    GlobalCLIArgs()
    assert(GlobalCLIArgs() == GlobalCLIArgs())

if __name__ == '__main__':
    test_case_0()
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:01:27.076812
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    float_0 = 508.625
    c_l_i_args_0 = CLIArgs.from_options(float_0)


# Generated at 2022-06-25 13:01:28.366611
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, type)


# Generated at 2022-06-25 13:01:35.546327
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict_0 = dict()
    dict_0['list_0'] = list()
    dict_1 = dict()
    dict_0['list_0'].append(dict_1)
    dict_2 = dict()
    dict_3 = dict()
    dict_2['dict_3'] = dict_3
    dict_0['list_0'].append(dict_2)
    dict_4 = dict()
    dict_0['dict_4'] = dict_4
    c_l_i_args_0 = CLIArgs(dict_0)
    assert c_l_i_args_0['list_0'][0] == dict_1
    assert c_l_i_args_0['list_0'][1] == dict_2

# Generated at 2022-06-25 13:01:36.218225
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    pass

# Generated at 2022-06-25 13:01:39.719159
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils.common.collections import Singleton
    from ansible.module_utils.common.collections import ABCMeta
    assert issubclass(_ABCSingleton, (Singleton, ABCMeta))


# Generated at 2022-06-25 13:01:41.836247
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {1: 1}
    assert CLIArgs.from_options(mapping) == CLIArgs(mapping)


# Generated at 2022-06-25 13:01:42.772968
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 508.625
    c_l_i_args_0 = CLIArgs(float_0)



# Generated at 2022-06-25 13:01:45.498025
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args_0 = GlobalCLIArgs()


# Generated at 2022-06-25 13:01:46.132464
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    s_ = _ABCSingleton()



# Generated at 2022-06-25 13:01:47.205455
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    ABCSingleton_0 = _ABCSingleton()
    assert isinstance(_ABCSingleton, type)


# Generated at 2022-06-25 13:01:51.300578
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    try:
        float_0 = 508.625
        c_l_i_args_0 = CLIArgs(float_0)
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-25 13:01:54.341360
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert GlobalCLIArgs.instance() is GlobalCLIArgs.instance()
    assert GlobalCLIArgs.instance() is not GlobalCLIArgs.instance()

# Generated at 2022-06-25 13:01:57.899124
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 508.625
    c_l_i_args_0 = GlobalCLIArgs.make(float_0)
    assert isinstance(c_l_i_args_0, GlobalCLIArgs)


# Generated at 2022-06-25 13:02:01.133255
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = GlobalCLIArgs()
    assert isinstance(global_c_l_i_args_0, GlobalCLIArgs)

test_case_0()
test_GlobalCLIArgs()

# Generated at 2022-06-25 13:02:02.576468
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    g_c_l_i_args_0 = GlobalCLIArgs()

# Generated at 2022-06-25 13:02:12.160827
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # check a_b_c_singleton_0 is an instance of _ABCSingleton
    a_b_c_singleton_0 = _ABCSingleton()
    assert isinstance(a_b_c_singleton_0, _ABCSingleton)

    # check type(a_b_c_singleton_0) is _ABCSingleton
    assert type(a_b_c_singleton_0) is _ABCSingleton

    # check the metaclass of a_b_c_singleton_0 is _ABCSingleton
    assert type(a_b_c_singleton_0) is _ABCSingleton
    assert type(type(a_b_c_singleton_0)) is _ABCSingleton

    # check a_b_c_singleton_1 is an instance of _ABCSingleton
    a_b

# Generated at 2022-06-25 13:02:15.466761
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 508.625
    c_l_i_args_0 = CLIArgs(float_0)
    assert (c_l_i_args_0 == 508.625)


# Generated at 2022-06-25 13:02:20.660848
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({"a": "b", "c": "d"})


# Generated at 2022-06-25 13:02:23.530821
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 508.625
    c_l_i_args_0 = CLIArgs(float_0)
    assert isinstance(c_l_i_args_0, object)


# Generated at 2022-06-25 13:02:27.640072
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    abc_singleton_0 = _ABCSingleton()
    assert isinstance(abc_singleton_0, Singleton)
    assert isinstance(abc_singleton_0, ABCMeta)


# Generated at 2022-06-25 13:02:35.691332
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 508.625
    c_l_i_args_0 = CLIArgs(float_0)
    for i in range(0,2):
        # c_l_i_args_0
        if c_l_i_args_0.get((i**2)%2):
            print(c_l_i_args_0.get((i**2)%2))
        else:
            print('c_l_i_args_0.get(' + str((i**2)%2) + ')')
    # c_l_i_args_0
    print(c_l_i_args_0)

# Generated at 2022-06-25 13:02:47.131447
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common.collections import MutableSequence, MutableSet

    class MyMapping(MutableMapping):
        pass

    class MySequence(MutableSequence):
        pass

    class MySet(MutableSet):
        pass

    # Use a lambda function to make sure we are not just creating a Singleton metaclass

# Generated at 2022-06-25 13:02:50.799489
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    try:
        test_case_0()
        test_case_1()
    except Exception:
        print("Exception in user code:")
        print('-'*60)
        traceback.print_exc(file=sys.stdout)
        print('-'*60)
        raise

if __name__ == "__main__":
    test_CLIArgs()

# Generated at 2022-06-25 13:02:51.788756
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()

# Generated at 2022-06-25 13:03:00.725164
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    c_l_i_args_0 = CLIArgs({})
    c_l_i_args_xml_0 = c_l_i_args_0.get('xml')
    int_0 = c_l_i_args_0.setdefault('java', int())
    c_l_i_args_0['dokku'] = int_0
    c_l_i_args_0.setdefault('ansible', c_l_i_args_xml_0)
    str_0 = c_l_i_args_0.setdefault('java', str())
    c_l_i_args_0.setdefault('dokku', str_0)

# Generated at 2022-06-25 13:03:02.934318
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Test with generic mapping object
    assert isinstance(GlobalCLIArgs.instance(), GlobalCLIArgs)
    # Test with globals
    test_case_0()


# Generated at 2022-06-25 13:03:06.819286
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 508.625
    print("TEST: GlobalCLIArgs()")
    c_l_i_args_0 = GlobalCLIArgs(float_0)
    return True

# Run the tests
if __name__ == "__main__":
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:03:15.217052
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    obj = _ABCSingleton()
    assert isinstance(obj, _ABCSingleton)


# Generated at 2022-06-25 13:03:16.394545
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    _ABCSingleton_0 = _ABCSingleton()


# Generated at 2022-06-25 13:03:18.337892
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 508.625
    c_l_i_args_0 = CLIArgs(float_0)


# Generated at 2022-06-25 13:03:21.994356
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-25 13:03:24.374938
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    expected_result = None
    c_l_i_args_0 = GlobalCLIArgs()
    assert (c_l_i_args_0 == expected_result)

# Generated at 2022-06-25 13:03:33.879769
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = GlobalCLIArgs.make_instance()

    string_0 = 'SUCCESS'
    string_1 = 'FAILURE'
    string_2 = 'SUCCESS'
    string_3 = 'FAILURE'
    string_4 = 'SUCCESS'
    string_5 = 'FAILURE'
    string_6 = 'SUCCESS'
    string_7 = 'FAILURE'

    # Checking if one GlobalCLIArgs is equal to itself
    if global_c_l_i_args_0 != GlobalCLIArgs.make_instance():
        print(string_0)
    else:
        print(string_1)

    # Checking if one GlobalCLIArgs is equal to itself

# Generated at 2022-06-25 13:03:36.339565
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    expected_result_0 = 508.625
    assert GlobalCLIArgs.from_options(expected_result_0) == expected_result_0

# Generated at 2022-06-25 13:03:42.808509
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    command_line_args = {'some_key': {'foo': 'bar'}, 'another_key': {
        'foo': 'bar', 'bar': 'baz'}, 'yet_another_key': ['foo', 'bar', 'baz']}
    c_l_i_args_0 = CLIArgs(command_line_args)
    # Test to make sure we are properly immutable
    try:
        c_l_i_args_0['some_key']['foo'] = 'baz'
    except TypeError:
        pass
    else:
        raise AssertionError
    # Test to make sure we are properly immutable
    try:
        c_l_i_args_0['yet_another_key'][1] = 'baz'
    except TypeError:
        pass
    else:
        raise

# Generated at 2022-06-25 13:03:44.561775
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    obj_0 = _ABCSingleton()
    obj_1 = _ABCSingleton()
    assert obj_0 is obj_1



# Generated at 2022-06-25 13:03:46.166286
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        _ABCSingleton()
    except:
        pass


# Generated at 2022-06-25 13:03:55.661436
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 508.625
    c_l_i_args_0 = CLIArgs(float_0)
    assert (c_l_i_args_0[0] == 508.625)



# Generated at 2022-06-25 13:03:58.942364
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping_0 = {'bar': None, 'baz': 'normal', 'foo': 'yes'}
    c_l_i_args_0 = CLIArgs(mapping_0)
    print('c_l_i_args_0 = ' + str(c_l_i_args_0))


# Generated at 2022-06-25 13:04:00.850811
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    CLIArgs(ImmutableDict({"foo": u"bar", u'baz': u'quuz', True: False}))

# Generated at 2022-06-25 13:04:02.014001
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs.from_options(str)


# Generated at 2022-06-25 13:04:11.343180
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 508.625
    c_l_i_args_0 = CLIArgs(float_0)
    global_c_l_i_args_0 = GlobalCLIArgs(float_0)
    # Assert that the instance is the same as the singleton
    assert global_c_l_i_args_0.__class__.__name__ == 'GlobalCLIArgs'
    assert global_c_l_i_args_0 is GlobalCLIArgs()
    # Assert that the class is derived from a parent class
    assert issubclass(global_c_l_i_args_0.__class__, CLIArgs)
    # Assert that the class inherits from the Singleton class
    assert issubclass(global_c_l_i_args_0.__class__, Singleton)


# Generated at 2022-06-25 13:04:20.534398
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 508.625
    c_l_i_args_0 = CLIArgs(float_0)
    # GlobalCLIArgs is a subclass of CLIArgs
    assert issubclass(GlobalCLIArgs, CLIArgs)
    # GlobalCLIArgs is a singleton
    assert isinstance(GlobalCLIArgs.instance(), GlobalCLIArgs)
    # GlobalCLIArgs is a metaclass
    assert isinstance(GlobalCLIArgs, metaclass=ABCMeta)
    assert isinstance(GlobalCLIArgs, metaclass=_ABCSingleton)
    # This is a singleton, so we shouldn't be able to create additional instances of it
    with pytest.raises(TypeError) as excinfo:
        GlobalCLIArgs(c_l_i_args_0)

# Generated at 2022-06-25 13:04:25.193523
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from unittest.case import TestCase
    from abc import ABCMeta

    class MySingleton(metaclass=_ABCSingleton):
        pass

    class MyABC(metaclass=_ABCMeta):
        pass

    class MyAbcSingleton(MySingleton, MyABC):
        pass

    class MyABCSingleton(MyABC, MySingleton):
        pass

    class MyABCSingleton2(metaclass=_ABCSingleton):
        def static_method(arg):
            pass

        static_method = staticmethod(static_method)


if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-25 13:04:27.868085
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 508.625
    args_0 = vars(float_0)
    c_l_i_args_0 = GlobalCLIArgs(args_0)

# Generated at 2022-06-25 13:04:37.582325
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    import ansible.module_utils.common.collections
    import ansible.utils
    import types
    import inspect
    import sys

    members = {name for name, value in inspect.getmembers(ansible.module_utils.common.collections)}
    assert 'CLIArgs' in members

    members = {name for name, value in inspect.getmembers(ansible.utils)}
    assert 'Singleton' in members

    # Validate the class can be instantiated
    instance = CLIArgs({})

    # Validate __doc__

# Generated at 2022-06-25 13:04:40.161017
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args_0 = GlobalCLIArgs(1)

if __name__ == '__main__':
    test_case_0()
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:04:58.000870
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import pytest

    with pytest.raises(TypeError) as err:
        GlobalCLIArgs(sys.version_info)
        assert not err

# Generated at 2022-06-25 13:04:59.082671
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_case_0()


# Generated at 2022-06-25 13:05:08.748519
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 508.625
    c_l_i_args_0 = CLIArgs(float_0)
    set_0 = {'tej|0', 'tej|1', 'tej|2', 'tej|3', 'tej|4', 'tej|5', 'tej|6', 'tej|7', 'tej|8', 'tej|9'}
    set_1 = {'tej|0', 'tej|1', 'tej|2', 'tej|3', 'tej|4', 'tej|5', 'tej|6', 'tej|7', 'tej|8', 'tej|9'}
    c_l_i_args_1 = CLIArgs(set_0)

# Generated at 2022-06-25 13:05:13.531260
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 508.625
    c_l_i_args_0 = CLIArgs(float_0)
    assert c_l_i_args_0.get() == 508.625


# Generated at 2022-06-25 13:05:14.368500
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_case_0()


# Generated at 2022-06-25 13:05:15.568604
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    with pytest.raises(Exception):
        test_case_0()

# Generated at 2022-06-25 13:05:23.613864
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test CLIArgs constructor
    """
    # Test with mapping that contains a list

    # int_0 is a list of integers

# Generated at 2022-06-25 13:05:24.049799
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
  pass


# Generated at 2022-06-25 13:05:28.389111
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert isinstance(_ABCSingleton, Singleton)
    assert isinstance(_ABCSingleton, ABCMeta)
    assert issubclass(_ABCSingleton, Singleton)
    assert issubclass(_ABCSingleton, ABCMeta)
    assert not issubclass(type, _ABCSingleton)
    assert not issubclass(Singleton, _ABCSingleton)
    assert not issubclass(ABCMeta, _ABCSingleton)

# Generated at 2022-06-25 13:05:31.519121
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 59.107
    c_l_i_args_0 = CLIArgs(float_0)
    assert  isinstance(c_l_i_args_0, CLIArgs) , "constructor of class CLIArgs did not return an instance of that class"


# Generated at 2022-06-25 13:06:00.496818
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        c_l_i_args_0 = test_case_0()
    except Exception as caught:
        raise AssertionError("Constructor for class _ABCSingleton raised exception when called by test_case_0().") from caught

if __name__ == "__main__":
    import sys
    import traceback
    try:
        test__ABCSingleton()
    except AssertionError as caught:
        sys.stderr.write("{}\n".format(caught))
        traceback.print_exc(limit=-1, file=sys.stderr)
        sys.exit(1)
    except Exception as caught:
        traceback.print_exc(limit=-1, file=sys.stderr)
        sys.exit(1)
    else:
        sys.exit(0)

# Generated at 2022-06-25 13:06:10.302507
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # setting up named tuple for testing
    globals_0 = {'__name__': '__main__', '__doc__': None, '__file__': 'C:/Users/jhaber/Videos/Ansible/sandbox/lib/ansible/cli/__init__.py', '__cached__': None, '__package__': 'ansible.cli', '_make_immutable': _make_immutable, 'CLIArgs': CLIArgs, 'GlobalCLIArgs': GlobalCLIArgs, '__spec__': None, 'test_case_0': test_case_0, 'test__ABCSingleton': test__ABCSingleton, 'test_CLIArgs': test_CLIArgs, 'test_GlobalCLIArgs': test_GlobalCLIArgs}

# Generated at 2022-06-25 13:06:19.127415
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-25 13:06:20.138988
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    _ABCSingleton()


# Generated at 2022-06-25 13:06:25.686726
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # we should be able to make a CLIArgs object with a test value
    # set the test values
    value = 'test'
    # make the object
    c_l_i_args_0 = CLIArgs(value)
    # make sure the value of the object is what we expected
    assert c_l_i_args_0.get('args') == value


# Generated at 2022-06-25 13:06:34.283814
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.utils.path import unfrackpath
    from ansible.utils._text import to_bytes
    from ansible.module_utils.six import PY3
    import os
    import sys

    sys.argv = ["/usr/bin/ansible-config", "view", "--type", "core"]

    # We have a full path - even on Windows
    a_b_c_singleton_0 = _ABCSingleton()
    assert(a_b_c_singleton_0 == a_b_c_singleton_0)
    assert(a_b_c_singleton_0 is a_b_c_singleton_0)
    assert(a_b_c_singleton_0.__class__ is _ABCSingleton)

# Generated at 2022-06-25 13:06:34.822908
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    pass


# Generated at 2022-06-25 13:06:35.635453
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    _singleton0 = _ABCSingleton()


# Generated at 2022-06-25 13:06:40.651929
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 508.625
    GlobalCLIArgs_0 = GlobalCLIArgs(float_0)

if __name__ == '__main__':
    import sys
    import os
    import pytest
    pytest_args = [__file__, '--doctest-modules']
    pytest_args += ['-x', '--tb=native', '--fulltrace', '--color=yes', '--instafail']
    pytest_args += sys.argv[1:]
    exit_code = pytest.main(pytest_args)
    if exit_code == 0:
        os._exit(0)
    else:
        os._exit(1)

# Generated at 2022-06-25 13:06:42.719670
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # self.assertRaises(TypeError, GlobalCLIArgs)
    assert True


# Generated at 2022-06-25 13:07:23.999214
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    pass


# Generated at 2022-06-25 13:07:26.762041
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Initialize an object of the GloablCLIArgs class
    example_dict_ = {'temp_key': 'temp_value'}
    global_cli_args = GlobalCLIArgs(example_dict_)
    # check the values of the temp_key
    assert global_cli_args['temp_key'] != 'not_a_key'



# Generated at 2022-06-25 13:07:29.907270
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    c_l_i_args_0 = CLIArgs(object())
    setattr(c_l_i_args_0, '_ABCSingleton__instance', object())
    setattr(c_l_i_args_0, '__ABCSingleton__instance', object())


# Generated at 2022-06-25 13:07:35.432516
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 508.625
    c_l_i_args_0 = CLIArgs(float_0)
    # String representation of class CLIArgs
    str_0 = "CLIArgs(508.625)"
    str_1 = c_l_i_args_0.__repr__()
    assert str_0 == str_1, f"CLIArgs(508.625) has wrong string representation {str_1}"

# Generated at 2022-06-25 13:07:36.921283
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    c_l_i_args_0 = GlobalCLIArgs(float_0)


# Generated at 2022-06-25 13:07:38.062383
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    obj_0 = _ABCSingleton(1, 2, 3)


# Generated at 2022-06-25 13:07:46.678321
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Create GlobalCLIArgs object
    global_cli_args_0 = GlobalCLIArgs()
    # Check if global_cli_args_0 is of GlobalCLIArgs type
    if not isinstance(global_cli_args_0, GlobalCLIArgs):
        raise AssertionError("global_cli_args_0 is not GlobalCLIArgs type")
    # Check if global_cli_args_0 is of ImmutableDict type
    if not isinstance(global_cli_args_0, ImmutableDict):
        raise AssertionError("global_cli_args_0 is not ImmutableDict type")
    # Check if global_cli_args_0 is of Sequence type

# Generated at 2022-06-25 13:07:50.516273
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Test multiple instances of _ABCSingleton raise an error
    try:
        class test_ABCSingleton(metaclass=_ABCSingleton):
            pass
        class test_ABCSingleton(metaclass=_ABCSingleton):
            pass
    except AssertionError:
        return True
    # If not, then there is a problem
    raise RuntimeError


# Generated at 2022-06-25 13:07:51.592161
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    g_c_l_i_args_0 = GlobalCLIArgs()

# Generated at 2022-06-25 13:07:52.365791
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()



# Generated at 2022-06-25 13:09:17.027717
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args_0 = GlobalCLIArgs(50.0)
    assert isinstance(global_cli_args_0, GlobalCLIArgs)


# Generated at 2022-06-25 13:09:25.828939
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs.__name__ == 'CLIArgs'
    assert CLIArgs.__doc__ == '\n    Hold a parsed copy of cli arguments\n\n    We have both this non-Singleton version and the Singleton, GlobalCLIArgs, version to leave us\n    room to implement a Context object in the future.  Whereas there should only be one set of args\n    in a global context, individual Context objects might want to pretend that they have different\n    command line switches to trigger different behaviour when they run.  So if we support Contexts\n    in the future, they would use CLIArgs instead of GlobalCLIArgs to store their version of command\n    line flags.\n    '


# Generated at 2022-06-25 13:09:26.684151
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()


# Generated at 2022-06-25 13:09:28.049601
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = GlobalCLIArgs()


# Generated at 2022-06-25 13:09:30.198232
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    str_0 = 'hf:[\`$v`'
    c_l_i_args_0 = _ABCSingleton(str_0)


# Generated at 2022-06-25 13:09:32.585341
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    c_l_i_args_0 = CLIArgs({})
    c_l_i_args_1 = CLIArgs({})
    c_l_i_args_2 = CLIArgs({})



# Generated at 2022-06-25 13:09:34.742082
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    try:
        test_case_0()
    except TypeError:
        pass


if __name__ == '__main__':
    test_CLIArgs()

# Generated at 2022-06-25 13:09:35.529620
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_case_0()

# Generated at 2022-06-25 13:09:39.214395
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    obj = _ABCSingleton()
    if not isinstance(obj, _ABCSingleton):
        raise AssertionError("Not a type of _ABCSingleton")
    if not isinstance(obj, Singleton):
        raise AssertionError("Not a type of Singleton")

# Generated at 2022-06-25 13:09:47.849972
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Test with a mutable object
    g_c_l_i_args_0 = GlobalCLIArgs({})
    # Test with an immutable object
    g_c_l_i_args_1 = GlobalCLIArgs(ImmutableDict({}))
    # Test with a mutable object
    g_c_l_i_args_2 = GlobalCLIArgs(tuple({}))
    # Test with a mutable object
    g_c_l_i_args_3 = GlobalCLIArgs(frozenset(tuple({})))
    # Test with a mutable object
    g_c_l_i_args_4 = GlobalCLIArgs(frozenset(ImmutableDict({})))
    # Test with a mutable object
    g_c_l_i_args_5 = GlobalCLI