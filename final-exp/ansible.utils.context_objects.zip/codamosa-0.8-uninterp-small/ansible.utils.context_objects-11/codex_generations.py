

# Generated at 2022-06-25 13:00:52.121962
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    gc_l_i_args = GlobalCLIArgs
    c_l_i_args = CLIArgs
    c_l_i_args = c_l_i_args({})
    gc_l_i_args = gc_l_i_args({})
    assert isinstance(gc_l_i_args, c_l_i_args) == True
    # The following is a failed assertion because the metaclass is not a direct subclass of the superclass.
    #assert issubclass(gc_l_i_args, c_l_i_args) == True



# Generated at 2022-06-25 13:00:55.457705
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    current = GlobalCLIArgs.instance()
    if current is None:
        current = GlobalCLIArgs(None)
    assert isinstance(current, GlobalCLIArgs)
    test_case_0()

if __name__ == '__main__':
    test_CLIArgs()

# Generated at 2022-06-25 13:00:59.837978
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    c_l_i_args_0 = GlobalCLIArgs()
    c_l_i_args_1 = GlobalCLIArgs()
    assert c_l_i_args_0 is c_l_i_args_1

# Generated at 2022-06-25 13:01:03.160500
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = GlobalCLIArgs({})
    global_c_l_i_args_1 = GlobalCLIArgs(global_c_l_i_args_0)


# Generated at 2022-06-25 13:01:04.770814
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({'a': 'a'}) == {'a': 'a'}


# Generated at 2022-06-25 13:01:11.947109
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    parser.add_argument('--bar', type=int, default=42)
    options = parser.parse_args([])
    c_l_i_args_0 = CLIArgs.from_options(options)
    c_l_i_args_1 = GlobalCLIArgs(c_l_i_args_0)
    c_l_i_args_2 = GlobalCLIArgs(c_l_i_args_0)
    exit_code_0 = c_l_i_args_0 == c_l_i_args_2
    exit_code_1 = c_l_i_args_1 == c_l_i_args_2

# Generated at 2022-06-25 13:01:12.821878
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    CLIArgs(None)


# Generated at 2022-06-25 13:01:22.016623
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Case 0: If a None object is passed into the constructor, the constructor should
    # return an empty set
    c_l_i_args_0 = None
    c_l_i_args_1 = CLIArgs(c_l_i_args_0)
    if len(c_l_i_args_1) != 0:
        raise Exception("Test case 0 failed\n")

    # Case 1: If a string is passed into the constructor, the constructor should
    # return an empty set
    c_l_i_args_0 = 'string'
    c_l_i_args_1 = CLIArgs(c_l_i_args_0)
    if len(c_l_i_args_1) != 0:
        raise Exception("Test case 1 failed\n")

    # Case 2: If an empty list is

# Generated at 2022-06-25 13:01:30.674828
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import collections
    import ansible.utils.collection_list
    # initialize
    global_c_l_i_args = GlobalCLIArgs()

    print("test_GlobalCLIArgs: Testing with the following arguments")
    print("global_c_l_i_args = GlobalCLIArgs()")
    print("results:")
    print("\tclass = {}".format(global_c_l_i_args.__class__))
    assert global_c_l_i_args.__class__ == GlobalCLIArgs
    print("\tIs an instance of GlobalCLIArgs = {}".format(isinstance(global_c_l_i_args, GlobalCLIArgs)))
    assert isinstance(global_c_l_i_args, GlobalCLIArgs)

# Generated at 2022-06-25 13:01:35.654460
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert isinstance(_ABCSingleton, type)
    assert issubclass(_ABCSingleton, Singleton)
    assert issubclass(_ABCSingleton, ABCMeta)


# Generated at 2022-06-25 13:01:48.176381
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs.__name__ == 'CLIArgs'
    # object.__init__ takes at most one argument
    with pytest.raises(TypeError) as excinfo:
        c_l_i_args_2 = CLIArgs()
    assert "object.__init__() takes no parameters" in str(excinfo.value)
    try:
        c_l_i_args_2 = CLIArgs({'a': 1, 'b': 2})
    except Exception as exc:
        print('ERROR: CLIArgs.__init__: exception: {}'.format(exc))
        assert False
    assert c_l_i_args_2['a'] == 1
    assert c_l_i_args_2['b'] == 2

# Generated at 2022-06-25 13:01:50.513838
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({})
    assert CLIArgs({'foo': 'bar'})



# Generated at 2022-06-25 13:01:52.167044
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_case_0()



# Generated at 2022-06-25 13:01:54.647050
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({"true":True, "false":False}) == {"true":True, "false":False}

    test_case_0()

# Generated at 2022-06-25 13:02:04.688990
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Test instantiation of class which is not a singleton already
    class ABCSingletonTest_1:
        @add_metaclass(_ABCSingleton)
        class ABCSingletonTest:
            pass
    assert not isinstance(ABCSingletonTest(), Singleton)
    assert not isinstance(ABCSingletonTest(), ABCMeta)
    assert isinstance(ABCSingletonTest(), ABCSingletonTest)

    # Test instantiation of class which is already a singleton
    class ABCSingletonTest_2(Singleton):
        @add_metaclass(_ABCSingleton)
        class ABCSingletonTest:
            pass
    assert isinstance(ABCSingletonTest(), Singleton)
    assert not isinstance(ABCSingletonTest(), ABCMeta)
    assert isinstance(ABCSingletonTest(), ABCSingletonTest)


# Generated at 2022-06-25 13:02:05.570908
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert 1 == 1


# Generated at 2022-06-25 13:02:09.995879
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    singleton_0 = _ABCSingleton()
    assert isinstance(singleton_0, _ABCSingleton)
    singleton_1 = _ABCSingleton()
    assert singleton_1 is singleton_0
    singleton_2 = _ABCSingleton()
    assert singleton_2 is singleton_1


# Generated at 2022-06-25 13:02:12.024966
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Make sure the singleton can be created
    class MySingleton(_ABCSingleton):
        pass
    MySingleton()


# Generated at 2022-06-25 13:02:21.824051
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    options = {}
    # Constructor should not raise any exception
    try:
        c_l_i_args_0 = CLIArgs(options)
    except Exception as e:
        assert(False)

    # Missing option should not raise any exception
    try:
        c_l_i_args_1 = c_l_i_args_0['verbosity']
    except Exception as e:
        assert(False)

    # Option should be None
    assert(c_l_i_args_1 is None)

    options['verbosity'] = 1
    c_l_i_args_0 = CLIArgs(options)
    c_l_i_args_1 = c_l_i_args_0['verbosity']
    assert(c_l_i_args_1 == 1)


# Generated at 2022-06-25 13:02:33.107670
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from copy import deepcopy
    test_dict = {'a': [1, 2, 3], 'b': {'d': 0, 'c': "abc"}, 'e': 'efg'}
    # Build a immutable dict
    c_l_i_args = CLIArgs(test_dict)
    assert isinstance(c_l_i_args, ImmutableDict)
    assert isinstance(c_l_i_args, Mapping)
    assert isinstance(c_l_i_args, Sequence)
    assert isinstance(c_l_i_args, Set)
    assert isinstance(c_l_i_args, Container)
    assert isinstance(c_l_i_args, Mapping)
    assert isinstance(c_l_i_args, Sequence)

# Generated at 2022-06-25 13:02:44.150503
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert Singleton
    assert _ABCSingleton
    assert issubclass(type, Singleton)
    assert issubclass(Singleton, _ABCSingleton)
    assert issubclass(type, _ABCSingleton)
    assert issubclass(_ABCSingleton, Singleton)
    assert issubclass(_ABCSingleton, type)
    assert isinstance(_ABCSingleton, type)
    assert isinstance(_ABCSingleton, Singleton)
    assert isinstance(_ABCSingleton, _ABCSingleton)
    # assert not issubclass(Singleton, type)  # Not by inheritance


# Generated at 2022-06-25 13:02:48.186875
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class FakeOptions:
        def __init__(self):
            self.skip = ['test']

    list_GlobalCLIArgs = GlobalCLIArgs.from_options(FakeOptions())
    assert(list_GlobalCLIArgs['skip'] == ['test'])

if __name__ == '__main__':
    test_case_0()
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:02:52.329414
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    globalcliargs_0 = None
    globalcliargs_1 = GlobalCLIArgs(globalcliargs_0)
    assert globalcliargs_1 == c_l_i_args_1



if __name__ == '__main__':
    # Unit Test
    test_case_0()
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:02:54.210472
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABCSingletonTest(metaclass=_ABCSingleton):
        pass

    class _ABCSingletonTest1(_ABCSingletonTest):
        pass


# Generated at 2022-06-25 13:02:57.056696
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    c_l_i_args_0 = GlobalCLIArgs(None)
    c_l_i_args_1 = GlobalCLIArgs(c_l_i_args_0)
    assert c_l_i_args_0 is c_l_i_args_1



# Generated at 2022-06-25 13:03:02.777747
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

        def __init__(self, _id):
            self._id = _id

        def __repr__(self):
            return 'A(id={!r})'.format(self._id)

    class B(object):
        __metaclass__ = Singleton

        def __init__(self, _id):
            self._id = _id

        def __repr__(self):
            return 'B(id={!r})'.format(self._id)

    # Test for class A
    a = A(0)
    b = A(1)
    assert(a is b)

    # Test for class B
    a = B(0)
    b = B(1)
    assert(a is b)



# Generated at 2022-06-25 13:03:04.201914
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    unittest.TestCase.assertEqual(test_case_0, "")


# Generated at 2022-06-25 13:03:10.368069
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    toplevel = {}
    toplevel = _make_immutable(toplevel)
    global_c_l_i_args = GlobalCLIArgs(toplevel)
    # This is just to keep mypy from complaining until we are smart enough to use is_container()
    # in the constructor and recursively compute the type of object passed in.
    assert isinstance(global_c_l_i_args, GlobalCLIArgs)
    return global_c_l_i_args

# Generated at 2022-06-25 13:03:14.477498
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    cli_args = {'a': [0, 1, 2], 'b': {0: 1, 1: 2}}
    cli_args_0 = GlobalCLIArgs(cli_args)
    cli_args_1 = GlobalCLIArgs(cli_args)
    assert cli_args_0 is cli_args_1

# Generated at 2022-06-25 13:03:18.710063
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = None
    global_c_l_i_args_1 = GlobalCLIArgs(global_c_l_i_args_0)
    assert global_c_l_i_args_1 is not None, "assert global_c_l_i_args_1"


# Locate extra modules needed for this module, and their tests

# Generated at 2022-06-25 13:03:26.950499
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys, inspect
    import ansible.module_utils.common.arguments
    from ansible.module_utils.common.arguments import option_helpers
    test_cli_args = GlobalCLIArgs.from_options(option_helpers.get_module_trace_opts())

if __name__ == '__main__':
    # test the object constructor for class GlobalCLIArgs
    test_GlobalCLIArgs()
    # test the object constructor for class GlobalCLIArgs
    test_case_0()

# Generated at 2022-06-25 13:03:34.340437
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Test creating multiple instances of GlobalCLIArgs throws an error"""
    c_l_i_args_0 = None
    c_l_i_args_1 = None
    c_l_i_args_0 = GlobalCLIArgs(c_l_i_args_0)
    try:
        c_l_i_args_1 = GlobalCLIArgs(c_l_i_args_1)
    except Exception as e:
        assert type(e) == type(AssertionError('Test'))
    else:
        assert 0, 'Should not get here'

# Unit test creator for class CLIArgs

# Generated at 2022-06-25 13:03:38.769172
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    ABCMeta.register(tuple)
    class _ABCSingletonChild(object):
        __metaclass__ = _ABCSingleton
        def __init__(self): pass
    _ABCSingletonChild()
    _ABCSingletonChild()
    _ABCSingletonChild()
    _ABCSingletonChild()



# Generated at 2022-06-25 13:03:41.912458
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestXXX(object):
        __metaclass__=_ABCSingleton

    class TestYYY(object,Singleton):
        __metaclass__=_ABCSingleton

    class TestZZZ(object,Singleton):
        __metaclass__=_ABCSingleton


# Generated at 2022-06-25 13:03:51.943334
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import SortedDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.formatters import boolean
    from ansible.module_utils.common.text.formatters import date_format
    from ansible.module_utils.common.text.formatters import human_to_bytes
    from ansible.module_utils.common.text.formatters import integer
    from ansible.module_utils.common.text.formatters import to_bytes
    from ansible.module_utils.common.text.formatters import to_float
    from ansible.module_utils.common.text.formatters import to_native
    from ansible.module_utils.common.text.formatters import to_path
   

# Generated at 2022-06-25 13:03:54.783487
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args = GlobalCLIArgs({})
    global_c_l_i_args.__init__({})
    global_c_l_i_args.from_options({})

# Generated at 2022-06-25 13:03:56.880199
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABCSingletonTest(object):
        __metaclass__ = _ABCSingleton

    # Assume there are no exceptions
    _ABCSingletonTest()



# Generated at 2022-06-25 13:03:59.968721
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = None
    global_c_l_i_args_1 = GlobalCLIArgs(global_c_l_i_args_0)


# Generated at 2022-06-25 13:04:06.690172
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    p_a_r_s_e_d_a_r_g_s = {'foo': {'bar': u'baz'}, 'answer': 42, 'list': [1, 2, 3], 'dict': {'foo': u'bar'}}
    g_c_l_i_args = GlobalCLIArgs(p_a_r_s_e_d_a_r_g_s)
    assert g_c_l_i_args == p_a_r_s_e_d_a_r_g_s
    GlobalCLIArgs.instance = None



# Generated at 2022-06-25 13:04:16.021900
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import argparse

    test_parser = argparse.ArgumentParser()
    test_parser.add_argument('--test-cli-args-0', default=False, type=bool)
    test_parser.add_argument('--test-cli-args-1', default='arbitrary string')
    test_parser.add_argument('--test-cli-args-2', default=['bar', 'baz', 42])
    test_parser.add_argument('--test-cli-args-3', default=['foo', 'bar', 'baz'], type=set)
    test_parser.add_argument('--test-cli-args-4', default=[42, 'foo', 'bar'], nargs='+', type=set)

# Generated at 2022-06-25 13:04:22.506676
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert isinstance(_ABCSingleton, type)
    assert issubclass(_ABCSingleton, Singleton)
    assert issubclass(_ABCSingleton, ABCMeta)


# Generated at 2022-06-25 13:04:27.641626
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    c_l_i_args_0 = GlobalCLIArgs(c_l_i_args_0)

if __name__ == '__main__':
    # Unit test for constructor of class CLIArgs
    # test_case_0()
    # Unit test for constructor of class GlobalCLIArgs
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:04:28.948292
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args = GlobalCLIArgs()



# Generated at 2022-06-25 13:04:30.636579
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert isinstance(_ABCSingleton('TestClass', (object,), {}), type)


# Generated at 2022-06-25 13:04:31.601958
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    obj = _ABCSingleton()


# Generated at 2022-06-25 13:04:34.325923
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, ABCMeta)
    assert issubclass(_ABCSingleton, Singleton)
    assert issubclass(_ABCSingleton, type)


# Generated at 2022-06-25 13:04:35.277834
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_case_0()

# Generated at 2022-06-25 13:04:38.391067
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict = {'a': 1, 'b': 2}
    c_l_i_args_0 = CLIArgs(dict)
    if (len(c_l_i_args_0.keys()) != 2):
        print('Error!')


# Generated at 2022-06-25 13:04:47.143286
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-25 13:04:51.411997
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class _CLIArgs0(GlobalCLIArgs):
        pass

    _c_l_i_args_0 = GlobalCLIArgs({})
    # assert class of _c_l_i_args_0 is GlobalCLIArgs
    assert _c_l_i_args_0.__class__ is GlobalCLIArgs


# Generated at 2022-06-25 13:05:09.191896
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args = GlobalCLIArgs({u'foo': u'bar'})
    c_l_i_args = CLIArgs({u'foo': u'bar'})
    assert (global_c_l_i_args == c_l_i_args)
    global_c_l_i_args_0 = GlobalCLIArgs({u'foo': u'bar', u'is_play_context': True})
    assert (global_c_l_i_args_0[u'is_play_context'] == True)
    global_c_l_i_args_1 = GlobalCLIArgs({u'foo': u'bar', u'start_at_task': u'bar'})

# Generated at 2022-06-25 13:05:14.999165
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ABCSingletonClass(object):
        __metaclass__ = _ABCSingleton

    abc_singleton_0 = ABCSingletonClass()
    abc_singleton_1 = ABCSingletonClass()
    assert abc_singleton_0 is abc_singleton_1



# Generated at 2022-06-25 13:05:15.985388
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    instance = _ABCSingleton()



# Generated at 2022-06-25 13:05:23.962409
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.cli import CLI
    from ansible.utils.vars import combine_vars
    from ansible.parsing.splitter import parse_kv, split_args
    from ansible.utils.listify import listify_lookup_plugin_terms

# Generated at 2022-06-25 13:05:25.430512
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    c_l_i_args_0 = None
    g_c_l_i_args = GlobalCLIArgs(c_l_i_args_0)



# Generated at 2022-06-25 13:05:27.583165
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # test invalid input case
    with pytest.raises(TypeError):
        # c_l_i_args_0 is invalid
        c_l_i_args_0 = None
        c_l_i_args_1 = GlobalCLIArgs(c_l_i_args_0)



# Generated at 2022-06-25 13:05:32.277915
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Struct:
        pass

    options = Struct()
    options.ask_vault_pass = True
    options.become_ask_pass = True
    options.ask_sudo_pass = True
    options.ask_su_pass = True
    options.become_user = 'foo'
    options.verbosity = 'a verbosity'
    options.inventory = 'an inventory'
    options.listhosts = 'a listhosts'
    options.listtasks = 'a listtasks'
    options.listtags = 'a listtags'
    options.syntax = 'a syntax'
    options.module_path = 'a module path'
    options.forks = 'a forks'
    options.timeout = 'a timeout'
    options.remote_user = 'a remote user'

# Generated at 2022-06-25 13:05:35.514372
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    c_l_i_args_0 = None
    c_l_i_args_1 = CLIArgs(c_l_i_args_0)
    print(c_l_i_args_0)
    print(c_l_i_args_1)

# Generated at 2022-06-25 13:05:40.245469
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    c_l_i_args_2 = None
    # Match the signature of the __init__ function in GlobalCLIArgs
    g_c_l_i_args_0 = GlobalCLIArgs(c_l_i_args_2)
    # You can't instantiate a GlobalCLIArgs object a second time
    # g_c_l_i_args_1 = GlobalCLIArgs(c_l_i_args_2)


# Generated at 2022-06-25 13:05:49.087905
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingletonClass(object):
        __metaclass__ = _ABCSingleton
        """You are tested"""
        pass
    class TestSingletonClass2(TestSingletonClass):
        """You are also tested"""
        pass
    class TestSingletonClass3(TestSingletonClass):
        """You are also also tested"""
        pass
    # a should be the only instance of TestSingletonClass, b should be the only instance of
    # TestSingletonClass2, etc.
    a = TestSingletonClass()
    b = TestSingletonClass2()
    c = TestSingletonClass3()
    a1 = TestSingletonClass()
    b1 = TestSingletonClass2()
    c1 = TestSingletonClass3()
    assert id(a) == id(a1)

# Generated at 2022-06-25 13:06:08.158492
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # TODO: Create tests
    pass

# Generated at 2022-06-25 13:06:13.482765
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_args = {'a': 'b', 'c': [1, 2, 3], 'd': {'a': 'b', 'c': [1, 2, 3]}}
    as_immutable = {'a': 'b', 'c': (1, 2, 3), 'd': ImmutableDict({'a': 'b', 'c': (1, 2, 3)})}
    c_l_i_args_0 = CLIArgs(test_args)
    assert c_l_i_args_0 == as_immutable



# Generated at 2022-06-25 13:06:14.974230
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs(c_l_i_args_0)

# Generated at 2022-06-25 13:06:24.796654
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    c_l_i_args_1 = CLIArgs({'ansible_ssh_host': '127.0.0.1', 'ansible_ssh_pass': 'foobar'})
    assert c_l_i_args_1['ansible_ssh_host'] == '127.0.0.1'
    c_l_i_args_2 = CLIArgs({'ansible_ssh_host': ['127.0.0.1', '127.0.0.2'], 'ansible_ssh_pass': 'foobar'})
    assert c_l_i_args_2['ansible_ssh_host'][1] == '127.0.0.2'

# Generated at 2022-06-25 13:06:33.659721
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global c_l_i_args_0, c_l_i_args_1, c_l_i_args_2, c_l_i_args_3
    c_l_i_args_0 = GlobalCLIArgs(vars(options))
    c_l_i_args_1 = GlobalCLIArgs(vars(options))
    c_l_i_args_2 = GlobalCLIArgs(vars(options))
    c_l_i_args_3 = GlobalCLIArgs(vars(options))
    assert c_l_i_args_0 is c_l_i_args_1
    assert c_l_i_args_1 is c_l_i_args_2
    assert c_l_i_args_2 is c_l_i_args_3

# Unit

# Generated at 2022-06-25 13:06:34.246840
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    instance = None
    instance = _ABCSingleton(instance)


# Generated at 2022-06-25 13:06:35.585192
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
    a = TestClass()
    assert a is TestClass()


# Generated at 2022-06-25 13:06:38.234957
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    try:
        c_l_i_args_0 = None
        c_l_i_args_1 = CLIArgs(c_l_i_args_0)
        assert (c_l_i_args_1 == {}) is True
    except Exception as e:
        print(e)


# Generated at 2022-06-25 13:06:43.333214
# Unit test for constructor of class CLIArgs
def test_CLIArgs():  
    c_l_i_args_0 = {'key1':'value1', 'key2':'value2', 'key3':'value3'}
    c_l_i_args_0_obj = CLIArgs(c_l_i_args_0)
    #assert(c_l_i_args_0 == c_l_i_args_0_obj.data and isinstance(c_l_i_args_0_obj, ImmutableDict))
    assert(c_l_i_args_0 == c_l_i_args_0_obj.data)



# Generated at 2022-06-25 13:06:45.426900
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Tmp(metaclass=_ABCSingleton):
        def __init__(self, arg):
            self.arg = arg

    t1 = Tmp(1)
    t2 = Tmp(2)
    assert t1 == t2



# Generated at 2022-06-25 13:07:32.557591
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # To prove we cannot instantiate an instance of _ABCSingleton
    # we cannot assign a,b,c to _ABCSingleton, but we can assign
    # a,b,c to two child class of _ABCSingleton by using isinstance
    a = _ABCSingleton()
    b = _ABCSingleton()
    c = _ABCSingleton()
    if isinstance(a, _ABCSingleton) and isinstance(b, _ABCSingleton) and isinstance(c, _ABCSingleton):
        raise RuntimeError("The _ABCSingleton Class is not singleton!")
    else:
        pass


# Generated at 2022-06-25 13:07:33.746003
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    pass


# Generated at 2022-06-25 13:07:35.345915
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    obj = _ABCSingleton
    assert (obj == obj)
    assert (obj() == obj())


# Generated at 2022-06-25 13:07:36.840559
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    print("\nTest use of class _ABCSingleton (does nothing) ...")
    return


# Generated at 2022-06-25 13:07:40.254741
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        class TestABCSingleton(metaclass=_ABCSingleton):
            pass
    except TypeError as e:
        assert False, "Failed to create a class that inherits _ABCSingleton."


# Unit tests for the constructor and from_options class methods of class CLIArgs

# Generated at 2022-06-25 13:07:41.523221
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_case_0()
    test_CLIArgs_exception()


# Generated at 2022-06-25 13:07:48.665090
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_data = {
        'action_plugins': 'acp',
        'connection_plugins': 'cp',
        'lookup_plugins': 'lp',
        'module_utils': 'mu',
        'callback_plugins': 'cbp',
        'filter_plugins': 'fp',
        'roles_path': 'rp',
        'library': 'lib',
        'module_path': 'mp',
        'factor': 'fact',
    }
    c_l_i_args = GlobalCLIArgs(test_data)
    for key, value in test_data.items():
        assert c_l_i_args[key] == value



# Generated at 2022-06-25 13:07:50.293034
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABCSingletonTest(object):
        __metaclass__ = _ABCSingleton
        pass
    _ABCSingletonTest()


# Generated at 2022-06-25 13:07:52.228890
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    c_l_i_args_0 = None
    global_cli_args_0 = GlobalCLIArgs(c_l_i_args_0)


# Generated at 2022-06-25 13:07:58.715085
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    testdata = {'a': 'b', 'c': [1, 2, 3], 'd': ['a', 'b', 'c']}
    args = CLIArgs(testdata)
    assert args['a'] == 'b'
    assert args['c'][0] == 1
    assert args['d'][2] == 'c'

    # Mutable items should be converted to their immutable equivalents
    testdata = {'a': 'b', 'c': [1, 2, 3], 'd': ['a', 'b', 'c'],
                'e': {'f': 1, 'g': 2}, 'h': {'i': 'j', 'k': 'l'}}
    args = CLIArgs(testdata)
    assert isinstance(args['c'], tuple)
    assert isinstance(args['d'], tuple)


# Generated at 2022-06-25 13:09:30.884412
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import (
        ImmutableDict,
        SimpleImmutableDict,
        is_immutable_mapping
    )
    myargs = dict(
      ansible_module_args={'a': 1, 'b': 2},
      ansible_module_name='mymodule',
      ansible_module_path=('/usr/local/lib/python2.7/site-packages/ansible/module_utils/' +
                           'basic.py'),
      ansible_playbook_python='/usr/bin/python',
      ansible_python_interpreter='/usr/bin/python',
      ansible_verbosity=0
    )
    g = GlobalCLIArgs.from_options(myargs)
    # Sanity check - test that from_options()

# Generated at 2022-06-25 13:09:40.091612
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    print("test_GlobalCLIArgs START")
    test_args = [
        {'module_path': 'path1', 'forks': 10},
        {'module_path': 'path2', 'forks': 10},
        {'module_path': 'path3', 'forks': 10},
        {'module_path': 'path4', 'forks': 10},
        {'module_path': 'path5', 'forks': 10}
    ]

    for args in test_args:
        print("test_GlobalCLIArgs: args: " + str(list(args.items())))
        cli_args = GlobalCLIArgs(args)
        print("test_GlobalCLIArgs: cli_args: " + str(list(cli_args.items())))
    print("test_GlobalCLIArgs END")

# Generated at 2022-06-25 13:09:45.241824
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    pass

"""
    c_l_i_args_0 = GlobalCLIArgs()
    c_l_i_args_1 = GlobalCLIArgs()
    c_l_i_args_2 = GlobalCLIArgs()
    assert c_l_i_args_0 is c_l_i_args_1
    assert c_l_i_args_1 is c_l_i_args_2
"""



# Generated at 2022-06-25 13:09:52.393163
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    try:
        c_l_i_args_0 = {}
        c_l_i_args_0['foo'] = {'a': 1, 'b': 2, 'c': 3}
        c_l_i_args_0['bar'] = {'a': 4, 'b': 5, 'c': 6}
        c_l_i_args_0['baz'] = {'a': 7, 'b': 8, 'c': 9}
        c_l_i_args_1 = CLIArgs(c_l_i_args_0)
        c_l_i_args_1['baz'] = {'a': 10, 'b': 11, 'c': 12}
    except Exception as e:
        print("test_CLIArgs failed: " + str(e))
        return False

    return True

# Generated at 2022-06-25 13:09:59.760990
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    try:
        c_l_i_args_0 = {}
        c_l_i_args_1 = CLIArgs(c_l_i_args_0)
        c_l_i_args_2 = CLIArgs(c_l_i_args_1)
        assert(c_l_i_args_0 == {})
        assert(c_l_i_args_1 == {})
        assert(c_l_i_args_2 == {})
    except TypeError:
        print('test_CLIArgs: constructor test failed')
    else:
        print('test_CLIArgs: constructor test passed')


# Generated at 2022-06-25 13:10:05.933376
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = GlobalCLIArgs()
    assert global_c_l_i_args_0.__class__.__name__ == 'GlobalCLIArgs'
    assert global_c_l_i_args_0.__doc__ == '\n    Globally hold a parsed copy of cli arguments.\n\n    Only one of these exist per program as it is for global context\n    '
    assert isinstance(global_c_l_i_args_0, CLIArgs)

# Generated at 2022-06-25 13:10:08.601269
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    c_l_i_args_0 = None
    c_l_i_args_1 = GlobalCLIArgs(c_l_i_args_0)

# Unit tests for from_options() class method
# of class CLIArgs

# Generated at 2022-06-25 13:10:10.402167
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args_0 = CLIArgs(global_cli_args_0)

# Generated at 2022-06-25 13:10:12.329635
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    data_map = {'a': 1, 'b': 2, 'c': 'hello'}
    class_instance = CLIArgs(data_map)
    assert class_instance == data_map

# Generated at 2022-06-25 13:10:14.427742
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    abc_metaclass = ABCMeta('ABC', (object,), {})
    class _ABCSingleton0(Singleton, abc_metaclass):
        pass
    class _ABCSingleton1(Singleton, abc_metaclass):
        pass

