

# Generated at 2022-06-25 13:00:46.188573
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    cls = _ABCSingleton()
    assert cls


# Generated at 2022-06-25 13:00:47.110225
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    _ABCSingleton()


# Generated at 2022-06-25 13:00:49.882692
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Create a _ABCSingleton object
    a_b_c_singleton = _ABCSingleton()
    # Call the method __init__
    test_case_0()



# Generated at 2022-06-25 13:00:51.726199
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    _abc_singleton_0 = _ABCSingleton()
    assert _abc_singleton_0


# Generated at 2022-06-25 13:00:53.416142
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = True
    c_l_i_args_0 = CLIArgs(bool_0)



# Generated at 2022-06-25 13:00:59.330953
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_mapping = {1: 1, 2: 2, '3': 3, '4': 4}
    # Make sure we can make an object
    c_l_i_args_1 = CLIArgs(test_mapping)
    # Make sure it's immutable
    try:
        c_l_i_args_1[1] = -1
    except TypeError:
        pass
    else:
        raise Exception('cls_0 is not immutable')
    # Try to make sure it is immutable recursively
    test_mapping_0 = {1: 1, 2: 2, '3': 3, '4': 4, 5: {1: 1, 2: 2, '3': 3, '4': 4}}
    c_l_i_args_1 = CLIArgs(test_mapping_0)

# Generated at 2022-06-25 13:01:06.571688
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    GlobalCLIArgs class

    Args:
        None

    Returns:
        None

    Raises:
        None
    """
    # Test CLIArgs object
    bool_0 = True
    c_l_i_args_0 = GlobalCLIArgs(bool_0)
    c_l_i_args_0 = GlobalCLIArgs(False)
    c_l_i_args_0 = CLIArgs(bool_0)
    c_l_i_args_0 = CLIArgs(False)

if __name__ == '__main__':
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:01:08.420623
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = True
    c_l_i_args_0 = CLIArgs(bool_0)


# Generated at 2022-06-25 13:01:09.857617
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    _abc_singleton_0 = _ABCSingleton()


# Generated at 2022-06-25 13:01:13.471452
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils.common.collections import SingletonMeta
    from ansible.utils.singleton import Singleton
    test__ABCSingleton_0 = _ABCSingleton(str('test __ABCSingleton_0'),
                                         (Singleton, SingletonMeta),
                                         dict())


# Generated at 2022-06-25 13:01:23.259550
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    #test_case 0: check if the constructor works as intended
    cli_args = GlobalCLIArgs({'foo':'bar', 'baz': 'trash'})
    assert cli_args['foo'] == 'bar'
    assert cli_args['baz'] == 'trash'

    #test_case 1: check if the constructor works as intended with nested dictionaries.
    cli_args = GlobalCLIArgs({'foo':'bar', 'baz': {'first': "trash", "second": "trash"}})
    assert cli_args['foo'] == 'bar'
    assert cli_args['baz']['second'] == 'trash'

# Generated at 2022-06-25 13:01:25.398277
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        # Can't create more than one instance of _ABCSingleton
        a_b_c_singleton_1 = _ABCSingleton()
        assert False
    except TypeError:
        pass



# Generated at 2022-06-25 13:01:33.785239
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import MutableMapping, MutableSequence, MutableSet
    from ansible.module_utils.common._collections_compat import Mapping, Sequence, Set

    name_0 = '11'
    mapping_0 = {
        'foo': 'bar',
        ('baz',): ('quux',),
        'blah': {'a': {'b': ['c', 'd', 'e']}},
        'mutable': MutableMapping(),
        'mset': MutableSet(),
        'mseq': MutableSequence(),
        'lmset': [MutableSet()],
        'lmseq': [MutableSequence()],
    }
    mapping_0['mutable']['mapping'] = name_0

# Generated at 2022-06-25 13:01:36.684757
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs.from_options(dict(a=1, b=2, c=3))
    assert args['a'] == 1
    assert args['b'] == 2
    assert args['c'] == 3

    args1 = GlobalCLIArgs.from_options(dict(a=1, b=2, c=3))
    assert id(args) == id(args1)


# Generated at 2022-06-25 13:01:46.932716
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-25 13:01:51.753177
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = GlobalCLIArgs({'a': 1})
    assert a['a'] == 1
    b = GlobalCLIArgs({'a': 1, 'b': 2})
    assert b['a'] == 1
    assert b['b'] == 2
    assert a['a'] == 1


# Generated at 2022-06-25 13:01:57.013914
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Create a copy of class _ABCSingleton
    _abc_singleton_0 = _ABCSingleton()

    try:
        assert issubclass(_abc_singleton_0, ABCMeta) is True
        assert issubclass(_abc_singleton_0, Singleton) is True
    except AssertionError:
        raise AssertionError(_abc_singleton_0)



# Generated at 2022-06-25 13:01:58.215966
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()

# Generated at 2022-06-25 13:02:07.965102
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test for the exception when passing a non container type
    try:
        a = CLIArgs(5)
    except TypeError:
        pass
    # Test for the exception when passing a non container type
    try:
        a = CLIArgs('five')
    except TypeError:
        pass
    # Test for the exception when passing a mutable list
    try:
        a = CLIArgs(['mutable', 'list'])
    except TypeError:
        pass
    # Test for the exception when passing a mutable set
    try:
        a = CLIArgs({'mutable', 'set'})
    except TypeError:
        pass
    # Test for the exception when passing a mutable dict

# Generated at 2022-06-25 13:02:10.046116
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    print(GlobalCLIArgs())


# Create GlobalCLIArgs instance as soon as this module is imported and register shutdown atexit
GlobalCLIArgs()

# Generated at 2022-06-25 13:02:14.469333
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()



# Generated at 2022-06-25 13:02:17.894487
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = ImmutableDict({'a': 1, 'b': 2})
    global_cli_args = GlobalCLIArgs(args)
    assert global_cli_args['a'] == 1
    assert global_cli_args['b'] == 2


# Generated at 2022-06-25 13:02:19.936626
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({"a": "b", "c": "d"}) == {"a": "b", "c": "d"}

# Generated at 2022-06-25 13:02:31.103206
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-25 13:02:35.769392
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    print("Constructor")
    obj = GlobalCLIArgs({'debug': True})
    print(obj.debug)
    try:
        obj.debug = False
    except AttributeError:
        print('Object is immutable')

if __name__ == '__main__':
    test_case_0()
    print("\n")
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:02:40.803539
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    a_b_c_singleton_0 = _ABCSingleton()
    a_b_c_singleton_1 = _ABCSingleton()
    assert a_b_c_singleton_0 == a_b_c_singleton_1


# Generated at 2022-06-25 13:02:47.893323
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs({'a': 1, 'b': {'c': 2}, 'd': [1, 2, 3]})
    assert(isinstance(cli_args, ImmutableDict))
    assert(isinstance(cli_args, ImmutableDict))
    assert(isinstance(cli_args, Mapping))
    assert(isinstance(cli_args, Set))
    assert(isinstance(cli_args, Mapping))
    assert(isinstance(cli_args['b'], ImmutableDict))
    assert(isinstance(cli_args['d'], tuple))



# Generated at 2022-06-25 13:02:50.490659
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    a = {'one': 1, 'two': 2, 'three': [1, 2, 3], 'four': {'one': 1, 'two': 2}}
    b = CLIArgs(a)
    assert b == a

# Test _make_immutable function

# Generated at 2022-06-25 13:02:53.910904
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    a = _ABCSingleton()
    b = _ABCSingleton()
    assert a is b
    assert a == b
    # Constructor doesn't take arguments
    try:
        a_b_c_singleton_1 = _ABCSingleton(1)
    except TypeError:
        assert True


# Generated at 2022-06-25 13:02:56.301669
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs(): 
    global_CLIArgs = GlobalCLIArgs()
    assert(isinstance(global_CLIArgs, GlobalCLIArgs))
    assert(global_CLIArgs is GlobalCLIArgs())

# Generated at 2022-06-25 13:03:07.660683
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        test_case_0()
    except TypeError as e:
        raise AssertionError("Failed to instantiate object of type _ABCSingleton") from e


# Generated at 2022-06-25 13:03:10.231333
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args_dict = dict(test_arg=1)
    args_test = CLIArgs(args_dict)
    assert isinstance(args_test, CLIArgs)


# Generated at 2022-06-25 13:03:12.444277
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    a = _ABCSingleton()
    b = _ABCSingleton()
    c = _ABCSingleton()
    assert(a is b)
    assert(a is c)

# Generated at 2022-06-25 13:03:13.918675
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a_b_c_singleton_1 = _ABCSingleton()

# Generated at 2022-06-25 13:03:17.217520
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    a_b_c_singleton_0 = _ABCSingleton()
    a_b_c_singleton_1 = _ABCSingleton()
    assert a_b_c_singleton_0 is a_b_c_singleton_1 is _ABCSingleton()


# Generated at 2022-06-25 13:03:20.068978
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    imm_dict = {}
    # Constructor of GlobalCLIArgs
    global_cli_args = GlobalCLIArgs(imm_dict)
    assert isinstance(global_cli_args, GlobalCLIArgs)
    assert isinstance(global_cli_args, CLIArgs)
    assert isinstance(global_cli_args, ImmutableDict)


# Generated at 2022-06-25 13:03:24.109670
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs({'option_0': "test_0", 'option_1': "test_1"})
    assert global_cli_args['option_0'] == "test_0"
    assert global_cli_args['option_1'] == "test_1"

# Generated at 2022-06-25 13:03:27.433907
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    try:
        cliarg = GlobalCLIArgs()
    except TypeError as e:
        assert(str(e) == 'Can\'t instantiate abstract class GlobalCLIArgs with abstract methods __init__')
    else:
        assert(False)

# Generated at 2022-06-25 13:03:31.274470
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'arg1': 'value1', 'arg2': 'value2'}
    cli_args = CLIArgs(mapping)
    assert (cli_args.get('arg1') == 'value1')
    assert (cli_args.get('arg2') == 'value2')



# Generated at 2022-06-25 13:03:33.357502
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    a_b_c_singleton_0 = test_case_0()
    return a_b_c_singleton_0



# Generated at 2022-06-25 13:03:48.664506
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    a_b_c_singleton_1 = _ABCSingleton()
    a_b_c_singleton_2 = _ABCSingleton()

    assert(a_b_c_singleton_1 is a_b_c_singleton_2)


# Generated at 2022-06-25 13:03:56.118506
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a_b_c_singleton_0 = GlobalCLIArgs()
    a_b_c_singleton_1 = GlobalCLIArgs()
    assert a_b_c_singleton_0 == a_b_c_singleton_1
    assert a_b_c_singleton_0 is a_b_c_singleton_1

    a_b_c_singleton_1.__init__({'ansible_debug': False})
    assert a_b_c_singleton_0 != a_b_c_singleton_1
    assert a_b_c_singleton_0 is not a_b_c_singleton_1

# Generated at 2022-06-25 13:04:01.252582
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {
        'a': 1,
        'b': 'b',
        'c': {
            'd': [1, 2, 3],
            'e': "hello world"
        }
    }
    cli_args = CLIArgs.from_options(mapping)

    assert isinstance(cli_args, CLIArgs)
    assert cli_args.a == 1
    assert cli_args.b == 'b'
    assert cli_args.c.d == (1, 2, 3)
    assert cli_args.c.e == "hello world"


# Generated at 2022-06-25 13:04:04.837480
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    a_b_c_singleton_0 = _ABCSingleton()
    a_b_c_singleton_1 = _ABCSingleton()
    assert id(a_b_c_singleton_0) == id(a_b_c_singleton_1)


# Generated at 2022-06-25 13:04:07.451535
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {"a": {"b": {"c": 1}}}
    cli_args = CLIArgs(mapping)
    assert(cli_args["a"]["b"]["c"] == 1)


# Generated at 2022-06-25 13:04:10.225677
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    x = ImmutableDict({'a': 'b', 'c': 2})
    b = CLIArgs(x)
    assert b == {'a': u'b', 'c': 2}


# Generated at 2022-06-25 13:04:19.483456
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # test constructor with a normal dict.
    cli_args = CLIArgs({"arg1": "value1", "arg2": "value2"})
    assert cli_args["arg1"] == "value1"
    assert cli_args["arg2"] == "value2"

    # test constructor with a list of tuple
    cli_args = CLIArgs([("arg1", "value1"), ("arg2", "value2")])
    assert cli_args["arg1"] == "value1"
    assert cli_args["arg2"] == "value2"

    # test constructor with an empty list
    cli_args = CLIArgs([])
    assert len(cli_args) == 0

    # test constructor with an empty dict
    cli_args = CLIArgs({})
    assert len(cli_args) == 0

# Generated at 2022-06-25 13:04:24.393568
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {}
    mapping['global'] = {}
    mapping['global']['root'] = 'temp'
    mapping['global']['verbosity'] = 'verbosity'
    mapping['command'] = {}
    mapping['command']['module_path'] = 'module_path'
    expected_result = {'global': {'root': 'temp', 'verbosity': 'verbosity'}, 'command': {'module_path': 'module_path'}}
    result = CLIArgs(mapping)
    assert result == expected_result


# Generated at 2022-06-25 13:04:34.600374
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs(dict(a=1, b=2, c=3))
    assert args['a'] == 1
    assert args['b'] == 2
    assert args['c'] == 3

    mutable_args = {'a': [1, 2], 'b': {'c': 3}, 'd': set([4, 5])}
    args = CLIArgs(mutable_args)
    assert args['a'] == (1, 2)
    assert args['b'] == ImmutableDict({'c': 3})
    assert args['d'] == frozenset([4, 5])

    assert args['a'] != [1, 2]
    assert args['b'] != {'c': 3}
    assert args['d'] != set([4, 5])



# Generated at 2022-06-25 13:04:36.364210
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    temp=CLIArgs({"a":"b"})
    assert temp != None
    assert temp.a == "b"

# Generated at 2022-06-25 13:04:50.532875
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    test the constructor if class GlobalCLIArgs
    """
    g_cli_args = GlobalCLIArgs.instance()
    print(g_cli_args)



# Generated at 2022-06-25 13:04:54.437489
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    a_b_c_singleton_1 = _ABCSingleton()
    a_b_c_singleton_2 = _ABCSingleton()
    assert a_b_c_singleton_1 is a_b_c_singleton_2



# Generated at 2022-06-25 13:04:57.364353
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert isinstance(GlobalCLIArgs.instance(), GlobalCLIArgs)

if __name__ == '__main__':
    test_case_0()
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:05:07.718038
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Instantiate object of class GlobalCLIArgs
    # Try to instantiate object again
    # It should be the same object
    a0 = GlobalCLIArgs()

    import weakref
    ref0 = weakref.ref(a0)
    ref1 = weakref.ref(GlobalCLIArgs())

    assert ref0 == ref1

    # A new container with cli args should be immutatable
    # A new container should be empty
    a = GlobalCLIArgs()
    assert a == ImmutableDict()

    # A loaded container should be non-empty and an ImmutableDict
    a.load_args({'a': 'b'})
    assert a == ImmutableDict({'a': 'b'})

    # A loaded container should not allow changes to it
    # However, it should remain unchanged
    a.load_

# Generated at 2022-06-25 13:05:11.984513
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a_b_c_dict = {"a": 1, "b": 2, "c": 3}
    a_b_c_instance = GlobalCLIArgs(a_b_c_dict)
    assert a_b_c_instance.get("a") == 1
    assert GlobalCLIArgs(a_b_c_dict).get("b") == 2


# This is a unit test for CLIArgs

# Generated at 2022-06-25 13:05:15.814860
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Set up
    cmd_line_options = {}

    # Exercise
    cmd_line_args = GlobalCLIArgs.from_options(cmd_line_options)

    # Verify
    assert cmd_line_args.toplevel == cmd_line_options



# Generated at 2022-06-25 13:05:18.921276
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs(ImmutableDict({'verbosity': 0, 'debug': 0}))
    assert global_cli_args['verbosity'] == 0
    assert global_cli_args['debug'] == 0



# Generated at 2022-06-25 13:05:21.003402
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    sample_dict = {'key1': 'value1', 'key2': 'value2', 'key3': 'value3'}
    GlobalCLIArgs(sample_dict)

# Generated at 2022-06-25 13:05:23.131995
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        a_b_c_singleton_0 = _ABCSingleton()
    except Exception as e:
        print(e)
        assert False
    else:
        assert True



# Generated at 2022-06-25 13:05:31.088359
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-25 13:05:46.848195
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, Singleton)
    assert issubclass(_ABCSingleton, ABCMeta)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 13:05:55.566223
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    toplevel = {
        "var": "1",
        "k": {
            "var": 2,
            "k": [3]
        },
        "k2": [
            {"k": 4},
            [5]
        ]
    }
    immutable_toplevel = _make_immutable(toplevel)
    cli_args = CLIArgs(immutable_toplevel)
    assert cli_args == immutable_toplevel
    try:
        cli_args["var"] = 5
    except TypeError:
        assert True
    else:
        assert False
    assert cli_args["var"] == "1"
    try:
        cli_args["k"]["var"] = 6
    except TypeError:
        assert True
    else:
        assert False
    assert cl

# Generated at 2022-06-25 13:06:00.604457
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = GlobalCLIArgs({'name': 'bob'})
    assert a['name'] == 'bob'

    a['name'] = 'tom'
    assert a['name'] == 'bob'



# Generated at 2022-06-25 13:06:04.826654
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    a_b_c_singleton_0 = _ABCSingleton()
    a_b_c_singleton_1 = _ABCSingleton()
    assert a_b_c_singleton_0 is a_b_c_singleton_1



# Generated at 2022-06-25 13:06:05.713556
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()



# Generated at 2022-06-25 13:06:09.131313
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    cli_args = {'one': 1, 'two': 2, 'three': 3}
    immutable_dict = GlobalCLIArgs.from_options(cli_args)
    assert isinstance(immutable_dict, GlobalCLIArgs)
    assert immutable_dict == cli_args

# Generated at 2022-06-25 13:06:14.270927
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # test case: _mapping is empty and it should return an empty dict
    assert isinstance(CLIArgs.from_options({}), dict)
    assert len(CLIArgs.from_options({})) == 0

    # test case: _mapping has value and it should return dict
    assert isinstance(CLIArgs.from_options({'foo': 'bar'}), dict)
    assert len(CLIArgs.from_options({'foo': 'bar'})) == 1
    assert CLIArgs.from_options({'foo': 'bar'}).get('foo') == 'bar'

# Generated at 2022-06-25 13:06:20.281638
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({"a": 1, "b": 2}).a == 1
    assert CLIArgs({"a": 1, "b": 2}).b == 2
    assert "a" in CLIArgs({"a": 1, "b": 2})
    assert "b" in CLIArgs({"a": 1, "b": 2})
    assert "c" not in CLIArgs({"a": 1, "b": 2})
    assert len(CLIArgs({"a": 1, "b": 2})) == 2


# Generated at 2022-06-25 13:06:22.915449
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert _ABCSingleton('_ABCSingleton') == _ABCSingleton('_ABCSingleton')
    assert _ABCSingleton('_ABCSingleton') is _ABCSingleton('_ABCSingleton')


# Generated at 2022-06-25 13:06:25.256496
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_case_0()
    test_GlobalCLIArgs()
    assert True

# Generated at 2022-06-25 13:06:55.371630
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    a = CLIArgs({'a':1,'b':2,'c':3})
    assert a ['a'] == 1
    assert a ['b'] == 2
    assert a ['c'] == 3


# Generated at 2022-06-25 13:07:05.150607
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    try:
        from ansible.module_utils.common.collections import ImmutableDict
    except ImportError:
        from collections import ImmutableDict
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.utils.context_objects import _make_immutable
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.utils.context_objects import CLIArgs

    # Check that CLIArgs is a subclass of ImmutableDict
    assert issubclass(CLIArgs, ImmutableDict)

    # Check that CLIArgs is a subclass of GlobalCLIArgs
    assert issubclass(CLIArgs, GlobalCLIArgs)

    # Check that CLIArgs is a subclass of Mapping
    assert issubclass(CLIArgs, Mapping)

    # Check that _

# Generated at 2022-06-25 13:07:06.318926
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert isinstance(_ABCSingleton(), _ABCSingleton)



# Generated at 2022-06-25 13:07:13.381422
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.display import Display
    display = Display()
    display.display("test_CLIArgs")

    # TODO - do we need to test instances that are not constructed from
    # TODO - from_options?
    # TODO - Do we need to test all the possible combinations of types
    # TODO - we might get passed in?
    # TODO - How should we also test that everything is indeed immutable?

    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.connection import ConnectionLoader
    from ansible.plugins.loader import connection_loader, filter_loader
    from ansible.utils.vars import combine_vars
    from ansible.vars import VariableManager
    variable_manager = VariableManager()

# Generated at 2022-06-25 13:07:15.248712
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()
    obj = _ABCSingleton()
    assert isinstance(obj, ABCMeta)
    assert isinstance(obj, Singleton)


# Generated at 2022-06-25 13:07:16.372518
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs.from_options(options=None)


# Generated at 2022-06-25 13:07:20.050924
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Test with empty dictionary
    test_dict = {}
    the_args = GlobalCLIArgs.from_options(test_dict)
    assert (the_args == {})

    # Test with a None
    test_dict = None
    the_args = GlobalCLIArgs.from_options(test_dict)
    assert (the_args == {})



# Generated at 2022-06-25 13:07:22.339972
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Assert that the value of attribute is equal to expected value
    assert GlobalCLIArgs.__name__ == 'GlobalCLIArgs'
    assert GlobalCLIArgs.__module__ == 'ansible.module_utils.common.arguments'



# Generated at 2022-06-25 13:07:24.033793
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    try:
        GlobalCLIArgs()
    except NameError:
        assert False


# Generated at 2022-06-25 13:07:24.826918
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()



# Generated at 2022-06-25 13:07:58.126300
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli.playbook import PlaybookCLI
    from ansible.utils.color import colorize

    cli = PlaybookCLI(['-f', '10', '/path/to/foo.yml'])
    cli.parse()
    run_args = CLIArgs(cli.args)
    global_args = GlobalCLIArgs(run_args)
    color = global_args['force_color']
    print(colorize('color', 'blue', True), color, colorize('global_args', 'blue', True), str(global_args))

# Generated at 2022-06-25 13:08:03.328808
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    # Test constructor of class GlobalCLIArgs
    GlobalCLIArgs(['-b', 'false'])

    # Test constructor of class GlobalCLIArgs
    GlobalCLIArgs(['-b', 'true'])

    # Test constructor of class GlobalCLIArgs
    GlobalCLIArgs(['-b', 'yes'])

    # Test constructor of class GlobalCLIArgs
    GlobalCLIArgs(['-b', 'no'])

# Generated at 2022-06-25 13:08:05.659790
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    bool_0 = True
    _ABCSingleton_0 = _ABCSingleton(bool_0)
    assert _ABCSingleton == _ABCSingleton_0


# Generated at 2022-06-25 13:08:08.854429
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options_0 = None
    i_d_0 = GlobalCLIArgs.from_options(options_0)
    assert(isinstance(i_d_0, GlobalCLIArgs))


# Generated at 2022-06-25 13:08:13.105124
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # bit of trickery to get a compiled class from a class definition
    class _ABCSingleton_0(object):
        __metaclass__ = _ABCSingleton
        pass
    assert isinstance(_ABCSingleton_0, type)
    assert issubclass(_ABCSingleton_0, ABCMeta)
    assert issubclass(_ABCSingleton_0, Singleton)



# Generated at 2022-06-25 13:08:13.928109
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_case_0()


# Generated at 2022-06-25 13:08:15.014265
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton):
        pass
    f = Foo()


# Generated at 2022-06-25 13:08:16.841072
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    input_0 = {}
    expected_0 = {}
    output_0 = GlobalCLIArgs(input_0)
    assert output_0 == expected_0

# Generated at 2022-06-25 13:08:17.891564
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    c_l_i_args_0 = GlobalCLIArgs()


# Generated at 2022-06-25 13:08:21.413470
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping_0 = ImmutableDict()

    # Test if a CLIArgs object is created with mapping_0 as the argument
    c_l_i_args_0 = CLIArgs(mapping_0)
    # Test if the argument of the constructor is wrong
    c_l_i_args_1 = CLIArgs(5)

_global_cli_args = GlobalCLIArgs.get_instance()

# Generated at 2022-06-25 13:09:22.636650
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert _ABCSingleton is type(_ABCSingleton())


# Generated at 2022-06-25 13:09:31.616959
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = True
    c_l_i_args_0 = CLIArgs(bool_0)
    str_0 = c_l_i_args_0.some_value
    str_1 = c_l_i_args_0.get('some_value')
    bool_1 = c_l_i_args_0.has_key('some_value')
    bool_2 = c_l_i_args_0.has_key('some_value')
    assert(str_0 == str_1)
    assert(bool_1 == bool_2)
    bool_3 = c_l_i_args_0.some_value
    assert(bool_0)
    assert(str_0 == str_1)
    assert(bool_1 == bool_2)
    assert(bool_3)

# Generated at 2022-06-25 13:09:36.931941
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Create a new Test._ABCSingleton_class instance with Test._ABCSingleton_class as the argument
    # This will throw a TypeError at the end of the class definition if the class does not support being
    # the argument of Test._ABCSingleton_class.__init__.  This is the same test that happens in the
    # __set_metaclass__ function of type below.
    _ABCSingleton_class_0 = _ABCSingleton(type)


# Generated at 2022-06-25 13:09:39.309223
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, Singleton)
    assert issubclass(_ABCSingleton, ABCMeta)


# Generated at 2022-06-25 13:09:40.323932
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Test cases for class _ABCSingleton
    test_case_0()


# Generated at 2022-06-25 13:09:42.417095
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    obj_0 = _ABCSingleton()
    bool_0 = True
    assert bool_0 is bool_0


# Generated at 2022-06-25 13:09:45.318121
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Construct a new instance of class _ABCSingleton
    test_obj = _ABCSingleton()
    # Test if test_obj is a singleton of class _ABCSingleton
    test_obj.__init__()


# Generated at 2022-06-25 13:09:47.624704
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Test for constructor of class GlobalCLIArgs"""
    mapping = 'bool_0'
    global_c_l_i_args_0 = GlobalCLIArgs(mapping)



# Generated at 2022-06-25 13:09:48.393523
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert GlobalCLIArgs is not None


# Generated at 2022-06-25 13:09:50.138809
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = True
    c_l_i_args_0 = CLIArgs(bool_0)
# Low Level Tests
