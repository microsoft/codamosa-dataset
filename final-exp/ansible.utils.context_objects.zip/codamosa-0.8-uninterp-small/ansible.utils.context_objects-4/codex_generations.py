

# Generated at 2022-06-25 13:00:49.744234
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Call the constructor and make sure it creates an object with the right data types
    mapping = {'bool': True, 'list': [1,2,3,4], 'int': 1, 'string': "String"}
    args = CLIArgs(mapping)
    assert type(args) is ImmutableDict
    assert all([type(i) is ImmutableDict for i in args.values()])
    assert all([type(j) is tuple for k in args.values() for j in k.values()])
    assert all([type(j) is frozenset for k in args.values() for j in k.values()])



# Generated at 2022-06-25 13:00:51.259833
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert isinstance(CLIArgs, object)


# Generated at 2022-06-25 13:00:56.961000
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    def test__ABCSingleton_class_instantiation(a0):
        class C0(object, metaclass=_ABCSingleton):
            pass
        class C1(C0, metaclass=_ABCSingleton):
            pass
        class C2(C1):
            pass
        class C3(C1):
            pass
        class C4(C1):
            pass
        assert C0 is C1
        assert C1 is C2
        assert C1 is C3
        assert C1 is C4
        assert C0 is C4

    test__ABCSingleton_class_instantiation(0)

# Generated at 2022-06-25 13:01:01.168483
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    bool_0 = None
    str_0 = '1'
    mapping_0 = dict()
    mapping_0['Ail^0 "Lif4h0'] = bool_0
    cli_args_0 = CLIArgs(mapping_0)


# Generated at 2022-06-25 13:01:02.124050
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert 1


# Generated at 2022-06-25 13:01:05.066496
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'foo': {'bar': 3}, 'qux': 'quux'}

    cli_args = CLIArgs(mapping)

    assert cli_args.foo.bar == 3
    assert cli_args.qux == 'quux'

    assert cli_args is not CLIArgs(mapping)


# Generated at 2022-06-25 13:01:08.974128
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    bool_0 = None
    str_0 = 'Ail^0 "Lif4h0'
    global_c_l_i_args_0 = GlobalCLIArgs(str_0)
    bool_1 = False
    str_1 = 'ld^vQ3'
    cli_args_0 = GlobalCLIArgs(str_1)


# Generated at 2022-06-25 13:01:11.181089
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert _ABCSingleton('/etc/ansible/ansible.cfg') == _ABCSingleton('/etc/ansible/ansible.cfg')


# Generated at 2022-06-25 13:01:12.115311
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()


# Generated at 2022-06-25 13:01:12.986081
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_case_0()

# Generated at 2022-06-25 13:01:17.529757
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    pass # TODO



# Generated at 2022-06-25 13:01:20.304104
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 1177.9
    dict_0 = {float_0: float_0, float_0: float_0}
    c_l_i_args_0 = CLIArgs(dict_0)

# Generated at 2022-06-25 13:01:27.557901
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 2890.0
    float_1 = 700.4
    list_0 = [float_0, float_1]
    float_2 = 200.1
    float_3 = 500.0
    tuple_0 = (float_0, float_1, float_1, float_1, float_1, float_2)
    float_4 = 845.6
    float_5 = 885.8
    float_6 = 463.2
    float_7 = 972.5
    float_8 = 472.5
    float_9 = 591.5
    float_10 = 989.3
    float_11 = 940.0
    float_12 = 502.3
    tuple_1 = (float_3, float_12, float_11, float_11)
    float_13

# Generated at 2022-06-25 13:01:28.812961
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    global_c_l_i_args_0 = GlobalCLIArgs()

if __name__ == '__main__':
    test_case_0()
    test__ABCSingleton()

# Generated at 2022-06-25 13:01:31.699178
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    float_0 = 1177.9
    dict_0 = {float_0: float_0, float_0: float_0}
    global_c_l_i_args_0 = GlobalCLIArgs(dict_0)


# Generated at 2022-06-25 13:01:39.592330
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    import unittest

    class Singleton(_ABCSingleton):
        def __init__(self, int_0):
            self._int_0 = int_0

        @classmethod
        def get_value(cls):
            return cls.__instance__._int_0

    _ABCSingleton.__instance__ = None
    int_0 = 78
    singleton_0 = Singleton(int_0)
    singleton_1 = Singleton(int_0)
    assert singleton_0._int_0 == singleton_1._int_0

    class Singleton(_ABCSingleton):
        def __init__(self, int_0):
            self._int_0 = int_0

        @classmethod
        def get_value(cls):
            return cls.__instance__._int_0

    _

# Generated at 2022-06-25 13:01:47.271165
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from types import MethodType
    from types import BuiltinFunctionType

    obj_0 = _ABCSingleton()
    if hasattr(obj_0, '__init__'):
        obj_0.__init__({'_': '_'})
    obj_0.__init__ = MethodType(lambda self: None)
    obj_0.__class__ = BuiltinFunctionType
    obj_0.__init__({'_': '_'})
    obj_0.__class__ = BuiltinFunctionType
    obj_0.__init__ = MethodType(lambda self: None)



# Generated at 2022-06-25 13:01:53.311846
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common._collections_compat import Mapping

    float_0 = 1177.9
    dict_0 = {float_0: float_0, float_0: float_0}
    c_l_i_args_0 = CLIArgs(dict_0)
    assert len(c_l_i_args_0) == 2
    assert isinstance(c_l_i_args_0, ImmutableDict)
    assert isinstance(c_l_i_args_0, Mapping)


# Generated at 2022-06-25 13:01:58.129435
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert isinstance(GlobalCLIArgs, _ABCSingleton)

if __name__ == '__main__':
    import sys
    import pytest

    test_case_0()
    test_GlobalCLIArgs()

    m = sys.modules[__name__]
    pytest.main(['-qq', m.__file__])

# Generated at 2022-06-25 13:02:01.012154
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    global_c_l_i_args_0 = GlobalCLIArgs({})
    assert isinstance(global_c_l_i_args_0, GlobalCLIArgs) is True


# Generated at 2022-06-25 13:02:08.821335
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict_0 = {'\xfb': '\xfb', '\xfb': '\xfb'}
    c_l_i_args_0 = CLIArgs(dict_0)


# Generated at 2022-06-25 13:02:10.430761
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_case_0()

if __name__ == '__main__':
    test_CLIArgs()

# Generated at 2022-06-25 13:02:13.902467
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 1177.9
    dict_0 = {float_0: float_0, float_0: float_0}
    global_c_l_i_args_0 = GlobalCLIArgs(dict_0)
    assert isinstance(global_c_l_i_args_0, CLIArgs)

# Generated at 2022-06-25 13:02:18.807400
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert not isinstance(_ABCSingleton,type)
    assert isinstance(_ABCSingleton,abc.ABCMeta)
    assert issubclass(_ABCSingleton,Singleton)
    assert issubclass(_ABCSingleton,abc.ABCMeta)
    assert _ABCSingleton.__subclasshook__(Singleton) is False
    assert _ABCSingleton.__subclasshook__(CLIArgs) is False


# Generated at 2022-06-25 13:02:27.986517
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 1092.2
    dict_0 = {float_0: float_0, float_0: float_0}
    c_l_i_args_0 = GlobalCLIArgs(dict_0)
    print(c_l_i_args_0)

    float_0 = 891.5
    dict_1 = {float_0: float_0, float_0: float_0}
    c_l_i_args_1 = GlobalCLIArgs(dict_1)
    print(c_l_i_args_1)

if __name__ == '__main__':
    test_case_0()
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:02:32.807448
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    dict_0 = {'': 0, 'Y': 0}
    c_l_i_args_0 = CLIArgs(dict_0)
    c_l_i_args_1 = GlobalCLIArgs.from_options(options=None)
    GlobalCLIArgs.from_options(options=None)


# Generated at 2022-06-25 13:02:34.046415
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    global_c_l_i_args_0 = GlobalCLIArgs()


# Generated at 2022-06-25 13:02:35.730616
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    global _ABCSingleton
    _ABCSingleton = _ABCSingleton()


# Generated at 2022-06-25 13:02:44.108670
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Setup
    float_0 = 4474.9
    list_0 = [float_0, float_0, float_0, float_0, float_0, float_0, float_0, float_0, float_0, float_0]
    dict_0 = {float_0: list_0}
    c_l_i_args_0 = GlobalCLIArgs(dict_0)

    # Teardown
    del c_l_i_args_0



# Generated at 2022-06-25 13:02:45.080675
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()


# Generated at 2022-06-25 13:02:52.851791
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Test for constructor of class CLIArgs
    test_case_0()
    pass


# Generated at 2022-06-25 13:02:56.156892
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict_0 = {1: 1, 2: 2, 3: 3}
    cliargs_0 = CLIArgs(dict_0)
    assert isinstance(cliargs_0, CLIArgs)
    # TODO: add comparison test to make sure they are the same

# Generated at 2022-06-25 13:03:04.912303
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict_0 = dict()
    dict_0[1] = 1
    dict_0[1.0] = 1.0
    dict_0[1.0] = 1.0
    dict_0['one'] = 1
    dict_0['one'] = 1
    dict_0[1.0] = 1.0
    dict_0['one'] = 'one'
    dict_0['one'] = 'one'
    dict_0['one'] = 'one'
    dict_0[1.0] = 1.0
    dict_0['one'] = 'one'
    dict_0[1.0] = 1.0
    dict_0[1] = 1
    dict_0[1.0] = 1.0
    dict_0[1.0] = 1.0

# Generated at 2022-06-25 13:03:14.673687
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    def test__ABCSingleton_0():
        # list_0 = [10, 1, 2, 3, 4, 5, 6, 7, 8, 9]
        # list_0 = sorted(list_0)
        # toplevel = {list_0: list_0, list_0: list_0}
        dict_0 = {'foo': 'bar'}

        c_l_i_args_0 = CLIArgs(dict_0)
        c_l_i_args_0 = CLIArgs(dict_0)
        dict_0 = {'foo': 'bar'}
        c_l_i_args_1 = CLIArgs(dict_0)
        c_l_i_args_2 = CLIArgs(dict_0)
        c_l_i_args_2['foo'] = 'foo'
       

# Generated at 2022-06-25 13:03:15.543328
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    obj_0 = _ABCSingleton()



# Generated at 2022-06-25 13:03:16.844071
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    c_l_i_args_0 = GlobalCLIArgs(dict_0)

# Generated at 2022-06-25 13:03:18.337604
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    global_c_l_i_args_0 = GlobalCLIArgs.instance()


# Generated at 2022-06-25 13:03:18.855531
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    pass

# Generated at 2022-06-25 13:03:23.805450
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict_0 = dict()
    dict_0["text_type"] = None
    dict_0["binary_type"] = None
    dict_0["text_type"] = 0
    dict_0["binary_type"] = 0
    c_l_i_args_0 = CLIArgs(dict_0)

    assert isinstance(c_l_i_args_0, CLIArgs)



# Generated at 2022-06-25 13:03:25.734472
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class_0 = CLIArgs({})
    class_0 = CLIArgs({})
    class_0 = CLIArgs({})


# Generated at 2022-06-25 13:03:38.421014
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    c_l_i_args_0 = GlobalCLIArgs({})

# Generated at 2022-06-25 13:03:40.782507
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 1177.9
    dict_0 = {float_0: float_0, float_0: float_0}
    c_l_i_args_0 = CLIArgs(dict_0)



# Generated at 2022-06-25 13:03:43.052881
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 1177.9
    dict_0 = {float_0: float_0, float_0: float_0}
    GlobalCLIArgs(dict_0)


# Generated at 2022-06-25 13:03:50.576428
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 87982.814143
    list_0 = [float_0, float_0, float_0, float_0, float_0, float_0, float_0, float_0, float_0, float_0]
    dict_0 = {float_0: float_0, float_0: float_0}
    c_l_i_args_0 = CLIArgs(dict_0)
    c_l_i_args_1 = GlobalCLIArgs.instance()
    assert not c_l_i_args_1 == None



# Generated at 2022-06-25 13:03:52.959217
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    global_cli_args = GlobalCLIArgs({})

if __name__ == '__main__':
    test_case_0()
    test_CLIArgs()

# Generated at 2022-06-25 13:03:58.475108
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 1177.9
    dict_0 = {float_0: float_0, float_0: float_0}
    c_l_i_args_0 = CLIArgs(dict_0)
    global_c_l_i_args_0 = GlobalCLIArgs.from_options(c_l_i_args_0)
    print("Values expected: %s \t\t Actual values: %s " % (float_0, global_c_l_i_args_0))

# Generated at 2022-06-25 13:04:00.775873
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()

if __name__ == '__main__':
    # Unit test for constructor of class _ABCSingleton
    test__ABCSingleton()

# Generated at 2022-06-25 13:04:05.299615
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 1177.9
    dict_0 = {float_0: float_0, float_0: float_0}
    c_l_i_args_0 = CLIArgs(dict_0)
    assert not isinstance(c_l_i_args_0, Mapping), "Assert that Mapping.(dict) returns False"


# Generated at 2022-06-25 13:04:08.544715
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Test that _ABCSingleton() is a Singleton
    obj = _ABCSingleton()
    assert isinstance(obj, Singleton)
    # Test that _ABCSingleton() is an ABCMeta
    obj = _ABCSingleton()
    assert isinstance(obj, ABCMeta)


# Generated at 2022-06-25 13:04:11.794054
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    dict_0 = {'7': 'jd.Z(7V@', '<': '&FoT)Q>d'}
    args_0 = GlobalCLIArgs(dict_0)
    assert args_0 == dict_0


# Generated at 2022-06-25 13:04:40.897540
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_GlobalCLIArgs = int('1000')
    dict_0 = {test_GlobalCLIArgs: test_GlobalCLIArgs, test_GlobalCLIArgs: test_GlobalCLIArgs}
    options_0 = CLIArgs.from_options(dict_0)
    assert hasattr(CLIArgs, 'from_options')


# Generated at 2022-06-25 13:04:42.777715
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        test_case_0()
    except Exception as exc:
        assert False, str(exc)


# Generated at 2022-06-25 13:04:49.457082
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict_0 = {'W8': '-2', 'X\x0c': 'b3', '&O@)': '', 'A': '-1', 'Y': '-3', 'X': '-5', 'W': '-1', 'Z': '-1'}
    c_l_i_args_0 = CLIArgs(dict_0)
    assert c_l_i_args_0.copy() == dict_0


# Generated at 2022-06-25 13:04:50.696258
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Run test case 0
    test_case_0()


# Generated at 2022-06-25 13:05:02.064406
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    ans_0 = {
        "remote_user": "ssh_user",
        "private_key_file": "~/.ssh/id_rsa",
        "ssh_args": "-F ssh.cfg",
        "ssh_common_args": "-o ControlMaster=auto -o ControlPersist=60s",
        "sftp_extra_args": "-f",
        "scp_extra_args": "-f",
        "become": True,
        "become_method": "sudo",
        "become_user": "root",
        "verbosity": 0,
        "check": False
    }
    global_c_l_i_args_0 = GlobalCLIArgs.from_options(ans_0)
    assert global_c_l_i_args_0 == ans_0

# Generated at 2022-06-25 13:05:11.199739
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    float_0 = 1133.9
    float_1 = float_0
    float_2 = float_1
    float_3 = float_2
    float_4 = float_2
    float_5 = float_4
    float_6 = float_2
    float_7 = float_3
    float_8 = float_6
    float_9 = float_6
    float_10 = float_9
    float_11 = float_9
    float_12 = float_6
    float_13 = float_1

# Generated at 2022-06-25 13:05:15.284981
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # TODO: Any idea why the need to call test_case_0 here?
    test_case_0()
    _abc_singleton_0 = _ABCSingleton()
    class_0 = _ABCSingleton.__new__(_ABCSingleton())
    assert isinstance(class_0, object)
    assert isinstance(class_0, _ABCSingleton)
    assert type(class_0) is _ABCSingleton


# Generated at 2022-06-25 13:05:20.218913
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    mapping = {'foo': 'bar'}
    global_cli_args_1 = GlobalCLIArgs.from_options(mapping)
    global_cli_args_2 = GlobalCLIArgs.from_options(mapping)
    print(global_cli_args_1 is global_cli_args_2)
    mapping = {'foo': 'bar'}
    global_cli_args_3 = GlobalCLIArgs(mapping)
    global_cli_args_4 = GlobalCLIArgs(mapping)
    print(global_cli_args_3 is global_cli_args_4)

if __name__ == '__main__':
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:05:22.720558
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_1 = 1177.9
    dict_1 = {float_1: float_1, float_1: float_1}
    c_l_i_args_1 = CLIArgs(dict_1)
    assert c_l_i_args_1 is not None

if __name__ == "__main__":
    test_case_0()
    test_CLIArgs()

# Generated at 2022-06-25 13:05:25.326701
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    dict_0 = {}
    global_c_l_i_args_0 = GlobalCLIArgs(dict_0)
    global_c_l_i_args_0 = GlobalCLIArgs(dict_0)


# Generated at 2022-06-25 13:05:53.050366
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 1177.9
    dict_0 = {float_0: float_0, float_0: float_0}
    c_l_i_args_0 = CLIArgs(dict_0)
    c_l_i_args_0 = CLIArgs.from_options(c_l_i_args_0)
    c_l_i_args_0 = c_l_i_args_0.copy()
    value = c_l_i_args_0[float_0]
    c_l_i_args_0[float_0] = float_0
    c_l_i_args_0[float_0] = float_0
    c_l_i_args_0.update(c_l_i_args_0)
    c_l_i_args_1 = c

# Generated at 2022-06-25 13:05:54.103329
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert isinstance([].__class__, type)

# Generated at 2022-06-25 13:06:03.152526
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    global_c_l_i_args_0 = GlobalCLIArgs()
    assert isinstance(global_c_l_i_args_0, GlobalCLIArgs)
    assert isinstance(global_c_l_i_args_0, ImmutableDict)
    assert isinstance(global_c_l_i_args_0, dict)
    assert isinstance(global_c_l_i_args_0, Container)
    assert isinstance(global_c_l_i_args_0, Mapping)


# Generated at 2022-06-25 13:06:09.726250
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Ensure _ABCSingleton is a metaclass
    class TestClass:
        pass

    TestClass = _ABCSingleton(TestClass.__name__, TestClass.__bases__, TestClass.__dict__)
    TestClass = _ABCSingleton(TestClass)
    assert isinstance(TestClass, _ABCSingleton)

    # Ensure _ABCSingleton is a subclass of ABCMeta
    assert issubclass(_ABCSingleton, ABCMeta)

    # Ensure _ABCSingleton is a subclass of Singleton
    assert issubclass(_ABCSingleton, Singleton)


# Generated at 2022-06-25 13:06:12.107415
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs(['--ignore-files=public_key\n'])


if __name__ == "__main__":
    test_case_0()
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:06:13.108864
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    pass


# Generated at 2022-06-25 13:06:17.153394
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 1177.9
    dict_0 = {float_0: float_0, float_0: float_0}
    c_l_i_args_0 = CLIArgs(dict_0)
    assert c_l_i_args_0._mapping[float_0] == float_0


# Generated at 2022-06-25 13:06:21.969288
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    dict_1 = {}
    dict_1[(0, 0)] = 0.00009
    global_c_l_i_args_0 = GlobalCLIArgs(dict_1)


# Generated at 2022-06-25 13:06:22.870551
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_case_0()



# Generated at 2022-06-25 13:06:26.940086
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 1177.9
    dict_0 = {float_0: float_0, float_0: float_0}
    c_l_i_args_0 = GlobalCLIArgs(dict_0)



# Generated at 2022-06-25 13:07:12.704811
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    import os
    import tempfile

    class Alpha(_ABCSingleton):
        pass

    # Verify None
    assert Alpha() is not None

    # Verify construtor with args
    alpha_obj = Alpha()

    try:
        # Write a file
        with tempfile.NamedTemporaryFile(delete=False) as _:
            pass

        os.unlink(alpha_obj.__file__)

        class Beta(_ABCSingleton):
            pass

        beta_obj = Beta()

        alpha_new = Alpha()
        assert alpha_new is alpha_obj

        beta_new = Beta()
        assert beta_new is beta_obj
    finally:
        try:
            os.unlink(alpha_obj.__file__)
        except IOError:
            pass



# Generated at 2022-06-25 13:07:17.075727
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 1177.9
    dict_0 = {float_0: float_0, float_0: float_0}
    c_l_i_args_0 = CLIArgs(dict_0)
    # TypeError
    try:
        c_l_i_args_1 = CLIArgs(dict_0, float_0)
    except TypeError:
        assert True
    else:
        assert False

if __name__ == '__main__':
    test_case_0()
    # Unit test for constructor of class CLIArgs
    test_CLIArgs()
    print("All tests passed")

# Generated at 2022-06-25 13:07:17.642735
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()



# Generated at 2022-06-25 13:07:20.084794
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    float_0 = 1177.9
    dict_0 = {float_0: float_0, float_0: float_0}
    c_l_i_args_0 = GlobalCLIArgs(dict_0)


# Generated at 2022-06-25 13:07:22.699261
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    dict_0 = {int_0: int_0}
    c_l_i_args_0 = CLIArgs(dict_0)

    # Verify that the singleton is working correctly
    c_l_i_args_1 = GlobalCLIArgs(dict_0)
    assert c_l_i_args_0 == c_l_i_args_1

# Generated at 2022-06-25 13:07:23.906915
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()

# Generated at 2022-06-25 13:07:31.452970
# Unit test for constructor of class _ABCSingleton

# Generated at 2022-06-25 13:07:33.747945
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_case_0()

if __name__ == '__main__':
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:07:37.269937
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    c_l_i_args_expect = CLIArgs({"a": "b"})
    c_l_i_args_actual = CLIArgs({"a": "b"})
    assert c_l_i_args_expect == c_l_i_args_actual



# Generated at 2022-06-25 13:07:45.608264
# Unit test for constructor of class _ABCSingleton

# Generated at 2022-06-25 13:09:21.402733
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-25 13:09:25.458106
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    string_0 = "test_value_0"
    string_1 = "test_value_1"
    string_2 = "test_value_2"
    dict_0 = {string_0: string_1, string_2: string_0}
    GlobalCLIArgs(dict_0)

# Generated at 2022-06-25 13:09:33.738872
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = -6.067537e+37
    float_1 = -3.7992644399720488e-39
    float_2 = 36.1904
    float_3 = 3.910820468381244e-38
    float_4 = -1.2541501332699e-30

# Generated at 2022-06-25 13:09:36.014603
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    dict_0 = {}
    global_c_l_i_args_0 = GlobalCLIArgs(dict_0)
    #assert global_c_l_i_args_0._immutable == True

# Generated at 2022-06-25 13:09:40.173650
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 3.4
    dict_0 = {float_0: float_0, float_0: float_0}
    c_l_i_args_0 = CLIArgs(dict_0)

CLIArgs.from_options(True)
GlobalCLIArgs.from_options(True)

# Generated at 2022-06-25 13:09:45.013682
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 1177.9
    dict_0 = {float_0: float_0, float_0: float_0}
    c_l_i_args_0 = CLIArgs(dict_0)
    assert type(c_l_i_args_0) == CLIArgs

if __name__ == "__main__":
    test_case_0()
    test_CLIArgs()

# Generated at 2022-06-25 13:09:51.510274
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    dict_0 = {}
    global_c_l_i_args_0 = GlobalCLIArgs(dict_0)
    assert isinstance(global_c_l_i_args_0, GlobalCLIArgs), "Failed to create type"
    assert (isinstance(global_c_l_i_args_0, CLIArgs) and isinstance(global_c_l_i_args_0, Container) and isinstance(global_c_l_i_args_0, Mapping) and isinstance(global_c_l_i_args_0, Sequence) and isinstance(global_c_l_i_args_0, Set)), "Failed to inherit base classes"



# Generated at 2022-06-25 13:09:53.582286
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Arrange
    dict_1 = dict()

    # Act
    c_l_i_args_1 = CLIArgs(dict_1)

    # Assert
    assert c_l_i_args_1 is not None

# Generated at 2022-06-25 13:09:57.225828
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, Singleton)

# Generated at 2022-06-25 13:10:00.961814
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    float_0 = 1177.9
    dict_0 = {float_0: float_0, float_0: float_0}
    c_l_i_args_0 = CLIArgs(dict_0)
    c_l_i_args_0 = CLIArgs.from_options(dict_0)

# Head start for test of GlobalCLIArgs