

# Generated at 2022-06-25 13:00:47.232558
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    tuple_0 = None
    cli_args_0 = CLIArgs(tuple_0)


# Generated at 2022-06-25 13:00:49.648828
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    tuple_0 = None
    cli_args_0 = CLIArgs(tuple_0)
    assert cli_args_0 is not None


# Generated at 2022-06-25 13:00:58.181903
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    # test the type of instance
    options = tuple()
    global_c_l_i_args_1 = GlobalCLIArgs.from_options(options)
    assert isinstance(global_c_l_i_args_1, GlobalCLIArgs)

    # test the value of instance
    assert global_c_l_i_args_1 == tuple()

    # test the type of instance
    options_2 = tuple()
    global_c_l_i_args_2 = GlobalCLIArgs.from_options(options_2)
    # the singleton object created by previous line should be the same with the instance created by this line
    assert global_c_l_i_args_1 is global_c_l_i_args_2


if __name__ == '__main__':
    print(test_case_0())

# Generated at 2022-06-25 13:00:59.683946
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert GlobalCLIArgs({})


# Generated at 2022-06-25 13:01:01.893342
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    tuple_0 = None
    global_c_l_i_args_1 = GlobalCLIArgs(tuple_0)



# Generated at 2022-06-25 13:01:03.061631
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    tuple_0 = None
    global_c_l_i_args_0 = GlobalCLIArgs(tuple_0)

# Generated at 2022-06-25 13:01:04.876606
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    tuple_0 = None
    global_c_l_i_args_0 = CLIArgs(tuple_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 13:01:07.440088
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    tuple_0 = None
    cli_args_0 = CLIArgs(tuple_0)
    # Test for global class GlobalCLIArgs
    tuple_0 = None
    global_c_l_i_args_1 = GlobalCLIArgs(tuple_0)


# Generated at 2022-06-25 13:01:10.600027
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    tuple_0 = None
    global_c_l_i_args_0 = GlobalCLIArgs(tuple_0)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 13:01:17.316479
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test the constructor of class GlobalCLIArgs.

    This is used to test it is constructed correctly.
    """
    # fail_called = False
    # try:
        # tuple_0 = None
        # global_c_l_i_args_0 = GlobalCLIArgs(tuple_0)
    # except TypeError:
        # fail_called = True
    # assert fail_called, "ERROR: failed to raise exception"
    # no assertion method for GlobalCLIArgs
    pass

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 13:01:25.298700
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    str_0 = '\n    Test the constructor of class CLIArgs.\n\n    This is used to test it is constructed correctly.\n    '
    arg_0 = {'a':'b', 'c':'d', 'e':'f'}
    cls_0 = CLIArgs(arg_0)
    print(cls_0)


# Generated at 2022-06-25 13:01:26.328593
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    
    tempobj0 = CLIArgs({})
    return None


# Generated at 2022-06-25 13:01:33.106401
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    str_2 = '\n    Test the constructor of class _ABCSingleton.\n\n    This is used to test it is constructed correctly.\n    '
    # Construct global Variable: int_0
    int_0 = 0
    # Construct global Variable: str_0
    str_0 = 'A'
    # Construct global Variable: str_1
    str_1 = 'B'
    # Construct global Variable: str_3
    str_3 = 'C'
    # Construct global Variable: int_1
    int_1 = 1
    # Construct global Variable: int_2
    int_2 = 2


# Generated at 2022-06-25 13:01:36.548354
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    import _ABCSingleton as src
    # Pass a dict that maps str to int
    test_case_0()


# Generated at 2022-06-25 13:01:44.853992
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    def test_0():
        inside_test_0 = '\n    This is used to test that __call__ is working.\n    '
        obj_0 = _ABCSingleton()
        assert isinstance(obj_0, _ABCSingleton)
    test_0()

    def test_1():
        inside_test_1 = '\n    This is used to test that __instancecheck__ is working.\n    '
        obj_0 = _ABCSingleton()
        assert isinstance(obj_0, _ABCSingleton)
    test_1()

test__ABCSingleton()


# Generated at 2022-06-25 13:01:47.676852
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    def test_check_CLIArgs_constructor():
        """
        Test the constructor of class GlobalCLIArgs.

        This is used to test it is constructed correctly.
        """
        str_0 = '\n        Test the constructor of class GlobalCLIArgs.\n\n        This is used to test it is constructed correctly.\n        '


# Generated at 2022-06-25 13:01:48.380219
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert True


# Generated at 2022-06-25 13:01:51.999575
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_case_0()


# Generated at 2022-06-25 13:01:54.504612
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args_0 = {}
    # Init instance of CLIArgs
    obj = CLIArgs(args_0)
    test_case_0()

# Generated at 2022-06-25 13:01:57.590077
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    with pytest.raises(TypeError):
        str_0 = '\n        Test the constructor of class GlobalCLIArgs.\n\n        This is used to test it is constructed correctly.\n        '


# Generated at 2022-06-25 13:02:07.156419
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # test of constructor
    # case 0
    str_0 = ';l'
    c_l_i_args_0 = GlobalCLIArgs(str_0)
    assert c_l_i_args_0 == str_0

# Generated at 2022-06-25 13:02:08.515299
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    pass  # TODO


# Generated at 2022-06-25 13:02:10.473315
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    instance = _ABCSingleton()
    assert instance


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 13:02:11.466813
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args_0 = GlobalCLIArgs()

# Generated at 2022-06-25 13:02:17.351899
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    print("Unit test for constructor of class CLIArgs")

# Generated at 2022-06-25 13:02:19.392632
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.context import CLIARGS
    cli_args = CLIARGS
    print(cli_args)



# Generated at 2022-06-25 13:02:20.962477
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert isinstance(_ABCSingleton, type)
    assert _ABCSingleton == _ABCSingleton


# Generated at 2022-06-25 13:02:29.342122
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    str_0 = """
    This class is used to implement Singleton classes with abstract baseclasses (ABCs).
    """

    # This is a docstring test.
    str_1 = _ABCSingleton.__doc__
    bool_0 = (str_1 != str_0)
    str_2 = "Singleton"
    # This is a type test.
    str_3 = _ABCSingleton.__name__
    bool_1 = (str_3 != str_2)
    assert bool_0 is False
    assert bool_1 is False


# Generated at 2022-06-25 13:02:31.782298
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    str_0 = ';l'
    global_c_l_i_args_0 = GlobalCLIArgs(str_0)

# Generated at 2022-06-25 13:02:38.314289
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from mock import patch, call
    from ansible.module_utils.common._collections_compat import ImmutableDict
    from ansible.module_utils.cli import CLIArgs, GlobalCLIArgs

    with patch.object(GlobalCLIArgs, '__init__') as mock_GlobalCLIArgs_init:
        GlobalCLIArgs()
        assert mock_GlobalCLIArgs_init.call_single_call_single_args[0] == ()
        assert mock_GlobalCLIArgs_init.call_single_call_single_args[1] == {}
        assert mock_GlobalCLIArgs_init.call_single_call_single_args[2] == None


# Generated at 2022-06-25 13:02:45.698977
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    str_1 = ';l'
    cli_args_0 = _ABCSingleton(str_1)
# test_case_0()

# Generated at 2022-06-25 13:02:47.910054
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 13:02:49.505964
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert isinstance(_ABCSingleton(), _ABCSingleton)


# Generated at 2022-06-25 13:02:56.931371
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    string_0 = 'show-diff catch_errors'
    CLIArgs_0 = CLIArgs(string_0)
    string_1 = 'verbose vvvv'
    CLIArgs_1 = CLIArgs(string_1)
    string_2 = 'check'
    CLIArgs_2 = CLIArgs(string_2)
    string_3 = 'listhosts vvv'
    CLIArgs_3 = CLIArgs(string_3)
    string_4 = 'vvvv'
    CLIArgs_4 = CLIArgs(string_4)
    string_5 = 'vvv'
    CLIArgs_5 = CLIArgs(string_5)
    string_6 = 'vv'
    CLIArgs_6 = CLIArgs(string_6)
    string_7 = 'v'
    CLIArgs_7 = CLIArgs(string_7)


# Generated at 2022-06-25 13:03:06.037652
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    dict_0 = dict()
    dict_0['a'] = 1
    dict_0['b'] = 2
    c_l_i_args_0 = CLIArgs(dict_0)
    global_c_l_i_args_0 = GlobalCLIArgs(c_l_i_args_0)
    global_c_l_i_args_1 = GlobalCLIArgs(c_l_i_args_0)

    # GlobalCLIArgs is a Singleton. We test the constructor
    # of GlobalCLIArgs here. The two instances global_c_l_i_args_0 and
    # global_c_l_i_args_1 should be equal.
    assert (global_c_l_i_args_0 == global_c_l_i_args_1)



# Generated at 2022-06-25 13:03:09.063388
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    str_0 = ';l'
    # Class constructor of class _ABCSingleton
    assert_equals(_ABCSingleton, _ABCSingleton(str_0))
    assert_equals(type(_ABCSingleton), _ABCSingleton)

# Generated at 2022-06-25 13:03:18.191023
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common._collections_compat import Counter, defaultdict
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils.singleton import Singleton

    # We are basically testing the constructor
    from ansible.module_utils.common import CLIArgs
    from ansible.module_utils.common import GlobalCLIArgs

    dict_0 = {}

    dict_1 = {}

    dict_1[0] = dict_0
    dict_1[1] = dict_0

    # c_l_i_args_0 should be equivalent to the singleton _instance
    c_l_i_args_0 = GlobalCLIArgs(dict_1)
    assert isinstance(c_l_i_args_0, dict)

    c_l_i_args

# Generated at 2022-06-25 13:03:21.489832
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_cli_args = CLIArgs.from_options({'debug': (True, 'a')})
    test_global_cli_args = GlobalCLIArgs(test_cli_args)
    assert test_global_cli_args == test_cli_args


# Generated at 2022-06-25 13:03:24.329548
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = GlobalCLIArgs()

if __name__ == '__main__':
    # test_case_0()
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:03:26.566382
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    c_l_i_args_0 = CLIArgs(';l')
    print(c_l_i_args_0)


# Generated at 2022-06-25 13:03:56.156867
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    # Test 1
    str_0 = ';l'
    c_l_i_args_0 = CLIArgs(str_0)
    # Test 2
    str_0 = ';#'
    c_l_i_args_0 = CLIArgs(str_0)
    # Test 3
    str_0 = ';#'
    c_l_i_args_0 = CLIArgs(str_0)
    # Test 4
    str_0 = ';#'
    c_l_i_args_0 = CLIArgs(str_0)
    # Test 5
    str_0 = ';#'
    c_l_i_args_0 = CLIArgs(str_0)
    # Test 6
    str_0 = ';#'

# Generated at 2022-06-25 13:03:59.060745
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert isinstance(GlobalCLIArgs(), GlobalCLIArgs)
    assert GlobalCLIArgs().__class__ == GlobalCLIArgs
    print('passed all testcases')


if __name__ == '__main__':
    test_case_0()
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:04:01.223701
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    print("test_GlobalCLIArgs()")
    assert isinstance(GlobalCLIArgs(), GlobalCLIArgs), "GlobalCLIArgs is not a GlobalCLIArgs"


# Generated at 2022-06-25 13:04:03.436868
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    c_l_i_args_0 = GlobalCLIArgs()
    assert type(c_l_i_args_0) == GlobalCLIArgs

# Generated at 2022-06-25 13:04:06.290443
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    str_0 = ';l'
    global_c_l_i_args_0 = GlobalCLIArgs(str_0)
    assert isinstance(global_c_l_i_args_0, GlobalCLIArgs)

# Generated at 2022-06-25 13:04:07.572096
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Expecting NoneException
    _ABCSingleton()


# Generated at 2022-06-25 13:04:09.062401
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    str_1 = ';l'
    c_l_i_args_1 = GlobalCLIArgs(str_1)

# Generated at 2022-06-25 13:04:12.000248
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = GlobalCLIArgs()

if __name__ == '__main__':
    test_case_0()
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:04:13.905168
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    str_0 = ';l'
    c_l_i_args_0 = CLIArgs(str_0)


# Generated at 2022-06-25 13:04:19.357931
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    b = GlobalCLIArgs({})
    d = GlobalCLIArgs({1: 2})
    d1 = GlobalCLIArgs({1: 2})
    b1 = GlobalCLIArgs({})
    print("b = ", b)
    print("d = ", d)
    print("d1 = ", d1)
    print("b1 = ", b1)


if __name__ == '__main__':
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:04:30.918397
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    str_0 = ';l'
    c_l_i_args_0 = GlobalCLIArgs(str_0)

# Generated at 2022-06-25 13:04:33.634034
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Constructor of class _ABCSingleton should return an instance of it
    assert isinstance(_ABCSingleton(), _ABCSingleton)

# vim: set et ts=4 sw=4

# Generated at 2022-06-25 13:04:41.024538
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # TypeError raised if value is not of type dict
    try:
        CLIArgs(';')
    except TypeError as e:
        pass
    else:
        raise AssertionError(
            '<TypeError> not raised when \'\';\' is passed to constructor as value argument.')
    # AssertionError raised if value is not immutable
    try:
        CLIArgs({'a': 'apple'})
    except AssertionError as e:
        pass
    else:
        raise AssertionError(
            'ImmutableDict not created for dictionary with \'a\' as key and \'apple\' as value.')

# Generated at 2022-06-25 13:04:42.577462
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_c_l_i_args_0 = GlobalCLIArgs()


# Generated at 2022-06-25 13:04:46.119871
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    abc_singleton_0 = _ABCSingleton()  # Constructor test


# Generated at 2022-06-25 13:04:47.247087
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    obj_let_0 = _ABCSingleton()


# Generated at 2022-06-25 13:04:55.125590
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    str_0 = 'abc'
    c_l_i_args_0 = CLIArgs(str_0)

    dict_0 = {1:1}
    dict_1 = {2:2}
    c_l_i_args_1 = CLIArgs(dict_0)
    c_l_i_args_2 = CLIArgs(dict_1)
    c_l_i_args_2 = c_l_i_args_1
    c_l_i_args_1 = c_l_i_args_2

    c_l_i_args_2 = CLIArgs(dict_0)
    c_l_i_args_3 = CLIArgs(c_l_i_args_2)

    str_0 = '123'

# Generated at 2022-06-25 13:04:56.989674
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert isinstance(GlobalCLIArgs(), GlobalCLIArgs)


# Generated at 2022-06-25 13:05:01.618416
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Mock value of variable `str_0`
    str_0 = ''
    # Call function `CLIArgs`
    # c_l_i_args_0 = CLIArgs(str_0)
    # assert c_l_i_args_0 == ''
    pass


# Generated at 2022-06-25 13:05:03.645913
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args_0 = GlobalCLIArgs()
    assert isinstance(global_cli_args_0, GlobalCLIArgs)

# Generated at 2022-06-25 13:05:26.414811
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs.from_options(None)
    assert args == GlobalCLIArgs.from_options(None)

# Generated at 2022-06-25 13:05:29.056687
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    g_1 = GlobalCLIArgs.from_options({'ansible_module': 'get_ca', 'ansible_module_args': ''})

if __name__ == "__main__":
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:05:30.168159
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    g_c_l_i_args_0 = GlobalCLIArgs()

# Generated at 2022-06-25 13:05:33.603139
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    str_0 = ';l'
    obj_0 = _ABCSingleton(str_0)
    assert isinstance(obj_0, Singleton)
    assert isinstance(obj_0, ABCMeta)



# Generated at 2022-06-25 13:05:34.762582
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args_0 = GlobalCLIArgs()


# Generated at 2022-06-25 13:05:36.196617
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Check if 'instance' is of type _ABCSingleton
    assert isinstance(GlobalCLIArgs(), _ABCSingleton)

# Generated at 2022-06-25 13:05:37.289268
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GLOBAL_CLI_ARGS = GlobalCLIArgs()



# Generated at 2022-06-25 13:05:39.597794
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    print('Testing constructor of class CLIArgs.')
    a = GlobalCLIArgs()
    print('Testing constructor of class CLIArgs successed.\n')


# Generated at 2022-06-25 13:05:43.459219
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    try:
        cli_0 = GlobalCLIArgs()
    except:
        pass
    cli_1 = GlobalCLIArgs()
    cli_2 = GlobalCLIArgs()

'''
if __name__ == '__main__':
    test_GlobalCLIArgs()
    test_CLIArgs()
'''

# Generated at 2022-06-25 13:05:47.339046
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    GlobalCLIArgs_instance = GlobalCLIArgs.instance()

    # Unit test for isinstance() method of class GlobalCLIArgs
    assert isinstance(instance, GlobalCLIArgs)

    # Unit test for __init__() method of class GlobalCLIArgs
    assert globalCLIArgs_instance._is_immutable == True

# Generated at 2022-06-25 13:06:37.818834
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    str_0 = '{&g+S#(SbQ+S'
    str_1 = '4^F4Vy'
    str_2 = '4^F4Vy'
    str_3 = ';l'
    str_4 = '{&g+S#(SbQ+S'
    str_5 = '4^F4Vy'
    str_6 = '4^F4Vy'
    str_7 = ';l'
    assert CLIArgs(str_0)
    assert CLIArgs(str_1)
    assert GlobalCLIArgs(str_2)
    assert CLIArgs(str_3)
    assert CLIArgs(str_4)
    assert CLIArgs(str_5)
    assert GlobalCLIArgs(str_6)
    assert CLIArgs(str_7)

# Generated at 2022-06-25 13:06:39.422182
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    str_0 = ';l'
    c_l_i_args_0 = CLIArgs(str_0)


# Generated at 2022-06-25 13:06:40.914965
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    c_l_i_args_1 = GlobalCLIArgs()

if __name__ == '__main__':
    test__ABCSingleton()
    test_case_0()

# Generated at 2022-06-25 13:06:48.971540
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    str_0 = ';l'
    c_l_i_args_0 = GlobalCLIArgs(str_0)
    stypy.reporting.localization.Localization.set_current(stypy.reporting.localization.Localization(__file__, 37, 13))
    
    # 'module' lookup
    module_type_store = module_type_store.join_ssa_context()
    
    # Assigning a type to the variable 'c_l_i_args_0' (line 37)
    module_type_store.set_type_of(stypy.reporting.localization.Localization(__file__, 37, 4), 'c_l_i_args_0', c_l_i_args_0)
    
    # Call to from_options(...): (line 38)
   

# Generated at 2022-06-25 13:06:49.949534
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    pass # test of constructor for class CLIArgs

# Generated at 2022-06-25 13:06:52.996227
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    str_1 = ';l'
    c_l_i_args_1 = CLIArgs(str_1)


# Generated at 2022-06-25 13:06:54.979282
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cliargs_0 = GlobalCLIArgs({'foo': 0, 'bar': 1})
    pass


# Generated at 2022-06-25 13:06:55.955520
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_case_0()


# Generated at 2022-06-25 13:06:57.696085
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    str_0 = ';l'
    obj_0 = _ABCSingleton(str_0)


# Generated at 2022-06-25 13:07:01.084254
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    singleton_0 = _ABCSingleton
    assert isinstance(singleton_0, Singleton) == True
    assert isinstance(singleton_0, ABCMeta) == True


# Generated at 2022-06-25 13:08:43.005164
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    str_0 = ';l'
    global_c_l_i_args_0 = GlobalCLIArgs(str_0)


# Generated at 2022-06-25 13:08:46.917130
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    s = 'a;lsdkfl;asldkfj'
    print(s)
    c_l_i_args_0 = CLIArgs(s)
    assert(c_l_i_args_0)
    print(c_l_i_args_0)


# Generated at 2022-06-25 13:08:48.207689
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    a = CLIArgs
    print(a)


# Generated at 2022-06-25 13:08:51.573930
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    str_0 = 'abc'
    options_0 = cliargs.from_options(str_0)

if __name__ == '__main__':
    test_GlobalCLIArgs()

# Generated at 2022-06-25 13:08:52.453680
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    pass


# Generated at 2022-06-25 13:08:53.333561
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    test_case_0()

# Generated at 2022-06-25 13:08:56.568542
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # test construction
    assert isinstance(GlobalCLIArgs, Container)
    assert isinstance(GlobalCLIArgs, Mapping)
    assert not isinstance(GlobalCLIArgs, Sequence)
    assert not isinstance(GlobalCLIArgs, Set)

# Generated at 2022-06-25 13:09:04.143290
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Test with class
    class SingletonClass(_ABCSingleton):
        pass

    # Test with function
    def function(*args, **kwargs):
        return _ABCSingleton(*args, **kwargs)

    # Test with instance of class
    SingletonInstance = SingletonClass()

    # Test with instance of function
    functionInstance = function()

    # Test with lambda
    lambda_ = lambda *args, **kwargs: _ABCSingleton(*args, **kwargs)

    # Test with method
    def method(self, *args, **kwargs):
        return _ABCSingleton(*args, **kwargs)

    # Test with object
    class SomeClass(object):
        pass
    obj = SomeClass()

    # Test with type
    type_ = type('newtype', (object,), dict(x=5))

   

# Generated at 2022-06-25 13:09:05.997988
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    str_0 = ';l'
    c_l_i_args_0 = CLIArgs(str_0)
    assert c_l_i_args_0.items() == {}



# Generated at 2022-06-25 13:09:07.361974
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    str_0 = ';l'
    c_l_i_args_0 = CLIArgs(str_0)
