

# Generated at 2022-06-11 17:45:05.676298
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ClassA(object):
        pass

    class ClassB(object):
        pass

    class TestClass1(ClassA, _ABCSingleton):
        pass

    class TestClass2(ClassA, TestClass1):
        pass

    class TestClass3(ClassB, TestClass1):
        pass

    assert TestClass1 is TestClass1() is TestClass1()
    assert TestClass2 is TestClass2() is TestClass2()
    assert TestClass3 is TestClass3() is TestClass3()
    assert TestClass1 is not TestClass2
    assert TestClass1 is not TestClass3

# Generated at 2022-06-11 17:45:17.213685
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs.from_options(options)
    assert isinstance(args, GlobalCLIArgs)
    assert args.get("module_name") == "options_test_module"
    assert args.get("module_path") == "options_test_module"
    assert args.get("test_id") == "test_id"
    assert args.get("user") == "swift_storage"
    assert args.get("become") == True
    assert args.get("become_method") == "sudo"
    assert args.get("become_user") == "root"
    assert args.get("check") == True
    assert args.get("listhosts") == False
    assert args.get("listtasks") == False
    assert args.get("listtags") == False

# Generated at 2022-06-11 17:45:24.345591
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import HAS_PYTHON26, HAS_PYTHON27
    from ansible.module_utils.six import iteritems

    import optparse
    parser = optparse.OptionParser()

    parser.add_option('--test-opt-strs', dest='test_opt_strs', default=[], action='append',
                      type='str', help='Add a string to a list of strings')
    parser.add_option('--test-opt-dict', dest='test_opt_dict', default={}, action='append',
                      type='str', help='Add a key=value to a dictionary')
    parser.add_option('--test-opt-str', dest='test_opt_str', default=None,
                      type='str', help='A string')
    parser.add_option

# Generated at 2022-06-11 17:45:31.824984
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    a = CLIArgs({'a': 1, 'b': [1, 3, 4, 5], 'c': {'x': 2, 'y': [1, 2, 3]}})
    assert a['a'] == 1
    assert a['b'] == (1, 3, 4, 5)
    assert a['c']['x'] == 2
    assert a['c']['y'] == (1, 2, 3)



# Generated at 2022-06-11 17:45:41.407385
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    correct_type = ImmutableDict
    args_dict = {'str_flag': 'str', 'int_flag': 1, 'list_flag': [1, 2, 3]}
    args = CLIArgs(args_dict)
    assert isinstance(args, correct_type)
    assert len(args) == len(args_dict)
    # Check that the str flag is a string
    assert isinstance(args['str_flag'], text_type)
    # Check that the int flag is a string
    assert isinstance(args['int_flag'], int)
    for test_item in args['list_flag']:
        # Check that the list flag contains ints
        assert isinstance(test_item, int)

# Generated at 2022-06-11 17:45:46.250234
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        def __init__(self):
            self.var1 = 'foo'
            self.var2 = 'bar'

    options = Options()

    cli_args = GlobalCLIArgs.from_options(options)
    assert cli_args['var1'] == 'foo'
    assert cli_args['var2'] == 'bar'

# Generated at 2022-06-11 17:45:49.225255
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({'foo': 'bar'})
    assert CLIArgs({'foo': ['bar', 'baz']})
    assert CLIArgs({'foo': {'bar': 'baz'}})

# Generated at 2022-06-11 17:46:00.541310
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = {}
    args['inventory'] = '/path/to/inventory'
    args['listhosts'] = False
    args['listtasks'] = False
    args['listtags'] = False
    args['syntax'] = False
    args['connection'] = 'ssh'
    args['module_path'] = None
    args['pacman'] = 'smart'
    args['timeout'] = 10
    args['private_key_file'] = None
    args['remote_user'] = 'root'
    args['ask_pass'] = False
    args['ask_sudo_pass'] = False
    args['ask_su_pass'] = False
    args['verbosity'] = 0
    args['check'] = False
    args['tree'] = None
    args['diff'] = False
    args['force_handlers'] = False
   

# Generated at 2022-06-11 17:46:11.704464
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test GlobalCLIArgs constructor
    """
    dict_compat = {'test': 0}
    cli_args = GlobalCLIArgs(dict_compat)

    # Test that setitem raises an exception
    try:
        cli_args['test'] = 1
    except TypeError as e:
        assert 'cannot assign' in text_type(e)
        assert 'GlobalCLIArgs' in text_type(e)
        assert 'immutable' in text_type(e)

    # Test that delitem raises an exception
    try:
        del cli_args['test']
    except TypeError as e:
        assert 'cannot delete' in text_type(e)
        assert 'GlobalCLIArgs' in text_type(e)
        assert 'immutable' in text_type(e)



# Generated at 2022-06-11 17:46:17.078500
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = ImmutableDict({"a": 1, "b": dict(c=dict(d=10, e=20)), "f": (1, 2, 3), "g": [1, 2, 3]})
    cliarg = GlobalCLIArgs(args)
    assert hash(cliarg) == hash(args)

# Generated at 2022-06-11 17:46:21.044243
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ShouldBeSingleton(object):
        __metaclass__ = _ABCSingleton

    assert ShouldBeSingleton() is ShouldBeSingleton()

# Generated at 2022-06-11 17:46:30.483969
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-11 17:46:32.044208
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert GlobalCLIArgs is GlobalCLIArgs.instance()



# Generated at 2022-06-11 17:46:34.109092
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(metaclass=_ABCSingleton):
        pass
    assert False, "test__ABCSingleton: no tests implemented"

# Generated at 2022-06-11 17:46:44.737280
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common._collections_compat import MutableDict
    d = MutableDict()
    d.update({"test": "test_data"})
    try:
        d["test"] = "test_new_data"
    except TypeError:
        pass
    else:
        assert 0, "_make_immutable did not make dict immutable"

    d = GlobalCLIArgs.from_options(d)
    try:
        d["test"] = "test_new_data"
    except TypeError:
        pass
    else:
        assert 0, "GlobalCLIArgs() did not make dict immutable"

    try:
        d.update({"test_new_key": "test_new_data"})
    except TypeError:
        pass

# Generated at 2022-06-11 17:46:51.436234
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Note: This test is only run if -v is given on the command line.
    # See the "import ansible.constants" in lib/ansible/cli/...

    class ABCSingletonTest(object):
        __metaclass__ = _ABCSingleton
    another_abc_singleton = ABCSingletonTest()
    assert another_abc_singleton is ABCSingletonTest()
    assert another_abc_singleton is ABCSingletonTest()

# Generated at 2022-06-11 17:46:53.890137
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'foo': 'bar'})
    assert args['foo'] == 'bar'
    assert len(args) == 1
    assert isinstance(args, ImmutableDict)

# Generated at 2022-06-11 17:47:04.027492
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from collections import namedtuple
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    options = namedtuple('options', ['foo', 'bar', 'module_path'])
    opts = options(foo='one', bar='two', module_path='three')
    GlobalCLIArgs(vars(opts))

    # check that we can set the module_path argument, too
    opts = options(foo='one', bar='two', module_path=['three'])
    GlobalCLIArgs(vars(opts))

    # check that if module_path is a path that it gets added to the
    # existing collection_loader
    opts = options(foo='one', bar='two', module_path='four')
    GlobalCLIArgs(vars(opts))
    assert 'four' in AnsibleCollection

# Generated at 2022-06-11 17:47:07.884842
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Parent(object):
        pass

    class Child(Parent, metaclass=_ABCSingleton):
        pass

    assert issubclass(Child, Parent)
    assert isinstance(Child(), Parent)


# Generated at 2022-06-11 17:47:10.293689
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs({'a': 'b'})
    assert global_cli_args['a'] == 'b'

# Generated at 2022-06-11 17:47:14.915545
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    g1 = GlobalCLIArgs.get_instance({'foo': 1})
    g2 = GlobalCLIArgs.get_instance({'foo': 2})
    assert g1 == g2 == {'foo': 1}

# Generated at 2022-06-11 17:47:18.066043
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    CLIArgs.from_options({})
    CLIArgs.from_options(
        {'a': None, 'b': {'c': {'d': 'e'}, 'f': 'g'}, 'h': ['i', 'j']}
    )

# Generated at 2022-06-11 17:47:23.545616
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert not issubclass(A(), B)
    assert not issubclass(B(), A)


# Generated at 2022-06-11 17:47:26.407774
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ABCSingletonTest(metaclass=_ABCSingleton):
        pass

    # no exception should be raised
    ABCSingletonTest()
    ABCSingletonTest()

# Generated at 2022-06-11 17:47:29.008289
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = {'foo': {'bar': 'baz'}}
    parse = GlobalCLIArgs(args)
    assert parse['foo']['bar'] == 'baz'

# Generated at 2022-06-11 17:47:35.700020
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs.from_options({
        'foo': {'bar': ['baz', 'blam']},
    })
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, Mapping)
    assert isinstance(args, Singleton)
    assert isinstance(args, object)
    assert isinstance(args['foo'], ImmutableDict)
    assert isinstance(args['foo'], Mapping)
    assert isinstance(args['foo']['bar'], tuple)
    assert isinstance(args['foo']['bar'], Sequence)
    assert isinstance(args['foo']['bar'][0], text_type)
    assert isinstance(args['foo']['bar'][1], text_type)


# Generated at 2022-06-11 17:47:43.575621
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test1(object):
        __metaclass__ = _ABCSingleton

    class Test2(object):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            pass

    assert isinstance(Test1(), Test1)
    assert not isinstance(Test1(), Test2)
    assert isinstance(Test2(), Test2)
    assert not isinstance(Test2(), Test1)



# Generated at 2022-06-11 17:47:50.817226
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Unit test only, not to be run by ansible-test
    from ansible.module_utils._text import to_bytes

    # Mutable copy of what command line arguments look like
    input_dict = {
        'database': 'mysql',
        'connect_host': 'localhost',
        'connect_port': 3306,
        'log_path': '/var/log/ansible',
        'debug': False,
        'extra_python_path': ['/usr/lib/python3'],
        'extra_python_path_path': '/usr/lib/python3',
    }

    global_args = GlobalCLIArgs(input_dict)
    assert isinstance(global_args, GlobalCLIArgs)
    assert isinstance(global_args, CLIArgs)

    # It should be immutable

# Generated at 2022-06-11 17:47:52.722941
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert not GlobalCLIArgs.instance()
    GlobalCLIArgs(dict())
    assert GlobalCLIArgs.instance()

# Generated at 2022-06-11 17:47:56.913839
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Assert that only one object exists
    obj1 = GlobalCLIArgs()
    obj2 = GlobalCLIArgs.instance()
    assert obj1 is obj2

    # Assert that object is immutable
    obj1['test'] = 'test'
    with pytest.raises(TypeError):
        obj2['test'] = 'test'

# Generated at 2022-06-11 17:48:04.852942
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    actual = CLIArgs({'foo': {'bar': {'baz': ['quux', 'quuz']}}})
    expected = ImmutableDict({'foo': ImmutableDict({'bar': ImmutableDict({'baz': ('quux', 'quuz')})})})
    assert actual == expected

# Generated at 2022-06-11 17:48:11.709347
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import ansible.constants as C
    import ansible.module_utils.common.options as options

    # We do not know what GlobalCLIArgs is initialized to when we get to this point, so unset it.
    # If we do not unset it, then the next line with fail the second time it is run from the
    # same process.
    GlobalCLIArgs.__instance = None

    (options, args) = options.parser(constants=C).parse_args([])
    cli_args = GlobalCLIArgs.from_options(options)

    assert isinstance(cli_args, GlobalCLIArgs)
    assert cli_args is GlobalCLIArgs()

# Generated at 2022-06-11 17:48:14.275865
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    try:
        CLIArgs(dict(foo = 'bar'))
    except TypeError as e:
        assert 'is immutable' in str(e)

# Generated at 2022-06-11 17:48:22.191959
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from ansible.module_utils.common.parameters import load_params
    from ansible.module_utils.common.validation import check_type_bool
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_text
    # test GlobalCLIArgs.__init__
    args = dict(FORCE_COLOR=True)
    global_args = GlobalCLIArgs(args)
    assert global_args

    # test GlobalCLIArgs.__setitem__
    with pytest.raises(AttributeError):
        global_args["FORCE_COLOR"] = 1
    assert global_args

    # test GlobalCLIArgs.__delitem__

# Generated at 2022-06-11 17:48:29.696890
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        pass

    class B(object):
        pass

    class C(A):
        pass

    class D(object):
        __metaclass__ = _ABCSingleton

    class E(D):
        pass

    class F(D):
        pass

    assert isinstance(A(), A)
    assert isinstance(B(), B)

    assert isinstance(C(), A)
    assert isinstance(C(), C)

    assert isinstance(D(), D)
    assert isinstance(E(), D)
    assert isinstance(F(), D)

# Generated at 2022-06-11 17:48:38.389287
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections

    # Testing that we can pass in a dictionary and that it is made immutable.  This also tests
    # the immutability feature of the ImmutableDict class.
    kwds = {
        'a_dict': {1: 2, 3: 4},
        'a_list': [5, 6],
        'a_set': {5},
        'a_tuple': (7, 8),
        'a_str': '9',
        'a_int': 10,
        'a_list_of_dicts': [{11: 12}, {13: 14}, {15: 16}],
    }
    a_cli_args = CLIArgs(kwds)
    for key in kwds.keys():
        assert a_cli_args[key] == kwds[key]

    # Python 2 needs

# Generated at 2022-06-11 17:48:42.510254
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(metaclass=_ABCSingleton):
        pass

    class Bar(Foo, metaclass=_ABCSingleton):
        pass

    assert isinstance(Foo(), Foo)
    assert not isinstance(Bar(), Bar)
    assert isinstance(Bar(), Foo)

# Generated at 2022-06-11 17:48:53.788121
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    opt = CLIArgs({'text': 'this is a string', 'sequence': [1, 2, 3], 'mapping': {'map1': 1, 'map2': 2}, 'set': set([1,2,3]), 'bool': True})
    assert(opt.text == 'this is a string')
    assert(opt.sequence == (1, 2, 3))
    assert(opt.mapping == {'map1': 1, 'map2': 2})
    assert(opt.set == frozenset({1, 2, 3}))
    assert(opt.bool == True)

    assert(isinstance(opt.text, text_type))
    assert(isinstance(opt.sequence, tuple))
    assert(isinstance(opt.mapping, ImmutableDict))
    assert(isinstance(opt.set, frozenset))

# Generated at 2022-06-11 17:48:59.177762
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        def __init__(self):
            self.connection = 'local'
            self.some_default_value = 'some_value'
            self.one_more_default_value = {'name': 'some_dict_value'}

    options = Options()
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-11 17:49:03.424608
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
    first_instance = TestClass()
    second_instance = TestClass()
    assert(first_instance is second_instance)


__all__ = ['CLIArgs', 'GlobalCLIArgs']

# Generated at 2022-06-11 17:49:09.063130
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test1(object):
        __metaclass__ = _ABCSingleton
        pass

    class Test2(Test1):
        pass

    class Test3(Test1):
        pass

    assert Test1() is Test2() is Test3()

# Generated at 2022-06-11 17:49:11.847203
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        def __init__(self, a):
            self.a = a

    try:
        Test(1)
    except TypeError:
        pass
    else:
        assert False, 'Must raise TypeError'

# Generated at 2022-06-11 17:49:17.397432
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test simple case
    test_arg = CLIArgs({'key1': 'value1'})
    assert test_arg['key1'] == 'value1'

    # Test a more complex arg
    test_arg = CLIArgs({'key1': 'value1',
                        'key2': {'key1-1': 'value1-1'},
                        'key3': [1, 2, 3, 4]})
    assert test_arg['key2']['key1-1'] == 'value1-1'
    assert test_arg['key3'][1] == 2

    # Test that we can't mutate the CLIArgs object

# Generated at 2022-06-11 17:49:18.240874
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    pass

# Generated at 2022-06-11 17:49:20.942464
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    f1 = Foo()
    f2 = Foo()

    assert f1 is f2



# Generated at 2022-06-11 17:49:25.202796
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class GlobalCLIArgs(ImmutableDict, metaclass=_ABCSingleton):
        """
        A singleton version of CLIArgs
        """
        pass

    args = GlobalCLIArgs.from_options(_make_immutable({"verbose": 123}))
    assert args["verbose"] == 123

# Generated at 2022-06-11 17:49:28.767307
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test1(object):
        __metaclass__ = _ABCSingleton
    Test2 = _ABCSingleton('Test2', (), {})

    assert(Test1 is Test1())
    assert(Test2 is Test2())

# Generated at 2022-06-11 17:49:30.754181
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    obj = GlobalCLIArgs.from_options(object())
    assert isinstance(obj, ImmutableDict)

# Generated at 2022-06-11 17:49:38.419691
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert isinstance(CLIArgs({'key': 'value'}), ImmutableDict)
    assert isinstance(CLIArgs({'key': [1, 2, 3]}), ImmutableDict)
    assert isinstance(CLIArgs({'key': {'subkey': 'subvalue'}}), ImmutableDict)
    assert isinstance(CLIArgs({'key': {'subkey': [1, 2]}}), ImmutableDict)
    assert isinstance(CLIArgs({'key': {'subkey': {'subsubkey': 'subsubvalue'}}}), ImmutableDict)
    assert isinstance(CLIArgs({'key': {'subkey': {'subsubkey': [1, 2]}}}), ImmutableDict)

# Generated at 2022-06-11 17:49:43.005807
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs({'foo': 'bar', 'mingle': ['a', 'b'], 'dingle': {'key': 'value'}})
    assert cli_args['foo'] == 'bar'
    assert cli_args['mingle'][0] == 'a'
    assert cli_args['dingle']['key'] == 'value'

# Generated at 2022-06-11 17:49:55.442564
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # We should be able to handle str, list, and dict
    input_arg = {'name': 'value', 'name_list': ['value', 'value2'], 'name_dict': {'key': 'value'}}
    cli_arg = CLIArgs(input_arg)
    assert cli_arg.name == 'value'
    assert cli_arg.name_list == ['value', 'value2']
    assert cli_arg.name_dict.key == 'value'


# Generated at 2022-06-11 17:50:00.547947
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args_dict = {'dest': 'world', 'greeting': 'hello'}
    instance1 = CLIArgs(args_dict)
    assert id(instance1) != id(args_dict)
    assert instance1 == args_dict
    args_dict['hello'] = 'world'
    assert instance1 == {'dest': 'world', 'greeting': 'hello'}


# Generated at 2022-06-11 17:50:08.462705
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class one(metaclass=_ABCSingleton):
        def __init__(self):
            self.x = 1
    class two(metaclass=_ABCSingleton):
        def __init__(self):
            self.x = 2
    assert one() == one()
    assert one() is one()
    assert one().x == 1
    assert two() == two()
    assert two() is two()
    assert two().x == 2
    assert one() is not two()


# Generated at 2022-06-11 17:50:19.797380
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # test_CLI_args_init
    options = MockOptions()
    args = CLIArgs.from_options(options)
    assert isinstance(args, CLIArgs)
    assert isinstance(args, Mapping)
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, Container)
    assert not isinstance(args, Set)
    assert not isinstance(args, Sequence)

    # test_CLI_args_make_immutable
    options = MockOptions()
    args = CLIArgs.from_options(options)
    assert isinstance(args, CLIArgs)
    assert isinstance(args['verbosity'], int)
    assert isinstance(args['ssh_extra_args'], tuple)
    assert isinstance(args['module_args'], tuple)

# Generated at 2022-06-11 17:50:26.039190
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Test for __new__
    class Foo(_ABCSingleton):
        pass
    class Bar(_ABCSingleton):
        pass
    class Baz(_ABCSingleton):
        pass
    one = Foo()
    two = Foo()
    three = Bar()
    assert one is two
    assert one is not three
    assert two is not three
    assert isinstance(one, Foo)
    assert isinstance(two, Foo)
    assert isinstance(three, Bar)
    four = Baz()
    five = Baz()
    assert four is five
    assert four is not one
    assert four is not two
    assert four is not three
    assert five is not one
    assert five is not two
    assert five is not three

# Generated at 2022-06-11 17:50:29.610034
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest

    args = {'foo': 'bar'}

    # Test that CLIArgs is called and converted to an ImmutableDict
    with pytest.raises(AttributeError):
        GlobalCLIArgs(args)

# Generated at 2022-06-11 17:50:31.192204
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABCSingletonTest(metaclass=_ABCSingleton):
        pass

# Generated at 2022-06-11 17:50:34.561149
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() == B() == C() == A()

# Generated at 2022-06-11 17:50:42.463437
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys

    # get command line args and prepare them
    cmd_line_args = sys.argv
    if cmd_line_args:
        if cmd_line_args[0].endswith('ansible-config'):
            cmd_line_args.pop(0)
        cmd_line_args.insert(0, 'ansible-config')

    # prepare options to pass CLIArgs constructor
    options = dict()
    for arg in cmd_line_args:
        if arg.startswith('-'):
            options[arg] = arg
        else:
            options[arg] = arg.upper()

    # create CLIArgs object and test it
    args = CLIArgs.from_options(options)
    assert all(arg in args for arg in cmd_line_args[1:])

# Generated at 2022-06-11 17:50:52.455448
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test GlobalCLIArgs.  This function is not run as a unit test and is only included here to provide
    an example of how to use GlobalCLIArgs.
    """
    from ansible.module_utils.common.collections import (
        ImmutableDict,
        ImmutableList,
    )

    # Dict with only strings with string key
    args_dict = {
        'value': 'string',
    }
    # Dict with only strings with int key
    args_dict_int_key = {
        1: 'string',
    }
    # Dict with dict and string with string key
    args_dict_nested1 = {
        'value': 'string',
        'nested_dict': {
            'value': 'string',
        }
    }
    # Dict with tuple and string

# Generated at 2022-06-11 17:51:04.628988
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass1(object):
        __metaclass__ = _ABCSingleton
        pass
    
    class TestClass2(object):
        __metaclass__ = _ABCSingleton
        pass
    
    assert TestClass1 is TestClass2

# Generated at 2022-06-11 17:51:16.014746
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test construction of CLIArgs
    """
    # Test that an empty dictionary can be constructed into a CLIArgs object
    CLIArgs({})

    # Test that a normal dictionary can be constructed into a CLIArgs object
    dict1 = {"key1": "value1"}
    cli_args = CLIArgs(dict1)
    assert cli_args == CLIArgs(dict1)

    # Test that a nested list can be constructed into a CLIArgs object
    dict2 = {"key1": "value1", "key2": ["value2", "value3"]}
    cli_args = CLIArgs(dict2)
    assert cli_args == CLIArgs(dict2)

    # Test that a nested dictionary can be constructed into a CLIArgs object

# Generated at 2022-06-11 17:51:17.757999
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = ['--version', '--help']
    GlobalCLIArgs.set(args)
    assert GlobalCLIArgs.get() == args


# Generated at 2022-06-11 17:51:23.063707
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({'a': {'b': {'c': 1}}})
    assert isinstance(args, GlobalCLIArgs)
    assert isinstance(args, CLIArgs)
    assert isinstance(args['a'], ImmutableDict)
    assert isinstance(args['a']['b'], ImmutableDict)
    assert isinstance(args['a']['b']['c'], int)

# Generated at 2022-06-11 17:51:33.505396
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # pylint: disable=redefined-outer-name
    import sys

    a = CLIArgs(dict(foo=42, bar=43))
    try:
        a['foo'] = 24
    except TypeError:
        if sys.version_info[0] == 2:
            assert True
        else:
            assert False, "Assignment should not fail for python3"
    else:
        assert False, "Assignment should fail for python2"

    try:
        del a['foo']
    except TypeError:
        if sys.version_info[0] == 2:
            assert True
        else:
            assert False, "Deletion should not fail for python3"
    else:
        assert False, "Deletion should fail for python2"

# Generated at 2022-06-11 17:51:35.424961
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    g = GlobalCLIArgs.from_options(CLIArgs.from_options(ImmutableDict()))

# Generated at 2022-06-11 17:51:39.171905
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Check we made an instance of GlobalCLIArgs
    assert isinstance(GlobalCLIArgs(), GlobalCLIArgs)

    # Check we only made one instance of GlobalCLIArgs
    assert GlobalCLIArgs() is GlobalCLIArgs()

# Generated at 2022-06-11 17:51:42.244223
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    _GlobalCLIArgs = GlobalCLIArgs({'key1': 'value1', 'key2': 'value2'})
    assert not _GlobalCLIArgs['key1'] == 'value1'

# Generated at 2022-06-11 17:51:47.578855
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class Foobar(object):
        __metaclass__ = _ABCSingleton

    class Foobar(Foobar):
        def __init__(self, f, b):
            self.f = f
            self.b = b

    class FoobarException(Exception):
        pass

    f = Foobar(1, 2)
    g = Foobar(3, 4)

    if id(f) != id(g):
        raise FoobarException

# Generated at 2022-06-11 17:51:59.768230
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import ansible.constants as C
    from collections import OrderedDict
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

    display = Display()
    display.verbosity = 0
    C.DEFAULT_LOG_PATH = '/dev/null'
    C.DEFAULT_LOG_FILE_LOG_PATH = False
    C.DEFAULT_FORKS = 10
    C.DEFAULT_REMOTE_TMP = '/tmp'
    C.DEFAULT_LOCAL_TMP = '/tmp'
    C.DEFAULT_PATTERN = '*'
    C.DEFAULT_MODULE_NAME = 'command'
    C.DEFAULT_MODULE_PATH = None
    C.DEFAULT_KEEP_REMOTE_FILES = False


# Generated at 2022-06-11 17:52:27.942095
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    import tempfile
    import shutil
    import os

    # Copy the test run's environment variables so we can restore them later.
    old_environment = os.environ.copy()

    # Create a temp directory to store our test fixture.
    temp_dir = tempfile.mkdtemp()

    # Always clean up after ourselves.
    def cleanup_temp_dir():
        if os.path.isdir(temp_dir):
            shutil.rmtree(temp_dir)
    request.addfinalizer(cleanup_temp_dir)

    # Copy our test fixture into place.
    fixture_dir = 'test/integration/fixtures/test_connection/connection_with_args'

# Generated at 2022-06-11 17:52:34.564146
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    new_args = GlobalCLIArgs.from_options(test_options)
    assert isinstance(new_args, GlobalCLIArgs)
    assert new_args.get('name', None) == 'foo'
    assert new_args.get('bar', None) == 'bax'
    assert new_args.get('baz', None) == [1, 2, 3]
    # Test defaults
    assert new_args.get('test', None) is None

# Unit tests for GlobalCLIArgs can't be made as it is a singleton
# and following line causes a failure
# assert isinstance(GlobalCLIArgs(test_options), GlobalCLIArgs)


# Generated at 2022-06-11 17:52:37.448171
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _TestSingletonClass(object):
        __metaclass__ = _ABCSingleton

    obj1 = _TestSingletonClass()
    obj2 = _TestSingletonClass()
    assert obj1 == obj2

# Generated at 2022-06-11 17:52:41.397586
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ExampleABCSingleton(object):
        __metaclass__ = _ABCSingleton

    class ExampleABCSingletonSubclass(ExampleABCSingleton):
        pass

    instance = ExampleABCSingleton()
    instance_subclass = ExampleABCSingletonSubclass()

    assert instance is instance_subclass

# Generated at 2022-06-11 17:52:43.903793
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class C(GlobalCLIArgs):
        pass
    C(dict(a=1, b=2))


# Generated at 2022-06-11 17:52:53.777204
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import os
    import sys
    from ansible.cli import CLI
    from ansible.parsing.dataloader import DataLoader

    curdir = os.path.dirname(__file__)
    sys.path.insert(0, os.path.join(curdir, 'lib'))

    cli = CLI(['dummy1', 'dummy2'])
    cli.options = cli.base_parser()
    cli.options.connection = "local"
    cli.options.module_path = None
    cli.options.forks = 1
    cli.options.private_key_file = '/dev/null'
    cli.options.remote_user = 'root'
    cli.options.ask_pass = False
    cli.options.verbosity = 0
    cli

# Generated at 2022-06-11 17:52:59.982490
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # So this is a bit weird as we are testing that the __ABCSingleton class can be instantiated.
    # But this is necessary as the metaclass's __new__ will raise an exception if the class being
    # instantiated doesn't have the magic name we expect.
    _ABCSingleton('_ABCSingletonClassName', (object,), {})



# Generated at 2022-06-11 17:53:08.207031
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class opts(object):
        def __init__(self, **kwargs):
            if 'null_val' in kwargs:
                self.null_val = kwargs['null_val']
                self.null_val_type = type(kwargs['null_val'])
            if 'bool_val' in kwargs:
                self.bool_val = kwargs['bool_val']
                self.bool_val_type = type(kwargs['bool_val'])
            if 'str_val' in kwargs:
                self.str_val = kwargs['str_val']
                self.str_val_type = type(kwargs['str_val'])
            if 'int_val' in kwargs:
                self.int_val = kwargs['int_val']
                self

# Generated at 2022-06-11 17:53:14.083566
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = {'key1': 'value1', 'key2': 'value2'}
    cli_args = GlobalCLIArgs(args)

    assert len(cli_args) == 2
    assert isinstance(cli_args['key1'], text_type)
    assert isinstance(cli_args['key2'], text_type)


# Generated at 2022-06-11 17:53:22.190727
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-11 17:54:03.030203
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    foo = GlobalCLIArgs({'bar': 5})
    assert isinstance(foo, GlobalCLIArgs)
    assert isinstance(foo['bar'], int)
    assert foo['bar'] == 5

# Generated at 2022-06-11 17:54:11.702718
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.cli import CLI

    test_collections = []
    for collections_path in AnsibleCollectionLoader.get_collections_paths(command_line=CLI(args=['--collections-path', './lib/ansible/collections/']).parse()):
        test_collections.extend([entry.path for entry in collections_path.iterdir()])

    loader = DataLoader()
    loader.set_basedir('.')
    options = CLI(['-vvvv', '-c', 'local', '-m', 'ping', 'localhost'],
                  collections_paths=test_collections).parse()

# Generated at 2022-06-11 17:54:16.497630
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--test-option', default='test-option')

# Generated at 2022-06-11 17:54:26.102967
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    data = {'foo': 'bar',
            'bam': True,
            'bar': None,
            'baz': {'xyzzy': 123},
            'plugh': ('hello', 'world'),
            'quux': {'foo', 'bar', 'baz'}}

    cli_args = CLIArgs(data)

    assert isinstance(cli_args, ImmutableDict)
    assert cli_args == data
    assert cli_args['foo'] == 'bar'
    assert cli_args['bam'] is True
    assert cli_args['bar'] is None
    assert cli_args['baz'] == {'xyzzy': 123}
    assert cli_args['plugh'] == ('hello', 'world')

# Generated at 2022-06-11 17:54:32.150947
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Make sure we can hold a singleton of our new class
    """
    class SingletonClass(_ABCSingleton):
        pass

    # Two of these should point to the same underlying object
    singleton_1 = SingletonClass()
    singleton_2 = SingletonClass()

    assert singleton_1 is singleton_2, "singleton_2 is not the same object as singleton_1"

# Generated at 2022-06-11 17:54:33.123573
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({})


# Generated at 2022-06-11 17:54:34.853444
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from types import TypeType
    class Foo(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(Foo, TypeType)

# Generated at 2022-06-11 17:54:42.728595
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {
        'k1': 'v1',
        'k2': 2,
        'k3': {},
        'k4': [],
        'k5': {'kn1': [], 'kn2': {}},
        'k6': [{'kn1': 'vn1'}, {'kn2': 'vn2'}],
    }
    cliargs = CLIArgs(mapping)
    assert cliargs == mapping
    assert isinstance(cliargs['k3'], ImmutableDict)
    assert isinstance(cliargs['k4'], tuple)
    assert isinstance(cliargs['k5'], ImmutableDict)
    assert isinstance(cliargs['k6'], tuple)
    assert isinstance(cliargs['k5']['kn1'], frozenset)


# Generated at 2022-06-11 17:54:47.462727
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    instance = GlobalCLIArgs({'a': 1, 'b': 2, 'c': 3})
    assert instance['a'] == 1
    assert instance['b'] == 2
    assert instance['c'] == 3
    instance['a'] = 4
    assert instance['a'] == 1


# Generated at 2022-06-11 17:54:55.885989
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_object = {
        'test_key1': 'test_value1',
        'test_key2': 'test_value2'
    }
    test_object = CLIArgs(test_object)
    assert isinstance(test_object, ImmutableDict)
    assert isinstance(test_object, Mapping)
    assert isinstance(test_object['test_key1'], text_type)
    assert isinstance(test_object['test_key2'], text_type)
    assert test_object['test_key1'] == 'test_value1'
    assert test_object['test_key2'] == 'test_value2'
    assert test_object.get('test_key1') == 'test_value1'
    assert test_object.get('test_key2') == 'test_value2'
