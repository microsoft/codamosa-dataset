

# Generated at 2022-06-11 17:45:04.755352
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    d = dict(a=1, b="hello", c=[1, 2, 3], d={2, 3, 4})
    o = CLIArgs(d)
    assert o == ImmutableDict(d)

# Generated at 2022-06-11 17:45:15.602284
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Tests whether the constructor of class GlobalCLIArgs behaves as required"""
    import sys
    import os
    import unittest

    class test_GlobalCLIArgs(unittest.TestCase):
        """Test the constructor of class GlobalCLIArgs"""
        def test_empty(self):
            """Test the constructor of class GlobalCLIArgs, while passing no parameters"""
            self.assertIsNone(GlobalCLIArgs())
        def test_parameter(self):
            """Test the constructor of class GlobalCLIArgs, while passing a parameter"""
            self.assertIsNotNone(GlobalCLIArgs({'key': 'value'}))
        def test_mutable_type(self):
            """Test the constructor of class GlobalCLIArgs, while passing an immutable type"""

# Generated at 2022-06-11 17:45:17.851155
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    i = GlobalCLIArgs.from_options({'a': 1})
    assert i == {'a': 1}

# Generated at 2022-06-11 17:45:23.128636
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    class MyCLIArgs(CLIArgs):
        pass

    my_cli_args = MyCLIArgs({'a': 1, 'b': {'c': 3, 'd': [4, 5]}, 'e': [6, [7, 8]]})

    assert my_cli_args['a'] == 1
    assert set(my_cli_args['b'].items()) == {('d', (4, 5)), ('c', 3)}
    assert set(my_cli_args['e']) == {6, (7, 8)}

# Generated at 2022-06-11 17:45:31.764831
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Test that the _ABCSingleton constructor works.

    This class is not for directly testing, but for being inherited from,
    so we only do a basic test of its constructor here.
    """
    class TestSingleton(_ABCSingleton):
        """A singleton for testing the _ABCSingleton metaclass."""
        def __init__(self, value):
            self.value = value
    singleton = TestSingleton(1)
    singleton_duplicate = TestSingleton(2)
    assert singleton == singleton_duplicate

# Generated at 2022-06-11 17:45:36.383271
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs(dict(a=1, b=dict(c=[1,2,3])))
    assert isinstance(args, ImmutableDict)
    assert isinstance(args['b'], ImmutableDict)
    assert isinstance(args['b']['c'], tuple)

# Generated at 2022-06-11 17:45:44.830567
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test to see if any two imports result in two different objects

    We should never have more than a single GlobalCLIArgs object.  This is because there is only
    ever one set of global command line args.  We test to see if importing from different modules
    result in multiple objects.
    """
    mod1 = __import__('ansible.config.cli_args', fromlist=['GlobalCLIArgs'])
    mod2 = __import__('ansible.module_utils.common.config', fromlist=['GlobalCLIArgs'])

    global_cli_args1 = mod1.GlobalCLIArgs()
    global_cli_args2 = mod2.GlobalCLIArgs()

    assert global_cli_args1 is global_cli_args2


# Generated at 2022-06-11 17:45:47.149356
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert isinstance(GlobalCLIArgs(), GlobalCLIArgs)
    assert id(GlobalCLIArgs()) == id(GlobalCLIArgs())

# Generated at 2022-06-11 17:45:51.461985
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--foo", default="default foo", type=str)
    args = parser.parse_args(["--foo", "args foo"])
    assert GlobalCLIArgs.from_options(args) == ImmutableDict({"foo": "args foo"})
    assert isinstance(GlobalCLIArgs(), GlobalCLIArgs)

# Generated at 2022-06-11 17:46:01.746343
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = GlobalCLIArgs._GlobalCLIArgs__instance = object()

    class FakeOptions(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    # Store a set of command line arguments and make sure they get converted to the appropriate
    # formats.  Ideally, we would also check that they were converted to an ImmutableDict, but
    # we can't do that because ImmutableDict is a Singleton too and lets us set attributes, making
    # this test fail.

# Generated at 2022-06-11 17:46:13.111799
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Create test CLIArgs object
    test_class = CLIArgs({
        'foo': 'bar',
        'baz': ['qux', 'quxx'],
        'corge': {
            'grault': 2,
            'garply': [
                'waldo',
                'fred',
                {'plugh': 'thud'}
            ]
        }
    })

    # test_class should be an ImmutableDict
    assert isinstance(test_class, ImmutableDict)

    # Test for correct return type of values
    assert isinstance(test_class['foo'], text_type)
    assert isinstance(test_class['baz'], tuple)
    assert isinstance(test_class['baz'][0], text_type)

# Generated at 2022-06-11 17:46:17.793851
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    gca1 = GlobalCLIArgs.__new__(GlobalCLIArgs)
    gca2 = GlobalCLIArgs.__new__(GlobalCLIArgs)
    assert gca1 == gca2
    assert id(gca1) == id(gca2)

# Generated at 2022-06-11 17:46:21.854856
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class CLIOpts(object):
        def __init__(self, argv):
            self.argv = argv

    args = CLIOpts(['a', 'b', 'c'])
    assert sorted(GlobalCLIArgs.from_options(args).keys()) == ['argv']

# Generated at 2022-06-11 17:46:26.067639
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class test_class_1(object):
        pass

    class test_class_2(test_class_1):
        pass

    assert test_class_2.__mro__[1] is _ABCSingleton
    assert test_class_2.__mro__[2] is test_class_1

# Generated at 2022-06-11 17:46:33.967052
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    a = CLIArgs({'a': 'b'})
    assert a == {'a': 'b'}
    assert a['a'] == 'b'
    a = CLIArgs({'a': {'b': 'c'}})
    assert a == {'a': {'b': 'c'}}
    assert a['a'] == {'b': 'c'}
    assert a['a']['b'] == 'c'
    a = CLIArgs({'a': ['b', {'c': 'd'}]})
    assert a == {'a': ('b', {'c': 'd'})}
    assert a['a'] == ('b', {'c': 'd'})
    assert a['a'][1] == {'c': 'd'}
    assert a['a'][1]['c']

# Generated at 2022-06-11 17:46:44.594537
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class AdHocOptions(object):
        pass

    # Make a mapping of options
    options = AdHocOptions()
    options.private_data_dir = 'look_under_this_dir_for_ssh_keys'
    options.verbosity = 2
    options.verbose = True
    options.color = 'always'
    options.connection = 'ssh'
    options.remote_user = 'me'
    options.connection_user = 'me'
    options.inventory = []
    options.inventory_path = []
    options.inventory_hostnames = []
    options.hostname = 'test_hostname'
    options.host_pattern = 'test_host_pattern'
    options.user = 'test_user'
    options.module = []
    options.module_path = []

# Generated at 2022-06-11 17:46:54.721461
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from datetime import date
    import dateutil.parser

    start_date = date(2017, 1, 1)
    end_date = date(2017, 1, 31)

    args = CLIArgs({'start_date': start_date, 'end_date': end_date})

    assert args['start_date'] == dateutil.parser.parse('2017-01-01T00:00:00')
    assert args['end_date'] == dateutil.parser.parse('2017-01-31T00:00:00')

    # Expect to see an error when I try to make the dict mutable
    try:
        args['start_date'] = 'mutable'
        raise AssertionError('Should not be able to mutate dict')
    except TypeError:
        pass


# Generated at 2022-06-11 17:46:56.665945
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    result = CLIArgs({'testkey': 'test'})
    True

# Generated at 2022-06-11 17:47:00.642358
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABCSingleton(_ABCSingleton): pass
    class TestABCSingletonB(TestABCSingleton): pass
    assert(type(TestABCSingleton()) is TestABCSingleton)
    assert(type(TestABCSingletonB()) is TestABCSingletonB)



# Generated at 2022-06-11 17:47:08.987270
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_args = {
        'text_type': text_type,
        'binary_type': binary_type,
        'Mapping': Mapping,
        'Set': Set,
        'Sequence': Sequence,
    }
    cli_args = CLIArgs(test_args)
    assert cli_args['text_type'] == text_type
    assert cli_args['binary_type'] == binary_type
    assert cli_args['Mapping'] == Mapping
    assert cli_args['Set'] == Set
    assert cli_args['Sequence'] == Sequence

# Generated at 2022-06-11 17:47:11.949051
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert GlobalCLIArgs({})

# Generated at 2022-06-11 17:47:15.396890
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()


# Generated at 2022-06-11 17:47:22.601518
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import json
    import os
    import tempfile

    fileobj, path = tempfile.mkstemp()
    os.close(fileobj)
    try:
        with open(path, 'w') as fileobj:
            json.dump({'a': [1, 2, 3], 'b': {'c': 'd'}}, fileobj)

        GlobalCLIArgs.from_options(ImmutableDict({'extra_vars': '@' + path}))

        # Check that we created immutable objects
        assert not isinstance(GlobalCLIArgs()['extra_vars']['b'], MutableMapping)
        assert not isinstance(GlobalCLIArgs()['extra_vars']['a'], MutableSequence)
    finally:
        os.remove(path)

# Generated at 2022-06-11 17:47:23.886043
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    b = GlobalCLIArgs({'mykey': 'myvalue'})
    assert b == {'mykey': 'myvalue'}


# Generated at 2022-06-11 17:47:32.785562
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class options(object):
        def __init__(self, option_list):
            for k, v in option_list:
                setattr(self, k, v)

    # Sample option list, note that some of the values are nested containers
    option_list = [('check', True), ('verbose', 3), ('inventory', ['a', ['b', 'c']])]

    # Create an instance of GlobalCLIArgs
    args = GlobalCLIArgs.from_options(options(option_list))

    # Assert that the instance of this class is a singleton
    assert GlobalCLIArgs() is args

    # Assert that the instance of this class is an ImmutableDict
    assert isinstance(args, ImmutableDict)

    # Assert that the instance of this class is a Mapping

# Generated at 2022-06-11 17:47:33.460109
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    pass

# Generated at 2022-06-11 17:47:35.899312
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert isinstance(GlobalCLIArgs(), GlobalCLIArgs)
    assert isinstance(type(GlobalCLIArgs()), GlobalCLIArgs)

# Generated at 2022-06-11 17:47:47.578774
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Test GlobalCLIArgs"""

    import argparse
    from ansible.utils.collection_loader import AnsibleCollectionLoader

    args_tuple = (('-i', ''), '-m', 'ping', 'example.com')
    args_dict = {'-i': '', '-m': 'ping', 'example.com': None}
    parser = argparse.ArgumentParser()
    parser.add_argument('-i')  # without default
    parser.add_argument('-m', default='shell')  # with default
    parser.add_argument('args', nargs='*', default=[])  # args = peers to modules, plays, etc.
    options = parser.parse_args(args_tuple[0:2])
    args = parser.parse_args(args_tuple[2:])

# Generated at 2022-06-11 17:47:49.073625
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs.from_options(ImmutableDict(abc='abc'))

# Generated at 2022-06-11 17:47:58.496320
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.vars import combine_vars
    import ansible.constants as C
    opts = ImmutableDict(C.CONFIG_OPTIONS)
    opts2 = ImmutableDict(C.COMMAND_LINE_OPTIONS)

# Generated at 2022-06-11 17:48:08.283106
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({})


# Generated at 2022-06-11 17:48:18.743557
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import pytest
    from ansible.utils.vars import combine_vars
    from ansible.parsing.vault import VaultLib, VaultSecret
    from collections import namedtuple


# Generated at 2022-06-11 17:48:26.433036
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    This is a unit test for the class _ABCSingleton.  Since the class has a rather strange feature,
    we want to make sure that it's working as intended.

    This will fail if we cannot create a Class, A, that subclassed a Singleton that itself
    subclassed an ABCMeta based class, B.
    """

    class ClassB(object):
        __metaclass__ = _ABCSingleton

    class ClassA(ClassB):
        pass

    # We should have been able to create a ClassA, so this should not throw an exception
    return

# Generated at 2022-06-11 17:48:30.527190
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class O(object):
        __metaclass__ = _ABCSingleton
    class O2(object):
        __metaclass__ = _ABCSingleton
    try:
        class O3(O):
            pass
    except TypeError:
        assert False
    o = O()
    o2 = O2()
    o3 = O3()
    assert(o3 is o3)

# Generated at 2022-06-11 17:48:33.679862
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

# Generated at 2022-06-11 17:48:37.347627
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Unit test for constructor of class CLIArgs

    Tests whether the class can be constructed without failure
    """
    args = CLIArgs({"hello": "world"})
    assert args["hello"] == "world"


# Generated at 2022-06-11 17:48:45.827813
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Run tests against GlobalCLIArgs to ensure that it does behave like a Singleton.
    Also test to see if additional values are added to the GlobalCLIArgs instance
    """
    GlobalCLIArgs()['testing'] = 'data'
    compare = GlobalCLIArgs()['testing']
    assert compare == 'data'
    assert GlobalCLIArgs()['testing'] == 'data'

    # Make sure that GlobalCLIArgs is a singleton by testing if it has the same ID as any other copy
    copy_1 = GlobalCLIArgs()
    copy_2 = GlobalCLIArgs()
    assert id(copy_1) == id(copy_2)
    assert id(copy_1) == id(compare)

# Generated at 2022-06-11 17:48:51.592044
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    class Bar(Foo):
        pass

    class Baz(Bar):
        pass

    assert Foo() is Foo()
    assert Bar() is Bar()
    assert Baz() is Baz()

    assert Foo() is Bar()
    assert Foo() is Baz()
    assert Bar() is Baz()

# Generated at 2022-06-11 17:48:56.196439
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Ensure it behaves like a singleton
    # See https://github.com/ansible/ansible/issues/43540
    # Test by setting one value, then testing to see if the value is set.
    GlobalCLIArgs.from_options({'test':'test'})
    assert GlobalCLIArgs().test == 'test'

# Generated at 2022-06-11 17:49:00.268726
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyClass(GlobalCLIArgs):
        pass

    # Instantiate and make sure they are the same
    class_a = MyClass()
    class_b = MyClass()
    assert class_a is class_b


# Generated at 2022-06-11 17:49:07.767800
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, Singleton)
    assert issubclass(_ABCSingleton, ABCMeta)

# Generated at 2022-06-11 17:49:15.315954
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ChildA(Singleton):
        pass

    class ChildB(ABCMeta):
        pass

    class ChildC(ChildA):
        pass

    class ChildD(ChildA):
        pass

    class ChildE(ChildA):
        pass

    class ChildF(ChildB):
        pass

    class ChildG(ChildB):
        pass

    class ChildH(ChildB):
        pass

    # Just verify we can construct these.  They are meaningless otherwise
    ChildA()
    ChildB()
    ChildC()
    ChildD()
    ChildE()
    ChildF()
    ChildG()
    ChildH()

    # ChildD of ChildA, which is a Singleton, should have the same __new__ as ChildA
    assert ChildD.__new__ == ChildA.__new__
    # ChildD of ChildA

# Generated at 2022-06-11 17:49:17.240043
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    options = None
    assert not options
    assert not CLIArgs(options)

# Generated at 2022-06-11 17:49:20.107978
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({"a": 1, "b": [1, 2, 3, 4]})
    assert isinstance(args, ImmutableDict)



# Generated at 2022-06-11 17:49:28.493218
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class testArgs:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    test_args = testArgs(
        one=1,
        two=[1, 2, 3],
        three=dict(
            a='A',
            b='B',
            c='C',
            d='D',
        ),
    )

    test1 = GlobalCLIArgs.from_options(test_args)
    assert test1.one == 1
    assert test1.two[2] == 3
    assert test1.three['a'] == 'A'

    test2 = GlobalCLIArgs.from_options(test_args)
    assert test2.two[2] == 3
    assert test2.three['a'] == 'A'

    # test1 and test2 should be

# Generated at 2022-06-11 17:49:37.366647
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.dict_transformations import recursive_diff
    import collections
    import copy
    import json

    # Test the recursive conversion of object types to ImmutableDict
    original_dict = {'a': [1, 2, 3], 'b': {'c': [4, 5, 6], 'd': [7, 8, 9]}}
    immutable_dict = CLIArgs(original_dict)

    assert isinstance(immutable_dict, ImmutableDict)
    assert isinstance(immutable_dict['a'], tuple)
    assert isinstance(immutable_dict['b'], ImmutableDict)
    assert isinstance(immutable_dict['b']['c'], tuple)
    assert immutable_dict['b']['c'] == (4, 5, 6)

# Generated at 2022-06-11 17:49:46.029130
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    data = {'a':1, 'b': [1, 2, 3], 'c': {'x': 1}, 'd': {'x': {'y': 1}}, 'e': (1, 2, 3)}
    new_data = CLIArgs(data)
    assert isinstance(new_data, ImmutableDict)
    assert isinstance(new_data['b'], tuple)
    assert isinstance(new_data['c'], ImmutableDict)
    assert isinstance(new_data['d'], ImmutableDict)
    assert isinstance(new_data['d']['x'], ImmutableDict)
    assert isinstance(new_data['e'], tuple)



# Generated at 2022-06-11 17:49:52.651145
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Unit test for class '_ABCSingleton'

    This unit test checks that the attribute '_instance' of the class
    '_ABCSingleton' is None by default and that the Singleton.__new__
    method creates a new instance if and only if the attribute '_instance'
    is None.
    """
    assert not hasattr(_ABCSingleton, '_instance'), \
        "_ABCSingleton._instance attribute should not exist yet"

    singleton_instance = _ABCSingleton()
    assert singleton_instance is not None, \
        "_ABCSingleton.__new__ method didn't create a new instance"

    assert hasattr(_ABCSingleton, '_instance'), \
        "_ABCSingleton._instance attribute did not exist at all"

# Generated at 2022-06-11 17:49:58.831227
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingletonBase(_ABCSingleton):
        pass

    class Child1(SingletonBase):
        pass

    class Child2(SingletonBase):
        pass

    c1 = Child1()
    c2 = Child2()

    assert isinstance(c1, SingletonBase)
    assert isinstance(c1, Singleton)
    assert isinstance(c2, SingletonBase)
    assert isinstance(c2, Singleton)

# Generated at 2022-06-11 17:50:02.413094
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        pass

    class FooSingleton(Foo, metaclass=_ABCSingleton):
        pass

    assert issubclass(FooSingleton, Foo)

# Generated at 2022-06-11 17:50:16.807958
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(A):
        pass

    class C(A):
        pass



# Generated at 2022-06-11 17:50:24.885453
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-11 17:50:32.266607
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import ansible.module_utils.basic
    assert isinstance(GlobalCLIArgs.instance, GlobalCLIArgs)
    n_instance = GlobalCLIArgs.instance
    n_instance.update({'foo':'bar'})
    assert n_instance == GlobalCLIArgs.instance
    try:
        n_instance.update({'foo':'baz'})
    except AttributeError:
        pass
    else:
        assert False
    assert GlobalCLIArgs.instance == {'foo':'bar'}
    assert ansible.module_utils.basic.ANSIBLE_VERSION == '2.6'

# Generated at 2022-06-11 17:50:41.652364
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # only test for two of the three types that CLIArgs could contain
    # if the third one passes then the others likely will as well
    test_dict = {
        'key': 'value',
        'key2': [1, 2, 3],
        'key3': {
            'key4': 'value2',
            'key5': set(),
            'key6': [4, 5, 6]
        }
    }
    args = CLIArgs(test_dict)
    assert args.pop('key') == 'value'
    assert args.pop('key2') == (1, 2, 3)
    assert args.pop('key3').pop('key4') == 'value2'
    assert args.pop('key3').pop('key5') == frozenset()
    assert args.pop('key3').pop('key6')

# Generated at 2022-06-11 17:50:44.204122
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    class TestGlobalCLIArgs(GlobalCLIArgs):
        pass

    TestGlobalCLIArgs(1)



# Generated at 2022-06-11 17:50:53.405288
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = CLIArgs({'one': 'two'})
    assert options['one'] == 'two'
    options = CLIArgs({'one': ('two', 'three')})
    assert options['one'] == ('two', 'three')
    options = CLIArgs({'one': ['two', 'three']})
    assert options['one'] == ['two', 'three']
    options = CLIArgs({'one': {'two': 'three'}})
    assert options['one'] == {'two': 'three'}
    options = CLIArgs({'one': {'two': 'three'}, 'four': 'five'})
    assert options['one'] == {'two': 'three'}
    assert options['four'] == 'five'

# Generated at 2022-06-11 17:50:58.742783
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    @add_metaclass(_ABCSingleton)
    class TestSingleton(object):
        pass

    class TestNonSingleton(object):
        pass

    assert issubclass(TestSingleton, Singleton)
    assert issubclass(TestSingleton, ABCMeta)
    assert not issubclass(TestNonSingleton, Singleton)

# Generated at 2022-06-11 17:51:01.722124
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    my_dict = {'a': 1, 'b': 2}
    instance = CLIArgs(my_dict)
    assert my_dict == instance


# Generated at 2022-06-11 17:51:08.519792
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    import unittest
    import unittest.mock

    from ansible.module_utils.common.argparser import CLIArgs

    class TestSingleton(_ABCSingleton):
        def __init__(self, test_string):
            self.test_string = test_string

    class TestCLISingleton(_ABCSingleton):
        def __init__(self, test_dict):
            self.test_dict = test_dict

    class TestCLISingletonSubclass(_ABCSingleton):
        def __init__(self, test_dict):
            self.test_dict = test_dict

    class TestGlobalCLISingletonSubclass(_ABCSingleton):
        def __init__(self, test_dict):
            self.test_dict = test_dict


# Generated at 2022-06-11 17:51:10.069989
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs(CLIArgs({}))


# Generated at 2022-06-11 17:51:44.273302
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from mock import patch

# Generated at 2022-06-11 17:51:47.841070
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(metaclass=_ABCSingleton):
        pass
    assert issubclass(type(TestClass()), type(TestClass()))
    assert issubclass(type(TestClass()), singleton.Singleton)
    assert issubclass(type(TestClass()), abc.ABCMeta)

# Generated at 2022-06-11 17:51:51.185865
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs.from_options(None) == ImmutableDict()

# Generated at 2022-06-11 17:51:55.701779
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs({"ansible_verbosity": 2,
                        "inventory_paths": ["/path/to/inv"]})
    assert cli_args["ansible_verbosity"] == 2
    assert cli_args["inventory_paths"] == ("/path/to/inv",)

# Generated at 2022-06-11 17:51:59.594616
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test that the GlobalCLIArgs class can be created
    """
    obj = GlobalCLIArgs({'a': 1, 'b': 'c'})
    assert obj == {'a': 1, 'b': 'c'}


_global_cli_args = GlobalCLIArgs({})



# Generated at 2022-06-11 17:52:10.871486
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections

    d = collections.OrderedDict()
    d['c'] = 10
    d['d'] = 20
    d['e'] = 30
    d['a'] = collections.OrderedDict([('d',40),('c',50),('b',60)])
    d['b'] = collections.OrderedDict([('c',70),('a',80),('b',90)])

    f = _make_immutable(d)

    assert isinstance(f, ImmutableDict)
    assert isinstance(f['a'], ImmutableDict)
    assert isinstance(f['b'], ImmutableDict)
    assert isinstance(f['a'].items(), tuple)
    assert isinstance(f['b'].items(), tuple)

    d = CLIArgs(d)
    assert isinstance

# Generated at 2022-06-11 17:52:13.455739
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class test1(metaclass=_ABCSingleton):
        pass

    class test2(test1):
        pass

    test1()
    test2()

# Generated at 2022-06-11 17:52:21.427054
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    d = {'x': [1, 2], 'y': {'a': 'b'}}
    cli_args = CLIArgs(d)
    assert isinstance(cli_args, CLIArgs)
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args['x'], tuple)
    assert isinstance(cli_args['y'], ImmutableDict)
    assert isinstance(cli_args['y']['a'], text_type)



# Generated at 2022-06-11 17:52:29.338254
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options():
        def __init__(self, test=1, ansible_test=2, ansible_test_true=True):
            self.test = test
            self.ansible_test = ansible_test
            self.ansible_test_true = ansible_test_true

    options = Options()
    _args = GlobalCLIArgs.from_options(options)
    assert _args['test'] == 1
    assert type(_args) is GlobalCLIArgs
    assert _args.get('test') == 1
    assert _args.get('ansible_test') == 2
    assert _args.get('ansible_test_true') is True
    assert _args.get('ansible_test_false') is None
    assert _args.get('ansible_test_false', True) is True

# Generated at 2022-06-11 17:52:39.962963
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.validation import check_type_bool
    class TestCLIArgs(Mapping):
        def __getitem__(self, key):
            retval = None
            if key == 'diff':
                retval = True
            return retval

    assert isinstance(GlobalCLIArgs.from_options(TestCLIArgs()), GlobalCLIArgs)
    assert is_immutable(GlobalCLIArgs.from_options(TestCLIArgs())['diff'])
    assert check_type_bool(GlobalCLIArgs.from_options(TestCLIArgs())['diff'])

# Generated at 2022-06-11 17:53:34.680517
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a1 = GlobalCLIArgs({u"hello": u"world", u"foo": u"bar"})
    a2 = GlobalCLIArgs({u"hello": u"world", u"foo": u"bar"})

    assert id(a1) == id(a1)
    assert id(a1) == id(a2)
    assert a1 == a2

    a2["test"] = "test"  # Should not be possible to mutate
    assert a1 == a2

# Generated at 2022-06-11 17:53:38.481848
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Create test object
    args = {'foo': 'bar', 'baz': 'qux'}
    global_args = GlobalCLIArgs(args)

    # Test that object is a singleton
    assert global_args is GlobalCLIArgs()

# Generated at 2022-06-11 17:53:47.086837
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.six import PY3

# Generated at 2022-06-11 17:53:54.861551
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    sys.argv = ['x', 'y', '-z']
    import ansible.cli.options

# Generated at 2022-06-11 17:53:57.140316
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    opt = GlobalCLIArgs({'foo': 'bar'})
    assert opt['foo'] == 'bar'
    assert opt.toplevel['foo'] == 'bar'

# Generated at 2022-06-11 17:54:06.992332
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Unit test for constructor of class GlobalCLIArgs"""
    from ansible.module_utils._text import to_native
    from ansible.parsing.dataloader import DataLoader
    from ansible.cli.arguments import optparser
    from ansible.config.manager import ConfigManager
    from ansible.errors import AnsibleError


# Generated at 2022-06-11 17:54:13.001873
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _Test__ABCSingleton0(metaclass=_ABCSingleton):
        pass

    class _Test__ABCSingleton1(_Test__ABCSingleton0):
        pass

    class _Test__ABCSingleton2(_Test__ABCSingleton0):
        pass

    class _Test__ABCSingleton3(metaclass=_ABCSingleton):
        pass

# Generated at 2022-06-11 17:54:23.908996
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # In order to properly test this, we need to do some mocking.
    # Mock the immutabledict
    from unittest.mock import MagicMock
    ImmutableDict.__init__ = MagicMock()
    ImmutableDict.__getitem__ = MagicMock(side_effect=lambda x: x[1])

    # Mock the from_options method
    from unittest.mock import patch
    with patch.object(CLIArgs, 'from_options') as mock_from_options:
        mock_from_options.return_value = {'foo': 'bar'}
        # Make sure that the constructor worked correctly
        cli_args = CLIArgs({'foo': 'bar'})
        assert cli_args == {'foo': 'bar'}
        # Make sure that the from_options method was called
       

# Generated at 2022-06-11 17:54:28.174320
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object):
        __metaclass__ = _ABCSingleton
        variable = "Test variable"

    class Test2(object):
        # pylint: disable=abstract-class-not-used
        __metaclass__ = _ABCSingleton
        variable = "Test variable"

    try:
        Test()
        Test2()
    except TypeError:
        assert(False), "Exception raised in _ABCSingleton test"

# Generated at 2022-06-11 17:54:37.982178
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABCSingletonTest(object):
        __metaclass__ = _ABCSingleton
        pass

    class _ABCSingletonTest2(_ABCSingletonTest):
        pass

    class _ABCSingletonTest3(_ABCSingletonTest):
        def __init__(self, a, b=None):
            super(_ABCSingletonTest3, self).__init__()
            self.a = a
            self.b = b

    class _ABCSingletonTest4(_ABCSingletonTest):
        __metaclass__ = _ABCSingleton

    class _ABCSingletonTest5(_ABCSingletonTest):
        __metaclass__ = _ABCSingleton

    assert _ABCSingletonTest() is _ABCSingletonTest()
    assert _ABCSingletonTest2() is _ABCSingletonTest()
    assert _ABCSingletonTest3