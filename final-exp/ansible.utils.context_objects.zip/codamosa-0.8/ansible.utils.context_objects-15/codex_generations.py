

# Generated at 2022-06-11 17:45:05.486259
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(A, Singleton)
    assert isinstance(A, ABCMeta)
    a = A()
    b = A()
    assert a is b

# Generated at 2022-06-11 17:45:08.676151
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABCSingleton(_ABCSingleton):
        pass

    class TestABCSingleton2(_ABCSingleton):
        pass

    Test1 = TestABCSingleton()
    Test2 = TestABCSingleton()
    assert Test1 is Test2

# Generated at 2022-06-11 17:45:14.327830
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert GlobalCLIArgs.from_options(object) == GlobalCLIArgs.from_options(object)
    assert GlobalCLIArgs.from_options(object) is GlobalCLIArgs.from_options(object)
    assert id(GlobalCLIArgs.from_options(object)) == id(GlobalCLIArgs.from_options(object))


# Generated at 2022-06-11 17:45:19.740773
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs.from_options(None)
    assert args == ImmutableDict({})
    assert args.__class__ == GlobalCLIArgs
    assert args is not None
    args = GlobalCLIArgs.from_options(args)
    assert args == ImmutableDict({})
    assert args.__class__ == GlobalCLIArgs
    assert args is not None

# Generated at 2022-06-11 17:45:23.451187
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SubClass1(object):
        __metaclass__ = _ABCSingleton

    class SubClass2(object):
        __metaclass__ = _ABCSingleton

    assert issubclass(SubClass1, SubClass2)


# Generated at 2022-06-11 17:45:35.723963
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-11 17:45:44.441948
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    # We need to use a real options instance here because we use an
    # option with a default value which would not be present in the
    # vars() call if the option is not given a value by the user.
    #
    # This is to test that ImmutableDict correctly handles the empty
    # dict as being different to a dict with a key with no value.
    import ansible.module_utils.common.arguments
    options = ansible.module_utils.common.arguments.AnsibleModuleArgumentParser().parse_args([])[0]

    try:
        GlobalCLIArgs(vars(options))
    except TypeError:
        assert False, "GlobalCLIArgs works badly"
    else:
        assert True, "GlobalCLIArgs works well"



# Generated at 2022-06-11 17:45:48.696026
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
        def __init__(self):
            self.a = 1

    class B(object):
        def __init__(self):
            self.a = 2

    assert A() == A()
    assert B() != B()

# Generated at 2022-06-11 17:45:54.007613
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI

    cli = CLI(args=['--version'])
    options = cli.parse()

    GlobalCLIArgs.from_options(options)
    GlobalCLIArgs.from_options(options)

    assert len(sys.modules.keys()) == 1, len(sys.modules.keys())

# Generated at 2022-06-11 17:45:55.910454
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from collections import Mapping
    assert isinstance(CLIArgs(dict()), Mapping)



# Generated at 2022-06-11 17:46:05.976599
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    new_args = GlobalCLIArgs({'bool_opt': True, 'list_opt': [1, 2, 3], 'dict_opt': {'k1': 1, 'k2': 2}, 'something': 'else'})
    assert new_args == {'bool_opt': True, 'list_opt': [1, 2, 3], 'dict_opt': {'k1': 1, 'k2': 2}, 'something': 'else'}

# Generated at 2022-06-11 17:46:09.055848
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyClass(object):
        __metaclass__ = _ABCSingleton

    class MyClass(object):
        __metaclass__ = _ABCSingleton

    assert MyClass is MyClass

# Generated at 2022-06-11 17:46:13.801654
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text

    GlobalCLIArgs({"ANSIBLE_MODULE_UTILS": ""})

# Generated at 2022-06-11 17:46:19.829287
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class class1(object):
        __metaclass__ = _ABCSingleton
    class class2(object):
        __metaclass__ = _ABCSingleton

    class1()
    try:
        class2()
    except TypeError:
        print("class2 is a singleton")

if __name__ == '__main__':
    test__ABCSingleton()

# Generated at 2022-06-11 17:46:24.902867
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Singleton metaclass should not allow itself to be subclassed"""
    import pytest
    class _TestClass(metaclass=_ABCSingleton):
        pass

    with pytest.raises(TypeError) as exc:
        class _TestClass2(_TestClass):
            pass

    with pytest.raises(TypeError) as exc:
        class _TestClass3(metaclass=_ABCSingleton):
            pass

    with pytest.raises(TypeError) as exc:
        class _TestClass4(metaclass=ABCMeta):
            pass

# Generated at 2022-06-11 17:46:26.513353
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs()
    GlobalCLIArgs()

# Generated at 2022-06-11 17:46:28.827367
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import ansible.cli.CLI
    ansible_cli = ansible.cli.CLI()
    ansible_cli.parse()
    cli_args = GlobalCLIArgs.from_options(ansible_cli.options)
    assert len(cli_args) == len(sys.argv)

# Generated at 2022-06-11 17:46:31.996952
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _TestClass(_ABCSingleton):
        def __init__(self, value):
            self.value = value

    cls = _TestClass(4)
    assert cls.value == 4
    cls = _TestClass(5)
    assert cls.value == 4 # Should not have been overwritten

# Generated at 2022-06-11 17:46:42.481153
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-11 17:46:45.202052
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABCSingletonFoo(object):
        __metaclass__ = _ABCSingleton
    assert _ABCSingletonFoo() is _ABCSingletonFoo()

# Generated at 2022-06-11 17:46:56.609823
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {'foo': {'bar': 'baz', 'qux': [1, 2, 3], 'quux': {'corge': 'grault'}, 'waldo': 'fred'},
            'ping': 'pong'}
    immut_args = CLIArgs(args)
    assert immut_args['foo']['bar'] == 'baz'
    assert immut_args['foo']['waldo'] == 'fred'
    assert immut_args['foo']['quux']['corge'] == 'grault'
    assert immut_args['foo']['qux'] == (1, 2, 3)
    assert immut_args['ping'] == 'pong'
    assert immut_args == args
    assert isinstance(immut_args, CLIArgs)
    assert isinstance

# Generated at 2022-06-11 17:47:00.887888
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Test that we cannot init a second object
    try:
        GlobalCLIArgs(dict())
        assert False
    except Singleton.SingletonException:
        pass

    # Verify that the first object we created is the same as the second
    assert GlobalCLIArgs.get_instance() is GlobalCLIArgs.get_instance()

# Generated at 2022-06-11 17:47:09.873056
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({'test': 'foo'}) == {'test': 'foo'}
    assert CLIArgs({'test': 'foo', 'test2': 'bar'}) == {'test': 'foo', 'test2': 'bar'}
    assert CLIArgs({'test': 'foo', 'test2': 'bar', 'test3': {'test4': 'test4val', 'test5': 'test5val'}}) == \
        {'test': 'foo', 'test2': 'bar', 'test3': {'test4': 'test4val', 'test5': 'test5val'}}



# Generated at 2022-06-11 17:47:13.281499
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    assert A() == A()
    assert B() != C()
    assert A() != B()

# Generated at 2022-06-11 17:47:19.882258
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _base(with_metaclass(_ABCSingleton, object)):
        pass

    class _a(_base):
        pass

    class _b(_base):
        pass

    class _c(_base):
        pass

    assert _c() is not _base()
    assert _c() is not _a()
    assert _c() is not _b()
    assert _b() is not _a()
    assert _a() is not _base()
    assert _c() is _c()
    assert _b() is _b()
    assert _a() is _a()

# Generated at 2022-06-11 17:47:24.770612
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(object):
        __metaclass__ = _ABCSingleton
    class D(C):
        pass

# Generated at 2022-06-11 17:47:33.167342
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B):
        pass

    assert isinstance(A(), A)
    assert isinstance(B(), A)
    assert isinstance(C(), A)
    assert isinstance(D(), A)

    assert not isinstance(A(), B)
    assert not isinstance(B(), C)
    assert not isinstance(C(), D)
    assert not isinstance(D(), A)

    assert isinstance(A(), Singleton)
    assert isinstance(B(), Singleton)
    assert isinstance(C(), Singleton)
    assert isinstance(D(), Singleton)

    b = B()
    assert B().__dict__ == b.__dict__

    c = C

# Generated at 2022-06-11 17:47:35.939561
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class NewSingleton(_ABCSingleton):
        pass

    class NewSingleton2(_ABCSingleton):
        pass

    assert NewSingleton is NewSingleton2

# Generated at 2022-06-11 17:47:38.955852
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        pass

    test1 = Test()
    test2 = Test()

    assert 'test1' and 'test2'

# Generated at 2022-06-11 17:47:44.002161
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs(dict(foo='bar', baz=dict(boo='bop')))
    assert args.foo == 'bar'
    assert isinstance(args.baz, ImmutableDict)
    assert args.baz.boo == 'bop'



# Generated at 2022-06-11 17:47:51.251329
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyABCSingleton(object):
        __metaclass__ = _ABCSingleton
        pass

    assert type(MyABCSingleton) == _ABCSingleton
    assert issubclass(MyABCSingleton, _ABCSingleton)
    assert issubclass(MyABCSingleton, ABCMeta)
    assert issubclass(MyABCSingleton, Singleton)
    assert issubclass(MyABCSingleton, object)

# Generated at 2022-06-11 17:47:53.915725
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs({'foo': {'bar': 'baz'}})
    assert global_cli_args['foo']['bar'] == 'baz'

# Generated at 2022-06-11 17:47:54.823522
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    assert isinstance(GlobalCLIArgs.instance(), GlobalCLIArgs)

# Generated at 2022-06-11 17:47:58.438684
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mock_mapping = {'key1': 'value1', 'key2': 'value2'}
    actual= CLIArgs(mock_mapping)
    expected= {'key1': 'value1', 'key2': 'value2', '_ansible_ignore_unknown_options': False}
    assert actual==expected


# Generated at 2022-06-11 17:48:01.165769
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
    print(TestClass)
    TestClass()
    TestClass()

# Generated at 2022-06-11 17:48:06.808911
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import optparse
    parser = optparse.OptionParser()
    parser.add_option("-e", "--extra-vars", dest="extra_vars", action="append")
    opt_args = parser.parse_args([])
    global_args = GlobalCLIArgs.from_options(opt_args)
    assert global_args.extra_vars is None

# Generated at 2022-06-11 17:48:09.354332
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABC(metaclass=_ABCSingleton):
        _instances = {}

        def __init__(self, value):
            self.value = value

    TestABC(1)
    TestABC(2)

# Generated at 2022-06-11 17:48:14.460934
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Instantiate a class with the _ABCSingleton metaclass"""

    class _TestClass2(object):
        __metaclass__ = _ABCSingleton

    try:
        _TestClass2()
        _TestClass2()
    except:
        assert False, "Could not instantiate singleton"



# Generated at 2022-06-11 17:48:22.268411
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # We need to make something reasonably immutable to test the constructor.  Use
    # something like the Results object which we already know has some mutable data.
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.play_context import PlayContext

    results = TaskResult(host=dict(name='localhost.localdomain',
                                   ansible_facts=dict(ansible_all_ipv4_addresses=['10.0.0.42'])),
                         task=dict(args=dict(), name='setup'))
    context = PlayContext()
    context.stdout_callback = 'json'
    context.env = dict(ANSIBLE_STDOUT_CALLBACK='json')


# Generated at 2022-06-11 17:48:25.636070
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingletonClass(object):
        __metaclass__ = _ABCSingleton

    x = SingletonClass()
    y = SingletonClass()

    assert x is y
    assert isinstance(x, SingletonClass)

# Generated at 2022-06-11 17:48:32.011147
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    class B(A):
        pass

    a = A()
    b = B()

    assert a is b

# Generated at 2022-06-11 17:48:34.007844
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_instance = GlobalCLIArgs({'test': 'value'})

# Generated at 2022-06-11 17:48:43.093862
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Single(object):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            self.number = 1

    class Single(object):
        pass

    class Multiple(object):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            self.number = 2

    class Multiple(object):
        pass

    s = Single()
    assert s.number == 1
    t = Single()
    assert t.number == 1
    assert s is t

    m = Multiple()
    assert m.number == 2
    n = Multiple()
    assert n.number == 2
    assert m is n

# Generated at 2022-06-11 17:48:54.470207
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils._text import to_text

    example_args_dict = {'connection': 'smart',
                         'forks': 10}
    example_args = CLIArgs(example_args_dict)
    assert example_args == example_args_dict
    assert type(example_args) == ImmutableDict
    assert to_text(example_args) == to_text(example_args)

    deeper_args_dict = {'connection': 'smart',
                        'forks': 10,
                        'scope': {'hosts': 'localhost'}}
    deeper_args = CLIArgs(deeper_args_dict)
    assert deeper_args == deeper_args_dict
    assert type(deeper_args) == ImmutableDict


# Generated at 2022-06-11 17:48:56.624105
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        pass

    a = Test()
    b = Test()
    assert a is b



# Generated at 2022-06-11 17:49:08.033608
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = ImmutableDict({"foo": "bar",
                             "spam": "eggs",
                             "python": "python2",
                             "lists": ["a", "b", "c"],
                             "tuples": ("a", "b", "c"),
                             "dictionaries": {"a": "b",
                                              "c": "d",
                                              "e": "f"},
                             "samples": [{"1": "2"},
                                         {"a": "b"}]})

    cli = GlobalCLIArgs.from_options(options)

    assert cli["foo"] == "bar"
    assert cli["spam"] == "eggs"
    assert cli["python"] == "python2"
    assert cli["lists"] == ["a", "b", "c"]


# Generated at 2022-06-11 17:49:08.604844
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    pass

# Generated at 2022-06-11 17:49:14.763007
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    @add_metaclass(_ABCSingleton)
    class A(object):
        pass

    @add_metaclass(_ABCSingleton)
    class B(object):
        pass

    @add_metaclass(_ABCSingleton)
    class C(A):
        pass

    @add_metaclass(_ABCSingleton)
    class D(C):
        pass

    assert A is A()
    assert A is A()
    assert A is not B()
    assert B is B()
    assert B is B()
    assert C is C()
    assert C is not D()
    assert D is D()
    assert D is not A()

# Generated at 2022-06-11 17:49:15.699402
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({})

# Generated at 2022-06-11 17:49:23.607480
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingletonClass(object):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            self.a = 1
            self.a = 2

    class SingletonClass2(object):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            self.a = 1
            self.b = 2

    assert SingletonClass() is SingletonClass()
    assert SingletonClass2() is SingletonClass2()



# Generated at 2022-06-11 17:49:37.855909
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest

    if not hasattr(unittest.TestCase, 'assertCountEqual'):
        import unittest2
        unittest.TestCase = unittest2.TestCase

    class TestGlobalCLIArgs(unittest.TestCase):

        class Options(object):
            pass

        def setUp(self):
            self.options = TestGlobalCLIArgs.Options()
            self.options.test_key_1 = 'test_value_1'
            self.options.test_key_2 = ['test_value_2_1', 'test_value_2_2']

# Generated at 2022-06-11 17:49:43.905936
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    tdict = {'a': 1, 'b': {'c': 'd', 'e': {'f': ['g', 'h']}}}
    cli_args = CLIArgs(tdict)
    assert cli_args is not tdict
    assert cli_args['a'] == 1
    assert cli_args['b'] == {'c': 'd', 'e': {'f': ['g', 'h']}}
    assert cli_args is not cli_args['b']
    assert cli_args['b'] is not cli_args['b']['e']
    assert cli_args['b']['e'] is not cli_args['b']['e']['f']
    assert isinstance(cli_args['b'], ImmutableDict)

# Generated at 2022-06-11 17:49:46.177623
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = ImmutableDict({'key': 'value'})
    b = GlobalCLIArgs(a)
    assert (a is b)

# Generated at 2022-06-11 17:49:47.611446
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    obj = GlobalCLIArgs({})

# Generated at 2022-06-11 17:49:51.046054
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _Foo1(metaclass=_ABCSingleton):
        pass

    class _Foo2(metaclass=_ABCSingleton):
        pass

    _Foo1()
    _Foo2()

# Generated at 2022-06-11 17:50:01.245211
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # test basic usage
    cli_args = CLIArgs({'foo': {'bar': 'baz', 'qux': [{'quux': 'norf'}]}, 'corge': 'grault'})
    assert isinstance(cli_args, CLIArgs)
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args['foo']['bar'] == 'baz'
    assert cli_args['foo']['qux'][0]['quux'] == 'norf'
    assert cli_args['corge'] == 'grault'

    # test internals of constructor
    cli_args = CLIArgs({'foo': {'bar': 'baz', 'qux': ['quux']}, 'corge': 'grault'})

# Generated at 2022-06-11 17:50:08.050790
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    d = {'a': 1, 'b': {'c': 2, 'd': {'e': 3}}}
    d = CLIArgs(d)
    assert d['a'] == 1
    assert d['b']['c'] == 2
    assert d['b']['d']['e'] == 3
    try:
        d['b']['c'] = 4
        assert False  # Should have thrown exception
    except TypeError:
        pass

# Generated at 2022-06-11 17:50:17.285578
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import json
    cli_args_dict = {'check': True,
                    'diff': True,
                    'inventory': '.ansible/tmp/ansible-inventory-',
                    'module_path': ['/usr/share/ansible', '/etc/ansible/v2'],
                    'no_log': False,
                    'vault_ids': [],
                    'vault_password_file': None,
                    'verbosity': 0}
    cli_args = CLIArgs(cli_args_dict)
    assert json.dumps(cli_args_dict) == json.dumps(cli_args)

# Generated at 2022-06-11 17:50:22.260820
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    The constructor for GlobalCLIArgs is null (it does nothing)
    so we can't unit test it.

    Instead, this unit test casts the constructor to a mock object
    to see if the constructor is actually called when initializing a
    new instance of the class.
    """
    test_instance = GlobalCLIArgs.from_options({"f": 5})
    assert test_instance is not None and len(test_instance) == 1

# Generated at 2022-06-11 17:50:31.822637
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    import itertools as it
    import types
    for test_dict in {
        'a': '1',
        'b': 2,
        'c': {'a': 1},
        'd': {'b': 2},
        'e': {'c': [1, 2]},
        'f': [1, 2, 3],
        'g': {'a': 1, 'b': 2, 'c': [1, 2]},
        'h': [1, 2, {'a': 1}],
    }:
        obj = CLIArgs({'test': test_dict})
        assert isinstance(obj, collections.Mapping), "Should be a mapping"
        assert not isinstance(obj, types.MutableMapping), "Shouldn't be a mutable mapping"

# Generated at 2022-06-11 17:50:45.953694
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class FooSingleton(GlobalCLIArgs):
        pass
    cfg1 = GlobalCLIArgs()
    cfg2 = FooSingleton()
    assert isinstance(cfg1, ImmutableDict)
    assert isinstance(cfg2, ImmutableDict)
    assert cfg1 is cfg2

# Generated at 2022-06-11 17:50:50.976275
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    temp = GlobalCLIArgs({'key': {'subkey': 'val'}})
    assert temp['key']['subkey'] == 'val'

    with pytest.raises(TypeError):
        temp['key'] = 'val'

    with pytest.raises(TypeError):
        temp['key']['subkey'] = 'val'

# Generated at 2022-06-11 17:50:54.392412
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils.six import add_metaclass

    @add_metaclass(_ABCSingleton)
    class A(object):
        pass

    assert A() == A()


# Generated at 2022-06-11 17:51:05.037056
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Animmutable(object):
        pass
    class Amutable(object):
        pass
    test_dict = {'M': 10, 'A': Animmutable(), 'B': {'C': 20, 'D': {'E': Set([10, 20]), 'F': [30, 40]}}, 'Z': Amutable()}
    test_cli_args = CLIArgs(test_dict)
    # Make sure the dictionary has been copied to a new immutable dictionary
    assert test_cli_args is not test_dict
    assert test_cli_args == test_dict
    # Make sure we have used immutable types
    assert isinstance(test_cli_args, ImmutableDict)
    assert isinstance(test_cli_args['B'], ImmutableDict)

# Generated at 2022-06-11 17:51:16.263625
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict, ImmutableList, ImmutableSet

    # Test basic constructor
    args = CLIArgs({'foo': 1, 'bar': 'baz'})
    assert isinstance(args, CLIArgs)
    assert args['foo'] == 1
    assert args['bar'] == 'baz'

    # Constructor should turn sequences of containers into their immutable counterparts
    args = CLIArgs({'foo': [1, 2], 'bar': ['baz', 'quux']})
    assert isinstance(args['foo'], ImmutableList)
    assert args['foo'][0] == 1
    assert args['foo'][1] == 2
    assert isinstance(args['bar'], ImmutableList)
    assert args['bar'][0] == 'baz'

# Generated at 2022-06-11 17:51:17.284177
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs.create_singleton({'foo': 'bar'})

# Generated at 2022-06-11 17:51:18.215148
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert GlobalCLIArgs is not None

# Generated at 2022-06-11 17:51:23.099487
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Confirm that all the sequence types we expect to see from the CLI are set immutable
    # We need to make these mappings
    args = CLIArgs.from_options({
        'test': ['foo', 'bar'],
        'test2': {'foo': 'bar'},
    })
    assert args['test'] == ('foo', 'bar')
    assert args['test2'] == {'foo': 'bar'}

# Generated at 2022-06-11 17:51:34.388798
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test1(metaclass=_ABCSingleton):
        pass

    test1_1 = Test1()
    test1_2 = Test1()
    assert test1_1 == test1_2

    class Test2(metaclass=_ABCSingleton):
        def __init__(self, var1):
            self.var1 = var1

    test2_1 = Test2(1)
    test2_1_ref = Test2(1)
    test2_2 = Test2(2)
    assert test2_1 == test2_1_ref
    assert test2_1 != test2_2

    test1_1_ref = Test1()
    assert test1_1 == test1_1_ref
    assert test1_1 == test1_2
    assert test1_1_ref == test1

# Generated at 2022-06-11 17:51:45.138440
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import unittest
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.argument_spec import ArgumentSpec
    from ansible.module_utils.common.json_utils import AnsibleJSONEncoder

    class TestCLIArgs(unittest.TestCase):
        def setUp(self):
            self.maxDiff = None

# Generated at 2022-06-11 17:52:09.742906
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Confirms that we can have subclasses from both Singleton and ABCMeta with this class.
    """
    class SingletonABCTest(GlobalCLIArgs, object):
        pass
    test = SingletonABCTest()
    assert id(test) == id(SingletonABCTest())

# Generated at 2022-06-11 17:52:11.594198
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    dict_a = {}
    dict_b = {}
    dict_a['key1'] = dict_b
    dict_b['key2'] = dict_a
    cli_args = CLIArgs(dict_a)
    assert cli_args.get('key1') is not dict_b



# Generated at 2022-06-11 17:52:19.020500
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # test when all are dictionary
    user_defined = {'test': 'test'}
    cli_args = CLIArgs(user_defined)
    assert cli_args == user_defined

    # test when one is list
    user_defined = {'test': 'test', 'var': ['1', '2', '3']}
    cli_args = CLIArgs(user_defined)
    assert cli_args == user_defined

    # test when one is set
    user_defined = {'test': 'test', 'var': {'1', '2', '3'}}
    cli_args = CLIArgs(user_defined)
    assert cli_args == user_defined

    # test when one is string
    user_defined = {'test': 'test', 'var': 'a string'}
    cli_

# Generated at 2022-06-11 17:52:21.812986
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ConcreteClass(_ABCSingleton):
        pass

    try:
        ConcreteClass()
        assert False, 'Expected exception, got none'
    except TypeError:
        assert True

# Generated at 2022-06-11 17:52:25.143803
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Concrete(_ABCSingleton):
        pass
    assert issubclass(Concrete, Singleton)
    assert issubclass(Concrete, ABCMeta)
    assert Concrete is Concrete()

# Generated at 2022-06-11 17:52:34.710725
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    global_args_1 = CLIArgs({'hello': 'world'})
    global_args_2 = CLIArgs({'hello': 'world'})
    global_args_3 = CLIArgs({'hello': 'world', 'foo': 'bar'})
    # `global_args_1` and `global_args_2` are equal because `CLIArgs` doesn't override immutable
    # and equality checks, so the contents of the dictionary it's wrapping are compared and found to
    # be equal.
    assert global_args_1 == global_args_2
    assert global_args_1 == global_args_3


# Generated at 2022-06-11 17:52:42.214117
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-11 17:52:48.374074
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import inspect
    import sys
    import os
    import tempfile
    import pytest
    cwd = os.getcwd()

# Generated at 2022-06-11 17:52:56.171340
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    obj1 = GlobalCLIArgs.__new__(GlobalCLIArgs, value={"a": 1, "b": 2})
    assert obj1 == GlobalCLIArgs.__new__(GlobalCLIArgs, value={"a": 1, "b": 2})

    obj2 = GlobalCLIArgs.__new__(GlobalCLIArgs, value={"a": 1, "b": 2})
    assert obj1 is obj2
    obj2.__init__(value={"a": 3, "b": 4})
    assert obj1 == GlobalCLIArgs.__new__(GlobalCLIArgs, value={"a": 1, "b": 2})
    assert obj1 is not obj2

# Generated at 2022-06-11 17:52:57.681041
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert _ABCSingleton != ABCMeta
    assert _ABCSingleton != Singleton

# Generated at 2022-06-11 17:53:40.043963
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert isinstance(GlobalCLIArgs({"foo": 1, "bar": "hello"}), GlobalCLIArgs)


# Generated at 2022-06-11 17:53:47.087286
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Try to instantiate GlobalCLIArgs twice and ensure that we get the same object

    We also try to trick GlobalCLIArgs by passing in a Mapping of the wrong type and make sure it
    still throws an exception.
    """
    class BadMapping(Mapping):
        def __getitem__(self, item):
            pass

        def __iter__(self):
            pass

        def __len__(self):
            pass

    args1 = GlobalCLIArgs.from_options(object())
    args2 = GlobalCLIArgs.from_options(object())
    assert args1 is args2
    assert not isinstance(args2, BadMapping)

# Unit tests for constructor of class CLIArgs

# Generated at 2022-06-11 17:53:54.862289
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    def assert_is_immutable(obj):
        if isinstance(obj, (text_type, binary_type)):
            # Strings first because they are also sequences
            assert isinstance(obj, (text_type, binary_type))
        elif isinstance(obj, Mapping):
            for key, value in obj.items():
                assert isinstance(obj, Mapping)
                assert_is_immutable(value)
        elif isinstance(obj, Set):
            for value in obj:
                assert isinstance(obj, Set)
                assert_is_immutable(value)
        elif isinstance(obj, Sequence):
            for value in obj:
                assert isinstance(obj, Sequence)
                assert_is_immutable(value)


# Generated at 2022-06-11 17:54:04.954422
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert type(type(CLIArgs({}))) == ABCMeta
    c = CLIArgs({})
    assert type(c) == CLIArgs
    assert isinstance(c, ImmutableDict)
    assert c.__sizeof__() == 2384
    assert repr(c) == "CLIArgs({})"

    # Test that we can convert a conventional dict with string keys and values
    assert CLIArgs({'key': 'value'}) == ImmutableDict({'key': 'value'})

    # Test that we can convert a conventional dict with string keys and non-string values
    assert CLIArgs({'key': True}) == ImmutableDict({'key': True})

    # Test that we can convert a conventional dict with non-string keys
    assert CLIArgs({True: 'value'}) == ImmutableDict({True: 'value'})

   

# Generated at 2022-06-11 17:54:15.448488
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Hopefully, every time we import this module, it should make a new copy of the _ABCSingleton
    variable.  If it doesn't, the variable test_var should be the same every time we create a new
    SingletonTest object.
    """
    test_var = []

    @add_metaclass(_ABCSingleton)
    class SingletonTest(object):
        def __init__(self):
            test_var.append(0)
            self.number = len(test_var)

    # Create some Singletons
    SingletonTest()
    SingletonTest()

    # Now, if the SingletonTest class is a properly implemented Singleton, all objects created
    # will have the same number.
    assert test_var == [0, 0]

# Generated at 2022-06-11 17:54:25.411448
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    '''
    Test to make sure constructor of CLIArgs objects works as expected
    '''
    test_dict = {'a': 'b', 'c': True, 'd': 1, 'e': [2, 3, 4], 'f': {'g': 'h'}}
    test_args_obj = CLIArgs(test_dict)

    assert 'a' in test_args_obj
    assert 'c' in test_args_obj
    assert 'd' in test_args_obj
    assert 'e' in test_args_obj
    assert 'f' in test_args_obj

    assert test_args_obj['a'] == test_dict['a']
    assert test_args_obj['c'] == test_dict['c']
    assert test_args_obj['d'] == test_dict['d']
    assert test_

# Generated at 2022-06-11 17:54:33.838697
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import json

    mapping = {
        'first': {
            'second': {
                'third': [
                    [1, 2],
                    {'four': 5}
                ]
            }
        }
    }

    # Note that this isn't something you can use in regular code, but it is a unit test for the
    # constructor code to make sure we are doing what we intend with the constructor.
    cli_args = CLIArgs(mapping)
    assert json.dumps(cli_args, sort_keys=True) == '{"first": {"second": {"third": [[1, 2], {"four": 5}]}}}'

# Generated at 2022-06-11 17:54:42.077917
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.errors import AnsibleError
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()

    options = PlayContext()
    options.become = False
    options.become_method = 'sudo'
    options.become_user = 'root'
    options.check = False
    options.connection = 'smart'
    options.diff = True
    options.extra_vars = []
    options.force_handlers = False
    options.forks = 5

# Generated at 2022-06-11 17:54:52.654633
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible_collections.community.general.tests.unit.compat.mock import patch

    class MockOptions(object):
        def __init__(self, foo=None, bar=None):
            self.foo = foo
            self.bar = bar

        def __eq__(self, other):
            try:
                return self.foo == other.foo and self.bar == other.bar
            except AttributeError:
                return False

    @patch.object(CLIArgs, '__init__', wraps=CLIArgs.__init__)
    def test_init(mock_CLIArgs):
        opts = MockOptions(foo="foo", bar="bar")
        global_args = GlobalCLIArgs.from_options(options=opts)

# Generated at 2022-06-11 17:55:03.638441
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.config.manager import ConfigManager
    from ansible.parsing.dataloader import DataLoader

    options = ConfigManager(
        ["ansible-config", "-v"],
        usage="Usage: %prog [options]",
        loader=DataLoader(),
    ).parse_args()

    global_cli_args = GlobalCLIArgs.from_options(options)

    # Make sure that we can't assign to the instance
    try:
        global_cli_args['verbosity'] = 2
    except TypeError as error:
        assert error.message == "This dictionary is immutable"
    else:
        assert False, "Assigning to immutable dict did not raise the correct error"

    # Make sure that we can't assign to the instance through methods