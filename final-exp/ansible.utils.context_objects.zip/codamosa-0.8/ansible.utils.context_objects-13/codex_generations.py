

# Generated at 2022-06-11 17:45:09.224238
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mutable_dict = {
        'a': [100, 'abc'],
        'b': [200, 'xyz'],
        'c': [300],
    }
    immutable_dict = {
        'a': (100, 'abc'),
        'b': frozenset([200, 'xyz']),
        'c': (300,),
    }
    args = CLIArgs.from_options(mutable_dict)

    # should be immutable
    for key, value in args.items():
        assert isinstance(value, Container), "Value of %s must be a Container" % key
    assert args == immutable_dict, "Should be immutable"

# Generated at 2022-06-11 17:45:10.103071
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    pass

# Generated at 2022-06-11 17:45:18.375721
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.parsing.vault import VaultLib
    from ansible.compat.tests.mock import patch

    with patch.object(VaultLib, 'read_vault_data_stdin') as mock_read:
        mock_read.return_value = 'foo'
        cli_args = CLIArgs.from_options(dict(vault_password_file='bar'))
        assert cli_args['vault_password_file'] == 'bar'
        assert cli_args['vault_password'] == 'foo'

# Generated at 2022-06-11 17:45:23.357444
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'f': 1, 'g': 2, 'r': ['a', 'b', 'c', 1, 2, 3]}
    immutable_dict = CLIArgs(test_dict)
    assert immutable_dict['f'] == 1
    assert immutable_dict['g'] == 2
    assert immutable_dict['r'] == ('a', 'b', 'c', 1, 2, 3)

# Generated at 2022-06-11 17:45:35.637820
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    create global cli arguments object and test for expected cli switch values
    """
    toplevel = {
        'inventory': 'fake_inventory.yml',
        'module_path': 'fake_module_path',
        'playbook': 'fake_playbook.yml',
        'roles': 'fake_roles',
        'verbosity': 4
    }

    # init class with dictionary containing all types of values we expect to see in ansible-playbook
    # run
    GlobalCLIArgs(toplevel)

    # test for values set via cli switches
    assert GlobalCLIArgs()['inventory'] == 'fake_inventory.yml'
    assert GlobalCLIArgs()['module_path'] == 'fake_module_path'

# Generated at 2022-06-11 17:45:39.760524
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    assert A() is A()
    assert B() is B()
    assert A() is not B()
    assert B() is not A()


# Generated at 2022-06-11 17:45:49.620211
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.sentinel import Sentinel
    from ansible.playbook.play_context import PlayContext
    for cls in [CLIArgs, GlobalCLIArgs]:
        assert isinstance(cls, ABCMeta)
        args = cls({'foo': Sentinel('foo'), 'bar': {'baz': 'bar'}})
        assert args._data.get('foo') is Sentinel('foo')
        foo = args._data.get('foo', 'foo')
        assert foo is Sentinel('foo')
        bar = args._data.get('bar')
        assert isinstance(bar, Mapping)
        assert bar['baz'] == 'bar'

        assert isinstance(args.get('qux', default=PlayContext()), PlayContext)
        assert not args.get('qux', default=None)

        assert args._data

# Generated at 2022-06-11 17:45:53.069289
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.args import parse_kv
    GlobalCLIArgs({'a': 'b'})
    GlobalCLIArgs({'a': 'b'})

# Generated at 2022-06-11 17:45:55.862810
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object, metaclass=_ABCSingleton):
        pass

    a1 = A()
    a2 = A()
    assert a1 is a2

# Generated at 2022-06-11 17:46:00.010160
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options:
        foo = 'bar'
        baz = ['biz']

    options = Options()
    global_args = GlobalCLIArgs.from_options(options)
    assert global_args.foo == 'bar'
    assert global_args.baz == ('biz',)

# Generated at 2022-06-11 17:46:07.187628
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_mapping = {
        'k1': 'v1',
        'k2': [1, 2, 3],
        'k3': {'k4': 4, 'k5': 'v5'},
    }
    test_obj = CLIArgs(test_mapping)
    assert test_obj == test_mapping


# Generated at 2022-06-11 17:46:12.048142
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        def __init__(self):
            self.a = 0
    class B(metaclass=_ABCSingleton):
        def __init__(self):
            self.b = 1
    class C(A, B):
        pass
    c1 = C()
    c2 = C()
    assert c1.a == c2.a
    assert c1.b == c2.b

# Generated at 2022-06-11 17:46:17.402511
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Metaclass essentially doesn't do anything but we should be sure it doesn't blow up
    class Test(_ABCSingleton):
        pass

    assert hasattr(Test, '__new__')
    assert hasattr(Test, '__call__')
    assert hasattr(Test, '__init__')

# Generated at 2022-06-11 17:46:23.527775
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils.common.validation import check_type_bool

    # Ensure that check_type_bool was inserted into the singleton before starting the test
    check_type_bool(True)

    class _ABCSingletonTest(object, metaclass=_ABCSingleton):
        pass

    class TestSingleton(_ABCSingletonTest):
        def __init__(self):
            self.testvar = 10

    a = TestSingleton()
    b = TestSingleton()

    assert a.testvar == b.testvar

# Generated at 2022-06-11 17:46:31.849465
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_dict = {
        'test_key': 'test_value',
        'test_list': [1, 2, 3],
        'test_dict': {'test_dict_key': 'test_dict_value'},
        'test_set': set(['test_set_value1', 'test_set_value2', 'test_set_value3']),
    }
    args = GlobalCLIArgs(test_dict)
    assert args['test_key'] == 'test_value'
    assert args['test_list'] == (1, 2, 3)
    assert args['test_dict'] == ImmutableDict({'test_dict_key': 'test_dict_value'})

# Generated at 2022-06-11 17:46:36.128360
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _TestABCSingleton(_ABCSingleton):
        pass
    class _TestABCSingletonAgain(_ABCSingleton):
        pass
    _TestABCSingleton()
    try:
        _TestABCSingletonAgain()
        assert False, 'Expected error, but got none'
    except TypeError:
        pass



# Generated at 2022-06-11 17:46:37.101224
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    CLIArgs.from_options()

# Generated at 2022-06-11 17:46:41.356117
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _SingletonClass(object):
        __metaclass__ = _ABCSingleton

    assert _SingletonClass() is _SingletonClass()  # check that class is a singleton
    assert isinstance(_SingletonClass(), _SingletonClass)  # check that class is an instance of itself

# Generated at 2022-06-11 17:46:43.173660
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    g_i = GlobalCLIArgs.instance()
    g_i['a'] = 3
    assert g_i['a'] == 3
    g_i['a'] = 4
    assert g_i['a'] == 3
    assert g_i['a'] != 4

# Generated at 2022-06-11 17:46:47.711889
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    gca_a = GlobalCLIArgs({'key': 'value'})
    gca_b = GlobalCLIArgs({'key': 'value'})

    assert gca_a == gca_b
    assert gca_a is gca_b

    assert gca_a.get('key') == 'value'

# Generated at 2022-06-11 17:46:51.629847
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # pylint: disable=unused-variable
    class TestSingletonClass(_ABCSingleton):
        pass
    assert TestSingletonClass() == TestSingletonClass()

# Generated at 2022-06-11 17:46:59.923976
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.clean import module_response
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.arguments import ModuleArgsParser

    # Create a temporary module to get options with default values
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    parser = ModuleArgsParser(module)
    options = parser.parse_args()

    # Create GlobalCLIArgs to verify that we can create it
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-11 17:47:03.357595
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    opt = {
        "connection": "ssh",
        "module_path": ["/tmp"],
        "start_at_task": ""
    }
    cli_args = CLIArgs(opt)
    assert isinstance(cli_args, ImmutableDict)

# Generated at 2022-06-11 17:47:07.734648
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    gc = GlobalCLIArgs.from_options(__doc__)
    GlobalCLIArgs.from_options("""
        abc.meta(
            first_call_from_imports=True,
        )
    """)

# Generated at 2022-06-11 17:47:12.481439
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # pylint: disable=protected-access
    # pylint: disable=unused-variable

    class TestClass(object, metaclass=_ABCSingleton):
        pass

    assert TestClass == TestClass()
    assert TestClass._Singleton__instance == TestClass()
    assert TestClass is TestClass._Singleton__instance



# Generated at 2022-06-11 17:47:15.861386
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object):
        __metaclass__ = _ABCSingleton

        def test(self):
            return "test"

    first = Test()
    second = Test()
    assert first.test() == second.test()

# Generated at 2022-06-11 17:47:22.938130
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {
        'a': 1,
        'b': 'string',
        'c': [1,2,3],
        'd': {
            'e': 1,
            'f': 'string',
            'g': [1,2,3]
        },
        'h': [1,2,{'i':'string'}],
        'j': {
            'k': 1,
            'l': 'string',
            'm': [1,2,3],
            'n': {
                'o':1,
                'p':'string',
                'q':[1,2,3],
                'r':{
                    's':1,
                    't':'string',
                    'u':[1,2,3]
                }
            }
        }
    }

# Generated at 2022-06-11 17:47:31.060049
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton
        def __init__(self):
            self.value = "foo"

    class Bar(object):
        __metaclass__ = _ABCSingleton
        def __init__(self):
            self.value = "bar"

    class Baz(Foo):
        def __init__(self):
            self.value = "baz"

    assert Foo() is Foo()
    assert Bar() is Bar()
    assert Baz() is Baz()
    # One instance of Foo is also an instance of Baz, so they must be the same object
    assert Foo() is Baz()

# Generated at 2022-06-11 17:47:33.935364
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class A(Singleton):
        pass

    class B(GlobalCLIArgs):
        pass

    a = A()
    b = B()

    assert a is b

# Generated at 2022-06-11 17:47:46.262989
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    c1 = CLIArgs({'a': {'b': {'c': 'd', 'e': ['f', 'g']}, 'h': 1},
                  'i': {'j': 2, 'k': {'l': 3}},
                  'm': ['n', 'o']})

    assert isinstance(c1, CLIArgs)
    assert isinstance(c1, ImmutableDict)
    assert isinstance(c1, dict)

# Generated at 2022-06-11 17:47:58.140213
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common.collections import MutableSequence

    class MutableMappingSubclass(MutableMapping):
        def __init__(self):
            self._map = {}

        def __getitem__(self, key):
            return self._map[key]

        def __setitem__(self, key, value):
            self._map[key] = value

        def __delitem__(self, key):
            del self._map[key]

        def __iter__(self):
            return iter(self._map)

        def __len__(self):
            return len(self._map)


# Generated at 2022-06-11 17:48:02.226689
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({})
    assert isinstance(args, CLIArgs)
    assert isinstance(args, Mapping)
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, Singleton)
    assert args == {}



# Generated at 2022-06-11 17:48:05.438028
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Use the name _ABCSingleton to make sure class exists in Python syntax
    assert issubclass(_ABCSingleton, ABCMeta)
    assert issubclass(_ABCSingleton, Singleton)


# Generated at 2022-06-11 17:48:10.436018
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    my_dict = {'a': 'b', 'c': 'd'}
    new_dict = GlobalCLIArgs.from_options(my_dict)
    try:
        new_dict['a'] = 'e'
    except TypeError:
        # TypeError is a valid outcome as we should not be able to change the dict object
        pass
    else:
        raise AssertionError('The dict object should have not been modifiable')

# Generated at 2022-06-11 17:48:13.969803
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_sequence
    from functools import partial
    is_list = partial(is_sequence, sequence_type=list)
    is_tuple = partial(is_sequence, sequence_type=tuple)
    assert isinstance(CLIArgs({'foo': [], 'bar': {}}), Mapping)
    assert is_list(CLIArgs({'foo': []})['foo'])
    assert is_tuple(CLIArgs({'foo': []}).items())

# Generated at 2022-06-11 17:48:21.666778
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs.from_options(dict(a=1, b=dict(c=dict(d=2)), e=dict(f=3)))
    assert args == dict(a=1, b=dict(c=dict(d=2)), e=dict(f=3))

    try:
        args['a'] = 2
        assert False, "Assignment worked when it should have failed"
    except TypeError:
        assert True, "Cannot assign to an immutable dict, as expected"

    try:
        del args['a']
        assert False, "Deletion worked when it should have failed"
    except TypeError:
        assert True, "Cannot delete from an immutable dict, as expected"


# vim: nocindent ts=4 expandtab

# Generated at 2022-06-11 17:48:25.016493
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    x = ImmutableDict({'a': 1, 'b': 2})
    cli_args = CLIArgs(x)
    assert cli_args == x

# Generated at 2022-06-11 17:48:33.371249
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible_collections.ansible.module_utils.common.collection_loader import _CLIOptions
    cli_options = _CLIOptions()
    cli_args = GlobalCLIArgs.from_options(cli_options)
    assert isinstance(cli_args, GlobalCLIArgs)
    assert cli_args.get('verbosity') == 0
    assert cli_args.get('ask_vault_pass') is False
    assert cli_args.get('vault_password') is False
    assert cli_args.get('vault_password_file') == '~/.vault_pass.txt'
    assert cli_args.get('tags') is None
    assert cli_args.get('skip_tags') is None
    assert cli_args.get('start_at_task') is None

# Generated at 2022-06-11 17:48:37.473321
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()


# Generated at 2022-06-11 17:48:47.004688
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict1 = {
        "arg1": "val",
        "arg2": {"first": "1", "second": "two"},
        "arg3": ["a", "b", "c"],
        "arg4": ("a", "b", "c"),
        "arg5": {5, "a", 6},
    }
    dict2 = dict(dict1)
    dict2["arg2"]["third"] = 3
    dict2["arg3"].append("d")
    dict2["arg4"] += ("d",)
    dict2["arg5"].add("b")

    cliargs = CLIArgs(dict1)

    # print(dict2)
    # print(cliargs)

    assert cliargs == dict1
    assert cliargs != dict2

# Generated at 2022-06-11 17:48:55.571087
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils import basic
    from ansible.module_utils.common.logging import Logging, log_format_args
    from ansible.utils.color import colorize
    logging = Logging(vars(basic._ANSIBLE_ARGS), log_format_args())
    options = basic._ANSIBLE_ARGS
    colorize()
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-11 17:48:59.374318
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    x = CLIArgs({'a': 10})
    assert x['a'] == 10
    x['a'] = 20
    assert x == ImmutableDict({'a': 20})
    assert x['a'] == 20

# Generated at 2022-06-11 17:49:05.696916
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton):
        pass

    class Bar(_ABCSingleton):
        pass

    # Only one instance of class Foo
    foo1 = Foo()
    foo2 = Foo()
    assert foo1 is foo2

    # Only one instance of class Bar
    bar1 = Bar()
    bar2 = Bar()
    assert bar1 is bar2

    # Only one instance of class _ABCSingleton
    assert foo1 is bar1

# Generated at 2022-06-11 17:49:14.163332
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _DummyClass1(object):
        """An empty class"""
        pass

    class _DummyClass2(object):
        """An empty class"""
        pass

    class _DummyMetaclass1(object):
        """An empty metaclass"""
        pass

    class _DummyMetaclass2(object):
        """An empty metaclass"""
        pass

    def _raise_error():
        """Raise an error"""
        raise Exception("This should never execute")

    # We should never be able to create two different instances of the same metaclass
    _DummyMetaclass1 = _ABCSingleton(str("_DummyMetaclass1"), (object,), {})
    _DummyMetaclass2 = _ABCSingleton(str("_DummyMetaclass2"), (object,), {})



# Generated at 2022-06-11 17:49:15.294522
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert GlobalCLIArgs.instance() is not GlobalCLIArgs.instance()

# Generated at 2022-06-11 17:49:16.897298
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({'a': 'b'})

# Generated at 2022-06-11 17:49:22.796769
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test = CLIArgs({'foo': {'bar': 23},
                    'Bar': [1, 2, 3],
                    'Baz': None,
                    'baz': True})

    assert test['foo']['bar'] == 23
    assert test['Bar'] == (1, 2, 3)
    assert test['Baz'] is None
    assert test['baz'] is True

# Generated at 2022-06-11 17:49:26.978776
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton
    class Bar(object):
        __metaclass__ = _ABCSingleton
    assert Foo() is Foo()
    assert type(Foo()) is Foo
    assert type(Foo()) is Bar
    assert Bar() is Bar()

# Generated at 2022-06-11 17:49:34.103450
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    '''
    Class allows multiple inheritance with ABCMeta and Singleton
    '''
    class Foo(object):
        pass

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(Foo, cls).__new__(cls, *args, **kwargs)
        return cls._instance

    class Bar(Foo, object, metaclass=_ABCSingleton):
        pass

    first = Bar()
    second = Bar()
    assert first == second

# Generated at 2022-06-11 17:49:37.891299
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    options = type('options', (object,), {'foo': 'bar', 'bar': 'baz'})
    args = CLIArgs.from_options(options)
    assert args['foo'] == 'bar'
    assert args['bar'] == 'baz'

# Generated at 2022-06-11 17:49:47.133138
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class cls(metaclass=_ABCSingleton):
        pass
    cls()
    cls()

# Generated at 2022-06-11 17:49:57.245476
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class option:
        pass
    test_options = option()
    test_options.a = 5
    test_options.b = 'stringy'
    test_options.c = ['flag', True]
    test_options.d = {'sub': {'sub2': 'value'}}

    test_args = CLIArgs.from_options(test_options)
    assert test_args == dict(a=5, b='stringy', c=['flag', True], d={'sub': {'sub2': 'value'}})

    # Test the immutability
    try:
        test_args['b'] = 'change'
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-11 17:49:59.935224
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            pass

    a0 = A()
    a1 = A()
    assert a0 is a1

# Generated at 2022-06-11 17:50:12.062008
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.text.converters import to_text

    class Foo(_ABCSingleton):
        pass

    class Bar(_ABCSingleton):
        pass

    assert isinstance(Foo(), Singleton)
    assert isinstance(Bar(), Singleton)
    assert Foo() is Foo()
    assert Bar() is Bar()
    assert Foo() is not Bar()

    class Baz(_ABCSingleton):
        def __len__(self):
            return 42

    assert isinstance(Baz(), Singleton)
    assert isinstance(Baz(), Container)
    assert is_sequence(Baz())
    assert len(Baz()) == 42
    assert to_text(Baz()) == to_text(u'[\u2026]')

# Generated at 2022-06-11 17:50:14.814051
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class Foo(metaclass=_ABCSingleton):
        pass
    class Bar(Foo):
        pass

    assert issubclass(Bar, Foo)
    assert Bar() is Bar()

# Generated at 2022-06-11 17:50:17.607940
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({'a': 'b'})
    assert len(GlobalCLIArgs()['a']) == 1

# Generated at 2022-06-11 17:50:19.445251
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingletonClass(object, metaclass=_ABCSingleton):
        pass
    assert TestSingletonClass() is TestSingletonClass()

# Generated at 2022-06-11 17:50:26.407402
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # test for not able to modify any keys as it is immutable
    def __test_immutable_dict():
        args = GlobalCLIArgs(vars(options))
        args['some_key'] = 'new_some_value'
        assert args.get('some_key') == 'new_some_value'
    args = GlobalCLIArgs(vars(options))
    assert args.get('some_key') == 'some_value'
    assert args.get('list_key[0]') == 'list_value_1'
    assert args.get('list_key[1]') == 'list_value_2'
    assert args.get('dict_key[key1]') == 'dict_value_1'
    assert args.get('dict_key[key2]') == 'dict_value_2'
    assert args

# Generated at 2022-06-11 17:50:32.825450
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    # Create a dict
    test_dict = dict(test_key='test_value', second_test_key='test_value')

    # Create an instance of GlobalCLIArgs
    test_args = GlobalCLIArgs(test_dict)
    assert type(test_args) == ImmutableDict
    assert test_args.get('test_key') == 'test_value'
    assert test_args.get('second_test_key') == 'test_value'

# Generated at 2022-06-11 17:50:41.955847
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from collections import deque
    from ansible.module_utils.common.collections import is_iterable_but_not_string
    from ansible.module_utils.common.collections import is_string

    # Verify container types
    c = CLIArgs({})
    c = CLIArgs({'a': 1})
    c = CLIArgs({'a': []})
    c = CLIArgs({'a': ()})
    c = CLIArgs({'a': {}})
    c = CLIArgs({'a': set()})
    c = CLIArgs({'a': deque()})
    c = CLIArgs({'a': [1]})
    c = CLIArgs({'a': (1,)})
    c = CLIArgs({'a': {'a': 1}})
    c = CLIArgs({'a': {1}})


# Generated at 2022-06-11 17:51:04.109052
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({}) == {}
    assert CLIArgs({'a': 'A'}) == {'a': 'A'}
    assert CLIArgs({'a': ['A', 'A']}) == {'a': ('A', 'A')}
    assert CLIArgs({'a': {'b': 'B'}}) == {'a': {'b': 'B'}}
    assert CLIArgs.from_options(type('A', (object,), {'a': 'A'})()) == {'a': 'A'}

# Generated at 2022-06-11 17:51:07.809675
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class SingletonTest(object):
        __metaclass__ = _ABCSingleton

    class SingletonTestSubclass(SingletonTest):
        pass


# Generated at 2022-06-11 17:51:14.200831
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ABCSingletonTester(object):
        """Dummy class to test _ABCSingleton metaclass"""
        __metaclass__ = _ABCSingleton

    class ABCSingletonTesterSubclass(ABCSingletonTester):
        """The subclass of a class using the _ABCSingleton metaclass"""

    assert issubclass(ABCSingletonTesterSubclass, ABCSingletonTester)
    assert issubclass(ABCSingletonTesterSubclass, Singleton)

# Generated at 2022-06-11 17:51:20.305571
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class MyOptions(object):
        pass

    options = MyOptions()
    options.test_key = 'test_value'
    options.test_key2 = 123

    cli_args = GlobalCLIArgs.from_options(options)

    assert isinstance(cli_args, GlobalCLIArgs)
    assert isinstance(cli_args, ImmutableDict)
    assert 'test_key' in cli_args
    assert 'test_key2' in cli_args
    assert cli_args['test_key'] == 'test_value'
    assert cli_args['test_key2'] == 123

# Generated at 2022-06-11 17:51:23.590221
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # FIXME: need a better unit test
    class Foo(object):
        __metaclass__ = _ABCSingleton
        def __init__(self):
            pass
    a = Foo()
    b = Foo()
    assert a is b



# Generated at 2022-06-11 17:51:34.948038
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli import CLI, CLIARGS
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils.singleton import Singleton
    import os

    # test for constructor
    args = CLI.base_parser(constants.DEFAULT_MODULE_PATH,
                           constants.DEFAULT_MODULE_DATA_PATH,
                           'test',
                           'test').parse_args(['-m', 'ping', 'localhost'])
    global_args = GlobalCLIArgs(vars(args))
    assert isinstance(global_args, ImmutableDict)
    assert isinstance(global_args, Singleton)
    assert vars(global_args) == vars(args)
    assert global_args['module_path'] == constants.DEFAULT_MODULE_PATH


# Generated at 2022-06-11 17:51:40.871692
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    glo = GlobalCLIArgs({'a': {'b': ['c', 'd', 'e']}})
    assert isinstance(glo, ImmutableDict)
    assert isinstance(glo['a'], ImmutableDict)
    assert isinstance(glo['a']['b'], tuple)
    assert len(glo['a']['b']) == 3


# Generated at 2022-06-11 17:51:49.682545
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import ansible.cli.CLI as cli
    import ansible.constants as constants
    import ansible.cli.arguments as arguments

    # Create a sub class of parser, so we can override the values
    class Parser(arguments.OptionParser):
        def get_usage(self):
            return "usage: %prog [options]"


# Generated at 2022-06-11 17:51:56.703748
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('-l', '--list', action='append', default=[])
    options = parser.parse_args(['-l', '1', '-l', '2'])
    args = CLIArgs.from_options(options)
    assert args['list'] == ('1', '2')
    assert isinstance(args['list'], tuple)


# Generated at 2022-06-11 17:52:01.670124
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    '''
    Test CLIArgs constructor
    '''
    cli_args = CLIArgs(dict(k1=dict(k11=list(range(3)))))
    assert isinstance(cli_args['k1']['k11'], tuple)
    assert isinstance(cli_args['k1'], ImmutableDict)
    assert isinstance(cli_args, ImmutableDict)

# Generated at 2022-06-11 17:52:35.375908
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    assert A() is A()

# Generated at 2022-06-11 17:52:43.801421
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import unittest
    from ansible.utils.collection_docs import CLIArgsDocs

    class TestCLIArgs(unittest.TestCase):

        def test_cli_args_creation(self):
            cli_args_dict = {'debug': True, 'module_path': '/some/path', 'foo': 'bar', 'boo': 'far'}
            cli_args = CLIArgs(cli_args_dict)

            self.assertTrue(isinstance(cli_args, CLIArgs))
            self.assertTrue(isinstance(cli_args, ImmutableDict))
            self.assertEqual(cli_args_dict, dict(cli_args))


# Generated at 2022-06-11 17:52:47.414352
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyType(Singleton, ABCMeta):
        pass
    # This is mostly just to be sure that this code doesn't do anything
    # silly, as it is copied from a StackOverflow answer.
    class MyClass(metaclass=MyType):
        pass

# Generated at 2022-06-11 17:52:56.764110
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    args = GlobalCLIArgs.from_options(argparse.Namespace(
        obscure_passwords=False,
        debug=False,
        diff=False,
        output_path=None,
        verbosity=0,
        module_path=[],
        tree=None,
        fetch_list=[],
        ask_vault_pass=False,
        tags=[],
    ))

    assert isinstance(args, GlobalCLIArgs)
    assert args.verbosity == 0


# Generated at 2022-06-11 17:53:00.366544
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    with pytest.raises(AssertionError):
        cli1 = GlobalCLIArgs({'foo': 'bar'})
        cli1['foo'] = 'baz'

# Generated at 2022-06-11 17:53:08.382859
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from mock import Mock, patch
    from ansible.config.args import parse_options

    # Test for None
    options = Mock(spec_set=dict)
    with patch('ansible.module_utils.cli_args.GlobalCLIArgs') as MockCliArgs:
        parse_options(options)
        MockCliArgs.assert_not_called()

    # Test for empty
    options = Mock(spec_set=dict)
    options.__getitem__.return_value = {}
    with patch('ansible.module_utils.cli_args.GlobalCLIArgs') as MockCliArgs:
        parse_options(options)
        MockCliArgs.return_value.update.assert_called_once_with({})

    # Test for a single argument
    options = Mock(spec_set=dict)

# Generated at 2022-06-11 17:53:19.142933
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Pass in a Mapping
    class MappingClass():
        def __init__(self, mapping):
            self._mapping = mapping

        def items(self):
            return self._mapping.items()

    mapping = MappingClass({u'foo': u'bar', u'baz': (u'qux', u'quux')})
    cli_args = CLIArgs(mapping)
    # cli_args should be immutable
    try:
        cli_args[u'foo'] = False
    except TypeError:
        pass
    else:
        assert False, "cli_args should be immutable"
    assert cli_args[u'foo'] == u'bar'
    assert set(cli_args[u'baz']) == set([u'qux', u'quux'])
    # Pass

# Generated at 2022-06-11 17:53:26.708657
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs({'one': 1, 'two': 2})
    assert cli_args['one'] == 1
    assert cli_args['two'] == 2
    assert cli_args == {'one': 1, 'two': 2}
    assert cli_args.get('one') == 1
    assert cli_args.get('three') is None
    assert 'one' in cli_args
    assert 'three' not in cli_args

# Generated at 2022-06-11 17:53:27.602174
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs.from_options({})

# Generated at 2022-06-11 17:53:29.235938
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton(_ABCSingleton):
        pass

    a = TestSingleton()
    b = TestSingleton()
    assert a is b

# Generated at 2022-06-11 17:54:36.412300
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Magic(object):
        __metaclass__ = _ABCSingleton
    assert issubclass(Magic, Singleton)
    assert issubclass(Magic, ABCMeta)

# Generated at 2022-06-11 17:54:38.541694
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(A, metaclass=_ABCSingleton):
        pass



# Generated at 2022-06-11 17:54:49.992512
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.vars import combine_vars
    from ansible.cli.arguments import options, parse

    parse(['--verbosity', '3'])

    cli_args = CLIArgs(vars(options))

    # cli_args is immutable, so we cannot directly assign it to variables.
    # Instead, we construct a dict that uses the same contents as cli_args,
    # and then we pass that dict to combine_vars().
    #
    # Here, we are using the same keys as ansible-playbook
    # and the same values as cli_args.
    #
    # In other words, we are testing whether cli_args can be
    # used as part of the first argument to combine_vars().

# Generated at 2022-06-11 17:54:55.641543
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test1(object):
        __metaclass__ = _ABCSingleton

        def __init__(self, value=True):
            self.value = value

    class Test2(Test1):
        def __init__(self, value=False):
            self.value = value

    class Test3(Test1):
        def __init__(self):
            pass

    t1 = Test1()
    t2 = Test2()
    t3 = Test3()

    assert t1.value == True
    assert t2.value == False
    assert t3.value == True

# Generated at 2022-06-11 17:55:01.913854
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABCSingletonTest(metaclass=_ABCSingleton):
        pass
    class _ABCSingletonTestSub(metaclass=_ABCSingleton):
        pass
    class _ABCSingletonTestSubSub(metaclass=_ABCSingleton):
        pass
    class _ABCSingletonTestSubSubSub(metaclass=_ABCSingleton):
        pass