

# Generated at 2022-06-11 17:45:10.467825
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.display import Display
    class A(object):
        a = 'a'
        b = 'b'
        c = 'c'
        d = ('d', 'e')

    class B(object):
        def __init__(self, mapping):
            self.my_mapping = dict(mapping)

    class C(object):
        def __init__(self, mapping):
            self.my_mapping = set(mapping)

    class D(object):
        def __init__(self, sequence):
            self.my_sequence = list(sequence)

    class E(object):
        def __init__(self, sequence):
            self.my_sequence = tuple(sequence)

    class F(object):
        def __init__(self, agg):
            self.my_agg = agg

# Generated at 2022-06-11 17:45:14.885937
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    obj = GlobalCLIArgs({'a': 'b'})
    assert isinstance(obj, GlobalCLIArgs)
    assert obj == {'a': 'b'}
    assert id(obj) == id(obj.get('a'))



# Generated at 2022-06-11 17:45:23.515913
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.cli import CLI
    from ansible.plugins.loader import cli_plugins

    parser = CLI.base_parser(
        # description='description',
        # usage='usage',
        # epilog='epilog',
        # formatter_class=RawDescriptionHelpFormatter
        # conflict_handler='resolve'
        # parents=[]
        # prog='ansible'
    )
    parser.add_argument('args', nargs='*')
    parser.add_argument('-s', '--somesetting')

    for plugin in cli_plugins.get_plugins().values():
        parser = plugin.update_parser(parser)

    args = parser.parse_args(['--somesetting', 'somevalue'])

    cli_args = CLIArgs.from_options(args)
    assert cli

# Generated at 2022-06-11 17:45:26.964356
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton(_ABCSingleton):  # noqa: F811
        pass

    first = TestSingleton()
    second = TestSingleton()
    assert(first is second)



# Generated at 2022-06-11 17:45:36.005100
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {"key1": {'key2': [1, 2, 3]}, 'key3': [5, 6, 7]}
    test_cliargs = CLIArgs(test_dict)
    assert isinstance(test_cliargs, CLIArgs)
    assert isinstance(test_cliargs, ImmutableDict)
    assert isinstance(test_cliargs['key1'], ImmutableDict)
    assert isinstance(test_cliargs['key1']['key2'], tuple)
    assert isinstance(test_cliargs['key3'], tuple)

# Generated at 2022-06-11 17:45:44.805106
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common._collections_compat import Mapping
    import sys
    import six
    import types

    assert isinstance(CLIArgs({}), ImmutableDict)
    assert isinstance(CLIArgs({}), Mapping)
    assert not isinstance(CLIArgs({}), types.DictType)
    assert sys.getrefcount(Mapping) > 1
    assert sys.getrefcount(ImmutableDict) > 1
    # The __new__ method of ImmutableDict is not publicly exposed:
    # pylint: disable=E1101
    assert CLIArgs({}) is not ImmutableDict.__new__(ImmutableDict)
    # pylint: enable=E1101

# Generated at 2022-06-11 17:45:46.153358
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton('NewBase', (object,), {}), object)

# Generated at 2022-06-11 17:45:51.164566
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass1(object):
        __metaclass__ = _ABCSingleton

    class TestClass2(TestClass1):
        pass

    class TestClass3(TestClass1):
        pass

    # Cursory check that we can create a class which is a Singleton
    assert(TestClass1() is TestClass1())
    assert(TestClass2() is TestClass2())
    assert(TestClass3() is TestClass3())

# Generated at 2022-06-11 17:45:58.066448
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'one': 1, 'two': '2', 'three': [3, '3'], 'four': '4', 'five': {'five': 5}}
    args = CLIArgs(test_dict)
    assert args['two'] == '2'
    assert args['three'] == (3, '3')
    assert args['five']['five'] == 5
    assert not isinstance(args, Singleton)



# Generated at 2022-06-11 17:46:03.087438
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class One(object, metaclass=_ABCSingleton):
        pass

    class Two(One):
        pass
    assert isinstance(One(), One)
    assert isinstance(Two(), One)
    assert One() is One()
    assert One() is Two()
    assert Two() is Two()



# Generated at 2022-06-11 17:46:12.015318
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    options = ImmutableDict(dict(number=42, string='forty-two', string_list=['1', '2', '3'], l=False, l2=False))
    args = CLIArgs.from_options(options)
    assert args['number'] == 42
    assert 'number' in args
    assert 'bad_key' not in args
    assert args['string'] == 'forty-two'
    assert args['string_list'] == ('1', '2', '3')
    for key in args:
        assert key in options



# Generated at 2022-06-11 17:46:22.902579
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    sys.argv = ['/bin/ansible', '-m', 'setup', '-a', 'foo=bar', '-vvvvv']
    from ansible.utils.args import module_args_to_string, create_parser, handle_module_args
    parser = create_parser()
    options, args = parser.parse_known_args()
    options.args = handle_module_args(args)
    options.module_args = module_args_to_string(options.args)

# Generated at 2022-06-11 17:46:31.599687
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # pylint: disable=unused-variable
    # pylint: disable=attribute-defined-outside-init
    class TestArgs(GlobalCLIArgs):
        def __init__(self):
            self.namespace = {'a': 1, 'b': 2, 'c': 3, 'd': [1, 2, 3], 'e': {'f': 'g', 'h': 'i'}}

    # Setup for the test
    temp_args = TestArgs()

    # Check if GlobalCLIArgs is working
    assert temp_args['a'] == 1
    assert temp_args['b'] == 2
    assert temp_args['c'] == 3
    assert temp_args['d'] == (1, 2, 3)
    assert temp_args['e'] == {'f': 'g', 'h': 'i'}

# Generated at 2022-06-11 17:46:35.514717
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    foo_dict = {'a': 1, 'b': 2, 'c': 3}
    foo_args = CLIArgs(foo_dict)
    test_structure = {'a': 1, 'b': 2, 'c': 3}
    assert foo_args == test_structure



# Generated at 2022-06-11 17:46:40.057613
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class FakeOptions(object):
        test_opt1 = 1
        test_opt2 = 'test'
    fake_options = FakeOptions()
    assert set(frozenset(GlobalCLIArgs.from_options(fake_options))) == {'test_opt1', 'test_opt2'}

# Generated at 2022-06-11 17:46:46.176970
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import ansible.module_utils.common.pre_py3_compat
    # We only test the constructor because the other methods are covered by
    # the ImmutableDict tests.
    assert isinstance(GlobalCLIArgs({}), ImmutableDict)
    assert isinstance(GlobalCLIArgs({'foo': 'bar'}), ImmutableDict)
    assert GlobalCLIArgs({'foo': 'bar'})['foo'] == 'bar'

# Generated at 2022-06-11 17:46:49.595716
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Does the _ABCSingleton class construct successfully"""
    class _ABCSingletonTest(object):
        __metaclass__ = _ABCSingleton

    _ABCSingletonTest()

# Generated at 2022-06-11 17:46:55.895945
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # This function only exists so we can prove that cli args are immutable
    def mutate_global_cli_args(args):
        args['extra_cli_args']['foo'] = 'bar'

    args = {
        'extra_cli_args': {
            'baz': 'qux'
        }
    }
    global_cli_args = GlobalCLIArgs(args)

    # This should not raise an exception
    mutate_global_cli_args(global_cli_args)
    assert global_cli_args['extra_cli_args']['foo'] is None

# Generated at 2022-06-11 17:46:59.786755
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():  # pylint: disable=function-redefined
    """
    meta = _ABCSingleton('Test', (object,), {})
    class Test():
        __metaclass__ = meta
    assert isinstance(Test(), Test)
    """

# Generated at 2022-06-11 17:47:02.208320
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs.__new__(GlobalCLIArgs)
    assert global_cli_args.__init__() == None


# Generated at 2022-06-11 17:47:14.474629
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import tempfile
    import yaml
    import json

    d = {'hi': 'there', 1: 2, 3: {'hello': 'there'}}

    with tempfile.NamedTemporaryFile('w') as f:
        yaml.dump(d, stream=f)
        f.flush()
        f.seek(0)
        newd = yaml.safe_load(f)
        args = CLIArgs(newd)
        assert d == args.copy()

    with tempfile.NamedTemporaryFile('w') as f:
        json.dump(d, f)
        f.flush()
        f.seek(0)
        newd = json.load(f)
        args = CLIArgs(newd)
        assert d == args.copy()

# Generated at 2022-06-11 17:47:22.309644
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    my_dict = {}
    my_dict['first'] = 'one'
    my_dict['second'] = 'two'
    my_dict['third'] = [1, 2, 3]
    my_dict['fourth'] = (1, 2, 3)
    my_dict['fifth'] = {'a': 'alpha', 'b': 'beta'}
    my_dict['sixth'] = {1, 2, 3}
    my_dict['nested'] = {'level1': {'level2': 'level3'}}

    expected_dict = my_dict.copy()
    expected_dict['third'] = tuple(expected_dict['third'])
    expected_dict['fifth'] = ImmutableDict(expected_dict['fifth'])

# Generated at 2022-06-11 17:47:32.220763
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args_dict = {'debug': True, 'diff': True, 'help': False, 'action': 'add', 'user': 'ansible', 'password': 'password'}
    cli_args = CLIArgs(cli_args_dict)
    assert cli_args['debug'] == True
    assert cli_args['diff'] == True
    assert cli_args['action'] == 'add'
    assert cli_args['user'] == 'ansible'
    assert cli_args['password'] == 'password'
    assert cli_args['help'] == False
    cli_args_dict['debug'] = False
    assert cli_args['debug'] == True
    cli_args_dict['debug'] = 'xyz'
    assert cli_args['debug'] == True
    cli_args_

# Generated at 2022-06-11 17:47:37.592592
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
        def __init__(self):
            self.a = 1

    class B(A):
        def __init__(self):
            super(B, self).__init__()
            self.b = 2

    class C(B):
        def __init__(self):
            super(C, self).__init__()
            self.c = 3

    assert A() is A()
    assert A() is B()
    assert A() is C()
    assert B() is C()
    assert A().a == 1
    assert B().a == 1
    assert C().a == 1
    assert B().b == 2
    assert C().b == 2
    assert C().c == 3

# Generated at 2022-06-11 17:47:48.287551
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            self.bar = 1

    class Bar(object):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            self.bar = 2

    foo1 = Foo()
    foo2 = Foo()
    bar1 = Bar()
    bar2 = Bar()

    assert foo1
    assert foo1 == foo2
    assert foo2 == foo1
    assert foo2 is foo1

    assert bar1
    assert bar1 == bar2
    assert bar2 == bar1
    assert bar2 is bar1

    assert foo1 != bar1
    assert bar1 != foo1
    assert bar2 != foo1
    assert foo1 != bar2

# Generated at 2022-06-11 17:47:58.140987
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import ansible.constants as C
    from ansible.utils.color import stringc
    from ansible.cli import CLI

    cli = CLI(
        args=["test.py"],
        runas_opts=True,
        connection_opts=True,
        module_opts=True,
        runas_prompt=False,
        verbosity=C.DEFAULT_VERBOSITY,
        check=False,
        diff=False,
        galaxy_interactive=False,
        output_opts=True,
        cmdline=["ansible-playbook", "--version"],
    )
    options, _ = cli.parse()

    GlobalCLIArgs.instance(options)


# Generated at 2022-06-11 17:48:08.102502
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import GlobalCLIArgs
    from collections import Counter

    s = GlobalCLIArgs
    s.set({"a": {"b": {"c": Counter({"hello": 1})}}})
    assert s.get("a")["b"]["c"] == Counter({"hello": 1})
    assert s.get("a")["b"]["c"] is not Counter({"hello": 1})
    assert s.get("a")["b"] is not {"c": Counter({"hello": 1})}
    assert s.get("a") is not {"b": {"c": Counter({"hello": 1})}}


# Make a GlobalCLIArgs instance and make it a Singleton
GlobalCLIArgs()



# Generated at 2022-06-11 17:48:17.885902
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Make sure that _ABCSingleton works as expected"""

    class A(metaclass=_ABCSingleton):
        pass

    class B(metaclass=_ABCSingleton):
        pass

    def test_instances():
        a1 = A()
        a2 = A()
        # Make sure that we are actually using the singleton metaclass
        assert id(a1) == id(a2)

        b1 = B()
        assert id(a1) != id(b1)

        # Make sure that we are actually using the ABCMeta metaclass
        try:
            A()
        except Exception as e:
            assert 'Can\'t instantiate abstract class A' in text_type(e)

    test_instances()

# Generated at 2022-06-11 17:48:20.017466
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class FirstClass(metaclass=_ABCSingleton):
        pass

    class SecondClass(FirstClass, metaclass=_ABCSingleton):
        pass

# Generated at 2022-06-11 17:48:22.621973
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object, metaclass=_ABCSingleton):
        pass
    class B(A):
        pass

# Generated at 2022-06-11 17:48:25.140960
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import unittest
    unittest.main()

# Generated at 2022-06-11 17:48:33.615799
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs.from_options(None) == ImmutableDict({})
    assert CLIArgs.from_options({}) == ImmutableDict({})
    assert ImmutableDict({'a': 1}) == CLIArgs.from_options({'a': 1})
    assert ImmutableDict({'a': ImmutableDict()}) == CLIArgs.from_options({'a': {'b': 1}})
    assert ImmutableDict({'a': ('b',)}) == CLIArgs.from_options({'a': ('b')})
    assert ImmutableDict({'a': frozenset()}) == CLIArgs.from_options({'a': set()})
    assert ImmutableDict({'a': frozenset([1])}) == CLIArgs.from_options({'a': set([1])})

# Generated at 2022-06-11 17:48:44.335140
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping1 = {'b': ['true', 'false'], 'a': {'c': ['d', 'e', 'f']}}
    cliargs1 = CLIArgs(mapping1)

    assert mapping1 == cliargs1
    assert isinstance(cliargs1, Mapping)
    assert isinstance(cliargs1.get('b'), Sequence)
    assert isinstance(cliargs1.get('a'), Mapping)
    assert isinstance(cliargs1.get('a').get('c'), Sequence)
    assert isinstance(cliargs1, ImmutableDict)

    # Test that the object is immutable
    mapping2 = {'b': 'true', 'a': {'c': ['d', 'e', 'f']}}
    cliargs2 = CLIArgs(mapping2)

    mapping2['b'][0]

# Generated at 2022-06-11 17:48:55.163193
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # pylint: disable=unused-argument
    def dict_new(cls, *args, **kwargs):
        return dict(*args, **kwargs)  # pylint: disable=no-value-for-parameter

    def dict_make_immutable(obj):
        if isinstance(obj, dict):
            ret = dict()
            for k, v in obj.items():
                ret[k] = dict_make_immutable(v)
            return ImmutableDict(ret)
        return obj

    # Test that it is really immutable
    x = CLIArgs(dict_new(a=1, b=2))

    # If we can change a leaf, we should be able to change the whole dict
    x['a'] = 2

    # Test _make_immutable
    x = dict_make_immutable

# Generated at 2022-06-11 17:49:00.885397
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test1(metaclass=_ABCSingleton):
        def __init__(self, value):
            self.value = value

    class Test2(Test1):
        pass

    test1 = Test1(5)  # nosec
    assert test1.value == 5

    test2 = Test2(10)  # nosec
    assert test2.value == 10

# Generated at 2022-06-11 17:49:03.524401
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Verify GlobalCLIArgs behaves correctly"""
    GlobalCLIArgs()
    assert isinstance(GlobalCLIArgs.instance(), GlobalCLIArgs)

# Generated at 2022-06-11 17:49:05.758226
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    a1 = A()
    a2 = A()
    assert a1 is a2

# Generated at 2022-06-11 17:49:07.599850
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object):
        __metaclass__ = _ABCSingleton
    assert(isinstance(Test(), Test))

# Generated at 2022-06-11 17:49:12.274040
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = GlobalCLIArgs({'a': 1})
    assert a is GlobalCLIArgs()
    assert a == GlobalCLIArgs({'a': 1})
    assert GlobalCLIArgs({'a': 1}) == GlobalCLIArgs({'a': 1})
    assert GlobalCLIArgs({'a': 1}) != GlobalCLIArgs({'a': 1, 'b': 2})
    assert GlobalCLIArgs({'a': 1, 'b': 2}) != GlobalCLIArgs({'a': 1})


# Generated at 2022-06-11 17:49:22.975134
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mydict = {
        'a' : [1, 2, 3],
        'b' : 'xyz',
        'c' : {'a': 'b'},
        'd' : ['a'],
        'e' : frozenset(['a', 'b']),
        'f' : {'a': ['a', 'b']},
    }
    new_dict = _make_immutable(mydict)

    if not isinstance(new_dict, ImmutableDict):
        raise AssertionError("Failed to make immutable")
    if not isinstance(new_dict['a'], tuple):
        raise AssertionError("Failed to make list immutable")
    if not isinstance(new_dict['b'], text_type):
        raise AssertionError("Failed to make string immutable")


# Generated at 2022-06-11 17:49:28.438167
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({}) == {}
    assert CLIArgs({"a": {"b": "c"}}) == ImmutableDict({"a": ImmutableDict({"b": "c"})})

# Generated at 2022-06-11 17:49:36.560625
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert issubclass(GlobalCLIArgs, ImmutableDict)
    assert issubclass(GlobalCLIArgs, Singleton)

    class MockOptions(object):
        def __init__(self, foo=True, bar=1, baz=[]):
            self.foo = foo
            self.bar = bar
            self.baz = baz

    test_options = MockOptions()
    my_args = GlobalCLIArgs.from_options(test_options)

    assert set(my_args.keys()) == set(['foo', 'bar', 'baz'])
    assert my_args['foo'] is True
    assert my_args['bar'] == 1
    assert my_args['baz'] == []

# Generated at 2022-06-11 17:49:46.657024
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Setup
    if GlobalCLIArgs._initialized:
        return True


# Generated at 2022-06-11 17:49:51.836946
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Test GlobalCLIArgs singleton implementation"""
    obj1 = GlobalCLIArgs({'b': 'b_value', 'a': 'a_value'})
    obj2 = GlobalCLIArgs({'b': 'b_value', 'a': 'a_value'})
    assert obj1 == obj2

# Generated at 2022-06-11 17:49:57.901875
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    a = CLIArgs({'a': 'a', 'b': 'b'})
    assert a['a'] == 'a'
    assert a['b'] == 'b'

    b = CLIArgs({'a': 'a'})
    a['a'] = 'b'
    assert a['a'] == 'a'
    assert b['a'] == 'a'
    assert a != b



# Generated at 2022-06-11 17:50:04.547320
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({}) == ImmutableDict({})
    assert CLIArgs({'top': {'level': {'nested': 'dict'}}}) == \
        ImmutableDict({'top': ImmutableDict({'level': ImmutableDict({'nested': 'dict'})})})
    assert CLIArgs({'top': ['a', 'list']}) == ImmutableDict({'top': ('a', 'list')})
    assert CLIArgs({'top': ('a', 'tuple')}) == ImmutableDict({'top': ('a', 'tuple')})

# Generated at 2022-06-11 17:50:16.509614
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import os
    import sys
    import tempfile
    import unittest

    class Tests(unittest.TestCase):

        def setUp(self):
            self.cur_dir = os.getcwd()
            self.script_dir = os.path.dirname(__file__)
            os.chdir(self.script_dir)

        def tearDown(self):
            os.chdir(self.cur_dir)


# Generated at 2022-06-11 17:50:25.461670
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    assert CLIArgs({}) == ImmutableDict()
    assert CLIArgs({'foo': 'bar'}) == ImmutableDict({'foo': 'bar'})
    assert CLIArgs({'foo': ['bar', 'baz']}) == ImmutableDict({'foo': ('bar', 'baz')})
    assert CLIArgs({'foo': {'bar': 'baz'}}) == ImmutableDict({'foo': ImmutableDict({'bar': 'baz'})})
    assert CLIArgs({'foo': {'bar': ['baz', 'quux']}}) == ImmutableDict({'foo': ImmutableDict({'bar': ('baz', 'quux')})})

# Generated at 2022-06-11 17:50:34.192733
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Try a string, an integer, a list, a dictionary, a boolean True and False
    # Test that they are all converted to the immutable version of their data type
    # If a dictionary or list have any other data types in them, they should be
    # converted to the immutable version of their data type as well
    args = CLIArgs({
        'string': 'I\'m a string',
        'int': 1,
        'list': [1, '2', 3],
        'dict': {'1': 1, 'two': '2', 'three': 3},
        'True': True,
        'False': False
    })
    assert(isinstance(args, CLIArgs))
    assert(isinstance(args['string'], text_type))
    assert(isinstance(args['int'], int))

# Generated at 2022-06-11 17:50:40.333676
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('-f')
    args = parser.parse_args()

    assert GlobalCLIArgs.from_options(args)
    assert GlobalCLIArgs.from_options(args) is GlobalCLIArgs.from_options(args)

    # Make sure constructing it twice in a row doesn't change its contents
    first = GlobalCLIArgs.from_options(args)
    assert GlobalCLIArgs.from_options(args) == first



# Generated at 2022-06-11 17:50:53.733668
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    my_opts = dict(
        opt1='value1',
        opt2='value2',
        opt3={'key1': 'value1', 'key2': 'value2'},
    )
    my_cliargs = GlobalCLIArgs.from_options(ImmutableDict(my_opts))

    # Constructor successfully creates unchangable data types by default
    assert isinstance(my_cliargs, ImmutableDict)
    # Constructor successfully converts dict and dict inside dict
    assert isinstance(my_cliargs['opt1'], text_type)
    assert isinstance(my_cliargs['opt2'], text_type)
    assert isinstance(my_cliargs['opt3'], ImmutableDict)
    assert isinstance(my_cliargs['opt3']['key1'], text_type)

# Generated at 2022-06-11 17:51:00.671456
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options:
        pass
    options = Options()
    options.foo = 'bar'
    options.baz = dict(alpha='beta', gamma=['delta', 'epsilon'])
    options.zeta = ['iota', options.baz]
    options.kappa = ['lambda']
    options.mu = set([options, 1, 2, 3])
    _ = GlobalCLIArgs.from_options(options)  # Just testing that this works

# Generated at 2022-06-11 17:51:08.172598
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.collection_list import CollectionList
    from ansible.utils.context_objects import AnsibleContext
    from ansible.utils.vars import AnsibleVars

    options = AnsibleContext.CLIOptions()
    options.connection = 'local'
    options.module_path = 'library'

    loader = AnsibleCollectionLoader()
    collections = CollectionList.from_paths(loader, [options.collections_paths])
    loader.set_collections(collections)

    vars = AnsibleVars(loader, options)

    cli_args = CLIArgs.from_options(options)
    assert(isinstance(cli_args, ImmutableDict))

    # Unit test for the __init__ method of class CLIArgs
    cl

# Generated at 2022-06-11 17:51:17.994674
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Test the metaclass _ABCSingleton

    _ABCSingleton is a metaclass that combines Singleton's __new__ with ABCMeta's __new__.  This test
    is to confirm that the order of operation on __new__ is correct and that subclassing _ABCSingleton
    works as expected.

    :return: None
    """

    class Foo(metaclass=_ABCSingleton):
        """ABCMeta-based class"""
        pass

    class Bar(metaclass=_ABCSingleton):
        """Singleton-based class"""

        def __init__(self, *args, **kwargs):
            super(Bar, self).__init__(*args, **kwargs)
            self.x = 5.0
            self.y = 2.5


# Generated at 2022-06-11 17:51:21.675344
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    class B(A):
        def __new__(cls, *args, **kwargs):
            raise Exception("foo")
    class C(A):
        pass
    class D(C, B):
        pass
    class E(A):
        pass

    A()
    C()
    E()
    with pytest.raises(Exception, match="foo"):
        D()

# Generated at 2022-06-11 17:51:23.785275
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    @add_metaclass(_ABCSingleton)
    class TestABCSingleton(object):
        pass

    TestABCSingleton()

# Generated at 2022-06-11 17:51:29.906863
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class TestClass(object):
        def __init__(self, arg_c, arg_d):
            self.c = arg_c
            self.d = arg_d
    opts = TestClass('test_c', 'test_d')
    global_cli_args = GlobalCLIArgs.from_options(opts)
    assert global_cli_args['c'] == 'test_c' and global_cli_args['d'] == 'test_d'

# Generated at 2022-06-11 17:51:33.422629
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = GlobalCLIArgs({'key': 1})
    assert isinstance(a, ImmutableDict)
    assert a['key'] == 1

# Generated at 2022-06-11 17:51:44.274002
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from collections import OrderedDict
    from ansible.module_utils.common.collections import is_sequence
    foo = GlobalCLIArgs(OrderedDict((
        ('key1', 'value1'),
        ('key2', ['value2a', 'value2b']),
        ('key3', OrderedDict((('key31', 'value31'), ('key32', 'value32')))),
        ('key4', ['value3a', OrderedDict((('key41', 'value41'), ('key42', 'value42')))])
    )))
    assert foo.key1 == 'value1'
    assert foo.key2[1] == 'value2b'
    assert foo.key3.key31 == 'value31'
    assert is_sequence(foo.key4)
    assert foo.key4[1].key

# Generated at 2022-06-11 17:51:51.790260
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():  # pylint: disable=no-self-use
    """
    Ensure that the constructor of GlobalCLIArgs behaves as expected
    """
    class Options(object):
        # pylint: disable=too-few-public-methods
        """
        Fake options object
        """
        test = "sample_string"
        dict_option = {'key': 'value'}
        list_option = ['s', 'a', 'm', 'p', 'l', 'e']
        set_option = {'s', 'a', 'm', 'p', 'l', 'e'}
        tuple_option = ('s', 'a', 'm', 'p', 'l', 'e')
        int_option = 0

    options = Options()
    imm_dict = GlobalCLIArgs.from_options(options)

    assert imm_

# Generated at 2022-06-11 17:52:06.158673
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Test constructor
    test_args_dict = {'var1': 1, 'var2': 2, 'var3': 3}
    test_args = GlobalCLIArgs(test_args_dict)
    assert test_args.var1 == 1
    assert test_args.var2 == 2
    assert test_args.var3 == 3

    # Test singleton property
    test_args2 = GlobalCLIArgs(test_args_dict)
    assert id(test_args) == id(test_args2)

    # Test from_options function
    import mock
    from ansible.cli.arguments import options, enable_dynamic_plugins
    enable_dynamic_plugins(options)
    test_options = options
    test_options.var1 = 1
    test_options.var2 = 2
    test_options.var

# Generated at 2022-06-11 17:52:16.339378
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.parsing.vault import VaultLib
    import time

    import six
    assert six.PY3


# Generated at 2022-06-11 17:52:19.622267
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Singleton and ABCMeta work together in _ABCSingleton
    """

    class SingletonABC(metaclass=_ABCSingleton):
        pass

    assert SingletonABC() is SingletonABC()



# Generated at 2022-06-11 17:52:27.618667
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Ensure that changing a cloned GlobalCLIArgs doesn't alter the original"""
    argv = "ansible-playbook test.yml -i localhost".split()
    parser = AnsibleCLI(['setup'], argv, simplify=True)
    options, args = parser.parse()
    copy1 = GlobalCLIArgs.from_options(options)
    copy2 = copy1.copy()
    # Modify a value in the copy to make sure it's really a copy
    copy2['inventory'] = '/tmp/foo'
    # Assert that the change didn't propagate to the original
    assert copy1['inventory'] != copy2['inventory']



# Generated at 2022-06-11 17:52:35.881199
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import argparse

    # create parser
    parser = argparse.ArgumentParser()
    parser.add_argument('-a', '--add', action='store_true')
    parser.add_argument('-b', '--buy', metavar="BUY_STATE",
                        help="Whether to buy or not", choices=["yes", "no"])
    parser.add_argument('-c', '--cancel', action='store_true')
    parser.add_argument('-r', '--remove', action='store_true')
    parser.add_argument('--removed_execptions', action='store_true')
    parser.add_argument('--ansible_log_path', action='store_true')
    parser.add_argument('--ansible_playbook_command', action='store_true')


# Generated at 2022-06-11 17:52:38.710308
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    first = GlobalCLIArgs({})
    second = GlobalCLIArgs({})
    assert first is second, "Only one copy of GlobalCLIArgs should exist, so the empty constructor should return the same instance every time"



# Generated at 2022-06-11 17:52:45.973516
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test that GlobalCLIArgs() is a Singleton and is a subclass of CLIArgs
    """
    inst1 = GlobalCLIArgs({
        u'test_key1': u'test_value1',
        u'test_key2': u'test_value2',
        u'test_key3': u'test_value3',
        u'test_key4': u'test_value4',
        u'test_key5': u'test_value5',
        u'test_key6': u'test_value6',
        u'test_key7': u'test_value7',
    })
    assert isinstance(inst1, CLIArgs)

# Generated at 2022-06-11 17:52:51.697957
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Make sure we can create a singleton instance of an abstract instance"""

    class DummyABCSingleton(_ABCSingleton):
        """
        Dummy class for testing _ABCSingleton

        This class is not abstract so we can construct it.  This allows is to test the meta-class.
        """
        something = 'test'

    assert DummyABCSingleton.something == 'test'
    assert DummyABCSingleton() is not None

# Generated at 2022-06-11 17:52:59.083826
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    print('test_CLIArgs')

    class MockOptions:
        # pylint: disable=too-few-public-methods
        def __init__(self, mapping):
            self.__dict__ = mapping

    my_mapping = {
        'key1': 'value1',
        'key2': 'value2',
        'key3': ['my', 'list', 'of', 'values'],
        'key4': {
            'subkey1': 'subvalue1',
            'subkey2': 'subvalue2',
        },
        'key5': 5,
        'key6': 6.5,
        'key7': True,
        'key8': ['value8', {'subkey3': 'subvalue3', }, ],
    }
    mapping_copy = my_mapping.copy()


# Generated at 2022-06-11 17:53:03.312200
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Creating a class with this metaclass is the goal of this test.
    class MyClass(object):
        __metaclass__ = _ABCSingleton
        pass

    x1 = MyClass()
    x2 = MyClass()
    assert x1 is x2

# Generated at 2022-06-11 17:53:28.748976
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    c = CLIArgs({'a': 1, 'b': {'a': 'hello', 'b': [1, 2, 3]}})
    assert isinstance(c, ImmutableDict)
    assert c['a'] == 1
    assert isinstance(c['b'], ImmutableDict)
    assert c['b']['a'] == 'hello'
    assert isinstance(c['b']['b'], tuple)
    assert c['b']['b'][1] == 2


# Generated at 2022-06-11 17:53:33.389103
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    args = {}
    parser = argparse.ArgumentParser()
    parser.add_argument('--bool-flag')
    options, args = parser.parse_known_args(["--bool-flag"], namespace=args)
    # this line should fail if it is not a singleton
    _ = GlobalCLIArgs(args)

# Generated at 2022-06-11 17:53:44.290117
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    # Case where no args get passed
    args = GlobalCLIArgs.from_options(None)
    assert args == {}

    # Case with simple string
    args = GlobalCLIArgs.from_options(argparse.Namespace(test="testvalue"))
    assert args == {"test": "testvalue"}

    # Case with simple int
    args = GlobalCLIArgs.from_options(argparse.Namespace(test=1))
    assert args == {"test": 1}

    # Case with mutable dictionary
    args = GlobalCLIArgs.from_options(argparse.Namespace(test={"key1": "value1",
                                                              "key2": "value2"}))
    assert args == {"test": {"key1": "value1",
                             "key2": "value2"}}

    # Case with mutable list

# Generated at 2022-06-11 17:53:53.194139
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import os
    import sys
    import unittest

    class TestCLIArgs(unittest.TestCase):
        def test_constructor(self):
            # Only test constructor as this specific test is for constructor
            key = {'a': {'b': [1, 2, 3], 'c': {'d': 4}}, 'e': 'f'}
            test_obj = CLIArgs(key)

            for arg, value in test_obj.items():
                self.assertTrue(isinstance(arg, text_type))
                self.assertTrue(isinstance(value, set))
                self.assertTrue(isinstance(value, ImmutableDict))
                self.assertTrue(isinstance(value, Container))
                if isinstance(value, Container):
                    for value_item in value.items():
                        self.assertTrue

# Generated at 2022-06-11 17:53:56.577214
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Check that we can not change the object.
    try:
        GlobalCLIArgs.__setitem__('foo', 'bar')
    except TypeError as e:
        assert str(e) == 'Arguments to this class can only be passed to __init__'



# Generated at 2022-06-11 17:54:06.511176
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        pass

    class B(object):
        pass

    assert A() != A()
    assert B() != B()

    class C(A, B):
        pass

    assert C() != C()

    class D(A, metaclass=singleton.Singleton):
        pass

    assert D() == D()

    class E(B, metaclass=singleton.Singleton):
        pass

    assert E() == E()

    class F(C, metaclass=singleton.Singleton):
        pass

    assert F() == F()
    assert F() != A()
    assert F() != B()
    assert F() != C()
    assert F() != D()
    assert F() != E()

    class G(object, metaclass=singleton.Singleton):
        pass

# Generated at 2022-06-11 17:54:13.366498
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Test _ABCSingleton Singleton class

    Verify that inheritance priority is correctly set so that singleton behaviour
    does not override the ABCMeta based behaviour.
    """
    class TestA(metaclass=_ABCSingleton):  # pylint: disable=no-method-argument
        pass

    assert TestA.__name__ == 'TestA'
    assert TestA.__module__ == 'ansible.cli.arguments'

# Generated at 2022-06-11 17:54:16.319501
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs({'user': 'bob'})
    assert global_cli_args['user'] == 'bob'

# Generated at 2022-06-11 17:54:25.962455
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    # try to make a immutable CLIArgs from a non-mutable set
    try:
        args = {'test': 1, 'list': ['a', 'b'], 'set': set(['a', 'b'])}
        obj = CLIArgs(args)
        raise AssertionError("Should failed when create CLIArgs object with non-mutable set.")
    except TypeError as e:
        assert(str(e)) == "unhashable type: 'set'"

    # try to make a immutable CLIArgs from a non-mutable list

# Generated at 2022-06-11 17:54:30.540757
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is A()
    assert C() is C()


del _ABCSingleton