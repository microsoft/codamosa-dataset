

# Generated at 2022-06-11 17:45:08.166780
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import unittest
    class TestCase(unittest.TestCase):
        def test_constructor(self):
            args = CLIArgs({'a': 1, 'b': 2})
            self.assertTrue(isinstance(args, Mapping))
            self.assertIn('a', args)
            self.assertEquals(1, args['a'])
            self.assertIn('b', args)
            self.assertEquals(2, args['b'])
    unittest.main(module=__name__, verbosity=2)

# Generated at 2022-06-11 17:45:19.869565
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options:
        def __init__(self):
            self.inventory = "inventory"
            self.listhosts = None
            self.module_paths = ["a_path"]
            self.pattern = "localhost"
            self.verbosity = 0
            self.host_list = None
            self.extra_vars = {
                "playbook_dir": "playbook",
                "playbook_name": "playbook",
                "playbook_path": "playbook",
            }
            self.connection = "smart"
            self.remote_user = "user"
            self.become = False
            self.check = False
            self.start_at_task = None
            self.step = False
            self.sudo = False
            self.sudo_user = None
            self.tags = ["tag"]


# Generated at 2022-06-11 17:45:23.216846
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test instance creation of class GlobalCLIArgs
    """
    args_dict = {'start': 0, 'end': 100, 'step': 2}
    GlobalCLIArgs(args_dict)

# Generated at 2022-06-11 17:45:35.113781
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'a': {'a1': {'a11': 'a111'}}}
    args = CLIArgs(mapping)
    assert args['a']['a1']['a11'] == 'a111'
    mapping['a']['a1']['a11'] = 'a112'
    assert args['a']['a1']['a11'] == 'a111'
    mapping['a']['a1'] = {'a12': 'a121'}
    assert args['a']['a1']['a11'] == 'a111'
    mapping['a'] = {'a2': {'a22': 'a221'}}
    assert args['a']['a1']['a11'] == 'a111'

# Generated at 2022-06-11 17:45:44.291268
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.argparser import CLIArgs

    # To test GlobalCLIArgs, we need to create a CLIArgs object
    #   that is a class with a __call__ method instead of an instance
    class FakeCLIArgs(CLIArgs):
        def __call__(self, **kwargs):
            self._kwargs = kwargs
            return self

    fake_args = FakeCLIArgs(dict(basedir='.', module_path=[]))()
    assert fake_args == {}

    # The GlobalCLIArgs class should be a Singleton, and hence it should
    #   create at most one instance and globalCLIArgs should always be
    #   the same as GlobalCLIArgs()
    globalCLIArgs = GlobalCLIArgs.get_instance()
    assert globalCLIArgs == {}

   

# Generated at 2022-06-11 17:45:52.620221
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import ansible.config.base
    from ansible.utils.cmdline import handle_connection_cache_options, handle_verbosity_options, \
        handle_inventory_options, handle_tqm_options, to_yaml

    root_parser, all_parsers = ansible.config.base.create_parser(
        None,
        to_yaml.base_parser(usage="usage: ansible-config [%s] [--help] [options] [settings]" %
                                   "/".join(to_yaml._SUBCOMMANDS)),
        None,
    )
    options = root_parser.parse_args('view -o --help'.split())

    # These are some of the options we want to make sure get through the constructor of CLIArgs
    # because they are handled by different pieces of code.  We don't

# Generated at 2022-06-11 17:46:02.330826
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {}
    test_dict['a'] = 'b'
    test_dict['c'] = 'd'
    test_dict['e'] = {}
    test_dict['e']['f'] = 'g'
    test_dict['h'] = ['i', 'j']
    test_dict['h'][1] = {}
    test_dict['h'][1]['k'] = 'l'
    test_dict['m'] = set(['n', 'o'])
    test_dict['m'].add('p')
    test_dict['m'].add('q')
    test_dict['r'] = set(['s', 't'])
    test_dict['r'].add(set(['u', 'v']))
    test_dict['r'].add('w')
   

# Generated at 2022-06-11 17:46:11.045898
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys

    # pylint: disable=no-member
    temp_args = sys.argv[:]
    sys.argv = [sys.argv[0], '--diff', '--diff-filter', 'ACMR']

    try:
        from ansible.cli import CLI
        output = CLI.run()
    finally:
        sys.argv = temp_args

    options = output['options']
    args = GlobalCLIArgs.from_options(options)

    assert args['diff']
    assert options.diff

    assert args['diff_filter'] == 'ACMR'
    assert options.diff_filter == 'ACMR'



# Generated at 2022-06-11 17:46:22.342011
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {
        u'flag': True,
        b'bytes': b'\x00',
        u'list': [1, 2, 3],
        u'immutable': ImmutableDict({'a': 1}),
        u'set': set([1, 2, 3]),
    }
    cli_args = CLIArgs(mapping)

    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args, CLIArgs)

    # Test that the items are all frozen
    assert cli_args.flag is True
    assert cli_args.bytes == b'\x00'
    assert isinstance(cli_args.list, tuple)
    assert all(isinstance(x, int) for x in cli_args.list)

# Generated at 2022-06-11 17:46:24.332575
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    CLIArgs({'test': {'a': 1, 'b': 2, 'c': ['1']}})

# Generated at 2022-06-11 17:46:37.013858
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test constructor of GlobalCLIArgs

    Test the constructor of the GlobalCLIArgs class
    """
    # Test with a base python object
    data = {'a': 1}
    global_cli_args = GlobalCLIArgs(data)
    assert global_cli_args['a'] == data['a']

    # Test with a list
    data = {'a': [1]}
    global_cli_args = GlobalCLIArgs(data)
    assert global_cli_args['a'][0] == data['a'][0]

    # Test with a tuple
    data = {'a': (1,)}
    global_cli_args = GlobalCLIArgs(data)
    assert global_cli_args['a'][0] == data['a'][0]

    # Test with a dictionary

# Generated at 2022-06-11 17:46:48.094029
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': {'b': 'c'}, 'b': ('d', 'e'), 'c': ['f', 'g', {'h': 'i'}], 'd': 'j', 'e': set(['k', 'l'])}

    immutable_dict = CLIArgs(test_dict)

    assert(immutable_dict['b'] == ('d', 'e'))
    assert(immutable_dict['c'][2]['h'] == 'i')
    assert(immutable_dict['e'] == frozenset(['k', 'l']))

    try:
        hashable_set = immutable_dict['e']
        hashable_set.add('should_fail')
    except:
        hashable_set = None

    assert(hashable_set is None)

# Generated at 2022-06-11 17:46:51.339859
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():  # pylint: disable=unused-argument
    class Test(_ABCSingleton):
        pass

    test = Test()
    assert test.zomg == test

# Generated at 2022-06-11 17:46:53.818169
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A:
        pass

    class B(A, metaclass=_ABCSingleton):
        pass

    assert isinstance(B(), B)
    assert isinstance(B(), A)

# Generated at 2022-06-11 17:47:03.120777
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.basic import AnsibleModule
    class Options:
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    coverage_options = {'coverage_debug': False, 'coverage_show_missing': False}
    options = Options(**coverage_options)
    my_args = CLIArgs.from_options(options)
    assert my_args is not None
    assert len(my_args) == 2
    assert options.coverage_debug == my_args['coverage_debug']
    assert coverage_options['coverage_debug'] == my_args['coverage_debug']



# Generated at 2022-06-11 17:47:04.695607
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Dummy(_ABCSingleton):
        pass



# Generated at 2022-06-11 17:47:11.023417
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Test class _ABCSingleton

    Test that the metaclass _ABCSingleton throws an error if it does not know which metaclass
    to use.  This is expected to fail as there is no real code that implements it, but we want to
    make sure that the code is doing what we expect.
    """
    class A(object):
        __metaclass__ = _ABCSingleton
    assert A() is not None

# Generated at 2022-06-11 17:47:20.361939
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    inputs = {'bool_flag_set': True, 'string_flag': 'foo', 'list_flag': ['bar']}
    # inputs that are supposed to be immutable
    immutables = [{'dict_flag': {'foo': 'foo', 'bar': 'bar'}},
                  {'list_flag': ['foo', 'bar']},
                  {'set_flag': {'foo', 'bar'}}]

    for immutable in immutables:
        inputs.update(immutable)

        # Create a CLIArgs object and check for immutability
        cliargs = CLIArgs(inputs)
        for key in inputs:
            assert not isinstance(inputs[key], ImmutableDict), key

        # Test all branches except str, unicode, and list
        cliargs = CLIArgs.from_options(cliargs)

# Generated at 2022-06-11 17:47:31.508578
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import ansible.module_utils.basic
    test_cli_args = ansible.module_utils.basic.AnsibleModule(
        argument_spec={'foo': {'type': 'str'}, 'bar': {'type': 'str'}},
        supports_check_mode=True,
        mutually_exclusive=[['foo', 'bar']]
    )

    args = CLIArgs({'hello': 'world', 'goodbye': ['cruel', 'world']})
    assert not isinstance(args, Mapping), 'CLIArgs should not support reassignment of items'
    assert not isinstance(args.get('goodbye'), List), 'CLIArgs should return immutable containers'
    assert isinstance(args.get('goodbye'), Tuple), 'CLIArgs should return immutable containers'


# Generated at 2022-06-11 17:47:44.441473
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import json
    import tempfile
    import textwrap
    import yaml

    # Setup
    with tempfile.NamedTemporaryFile() as temp_file:
        temp_file_name = temp_file.name
        test_data = {'test': 'data'}
        yaml.dump(test_data, temp_file)
        temp_file.flush()
        test_args = CLIArgs(
            dict(
                test_argument=True,
                test_argument_with_data='test data',
                test_argument_with_json=json.dumps(test_data),
                test_argument_with_yaml=temp_file_name
            )
        )

    # Unit test
    assert isinstance(test_args, Mapping)
    assert 'test_argument' in test_args


# Generated at 2022-06-11 17:47:56.988373
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # The CLIArgs class constructor takes a mapping object and converts it
    # into an ImmutableDict. If the mapping object (and any nested data
    # structures) contains a dict, list, set, or tuple, the data structure
    # will be converted to frozenset, tuple, and ImmutableDict respectively.
    # Strings will be left alone.
    mapping1 = {
        'a': {
            'b': [
                'c',
                'd',
                {'e': 'f'},
            ],
        },
        'h': 'i',
    }

    mapping2 = {
        'a': frozenset({'a', 'b'}),
        'b': [
            'a',
            'b',
            {'c': 'd'}
        ],
    }


# Generated at 2022-06-11 17:48:07.579998
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.six import PY3
    import ansible.module_utils.basic

    # Create an options object to pass to GlobalCLIArgs()
    class Options(object):
        pass
    options = Options()
    options.module_path = '/path/to/ansible/module/utilities/basic.py'
    options.connection = 'smart'
    options.forks = 5
    options.remote_user = 'ansible'
    options.private_key_file = '/path/to/private/key'
    options.ssh_common_args = None
    options.ssh_extra_args = None
    options.sftp_extra_args = None
    options.scp_extra_args = None
    options.become = False
    options.become_method = 'sudo'
    options

# Generated at 2022-06-11 17:48:17.807037
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.removed import removed
    removed('Module utils', version='2.4')

    d = ImmutableDict({'a': 1})
    assert id(CLIArgs(d)) != id(d)

    d = ImmutableDict({'a': [1, 2]})
    assert id(CLIArgs(d)) != id(d)
    assert id(CLIArgs(d)['a']) != id(d['a'])

    d = ImmutableDict({'a': {'b': 1}})
    assert id(CLIArgs(d)) != id(d)
    assert id(CLIArgs(d)['a']) != id(d['a'])

    d = ImmutableDict({'a': {'b': [1, 2]}})
   

# Generated at 2022-06-11 17:48:25.554670
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test if CLIArgs is correctly constructed
    """
    source = {'a': [1, 2, 3],
              'b': [{'c': {'d': 4, 'e': 5, 'f': 6},
                     'g': 7,
                     'h': 8}],
              'i': {'j': {'k': 9, 'l': 10}},
              'm': 'n'}
    cli_args = CLIArgs(source)
    assert cli_args == source

# Generated at 2022-06-11 17:48:33.132036
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test CLIArgs.
    """
    import pytest
    args = CLIArgs({'key1': 'value', 'key2': 'value2'})
    assert args['key1'] == 'value'
    assert args['key2'] == 'value2'
    with pytest.raises(KeyError):
        args['key3']
    with pytest.raises(TypeError):
        args['key1'] = 'value3'
    with pytest.raises(TypeError):
        del args['key1']


# Generated at 2022-06-11 17:48:43.394081
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class options(object):
        def __init__(self, dict):
            self.__dict__.update(dict)

    opts = options({'foo': 1, 'bar': 2, 'bam': {'foobar': 3}, 'boom': [1, 2, 3]})
    args = GlobalCLIArgs.from_options(opts)

    assert isinstance(args['bar'], int)
    assert isinstance(args['foo'], int)

    assert isinstance(args['bam'], ImmutableDict)
    assert isinstance(args['bam']['foobar'], int)

    assert isinstance(args['boom'], tuple)
    assert isinstance(args['boom'][0], int)

# Generated at 2022-06-11 17:48:46.681228
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 1, 'b': 2})
    assert isinstance(args, Container)
    assert args == {'a': 1, 'b': 2}

# Generated at 2022-06-11 17:48:48.048617
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class test_abc(object):
        __metaclass__ = _ABCSingleton

    class test_abc_deriv(test_abc):
        pass

# Generated at 2022-06-11 17:48:56.986439
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MySingleton(_ABCSingleton):
        pass

    # Make sure that the metaclass knows how to get the correct order when inheriting from both ABCMeta and Singleton
    class MyABCSingleton(_ABCSingleton,
                         metaclass=ABCMeta):
        pass

    # Wait up to a second for the class to be compiled and added to the Singleton cache
    import time
    start_time = time.time()
    elapsed_time = 0
    end_time = start_time + 1
    while (not MySingleton.__singleton_instance__) and (elapsed_time < end_time):
        time.sleep(0.1)
        elapsed_time = time.time()
    assert MySingleton.__singleton_instance__ is not None

    # Wait up to a second for the class to be compiled and added to the Sing

# Generated at 2022-06-11 17:49:06.657423
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Test if metaclass _ABCSingleton works as expected.
    It is a Singleton and ABCMeta based meta class.
    Tested with its class GlobalCLIArgs.
    It should return the same instance for different
    initiation calls and is subclass of ABCMeta and Singleton.
    """
    a = GlobalCLIArgs({'a': 1})
    b = GlobalCLIArgs({'b': 2})
    c = GlobalCLIArgs({'c': 3})

    assert a is b
    assert b is c
    assert a is c

    assert issubclass(GlobalCLIArgs, Singleton)
    assert issubclass(GlobalCLIArgs, ABCMeta)

# Generated at 2022-06-11 17:49:14.978516
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert GlobalCLIArgs is GlobalCLIArgs()

# Generated at 2022-06-11 17:49:25.782557
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class _MockOption(object):
        def __init__(self, dictobj):
            self.__dict__ = dictobj

    dictobj = {'foo': 'bar',
               'bar': {'baz': 'foo'},
               'baz': ['bar', 'foo'],
               'foo_bar': [{'baz': 'foo'}],
               'bar_baz': ['bar', {'foo': 'bar'}],
               'baz_foo': [{'baz': 'foo'}, ['bar', 'baz']]}

# Generated at 2022-06-11 17:49:28.437914
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton):
        pass

    class Bar(_ABCSingleton):
        pass

    assert Foo() is Foo()
    assert Bar() is Bar()

# Generated at 2022-06-11 17:49:36.273634
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    d = {
        'inventory': '/playbook/hosts',
        'verbosity': 5,
        'diff': True,
    }
    c = CLIArgs(d)
    # Make sure we can't change c
    with pytest.raises(TypeError):
        c['foo'] = 'bar'

    # Make sure we can't change the internal dictionary
    with pytest.raises(TypeError):
        c['verbosity'] = 7

    with pytest.raises(AttributeError):
        c.inventory = '/other/hosts'

    # Make sure we can't replace an internal dictionary
    with pytest.raises(TypeError):
        c.__dict__ = {}

# Generated at 2022-06-11 17:49:40.977114
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        pass
    test1 = Test()
    test2 = Test()
    if test1 is not test2:
        raise RuntimeError('_ABCSingleton is not a Singleton')
    if not isinstance(Test(), Test):
        raise RuntimeError('_ABCSingleton does not mix in with ABCMeta')

# Generated at 2022-06-11 17:49:41.925605
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({'foo': 'bar'})

# Generated at 2022-06-11 17:49:42.531668
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    pass

# Generated at 2022-06-11 17:49:50.692159
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.vars import combine_vars
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import string_types

    # check_raw option
    assert isinstance(GlobalCLIArgs.from_options({'check_raw': 'yes'}), ImmutableDict)
    assert isinstance(GlobalCLIArgs.from_options({'check_raw': True}), ImmutableDict)
    assert isinstance(GlobalCLIArgs.from_options({'check_raw': b'yes'}), ImmutableDict)

    # check option

# Generated at 2022-06-11 17:49:57.805551
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import datetime
    options = dict(boolean=True, list=[1, 2, 3], number=5, dictionary=dict(a=1, b=2), string='foo', none=None,
                   datetime=datetime.datetime(2016, 12, 25))
    cliargs = CLIArgs.from_options(options)
    for key, value in options.items():
        assert cliargs._data[key] == value

test_CLIArgs()

# Generated at 2022-06-11 17:50:03.703947
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--global_cli_args_foo', dest='global_cli_args_foo', default=[], type=int, action='append',
                        help='GlobalCLIArgs test argument')
    options = parser.parse_args(['--global_cli_args_foo', '1', '--global_cli_args_foo', '2', '--global_cli_args_foo', '3'])
    gca1 = GlobalCLIArgs.from_options(options)
    gca2 = GlobalCLIArgs.from_options(options)
    assert gca1 == gca2


# Generated at 2022-06-11 17:50:11.820476
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs.from_options(None)

# Generated at 2022-06-11 17:50:16.404390
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    foo = GlobalCLIArgs.from_options(ImmutableDict({'a': {'b': 1}}))
    assert isinstance(foo, GlobalCLIArgs)
    assert 'a' in foo
    foo['a'] = 2
    assert 'a' not in foo

# Generated at 2022-06-11 17:50:20.613039
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton(_ABCSingleton):
        def __init__(self):
            pass

    class TestSingleton2(_ABCSingleton):
        def __init__(self):
            pass

    assert TestSingleton() is TestSingleton()
    assert TestSingleton2() is TestSingleton2()
    assert TestSingleton() is not TestSingleton2()

# Generated at 2022-06-11 17:50:26.971065
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import tempfile
    import os
    import json


# Generated at 2022-06-11 17:50:34.808522
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    import optparse

    option_list = optparse.OptionParser().option_list
    for option in option_list:
        if option.dest == 'connection':
            break
    else:
        print("test_GlobalCLIArgs(): Cannot find 'connection' argument from optparse.OptionParser().option_list")
        return False

    options = optparse.Values({'connection': 'smart'})
    args = GlobalCLIArgs.from_options(options)
    if args.get('connection') != 'smart':
        print("test_GlobalCLIArgs(): args.get('connection') = '%s'", args.get('connection'))
        return False

    # Test the constructor's immutability
    try:
        args['connection'] = 'elivs'
    except TypeError:
        # Passed
        pass

# Generated at 2022-06-11 17:50:37.389146
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Ensure no exceptions are raised due to metaclass ordering
    class TestClass(metaclass=_ABCSingleton):
        pass

# Generated at 2022-06-11 17:50:38.478498
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({"a": 1, "b": 2})

# Generated at 2022-06-11 17:50:40.686133
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    toplevel = dict(one=1, two=2, three=3)
    options = CLIArgs(toplevel)
    assert options == toplevel

# Generated at 2022-06-11 17:50:51.431321
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Set up test variables
    k1 = 'key1'
    v1 = 'value1'
    k2 = 'key2'
    v2 = 'value2'
    k3 = 'key3'
    v3 = 'value3'
    k4 = 'key4'
    v4 = ['value4a', 'value4b']
    k5 = 'key5'
    v5 = {'key5-1': 'value5-1', 'key5-2': 'value5-2'}
    v6 = {'key6-1': {'key6-2': 'value6-2'}}
    test_dict = {k1: v1, k2: v2, v3: k3, k4: v4, k5: v5, v6: k6}

    # Create object


# Generated at 2022-06-11 17:51:02.998353
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        def __init__(self):
            self.foo = 1
            self.bar = {'x': [1, 2, 3], 'y': None}
            self.baz = {'x': {'a': 1, 'b': 2}, 'y': None}
            self.cork = ['a', 'b', 'c']

    options = Options()
    cliargs = CLIArgs.from_options(options)
    assert cliargs['foo'] == 1
    assert cliargs['bar'] == ImmutableDict({'x': [1, 2, 3], 'y': None})
    assert cliargs['baz'] == ImmutableDict({'x': ImmutableDict({'a': 1, 'b': 2}), 'y': None})
    assert cliargs['cork']

# Generated at 2022-06-11 17:51:25.807910
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import os
    import tempfile
    import six
    import stat

    # Create a temp file with content that can be read by open
    (fd, test_path) = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as f:
        f.write('content')


# Generated at 2022-06-11 17:51:28.114198
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs.from_options(GlobalCLIArgs.default_options())
    assert global_cli_args == {}

# Generated at 2022-06-11 17:51:34.189317
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # For py2, CLIArgs is a new style class which is not a new style class in py3
    if isinstance(GlobalCLIArgs, type):
        assert issubclass(GlobalCLIArgs, CLIArgs)
    else:
        assert issubclass(GlobalCLIArgs, CLIArgs)
    assert issubclass(GlobalCLIArgs, Singleton)



# Generated at 2022-06-11 17:51:44.939507
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-11 17:51:48.913406
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    x = {'a': 1, 'b': {'c': 3, 'd': [4, 5]}}
    assert CLIArgs(x) == {'a': 1, 'b': {'c': 3, 'd': (4, 5)}}

# Generated at 2022-06-11 17:51:54.397891
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # The test case for this is in test_utils/test_singleton.py
    # We're just calling the constructor here to make 100% coverage work
    @add_metaclass(_ABCSingleton)
    class _Test(object):
        pass

    _Test()

# Generated at 2022-06-11 17:52:04.225228
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-locals

    class Options(object):
        """
        Just a dummy object to hold command line flags
        """
        def __init__(self, args=None):
            self.__dict__ = args


# Generated at 2022-06-11 17:52:10.353469
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Test making a CLIArgs object from a mock options object"""

    class MockOptions:
        """Mock for OptParse Options object"""

        my_option = "some_value"
        my_other_option = "another_value"

    mock_options = MockOptions()

    assert CLIArgs.from_options(mock_options).my_option == "some_value"



# Generated at 2022-06-11 17:52:18.946265
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    cli_args = CLIArgs(vars(collections.namedtuple('options', ['foo', 'bar'])
                            (foo=['Hello', 'World'], bar={'abc': '123', 'xyz': ['abc', 42, {'def': '42'}]})))
    assert isinstance(cli_args.get('foo'), tuple)
    assert isinstance(cli_args.get('bar'), ImmutableDict)
    assert isinstance(cli_args.get('bar').get('xyz'), tuple)
    assert isinstance(cli_args.get('bar').get('xyz')[2], ImmutableDict)
    assert isinstance(cli_args.get('bar').get('xyz')[2].get('def'), str)

# Generated at 2022-06-11 17:52:22.728131
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    options = type('', (), {'a': 1, 'b': '2', 'c': ['3', 4]})()
    assert CLIArgs.from_options(options) == {'a': 1, 'b': '2', 'c': ('3', 4)}

# Generated at 2022-06-11 17:53:00.104223
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
        def __init__(self):
            self.a = 'a'

    class C(object):
        def __init__(self):
            self.c = 'c'

    class B(C, A):
        pass

    assert A() is A()
    assert B() is B()
    assert B() is C()

# Generated at 2022-06-11 17:53:05.604864
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = type('FakeOptions', (object,), dict(verbosity=1, connection='local'))()
    cli_args = GlobalCLIArgs.from_options(options)
    assert isinstance(cli_args['verbosity'], int)
    assert cli_args['connection'] == 'local'

    try:
        cli_args['verbosity'] = 2
    except TypeError:
        pass
    else:
        assert False

# Generated at 2022-06-11 17:53:11.144262
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.context import AnsibleContext

    args = CLIArgs.from_options(AnsibleContext().options)
    assert isinstance(args, ImmutableDict)

    args['foo'] = 'bar'
    assert args['foo'] == 'bar'

    with pytest.raises(TypeError):
        args['foo'] = 'baz'

# Generated at 2022-06-11 17:53:16.622348
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_arg = 'foo'
    test_val = 'bar'
    test_args = GlobalCLIArgs({test_arg: test_val})
    assert isinstance(test_args, GlobalCLIArgs)
    assert isinstance(test_args, ImmutableDict)
    assert test_args[test_arg] == test_val
    assert test_args is GlobalCLIArgs()

# Generated at 2022-06-11 17:53:21.200199
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Test that we can instantiate _ABCSingleton
    """
    class TestABCSingleton(_ABCSingleton):
        """
        A Test class for _ABCSingleton
        """
        pass

    # class TestABCSingleton cannot be instantiated
    TestABCSingleton()

    # Make this class a singleton
    class TestABCSingleton(_ABCSingleton):
        """
        A Test class for _ABCSingleton
        """
        pass

    TestABCSingleton()

# Generated at 2022-06-11 17:53:30.868331
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-11 17:53:42.325821
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.module_utils.common.collections import MutableSet
    from ansible.module_utils.common.collections import MutableSequence
    from ansible.module_utils.common.collections import MutableDict
    from ansible.module_utils.common.collections import MutableList

    def assert_immutable(obj):
        if isinstance(obj, MutableMapping):
            raise AssertionError('MutableMapping subclass is not allowed: %s' % obj)
        elif isinstance(obj, MutableSet):
            raise AssertionError('MutableSet subclass is not allowed: %s' % obj)

# Generated at 2022-06-11 17:53:45.809590
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = type('options', (object,), {'cmdline': True})
    assert id(GlobalCLIArgs.from_options(options)) == id(GlobalCLIArgs())

# Generated at 2022-06-11 17:53:55.683534
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class FakeOptions:
        def __init__(self, dct):
            self.__dict__ = dct

    options = FakeOptions({
        "foo": "bar",
        "baz": [1, 2, 3],
        "qux": {
            "quux": True,
        },
    })
    args = CLIArgs.from_options(options)

    assert args.foo == "bar"
    assert args.baz == (1, 2, 3)

    assert args.qux.quux is True

    try:
        args.foo = "modified foo"
        assert False, "foo shouldn't be assignable"
    except TypeError:
        pass


# Generated at 2022-06-11 17:54:05.789368
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.config.manager import ConfigManager
    from ansible.config.data import ConfigData
    from ansible.cli.arguments import Options
    from ansible.cli.config import AnsibleConfigCLI
    from ansible.cli.galaxy import GalaxyCLI
    from ansible.cli.inventory import InventoryCLI
    from ansible.cli.playbook import PlaybookCLI
    from ansible.cli.adhoc import AdHocCLI
    from ansible.cli.vault import VaultCLI
    from ansible.plugins.loader import ModuleLoader
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader

    class TestOption(object):
        def __init__(self, dest, value):
            self.dest = dest
            self.value = value
