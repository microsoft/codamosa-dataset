

# Generated at 2022-06-11 17:45:08.041615
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    c = CLIArgs({"a": 1, "b": {"c": 2}, "d": [1, 2]})
    assert c["a"] == 1
    assert c["b"]["c"] == 2
    assert c["d"][1] == 2
    assert isinstance(c, ImmutableDict)
    assert isinstance(c["b"], ImmutableDict)
    assert isinstance(c["d"], tuple)
    assert not isinstance(c["d"], list)

# Generated at 2022-06-11 17:45:19.784487
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli.adhoc import AdHocCLI
    from ansible.cli import CLI
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    my_args = AdHocCLI().parse()
    my_cli = CLI(args=my_args)
    pb = Play.load(dict(name="freebsd", hosts=["bsd1"], gather_facts="no"),
                   play_context=PlayContext(), variable_manager=my_cli.variable_manager, loader=my_cli.loader)
    my_cli.options = my_args
    my_cli.options.connection = "local"
    my_cli.options.module_path = None
    my_cli.options.forks = 5

# Generated at 2022-06-11 17:45:24.631754
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    class TestClass2(object):
        __metaclass__ = _ABCSingleton

        def __class_init__(self):
            self.val = 'value'

    assert TestClass is TestClass2
    assert TestClass().val == 'value'

# Generated at 2022-06-11 17:45:36.952991
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    data = {'a': 'b', 'c': [1, 2, 3], 'd': 4, 'e': {'f': 5}, 'g': {'h': 6}}
    cli_args = CLIArgs(data)
    assert cli_args['a'] == 'b'
    assert cli_args['c'] == (1, 2, 3)
    assert cli_args['d'] == 4
    assert cli_args['e']['f'] == 5
    assert cli_args['g']['h'] == 6

    # Change original data to see if cli_args is immutable
    data['a'] = 'aaa'
    data['c'].append(4)
    data['e']['f'] = 8
    data['g']['h'] = 9

    # Check that changes in original

# Generated at 2022-06-11 17:45:39.950580
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
    a = TestClass()
    b = TestClass()
    assert a is b

# Generated at 2022-06-11 17:45:49.889308
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import unittest

    class TestCase(unittest.TestCase):
        def test(self):
            from ansible.parsing import vault as cliargs

            non_dict = cliargs.CLIArgs(42)
            self.assertEqual(non_dict, 42)

            test_dict = {'a': {'b': 'b', 'c': 'c', 'd': 'd'}, 'b': u'b2', 'foo': {'bar': ['a', 'b', 'c', 'd'], 'baz': 'baz'}}

# Generated at 2022-06-11 17:45:51.842006
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        pass
    assert isinstance(Test(), Test)

# Generated at 2022-06-11 17:46:01.961091
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-11 17:46:06.260491
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        __metaclass__ = ABCMeta

        def __init__(self):
            print(self)
            self._a = 10
            super(A, self).__init__()

    A()

# Generated at 2022-06-11 17:46:11.222792
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class test_ABCSingleton(object):
        pass
    assert issubclass(test_ABCSingleton, ABCMeta)
    assert issubclass(test_ABCSingleton, Singleton)

    obj1 = test_ABCSingleton()
    obj2 = test_ABCSingleton()
    assert obj1 is obj2

# Generated at 2022-06-11 17:46:20.255148
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Test that we can create subclasses of _ABCSingleton
    """
    class TempABCSingleton(_ABCSingleton):
        """
        Test class for _ABCSingleton
        """
        def __init__(self, mapping):
            self.map = mapping
    mapping = {'a': 'b'}
    obj1 = TempABCSingleton(mapping)
    obj2 = TempABCSingleton(mapping)
    assert obj1 is obj2

# Generated at 2022-06-11 17:46:22.535250
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(metaclass=_ABCSingleton):
        pass

    Test()
    Test()
    Test()

# Generated at 2022-06-11 17:46:31.073415
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    e1 = {'a': 'e1', 'b': 'e1', 'c': 'e1'}
    e2 = {'a': 'e2', 'b': 'e2', 'c': 'e2'}
    e3 = {'a': 'e3', 'b': 'e3', 'c': 'e3'}

    cliargs = [
        {'a': e1, 'b': e1, 'c': e1},
        {'a': e2, 'b': e2, 'c': e2},
        {'a': e3, 'b': e3, 'c': e3},
    ]

    for args in cliargs:
        GlobalCLIArgs(args)

    # Return the last set of args
    return args

# Generated at 2022-06-11 17:46:33.099142
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Reassure ourselves that the GlobalCLIArgs class can be constructed without error.
    """
    GlobalCLIArgs({})

# Generated at 2022-06-11 17:46:35.934957
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    mapping = {'foo': 'bar', 'bar': 'baz'}
    args = GlobalCLIArgs(mapping)
    assert args['foo'] == 'bar'
    assert args['bar'] == 'baz'

# Generated at 2022-06-11 17:46:46.773694
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args1 = {'foo': 'bar', 'bam': [1, 2], 'boo': {'boodo' : 'bang'}}
    args2 = {'foo': 'bam', 'bam': [3, 4], 'boo': {'boodo' : 'bam'}}
    args3 = {'foo': 'bam', 'bam': [3, 4], 'boo': {'boodo' : 'bam'}}

    g1 = GlobalCLIArgs(args1)
    g2 = GlobalCLIArgs(args2)

    assert id(g1) == id(g2)
    assert g1 != g2

    g1.mutate(args3)

    assert id(g1) == id(g2)
    assert g1 == g2



# Generated at 2022-06-11 17:46:56.358310
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    opts = {
        "one": 1,
        "two": 2,
        "three": 3,
        "four": 4,
        "five": 5,
        "six": 6,
        "seven": 7,
        "eight": 8,
        "nine": 9,
        "ten": 10,
        "eleven": 11,
        "twelve": 12,
        "thirteen": 13,
        "fourteen": 14,
        "fifteen": 15,
        "sixteen": 16
    }
    cli_args = GlobalCLIArgs(opts)
    assert isinstance(cli_args, GlobalCLIArgs)
    assert cli_args.one == 1
    assert cli_args.six == 6
    assert cli_args.ten == 10

# Generated at 2022-06-11 17:47:04.918231
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    d = {'a': 4, 'b': 'abc', 'c': [1, 2, 3], 'd': {'one': 1, 'two': 2, 'three': 3, 'four': [1, 2, 3]}, 'e': {'one': 1, 'two': 2}}

    a = CLIArgs(d)

    assert a['a'] == 4
    assert a['b'] == 'abc'
    assert a['c'] == (1, 2, 3)
    assert a['d']['one'] == 1
    assert a['d']['two'] == 2
    assert a['d']['three'] == 3
    assert a['d']['four'] == (1, 2, 3)
    assert a['e'] == ImmutableDict({'one': 1, 'two': 2})


# Generated at 2022-06-11 17:47:16.107688
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.constants import DEFAULT_DEBUG
    from ansible.module_utils.common.warnings import AnsibleDeprecationWarning
    import warnings

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        GlobalCLIArgs(dict(module_path='/path/to/module',))
    assert(len(w) == 1)
    assert(issubclass(w[-1].category, AnsibleDeprecationWarning))
    assert("Options specfied on the command line" in str(w[-1].message))

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")

# Generated at 2022-06-11 17:47:18.065861
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A:
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    assert B() is B()

# Generated at 2022-06-11 17:47:28.754460
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 'A', 'b': [1, 2, 3], 'c': {'a': 'A', 'b': [1, 2, 3]}}
    test_object = CLIArgs(test_dict)
    assert isinstance(test_object, ImmutableDict)
    assert test_object == ImmutableDict({'a': 'A', 'b': (1, 2, 3), 'c': ImmutableDict({'a': 'A', 'b': (1, 2, 3)})})

# Generated at 2022-06-11 17:47:40.331787
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _Foo(_ABCSingleton):
        pass

    class _Bar(_ABCSingleton):
        pass

    foo1 = _Foo()
    bar1 = _Bar()
    foo1.some_val = 42

    # If the _ABCSingleton is working correctly, then accessing foo2 will blow up on us because the
    # constructor of _Foo never got to execute since _Foo is already initialized.
    foo2 = _Foo()
    # If the _ABCSingleton is working correctly, then accessing bar2 will blow up on us because the
    # constructor of _Bar never got to execute since _Bar is already initialized.
    bar2 = _Bar()

    # The following should be allowed since foo1 is from the class _Foo
    foo1.some_val += 1

    # The following should be allowed since bar1 is from the class

# Generated at 2022-06-11 17:47:45.060584
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_args = GlobalCLIArgs({ 'host_key_checking': False, 'parameters': {'n': 1, 'm': 2} })
    assert(global_args == {'host_key_checking': False, 'parameters': {'n': 1, 'm': 2}})

# Generated at 2022-06-11 17:47:55.602170
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.display import Display
    from ansible.config.manager import ConfigManager
    from ansible.release import __version__
    from ansible.utils.hashing import checksum_s

    display = Display()
    config = ConfigManager(None, [])

    # Make a hash of the global config file
    config_hash = checksum_s(config.global_config_path)

    # This is what an argparse Namespace looks like.  The IGNORE_ENVIRONMENT variable has been added after
    # parsing to prevent some tests failing.  It is not added to the parser because it breaks some other tests.

# Generated at 2022-06-11 17:47:59.111393
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Dummy(object):
        __metaclass__ = _ABCSingleton
    try:
        a = Dummy()
        b = Dummy()
        assert a is b
        assert a.__class__.__name__ == '_ABCSingleton'
    except TypeError:
        pass

# Generated at 2022-06-11 17:48:09.539033
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test CLIArgs

    :return: True if test passed
    """

    # Test construction of CLIArgs
    # Should accept a dictionary
    test_dict = {'foo1': 'bar1', 'foo2': 'bar2'}
    test_args = CLIArgs(test_dict)

    # CLIArgs should have correct type
    assert isinstance(test_args, CLIArgs)

    # CLIArgs should be an ImmutableDict
    assert isinstance(test_args, ImmutableDict)

    # Arguments should be accessible like a dictionary
    assert test_args['foo1'] == 'bar1'

    # Test init with tuple
    # Initialize with a tuple
    test_args = CLIArgs((('foo1', 'bar1'), ('foo2', 'bar2')))

    # Arguments should be accessible like a dictionary


# Generated at 2022-06-11 17:48:14.956486
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import mock
    with mock.patch.object(CLIArgs, '__init__') as mock_CLIArgs_init:
        inst = mock_CLIArgs_init.return_value
        i = CLIArgs.from_options(mock.sentinel.options)
        mock_CLIArgs_init.assert_called_once()
        assert i == inst

# Generated at 2022-06-11 17:48:22.536937
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.display import Display
    from ansible.utils.plugins import PluginLoader
    from ansible.utils.path import module_loader


# Generated at 2022-06-11 17:48:25.080858
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABCSingleton(object):
        __metaclass__ = _ABCSingleton
    assert TestABCSingleton is TestABCSingleton()

# Generated at 2022-06-11 17:48:29.644659
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ABCSingleton1(metaclass=_ABCSingleton):
        """
        A class based on ABCMeta should be acceptable to _ABCSingleton
        """
        pass

    class ABCSingleton2(metaclass=_ABCSingleton):
        """
        A class based on ABCMeta should be acceptable to _ABCSingleton
        """
        pass

    assert ABCSingleton1 is ABCSingleton2

# Generated at 2022-06-11 17:48:39.898717
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    class B(metaclass=_ABCSingleton):
        pass
    class C(A, B):
        pass

    assert issubclass(C, A)
    assert issubclass(C, B)

# Generated at 2022-06-11 17:48:47.434808
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs(dict(
        foo=dict(bar=dict(blah=1), bar1=dict(blah1=2)),
        foo1=dict(bar2=dict(blah2=3), bar3=dict(blah3=4)),
        foo2=1))
    assert isinstance(args, CLIArgs)
    assert isinstance(args, ImmutableDict)
    assert args['foo'] == dict(bar=dict(blah=1), bar1=dict(blah1=2))
    assert args['foo1'] == dict(bar2=dict(blah2=3), bar3=dict(blah3=4))
    assert args['foo2'] == 1

# Generated at 2022-06-11 17:48:50.685120
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Derived(_ABCSingleton):
        pass

    obj1 = Derived()
    obj2 = Derived()

    assert obj1 is obj2
    assert obj1 == obj2

# Generated at 2022-06-11 17:48:54.263280
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    containing_dict = {'a': 1, 'b': {'c': [2, 3, 4]}, 'd': {'e': 5}}
    cli_args = CLIArgs(containing_dict)
    assert isinstance(cli_args, ImmutableDict) is True
    assert cli_args == containing_dict

# Generated at 2022-06-11 17:49:01.182459
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs(
        {'forks': 5}
    )
    assert GlobalCLIArgs(
        {'forks': 5}
    ) == GlobalCLIArgs(
        {'forks': 5}
    )
    GlobalCLIArgs(
        {'forks': 5}
    )
    assert GlobalCLIArgs(
        {'forks': 5}
    ) is GlobalCLIArgs(
        {'forks': 5}
    )

# Generated at 2022-06-11 17:49:09.276811
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # no prior instance
    assert GlobalCLIArgs()._GlobalCLIArgs__instance is None
    # the following code is not allowed to execute
    # GlobalCLIArgs()
    # next line is ok
    GlobalCLIArgs.instance()
    # from now on, no need to call _instance()
    assert GlobalCLIArgs()._GlobalCLIArgs__instance is not None
    # the following code is not allowed to execute
    # GlobalCLIArgs()
    # the instance must be the same one
    assert GlobalCLIArgs()._GlobalCLIArgs__instance is GlobalCLIArgs()._GlobalCLIArgs__instance

# Generated at 2022-06-11 17:49:17.801756
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    a = CLIArgs({'a': [1, 2, 3], 'b': 'test string', 'c': {1: '2', 3: '4'}})
    assert a['a'] == (1, 2, 3)
    assert a['b'] == 'test string'
    try:
        a['a'].append(4)
    except AttributeError:
        pass
    else:
        assert False
    assert a['c'].get(1) == '2'
    assert a['c'].get(3) == '4'
    try:
        a['c'][4] = '5'
    except AttributeError:
        pass
    else:
        assert False
    assert a['c'].get(4) is None


# Generated at 2022-06-11 17:49:27.215756
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict

    # make a mutable dictionary
    mutable_dict = {}
    mutable_dict['a'] = 'abc'
    mutable_dict['b'] = 'def'

    # make a mutable list from the dictionary
    mutable_list = list(mutable_dict.items())

    temp_mapping = {}
    temp_mapping['a'] = mutable_list[0]
    temp_mapping['b'] = mutable_list[1]

    test_instance = CLIArgs(temp_mapping)

    # Check if the class properties are correctly initialized
    assert isinstance(test_instance, ImmutableDict)
    assert test_instance['a'] == ('a', 'abc')

# Generated at 2022-06-11 17:49:30.801817
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    def create_it():
        class A(_ABCSingleton):
            pass
        return A()

    a1 = create_it()
    a2 = create_it()
    assert a1 == a2
    assert a1 is a2

# Generated at 2022-06-11 17:49:37.185163
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    options = lambda **kwargs: type('', (object,), kwargs)
    options = options(
        var=set(['foo', 'bar']),
        list_var=['list', ['foo', 'bar']],
        dict_var={'key': ['foo', 'bar']})
    assert CLIArgs.from_options(options) == dict(
        var=frozenset(['foo', 'bar']),
        list_var=(['list', ['foo', 'bar']]),
        dict_var=ImmutableDict({'key': ['foo', 'bar']}))



# Generated at 2022-06-11 17:49:51.821219
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Let's make two classes with the same name but different content.  Can't
    # do this normally because the class is already defined by the time we
    # use the @add_metaclass decorator.
    class A(metaclass=_ABCSingleton):
        A = 'A'
        def foo(self):
            return 'foo'

    class B(metaclass=_ABCSingleton):
        B = 'B'
        def bar(self):
            return 'bar'

    # Check that the two classes are equivalent because they have been
    # converted into singletons.
    assert A is B
    assert A.A is B.B
    assert A.foo is B.foo
    assert A.bar is B.bar

    # Signal that test is pass
    return True

# Generated at 2022-06-11 17:49:55.194943
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import ansible.__main__
    # Test that the class compiles
    ansible.__main__.parse()
    # Test that the singleton is working
    assert GlobalCLIArgs() is GlobalCLIArgs()

# Generated at 2022-06-11 17:50:02.000289
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _TestClass1(object):
        __metaclass__ = _ABCSingleton

    class _TestClass2(_TestClass1):
        pass

    assert issubclass(_TestClass1, Singleton)
    assert issubclass(_TestClass2, Singleton)

    obj1 = _TestClass1()
    obj2 = _TestClass2()
    obj3 = _TestClass1()
    obj4 = _TestClass2()

    assert obj1 == obj3
    assert obj2 == obj4
    assert obj1 != obj2 and obj2 != obj1
    assert obj3 != obj4 and obj4 != obj3

# Generated at 2022-06-11 17:50:06.307082
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = {'verbosity': 4, 'foo': [1, 2, 3]}
    test_obj = GlobalCLIArgs(args)
    assert GlobalCLIArgs(args) == test_obj
    test_obj == GlobalCLIArgs.from_options(GlobalCLIArgs(args))

# Generated at 2022-06-11 17:50:17.793167
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'param1': {'param2': {'param3': 'value1', 'list': ['value2', 'value3']}}})
    assert args['param1']['param2']['param3'] == 'value1'
    assert args['param1']['param2']['list'] == ('value2', 'value3')

    args = CLIArgs({'param1': 'value1', 'param2': {'param3': 'value2', 'list': ['value4', 'value5']}})
    assert args['param1'] == 'value1'
    assert args['param2']['param3'] == 'value2'
    assert args['param2']['list'] == ('value4', 'value5')


# Generated at 2022-06-11 17:50:21.471489
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    class Bar(object):
        __metaclass__ = _ABCSingleton

    # Test that each new instance of a class with this metaclass is the same instance
    assert Foo() is Foo()
    assert Bar() is Bar()

# Generated at 2022-06-11 17:50:25.598263
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.hashing import checksum_s
    global_cli_args = GlobalCLIArgs.instance()
    assert global_cli_args.get('module_path', None) is not None
    assert global_cli_args.get('module_path', None) is not Sentinel.VALUE
    assert checksum_s(global_cli_args.get('module_path', None)) != checksum_s(Sentinel.VALUE)

# Generated at 2022-06-11 17:50:28.419504
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ImplementsABCSingleton(object):
        __metaclass__ = _ABCSingleton

    _ImplementsABCSingleton()

# Generated at 2022-06-11 17:50:39.058382
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--global', action='store_true')
    parser.add_argument('--branch', default=dict(a='a', b='b'))
    parser.add_argument('--leaf', default=set(['c', 'd']))
    args = GlobalCLIArgs.from_options(parser.parse_args(['--global']))
    assert isinstance(args, GlobalCLIArgs), type(args)
    assert args.get('global') is True, args.get('global')
    from ansible.module_utils.common.collections import ImmutableDict
    assert isinstance(args.get('branch'), ImmutableDict), type(args.get('branch'))

# Generated at 2022-06-11 17:50:42.277143
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A:
        __metaclass__ = _ABCSingleton

    assert isinstance(A(), A)
    assert isinstance(A(), Singleton)
    assert isinstance(A(), ABCMeta)

# Generated at 2022-06-11 17:51:01.677287
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Hello(object):
        __metaclass__ = _ABCSingleton

    hello1 = Hello()
    hello2 = Hello()
    assert id(hello1) == id(hello2)
    assert hello1 == hello2

# Generated at 2022-06-11 17:51:08.298606
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options:
        def __init__(self, arg1, arg2, arg3, arg4=None):
            self.arg1 = arg1
            self.arg2 = arg2
            self.arg3 = arg3
            self.arg4 = arg4

    global_cli_args = GlobalCLIArgs.from_options(Options(1, "two", [3, 4, 5],
                                                         {"arg6": [{"arg7": 7}]},))
    assert global_cli_args == ImmutableDict({
        'arg1': 1,
        'arg2': "two",
        'arg3': (3, 4, 5),
        'arg4': ImmutableDict({'arg6': (ImmutableDict({'arg7': 7}),)})
    })

# Generated at 2022-06-11 17:51:10.238268
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class TestMeta(_ABCSingleton):
        pass

    assert issubclass(TestMeta, ABCMeta)

# Generated at 2022-06-11 17:51:20.158968
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = dict(a=1, b=dict(d=5, e=6), c=[1, 2, 3, dict(f=7)])

    cli_args = CLIArgs(mapping)

    assert cli_args['a'] == 1
    assert cli_args['b'] == ImmutableDict(d=5, e=6)
    assert cli_args['c'] == (1, 2, 3, ImmutableDict(f=7))

    cli_args = CLIArgs(dict(a=1, b=(1, 2, 3)))
    assert cli_args['a'] == 1
    assert cli_args['b'] == (1, 2, 3)

    cli_args = CLIArgs(dict(a=1, b=set([1, 2, 3])))
    assert cli_

# Generated at 2022-06-11 17:51:23.784274
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # TestGlobalCLIArgs is a singleton class
    g1 = GlobalCLIArgs({'foo': 'bar'})
    g2 = GlobalCLIArgs({'foo': 'bar'})
    if g1 is g2:
        print('Test passed')
    else:
        print('Test failed')



# Generated at 2022-06-11 17:51:35.188491
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import unittest
    import copy

    class TestCLIArgs(unittest.TestCase):

        def test_copy_constructor(self):
            # Make test data that is not already immutable
            data = {'arg1': 'val1', 'arg2': {'narg1': 'nval1', 'narg2': {'nnarg1': 'nnval1'}}}
            data_copy = copy.deepcopy(data)

            # Call constructor
            temp = CLIArgs(data)

            # Check that it converted the input data
            self.assertEqual(temp, data_copy)
            self.assertNotEqual(temp, data)

            # Check that it didn't modify the input data
            self.assertEqual(data, data_copy)


# Generated at 2022-06-11 17:51:41.158576
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Create a Mapping object
    mapping = {
        'foo': 'bar',
        'baz': {
            'qux': 'quux',
            'quuz': ['corge', 'grault', 'garply']
        }
    }

    cli_args = CLIArgs(mapping)

    for key, value in mapping.items():
        assert value == cli_args[key]



# Generated at 2022-06-11 17:51:46.723313
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs({'verbosity': 1, 'module_path': {'name': 'value'}})
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args['verbosity'] == 1
    assert cli_args['module_path'] == {'name': 'value'}
    assert cli_args['module_path'] != {'name': 'value', 'key': 'value2'}

# Generated at 2022-06-11 17:51:51.816943
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A:
        pass

    class B(A, metaclass=_ABCSingleton):
        pass

    a = A()
    b = B()
    assert a is not b
    assert b is B()

# Generated at 2022-06-11 17:51:55.225820
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    global _ABCSingleton
    class a(_ABCSingleton):
        def __init__(self):
            self.foo = 'bar'
    a2 = a()
    assert a2.foo == 'bar'

# Generated at 2022-06-11 17:52:31.863342
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Make sure _ABCSingleton can actually be constructed.

    We do this to verify that when we use the add_metaclass method that it works with _ABCSingleton's
    custom __new__ method.
    """
    class MyClass(object):
        __metaclass__ = _ABCSingleton
    MyClass()


# Generated at 2022-06-11 17:52:41.368123
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    obj = CLIArgs({'a': {'b': {'c': 'd'}}})
    assert obj.a.b.c == 'd'
    assert obj.a.b.d == CLIArgs.__missing__
    assert obj.a.d == CLIArgs.__missing__
    assert obj.d == CLIArgs.__missing__
    # Should be an immutable dict so it throws an exception if we try to change it
    try:
        obj.a.b.c = 'z'
        raise AssertionError('Cannot assign to a member of an ImmutableDict')
    except TypeError:
        pass
    try:
        obj.a.b = 'z'
        raise AssertionError('Cannot assign to a member')
    except TypeError:
        pass



# Generated at 2022-06-11 17:52:47.641103
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.path import unfrackpath
    from ansible.config.loader import ConfigLoader
    from ansible.cli import CLI

    cli = CLI(args=['--config', unfrackpath('/dev/null')])
    opts = cli.parse()
    config_loader = ConfigLoader()
    args = CLIArgs.from_options(opts)
    config_loader.load_from_file(args.config_file)
    assert isinstance(args, CLIArgs)

# Generated at 2022-06-11 17:52:50.218106
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class FooSingleton(_ABCSingleton):
        pass
    class Foo(metaclass=FooSingleton):
        pass
    assert Foo() is Foo()

# Generated at 2022-06-11 17:52:56.283955
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import unittest
    class TestCLIArgs(unittest.TestCase):

        def test_init(self):
            test_mapping = {'foo' : 'bar'}
            obj = CLIArgs(test_mapping)
            self.assertTrue(isinstance(obj, ImmutableDict))
            obj['foo'] = 'baz'
            with self.assertRaises(Exception):
                obj['foo'] = 'baz'
            self.assertTrue(obj['foo'] == 'bar')
    unittest.main()

# Generated at 2022-06-11 17:53:06.232227
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Unit test for CLIArgs"""
    import pprint
    # Make a mapping that contains normal data types and nested containers

# Generated at 2022-06-11 17:53:14.357321
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 1, 'b': {'c': {'1': 1, '2': 2}}, 'd': [1, 2, 3]}
    expected_dict = {'a': 1, 'b': ImmutableDict({'c': ImmutableDict({'1': 1, '2': 2})}), 'd': (1, 2, 3)}
    cli_args_instance = CLIArgs(test_dict)
    assert isinstance(cli_args_instance, ImmutableDict)
    assert cli_args_instance == expected_dict

# Generated at 2022-06-11 17:53:22.341097
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test that GlobalCLIArgs is a Singleton
    """
    import sys
    from six import PY2
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_text

    args = GlobalCLIArgs({u'foo': u'bar'})
    assert args[u'foo'] == u'bar'

    # Make sure we can't modify the singleton
    if not PY2:
        # On Python 2, the property below doesn't raise an AttributeError
        # since the object is an ImmutableDict and therefore read only.
        # On Python 3, it raises an exception.
        try:
            args[u'foo'] = u'baz'
        except AttributeError:
            pass
        else:
            assert False, "should have thrown"



# Generated at 2022-06-11 17:53:23.778015
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    CLIArgs({'hello': 'world'})

# Generated at 2022-06-11 17:53:29.475839
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory import Inventory
    from ansible.cli import CLI
    from ansible.errors import AnsibleError

    ansible_options = CLI.base_parser(constants.base_parser_args, usage='usage: %prog [options]')
    parser = CLI.playbook_parser(ansible_options)
    try:
        options, args = parser.parse_args(['test'])
    except SystemExit:
        raise AnsibleError("Invalid options passed to Ansible CLI. Ansible CLI defaults to --version, with no additional arguments, when run without any arguments.")

    loader = DataLoader()
    variable_manager = VariableManager()
   

# Generated at 2022-06-11 17:54:39.089527
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert C() == B() == A()

# Generated at 2022-06-11 17:54:50.557130
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--new-toplevel', action='store_true', help='New toplevel arg')

    # Prevent name collisions
    args1 = parser.parse_args([])
    args2 = parser.parse_args(['--new-toplevel'])

    # Test cache
    gargs1 = GlobalCLIArgs(vars(args1))
    gargs2 = GlobalCLIArgs(vars(args2))
    assert gargs1 is gargs2
    # Test mapping
    assert gargs1['new_toplevel'] == False
    assert gargs2['new_toplevel'] == True

    # Test when not in cache
    gargs1 = GlobalCLIArgs.from_options(args1)
    gargs2 = Global

# Generated at 2022-06-11 17:54:51.357057
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert isinstance(CLIArgs(dict(a="b")), ImmutableDict)


# Generated at 2022-06-11 17:55:01.679256
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from collections import MutableMapping, MutableSequence, MutableSet

    class MutableDict(_ABCSingleton, MutableMapping):
        pass

    class MutableTuple(_ABCSingleton, MutableSequence):
        pass

    class MutableSet(_ABCSingleton, MutableSet):
        pass

    assert issubclass(MutableDict, MutableMapping)
    assert issubclass(MutableDict, Singleton)
    assert issubclass(MutableDict, _ABCSingleton)
    assert not issubclass(MutableDict, ABCMeta)

    assert issubclass(MutableTuple, MutableSequence)
    assert issubclass(MutableTuple, Singleton)
    assert issubclass(MutableTuple, _ABCSingleton)