

# Generated at 2022-06-11 17:45:05.171476
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    a1 = A()
    a2 = A()
    assert a1 is a2

# Generated at 2022-06-11 17:45:07.110841
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs.from_options({'test': 1})
    assert args['test'] == 1, "Class GlobalCLIArgs does not work"

# Generated at 2022-06-11 17:45:15.283637
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestParent(_ABCSingleton):
        pass

    class TestChild(TestParent):
        pass

    test_parent = TestParent()
    test_child = TestChild()

    # Verify that the class method __call__ was properly applied to the class and all its subclasses.
    assert isinstance(test_parent, Singleton)
    assert isinstance(test_child, Singleton)

    # Verify that the method __new__ was properly wrapped.
    assert isinstance(test_parent, ABCMeta)
    assert isinstance(test_child, ABCMeta)

# Generated at 2022-06-11 17:45:21.131986
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    result = CLIArgs({'a': '1', 'b': '2', 'c': '3'})
    assert result['a'] == '1'
    assert result['b'] == '2'
    assert result['c'] == '3'


if __name__ == '__main__':
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 4
    test_CLIArgs()

# Generated at 2022-06-11 17:45:31.041776
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Make sure the right things work when we have a class based on _ABCSingleton.

    A class with an ABCMeta based class in it's mro MUST have isinstance() return True for instances
    of that class.  This is required to make ABCMeta based classes work.
    """
    class MyClass(_ABCSingleton):
        pass

    class MyNonClass(MyClass):
        pass

    mc_instance = MyClass()
    mnc_instance = MyNonClass()

    assert isinstance(mc_instance, MyClass)
    assert not isinstance(mnc_instance, MyClass)
    assert isinstance(mnc_instance, MyNonClass)

# Generated at 2022-06-11 17:45:32.290012
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs.from_options(MockCLIOptions)
    assert isinstance(args, GlobalCLIArgs)


# Generated at 2022-06-11 17:45:36.383221
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    assert A() is A()
    assert A() is not B()
    assert B() is B()
    assert B() is not A()



# Generated at 2022-06-11 17:45:43.012443
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton):
        pass

    foo1 = Foo()
    foo2 = Foo()
    assert foo1 is foo2
    assert isinstance(foo1, Foo)

    import abc

    class Bar(Foo, abc.ABC):
        @abc.abstractmethod
        def abstract_method(self):
            pass

        def normal_method(self):
            pass

    # This fails if we do not have __instancecheck__ implemented in _ABCSingleton
    assert issubclass(Bar, abc.ABC)

# Generated at 2022-06-11 17:45:45.290237
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(metaclass=_ABCSingleton):
        pass
    assert TestClass() == TestClass()
    assert TestClass() is TestClass()

# Generated at 2022-06-11 17:45:48.695755
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    GlobalCLIArgs.from_options(parser.parse_args(args=['--foo']))

# Generated at 2022-06-11 17:46:03.225181
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Given
    mapping = {
        "foo": {
            "bar": {
                "egg": ["spam", "bacon"],
                "baz": "ham"
            },
            "egg": {
                "george": "porkie",
                "fred": "beefie"
            }
        },
        "spam": ["egg", "bacon", ["sausage", "tomato"]]
    }

# Generated at 2022-06-11 17:46:08.283333
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # This should create a new class
    # pylint: disable=too-few-public-methods
    class ABCSingletonTest(with_metaclass(_ABCSingleton)):
        pass
    ABCSingletonTest()
    # The second instantiation of ABCSingletonTest should return the same instance as the first.
    ABCSingletonTest()

# Generated at 2022-06-11 17:46:13.609574
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    sample_args = dict(json=True, vault_identity=True)
    global_args = GlobalCLIArgs(sample_args)
    assert isinstance(global_args, ImmutableDict)
    assert isinstance(global_args, Singleton)



# Generated at 2022-06-11 17:46:19.976848
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_input = {'test': 'test', 'test2': ['test'], 'test3': {'test': 'test'}}
    test_output = CLIArgs(test_input)

    assert isinstance(test_output['test'], text_type)
    assert isinstance(test_output['test2'], tuple)
    assert isinstance(test_output['test3'], ImmutableDict)

# Generated at 2022-06-11 17:46:22.762937
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # noinspection PyUnusedLocal
    class Test(_ABCSingleton):
        pass

    t = Test()
    assert t is Test(), 'Singleton classes with _ABCSingleton should fail to instantiate more than once'

# Generated at 2022-06-11 17:46:31.463498
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import pytest
    from ansible.module_utils.common._collections_compat import (Container, Mapping, Sequence, Set)

    class MyMutableObject(object):
        """
        An object to mutate
        """
        def __init__(self, my_list=None, my_string=None, my_int=None):
            self._my_list = my_list
            self._my_string = my_string
            self._my_int = my_int

        def __repr__(self):
            return repr(self._my_list)

        def __str__(self):
            return str(self._my_string)

        def __int__(self):
            return self._my_int

        def __eq__(self, other):
            return self._my_list == other._

# Generated at 2022-06-11 17:46:32.378294
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({'a': 10})

# Generated at 2022-06-11 17:46:42.901808
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import pytest
    dict1 = {'var1': 3, 'var2': 'string'}
    cli_args = CLIArgs(dict1)
    assert cli_args == dict1

    # Verify that CLIArgs returns an immutable dictionary
    dict1['var1'] = 4
    assert cli_args != dict1

    # Verify that CLIArgs will be immutable if nested dictionary is made immutable
    dict2 = {'var3': {'var4': 4, 'var5': 10}}
    dict1.update(dict2)
    cli_args = CLIArgs(dict1)
    dict1['var3']['var5'] = 10
    assert cli_args != dict1

    # Verify that CLIArgs will be immutable if nested list is made immutable

# Generated at 2022-06-11 17:46:53.743840
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-11 17:47:03.899007
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.parsing.convert_bool import BOOLEANS, boolean
    from ansible.module_utils.parsing.convert_datetime import to_datetime
    from ansible.module_utils.parsing.convert_json import from_json
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.utils.hashing import md5s, checksum_s
    import datetime

# Generated at 2022-06-11 17:47:15.540778
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test1(_ABCSingleton):
        pass

    class Test2(_ABCSingleton):
        pass
    try:
        class Test3(_ABCSingleton):
            __slots__ = ()

            def __init__(self, test):
                self.test = test
    except TypeError:
        pass
    else:
        raise AssertionError("Class Test3 was created")
    try:
        class Test4(_ABCSingleton):
            __slots__ = ('test', )

            def __init__(self, test):
                self.test = test

        Test4(test=1)
    except TypeError:
        pass
    else:
        raise AssertionError("Class Test4 was instantiated")

# Generated at 2022-06-11 17:47:26.795628
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.display import Display

    # Build a new collection loader
    loader = AnsibleCollectionLoader()

    # Mock a set of command line arguments

# Generated at 2022-06-11 17:47:30.180420
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import six

    try:
        # Attempt to initialize the singleton twice
        GlobalCLIArgs()
        GlobalCLIArgs()
    except TypeError:
        pass
    else:
        raise AssertionError(six.b("GlobalCLIArgs() should only allow a single initialization"))

# Generated at 2022-06-11 17:47:33.737864
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    cli_args = GlobalCLIArgs({'a': 1, 'b': {'b1': 1}})
    assert cli_args['a'] == 1
    assert cli_args['b'] == {'b1': 1}

# Generated at 2022-06-11 17:47:36.696980
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    final_result = {'debug': True, 'verbosity': 3,
                    'connection': 'test'}
    cli_args = GlobalCLIArgs(final_result)
    assert cli_args['debug']
    assert cli_args['verbosity'] == 3
    assert cli_args['connection'] == 'test'
    assert isinstance(cli_args, ImmutableDict)

# Generated at 2022-06-11 17:47:48.060242
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    original_args = {'one': 'a', 'two': 'b', 'three': 'c'}
    # Spot check the constructor of CLIArgs
    assert CLIArgs(original_args).one == 'a' and CLIArgs(original_args).two == 'b' and \
        CLIArgs(original_args).three == 'c'
    # Spot check the constructor of GlobalCLIArgs
    assert GlobalCLIArgs(original_args).one == 'a' and GlobalCLIArgs(original_args).two == 'b' and \
        GlobalCLIArgs(original_args).three == 'c'
    # Spot check that GlobalCLIArgs is a singleton
    singleton_instance_1 = GlobalCLIArgs(original_args)
    singleton_instance_2 = GlobalCLIArgs(original_args)
    assert singleton_instance_

# Generated at 2022-06-11 17:47:57.977544
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import tempfile
    import os
    import shutil
    import json
    import collections

    test_dir = tempfile.mkdtemp(dir=os.getcwd())

    test_data = {
        "nested_dict": {
            "a": "A",
            "b": "B"
        },
        "nested_list": [
            "A",
            "B"
        ],
        "nested_set": {
            "A",
            "B"
        },
        "nested_tuple": (
            "A",
            "B"
        ),
        "simple_string": "ABC",
        "simple_int": 123
    }

    json.dump(test_data, open(os.path.join(test_dir, "test"), 'w'))


# Generated at 2022-06-11 17:48:08.583106
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """ Test the constructor of class CLIArgs """
    # pylint: disable=attribute-defined-outside-init
    # Allows for simpler test methods for testing class instantiation.
    # These are attributes that are normally defined in the CLI.

    class TestCLIObject(object):
        """Object to hold attributes used in testing class instantiation"""
        def __init__(self):
            self.ask_vault_pass = True
            self.connection = 'ssh'
            self.become = True
            self.become_method = 'sudo'
            self.become_user = 'root'
            self.check = False
            self.extra_vars = {'randomarg': 'randomvalue'}
            self.flush_cache = False
            self.forks = 5
            self.listhosts = False
            self.listtasks

# Generated at 2022-06-11 17:48:14.009983
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton
    class Bar(object):
        __metaclass__ = _ABCSingleton
    # All Bar instances are the same
    assert Bar() is not Bar()
    assert Bar() is Bar()
    # All Foo instances are the same
    assert Foo() is not Foo()
    assert Foo() is Foo()
    # There is only one instance that is both a Bar and a Foo
    assert Bar() is Foo()
    # It was successfully constructed as a Foo
    assert isinstance(Bar(), Foo)
    # It was successfully constructed as a Bar
    assert isinstance(Foo(), Bar)
    # It was successfully constructed as a Bar and a Foo
    assert isinstance(Bar(), Foo) and isinstance(Foo(), Bar)

# Generated at 2022-06-11 17:48:20.205506
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test CLIArgs constructor
    """
    dict1 = {'a': 1, 'b': '2', 'c': [3], 'd': {'e': 'f', 'g': {'h': 'i'}}}
    dict2 = {'a': 1, 'b': '2', 'c': (3,), 'd': ImmutableDict({'e': 'f', 'g': ImmutableDict({'h': 'i'})})}
    assert CLIArgs(dict1) == dict2



# Generated at 2022-06-11 17:48:24.070855
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton(_ABCSingleton):
        pass

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-11 17:48:29.513929
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    foo = {'bar': {'baz': [1, 2, 3]}}
    args = GlobalCLIArgs(foo)
    assert args['bar']['baz'][0] == 1
    assert isinstance(args, ImmutableDict)
    assert isinstance(args['bar'], ImmutableDict)
    assert isinstance(args['bar']['baz'], tuple)

# Generated at 2022-06-11 17:48:37.376737
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.vars import combine_vars
    from ansible.parsing.plugin_docs import read_docstring

    # Test if GlobalCLIArgs and CLIArgs are not same
    assert(GlobalCLIArgs is not CLIArgs)

    # Test if CLIArgs constructor is called.
    args = {'asdf': 'jkl',}
    global_cli_args = GlobalCLIArgs(args)
    assert(global_cli_args == args)

    # Test if ImmutableDict constructor is called
    args = {'asdf': 'jkl',}
    cli_args = CLIArgs(args)
    assert(cli_args == args)

# Generated at 2022-06-11 17:48:46.917089
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Test that the _ABCSingleton metaclass handles inheritance correctly

    The _ABCSingleton metaclass is intended to handle multiple inheritance from classes that
    implement both Singleton and ABCMeta.  In the situation where inheritance conflicts, it is
    important to know which class should be choosing the parent class.  This unit test verifies
    that the metaclass behaves as intended.
    """
    class Parent1(object):
        """
        The first class of the parent pair inherits from object.

        Inheritance from object is done to allow the tests do verify the behaviour of
        _ABCSingleton.  Normally, Singleton is a parent class which is already a new style class, so
        it is not necessary to inherit from object.
        """


# Generated at 2022-06-11 17:48:56.544257
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({}) == {}
    assert CLIArgs({'foo': 'bar'}) == {'foo': 'bar'}
    assert CLIArgs({'foo': {'bar': 'baz'}}) == {'foo': {'bar': 'baz'}}
    assert CLIArgs({'foo': {'bar': {'baz': 'qux'}}}) == {'foo': {'bar': {'baz': 'qux'}}}
    assert CLIArgs({'foo': ['bar', 'baz']}) == {'foo': ('bar', 'baz')}
    assert CLIArgs({'foo': ['bar', ['baz']]}) == {'foo': ('bar', ('baz',))}

# Generated at 2022-06-11 17:48:58.261776
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class SingletonClass(_ABCSingleton):
        pass

    SingletonClass()

# Generated at 2022-06-11 17:49:01.788896
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
# pylint: disable=protected-access
    options = GlobalCLIArgs._GlobalCLIArgs__instance._options
    assert isinstance(options.connection, text_type)
    assert isinstance(options.check, bool)

# Generated at 2022-06-11 17:49:06.009627
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = dict(foo='bar', baz=dict(a=1, b=2), list=[1, 2, 3], set=[2, 3, 1])
    result_dict = CLIArgs(test_dict)

    assert(result_dict == test_dict)



# Generated at 2022-06-11 17:49:08.853461
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton):
        def __init__(self):
            self.x = 1

    foo1 = Foo()
    foo2 = Foo()
    assert foo1 is foo2


# Generated at 2022-06-11 17:49:15.924401
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    '''
    class CLIArgs()

    Unit test for constructor of class 'CLIArgs'
    '''
    # Test with valid input
    input_dict = {
        'become': True,
        'become_user': 'root',
        'become_method': 'sudo',
        'connection': 'ssh',
        'host_key_checking': True,
        'check': False,
        'diff': False,
        'forks': 5,
        'remote_user': 'user',
        'timeout': 60
    }
    cli_args = CLIArgs(input_dict)
    assert isinstance(cli_args, CLIArgs)

    # Test with invalid input

# Generated at 2022-06-11 17:49:27.274692
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import json
    import re

    class Dummy(object):
        def __repr__(self):
            return "Dummy"

    from ansible.module_utils.common._collections_compat import MutableMapping

    # pylint: disable=ungrouped-imports
    from ansible.module_utils.common._collections_compat import MutableSequence
    from ansible.module_utils.common._collections_compat import MutableSet
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.module_utils.common._collections_compat import Set

    # test_CLIArgs()
    #  - test with a simple dictionary
    #  - test with a dictionary that has nested dictionaries
    #  - test with a list
    #  - test with

# Generated at 2022-06-11 17:49:36.561314
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    # Instantiate GlobalCLIArgs once for use in all tests
    my_GlobalCLIArgs = GlobalCLIArgs({'test': {'test_dictionary': {'test_key': 'test_value'}}})

    # Test that we can't add to a dictionary in cli args
    try:
        my_GlobalCLIArgs['test']['new_key'] = 'new_value'
    except TypeError:
        pass
    except Exception as e:
        raise Exception("Expected TypeError exception in test GlobalCLIArgs but got exception %s" % repr(e))
    else:
        raise Exception("Expected TypeError exception in test GlobalCLIArgs but got no exception")

    # Test that we can't delete from a dictionary in cli args

# Generated at 2022-06-11 17:49:39.900373
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    There is no real way to make a test for a constructor, but we want to ensure that the code to
    unit test this constructor runs properly, so this is a do nothing test
    """
    assert True

# Generated at 2022-06-11 17:49:41.433255
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(with_metaclass(_ABCSingleton, object)):
        pass

    A()

# Generated at 2022-06-11 17:49:50.040291
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from enum import Enum
    from argparse import ArgumentParser

    class Verbosity(Enum):
        """
        Single-letter enum for CLI arg
        """
        QUIET = 'q'
        VERBOSE = 'v'

    # Create a simple set of arguments for testing
    parser = ArgumentParser()
    parser.add_argument("-d", "--different", dest="diff", help="Toggle differences", action='store_true')
    parser.add_argument("--verbosity", help="Set the verbosity", choices=list(Verbosity))
    parser.add_argument("--tuple1", help="A tuple")
    parser.add_argument("--tuple2", help="A list")
    parser.add_argument("--list1", help="A list")

# Generated at 2022-06-11 17:50:00.765656
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    ImmutableDict = collections.namedtuple('ImmutableDict', ['tuple_set'])

    class One:
        def __init__(self, a=1, b=2, c=3):
            self.a = a
            self.b = b
            self.c = c

        def __repr__(self):
            return str(self.a) + str(self.b) + str(self.c)

    class Two:
        def __init__(self, d=4, e=5, f=6):
            self.d = d
            self.e = e
            self.f = f

        def __repr__(self):
            return str(self.d) + str(self.e) + str(self.f)


# Generated at 2022-06-11 17:50:05.175959
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    class B(A):
        pass
    assert issubclass(A, ABCMeta)
    assert issubclass(A, Singleton)


# Generated at 2022-06-11 17:50:15.299404
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs({'data': {'name': 'foo', 'ansible_connection': 'local'}, 'bar': 'foo'})
    assert cli_args == {'data': {'name': 'foo', 'ansible_connection': 'local'}, 'bar': 'foo'}
    assert isinstance(cli_args.data, ImmutableDict)
    assert isinstance(cli_args['data'], ImmutableDict)
    assert cli_args.data == {'name': 'foo', 'ansible_connection': 'local'}
    assert cli_args['data'] == {'name': 'foo', 'ansible_connection': 'local'}


# Generated at 2022-06-11 17:50:17.984145
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    x = TestClass()
    assert x is TestClass()

# Generated at 2022-06-11 17:50:21.936078
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'param': [1, 2, 3]}
    cli_args = CLIArgs(mapping)
    assert cli_args['param'] == (1, 2, 3)
    assert isinstance(cli_args['param'], tuple)
    assert isinstance(cli_args, ImmutableDict)


# Generated at 2022-06-11 17:50:31.522647
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Exceptions should happen when instantiating a second GlobalCLIArgs object
    try:
        another_args = GlobalCLIArgs({'arg1': 'value1', 'arg2': 'value2'})
    except Exception as e:
        # The exception will be thrown when _GlobalCLIArgs__instance is overridden
        assert(e.args[0] == "A Singleton instance already exists")


# Generated at 2022-06-11 17:50:41.182531
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    gca = GlobalCLIArgs({'a': {'b': [{'c': 'd'}, 1, 2, 3]}})
    assert gca.a.b[0].c == 'd'
    assert gca.a.b[1:] == (1, 2, 3)
    assert isinstance(gca, ImmutableDict)
    assert isinstance(gca, Mapping)
    assert isinstance(gca.a, ImmutableDict)
    assert isinstance(gca.a.b, tuple)
    assert isinstance(gca.a.b[0], ImmutableDict)
    assert isinstance(gca.a.b[1:], tuple)


# Instantiate the singleton for global context so the rest of the code can use it
GlobalCLIArgs.instance()

# Generated at 2022-06-11 17:50:51.583988
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Use a dict as an example of the kind of mapping object that will be converted to an ImmutableDict
    x = GlobalCLIArgs(dict(a=dict(b=set([dict(c=set()), dict(c=set())]))))
    assert isinstance(x, dict) and isinstance(x, ImmutableDict)
    assert isinstance(x['a'], ImmutableDict)
    assert isinstance(x['a']['b'], frozenset)
    assert isinstance(x['a']['b'][0], ImmutableDict)
    assert isinstance(x['a']['b'][0]['c'], frozenset)
    assert isinstance(x['a']['b'][1]['c'], frozenset)

# Generated at 2022-06-11 17:51:03.135947
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs(dict(
        ANSIBLE_MODULE_ARGS=dict(
            foo=dict(
                bar='baz',
                nested=dict(
                    one='one value',
                    two='another value',
                ),
                a_list=[
                    'one',
                    'two'
                ]
            )
        ),
        ANSIBLE_MODULE_CONSTANTS=dict(
            foo='bar',
            number=42
        )
    ))
    assert args['ANSIBLE_MODULE_ARGS']['foo']['bar'] == 'baz'
    assert args['ANSIBLE_MODULE_ARGS']['foo']['a_list'][0] == 'one'
    assert args['ANSIBLE_MODULE_CONSTANTS']['number'] == 42

# Generated at 2022-06-11 17:51:04.727733
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({'foo': [1, 2, 3]})



# Generated at 2022-06-11 17:51:14.915312
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingletonChild1(metaclass=_ABCSingleton):
        pass

    class SingletonChild2(metaclass=_ABCSingleton):
        pass

    # Singleton class so check they are the same instance
    assert SingletonChild1() is SingletonChild1()

    # Singleton and ABCMeta means they don't override each other
    assert not issubclass(SingletonChild1, SingletonChild2)

    # Test metaclass inheritance
    class SingletonGrandchild1(SingletonChild1):
        pass

    class SingletonGrandchild2(SingletonChild2):
        pass

    # Test that grandchild classes are still singletons
    assert SingletonGrandchild1() is SingletonGrandchild1()

# Generated at 2022-06-11 17:51:18.864545
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyABCSingleton(object):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            self.foo = 1

    a = MyABCSingleton()
    b = MyABCSingleton()
    assert a.foo == 1
    assert b.foo == 1

# Generated at 2022-06-11 17:51:22.084714
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class S1(object):
        __metaclass__ = _ABCSingleton
        def __init__(self):
            self.a = 'a'

    class S2(object):
        __metaclass__ = _ABCSingleton
        def __init__(self):
            self.b = 'b'

    assert S1() == S1()
    assert S2() == S2()
    assert S1() != S2()

# Generated at 2022-06-11 17:51:26.385339
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli import CLI
    from ansible.config.manager import ConfigManager
    mycli = CLI(args=['--version'])
    mycli.parse()
    options = ConfigManager.from_options(mycli.options)
    args = GlobalCLIArgs.from_options(options)
    assert vars(options) == args

# Generated at 2022-06-11 17:51:31.528292
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Unit test for GlobalCLIArgs
    class TestGlobalCLIArgs(object):
        def __init__(self):
            return

    assert TestGlobalCLIArgs.__class__.__name__ == '_ABCSingleton', 'Expected _ABCSingleton metaclass, got %s' % TestGlobalCLIArgs.__class__.__name__

# Generated at 2022-06-11 17:51:41.890698
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    # There should be a single instance of Foo
    assert Foo.instance() is Foo.instance()


# Generated at 2022-06-11 17:51:46.357921
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    result = CLIArgs.from_options([1, 2, 3])
    assert isinstance(result, CLIArgs)
    assert isinstance(_make_immutable({1: 1, 2: 2}), ImmutableDict)
    assert isinstance(_make_immutable({1: 1, 2: {3: 3}}), ImmutableDict)

# Generated at 2022-06-11 17:51:52.785598
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs can be constructed without errors
    """
    import collections
    opt = collections.namedtuple('options', ['foo'])
    opt.foo = 'bar'
    args = CLIArgs.from_options(opt)
    assert args['foo'] == 'bar'



# Generated at 2022-06-11 17:51:54.949312
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({'test1':'value1', 'test2':'value2'})

# Generated at 2022-06-11 17:51:58.238421
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Can't test individual details of an immutable object, just did
    # what we could and hope it works
    GlobalCLIArgs.set(CLIArgs({'hello': 'world'}))
    assert isinstance(GlobalCLIArgs.get(), CLIArgs)

# Generated at 2022-06-11 17:52:00.825209
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs.from_options(CLIArgs(dict()))
    assert isinstance(args, CLIArgs)
    assert isinstance(args, ImmutableDict)
    assert args == ImmutableDict()

# Generated at 2022-06-11 17:52:02.566878
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import ansible.module_utils.common.removed
    args = CLIArgs({'check_mode': True, 'no_log': False, u'_ansible_debug': False})

# Generated at 2022-06-11 17:52:06.158689
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class First(metaclass=_ABCSingleton):
        def __init__(self):
            pass
    first_1 = First()
    first_2 = First()
    assert first_1 is first_2


# Generated at 2022-06-11 17:52:15.496408
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({"a": 1}) == ImmutableDict({"a": 1})
    assert CLIArgs({"a": [1]}) == ImmutableDict({"a": (1,)})
    assert CLIArgs({"a": {1: 1}}) == ImmutableDict({"a": ImmutableDict({1: 1})})
    assert CLIArgs({"a": {1: [1]}}) == ImmutableDict({"a": ImmutableDict({1: (1,)})})
    assert CLIArgs({"a": {1: {1: 1}}}) == ImmutableDict({"a": ImmutableDict({1: ImmutableDict({1: 1})})})



# Generated at 2022-06-11 17:52:26.529665
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import os
    import tempfile
    import pytest

    def run_playbook_to_get_args():
        # run a playbook to generate the args
        # create a directory
        base_dir = tempfile.mkdtemp()
        inventory_file = os.path.join(base_dir, 'inventory')
        with open(inventory_file, 'w') as f:
            f.write('local ansible_connection=local')
        playbook_file = os.path.join(base_dir, 'playbook.yml')
        with open(playbook_file, 'w') as f:
            f.write('''
- hosts: local
  tasks:
    - debug:
        msg: hello
''')
        old_argv = sys.argv

# Generated at 2022-06-11 17:52:52.698791
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    # test for a mapping like ansible --version
    test_dict = {'version': True}
    test_immutable_dict = CLIArgs(test_dict)

    assert isinstance(test_immutable_dict, ImmutableDict)
    assert test_immutable_dict == test_dict
    assert isinstance(test_immutable_dict['version'], bool)
    assert test_immutable_dict['version'] == test_dict['version']

    # test for a mapping like ansible module_name
    test_dict = {'CHECKMODE': True, 'test_with_types': [1, 1.1, 'test', u'test'],
                 'test_with_dict': {'test': 'test'}}
    test_immutable_dict = CLIArgs(test_dict)


# Generated at 2022-06-11 17:52:56.689926
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'test': ('one', 'two', 'three')}
    args = CLIArgs(mapping)
    assert isinstance(args, dict)
    assert isinstance(args, Container)
    assert isinstance(args['test'], tuple)
    assert isinstance(args['test'], Container)
    assert args['test'][0] == 'one'

# Generated at 2022-06-11 17:53:04.049202
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    input = {
        'some_key': 'some_value',
        'some_list': ['one', 'two'],
        'some_dict': {'some_key': 'some_value'},
    }
    result = CLIArgs(input)
    assert isinstance(result, ImmutableDict)
    assert isinstance(result['some_dict'], ImmutableDict)
    assert isinstance(result['some_list'], tuple)
    assert isinstance(result, CLIArgs)



# Generated at 2022-06-11 17:53:06.933716
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_1 = GlobalCLIArgs({})
    assert isinstance(global_1, CLIArgs)
    global_2 = GlobalCLIArgs({})
    assert global_1 is global_2

# Generated at 2022-06-11 17:53:18.089700
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    my_args = CLIArgs({'foo': 'bar'})
    assert my_args['foo'] == 'bar'

    my_args = CLIArgs({'foos': ['bar', 'baz'], 'bazs': {'bang': {'thing': 'xyz'}}})
    assert my_args['foos'] == ('bar', 'baz')
    assert isinstance(my_args['foos'], tuple)
    assert my_args['bazs'] == ImmutableDict({'bang': {'thing': 'xyz'}})
    assert isinstance(my_args['bazs'], ImmutableDict)

    my_args = CLIArgs({'foos': ('bar', 'baz'), 'bazs': ImmutableDict({'bang': {'thing': 'xyz'}})})

# Generated at 2022-06-11 17:53:21.417594
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert _ABCSingleton is not ABCMeta
    assert issubclass(_ABCSingleton, ABCMeta)
    assert issubclass(_ABCSingleton, Singleton)
    assert issubclass(_ABCSingleton, type)

# Generated at 2022-06-11 17:53:24.689452
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    assert Foo() is Foo()



# Generated at 2022-06-11 17:53:27.440666
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert issubclass(TestClass, _ABCSingleton)



# Generated at 2022-06-11 17:53:37.777850
# Unit test for constructor of class CLIArgs
def test_CLIArgs():  # pylint: disable=invalid-name
    """
    Tests CLIArgs(Mapping) instance constructor.
    """
    from ansible.utils.vars import combine_vars
    test_dict = dict()
    test_dict['ansible_python_interpreter'] = '/usr/bin/python'
    test_dict['inventory'] = '/etc/ansible/hosts'
    test_dict['check'] = False
    test_dict['ask_pass'] = False
    test_dict['ask_su_pass'] = False
    test_dict['ask_vault_pass'] = False
    test_dict['become'] = False
    test_dict['become_method'] = None
    test_dict['become_user'] = None
    test_dict['become_ask_pass'] = False
    test

# Generated at 2022-06-11 17:53:41.019170
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Test CLIArgs' constructor"""
    opts = CLIArgs.from_options(object())
    assert isinstance(opts, ImmutableDict)



# Generated at 2022-06-11 17:54:24.238131
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.utils.display import Display
    from ansible.plugins.callback.default import CallbackModule
    from ansible.utils.vars import combine_vars

    class Options(object):

        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    options = Options(
        connection='local',
        module_path=[],
        forks=10,
        become=False,
        become_method=None,
        become_user=None,
        check=False,
        diff=False,
        inventory=None,
        listhosts=None,
        listtasks=None,
        listtags=None,
        module_path=None,
        syntax=None,
        verbosity=0,
    )
    display = Display()
    vars

# Generated at 2022-06-11 17:54:27.595366
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    class B(A):
        pass
    class C(A):
        pass
    return A(), B(), C()

# Generated at 2022-06-11 17:54:31.574038
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(_ABCSingleton):
        pass

    # pylint: disable=no-member
    assert issubclass(A, _ABCSingleton)
    a = A()
    b = A()
    assert a is b

# Generated at 2022-06-11 17:54:34.446159
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict1 = {'a': 'b', 'c': 'd'}
    cli_args = CLIArgs(dict1)
    assert isinstance(cli_args['a'], str)
    assert cli_args['a'] == dict1['a']

# Generated at 2022-06-11 17:54:42.409406
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import os
    import sys

    module_name = os.path.basename(sys.argv[0])
    if module_name.endswith(('.py', '-script.py')):
        module_name = module_name[:-3]
    if module_name == '__main__':
        module_name = os.path.basename(sys.argv[1])

    if module_name in ('ansible', 'ansible-config', 'ansible-connection', 'ansible-console',
                       'ansible-doc', 'ansible-galaxy', 'ansible-inventory', 'ansible-playbook',
                       'ansible-pull', 'ansible-vault'):
        import ansible.utils.display as display
        display.display("Unit tests skipped because they would halt the program",
                        color='yellow')

# Generated at 2022-06-11 17:54:45.374577
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options:
        x = [(1, 2), (3, 4)]

    options = Options()
    assert isinstance(GlobalCLIArgs.from_options(options), GlobalCLIArgs)

# Generated at 2022-06-11 17:54:46.764839
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton(): pass
test__ABCSingleton.__metaclass__ = _ABCSingleton



# Generated at 2022-06-11 17:54:50.072769
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A is B

# Generated at 2022-06-11 17:54:57.083327
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = {'foo': {'bar': 'baz', 'qux': 'quux'}}
    test_args = CLIArgs(cli_args)
    assert isinstance(test_args, ImmutableDict)

    # test if Mapping is converted to ImmutableDict
    assert isinstance(test_args['foo'], ImmutableDict)
    # test if Sequence is converted to tuple
    assert isinstance(cli_args['foo'].keys(), Sequence)
    assert isinstance(test_args['foo'].keys(), tuple)

    # test if Set is converted to frozenset
    cli_args = {'foo': set(['bar'])}
    test_args = CLIArgs(cli_args)
    assert isinstance(test_args['foo'], frozenset)
