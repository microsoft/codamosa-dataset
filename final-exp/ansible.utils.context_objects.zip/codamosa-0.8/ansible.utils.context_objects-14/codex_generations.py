

# Generated at 2022-06-11 17:45:10.295249
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from optparse import Values
    from ansible.module_utils.common._collections_compat import UserDict, Mapping

# Generated at 2022-06-11 17:45:15.698399
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton):
        pass

    class Bar(_ABCSingleton):
        def __init__(self):
            self.foo = Foo()
            self.baz = 'test'

    b1 = Bar()
    b2 = Bar()
    assert b1 == b2
    assert b1.foo == b2.foo

# Generated at 2022-06-11 17:45:21.415406
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options:
        def __init__(self):
            self.one = None
            self.two = None
    options = Options()
    options.one = 'one'
    options.two = 'two'
    args = GlobalCLIArgs.from_options(options)
    assert args.get('one') == 'one'
    assert args.get('two') == 'two'
    assert args.__class__ == GlobalCLIArgs


# Generated at 2022-06-11 17:45:23.216544
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        pass

    Test()
    Test()

# Generated at 2022-06-11 17:45:35.539233
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Tests for the CLIArgs class
    :return:
    """
    test_mapping = {'one': 1, 'two': 2}
    test_mapping_immutable = ImmutableDict(test_mapping)
    test_mapping_int = 1
    test_mapping_str = "this is a string"

    # test 'mapping' is immutable
    assert isinstance(CLIArgs(test_mapping).one, int)
    assert isinstance(CLIArgs(test_mapping).two, int)
    assert isinstance(CLIArgs(test_mapping).one, type(test_mapping['one']))
    assert isinstance(CLIArgs(test_mapping).two, type(test_mapping['two']))

    # test 'mapping' is not updated
    assert CLIArgs

# Generated at 2022-06-11 17:45:39.090400
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import unittest
    import sys
    import os

    class GlobalCLIArgsTestCase(unittest.TestCase):
        def setUp(self):
            self.orig_argv = sys.argv
            self.argv = ['ansible-inventory', '--list']
            sys.argv = self.argv

        def tearDown(self):
            sys.argv = self.orig_argv

        def test_constructor(self):
            options = GlobalCLIArgs.from_options(GlobalCLIArgs.parse())
            self.assertTrue(isinstance(options, CLIArgs))

    suite = unittest.TestLoader().loadTestsFromModule(sys.modules[__name__])

    unittest.TextTestRunner(verbosity=2).run(suite)


# Generated at 2022-06-11 17:45:48.696237
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'b': True, 'a': 'hello'})
    assert args.a == 'hello'
    assert args.b is True
    assert not hasattr(args, 'c')

    args = CLIArgs({'a': {'b': True, 'a': 'hello'}})
    assert args.a.a == 'hello'
    assert args.a.b is True
    assert not hasattr(args, 'c')

    args = CLIArgs({'a': [True, 'hello']})
    assert args.a[0] is True
    assert args.a[1] == 'hello'
    assert len(args.a) == 2
    assert not hasattr(args, 'c')

    args = CLIArgs({'a': (True, 'hello')})
    assert args.a[0] is True


# Generated at 2022-06-11 17:45:56.872958
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    ABCSingletonA = _ABCSingleton("ABCSingletonA", (A,), {})
    ABCSingletonB = _ABCSingleton("ABCSingletonB", (B,), {})
    ABCSingletonC = _ABCSingleton("ABCSingletonC", (C,), {})

    assert issubclass(ABCSingletonB, ABCSingletonA)
    assert issubclass(ABCSingletonC, ABCSingletonA)

# Generated at 2022-06-11 17:45:59.997011
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
        pass

    class B(object):
        __metaclass__ = _ABCSingleton
        pass

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-11 17:46:08.378383
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import ansible.constants as C
    import ansible.errors as errors
    from ansible.cli import CLI
    from ansible.utils.display import Display

    display = Display()
    cli = CLI(args=[], display=display)
    options = cli.parse()
    # Make a playbook context
    playbook = GlobalCLIArgs.from_options(options)
    try:
        playbook['step'] = 'step'
        assert False
    except errors.AnsibleError:
        pass


# Generated at 2022-06-11 17:46:16.156901
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    gca = GlobalCLIArgs({})
    assert isinstance(gca['module_utils'], ImmutableDict)
    assert not isinstance(gca['module_utils'], Mapping)
    assert not isinstance(gca['module_utils'], Set)
    assert not isinstance(gca['module_utils'], Sequence)

# Generated at 2022-06-11 17:46:24.376137
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs.from_options(ImmutableDict([('foo', 'bar'), ('baz', 'bang'), ('real', ['arguments'])]))
    assert isinstance(args, Container)
    assert args == ImmutableDict([('foo', 'bar'), ('baz', 'bang'), ('real', ('arguments',))])
    args2 = GlobalCLIArgs.from_options(ImmutableDict([('foo', 'bar'), ('baz', 'bang'), ('real', ['arguments'])]))
    assert(args == args2)
    try:
        args['foo'] = 'bar'
        raise AssertionError("Was able to change value returned by GlobalCLIArgs")
    except TypeError:
        pass

# Generated at 2022-06-11 17:46:32.335481
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections

    point = collections.namedtuple('Point', 'x y')
    cmdline_args = CLIArgs({'foo': 'bar', 'bool': True})
    assert cmdline_args.foo == 'bar'
    assert cmdline_args.bool is True
    assert 'bool' in cmdline_args

    # Make sure we get the same instance back for each creation
    same_instance = CLIArgs({'foo': 'bar'})
    assert same_instance is cmdline_args

    # Try a namedtuple
    cmdline_args = CLIArgs({'point': point(x=1, y=2)})
    # This is a little nutty, but we are testing to make sure we got a *copy* of the named tuple
    # back out and not a reference to the original one
    assert cmdline_args.point != point

# Generated at 2022-06-11 17:46:42.855473
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options: pass
    options = Options()
    options.a_boolean_flag = True
    options.search_path = ['/foo/bar', '/bar']
    options.search_path_set = set(['list', 'of', 'paths'])
    options.mapping = {'a': 'mapping', 'with': 'camelCaseKeys'}
    options.a_sequence = ('foo', 'bar', set(['baz', 'fuz']))

    args = CLIArgs(vars(options))
    assert args['a_boolean_flag']
    assert '/foo/bar' in args['search_path']
    assert 'list' in args['search_path_set']
    assert 'mapping' in args['mapping']
    assert 'bar' in args['a_sequence']

# Generated at 2022-06-11 17:46:51.156982
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 1, 'b': 'hello', 'c': [1, 2, 3]})
    assert args == {'a': 1, 'b': 'hello', 'c': (1, 2, 3)}

    # It's immutable
    try:
        args['d'] = 2
        # Should have thrown exception
        assert False
    except TypeError:
        pass

    # But it's deep immutable
    try:
        args['c'].append(4)
        # Should have thrown exception
        assert False
    except TypeError:
        pass

# Generated at 2022-06-11 17:46:58.039540
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Set to some pre-determined value
    test_dict = {'foo': 'foo_value',
                 'bar': {'baz': 'baz_value',
                         'quux': ['quux_0', 'quux_1', 'quux_2']},
                 'quux': set(['quux_0', 'quux_1', 'quux_2']),
                 'boo': 'boo_value',
                 'bar_items': ['baz', 'quux']}

    # Convert test_dict into an immutable dict
    imm_obj = CLIArgs(test_dict)

    # Verify imm_obj contains the same data
    assert imm_obj == test_dict
    # Verify imm_obj is immutable

# Generated at 2022-06-11 17:47:05.438476
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import os
    import sys
    from collections import Mapping
    from ansible.module_utils.common._collections_compat import Container, Sequence
    from ansible.module_utils.common.collections import ImmutableDict, from_docker_opt
    from ansible.plugins.loader import add_all_plugin_dirs, find_plugin
    from ansible.utils.add_cli_args import add_cli_args

    def add_args_for_unittest():
        # This is what we want in order to run unit tests
        parser = parser_toplevel.add_argument_group('TESTING ARGS')
        parser.add_argument('--unittest', default=False, action='store_true')
        parser.add_argument('--unittest-subarg', default='subarg_default')
        parser

# Generated at 2022-06-11 17:47:06.257375
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    pass

# Generated at 2022-06-11 17:47:15.862146
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Make a function which should be a Singleton based class and is also able to override
    class Func(object):
        def __init__(self, a):
            self.a = a
        def __call__(self, b):
            return self.a + b

    f1 = Func(1)
    assert f1(2) == 3

    # Make a class which should be a Singleton based class and is also able to override
    class C(metaclass=_ABCSingleton):
        def __init__(self, a):
            self.a = a
        def __call__(self, b):
            return self.a + b

    c1 = C(1)
    assert c1(2) == 3

# Generated at 2022-06-11 17:47:27.458224
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = {'foo': 42, 'bar': 'spam'}
    my_args = GlobalCLIArgs(args)
    assert isinstance(my_args, GlobalCLIArgs)
    assert isinstance(my_args, ImmutableDict)
    assert args == my_args
    assert args is not my_args

    args['baz'] = 'eggs'
    assert 'baz' not in my_args

    args['foo'] = 'chicken'
    assert 'foo' in my_args
    assert args['foo'] != my_args['foo']
    assert args['foo'] == 'chicken'
    assert my_args['foo'] == 42

    args['bar'] = ['x', 'y', 'z']
    assert isinstance(args['bar'], list)

# Generated at 2022-06-11 17:47:35.801042
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton
    class Bar(object):
        __metaclass__ = _ABCSingleton
    assert Foo() is Foo()
    assert Bar() is Bar()
    assert not Foo() is Bar()

# Generated at 2022-06-11 17:47:46.338641
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from textwrap import dedent
    expected_metaclass_name = '__auxiliary_ABCMeta__'

    class Foo(metaclass=_ABCSingleton):
        pass

    assert Foo().__class__.__metaclass__.__name__ == expected_metaclass_name, \
        dedent('''\
            expected _ABCSingleton metaclass name to be {expected_metaclass_name}
            instead got {got_metaclass_name}
            '''.format(expected_metaclass_name=expected_metaclass_name,
                       got_metaclass_name=Foo().__class__.__metaclass__.__name__))

# Generated at 2022-06-11 17:47:47.637165
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({})
    GlobalCLIArgs({'a': 1})

# Generated at 2022-06-11 17:47:49.855005
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object, metaclass=_ABCSingleton):
        pass

    assert Foo() is Foo()

# Generated at 2022-06-11 17:47:53.337295
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():  # pragma: no cover
    class TestSingleton(object, metaclass=_ABCSingleton):
        def __init__(self):
            pass

    obj1 = TestSingleton()
    obj2 = TestSingleton()
    assert obj1 is obj2

# Generated at 2022-06-11 17:47:59.843278
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'foo': {'bar': {'baz': 'bat'}}})
    assert isinstance(args['foo'], ImmutableDict)
    assert isinstance(args['foo']['bar'], ImmutableDict)
    assert isinstance(args['foo']['bar']['baz'], text_type)
    assert args['foo']['bar']['baz'] == 'bat'
    assert args['foo']['bar']['baz'] is args['foo']['bar']['baz']
    assert args['foo'] is args['foo']
    assert args['foo']['bar'] is args['foo']['bar']

# Generated at 2022-06-11 17:48:10.153904
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Check that ABCMeta overrides are correct
    class SingletonNoAbstractMethods(ImmutableDict, metaclass=_ABCSingleton):
        pass

    class SingletonAbstractMethods(ImmutableDict, metaclass=_ABCSingleton):
        @classmethod
        def foo(cls):
            pass

        @classmethod
        def bar(cls):
            pass

        @classmethod
        def garply(cls):
            pass

    # The following should work because there are no abstract methods in class SingletonNoAbstractMethods
    assert SingletonNoAbstractMethods == SingletonNoAbstractMethods()

    # The following should fail because there are abstract methods in class SingletonAbstractMethods
    try:
        SingletonAbstractMethods == SingletonAbstractMethods()
        assert False, "Should raise an exception"
    except TypeError as e:
        assert e

# Generated at 2022-06-11 17:48:19.968148
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from argparse import Namespace

    class FakeArgParser:
        def __init__(self, args):
            self.args = args
        def parse_args(self):
            return self.args

    fake_args = Namespace()
    fake_args.test_string = "dog"
    fake_args.test_list = ["a", "b", "c"]
    fake_args.test_dict = {
        "a": 1,
        "b": "b",
        "c": [3,2,1],
    }
    fake_parser = FakeArgParser(fake_args)

    sys.modules['ansible.cli.argparser'] = fake_parser
    test_args = GlobalCLIArgs.from_options(None)
    del sys.modules['ansible.cli.argparser']

   

# Generated at 2022-06-11 17:48:23.709480
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert len(CLIArgs({"a": 1, "b": 2})) == 2
    assert CLIArgs({"a": 1, "b": 2})["a"] == 1


# Generated at 2022-06-11 17:48:24.788815
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.cli.playbook.playbooks import PlaybookCLI

    assert isinstance(PlaybookCLI, _ABCSingleton)

# Generated at 2022-06-11 17:48:45.226630
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    # Set up example command line arguments from other tests
    from ansible.module_utils._text import to_text
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.common.arguments import AnsibleArgumentError
    from ansible.module_utils.connection.connection import Connection
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars

    inventory = InventoryManager(host_list='localhost,', vault_password='test')
    hostvars_manager = HostVars(inventory, loader)

    templar = Templar(loader, variables=dict())


# Generated at 2022-06-11 17:48:55.595672
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    a = CLIArgs({'foo': 'bar',
                 'baz': {'qux': 'quux'},
                 'quux': [{'corge': 'grault'},
                          {'garply': 'waldo'}]})
    assert not a.is_mutable()
    assert isinstance(a, Mapping)

    b = a['baz']
    assert not b.is_mutable()
    assert isinstance(b, Mapping)

    c = a['quux']
    assert not c.is_mutable()
    assert isinstance(c, Sequence)
    assert len(c) == 2

    d = c[0]
    assert not d.is_mutable()
    assert isinstance(d, Mapping)

    e = c[1]
    assert not e.is_m

# Generated at 2022-06-11 17:48:57.805225
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs.from_options({'foo': 'bar'})
    assert args['foo'] == 'bar'

# Generated at 2022-06-11 17:49:01.616696
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({"foo": "bar"})
    assert isinstance(args, GlobalCLIArgs)
    assert isinstance(args, CLIArgs)
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, dict)

# Generated at 2022-06-11 17:49:11.546084
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli.arguments import Options
    from ansible.utils.color import stringc


# Generated at 2022-06-11 17:49:20.505674
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    container = {'k1': {'k2': 'v2'}, 'k3': [1, 2, 3], 'k4': (4, 5, 6, 7)}
    cli_args = CLIArgs(container)

    assert cli_args['k1']['k2'] == 'v2'
    assert cli_args['k3'] == (1, 2, 3)
    assert cli_args['k4'] == (4, 5, 6, 7)
    assert isinstance(cli_args['k1'], ImmutableDict)
    assert isinstance(cli_args['k3'], tuple)
    assert isinstance(cli_args['k4'], tuple)



# Generated at 2022-06-11 17:49:25.756671
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # These have to be in here as they can't be in a fixture
    # They are just here to make the pylint warning go away
    opt_1 = [('r', '', '', ''), ('i', '', '', '')]
    opt_2 = [('r', '', '', ''), ('i', '', '', '')]
    assert sorted(opt_1) == sorted(opt_2)

# Generated at 2022-06-11 17:49:28.815089
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = GlobalCLIArgs.from_options(CLIArgs.from_options({'a':1}))
    assert isinstance(a, GlobalCLIArgs)
    assert a['a'] == 1

# Generated at 2022-06-11 17:49:30.802292
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    a = A()

# Generated at 2022-06-11 17:49:38.419512
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class TestObj:
        def __init__(self):
            self.test_iter = iter([1, 2, 3])
    cli_args = GlobalCLIArgs({'foo': 'bar', 'fizzle': TestObj()})
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args['fizzle'], TestObj)
    assert cli_args['fizzle'].test_iter.next() == 1
    try:
        cli_args['fizzle'].test_iter.next()
    except StopIteration as e:
        # Should fail because we can't modify a frozen iter
        assert True
    except Exception as e:  # pylint: disable=broad-except
        # Should fail because we can't modify a frozen iter, not because of any other reason
        assert False

# Generated at 2022-06-11 17:49:49.692879
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs(dict(some_key='some_value'))
    assert args['some_key'] == 'some_value'


# Generated at 2022-06-11 17:49:51.503619
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    cli_args = GlobalCLIArgs()
    assert cli_args

# Generated at 2022-06-11 17:49:58.076047
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # confirm you can create a CLIArgs instance when you provide a dict
    args = CLIArgs({'some_data': 'foo'})

    # confirm you can get data out of CLIArgs, that was put in
    assert 'some_data' in args.keys()
    assert args['some_data'] == 'foo'

    # confirm it's immutable
    with pytest.raises(TypeError):
        args['some_data'] = 'bar'

# Generated at 2022-06-11 17:50:01.380730
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object, metaclass=_ABCSingleton):
        def __init__(self):
            pass
    # Default class created
    t = TestClass()
    # Second class created which fails to exist
    try:
        t2 = TestClass()
    except TypeError:
        pass


# Generated at 2022-06-11 17:50:11.631619
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        pass

    class B(object):
        pass

    class C(_ABCSingleton):
        pass

    class D(A, B, C):
        pass

    assert issubclass(A, object) is True
    assert issubclass(B, object) is True
    assert issubclass(C, Singleton) is True
    assert issubclass(D, object) is True

    assert isinstance(A(), object) is True
    assert isinstance(B(), object) is True
    assert isinstance(C(), Singleton) is True
    assert isinstance(D(), object) is True

    assert D() is D()



# Generated at 2022-06-11 17:50:18.891786
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    import unittest
    import sys
    import weakref

    class _ABCSingletonTest(GlobalCLIArgs):
        __metaclass__ = _ABCSingleton

        def __init__(self, *args, **kwargs):
            super(_ABCSingletonTest, self).__init__(*args, **kwargs)

    test = _ABCSingletonTest({'test': 'test'})
    test2 = _ABCSingletonTest({})
    assert test == test2
    del test, test2

# Generated at 2022-06-11 17:50:25.124979
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        pass

    class B(object):
        pass

    assert not issubclass(A, B)
    assert not issubclass(B, A)

    class C(A, B):
        pass

    assert issubclass(C, A)
    assert issubclass(C, B)
    assert issubclass(A, C)
    assert issubclass(B, C)

    class D(C):
        pass

    assert issubclass(D, A)
    assert issubclass(D, B)
    assert issubclass(D, C)

# Generated at 2022-06-11 17:50:33.969040
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-11 17:50:41.054583
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    instance = CLIArgs({'SGD': ['JPY', 'USD'], 'BTC': ['CNY', 'USD'], 'CNY': ['EUR', 'JPY', 'USD']})
    assert instance['SGD'] == ('JPY', 'USD')
    assert instance['BTC'] == ('CNY', 'USD')
    assert instance['CNY'] == ('EUR', 'JPY', 'USD')
    assert instance['SGD'] == ('JPY', 'USD')
    assert instance['BTC'] == ('CNY', 'USD')
    assert instance['CNY'] == ('EUR', 'JPY', 'USD')

# Generated at 2022-06-11 17:50:44.633817
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    simple_mapping = {'foo': 'bar', 'sna': 'fu'}
    cli_args = CLIArgs(simple_mapping)
    assert cli_args == simple_mapping


# Generated at 2022-06-11 17:51:03.757311
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli.arguments import options
    global_cli_args = GlobalCLIArgs.from_options(options)

# Generated at 2022-06-11 17:51:12.601896
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
        pass

    class B(object):
        __metaclass__ = _ABCSingleton
        pass

    a1 = A()
    a2 = A()
    assert a1 is a2
    assert type(a1) is type(a2)

    b1 = B()
    b2 = B()
    assert b1 is b2
    assert type(b1) is type(b2)

    assert a1 is not b1
    assert type(a1) is not type(b1)

# Generated at 2022-06-11 17:51:22.137003
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common._collections_compat import Mapping, Sequence

    import ansible.cli.adhoc
    import ansible.cli.playbook
    import ansible.cli.connection
    import ansible.cli.galaxy
    import ansible.cli.vault
    import ansible.cli.include_role
    import ansible.cli.provision
    import ansible.cli.pull
    import ansible.cli.push
    import ansible.cli.repl

    import ansible.constants
    import ansible.config.loader
    import ansible.context
    import ansible.executor.task_queue_manager
    import ansible.inventory
    import ansible.module_utils.connection
    import ansible.plugins
    import ansible.plays.play
    import ansible.parsing

# Generated at 2022-06-11 17:51:28.926954
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.vars import combine_vars
    import ansible.constants as C
    mapping = {}
    mapping.update(C.__dict__)
    mapping.update(combine_vars(None, None))
    mapping['tags'] = set()
    mapping['skip_tags'] = set()
    mapping['check_mode'] = True

    # Can't use GlobalCLIArgs as a contextmanager as it is a singleton
    # so need to use CLIArgs instead
    with CLIArgs.from_options(mapping):
        pass

# Generated at 2022-06-11 17:51:35.141953
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Make sure that you can only ever create one of GlobalCLIArgs
    # This is to make sure that the singleton metaclass works
    assert isinstance(GlobalCLIArgs.instance(), GlobalCLIArgs)

    assert isinstance(_make_immutable(GlobalCLIArgs.instance()), ImmutableDict)

    #TODO: Add more tests

# Generated at 2022-06-11 17:51:44.699540
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        class SingletonMetaclass(type):
            __metaclass__ = _ABCSingleton

        class SingletonTestClass(metaclass=SingletonMetaclass):
            def __init__(self, foo):
                self.foo = foo

        class SingletonSubclass(SingletonTestClass):
            def __init__(self, bar):
                super(SingletonSubclass, self).__init__(bar)
                self.bar = bar

        assert hasattr(SingletonTestClass, '__new__')
        assert hasattr(SingletonSubclass, '__new__')
    except TypeError:
        raise AssertionError('ABCMeta and Singleton can not be used at the same time.')

# Generated at 2022-06-11 17:51:51.981687
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Generalize containers through recursion instead of by instance
    # detection when we can't be sure that a class we want is in the MRO
    class NestedMapping(dict):
        pass
    class NestedSequence(list):
        pass
    class NestedSet(set):
        pass
    class NestedContainer(NestedMapping, NestedSequence, NestedSet):
        pass


# Generated at 2022-06-11 17:51:56.526501
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Test what happens if we set the args to a known value and then try to create a singleton
    # instance.
    args = ["ansible-playbook", "-i", "hosts.yml"]
    GlobalCLIArgs.set(args)
    GlobalCLIArgs.instance()



# Generated at 2022-06-11 17:52:06.629334
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse

    parser = argparse.ArgumentParser(description="Test GlobalCLIArgs")
    parser.add_argument("foo-arg")
    parser.add_argument("--bar-opt", nargs="*")
    parser.add_argument("--baz-opt", nargs="+")

    # This is tested in test_CLIArgs
    # parser.add_argument("--boo-opt", action='append')

    global_args = parser.parse_args("first_arg --bar-opt bar1 --bar-opt bar2 --baz-opt baz1 baz2 --baz-opt baz3 baz4 baz5".split())
    GlobalCLIArgs.from_options(global_args)

    assert GlobalCLIArgs["foo-arg"] == "first_arg"

# Generated at 2022-06-11 17:52:15.274201
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Setup
    class Test:
        def __init__(self, arg):
            super(Test, self).__init__()
            self._args = arg

    class TestArgs(GlobalCLIArgs):
        pass

    TestArgs.__new__ = Test

    # Test
    args = TestArgs({'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': [5, 6, 7]})
    assert args._args == {'a': 1, 'b': 2, 'c': ImmutableDict({'d': 3, 'e': 4}), 'f': tuple([5, 6, 7])}

# Generated at 2022-06-11 17:52:57.739017
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser(description='This is a test')
    parser.add_argument('--ignore', default=u'ignored', type=text_type)
    args, _ = parser.parse_known_args()
    cliargs = GlobalCLIArgs.from_options(args)
    assert isinstance(cliargs, ImmutableDict)
    assert u'ignore' in cliargs
    assert cliargs[u'ignore'] == u'ignored'

# Generated at 2022-06-11 17:53:00.988555
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    class B(A):
        pass
    A()
    # We don't expect this to be a singleton class
    assert isinstance(B, A)

# Generated at 2022-06-11 17:53:07.259347
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        def __init__(self, x):
            self.x = x

    class B(A):
        pass

    class C(metaclass=_ABCSingleton):
        pass

    x = A(1)
    y = A(2)
    assert x.x == 1
    assert y.x == 1

    x = B(1)
    y = B(3)
    assert x.x == 3
    assert y.x == 3

    x = C()
    y = C()
    assert x is y

# Generated at 2022-06-11 17:53:09.867954
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    sing = _ABCSingleton()
    assert isinstance(sing, _ABCSingleton) is True


# Generated at 2022-06-11 17:53:14.177266
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Basic constructor call
    command_line_args = CLIArgs({"command_line_switches": {"verbosity": True}})
    # Validate that what we get back is a tuple
    assert isinstance(command_line_args["command_line_switches"]["verbosity"], tuple)



# Generated at 2022-06-11 17:53:22.235962
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test when all containers are nested to a depth of 1
    cl = CLIArgs({'k1': {'k2': {'k3': 'v1'}}})
    assert isinstance(cl, ImmutableDict)
    assert isinstance(cl['k1'], ImmutableDict)
    assert isinstance(cl['k1']['k2'], ImmutableDict)
    assert cl['k1']['k2']['k3'] == 'v1'

    # Test when all containers are nested to a depth of 2
    cl = CLIArgs({'k1': {'k2': {'k3': ['v1', 'v2']}}})
    assert isinstance(cl, ImmutableDict)
    assert isinstance(cl['k1'], ImmutableDict)

# Generated at 2022-06-11 17:53:31.465286
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class DummyOptions(object):
        def __init__(self, i):
            self.int_value = i
            self.list = [1, 2, 3]
            self.dict = {"a": "b"}
            self.set = {1, 2, 3}

    args = CLIArgs.from_options(DummyOptions(0))
    assert args["int_value"] == 0
    args["int_value"] = 1
    assert args["int_value"] == 0
    with pytest.raises(TypeError):
        args["int_value"] = None

    # Test that the keys of the args object are indeed immutable.
    for key in args:
        # pylint: disable=unsupported-assignment-operation
        with pytest.raises(TypeError):
            key = "test"

    # Test that

# Generated at 2022-06-11 17:53:33.804894
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = ImmutableDict({'verbosity':0, 'help':False})
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-11 17:53:44.512208
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_set = {'toplevel': {'mutable': [1, 2], 'next': {'immutable': 'string'}, 'nested': {'mutable': {'bottom': 'level'}}}}
    args = CLIArgs(test_set)
    assert isinstance(args, ImmutableDict)
    assert isinstance(args['toplevel'], ImmutableDict)
    assert isinstance(args['toplevel']['mutable'], tuple)
    assert isinstance(args['toplevel']['next'], ImmutableDict)
    assert isinstance(args['toplevel']['nested'], ImmutableDict)
    assert isinstance(args['toplevel']['nested']['mutable'], ImmutableDict)

# Generated at 2022-06-11 17:53:53.222314
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("-f", "--foo", help="foo help")
    parser.add_argument("-b", "--bar", help="bar help")

    sys.argv = ['/usr/bin/ansible-playbook', '-foo', 'foo_value', '-bar', 'bar_value']
    options_1 = parser.parse_args()

    args_1 = GlobalCLIArgs.from_options(options_1)

    assert options_1.foo == args_1['foo']
    assert options_1.bar == args_1['bar']

    # Now we will verify that even though we parse the command line args
    # for a second time, we will still get the same (only) instance of
    # GlobalCLIArgs