

# Generated at 2022-06-11 17:45:13.880460
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test on valid input
    args = {'host': 'hostname', 'file': 'filepath', 'module': 'module_name'}
    assert CLIArgs(args) == args

    # Test on invalid input
    args = [1, 2, 3, 4]
    try:
        _ = CLIArgs(args)
    except Exception as e:
        assert isinstance(e, TypeError)



# Generated at 2022-06-11 17:45:22.956998
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # test constructor
    # test for boolean
    item = CLIArgs({'boolean': True})
    assert isinstance(item, CLIArgs)

    # test for integer
    item = CLIArgs({'integer': 10})
    assert isinstance(item, CLIArgs)

    # test for string
    item = CLIArgs({'string': 'Hello'})
    assert isinstance(item, CLIArgs)

    # test for list
    item = CLIArgs({'list': ['a', 'b']})
    assert isinstance(item, CLIArgs)

    # test for set
    item = CLIArgs({'set': set(['a', 'b', 'c'])})
    assert isinstance(item, CLIArgs)

    # test for dictionary
    item = CLIArgs({'dict': {'a': 1, 'b': 2}})

# Generated at 2022-06-11 17:45:28.281757
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    argparser = argparse.ArgumentParser()
    argparser.add_argument("-b", "--bool", action="store_true")
    options = argparser.parse_args(["-b"])
    args = GlobalCLIArgs.from_options(options)
    assert args == {"bool": True}



# Generated at 2022-06-11 17:45:30.116017
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert isinstance(_ABCSingleton(str('A'), (object,), {}), type)

# Generated at 2022-06-11 17:45:35.096077
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({'a': 1}) == {'a': 1}
    assert CLIArgs({'a': 1, 'b': {'c': [1, 2]}}) == {'a': 1, 'b': {'c': (1, 2)}}
    assert CLIArgs({'a': [1, 2, 3]}) == {'a': (1, 2, 3)}
    assert CLIArgs({'a': {'b': [1, 2, 3]}}) == {'a': {'b': (1, 2, 3)}}
    assert CLIArgs({'a': {'b': {'c': [1, 2, 3]}}}) == {'a': {'b': {'c': (1, 2, 3)}}}

# Generated at 2022-06-11 17:45:44.261272
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from collections import OrderedDict
    cliargs = CLIArgs(OrderedDict([('a', 'hello'), ('b', 'there'), ('c', 'world')]))
    assert cliargs['a'] == 'hello'
    assert cliargs['b'] == 'there'
    assert cliargs['c'] == 'world'
    assert len(cliargs) == 3

    cliargs = CLIArgs(OrderedDict([('a', {'b': 'hello', 'c': 'there'})]))
    assert cliargs['a']['b'] == 'hello'
    assert cliargs['a']['c'] == 'there'
    assert len(cliargs) == 1


# Generated at 2022-06-11 17:45:52.621281
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import collections

    option = collections.namedtuple('option', ['foo', 'bar'])
    args = CLIArgs({'foo': 1, 'bar': option(1, 2)})

    assert isinstance(args, collections.Mapping)
    assert isinstance(args, collections.Mapping)
    assert isinstance(args['bar'], collections.Mapping)
    assert isinstance(args['bar'], collections.Mapping)
    assert isinstance(args['bar'], collections.Mapping)
    assert isinstance(args['bar'], collections.Mapping)

    try:
        args['foo'] = 2
        assert False
    except AttributeError:  # raised by the ImmutableDict
        pass


# Generated at 2022-06-11 17:45:54.629956
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    gca = GlobalCLIArgs.from_options(object())
    assert isinstance(gca, CLIArgs)

# Generated at 2022-06-11 17:46:03.184268
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Unit test for constructor of class CLIArgs"""
    arg = {
        'foo': {
            'bar': [
                'baz',
                [1, 2, 3],
            ],
            'qux': {
                'quux': 'quuz',
                'corge': set(('grault', 'garply', 'waldo', 'fred')),
            },
        },
        'plugh': text_type('xyzzy'),
    }
    cli_args = CLIArgs(arg)
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args['foo'], ImmutableDict)
    assert isinstance(cli_args['foo']['bar'], tuple)
    assert isinstance(cli_args['foo']['bar'][1], tuple)
    assert isinstance

# Generated at 2022-06-11 17:46:08.284162
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    parsed_global_cli_args = GlobalCLIArgs({'check_mode': False, 'become': False, 'become_method': None})
    assert parsed_global_cli_args['check_mode'] is False
    assert parsed_global_cli_args['become'] is False
    assert parsed_global_cli_args['become_method'] is None

# Generated at 2022-06-11 17:46:21.741788
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {
        "a": 10,
        "b": {
            "c": 20,
            "d": ["e", "f"],
            "g": ("h", ["i"]),
        },
    }

    new_dict = CLIArgs(test_dict)

    assert test_dict == new_dict
    assert new_dict['a'] == 10
    assert new_dict['b']['c'] == 20
    assert new_dict['b']['d'] == ("e", "f")
    assert new_dict['b']['g'] == ("h", ["i"])

    try:
        new_dict['a'] = 11
    except TypeError:
        # This should be an error
        pass
    else:
        raise AssertionError

    # We should not be able to modify the contents

# Generated at 2022-06-11 17:46:27.588827
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {
        'foo': [4, 5, 'bar'],
        'bar': {'baz': 'xyzzy'},
        'baz': 42,
    }
    cli_args = CLIArgs(mapping)
    assert cli_args.foo == (4, 5, 'bar')
    assert cli_args.bar == ImmutableDict({'baz': 'xyzzy'})
    assert cli_args.baz == 42

# Generated at 2022-06-11 17:46:31.632829
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs(dict(a='b', c=dict(d='e')))
    assert isinstance(args, Mapping)
    assert isinstance(args, GlobalCLIArgs)

    assert isinstance(args.get('c'), ImmutableDict)
    assert args.get('c') == dict(d='e')

    assert args.get('d') is None

# Generated at 2022-06-11 17:46:37.449533
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class NewABCSingleton(object):
        pass
    assert issubclass(NewABCSingleton, object)

    class NewSingleton(object):
        pass
    assert issubclass(NewSingleton, object)

    class NewABCSingletonSingleton(object):
        __metaclass__ = _ABCSingleton
    assert issubclass(NewABCSingletonSingleton, NewABCSingleton)
    assert issubclass(NewABCSingletonSingleton, NewSingleton)

# Generated at 2022-06-11 17:46:49.143973
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict_value = {
        'value': 'this is a string',
        'integer': 10,
        'set': {'1', '2', '3'},
        'tuple': ('some', 'values', 'in', 'a', 'tuple'),
        'list': ['a', 'list', 'of', 'strings'],
        'dict': {
            'aaa': 'bbb',
            'ccc': {
                'ddd': 'eee'
            }
        }
    }
    cli_args = CLIArgs(dict_value)
    cli_args_copy = cli_args.copy()
    assert cli_args is cli_args_copy
    assert cli_args['value'] == 'this is a string'
    assert cli_args['integer'] == 10
    assert cli

# Generated at 2022-06-11 17:46:50.598162
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MySingleton(GlobalCLIArgs):
        pass
    MySingleton()

# Generated at 2022-06-11 17:46:55.764540
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ABCSingletonTest(object):
        __metaclass__ = _ABCSingleton
        def __new__(cls, *args, **kwargs):
            if not hasattr(cls, '_instance'):
                cls._instance = super(ABCSingletonTest, cls).__new__(cls, *args, **kwargs)
            return cls._instance

    assert ABCSingletonTest() is ABCSingletonTest(), "Failed to create Singleton properly"

# Generated at 2022-06-11 17:46:57.660391
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    _ABCSingleton('method_doesnt_matter', (), {})

# Generated at 2022-06-11 17:47:03.864718
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # pylint: disable=no-member, too-few-public-methods

    class Test(object):
        __metaclass__ = _ABCSingleton

    t1 = Test()
    t2 = Test()
    assert t1 is t2, "Test is not a singleton"

    class Test2(Test):
        pass

    t1 = Test2()
    t2 = Test2()
    assert t1 is t2, "Test2 is not a singleton"

    # pylint: enable=no-member, too-few-public-methods

# Generated at 2022-06-11 17:47:15.155169
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    cli_options = {
        'test1': 'test1',
        'test2': 'test2'
    }
    cli_options_with_argparse = {
        'test3': 'test3',
        'test4': 'test4'
    }

    # constructor without any arguments
    test_args1 = CLIArgs({})
    assert isinstance(test_args1, ImmutableDict)

    # construcotr with argparse objects
    test_args2 = CLIArgs.from_options(cli_options_with_argparse)
    assert isinstance(test_args2, ImmutableDict)

    # constructor with nested ImmutableDict

# Generated at 2022-06-11 17:47:23.545318
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _FakeCLIArgs(CLIArgs):
        """
        A fake version of CLIArgs to verify that _ABCSingleton properly inherits Singleton.
        """
        pass

    assert isinstance(_FakeCLIArgs, Singleton), "Expected _FakeCLIArgs to inherit Singleton"

# Generated at 2022-06-11 17:47:26.004031
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    All we can test here is that the constructor didn't throw an exception.
    """
    GlobalCLIArgs({'my_foo': 'bar'})

# Generated at 2022-06-11 17:47:36.187059
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class MyClass(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y

        def __repr__(self):
            return '({}, {})'.format(self.x, self.y)

    def recursive_globalcliargs_test(options):
        # print('recursive_globalcliargs_test: options = {}'.format(options))
        assert isinstance(options, dict)

        for key, value in options.items():
            if isinstance(value, dict):
                recursive_globalcliargs_test(value)
            else:
                assert isinstance(key, text_type), '{} is not unicode'.format(key)
                assert isinstance(value, (text_type, binary_type, int, float, MyClass)) or value is None or value

# Generated at 2022-06-11 17:47:47.781646
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    argument_dict = {
        "ansible_host": "localhost",
        "ansible_user": "root",
        "connection": "ansible.connection.chroot",
        "verbosity": 1,
        "extra_variables": {
            "hello": "world",
            "my_set": {
                1, 2, 3
            },
            "my_list": [
                4, 5, 6
            ]
        }
    }

    # Result should be immutable
    args = CLIArgs(argument_dict)

    # CLIArgs should also be a container
    assert "ansible_host" in args

    # Should be a deep copy
    assert argument_dict is not args

    # Should be immutable

# Generated at 2022-06-11 17:47:50.470133
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # pylint: disable=too-few-public-methods
    class Temp(_ABCSingleton):
        pass
    Temp()


# Generated at 2022-06-11 17:47:59.039216
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Ensure class is usable"""
    class TestSingleton(object):
        __metaclass__ = _ABCSingleton
    test1 = TestSingleton()
    assert test1 is TestSingleton(), "Singleton pattern failed"
    class TestSingleton2(object):
        __metaclass__ = _ABCSingleton
    test1 = TestSingleton2()
    assert test1 is TestSingleton2(), "Singleton pattern failed"
    assert TestSingleton2 is not TestSingleton, "Wrong singleton used"
    class TestSingleton3(TestSingleton, ABCMeta):
        pass
    test1 = TestSingleton3()
    assert test1 is TestSingleton3(), "Singleton pattern failed"
    assert TestSingleton3 is TestSingleton, "Wrong singleton used"

# Generated at 2022-06-11 17:48:01.345086
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _Test(_ABCSingleton, object):
        def __init__(self):
            super(_Test, self).__init__()

    _Test()

# Generated at 2022-06-11 17:48:04.852302
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # sanity test the constructor
    a = CLIArgs(dict(foo='bar'))
    assert a.foo == 'bar'
    assert isinstance(a, ImmutableDict)



# Generated at 2022-06-11 17:48:08.584719
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test1(_ABCSingleton):
        pass

    class Test2(_ABCSingleton):
        pass

    Test1.register(tuple)

    t1 = Test1()
    t2 = Test2()

    assert t1 == tuple
    assert t2 == Test2

# Generated at 2022-06-11 17:48:11.403463
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton(object):
        __metaclass__ = _ABCSingleton
        pass
    class TestSingleton2(TestSingleton):
        pass
    assert TestSingleton is TestSingleton2
    test = TestSingleton()
    test2 = TestSingleton()
    assert test is test2

# Generated at 2022-06-11 17:48:16.773199
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    a = A()
    b = A()
    assert a is b
    assert a == b

# Generated at 2022-06-11 17:48:27.338315
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mydict = {'foo': 'bar',
              'hello': {'where': 'world',
                        'how': 'does it feel'},
              'truth': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
              'death': ['knell', 'toll', 'clang', 'ring']}
    cli_args = CLIArgs(mydict)

    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args, Mapping)
    assert isinstance(cli_args, CLIArgs)

    for key, value in mydict.items():
        assert key in cli_args
        assert cli_args[key] == value

    for key, value in cli_args.items():
        assert key in mydict
        assert value == mydict[key]

# Generated at 2022-06-11 17:48:31.131527
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Test initialize of class CLIArgs."""
    test_dict = {'a': {'b': 2, 'c': [3, 4, 5]}, 'b': 2}
    test_cli_args = CLIArgs(test_dict)
    assert test_cli_args == ImmutableDict({'a': ImmutableDict({'b': 2, 'c': (3, 4, 5)}), 'b': 2})

# Generated at 2022-06-11 17:48:36.466570
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    import unittest

    class TestClass(object, metaclass=_ABCSingleton):
        pass

    class TestClass2(object, metaclass=_ABCSingleton):
        pass

    # Should only be able to create a single instance of each
    assert TestClass() is TestClass()
    assert TestClass2() is TestClass2()
    # Should not be able to create instances of the same subclass
    with unittest.TestCase().assertRaises(TypeError):
        TestClass2()

# Generated at 2022-06-11 17:48:42.374801
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    input_dict = {'a': {'b': [1, 2], 'c': {'d': [3, 4]}}}
    output_dict = {'a': {'b': (1, 2), 'c': {'d': (3, 4)}}}
    args = CLIArgs(input_dict)
    assert output_dict == args


# Generated at 2022-06-11 17:48:46.280584
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    foo_a = Foo()
    foo_b = Foo()

    assert id(foo_a) == id(foo_b)


# Generated at 2022-06-11 17:48:46.921889
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    pass

# Generated at 2022-06-11 17:48:56.542058
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import unittest
    import pytest
    from ansible.module_utils.common.type_utils import not_found
    from ansible.module_utils.common.type_utils import assign
    from ansible.module_utils.common.type_utils import set_immutable
    from ansible.module_utils.common.type_utils import immutable_types_only

    class test(unittest.TestCase):
        def test_set_immutable(self):
            """Tests that set_immutable does not raise an exception when called on GlobalCLIArgs"""
            set_immutable(GlobalCLIArgs)

        def test_immutable_types_only(self):
            """Tests that immutable_types_only does not raise an exception when called on GlobalCLIArgs"""
            immutable_types_only(GlobalCLIArgs)

       

# Generated at 2022-06-11 17:49:06.462879
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABCSingletonTestDict(CLIArgs, metaclass=_ABCSingleton):
        def __init__(self):
            super(_ABCSingletonTestDict, self).__init__({'a': 1, 'b': 2})

    class _ABCSingletonTestList(CLIArgs, metaclass=_ABCSingleton):
        def __init__(self):
            super(_ABCSingletonTestList, self).__init__({'a': 1, 'b': 2})

    assert id(_ABCSingletonTestDict()) == id(_ABCSingletonTestDict())
    assert id(_ABCSingletonTestDict()) != id(_ABCSingletonTestList())

# Generated at 2022-06-11 17:49:08.024571
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs.from_options(options=None)
    GlobalCLIArgs.from_options(options=object())

# Generated at 2022-06-11 17:49:23.858150
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import datetime
    from ansible.utils.boolean import boolean
    from collections import OrderedDict
    from ansible_collections.openstack.cloud.plugins.module_utils import cli_args
    options_obj = object
    options_obj.connection = 'network_cli'
    options_obj.extra_vars = '{"os_cloud": "openstack"}'
    options_obj.module_path = '../plugins/modules/'
    options_obj.module_name = 'os_compute_instance_v2'
    options_obj.module_args = '{"name": "test"}'
    options_obj.diff = False
    options_obj.no_log = False
    options_obj.debug = False
    options_obj.check = False

# Generated at 2022-06-11 17:49:26.819347
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(GlobalCLIArgs, Singleton)
    assert issubclass(GlobalCLIArgs, ABCMeta)
    assert issubclass(GlobalCLIArgs, CLIArgs)

# Generated at 2022-06-11 17:49:29.153924
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_dict = {}
    with GlobalCLIArgs.create_instance(test_dict):
        assert GlobalCLIArgs is not None

# Generated at 2022-06-11 17:49:35.026463
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo():
        def __init__(self):
            pass

    class Bar():
        def __init__(self):
            pass

    class _ABCSingletonFoo(Foo, metaclass=_ABCSingleton):
        pass

    class _ABCSingletonBar(Bar, metaclass=_ABCSingleton):
        pass

    _ABCSingletonFoo()
    _ABCSingletonBar()
    _ABCSingletonFoo()
    _ABCSingletonBar()

# Generated at 2022-06-11 17:49:41.359454
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class A(object):
        pass
    a = A()
    a.b = A()
    a.b.c = "1"
    a.b.d = "2"
    a.e = "3"
    a.f = "4"
    x = GlobalCLIArgs.from_options(a)
    assert x == {"b": {"c": "1", "d": "2"}, "e": "3", "f": "4"}



# Generated at 2022-06-11 17:49:46.316083
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """UnitTest"""
    class Thing(object):
        """UnitTest"""
        __metaclass__ = _ABCSingleton

    class OtherThing(object):
        """UnitTest"""
        __metaclass__ = _ABCSingleton

    assert Thing() is Thing()
    assert OtherThing() is OtherThing()
    assert Thing() is not OtherThing()

# Generated at 2022-06-11 17:49:58.256428
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import unittest
    import sys
    import types

    class TestGlobalCLIArgsInit(unittest.TestCase):
        """
        Test the constructor of class GlobalCLIArgs
        """
        def test_GlobalCLIArgs_is_a_class(self):
            """
            Verify that GlobalCLIArgs is a class
            """
            self.assertTrue(isinstance(GlobalCLIArgs, type))

        def test_GlobalCLIArgs_is_derived_from_CLIArgs(self):
            """
            Verify that GlobalCLIArgs is derived from CLIArgs
            """
            self.assertTrue(issubclass(GlobalCLIArgs, CLIArgs))

        def test_Globalcliargs_is_derived_from_ABCMeta(self):
            """
            Verify that GlobalCLIArgs is derived from ABCMeta
            """


# Generated at 2022-06-11 17:50:04.763856
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Example arguments used in unittests
    cli_args = {'private_key_file': '~/.ssh/ansible-test.pem',
                'remote_user': 'ec2-user',
                'become': True,
                'become_method': 'sudo',
                'become_user': 'root',
                'verbosity': 6,
                'listhosts': ['10.0.1.3', '10.0.1.4']}

    global_cli_args = GlobalCLIArgs(cli_args)

    for key, value in cli_args.items():
        assert global_cli_args[key] == value

    assert global_cli_args['private_key_file'] == '~/.ssh/ansible-test.pem'


# Generated at 2022-06-11 17:50:08.052424
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    x = GlobalCLIArgs({})
    assert isinstance(x, ImmutableDict), "Not an immutable dict"
    assert isinstance(x, GlobalCLIArgs), "Not a singleton"

# Generated at 2022-06-11 17:50:19.435341
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs({'aws': 'blah', 'ssh': 'blah', 'remote': 'blah', 'winrm': 'blah'})
    assert isinstance(cli_args, CLIArgs)
    assert isinstance(cli_args, ImmutableDict)
    assert not isinstance(cli_args, dict)
    assert cli_args != {'aws': 'blah', 'ssh': 'blah', 'remote': 'blah', 'winrm': 'blah'}
    assert cli_args == {'aws': 'blah', 'ssh': 'blah', 'remote': 'blah', 'winrm': 'blah'}
    assert cli_args['aws'] == 'blah'
    assert cli_args['ssh'] == 'blah'

# Generated at 2022-06-11 17:50:40.085940
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Test that we are a singleton
    assert GlobalCLIArgs() is GlobalCLIArgs()

    import six
    if six.PY2:
        # In Python2, `next` is not a keyword
        next = lambda x: six.next(x)
    else:
        next = next
    # We should have an iterator that can only be iterated over once
    iterator = vars(GlobalCLIArgs()).items()
    # Call next() as many times as we can without failing for the first time
    for item in iterator:
        pass
    # Ensure that once we've iterated over everything we still get the same error
    try:
        next(iterator)
        assert False
    except StopIteration:
        pass

    my_cli_args = {'a': 1, 'b': 2}

# Generated at 2022-06-11 17:50:50.820197
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import json
    import datetime

# Generated at 2022-06-11 17:50:53.999942
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(B):
        pass

    assert A() is A()

# Generated at 2022-06-11 17:51:04.769181
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        pass

    class B(object):
        pass

    class C(A, B, object):
        pass

    class SingletonA(A, _ABCSingleton):
        __metaclass__ = _ABCSingleton
        pass

    class SingletonB(B, _ABCSingleton):
        __metaclass__ = _ABCSingleton
        pass

    class SingletonC(C, _ABCSingleton):
        __metaclass__ = _ABCSingleton
        pass

    class_a = SingletonA()
    class_b = SingletonB(class_a)

    try:
        class_c = SingletonC(class_a)
    except TypeError:
        class_c = None

    assert isinstance(class_a, SingletonA)

# Generated at 2022-06-11 17:51:08.106350
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    parser = CLIArgs({'hello': 'world'})
    obj = parser.copy()
    assert obj['hello'] == 'world'



# Generated at 2022-06-11 17:51:17.956859
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    '''
    Test that the CLI args get converted to immutable data types
    '''
    import collections
    import os
    import sys

    # We need to simulate command line arguments, but we cannot use argparse because that will
    # trigger the __main__ parser and we are testing the GlobalCLIArgs class instead.  So we use
    # optparse and then convert
    from optparse import OptionParser

    def make_option_parser():
        """Return an option parser with the same defaults as cli args"""
        parser = OptionParser()

        # command line switches
        # General
        parser.add_option('-v', '--verbose', dest='verbosity', action='count', default=0,
                          help='Verbose mode (-v, -vv, etc)')

# Generated at 2022-06-11 17:51:25.408606
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {"key1": "value", "key2": ["value", "value2"], "key3": {"key4": ["value3", "value4"]}}
    test = CLIArgs(args)
    assert isinstance(test["key1"], str)
    assert isinstance(test["key2"], tuple)
    assert isinstance(test["key2"][0], str)
    assert isinstance(test["key2"][1], str)
    assert isinstance(test["key3"], ImmutableDict)
    assert isinstance(test["key3"]["key4"], tuple)
    assert isinstance(test["key3"]["key4"][0], str)
    assert isinstance(test["key3"]["key4"][1], str)

# Generated at 2022-06-11 17:51:37.196704
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from datetime import datetime
    from ansible.utils.context_objects import Context
    from ansible.options import Options

    # Make sure raising exception has no side effects
    try:
        GlobalCLIArgs(123)
    except TypeError:
        pass

    assert GlobalCLIArgs.__doc__ == CLIArgs.__doc__
    assert GlobalCLIArgs.from_options.__func__ is CLIArgs.from_options.__func__
    assert GlobalCLIArgs.from_options.__doc__ is CLIArgs.from_options.__doc__

    options = Options()
    options_immutable_dict = CLIArgs.from_options(options)
    assert isinstance(options_immutable_dict, ImmutableDict)


# Generated at 2022-06-11 17:51:39.871954
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # yes you can use ** on a dict.
    args = CLIArgs(dict(foo='bar'))
    assert isinstance(args, ImmutableDict)


test_CLIArgs()

# Generated at 2022-06-11 17:51:49.085543
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    input_args = {'ANSIBLE_ARGS': 'arg1=val1', 'ANSIBLE_CONFIG': 'arg2=val2'}
    output_args = CLIArgs(input_args)

    assert isinstance(output_args, CLIArgs)
    assert isinstance(output_args, ImmutableDict)
    assert not isinstance(output_args, Mapping)
    assert not isinstance(output_args, Sequence)
    assert not isinstance(output_args, Set)
    assert not isinstance(output_args, Container)
    # because we are using a dictionary comprehension, the order is more likely to be random
    assert set(output_args.keys()) == set(['ANSIBLE_ARGS', 'ANSIBLE_CONFIG'])
    assert output_args['ANSIBLE_ARGS'] == 'arg1=val1'


# Generated at 2022-06-11 17:52:16.236412
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABCSingleton1(object):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            super(TestABCSingleton1, self).__init__()
            self.test = 'test'

    class TestABCSingleton2(object):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            super(TestABCSingleton2, self).__init__()
            self.test = 'test'

    TestABCSingleton1()
    TestABCSingleton2()

# Generated at 2022-06-11 17:52:22.103769
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Don't want this code in __main__ because it is also a unit test but we don't want to
    # import and run unit tests as part of __main__
    from ansible.config.manager import ConfigManager
    options, args = ConfigManager(args=['--version'], usage='it is not used')
    gca = GlobalCLIArgs.from_options(options)
    assert gca.keys() == ['version']

# Generated at 2022-06-11 17:52:26.251978
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Test to ensure we can define a subclass of _ABCSingleton.
    """
    class ATestClass(_ABCSingleton):
        """
        Create a class that uses _ABCSingleton as a metaclass.
        """
        pass

    assert isinstance(ATestClass, _ABCSingleton)

# Generated at 2022-06-11 17:52:29.265855
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # check for singleton property
    args1 = GlobalCLIArgs()
    args2 = GlobalCLIArgs()
    assert args1 is args2

# Generated at 2022-06-11 17:52:30.813828
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # we will not perform a check on the GlobalCLIArgs class
    assert True

# Generated at 2022-06-11 17:52:41.136783
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class FakeOptions(object):
        def __init__(self):
            self.foo = 'foo'
            self.bar = 'bar'
            self.baz = {'a': {'b': 1}}

    options = FakeOptions()
    cli_args = CLIArgs.from_options(options)

    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args['foo'], text_type)
    assert isinstance(cli_args['bar'], text_type)
    assert isinstance(cli_args['baz'], ImmutableDict)
    assert isinstance(cli_args['baz']['a'], ImmutableDict)
    assert isinstance(cli_args['baz']['a']['b'], int)


# Generated at 2022-06-11 17:52:46.565724
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Verify that subclasses of _ABCSingleton don't conflict with each other.
    """
    # pylint: disable=too-few-public-methods
    class Foo(object):
        """Test class"""
        __metaclass__ = _ABCSingleton
    class Bar(object):
        """Test class"""
        __metaclass__ = _ABCSingleton

# Generated at 2022-06-11 17:52:55.944862
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyObject(_ABCSingleton):
        pass

    class MyObjectChild(MyObject):
        pass

    # Check it behaves how we expect
    obj1 = MyObject()
    obj2 = MyObject()
    assert id(obj1) == id(obj2)
    assert isinstance(obj1, MyObject)
    assert isinstance(obj2, MyObject)
    assert not isinstance(obj1, MyObjectChild)
    assert not isinstance(obj2, MyObjectChild)

    obj1 = MyObjectChild()
    obj2 = MyObjectChild()
    assert id(obj1) == id(obj2)
    assert isinstance(obj1, MyObject)
    assert isinstance(obj2, MyObject)
    assert isinstance(obj1, MyObjectChild)
    assert isinstance(obj2, MyObjectChild)



# Generated at 2022-06-11 17:53:00.597365
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    class B(A):
        pass
    assert issubclass(B, A)
    assert isinstance(B(), A)
    assert A() is A()
    assert B() is A()
    assert B() is B()

# Generated at 2022-06-11 17:53:08.494286
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    x = {'a': 'b', 'c': [1, 2, 3], 'd': {'e': 'f'}}
    y = CLIArgs(x)
    assert isinstance(y, ImmutableDict)
    assert y == x

    # Test we have recursively turned all mutable types into immutable types
    assert frozenset(y.keys()) == frozenset(x.keys())
    assert isinstance(y.keys(), Set)  # Should be ImmutableSet

    assert frozenset(y.values()) == frozenset(x.values())
    assert isinstance(y.values(), Set)  # Should be ImmutableSet

    assert tuple(y.items()) == tuple(x.items())
    assert isinstance(y.items(), Sequence)  # Should be ImmutableTuple


# Generated at 2022-06-11 17:53:53.964684
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _EmptyClass(_ABCSingleton):
        def __init__(self):
            pass

    assert _EmptyClass()
    assert _EmptyClass()

# Generated at 2022-06-11 17:54:04.259043
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.parameters import OptionParser

    option_parser = OptionParser()
    options = option_parser.get_opts()
    options.become = True
    options.become_user = "root"
    args = GlobalCLIArgs.from_options(options)

    # Make sure we got our arguments back out
    assert args["become"] is True
    assert args["become_user"] == "root"

    # Make sure we don't have an option that wasn't in the original
    assert "fail_on_exec" not in args

    # We also want to make sure that args is immutable
    try:
        args["become"] = False
        assert False, "We should not be able to change args"
    except ValueError:
        pass

    # Try to create a second instance and make

# Generated at 2022-06-11 17:54:08.724895
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'foo': 'bar', 'baz': 'qux'})
    assert args == {'foo': 'bar', 'baz': 'qux'}
    assert args['foo'] == 'bar'
    assert isinstance(args, dict)
    assert isinstance(args, ImmutableDict)



# Generated at 2022-06-11 17:54:15.578436
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    To instantiate a CLIArgs object, you need to provide a dict.
    """
    # 1. Instantiate a CLIArgs object
    arg_dict = dict(foo=1, bar=2, baz=3)
    cli_args_obj = CLIArgs(arg_dict)
    # 2. Assert it is an instance of CLIArgs
    assert isinstance(cli_args_obj, CLIArgs)



# Generated at 2022-06-11 17:54:22.982477
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _UnitTestABCSingleton(metaclass=_ABCSingleton):
        pass

    class _UnitTestABCSingleton2(metaclass=_ABCSingleton):
        pass

    assert isinstance(_UnitTestABCSingleton(), _UnitTestABCSingleton)
    assert isinstance(_UnitTestABCSingleton(), _UnitTestABCSingleton2)
    assert isinstance(_UnitTestABCSingleton2(), _UnitTestABCSingleton2)
    assert isinstance(_UnitTestABCSingleton2(), _UnitTestABCSingleton)



# Generated at 2022-06-11 17:54:34.334134
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-11 17:54:35.466558
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object, metaclass=_ABCSingleton):
        pass
    Foo()

# Generated at 2022-06-11 17:54:37.725040
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(TestClass(), TestClass)

# Generated at 2022-06-11 17:54:43.421832
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class FakeOption():
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    GlobalCLIArgs._clear_instance()
    options = FakeOption(
        one=1,
        two=dict(three='three', four=[4, 5, 6]),
        seven=[dict(eight=['a', 'b', 'c', dict(nine=9, ten=10)])],
        eleven=dict(twelve=['a', dict(thirteen=13)]),
        fourteen=[dict(fifteen=dict(sixteen=16, seventeen=17))],
    )
    cli_args = GlobalCLIArgs.from_options(options)

    # ensure first level of options are as expected
    assert set(cli_args.keys()) == set(options.__dict__.keys())

   

# Generated at 2022-06-11 17:54:46.537551
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    obj = GlobalCLIArgs.from_options(None)
    assert isinstance(obj, GlobalCLIArgs)

