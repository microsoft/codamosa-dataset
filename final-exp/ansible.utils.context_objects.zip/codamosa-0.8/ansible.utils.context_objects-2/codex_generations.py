

# Generated at 2022-06-11 17:45:06.571168
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    class GlobalCLIArgs(CLIArgs):
        def __init__(self, mapping):
            super(GlobalCLIArgs, self).__init__(mapping)

    args = {'foo': 'bar', 'baz': [1, 2, 3]}
    a = GlobalCLIArgs(args)
    b = GlobalCLIArgs(args)
    assert a is b

# Generated at 2022-06-11 17:45:18.376166
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test a simple dictionary
    assert CLIArgs({'a': 1, 'b': 'two', 'c': 3}) == ImmutableDict({'a': 1, 'b': 'two', 'c': 3})

    assert CLIArgs({'a': 1, 'b': 'two', 'c': {1, 2, 3}}) == ImmutableDict({'a': 1, 'b': 'two', 'c': frozenset({1, 2, 3})})

    # Test a dictionary with nested dictionaries, lists, sets and strings

# Generated at 2022-06-11 17:45:26.506534
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import os
    import tempfile

    test_args = {'verbosity': 1,
                 'inventory': os.path.join(tempfile.gettempdir(), "ansible_test_inv.txt"),
                 'module_path': os.path.join(os.getcwd(), "lib/ansible/modules/commands"),
                 'forks': 5,
                 'timeout': 10}

    result1 = GlobalCLIArgs.from_options(GlobalCLIArgs(test_args))
    result2 = GlobalCLIArgs.from_options(result1)

    assert result1 == result2
    assert result1 is result2

# Generated at 2022-06-11 17:45:38.811630
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # convert to
    def check_type(a, b, class_type):
        if isinstance(a, class_type) and isinstance(b, class_type):
            return True

    cli_arg = CLIArgs({'a': 1,
                       'b': "b",
                       'c': {'da': 1, 'db': 2},
                       'd': [2, 3],
                       'e': (3, 4),
                       'f': {5, 6},
                       'g': frozenset({7, 8})})
    # check if the cli_arg is immutable
    assert check_type(cli_arg, cli_arg['c'], ImmutableDict)
    assert check_type(cli_arg, cli_arg['d'], tuple)

# Generated at 2022-06-11 17:45:43.492735
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        pass
    assert isinstance(A(), A)
    assert A() is A()

    class B(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(B(), B)
    assert B() is B()

    class C(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(C(), C)
    assert C() is C()

# Generated at 2022-06-11 17:45:52.304481
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli.arguments import option_helpers
    from optparse import Option
    from unittest import TestCase
    from ansible.module_utils.common.text.converters import to_bytes

    class TestCase2(TestCase):
        def setUp(self):
            super(TestCase2, self).setUp()
            self.options = list()
            self.options.append(Option('--test', dest='test', action='store_const',
                                       const=1, default=0))
            self.options.append(Option('--test2', dest='test2', action='store_const',
                                       const=1, default='a'))
            self.options.append(Option('--foo', dest='foo', action='store',
                                       default=u'b\xe9'))

# Generated at 2022-06-11 17:45:54.844111
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    obj0 = GlobalCLIArgs.instance()
    obj1 = GlobalCLIArgs.instance()
    assert obj0 is obj1

# Generated at 2022-06-11 17:46:03.296084
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.module_utils.common.arguments import AnsibleModuleArgumentParser

    def test_args_parser(parser):
        """
        Add arguments to the parser and populate them with defaults to make it easier to figure out how
        CLIArgs and GlobalCLIArgs handle different types of data.
        """
        parser.add_argument('--text', type='str')
        parser.add_argument('--list', type='list')
        parser.add_argument('--list_str', type='list:str')
        parser.add_argument('--list_int', type='list:int', default=['1', '2', '3'])
        parser.add_argument('--list_of_list', type='list:list:str')
        parser.add_argument('--dict', type='dict')

# Generated at 2022-06-11 17:46:10.593065
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    '''Unit test for _ABCSingleton'''
    class TestABCMeta(_ABCSingleton):
        pass

    class TestABCMetaChild(TestABCMeta):
        pass

    class TestSingleton(Singleton):
        pass

    class TestSingletonChild(TestSingleton):
        pass

    class TestBoth(TestSingleton, TestABCMeta):
        pass

    class TestBothChild(TestBoth):
        pass

    try:
        class Invalid(Singleton, ABCMeta):
            pass
    except TypeError:
        pass
    else:
        assert False, 'Invalid class created'

# Generated at 2022-06-11 17:46:12.825750
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Verify that metaclasses are correct"""
    assert isinstance(GlobalCLIArgs, _ABCSingleton)

# Generated at 2022-06-11 17:46:21.479029
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {'foo': 'bar', 'baz': {'quux': 'quuux'}}
    a = CLIArgs(args)
    assert a == ImmutableDict(args)
    assert isinstance(a, ImmutableDict)
    # Test a non-mapping
    assert a[1] == a[2]
    assert a == a
    assert a != {}
    assert hash(a) != hash({})



# Generated at 2022-06-11 17:46:30.779132
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    args = CLIArgs({'a': 1, 'b': '2', 'c': 3.14, 'd': [1, '2', 3.14]})
    assert args == {'a': 1, 'b': '2', 'c': 3.14, 'd': (1, '2', 3.14)}
    assert isinstance(args, ImmutableDict)
    assert isinstance(args['d'], tuple)
    assert isinstance(args['a'], int)
    assert isinstance(args['b'], text_type)
    assert isinstance(args['c'], float)


# Generated at 2022-06-11 17:46:32.617953
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Verify that GlobalCLIArgs constructor doesn't fail
    """
    GlobalCLIArgs.from_options(None)

# Generated at 2022-06-11 17:46:43.103848
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    fake_mapping = {
        'a': 'b',
        'c': [1, 2, {'d': 'e'}],
        'f': {'g': 'h'},
        'i': {'j': {'k': 'l'}},
        'm': frozenset(['n', 'o']),
        'p': {'q': frozenset('r')},
        'v': [1, 2, 'a', {'b': 'c'}, frozenset('d')],
        'w': 'x',
    }
    cli_args = CLIArgs(fake_mapping)

    # test the types
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args['c'], tuple)

# Generated at 2022-06-11 17:46:50.255260
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a':'a_value', 'b':'b_value'}
    cli_args = CLIArgs(test_dict)

    # Test that attributes are set
    assert cli_args.a == 'a_value'
    assert cli_args.b == 'b_value'

    # Test that attributes are immutable
    try:
        cli_args.a = 'new_value'
        assert False
    except AttributeError:
        pass

# Generated at 2022-06-11 17:46:57.275524
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {}
    args['foo'] = 'bar'
    args['list'] = [1, 2, 3, 4, 5]
    args['dict'] = {'a': 'A', 'b': 'B', 'c': 'C'}
    args['tuple'] = ('A', 'B', 'C', 'D', 'E')

    a = CLIArgs(args)

    assert a['foo'] == 'bar'
    assert a['list'] == (1, 2, 3, 4, 5)
    assert a['dict'] == ImmutableDict({'a': 'A', 'b': 'B', 'c': 'C'})
    assert a['tuple'] == ('A', 'B', 'C', 'D', 'E')

# Generated at 2022-06-11 17:46:59.557395
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs.from_options(ImmutableDict({"a": 1, "b": 2})) == {"a": 1, "b": 2}

# Generated at 2022-06-11 17:47:02.207856
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Unit test for constructor of class GlobalCLIArgs
    """
    GlobalCLIArgs({})
    GlobalCLIArgs({'boolean_true': True})
    GlobalCLIArgs({'boolean_false': False})

# Generated at 2022-06-11 17:47:10.201392
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {'verbosity': 5, 'foo': 'bar', 'roles_path': ['/my/roles/path']}
    cli_args = CLIArgs(args)
    assert cli_args.verbosity == 5
    assert cli_args.foo == 'bar'
    assert isinstance(cli_args.roles_path, tuple)
    assert cli_args.roles_path == ('/my/roles/path',)
    assert not isinstance(cli_args.roles_path, list)


# Generated at 2022-06-11 17:47:19.732618
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Unit test for the CLIArgs class constructor

    Confirms that we correctly stash away the arguments that are passed in
    """
    # Use the same args that we would normally get by parsing options
    args = {'foo_bar': [], 'bar_baz': True, 'baz_qux': True, 'bat_bat': False}
    test_args = CLIArgs(args)
    assert test_args['foo_bar'] == []
    assert test_args['bar_baz'] is True
    assert test_args['baz_qux'] is True
    assert test_args['bat_bat'] is False
    # Test that the CLIArgs constructor properly makes the passed data immutable

# Generated at 2022-06-11 17:47:31.715337
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    cli_args = GlobalCLIArgs()

    assert len(cli_args) is 0


# Generated at 2022-06-11 17:47:34.224584
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = {'test': {'test2': {'test3': 1}}}
    assert GlobalCLIArgs(args) == args

# Generated at 2022-06-11 17:47:41.613221
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    d = {'foo': 0, 'bar': 'baz'}
    c = CLIArgs(d)
    assert c['bar'] == 'baz'
    assert c['foo'] == 0
    try:
        c['foo'] = 42
    except TypeError:
        pass
    else:
        raise RuntimeError("Shouldn't be able to assign to an immutable dictionary")


# Generated at 2022-06-11 17:47:47.797803
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import json
    import unittest

    def change_global_cli_args(changes):
        """Mutate global_cli_args"""
        global_cli_args_dict = vars(global_cli_args)
        for key, value in global_cli_args_dict.items():
            if key in changes:
                global_cli_args_dict[key] = changes[key]

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_not_equal_to_other_instance(self):
            self.assertNotEqual(global_cli_args, GlobalCLIArgs())

        def test_immutable(self):
            with self.assertRaises(TypeError):
                GlobalCLIArgs()['foo'] = 'bar'


# Generated at 2022-06-11 17:47:52.131437
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    class Opts:
        foo = 'bar'

    opts = Opts()
    args = GlobalCLIArgs.from_options(opts)
    with pytest.raises(TypeError):
        args['foo'] = 'baz'

# Generated at 2022-06-11 17:47:54.625639
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _Test(_ABCSingleton):
        pass

    t1 = _Test()
    t2 = _Test()

    assert id(t1) == id(t2)

# Generated at 2022-06-11 17:47:57.573889
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        pass
    assert Test() == Test()
    assert Test.__doc__ == 'Combine Singleton and ABCMeta so we have a metaclass that unambiguously knows which can override\nthe other.  Useful for making new types of containers which are also Singletons.'

# Generated at 2022-06-11 17:48:08.144124
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options:
        pass

    op = Options()

    op.option_a = "option_a"
    op.option_b = 2
    op.option_c = 3.14
    op.option_d = {"subkey": "subvalue"}

    op.option_e = (1, 2, 3)
    op.option_f = [1, 2, 3]
    op.option_g = set([1, 2, 3])

    op.option_h = "a_string"


# Generated at 2022-06-11 17:48:10.498287
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Use the isinstance function to ensure that a GlobalCLIArgs object is a CLIArgs object
    assert isinstance(GlobalCLIArgs(), CLIArgs)

# Generated at 2022-06-11 17:48:13.150802
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class C(object):
        __metaclass__ = _ABCSingleton

    c1 = C()
    c2 = C()
    assert c1 is c2



# Generated at 2022-06-11 17:48:17.297707
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Check that there are no exceptions trying to create a GlobalCLIArgs
    _ = GlobalCLIArgs({"hello": "world"})

# Generated at 2022-06-11 17:48:19.968776
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton):
        pass
    a = Foo()
    b = Foo()
    assert a is b, "Two instances of Foo() should be the same"


# Generated at 2022-06-11 17:48:32.088566
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        def __init__(self, x):
            self.x = x

    assert A(1) == A(1)
    assert A(1).x == A(2).x
    assert not (A(1) is A(1))
    assert not (A(1).x is A(2).x)
    assert dir(A(1)) == dir(A(2))

# Generated at 2022-06-11 17:48:33.727175
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    print("CLIArgs initialized")

# Generated at 2022-06-11 17:48:44.443623
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class TestCLIArgs(CLIArgs):
        pass
    t1 = TestCLIArgs({'a': 1, 'b': 2})
    assert (t1['a'] == 1)
    assert (t1['b'] == 2)
    assert (len(t1.keys()) == 2)
    assert (len(t1.values()) == 2)
    assert (1 in t1.values())
    assert (2 in t1.values())
    assert ('a' in t1.keys())
    assert ('b' in t1.keys())
    t2 = TestCLIArgs({'c': 3, 'd': 4})
    assert (t2['c'] == 3)
    assert (t2['d'] == 4)
    assert (len(t2.keys()) == 2)

# Generated at 2022-06-11 17:48:47.842909
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

        pass

    class B(object):
        __metaclass__ = _ABCSingleton

        pass

    assert A() == B()

# Generated at 2022-06-11 17:48:56.889906
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.unsafe_proxy import wrap_var

    test_immutable_dict_args = {
        'test_bool': True,
        'test_str': 'text',
        'test_list': [1, 2, 3, 4],
        'test_set': {1, 2, 3, 4},
        'test_dict': {
            'test_bool': True,
            'test_str': 'text',
            'test_list': [1, 2, 3, 4],
            'test_set': {1, 2, 3, 4},
        },
    }
    test_immutable_dict = CLIArgs(test_immutable_dict_args)
    for key, value in test_immutable_dict.items():
        assert key in test_immutable_dict_args
        assert value == test

# Generated at 2022-06-11 17:48:59.565526
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ABCSingletonTest(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(ABCSingletonTest(), ABCSingletonTest)

# Generated at 2022-06-11 17:49:03.031107
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _Test(object):
        __metaclass__ = _ABCSingleton
    singleton1 = _Test()
    singleton2 = _Test()
    assert singleton1 is singleton2

# Generated at 2022-06-11 17:49:09.771257
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        def __init__(self, values):
            for key, value in values.items():
                setattr(self, key, value)

    args = GlobalCLIArgs.from_options(Options({"verbosity": 3}))
    assert isinstance(args, GlobalCLIArgs)
    assert args[u'verbosity'] == 3

    args = GlobalCLIArgs.from_options(Options({"verbosity": 3}))
    assert args is GlobalCLIArgs()
    assert args[u'verbosity'] == 3

# Generated at 2022-06-11 17:49:18.413446
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_const', const='foo')
    options = parser.parse_args([])
    g_args = GlobalCLIArgs.from_options(options)
    assert g_args['foo'] == 'foo'



# Generated at 2022-06-11 17:49:27.589625
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Only run this test if we're running the tests
    if __name__ != '__main__':
        # Use CLIArgs as a substitute for a command line parser
        parser = CLIArgs(
            {
                '_ansible_verbosity': 4,
                '_ansible_version': '2.8.3',
                '_ansible_version_info': [2, 8, 3, 'final', 0],
                '_ansible_no_log': False,
                '_ansible_debug': False,
                '_ansible_diff': False,
                '_ansible_selinux_special_fs': [],
                '_ansible_base_directory': 'test_dir',
                '_ansible_module_name': 'test_module',
            }
        )

        # Ensure that we get back an immutable

# Generated at 2022-06-11 17:49:30.706053
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({'a': 'hello', 'b': 1, 'c': 'world', 'd': 2})
    GlobalCLIArgs({'a': 1, 'c': 2, 'e': 3})

# Generated at 2022-06-11 17:49:35.182655
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    # Check that there is only instance of each class
    assert A() is A()
    assert B() is B()
    # Check that they are not the same instance
    assert A() is not B()


# Generated at 2022-06-11 17:49:37.805434
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton(_ABCSingleton): pass

    first = TestSingleton()
    second = TestSingleton()
    assert first == second

# Generated at 2022-06-11 17:49:47.358050
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import argparse as ap
    parser = ap.ArgumentParser(prog=sys.argv[0], description='Test')
    parser.add_argument('--param1', type=int, default=1)
    parser.add_argument('--param2', type=str, default='test',
                        choices=['test', 'test2'])
    args = parser.parse_args()
    assert isinstance(args, ap.Namespace)
    assert args.param1 == 1
    assert args.param2 == 'test'
    args = CLIArgs.from_options(args)
    assert isinstance(args, CLIArgs)
    assert isinstance(args, ImmutableDict)
    assert args.param1 == 1
    assert args.param2 == 'test'

# Generated at 2022-06-11 17:49:52.356513
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(B):
        pass
    class D(B):
        pass
    class E(D):
        pass
    A()
    B()
    C()
    D()
    E()

# Generated at 2022-06-11 17:50:01.970883
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs constructor makes a valid CLIArgs instance.
    """
    import textwrap
    import tempfile
    from ansible.config.manager import ConfigManager

    with tempfile.NamedTemporaryFile() as config_file:
        config_file.write(textwrap.dedent("""
        [defaults]
        fact_caching = memory
        fact_caching_period = 1
        """))
        config_file.flush()
        options = ConfigManager.load_config_file(config_file.name)
        cli_args = CLIArgs.from_options(options)

# Generated at 2022-06-11 17:50:08.556514
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        pass

    options = Options()
    options.foo = 'bar'

    args = CLIArgs.from_options(options)
    assert args == {'foo': 'bar'}, 'Results of CLIArgs.from_options should match command line args'

    args = GlobalCLIArgs.from_options(options)
    assert args == {'foo': 'bar'}, 'Results of GlobalCLIArgs.from_options should match command line args'

# Generated at 2022-06-11 17:50:19.876662
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options:
        pass
    options = Options()
    options.args = ['hello']

    options.foo = 'bar'

    options.baz = ['a', 'b', 'c']
    options.a = {'d': 1, 'e': 'f', 'g': ['a', 'b', 'c']}
    options.b = {'c': 1, 'd': 'f', 'e': ['a', 'b', 'c']}
    options.c = ['a', 'b', 'c']
    options.d = ['a', ['b', 'c']]
    options.e = ['a', ['b', 'c'], 'd']

    args = GlobalCLIArgs.from_options(options)

    assert args.args == ['hello']
    assert args.foo == 'bar'

# Generated at 2022-06-11 17:50:30.360500
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABCSingletonTest(object):
        __metaclass__ = _ABCSingleton

    obj = _ABCSingletonTest()

__all__ = ["CLIArgs", "GlobalCLIArgs"]

# Generated at 2022-06-11 17:50:40.402825
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.dict_transformations import _dict_union
    class Options(object):
        pass
    options = Options()
    options.become = None
    options.become_method = "sudo"
    options.become_user = None
    options.connection = "paramiko"
    options.remote_user = "blackbeard"
    options.remote_tmp = None
    options.private_key_file = None

    cli_args = CLIArgs(vars(options))

# Generated at 2022-06-11 17:50:40.930278
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    pass

# Generated at 2022-06-11 17:50:43.173387
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    cli = GlobalCLIArgs({'foo': 'bar'})
    assert cli.get('foo') == 'bar'

# Generated at 2022-06-11 17:50:45.698634
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABCSingleton_Test(metaclass=_ABCSingleton):
        pass

    t = _ABCSingleton_Test()

# Generated at 2022-06-11 17:50:48.527288
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    obj = GlobalCLIArgs.from_options({})
    assert isinstance(obj, GlobalCLIArgs)
    assert isinstance(obj, ImmutableDict)
    assert obj == {}

# Generated at 2022-06-11 17:50:51.507564
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli.arguments import AnsibleCLIArguments
    args = AnsibleCLIArguments()

    GlobalCLIArgs.set(CLIArgs.from_options(args))
    assert 'version' in GlobalCLIArgs

# Generated at 2022-06-11 17:51:03.041232
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable, is_immutable_mapping, is_immutable_sequence, \
        is_immutable_set
    from collections import Mapping, Sequence, Set

    class Dummy(Mapping):
        def __init__(self):
            pass

        def __getitem__(self, item):
            return ""

        def __iter__(self):
            return iter([])

        def __len__(self):
            return 0

    class Dummy2(Dummy, Sequence):
        def __getitem__(self, item):
            if isinstance(item, slice):
                return [0, 1, 2]
            else:
                return 1


# Generated at 2022-06-11 17:51:05.515863
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_args = GlobalCLIArgs.get_instance({'foo': 'bar'})
    assert global_args['foo'] == 'bar'

# Generated at 2022-06-11 17:51:11.317768
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Create the object, then try to create the same object again and make sure it is the same object.
    :return: None
    """
    class TestSingleton(object, metaclass=_ABCSingleton):
        pass

    test1 = TestSingleton()
    test2 = TestSingleton()

    assert test1 is test2

# Generated at 2022-06-11 17:51:38.156610
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {
        'a': 'a',
        'b': (1, 2, 3),
        'c': ['a', 'b', 'c'],
        'd': {
            'd1': 'a',
            'd2': ['a', 'b', 'c'],
            'd3': {
                'd31': 'a',
                'd32': ['a', 'b', 'c'],
            }
        },
    }
    test_object = CLIArgs(test_dict)
    test_object_tuple = CLIArgs.from_options(test_dict)
    assert test_object == test_object_tuple
    assert test_dict == test_object
    assert test_dict == test_object_tuple

# Generated at 2022-06-11 17:51:47.961771
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test switching out an object for an ImmutableDict

    This test is only executed if the module CLIArgs
    gets executed as a program, as described in the
    pydoc example.
    """
    # Get command line arguments
    import sys
    if sys.argv[0].find('ansible_test/unit/utils/args.py') != -1:
        # Command line arguments are in sys.argv[1] and after
        args = sys.argv[1:]
    else:
        # Module is being called from somewhere else
        args = sys.argv[:]
        args.insert(0, __file__)

    # Make an options object
    from optparse import OptionParser, Values
    parser = OptionParser()
    parser.add_option('-m', action="append", dest="module_paths")

# Generated at 2022-06-11 17:52:00.018191
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class MyOptions(object):
        def __init__(self, argtable):
            self.argtable = argtable

    # test simple argument case
    my_opts = MyOptions({'foo': 'bar'})
    cmdline = GlobalCLIArgs.from_options(my_opts)
    assert cmdline.get('foo') == 'bar'

    # test list of strings
    my_opts = MyOptions({'foo': ['bar', 'baz']})
    cmdline = GlobalCLIArgs.from_options(my_opts)
    assert cmdline.get('foo') == ('bar', 'baz')

    # test list of dicts
    my_opts = MyOptions({'foo': [{'bar': 'baz'}]})

# Generated at 2022-06-11 17:52:03.981717
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    d = {'a':'a', 'b':'b', 'c':'c'}
    o = CLIArgs.from_options(d)
    for k,v in d.items():
        assert k in o
        assert o[k] == v


# Generated at 2022-06-11 17:52:10.829218
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--int_arg', type=int)
    parser.add_argument('--str_arg', type=str)
    parser.add_argument('--list_arg', type=str, nargs='*')
    args = parser.parse_args([])
    globals()['BECOME_ARGS'] = GlobalCLIArgs.from_options(args)

# Generated at 2022-06-11 17:52:13.109182
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    cli_args = GlobalCLIArgs('foo', 'bar')
    assert cli_args == 'foo', 'Value not stored correctly in GlobalCLIArgs'

# Generated at 2022-06-11 17:52:19.621810
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Unit test for constructor of class _ABCSingleton

    Really, we're just testing for the side-effect of the exception swallowing
    """
    class A(object):
        __metaclass__ = _ABCSingleton
    try:
        A()
    except TypeError:
        pass
    try:
        A()
    except TypeError:
        assert False
    except:
        assert False

# Generated at 2022-06-11 17:52:26.034097
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {}
    mapping['one'] = 1
    mapping['two'] = 2
    mapping['three'] = 3
    args = CLIArgs(mapping)
    assert len(args) == 3
    # Map objects can be iterated over
    for key in args:
        assert isinstance(key, (text_type, binary_type))
    assert args['one'] == 1
    assert args['two'] == 2
    assert args['three'] == 3


# Generated at 2022-06-11 17:52:35.242421
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import discover_plugins
    from ansible.utils.display import Display

    # initialize some plugin paths and things
    discover_plugins()
    Display().verbosity = 0
    loader = DataLoader()

    cli_args = CLIArgs(dict(connection='ssh', forks=3, verbosity=3, deprecated=['ssh', 'module_name']))
    assert isinstance(cli_args, Container)
    assert cli_args.get('connection') == 'ssh'
    assert cli_args.get('verbosity') == 3
    assert cli_args.get('deprecated') == ('ssh', 'module_name')

    cli_args = CLIArgs(dict(connection='ssh', forks=3, verbosity=3))
    cl

# Generated at 2022-06-11 17:52:38.531417
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(metaclass=_ABCSingleton):
        pass

    assert(A() == A())
    assert(B() == B())
    assert(A() != B())



# Generated at 2022-06-11 17:53:21.018954
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    test_input = dict(a=1, b=2, c=3)
    result = CLIArgs(test_input)

    assert result == test_input
    assert isinstance(result, ImmutableDict)

    test_input = dict(a=1, b=dict(c=2, d=3), e=dict(f=4, g=dict(h=5, i=dict(j=6))))
    result = CLIArgs(test_input)

    assert result == test_input
    assert isinstance(result, ImmutableDict)
    assert isinstance(result['b'], ImmutableDict)
    assert isinstance(result['e'], ImmutableDict)
    assert isinstance(result['e']['g'], ImmutableDict)

# Generated at 2022-06-11 17:53:27.908429
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _GlobalArgsSingleton(object):
        pass

    new_class = _ABCSingleton('_GlobalArgsSingleton', (_GlobalArgsSingleton,), {})
    assert new_class.__name__ == '_GlobalArgsSingleton'
    assert new_class.__bases__ == (_GlobalArgsSingleton,)
    assert new_class.__module__ == 'ansible.module_utils.common.collections.__init__'

# Generated at 2022-06-11 17:53:38.664597
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test the constructor of class CLIArgs
    """
    import pytest
    ISOLATED_ARGS = dict(a=None, b=1, c=2, d=0)  # Cmd line args are always strings.

    args = CLIArgs(ISOLATED_ARGS)

    for key in ISOLATED_ARGS:
        assert key in args
        assert args[key] == ISOLATED_ARGS[key]
        with pytest.raises(KeyError):
            # KeyError exceptions are raised when a dict lookup fails:
            # http://docs.python.org/2/tutorial/datastructures.html#dictionaries
            args[key + '_not_in_dict']

    # Test that the keys can't be changed.

# Generated at 2022-06-11 17:53:44.546946
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({})
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, Mapping)
    assert isinstance(args, Container)
    assert isinstance(args, CLIArgs)
    assert not isinstance(args, GlobalCLIArgs)
    assert not isinstance(args, Set)
    assert not isinstance(args, Sequence)
    assert not isinstance(args, Singleton)
    assert not isinstance(args, ABCMeta)


# Generated at 2022-06-11 17:53:53.221961
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import json

    import ansible.cli.galaxy
    import ansible.parsing.mod_args

    # For CLIArgs we want to make sure that what gets made is a frozen set / dict / tuple
    # but for GlobalCLIArgs we want to ensure that only one of them is ever made and what
    # is made is a frozen set / dict / tuple.  Test both that only one object is made, and
    # that it is a frozendict.

    # Test that only one object is ever made
    first_object = GlobalCLIArgs(dict())
    second_object = GlobalCLIArgs(dict())
    if first_object is not second_object:
        sys.exit("Failed to create a unique instance of the GlobalCLIArgs class")

    # Test that it is a frozendict.
    ans

# Generated at 2022-06-11 17:54:00.627622
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Ensure that Singleton and ABCMeta are working together.

    ABCMeta is responsible for implementing __new__, which sets the dictionary in the instance of
    a class and has a somewhat complicated process of doing so.  If Singleton had a simpler
    __new__, this might not be needed but since it also sets io_loop, lock and instance_id, we
    need to make sure they don't get in each other's way.

    This is a bit hacky since we don't want to actually implement a Singleton based on ABCMeta and
    it is hard to test the combination without making one.  So we hack in a Singleton based on
    ABCMeta, call its __new__ method, verify it set a dictionary on the instance, and then destroy
    the Singleton
    """

# Generated at 2022-06-11 17:54:02.575891
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class options(object):
        """Fake options class for test"""
        def __init__(self, mapping):
            for key, value in mapping.items():
                setattr(self, key, value)
    args = {'foo': [], 'bar': 'baz', 'bing': [1, 2, 3]}
    assert GlobalCLIArgs.from_options(options(args)) == args

# Generated at 2022-06-11 17:54:07.243855
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class s(metaclass=_ABCSingleton):
        pass

    assert isinstance(s(), s)

    class s2(s):
        pass

    assert isinstance(s2(), s2)

    class s3(s2):
        pass

    assert isinstance(s3(), s3)
    assert isinstance(s3(), s2)
    assert isinstance(s3(), s)

# Generated at 2022-06-11 17:54:12.628489
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Unit test for constructor of class _ABCSingleton"""
    class Foo(_ABCSingleton):
        """
        class Foo.
        """
        pass

    class Bar(_ABCSingleton):
        """
        class Bar.
        """
        pass

    assert isinstance(Foo(), Foo)
    assert not isinstance(Bar(), Foo)

# Generated at 2022-06-11 17:54:17.999920
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton):
        pass

    class Bar(_ABCSingleton):
        pass

    assert isinstance(Foo.__instance, Foo)
    assert isinstance(Bar.__instance, Bar)
    assert Foo.__instance is not Bar.__instance

if __name__ == '__main__':
    test__ABCSingleton()