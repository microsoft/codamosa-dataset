

# Generated at 2022-06-11 17:45:10.124602
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class FakeModuleUtilsOptions:
        def __init__(self):
            self.connection = 'ssh'
            self.remote_user = 'ubuntu'
            self.inventory = ['localhost']
            self.module_path = ['/lib/ansible/modules']
            self.become = False
            self.become_method = 'sudo'
            self.become_user = 'root'
            self.check = True
            self.diff = False

    fake_options = FakeModuleUtilsOptions()
    options = GlobalCLIArgs.from_options(fake_options)
    # Assert that keys are present in the dict
    assert options['connection']
    assert options['remote_user']
    assert options['inventory']
    assert options['module_path']
    assert options['become']

# Generated at 2022-06-11 17:45:15.114279
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = type('options', (), {'private_data_dir': 'a'})()
    cli_args = GlobalCLIArgs.from_options(options)
    assert isinstance(cli_args, GlobalCLIArgs)
    assert cli_args.get('private_data_dir') == 'a'

# Generated at 2022-06-11 17:45:19.021515
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyMeta(type):
        pass
    class MySingleton(MyMeta):
        __metaclass__ = _ABCSingleton
    assert issubclass(MySingleton, Singleton)
    assert issubclass(MySingleton, ABCMeta)

# Generated at 2022-06-11 17:45:30.545826
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Basic smoke tests to make sure the CLIArgs getter returns an immutable dictionary and that
    it properly converts all mutable objects to a read-only equivalent.
    """
    test_dict = {"foo": "bar", "nested": {"a": 1, "b": 2}, "list": [1, 2, 3], "tuple": (1, 2, 3), "set": {1, 2, 3}}
    test_cli_args = CLIArgs(test_dict)
    assert test_cli_args == test_dict

    assert not isinstance(test_cli_args, dict)
    assert isinstance(test_cli_args, ImmutableDict)
    assert isinstance(test_cli_args["nested"], ImmutableDict)
    assert isinstance(test_cli_args["tuple"], tuple)

# Generated at 2022-06-11 17:45:41.463924
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Testing that the constructor accepts an empty dict
    cli_args = CLIArgs({})
    assert cli_args == {}

    # Testing that the constructor accepts mutable dicts and copies them to an
    # immutable dict
    cli_args = CLIArgs({'foo': 'bar'})
    assert cli_args == {'foo': 'bar'}
    assert isinstance(cli_args, ImmutableDict)

    # Testing that the constructor accepts immutable dicts and returns them
    # without making a copy
    cli_args_copy = ImmutableDict({'foo': 'bar'})
    cli_args = CLIArgs(cli_args_copy)
    assert cli_args is cli_args_copy
    assert isinstance(cli_args, ImmutableDict)

    # Testing that the constructor will make a deep copy

# Generated at 2022-06-11 17:45:42.131046
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    pass

# Generated at 2022-06-11 17:45:47.842157
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # This test should run as standalone using nosetest command.
    # nosetests --cover-erase --with-coverage --cover-package=ansible --cover-html ansible/module_utils/common/collections.py:test_GlobalCLIArgs
    args = {'bar': 'foo', 'baz': 'fiz'}
    obj = GlobalCLIArgs(args)
    expected = ImmutableDict(args)
    assert obj == expected

# Generated at 2022-06-11 17:45:49.324451
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = GlobalCLIArgs({'test': 1})

# Generated at 2022-06-11 17:45:53.513587
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_options = ImmutableDict({'test_key': 'test_value'})
    test_args = GlobalCLIArgs.from_options(test_options)

    assert test_args['test_key'] == 'test_value'

# Generated at 2022-06-11 17:45:59.529202
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    # This module has no command line args
    import ansible.module_utils.basic  # noqa

    assert GlobalCLIArgs is not None
    assert GlobalCLIArgs._init is True
    assert sys.getrefcount(GlobalCLIArgs) == 3

    # Make sure other things are available
    GlobalCLIArgs()
    assert GlobalCLIArgs.get() is not None



# Generated at 2022-06-11 17:46:05.239779
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    This is a test case GlobalCLIArgs.
    """
    # no error
    GlobalCLIArgs(vars({'ask_pass': 'False'}))

# Generated at 2022-06-11 17:46:08.671936
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    import types
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A is B
    assert isinstance(A, types.ClassType)

# Generated at 2022-06-11 17:46:21.167457
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Tests for GlobalCLIArgs class"""
    globals_ = {}

# Generated at 2022-06-11 17:46:25.488232
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    given_dict = {'a': 1, 'b': 2}
    cli_args = CLIArgs(given_dict)
    assert cli_args == given_dict
    assert cli_args.a == 1
    assert cli_args.b == 2

# Generated at 2022-06-11 17:46:29.201791
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    c = CLIArgs({'a': 'b'})
    assert isinstance(c, ImmutableDict)
    assert c == ImmutableDict({'a': 'b'})
    c2 = CLIArgs({'a': {'b': {'c': 'd'}}})
    assert c2 == ImmutableDict({'a': ImmutableDict({'b': ImmutableDict({'c': 'd'})})})

# Generated at 2022-06-11 17:46:39.598733
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    import contextlib
    @add_metaclass(_ABCSingleton)
    class TestABCMetaSingleton(object):
        pass

    class TestSingleton(Singleton):
        pass

    @add_metaclass(_ABCSingleton)
    class TestSingletonABCMeta(TestSingleton):
        pass

    @add_metaclass(_ABCSingleton)
    class TestABCMetaSingletonABCMeta(TestABCMetaSingleton):
        pass

    with contextlib.suppress(TypeError):
        class TestABCMetaSingletonNonMeta(TestABCMetaSingleton):
            pass

    with contextlib.suppress(TypeError):
        class TestSingletonNonMeta(TestSingleton):
            pass

    with contextlib.suppress(TypeError):
        class TestSingletonABCMetaNonMeta(TestSingletonABCMeta):
            pass



# Generated at 2022-06-11 17:46:50.950248
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class MyOptions(object):
        a = 0
        b = 1
        c = 2
        d = 3
        e = 4
        f = 5

    my_options = MyOptions()
    my_options.a = [{'foo': 'bar'}]
    my_options.b = [set([1,2,3])]
    my_options.c = ['str1', 'str2']
    my_options.d = ['str1', {'foo': 'bar'}]
    my_options.e = ['str1', set([1,2,3])]
    my_options.f = ['str1', [{'foo': 'bar'}]]
    args = CLIArgs.from_options(my_options)

    assert isinstance(args, CLIArgs)

# Generated at 2022-06-11 17:46:57.941699
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    obj = CLIArgs({'a': ['b', 'c', {'x': 'y'}]})
    assert obj.a[2].x == 'y'
    obj = CLIArgs({'a': {'b': 'c', 'd': {'e': 'f'}}})
    assert obj.a.d.e == 'f'
    obj = CLIArgs({'a': [1, 2, 3, 4]})
    assert obj.a[2] == 3
    obj = CLIArgs({'a': (1, 2, 3, 4)})
    assert obj.a[2] == 3
    obj = CLIArgs({'a': ({'b': 'c', 'd': 'e'}, 'f', [1, 2, 3])})
    assert obj.a[0].b == 'c'
    assert obj.a

# Generated at 2022-06-11 17:47:02.050377
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = dict(a='a', b=dict(c='c'))
    immutable = CLIArgs(mapping)
    assert immutable['a'] == 'a'
    assert immutable['b']['c'] == 'c'
    assert isinstance(immutable['b'], ImmutableDict)
    assert immutable['b'] == dict(c='c')

# Generated at 2022-06-11 17:47:06.861196
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    options = type('obj', (object,), {'debug': 'true', 'help': 'this is a test'})
    test_args = CLIArgs.from_options(options)
    assert test_args['debug'] == 'true'
    assert test_args['help'] == 'this is a test'



# Generated at 2022-06-11 17:47:15.444895
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Make sure we can't be tricked into creating a metaclass which is
    ambiguous about which to use first

    This is the one failing test which causes the other two to fail
    """
    try:
        class Ambiguous(Singleton, ABCMeta):
            pass
    except TypeError:
        # Good, it failed
        pass
    else:
        assert False, 'Class ' + Ambiguous.__name__ + ' should not have been allowed'



# Generated at 2022-06-11 17:47:18.822868
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert GlobalCLIArgs() is GlobalCLIArgs()
    assert CLIArgs({'foo': 'bar'}) != GlobalCLIArgs()
    assert GlobalCLIArgs().get('foo') == GlobalCLIArgs()['foo']
    assert GlobalCLIArgs()['foo'] is None

# Generated at 2022-06-11 17:47:22.387815
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    expected_args = {'host': 'localhost', 'verbose': 5}
    args = GlobalCLIArgs.from_options(expected_args)
    assert args == expected_args

# Generated at 2022-06-11 17:47:25.163097
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs({'one': 1, 'two': 2})
    assert cli_args['one'] == 1


# Generated at 2022-06-11 17:47:30.337089
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    args = {
        "ARG1": "VALUE1",
        "ARG2": "VALUE2",
        "ARG3": "VALUE3",
    }

    cli_args = CLIArgs(args)

    assert cli_args["ARG1"] == "VALUE1"
    assert cli_args["ARG2"] == "VALUE2"
    assert cli_args["ARG3"] == "VALUE3"


# Generated at 2022-06-11 17:47:42.743016
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    options = Options(connection='local', inventory=['/path/to/inventory'], skip_tags=['foo'], extra_vars={})
    cli_args = GlobalCLIArgs.from_options(options)

    assert isinstance(cli_args, GlobalCLIArgs)
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args, Container)
    assert isinstance(cli_args, Mapping)
    assert isinstance(cli_args, Sequence)
    assert not isinstance(cli_args, Set)

    for key, value in vars(options).items():
        assert key in cli_args

# Generated at 2022-06-11 17:47:50.520868
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABCSingletonTest(object):
        __metaclass__ = _ABCSingleton
    assert _ABCSingletonTest()
    try:
        class _ABCSingletonTest2(object):
            __metaclass__ = _ABCSingleton
            def __new__(cls, *args, **kwargs):
                if not hasattr(cls, '_instance'):
                    cls._instance = super(_ABCSingletonTest2, cls).__new__(cls)
                return cls._instance
    except Exception as e:
        raise AssertionError('Should be possible to define a singleton using the _ABCSingleton metaclass') from e
    assert _ABCSingletonTest2()
    assert _ABCSingletonTest2() is _ABCSingletonTest2()
    class Test(object):
        __metaclass

# Generated at 2022-06-11 17:47:54.003726
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton): # pylint: disable=abstract-class-instantiated
        pass
    class B(A):
        pass

    assert A() is A()
    assert B() is B()

# Generated at 2022-06-11 17:48:02.773818
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        """
        Empty class for testing
        """
        __metaclass__ = _ABCSingleton

    class TestClass2(object):
        """
        Empty class for testing
        """
        __metaclass__ = _ABCSingleton

    # class TestClass3(object):
    TestClass3 = type('TestClass3', (object,), {'__metaclass__': _ABCSingleton})

    tc = TestClass()
    assert isinstance(tc, TestClass)
    assert isinstance(tc, Singleton)
    tc2 = TestClass()
    assert tc is tc2

    tc3 = TestClass2()
    assert isinstance(tc3, TestClass2)
    assert isinstance(tc3, Singleton)
    tc4 = TestClass2()
    assert tc3 is tc4


# Generated at 2022-06-11 17:48:08.976792
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli = CLIArgs({'a': 'b', 'c': ['d', 'e'], 'f': {'i': 'j', 'k': ['l', 'm']}})
    assert isinstance(cli, dict)
    assert cli['a'] == 'b'
    assert cli['c'] == ('d', 'e')
    assert cli['f'] == ImmutableDict({'i': 'j', 'k': ('l', 'm')})

# Generated at 2022-06-11 17:48:15.725393
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert GlobalCLIArgs({})



# Generated at 2022-06-11 17:48:17.722491
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    assert not A
    assert not B

# Generated at 2022-06-11 17:48:25.437407
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({
        "vars": ["var1=value1", "var2=value2"],
        "verbosity": 100,
        "list": False,
        "syntax_check": False,
        "check": False,
        "inventory": "./hosts",
        "inventory_sources": ["ec2.yml", "rackspace.yml"]
    })
    assert args
    assert args.get("vars")
    assert args.get("verbosity")


# Generated at 2022-06-11 17:48:30.231700
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = {}
    args['bool_opt'] = True
    args['int_opt'] = 42
    args['float_opt'] = 3.1415
    args['str_opt'] = 'foo'
    args['list_opt'] = ['foo', 'bar', 'baz']
    args['dict_opt'] = {'foo': 'bar', 'bar': 'baz'}

    GlobalCLIArgs(args)
    pass

# Generated at 2022-06-11 17:48:33.288468
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    a = TestClass()
    b = TestClass()

    assert a is b

# Generated at 2022-06-11 17:48:44.119298
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common._collections_compat import Mapping, Sequence

    mapping = {'str': 'string', 'tuple': ('tuple',), 'dict': {'dict': 'dict'}, 'list': ['list']}
    cli_args = CLIArgs(mapping)
    assert isinstance(cli_args, Mapping)
    assert isinstance(cli_args['dict'], Mapping)
    assert isinstance(cli_args['list'], Sequence)
    assert isinstance(cli_args['tuple'], Sequence)
    assert cli_args['dict']['dict'] == 'dict'
    assert cli_args['list'] == ['list']
    assert cli_args['str'] == 'string'
    assert cli_args['tuple'] == ('tuple',)

# Generated at 2022-06-11 17:48:51.079341
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = CLIArgs({"a": 1, "b": "two", "c": [1, 2, 3], "d": {"e": 1, "f": [1, 2, 3]}})
    b = GlobalCLIArgs({"a": 1, "b": "two", "c": [1, 2, 3], "d": {"e": 1, "f": [1, 2, 3]}})
    assert a == b

# Generated at 2022-06-11 17:49:01.740968
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Prepare test data
    mapping = {
        "a": 1,
        "b": "value_b",
        "c": {
            "d": [1, 2, 3],
            "e": {
                "f": "value_f",
                "g": {
                    "h": "value_h"
                }
            }
        }
    }

    # Test constructor of class CLIArgs
    args = CLIArgs(mapping)
    assert args["a"] == 1
    assert args["b"] == "value_b"
    assert args["c"]["d"] == (1, 2, 3)
    assert args["c"]["e"]["f"] == "value_f"
    assert args["c"]["e"]["g"]["h"] == "value_h"

# Generated at 2022-06-11 17:49:11.622335
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Create a dict and make sure it is made immutable
    a = {'a': [1, 2, 3]}
    args = CLIArgs(a)
    assert isinstance(a, dict)
    assert not isinstance(a, ImmutableDict)
    assert isinstance(args, ImmutableDict)

    # Make sure nested dicts are made immutable
    a = {'a': [1, 2, 3], 'b': {'c': [1, 2, 3]}}
    args = CLIArgs(a)
    assert isinstance(a, dict)
    assert not isinstance(a, ImmutableDict)
    for key in args:
        if key == 'a':
            continue
        assert isinstance(args[key], ImmutableDict)

# Generated at 2022-06-11 17:49:16.625854
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Ensure that CLIArgs does not allow for value changes
    """
    cli_args = CLIArgs.from_options(object)

    # Ensure that we can't change the items in cli_args
    cli_args['new_item'] = 'hello'
    cli_args['new_item'] = 'bye'

    assert 'new_item' in cli_args



# Generated at 2022-06-11 17:49:26.308704
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    pass

# Generated at 2022-06-11 17:49:28.159867
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = GlobalCLIArgs({'a': None})
    assert a == {'a': None}

# Generated at 2022-06-11 17:49:37.154479
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from os import path
    from argparse import Action, ArgumentParser, Namespace
    from ansible.constants import get_config, load_config_file

    class _DummyAction(Action):
        def __call__(self, parser, namespace, values, option_string=None):
            setattr(namespace, self.dest, values)

    # We do this because we want tests to use a temporary working directory instead of cwd
    cwd = None
    try:
        cwd = get_config(None, 'DEFAULT', 'roles_path')
        config_file = path.join(cwd, 'ansible.cfg')
        load_config_file(config_file)
    except:
        cwd = path.abspath('.')

# Generated at 2022-06-11 17:49:37.905152
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs()

# Generated at 2022-06-11 17:49:43.955360
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.cli.options import Options
    import os
    loader = DataLoader()
    cli_args = Options(loader=loader)
    cli_args.help = True
    cli_args.connection = 'local'
    cli_args.forks = 3
    cli_args.module_path = os.getcwd()
    cli_args.extra_vars = ['a=1', 'b=2']
    cli_args.tags = ['tag1', 'tag2']
    cli_args.skip_tags = ['skip_tag1', 'skip_tag2']
    cli_args.check = True
    args = CLIArgs.from_options(cli_args)
    assert args['help']

# Unit

# Generated at 2022-06-11 17:49:51.399210
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Unit test for the GlobalCLIArgs class.

    This test is only executed when module is called by itself.

    :return None:
    """
    from ansible.module_utils.common._collections_compat import namedtuple
    from ansible.module_utils.common.collections import ImmutableDict
    import pytest

    Options = namedtuple('Options', ['debug', 'verbosity', 'extra_vars', 'tags', 'skip_tags', 'check'])
    options = Options(
        debug=True,
        verbosity=2,
        extra_vars=dict(key='val'),
        tags=['t1', 't2'],
        skip_tags=['st1', 'st2'],
        check=True,
    )


# Generated at 2022-06-11 17:49:58.347514
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class X:
        __metaclass__ = _ABCSingleton

    class Y(X):
        pass

    # The following two lines should be the same object.
    # If they are different objects then some code in this file
    # is broken and should be fixed.
    assert X() is X()
    # This next line should also be the same object as the previous.
    # If it is a different object then the code in this file is broken.
    assert X() is Y()

# Generated at 2022-06-11 17:50:10.812859
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli import CLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    options = CLI.base_parser(
        usage='usage',
        output_opts=True,
        runas_opts=True,
        async_opts=True,
        connect_opts=True,
        subset_opts=True,
        check_opts=True,
        diff_opts=False,
        vault_opts=True,
        fork_opts=True,
    ).parse_args()

    variable_manager = VariableManager()
    loader = DataLoader()
    cliargs = GlobalCLIArgs.from_options(options)
    assert cliargs['ask_vault_pass'] is False

# Generated at 2022-06-11 17:50:17.096415
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import pytest
    args = CLIArgs({'a': {'1': 'x', '2': 'y'}, 'b': 'c'})
    assert args['a']['1'] == 'x'
    assert args['a']['2'] == 'y'
    assert args['b'] == 'c'
    with pytest.raises(TypeError):
        args['b'] = 'b'

# Generated at 2022-06-11 17:50:20.532868
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs.from_options(MutableGlobalCLIArgs)
    assert len(args) == 4
    assert args['verbosity'] == 3
    assert args['force_handlers'] is True
    assert args['module_path'] == '/fake/foo/bar'



# Generated at 2022-06-11 17:50:40.235271
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs()

# Generated at 2022-06-11 17:50:47.766989
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class FakeOptions(object):
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    options = FakeOptions(connection='ssh', forks=5, module_path=['/some/path'])
    args = CLIArgs.from_options(options)
    assert isinstance(args['connection'], text_type)
    assert isinstance(args['forks'], int)
    assert isinstance(args['module_path'], Sequence)

# Generated at 2022-06-11 17:50:53.281501
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Test GlobalCLIArgs() constructor"""
    # Make sure we correctly wrap the MutableMapping passed in
    # to the constructor.
    orig_parsed = {'key': 'value'}
    parsed = GlobalCLIArgs(orig_parsed)
    assert parsed == {'key': 'value'}
    assert 'key' in parsed
    assert parsed['key'] == 'value'
    assert parsed.get('key') == 'value'
    assert parsed.get('keys') is None


# Generated at 2022-06-11 17:51:04.262489
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that two different CLIArgs can exist and contain values
    CLI_args = CLIArgs({"a": 1, "b": 2})
    assert isinstance(CLI_args, Mapping)
    assert CLI_args["a"] == 1
    assert CLI_args["b"] == 2

    CLI_args2 = CLIArgs({"a": 3, "b": 4, "c": 5})
    assert isinstance(CLI_args2, Mapping)
    assert CLI_args2["a"] == 3
    assert CLI_args2["b"] == 4
    assert CLI_args2["c"] == 5

    # Test that CLIArgs cannot be changed once initialized
    try:
        CLI_args["a"] = 2
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-11 17:51:08.805029
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args1 = GlobalCLIArgs(dict(a=1, b=2, c=3))
    args2 = GlobalCLIArgs(dict(d=1, e=2, f=3))
    assert args1 is args2

# Generated at 2022-06-11 17:51:16.344373
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options():
        def __init__(self):
            self.a = ['a', 'b', 'c']
            self.b = ['d', 'e', 'f']
            self.c = {'A': 'a', 'B': 'b', 'C': 'c'}
            self.d = {'D': 'd', 'E': 'e', 'F': 'f'}

    options = Options()
    cli_args = CLIArgs.from_options(options)

    assert isinstance(cli_args['a'], tuple)
    assert isinstance(cli_args['b'], tuple)
    assert cli_args['a'] == ('a', 'b', 'c')
    assert cli_args['b'] == ('d', 'e', 'f')

# Generated at 2022-06-11 17:51:19.140583
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class test_options():
        def __init__(self):
            self.foo = None
            self.bar = None
    test_opts = test_options()
    test_opts.foo = "foo"
    test_opts.bar = "bar"

    args = CLIArgs.from_options(test_opts)

    assert args['foo'] == "foo"
    assert args['bar'] == "bar"

# Generated at 2022-06-11 17:51:22.705574
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({'foo': 'bar'})
    assert hash(args) == hash(GlobalCLIArgs({'foo': 'bar'}))
    assert args == GlobalCLIArgs({'foo': 'bar'})
    assert args != GlobalCLIArgs({'foo': 'baz'})

# Generated at 2022-06-11 17:51:23.601632
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({})

# Generated at 2022-06-11 17:51:30.039120
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    result = CLIArgs({'a': {'b': ['c', 'd', 'e'], 'f': None}, 'x': ['y', 'z']})
    assert result['a']['b'] is not ['c', 'd', 'e']
    assert result['a']['b'] == ('c', 'd', 'e')
    assert result['a']['f'] is None
    assert result['x'] is not ['y', 'z']
    assert result['x'] == ('y', 'z')

# Generated at 2022-06-11 17:52:11.316931
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():  # pragma: no cover
    class test(object):
        __metaclass__ = _ABCSingleton

    assert issubclass(test, object)

# Generated at 2022-06-11 17:52:16.167116
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    onex = TestClass()
    try:
        onex_again = TestClass()
    except Exception:
        # This is what we expect to have happen
        pass
    else:
        raise AssertionError("We shouldn't have been able to create a second instance of "
                             "the TestClass which has a _ABCSingleton metaclass applied to it")

# Generated at 2022-06-11 17:52:23.446652
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {'foo': 'bar', 'poop': 'doodle', 'galaxy_foo': ['path/to/galaxy1'], 'debug': False, 'connection': 'ssh'}
    c = CLIArgs(args)
    assert c['foo'] == 'bar'
    assert c['poop'] == 'doodle'
    assert c['galaxy_foo'] == ('path/to/galaxy1',)
    assert c['debug'] is False
    assert c['connection'] == 'ssh'



# Generated at 2022-06-11 17:52:26.179486
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {'a': '1', 'b': '2'}
    cli = CLIArgs(args)
    assert not isinstance(cli, dict)
    assert isinstance(cli, CLIArgs)
    pass

# Generated at 2022-06-11 17:52:35.236146
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Unit test for CLIArgs to make sure it converts to immutable
    """
    args_dict = {
        'b': [2, 3],
        'c': {
            'd': (1, 2, 3),
            'e': {
                'f': 6
            },
        },
        'g': [4, 5, 6, 7],
        'h': 'j',
    }

    args_from_constructor = CLIArgs(args_dict)

    assert isinstance(args_from_constructor, CLIArgs)
    assert isinstance(args_from_constructor, ImmutableDict)
    assert not isinstance(args_from_constructor, Mapping)

    assert isinstance(args_from_constructor['c'], ImmutableDict)

# Generated at 2022-06-11 17:52:36.725493
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # sanity test for singleton instantiation
    GlobalCLIArgs.instance()

# Generated at 2022-06-11 17:52:40.824960
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABCSingletonClass(_ABCSingleton):
        def __new__(cls):
            return super(TestABCSingletonClass, cls).__new__(cls)
    instance1 = TestABCSingletonClass.instance()
    instance2 = TestABCSingletonClass.instance()
    assert instance1 is instance2

# Generated at 2022-06-11 17:52:45.370399
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object, metaclass=_ABCSingleton):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(_ABCSingleton, object):
        pass

# Generated at 2022-06-11 17:52:46.836690
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test the constructor of class GlobalCLIArgs
    """
    GlobalCLIArgs()
    GlobalCLIArgs()

# Generated at 2022-06-11 17:52:56.246276
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {
        'key_0': 'value_0',
        'key_1': 'value_1',
        'key_2': {
            'key_2.1': 'value_2.1',
            'key_2.2': {
                'key_2.2.1': 'value_2.2.1',
            },
            'key_2.3': ['value_2.3.0', 'value_2.3.1'],
        },
        'key_3': ['value_3.0', {'key_3.1': 'value_3.1'}],
    }

    obj = CLIArgs(mapping)

    assert obj['key_0'] == 'value_0'
    assert obj['key_1'] == 'value_1'

# Generated at 2022-06-11 17:54:20.796599
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(A):
        pass

    class C(A):
        pass

    assert isinstance(A(), A)
    assert isinstance(A(), B)
    assert isinstance(A(), C)
    assert A() is B()
    assert A() is C()
    assert B() is C()

# Generated at 2022-06-11 17:54:32.189739
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from copy import deepcopy
    from collections import OrderedDict

    class MyClass(object):
        pass

    myobj = MyClass()
    myobj.attribute = OrderedDict()
    myobj.attribute['level1'] = OrderedDict()
    myobj.attribute['level1']['level2'] = 'level3'
    myobj.attribute['level1']['intlevel'] = 1

    mydict = OrderedDict()
    mydict['level1'] = OrderedDict()
    mydict['level1']['level2'] = 'level3'
    mydict['level1']['intlevel'] = 1

    # test data

# Generated at 2022-06-11 17:54:40.284979
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleOptionsError
    from ansible.cli import CLI
    loader = DataLoader()
    cli = CLI(args=['-vv', '-m' 'raw', '-a', 'uname', '-i', 'localhost,', '-e', 'ansible_python_interpreter=/bin/python'], loader=loader)
    opt = cli.parse()
    cliargs = CLIArgs.from_options(opt)
    original = vars(opt)
    new_obj = _make_immutable(original)
    assert cliargs['verbosity'] == new_obj['verbosity']
    assert cliargs['host_key_checking'] == new_obj['host_key_checking']

# Generated at 2022-06-11 17:54:44.819748
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        def __init__(self, value):
            self.value = value

    a = Test(5)
    assert a.value == 5
    b = Test(6)
    assert b.value == 5
    c = Test(5)
    assert a is c

# Generated at 2022-06-11 17:54:48.761297
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        """
        Test for unit for class _ABCSingleton
        """

        def __init__(self):
            pass

    a1 = A()
    a2 = A()
    assert a1 == a2

# Generated at 2022-06-11 17:54:51.121903
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object, metaclass=_ABCSingleton):
        pass

    assert TestClass() == TestClass()

# Generated at 2022-06-11 17:54:57.890603
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.text.converters import to_bytes

    class option:
        def __init__(self, arg):
            self.arg = arg

    class options:
        def _update_careful(self, other):
            options._updated_options[other.arg] = other.arg

        def __init__(self):
            self.connection = option("connection")
            self.become = option("become")
            self.check = option("check")
            self.remove_tmp_path = option("remove_tmp_path")
            self.diff = option("diff")
            self.flush_cache = option("flush_cache")

    options._updated_options = GlobalCLIArgs({})
    args = GlobalCLIArgs.from_options(options())