

# Generated at 2022-06-11 17:45:11.288061
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.unsafe_proxy import UnsafeProxy
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.cli import CLI

    # Create a fake options object
    options = UnsafeProxy(cli.CLI.base_parser.parse_args(['-vvv']))

    # Convert the object to an immutable version
    args = GlobalCLIArgs(options)

    # Make sure we are what we are supposed to be
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, GlobalCLIArgs)

# Generated at 2022-06-11 17:45:16.364875
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import pytest

    with pytest.raises(AttributeError):
        # Not allowed to create a new one on your own
        CLIArgs({"key": "value"})

    with pytest.raises(TypeError):
        # Must be a Mapping
        CLIArgs.from_options([])



# Generated at 2022-06-11 17:45:17.949638
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert GlobalCLIArgs({}) == GlobalCLIArgs({})

# Generated at 2022-06-11 17:45:21.519756
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {'foo': 'bar'}
    cli_args = CLIArgs(args)
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args == args
    args['foo'] = 'baz'
    assert cli_args['foo'] == 'bar'



# Generated at 2022-06-11 17:45:23.699370
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton(_ABCSingleton):
        pass

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-11 17:45:36.005505
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class options:
        check_mode = 'fake_check_mode'
        connection = ['connection']
        diff = 'diff'
        force_handlers = ['force_handlers']
        limit = 'limit'
        listhosts = 'listhosts'
        module_path = ['module_path']
        playbook = 'playbook.yml'
        private_key = 'private_key'
        timeout = 'timeout'
        vault_password = 'vault_password'
        verbosity = ['verbosity']
        version = 'version'
        start_at_task = 'start_at_task'
    gca = GlobalCLIArgs.from_options(options)
    assert gca['check_mode'] == 'fake_check_mode'
    assert gca['connection'] == ('connection',)

# Generated at 2022-06-11 17:45:40.439429
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Just make sure that the _ABCSingleton exists and doesn't throw any error
    class SingletonABC(object):
        __metaclass__ = _ABCSingleton

    class SingletonABC2(object):
        __metaclass__ = _ABCSingleton

    assert SingletonABC is SingletonABC2

# Generated at 2022-06-11 17:45:46.552991
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Make a GlobalCLIArgs object to test
    cli_args = GlobalCLIArgs({'verbosity': 3})

    # Make sure the object is a Singleton
    assert cli_args is GlobalCLIArgs({})

    # Make sure the object is an ImmutableDict
    assert isinstance(cli_args, ImmutableDict)

    # Make sure the object is a CLIArgs
    assert isinstance(cli_args, CLIArgs)



# Generated at 2022-06-11 17:45:50.002466
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    m = {'key': 'value', 'other_key': [1, 2, 3]}
    cli = CLIArgs(m)
    assert cli == m
    assert is_immutable(cli)

# Generated at 2022-06-11 17:45:52.394795
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(type(_ABCSingleton(str, (object,), {})), _ABCSingleton)



# Generated at 2022-06-11 17:46:00.356535
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton):
        pass

    class Bar(_ABCSingleton):
        pass

    foo1 = Foo()
    foo2 = Foo()
    bar1 = Bar()
    bar2 = Bar()

    assert foo1 is foo2
    assert bar1 is bar2
    assert foo1 is not bar1

# Generated at 2022-06-11 17:46:05.240109
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    try:
        GlobalCLIArgs()
    except TypeError:
        # Expected error as this constructor should never be called
        pass


# Create a singleton
GlobalCLIArgs()

# Generated at 2022-06-11 17:46:07.398849
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({'a':1, 'b':2, 'c':['a', 'b', {'d': 1}]})

# Generated at 2022-06-11 17:46:12.613309
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton, object):
        pass

    def bar():
        class Baz(_ABCSingleton, object):
            pass

    # We need to do this test in a function to prevent Python from setting the class of Baz
    # to <class '__main__.test__ABCSingleton.<locals>.Baz'>.
    # See PEP 3155 for details.
    Bar = bar()

    assert Foo == Foo
    assert Bar == Bar
    assert Foo != Bar
    assert type(Foo) != type(Bar)

# Generated at 2022-06-11 17:46:23.122046
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # map of arguments
    simple_dict = {
        'foo': 'bar',
        'bar': 'baz',
        'baz': {
            'bar': 'foo'
        },
        'list': [
            'foo',
            'bar'
        ]
    }

    # create a CLIArgs instance from the map
    cli_args = CLIArgs(simple_dict)
    # cli_args should be immutable, so attempt to change it causes an exception
    with pytest.raises(TypeError):
        cli_args['foo'] = "baz"

    # check if the map was properly stored and converted to immutable
    assert simple_dict['foo'] == cli_args['foo']
    assert isinstance(cli_args['baz'], ImmutableDict)

# Generated at 2022-06-11 17:46:31.699465
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from collections import Mapping, Sequence, Set

    def verify_impossible_to_modify(mapping):
        try:
            mapping['foo'] = 'bar'
            assert False
        except TypeError:
            pass

    test_mapping = {'foo': {'bar': {'baz': 'baz_value'}}}
    test_set = {'foo', 'bar', 'baz'}
    test_set |= {'bar'}
    test_sequence = [{'foo': 'bar'}, 'baz', {'bob': 'bob_value'}, 'bart']
    test_sequence.append({'bob': 'bob_value'})
    test_string = "Hello, World!"

# Generated at 2022-06-11 17:46:34.482706
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs({'optimistic_parameters': False})
    assert isinstance(global_cli_args['optimistic_parameters'], bool)


# Generated at 2022-06-11 17:46:45.318524
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    optmapping = {
        "foo": "bar",
        "baz": "bang",
    }
    optinstance = GlobalCLIArgs.from_options(object())
    assert optinstance == {}
    assert optinstance != optmapping
    optinstance = GlobalCLIArgs.from_options(object(**optmapping))
    assert optinstance == optmapping
    optinstance['baz'] = 'boom'
    assert optinstance != optmapping
    assert optinstance['baz'] == 'boom'
    assert optinstance.get('baz') == 'boom'
    assert optinstance.get('baz') == optinstance['baz']
    optinstance['baz'] = 'bang'
    assert optinstance['baz'] == 'bang'

# Generated at 2022-06-11 17:46:49.443436
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    with GlobalCLIArgs.lock:
        if not GlobalCLIArgs.instance:
            GlobalCLIArgs.instance = GlobalCLIArgs({'test': 'test'})
    assert GlobalCLIArgs.instance == {'test': 'test'}

# Generated at 2022-06-11 17:46:53.782757
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    parser = None
    options = None
    args = GlobalCLIArgs(vars(options))
    assert args == ImmutableDict()

    # Try with a parser
    parser = None
    options, args = parser.parse_args()
    args1 = GlobalCLIArgs.from_options(options)
    assert args1 == ImmutableDict()

# Generated at 2022-06-11 17:47:01.408200
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import types

    # Make sure we are immutable
    cli_args = GlobalCLIArgs({u'foo': [u'bar', u'baz']})
    with pytest.raises(AttributeError):
        cli_args.foo = 123

    # Make sure we are a Singleton
    assert GlobalCLIArgs.instance() is GlobalCLIArgs.instance()
    assert not GlobalCLIArgs.instance() is CLIArgs.instance()

# Generated at 2022-06-11 17:47:07.936901
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {
        'one': 'host',
        'two': {
            'three': 'host',
            'four': 'host',
        },
    }
    test_dict['self_ref'] = test_dict
    args = CLIArgs(test_dict)

    assert isinstance(args, ImmutableDict)
    assert isinstance(args['two'], ImmutableDict)
    assert args['self_ref'] is args

# Generated at 2022-06-11 17:47:12.336796
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Unit test to make sure immutable dict works like we want it to
    GlobalCLIArgs.get(mapping={'key': 'value'})
    args = GlobalCLIArgs()
    assert args['key'] == 'value'
    try:
        args['key'] = 'new value'
    except TypeError:
        pass

# Generated at 2022-06-11 17:47:15.012640
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    f1 = Foo()
    f2 = Foo()
    assert f1 is f2

# Generated at 2022-06-11 17:47:20.834730
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A:
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert isinstance(A(), Singleton)
    assert isinstance(B(), Singleton)
    assert isinstance(C(), Singleton)
    assert isinstance(A(), ABCMeta)
    assert isinstance(B(), ABCMeta)
    assert isinstance(C(), ABCMeta)
    assert isinstance(A(), A)
    assert isinstance(B(), A)
    assert isinstance(C(), A)

# Generated at 2022-06-11 17:47:31.716349
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class NewMeta(object):
        __metaclass__ = _ABCSingleton

    class NewClass(object):
        pass

    class SubClassOfNewMeta(NewMeta):
        pass

    class SubNewMeta(object):
        __metaclass__ = SubClassOfNewMeta

    class SubClassOfSubNewMeta(SubNewMeta):
        pass

    class SubClassOfABC(object):
        __metaclass__ = ABCMeta

    assert issubclass(SubClassOfNewMeta, NewMeta)
    assert issubclass(SubClassOfNewMeta, ABCMeta)
    assert issubclass(SubClassOfNewMeta, Singleton)
    assert issubclass(SubClassOfSubNewMeta, SubNewMeta)
    assert issubclass(SubClassOfSubNewMeta, SubClassOfNewMeta)

# Generated at 2022-06-11 17:47:43.317975
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import collections
    import pytest

    mapping = {'key1': 1, 'key2': 2, 'key3': [1, 2, 3, 4]}
    gca = GlobalCLIArgs(mapping)
    assert isinstance(gca, collections.Mapping)
    assert isinstance(gca.__class__, _ABCSingleton)
    assert gca.get('key1') == 1
    assert gca.get('key2') == 2
    assert gca.get('key3')[0] == 1
    with pytest.raises(TypeError):
        gca['key1'] = 3
    with pytest.raises(TypeError):
        del gca['key1']

# Generated at 2022-06-11 17:47:50.671346
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.plugins.loader import find_plugin

    from ansible.cli import CLI
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-11 17:47:55.927224
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # To keep coverage happy, we need to call the constructor of _ABCSingleton at least once.
    class TestMetaClass(_ABCSingleton):
        pass

    class TestAbstractMethod(metaclass=TestMetaClass):
        @classmethod
        def foo(cls):
            pass

    # Make sure that our method is abstract
    try:
        TestAbstractMethod()
    except TypeError:
        pass

# Generated at 2022-06-11 17:48:02.678366
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.config.manager import ConfigManager
    from ansible.config.loader import ConfigLoader

    commandline_options = ConfigManager.load_cli_options()
    config_file_options = ConfigManager.load_config_file_options()

    actual_config_options = config_file_options.merge(commandline_options)
    config_loader = ConfigLoader()
    final_config_options = config_loader.resolve(actual_config_options)

    GlobalCLIArgs.from_options(final_config_options)

# Generated at 2022-06-11 17:48:10.120029
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cliargs = CLIArgs({"a": "b",
                       "c": {"d": "e",
                             "f": ["g", "h", {"i": "j",
                                              "k": {"l": "m"}}]}})
    assert cliargs == {"a": "b",
                       "c": {"d": "e",
                             "f": ("g", "h", {"i": "j",
                                              "k": {"l": "m"}})}}

# Generated at 2022-06-11 17:48:19.967885
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs.from_options(
        ImmutableDict(
            {
                "bool_opt": True,
                "choice_opt": "A",
                "int_opt": 7,
                "list_opt": ["_A", "_B"]
            }
        )
    )
    assert isinstance(cli_args, CLIArgs)
    assert isinstance(cli_args, Mapping)
    assert isinstance(cli_args["bool_opt"], bool)
    assert isinstance(cli_args["choice_opt"], text_type)
    assert isinstance(cli_args["int_opt"], int)
    assert isinstance(cli_args["list_opt"], tuple)
    assert isinstance(cli_args["list_opt"][0], text_type)

# Generated at 2022-06-11 17:48:32.089800
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common._collections_compat import MutableSequence, MutableMapping

    if not isinstance(GlobalCLIArgs.instance, GlobalCLIArgs):
        raise ValueError("GlobalCLIArgs.instance should always be a GlobalCLIArgs instance")

    GlobalCLIArgs.instance = GlobalCLIArgs({'a': 2, 'b': 3})
    args = GlobalCLIArgs.instance

    if args['a'] != 2:
        raise ValueError("'a' should be 2")
    if args['b'] != 3:
        raise ValueError("'b' should be 3")

    try:
        args['c']
        raise ValueError("GlobalCLIArgs should be immutable")
    except KeyError:
        pass


# Generated at 2022-06-11 17:48:42.233555
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    ansible_options = type('Options', (object,), {'verbosity': 0})()
    # Create an instance of GlobalCLIArgs
    cli_args = GlobalCLIArgs.from_options(ansible_options)

    # Test a generic key in the dictionary
    assert cli_args['verbosity'] == 0

    # Test the dictionary is immutable
    try:
        cli_args['verbosity'] = 1
        assert False
    except TypeError:
        assert True

    # Test that the object is a Singleton
    try:
        GlobalCLIArgs.from_options(ansible_options)
        assert False
    except AssertionError:
        assert True

# Generated at 2022-06-11 17:48:50.063659
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({'a': ['a'], 'b': 'b', 'c': {'x': 'x', 'y': 'y', 'z': ['a', 'b', 'c']}})
    assert args['a'] == ('a',)
    assert args['b'] == 'b'
    assert args['c']['x'] == 'x'
    assert args['c']['y'] == 'y'
    assert args['c']['z'] == ('a', 'b', 'c')

# Generated at 2022-06-11 17:48:57.672086
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABCSingletonTestBase(object):
        pass

    class _ABCSingletonTest(_ABCSingletonTestBase, metaclass=_ABCSingleton):
        def __init__(self, value=None):
            self._value = value

        @classmethod
        def whoami(cls):
            return "I am a {}".format(cls.__name__)

    assert _ABCSingletonTest()._value is None
    assert _ABCSingletonTest(1)._value == 1
    assert _ABCSingletonTest(1)._value == _ABCSingletonTest(2)._value == 1

    class _ABCSingletonTestSubclass(_ABCSingletonTest):
        def __init__(self, value=None):
            _ABCSingletonTest.__init__(self, 101)

    assert _ABCSingletonTestSubclass

# Generated at 2022-06-11 17:49:03.572661
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABC(object):
        """A class to test _ABCSingleton"""
        __metaclass__ = _ABCSingleton

        def __init__(self):
            """constructor of class TestABC"""
            self.x = 1

    test_instance1 = TestABC()
    test_instance2 = TestABC()

    assert test_instance1 is test_instance2

# Generated at 2022-06-11 17:49:08.217514
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _TestClass(object):
        __metaclass__ = _ABCSingleton

    try:
        _TestClass()
        assert False, "instantiated singleton"
    except TypeError:
        pass

    inst = _TestClass.get_instance()
    assert type(inst) is _TestClass, "singleton failed"

# Generated at 2022-06-11 17:49:10.756614
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    x = CLIArgs({"a": 1, "b": "foo"})
    assert x.get("a") == 1, 'a'
    assert x.get("b") == "foo", 'b'


# Generated at 2022-06-11 17:49:15.137420
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--test', default='test')
    sys.argv = ['test', '--test', '1']
    options = parser.parse_args()
    options = vars(options)
    args = GlobalCLIArgs.from_options(options)
    args['test'] = '2'
    assert args['test'] == '1', 'GlobalCLIArgs should be immutable'

# Generated at 2022-06-11 17:49:27.245311
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import types
    import time

    def fake_parser(self):
        return

    def fake_main(self):
        return

    def fake_parse_args(self):
        return []

    def fake_get_pid(self):
        return 9999

    def fake_write_pid(self):
        return

    def fake_sleep(self):
        return

    def fake_unlink(self):
        return

    # Add attributes to GlobalCLIArgs, Globally
    if sys.version_info[0] < 3:
        GlobalCLIArgs.add_to_sys = types.FunctionType(add_to_sys, globals())
    else:
        GlobalCLIArgs.add_to_sys = add_to_sys

    #Create a fake parser object
    fake_parser = types.ModuleType

# Generated at 2022-06-11 17:49:36.526054
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # a map
    test_dict = {"key1" : "value1", "key2" : ["value21", "value22"], "key3" : {"key31" : "value31", "key32" : ["value321", "value322"]}, "key4": ("value41", "value42")}
    # a set
    test_set = set()
    test_set.add("value1")
    test_set.add("value2")
    # a list
    test_list = ["test1", "test2", "test3"]
    # an object
    test_obj = object()

    test_dict["list1"] = test_list
    test_dict["set1"] = test_set
    test_dict["obj1"] = test_obj
    new_cli_args = CLIArgs(test_dict)


# Generated at 2022-06-11 17:49:40.579556
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    with assertRaises(TypeError) as context:
        class B(A):
            pass
    assert "A with a different metaclass cannot be derived from A" in str(context.exception)

# Generated at 2022-06-11 17:49:43.215948
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    arg_dict = dict(a='a', b='b', c=dict(a='a', b='b'))
    cli_args = CLIArgs(arg_dict)
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args['c'], ImmutableDict)

# Generated at 2022-06-11 17:49:51.059184
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils._text import to_text
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.connection import ConnectionBase
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import fragment_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import terminal_loader
    from ansible.plugins.loader import test_loader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import Loader

    import sys

    # Reset the connection loader, which should have no connections in it at this point,


# Generated at 2022-06-11 17:49:56.578440
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestA(object):
        __metaclass__ = _ABCSingleton
        def __init__(self, value):
            self.value = value

    class TestB(TestA):
        def __init__(self, value):
            self.value = value

    ta = TestA(1)
    tb = TestB(2)

    assert ta is tb

# Generated at 2022-06-11 17:50:00.509091
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = {'module_path': ('/path/to/usr', '/path/to/usr/local')}
    import types
    global_cli_args = GlobalCLIArgs.from_options(types.SimpleNamespace(**args))
    assert global_cli_args
    assert global_cli_args == args

# Generated at 2022-06-11 17:50:12.774928
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    class B(A):
        pass
    class C(B, metaclass=_ABCSingleton):
        pass
    class D(C):
        pass
    class E(D, metaclass=_ABCSingleton):
        pass
    class F(E):
        pass
    class G(F):
        pass
    class H(G):
        pass
    class I(H):
        pass
    class J(I):
        pass
    class K(J):
        pass
    class L(K):
        pass
    class M(L):
        pass
    class N(M):
        pass
    class O(N):
        pass
    class P(O):
        pass
    class Q(P):
        pass

# Generated at 2022-06-11 17:50:18.718469
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import collections

    a = GlobalCLIArgs.from_options(collections.namedtuple('test', 'foo bar')(1, 2))

    assert a['foo'] == 1
    assert a['bar'] == 2

    assert a is a.foo

    assert a.foo is a.foo

    assert a is GlobalCLIArgs(collections.namedtuple('test', 'foo bar')(1, 2))

# Generated at 2022-06-11 17:50:21.011231
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs({'test_key': 'test_value'})
    assert cli_args['test_key'] == 'test_value'



# Generated at 2022-06-11 17:50:34.354169
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton(_ABCSingleton):
        def __init__(self, value):
            self.value = value

    # Verify that initialization is done only once
    test_set = TestSingleton(1)
    assert test_set.value == 1

    test_set2 = TestSingleton(2)
    assert test_set2.value == 1  # Should be equal to test_set.value != 2

    # Verify that the ABCMeta class checks work
    class TestAbstractClass(_ABCSingleton):
        __metaclass__ = ABCMeta
        @abstractmethod
        def test_method(self):
            pass

    class TestConcreteClass(TestAbstractClass):
        def test_method(self):
            pass

    # This should not throw an exception
    test_concrete_abstract_class = TestConcreteClass()

# Generated at 2022-06-11 17:50:36.989058
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {"one": 1, "two": 2}
    args = CLIArgs(mapping)
    assert args == mapping


# Generated at 2022-06-11 17:50:42.980775
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cliargs = CLIArgs(dict(foo=dict(bar=dict(xyzzy=frozenset([1, 2, 3])))))
    assert isinstance(cliargs, ImmutableDict)
    assert isinstance(cliargs['foo'], ImmutableDict)
    assert isinstance(cliargs['foo']['bar'], ImmutableDict)
    assert cliargs['foo']['bar']['xyzzy'] == frozenset([1, 2, 3])

# Generated at 2022-06-11 17:50:48.995474
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = object()
    with GlobalCLIArgs.lock:
        args = GlobalCLIArgs._instance = None
        args = GlobalCLIArgs.from_options(options)
    assert args is GlobalCLIArgs._instance
    assert GlobalCLIArgs is GlobalCLIArgs.__class__
    assert isinstance(args, dict)
    assert isinstance(args, GlobalCLIArgs)
    assert args is not options

# Generated at 2022-06-11 17:50:59.818475
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 'b', 'c': 1, 'd': [1, 2], 'e': {'f': 'g'}}
    test_args = CLIArgs(test_dict)
    assert isinstance(test_args['a'], text_type)
    assert isinstance(test_args['c'], int)
    assert isinstance(test_args['d'], tuple)
    assert isinstance(test_args['e'], ImmutableDict)
    assert test_args['a'] == 'b'
    assert test_args['c'] == 1
    assert test_args['d'] == (1, 2)
    assert test_args['e'] == {'f': 'g'}
    assert test_args == test_dict


# Generated at 2022-06-11 17:51:04.108409
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys

    old_argv = sys.argv[:]
    try:
        sys.argv = ['ansible-test', '--test']
        args = GlobalCLIArgs.from_options(None)
        assert args['test'] == True
    finally:
        sys.argv = old_argv

# Generated at 2022-06-11 17:51:15.535951
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import collections
    import operator
    import unittest.mock as mock

    from ansible.module_utils.common.collections import (
        ImmutableDict,
        is_sequence,
    )

    class TestOptions(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        def __eq__(self, other):
            return self.__dict__ is other.__dict__

        def __ne__(self, other):
            return not self.__eq__(other)

        def __hash__(self):
            return hash(self.__dict__)

    def get_non_mutable_object(value):
        if isinstance(value, collections.Mapping):
            return ImmutableDict(value)

# Generated at 2022-06-11 17:51:17.751632
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(A):
        pass
    b = B()
    assert A.instance is b

# Generated at 2022-06-11 17:51:21.312335
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    input_data = {
        'foo': text_type('bar'),
        'bar': binary_type('foo')
    }

    obj = GlobalCLIArgs(input_data)

    assert obj == input_data



# Generated at 2022-06-11 17:51:26.150685
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # pylint: disable=unused-variable,undefined-variable,no-member
    class Test(object):
        __metaclass__ = _ABCSingleton
    try:
        # this should NOT raise an exception
        Test()
        # this should raise an exception because there should only be one instance of Test
        Test()
    except RuntimeError:
        pass

# Generated at 2022-06-11 17:51:44.795827
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Unit test for CLIArgs constructor.
    """
    # test empty dict
    cliargs = CLIArgs({})
    result = cliargs.copy()
    assert (result == {})

    # test ImmutableDict
    temp_dict = {'a': 1, 'b': 2, 'c': 3}
    cliargs = CLIArgs(temp_dict)
    assert (isinstance(cliargs, ImmutableDict))

    # test text_type, binary_type and Sequence
    cliargs = CLIArgs({'a': [text_type('a')], 'b': binary_type(b'b'), 'c': [text_type('c'), binary_type(b'd')]})
    result = cliargs.copy()

# Generated at 2022-06-11 17:51:47.347327
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    for key in ['action', 'connection', 'become', 'become_user', 'become_method',
                'check', 'diff']:
        assert key in CLIArgs.from_options(object())

# Generated at 2022-06-11 17:51:55.086787
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object, metaclass=_ABCSingleton):
        pass
    class B(A, metaclass=_ABCSingleton):
        pass
    class C(B):
        pass
    assert issubclass(A, A)
    assert issubclass(A, B)
    assert issubclass(B, A)
    assert issubclass(A, C)
    assert issubclass(B, C)

# Generated at 2022-06-11 17:51:59.767918
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({"a": 1, "b": [0, 1, 2], "c": {"k1": "v1", "k2": [0, 1, 2]}})
    assert args["a"] == 1
    assert args["b"][1] == 1
    assert args.get("c")["k2"][0] == 0



# Generated at 2022-06-11 17:52:11.085279
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import datetime
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils.display import Display
    from ansible.utils.object_finder import find_needle

    # Make a mutable version of the global cli args to use as a test

# Generated at 2022-06-11 17:52:18.687162
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import datetime
    from ansible.utils.unsafe_proxy import wrap_var

    mapping = {'valid': 'test', 'nested': {'test': ['value', 3, datetime.date(2015, 11, 5), wrap_var({'should_be': 'ok'})]}}
    result = GlobalCLIArgs(mapping)
    assert result['valid'] == 'test'
    assert result['nested']['test'][0] == 'value'
    assert result['nested']['test'][1] == 3
    assert result['nested']['test'][2] == datetime.date(2015, 11, 5)
    assert result['nested']['test'][3]['should_be'] == 'ok'
    assert isinstance(result, ImmutableDict)

# Generated at 2022-06-11 17:52:21.913291
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Example(_ABCSingleton):
        pass

    class OtherExample(_ABCSingleton):
        pass

    assert Example() is Example()
    assert OtherExample() is OtherExample()
    assert Example() is not OtherExample()

# Generated at 2022-06-11 17:52:24.127800
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    @add_metaclass(_ABCSingleton)
    class Foo(object):
        pass

    _ = Foo()

# Generated at 2022-06-11 17:52:30.381049
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from copy import copy, deepcopy
    from collections import OrderedDict

    GlobalCLIArgs(ImmutableDict(dict()))
    GlobalCLIArgs(ImmutableDict(dict(a=1)))
    GlobalCLIArgs(ImmutableDict(dict(a=1, b=2)))
    GlobalCLIArgs(ImmutableDict(dict(a=1, b=2, c=3)))

    GlobalCLIArgs(ImmutableDict(OrderedDict()))
    GlobalCLIArgs(ImmutableDict(OrderedDict(a=1)))
    GlobalCLIArgs(ImmutableDict(OrderedDict(a=1, b=2)))
    GlobalCLIArgs(ImmutableDict(OrderedDict(a=1, b=2, c=3)))

    test = GlobalCLIArgs

# Generated at 2022-06-11 17:52:36.064933
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    d = {'test': {'this': 'that', 'another': [{'thing': 'test'}, 'test']}}
    a = CLIArgs(d)
    assert a['test']['this'] == 'that'
    assert a['test']['another'][0]['thing'] == 'test'
    assert a['test']['another'][1] == 'test'

# Generated at 2022-06-11 17:53:02.763716
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        def __init__(self, name):
            self.name = name

    class B(A):
        pass

    a = A('A')
    b = B('B')
    assert a == b

# Generated at 2022-06-11 17:53:04.129910
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # nothing to assert, just verify that it exists
    _ABCSingleton()

# Generated at 2022-06-11 17:53:15.557703
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from collections import Mapping
    class _BadOptions(Mapping):
        def __init__(self):
            self._data= dict(ansible_become_password='foo')

        def __getitem__(self, key):
            return self._data[key]

        def __iter__(self):
            return iter(self._data)

        def __len__(self):
            return len(self._data)

    class _BadMapping(Mapping):
        def __init__(self):
            self._data = dict(keys=['a', ['b']])

        def __getitem__(self, key):
            return self._data[key]

        def __iter__(self):
            return iter(self._data)

        def __len__(self):
            return len(self._data)

    # Unit

# Generated at 2022-06-11 17:53:19.142019
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Make sure that the constructor is overriden and won't
    allow more than one instance once called
    """
    try:
        args = GlobalCLIArgs({})
    except TypeError:
        pass
    else:
        raise AssertionError("Constructor of class GlobalCLIArgs has not been overridden")

# Generated at 2022-06-11 17:53:21.131052
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        pass
    t1 = Test()
    t2 = Test()

# Generated at 2022-06-11 17:53:30.815992
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    "Ensure that new instances of _ABCSingleton can't be made"
    # pylint: disable=too-few-public-methods
    class Foo(_ABCSingleton):
        def __init__(self):
            # pylint: disable=super-init-not-called
            pass
    class Bar(_ABCSingleton):
        def __init__(self):
            # pylint: disable=super-init-not-called
            pass
    assert issubclass(Bar, Foo)
    assert issubclass(Bar, _ABCSingleton)
    # The next line raises an Exception:
    # TypeError: Can't instantiate abstract class Bar with abstract methods __init__
    # This is because _ABCSingleton is using ABCMeta and Singleton which are both metaclasses
    # But ABCMeta and Singleton are both metaclasses

# Generated at 2022-06-11 17:53:32.993653
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    cli_args = GlobalCLIArgs({"a": "b"})
    assert cli_args.get("a") is not None

# Generated at 2022-06-11 17:53:41.763133
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object):

        def __init__(self, value):
            self.value = value

        def __repr__(self):
            return "<Test({})>".format(self.value)

    class SingletonTest(_ABCSingleton, Test):

        def __init__(self, value='abc'):
            super(SingletonTest, self).__init__(value)

    t1 = SingletonTest()
    t2 = SingletonTest()
    assert t1 is t2
    assert t1.value == t2.value



# Generated at 2022-06-11 17:53:48.619171
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Test the CLIArgs constructor to ensure it recursively converts containers to immutable types"""
    # Test python3 dictionary, a Mapping
    source = {'foo': {'bar': {'baz': [1, 2, 3, 4]}}}
    cli_args = CLIArgs(source)
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args['foo'], ImmutableDict)
    assert isinstance(cli_args['foo']['bar'], ImmutableDict)
    assert isinstance(cli_args['foo']['bar']['baz'], tuple)
    assert cli_args['foo']['bar']['baz'] == (1, 2, 3, 4)
    # Test list, a Sequence

# Generated at 2022-06-11 17:53:56.353116
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'key1': {'key2': ['value1', 'value2']}, 'key3': 'value3'})
    assert isinstance(args, ImmutableDict)
    assert isinstance(args['key1'], ImmutableDict)
    assert isinstance(args['key1']['key2'], tuple)
    assert args['key1']['key2'][0] == 'value1'
    assert args['key1']['key2'][1] == 'value2'
    assert args['key3'] == 'value3'


# Generated at 2022-06-11 17:54:33.483343
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):  # pylint: disable=no-init,unused-variable
        pass
    class B(A):  # pylint: disable=no-init,unused-variable
        pass
    class C(A):  # pylint: disable=no-init,unused-variable
        pass



# Generated at 2022-06-11 17:54:41.079762
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    arguments = \
        [{'host_key_checking': False, 'verbosity': 1, 'color': False},
         {'host_key_checking': False, 'verbosity': 1, 'color': True},
         {'host_key_checking': False, 'verbosity': 0, 'color': False},
         {'host_key_checking': False, 'verbosity': 0, 'color': True},
         {'host_key_checking': False, 'verbosity': 2, 'color': False},
         {'host_key_checking': False, 'verbosity': 2, 'color': True},
         {'host_key_checking': False, 'verbosity': 3, 'color': False},
         {'host_key_checking': False, 'verbosity': 3, 'color': True}]

# Generated at 2022-06-11 17:54:45.021648
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.cfg import CLIARGS
    if CLIARGS is not None:
        for key, value in vars(CLIARGS).items():
            assert key in CLIARGS
            assert CLIARGS[key] == value

# Generated at 2022-06-11 17:54:48.929229
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert GlobalCLIArgs({'a': 'b'}) == GlobalCLIArgs({'a': 'b'})
    # Assert the type of GlobalCLIArgs is ImmutableDict
    assert isinstance(GlobalCLIArgs({'a': 'b'}), ImmutableDict)

# Generated at 2022-06-11 17:54:55.379219
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = dict(
        host_list='/tmp/fake_host_list',
        extra_vars=dict(
            var1='a',
            var2='b'),
        forks=10,
        inventory='fake_inventory',
    )
    global_args = GlobalCLIArgs(args)
    assert global_args['host_list'] == '/tmp/fake_host_list'
    assert global_args['forks'] == 10
    assert global_args['extra_vars']['var1'] == 'a'
    assert global_args['extra_vars']['var2'] == 'b'

# Generated at 2022-06-11 17:55:00.116525
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    _dict = {'arg1':True, 'arg2':8}
    assert CLIArgs(_dict) == ImmutableDict(_dict)
    assert CLIArgs(_dict) != dict(_dict)
