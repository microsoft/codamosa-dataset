

# Generated at 2022-06-11 17:45:06.683406
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABCSingleton(_ABCSingleton):
        pass

    assert issubclass(TestABCSingleton, Singleton)
    assert issubclass(TestABCSingleton, ABCMeta)
    assert not issubclass(TestABCSingleton, Mapping)
    assert not issubclass(TestABCSingleton, Sequence)
    assert not issubclass(TestABCSingleton, Set)
    assert not issubclass(TestABCSingleton, Container)



# Generated at 2022-06-11 17:45:18.471688
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = {
        'verbosity': 3,
        'diff': True,
        'force_handlers': False,
        'start_at_task': 'install-software'
    }
    test_args = GlobalCLIArgs(args)
    assert test_args['verbosity'] == 3
    assert test_args['diff'] is True
    assert test_args['force_handlers'] is False
    assert test_args['start_at_task'] == 'install-software'

    # Test that we can't mutate the config values
    with pytest.raises(AttributeError):
        test_args['verbosity'] = 5

    with pytest.raises(AttributeError):
        del(test_args['verbosity'])


# Generated at 2022-06-11 17:45:26.694340
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Since we use the singleton pattern for this class, we can create as many instances as
    # we want, but they will all have the same id and thus point to the same instance in memory.
    args1 = GlobalCLIArgs({"hello": "world", "foo": "bar"})
    args2 = GlobalCLIArgs({"baz": "qux", "quux": "quuz"})

    assert id(args1) == id(args2)
    assert args1 == args2 == {"hello": "world", "foo": "bar", "baz": "qux", "quux": "quuz"}

# Generated at 2022-06-11 17:45:28.854741
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        pass
    class B(object):
        pass
    A()
    B()

# Generated at 2022-06-11 17:45:34.384877
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MySingleton(_ABCSingleton):
        pass

    class MySingleton2(_ABCSingleton):
        pass

    assert MySingleton() is MySingleton()
    assert MySingleton2() is MySingleton2()
    assert MySingleton() is not MySingleton2()



# Generated at 2022-06-11 17:45:43.832944
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {
        'foo': 'bar',
        'waldo': ('a', 'b', 'c'),
        'wibble': {
            'a': '1',
            'b': '2',
        },
    }
    new_dict = CLIArgs(test_dict)

    # Make sure the topmost level is an ImmutableDict
    assert(isinstance(new_dict, ImmutableDict))

    # Test that tuple, string, ImmutableDict, and ImmutableDict.ImmutableList are all unchanged the
    # same
    assert(new_dict['waldo'] == ('a', 'b', 'c'))
    assert(new_dict['foo'] == 'bar')
    assert(isinstance(new_dict['waldo'], tuple))

# Generated at 2022-06-11 17:45:45.731584
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    e = GlobalCLIArgs({'foo': 'bar'})
    assert e is GlobalCLIArgs.instance()

# Generated at 2022-06-11 17:45:49.064400
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ABCSingletonExample(ABCSingleton, text_type):
        pass

    es = ABCSingletonExample('example')
    assert type(es) is ABCSingletonExample
    assert type(es) is text_type



# Generated at 2022-06-11 17:45:58.689114
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs.from_options(
        ImmutableDict(
            destdir='/var/tmp',
            extra_vars=[
                '@/var/tmp/foo'
            ],
            vault_password_file='/var/tmp/vault_password_file',
            new_vault_password_file='/var/tmp/new_vault_password_file',
        )
    )

    assert isinstance(args, GlobalCLIArgs)

    assert args.destdir == '/var/tmp'
    assert args.extra_vars == ('@/var/tmp/foo',)



# Generated at 2022-06-11 17:46:09.240605
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    module_args = {
        'key1': text_type('bar'),
        'key2': ['spam', 'eggs'],
        'key3': {'a': 'b', 'c': 'd'}
    }
    global_cli_args = GlobalCLIArgs(module_args)

    import sys
    if sys.version_info[:2] < (2, 7):
        # tuples vs. lists
        assert global_cli_args['key2'] == tuple(module_args['key2'])
    else:
        assert global_cli_args['key2'] == module_args['key2']
    assert global_cli_args['key3'] == ImmutableDict(module_args['key3'])



# Generated at 2022-06-11 17:46:13.800237
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class D(object, metaclass=_ABCSingleton):
        pass
    for i in range(4):
        D()

# Generated at 2022-06-11 17:46:22.797844
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        """
        class A is used to test singleton class of _ABCSingleton
        """
        __metaclass__ = _ABCSingleton

        def __init__(self):
            self.num = 123

    class B(A):
        """
        class B is used to test singleton class of _ABCSingleton
        """
        pass

    a1 = A()
    a2 = A()

    assert a1.num == a2.num

    a3 = B()
    a4 = B()

    assert a3.num == a4.num

    assert a1 is a2
    assert a1 is not a3
    assert a3 is a4

# Generated at 2022-06-11 17:46:27.024210
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # type: () -> None
    """
    Test the constructor for class GlobalCLIArgs
    """
    try:
        GlobalCLIArgs({1: 2})
        assert False, "Should not get here"
    except TypeError as exception:
        assert str(exception) == 'Can\'t add new key \'1\' to immutable mapping'



# Generated at 2022-06-11 17:46:33.909894
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test constructor of GlobalCLIArgs.

    Unit test to make sure constructor of GlobalCLIArgs works as expected.
    """
    from inspect import isclass
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    assert isclass(GlobalCLIArgs)
    assert issubclass(GlobalCLIArgs, CLIArgs)
    assert issubclass(GlobalCLIArgs, ImmutableDict)
    assert issubclass(GlobalCLIArgs, Container)
    assert issubclass(GlobalCLIArgs, Mapping)
    assert issubclass(GlobalCLIArgs, Sequence)
    assert issubclass(GlobalCLIArgs, Set)


# Generated at 2022-06-11 17:46:37.495435
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Bare class should be abstract
    def f(): pass
    try:
        class A(_ABCSingleton):
            pass
        A()
        f()
    except TypeError:
        pass
    else:
        f()
        assert False



# Generated at 2022-06-11 17:46:43.479112
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    a1 = A()
    a2 = A()
    assert a1 is a2
    b1 = B()
    b2 = B()
    assert b1 is b2
    assert b1 is not a1


# Generated at 2022-06-11 17:46:47.663736
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert A() is B()
    assert B() is A()


# Generated at 2022-06-11 17:46:56.712805
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class options(object):
        def __init__(self, test_val1, test_val2, test_val3):
            self.test_val1 = test_val1
            self.test_val2 = test_val2
            self.test_val3 = test_val3

        def __iter__(self):
            return iter(self.__dict__)

        def __len__(self):
            return len(self.__dict__)

        def __getitem__(self, key):
            return self.__dict__[key]

        def __setitem__(self, key, value):
            self.__dict__[key] = value

        def __delitem__(self, key):
            del self.__dict__[key]

        def keys(self):
            return self.__dict__.keys()

# Generated at 2022-06-11 17:47:02.200828
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs({'name': 'skip_tags', 'value': ['network'], 'include': 'yes', 'version': 2})

    assert cli_args.get('name') == 'skip_tags'
    assert cli_args.get('value') == ('network',)
    assert cli_args.get('include') == 'yes'
    assert cli_args.get('version') == 2


# Generated at 2022-06-11 17:47:08.783522
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    c = CLIArgs({'a': '1', 'b': '2'})

    # Make sure we have the right data
    assert c['a'] == '1'
    assert c['b'] == '2'

    # And it is immutable
    try:
        c['b'] = 2
    except RuntimeError as e:
        assert e.args == ("'ImmutableDict' object does not support item assignment",)


# Generated at 2022-06-11 17:47:16.743476
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass1(object):
        __metaclass__ = _ABCSingleton

    class TestClass2(TestClass1):
        pass

    class TestClass3(TestClass2):
        pass

    class TestClass4(TestClass1):
        pass

    assert issubclass(TestClass2, TestClass1)
    assert issubclass(TestClass3, TestClass2)
    assert issubclass(TestClass4, TestClass1)



# Generated at 2022-06-11 17:47:26.422556
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict1 = {'key1': 'value1',
             'key2': ['some', 'values', 'value2'],
             'key3': {'key4': 'value4'},
             'key5': (1, 2, 3),
             'key6': {'key7': ('value7',),
                      'key8': {'key9': 'value9'}, }
             }
    dict2 = CLIArgs(dict1)
    for key in dict1:
        assert dict1[key] == dict2[key].data, '%s.data' % key


# Generated at 2022-06-11 17:47:31.377243
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test the GlobalCLIArgs class to make sure it does not allow mutation
    """
    cli_args = GlobalCLIArgs({'key': 'value'})
    assert cli_args['key'] == 'value'
    # Keys are supposed to be immutable, so this should raise an exception
    with pytest.raises(TypeError):
        cli_args['key'] = 'value2'

# Generated at 2022-06-11 17:47:33.936323
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class NewABCSingleton(object):
        __metaclass__ = _ABCSingleton

    assert isinstance(NewABCSingleton(), NewABCSingleton)

# Generated at 2022-06-11 17:47:46.300705
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_data = {
        'one': {
            'two': {
                'three': 3,
                'four': '4'
            },
            'five': [
                {
                    'six': [
                        6,
                        'six'
                    ]
                },
                [
                    7,
                    'seven'
                ]
            ]
        }
    }
    cli_args = CLIArgs(test_data)
    assert cli_args == test_data
    # Check that all the internal structures are immutable
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args['one'], ImmutableDict)
    assert isinstance(cli_args['one']['two'], ImmutableDict)

# Generated at 2022-06-11 17:47:52.035713
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # create a test dictionary
    test_dict = {
        'create': {
            'key': 'value'
        },
        'update': {
            'key': 'value'
        },
    }

    cli_args = CLIArgs(test_dict)
    assert cli_args['create'] == {'key': 'value'}
    assert cli_args['update'] == {'key': 'value'}

# Generated at 2022-06-11 17:47:56.951530
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args_dict = {'listtags': True, 'listtasks': True, 'syntax': True}
    args = GlobalCLIArgs(args_dict)

    assert isinstance(args, ImmutableDict)
    assert isinstance(args['listtags'], bool)
    assert isinstance(args['listtasks'], bool)
    assert isinstance(args['syntax'], bool)



# Generated at 2022-06-11 17:47:59.926401
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton
    class Bar(object):
        __metaclass__ = _ABCSingleton
    assert Foo() is not Bar()
    assert isinstance(Foo(), Bar)

# Generated at 2022-06-11 17:48:09.394857
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.basic import AnsibleModule

    testopt = AnsibleModule(
        argument_spec=dict(
            teststr1=dict(default='teststr1', type='str'),
            teststr2=dict(default='teststr2', type='str'),
            teststr3=dict(default='teststr3', type='str')
        ),
        supports_check_mode=True
    ).params
    test_cliargs = GlobalCLIArgs.from_options(testopt)
    assert test_cliargs['teststr1'] == 'teststr1'
    assert test_cliargs['teststr2'] == 'teststr2'
    assert test_cliargs['teststr3'] == 'teststr3'

# Generated at 2022-06-11 17:48:19.789267
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.netcommon import _parse_cli_to_dict
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.connection import Connection, ConnectionError

    module_args = dict(
        provider=dict(
            host=dict(required=True),
            username=dict(required=True),
            password=dict(),
            ssh_keyfile=dict(),
            authorize=dict(type='bool'),
            auth_pass=dict()
        )
    )

    cli_args = vars(_parse_cli_to_dict(module_args))
    cli_args['provider']['password'] = 'pass'
    cli_args['provider']['username'] = 'user'


# Generated at 2022-06-11 17:48:33.131358
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    example = {'hello': 'world', 'foo': 'bar', 'baz': 'biz'}
    obj = CLIArgs(example)
    assert(isinstance(obj, CLIArgs))
    assert(obj.hello == 'world')
    assert(obj.foo == 'bar')
    assert(obj.baz == 'biz')
    assert(len(obj) == 3)
    example = {'hello': {'world': 'hello world'}, 'foo': ['bar', 'baz'], 'baz': {'bar': {'baz': 'biz'}}}
    obj = CLIArgs(example)
    assert(isinstance(obj, CLIArgs))
    assert(obj.hello.world == 'hello world')
    assert(obj.foo[0] == 'bar')
    assert(obj.foo[1] == 'baz')

# Generated at 2022-06-11 17:48:38.346361
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class First(_ABCSingleton):
        def __init__(self):
            super(First, self).__init__()
            print('First')

    class Second(_ABCSingleton):
        def __init__(self):
            super(Second, self).__init__()
            print('Second')

    First()
    Second()

# Generated at 2022-06-11 17:48:41.028629
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    The test of __ABCSingleton is implemented in unit test of CLIArgs, test_core.
    :return:
    """
    pass

# Generated at 2022-06-11 17:48:52.492465
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Keep the test in a single function so that all the tests can use the same
    # `instance` variable and not pollute the global namespace

    # We should be able to construct the class directly
    import argparse
    instance = CLIArgs(vars(argparse.Namespace()))
    assert isinstance(instance, dict)

    instance = CLIArgs.from_options(argparse.Namespace())
    assert isinstance(instance, dict)

    # Make sure our constructor makes all of it immutable
    instance = CLIArgs({
        'foo': 'bar',
        'bar': {
            'foo': 'foo',
            'bar': ['bar', 'foo', 'foo'],
            'baz': {
                'foo': 'bar'
            }
        },
        'baz': ('foo', 'bar', 'bar')
    })


# Generated at 2022-06-11 17:49:03.669152
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyClass(object):
        pass

    class MyClass2(object):
        pass

    class MySingleton(MyClass, _ABCSingleton):
        pass

    class MySingleton2(MyClass, _ABCSingleton):
        pass

    class MyABC(object):
        __metaclass__ = ABCMeta

    class MyABCSingleton(MyABC, _ABCSingleton):
        pass

    class MyABCSingleton2(MyABC, _ABCSingleton):
        pass

    assert issubclass(MySingleton, MyClass)
    assert not issubclass(MyClass, MySingleton)
    assert issubclass(MySingleton, MySingleton2)
    assert issubclass(MySingleton2, MySingleton)
    assert not issubclass(MySingleton, MyABCSingleton)
    assert not iss

# Generated at 2022-06-11 17:49:12.521745
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    d = {'a': True, 'b': 1, 'c': [1, 2, 3], 'd': {'e': 'f'}}
    c = CLIArgs(d)
    assert c.a
    assert c.b == 1
    assert c.c == (1, 2, 3)
    assert c.d.e == 'f'
    d['b'] = 2
    assert c.b == 1
    d['c'][1] = 5
    assert c.c == (1, 2, 3)
    d['d']['g'] = 'h'
    assert 'g' not in c.d
    assert isinstance(c, ImmutableDict)
    assert isinstance(c.d, ImmutableDict)
    assert isinstance(c.c, tuple)

# Generated at 2022-06-11 17:49:20.643233
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--help', action='help', help='show this help message and exit')
    parser.add_argument('--foo', default='bar', help='help for %(prog)s')
    args = parser.parse_args([])
    assert args.foo == 'bar'
    instance_1 = GlobalCLIArgs.from_options(args)
    instance_2 = GlobalCLIArgs.from_options(args)
    assert instance_1 is instance_2
    assert instance_1.foo == 'bar'
    assert instance_2.foo == 'bar'

# Generated at 2022-06-11 17:49:28.730784
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
     cli_args = {
         'connection': 'smart',
         'force_handlers': False,
         'tags': [],
         'verbosity': 1,
         'playbook_path': './test_playbook.yml',
         'inventory': ['./test.inventory'],
         'module_path': ['/test/module/path']
     }

     # Mapping is converted to ImmutableDict
     assert isinstance(cli_args, Mapping)
     global_cli_args = GlobalCLIArgs(cli_args)
     assert isinstance(global_cli_args, ImmutableDict)

     # Containers are converted to their immutable counterparts
     assert isinstance(cli_args['tags'], list)
     assert isinstance(global_cli_args['tags'], tuple)

     # The object is a Sing

# Generated at 2022-06-11 17:49:30.754100
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()

# Generated at 2022-06-11 17:49:36.346677
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # pylint: disable=attribute-defined-outside-init
    class GlobalCLIArgsTest(GlobalCLIArgs):
        """ Test for global options"""
        pass

    options = GlobalCLIArgsTest.from_options({'foo': {'bar': 'baz'}, 'froz': 6, 'spam': 'ham'})
    assert options['foo'] == {'bar': 'baz'}
    assert options['froz'] == 6
    assert options['spam'] == 'ham'

# Generated at 2022-06-11 17:49:48.658291
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import json
    import os
    import tempfile
    import pytest
    import textwrap
    import subprocess
    here = os.path.dirname(os.path.abspath(__file__))
    cli_args_path = os.path.join(here, os.pardir, 'ansible', 'cli', '__init__.py')
    # construct a script that calls a function to construct an ansible.utils.cli.GlobalCLIArgs object
    # which can then be inspected

# Generated at 2022-06-11 17:49:51.714038
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class X(GlobalCLIArgs):
        pass
    class Y(GlobalCLIArgs):
        pass

    x = X()
    y = Y()

    assert x is y

# Generated at 2022-06-11 17:49:57.400713
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

        def __init__(self, value):
            self.value = value

    assert TestClass(42) == TestClass(42)
    assert TestClass(42).value == 42
    assert TestClass(43) != TestClass(42)
    assert TestClass(43).value == 43

# Generated at 2022-06-11 17:50:01.717302
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # a list of arguments to parse
    args = ['--private-key', '/tmp/id_rsa', '--user', 'root', '--become', 'false',
            '--become-method', 'sudo', '--ask-become-pass']
    parser = CLIArgs.from_options(options=args)
    assert parser.get('private-key') == '/tmp/id_rsa'

# Generated at 2022-06-11 17:50:13.663077
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-11 17:50:17.194523
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = ImmutableDict({'foo': 'bar'})
    a = GlobalCLIArgs.from_options(options)
    b = GlobalCLIArgs.from_options(options)

    assert a is b

# Generated at 2022-06-11 17:50:25.109565
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    g = GlobalCLIArgs()
    # GlobalCLIArgs is a Singleton so we shouldn't be able to create a second one.
    # If a second constructor is called, it should return the same object that was created by the first call.
    g2 = GlobalCLIArgs()
    assert g is g2
    # Now modify the values of the singleton
    g['foo'] = 'bar'
    g['bar'] = [1, 2, 3]
    # Calling the constructor again with different values should not cause the values of the singleton to change.
    g3 = GlobalCLIArgs()
    assert g is g3
    assert g == g3
    assert g == {'foo': 'bar', 'bar': [1, 2, 3]}
    # Calling the constructor again on a new class instance shouldn't cause a new instance to be created.
   

# Generated at 2022-06-11 17:50:27.849844
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import copy

    x = GlobalCLIArgs.from_options(object())
    y = copy.deepcopy(x)
    assert x == y

# Generated at 2022-06-11 17:50:32.895692
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():  # type: () -> None
    # This is a test that makes sure the constructor of class GlobalCLIArgs
    # allows ImmutableDict to be instantiated as a GlobalCLIArgs class
    # this tests for the removal of setattr where setattr was used
    # for the same thing
    immutable_dict = ImmutableDict({'test': 'value'})
    global_cl_args = GlobalCLIArgs(immutable_dict)
    assert global_cl_args.data == immutable_dict

# Generated at 2022-06-11 17:50:34.406949
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class X(_ABCSingleton):
        pass

# Generated at 2022-06-11 17:50:53.645964
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABCSingletonTest(object):
        __metaclass__ = _ABCSingleton

    class _SingletonTest(object):
        __metaclass__ = Singleton

    class _ABCSingletonTest2(_ABCSingletonTest):
        pass

    class _SingletonTest2(_SingletonTest):
        pass

    class _ABCSingletonTest3(_ABCSingletonTest2):
        pass

    class _SingletonTest3(_SingletonTest2):
        pass

    assert "_SingletonTest" == _SingletonTest.__name__
    assert "_SingletonTest2" == _SingletonTest2.__name__
    assert "_SingletonTest" == _SingletonTest3.__name__
    assert "_ABCSingletonTest" == _ABCSingletonTest.__name__
    assert "_ABCSingletonTest2" == _ABCSing

# Generated at 2022-06-11 17:51:04.520393
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import json
    import os
    import sys
    import tempfile
    if not sys.version_info[:2] == (2, 7):
        raise Exception("Tests of GlobalCLIArgs are only supported in Python 2.7")
    if sys.version_info[3] == 'final' and sys.version_info[:3] == (2, 7, 13):
        raise Exception("The 2.7.13 interpreter is known to fail GlobalCLIArgs tests, please use another version of Python 2.7")
    temp_file = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-11 17:51:09.302172
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test = GlobalCLIArgs({'one':'two'})
    assert test['one'] == 'two'
    # not a failure, but this should not work
    test['one'] = 'three'
    assert test['one'] == 'two'

# Generated at 2022-06-11 17:51:14.245140
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs(dict(a=1, b=2, c=3))
    assert cli_args.a == 1
    assert cli_args.b == 2
    assert cli_args.c == 3
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args, Mapping)



# Generated at 2022-06-11 17:51:21.574459
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Create an options object to pass as an argument to the constructor
    class Options(object):
        def __init__(self, inventory_dir, log_dir, private_data_dir, cwd):
            self.inventory_dir = inventory_dir
            self.log_dir = log_dir
            self.private_data_dir = private_data_dir
            self.cwd = cwd

    test_options = Options('inventory_dir', 'log_dir', 'private_data_dir', 'cwd')
    # Create two objects, they should be equal and there should only be one object
    temp_args1 = GlobalCLIArgs.from_options(test_options)
    temp_args2 = GlobalCLIArgs.from_options(test_options)
    assert temp_args1 == temp_args2

# Generated at 2022-06-11 17:51:26.060898
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    a_one = A()
    a_two = A()

    assert a_one is a_two

    class B(A):
        pass

    b_one = B()
    b_two = B()

    assert b_one is b_two

# Generated at 2022-06-11 17:51:29.439981
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = GlobalCLIArgs({"foo":123,"bar":{"baz":"bang"}})
    assert isinstance(a, ImmutableDict)
    assert a == ImmutableDict({"foo":123,"bar":{"baz":"bang"}})

# Generated at 2022-06-11 17:51:41.493215
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    import types

    # Create args from type
    args = GlobalCLIArgs()
    assert (isinstance(args, GlobalCLIArgs))
    assert (isinstance(args, CLIArgs))
    assert (not isinstance(args, types.DictType))
    assert (not isinstance(args, types.SimpleNamespace))

    # We should have an empty args when nothing is passed in
    assert (0 == len(args))
    with pytest.raises(KeyError):
        args['foo']

    # Create args from dict
    args = GlobalCLIArgs({'foo': 'bar'})
    assert (isinstance(args, GlobalCLIArgs))
    assert (isinstance(args, CLIArgs))
    assert (not isinstance(args, types.DictType))

# Generated at 2022-06-11 17:51:50.158915
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ABCMetaBase(object):
        """
        An abstract class to test _ABCSingleton
        """
        __metaclass__ = ABCMeta

    class ABCMetaSingleton(ABCMetaBase):
        """
        An abstract class to test _ABCSingleton
        """
        __metaclass__ = _ABCSingleton

    class NonAbstract(ABCMetaSingleton):
        """
        A class that is not abstract
        """
        pass

    # Test that you can create an instance of the class
    assert isinstance(NonAbstract(), NonAbstract)
    # Test that you can not create an instance of an abstract class
    try:
        assert isinstance(ABCMetaSingleton(), ABCMetaSingleton)
    except TypeError:
        pass
    else:
        raise AssertionError("ABCMetaSingleton should be abstract")

# Generated at 2022-06-11 17:51:50.885771
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs(dict())

# Generated at 2022-06-11 17:52:06.203663
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    If a Singleton class has a different constructor used on a class then the Singleton metaclass
    will break.  This test checks that GlobalCLIArgs is actually a Singleton class which only calls
    super when the class is instantiated.
    """
    a = GlobalCLIArgs.from_options(ImmutableDict({"a": 1}))
    b = GlobalCLIArgs.from_options(ImmutableDict({"a": 2}))

    assert a == b
    assert a is b

# Generated at 2022-06-11 17:52:09.108082
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ABCSingletonTest(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(ABCSingletonTest(), ABCSingletonTest)

# Generated at 2022-06-11 17:52:17.559100
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    map1 = {"hosts": "hosts"}
    cli_args1 = CLIArgs(map1)
    assert isinstance(cli_args1, Mapping)
    # ImmutableDict should not be modifiable (it's wrapper of dict)
    try:
        cli_args1['port'] = "port"
    except TypeError:
        pass
    else:
        assert False
    # CLIArgs.__init__ should recursively convert dict, list and set into corresponding immutable types
    map2 = {"key1": "value1", "key2": [1, 2, 3], "key3": {"key4": "value4", "key5": [5, 6, 7]}, "key6": {1, 2}, "key7": (1, 2, 3)}
    cli_args2 = CLIArgs(map2)

# Generated at 2022-06-11 17:52:27.467576
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    g = GlobalCLIArgs({'foo': 'bar'})

    assert g['foo'] == 'bar'
    assert g.get('foo') == 'bar'

    # verify we can't add or change values
    try:
        g['foo'] = 'baz'
    except TypeError:
        pass
    else:
        raise RuntimeError('Should not be able to set foo')

    try:
        g['flur'] = 'baz'
    except TypeError:
        pass
    else:
        raise RuntimeError('Should not be able to set flur')

    # verify we can't delete values
    try:
        del g['foo']
    except TypeError:
        pass
    else:
        raise RuntimeError('Should not be able to del foo')

    # verify we can't replace the whole dict

# Generated at 2022-06-11 17:52:31.717063
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Unit test to see if GlobalCLIArgs is a singleton or not

    In fact, it should be singleton.
    """
    a = GlobalCLIArgs({'a': 'b'})
    if a is GlobalCLIArgs.get_instance():
        print('GlobalCLIArgs is a singleton')
    else:
        print('GlobalCLIArgs is NOT a singleton')

# Generated at 2022-06-11 17:52:35.593681
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs({'connection': 'ssh'})
    assert global_cli_args['connection'] == 'ssh'
    assert isinstance(global_cli_args, ImmutableDict)
    assert not isinstance(global_cli_args, dict)

# Generated at 2022-06-11 17:52:42.552126
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Constructor for class GlobalCLIArgs
    """
    # Is this test needed as we can't use print()?
    # pylint: disable=unused-argument
    def fake_option_parser(cls, usage=None, description=None, epilog=None):
        """
        Fake option parser for unit test

        We don't use optparse or argparse as the logic for command line parsing is already done and
        we don't have to implement it ourselves.  Which makes this test pretty barebones as we don't
        have to do anything with the option parser to test CLIArgs creator.
        """
        pass

    class Options(object):
        """
        Fake options object for unit test
        """
        pass

    arg_parser = fake_option_parser
    options = Options()
    options.force_handlers = True


# Generated at 2022-06-11 17:52:48.604197
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    # Create a parser
    parser = argparse.ArgumentParser()
    parser.add_argument('foo', type=int)
    # Make our args object with the parser
    args = parser.parse_args(["1"])
    # Make a CLIArgs object
    cli_args = GlobalCLIArgs.from_options(args)

    # An int should stay int
    assert isinstance(cli_args['foo'], int)
    # Strings should be immutable
    assert isinstance(cli_args['foo'], (text_type, binary_type))
    # Strings should be immutable
    assert isinstance(cli_args['foo'], (text_type, binary_type))
    # And dicts
    assert isinstance(cli_args, Mapping)
    # And lists

# Generated at 2022-06-11 17:52:51.209572
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(A):
        pass
    # Check that we can instantiate subclasses
    assert B() is B()

# Generated at 2022-06-11 17:52:53.261379
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class MyClass(GlobalCLIArgs):
        def __init__(self):
            pass
    assert id(MyClass()) == id(MyClass())

# Generated at 2022-06-11 17:53:12.649468
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Test to just verify that we can create a subclass of _ABCSingleton
    class Test(_ABCSingleton):
        pass
    assert Test() is Test()

# Generated at 2022-06-11 17:53:21.438525
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class FakeOptions(object):
        def __init__(self):
            self.foo = 'bar'
            self.baz = set()

    opt = FakeOptions()

    # Make a new ImmutableDict
    args = CLIArgs.from_options(opt)
    assert isinstance(args, ImmutableDict)
    assert args != opt
    # But its in the same tree
    assert args['foo'] == opt.foo
    assert args['baz'] == opt.baz

    # Make a new ImmutableDict from a dict
    args = CLIArgs({'foo': 'bar', 'baz': set()})
    assert isinstance(args, ImmutableDict)
    assert args != opt
    # But its in the same tree
    assert args['foo'] == opt.foo

# Generated at 2022-06-11 17:53:23.188124
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Create a GlobalCLIArgs instance"""
    GlobalCLIArgs({"a": "b"})

# Generated at 2022-06-11 17:53:28.169194
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # pylint: disable=no-member
    assert issubclass(_ABCSingleton, ABCMeta)
    assert issubclass(_ABCSingleton, Singleton)
    assert _ABCSingleton.__instance is None
    # pylint: enable=no-member


# Generated at 2022-06-11 17:53:39.485910
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    module_args = {'one': 'a', 'two': 'b'}

    # Test GlobalCLIArgs is Singleton
    assert GlobalCLIArgs(module_args) is GlobalCLIArgs(module_args)

    # Test GlobalCLIArgs is immutable
    global_cli_args = GlobalCLIArgs(module_args)
    try:
        global_cli_args['one'] = 'one'
    except KeyError:
        pass
    except Exception as e:
        assert False, 'Unexpected exception encountered: %s' % e

    try:
        global_cli_args.update({'one': 'one'})
    except KeyError:
        pass
    except Exception as e:
        assert False, 'Unexpected exception encountered: %s' % e

    # Test GlobalCLIArgs is ImmutableDict

# Generated at 2022-06-11 17:53:41.949838
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class ABCSingletonTest(object):
        __metaclass__ = _ABCSingleton

    assert isinstance(ABCSingletonTest(), ABCSingletonTest)



# Generated at 2022-06-11 17:53:42.894264
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Dummy(_ABCSingleton):
        pass

# Generated at 2022-06-11 17:53:52.645826
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Test constructor of class CLIArgs"""
    class Container(object):
        """Test object that contains a container"""
        def __init__(self, mapping):
            self.mapping = mapping

    # Test a mapping with a list (sequence) in it
    test_mapping = {
        'key1': [
            'value1',
            'value2',
            'value3'
        ]
    }
    temp = CLIArgs(test_mapping)
    assert temp == test_mapping

    # Test a mapping with a set in it
    test_mapping = {
        'key1': set([
            'value1',
            'value2',
            'value3'
        ])
    }

    temp = CLIArgs(test_mapping)
    assert temp == test_mapping

    # Test a mapping with a

# Generated at 2022-06-11 17:54:00.383221
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    import types

    class NewType(metaclass=_ABCSingleton):
        pass

    class NewTypeSub(NewType):
        pass

    try:
        class NewTypeSubSub(NewTypeSub):
            pass
    except TypeError:
        pass

    class NewTypeOverwrite(NewType):
        def __new__(cls):
            raise TypeError

    NewTypeSubOverwrite = types.new_class('NewTypeSubOverwrite', (NewTypeSub,), {}, lambda ns: ns.update(__new__=lambda cls: 42))

    assert NewTypeOverwrite.__new__ is NewType.__new__
    assert NewTypeSubOverwrite.__new__ is NewTypeSub.__new__
    assert NewTypeSubOverwrite().__new__() == 42


# Generated at 2022-06-11 17:54:02.890899
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({'a': 1, 'b': [1, 2], 'c': {'d': [1, 2, 3]}})



# Generated at 2022-06-11 17:54:49.993141
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
  import ansible.module_utils.common.collections
  # Create CLIArgs object from dict with dicts, lists, and strings
  mapping = {}
  mapping['key1'] = 'value1'
  mapping['key2'] = 'value2'
  mapping['key3'] = ansible.module_utils.common.collections.ImmutableList(['foo', 'bar', 'baz'])
  mapping['key4'] = ansible.module_utils.common.collections.ImmutableDict(dict(
    key1='value1',
    key2='value2',
    key3='value3'
  ))
  # Ensure type conversions have happened on construction
  assert isinstance(mapping['key1'], str)
  assert isinstance(mapping['key2'], str)

# Generated at 2022-06-11 17:54:52.428380
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    class Bar(object):
        __metaclass__ = _ABCSingleton

    assert Foo() is Foo()
    assert Foo() is not Bar()

# Generated at 2022-06-11 17:54:54.608524
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test1(_ABCSingleton):
        pass

    class Test2(_ABCSingleton):
        pass

    assert Test1() is Test1()
    assert not isinstance(Test1(), Test2)