

# Generated at 2022-06-11 17:44:57.800628
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    assert Foo() == Foo()


# Generated at 2022-06-11 17:45:00.358802
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABCSingletonClass(object):
        __metaclass__ = _ABCSingleton
    assert _ABCSingletonClass() is _ABCSingletonClass()

# Generated at 2022-06-11 17:45:05.446120
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 'apple', 'b': {'c': 'carrot'}, 'd': [1, 2, 3]}
    a = CLIArgs(test_dict)
    test_dict['a'] = 'apple_changed'
    assert a['a'] == 'apple'
    b = _make_immutable(test_dict)
    assert b['a'] == 'apple'



# Generated at 2022-06-11 17:45:09.420531
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # setup
    mapping = {'verbosity': 0, 'check_mode': False}
    # execution
    args = CLIArgs(mapping)
    # verification
    assert args.verbosity == mapping['verbosity']
    assert args.check_mode == mapping['check_mode']



# Generated at 2022-06-11 17:45:20.706622
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    temp_dict = {
        'foo': 1,
        'bar': 'woof',
        'baz': (2, 3, 4),
        'qux': [{'woof':'woof'}, {'meow':'meow'}],
    }
    cli_args = CLIArgs(temp_dict)
    assert cli_args.foo == 1
    assert cli_args.bar == 'woof'
    assert cli_args.baz == (2, 3, 4)
    assert cli_args.qux == (ImmutableDict({'woof':'woof'}), ImmutableDict({'meow':'meow'}))
    assert isinstance(cli_args, ImmutableDict)
    assert issubclass(cli_args.__class__, Mapping)


# Generated at 2022-06-11 17:45:24.120163
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    obj = GlobalCLIArgs({'a': 1, 'b': 2})
    GlobalCLIArgs({'a': 1, 'b': 2})
    GlobalCLIArgs({'a': 1, 'b': 3})

# Generated at 2022-06-11 17:45:36.430524
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import os
    import sys

    sys.argv.append('--foo=bar')
    try:
        from ansible.config.args import parse_args

        options = parse_args(args=['ansible-config'])
        GlobalCLIArgs.from_options(options)
    finally:
        sys.argv.pop()

    # The object should be immutable, so we cannot add a new key
    try:
        GlobalCLIArgs['new_key'] = 'new_value'
    except TypeError:
        pass
    else:
        assert False, 'GlobalCLIArgs did add a new key'

    # The object should be immutable, so we cannot modify an existing key
    try:
        GlobalCLIArgs['foo'] = 'new_value'
    except TypeError:
        pass
    else:
        assert False

# Generated at 2022-06-11 17:45:40.531000
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyABCSingleton(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(MyABCSingleton(), MyABCSingleton)

_cliargs = GlobalCLIArgs.from_options({})  # pylint: disable=invalid-name



# Generated at 2022-06-11 17:45:47.248400
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    map1 = { 'a': [ 1, 2, { 'b': [ 3, 4 ] } ] }
    a = CLIArgs(map1)
    assert 'a' in a
    assert 1 in a['a']
    assert 3 in a['a'][2]['b']
    try:
        a['a'][2]['b'].append(5)
        assert False
    except Exception as e:
        assert str(e) == '\'tuple\' object has no attribute \'append\''

# Generated at 2022-06-11 17:45:49.850593
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    testArgs = {'example_cli': False, 'ansible_python_interpreter': '', 'connection': '', 'remote_user': '', 'sudo': False}
    GlobalCLIArgs(testArgs)

# Generated at 2022-06-11 17:45:58.361949
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert CLIArgs({'a': 1, 'b': [2, 3]}) == {'a': 1, 'b': (2, 3)}
    assert CLIArgs({'a': 1, 'b': {'c': 2, 'd': 3}}) == {'a': 1, 'b': {'c': 2, 'd': 3}}

# Generated at 2022-06-11 17:46:05.026135
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    x = CLIArgs(dict(one=1, two=2))
    assert(x['one'] == 1)
    assert(x['two'] == 2)
    assert(len(x) == 2)
    try:
        x['one'] = 2
    except Exception:
        pass
    else:
        raise AssertionError('CLIArgs should not be mutable')


# Generated at 2022-06-11 17:46:13.184715
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils.common.collections import AttributeDict

    class MyClass(object):
        __metaclass__ = _ABCSingleton

    class MySubClass(MyClass):
        pass

    class MySubSubClass(MySubClass):
        pass

    def test_type(obj):
        assert isinstance(obj, MyClass)
        assert isinstance(obj, AttributeDict)
        assert not isinstance(obj, dict)
        assert not isinstance(obj, Mapping)

    assert issubclass(MyClass, MyClass)
    assert issubclass(MySubClass, MyClass)
    assert issubclass(MySubSubClass, MyClass)

    test_type(MyClass())
    test_type(MyClass())
    test_type(MySubClass())

# Generated at 2022-06-11 17:46:16.810925
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert hash(A()) == hash(A())

# Generated at 2022-06-11 17:46:20.165786
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict = { "FOO" : "BAR" }
    cli_args = CLIArgs(dict)
    assert cli_args["FOO"] == "BAR"



# Generated at 2022-06-11 17:46:30.007144
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import collections
    import pytest
    import tempfile

    mapping = {
        "a": "A",
        "b": ["B"],
        "c": collections.OrderedDict({"a": "A", "b": "BB", "c": "CCC"}),
        "d": tempfile.TemporaryFile(),
        "e": collections.Counter({"a": 1, "b": 2}),
    }

    g = GlobalCLIArgs(mapping)
    for key, value in mapping.items():
        assert g[key] == value
        if key == "d":
            # Just check that the type is the same and that the file isn't open
            assert isinstance(g[key], type(value))
            assert g[key].closed is True
        else:
            assert type(g[key]) == ImmutableD

# Generated at 2022-06-11 17:46:40.550645
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    d = {'foo': {'bar': 'baz', 'baz': ['foo', 'bar']}, 'bar': 'baz', 'baz': ['foo', 'bar']}
    a = CLIArgs(d)
    assert a['foo'] is not d['foo']
    assert type(a['foo']) is ImmutableDict
    assert a['foo']['bar'] == d['foo']['bar']
    assert a['foo']['baz'] is not d['foo']['baz']
    assert type(a['foo']['baz']) is tuple
    assert a['foo']['baz'][0] == d['foo']['baz'][0]
    assert a['bar'] == d['bar']
    assert a['baz'] is not d['baz']

# Generated at 2022-06-11 17:46:43.705976
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    assert isinstance(A(), A)
    assert isinstance(B(), B)


# Generated at 2022-06-11 17:46:51.677930
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import pytest
    from tempfile import TemporaryFile

    x = CLIArgs({'x': 1})

    with TemporaryFile() as tmp_file:
        with pytest.raises(ValueError):
            CLIArgs({'x': 1, 'y': 2, 'z': tmp_file})

    class Concrete(object):
        pass

    with TemporaryFile() as tmp_file:
        with pytest.raises(ValueError):
            CLIArgs({'x': 1, 'y': 2, 'z': {'a': Concrete()}})

# Generated at 2022-06-11 17:47:00.600393
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Test that GlobalCLIArgs is immutable"""
    opts = {'a': 'b'}
    clargs = GlobalCLIArgs(opts)
    assert clargs['a'] == 'b'
    opts['a'] = 'c'
    assert clargs['a'] == 'b'
    assert opts['a'] == 'c'
    clargs['a'] = 'd'
    assert clargs['a'] == 'b'
    assert opts['a'] == 'c'
    try:
        clargs['b'] = 'd'
        assert False, 'should have thrown TypeError'
    except TypeError:
        pass

# Generated at 2022-06-11 17:47:06.097780
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    s = GlobalCLIArgs({"foo": "bar"})
    assert s["foo"] == "bar"

# Generated at 2022-06-11 17:47:10.876915
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Test for metaclass inheritance
    class TestABCSingleton(with_metaclass(_ABCSingleton, object)):
        pass

    class TestABCSingleton2( with_metaclass(_ABCSingleton, object)):
        pass

    assert TestABCSingleton() is not TestABCSingleton2()

# Generated at 2022-06-11 17:47:20.215838
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test for the constructor of the class GlobalCLIArgs
    """
    class Options:
        a = None
        b = None
        c = None
        d = None
        e = None
        f = None
        g = None
        i = None
        l = None
        m = None
        n = None
        o = None
        P = None
        p = None
        r = None
        s = None
        t = None
        T = None
        u = None
        v = None
        w = None
        x = None
        z = None

    options = Options()
    options.a = 1
    options.b = 1
    options.c = {'a': 'a', 'b': 'b'}
    options.d = 'd'
    options.e = ['a', 'b']

# Generated at 2022-06-11 17:47:23.808141
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyTest(object):
        __metaclass__ = _ABCSingleton
        def __init__(self):
            pass

    MyTest()

# Generated at 2022-06-11 17:47:31.021115
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 'one', 'b': 2, 3: 'three'})
    assert(isinstance(args, Mapping))
    assert(not hasattr(args, 'get'))
    assert(args[3] == 'three')
    assert(len(args) == 3)
    assert(isinstance(args.keys(), Set))
    assert(isinstance(args.values(), Sequence))
    assert('b' in args)
    assert(args.get('b') == 2)
    assert(args.get('c', 3) == 3)


# Generated at 2022-06-11 17:47:43.765406
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    temp_dict = {'a': 'abc', 'b': ['cde', 'efg', 'hij']}
    temp_dict_copy = {}
    for key, value in temp_dict.items():
        temp_dict_copy[key] = value
    cli_args = CLIArgs(temp_dict)
    # Ensure that the constructor of CLIArgs can handle all mutable type of containers
    assert isinstance(temp_dict, Container)
    assert isinstance(temp_dict['b'], Container)
    assert isinstance(temp_dict_copy['b'], Container)
    # Test the copy constructor
    assert temp_dict == temp_dict_copy
    # Test the contents of cli_args
    assert cli_args['a'] == temp_dict_copy['a']
    assert cli_args['b'] == temp

# Generated at 2022-06-11 17:47:50.911315
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils._text import to_bytes  # TODO: deprecate this?
    from ansible.parsing.vault import VaultLib
    import os


# Generated at 2022-06-11 17:47:52.769585
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_args = GlobalCLIArgs({})
    assert global_args is GlobalCLIArgs({})

# Generated at 2022-06-11 17:47:58.984525
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class cls1(GlobalCLIArgs):
        pass
    a = cls1()
    b = cls1()
    assert a is b

    class cls2(GlobalCLIArgs, object):
        pass
    c = cls2()
    d = cls2()
    assert c is d
    assert a is d
    assert isinstance(a, cls1)
    assert isinstance(c, cls2)

    class cls3(GlobalCLIArgs, object):
        pass
    e = cls3()
    assert a is not e
    assert c is not e

# Generated at 2022-06-11 17:48:09.430493
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    import types

    # The object to test on is a list of args
    import argparse
    parser = argparse.ArgumentParser(description='Process some integers.')
    parser.add_argument('integers', metavar='N', type=int, nargs='+',
                        help='an integer for the accumulator')
    parser.add_argument('--sum', dest='accumulate', action='store_const',
                        const=sum, default=max,
                        help='sum the integers (default: find the max)')
    args = parser.parse_args([1, 2, 3, 4])

    # Now the tests begin. There are 5 types of tests.
    # 1.  Testing for the still existance of the original type of the parameter.
    #

# Generated at 2022-06-11 17:48:22.558912
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('-a', '--arg_mapping', type=dict, default={})
    parser.add_argument('-s', '--arg_set', type=set, default={})
    parser.add_argument('-l', '--arg_list', type=set, default=[])

    args = parser.parse_args([])
    cli_args = GlobalCLIArgs.from_options(args)

    # Test that it is an abc.Mapping (which is an abstract class)
    cli_args.pop('arg_list', None)
    assert isinstance(cli_args, Mapping)
    cli_args.pop('arg_set', None)
    cli_args.pop('arg_mapping', None)

# Generated at 2022-06-11 17:48:26.812710
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestX(object):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            self.attribute = None

    class TestY(TestX):
        def __init__(self):
            self.attribute = 1

    assert TestX().attribute is None
    assert TestY().attribute == 1

# Generated at 2022-06-11 17:48:35.430084
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.parsing.dataloader import DataLoader
    dataloader = DataLoader()
    from ansible.playbook.play_context import PlayContext
    play_context = PlayContext()
    play_context.update_vault_secrets = False
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    inventory = InventoryManager(loader=dataloader, sources=['localhost'])
    variable_manager = VariableManager(loader=dataloader, inventory=inventory)

# Generated at 2022-06-11 17:48:40.565831
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils.common.collections import OrderedDict

    class NewOrderedDict(OrderedDict):
        __metaclass__ = _ABCSingleton
        pass

    a = NewOrderedDict()
    b = NewOrderedDict()
    assert a is b

# Generated at 2022-06-11 17:48:44.003786
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import optparse

    parser = optparse.OptionParser()
    parser.add_option('-l', '--limit', dest='limit', action='store', help='limit')
    (options, args) = parser.parse_args([])
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-11 17:48:55.047538
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    dict_obj = dict(
        boolean=True,
        list=['a', 'b', 'c'],
        dict={'a': 'a', 'b': 'b', 'c': 'c'},
        int=5,
        string='test',
        tuple=('a', 'b', 'c'),
        frozenset=frozenset(['a', 'b', 'c']),
    )
    cliargs_obj = CLIArgs(dict_obj)

    # Check the CLIArgs object is the same size as the input dict
    assert len(dict_obj) == len(cliargs_obj)

    # Check the attributes in the CLIArgs object are the same as the input dict
    for key, value in cliargs_obj.items():
        assert value == dict_obj[key]

    # Check the CLIArgs object

# Generated at 2022-06-11 17:48:57.124824
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton):
        pass

    f = Foo()
    assert type(f) == Foo

# Generated at 2022-06-11 17:49:00.592962
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SomeABCClass(metaclass=_ABCSingleton):
        pass

    instance_1 = SomeABCClass()
    instance_2 = SomeABCClass()
    assert instance_1 is instance_2

# Generated at 2022-06-11 17:49:03.997944
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    result = CLIArgs({'asd': {'fgh': [1, 2, 'asdf']}})
    assert result['asd']['fgh'][2] == 'asdf'

# Generated at 2022-06-11 17:49:13.068309
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import os
    import sys
    try:
        # NOTE: fixes coverage to double cover
        #       each import in `__init__.py`
        from ansible.cli import CLI
        from ansible.config.manager import ConfigManager, ensure_type
    except ImportError:
        ansible_dir = os.path.dirname(os.path.dirname(__file__))
        sys.path.append(ansible_dir)
        from ansible.cli import CLI
        from ansible.config.manager import ConfigManager, ensure_type


# Generated at 2022-06-11 17:49:23.857749
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Make sure we can construct ABCSingleton correctly"""
    assert not issubclass(_ABCSingleton, ABCMeta)
    class MySingleton(object):
        __metaclass__ = _ABCSingleton
    assert issubclass(MySingleton, _ABCSingleton)
    assert issubclass(MySingleton, ABCMeta)



# Generated at 2022-06-11 17:49:28.862179
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    globals_cli_args = GlobalCLIArgs({'ansible-config': None, 'vault-password-file': 'dummy_file'})
    assert globals_cli_args.get('ansible-config') is None
    assert globals_cli_args.get('vault-password-file') == 'dummy_file'

# Generated at 2022-06-11 17:49:36.595034
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.config.manager import ConfigManager     # This is a relative import to avoid circular import problems.

    # mock up the options structure that's compatible with that class
    options = type('Options', (object,), {'config': 'config.cfg'})

    # call the constructor and see what it produces
    cli_args = GlobalCLIArgs.from_options(options)

    # check that the result has the right properties
    assert cli_args is not None
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args, GlobalCLIArgs)
    assert isinstance(cli_args, CLIArgs)
    assert 'config' in cli_args

# Generated at 2022-06-11 17:49:39.900379
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class First(object):
        __metaclass__ = _ABCSingleton

    class Second(object):
        __metaclass__ = _ABCSingleton

    assert First is Second


# Generated at 2022-06-11 17:49:44.484515
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    class Bar(Foo):
        pass

    a = Foo()
    b = Foo()
    assert a is b
    #  Make sure this wasnt' a Singleton only, but that we also have an ABCMeta based class
    assert Foo()
    assert Bar()



# Generated at 2022-06-11 17:49:49.771953
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _TestSingletonA(object):
        __metaclass__ = _ABCSingleton

    class _TestSingletonB(object):
        __metaclass__ = _ABCSingleton

    class _TestSingletonC(_TestSingletonA, _TestSingletonB):
        pass

    assert _TestSingletonA() is _TestSingletonA()
    assert _TestSingletonB() is _TestSingletonB()
    assert _TestSingletonC() is _TestSingletonC()

test__ABCSingleton()

# Generated at 2022-06-11 17:50:00.585904
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    class TestOptions(collections.Mapping):
        def __init__(self, d):
            super(TestOptions, self).__init__()
            self.d = d
            self.freeze()
        def __getitem__(self, key):
            return self.d[key]
        def __iter__(self):
            return iter(self.d)
        def __len__(self):
            return len(self.d)
        def freeze(self):
            for key, value in self.d.items():
                if isinstance(value, collections.MutableSequence):
                    value = tuple(value)
                elif isinstance(value, collections.MutableSet):
                    value = frozenset(value)
                elif isinstance(value, collections.MutableMapping):
                    self.d

# Generated at 2022-06-11 17:50:12.867373
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.utils import context_objects as co
    import copy
    import json

    # Build some nested dicts to throw at the constructor
    test_data = {'int': 12345, 'str': 'aString', 'list': ['a', 'list']}
    test_data = {'nested': test_data}
    test_data = {'nested': test_data}
    test_data = {'nested': test_data}
    test_data = {'nested': test_data}
    test_data = {'nested': test_data}

    # Make a copy because the constructor will mutate the data
    test_data_copy = copy.deepcopy(test_data)

    # Try the constructor with a normal dict
   

# Generated at 2022-06-11 17:50:18.806108
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    a = {'a': 1, 'b': 2, 'c': {'d': 1, 'e': [1, 2, 3]}}
    b = CLIArgs(a)
    b['a'] = 3
    b['c']['e'][1] = 5

    assert b['c']['e'][1] == 5
    assert a['c']['e'][1] == 5

# Generated at 2022-06-11 17:50:21.394673
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Make sure we can instantiate _ABCSingleton
    """
    class TestClass(object):
        __metaclass__ = _ABCSingleton
        a = 'test'

    assert TestClass() is TestClass()

# Generated at 2022-06-11 17:50:41.811525
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import ansible.module_utils.common.argparse as argparse

    test_dict = {'boolean_value': True,
                 'list_value': '1,2',
                 'mapping_value': 'key:val',
                 'sequence_value': '1,2,3',
                 'set_value': '1,2,3',
                 'string_value': 'value',
                 }

    class Parser(object):
        def __init__(self, defaults=None):
            self.defaults = defaults

    options = argparse.Values(test_dict)
    args = GlobalCLIArgs.from_options(options)
    assert args.boolean_value == True
    assert args.list_value == ['1', '2']
    assert args.mapping_value == {'key': 'val'}


# Generated at 2022-06-11 17:50:48.757742
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Test _ABCSingleton class"""

    class TestSingleton(_ABCSingleton):
        __slots__ = _ABCSingleton.__slots__ + ('foo',)

        def __init__(self, foo):
            assert self.foo is None
            self.foo = foo

    t1 = TestSingleton(1)
    assert t1.foo == 1
    t2 = TestSingleton(2)
    assert t2.foo == 1
    assert t2 is t1

# Generated at 2022-06-11 17:50:53.640078
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():  # pylint: disable=invalid-name
    from ansible.module_utils.common._collections_compat import Mapping

    assert isinstance(GlobalCLIArgs(), Mapping), "GlobalCLIArgs did not return Mapping"
    assert isinstance(GlobalCLIArgs(), ImmutableDict), "GlobalCLIArgs did not return ImmutableDict"

# Generated at 2022-06-11 17:51:04.520217
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Create an ABCMeta based class and instantiate it
    class Example_ABCMeta(object):
        __metaclass__ = ABCMeta

        @abstractmethod
        def something(self):
            pass

        def something_else(self):
            pass

    a = Example_ABCMeta()

    # Create a Singleton based class and instantiate it
    class Example_Singleton(object):
        __metaclass__ = Singleton

        def something_else(self):
            pass

    b = Example_Singleton()

    # Create an _ABCSingleton based class and instantiate it
    class Example_ABCSingleton(object):
        __metaclass__ = _ABCSingleton

        def something_else(self):
            pass

    c = Example_ABCSingleton()

    # Verify that the metaclasses are distinct
    assert ABCMeta

# Generated at 2022-06-11 17:51:07.809592
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(A):
        pass

    class C(A):
        pass

# Generated at 2022-06-11 17:51:13.483964
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    input_dict = {'a': '1', 'b': ['2', '3'], 'c': {'d': '4'}}
    expected_output_dict = {'a': '1', 'b': ('2', '3'), 'c': ImmutableDict({'d': '4'})}
    cli_args = CLIArgs(input_dict)

    assert cli_args == expected_output_dict

# Generated at 2022-06-11 17:51:17.251849
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    class E(A):
        pass

# Test case for the constructor of class CLIArgs

# Generated at 2022-06-11 17:51:20.466472
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():  # pragma: no cover
    class _Test(_ABCSingleton):
        pass

    try:
        _Test()
    except TypeError:
        raise AssertionError("Failed constructing a Singleton using _ABCSingleton")

# Generated at 2022-06-11 17:51:22.803346
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
        pass

    class B(A):
        pass

    A()
    B()

# Generated at 2022-06-11 17:51:34.045314
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Unit test for CLIArgs and its related methods
    """
    cli_args = {'a': True, 'b': False, 'c': 'hello', 'd': ['one', 'two', 'three'], 'e': {'one': 1, 'two': 2},
                'f': set(['one', 2]), 'g': ('my item', 'my second item')}

    cli_args_copy = cli_args.copy()
    cli_args_obj = CLIArgs(cli_args)
    assert isinstance(cli_args_obj, Container)
    # The constructor actually makes a copy of the passed-in dict
    assert cli_args_obj != cli_args
    # The constructor recursively calls its _make_immutable method on all the variables in the dict
    # so the dict and all its

# Generated at 2022-06-11 17:51:59.392241
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyABCSingleton(GlobalCLIArgs):
        """ A test class """
        pass
    assert issubclass(MyABCSingleton, GlobalCLIArgs)

# Generated at 2022-06-11 17:52:01.206103
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Simple test to prove this class has the same interface as CLIArgs
    assert isinstance(GlobalCLIArgs({"foo": "bar"}), GlobalCLIArgs)

# Generated at 2022-06-11 17:52:03.091112
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(metaclass=_ABCSingleton):
        pass

    Test()

# Generated at 2022-06-11 17:52:11.892980
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Valid CLI args, field 'tags' has a list value
    args = CLIArgs({ 'tags' : ['foo', 'bar']})
    assert isinstance(args['tags'], tuple)

    # Valid CLI args, field 'tags' has a string value
    args = CLIArgs({'tags' : 'foo'})
    assert isinstance(args['tags'], text_type)

    # Valid CLI args, field 'tags' has a frozenset value
    args = CLIArgs({'tags' : frozenset(['foo', 'bar'])})
    assert isinstance(args['tags'], frozenset)

# Generated at 2022-06-11 17:52:14.277789
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class singleton(metaclass=_ABCSingleton):
        pass

    s = singleton()
    ss = singleton()
    assert s == ss


# Generated at 2022-06-11 17:52:20.322762
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass
    x = A()
    assert x is A()
    x = B()
    assert x is B()
    assert x is A()
    assert x is C()
    assert x is not B()

# Generated at 2022-06-11 17:52:24.849111
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs(Container())
    assert isinstance(cli_args, CLIArgs)
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args, Mapping)
    assert isinstance(cli_args, Container)
    assert isinstance(cli_args, object)

# Generated at 2022-06-11 17:52:34.563757
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        pass

    o = Options()
    o.connection = "fake_connection"
    o.module_path = "fake_module_path"
    o.force_handlers = True
    o.tags = ["tag_one"]
    o.skip_tags = ["skip_one"]

    global_cli_args = GlobalCLIArgs.from_options(o)

    assert isinstance(global_cli_args, CLIArgs)
    assert isinstance(global_cli_args, GlobalCLIArgs)
    assert global_cli_args["connection"] == "fake_connection"
    assert global_cli_args["module_path"] == "fake_module_path"
    assert global_cli_args["force_handlers"] == True
    assert global_cli_args["tags"] == ["tag_one"]
   

# Generated at 2022-06-11 17:52:42.102056
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # toplevel dict
    assert isinstance(CLIArgs({'a': 1}), ImmutableDict)

    # child dict
    assert isinstance(CLIArgs({'a': {'b': 'c'}}), ImmutableDict)
    assert isinstance(CLIArgs({'a': {'b': 'c'}})['a'], ImmutableDict)

    # grandchild dict
    assert isinstance(CLIArgs({'a': {'b': 'c', 'd': {'e': 'f'}}}), ImmutableDict)
    assert isinstance(CLIArgs({'a': {'b': 'c', 'd': {'e': 'f'}}}), ImmutableDict)

# Generated at 2022-06-11 17:52:52.786079
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import unittest

    class TestGlobalCLIArgs(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_init(self):
            x = GlobalCLIArgs(dict(a=1, b=2))
            self.assertEqual(x, dict(a=1, b=2))

        def test_add_item(self):
            x = GlobalCLIArgs(dict(a=1, b=2))
            with self.assertRaises(AttributeError):
                x['c'] = 3

        def test_change_item(self):
            x = GlobalCLIArgs(dict(a=1, b=2))
            with self.assertRaises(AttributeError):
                x['a'] = 3


# Generated at 2022-06-11 17:53:43.310527
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs(dict(foo='bar'))
    return global_cli_args

# vim: ai ts=4 sw=4 et sts=4 ft=python

# Generated at 2022-06-11 17:53:53.044839
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Unit test for constructor of class CLIArgs"""
    cli_args = {u'a_list': [1, 2, 3], u'something_else': 3, u'a_dict': {u'a': 1, u'b': u'x'}, u'a_set': {1, 2, 3}}
    cli_args_immutable = CLIArgs(cli_args)
    assert isinstance(cli_args_immutable, ImmutableDict)
    assert isinstance(cli_args_immutable[u'a_list'], tuple)
    assert isinstance(cli_args_immutable[u'something_else'], int)
    assert isinstance(cli_args_immutable[u'a_dict'], ImmutableDict)

# Generated at 2022-06-11 17:53:56.163714
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_dict = dict(foo=dict(bar='baz'))
    cli_args = GlobalCLIArgs(test_dict)
    assert cli_args == ImmutableDict(test_dict)
    assert cli_args is not test_dict

# Generated at 2022-06-11 17:54:03.692488
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SomeAbstractClass(object):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            super(SomeAbstractClass, self).__init__()

    class ConcreteClassOne(SomeAbstractClass):
        def __init__(self):
            super(ConcreteClassOne, self).__init__()

    class ConcreteClassTwo(SomeAbstractClass):
        def __init__(self):
            super(ConcreteClassTwo, self).__init__()

    ConcreteClassOne()
    ConcreteClassTwo()

# Generated at 2022-06-11 17:54:05.363892
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({'a': {'b': 'c'}})
    assert isinstance(args, CLIArgs)



# Generated at 2022-06-11 17:54:07.065178
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ConcreteCLIArgs(GlobalCLIArgs):
        pass
    ConcreteCLIArgs()
    ConcreteCLIArgs()

# Generated at 2022-06-11 17:54:11.253466
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
        def __init__(self):
            self.x = 1
    a = A()
    assert a.x == 1
    a = A()
    assert a.x == 1

# Generated at 2022-06-11 17:54:14.463666
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    A()
    # Do it twice to check for a bug found in Python 3.4.1
    A()

# Generated at 2022-06-11 17:54:24.711910
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils.common.text.converters import to_bytes
    class ABCSingletonTestClass1(object):
        __metaclass__ = _ABCSingleton
    class ABCSingletonTestClass2(object):
        __metaclass__ = _ABCSingleton
    class ABCSingletonTestClass3(object):
        __metaclass__ = _ABCSingleton
    class ABCSingletonTestClass4(ABCSingletonTestClass1, ABCSingletonTestClass2):
        pass
    class ABCSingletonTestClass5(ABCSingletonTestClass1, ABCSingletonTestClass2):
        pass
    class ABCSingletonTestClass6(ABCSingletonTestClass1, ABCSingletonTestClass2, ABCSingletonTestClass3):
        pass

# Generated at 2022-06-11 17:54:33.877232
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'key1': 'value1', 'key2': {'foo': 'bar'}, 'key3': ['baz', {'foo': 'bar'}], 'key4': set(['bar', 'foo']), 'key5': ('bar', 'foo')}
    cliargs = CLIArgs(mapping)
    assert cliargs == mapping
    assert isinstance(cliargs, ImmutableDict)
    assert isinstance(cliargs.key2, ImmutableDict)
    assert isinstance(cliargs.key3[1], ImmutableDict)
    assert isinstance(cliargs.key4, frozenset)
    assert isinstance(cliargs.key5, tuple)