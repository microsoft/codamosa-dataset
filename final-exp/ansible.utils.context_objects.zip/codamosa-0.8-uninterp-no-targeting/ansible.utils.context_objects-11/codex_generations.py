

# Generated at 2022-06-21 08:22:16.976882
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    # argparse.ArgumentParser() returns:
    #   <ArgumentParser (prog=None, usage=None, description=None, version=None, formatter_class=<class 'argparse.HelpFormatter'>, conflict_handler='error', add_help=True)>
    # print(type(GlobalCLIArgs()))
    #   <class 'ansible.module_utils.common.arg_opts.GlobalCLIArgs'>
    # print(GlobalCLIArgs())
    #   GlobalCLIArgs({'activity': None, 'conditional': 'False', 'diff': None, 'force': 'False', 'gathering': 'smart', 'module_name': None, 'module_path': None, 'new_vault_password_file': None, 'original_baseline': None, 'output

# Generated at 2022-06-21 08:22:18.490774
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        pass
    assert Foo.__metaclass__ is type

# Generated at 2022-06-21 08:22:22.059464
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Base(object):
        __metaclass__ = _ABCSingleton
        def foo(self):
            pass

    class Derived(Base):
        def bar(self):
            pass

    # for coverage
    isinstance(Derived, Container)

# Generated at 2022-06-21 08:22:27.865939
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Run a unit test against the class
    """
    d = {'a': {'b': set(['1', '2', '3']), 'c': ['4']}, 'b': '7'}
    d = CLIArgs(d)
    print(d['a']['b'])
    d['a']['b'].add('5')
    print(d['a']['b'])

# Generated at 2022-06-21 08:22:38.539755
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    global_vars = dict(
        ansible_connection='ssh',
        ansible_user='user1',
        ansible_ssh_pass='pass1',
        ansible_become_pass='pass2',
        ansible_ssh_private_key_file='private.key',
        ansible_become=True,
        ansible_become_user='user2',
        ansible_become_method='sudo',
    )
    cli_args = CLIArgs(global_vars)
    assert id(cli_args) != id(global_vars)
    assert cli_args.get('connection') == 'ssh'
    assert cli_args.get('become_pass') == 'pass2'
    assert cli_args.get('j') is None


# Generated at 2022-06-21 08:22:45.254201
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    data = dict(
        foo=1,
        bar=dict(
            baz=dict(
                bat=2,
            )
        )
    )
    cliargs = CLIArgs(data)

    assert cliargs['foo'] == data['foo']
    assert cliargs['bar']['baz']['bat'] == data['bar']['baz']['bat']

# Generated at 2022-06-21 08:22:56.643701
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import copy
    import ansible.module_utils.common.args as args
    import ansible.module_utils.common.collections as collections

    def helper(options):
        return args._CLIArgs.from_options(options)

    # Can't use isinstance on this because it doesn't work on metaclasses
    assert issubclass(helper(args.Options()).__class__, collections.ImmutableDict)

    opt = args.Options()
    opt.become = True
    opt.become_user = "bob"
    opt.listhosts = True
    opt.listtasks = True
    opt.syntax = True
    opt.tags = ['update', 'config']
    opt.skip_tags = ['untagged']

    # Two tests for each option to test both the actual data type

# Generated at 2022-06-21 08:23:04.006333
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    assert "A" == A().__class__.__name__
    with pytest.raises(RuntimeError):
        A()
    assert "B" == B().__class__.__name__
    with pytest.raises(RuntimeError):
        B()
    assert "A" == B().get_class_name()
    assert "B" == B().get_class_name(B())

# Generated at 2022-06-21 08:23:04.922743
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({
        'foo': 'bar',
        'baz': 'qux',
    })

# Generated at 2022-06-21 08:23:12.661262
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Test the construction of a CLIArgs object."""
    args = CLIArgs({'a': 1, 'b': ['1', '2', '3'], 'c': {'d': '4', 'e': 5}, 'f': {'1', '2', '3'}})
    assert isinstance(args['a'], int)
    assert args['a'] == 1
    assert isinstance(args['b'], tuple)
    assert isinstance(args['b'][0], text_type)
    assert isinstance(args['c'], ImmutableDict)
    assert isinstance(args['f'], frozenset)
    assert args['f'] == frozenset({'3', '2', '1'})



# Generated at 2022-06-21 08:23:21.979532
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():  # pylint: disable=too-few-public-methods
    """
    Test the _ABCSingleton class method
    """

    class CustomClass(metaclass=_ABCSingleton):
        pass

    class NewClass(metaclass=_ABCSingleton):
        pass

    first_obj = CustomClass()
    second_obj = NewClass()

    assert first_obj == second_obj


if __name__ == '__main__':
    test__ABCSingleton()

# Generated at 2022-06-21 08:23:26.461670
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    # Checking if Singleton is a super class of _ABCSingleton
    assert issubclass(A, Singleton)

    # Checking if ABCMeta is a super class of _ABCSingleton
    assert issubclass(A, ABCMeta)



# Generated at 2022-06-21 08:23:35.624186
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils.common.parameters import OptionValidator

    class test1(OptionValidator):
        def __init__(self, *args):
            super(test1, self).__init__(*args)

    class test2(OptionValidator):
        def __init__(self, *args):
            super(test2, self).__init__(*args)

    assert test1(1) is test1(1)
    assert test2(2) is test2(2)
    assert not test1(1) is test2(1)

# Generated at 2022-06-21 08:23:37.515945
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs(dict())
    assert isinstance(args, ImmutableDict)

# Generated at 2022-06-21 08:23:39.904872
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({'a': {'b': [{'c': 3}]}})

# Generated at 2022-06-21 08:23:42.358436
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Make sure GlobalCLIArgs is able to be instantiated
    """
    obj = GlobalCLIArgs({})


# Generated at 2022-06-21 08:23:47.850402
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = {'check': True, 'extra_vars': [], 'help': True, 'listhosts': False, 'listtags': False}
    options = type('FakeOptions', (), args)

    actual = GlobalCLIArgs.from_options(options)
    for key in args:
        assert actual[key] == args[key]

# Generated at 2022-06-21 08:23:57.040926
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():  # pylint: disable=too-many-public-methods
    """
    Unit test for constructor of class _ABCSingleton

    Ensure that Singleton and ABCMeta work together as expected

    """
    # ensure that each time we create a class based on _ABCSingleton, we get a new instance of that
    # class
    assert type(dict) is not type(ImmutableDict)
    assert type(dict) is not type(CLIArgs)
    assert type(dict) is not type(GlobalCLIArgs)
    assert type(ImmutableDict) is not type(CLIArgs)
    assert type(ImmutableDict) is not type(GlobalCLIArgs)
    assert type(CLIArgs) is not type(GlobalCLIArgs)

    # ensure that classes which use _ABCSingleton as a metaclass have the expected attributes and

# Generated at 2022-06-21 08:23:59.589385
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    try:
        class A(GlobalCLIArgs):
            pass
        raise AssertionError("Must raise TypeError with ABCSingleton")
    except TypeError:
        pass

# Generated at 2022-06-21 08:24:04.495118
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.args import parse_cli_args

    parser = parse_cli_args()
    args = parser.parse_args(["--version"])
    args = vars(args)
    GlobalCLIArgs(args)
    GlobalCLIArgs(args)

# Generated at 2022-06-21 08:24:09.192783
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class TestClass(object):
        __metaclass__ = _ABCSingleton

    class TestChildClass(TestClass):
        pass



# Generated at 2022-06-21 08:24:15.845493
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    x = _ABCSingleton()
    y = _ABCSingleton()
    assert x == y
    assert x is y
    # These should raise TypeError to show that the metaclass works
    with pytest.raises(TypeError):
        class F(metaclass=_ABCSingleton):
            __slots__ = 'a'
    with pytest.raises(TypeError):
        class G(metaclass=_ABCSingleton):
            __slots__ = 'a'


# Generated at 2022-06-21 08:24:23.993844
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import datetime
    class A(object):
        pass
    # test 1
    d = {
        'a': 'a',
        'b': datetime.date(2018, 12, 23),
        'c': {
            '1': 'c1',
            '2': [
                'a',
                'b'
            ]
        },
        'd': [
            'a',
            'b'
        ]
    }
    a = GlobalCLIArgs(d)
    assert a.a == 'a'
    assert a.b == datetime.date(2018, 12, 23)
    assert a.c.get('1') == 'c1'
    assert a.c.get('2')[0] == 'a'
    assert a.c.get('2')[1] == 'b'


# Generated at 2022-06-21 08:24:25.545374
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    cliargs = GlobalCLIArgs.from_options(options)

# Generated at 2022-06-21 08:24:37.252476
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args_dict = dict()
    r1 = dict(mode='incremental', secret_key='123')
    r2 = dict(weight=80, gender='female')
    cli_args_dict['host'] = 'www.ansible.com',
    cli_args_dict['stats'] = r1
    cli_args_dict['info'] = r2
    cli_args_dict['discovery'] = 'list'
    cli_args = CLIArgs(cli_args_dict)

    assert isinstance(cli_args['stats'], ImmutableDict)
    assert isinstance(cli_args['info'], ImmutableDict)
    assert isinstance(cli_args['host'], tuple)
    assert isinstance(cli_args['discovery'], text_type)



# Generated at 2022-06-21 08:24:47.142085
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from tempfile import mkdtemp
    from ansible.module_utils.common._collections_compat import MutableMapping

    class MyMutex(MutableMapping):
        def __init__(self, *args):
            pass

        def lock(self):
            pass

        def unlock(self):
            pass

        def __getitem__(self, key):
            pass

        def __setitem__(self, key, value):
            pass

        def __delitem__(self, key):
            pass

        def __iter__(self):
            pass

        def __len__(self):
            pass

    # test for singleton
    class A(MyMutex):
        pass


# Generated at 2022-06-21 08:24:49.038185
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(_ABCSingleton):
        pass

    x = A()
    y = A()

    assert x is y

# Generated at 2022-06-21 08:24:56.717858
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        pass
    options = Options()
    options.user = "Bob"
    options.passwords = ['cat', 'dog', 'mouse']
    options.ansible_hello = ['world', 'foo', 'bar']

    cli_args = CLIArgs.from_options(options)

    assert cli_args["user"] == "Bob"
    assert cli_args["passwords"] == ("cat", "dog", "mouse")
    assert cli_args["ansible_hello"] ==  ("world", "foo", "bar")

# Generated at 2022-06-21 08:25:02.259200
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object, metaclass=_ABCSingleton):
        pass

    assert isinstance(Foo.__subclasses__(), Sequence) and len(Foo.__subclasses__()) == 0
    class Bar(Foo):
        pass
    assert isinstance(Foo.__subclasses__(), Sequence) and len(Foo.__subclasses__()) == 1



# Generated at 2022-06-21 08:25:09.627752
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    from ansible.utils.vars import combine_vars
    from ansible.cli import CLI, CLIANSIBLE
    from ansible.utils.plugins import PluginLoader
    from ansible.plugins.action import ActionModule

    parser = argparse.ArgumentParser(description="an argument parser for testing")
    parser.add_argument('-i', '--inventory',
                        type=str,
                        dest="inventory",
                        dest_list=["inventory"],
                        default=[],
                        action='append',
                        help="A file or directory containing Ansible inventory definitions")

# Generated at 2022-06-21 08:25:23.772688
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that all types convert to immutable
    test_dict = {
        'key0': {
            'key1': [
                'value1',
                'value2',
            ],
            'key2': {'key3': 'value3'},
        },
        'key4': 'value4',
        'key5': {
            'key6': set([
                1,
                2,
                3,
            ]),
            'key7': 'value7',
        },
        'key8': ('value8', 'value9'),
        'key9': set([
            1,
            2,
            3,
        ]),
        'key10': 'value10',
        'key11': [
            'value11',
            'value12',
        ]
    }
    cli_args = _

# Generated at 2022-06-21 08:25:30.012189
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    my_arg = CLIArgs({"foo": "bar", "baz": [{"bing": "bong"}, "foo"]})
    assert my_arg["foo"] == "bar"
    assert my_arg["baz"][0]["bing"] == "bong"
    assert my_arg["baz"][1] == "foo"


# Generated at 2022-06-21 08:25:37.945059
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    options = ImmutableDict({'s': ImmutableDict({'t': 'u'}), 'v': 'w', 'x': ('y', 'z')})
    args = CLIArgs(options)
    assert args == {'s': {'t': 'u'}, 'v': 'w', 'x': ('y', 'z')}
    assert args.s == {'t': 'u'}
    assert args.s.t == 'u'
    assert args.v == 'w'
    assert args.x == ('y', 'z')


# Test for constructor of class CLIArgs with nested MutableMapping objects

# Generated at 2022-06-21 08:25:40.846715
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options:
        def __init__(self, test):
            self.test = test

    GlobalCLIArgs.from_options(Options('value'))
    assert GlobalCLIArgs['test'] == 'value'

# Generated at 2022-06-21 08:25:48.832735
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import argparse
    arg_parser = argparse.ArgumentParser()
    arg_parser.add_argument('--foo', dest='foo', action='store_true')
    arg_parser.add_argument('--bar')
    arg_parser.add_argument('--baz')
    args = arg_parser.parse_args()
    imm_dict = CLIArgs.from_options(args)
    assert imm_dict['foo'] is True
    assert imm_dict['bar'] == 'None'
    assert imm_dict['baz'] == 'None'

# Generated at 2022-06-21 08:25:52.561283
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABC(object):
        __metaclass__ = _ABCSingleton

    class _A(_ABC):
        pass

    class _B(_ABC):
        pass

    _a = _A()
    _b = _B()
    assert _a  is _A()
    assert _b  is _B()
    assert _a is _b

# Generated at 2022-06-21 08:25:55.403058
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_input = {'foo': 'bar', 'a': {'b': 'c', 'd': {'e': 'f'}}, 'g': [{'h': 'i', 'j': ['k', 'l']}, {'m': 'n', 'o': ['p', 'q']}]}
    cli_args = CLIArgs(test_input)
    print(cli_args)

# Generated at 2022-06-21 08:26:06.925282
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import collections

    top_dict = {'key1': 'value1', 'key2': 2, 'key3': collections.OrderedDict([('key4', 3), ('key5', {'key6': 4})])}
    args1 = GlobalCLIArgs(top_dict)
    assert isinstance(args1, GlobalCLIArgs)
    assert isinstance(args1, ImmutableDict)

    args2 = GlobalCLIArgs(top_dict)
    assert args1 is args2

    assert args1['key3']['key5']['key6'] == 4

    with pytest.raises(TypeError):
        args1['key3']['key5']['key6'] = 5


# Generated at 2022-06-21 08:26:13.085485
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import types
    import doctest
    import sys
    import os

    # This is the default test module the python standard lib docs
    # suggest to use.  But the python version I cloned this from did
    # not have this module.  So we are just going to ignore the error
    # if the module doesn't exist.
    try:
        import test.test_doctest
    except ModuleNotFoundError:
        pass

    # Maximum number of failures before abandoning test
    # I believe the ansible default was 10 but that is too high for me
    # I want to catch the failing tests early and quickly, so I set this
    # to only allow one failing test before the test runner quits
    max_failures = 1

    # If the command line argument --test-module-docstrings is used,
    # then test all the docstrings in all

# Generated at 2022-06-21 08:26:20.551630
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Obj(object):
        def __init__(self, value):
            self.value = value
    my_dict = {
        'a_string': 'foo',
        'a_list': ['foo', {'first': 'bar', 'second': 'baz'}],
        'a_set': set(('one', 'two', 'three', 'four')),
        'an_object': Obj(42)
    }
    cli_args = CLIArgs(my_dict)

    assert isinstance(cli_args, ImmutableDict)
    assert cli_args.get('a_string') == 'foo'
    assert cli_args.get('a_list')[0] == 'foo'
    assert cli_args.get('a_list')[1].get('first') == 'bar'

# Generated at 2022-06-21 08:26:32.995818
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    A()
    B()

# Generated at 2022-06-21 08:26:40.231638
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Test that _ABCSingleton is a valid Singleton AND ABCMeta
    """
    class ABCSingletonTest1(object):
        """Test that _ABCSingleton can be used with a non-ABCMeta class"""
        __metaclass__ = _ABCSingleton

    class ABCSingletonTest2(object):
        """Test that _ABCSingleton can be used with an ABCMeta class"""
        __metaclass__ = _ABCSingleton
        __metaclass__ = ABCMeta

    class ABCSingletonTest3(object):
        """Test that the Singleton parent of _ABCSingleton can be used as a metaclass"""
        __metaclass__ = Singleton

    class ABCSingletonTest4(object):
        """Test that the Singleton parent of _ABCSingleton can be used with an ABCMeta class"""
        __metaclass

# Generated at 2022-06-21 08:26:52.430727
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs.clear_instance()
    inst = GlobalCLIArgs({'a': 1, 'b': {'c': 2, 'd': [3, 4], 'e': [5, {'f': 6}]}})
    assert inst['a'] == 1
    assert inst['b'].get('c', None) == 2
    assert inst['b'].get('d', None) == (3, 4)
    assert inst['b']['e'][0] == 5
    assert inst['b']['e'][1]['f'] == 6
    assert inst['b']['e'][1]['f'] == 6
    try:
        inst['b']['e'][1]['f'] = 7
    except TypeError:
        pass
    else:
        assert False

# Generated at 2022-06-21 08:27:01.301010
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import json
    import collections

    temp = {
        'a': 1,
        'b': [1, 2, [3, 4]],
        'c': {
            'd': {
                'e': [3, 4]
            },
            'f': 5,
            'g': [6, 7]
        }
    }
    new_temp = CLIArgs(temp)

    # make sure we have the same values
    assert new_temp == {'a': 1, 'b': (1, 2, (3, 4)), 'c': ImmutableDict(collections.OrderedDict([('d', ImmutableDict(collections.OrderedDict([('e', (3, 4))]))), ('f', 5), ('g', (6, 7))]))}

    # make sure we have immutable dicts

# Generated at 2022-06-21 08:27:09.449358
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.inventory.manager import InventoryManager

    class Foo:
        pass

    class Bar(Foo, metaclass=_ABCSingleton):
        pass

    class Baz(InventoryManager, metaclass=_ABCSingleton):
        pass

    class Qux(AnsibleCollectionLoader, metaclass=_ABCSingleton):
        pass

    assert Foo.__abstractmethods__ is None
    assert Bar.__abstractmethods__ is None
    assert Baz.__abstractmethods__ is None
    assert Qux.__abstractmethods__ is None

    assert Foo.__subclasshook__(Bar)
    assert Bar.__subclasshook__(Bar)
    assert Baz.__subclasshook__(Bar)

    assert AnsibleCollectionLoader

# Generated at 2022-06-21 08:27:12.266668
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Verify constructor for GlobalCLIArgs
    """
    mapping = dict()
    GlobalCLIArgs(mapping)

# Generated at 2022-06-21 08:27:13.798723
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = GlobalCLIArgs()
    c = GlobalCLIArgs()
    assert a is c
    assert len(a) == 0


# Generated at 2022-06-21 08:27:17.587915
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    sys.modules['ansible'] = type('ansible', (), {})
    t1 = GlobalCLIArgs({"a": "b"})
    t2 = GlobalCLIArgs({"a": "b"})
    assert t1 is t2

# Generated at 2022-06-21 08:27:21.787414
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils.six import with_metaclass

    class One(with_metaclass(_ABCSingleton)):
        pass

    class Two(One):
        pass

    class Three(Two):
        pass

    assert One() is One()
    assert Two() is Two()
    assert Three() is Three()



# Generated at 2022-06-21 08:27:32.730986
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    import argparse
    parser = argparse.ArgumentParser(description='GlobalCLIArgs test')
    parser.add_argument('--hello', default='default_hello', type=str, help='Hello val')
    parser.add_argument('--goodbye', default='default_goodbye', type=str, help='Goodbye val')
    parsed_args = parser.parse_args()
    global_cli_args = GlobalCLIArgs(vars(parsed_args))
    assert is_immutable(global_cli_args)
    assert global_cli_args['hello'] == 'default_hello'
    assert global_cli_args['goodbye'] == 'default_goodbye'

# Generated at 2022-06-21 08:28:04.262946
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.plugins.loader import connection_loader, lookup_loader, module_loader, filter_loader
    from ansible import context
    import ansible.inventory.manager

    loader = DataLoader()
    inventory = ansible.inventory.manager.InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    context.CLIARGS = CLIArgs.from_options(context.CLIARGS)
   

# Generated at 2022-06-21 08:28:07.389053
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    inst = GlobalCLIArgs({'debug': 1})
    assert inst.raw_debug == 1
    assert inst.debug == True

if __name__ == '__main__':
    test_GlobalCLIArgs()

# Generated at 2022-06-21 08:28:11.967008
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import argparse
    a = argparse.ArgumentParser()
    a.add_argument('--foo', default=True, action='store_true')
    a.add_argument('--bar', default=False, action='store_false')

    args = a.parse_args([])
    cli_args = CLIArgs.from_options(args)
    assert cli_args.foo == True
    assert cli_args.bar == False

# Generated at 2022-06-21 08:28:25.330048
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from io import StringIO
    from ansible.module_utils.common.argparse import BasicParser
    from ansible.module_utils.common.argparse import BasicParserError
    parser = BasicParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar', action='append')
    string_io = StringIO()
    original_stdout = sys.stdout
    sys.stdout = string_io
    try:
        result = parser.parse_args(['--foo', 'baz', '--bar', 'spam', '--bar', 'eggs'])
    except BasicParserError:
        result = parser.parse_args(['--foo', 'baz', '--bar=spam', '--bar=eggs'])
    sys.stdout = original_stdout


# Generated at 2022-06-21 08:28:29.962666
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    obj = GlobalCLIArgs({})
    assert obj == GlobalCLIArgs({})
    assert obj is GlobalCLIArgs({})
    from ansible.module_utils.common._collections_compat import MutableMapping
    assert isinstance(obj, ImmutableDict)
    assert not isinstance(obj, MutableMapping)


# Generated at 2022-06-21 08:28:40.395240
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options:
        pass

    options = Options()
    options.verbosity = 4
    options.foo = 'bar'
    options.baz = ['a', 'b']
    options.meh = {'a': 1, 'b': 'c'}
    options.frooble = (1, 'foo', False)

    # regular assignment of the converted args, we get a mutable dictionary:
    cli_args = CLIArgs.from_options(options)
    assert isinstance(cli_args, ImmutableDict)
    assert len(cli_args) == 5
    assert cli_args['verbosity'] == 4
    assert cli_args['foo'] == 'bar'
    assert cli_args['baz'] == ('a', 'b')
    assert cli_args['meh'] == ImmutableD

# Generated at 2022-06-21 08:28:44.236519
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Test that we can initialize CLIArgs, and that it makes a ImmutableDict"""
    # Check that calling CLIArgs() doesn't error
    args = CLIArgs({'a': 'b'})
    # Check that we get back a ImmutableDict
    assert isinstance(args, ImmutableDict)


# Generated at 2022-06-21 08:28:56.530780
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test the constructor of class CLIArgs
    """

    dict1 = dict()
    dict1[b"Dog"] = 1
    dict1[b"Cat"] = 2
    dict1[b"Mouse"] = 4

    dict2 = dict()
    dict2[text_type("Dog")] = 2
    dict2[text_type("Cat")] = 5

    dict3 = dict()
    dict3[text_type("Dog")] = 1
    dict3[text_type("Cat")] = 2
    dict3[text_type("Mouse")] = 4

    list1 = [1, 2, 3]

    list2 = [dict1, dict2]

    dict4 = dict()
    dict4[text_type("Dog")] = list1

    dict5 = dict()

# Generated at 2022-06-21 08:28:58.566101
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.removed import removed
    removed('unittest CLIArgs')

# Generated at 2022-06-21 08:28:59.729420
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class NewClass(object):
        __metaclass__ = _ABCSingleton


# Generated at 2022-06-21 08:29:47.604576
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    class Bar(object):
        __metaclass__ = _ABCSingleton
        pass

    class Baz(object):
        __metaclass__ = _ABCSingleton

    a = Foo()
    b = Foo()

    assert a is b

    c = Bar()
    d = Bar()
    assert c is d

    e = Baz()
    f = Baz()
    assert e is f

# Generated at 2022-06-21 08:29:51.395266
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        v1 = 'foo'

    args = GlobalCLIArgs.from_options(Options())
    assert args._data == ImmutableDict(v1='foo')._data



# Generated at 2022-06-21 08:30:01.077864
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class options(object):
        pass

    opt = options()
    opt.ansible_python_interpreter = "/usr/bin/python"
    opt.verbosity = 5
    opt.diff = True
    opt.syntax = "ini"

    cliargs = CLIArgs.from_options(opt)

    # It's not a singleton
    assert cliargs is not GlobalCLIArgs()

    assert cliargs['ansible_python_interpreter'] == "/usr/bin/python"
    assert cliargs['verbosity'] == 5
    assert cliargs['diff'] is True
    assert cliargs['syntax'] == "ini"

# Generated at 2022-06-21 08:30:12.081679
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.basic import AnsibleModule
    args = {'ANSIBLE_VERSION': '2.10.1',
            'ANSIBLE_MODULE_ARGS': {},
            'ANSIBLE_MODULE_NAME': 'test_module'}
    module = AnsibleModule(argument_spec={})
    ansible_args = GlobalCLIArgs.from_options(module.ansible_options)

    if ansible_args['ANSIBLE_VERSION'] != args['ANSIBLE_VERSION']:
        raise Exception("ANSIBLE_VERSION not created properly")
    if ansible_args['ANSIBLE_MODULE_ARGS'] != args['ANSIBLE_MODULE_ARGS']:
        raise Exception("ANSIBLE_MODULE_ARGS not created properly")

# Generated at 2022-06-21 08:30:16.141045
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    assert 'ansible-test' in sys.argv[0]
    # This is an integration test because it makes sure that from_options() initializes the class
    # variable.  It is also a unit test because it only tests the constructor.
    GlobalCLIArgs.from_options(None)  # pylint: disable=no-member
    assert GlobalCLIArgs() is GlobalCLIArgs.get_instance()

# Generated at 2022-06-21 08:30:18.613878
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(TestClass(), TestClass)

# Generated at 2022-06-21 08:30:21.028343
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = GlobalCLIArgs.from_options(options)
    b = GlobalCLIArgs.from_options(options)
    assert a == b

# Generated at 2022-06-21 08:30:23.613420
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Test constructor of _ABCSingleton"""
    class _TestClass(_ABCSingleton):
        pass

    assert isinstance(_TestClass(), _TestClass)

# Generated at 2022-06-21 08:30:29.142694
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class MockOptions(object):
        def __init__(self):
            self.test_arg = ['argument_1', 'argument_2']

    options = MockOptions()
    global_cli_args = GlobalCLIArgs.from_options(options)

    assert isinstance(global_cli_args.test_arg, tuple)
    assert isinstance(global_cli_args.test_arg, Sequence)

# Generated at 2022-06-21 08:30:30.782405
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class S(_ABCSingleton):
        pass
    a = S()
    b = S()
    assert a is b

# Generated at 2022-06-21 08:31:58.169978
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(_ABCSingleton):
        pass
    assert A() is A()
    assert A() is not A()  # NOT a singleton.  Can't instantiate an abstract class.

# Generated at 2022-06-21 08:32:01.155104
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class X(object, metaclass=_ABCSingleton):
        pass

    class Y(X, metaclass=_ABCSingleton):
        pass

    X() == X()
    Y() == Y()
    X() == Y()