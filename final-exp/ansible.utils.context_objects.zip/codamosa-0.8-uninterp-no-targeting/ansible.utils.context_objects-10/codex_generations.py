

# Generated at 2022-06-21 08:22:19.627075
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Prepare the test data
    data_in = {
        'test_key_a': 'test_value_a',
        'test_key_b': {
            'test_key_c': 'test_value_c',
            'test_key_d': [
                'test_value_d',
                'test_value_e',
                ['test_value_f', 'test_value_g']
            ]
        },
        'test_key_h': {
            'test_key_i': 'test_value_i'
        }
    }
    # Instantiate the object to test
    ca = CLIArgs(data_in)
    # Test that the object is correctly converted
    # This can't be hashed
    assert isinstance(ca, ImmutableDict)

# Generated at 2022-06-21 08:22:23.636152
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    # Test building a subclass.
    class Test(_ABCSingleton):
        pass

    Test()  # Should not raise error.

    # Test building a subclass of the subclass.
    class Test2(Test):
        pass

    Test2()  # Should not raise error.

# Generated at 2022-06-21 08:22:26.686485
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert GlobalCLIArgs() is GlobalCLIArgs()
    assert GlobalCLIArgs({'foo': 'bar'}) is GlobalCLIArgs({'foo': 'bar'})

# Generated at 2022-06-21 08:22:28.110120
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(GlobalCLIArgs, ImmutableDict)

# Generated at 2022-06-21 08:22:34.930545
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Case of empty command line args
    assert isinstance(CLIArgs(dict()), CLIArgs)
    assert isinstance(CLIArgs.from_options(type(str('options'), (object,), {})()), CLIArgs)

    # Case of command line args that are containers
    test_dict = {'a': {'b': {'c': "d"}}}
    assert isinstance(CLIArgs(test_dict), CLIArgs)
    assert isinstance(CLIArgs.from_options(type(str('options'), (object,), test_dict)()), CLIArgs)
    # Case of command line args that are sequences
    test_dict = {'a': ["b", ["c"]]}
    assert isinstance(CLIArgs(test_dict), CLIArgs)

# Generated at 2022-06-21 08:22:37.948364
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() == B()

# Generated at 2022-06-21 08:22:44.272614
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        verbosity = 3
        tags = 'tag1,tag2'
        skip_tags = 'tag3,tag4'

    Glob = GlobalCLIArgs.from_options(Options)

    assert Glob['verbosity'] == 3
    assert 'verbosity' in Glob
    assert Glob['tags'] == 'tag1,tag2'
    assert 'foo' not in Glob

# Generated at 2022-06-21 08:22:55.698658
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    obj = CLIArgs( { "foo": 1, "bar": "2", "baz": ["3", ["4", "5"]], "tuple": (1,2,3), "dict": {"k1": 1, "k2": 2}, "set": set(["a", "b", "c"]) } )
    assert obj.foo == 1
    assert obj.bar == "2"
    assert obj.tuple == (1,2,3)
    assert obj.dict == { "k1": 1, "k2": 2 }
    assert obj.set == frozenset(["a", "b", "c"])
    assert obj.baz == ("3", ("4", "5"))

    assert type(obj.baz) == tuple
    assert type(obj.baz[0]) == str

# Generated at 2022-06-21 08:22:57.983222
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(A):
        pass

    assert B() is B()

# Generated at 2022-06-21 08:23:00.860821
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object):
        __metaclass__ = _ABCSingleton
        def __init__(self):
            self.val = 10

    assert (Test().val == Test().val)

# Generated at 2022-06-21 08:23:12.685508
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    import ansible.module_utils.basic


# Generated at 2022-06-21 08:23:22.326380
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = GlobalCLIArgs.from_options(options)
    cli_args = CLIArgs(cli_args)
    cli_args['become_user'] = 'testuser'
    assert cli_args['become_user'] == 'testuser'
    assert GlobalCLIArgs()['become_user'] == 'root'
    assert GlobalCLIArgs()['become_user'] == 'root'
    GlobalCLIArgs()['become_user'] = 'bob'
    assert GlobalCLIArgs()['become_user'] == 'root'

# Generated at 2022-06-21 08:23:25.753896
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _TestSingleton(object):
        __metaclass__ = _ABCSingleton

    assert _TestSingleton() is _TestSingleton()
    assert not issubclass(_TestSingleton, ABCMeta)

# Generated at 2022-06-21 08:23:33.573520
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cliargs = {'boolean': True, 'value': False, 'array': [1, 2, 3], 'string_array': ['a', 'b', 'c'],
               'mutable_array': [1, 2, 3], 'mutable_string_array': ['a', 'b', 'c'],
               'mutable_mapping': {'key1': 'string', 'key2': 'string'},
               'mutable_tuple': (1, 2, 3)}
    cliargs['mutable_array'][0] = 0
    cliargs['mutable_string_array'][0] = 'mutated'
    cliargs['mutable_mapping']['newkey'] = 'string'
    cliargs['mutable_tuple'] = (1, 2, 3, 4)

    immutable

# Generated at 2022-06-21 08:23:42.358602
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class TestClass(object):
        def __init__(self, arg1):
            self.arg1 = arg1

    # give toplevel values to the GlobalCLIArgs object
    toplevel = {'foo': [1, 2, 3], 'bar': 'baz', 'baz': TestClass("1")}
    GlobalCLIArgs(toplevel)

    assert GlobalCLIArgs.foo == (1, 2, 3)
    assert GlobalCLIArgs.bar == 'baz'
    assert GlobalCLIArgs.baz.arg1 == "1"



# Generated at 2022-06-21 08:23:54.377947
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    from ansible.module_utils.common.collections import is_immutable
    from collections import OrderedDict
    from ansible.module_utils._text import to_text

    args = {
        'opt1': 'val1',
        'opt2': 'val2',
        'opt_list': ['list1', 'list2'],
        'opt_dict': {'dict1': 'val1', 'dict2': 'val2'}
    }

    cli1 = GlobalCLIArgs(args)

    # Be sure the returned object is immutable
    assert is_immutable(cli1)

    # Be sure the individual strings in immutable structure returned are immutable
    assert is_immutable(cli1['opt1'])
    assert is_immutable(cli1['opt2'])

# Generated at 2022-06-21 08:23:55.444140
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    pass

# Generated at 2022-06-21 08:24:02.464671
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({}) == {}
    assert CLIArgs({'a': 1}) == {'a': 1}
    assert CLIArgs({'a': [1, 2, 3]}) == {'a': (1, 2, 3)}
    assert CLIArgs({'a': {'b': 7}}) == {'a': {'b': 7}}
    assert CLIArgs({'a': {'b': [1, 2, 3]}}) == {'a': {'b': (1, 2, 3)}}

# Generated at 2022-06-21 08:24:05.387273
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import types

    assert isinstance(GlobalCLIArgs(), CLIArgs)
    assert isinstance(GlobalCLIArgs(), types.ModuleType)


# Generated at 2022-06-21 08:24:15.944020
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that CLIArgs constructor creates an immutable dictionary type
    """
    test_dict = {'firstkey': 'firstvalue', 'secondkey': {'subkey': 'subvalue'}}
    test_args = CLIArgs(test_dict)

    # Test that we have a dictionary
    assert isinstance(test_args, dict)

    # Test that we get the correct values from the dictionary
    assert test_args['firstkey'] == 'firstvalue'
    assert test_args['secondkey']['subkey'] == 'subvalue'

    # Test that we can't change the values of the dictionary
    try:
        test_args['firstkey'] = 'not firstvalue'
        assert test_args['firstkey'] == 'not firstvalue'
    except TypeError:
        assert test_args['firstkey'] == 'firstvalue'



# Generated at 2022-06-21 08:24:21.333001
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("-a", action="store_true", default=False)
    parser.add_argument("-x", "--xxx", default="xxxx")
    test_global_cli_args = GlobalCLIArgs({'a': True, 'xxx': "yyyy"})

# Generated at 2022-06-21 08:24:28.190938
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # We need to create mock classes so we have new classes to instantiate.
    from types import SimpleNamespace as Namespace
    MockABCMeta = Namespace()
    MockABCMeta.__mro__ = (MockABCMeta,)
    MockSingleton = Namespace()
    MockSingleton.__mro__ = (MockSingleton,)

    class Temp(_ABCSingleton, MockABCMeta, MockSingleton):
        pass

    class Other(Temp):
        pass

    temp = Temp()
    assert Other() is temp

# Generated at 2022-06-21 08:24:39.980472
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import os
    import sys
    # If a file is given on the command line, Ansible expects it to be the inventory.
    CLIArgs.from_options(sys.__dict__)
    cli_args = CLIArgs.from_options(sys.__dict__)

# Generated at 2022-06-21 08:24:45.569775
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class MyOptions:
        pass

    my_opts = MyOptions()
    my_opts.become = True
    my_opts.become_method = 'sudo'
    my_opts.become_user = 'root'
    my_opts.connection = 'local'
    my_opts.become_flags = ['-S']

    GlobalCLIArgs.from_options(my_opts)


# Generated at 2022-06-21 08:24:49.869327
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.cli import CLI
    from ansible.playbook.play_context import PlayContext

    mock_cli = CLI(args=['--list-hosts'])
    loader = DataLoader()
    play_context = PlayContext(mock_cli, loader)
    # just simply test the constructor for now
    args = CLIArgs.from_options(mock_cli.options)
    assert isinstance(args, CLIArgs)

# Generated at 2022-06-21 08:25:00.634551
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    host_vars = {'var1': 'value1', 'var2': 'value2'}
    host_vars_patches = {'var1': 'value1_patch', 'var2': 'value2_patch'}
    groups = {'group1': {'hosts': ['host1'], 'vars': {'gvar1': 'gvalue1', 'gvar2': 'gvalue2'}},
              'group2': {'hosts': ['host2'], 'vars': {'gvar1': 'gvalue1', 'gvar2': 'gvalue2'}}}

# Generated at 2022-06-21 08:25:04.204365
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(with_metaclass(_ABCSingleton)):
        pass

    class B(with_metaclass(_ABCSingleton)):
        pass

    class C(A, B):
        pass

    assert A is C
    assert B is C



# Generated at 2022-06-21 08:25:11.211632
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Creating a new instance of the class CLIArgs with an empty mapping.
    my_args = CLIArgs({})
    # Mapping of the instance before calling the method _make_immutable
    assert my_args == {}, "The initialization of the class did not work as expected."
    # Creating a new instance of the class CLIArgs with a non-empty mapping.
    my_args = CLIArgs({"a": "b", 1: 2})
    # Mapping of the instance before calling the method _make_immutable
    assert my_args == {"a": "b", 1: 2}, "The initialization of the class did not work as expected."

# Generated at 2022-06-21 08:25:19.870936
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(six.with_metaclass(_ABCSingleton)):
        '''Foo'''
        def __init__(self, value):
            self.value = value

    class Bar(Foo):
        '''Bar'''
        def __init__(self, value):
            pass

    # even though Bar doesn't call super, because it's
    # an __ABCSingleton, it should still pass the test
    assert Foo(1) is Bar(2)

# Generated at 2022-06-21 08:25:22.330136
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(metaclass=_ABCSingleton):
        the_answer = 42

    assert Foo.the_answer == 42
    assert Foo().the_answer == 42
    assert Foo() is Foo()

# Generated at 2022-06-21 08:25:30.215376
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(metaclass=_ABCSingleton):
        def __init__(self, a):
            self.a = a

    assert(isinstance(TestClass(1), TestClass))

# Generated at 2022-06-21 08:25:33.451973
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    @add_metaclass(_ABCSingleton)
    class DummyClass(object):
        pass

    # Actual test from Singleton class
    class_one = DummyClass()
    class_two = DummyClass()
    assert class_two is class_one

# Generated at 2022-06-21 08:25:44.651341
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Unit test for constructor of class GlobalCLIArgs"""
    import sys
    import unittest
    import ansible.module_utils.common.arguments as arguments

    class TestGlobalCLIArgs(unittest.TestCase):
        """Test the CLIArgs class"""

        def setUp(self):
            self.old_argv = sys.argv
            # This part of the test is to get through parsing the command line options
            # and leave the args in a usable form
            sys.argv = ['ansible-playbook', '-i', 'hosts', 'play.yml']
            options = arguments.Options()
            options._parse()
            # Here we're actually testing the GlobalCLIArgs class
            self.args = GlobalCLIArgs.from_options(options)

        def tearDown(self):
            sys.arg

# Generated at 2022-06-21 08:25:53.949239
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest

    class GlobalCLIArgsTestCase(unittest.TestCase):
        def test_singleton(self):
            self.assertTrue(GlobalCLIArgs() is GlobalCLIArgs())

        def test_from_options(self):
            import ansible.module_utils.basic

            parser = ansible.module_utils.basic.AnsibleArgumentParser()

            parser.add_argument('-b', dest='b', action='store_true')
            parser.add_argument('-c', dest='c', type=int, default=42)
            parser.add_argument('--debug', dest='debug', action='store_true')
            parser.add_argument('-e', dest='e', type=str, default='no')

# Generated at 2022-06-21 08:26:05.490556
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs.from_options(cli_options)
    assert isinstance(args, ImmutableDict)
    assert args.get('connection') is None
    assert args.get('inventory') is None
    assert args.get('module_path') is None
    assert args.get('verbosity') == 0
    assert args.get('yaml_lint') is False
    assert args.get('skip_file_validation') is False
    assert args.get('skip_tag_validation') is False
    assert args.get('extra_vars') == ()
    assert args.get('subset') is None
    assert args.get('private_key_file') is None
    assert args.get('timeout') is None
    assert args.get('remote_user') is None
    assert args.get('check') is False

# Generated at 2022-06-21 08:26:10.945453
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Unit test for the constructor of class GlobalCLIArgs"""
    local_args = {}
    local_args['no_log'] = True
    local_args['password'] = 'password'
    local_args['tags'] = ['tag1']
    global_args = GlobalCLIArgs(local_args)
    assert global_args['no_log'] == True
    assert global_args['password'] == 'password'
    assert global_args['tags'] == ['tag1']
    #test _make_immutable()
    assert isinstance(global_args['tags'], (text_type, binary_type, Set, Sequence, Mapping))

# Generated at 2022-06-21 08:26:15.652446
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 'alpha', 'b': 'beta', 'c': 'charlie', 'd': 'delta'})
    assert args['a'] == 'alpha'
    assert args['b'] == 'beta'
    assert args['c'] == 'charlie'
    assert args['d'] == 'delta'


# Generated at 2022-06-21 08:26:19.738789
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    try:
        GlobalCLIArgs.from_options({"a": 1, "b": "test", "c": [1, 2, 3], "d": {"e": 1, "f": "test"}})
    except Exception as e:
        assert False, "constructor of GlobalCLIArgs failed: %s" % e

# Generated at 2022-06-21 08:26:22.787383
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import os

    # Test creation of CLIArgs object
    c = CLIArgs({
        'test' : os.path.expanduser('~')
    })
    assert isinstance(c, CLIArgs)



# Generated at 2022-06-21 08:26:33.814437
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    from ansible.parsing.dataloader import DataLoader

    class Options(object):
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class Play(object):
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class Task(object):
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)


# Generated at 2022-06-21 08:26:48.148628
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    c = CLIArgs({'a': 1, 'b': {'a': 1, 'b': 2, 'c': (1, 2, 3)}})
    assert isinstance(c, CLIArgs)
    assert not isinstance(c, GlobalCLIArgs)
    assert isinstance(c, ImmutableDict)
    assert isinstance(c['b'], ImmutableDict)
    assert isinstance(c['b']['c'], tuple)

# Generated at 2022-06-21 08:26:58.299446
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs(dict([('x', 5), ('y', dict([('a', 1), ('b', [1, 2])]))]))
    assert args['x'] == 5
    assert args['y']['a'] == 1
    assert args['y']['b'][0] == 1
    assert args['y']['b'][1] == 2

    args = CLIArgs(dict([('x', 5), ('y', dict([('a', 1), ('b', [1, 2]), ('c', dict(z=1))]))]))
    assert args['x'] == 5
    assert args['y']['a'] == 1
    assert args['y']['b'][0] == 1
    assert args['y']['b'][1] == 2

# Generated at 2022-06-21 08:27:07.915549
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import is_immutable
    import os

    d = os.environ.copy()
    d["new_key"] = "new_value"
    d = CLIArgs(d)
    assert isinstance(d, ImmutableDict)
    assert is_immutable(d)
    assert hasattr(d, "new_key")
    assert callable(d.new_key)

    t = d.copy()
    assert isinstance(t, Mapping)
    assert is_immutable(t)
    assert hasattr(t, "new_key")
    assert callable(t.new_key)

   

# Generated at 2022-06-21 08:27:19.863784
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'a': {'1': '2', '3': '4'},
               'b': '5',
               'c': ('6', '7')}

    cli_args = CLIArgs(mapping)

    assert isinstance(cli_args['a'], ImmutableDict)

    # Make sure even if input is mutable, the CLIArgs object is not
    try:
        cli_args['a']['1'] = '3'
        assert False, "Should not be able to modify internal dictionary"
    except TypeError:
        assert True
    except AttributeError:
        assert True

    assert cli_args['b'] == '5'
    assert cli_args['c'][0] == '6'
    assert cli_args['c'][1] == '7'

# Generated at 2022-06-21 08:27:23.839472
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    d = CLIArgs({'key': {1: [1, 2, 3]}, 'key2': [1, 2, 3], 'key3': 1})
    assert isinstance(d['key'], ImmutableDict)
    assert isinstance(d['key2'], tuple)
    assert d['key3'] == 1
    assert d['key'][1] == (1, 2, 3)

# Generated at 2022-06-21 08:27:31.659491
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object):
        __metaclass__ = _ABCSingleton
        pass

    assert Test.__instance is None
    t = Test()
    assert t is Test.__instance

    # Verify that _ABCSingleton is a subclass of Singleton
    assert isinstance(t, Singleton)

    # The following is a way to test for the presence of an abstract base class:
    import abc
    Test()
    assert Test not in abc.ABCMeta.__subclasses__(abc.ABCMeta)

# Generated at 2022-06-21 08:27:43.013009
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import os

    sys.argv.append("--debug")
    sys.argv.append("--check")
    from ansible.cli import CLI
    options, args = CLI.parse()

    # this will throw an exception if GlobalCLIArgs is not global
    GlobalCLIArgs.clear_instance()

    global_cli_args = GlobalCLIArgs.from_options(options)
    assert (isinstance(global_cli_args, GlobalCLIArgs))
    assert (global_cli_args.get("debug"))
    assert (global_cli_args.get("check"))

    # Create a file to test the "check.to" option
    check_file = 'check.txt'
    open(check_file, 'a').close()
    sys.argv.append("--check.to")

# Generated at 2022-06-21 08:27:48.931128
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import json
    sys.argv = ['ansible-doc', '--version']
    from ansible.module_utils.common.args import AnsibleOptions
    from ansible.module_utils.common.args import GlobalCLIArgs
    options = AnsibleOptions(version=2.1)
    GlobalCLIArgs.from_options(options)
    print(json.dumps(GlobalCLIArgs(), sort_keys=True, indent=4, separators=(',', ': ')))

test_GlobalCLIArgs()

# Generated at 2022-06-21 08:28:00.577851
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {
        'one': '1',
        'two': 2,
        'three': '3',
        'four': {
            'four': 4,
            'five': '5',
            'six': 6
        },
        'seven': 7,
        'eight': 8,
        'nine': '9',
        'ten': {
            'ten': 10,
            'eleven': '11',
            'twelve': 12,
            'thirteen': [
                1,
                2,
                3,
                {
                    'fourteen': '14',
                    'fifteen': 15
                }
            ]
        }
    }

    parsed_args = CLIArgs(mapping)
    assert parsed_args.one == '1'

# Generated at 2022-06-21 08:28:03.037173
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    assert issubclass(A, ABCMeta)
    assert issubclass(A, Singleton)

# Generated at 2022-06-21 08:28:28.254066
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    with pytest.raises(TypeError):
        CLIArgs(1)
    with pytest.raises(TypeError):
        CLIArgs("hello")
    with pytest.raises(TypeError):
        CLIArgs(None)

    test_args = dict()
    test_args["connection"] = "local"
    test_args["help"] = True

    # create a CLIArgs object
    ca1 = CLIArgs(test_args)

    # test that the properties are unmodifiable
    with pytest.raises(AttributeError):
        ca1["connection"] = "ssh"

    with pytest.raises(AttributeError):
        ca1.connection = "ssh"

    ca1 = None



# Generated at 2022-06-21 08:28:34.801951
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    This test exists just to make sure that _ABCSingleton works

    As _ABCSingleton is a metaclass, we can't test its functionality with a test class, so we
    just create a test object inside of this function.
    """
    class TestClass(object):
        """
        TestClass is only used to test the functionality of _ABCSingleton metaclass
        """
        __metaclass__ = _ABCSingleton
    # If the metaclass worked correctly, this should return the same object as the second call
    # to DjangoCliArgs should return the first instance that was created.
    assert TestClass() == TestClass()

# Generated at 2022-06-21 08:28:45.787601
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        def __init__(self):
            self.val = 1

    class B(A):
        def __init__(self):
            # No super call because there is no __init__ method that it can call
            self.val = 2

    class C(A):
        def __init__(self):
            super(C, self).__init__()
            self.val = 3

    class D(A):
        pass

    # Create instances of each subclass
    a = A()
    b = B()
    c = C()
    d = D()

    # Can create an instance of any subclass and get the same instance
    assert a is A()
    assert b is B()
    assert c is C()
    assert d is D()

    # Check that instance attributes were set

# Generated at 2022-06-21 08:28:57.683997
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-21 08:29:04.251563
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options:
        def __init__(self, args):
            self.__dict__ = dict(args)

    args = dict(a=1, b=dict(c=2))
    options = Options(args)
    cli_args = GlobalCLIArgs.from_options(options)
    assert isinstance(cli_args, GlobalCLIArgs)
    assert cli_args['a'] == 1
    assert cli_args['b']['c'] == 2

# Generated at 2022-06-21 08:29:16.317511
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.display import Display
    import codecs, sys
    # This is needed for pylint to be happy about GlobalCLIArgs. Called from
    # do_cli() so that the cmd line options are available in this test

    # W0603: global name 'GlobalCLIArgs' is used before assignment
    display = Display()  # pylint: disable=W0603
    sys.stdout = codecs.lookup('utf-8')[-1](sys.stdout)
    sys.stderr = codecs.lookup('utf-8')[-1](sys.stderr)
    display.verbosity = 0

    # argv as it would be if called by `ansible all -m ping`
    argv = ['all', '-m', 'ping']
    from ansible.cli import CLI


# Generated at 2022-06-21 08:29:27.585059
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    import ansible.module_utils.common.json_utils as json_utils
    import tempfile
    import os

    modules = {'module.unmutable.js': '{"a":[1,2,3]}', 'module.mutable.js': '["a",{"b":2}]'}
    for module, content in modules.items():
        with tempfile.NamedTemporaryFile(delete=False) as f:
            f.write((data_path + os.sep + module + content).encode('utf-8'))

    options = json_utils.load_fragment_arg(data_path + os.sep + modules['module.unmutable.js'])

# Generated at 2022-06-21 08:29:28.215047
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    pass

# Generated at 2022-06-21 08:29:30.256824
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class foo(metaclass=_ABCSingleton):
        pass

    assert issubclass(type(foo()), type)

# Generated at 2022-06-21 08:29:32.575549
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options:
        a = "b"
        c = 1

    assert isinstance(CLIArgs.from_options(Options), CLIArgs)



# Generated at 2022-06-21 08:30:15.015031
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    options = "abcd"
    options_dict = {"a": "b", "c": "d"}
    options_list = ["e", "f"]
    options_dictlist = [options_dict, options_dict]
    test_CLIArgs = CLIArgs(options)
    assert test_CLIArgs["options"] == options
    test_CLIArgs = CLIArgs(options_dict)
    assert test_CLIArgs["options_dict"] == options_dict
    test_CLIArgs = CLIArgs(options_list)
    assert test_CLIArgs["options_list"] == options_list
    test_CLIArgs = CLIArgs(options_dictlist)
    assert test_CLIArgs["options_dictlist"] == options_dictlist



# Generated at 2022-06-21 08:30:26.159956
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    obj = CLIArgs(dict(
        debug=True,
        inventory='inventory.yml',
        list_tasks=True,
        ttasks='all',
        start_at_task='all',
        forks=5,
        verbosity=1,
        module_path=["/foo/bar/baz", "/qux/quux"],
    ))

    assert obj.debug is True
    assert obj.inventory == 'inventory.yml'
    assert obj.list_tasks is True
    assert obj.ttasks == 'all'
    assert obj.start_at_task == 'all'
    assert obj.forks == 5
    assert obj.verbosity == 1

    assert len(obj.module_path) == 2
    assert obj.module_path[0] == '/foo/bar/baz'

# Generated at 2022-06-21 08:30:36.266540
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils._text import to_bytes
    assert isinstance(CLIArgs({}), ImmutableDict)
    assert isinstance(CLIArgs({b'test': b'value'}), ImmutableDict)
    assert isinstance(CLIArgs({u'test': u'value'}), ImmutableDict)
    assert isinstance(CLIArgs({b'test': [u'value']}), ImmutableDict)
    assert isinstance(CLIArgs({b'test': (u'value',)}), ImmutableDict)
    assert isinstance(CLIArgs({b'test': {u'value': u'value'}}), ImmutableDict)
    assert isinstance(CLIArgs({b'test': {u'subtest': {b'value': u'value'}}}), ImmutableDict)

# Generated at 2022-06-21 08:30:39.584991
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    '''
    A test to ensure that the class _ABCSingleton works properly
    :return: boolean
    '''

    class ABCSingletonSample(object):
        __metaclass__ = _ABCSingleton

    assert isinstance(ABCSingletonSample(), ABCSingletonSample)



# Generated at 2022-06-21 08:30:50.155571
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # GIVEN
    mapping = {'some_cmd_line_tuple': (3, 4, 5),
               'some_cmd_line_dict': {'a': 7, 'b': 8}}
    # WHEN
    global_cli_args = GlobalCLIArgs(mapping)
    # THEN
    assert global_cli_args['some_cmd_line_tuple'] == (3, 4, 5)
    assert global_cli_args['some_cmd_line_dict'] == {'a': 7, 'b': 8}
    # global_cli_args is immutable, so asserting it raises a TypeError
    assert TypeError

# Generated at 2022-06-21 08:30:54.370662
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    class C(A):
        pass

    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()


# TODO: implement a CLIArgsLock context manager
# class CLIArgsLock(object):
#     """
#     Lock the args for the current scope.
#
#     This prevents them from being changed by someone else, but someone else can lock the args
#     and change them if the lock is released.
#     """
#     pass

# Generated at 2022-06-21 08:30:58.426344
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # if this fails, we broke _ABCSingleton
    class SingletonABCBase(metaclass=_ABCSingleton):
        pass

    class SingletonClass(SingletonABCBase):
        pass

    class SingletonABC(metaclass=_ABCSingleton):
        @classmethod
        def something(cls):
            pass

# Generated at 2022-06-21 08:31:01.115813
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    # Should fail, because if it was singleton, would not allow subclassing
    class B(A):
        pass

# Generated at 2022-06-21 08:31:13.308686
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Unit test for constructor of class CLIArgs
    """
    dict_input = dict(foo="bar", baz=dict(cat='dog', tiger="lion"), num_list=[1, 2, 3], num_set=set(["1", "2", "3"]),
                      list_set=[set([1, 2, 3]), set(['1', '2', '3'])])
    cli_args = CLIArgs(dict_input)
    # Sets are not hashable and therefore order in converted to tuple

# Generated at 2022-06-21 08:31:14.125271
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({'foo': 'bar'})