

# Generated at 2022-06-21 08:22:13.440639
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Test to ensure that _ABCSingleton can be instantiated"""
    class foo(object):
        __metaclass__ = _ABCSingleton

    f = foo()

# Generated at 2022-06-21 08:22:17.352024
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABCSingleton(_ABCSingleton):
        """
        Test Singleton metaclass for GlobalCLIArgs initialization
        """
        pass

    # Creates an instance of TestABCSingleton
    TestABCSingleton()



# Generated at 2022-06-21 08:22:19.132986
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    a1 = _ABCSingleton()
    a2 = _ABCSingleton()
    assert a1 == a2

# Generated at 2022-06-21 08:22:29.577758
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    class MockCLIArgs(GlobalCLIArgs):
        """Mock GlobalCLIArgs class for unit test"""
        def __init__(self):
            # test_GlobalCLIArgs will pass in a mock options object,
            # we can treat it as a mapping and pass directly to the
            # superclass constructor
            super(MockCLIArgs, self).__init__({'mock': True})

        def __new__(cls, *args, **kargs):
            obj = super(MockCLIArgs, cls).__new__(cls)
            return obj

    # Test that the superclass constructor is called
    test_args = MockCLIArgs()
    assert 'mock' in test_args

    # Test that the singleton is not deceived by copying
    test_args_copy = MockCLIArgs()
   

# Generated at 2022-06-21 08:22:33.342273
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    assert issubclass(A, Singleton)
    assert issubclass(A, ABCMeta)
    a1 = A()
    a2 = A()
    assert a1 is a2

# Generated at 2022-06-21 08:22:45.846961
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    import os
    import sys
    import unittest
    import shutil
    import tempfile

    class TestCLIArgs(unittest.TestCase):

        def setUp(self):
            self.tmpdir = tempfile.mkdtemp(prefix='tmp_cliargs_root_')
            self.tmpdir_nonrecursive = tempfile.mkdtemp(prefix='tmp_cliargs_nonrecursive_')
            self.options = lambda **kw: collections.namedtuple('Options', kw.keys())(*kw.values())  # pylint: disable=unnecessary-lambda

        def tearDown(self):
            shutil.rmtree(self.tmpdir)
            shutil.rmtree(self.tmpdir_nonrecursive)


# Generated at 2022-06-21 08:22:49.459013
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.removed import removed_class
    with removed_class('GlobalCLIArgs'):
        GlobalCLIArgs({"key": "value"})

# Generated at 2022-06-21 08:22:52.363706
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = GlobalCLIArgs.from_options(argparse.Namespace())
    assert(options.__class__.__name__ == 'GlobalCLIArgs')
    assert(options == {})

# Generated at 2022-06-21 08:23:01.406822
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.display import Display
    from ansible.utils.path import parse_kv
    obj = GlobalCLIArgs.from_options(parse_kv(b'vault-password-file=/tmp/secretdebug=1'))
    assert isinstance(obj, CLIArgs)
    assert isinstance(obj, GlobalCLIArgs)
    assert isinstance(obj, Mapping)
    assert isinstance(obj, Container)
    assert len(obj) == 2
    assert 'debug' in obj
    assert 'vault_password_file' in obj
    assert obj['debug'] == 1
    assert obj['vault_password_file'] == '/tmp/secret'

# Generated at 2022-06-21 08:23:11.022965
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import click

    class ClickOptions(click.Option):
        def __init__(self, *args, **kwargs):
            self.type = kwargs.pop('type', None)
            nargs = kwargs.pop('nargs', None)
            super(ClickOptions, self).__init__(*args, **kwargs)
            self._nargs = nargs

        def full_process_value(self, ctx, value):
            if self.nargs is not None and value is None:
                value = []
            return super(ClickOptions, self).full_process_value(ctx, value)


# Generated at 2022-06-21 08:23:26.239412
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # using global_args as a mock
    import ansible.config.base

# Generated at 2022-06-21 08:23:32.671314
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # pylint: disable=protected-access
    GlobalCLIArgs._instance = None
    GlobalCLIArgs._new_args = {"a": 1, "x": 2}
    GlobalCLIArgs()
    assert GlobalCLIArgs._instance._data == {"a": 1, "x": 2}
    GlobalCLIArgs._new_args = {"a": 1, "x": 2, "y": {"a": 1, "b": 2}}
    GlobalCLIArgs()
    assert GlobalCLIArgs._instance._data == {"a": 1, "x": 2, "y": {"a": 1, "b": 2}}

# Generated at 2022-06-21 08:23:40.374953
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class MockOptions(object):
        booboo = [1, 2, 3]
        foo = 'bar'
        yo = {
            'ahh': 'yo'
        }
    options = MockOptions()
    cli_args = CLIArgs.from_options(options)
    assert cli_args.booboo == (1, 2, 3)
    assert cli_args.foo == 'bar'
    assert cli_args.yo == {'ahh': 'yo'}


# Generated at 2022-06-21 08:23:51.904310
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingletonA(object):
        __metaclass__ = _ABCSingleton
    sa1 = SingletonA()
    sa2 = SingletonA()
    assert sa1 == sa2

    class SingletonB(SingletonA):
        pass
    sb1 = SingletonB()
    sb2 = SingletonB()
    assert sb1 == sb2

    class NonSingletonA(object):
        pass
    class NonSingletonB(object):
        __metaclass__ = _ABCSingleton
    na1 = NonSingletonA()
    na2 = NonSingletonA()
    assert na1 != na2
    nb1 = NonSingletonB()
    nb2 = NonSingletonB()
    assert nb1 != nb2

    class SingletonNotAB(object):
        __met

# Generated at 2022-06-21 08:23:59.223284
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    from ansible.cli import CLI

    options = CLI.base_parser(
        usage='usage: %prog [options] [inventory_file] [playbooks...]',
        connect_opts=True,
        meta_opts=True,
        runas_opts=True,
        subset_opts=True,
        check_opts=True,
        inventory_opts=True,
        runtask_opts=True,
        vault_opts=True,
        fork_opts=True,
        module_opts=True,
        desc='Ansible command line interface')

    options, args = options.parse_args()


# Generated at 2022-06-21 08:24:11.053402
# Unit test for constructor of class _ABCSingleton

# Generated at 2022-06-21 08:24:14.985306
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'toplevel1': [1, 2, 3],
               'deeper':
                   {
                       'toplevel2': [1, 2, 3],
                   }
               }

    args = CLIArgs(mapping)
    assert args == ImmutableDict(mapping)

# Generated at 2022-06-21 08:24:16.044126
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({})


# Generated at 2022-06-21 08:24:25.598244
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        pass

    options = Options()
    options.foo = b'unicode_bytes'
    options.bar = u'unicode_unicode'
    options.baz = 1
    options.frobnitz = {}

    cli_args = GlobalCLIArgs.from_options(options)

    assert isinstance(cli_args, CLIArgs)
    assert isinstance(cli_args, dict)

    assert isinstance(cli_args['foo'], text_type)
    assert isinstance(cli_args['bar'], text_type)
    assert isinstance(cli_args['baz'], int)
    assert isinstance(cli_args['frobnitz'], ImmutableDict)

    assert cli_args['foo'] == u'unicode_bytes'
    assert cli_args

# Generated at 2022-06-21 08:24:28.995952
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs({"verbosity":10})
    assert isinstance(global_cli_args, GlobalCLIArgs)
    assert isinstance(global_cli_args, ImmutableDict)

# Generated at 2022-06-21 08:24:41.633483
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs({
        'connection': 'smart',
        'module_path': './modules',
        'become_method': 'sudo',
        'check': False,
        'become_user': 'root',
        'check_mode': False,
        'force': False,
        'forks': 1,
        'remote_user': 'root',
        'ask_vault_pass': False,
        'action': ['setup'],
        'host_pattern': '*',
        'run_hosts': [],
        'verbosity': 1})

    # Parsed command line options are stored as ImmutableDict
    assert isinstance(cli_args, ImmutableDict)

    # Connection check
    assert cli_args['connection'] == 'smart'

    # Module path check
    assert cl

# Generated at 2022-06-21 08:24:47.628718
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton(metaclass=_ABCSingleton):
        def __init__(self, x):
            self.x = x

    t1 = TestSingleton(1)
    t2 = TestSingleton(2)
    assert t1.x == 1
    assert t2.x == 1
    t2.x = 2
    assert t1.x == 2
    assert t2.x == 2
    t1.x = 3
    assert t1.x == 3
    assert t2.x == 3
    assert t1 is t2

# Generated at 2022-06-21 08:24:52.760331
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():  # pylint: disable=unused-variable
    """
    Test that the GlobalCLIArgs constructor sets all its data to immutable types
    """
    class Options(object):
        fake_arg = "fake_arg"

    options = Options()
    global_args = GlobalCLIArgs(vars(options))
    assert global_args.fake_arg == "fake_arg"

# Generated at 2022-06-21 08:24:56.466495
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SomeDumbClass(_ABCSingleton):
        pass

    obj_a = SomeDumbClass()
    obj_b = SomeDumbClass()
    assert obj_a is obj_b
    assert obj_a == obj_b

# Generated at 2022-06-21 08:25:00.388697
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    values = {"a" : "1", "b" : 2}
    args = CLIArgs(values)
    assert args["a"] == values["a"]
    assert args["b"] == values["b"]


# Generated at 2022-06-21 08:25:08.588292
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.splitter import SPLITTER_OPTIONS
    import inspect
    import ansible.constants as C

    my_str = "test"
    my_dict = {"a": my_str, "b": [1, 2, 3]}
    args = GlobalCLIArgs(my_dict)
    assert isinstance(args, ImmutableDict)
    assert isinstance(args['a'], text_type)
    assert isinstance(args['b'], tuple)
    assert args['a'] == "test"
    assert args['b'][0] == 1

    for key in SPLITTER_OPTIONS:
        assert key in args


# Generated at 2022-06-21 08:25:17.307772
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import unittest.mock

    # Arrange
    class DummyMapping(Mapping):
        def __iter__(self):
            return iter(())

        def __len__(self):
            return 0

        def __getitem__(self, item):
            raise KeyError(item)

    # Act
    args = CLIArgs(DummyMapping())

    # Assert
    assert isinstance(args, ImmutableDict)
    assert len(args) == 0
    assert args == {}



# Generated at 2022-06-21 08:25:20.357942
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(with_metaclass(_ABCSingleton)):
        pass

    f1 = Foo()
    f2 = Foo()

    assert f1 is f2
    assert f1 == f2

# Generated at 2022-06-21 08:25:26.070649
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = [("--connection", "local"), ("foo", "bar"), ("baz", "xyz")]
    args = GlobalCLIArgs(dict(options))

    # Test __dict__ to make sure that ImmutableDict is fully populated
    assert args.__dict__ == dict(options)



# Generated at 2022-06-21 08:25:36.545312
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.unsafe_proxy import wrap_var

    x = wrap_var(Sentinel('x'))

    GlobalCLIArgs.from_options(
        Sentinel(
            foo='bar',
            baz=[x, 'bat'],
            qox={wrap_var(Sentinel('a')): wrap_var(Sentinel('aa')), 'b': 'bb'}
        )
    )
    assert GlobalCLIArgs.get('foo') == 'bar'
    assert GlobalCLIArgs.get('baz') == (x, 'bat')
    assert GlobalCLIArgs.get('qox') == {'a': 'aa', 'b': 'bb'}

# Generated at 2022-06-21 08:25:49.640062
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from pprint import pformat
    test_dict = {'a': {'b': {'c': 'A.B.C'}, 'd': 'A.D', 'e': 'A.E'},
                 'f': ['F0', 'F1', 'F2'],
                 'g': {'h': 'G.H', 'i': ['I0', 'I1', 'I2'], 'j': ['J0', 'J1', 'J2']},
                 'k': ['K0', 'K1', 'K2']}

# Generated at 2022-06-21 08:25:58.349735
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 'a', 'b': 'b', 'c': ['c', 'd', {'e': 'e'}], 'f': {'g': 'g', 'h': 'h'}})
    # For ImmutableDict:
    # 1. Make sure that we can access values in normal ways
    assert(args['a'] == 'a')
    assert(args.get('a') == 'a')
    # 2. Make sure the dictionary is immutable.
    try:
        args['a'] = 'foo'
        assert False
    except TypeError:
        assert True
    # For CLIArgs:
    # 3. Make sure that we can't access a value that doesn't exist
    try:
        args['foo']
        assert False
    except KeyError:
        assert True
    # 4. Ass

# Generated at 2022-06-21 08:26:02.913589
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # pylint: disable=protected-access
    context = GlobalCLIArgs({})
    assert isinstance(context, GlobalCLIArgs)
    assert isinstance(context, Singleton)
    assert isinstance(GlobalCLIArgs._instance, Singleton._ABCSingletonInstanceType)



# Generated at 2022-06-21 08:26:06.069270
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        class SubClass(_ABCSingleton):
            pass
        assert False, "Expected TypeError"
    except TypeError as e:
        assert "_ABCSingleton can't be used with abstract methods" in str(e)

# Generated at 2022-06-21 08:26:08.785812
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    a = A()
    b = B()

    # make sure the decorator works
    assert issubclass(A, Singleton)

# Generated at 2022-06-21 08:26:18.210558
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import ansible.constants as C
    from ansible.utils.path import load_extra_vars_file

    # This is the same as AnsibleCLI.parse
    from ansible.cli import CLI
    cli = CLI(args=[])
    options, _, display_args = cli.parse()
    options = vars(options)

    # Now we can create a GlobalCLIArgs and check if it behaves
    # like an ImmutableDict
    global_args = GlobalCLIArgs(options)
    # Check that we have the expected keys

# Generated at 2022-06-21 08:26:20.347487
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs.from_options(None)
    assert cli_args
    assert isinstance(cli_args, CLIArgs)

# Generated at 2022-06-21 08:26:26.180781
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import collections

    CLIArgs_instance = GlobalCLIArgs({'abc': 123})

    assert isinstance(CLIArgs_instance, collections.abc.Mapping)
    assert isinstance(CLIArgs_instance, collections.abc.ItemsView)
    assert isinstance(CLIArgs_instance, collections.abc.Iterable)
    assert isinstance(CLIArgs_instance, collections.abc.Container)

# Generated at 2022-06-21 08:26:36.423409
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    opt_dict = {
        'foo': {
            'bar': {
                'baz': 1,
                'quux': [2, 3, 4],
                'norf': {
                    'thud': 'squash',
                },
            },
            'corge': 'foobar',
        },
        'grault': {
            'garply': 7,
            'waldo': [8, 9, 10],
            'fred': {
                'plugh': 'xyzzy',
            },
        },
    }
    # Get a new CLIArgs object that we can modify as we wish
    obj = CLIArgs(opt_dict)
    # Verify that the mods we made were made correctly

# Generated at 2022-06-21 08:26:48.357361
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options():
        def __init__(self):
            self.privatekey_path = text_type(u'test')
            self.host_key_checking = True
    options = Options()
    args = GlobalCLIArgs.from_options(options)

    assert isinstance(args, CLIArgs)
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, Mapping)
    assert isinstance(args, Container)  # Including the Mapping interface is enough to inherit Container
    assert isinstance(args.privatekey_path, text_type)
    assert isinstance(args.host_key_checking, bool)
    try:
        args.privatekey_path = 'bad'
        assert False, "Args are supposed to be immutable"
    except TypeError:
        pass

# Generated at 2022-06-21 08:26:54.033174
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs()
    assert isinstance(args, GlobalCLIArgs)
    assert isinstance(args, ImmutableDict)


# Generated at 2022-06-21 08:26:56.822572
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs.reset_instance({'test-arg': 'test-value'})
    assert GlobalCLIArgs().get('test-arg') == 'test-value'

# Generated at 2022-06-21 08:27:07.461849
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {
        'boolean': True,
        'integer': 100,
        'float': 99.99,
        'string': 'string',
        'list': ['one', 2, 3.0],
        'dict': {"key": "value"},
        'set': {"one", 2},
    }

    args = CLIArgs(mapping)

    assert isinstance(args, CLIArgs)
    assert isinstance(args, Mapping)
    assert isinstance(args, ImmutableDict)

    for key in mapping:
        assert key in args

    assert args['boolean']
    assert args['integer'] == 100
    assert args['float'] == 99.99
    assert args['string'] == 'string'
    assert args['list'] == tuple(['one', 2, 3.0])
    assert args['dict'] == Imm

# Generated at 2022-06-21 08:27:14.819370
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # assert_raises is a great way to unit test that a class does not have a constructor
    # you can call in an unexpected way.  If the constructor is private you cannot use
    # pytest style of instantiating via __init__, but you can test for the wrong usage
    # by asserting an exception was raised.
    from pytest import raises
    with raises(TypeError):
        GlobalCLIArgs()



# Generated at 2022-06-21 08:27:23.676926
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli.options import AnsibleCLI
    from ansible.cli import CLI
    cli = CLI()
    cli_opts = AnsibleCLI(args=[])
    opts = vars(cli_opts.parser.parse_args())

    cli.options = cli_opts
    cli.init_options()

    cli.setup()
    cli.run()

    # construct a GlobalCLIArgs from options and test that the attributes are immutable
    args = GlobalCLIArgs.from_options(opts)
    # not sure what the options are for all ansible installations, so check for some that we know
    # the values of.
    assert args['connection'] == 'smart'
    assert args['forks'] == 5

    # test that the attributes are immutable

# Generated at 2022-06-21 08:27:29.876651
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_dict = {
        'one': 'two',
        'three': 'four',
        'five': 'six'
    }
    args_obj = GlobalCLIArgs(test_dict)
    assert args_obj['one'] == 'two'
    assert args_obj['three'] == 'four'
    assert args_obj['five'] == 'six'

# Generated at 2022-06-21 08:27:41.427797
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-21 08:27:49.845957
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({"test": "foo"})
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, Mapping)

    assert args["test"] == "foo"
    try:
        args["test"] = "bar"
    except TypeError:
        pass
    else:
        assert False, "args object is mutable"

    # Test make immutable on containers
    dct = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
    immut_dct = _make_immutable(dct)
    assert not isinstance(immut_dct, dict)
    assert immut_dct['a'] == 1
    assert immut_dct['b'] == 2
    assert immut_dct['c'] == 3
    assert immut_d

# Generated at 2022-06-21 08:27:53.261813
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(_ABCSingleton):
        def __init__(self):
            self.initialised = True

    a = TestClass()
    b = TestClass()

    assert a.initialised == b.initialised == True

# Generated at 2022-06-21 08:27:57.995326
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.context_objects import CLIFactory
    args = CLIFactory.global_context().get_args()
    assert isinstance(args, CLIArgs)
    assert isinstance(args, ImmutableDict)
    assert not isinstance(args, Mapping)


# Generated at 2022-06-21 08:28:14.290004
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Create a Options class (from optparse)
    class Options:
        def __init__(self):
            self.hello = ['world', 'ansible']
            self.foo = 42
            self.bar = None
            self.baz = dict(x=1, y=2, z=3)
            self.qux = ['quux', 'quuux']

    # Create instance of Options
    options = Options()

    # Create instance of GlobalCLIArgs
    # GlobalCLIArgs is a singleton, so
    #    GlobalCLIArgs(options)
    # is the same as:
    #    GlobalCLIArgs.from_options(options)
    # Both return a new singleton instance of GlobalCLIArgs
    instance = GlobalCLIArgs(options)

    # GlobalCLIArgs is a subclass of ImmutableD

# Generated at 2022-06-21 08:28:20.328828
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import option_context

    tkey = u'key'
    tval = u'test'
    test_dict = {}
    test_dict[tkey] = tval
    gca = GlobalCLIArgs.from_options(option_context.make_context('-t', tval).options)
    assert gca[tkey] == tval, gca[tkey]

# Generated at 2022-06-21 08:28:21.928541
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({'debug': True})
    assert GlobalCLIArgs.instance().debug is True

# Generated at 2022-06-21 08:28:22.515397
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    pass

# Generated at 2022-06-21 08:28:28.539960
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import argparse

    p = argparse.ArgumentParser()
    p.add_argument('--foo')
    p.add_argument('--bar')

    options = p.parse_args(['--foo', 'foo', '--bar', 'bar'])

    a = CLIArgs.from_options(options)

    assert a['bar'] == 'bar'
    assert a['foo'] == 'foo'



# Generated at 2022-06-21 08:28:31.934388
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():  # noqa
    class A(object):
        __metaclass__ = _ABCSingleton
    a1 = A()
    a2 = A()
    assert isinstance(a1, object)
    assert isinstance(a2, object)
    assert a1 is a2



# Generated at 2022-06-21 08:28:34.082579
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    @add_metaclass(_ABCSingleton)
    class TestClass(object):
        pass

    assert TestClass()  # Object instantiation should work

# Generated at 2022-06-21 08:28:35.663488
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({'foo': 'bar'})
    GlobalCLIArgs.instance()

# Generated at 2022-06-21 08:28:41.656094
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.vars import combine_vars
    test_dict = combine_vars({"a":1}, {"b":2}, {"a":"c"})
    test_args = CLIArgs(test_dict)
    assert isinstance(test_args, ImmutableDict)
    assert test_args['a'] == 'c'
    assert test_args['b'] == 2



# Generated at 2022-06-21 08:28:50.549654
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Test class _ABCSingleton

    Test that _ABCSingleton is a metaclass and doesn't error when used.
    """
    from abc import ABC, abstractmethod

    class _TestABCMeta(_ABCSingleton, ABC):
        """Test _ABCSingleton with a new class that also inherits from ABC."""
        @abstractmethod
        def concrete_function(self):
            pass

    class _TestABCSingleton(_TestABCMeta):
        """Test _ABCSingleton with a class that inherits the metaclass."""
        def concrete_function(self):
            pass

    _TestABCSingleton() # test that this doesn't error

# Generated at 2022-06-21 08:29:12.959268
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # can't instantiate because it's a singleton
    try:
        GlobalCLIArgs()
    except TypeError as e:
        # py2 and py3 differ in exception type
        assert isinstance(e, (TypeError, AttributeError))

# Generated at 2022-06-21 08:29:16.074478
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
        def __init__(self, value):
            self._value = value

    _ = A(1)
    _ = A(2)

# Generated at 2022-06-21 08:29:27.431086
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

    display = Display()
    display.verbosity = 5


# Generated at 2022-06-21 08:29:31.801616
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # class SingletonClassDeclaration is a test class for _ABCSingleton.
    class SingletonClassDeclaration:
        __metaclass__ = _ABCSingleton
    assert isinstance(SingletonClassDeclaration, Singleton) is True
    assert isinstance(SingletonClassDeclaration, ABCMeta) is True

# Generated at 2022-06-21 08:29:33.050290
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Just cover that we can make an instance
    GlobalCLIArgs({})

# Generated at 2022-06-21 08:29:34.276855
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # check that the constructor does not require a list of options
    GlobalCLIArgs(None)

# Generated at 2022-06-21 08:29:46.258033
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    dict_1 = {'a': {'b': 1}}
    dict_2 = {'a': {'b': [1, 2, 3]}}
    dict_3 = {'a': {'c': [1, 2, 3]}}
    dict_4 = {'a': {'a': {'b': [1, 2, 3]}}}
    dict_5 = {'a': {'c': [1, 2, 3]}}

    dict_1_obj = GlobalCLIArgs(dict_1)
    dict_2_obj = GlobalCLIArgs(dict_2)
    dict_3_obj = GlobalCLIArgs(dict_3)
    dict_4_obj = GlobalCLIArgs(dict_4)
    dict_5_obj = GlobalCLIArgs(dict_5)

    assert dict_1_

# Generated at 2022-06-21 08:29:48.118680
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingletonABCTest(metaclass=_ABCSingleton):
        pass

    with SingletonABCTest() as obj:
        pass

# Generated at 2022-06-21 08:30:00.617300
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import unittest

    from ansible.module_utils.common.argparse import CLIARGS

    CLIARGS = CLIARGS.from_options(None)
    x = GlobalCLIArgs(CLIARGS)
    y = GlobalCLIArgs.instance()

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_instance(self):
            self.assertIsNotNone(y)
            self.assertIsInstance(y, GlobalCLIArgs)
            self.assertEqual(x, y)

        def test_debug(self):
            self.assertIsNotNone(y.debug)
            self.assertIsInstance(y.debug, bool)

        def test_listtags(self):
            self.assertIsNotNone(y.listtags)

# Generated at 2022-06-21 08:30:11.556470
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-21 08:30:52.021198
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _TempABCSingleton(_ABCSingleton):
        pass

    class _TempSingleton(Singleton):
        pass

# Generated at 2022-06-21 08:30:58.355491
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    g = GlobalCLIArgs({'foo': 'bar'})

    assert g.foo == 'bar'

    try:
        g.foo = 'baz'
    except TypeError:
        pass
    else:
        assert False, 'Expected GlobalCLIArgs to be immutable, but it is not'

    try:
        g['foo'] = 'baz'
    except TypeError:
        pass
    else:
        assert False, 'Expected GlobalCLIArgs to be immutable, but it is not'



# Generated at 2022-06-21 08:31:03.673338
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _Example(_ABCSingleton):
        def __init__(self):
            pass
    a = _Example()
    b = _Example()
    assert a is b
    assert isinstance(a, _ABCSingleton)
    assert isinstance(a, Singleton)
    assert isinstance(a, _Example)
    assert isinstance(a, object)



# Generated at 2022-06-21 08:31:15.274952
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.six.moves import configparser as ConfigParser
    from ansible.module_utils.six import StringIO

    # Write a bit of config file to use for testing
    configfile = StringIO()
    configfile.write("[defaults]\n")
    configfile.write("inventory = inventory.yml")
    configfile.seek(0)

    # Create a ConfigParser object and load the file
    parser = ConfigParser.ConfigParser(allow_no_value=True)
    parser.readfp(configfile)

    # Make a mock optparse object
    class MockOptionParser(object):
        def __init__(self):
            self.attributes = {}
            self.attributes["connection"] = "connection"
            self.attributes["module_path"] = "module_path"
            self

# Generated at 2022-06-21 08:31:24.021182
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass1(object):
        __metaclass__ = _ABCSingleton

    assert isinstance(TestClass1(), TestClass1)

    try:
        class TestClass2(object):
            __metaclass__ = _ABCSingleton
            def __init__(self):
                pass

        # This is expected to fail with a TypeError
        TestClass2()
    except TypeError:
        pass
    else:
        raise RuntimeError("TypeError not raised")

# Generated at 2022-06-21 08:31:27.890120
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Test that _ABCSingleton creates a Python 2.6 friendly metaclass
    """
    class TestClass(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(TestClass, _ABCSingleton)
    assert TestClass._abc_cache is None

# Generated at 2022-06-21 08:31:31.034492
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SomeClass(object):
        __metaclass__ = _ABCSingleton
    obj1 = SomeClass()
    obj2 = SomeClass()
    assert obj1 is obj2

# Generated at 2022-06-21 08:31:34.353938
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Verify that the _ABCSingleton class behaves properly
    """
    class class_a(object):
        pass

    class class_b(class_a):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            self.foo = 'FOO'

    b1 = class_b()
    assert hasattr(b1, 'foo')
    assert b1.foo == 'FOO'
    b2 = class_b()
    assert b1 is b2, 'Second instantiated class_b not equal to first class_b'
    b3 = class_a()
    assert b3 != b1

# Generated at 2022-06-21 08:31:38.567715
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    assert is_immutable(GlobalCLIArgs({'a': 1, 'b': (2, 3), 'c': {'d': 4, 'e': (5, 6)}, 'f': {'g': 7}}))

# Generated at 2022-06-21 08:31:39.790170
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs.create({"test": {"key": "value"}})