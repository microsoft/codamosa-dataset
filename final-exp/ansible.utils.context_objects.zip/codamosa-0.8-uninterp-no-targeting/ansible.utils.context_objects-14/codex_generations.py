

# Generated at 2022-06-21 08:22:07.884903
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ConcreteClass(metaclass=_ABCSingleton):
        pass

    concrete_object = ConcreteClass()
    concrete_object2 = ConcreteClass()
    assert concrete_object is concrete_object2

# Generated at 2022-06-21 08:22:19.951821
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # We expect it to take in a dictionary, which it will make immutable
    # But its internal representation should be immutable
    args = CLIArgs({'tempfile': True})
    assert isinstance(args, ImmutableDict)
    # Should not be allowed to modify original object
    try:
        args['test'] = False
        assert False, "Should not be allowed to edit args"
    except TypeError:
        pass
    try:
        del args['test']
        assert False, "Should not be allowed to edit args"
    except TypeError:
        pass
    # Should not be allowed to modify internal objects
    args['test'] = {u'test': True}
    assert args['test'] == {u'test': True}

# Generated at 2022-06-21 08:22:24.601612
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = CLIArgs({
        'a': 1,
        'b': {
            'c': 2,
            'd': 3,
        }
    })
    assert isinstance(args, GlobalCLIArgs)
    assert args.a == 1
    assert args.b.c == 2
    assert args.b.d == 3

# Generated at 2022-06-21 08:22:27.733921
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    try:
        cli_args = CLIArgs({})
    except TypeError:
        cli_args = None  # It will not make it here
    assert cli_args is not None

# Generated at 2022-06-21 08:22:29.344908
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({'test':1})
    assert isinstance(args, ImmutableDict)

# Generated at 2022-06-21 08:22:38.295902
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Sub class CLIArgs.
    class CLIArgsTest(CLIArgs):
        pass

    # Assign value to variable map.
    map1 = { 'one': 1, 'two': 2 }
    map2 = { 'three': 3, 'four': 4 }
    map1.update(map2)

    # Create a CLIArgsTest object with map1.
    cli_args_obj = CLIArgsTest.from_options(map1)

    # Test __init__().
    assert cli_args_obj.toplevel == {'one': 1, 'two': 2, 'three': 3, 'four': 4}


# Generated at 2022-06-21 08:22:40.898689
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(A):
        pass

    A()
    B()

# Generated at 2022-06-21 08:22:45.637213
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    cli_args = GlobalCLIArgs({'test_key': 'test_value'})
    assert cli_args['test_key'] == 'test_value'
    assert cli_args == GlobalCLIArgs({'test_key': 'test_value'})

# Generated at 2022-06-21 08:22:57.005132
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    params = GlobalCLIArgs.from_options(globals()['options'])
    assert isinstance(params, ImmutableDict)

    # We should not be able to change the data in the object
    try:
        params.update(dict(hello='world'))
    except AttributeError:
        pass
    else:
        assert False, "GlobalCLIArgs should be immutable"

    # We should not be able to change the object itself
    try:
        params['hello'] = 'world'
    except TypeError:
        pass
    else:
        assert False, "GlobalCLIArgs should be immutable"

    # We should not be able to change the object itself
    try:
        del params['hello']
    except (TypeError, KeyError):
        pass

# Generated at 2022-06-21 08:22:59.786243
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Unit test for constructor of class GlobalCLIArgs"""
    global_args = GlobalCLIArgs({'test': 'value'})
    assert global_args == {'test': 'value'}

# Generated at 2022-06-21 08:23:07.816158
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import unittest

    class MyTestCase(unittest.TestCase):
        def test_constructor(self):
            options = {'a': "asdf", 'b': ("asdf",), 'c': {"a": "asdf", "b": ("asdf",)}, 'd': {"asdf"}}
            args = GlobalCLIArgs.from_options(options)

            self.assertEqual(options['a'], args['a'])
            self.assertEqual(options['b'], args['b'])
            self.assertEqual(options['c'], args['c'])
            self.assertEqual(options['d'], args['d'])

    unittest.main()



# Generated at 2022-06-21 08:23:09.081540
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    assert Foo() is Foo()

# Generated at 2022-06-21 08:23:13.487374
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict1 = dict(key1='value1', key2='value2')
    args1 = CLIArgs(dict1)
    assert id(dict1) != id(args1), 'The object is not immutable'
    assert args1['key1'] == dict1['key1'], "The object should have identical key-value pair"

# Generated at 2022-06-21 08:23:20.838726
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
        def __init__(self):
            pass

    class B(object):
        __metaclass__ = _ABCSingleton
        def __init__(self):
            pass

    try:
        a = A()
        b = B()
    except TypeError:
        assert False, "test__ABCSingleton failed"

    assert True

# Generated at 2022-06-21 08:23:22.860398
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = GlobalCLIArgs({'a': 'b'})
    assert a['a'] == 'b'

# Generated at 2022-06-21 08:23:26.413390
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs.destroy()
    obj = GlobalCLIArgs.load(dict(foo=dict(bar='baz')))
    assert obj == ImmutableDict({'foo': ImmutableDict({'bar': 'baz'})})

# Generated at 2022-06-21 08:23:30.813895
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options:
        var1 = 'val1'
        var2 = 'val2'
        var3 = 'val3'

    args = GlobalCLIArgs.from_options(Options())
    assert Options.var1 == args['var1']
    assert Options.var2 == args['var2']
    assert Options.var3 == args['var3']

# Generated at 2022-06-21 08:23:42.313155
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from collections import namedtuple
    from ansible.module_utils.six import string_types
    from ansible.utils.unsafe_proxy import wrap_var

    # Create some test data to turn into a CLIArgs object
    options = namedtuple("TestOption", ["hoist"])
    options.hoist = ["me"]
    cli_args = CLIArgs.from_options(options)

    # Ensure that the __contains__ method works
    assert "hoist" in cli_args

    # Ensure that the __getitem__ method works
    assert cli_args["hoist"] == ("me",)
    assert isinstance(cli_args["hoist"], tuple)

    # Ensure that the __iter__ method works
    assert set(cli_args) == {"hoist"}

    # Ensure that the __len__ method works
   

# Generated at 2022-06-21 08:23:53.413176
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-21 08:23:54.823274
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    c = GlobalCLIArgs.from_options(ImmutableDict({'one': 1}))
    assert c['one'] == 1

# Generated at 2022-06-21 08:24:08.210751
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    a_dict = {
        'a': 'a',
        'b': 'b',
        'c': ['3', '4', '5'],
        'd': {
            'e': '5',
            'f': '6',
            'g': ['7', '8', '9'],
        }
    }
    a_args = CLIArgs(a_dict)
    assert a_args['a'] == 'a'
    assert a_args['b'] == 'b'
    assert a_args['c'] == ('3', '4', '5')
    assert a_args['c'][0] == '3'
    assert a_args['c'][1] == '4'
    assert a_args['c'][2] == '5'
    assert a_args['d'] == ImmutableD

# Generated at 2022-06-21 08:24:18.130456
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test normal operations
    assert CLIArgs({'_ansible_verbosity': 1}) == {'_ansible_verbosity': 1}
    assert CLIArgs({'_ansible_verbosity': 1, 'foo': {'bar': 2}}) == {'_ansible_verbosity': 1, 'foo': {'bar': 2}}
    assert CLIArgs({'_ansible_verbosity': 1, 'foo': 2, 'baz': [1, 2, 3]}) == {'_ansible_verbosity': 1, 'foo': 2, 'baz': (1, 2, 3)}

# Generated at 2022-06-21 08:24:20.440525
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        def __init__(self, a, b):
            self.a = a
            self.b = b

    Test(1, 2)
    Test(3, 4)

# Generated at 2022-06-21 08:24:20.997066
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    pass

# Generated at 2022-06-21 08:24:26.953592
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # pylint: disable=superfluous-parens
    class TestBase(object, metaclass=_ABCSingleton):
        @staticmethod
        def test_method():
            return 'test_method'

    class TestSubClass(TestBase):
        pass

    assert TestSubClass() is TestSubClass()
    assert TestSubClass().test_method() == 'test_method'


# Unit tests for class CLIArgs

# Generated at 2022-06-21 08:24:33.003717
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABCSingleton(object, metaclass=_ABCSingleton):
        def __init__(self):
            self.value = True

    def make_one_instance():
        return TestABCSingleton()

    instance = TestABCSingleton()
    instance2 = TestABCSingleton()
    assert instance == instance2, "Only one instance of singleton should exist at a time"

# Generated at 2022-06-21 08:24:35.887838
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs(dict(foo=dict(bar='baz')))
    GlobalCLIArgs.from_options(dict(foo=dict(bar='baz')))

# Generated at 2022-06-21 08:24:46.198113
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Test the constructor of GlobalCLIArgs. Assertions are found in the tests."""

    # Create a dummy class which derived from argparse.Namespace
    # Ref: https://docs.python.org/2/library/argparse.html#argparse.Namespace
    class DummyOptions(object):
        def __init__(self, arg1, arg2):
            self.arg1 = arg1
            self.arg2 = arg2

    # Create a DummyOptions instance,
    # and pass it to the from_options method of GlobalCLIArgs.
    options = DummyOptions("value1", "value2")
    instance = GlobalCLIArgs.from_options(options)

    # Assertions
    assert isinstance(instance, GlobalCLIArgs)
    assert instance['arg1'] == "value1"
    assert instance

# Generated at 2022-06-21 08:24:48.953716
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    opts = GlobalCLIArgs.from_options(options=None)
    assert(opts is GlobalCLIArgs())

# Generated at 2022-06-21 08:24:59.841477
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import PY3
    if PY3:
        import builtins
        string_types = (str,)

# Generated at 2022-06-21 08:25:07.945378
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A, metaclass=ABCMeta):
        def __init__(self):
            self.x = "foo"
    class C(A, metaclass=ABCMeta):
        def __init__(self):
            self.x = "bar"
    assert A() is A()
    assert B() is B()
    assert C() is C()
    assert A() is not B()
    assert A() is not C()
    assert B() is not C()
    assert B().x == "foo"
    assert C().x == "bar"

# Generated at 2022-06-21 08:25:16.852542
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--this', default=[1, 2], type=int, nargs='+', action='store')
    parser.add_argument('--that', default=True, action='store_false')

    args = parser.parse_args(['--this', '1', '2', '3', '--that'])
    gc = GlobalCLIArgs.from_options(args)

    assert gc['this'] == (1, 2, 3)
    assert gc['that'] is False



# Generated at 2022-06-21 08:25:19.662243
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import GlobalCLIArgs

    obj = GlobalCLIArgs.from_options(object())

    assert isinstance(obj, GlobalCLIArgs)

# Generated at 2022-06-21 08:25:24.532408
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object, metaclass=_ABCSingleton):
        pass
    assert isinstance(Test(), Test)
    assert issubclass(Test, ABCMeta)
    assert issubclass(Test, Singleton)



# Generated at 2022-06-21 08:25:27.311750
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Single(metaclass=_ABCSingleton):
        pass

    assert issubclass(Single, Singleton)


# Generated at 2022-06-21 08:25:37.113611
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    assert isinstance(GlobalCLIArgs(), GlobalCLIArgs)
    assert GlobalCLIArgs() is GlobalCLIArgs()

    GlobalCLIArgs()['foo'] = 'bar'
    assert GlobalCLIArgs()['foo'] == 'bar'
    try:
        GlobalCLIArgs()['foo'] = 'baz'
    except TypeError:
        pass
    else:
        raise AssertionError('GlobalCLIArgs() should be immutable, top level should be')
    nested = {'nested_key': 'nested_value'}
    GlobalCLIArgs()['nested'] = nested
    assert GlobalCLIArgs()['nested']['nested_key'] == 'nested_value'

# Generated at 2022-06-21 08:25:43.162122
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        verbosity = 1
        module_path = "/the/first/path"
        inventory_path = "/the/sec/path"
    options = Options()
    args = CLIArgs(vars(options))
    assert args["verbosity"] == 1
    assert args["module_path"] == "/the/first/path"
    assert args["inventory_path"] == "/the/sec/path"

# Generated at 2022-06-21 08:25:50.703458
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    example = {
        "foo": {
            "bar": [1,2,3],
            "baz": {
                "blah": 123
            }
        }
    }
    args = CLIArgs(example)
    assert isinstance(args, ImmutableDict)
    assert isinstance(args['foo'], ImmutableDict)
    assert isinstance(args['foo']['bar'], tuple)
    assert isinstance(args['foo']['baz'], ImmutableDict)
    assert isinstance(args['foo']['baz']['blah'], int)

# Generated at 2022-06-21 08:25:55.412352
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Test that we can use the _ABCSingleton() class

    We want to know if the class _ABCSingleton will be available to
    other modules.  It should be available because we import it into
    this module, and this module is imported during the test loader
    run.
    """
    class A(metaclass=_ABCSingleton):
        pass
    assert A() == A()

# Generated at 2022-06-21 08:26:01.082146
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    options = ImmutableDict({'a': 'value'})
    options_as_dict = dict(options)
    args = CLIArgs.from_options(options)
    assert options.a == args.a
    assert options_as_dict.a == args.a

# Generated at 2022-06-21 08:26:07.525622
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyABCSingleton(object):
        __metaclass__ = _ABCSingleton

    # Works with empty class
    MyABCSingleton()

    # Works with metaclass listed in class
    class MyOtherABCSingleton(object, metaclass=_ABCSingleton):
        pass

    MyOtherABCSingleton()


# Generated at 2022-06-21 08:26:10.080410
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton
        pass

    foo1 = Foo()
    foo2 = Foo()
    assert foo1 is foo2

# Generated at 2022-06-21 08:26:19.153513
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dictionary = {
        "a": "hello",
        "b": "world",
        "c": {
            "d": "goodbye",
            "e": "world",
        },
        "f": [
            {
                "g": "foo",
                "h": "bar",
            },
            {
                "g": "baz",
                "h": "qaz",
            },
        ],
        "i": ["a", "b", "c"],
        "j": ("a", "b", "c"),
    }

    foo = CLIArgs(test_dictionary)

    assert foo["a"] == "hello"
    assert foo["b"] == "world"
    assert foo["c"]["d"] == "goodbye"

# Generated at 2022-06-21 08:26:22.563809
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Test _ABCSingleton constructor.

    We have to test it here since it is an inner class
    """
    class Test(_ABCSingleton):

        pass

    assert issubclass(Test, Singleton)

# Generated at 2022-06-21 08:26:33.570240
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    print(__name__)
    test_dict = {'foo': 'bar', 'bar': 3.5, 'abc': u'123'}
    dict2 = ImmutableDict(test_dict)
    args = CLIArgs(test_dict)
    print(args)
    try:
        args['foo'] = 'test'
    except AttributeError:
        pass
    else:
        assert False
    try:
        args['bar'] = 'test'
    except AttributeError:
        pass
    else:
        assert False
    try:
        args['abc'] = 'test'
    except AttributeError:
        pass
    else:
        assert False
    try:
        args['123'] = 'test'
    except AttributeError:
        pass
    else:
        assert False

# Unit test

# Generated at 2022-06-21 08:26:36.263501
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Other(object):
        pass

    class Test(object):
        __metaclass__ = _ABCSingleton

    assert Test.__isabstractmethod__ is not Other.__isabstractmethod__

# Generated at 2022-06-21 08:26:41.792112
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    import random
    import string
    import time

    # Verifies that our validations are being done correctly
    class BadCustomer(object):
        def __init__(self, name):
            self._name = name
        def __str__(self):
            return ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(8))

    # Verifies that our object is still mutable
    class NotAContainer(object):
        def __init__(self, name):
            self._name = name
        def __str__(self):
            return ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(8))


# Generated at 2022-06-21 08:26:45.641154
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    my_dict = {'a': 'b', 'c': {'d': 'e'}}
    my_args = CLIArgs(my_dict)
    my_args['c']['d'] = 'f'


# Generated at 2022-06-21 08:26:56.881592
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import is_sequence
    from tests.unit.module_utils import basic
    import os

    gca = GlobalCLIArgs.from_options(basic.get_opts())
    assert gca['step'] is False
    assert gca['start_at_task'] is None
    assert gca['diff'] is False
    assert gca['syntax'] is False
    assert gca['connection'] == 'smart'
    assert gca['module_path'] == [os.getcwd()]
    assert gca['module_path'] is not [os.getcwd()]
    is_sequence(gca['module_path'])
    is_sequence(gca['module_path'])
    assert gca['forks'] == 5

# Generated at 2022-06-21 08:26:59.548860
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Subclass(_ABCSingleton):
        pass

    assert len(set(Subclass.__subclasses__())) == 1

# Generated at 2022-06-21 08:27:06.197639
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Singleton and ABCMeta should be unambiguous
    class NewCLIArgs(CLIArgs, metaclass=_ABCSingleton):
        pass

# Generated at 2022-06-21 08:27:19.056144
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test that GlobalCLIArgs is both Singleton and ImmutableDict.

    We construct two GlobalCLIArgs instances, make sure they are actually the same instance and also
    that they are immutable.
    """
    some_vars = {'debug': True, 'var': {'key': 'value'}}
    first = GlobalCLIArgs(some_vars)
    second = GlobalCLIArgs(some_vars)
    assert first is second
    assert first == second
    with pytest.raises(AttributeError) as excinfo:
        first.debug = False
    assert "object has no attribute 'debug'" in str(excinfo.value)
    with pytest.raises(AttributeError) as excinfo:
        first.var['key'] = 'another value'

# Generated at 2022-06-21 08:27:25.496113
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({'foo': ['bar', 'baz'], 'chup': {'quep': ['wup', 'dup']}})
    assert isinstance(args, (Mapping, Container))
    assert isinstance(args['foo'], Sequence)
    assert isinstance(args['foo'][0], text_type)
    assert isinstance(args['foo'][1], text_type)
    assert isinstance(args['chup'], Mapping)
    assert isinstance(args['chup']['quep'], Sequence)
    assert isinstance(args['chup']['quep'][0], text_type)
    assert isinstance(args['chup']['quep'][1], text_type)

# Generated at 2022-06-21 08:27:30.497457
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    tempdict = {}
    tempdict["foo"] = "bar"
    tempdict["baz"] = "qux"
    tempdict["norf"] = "thud"

    args = GlobalCLIArgs.from_options(tempdict)
    assert args['foo'] == "bar"

# Generated at 2022-06-21 08:27:41.198012
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        @classmethod
        def singleton(cls):
            pass

    class B(A):
        pass

    class C(A):
        # Now A is no longer virtual
        pass

    # B should be a subclass of A
    assert issubclass(B, A)
    # A should be a subclass of B
    assert issubclass(A, B)
    # A should be a subclass of A
    assert issubclass(A, A)
    # B should be a subclass of B
    assert issubclass(B, B)

    # B and A should be different classes
    assert B != A
    # A and C should be different classes
    assert A != C



# Generated at 2022-06-21 08:27:45.497458
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    foo = GlobalCLIArgs({'a': 1, 'b': 'foo', 'c': {'d': 2, 'e': ['bar', 'baz', 1]}})
    assert foo == {'a': 1, 'b': 'foo', 'c': {'d': 2, 'e': ('bar', 'baz', 1)}}

# Generated at 2022-06-21 08:27:48.020514
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = CLIArgs({'some': 'value'})
    b = GlobalCLIArgs({'some': 'value'})
    assert a != b

# Generated at 2022-06-21 08:27:53.762654
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _Test(_ABCSingleton):
        def __init__(self):
            pass

    class _TestBad(_ABCSingleton, Mapping):
        def __init__(self):
            pass

    _Test()
    try:
        _TestBad()
        raise AssertionError("_TestBad() should raise TypeError, but did not")
    except TypeError:
        pass


# Generated at 2022-06-21 08:28:05.158301
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'argument1': 'value1',
                    'argument2': 'value2',
                    'argument3': {'subargument1': 'subvalue1',
                                  'subargument2': 'subvalue2'},
                    'argument4': [
                        {'sublist_subargument1': 'sublist_subvalue1',
                         'sublist_subargument2': 'sublist_subvalue2'}
                    ]})

# Generated at 2022-06-21 08:28:07.155825
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    CLIArgs({})
    CLIArgs({'a': 1, 'b': 2})



# Generated at 2022-06-21 08:28:20.457564
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = GlobalCLIArgs.from_options(ImmutableDict.from_mutable(dict(foo='bar')))
    b = GlobalCLIArgs.from_options(ImmutableDict.from_mutable(dict(foo='bar')))
    assert a == b
    assert a is b

# Generated at 2022-06-21 08:28:24.903838
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_args1 = GlobalCLIArgs.create(dict(a=1))
    global_args2 = GlobalCLIArgs.create(dict(a=1))
    assert global_args1.a == 1
    assert global_args2.a == 1
    assert global_args1 == global_args2

# Generated at 2022-06-21 08:28:33.992502
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import json
    import os
    from ansible.module_utils.common.collections import is_immutable
    from ansible.parsing.dataloader import DataLoader

    # create a dataloader so we can parse yaml to get our test arguments
    dl = DataLoader()

    test_args_file = os.path.join(os.path.dirname(__file__), os.path.pardir, 'test/utils/test_cli_args_data.yaml')
    test_args_yaml = dl.load_from_file(test_args_file)
    test_args_json = json.dumps(test_args_yaml)
    test_args = json.loads(test_args_json)
    cli_args = CLIArgs(test_args)

    assert cli_

# Generated at 2022-06-21 08:28:39.160429
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class X(metaclass=_ABCSingleton):
        pass

    class Y(X):
        pass

    class Z(X):
        def __new__(cls):
            return object.__new__(cls)

    assert issubclass(Y, X)
    assert issubclass(Z, X)

# Generated at 2022-06-21 08:28:49.715736
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.constants import DEFAULT_LOG_PATH
    from ansible.release import __version__
    from ansible.utils.display import Display

    args = GlobalCLIArgs({'DEFAULT_LOG_PATH': DEFAULT_LOG_PATH, 'verbosity': 0})

    assert isinstance(args, dict)

    assert isinstance(args['DEFAULT_LOG_PATH'], (text_type, binary_type))
    assert args['DEFAULT_LOG_PATH'] == DEFAULT_LOG_PATH

    assert isinstance(args['verbosity'], int)
    assert args['verbosity'] == 0

    assert '__version__' not in args
    assert args.get('__version__') != __version__
    assert args.get('__version__', '1.2.3') == '1.2.3'


# Generated at 2022-06-21 08:28:51.614890
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    g = GlobalCLIArgs({'key1': 1, 'key2': 'value2'})

# Generated at 2022-06-21 08:28:53.849456
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class C(object, metaclass=_ABCSingleton):
        pass



# Generated at 2022-06-21 08:29:04.908811
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.args import AnsibleOptions
    from ansible.module_utils.common.collections import Dict

    options = AnsibleOptions()
    options.test = 'This is a test'

    # Because this is a Singleton, it should only create one instance
    # of the object, no matter how many times we call the constructor.
    # Note that because this is a Singleton, we can't explicitly
    # test it in the same executable as anything that imports GlobalCLIArgs.
    # Otherwise we'd be trying to use 'from ansible.module_utils.common.args import GlobalCLIArgs'
    # to create a new instance of the class.
    global_cli_args = GlobalCLIArgs.from_options(options)
    assert isinstance(global_cli_args, Dict)
    assert global_

# Generated at 2022-06-21 08:29:07.451759
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABCSingleton(object, metaclass=_ABCSingleton):
        def __init__(self):
            self.foo = 'bar'

    assert isinstance(TestABCSingleton(), TestABCSingleton)

# Generated at 2022-06-21 08:29:12.472539
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class X(_ABCSingleton):
        def __init__(self, t):
            self.t = t

    x1 = X(1)
    x2 = X(2)

    assert x1 is x2
    assert x1.t == 2 and x2.t == 2

# Generated at 2022-06-21 08:29:44.026042
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _SingletonTest(GlobalCLIArgs):
        pass

# Generated at 2022-06-21 08:29:50.022159
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    d = dict(a=1, b=2, c=dict(d=3, e=dict(f=4)), g=set([5, 6]), h=[7, 8])
    args = CLIArgs(d)
    assert args.a == 1
    assert args.b == 2
    assert args.c.d == 3
    assert args.c.e.f == 4
    assert args.g == set([5, 6])
    assert args.h == (7, 8)
    assert args.c is not d['c']


# Generated at 2022-06-21 08:30:01.978789
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test = {'toplevel': 'test1', 'sub_dict': {'sub_dict_key': 'test2', 'sub_list': ['test3', 'test4']}}
    cli_args = CLIArgs(test)
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args['toplevel'] == 'test1'
    assert cli_args['sub_dict']['sub_dict_key'] == 'test2'
    assert cli_args['sub_dict']['sub_list'][0] == 'test3'
    assert cli_args['sub_dict']['sub_list'][1] == 'test4'
    assert cli_args.toplevel == 'test1'

# Generated at 2022-06-21 08:30:05.514569
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    a = A()
    b = B()
    assert a is b, "Created different instances of class B, shouldn't be possible"

# Generated at 2022-06-21 08:30:06.197893
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    pass

# Generated at 2022-06-21 08:30:14.835381
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    class TestOptions(object):
        pass
    test_options = TestOptions()
    # Make options look like command line options
    test_options.connection = 'local'
    test_options.module_path = sys.path
    test_options.module_args = 'echo Hello World!'
    test_options.forks = 5

    test_cli_args = CLIArgs.from_options(test_options)

    assert test_cli_args.connection == 'local'
    assert test_cli_args.module_path == sys.path
    assert test_cli_args.module_args == 'echo Hello World!'
    assert test_cli_args.forks == 5

# Generated at 2022-06-21 08:30:25.853222
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Create a mutable dict, create a GlobalCLIArgs from it and test that it can't be changed
    # NOTE: This test is based on ImmutableDict's test, test_MutableMapping
    test_dict = {u'spam': u'eggs', u'foo': u'bar'}
    i = GlobalCLIArgs(test_dict)
    assert i == test_dict
    # Modifications should fail
    test_dict = {u'spam': u'foo', u'foo': u'bar'}
    i = GlobalCLIArgs(test_dict)
    try:
        i[u'spam'] = u'foo'
    except TypeError:
        pass
    else:
        assert False, "MutableGlobalCLIArgs fails to raise TypeError on __setitem__"

# Generated at 2022-06-21 08:30:27.961186
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(A):
        pass

# Generated at 2022-06-21 08:30:35.631550
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, ABCMeta)
    assert issubclass(_ABCSingleton, Singleton)
    assert not issubclass(ABCMeta, _ABCSingleton)
    assert not issubclass(Singleton, _ABCSingleton)
    assert _ABCSingleton is not ABCMeta
    assert _ABCSingleton is not Singleton
    assert _ABCSingleton != type
    assert _ABCSingleton != ABCMeta
    assert _ABCSingleton != Singleton
    assert _ABCSingleton.__name__ == '_ABCSingleton'
    assert _ABCSingleton.__module__ == __name__



# Generated at 2022-06-21 08:30:42.771861
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(Singleton):
        def __init__(self, value):
            self.value = value
    assert A(5) == A(5)
    assert A(5) is not A(6)

    class B(metaclass=_ABCSingleton):
        def __init__(self, value):
            self.value = value
    assert B(5) == B(5)
    assert B(5) is not B(6)

    class C(B):
        pass
    assert C(5) == C(5)
    assert C(5) is not C(6)

    class D(B, Singleton):
        def __init__(self, value):
            self.value = value
    assert D(5) == D(5)
    assert D(5) is not D(6)


# Generated at 2022-06-21 08:31:28.858880
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest

    from ansible.module_utils.common.cli import CLI
    from ansible.module_utils.common.cli import CLIArgs

    # monkeypatch CLI.get_optparser() to return a mock object
    CLI.__dict__['_optparser'] = None
    def optparser_factory():
        import sys
        import mock
        class OptionParser(mock.Mock):
            args = sys.argv[1:]

            def add_option(self, *args, **kwargs):
                pass

            def parse_args(self, args=None):
                return self.args

        return OptionParser()

    CLI.get_optparser = optparser_factory

    # call the constructor and test that the result is what we expect
    assert CLIArgs.from_options(GlobalCLIArgs) == []



# Generated at 2022-06-21 08:31:39.456401
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    cli_args = CLIArgs({
        'test_1': 1,
        'test_2': {
            'test_3': True,
            'test_4': [
                {
                    'test_5': 'test'
                }
            ]
        }
    })

    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args['test_1'], int)
    assert cli_args['test_1'] == 1

    assert isinstance(cli_args['test_2'], ImmutableDict)
    assert isinstance(cli_args['test_2']['test_3'], bool)
    assert cli_args['test_2']['test_3'] is True


# Generated at 2022-06-21 08:31:42.411292
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_args = {'test': {'test2': ['test3', 'test4']}}
    cli_args = GlobalCLIArgs(test_args)
    cli_args['test']['test2'].append('test5')
    assert cli_args == test_args

# Generated at 2022-06-21 08:31:47.264667
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    class D(B, C):
        pass

    assert A is B
    assert A is C
    assert A is D

# Generated at 2022-06-21 08:31:58.634494
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Generate a bunch of nested data types and run them through the CLIArgs class constructor
    to check that the data is made immutable.
    """
    import copy
    import random

    # The tests are currently only checking the constructor, not the overridden methods
    # so we are going to simulate the dictionary that comes from the options parser