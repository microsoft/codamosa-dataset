

# Generated at 2022-06-21 08:22:15.390430
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        pass

    class B(A, metaclass=_ABCSingleton):
        pass

    try:
        A()
        assert 0, "Shouldn't be able to create an instance of A"
    except TypeError:
        pass

    a = B()
    b = B()

    assert a is b, "B should be a singleton"

# Generated at 2022-06-21 08:22:18.583010
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class A(object):
        __metaclass__ = _ABCSingleton

    # Create two instances, they should be the same
    a = A()
    b = A()
    assert a is b

# Generated at 2022-06-21 08:22:24.103065
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Instantiate class GlobalCLIArgs and check that it raises exception if initialised more than once
    """
    # Args are not provided so the first call to constructor raises an exception
    args_1 = GlobalCLIArgs({})
    with pytest.raises(Exception):
        args_2 = GlobalCLIArgs({})
    # compare the two objects
    assert args_1 == args_2

# Generated at 2022-06-21 08:22:30.073297
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    # Test Constructor
    args = CLIArgs({'a': {'b': {'c': {'d': {'e': {'f': 'g'}}}}}})

    assert isinstance(args, ImmutableDict)
    assert isinstance(args['a'], ImmutableDict)
    assert isinstance(args['a']['b'], ImmutableDict)
    assert isinstance(args['a']['b']['c'], ImmutableDict)
    assert isinstance(args['a']['b']['c']['d'], ImmutableDict)
    assert isinstance(args['a']['b']['c']['d']['e'], ImmutableDict)

# Generated at 2022-06-21 08:22:41.928930
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class FakeOption(object):
        def __init__(self):
            self.verbosity = 0
            self.debug = 0
            self.check = False
            self.diff = False
            self.inventory = []
            self.module_path = []
            self.forks = 5
            self.become = False
            self.become_method = 'sudo'
            self.become_user = 'root'
            self.become_ask_pass = False
            self.listhosts = None
            self.syntax = None
            self.connection = 'smart'
            self.timeout = 10
            self.remote_user = 'root'
            self.private_key_file = []
            self.ssh_common_args = ''
            self.ssh_extra_args = ''
            self.sftp_extra

# Generated at 2022-06-21 08:22:54.001359
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Create CLIArgs object with 2 keys
    cli_args = CLIArgs({'key1': 'value1', 'key2': 'value2'})
    # Make sure the object is immutable
    with pytest.raises(TypeError):
        cli_args['key3'] = 'value3'
    # Make sure the object has the correct key-value pair
    assert cli_args['key1'] == 'value1'
    assert cli_args['key2'] == 'value2'
    # Make sure the object is singleton
    cli_args2 = GlobalCLIArgs()
    assert cli_args == cli_args2
    # Test toString method
    assert str(cli_args) == str(cli_args2)
    assert str(cli_args) == str(cli_args.copy())

# Generated at 2022-06-21 08:23:01.444604
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options:
        def __init__(self):
            self.connection = 'ssh'
            self.module_path = '/a/b/c'
            self.foo = 'bar'

    options = Options()
    args = GlobalCLIArgs.from_options(options)
    assert args.get('connection') == 'ssh'
    assert args.get('module_path') == '/a/b/c'
    assert args.get('foo') == 'bar'


__all__ = ('GlobalCLIArgs', 'CLIArgs')

# Generated at 2022-06-21 08:23:08.483352
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    original_dict = {'key1': 'val1', 'key2': ['val2'], 'key3': [{'key31': 'val31'}, {'key32': 'val32'}]}

    expected_dict = {'key1': 'val1',
                     'key2': ('val2',),
                     'key3': ({'key31': 'val31'}, {'key32': 'val32'})}

    test_cli_args = CLIArgs(original_dict)
    assert test_cli_args == expected_dict

# Generated at 2022-06-21 08:23:11.049735
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    singleton = CLIArgs({'logging': {'debug': True}})
    singleton2 = CLIArgs({'logging': {'debug': False}})
    assert singleton is not singleton2

# Generated at 2022-06-21 08:23:19.205734
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test GlobalCLIArgs singleton by asserting that 2 GlobalCLIArgs are the same
    """
    a = GlobalCLIArgs({'test': 'value'})
    b = GlobalCLIArgs.get_instance()
    assert a is b
    # Test that singleton objects are not mutated when other objects are mutated
    aa = GlobalCLIArgs({'test': 'value'})
    bb = GlobalCLIArgs.get_instance()
    assert aa is bb
    assert aa == a

# Generated at 2022-06-21 08:23:28.533429
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class S1(object):
        __metaclass__ = _ABCSingleton

    try:
        S2 = type('S2', (S1,), {})
    except TypeError as e:
        assert e.message == "metaclass conflict: the metaclass of a derived class must be a (non-strict) subclass of the metaclasses of all its bases"
    else:
        raise AssertionError('TypeError should have been raised')


# Generated at 2022-06-21 08:23:40.542275
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import pytest
    from collections import namedtuple
    from ansible.module_utils.common.collections import is_immutable

    # Test with a dictionary
    args = {
                'test': {
                    'one': 1,
                    'two': 'two',
                }
            }
    assert is_immutable(CLIArgs(args))
    assert is_immutable(args['test'])

    # Test with a named tuple
    Args = namedtuple('Args', ['one', 'two'])
    args = Args(one=[1, 2, 3], two=[1, 2, 3, 4])
    converted_args = CLIArgs.from_options(args)
    assert is_immutable(converted_args)
    assert is_immutable(converted_args['one'])
    assert is_immutable

# Generated at 2022-06-21 08:23:44.682999
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class TestClass(_ABCSingleton):
        def __init__(self, test_value):
            self.test_value = test_value

    obj_a = TestClass(0)
    obj_b = TestClass(1)
    assert obj_a == obj_b

# Generated at 2022-06-21 08:23:55.444922
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    #_make_immutable test
    assert _make_immutable(ImmutableDict({'a':1})) == ImmutableDict({'a':1})
    assert _make_immutable([1,2, ImmutableDict({'a':1})]) == (1,2, ImmutableDict({'a':1}))
    assert _make_immutable(set([1,2, ImmutableDict({'a':1})])) == set([1,2, ImmutableDict({'a':1})])
    assert _make_immutable('abc') == 'abc'
    assert _make_immutable(u'abc') == u'abc'

# Generated at 2022-06-21 08:24:06.953978
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Check that only one instance of GlobalCLIArgs exists
    cli_args = GlobalCLIArgs()
    assert cli_args is GlobalCLIArgs()

    # Check that the constructor produces the right object
    raw_mapping = {'something': 'value',
                   'other': ['other_value', 'yet_another_value'],
                   'there': {'is_another': 'value'}}
    cli_args = GlobalCLIArgs(raw_mapping)
    for key, value in raw_mapping.items():
        if isinstance(value, Container):
            assert cli_args[key] == _make_immutable(value)
        else:
            assert cli_args[key] == value
    assert len(cli_args) == len(raw_mapping)



# Generated at 2022-06-21 08:24:09.968115
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = CLIArgs()
    assert options

# Generated at 2022-06-21 08:24:14.591783
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.argspec._get_arg_spec import options
    opt = options(['-K', '-i', 'inventory', '--force-handlers', '--list-tasks', '-k'])
    a = CLIArgs.from_options(opt)
    assert a.get('force_handlers')
    assert a.get('list_tasks')
    assert a.get('ask_pass')
    assert a.get('inventory') == 'inventory'

# Generated at 2022-06-21 08:24:17.007213
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _TestClass(_ABCSingleton):
        def __init__(self, x):
            self.x = x

    t1 = _TestClass(5)
    t2 = _TestClass(6)
    assert t1.x == 5 and t2.x == 5



# Generated at 2022-06-21 08:24:23.878079
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.errors import AnsibleParserError, AnsibleUndefinedVariable
    from ansible.config.manager import ConfigManager
    from ansible.config.parser import ConfigParser
    from ansible.constants import DEFAULTS
    from ansible.utils.vars import combine_vars

    config_manager = ConfigManager()
    parser = ConfigParser(config_manager=config_manager)
    options = parser.parse_args(['--foo', 'bar',
                                 '--baz', 'qux',
                                 '--listen',
                                 '--listen-port', '9999',
                                 '--diff',
                                 '--check'])
    options_dict = vars(options)

    # Make sure that the options we expect are there
    assert options_dict['foo'] == 'bar'
    assert options_dict

# Generated at 2022-06-21 08:24:29.048284
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    global cli_args
    cli_args = CLIArgs({"a": "b", "c": {"d": "e"}})
    assert cli_args.get("a") == "b"
    assert cli_args.get("c").get("d") == "e"
    cli_args = CLIArgs({})


# Generated at 2022-06-21 08:24:37.537924
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    obj = CLIArgs({'a': {'b': [1, 2, 3]}})
    assert obj['a']['b'][1] == 2
    obj['a']['b'][1] = None  # ImmutableDict should prevent change
    assert obj['a']['b'][1] == 2



# Generated at 2022-06-21 08:24:47.031527
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.plugin_docs import read_docstring
    from ansible.cli import CLI
    from ansible.plugins import module_loader

    Options = CLI.base_parser(None, usage='usage: %prog [options]',
                              module_opts=read_docstring(module_loader, verbose=False))
    Options.add_options()

    (options, args) = Options.parse_args(['-T', '60', '-v', '-vvvv'])

    GlobalCLIArgs.from_options(options)

    loader = DataLoader()
    GlobalCLIArgs.from_options(options)

    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-21 08:24:48.693989
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({})
    assert isinstance(args, GlobalCLIArgs)

# Generated at 2022-06-21 08:24:52.822890
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(metaclass=_ABCSingleton):
        pass

    @add_metaclass(_ABCSingleton)
    class C(A):
        pass

    assert A is B
    assert C is B

# Generated at 2022-06-21 08:24:56.517864
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common._collections_compat import Mapping

    mapping = {'a': {'b': {'c': 'd'}}}
    assert isinstance(CLIArgs(mapping), Mapping)

# Generated at 2022-06-21 08:25:04.505975
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Test that _ABCSingleton doesn't error out
    """
    # pylint: disable=no-init, abstract-method
    class TestABCSingleton(object):
        __metaclass__ = _ABCSingleton

    # The following should error without _ABCSingleton set properly
    # pylint: disable=too-few-public-methods
    class SpecialTestABCSingleton(TestABCSingleton):
        pass

    assert isinstance(TestABCSingleton(), TestABCSingleton)
    assert isinstance(SpecialTestABCSingleton(), SpecialTestABCSingleton)
    assert not isinstance(SpecialTestABCSingleton(), TestABCSingleton)



# Generated at 2022-06-21 08:25:12.932149
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        pass

    test_options = Options()
    test_options.a = 'test'
    test_options.b = True
    test_options.c = {'foo': 'bar', 'baz': 'qux'}
    test_options.d = [{'x': 'y'}, {'b': 'c'}]

    my_cli_args = CLIArgs.from_options(test_options)
    assert my_cli_args['a'] == 'test'
    assert my_cli_args['b'] is True
    assert my_cli_args['c'] == ImmutableDict({'foo': 'bar', 'baz': 'qux'})

# Generated at 2022-06-21 08:25:14.172637
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from abc import ABCMeta
    assert issubclass(GlobalCLIArgs, CLIArgs)



# Generated at 2022-06-21 08:25:23.711934
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.display import Display
    from ansible.module_utils.common.collections import is_immutable

    class MockOptions(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    options = MockOptions(ask_vault_pass=True, verbosity=Display.VERBOSITY_NORMAL,
                          extra_vars={"greeting": "Hello"},
                          check=False, diff=True)
    args = CLIArgs.from_options(options)
    assert args.ask_vault_pass is True
    assert args.verbosity == 1
    assert args.check is False
    assert is_immutable(args)
    # We test the immutability of any values at the top level of the dict by changing the value of
    #

# Generated at 2022-06-21 08:25:35.217902
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import tempfile
    import os
    import shutil


# Generated at 2022-06-21 08:25:48.044977
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Make sure that constructor of class GlobalCLIArgs is a singleton.
    import ansible.module_utils.common.arguments as arguments
    import unittest
    class_test = unittest.TestCase()
    # Create new object of GlobalCLIArgs
    obj_test = arguments.GlobalCLIArgs()
    # Create another object of GlobalCLIArgs
    obj2_test = arguments.GlobalCLIArgs()
    # Now compare the memory address of both the objects
    class_test.assertEqual(id(obj_test), id(obj2_test), msg=None)
test_GlobalCLIArgs()

# Generated at 2022-06-21 08:25:56.787128
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    d = dict(a=1, b=dict(c=2, d=dict(e=3)), f=4)
    a = CLIArgs(d)
    assert isinstance(a, Mapping)
    assert not isinstance(a, MutableMapping)
    assert isinstance(a['b'], Mapping)
    assert not isinstance(a['b'], MutableMapping)
    assert isinstance(a['b']['d'], Mapping)
    assert not isinstance(a['b']['d'], MutableMapping)
    assert a['f'] == 4
    assert a['b']['c'] == 2
    assert a['b']['d']['e'] == 3


# Generated at 2022-06-21 08:25:58.971295
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs.reset()

# Generated at 2022-06-21 08:26:08.852906
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        def __init__(self, x):
            self.x = x

    class B(object):
        def __init__(self, x):
            self.x = x

    class C(A):
        def __init__(self, x):
            super(C, self).__init__(x)

    class D(A):
        def __init__(self, x):
            self.x = x

    class Test(_ABCSingleton):
        pass

    class E(Test):
        pass

    class F(Test, A):
        def __init__(self, x):
            super(F, self).__init__(x)

    class G(Test, B):
        def __init__(self, x):
            super(G, self).__init__(x)


# Generated at 2022-06-21 08:26:18.278777
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-21 08:26:21.199718
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # pylint: disable=missing-docstring
    class YYY(object):
        __metaclass__ = _ABCSingleton
    y = YYY()
    z = YYY()
    assert y is z

# Generated at 2022-06-21 08:26:32.252865
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {
        'one': 1,
        'two': 'two',
        'three': ['3a', '3b'],
        'four': {'4a': 'sub-a', '4b': 'sub-b'}}
    cli_args = CLIArgs(args)
    assert cli_args == args
    assert cli_args['one'] == args['one']
    assert cli_args['two'] == args['two']
    assert cli_args['three'] == args['three']
    assert cli_args['four'] == args['four']
    assert cli_args['one'] is not args['one']
    assert cli_args['two'] is not args['two']
    assert cli_args['three'] is not args['three']

# Generated at 2022-06-21 08:26:35.809369
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {'become_user': 'foo', 'become': 'yes'}
    cli_args = CLIArgs(args)
    assert cli_args == {'become_user': 'foo', 'become': 'yes'}



# Generated at 2022-06-21 08:26:43.599140
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args1 = GlobalCLIArgs({'a': 'value-a', 'b': 'value-b'})
    # test hashable
    assert args1 == args1
    assert hash(args1) == hash(args1)

    args2 = GlobalCLIArgs({'c': 'value-c', 'd': 'value-d'})
    # test hashable
    assert args1 == args1
    assert hash(args1) == hash(args1)

    assert args1 != args2



# Generated at 2022-06-21 08:26:55.122640
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Verify that we retain original types
    immutable_mapping = CLIArgs({
        'string': 'a string',
        'integer': 13,
        'boolean': True,
        'list': [1, 3, 3, 7],
        'set': set([1, 3, 3, 7]),
        'dict': {
            'string': 'a string',
            'integer': 13,
            'boolean': True,
            'list': [1, 3, 3, 7],
            'set': set([1, 3, 3, 7]),
        },
    })._data
    assert isinstance(immutable_mapping, ImmutableDict)
    assert isinstance(immutable_mapping['string'], text_type)
    assert isinstance(immutable_mapping['integer'], int)

# Generated at 2022-06-21 08:27:10.552070
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingletonMetaclass(object):
        __metaclass__ = _ABCSingleton

    class TestSingletonABC(TestSingletonMetaclass):
        """This is a test"""

    assert TestSingletonABC.__doc__ == TestSingletonMetaclass.__doc__

# Generated at 2022-06-21 08:27:13.914228
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingleABC(metaclass=_ABCSingleton):
        pass

    # Not a Singleton, so can create multiple instances
    SingleABC()
    SingleABC()

# Generated at 2022-06-21 08:27:23.105983
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Test one level deep
    args = GlobalCLIArgs()
    args["ansible_connection"] = "ssh"
    assert args.get("ansible_connection") == "ssh"
    try:
        args["ansible_connection"] = "paramiko"
    except TypeError:
        pass
    else:
        assert False, "Setting a value in a GlobalCLIArgs object should raise TypeError"
    assert len(args.keys()) == 1

    # Test two levels deep
    args["ansible_ssh_common_args"] = "-o ForwardAgent=yes"
    assert args.get("ansible_ssh_common_args") == "-o ForwardAgent=yes"
    try:
        args["ansible_ssh_common_args"] = "-o Compression=yes"
    except TypeError:
        pass

# Generated at 2022-06-21 08:27:32.182753
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # first it has same function as CLIArgs
    a = CLIArgs({'a': 1, 'b': {'c': 3}})
    b = GlobalCLIArgs({'a': 1, 'b': {'c': 3}})
    assert a == b
    assert type(a) is CLIArgs
    assert type(b) is GlobalCLIArgs
    # then make sure it is a singleton
    c = GlobalCLIArgs({'a': 1, 'b': {'c': 3}})
    assert c == b
    assert type(c) is GlobalCLIArgs

# Generated at 2022-06-21 08:27:35.445075
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'a': 'a'}
    cli_args = CLIArgs(mapping)
    assert cli_args['a'] == 'a'


# Generated at 2022-06-21 08:27:45.824725
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import collections
    import unittest

    class TestGlobalCLIArgs(unittest.TestCase):
        def setUp(self):
            # We will call GlobalCLIArgs and never call CLIArgs with these values
            self.args = collections.OrderedDict((('key', 'value'), ('key2', 'value2'), ('key3', 'value3')))
            self.global_args = GlobalCLIArgs.from_options(self.args)

        def test_init(self):
            self.assertEqual(self.global_args['key'], 'value')
            self.assertEqual(self.global_args['key2'], 'value2')
            self.assertEqual(self.global_args['key3'], 'value3')

# Generated at 2022-06-21 08:27:47.013307
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert (type(GlobalCLIArgs), ABCMeta)

# Generated at 2022-06-21 08:27:49.809113
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli.arguments import options
    args = GlobalCLIArgs.from_options(options)
    assert args['connection'] == 'smart'

# Generated at 2022-06-21 08:27:56.872491
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABCSingleton(object):
        __metaclass__ = _ABCSingleton
    class TestABCSingleton2(TestABCSingleton):
        pass
    class TestABCSingleton3(TestABCSingleton2):
        pass

    TestABCSingleton()
    TestABCSingleton2()
    TestABCSingleton3()

    class TestABCSingleton(object):
        __metaclass__ = _ABCSingleton
    class TestABCSingleton2(TestABCSingleton):
        pass

# Generated at 2022-06-21 08:28:07.899251
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # ImmutableDict calls tuple on its arguments.  It will explode if a list is passed.
    # This test is to ensure that no one makes the type change by accident.
    test_dict = {'a': 1, 'b': {'c': [1, 2, 3], 'd': [1, 2, 3]}}  # noqa F812
    cli_args = CLIArgs(test_dict)
    assert isinstance(cli_args['b'], ImmutableDict)
    assert isinstance(cli_args['b']['c'], tuple)
    assert isinstance(cli_args['b']['d'], tuple)
    assert cli_args == ImmutableDict({'a': 1, 'b': {'c': (1, 2, 3), 'd': (1, 2, 3)}})

# Generated at 2022-06-21 08:28:31.934590
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs.__new__.reset()  # Reset the new method for the singleton

    GlobalCLIArgs({'foo': 'bar'})

    assert GlobalCLIArgs.__new__.is_set()

# Generated at 2022-06-21 08:28:42.713101
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class FakeOptionsObject(object):
        def __init__(self, mapping):
            self.__dict__ = mapping

    options = FakeOptionsObject({'foo': [1,2,3,4], 'bar': {'quux': 'baz'}})
    cli_args = GlobalCLIArgs.from_options(options)

    assert isinstance(cli_args, GlobalCLIArgs)
    assert not hasattr(cli_args, '__setitem__')
    assert cli_args['foo'] == (1,2,3,4)
    assert cli_args['bar'] == ImmutableDict({'quux': 'baz'})
    assert cli_args['foo'] == cli_args['foo']
    assert cli_args['foo'] is not cli_args['foo']
    assert cli

# Generated at 2022-06-21 08:28:43.993151
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = GlobalCLIArgs({})
    assert a == ImmutableDict()

# Generated at 2022-06-21 08:28:56.267354
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import types
    import sys

    # Monkey patch to make the isinstance() test work
    original_import = __import__

    def _mock_import_module(name, *args):
        if name == "ansible.module_utils.common.collections":
            return types
        return original_import(name, *args)

    import sys
    sys.modules["__builtin__"] = types
    OriginalModuleType = types.ModuleType

    def _mock_isinstance(obj, class_or_tuple):
        # Fake isinstance() for types.ModuleType
        if class_or_tuple is types.ModuleType:
            return isinstance(obj, OriginalModuleType)
        return isinstance(obj, class_or_tuple)


# Generated at 2022-06-21 08:29:06.456246
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli = CLIArgs(
        dict(
            one=1,
            two=2,
            three=3,
            frozenset=frozenset([1, 2, 3]),
            tuple=tuple([1, 2, 3]),
            list=list([1, 2, 3]),
            dict=dict(one=1, two=2, three=3),
            set=set([1, 2, 3]),
        )
    )

# Generated at 2022-06-21 08:29:11.628987
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _Foo(object):
        __metaclass__ = _ABCSingleton

    assert isinstance(_Foo(), _Foo)
    assert issubclass(_Foo, ABCMeta)
    assert issubclass(_Foo, Singleton)

# Generated at 2022-06-21 08:29:16.829653
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    data = {'foo': 'bar'}
    instance = GlobalCLIArgs.from_options(data)
    assert instance['foo'] == 'bar'
    try:
        instance['foo'] = 'baz'
        assert False, "should not get here"
    except TypeError:
        # We expect to get a TypeError if we try to change the value of foo
        pass

# Generated at 2022-06-21 08:29:23.879900
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # create a class instance
    test_instance = CLIArgs({'foo': 'bar', 'baz': 'qux'})
    # we expect an ImmutableDict data type
    assert isinstance(test_instance, ImmutableDict)
    # we expect to hold a parsed copy of cli_args
    assert test_instance == {'foo': 'bar', 'baz': 'qux'}


# Generated at 2022-06-21 08:29:31.368764
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {'debug': True, 'connection': 'smart', 'other_args': ['ansible', '-m', 'ping', 'localhost']}
    a = CLIArgs(args)
    assert a['debug'] is True
    assert a['connection'] == 'smart'
    assert a['other_args'] == tuple(['ansible', '-m', 'ping', 'localhost'])

# Generated at 2022-06-21 08:29:35.471087
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    try:
        global_cli_args1 = GlobalCLIArgs({'test_key': 'test_value'})
        global_cli_args2 = GlobalCLIArgs({'test_key': 'test_value'})
        global_cli_args3 = GlobalCLIArgs({'test_key': 'test_value'})
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-21 08:30:51.570112
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    testdict = {'foobar': 'baz'}
    x = CLIArgs(testdict)
    assert x['foobar'] == 'baz'

    testdict = {'foobar': ['baz', 'baz']}
    x = CLIArgs(testdict)
    assert x['foobar'] == ('baz', 'baz')

    testdict = {'foobar': {'foo': 'bar', 'fuz': 'baz'}}
    x = CLIArgs(testdict)
    assert isinstance(x['foobar'], ImmutableDict)
    assert x['foobar']['foo'] == 'bar'

    testdict = {'foobar': ({'foo': {'bar': 'baz'}})}
    x = CLIArgs(testdict)

# Generated at 2022-06-21 08:30:59.899157
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Setup test object
    class Testing(GlobalCLIArgs):
        def __init__(self, arg_dict):
            super(Testing, self).__init__(arg_dict)

    arg_dict = {}
    arg_dict['two'] = 2
    arg_dict['three'] = [1, 2, 3]
    arg_dict['four'] = ('a', 'b', 'c')
    arg_dict['five'] = {'a': 1, 'b': 2}
    arg_dict['six'] = {1, 2}
    arg_dict['seven'] = ''

    testing1 = Testing(arg_dict)
    testing2 = Testing(arg_dict)

    # Assert test object is initialized correctly
    assert testing1 == testing2
    assert testing1 is testing2

# Generated at 2022-06-21 08:31:11.922288
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Alpha(object):
        pass

    assert set(Alpha.__mro__) == set([Alpha, object]), "Unexpected MRO"
    assert not isinstance(Alpha, Singleton), "Inherited from Singleton when we shouldn't"
    assert not isinstance(Alpha, ABCMeta), "Inherited from ABCMeta when we shouldn't"

    class Bravo(metaclass=Alpha):
        pass

    assert set(Bravo.__mro__) == set([Bravo, object]), "Unexpected MRO"
    assert not isinstance(Alpha, Singleton), "Inherited from Singleton when we shouldn't"
    assert not isinstance(Alpha, ABCMeta), "Inherited from ABCMeta when we shouldn't"

    class Charlie(metaclass=_ABCSingleton):
        pass


# Generated at 2022-06-21 08:31:22.632458
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    a = CLIArgs(dict(a=1, b='2', c=True, d=None))
    assert a['a'] == 1
    assert a['b'] == '2'
    assert a['c'] is True
    assert a['d'] is None

    b = CLIArgs(dict(a=dict(b=dict(c=1, d='1'))))
    assert b['a']['b']['c'] == 1
    assert b['a']['b']['d'] == '1'

    c = CLIArgs(dict(a=[dict(c=1), dict(d='1')]))
    assert c['a'][0]['c'] == 1
    assert c['a'][1]['d'] == '1'

    d = CLIArgs(dict(a=[1, '1']))


# Generated at 2022-06-21 08:31:30.505656
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {"string_entry": "string_value",
                 "list_entry": ["list", "of", "values"],
                 "dict_entry": {"dict": "of", "values": "and", "lists": ["inside"]}}

    expected_dict = {"string_entry": "string_value",
                     "list_entry": ("list", "of", "values"),
                     "dict_entry": ImmutableDict({"dict": "of", "values": "and", "lists": ("inside",)}),
                     }

    assert CLIArgs(test_dict) == expected_dict

# Generated at 2022-06-21 08:31:40.508540
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test class constructor to make sure that it transforms a dict into an immutable dict of
    frozen dicts, frozen sets, and frozen tuples.
    """

# Generated at 2022-06-21 08:31:45.779037
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class DummyCLIOptions(object):
        def __init__(self, **kwargs):
            for name, value in kwargs.items():
                setattr(self, name, value)


# Generated at 2022-06-21 08:31:49.899317
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs.__init__( {} )
    # It is ok to explicitly call __init__ but using it to perform initialization is an error
    try:
        GlobalCLIArgs.__init__( {'foo': 'bar'} )
        assert False
    except RuntimeError:
        pass

# Generated at 2022-06-21 08:32:00.680242
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from prettytable import PrettyTable
    from ansible.config.data import ConfigData

    class Options:
        def __init__(self, config_file=None, playbook='/tmp/playbook'):
            self.config_file = config_file
            self.playbook = playbook
            self.print_table = None
            self.formatter = None
            self.display_args_to_stdout = None
            self.display_skipped_hosts = None
            self.display_ok_hosts = None
            self.display_failed_stderr = None
            self.extra_vars = None
            self.diff = None
            self.host_key_checking = None
            self.verbosity = None
            self.verbose_override = None
            self.connection = None
            self.check = None
           

# Generated at 2022-06-21 08:32:06.922942
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    global_args = GlobalCLIArgs(vars(argparse.Namespace()))
    assert isinstance(global_args, ImmutableDict)
    assert isinstance(global_args, CLIArgs)
    assert isinstance(global_args, GlobalCLIArgs)
    assert isinstance(global_args, Mapping)
    assert isinstance(global_args, Container)
    assert isinstance(global_args, Sequence)
    assert not isinstance(global_args, Set)
    assert global_args == {}

