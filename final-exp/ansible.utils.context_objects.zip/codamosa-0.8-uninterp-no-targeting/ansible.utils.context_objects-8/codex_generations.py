

# Generated at 2022-06-21 08:22:16.546520
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class _TestBase(object, metaclass=_ABCSingleton):
        pass

    class _Test_1(_TestBase):
        pass

    assert id(_Test_1()) == id(_Test_1())
    assert id(_Test_1()) != id(_TestBase())



# Generated at 2022-06-21 08:22:27.401018
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.path import unfrackpath
    from ansible.cli import CLI
    from ansible.cli.arguments import optparse_helpers

    cli = CLI(["--module-path", ".", "--forks", "42"])

    assert cli.options.module_path == unfrackpath(".")
    assert cli.options.forks == 42

    cli_args = CLIArgs.from_options(cli.parser.values)

    assert cli_args.module_path == unfrackpath(".")
    assert cli_args.forks == 42

    # Make sure we have an immutable copy.  The copy should be
    # immutable, but the original should still be mutable
    with pytest.raises(TypeError):
        cli_args["module_path"] = "a different string"
   

# Generated at 2022-06-21 08:22:31.724426
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test1:
        def __init__(self):
            pass
    class Test2(Test1):
        def __init__(self):
            pass
    Test0 = _ABCSingleton("Test0", (Test1,), {})
    Test3 = _ABCSingleton("Test3", (Test2,), {})
    Test4 = _ABCSingleton("Test4", (Test2,), {})

# Generated at 2022-06-21 08:22:35.381766
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    first_copy = GlobalCLIArgs.from_options(GlobalCLIArgs.from_options(GlobalCLIArgs()))
    assert id(first_copy) == id(GlobalCLIArgs())



# Generated at 2022-06-21 08:22:46.018571
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # test1: Empty mapping
    result = CLIArgs(dict())
    assert result
    # test2: No value of dict is Container
    result = CLIArgs(dict(a=1, b=2, c=3))
    assert result
    # test3: Some values are Containers
    assert CLIArgs(dict(a=1, b=dict(), c=3))
    assert CLIArgs(dict(a=1, b=[1, 2, 3], c=3))
    assert CLIArgs(dict(a=1, b=set(), c=3))
    # test4: All values are Containers
    assert CLIArgs(dict(a=dict(), b=[1, 2, 3], c=set()))

# Generated at 2022-06-21 08:22:51.496642
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        pass
    options = Options()

    options.args = ['cmd', 'arg']
    options.module_paths = ['mod/path', 'mod/path2']
    options.module_paths.append(['mod/path3', 'mod/path4'])
    options.module_paths.extend(['mod/path5', 'mod/path6'])
    options.tree = 'simple_tree'

    cli_args = CLIArgs.from_options(options)
    assert cli_args['args'] == ('cmd', 'arg')
    assert cli_args['module_paths'] == ('mod/path', 'mod/path2', ['mod/path3', 'mod/path4'], 'mod/path5', 'mod/path6')

# Generated at 2022-06-21 08:23:02.272620
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test constructor for class GlobalCLIArgs.

    The constructor might have been changed from the original CLIArgs constructor and this test
    would help to demonstrate which one is better
    """
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action="append", default=[])
    parser.add_argument('--bar', action="append", default=[])

    # args = parser.parse_args()
    args = parser.parse_args(['--foo', '123', '--foo', 'abc', '--bar', 'xyz'])
    GlobalCLIArgs.from_options(args)

    # We're not worried about actually checking the values, since this is a way to ensure
    # the constructor is actually being called

    # Set up the environment to test that we can't do anything to the object

# Generated at 2022-06-21 08:23:07.729614
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import os
    import shutil
    import tempfile
    from ansible.utils.display import Display

    class TestOptions:
        def __init__(self, foo, bar):
            self.foo = foo
            self.bar = bar

    tempdir = tempfile.mkdtemp(prefix='ansible_GlobalCLIArgs_test_')
    display = Display()
    options = TestOptions('baz', 'qux')

# Generated at 2022-06-21 08:23:10.652525
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    argv = ['/bin/ansible-playbook', '--check']
    parser = GlobalCLIArgs._create_parser(argv, 'foo')
    GlobalCLIArgs.from_options(parser.parse_args(argv))

# Generated at 2022-06-21 08:23:24.960251
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import json
    import unittest2 as unittest

    class TestGlobalCLIArgs(unittest.TestCase):
        def setUp(self):
            self.mapping = {"a": {"b": "c", "d": "e"}, "f": {"g": {"h": "i"}}}
            self.expected = {'a': {'b': 'c', 'd': 'e'}, 'f': {'g': {'h': 'i'}}}
            self.args = GlobalCLIArgs(self.mapping)

        def test_constructor(self):
            self.assertIsInstance(self.args, ImmutableDict)
            self.assertIsInstance(self.args, GlobalCLIArgs)

        def test_types(self):
            self.assertIsInstance(self.args, GlobalCLIArgs)


# Generated at 2022-06-21 08:23:34.456481
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # default behaviour
    assert isinstance(GlobalCLIArgs(), GlobalCLIArgs)
    assert isinstance(GlobalCLIArgs(), CLIArgs)

    # check that we can't set attributes using setattr
    try:
        setattr(GlobalCLIArgs(), 'test', 123)
        assert False
    except TypeError:
        assert True

    # check that we can set attributes using setitem and those attributes are immutable
    try:
        GlobalCLIArgs().__setitem__('test', 123)
        assert False
    except AttributeError:
        assert True

    # check that we can't del attributes using delattr
    try:
        delattr(GlobalCLIArgs(), 'test')
        assert False
    except TypeError:
        assert True

    # check that we can del attributes using delitem

# Generated at 2022-06-21 08:23:39.581711
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    dict1 = {'foo': 'bar'}
    dict2 = {'baz': 0}

    global_cli_args = GlobalCLIArgs(dict1)
    assert id(global_cli_args.from_options(dict2)) is id(global_cli_args)
    assert dict1 == dict2

# Generated at 2022-06-21 08:23:50.549932
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # test1
    cli_args = CLIArgs({"1": "2"})
    assert cli_args.get("1") == "2"

    # test2
    cli_args = CLIArgs({"1": "2", "3": {"4": "5"}})
    assert cli_args.get("1") == "2"
    assert cli_args.get("3").get("4") == "5"

    # test3
    cli_args = CLIArgs({"1": ["2", "3"], "4": {"5": ["6", "7"]}})
    assert cli_args.get("1") == ("2", "3")
    assert cli_args.get("4").get("5") == ("6", "7")

# Generated at 2022-06-21 08:23:58.658117
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():  # pragma: no cover
    import json
    import unittest
    import ansible.module_utils.basic

    class TestCase(unittest.TestCase):
        def setUp(self):
            args = ['--extra-vars', '@json_file', '--extra-vars', '{"var": "var"}']
            super(TestCase, self).setUp(args=args)

        def tearDown(self):
            super(TestCase, self).tearDown()

        def test_create_GlobalCLIArgs(self):
            # pylint: disable=attribute-defined-outside-init
            self.args = GlobalCLIArgs.from_options(self.options)
            self.assertTrue(isinstance(self.args, GlobalCLIArgs))
            # pylint: enable=attribute-defined-outside

# Generated at 2022-06-21 08:24:10.626904
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():  # pylint: disable=invalid-name
    from ansible.utils.display import Display
    from ansible.config.manager import ConfigManager, Setting, PosixCLI
    from ansible.cli import CLI
    from ansible.module_utils.six import PY3, iteritems, string_types

    class TestDisplay(Display):
        def __init__(self, verbosity=0, enabled=True):
            if not enabled:
                verbosity = 0
            self.verbosity = verbosity
            self._deprecation_count = 0
            self._deprecation_messages = {}
            self._warn_messages = {}
            self._warnings = 0

    Display.verbosity = 0
    display = TestDisplay(verbosity=0)

# Generated at 2022-06-21 08:24:13.140710
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections

    assert isinstance(CLIArgs(collections.OrderedDict()), ImmutableDict)
    # TODO: add more tests

# Generated at 2022-06-21 08:24:21.896412
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        def __init__(self):
            self.one = 1234
            self.two = 'string'
            self.three = ['string', 'list']
            self.four = {'a':1, 'b':2, 'c':3}
            self.five = {'a':'1', 'b':'2', 'c':'3'}
            self.six = [1, 2, 3, 4]
            self.seven = (1, 2, 3, 4)
            self.eight = {'a':1, 'b':2, 'c':3,
                          'd':{'dd':[1, 2, 3, 4], 'de':('1', '2', '3', '4')}}

# Generated at 2022-06-21 08:24:33.470619
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({"foo": 12})
    assert isinstance(args, ImmutableDict)
    assert len(args) == 1
    assert args["foo"] == 12

    args = CLIArgs({"foo": [1, 2, 3]})
    assert isinstance(args["foo"], tuple)
    assert len(args["foo"]) == 3
    assert args["foo"][0] == 1
    assert args["foo"][1] == 2
    assert args["foo"][2] == 3

    args = CLIArgs({"foo": {1: 2}})
    assert isinstance(args["foo"], ImmutableDict)
    assert len(args["foo"]) == 1
    assert args["foo"][1] == 2

    args = CLIArgs({"foo": set([1, 2, 3])})
    assert isinstance

# Generated at 2022-06-21 08:24:44.208020
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class TestOptions(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)
    args = {"test1": TestOptions(a=1, b=2, c=3), "test2": ["a", "b", "c"]}
    obj = GlobalCLIArgs.from_options(TestOptions(**args))

    # Check internal dict is immutable
    try:
        obj["test1"]["a"] = 4
    except TypeError:
        assert True
    else:
        assert False

    # Check internal dict is frozen
    try:
        obj["test1"].a = 4
    except AttributeError:
        assert True
    else:
        assert False

    # Check internal list is immutable

# Generated at 2022-06-21 08:24:47.387018
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

        def a(self):
            pass

    class B(A):
        def a(self):
            pass

    a = A()
    b = B()
    assert id(a) == id(b)

# Generated at 2022-06-21 08:24:54.925663
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Prior to Python 3.5, UUID's are not callable.  The following line creates a UUID to confirm that
    # the inheritance order of _ABCSingleton is such that __call__ on UUID comes before the custom
    # implementation of __call__ in _ABCSingleton
    uuid.uuid4()

# Generated at 2022-06-21 08:25:01.169249
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Create a GlobalCLIArgs instance
    global_cli_args = GlobalCLIArgs({'foo': {'bar': 'baz', 'zab': 'boof'}})

    # Test
    assert global_cli_args['foo'] == {'bar': 'baz', 'zab': 'boof'}

# Generated at 2022-06-21 08:25:03.559033
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    try:
        GlobalCLIArgs()
    except Exception as e:
        raise AssertionError('Failed to construct GlobalCLIArgs' + str(e))

# Generated at 2022-06-21 08:25:12.120970
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Test that constructing with a sequence throws an exception
    try:
        GlobalCLIArgs(['a', 'b', 'c'])
    except TypeError:
        pass
    else:
        raise AssertionError('TypeError expected when constructing GlobalCLIArgs with sequence')
    # Test that constructing with a mapping works
    try:
        GlobalCLIArgs({'a': 'b'})
    except TypeError:
        raise AssertionError('TypeError when constructing GlobalCLIArgs with mapping')

    # Test that constructing a second time fails
    try:
        GlobalCLIArgs({'a': 'b'})
    except RuntimeError:
        pass
    else:
        raise AssertionError('RuntimeError expected when constructing GlobalCLIArgs a second time')

# Generated at 2022-06-21 08:25:23.146164
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass1(Singleton):
        pass

    class TestClass2(object, metaclass=_ABCSingleton):
        pass

    t1 = TestClass1()
    t2 = TestClass1()
    t3 = TestClass2()
    t4 = TestClass2()

    assert t1 == t2
    assert t3 == t4

    class TestClass3(object, metaclass=_ABCSingleton):
        pass

    t5 = TestClass3()

    assert t5 == t3

    # We should be able to make a class that is a singleton, an abstract class and acts as an
    # iterator
    class TestClass4(object, metaclass=_ABCSingleton):
        __metaclass__ = ABCMeta

        def __iter__(self):
            yield

    t4 = TestClass4

# Generated at 2022-06-21 08:25:33.186514
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # define arguments
    args1 = {'version': True, 'inventory': '/etc/inventory', 'verbosity': 0}
    args2 = {'inventory': '/etc/inventory'}
    args3 = {'inventory': '/etc/inventory', 'verbosity': 0}

    obj1 = GlobalCLIArgs.from_options(args1)
    obj2 = GlobalCLIArgs.from_options(args2)
    obj3 = GlobalCLIArgs.from_options(args3)

    assert obj1 != obj2
    assert obj1 != obj3
    assert obj2 != obj3
    assert obj2 == obj2

# Generated at 2022-06-21 08:25:44.086730
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {
        'a': '1',
        'b': {
            'ba': [
                {
                    'baa': [
                        'baaa',
                        'baab',
                    ],
                    'bab': {
                        'baba': 'babaa',
                        'babb': [
                            'babba',
                            'babbb',
                        ],
                    },
                },
            ],
            'bb': [
                'bba',
                'bbb',
            ],
        },
        'c': [
            '1',
            '2',
        ],
    }
    args = CLIArgs(mapping)

    assert isinstance(args['a'], text_type)
    assert isinstance(args['b'], ImmutableDict)

# Generated at 2022-06-21 08:25:54.019993
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # test the construction of the GlobalCLIArgs class
    import tempfile
    import os
    import shutil
    import sys
    import pytest

    # an empty options object
    class Options(object):
        pass

    options = Options()
    args = {}
    for key in CLIArgs.__slots__:
        args[key] = key
    options.__dict__ = args
    # save a copy of the expected results
    expected_output = vars(options)

    # make temp dir for the temp modules, this is not the module_utils
    # dir and will be safely ignored by the unit test runner
    temp_dir = tempfile.mkdtemp()
    # create a module in the temp dir
    temp_module = os.path.join(temp_dir, 'test.py')

# Generated at 2022-06-21 08:26:05.520058
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    string_key = 'string_key'
    string_value = 'string_value'

    list_key = 'list_key'
    list_value = ['item1', 'item2']

    dict_key = 'dict_key'
    dict_value = {'key1': ['item1', 'item2'],
                  'key2': ['item3', 'item4']}

    mixed_key = 'mixed_key'

# Generated at 2022-06-21 08:26:12.008829
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import collections

    GlobalCLIArgs.instance = None
    GlobalCLIArgs.instance = GlobalCLIArgs({'a': [1, 2, 3], 'b': {5: 6, 7: 8}})
    assert GlobalCLIArgs.instance == GlobalCLIArgs.instance
    assert GlobalCLIArgs.instance == GlobalCLIArgs({'a': [1, 2, 3], 'b': {5: 6, 7: 8}})
    assert GlobalCLIArgs.instance != CLIArgs({'a': [1, 2, 3], 'b': {5: 6, 7: 8}})
    assert GlobalCLIArgs.instance != GlobalCLIArgs({'a': [1, 2, 3], 'b': {5: 6}})
    assert GlobalCLIArgs.instance['a'] == (1, 2, 3)

# Generated at 2022-06-21 08:26:20.252834
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 'abcd', 'b': [1, 2, 3]})
    assert args['a'] == 'abcd'
    assert args['b'] == (1, 2, 3)



# Generated at 2022-06-21 08:26:28.848287
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.context_objects import GlobalCLIArgs
    from ansible.module_utils.common.collections import ImmutableDict

    x = CLIArgs({'one':1, 'two':[1, 2, 3]})

    assert isinstance(x, ImmutableDict)
    assert len(x) == 2
    assert x['one'] == 1
    assert x['two'] == (1, 2, 3)

    assert isinstance(GlobalCLIArgs.instance(), ImmutableDict)

    # Singleton means we always have the same object
    assert x is GlobalCLIArgs.instance()

# Generated at 2022-06-21 08:26:38.038891
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Ensure CLIArgs is immutable"""
    toplevel = {
        'mutable': [],
    }
    argv = CLIArgs(toplevel)
    assert(argv['mutable'] == [])
    toplevel['mutable'].append(1)
    assert(argv['mutable'] == [])
    toplevel['mutable'] = 1
    assert(argv['mutable'] == [])

    toplevel = {
        'mutable': {},
    }
    argv = CLIArgs(toplevel)
    assert(argv['mutable'] == {})
    toplevel['mutable'][1] = 1
    assert(argv['mutable'] == {})
    toplevel['mutable'] = 1
    assert(argv['mutable'] == {})

   

# Generated at 2022-06-21 08:26:40.447020
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Test that _ABCSingleton is a Mapping object
    """
    assert issubclass(_ABCSingleton, Mapping)



# Generated at 2022-06-21 08:26:52.575350
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    from collections import namedtuple

    # Create a mock version of OptionParser for testing
    class OptionParser:
        def __init__(self):
            self._toplevel = {}
            self._current_module = None

        def add_module(self, module_name):
            # Add a new module to our fake OptionParser mock
            new_module = []
            self._toplevel[module_name] = new_module
            self._current_module = new_module

        def add_option(self, *args, **kwargs):
            # Add a new option to our fake OptionParser mock
            Option = namedtuple('Option', ['dest', 'action', 'help', 'choices', 'default'])
            option_args = list(args)
            option_args.pop(0)  # Remove leading dash or double

# Generated at 2022-06-21 08:26:56.673244
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class testClass1(object, metaclass=_ABCSingleton):
        pass

    class testClass2(testClass1):
        pass

    try:
        class testClass3(object, metaclass=_ABCSingleton):
            pass
    except TypeError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 08:27:01.723158
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object):
        __metaclass__ = _ABCSingleton
        pass

    assert Test() is Test()
    assert isinstance(Test(), Test)
    assert issubclass(Test, Singleton)
    assert issubclass(Test, ABCMeta)

# Generated at 2022-06-21 08:27:03.620706
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Test with empty dict
    GlobalCLIArgs(dict())


# Test for constructor of class CLIArgs

# Generated at 2022-06-21 08:27:07.423862
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """This test is for the GlobalCLIArgs class constructor and has been added for the purpose of demonstrating
    that the constructor works and to prevent the Singleton metaclass from causing an issue with pytest.
    """
    dummy_args = {'foo': 'bar'}
    CLIArgs.from_options(dummy_args)

# Generated at 2022-06-21 08:27:12.745619
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    a_first = A()
    a_second = A()
    assert a_first is a_second, "Singleton instance of A is not a singleton"

# Generated at 2022-06-21 08:27:35.067113
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        pass

    args_dict = {'verbosity': 0, 'foo': {'bar': 'bingo', 'bas': 'bango'},
                 'dictionary': {'foo': {'bar': 'bingo', 'bas': 'bango'},
                                'bingo': 'bango'},
                 'listy': ['bingo', 'bango']}
    args_dict_copy = args_dict.copy()
    options = Options()
    options.__dict__ = args_dict
    args = CLIArgs.from_options(options)
    del options

    # Verify we hold a copy of the original args
    assert args_dict == args_dict_copy

    # Verify the copy is immutable
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, Mapping)


# Generated at 2022-06-21 08:27:44.443580
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {"foo": "bar", "ansible_connection": "local", "connection": "ssh",
                 "list": ["a", "b", "c"], "list_of_dict": [{"a": 1, "b": 2}, {"a": 3, "b": 4},
                                                           {"a": 5, "b": 6}],
                 "dict": {"a": 1, "b": 2}, "dict_of_dict": {"a": {"a": 1, "b": 2}, "b": {"a": 3, "b": 4}}}
    class_object = CLIArgs(test_dict)

    for key, value in test_dict.items():
        assert getattr(class_object, key) == value

# Generated at 2022-06-21 08:27:50.041621
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_only_instantiated_once(self):
            """
            Test that the GlobalCLIArgs is a singleton.
            """
            sys.argv = ['/path/to/module/file', '-a', '-b', '-c']
            self.assertIs(GlobalCLIArgs(), GlobalCLIArgs())

# Generated at 2022-06-21 08:27:52.078539
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert isinstance(int, _ABCSingleton)
    assert isinstance(object, _ABCSingleton)

# Generated at 2022-06-21 08:28:00.326492
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyABCClass(object):
        __metaclass__ = _ABCSingleton
        def __init__(self):
            self.test = 1

    class MySingletonClass(object):
        __metaclass__ = _ABCSingleton
        def __init__(self):
            self.test = 1

    assert hasattr(GlobalCLIArgs, '__metaclass__')
    assert hasattr(MyABCClass, '__metaclass__')
    assert hasattr(MySingletonClass, '__metaclass__')

# Generated at 2022-06-21 08:28:10.213511
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        pass
    a = A()
    assert isinstance(a, A)
    assert not isinstance(a, object)
    assert not isinstance(a, type)
    assert not isinstance(A, object)
    assert isinstance(A, type)

    class B(object):
        __metaclass__ = _ABCSingleton
    b = B()
    assert isinstance(b, B)
    assert isinstance(b, object)
    assert isinstance(b, type)
    assert isinstance(B, object)
    assert isinstance(B, type)

    class C(B):
        pass
    c = C()
    assert isinstance(c, C)
    assert isinstance(c, object)
    assert isinstance(c, type)
    assert isinstance(C, object)

# Generated at 2022-06-21 08:28:15.979746
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 2
    ansible_display = ImmutableDict({'verbosity': 2})

# Generated at 2022-06-21 08:28:18.845789
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(GlobalCLIArgs, Singleton)
    assert issubclass(GlobalCLIArgs, ImmutableDict)
    assert issubclass(GlobalCLIArgs, Mapping)

# Generated at 2022-06-21 08:28:28.397823
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'a': 1, 'b': 'string', 'c': [1, 2, 3, {'d': 'string'}], 'd': {'e': 'f'}, 'e': {'f': 'g'}, 'f': {'g': 'h'}}
    expected_output = {'a': 1, 'b': 'string', 'c': (1, 2, 3, {'d': 'string'}), 'd': ImmutableDict({'e': 'f'}),
                       'e': ImmutableDict({'f': 'g'}), 'f': ImmutableDict({'g': 'h'})}
    assert CLIArgs(mapping) == expected_output

# Generated at 2022-06-21 08:28:35.114037
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({u'foo': u'bar', u'cows': u'goat', u'bats': {u'red': u'green',
                    u'blue': u'yellow', u'brown': u'orange'}})
    assert hasattr(args, u'foo')
    assert u'foo' in args
    assert u'bar' == args[u'foo']
    assert args[u'cows'] == u'goat'
    assert isinstance(args[u'bats'], ImmutableDict)
    assert args[u'bats'][u'red'] == u'green'
    assert args[u'bats'][u'blue'] == u'yellow'

# Generated at 2022-06-21 08:29:02.269486
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys

    # test that the cli args can be captured and stored in a container
    cli_args = GlobalCLIArgs(sys.argv[1:])
    assert isinstance(cli_args, ImmutableDict)

    # test that the container has its own copy of the data and not the original
    sys.argv[1] = 'Not the same'
    assert cli_args['ansible-playbook'] != sys.argv[1]

# Generated at 2022-06-21 08:29:10.174180
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    original_data = dict({'debug': True, 'foo': 'bar', 'list': [1, 'two', 3], 'tup': (1, 2, 3)})
    args = CLIArgs(original_data)
    assert args['debug'] is True
    assert args['foo'] == 'bar'
    assert isinstance(args['list'], tuple)
    assert args['list'] == (1, 'two', 3)
    assert args['tup'] == (1, 2, 3)

    # Check that it is made immutable
    assert isinstance(args['list'], tuple)
    for value in args.values():
        assert isinstance(value, (text_type, binary_type, tuple, ImmutableDict, frozenset, bool))

    # Ensure that it does not convert everything to a tuple

# Generated at 2022-06-21 08:29:23.880522
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import os
    from ansible.utils.display import Display
    fake_vars = {'fake_arg': 'fake_value',
                 'verbosity': 1,
                 'connection': 'fake_connection',
                 'module_path': 'fake_module_path',
                 'become': True,
                 'become_method': 'fake_become_method',
                 'become_user': 'fake_become_user',
                 'private_key_file': ['fake_private_key_file'],
                 'timeout': 10}

    # add test options to vars
    vars = fake_vars

    # create display object
    display = Display()

    # create CLIArgs
    args = CLIArgs(vars)

    # test args

# Generated at 2022-06-21 08:29:31.053154
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Dummy test for CLIArgs"""
    args = {"test": "test", "test1": "test1"}
    cli = CLIArgs(args)
    if isinstance(cli, Mapping):
        print("CLIArgs works well")
        return 0
    else:
        print("CLIArgs do not works well")
        return 1

# Generated at 2022-06-21 08:29:38.075335
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from collections import OrderedDict, Mapping
    from ansible import release
    from ansible.utils.color import stringc
    from ansible.utils.version import LooseVersion
    import datetime
    import sys
    import types

    def _assert_immutable_and_equal(obj, compare_to):
        """Ensure that an object is immutable and equal to another object"""
        assert isinstance(obj, type(compare_to)), "{} is not a {}".format(obj, type(compare_to))
        assert obj == compare_to, "{} does not equal {}".format(obj, compare_to)

        # We can't test for immutability on some types because of the way they are implemented
        if not isinstance(obj, (type(sys), types.ModuleType, LooseVersion)):
            is_mutable

# Generated at 2022-06-21 08:29:43.828389
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Function for testing the constructor of class CLIArgs"""
    dict_args = dict(a=1, b=[1, 5], c={1: 'abc'}, d=(1, 2, 3))
    args = CLIArgs(dict_args)
    assert args == _make_immutable(dict_args)

# Generated at 2022-06-21 08:29:49.621093
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    instance = GlobalCLIArgs({'a': 1, 'b': '2'})
    assert instance['a'] == 1
    assert instance['b'] == '2'
    assert instance == {'a': 1, 'b': '2'}

    for value in (1, 2, 3):
        scoped_instance = GlobalCLIArgs({'a': value})
        assert scoped_instance['a'] == value
        assert scoped_instance == {'a': value}
        assert scoped_instance is instance

# Generated at 2022-06-21 08:29:50.727591
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    CLIArgs({"foo": 1})


# Generated at 2022-06-21 08:29:58.458172
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test constructor of class GlobalCLIArgs

    Using only the constructor of class GlobalCLIArgs verify that it accepts a dictionary and
    returns an ImmutableDict as a toplevel attribute.
    """
    test_dict = {'one': 'two', 'three': 'four'}
    global_cli_args = GlobalCLIArgs(test_dict)
    assert global_cli_args == ImmutableDict(test_dict)

# Generated at 2022-06-21 08:30:05.110514
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.collection_loader import SharedPluginLoaderObj
    from ansible.utils.collection_loader import SharedCollectionLoaderObj
    # Test a mix of base types

# Generated at 2022-06-21 08:30:50.030782
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert isinstance(_ABCSingleton('TestClass', (object, ), {}), ABCMeta)

# Generated at 2022-06-21 08:30:56.629929
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import ansible.cli.galaxy
    from ansible.cli.arguments import CLIArgumentParser

    def test(options):
        GlobalCLIArgs(options)

    arg_parser = CLIArgumentParser(
        prog='ansible-galaxy',
        description='ansible galaxy cli arguments',
        epilog=ansible.__copyright__,
        formatter_class='default'
    )
    arg_parser.add_galaxy_cli_options()
    options = arg_parser.parse_args([])
    test(options)

# Generated at 2022-06-21 08:30:59.814759
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import ansible.constants as C
    cli_args = GlobalCLIArgs(vars(C))
    assert cli_args

# Generated at 2022-06-21 08:31:04.353851
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class B(object):
        __metaclass__ = _ABCSingleton
    assert issubclass(B, Singleton)
    assert issubclass(B, ABCMeta)
    assert not issubclass(Singleton, _ABCSingleton)
    assert issubclass(B, _ABCSingleton)

# Generated at 2022-06-21 08:31:15.445846
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _TestSingleton(_ABCSingleton):
        def __init__(self, foo):
            self.foo = foo

    class _TestOtherSingleton(_ABCSingleton):
        def __init__(self, bar):
            self.bar = bar

    class _TestNonSingleton(object):
        def __init__(self, quux):
            self.quux = quux

    class _TestSpecialSingleton(_TestSingleton, _TestOtherSingleton, _TestNonSingleton, object):
        pass

    assert _TestSingleton('foo') is not _TestSingleton('foo')
    assert _TestOtherSingleton('bar') is not _TestOtherSingleton('bar')
    assert _TestNonSingleton('quux') is not _TestNonSingleton('quux')
    assert _TestSpecialSingleton('foo') is _Test

# Generated at 2022-06-21 08:31:27.074957
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    A few tests to make sure the _ABCSingleton metaclass is working as expected
    """
    class Parent(object):
        pass

    # Create a non-singleton subclass of Parent, should work
    class Child(Parent):
        pass

    # Create another non-singleton subclass of Parent, should work
    class OtherChild(Parent):
        pass

    # This should fail since Child is a Singleton and we have a non-singleton class trying to inherit
    try:
        class InvalidSingletonSubclass(Parent, Child):
            pass
    except TypeError:
        pass

    # This should fail since Child is a Singleton and we have a non-singleton class trying to inherit
    try:
        class OtherInvalidSingletonSubclass(Child, OtherChild):
            pass
    except TypeError:
        pass

    # This should

# Generated at 2022-06-21 08:31:31.089892
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({'a': 1, 'b': 'b', 'c': [1, '2', 3]}) == {'a': 1, 'b': 'b', 'c': (1, '2', 3)}



# Generated at 2022-06-21 08:31:33.408748
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Ensure that we can create a Singleton class based on combining ABCMeta and Singleton
    """
    GlobalCLIArgs()

# Generated at 2022-06-21 08:31:37.445905
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(B):
        pass

    assert isinstance(A(), A)
    assert isinstance(B(), A)
    assert isinstance(C(), A)

# Generated at 2022-06-21 08:31:38.652082
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABC(metaclass=_ABCSingleton):
        pass
    TestABC()