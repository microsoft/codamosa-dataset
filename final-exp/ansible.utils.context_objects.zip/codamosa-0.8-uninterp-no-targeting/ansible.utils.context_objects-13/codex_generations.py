

# Generated at 2022-06-21 08:22:15.989479
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Simple test to ensure that we can successfully create a CLIArgs object that contains all
    # expected immutable data types
    toplevel = {"boolean_flag": True, "integer_flag": 1, "string_flag": "foo"}
    test_dict = {
        "toplevel": toplevel,
        "tuple_flag": (1, 2, 3),
        "set_flag": {1, 2, 3},
        "list_flag": [1, 2, 3],
    }
    ca = CLIArgs(test_dict)
    assert isinstance(ca, Mapping)
    assert isinstance(ca, ImmutableDict)
    assert isinstance(ca, CLIArgs)
    assert isinstance(ca["toplevel"], ImmutableDict)
    assert isinstance(ca["tuple_flag"], Sequence)

# Generated at 2022-06-21 08:22:20.562234
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    @add_metaclass(_ABCSingleton)
    class Child(object):
        def __init__(self):
            self.val = 1

    assert(Child() == Child())
    assert(Child() is Child())
    assert(Child().val == Child().val)
    assert(Child().val is Child().val)

# Generated at 2022-06-21 08:22:30.483356
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.utils.argsimport import get_args

    results = GlobalCLIArgs.from_options(get_args(args_list=[]))

    if results is None:
        raise AssertionError("CLIArgs.from_options() returned None")

    if type(results) != GlobalCLIArgs:
        raise AssertionError("CLIArgs.from_options() did not return an instance of GlobalCLIArgs")

    if results.get('inventory') != '/etc/ansible/hosts':
        raise AssertionError("GlobalCLIArgs.inventory defaults to '%s' not '/etc/ansible/hosts'" % results.get('inventory'))

    if results.get('password') != to_bytes(''):
        raise Assert

# Generated at 2022-06-21 08:22:42.411456
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-21 08:22:43.274666
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    pass

# Generated at 2022-06-21 08:22:55.050550
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _TestAbstractA(_ABCSingleton):
        __metaclass__ = _ABCSingleton

        @classmethod
        def test_a(cls):
            return "A"

    class _TestAbstractB(_ABCSingleton):
        __metaclass__ = _ABCSingleton

        @classmethod
        def test_b(cls):
            return "B"

    class _TestAbstractC(_TestAbstractA, _TestAbstractB):
        __metaclass__ = _ABCSingleton

        @classmethod
        def test_c(cls):
            return "C"

    class _TestAbstractD(_TestAbstractA, _TestAbstractB):
        __metaclass__ = _ABCSingleton

        @classmethod
        def test_a(cls):
            return "D"


# Generated at 2022-06-21 08:23:01.136376
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    data = {'foo': 'bar'}
    args = CLIArgs.from_options(type('Options', (object,), data))
    assert args == data

    # Test that mutation of original dict does not affect args
    data['foo'] = 'baz'
    assert args == {'foo': 'bar'}

    # Test that mutation of args does not affect original dict
    args['foo'] = 'baz'



# Generated at 2022-06-21 08:23:10.914205
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        def __init__(self):
            self.foo = {"bar": [1, 2, {"baz": { "foo": "bar"}}]}
            self.var = "bar"
            self.ansible_callback_whitelist = ['profile_tasks']
            self.ansible_string_conversion_action = 'warn'
            self.ansible_verbosity = 3

    options = Options()

    cli_args = CLIArgs.from_options(options)


# Generated at 2022-06-21 08:23:13.816211
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton
    a, b = Foo(), Foo()
    assert a is b
    assert a == b

# Generated at 2022-06-21 08:23:23.965978
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # pylint: disable=too-few-public-methods
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert isinstance(TestClass(), Singleton)
    assert issubclass(TestClass, ABCMeta)

    try:
        TestClass.register(dict)
    except TypeError:
        raise AssertionError('_ABCSingleton does not properly combine Singleton and ABCMeta')

    class Test2Class(object):
        __metaclass__ = _ABCSingleton

    # If we get here with no errors, it worked
    # pylint: enable=too-few-public-methods



# Generated at 2022-06-21 08:23:33.105431
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 1, 'b': False, 'c': 'test', 'd': [1, 2, 3], 'e': {'x': 10, 'y': 20}}
    obj = CLIArgs(test_dict)
    assert obj['a'] == 1
    assert obj['b'] is False
    assert obj['c'] == 'test'
    assert obj['d'] == (1, 2, 3)
    assert obj['e'] == ImmutableDict({'x': 10, 'y': 20})
    assert obj == ImmutableDict({'a': 1, 'b': False, 'c': 'test', 'd': (1, 2, 3), 'e': ImmutableDict({'x': 10, 'y': 20})})

# Generated at 2022-06-21 08:23:35.623942
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {"abc": 123}
    cliargs = CLIArgs(test_dict)
    assert cliargs == test_dict


# Generated at 2022-06-21 08:23:41.059953
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'leaf1': 'value1', 'leaf2': 'value2'})
    # args should not be a mutable mapping
    assert not isinstance(args, Mapping)
    # test for correctness
    assert args == {'leaf1': 'value1', 'leaf2': 'value2'}


# Generated at 2022-06-21 08:23:47.938308
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # pylint: disable=too-few-public-methods
    # pylint: disable=no- value-for-parameter, unused-argument
    class child(object):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            pass

    assert isinstance(child(), _ABCSingleton)
    assert not isinstance(child(), Singleton)
    assert not hasattr(child(), '__getnewargs__')

# Generated at 2022-06-21 08:23:49.766110
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Unit test for constructor of class _ABCSingleton"""
    assert type(_ABCSingleton) is _ABCSingleton

# Generated at 2022-06-21 08:23:53.248263
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton(_ABCSingleton):
        pass

    assert TestSingleton() is TestSingleton()
    assert TestSingleton() is not object()

    assert isinstance(TestSingleton(), TestSingleton)
    assert isinstance(TestSingleton(), object)

# Generated at 2022-06-21 08:23:58.996207
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Create an instance of options and populate it with a dictionary
    options = GlobalCLIArgs({'test_option': 'test_value'})

    assert isinstance(options, GlobalCLIArgs)
    assert isinstance(options, ImmutableDict)

    # Assert the test_option that was created earlier is in GlobalCLIArgs
    assert 'test_option' in options

    # Assert that the GlobalCLIArgs is frozen and therefore Immutable
    try:
        options['test_option'] = 'value'
    except TypeError as e:
        assert isinstance(e, TypeError)
    else:
        assert False



# Generated at 2022-06-21 08:24:10.968810
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs(
        {
            'foo': 'bar',
            'baz': [
                'quux',
                {
                    'hello': 'world',
                },
            ],
        }
    )
    assert cli_args['foo'] == 'bar'
    cli_args['foo'] = 'baz'
    assert cli_args['foo'] != 'baz'
    try:
        cli_args['foo'] = 'hello'
        raise AssertionError('cli_args should have been immutable')
    except TypeError:
        pass
    assert cli_args['baz'][0] == 'quux'

# Generated at 2022-06-21 08:24:13.605547
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class TestSingleton(_ABCSingleton):
        pass

    class TestSingleton2(_ABCSingleton):
        pass

    assert TestSingleton() is TestSingleton()

# Generated at 2022-06-21 08:24:15.130842
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({'a': 'b', 'c': 'd'})

# Generated at 2022-06-21 08:24:25.123100
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
        def __init__(self, a):
            self.a = a
    class B(A):
        def __init__(self, a, b):
            super(B, self).__init__(a)
            self.b = b

    obj1 = A(1)
    obj2 = A(2)
    assert obj1 is obj2

    obj3 = B(1, 2)
    obj4 = B(2, 3)
    assert obj3 is obj4
    assert obj3.b == 3

# Generated at 2022-06-21 08:24:30.869684
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        def __init__(self, foo):
            self._foo = foo

    t1 = Test('whatever')
    t2 = Test('something else')

    assert t1 is t2
    assert t1._foo is t2._foo
    assert t1._foo == t2._foo
    assert t1._foo == 'whatever'

# Generated at 2022-06-21 08:24:37.877239
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # pylint: disable=protected-access
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        def foo(self):
            return

    class C(A):
        def bar(self):
            return

    assert A() is A()

    a = A()
    b = B()
    c = C()
    assert a is b
    assert a is c

    # pylint: enable=protected-access

# Generated at 2022-06-21 08:24:40.426460
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Unit test for class GlobalCLIArgs"""

    GlobalCLIArgs({'a': 1, 'b': 2})



# Generated at 2022-06-21 08:24:42.367607
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({"foo": "bar", "nope": "nomatch", "garbage": "garbage"})

# Generated at 2022-06-21 08:24:44.405385
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs(vars(None))
    assert isinstance(global_cli_args, GlobalCLIArgs)

# Generated at 2022-06-21 08:24:45.542889
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs(vars({'verbosity': '1', 'debug': True}))

# Generated at 2022-06-21 08:24:51.358789
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
        pass

    class B(A):
        pass

    try:
        class C(_ABCSingleton, object):
            pass
    except TypeError:
        # This should fail, global_cli_args is a Singleton, it should not be subclassed.
        pass
    else:
        assert False, "Should not be able to subclass a Singleton."

    class D(_ABCSingleton, A):
        pass

    assert type(A) == type(B) == type(D)
    assert isinstance(A(), A)
    assert isinstance(B(), A)
    assert isinstance(D(), A)
    a = A()
    b = B()
    d = D()
    assert a is b
    assert a is d

# Generated at 2022-06-21 08:24:56.466413
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that a CLIArgs instance has immutable containers for its values.
    """
    cli_args = CLIArgs({"a": {}, "b": set()})

    assert isinstance(cli_args["a"], ImmutableDict)
    assert isinstance(cli_args["b"], frozenset)



# Generated at 2022-06-21 08:25:01.189675
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test the CLIArgs type for unexpected behavior

    Run this with `python -m pytest -v test/unit/utils/args.py`
    """
    args = CLIArgs.from_options(['-c', 'local', '-m', 'setup'])
    assert args['connection'] == 'local'
    assert args['module_name'] == 'setup'

# Generated at 2022-06-21 08:25:08.327991
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest

    with pytest.raises(TypeError):
        _ = GlobalCLIArgs()
    _ = GlobalCLIArgs({"test": "test"})

# Generated at 2022-06-21 08:25:13.353688
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Assert that it is possible to subclass ABCMeta and Singleton using _ABCSingleton
    """
    class TestSingleton(object, metaclass=_ABCSingleton):
        pass

    try:
        class TestSingletonOne(TestSingleton):
            pass
        del(TestSingletonOne)
        class TestSingletonTwo(TestSingleton):
            pass
        del(TestSingletonTwo)
    except TypeError:
        assert False, 'It is not possible to subclass ABCMeta with Singleton using _ABCSingleton'

# Generated at 2022-06-21 08:25:19.691700
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    data = {'foo': 'bar', 'baz': {'wibble': 'wobble', 'a': 1}, 'c': [1, 2, ['three', 'four']]}
    cli_args = CLIArgs(data)
    assert cli_args['foo'] == 'bar'
    assert cli_args['baz']['wibble'] == 'wobble'
    assert cli_args['baz']['a'] == 1
    assert cli_args['c'][0] == 1
    assert cli_args['c'][2][0] == 'three'

    # Make sure we can't modify the cli args
    try:
        cli_args['foo'] = 'baz'
    except TypeError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 08:25:22.480894
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test1(metaclass=_ABCSingleton):
        pass

    class Test2(metaclass=_ABCSingleton):
        pass

    assert(Test1() is Test1())
    assert(Test2() is not Test2())

# Generated at 2022-06-21 08:25:34.773367
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_args = GlobalCLIArgs({'foo': 'bar'})
    assert isinstance(global_args, GlobalCLIArgs)
    assert isinstance(global_args, ImmutableDict)
    assert global_args == ImmutableDict({'foo': 'bar'})
    assert global_args is GlobalCLIArgs()
    assert len(global_args) == 1

    expected_message = "GlobalCLIArgs: 'dict' object does not support item assignment"

    # We should not be able to mutate the contents of GlobalCLIArgs
    with pytest.raises(UnexpectedMutation):
        global_args['abc'] = 'def'

    # We should not be able to reset the contents of GlobalCLIArgs, but we will fail with an
    # unexpected exception because it is a Singleton object

# Generated at 2022-06-21 08:25:46.116138
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class DummyOptions(object):
        def __init__(self):
            self.i = 'i'
            self.s = 's'
            self.p = 'p'
            self.a = 'a'
            self.b = 'b'
            self.c = 'c'
            self.d = 'd'
            self.e = [{'a':'a', 'b':'b'}, {'c':'c', 'd':'d'}]
            self.f = 'f'
            self.g = {'a': 'a', 'b': 'b'}
            self.h = 'h'

    opt = DummyOptions()
    cli_args = CLIArgs.from_options(opt)

    assert cli_args['i'] == 'i'
    assert cli_args

# Generated at 2022-06-21 08:25:54.192073
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test the CLIArgs constructor which converts arguments into an immutable dictionary

    Test the CLIArgs constructor against some basic cases where arguments can be any number of
    immutable objects like strings, lists, tuples, or dictionaries to verify that the constructor
    succeeds in converting the arguments into an immutable dictionary
    """
    input_arguments = {
        'bar': 'baz',
        'spam': 'eggs',
        'hello': [1, 2, 4],
        'world': {
            'answer': 42,
            'universe': [
                'good morning',
                'good night',
            ],
        },
    }

    arguments = CLIArgs(input_arguments)
    assert input_arguments == arguments
    with pytest.raises(AttributeError):
        arguments['bar'] = 'quux'

# Generated at 2022-06-21 08:25:57.970998
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ABCSingleton(object):
        __metaclass__ = _ABCSingleton

    class MyClass(ABCSingleton):
        pass

    assert(MyClass() is MyClass())


# Generated at 2022-06-21 08:26:03.238703
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class C(metaclass=_ABCSingleton):
        def __init__(self):
            self.data = "foo"

    c1 = C()
    c2 = C()
    assert id(c1) == id(c2)
    assert c1.data == "foo"
    assert c2.data == "foo"

# Generated at 2022-06-21 08:26:07.645302
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    d = {"a": 1, "b": "test", "c": [1, 2, 3], "d": {"a": "1", "b": "2"}, "e": ["a", "b", "c"], "f": {"a": 1, "b": 2}}
    cli_args = CLIArgs(d)
    assert(isinstance(cli_args, ImmutableDict))

# Generated at 2022-06-21 08:26:27.255482
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import os
    import tempfile
    import traceback

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-21 08:26:32.465899
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys

    option_class = type('test_GlobalCLIArgs', (object,), {'connection': 'test_connection'})
    options = option_class()
    sys.modules['ansible'] = type('ansible', (object,), {'options': options})

    args = GlobalCLIArgs.from_options(options)
    assert args.connection == 'test_connection'

# Generated at 2022-06-21 08:26:36.302790
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # TODO: Change this to a real unit test
    options = ImmutableDict({
        'foo': 'bar',
        'baz': ImmutableDict({
            'biz': 'buz'
        })
    })
    assert isinstance(GlobalCLIArgs.from_options(options), GlobalCLIArgs)

# Generated at 2022-06-21 08:26:37.915059
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Example(_ABCSingleton):
        pass

    class Example2(_ABCSingleton):
        pass

    assert Example is Example
    assert Example2 is Example2

# Generated at 2022-06-21 08:26:44.208268
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('-o')
    parser.add_argument('--longop', action='store_true')
    options = parser.parse_args(['--longop', '-o', 'value'])
    args = GlobalCLIArgs.from_options(options)
    assert args['longop']
    assert args['o'] == 'value'

# Generated at 2022-06-21 08:26:46.830541
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Constructor returns an object of class CLIArgs
    result = CLIArgs(dict())
    assert isinstance(result, CLIArgs)



# Generated at 2022-06-21 08:26:57.550305
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # dict of dict, list and set
    next_level_dict = {'a': 'A', 'b': 'B', 'c': 'C'}
    next_level_list = ['a', 'b', 'c']
    next_level_set = {'a', 'b', 'c'}

    # dict of dict, list and set
    top_level_dict = {'a': next_level_dict, 'b': next_level_list, 'c': next_level_set}
    test = CLIArgs(top_level_dict)

    for k in test:
        # dict of dict, list and set converted to immutable dict
        assert isinstance(test[k], ImmutableDict)


# Generated at 2022-06-21 08:27:03.318521
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    argv = ['arg1', 'arg2', 'arg3']
    args = dict(arg1='val1', arg2='val2', arg3='val3')
    cliargs =  CLIArgs(args)
    assert cliargs.arg1 == 'val1'
    assert cliargs.arg2 == 'val2'
    assert cliargs.arg3 == 'val3'

# Generated at 2022-06-21 08:27:05.468622
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Temp(_ABCSingleton):
        pass

    assert issubclass(Temp, Singleton)
    assert issubclass(Temp, ABCMeta)

# Generated at 2022-06-21 08:27:18.006712
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = {1: 2}
    b = {'foo': 'bar'}
    c = [1, 2, 3]
    d = (3, 2, 1)
    e = {'baz': {'bing': 1}}
    f = set(['a', 'b'])
    g = {'a': set(['a', 'b']),
         'b': set(['a', {'c': f}])}


# Generated at 2022-06-21 08:27:40.230856
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class T(_ABCSingleton):
        pass

    class U(_ABCSingleton, Singleton):
        pass

    assert isinstance(T, type) # Note, this implicitly tests metaclass->metaclass resolution

# Generated at 2022-06-21 08:27:43.344648
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class a(object):
        __metaclass__ = _ABCSingleton

    class b(a):
        pass

    class c(b):
        pass

    a()
    b()
    c()

# Generated at 2022-06-21 08:27:50.816330
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import copy

    # Make sure that we can't change the GlobalCLIArgs object
    GlobalCLIArgs.from_options({
        'foo': {
            'bar': 12345
        },
        'baz': [1, 2, 3, 4, 5]
    })
    # We can't change the value of foo because we made it immutable
    with pytest.raises(TypeError):
        GlobalCLIArgs()['foo']['bar'] = 54321
    # We can't change the value of baz because we made it immutable
    with pytest.raises(TypeError):
        GlobalCLIArgs()['baz'][0] = 6

    # Make sure we can't modify the dictionary itself
    # API: TypeError: 'ImmutableDict' object does not support item assignment

# Generated at 2022-06-21 08:27:55.640448
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    foo = Foo()
    assert isinstance(Foo(), Foo) # Singleton meta class
    assert isinstance(Foo, ABCMeta) # ABCMeta meta class
    assert isinstance(Foo(), type) # Singleton meta class

# Generated at 2022-06-21 08:28:01.332963
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({})
    try:
        args['foo'] = 'bar'
        assert False, "Should not be able to modify contents of GlobalCLIArgs"
    except TypeError:
        pass

    try:
        del args['foo']
        assert False, "Should not be able to modify contents of GlobalCLIArgs"
    except TypeError:
        pass


# Generated at 2022-06-21 08:28:11.011324
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-21 08:28:16.619694
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Test that GlobalCLIArgs is a singleton."""
    GlobalCLIArgs.set(None) # Clear
    assert GlobalCLIArgs.get() is None
    GlobalCLIArgs.set({'a': 1})
    assert GlobalCLIArgs.get() is not None

# Generated at 2022-06-21 08:28:21.203138
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict1 = {
        'abc': [1, 2, 3],
        'def': [1, set([1, 2, 3]), {'a': 'b'}]
    }
    args = CLIArgs(dict1)
    assert isinstance(args, ImmutableDict)
    assert dict1 == dict(args)

# Generated at 2022-06-21 08:28:22.827167
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Opt(object):
        swallow_error = 'false'

    GlobalCLIArgs.from_options(Opt())

# Generated at 2022-06-21 08:28:32.882010
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common._collections_compat import Mapping, Sequence, Set
    from ansible.module_utils.six import binary_type, text_type
    import collections

    # Check that the object behaves like a Mapping
    assert issubclass(CLIArgs, Mapping)
    assert isinstance(CLIArgs({}), collections.Mapping)

    # Check that the contents are immutable
    d = CLIArgs({'foo': 'bar'})
    with pytest.raises(AttributeError):
        d.foo = 'new bar'
    with pytest.raises(AttributeError):
        d.setdefault('foo', 'new bar')

# Generated at 2022-06-21 08:29:25.890504
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class Test1(object):
        __metaclass__ = _ABCSingleton

    class Test2(object):
        __metaclass__ = _ABCSingleton

    # Test1 and Test2 should be Singletons
    assert Test1() is Test1()
    assert Test2() is Test2()

    # Test1 and Test2 should be different Singletons
    assert Test1() is not Test2()

    # Test1 and Test2 should be instances of _ABCSingleton
    assert isinstance(Test1(), _ABCSingleton)
    assert isinstance(Test2(), _ABCSingleton)

    # Test1 and Test2 should be instances of ABCMeta
    assert isinstance(Test1(), ABCMeta)
    assert isinstance(Test2(), ABCMeta)

# Generated at 2022-06-21 08:29:34.634104
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import inspect
    import types

    mapping = {'foo': 'bar'}
    a = GlobalCLIArgs(mapping)
    b = GlobalCLIArgs(mapping)

    assert id(a) == id(b)

    # Try to fake out the singleton
    original = GlobalCLIArgs.__call__
    try:
        GlobalCLIArgs.__call__ = types.MethodType(original, GlobalCLIArgs)
        c = GlobalCLIArgs(mapping)
        assert id(c) == id(b)
    finally:
        GlobalCLIArgs.__call__ = original

# Generated at 2022-06-21 08:29:43.183793
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
        def __init__(self, value):
            self.value = value

    a1 = A(1)
    assert a1.value == 1
    assert A(2).value == 1

    class B(A):
        def __init__(self, value):
            super(B, self).__init__(value)

    b1 = B(2)
    assert b1.value == 2
    assert B(3).value == 2
    assert A(3).value == 1

# Generated at 2022-06-21 08:29:51.114768
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_options = {'v': 0, 'vv': 0, 'vvv': 0, 'inventory': './test_inventory', 'user': 'test_user', 'ask_sudo_pass': False}
    test_global_cli_args = GlobalCLIArgs.from_options(test_options)
    assert test_global_cli_args['v'] == 0
    assert test_global_cli_args['vv'] == 0
    assert test_global_cli_args['ask_sudo_pass'] == False
    assert not isinstance(test_global_cli_args['v'], dict)
    assert not isinstance(test_global_cli_args['vv'], dict)
    assert not isinstance(test_global_cli_args['ask_sudo_pass'], dict)



# Generated at 2022-06-21 08:29:52.592770
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({})



# Generated at 2022-06-21 08:29:55.391892
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    ga = GlobalCLIArgs({})
    assert isinstance(ga, CLIArgs)
    assert isinstance(ga, dict)

# Generated at 2022-06-21 08:30:05.558443
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    # Pass in a Mapping object
    options = Options(one=1, two=dict(three="four"))
    args = CLIArgs(vars(options))
    assert isinstance(args, ImmutableDict)
    assert args["one"] == 1
    assert args["two"]["three"] == "four"

    # Pass in a Set object
    options = Options(one=1, two=set(["foo", "bar"]))
    args = CLIArgs(vars(options))
    assert isinstance(args, ImmutableDict)
    assert args["one"] == 1
    assert list(args["two"]) == ["bar", "foo"]

    # Pass in a Sequence object
    options

# Generated at 2022-06-21 08:30:15.522337
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import os
    import sys
    import types

    # Make sure that we have an valid set of command line arguments to pass to CLIArgs
    if len(sys.argv) < 2 or sys.argv[1] != 'ansible-test':
        raise Exception('CLIArgs was not imported as part of ansible-test')

    test_module_dir = os.path.join(os.path.dirname(__file__), 'ansible_test_data')

# Generated at 2022-06-21 08:30:24.986368
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_input = {'one': 1, 'two': 2, 'three': {'four': 4, 'five': 5}, 'six': [6, 6, 6], 'seven': {6, 7, 8}, 'eight': (8, 7, 6)}
    result = CLIArgs(test_input)
    assert result == test_input
    assert result['three'] == test_input['three']
    assert result['six'] == test_input['six']
    assert result['seven'] == test_input['seven']
    assert result['eight'] == test_input['eight']

# Generated at 2022-06-21 08:30:30.108569
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils.six import with_metaclass

    class MetaSingleton(with_metaclass(_ABCSingleton, object)):
        pass

    class Meta(object):
        def __call__(cls):
            return super(Meta, cls).__call__()

    class Singleton(with_metaclass(Meta, object)):
        pass

# Generated at 2022-06-21 08:32:04.973128
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.shlex import shlex_split
    data = {'list': ['a', 'b', 'c'], 'bool': True, 'dict': dict(a=1, b=2), 'string': 'hello world',
            'list_of_list': [['a', 'b'], ['c', 'd']]}
    cli_args = CLIArgs(data)
    cli_args_new = CLIArgs(data)
    assert cli_args == cli_args_new
    data['list'][2] = 'd'
    assert cli_args != cli_args_new
    cli_args_new = CLIArgs(data)
    assert cli_args != cli_args_new
    data['list_set'] = set(['e'])
    cli_args_