

# Generated at 2022-06-21 08:22:14.364115
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_tuple = ('foo', 'bar')
    test_list = ['baz', 'qux']

    args = CLIArgs({'fred': {'arg1': test_tuple, 'arg2': test_list}})

    assert args['fred']['arg1'] is test_tuple
    assert args['fred']['arg2'] is test_list

# Generated at 2022-06-21 08:22:19.774057
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class test(object):
        __metaclass__ = _ABCSingleton

        def __init__(self, first, second):
            self.first = first
            self.second = second

    obj1 = test(1, 2)
    obj2 = test(3, 4)
    assert obj1 is obj2
    assert obj1.first == 3
    assert obj1.second == 4

# Generated at 2022-06-21 08:22:21.763436
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({'foo': 'bar'})
    assert args['foo'] == 'bar'



# Generated at 2022-06-21 08:22:31.373697
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('-t', '--test-arg', action='store', type=int, default=None)
    parser.add_argument('-s', '--store-arg', action='store', type=str, default=None)
    parser.add_argument('-l', '--list-arg', action='append', type=str, default=None)
    args_given = parser.parse_args(['-t', '123', '-s', 'hello', '-l', 'one', '-l', 'two'])
    args = CLIArgs.from_options(args_given)
    assert args._store == ImmutableDict({'test_arg': 123, 'store_arg': 'hello', 'list_arg': ('one', 'two')})
   

# Generated at 2022-06-21 08:22:43.521315
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Known good args from AnsibleModule.__init__
    mock_args = {
        '_ansible_remote_tmp': '/tmp/ansible-tmp-1536956854.12-37915749750724',
        '_ansible_version': '2.7.2',
        '_ansible_syslog_facility': 'LOG_USER',
        '_ansible_module_name': 'ansible.modules.system.setup',
        '_ansible_no_log': False,
        '_ansible_verbosity': 4,
        '_ansible_allowed_file_extensions': ['ps1', 'py', 'rb', 'pl', 'j2', 'sh', 'psm1', 'groovy']
    }

    # Known good answer from those args

# Generated at 2022-06-21 08:22:49.009646
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import doctest
    results = doctest.testmod(name='ansible.module_utils.common.arguments.CLIArgs',
                              optionflags=doctest.ELLIPSIS, raise_on_error=True)
    assert results.failed == 0, "Setup failed: %s" % results

# Generated at 2022-06-21 08:22:59.537514
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # text_type and binary_type are strings so they should go through unchanged
    test_dict = dict(
        text=text_type('some text'),
        binary=binary_type(b'\x00\x01\x02\x03'),
    )
    assert CLIArgs(test_dict) == test_dict

    # Check the dict is immutable
    with pytest.raises(TypeError):
        mutable_dict = test_dict
        mutable_dict['text'] = 'some text'

    # Mutable versions shouldn't be mutated themself

# Generated at 2022-06-21 08:23:02.272425
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ABCSingletonTest(object):
        pass


    a = ABCSingletonTest()
    b = ABCSingletonTest()
    assert a is b

# Generated at 2022-06-21 08:23:09.440950
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Requirement - CLIArgs behaves like a dictionary

    Behavior - store a reference to a dictionary and use it to create a new
        CLIArgs.  Then verify that __contains__ and __iter__ work the same way
        for both the dictionary and the CLIArgs.

    :return: None
    """
    dictionary = {'a': 1, 'b': 2, 'c': 3}
    args = CLIArgs(dictionary)
    for key in dictionary:
        assert key in args
    assert 'd' not in args

    assert set(dictionary) == set(args)



# Generated at 2022-06-21 08:23:12.281522
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class testclass(metaclass=_ABCSingleton):
        def __init__(self, *args, **kwargs):
            super(testclass, self).__init__()

    a = testclass()
    b = testclass()
    assert(a is b)

# Generated at 2022-06-21 08:23:23.703878
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    a_dict = {'key1': 'value1', 'key2': [1, 2, 3, 4], 'key3': {'k1': 1, 'k2': [5, 6, 7, 8]},
              'key4': {'k1': {'k2': {'k3': {'k4': {'k5': [5, 6, 7, 8]}}}}}}
    cmd_args = CLIArgs(a_dict)
    assert(cmd_args == a_dict)



# Generated at 2022-06-21 08:23:29.513056
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Test CLIArgs constructor, test that it doesn't contain mutable types"""
    from ansible.utils.display import Display
    display = Display()

    cli_args = CLIArgs(CLIArgs.from_options(display.options))

    assert isinstance(cli_args['options']['verbosity'], int)
    assert not isinstance(cli_args['options']['verbosity'], list)



# Generated at 2022-06-21 08:23:31.055500
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    _cli = GlobalCLIArgs()



# Generated at 2022-06-21 08:23:42.506245
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Test the GlobalCLIArgs class.

    Asserts that:
    1) GlobalCLIArgs is a Singleton
    2) GlobalCLIArgs is a subclass of CLIArgs
    3) GlobalCLIArgs is immutable
    """
    import copy

    opt = copy.deepcopy(GlobalCLIArgs)

    # Assert GlobalCLIArgs is a Singleton
    opt.hello = "world"
    assert opt['hello'] == "world"
    assert GlobalCLIArgs['hello'] == "world"

    # Assert GlobalCLIArgs is immutable
    try:
        GlobalCLIArgs['hello'] = 'world'
    except TypeError:
        pass
    else:
        raise Exception("Mutation of Singleton not detected")

    # Assert GlobalCLIArgs is a subclass of CLIArgs

# Generated at 2022-06-21 08:23:48.767576
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyClass(object):
        __metaclass__ = _ABCSingleton

        def __init__(self, name):
            self.name = name

    instance1 = MyClass('instance1')
    instance2 = MyClass('instance2')

    assert instance1.name == 'instance1'
    assert instance2.name == 'instance1'
    assert instance1 == instance2
    assert instance1 is instance2

# Generated at 2022-06-21 08:23:52.769222
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Make sure we can create a Singleton class
    """
    class A(object):
        __metaclass__ = _ABCSingleton

    x = A()
    y = A()
    assert x is y, 'Failed to create a Singleton class'

# Generated at 2022-06-21 08:23:57.320922
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    try:
        GlobalCLIArgs({'foo': 'bar'})
        raise RuntimeError("Should not be able to construct a GlobalCLIArgs, must use 'instance' not 'constructor'")
    except TypeError:
        pass

    test_args = CLIArgs({'foo': 'bar'})
    GlobalCLIArgs.instance(test_args)

    assert GlobalCLIArgs.instance() == {'foo': 'bar'}


# Generated at 2022-06-21 08:24:03.736332
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    x = GlobalCLIArgs({'a': {1, 2, 3}, 'b': {'foo': 'bar', 'baz': 42}})
    assert isinstance(x, ImmutableDict)
    assert isinstance(x, Mapping)
    assert isinstance(x, CLIArgs)
    assert isinstance(x['a'], Set)
    assert isinstance(x['b'], Mapping)

# Generated at 2022-06-21 08:24:14.446733
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton(_ABCSingleton):
        pass
    class TestMetaclass(ABCMeta):
        pass
    class Test(_ABCSingleton, TestMetaclass):
        pass
    class Test2(TestMetaclass, _ABCSingleton):
        pass
    # Check that we can't create multiple instances of a class
    try:
        class TestSingletonError(_ABCSingleton):
            pass
        TestSingletonError()
        TestSingletonError()
        assert False
    except AssertionError:
        raise
    except TypeError:
        pass
    # Check that we can't create multiple instances of a class with a non-ABCMeta parent
    try:
        Test()
        Test()
        assert False
    except AssertionError:
        raise
    except TypeError:
        pass
    # Check that we can't

# Generated at 2022-06-21 08:24:20.717928
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a1 = GlobalCLIArgs({'a': 1})
    assert a1
    assert a1 == {'a': 1}

    try:
        a1['a'] = 2
    except TypeError:
        pass
    else:
        assert False, "Should not be able to modify a frozen mapping"

    a2 = GlobalCLIArgs(a1)
    assert a2
    assert a2 == a1

    # Check that making a new object does not modify the old one
    a3 = GlobalCLIArgs({'a': 2})
    assert a2 == {'a': 1}
    assert a3 == {'a': 2}

# Generated at 2022-06-21 08:24:25.443259
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyClass(object, metaclass=_ABCSingleton):
        pass
    assert issubclass(MyClass, object)
    assert MyClass is MyClass()


# Generated at 2022-06-21 08:24:29.914589
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    try:
        class TestMetaclass(metaclass=_ABCSingleton):
            pass
        raise RuntimeError('Creating a new class using _ABCSingleton as a metaclass should not be allowed')
    except TypeError:
        print('Caught TypeError')


# Generated at 2022-06-21 08:24:41.289672
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    x = GlobalCLIArgs({'a': 1, 'b': {'c': 3}, 'd': ['e', 'f']})

    # Test that each field appears
    assert x['a'] == 1
    assert x['b']['c'] == 3
    assert x['d'][0] == 'e'

    # Test that changes to the input dictionary do not affect the GlobalCLIArgs instance
    input_dict = {'a': 1, 'b': {'c': 3}, 'd': ['e', 'f']}
    assert input_dict['a'] == 1
    input_dict['a'] = 99
    assert x['a'] == 1
    input_dict['b']['c'] = 99
    assert x['b']['c'] == 3
    input_dict['d'][0] = 'g'


# Generated at 2022-06-21 08:24:45.854541
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        """Check that Singleton wins over ABCMeta"""
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    class D(object):
        """Check that ABCMeta wins over Singleton"""
        __metaclass__ = _ABCSingleton
        __metaclass__ = ABCMeta

    class E(D):
        pass

# Generated at 2022-06-21 08:24:56.912943
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestBaseClass(object):
        """A class to test that the metaclass _ABCSingleton is working correctly"""
        pass

    class TestA(TestBaseClass):
        """This class should not have a metaclass of type TestBaseClass"""
        pass

    TestB = _ABCSingleton('TestB', (TestBaseClass,), {})
    class TestC(TestB):
        """This class should have a metaclass of type TestB"""
        pass

    assert issubclass(TestA, TestBaseClass)
    assert TestA.__class__ == type
    assert not issubclass(TestB, TestBaseClass)
    assert TestB.__class__ == _ABCSingleton
    assert issubclass(TestC, TestB)
    assert TestC.__class__ == TestB

# Generated at 2022-06-21 08:24:59.330430
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton


# Generated at 2022-06-21 08:25:02.531313
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Ensure that we can initialize a _ABCSingleton class

    We do this because the combination of Singleton and ABCMeta was once a class that was not
    creatable.
    """
    class TestABCSingleton(_ABCSingleton):
        pass

    TestABCSingleton()



# Generated at 2022-06-21 08:25:05.073546
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    cliargs = GlobalCLIArgs({'a': 'b'})
    assert cliargs == ImmutableDict({'a': 'b'})

# Generated at 2022-06-21 08:25:11.895754
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Creates a class that inherits from _ABCSingleton"""
    class TestGlobalCLIArgs(GlobalCLIArgs):
        """Test class to verify Singleton metaclass"""
        def __init__(self):
            pass

    try:
        TestGlobalCLIArgs()  # pylint: disable=abstract-class-instantiated
        TestGlobalCLIArgs()  # pylint: disable=abstract-class-instantiated
    except TypeError:
        return
    assert False, "TestGlobalCLIArgs() should be a metaclass of _ABCSingleton and should raise a TypeError"

# Generated at 2022-06-21 08:25:18.041139
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton(_ABCSingleton):
        pass

    class Test1(metaclass=TestSingleton):
        pass

    class Test2(metaclass=TestSingleton):
        pass

    assert issubclass(Test1, Test2)
    assert issubclass(Test2, Test1)

# Generated at 2022-06-21 08:25:25.246225
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Create a common instance of CLIArgs
    a = CLIArgs({'foo': 'bar'})

    # Create a copy of CLIArgs
    b = CLIArgs(a)

    # Check some properties
    assert isinstance(a, dict)
    assert not isinstance(a, Mapping)
    assert isinstance(a, ImmutableDict)
    assert not isinstance(a, Mapping)
    assert not isinstance(a, Set)
    assert not isinstance(a, Sequence)
    assert a == b
    assert id(a) != id(b)
    assert hash(a) == hash(b)



# Generated at 2022-06-21 08:25:29.555482
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Meta(_ABCSingleton):
        pass

    class Test(object):
        __metaclass__ = Meta

    testInstance = Test()
    testInstance_2 = Test()
    assert testInstance == testInstance_2

# Generated at 2022-06-21 08:25:38.835256
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # test that it behaves the same as ImmutableDict for base case
    mapping = {'key': 'value'}
    cli_args = CLIArgs(mapping)

    assert mapping == cli_args
    assert mapping is not cli_args

    # test that it behaves the same as ImmutableDict for recursive case
    mapping2 = {'key': {'key2': {'key3': 'value'}}}
    cli_args2 = CLIArgs(mapping2)

    assert mapping2 == cli_args2
    assert mapping2 is not cli_args2
    assert mapping2['key'] is not cli_args2['key']
    assert mapping2['key']['key2'] is not cli_args2['key']['key2']


# Generated at 2022-06-21 08:25:49.845715
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.display import Display
    from ansible.module_utils.common.collections import ImmutableDict

    class Test(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b

        def __eq__(self, other):
            return (self.a, self.b) == (other.a, other.b)

    # We only use the constructor not the from_options() method in this unit test
    args = CLIArgs(vars(Display().parse_cli_args(['--foo=bar'])))
    assert isinstance(args, ImmutableDict)
    assert args == {u'foo': u'bar'}

    test = Test('1', '2')

# Generated at 2022-06-21 08:25:58.472410
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Boilerplate for all test cases
    class Options(object):
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    # Assert that all containers are mutated to be immutable
    options = Options(a=[1, 2, 3], b=[dict(a=1), dict(b=2)])
    cli = CLIArgs.from_options(options)
    assert isinstance(cli, CLIArgs), "Constructor of class CLIArgs failed to make an instance"
    assert isinstance(cli['a'], tuple), "Constructor of class CLIArgs failed to make tuple"
    assert isinstance(cli['b'], tuple), "Constructor of class CLIArgs failed to make tuple"

# Generated at 2022-06-21 08:26:01.919970
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    my_dictionary = {'one': 1, 'two': {"hello": "world"}}
    my_args = CLIArgs(my_dictionary)
    assert my_args == my_dictionary


# Generated at 2022-06-21 08:26:11.296771
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from collections import namedtuple
    from ansible.module_utils.common.collections import ActionBase

    globals = GlobalCLIArgs(dict(one="two", three=4, five=True, six=False))
    assert globals['one'] == "two"
    assert globals['three'] == 4
    assert globals['five'] == True
    assert globals['six'] == False

    # Test that the class is always a Singleton
    globals2 = GlobalCLIArgs.from_options(None)
    assert globals is globals2

    # Test that it will fail on setting a value
    try:
        globals['not_allowed'] = True
        assert False
    except RuntimeError:
        pass


# Generated at 2022-06-21 08:26:13.144079
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = GlobalCLIArgs(dict([(1,2)]))

# Generated at 2022-06-21 08:26:13.747061
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    pass

# Generated at 2022-06-21 08:26:19.879481
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Test that the __metaclass__ magic method is callable and returns an instance of the class it is
    being called on.
    """
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert A() == A()
    assert A() is A()
    assert B() == B()
    assert B() is B()
    assert C() == C()
    assert C() is C()

    assert A() != B()
    assert A() is not B()
    assert B() != C()
    assert B() is not C()

# Generated at 2022-06-21 08:26:24.680141
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    cli_args = GlobalCLIArgs.from_options(object())
    assert cli_args
    assert isinstance(cli_args, GlobalCLIArgs)

# Generated at 2022-06-21 08:26:35.189555
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import is_listlike
    from ansible.module_utils.common.text.converters import to_text

    GlobalCLIArgs({to_text('foo'): to_text('bar'), to_text('baz'): [1, 2, 3]})

    assert GlobalCLIArgs({}) == ImmutableDict({})

    assert is_listlike(GlobalCLIArgs({to_text('baz'): [1, 2, 3]}).get('baz'))

    assert GlobalCLIArgs({to_text('baz'): ['bar']}) != GlobalCLIArgs({to_text('baz'): ['foo', 'bar']})

    assert GlobalCLIArgs({'foo': {}, 'bar': 3})['foo'] == {}


# Generated at 2022-06-21 08:26:45.696080
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({}) == {}
    assert CLIArgs(dict(a=1)) == dict(a=1)
    assert CLIArgs(dict(a=dict(b="c"))) == dict(a=dict(b="c"))
    assert CLIArgs(dict(a=dict(b=["c", "d"]))) == dict(a=dict(b=tuple(["c", "d"])))
    assert CLIArgs(dict(a=dict(b=set(["c", "d"])))) == dict(a=dict(b=frozenset(["c", "d"])))
    assert CLIArgs(dict(a=dict(b=(["c", ["d"]])))) == dict(a=dict(b=(tuple(["c", tuple(["d"])]))))

# Generated at 2022-06-21 08:26:50.371469
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # noinspection PyUnresolvedReferences
    class A(_ABCSingleton):
        pass

    # noinspection PyUnresolvedReferences
    class B(_ABCSingleton):
        pass

    # noinspection PyUnresolvedReferences
    class C(B):
        pass

# Generated at 2022-06-21 08:26:57.695470
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        pass

    b = A()
    c = A()
    assert(b is not c)

    class B(object):
        __metaclass__ = _ABCSingleton

    d = B()
    e = B()
    assert(d is e)

    class C(object):
        __metaclass__ = A

    f = C()
    g = C()
    assert(f is not g)

    class D(object):
        __metaclass__ = B

    h = D()
    i = D()
    assert(h is i)

# Generated at 2022-06-21 08:27:04.245998
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.text.converters import to_bytes

    class FakeOptions(object):
        def __init__(self, arg_dict):
            for key, val in arg_dict.items():
                setattr(self, key, val)

    # Common code.  Test that a vanilla copy of the options gets turned into an ImmutableDict
    opt_dict = {'hello': 'world',
                'number': 22,
                'flag': True,
                'listofstuff': [1, 2, 3, 4],
                'nested': {'level2': {'level3': 'nested'}}}
    options = FakeOptions(opt_dict)
    arg_dict = CLIArgs(vars(options))

# Generated at 2022-06-21 08:27:08.896437
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # calling a function to set up some global variables
    test_args()
    cli_args = GlobalCLIArgs()
    assert cli_args['verbosity'] == 3 and cli_args['connection'] == 'local' and cli_args['forks'] == 8


# Generated at 2022-06-21 08:27:12.266252
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert GlobalCLIArgs() is not None
    assert GlobalCLIArgs() is GlobalCLIArgs()
    assert GlobalCLIArgs() == GlobalCLIArgs()

# Generated at 2022-06-21 08:27:21.711209
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import unittest

    from ansible.module_utils.six import with_metaclass

    class TestSingleton(with_metaclass(_ABCSingleton)):
        def __init__(self):
            self.x = 1

        @classmethod
        def test(cls):
           return cls()

    class GlobalCLIArgs(TestSingleton):
        pass

    class TestGlobalCLIArgsMethods(unittest.TestCase):
        def test_singleton(self):
            self.assertEqual(TestSingleton.test().x, 1)
            self.assertEqual(TestSingleton().x, 1)
            self.assertEqual(GlobalCLIArgs.test().x, 1)
            self.assertEqual(GlobalCLIArgs().x, 1)

# Generated at 2022-06-21 08:27:27.151912
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingletonClass(_ABCSingleton):
        pass

    class AnotherSingleton(_ABCSingleton):
        pass

    assert issubclass(SingletonClass, Singleton)
    assert issubclass(SingletonClass, ABCMeta)
    assert SingletonClass is not AnotherSingleton
    assert not hasattr(SingletonClass, '__abstractmethods__')

# Generated at 2022-06-21 08:27:33.564718
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _Foo():
        pass

    assert isinstance(_Foo, _ABCSingleton)

# Generated at 2022-06-21 08:27:41.518179
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class _ABCSingletonTestClass(ImmutableDict, object, metaclass=_ABCSingleton):
        def __init__(self, val):
            super(_ABCSingletonTestClass, self).__init__()
            self._val = val

        def __getattr__(self, item):
            return self._val

    # Test creation of multiple instances of class which has the _ABCSingleton metaclass
    a = _ABCSingletonTestClass(val="a")
    b = _ABCSingletonTestClass(val="b")
    assert a is b

# Generated at 2022-06-21 08:27:44.023244
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object):
        __metaclass__ = _ABCSingleton
    new = Test()
    new_two = Test()

    assert new == new_two

# Generated at 2022-06-21 08:27:47.257244
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class Foo(with_metaclass(_ABCSingleton, object)):
        pass

    class Bar(with_metaclass(_ABCSingleton, object)):
        pass

    assert Foo() is Foo()
    assert Bar() is Bar()
    assert Foo() is not Bar()

# Generated at 2022-06-21 08:27:49.271125
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(GlobalCLIArgs, Singleton)
    assert isinstance(GlobalCLIArgs, ABCMeta)

# Generated at 2022-06-21 08:28:00.574047
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # A trivial example
    args = CLIArgs({'foo': 'bar'})
    assert args['foo'] == 'bar'
    # A trivial example of a complicated data types
    args = CLIArgs({'foo': [1, 2, 3], 'bar': {'baz': 'bang'}})
    assert args['foo'] == (1, 2, 3)
    assert args['bar'] == ImmutableDict({'baz': 'bang'})
    # A more complex example
    args = CLIArgs({'foo': [{'bar': 'baz', 'bang': [1, 2, 3]}, 'qux']})
    assert args['foo'] == ImmutableDict([({'bar': 'baz', 'bang': (1, 2, 3)},)])



# Generated at 2022-06-21 08:28:10.406131
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    input_dict = {
        'listoptions': set(['list1', 'list2']),
        'bar': u'baz',
        'other': {
            'nested_list': [
                {
                    'first': '1',
                },
                {
                    'second': '2',
                },
            ],
            'nested_dict': {
                'key1': 'value1',
                'key2': 'value2',
            },
            'nested_set': {'set1', 'set2'},
        },
    }
    output_dict = CLIArgs(input_dict)
    assert isinstance(output_dict['listoptions'], frozenset)
    assert isinstance(output_dict['bar'], text_type)

# Generated at 2022-06-21 08:28:18.445423
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    @add_metaclass(_ABCSingleton)
    class A(object):
        pass

    @add_metaclass(_ABCSingleton)
    class B(object):
        pass

    a1 = A()
    a2 = A()

    assert(a1 is a2)
    assert(A is a1)

    b1 = B()
    b2 = B()

    assert(b1 is b2)
    assert(B is b1)

# Generated at 2022-06-21 08:28:20.815817
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(GlobalCLIArgs, Singleton)
    assert issubclass(GlobalCLIArgs, ABCMeta)


# Generated at 2022-06-21 08:28:22.063006
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert isinstance(GlobalCLIArgs([]), GlobalCLIArgs)

# Generated at 2022-06-21 08:28:38.238895
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs(dict(a='text'))

# Generated at 2022-06-21 08:28:40.931922
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    arg = GlobalCLIArgs({'arg1': 1, 'arg2': 2})
    assert arg['arg1'] == 1
    assert arg['arg2'] == 2



# Generated at 2022-06-21 08:28:43.284930
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    '''
    >>> args = CLIArgs({'foo': {'bar': 'baz'}, 'fie': 'fum'})
    '''


# Generated at 2022-06-21 08:28:52.194746
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Unset the global singleton completely so we can test our singleton initialization
    GlobalCLIArgs._GlobalCLIArgs__instance = None
    # Make sure all the munging of the class definitions above worked to make GlobalCLIArgs a
    # singleton
    assert GlobalCLIArgs is GlobalCLIArgs()
    # Check that we get the same thing when we call the constructor again
    assert GlobalCLIArgs is _make_immutable(GlobalCLIArgs())
    # Check that we get the same thing when we construct GlobalCLIArgs directly
    assert GlobalCLIArgs is GlobalCLIArgs({'key': 'value'})

# Generated at 2022-06-21 08:29:03.724801
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import mock
    import ansible.cli.cli as cli
    from ansible.cli import CLI
    from ansible.errors import AnsibleError
    from ansible.module_utils._text import to_native
    cli.CLI.base_parser = CLI.base_parser
    cli.CLI.base_parser.add_argument = mock.MagicMock(wraps=cli.CLI.base_parser.add_argument)

    # We need an exception to get control back after parsing the command line
    class FakeException(Exception):
        pass

    # Mocking the help to catch if its called in the code under test
    help_function = mock.MagicMock(side_effect=FakeException())
    cli.CLI.p.add_argument = mock.MagicMock(return_value=cli.CLI.p)

# Generated at 2022-06-21 08:29:08.441936
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class X(object):
        __metaclass__ = _ABCSingleton

        def __init__(self, name):
            self.name = name

    class Y(X):
        pass

    class Z(X):
        pass

    assert X('foo') is not X('bar')
    assert X('foo') is Y('foo')
    assert X('foo') is Z('foo')
    assert Y('foo') is Z('foo')

# Generated at 2022-06-21 08:29:20.528883
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import string_types

    cli_args = GlobalCLIArgs({'foo': 'bar', 'test': Mapping({'test1': "test2", "test3": "test4"})})
    assert cli_args.get('foo') == 'bar'
    assert cli_args.get('test').get('test1') == 'test2'
    assert cli_args.get('test').get('test3') == 'test4'
    # Check if they are immutables
    if isinstance(cli_args['foo'], string_types):
        pass
    else:
        pytest.fail("%s is not immutable." % type(cli_args['foo']))

# Generated at 2022-06-21 08:29:24.233211
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingletonABC(object):
        __metaclass__ = _ABCSingleton

    class AnotherSingletonABC(object):
        __metaclass__ = _ABCSingleton

    assert(issubclass(SingletonABC, _ABCSingleton))

# Generated at 2022-06-21 08:29:33.453343
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestA(metaclass=_ABCSingleton):
        pass
    class TestB(metaclass=_ABCSingleton):
        pass
    try:
        class TestC(TestA, TestB):
            pass
    except TypeError:
        raise AssertionError("ABCSingleton: can't combine Singleton and ABCMeta") from None
    try:
        class TestD(TestB, TestA):
            pass
    except TypeError:
        raise AssertionError("ABCSingleton: can't combine Singleton and ABCMeta") from None

# Generated at 2022-06-21 08:29:37.364115
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class test(object):
        __metaclass__ = _ABCSingleton
        def __init__(self):
            self.x = "foo"

    a = test()
    b = test()
    assert a is b
    assert a.x == b.x
    assert a.x == "foo"

# Generated at 2022-06-21 08:30:03.620999
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import unittest
    import ansible.constants as C

    _myoptions = type('myoptions', (object,), {'force_handlers': True, 'flush_cache': C.FLUSH_CACHE_NEVER,
                                               'step': True, 'start_at_task': "this", 'verbosity': 0, 'check': False})
    _myargs = type('myargs', (object,), {'options': _myoptions()})()
    _mycliargs = GlobalCLIArgs(_myargs)
    _mycliargs2 = GlobalCLIArgs(_myargs)

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_singleton(self):
            self.assertIs(_mycliargs, _mycliargs2)


# Generated at 2022-06-21 08:30:14.095194
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    class B(metaclass=_ABCSingleton):
        pass
    class C(A, B):
        pass
    class D(B, A):
        pass
    class E(C, D):
        pass
    class F(D, C):
        pass
    class G(E, F):
        pass
    class H(F, E):
        pass
    class J(metaclass=_ABCSingleton):
        pass
    class K(metaclass=_ABCSingleton):
        pass
    class L(J, K):
        pass
    class M(K, J):
        pass
    class N(L, M):
        pass
    class O(M, L):
        pass
    class P(N, O):
        pass

# Generated at 2022-06-21 08:30:25.235692
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from collections import OrderedDict, namedtuple
    from ansible.module_utils.parsing.convert_bool import boolean
    dict1 = dict(a=1, b=True, c=False, d=None)
    dict2 = dict(a=None, b=False, c=True, d=1)
    dict3 = dict(a=3, c=True)
    dict4 = dict(a=4, c=True)
    dict5 = dict(d=5, c=False)
    dict6 = dict(d=6, c=False)
    dict7 = dict(b=7, c=True)
    dict8 = dict(b=8, c=False)
    dict9 = dict(b=9, c=False)
    dict10 = dict(b=10, c=True)


# Generated at 2022-06-21 08:30:27.828348
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    b = B()

# Generated at 2022-06-21 08:30:37.395412
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-21 08:30:39.553389
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.options import Options
    options = Options()

    # Initialize the library classes
    options.initialize()

    # Parse options and call final callback
    options.parse()

    # Create GlobalCLIArgs
    CLIArgs(vars(options))

# Generated at 2022-06-21 08:30:46.298988
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton
    # the following should fail
    class Bar(object):
        __metaclass__ = _ABCSingleton
    assert not issubclass(Bar, Foo)
    assert Foo != Bar
    assert Foo() != Bar()
    assert Foo.__class__ == Bar.__class__ == _ABCSingleton

# Generated at 2022-06-21 08:30:52.748977
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs.clear_instance()
    cli_args = GlobalCLIArgs(dict(bar='bar', zoo='zoo', foobar='foobar'))
    for key in cli_args:
        assert key in ('bar', 'zoo', 'foobar')
    assert cli_args['bar'] == 'bar'
    assert cli_args['zoo'] == 'zoo'
    assert cli_args['foobar'] == 'foobar'

# Generated at 2022-06-21 08:31:00.562769
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import types

    # test init
    options = types.SimpleNamespace()
    options.become = True
    options.become_ask_pass = True
    options.become_user = 'joe'
    options.tags = ['tag1', 'tag2']
    options.skip_tags = ['skip', 'skip2']
    options.check = True

    args = GlobalCLIArgs.from_options(options)
    assert args.become == options.become
    assert args.become_ask_pass == options.become_ask_pass
    assert args.become_user == options.become_user
    assert args.tags == options.tags
    assert args.skip_tags == options.skip_tags
    assert args.check == options.check

    # test immutable

# Generated at 2022-06-21 08:31:12.792138
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.boolean import boolean
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.six import string_types
    from ansible.module_utils.six import text_type

    options = {'a': ['1', '2'], 'b': None, 'c': '3', 'd': 'True', 'f': '1,2,3', 'g': 'posix', 'h': 'foo,bar,baz', 'i': '', 'j': '0'}
    opt = CLIArgs(options)

    assert isinstance(opt, Mapping)
    assert opt['a'] == ('1', '2')
    assert opt['b'] is None
    assert opt['c'] == '3'
    assert opt['d'] is True

# Generated at 2022-06-21 08:31:47.999217
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = GlobalCLIArgs({'a': 1, 'b': 'A'})
    assert a['a'] == 1
    assert a['b'] == 'A'
    assert a == {'a': 1, 'b': 'A'}

# Generated at 2022-06-21 08:31:58.979534
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    data = {
        'rpcapi_port': 123,
        'path_plugins': ['.'],
        'foo': 'bar',
        'dict': {'a': 'b', 'c': 'd'},
    }

    class ContextObj(object):
        def __init__(self, a_int, a_str):
            self.a_int = a_int
            self.a_str = a_str

        def __eq__(self, other):
            return (self.a_int == other.a_int and self.a_str == other.a_str)

        def __hash__(self):
            return hash(repr(self))
