

# Generated at 2022-06-21 08:22:23.147376
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from copy import deepcopy
    import collections
    import types

    def test_recursive_is_immutable(x):
        if type(x) in (dict, collections.Iterator, types.GeneratorType):
            assert isinstance(x, ImmutableDict)
            for key, value in x.items():
                test_recursive_is_immutable(value)
        elif type(x) in (list, tuple):
            for val in x:
                test_recursive_is_immutable(val)
        else:
            assert type(x) not in (dict, list, tuple)

    # test data to ensure recursion doesn't crash

# Generated at 2022-06-21 08:22:27.348739
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    # Only run the test if we're running in a 'built' state
    if "__file__" in sys.modules[__name__]:
        args = GlobalCLIArgs({'test': 'this'})
        assert args == {'test': 'this'}



# Generated at 2022-06-21 08:22:31.081106
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(metaclass=_ABCSingleton):
        pass
    assert len(Foo.__bases__) == 2
    assert Foo.__mro__ == (Foo, ABCMeta, object)
    class Bar(Foo):
        pass
    assert Bar._abc_registry == Foo._abc_registry


# Generated at 2022-06-21 08:22:43.220688
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass
    assert A is not B and B is not C and C is not D
    assert issubclass(A, ABCMeta)
    assert issubclass(A, Singleton)
    assert issubclass(B, A) and issubclass(C, A) and issubclass(D, C)
    assert not issubclass(A, B) and not issubclass(A, C) and not issubclass(C, D)
    assert A().__class__ is A and B().__class__ is B and C().__class__ is C and D().__class__ is D
    assert A() is A() and B() is B() and C()

# Generated at 2022-06-21 08:22:48.155605
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(metaclass=_ABCSingleton):
        pass
    class Bar(metaclass=_ABCSingleton):
        def __init__(self, value):
            self._value = value

    foo1 = Foo()
    foo2 = Foo()
    assert foo1 is foo2

    bar1 = Bar(1)
    assert bar1._value == 1
    bar2 = Bar(2)
    assert bar1 is bar2

    class Baz(Foo, Bar):
        def __init__(self, value):
            self._value = value

    baz = Baz(3)
    assert baz._value == 3
    assert baz is bar1

# Generated at 2022-06-21 08:22:50.514748
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton(_ABCSingleton):
        pass

    class TestABCMeta(TestSingleton, ABCMeta):
        pass

    class Test(metaclass=TestABCMeta):
        pass

    assert id(TestSingleton()) == id(TestSingleton())
    assert id(Test()) == id(Test())

# Generated at 2022-06-21 08:22:52.822509
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs({'foo': 'bar'})
    assert global_cli_args['foo'] == 'bar'

# Generated at 2022-06-21 08:22:56.548806
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()
    assert B() is B()
    assert A() is not B()


# Generated at 2022-06-21 08:23:01.101454
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    metaclass = _ABCSingleton('test__ABCSingleton', (), {})

    class test__ABCSingleton_class(metaclass):
        pass

    first_object = test__ABCSingleton_class()
    second_object = test__ABCSingleton_class()
    assert first_object is second_object

# Generated at 2022-06-21 08:23:07.200037
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': {'b': 'foo', 'c': 'bar'}, 'd': 'baz'}
    cli_args = CLIArgs.from_options(test_dict)
    assert cli_args == test_dict
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args['a'], ImmutableDict)
    assert isinstance(cli_args['d'], str)

# Generated at 2022-06-21 08:23:21.415202
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections

    # Basic assignment
    test_dict = collections.OrderedDict()
    test_dict['string'] = 'I am a string'
    test_dict['list'] = ['I', 'am', 'a', 'list']
    test_dict['tuple'] = ('I', 'am', 'a', 'tuple')
    test_dict['dict'] = {'I': 'am', 'a': 'dict'}
    test_dict['int'] = 5

# Generated at 2022-06-21 08:23:23.695856
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton):
        ...

    assert issubclass(Foo, ABCMeta)
    assert issubclass(Foo, Singleton)

# Generated at 2022-06-21 08:23:28.829528
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
        pass

    try:
        TestClass()
    except TypeError:  # Caller should not be able to construct directly, constructor should be Singleton()
        pass
    else:
        raise AssertionError("TestClass constructor should raise TypeError when called directly")


# Generated at 2022-06-21 08:23:30.847575
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    opts = CLIArgs({})
    assert isinstance(opts, CLIArgs)

# Generated at 2022-06-21 08:23:42.358685
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    argument_dict_mutable = {'key1': 'value1', 'key2': ['value2-0', 'value2-1', 'value2-2']}
    argument_dict_immutable = {'key1': 'value1', 'key2': ('value2-0', 'value2-1', 'value2-2')}

    # Test the constructor
    arguments = CLIArgs(argument_dict_mutable)
    assert isinstance(arguments, ImmutableDict)
    assert isinstance(arguments, Mapping)
    assert hasattr(arguments, '__getitem__')
    assert hasattr(arguments, 'items')
    assert hasattr(arguments, 'keys')
    assert hasattr(arguments, 'values')

    # Test the constructor recursively made the list into a tuple
    assert arguments == argument

# Generated at 2022-06-21 08:23:46.974370
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {
        "test_key": {
            "test_key_2": "test_text",
            "test_key_3": [
                "test_text_1",
                "test_text_2"
            ]
        }
    }
    cli_args = CLIArgs(args)
    assert cli_args["test_key"]["test_key_2"] == "test_text"
    assert cli_args["test_key"]["test_key_3"][0] == "test_text_1"
    assert cli_args["test_key"]["test_key_3"][1] == "test_text_2"

# Generated at 2022-06-21 08:23:50.963676
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from argparse import ArgumentParser
    parser = ArgumentParser()
    parser.add_argument('--foo', type=int, default=10)
    argv = ['--foo', '1']
    options = parser.parse_args(argv)
    options_dict = vars(options)
    global_cli_args = GlobalCLIArgs.from_options(options)
    for key, value in options_dict.items():
        assert global_cli_args[key] == value



# Generated at 2022-06-21 08:23:58.281734
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class test_cli_args(object):
        def __init__(self):
            self.test_dict = {'test_dict': {'test1': 'value1', 'test2': 'value2'},
                              'test_list': ['test3', 'test4'],
                              'test_str': 'test_str'}
    test_mapping = test_cli_args
    args = CLIArgs(test_mapping.__dict__)
    assert isinstance(args, CLIArgs)
    assert isinstance(args, ImmutableDict)
    assert isinstance(args.get('test_dict'), ImmutableDict)
    assert isinstance(args.get('test_list'), tuple)
    assert isinstance(args.get('test_str'), text_type)


# Generated at 2022-06-21 08:24:10.212722
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import MutableMapping
    from ansible.module_utils.common.text.converters import to_bytes

    # Assert the basics
    assert issubclass(CLIArgs, MutableMapping)
    assert CLIArgs({})
    c = CLIArgs({'foo': 'bar'})
    assert c['foo'] == 'bar'
    assert c == {'foo': 'bar'}
    assert c == {'foo': 'bar'}
    assert c != {'foo': 'baz'}
    assert set(c.keys()) == {'foo'}
    assert set(c.values()) == {'bar'}
    assert set(c.items()) == {('foo', 'bar')}
    assert hash(c) == hash(('foo', 'bar'))

# Generated at 2022-06-21 08:24:19.750086
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import collections
    from ansible.executor.task_result import TaskResult
    from ansible.utils.color import stringc
    from ansible.utils.plugins import PluginLoader

    a = collections.defaultdict(lambda: 'abc')
    a.update({'a': 'abc', 'b': 'def', 'c': [1, 2, 3]})
    b = TaskResult('fake_host', 'fake_task', 'fake_action', 'fake_task_result')
    c = stringc('x')
    d = PluginLoader()
    assert not isinstance(a, GlobalCLIArgs)
    assert not isinstance(b, GlobalCLIArgs)
    assert not isinstance(c, GlobalCLIArgs)
    assert not isinstance(d, GlobalCLIArgs)

# Generated at 2022-06-21 08:24:26.702902
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({'foo': 1})
    assert args.foo == 1
    assert args.get('foo') == 1
    assert args['foo'] == 1
    try:
        args.foo = 2
    except AttributeError as e:
        assert "can't set attribute" in str(e)
    else:
        assert False



# Generated at 2022-06-21 08:24:37.925777
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar', nargs='*')
    parser.add_argument('-b', '--baz', action='store_false')
    parser.add_argument('--qux', action='store_true')
    args = vars(parser.parse_args())

    global_args = GlobalCLIArgs.from_options(args)
    assert global_args['foo'] == 'test'
    assert global_args['bar'] == ['bar1', 'bar2', 'bar3']
    assert global_args['baz'] is False
    assert global_args['qux'] is True
    assert global_args['foosball'] is None

# Generated at 2022-06-21 08:24:46.468503
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.module_utils.common.argparse import (
        argparse_args,
        console_messages,
        console_warning,
    )
    cmd_args = ['--force-color', '--diff']
    with pytest.raises(SystemExit) as ex:
        argparse_args(['ansible', 'hello'] + cmd_args)
    assert ex.value.code == 0
    console_messages.reset()
    with pytest.raises(SystemExit) as ex:
        argparse_args(['ansible-config', 'view', '--version'] + cmd_args)
    assert ex.value.code == 0

# Generated at 2022-06-21 08:24:52.874930
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        def __init__(self, args):
            self.var = args

    args = ['arg1', 'arg2']
    options = Options(args)
    # Instantiate GlobalCLIArgs once
    GlobalCLIArgs.from_options(options)
    # Instantiate GlobalCLIArgs again to check for
    # Singleton functionality
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-21 08:24:58.147451
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    global_singleton = GlobalCLIArgs({})
    assert global_singleton is GlobalCLIArgs()
    assert "__len__" in dir(GlobalCLIArgs)
    our_singleton = CLIArgs({})
    assert our_singleton is CLIArgs()
    assert isinstance(our_singleton, Mapping)
    assert not isinstance(our_singleton, Singleton)

# Generated at 2022-06-21 08:24:59.149250
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({'a': 1})

# Generated at 2022-06-21 08:25:01.716951
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABCSingletonSubclass(metaclass=_ABCSingleton):
        pass
    instance = _ABCSingletonSubclass()
    assert isinstance(instance, _ABCSingletonSubclass)

# Generated at 2022-06-21 08:25:08.616360
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyABCSingletonClass(object):
        __metaclass__ = _ABCSingleton

    # Only one instance of the class can be created
    first_instance = MyABCSingletonClass()
    second_instance = MyABCSingletonClass()
    assert first_instance is second_instance

    # An abstract class can be defined
    class ABCTestClass(MyABCSingletonClass):
        pass
    assert any('abstract' in prop for prop in ABCTestClass.__dict__.values())

    # But it needs to be subclassed to create an object
    class SubClassOfABCTestClass(ABCTestClass):
        pass
    SubClassOfABCTestClass()


# Generated at 2022-06-21 08:25:10.586227
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs(dict(a=1, b=dict(c=3, d=4))) == dict(a=1, b=dict(c=3, d=4))

# Generated at 2022-06-21 08:25:22.941842
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that we can create a CLIArgs object from a dictionary of options
    # test for sequence type
    options = {'debug': True, 'host_key_checking': True}
    argument_obj = CLIArgs(options)
    assert argument_obj['debug'] == True
    assert argument_obj['host_key_checking'] == True
    # Test that we can create a CLIArgs object with a sequence in its options
    options = {'debug': True, 'host_key_checking': True, 'ssh_args': ['-C', '-q']}
    argument_obj = CLIArgs(options)
    assert argument_obj['debug'] == True
    assert argument_obj['host_key_checking'] == True
    assert argument_obj['ssh_args'] == ('-C', '-q')
    # Test that we can create a CLIArgs object

# Generated at 2022-06-21 08:25:29.151886
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SubMetaClass(_ABCSingleton):
        pass

    class MyClass(object):
        __metaclass__ = SubMetaClass

    assert issubclass(MyClass, Singleton)

# Generated at 2022-06-21 08:25:32.755043
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = ImmutableDict({'foo': 'bar', 'baz': 'quz'})
    args = GlobalCLIArgs(options)

    assert args['foo'] == 'bar'
    assert args['baz'] == 'quz'

# Generated at 2022-06-21 08:25:35.008096
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyClass(object):
        __metaclass__ = _ABCSingleton
    c1 = MyClass()
    c2 = MyClass()
    assert c1 is c2

# Generated at 2022-06-21 08:25:46.297751
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    import random
    import unittest
    
    class TestCLIArgs(unittest.TestCase):

        def test_simple_dict(self):
            # Test case with a simple dict
            simple_dict = dict([('key{0}'.format(i), 'value{0}'.format(i)) for i in range(10)])
            args = CLIArgs(simple_dict)
            self.assertEqual(simple_dict, dict(args.items()))

        def test_dict_with_list(self):
            # Test case with a dict with list value
            list_dict = dict(key_list=[i for i in range(5)])
            args = CLIArgs(list_dict)
            self.assertEqual(dict, type(args))

# Generated at 2022-06-21 08:25:48.350476
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    a = TestClass()
    b = TestClass()
    assert a is b


# Generated at 2022-06-21 08:25:50.154083
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    dummy = type('dummy', (_ABCSingleton,), {})
    dummy()
    dummy()

# Generated at 2022-06-21 08:25:58.649129
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_sequence
    from ansible.parsing.dataloader import DataLoader

    options = {'ansible_connection': 'local',
               'connection_plugins': ['local']}
    new_cli_args = CLIArgs(options)

    # The value of 'ansible_connection' should be a sequence
    assert is_sequence(new_cli_args['ansible_connection'])
    # The value of 'connection_plugins' should be the same as the value of
    # 'ansible_connection'
    assert new_cli_args['ansible_connection'] == new_cli_args['connection_plugins']

    new_cli_args['ansible_connection'] = 'local'
    new_cli_args['connection_plugins'] = ['local']

    # Make sure we

# Generated at 2022-06-21 08:26:03.976229
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cl = CLIArgs({'foo': 'bar', 'baz': [1, 2, 3], 'abc': {'qwerty': 0}})
    assert isinstance(cl, ImmutableDict)
    assert cl == {'foo': 'bar', 'baz': (1, 2, 3), 'abc': ImmutableDict({'qwerty': 0})}

# Generated at 2022-06-21 08:26:07.957521
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Make sure we can instantiate _ABCSingleton
    """
    # pylint: disable=unused-variable

    class TestSingleton(_ABCSingleton):
        """
        Just a class to make sure we can instantiate _ABCSingleton
        """
        pass

    # pylint: enable=unused-variable

# Generated at 2022-06-21 08:26:09.061651
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs.create(1)

# Generated at 2022-06-21 08:26:14.622739
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():  # pylint: disable=unused-argument
    """
    Call the __new__ method from class _ABCSingleton and assert the type
    of the object.
    """
    assert isinstance(_ABCSingleton(), _ABCSingleton)

# Generated at 2022-06-21 08:26:15.186471
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs()

# Generated at 2022-06-21 08:26:21.631303
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}, 'f': [1, 2, 3]}
    a = CLIArgs(args)
    assert a == args, 'CLIArgs.__init__() failed'
    assert a is not args, 'CLIArgs.__init__() failed'
    assert a['a'] == 1, 'CLIArgs.__init__() failed'
    assert a['b'] == 2, 'CLIArgs.__init__() failed'
    assert a['c'] == {'d': 3, 'e': 4}, 'CLIArgs.__init__() failed'
    assert a['f'] == (1, 2, 3), 'CLIArgs.__init__() failed'

# Generated at 2022-06-21 08:26:26.228493
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class D1(object):
        __metaclass__ = _ABCSingleton

    class D2(D1):
        pass

    assert id(D1()) == id(D1())
    assert id(D2()) == id(D2())
    assert id(D1()) != id(D2())

# Generated at 2022-06-21 08:26:32.515515
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test the CLIArgs class constructor
    """
    cliargs = CLIArgs({'VARIABLE': 'VALUE'})
    assert isinstance(cliargs, ImmutableDict)
    assert cliargs['VARIABLE'] == 'VALUE'
    try:
        cliargs['VARIABLE'] = 'CHANGED'
        assert False, "Should have raised an immutable error"
    except TypeError:
        pass


# Generated at 2022-06-21 08:26:39.571982
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        def __init__(self, value):
            self.value = value

        def __eq__(self, other):
            return self.value == other.value

    try:
        class_a = _ABCSingleton('class_a', (TestClass,), {})
        class_b = _ABCSingleton('class_b', (TestClass,), {})

        a = class_a(value=1)
        b = class_b(value=1)

        assert a == b

        a = class_a(value=2)
        b = class_b(value=2)

        assert a == b

    except TypeError as e:
        assert False, 'TypeError when initializing {}'.format(e)

# Generated at 2022-06-21 08:26:45.432781
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABCSingleton(_ABCSingleton):
        pass

    # _ABCSingleton is not a regular Singleton so we can't test by instantiating another
    # instance and seeing if it is the same as the initial one.
    assert issubclass(TestABCSingleton, Singleton)


_MODULE_ARGS_ATTR = '__ansible_arguments__'



# Generated at 2022-06-21 08:26:50.986358
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test constructor of class CLIArgs

    :return: None
    """
    test_dict = {'test1': 'value1', 'test2': 'value2'}
    cli_args = CLIArgs(test_dict)
    assert cli_args == ImmutableDict(test_dict)


__all__ = ['GlobalCLIArgs']

# Generated at 2022-06-21 08:27:00.448925
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs.from_options(get_args_options_mutable())

    assert(args.inventory == 'inventory')
    assert(args.syntax == 'syntax')
    assert(args.tree == 'tree')
    assert(args.diff == 'diff')
    assert(args.verbosity == 'verbosity')
    assert(args.check == 'check')
    assert('connection' in args.connection_options)
    assert(args.start_at_task == 'start_at_task')
    assert(args.step == 'step')
    assert(args.become == 'become')
    assert(args.become_method == 'become_method')
    assert(args.become_user == 'become_user')

# Generated at 2022-06-21 08:27:02.225352
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    assert A() is A()



# Generated at 2022-06-21 08:27:08.477252
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Test class _ABCSingleton.

    We need to make sure the constructor and __new__ functions of class
    _ABCSingleton call the constructor of the parent classes in the correct
    order, else ABCMeta's functionality is broken.
    """
    class TestClass(object, metaclass=_ABCSingleton):
        pass

    a = TestClass()
    b = TestClass()
    assert a is b, "Objects a and b should be identical in a Singleton"

# Generated at 2022-06-21 08:27:15.335889
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingletonParentType(metaclass=_ABCSingleton):
        pass

    class SingletonChildType(SingletonParentType):
        pass

    child_instance = SingletonChildType()

    assert SingletonChildType() is child_instance
    assert SingletonChildType() is SingletonParentType()
    assert SingletonChildType() is not SingletonChildType.__new__(SingletonParentType)

# Generated at 2022-06-21 08:27:24.902181
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-21 08:27:29.438102
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # pylint: disable=line-too-long
    from ansible.utils.module_docs import is_docstring_multiline
    assert is_docstring_multiline(CLIArgs)
    # pylint: enable=line-too-long


# Generated at 2022-06-21 08:27:33.945733
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Test class construction of class _ABCSingleton
    """

    class Test(_ABCSingleton):
        def __init__(self):
            pass

    class BadMeta(type):
        pass

    class GoodMeta(ABCMeta):
        pass

    # If it's not a metaclass to begin with, it's still not a metaclass
    assert issubclass(type(Test), ABCMeta) is False

    # If only one metaclass is a metaclass, the type is still a metaclass
    class GoodBad(GoodMeta, BadMeta):
        pass

    assert issubclass(type(GoodBad), ABCMeta) is False

    # If both metaclasses are not metaclasses, then the type is not a metaclass
    class BadBad(BadMeta, BadMeta):
        pass


# Generated at 2022-06-21 08:27:38.918711
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE, BOOLEANS_FALSE

    class DummySingleton(object):
        __metaclass__ = _ABCSingleton

    class DummyTrueSingleton(_ABCSingleton):
        pass

    class DummyFalseSingleton(object):
        __metaclass__ = _ABCSingleton

    true_singleton = DummyTrueSingleton()
    false_singleton = DummyFalseSingleton()

    class DummySingletonChild(DummySingleton):
        pass

    class DummyTrueSingletonChild(_ABCSingleton):
        pass

    class DummyFalseSingletonChild(object):
        pass

    true_singleton_child = DummyTrueSingletonChild

# Generated at 2022-06-21 08:27:45.125058
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # if it's a singleton class it will have only one instance
    class Single(_ABCSingleton):
        pass

    assert Single() is Single()
    # classes without metaclasses have no metaclass
    try:
        Single.__metaclass__
    except AttributeError:
        pass
    else:
        assert False, "__metaclass__ incorrectly set on Single"

    # classes that inherit from Singleton are themselves Singletons
    class SingleSub(Single):
        pass

    assert SingleSub() is SingleSub()
    assert SingleSub.__metaclass__ is _ABCSingleton

    # classes that inherit from Singleton and a metaclass are Singletons
    # with the last metaclass on the list
    class SingleSubSingleMetaclass(_ABCSingleton):
        pass


# Generated at 2022-06-21 08:27:48.695574
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    class Bar(object):
        __metaclass__ = _ABCSingleton

    foo = Foo()
    assert foo is Foo()
    assert foo is not Bar()

# Generated at 2022-06-21 08:27:51.875396
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Test cases

    Ensure we can create a new class using _ABCSingleton as a metaclass.
    """
    class Foo(_ABCSingleton):
        pass

    class Bar(_ABCSingleton):
        pass

# Generated at 2022-06-21 08:27:55.087468
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    assert isinstance(TestClass(), TestClass)
    assert isinstance(TestClass(), Singleton)



# Generated at 2022-06-21 08:27:59.467691
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Check that the constructor is a Singleton
    opt1 = GlobalCLIArgs({})
    opt2 = GlobalCLIArgs({})

    assert opt1 is opt2

# Generated at 2022-06-21 08:28:09.636003
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object): pass
    class B(A): pass

    class MetaA(A, _ABCSingleton): pass
    class MetaAB(A, B, _ABCSingleton): pass

    class MetaBA(_ABCSingleton, B, A): pass
    class MetaBAB(_ABCSingleton, B, A, B): pass

    class MetaB(_ABCSingleton, B): pass
    class MetaBB(_ABCSingleton, B, B): pass

    # not the same
    assert A is MetaA.__base__
    assert A is not MetaA.__mro__[1]
    assert B is MetaAB.__base__
    assert B is MetaAB.__mro__[1]

    # same
    assert B is MetaBA.__base__
    assert B is MetaBA.__mro__[1]
    assert B

# Generated at 2022-06-21 08:28:11.736287
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _TestClass(_ABCSingleton):
        pass
    assert issubclass(_TestClass, Singleton)
    assert issubclass(_TestClass, ABCMeta)

# Generated at 2022-06-21 08:28:20.943396
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class options():
        def __init__(self, data):
            for key, value in data.items():
                setattr(self, key, value)

    # We can't pass in lists or dicts directly, which makes sense since CLIArgs is immutable
    test_vars = {'one': 'one', 'two': 'two'}
    options_object = options(test_vars)
    cli_args = CLIArgs.from_options(options_object)

    assert cli_args == CLIArgs({'one': 'one', 'two': 'two'})

# Generated at 2022-06-21 08:28:22.528640
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import json
    container_list = [{'test': 5}]
    cli_args = CLIArgs(container_list)
    assert json.loads(json.dumps(cli_args)) == [{'test': 5}]



# Generated at 2022-06-21 08:28:28.584296
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.constants import DEFAULT_CLI_OPTIONS
    from ansible.module_utils.common.collections import ImmutableDict
    cli_args = CLIArgs.from_options(DEFAULT_CLI_OPTIONS)
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args.get('connection') == 'smart'


# Generated at 2022-06-21 08:28:30.990767
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Tmp(object):
        __metaclass__ = _ABCSingleton

    t1 = Tmp()
    t2 = Tmp()

    assert t1 is t2

# Generated at 2022-06-21 08:28:35.606330
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(_ABCSingleton):
        pass

    class B(A):
        pass

    # TODO: This test only cover the inheritance of type and object.
    # Need to add more tests for Singleton part.
    abc = A()
    assert isinstance(abc, object)
    assert isinstance(abc, type)
    assert abc.abc is abc

    b = B()
    assert isinstance(b, object)
    assert isinstance(b, type)
    assert b.abc is b

# Generated at 2022-06-21 08:28:45.736321
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Test our class constructor works as expected"""
    assert CLIArgs(dict()) == ImmutableDict()
    assert CLIArgs(dict(a=1, b=2)) == ImmutableDict(a=1, b=2)
    assert CLIArgs(dict(a=dict(b=1, c=2))) == ImmutableDict(a=ImmutableDict(b=1, c=2))
    assert CLIArgs(dict(a=[1, 2])) == ImmutableDict(a=(1, 2))
    assert CLIArgs(dict(a=set([1, 2]))) == ImmutableDict(a=frozenset((1, 2)))
    assert CLIArgs(dict(a=(1, 2))) == ImmutableDict(a=(1, 2))

# Generated at 2022-06-21 08:28:48.996435
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    class B(A):
        pass
    assert not issubclass(A, B)
    assert issubclass(B, A)

# Generated at 2022-06-21 08:28:54.138480
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class NewABCSingleton(metaclass=_ABCSingleton):
        pass

    assert issubclass(NewABCSingleton, Singleton)
    assert issubclass(NewABCSingleton, ABCMeta)

# Generated at 2022-06-21 08:28:56.936801
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    @add_metaclass(_ABCSingleton)
    class Foo(object):
        pass

    assert isinstance(Foo(), Foo)

# Generated at 2022-06-21 08:29:06.959129
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        def __init__(self):
            self.food = 'pie'

    foobar = A()
    foobar.foo = 'bar'

    class B(object):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            self.food = 'pie'

    class C(object):
        __metaclass__ = _ABCSingleton

        def __init__(self, x):
            self.x = x
            self.food = 'pie'

    class D(object):
        __metaclass__ = _ABCSingleton

    class E(object):
        __metaclass__ = _ABCSingleton

        def __init__(self, **kwargs):
            self.food = 'pie'


# Generated at 2022-06-21 08:29:13.451320
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs._instance = None

    g_args = GlobalCLIArgs({'a': 'b'})
    assert g_args['a'] == 'b'

    # Singleton
    assert GlobalCLIArgs({'a': 1}) is g_args

    # Supports ImmutableDict access
    assert g_args['a'] == g_args.get('a')

# Generated at 2022-06-21 08:29:23.041656
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton):
        def __init__(self):
            self.foo = "foo"

    foo1 = Foo()
    foo2 = Foo()

    assert foo1 == foo2
    assert foo1.foo == foo2.foo

    assert foo1 is foo2  # Singleton

    # Make sure that we can declare the same type of object more than once
    class Bar(_ABCSingleton):
        pass

    class Bar(_ABCSingleton):
        pass

    # Make sure we can declare objects of the same type more than once
    baz1 = Bar()
    baz2 = Bar()
    assert baz1 == baz2



# Generated at 2022-06-21 08:29:30.804937
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import mock
    from ansible.utils.display import Display

    display = mock.Mock(spec=Display)
    options = mock.Mock()
    options.verbosity = 0
    options.debug = True
    options.connection = 'local'
    options.module_path = '/usr/share/ansible'
    options.forks = 5
    options.private_key_file = None
    options.remote_user = 'root'
    options.ask_pass = False
    options.sudo = False
    options.sudo_user = None
    options.ask_sudo_pass = False
    options.timeout = 10
    options.module_language = None
    options.output_path = '/dev/null'
    options.become = False
    options.become_method = None
    options.become_user = None

# Generated at 2022-06-21 08:29:32.741666
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object):
        __metaclass__ = _ABCSingleton
        def __init__(self):
            pass

    Test()
    Test()

# Generated at 2022-06-21 08:29:37.015446
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        def __init__(self, x):
            self.x = x

    a1 = A()
    a2 = A()
    assert a1 is a2

    b1 = B(1)
    b2 = B(2)
    assert b1 is b2
    assert b1.x == 2



# Generated at 2022-06-21 08:29:48.569735
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Create and fill GlobalCLIArgs
    from ansible.utils.display import Display
    from ansible.utils.color import stringc
    Display.verbosity = 0
    Display.color = 'green'
    Display.columns = 80
    Display.output_encoding = 'UTF-8'
    Display.warnings = True

    # Create and fill GlobalCLIArgs
    from ansible.cli import CLI
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import plugin_loader

    # Create dataloader and inventory
    loader = DataLoader

# Generated at 2022-06-21 08:29:52.426107
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    '''
    Ensure that GlobalCLIArgs is immutable.
    '''
    GlobalCLIArgs.instance().update({"test": "value"})
    assert GlobalCLIArgs.instance() == {"test": "value"}

# Generated at 2022-06-21 08:30:05.602321
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.release import __version__
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import is_immutable
    from ansible.parsing.vault import VaultLib

# Generated at 2022-06-21 08:30:06.944016
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert True
    # TODO: Add Unit Test

# Generated at 2022-06-21 08:30:14.326755
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test to detect any regressions in constructor of class GlobalCLIArgs.

    The constructor of GlobalCLIArgs is setting a new instance of self
    on GlobalCLIArgs._instance. If a regression is introduced that causes
    the constructor to be called twice during a single execution, the test
    will detect that a second instance is set.
    """
    gca_set = set(type(GlobalCLIArgs()).__dict__.values())
    assert len(gca_set) == 1
    assert isinstance(next(iter(gca_set)), GlobalCLIArgs)

# Generated at 2022-06-21 08:30:19.060602
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABCSingletonMetaclass(CLIArgs, metaclass=_ABCSingleton):
        pass

    testABCSingletonMetaclass = TestABCSingletonMetaclass()
    assert isinstance(testABCSingletonMetaclass, TestABCSingletonMetaclass)



# Generated at 2022-06-21 08:30:21.708353
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class B(object, metaclass=_ABCSingleton):
        pass

    class C(B):
        pass

    b = B()
    c = C()
    assert b is c

# Generated at 2022-06-21 08:30:24.985641
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    a = _ABCSingleton()
    b = _ABCSingleton()
    assert a is b


# Generated at 2022-06-21 08:30:35.370692
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    d = GlobalCLIArgs(dict(long_opts=["test1", "test2"]))
    assert d == {"long_opts": ("test1", "test2")}
    d = GlobalCLIArgs(dict(long_opts=set(["test1", "test2"]), short_opts="t"))
    assert d == {"long_opts": frozenset(["test1", "test2"]), "short_opts": "t"}
    d = GlobalCLIArgs(dict(long_opts=set(["test1", "test2"]), short_opts="t", log_path="x"))
    assert d == {"long_opts": frozenset(["test1", "test2"]), "short_opts": "t", "log_path": "x"}

# Generated at 2022-06-21 08:30:36.852314
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class t1(metaclass=_ABCSingleton):
        pass

    t2 = type('t2', (t1,), {})

    assert t1() is t1()
    assert t1() is t2()
    assert t1() is not t1()
    assert t1() is not t2()

# Generated at 2022-06-21 08:30:43.528979
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # unit test for class GlobalCLIArgs into module ansible.cli.arguments
    import ansible.module_utils.six as six
    import ansible.module_utils.common.collections as collections
    import ansible.module_utils.common.text.converters as text_converters
    # test for GlobalCLIArgs to be a singleton
    GlobalCLIArgs_1 = GlobalCLIArgs({'foo': 'bar'})
    GlobalCLIArgs_2 = GlobalCLIArgs({'foo': 'bar'})
    assert GlobalCLIArgs_1 is GlobalCLIArgs_2
    # test for GlobalCLIArgs to be a immutable data type
    GlobalCLIArgs_3 = GlobalCLIArgs({'foo': {'bar': 'baz'}})

# Generated at 2022-06-21 08:30:45.088115
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

# Generated at 2022-06-21 08:30:56.884199
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.config.manager import ConfigManager
    manager = ConfigManager()
    manager._parse(args=['foo', '--extra-vars={"bar": "baz"}'],
                   usage="%(prog)s [options]",
                   description="Description")
    cli_args = GlobalCLIArgs(vars(manager._parser._an_opts))
    assert cli_args['extra_vars'] == {'bar': 'baz'}

# Generated at 2022-06-21 08:31:01.259313
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        pass
    class Test2(_ABCSingleton):
        pass
    t1 = Test()
    t2 = Test()
    t3 = Test2()
    assert t1 is t2
    assert t1 is not t3

# Generated at 2022-06-21 08:31:08.499929
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingletonMeta(object):
        __metaclass__ = _ABCSingleton

    class TestSingletonMeta1(TestSingletonMeta):
        pass

    class TestSingletonMeta2(TestSingletonMeta):
        pass

    assert TestSingletonMeta1() is TestSingletonMeta1()
    assert TestSingletonMeta2() is TestSingletonMeta2()
    assert TestSingletonMeta1() is not TestSingletonMeta2()

# Generated at 2022-06-21 08:31:10.873653
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MySingleton(_ABCSingleton):
        pass
    class MySingleton2(_ABCSingleton):
        pass

    assert MySingleton is MySingleton
    assert MySingleton2 is MySingleton2

    assert not issubclass(MySingleton, MySingleton2)
    assert issubclass(MySingleton2, MySingleton)

# Generated at 2022-06-21 08:31:18.227125
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.config.manager import ConfigManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.release import __version__ as ansible_version
    from ansible.utils.display import Display

    # create a CLI
    cli = CLI(args=sys.argv[1:])
    cli.parser.version = ansible_version

    # parse the CLI into an options object
    options, display, parser = cli.parse()

    # create the CLIArgs object
    cliargs = CLIArgs.from_options(options)

    # make sure it's a singleton
    cliargs2 = CLIArgs.from_options(options)
    assert id(cliargs) == id(cliargs2)

    # create a player
   

# Generated at 2022-06-21 08:31:21.663458
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Test the constructor of the class _ABCSingleton
    class MyClass(object):
        __metaclass__ = _ABCSingleton
    # Pass
    pass


# Generated at 2022-06-21 08:31:24.171510
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    assert A() is A()

# Generated at 2022-06-21 08:31:26.726679
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(with_metaclass(_ABCSingleton, object)): pass
    f1 = Foo()
    f2 = Foo()
    assert f1 is f2

# Generated at 2022-06-21 08:31:32.358158
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs.from_options(type('OptionsFake', (object,), {'test': True}))
    assert isinstance(cli_args, CLIArgs)
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args.get('test') is True

# Unit test to ensure GlobalCLIArgs is a singleton

# Generated at 2022-06-21 08:31:41.700009
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.vars import combine_vars

    testargs = {'become_user': 'root', 'become_ask_pass': 0, 'extra_vars': {'foo': 'bar'}, 'connection': 'local', 'module_path': '.', 'playbook_path': '/home/test/test_playbook.yml', 'subset': '!test'}
    combined_vars = combine_vars(loader=None, variables=testargs['extra_vars'])
    testargs['extra_vars'] = combined_vars

    # test initialization of GlobalCLIArgs object
    init_global_cli_args = GlobalCLIArgs(mapping=testargs)
    # test that the GlobalCLIArgs object is created as expected

# Generated at 2022-06-21 08:31:58.809973
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    options = Options(test=1)

    args = GlobalCLIArgs.from_options(options)
    assert args == ImmutableDict({'test': 1})

# Generated at 2022-06-21 08:32:05.155328
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import datetime
    import os
    import sys

    from ansible.module_utils.common.dates import json_serial

    test_date = datetime.datetime(2018, 3, 31, 14, 30, 30, 0)

    class Complicated(object):
        def __init__(self, is_complicated=None):
            self.is_complicated = is_complicated

        def __repr__(self):
            return "Complicated(%r)" % self.is_complicated

        def __eq__(self, other):
            return self.is_complicated == other.is_complicated

        def __hash__(self):
            return hash(self.is_complicated)
