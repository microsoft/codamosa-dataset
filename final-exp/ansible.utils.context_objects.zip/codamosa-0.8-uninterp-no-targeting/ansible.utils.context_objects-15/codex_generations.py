

# Generated at 2022-06-21 08:22:13.721127
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    input_dict = {'foo': 'bar'}
    output_dict = CLIArgs(input_dict)
    assert input_dict == output_dict
    assert isinstance(output_dict, ImmutableDict)



# Generated at 2022-06-21 08:22:24.469435
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # pylint: disable=unused-variable
    class Hoge(object):
        pass
    x = CLIArgs({"hoge":"fuga"})
    x = CLIArgs({"hoge":Hoge()})
    x = CLIArgs({"hoge":{"foo":"bar"}})
    x = CLIArgs({"hoge":["foo", "bar"]})
    x = CLIArgs({"hoge":("foo", "bar")})
    x = CLIArgs({"hoge":("foo", Hoge())})
    x = CLIArgs({"hoge":[{"foo":"bar"}]})
    x = CLIArgs({"hoge":{"foo":("bar",)}})
    x = CLIArgs({"hoge":{"foo":"bar"}, "fuge":{"foo":("bar",)}})

# Generated at 2022-06-21 08:22:27.881667
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ChildA(_ABCSingleton):
        pass

    class ChildB(_ABCSingleton):
        pass

    # The purpose of this test is just to make sure that _ABCSingleton can be instantiated.
    # If there's ever a problem with it, the Python interpreter should throw an exception
    # and this should stop the unit test run.
    assert isinstance(ChildA(), ChildA)
    assert isinstance(ChildA(), ChildB)
    assert ChildA is ChildB
    assert ChildA() is ChildB()

# Generated at 2022-06-21 08:22:38.543080
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.display import Display
    from ansible.utils.vars import merge_hash

    display_options = {
        'default_verbosity': 2,
        'verbosity': 2,
        'verbosity_level': 0,
        'deprecation_warnings': True,
        'show_custom_stats': False,
    }
    display_args = {
        'verbosity': 'vv',
        'deprecation_warnings': [True],
        'show_custom_stats': [False],
        'tree': ['/tmp/ansible-tree'],
    }
    display = Display()
    display.verbosity = 2
    display.deprecation_warnings = True
    display.show_custom_stats = False
    display.add_parser_options = lambda parser: parser.add_argument

# Generated at 2022-06-21 08:22:42.668587
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', action='store_true')
    args = parser.parse_args([])
    GlobalCLIArgs.from_options(args)



# Generated at 2022-06-21 08:22:45.796406
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class NewABCSingleton(metaclass=_ABCSingleton):
        pass

    n = NewABCSingleton()
    assert n is NewABCSingleton()



# Generated at 2022-06-21 08:22:48.608472
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-21 08:22:59.143257
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    old_sys_argv = sys.argv
    try:
        sys.argv = ['/usr/bin/ansible-playbook', '-i', 'new_inventory', '-u', 'new_user', 'playbook.yml']
        from ansible.cli.playbook import PlaybookCLI
        p = PlaybookCLI(args=sys.argv[1:])
        p.parse()
        options = p.options
        assert options.inventory == 'new_inventory'
        assert options.user == 'new_user'
        cli_args = CLIArgs.from_options(options)
        assert cli_args.inventory == 'new_inventory'
        assert cli_args.user == 'new_user'
    finally:
        sys.argv = old_sys_argv

# Generated at 2022-06-21 08:23:02.272200
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    try:
        a = A()
    except TypeError:
        assert False
    else:
        assert True

# Generated at 2022-06-21 08:23:11.543609
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'test': {'test2': ['test3', 'test4'], 'test1': 'test2'}, 'test5': 'test6'}
    test_instance = CLIArgs(test_dict)

    assert isinstance(test_instance, ImmutableDict)
    assert not isinstance(test_instance, Mapping)
    assert test_instance != test_dict
    assert test_instance == ImmutableDict(test_dict)
    assert test_instance['test'] != test_dict['test']
    assert test_instance['test'] == ImmutableDict(test_dict['test'])
    assert test_instance['test']['test2'] != test_dict['test']['test2']

# Generated at 2022-06-21 08:23:20.031510
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    class C(A):
        pass

    assert isinstance(A(), A)
    assert isinstance(B(), A)
    assert not isinstance(A(), B)
    assert not isinstance(B(), C)

# Generated at 2022-06-21 08:23:27.564834
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Ensure that the CLIArgs class works as intended
    """
    args = CLIArgs({})
    assert args == ImmutableDict({})

    args = CLIArgs({'foo': ['bar', 'baz']})
    assert args == ImmutableDict({'foo': ('bar', 'baz')})

    args = CLIArgs({'foo': [{'bar': 'baz'}]})
    assert args == ImmutableDict({'foo': (ImmutableDict({'bar': 'baz'}),)})

# Generated at 2022-06-21 08:23:31.870012
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton
        def __init__(self):
            self.a = 1
    assert TestClass().a == 1



# Generated at 2022-06-21 08:23:34.681003
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    f = Foo()
    assert isinstance(f, Foo)



# Generated at 2022-06-21 08:23:42.457055
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.basic import AnsibleModule
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument(
        '-f', '--foo', action='store', default='bar',
        help='Foo must be bar.',
    )
    args = parser.parse_args([])
    module = AnsibleModule(argument_spec=dict())
    module.exit_json(foo=args.foo)
    GlobalCLIArgs.from_options(args)

# Generated at 2022-06-21 08:23:46.101447
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _TestClass(_ABCSingleton):
        pass

    test_obj_1 = _TestClass()
    test_obj_2 = _TestClass()

    assert test_obj_1 is test_obj_2, "_ABCSingleton isn't Singleton"

# Generated at 2022-06-21 08:23:49.268784
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    first_instance = A()
    second_instance = A()
    assert first_instance is second_instance

# Generated at 2022-06-21 08:23:51.314629
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class SingletonObj(_ABCSingleton):
        pass

    SingletonObj()
    SingletonObj()

# Generated at 2022-06-21 08:23:58.925652
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.args import GlobalCLIArgs
    from ansible.module_utils.common._collections_compat import Mapping

    # Validate that only one instance of class GlobalCLIArgs exists.
    a = GlobalCLIArgs(dict(foo=1))
    b = GlobalCLIArgs(dict(foo=1))
    assert a == b
    assert a is b

    # Validate that all the contents of the dictionary are immutable.
    assert isinstance(a, Mapping)
    assert a == dict(foo=1)
    with pytest.raises(TypeError):
        a['foo'] = 2
    with pytest.raises(TypeError):
        a.update(dict(foo=2))

    # Validate that all the contents of the dictionary are immutable.
    c = GlobalCLI

# Generated at 2022-06-21 08:24:10.924941
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Test(object):
        pass

    test = Test()
    test.test = 'test'

    args = {u'test': test,
            u'alpha': 10,
            u'beta': u'test',
            u'gamma': {u'x': 1, u'y': 2, u'z': 3},
            u'delta': [u'a', u'b', u'c'],
            u'epsilon': (4, u'd', u'e', u'f'),
            u'zeta': frozenset((u'g', u'h', u'i')),
            }

    cli_args = GlobalCLIArgs(args)
    assert cli_args['test'].test == 'test'
    assert cli_args['alpha'] == 10

# Generated at 2022-06-21 08:24:16.868515
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.core import ANSIBLE_ARGS
    c = GlobalCLIArgs(ANSIBLE_ARGS)
    assert c

# Generated at 2022-06-21 08:24:23.838257
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = InventoryManager(loader=loader, sources=None)
    variable_manager.extra_vars = {'foo': 'bar'}

    play_context = PlayContext()
    play_context.variables = variable_manager
    play_context.connection = 'smart'

    playbook = PlaybookExecutor(
        playbooks=[],
        inventory=variable_manager,
        variable_manager=variable_manager,
        loader=loader,
        options=None,
        passwords={}
    )
    playbook._tqm._std

# Generated at 2022-06-21 08:24:35.644598
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'b': True})
    # The values in args will be ImmutableDict, ImmutableDict, and ImmutableDict
    assert isinstance(args, ImmutableDict)
    assert isinstance(args['b'], bool)
    args = CLIArgs({'a': {'b': {'c': 'test'}}})
    assert isinstance(args, ImmutableDict)
    assert isinstance(args['a'], ImmutableDict)
    assert isinstance(args['a']['b'], ImmutableDict)
    assert isinstance(args['a']['b']['c'], text_type)
    args = CLIArgs({'a': ['b', {'c': 'test'}]})
    assert isinstance(args, ImmutableDict)

# Generated at 2022-06-21 08:24:40.730431
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    d = CLIArgs({'a': 1, 'b': 2, 'c': {'d': 3, 'e': 4}})
    assert d['a'] == 1
    assert d['b'] == 2
    assert d['c']['d'] == 3
    assert d['c']['e'] == 4
    assert isinstance(d, dict)

# Generated at 2022-06-21 08:24:49.091307
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    output = CLIArgs({
        'foo': {
            'bar': 'baz',
            'qux': ['quux', 'quuz'],
            'corge': {
                'grault': 'garply',
                'waldo': 'fred',
            },
        },
        'another': {
            'frobble': 'grot',
        },
        'baz': ['boo', 'bar'],
    })

# Generated at 2022-06-21 08:24:51.965833
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton, object):
        _instances = {}

    f1 = Foo()
    f2 = Foo()
    assert f1 is f2

# Generated at 2022-06-21 08:25:01.990902
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import os
    import json
    import tempfile

    # Create a temp file and then make sure to get rid of it when we're done
    fp = tempfile.NamedTemporaryFile()
    fp.close()


# Generated at 2022-06-21 08:25:09.514935
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class fake_options():
        foo = 'bar'
        fum = {'fam': 'foobar'}
        item = 'baz'
        iterable = [1, 2, 3]

    mapping = vars(fake_options)
    cli_args = CLIArgs(mapping)

    assert cli_args.get('foo') == 'bar'
    assert cli_args.get('fum').get('fam') == 'foobar'

    assert repr(cli_args) == repr(mapping)
    assert repr(cli_args.get('fum')) == repr(mapping['fum'])

    # Ensure that it is immutable
    try:
        cli_args['foo'] = 'silly'
    except TypeError:
        assert True

# Generated at 2022-06-21 08:25:22.031172
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # test __init__()
    cli_args = CLIArgs({"a":1, "b":2})
    assert cli_args == {"a":1, "b":2}, "Test cli_args fail."
    try:
        cli_args["a"] = 3
        assert False, "TypeError should occur."
    except TypeError:
        pass

    # test from_options()
    opt = type('options', (object,), {"a": 1, "b": 2})
    cli_args = CLIArgs.from_options(opt)
    assert cli_args == {"a":1, "b":2}, "Test cli_args.from_options(opt) fail."

# Generated at 2022-06-21 08:25:25.280406
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo():
        __metaclass__ = _ABCSingleton
        def __init__(self):
            pass

    Foo()

# Generated at 2022-06-21 08:25:29.102872
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    pass

# Generated at 2022-06-21 08:25:38.796627
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("-s", "--samplestring", help="sample string argument")
    parser.add_argument("-i", "--sampleint", type=int, help="sample int argument")
    args = parser.parse_args()
    cli_args = GlobalCLIArgs.from_options(args)
    assert cli_args["samplestring"] is None
    assert cli_args["sampleint"] is None
    assert not cli_args.changed
    assert not cli_args.readonly
    assert isinstance(cli_args, GlobalCLIArgs)
    assert isinstance(cli_args, Mapping)
    assert isinstance(cli_args, Singleton)
    assert isinstance(cli_args, CLIArgs)

# Generated at 2022-06-21 08:25:39.690674
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs(vars(Options()))

# Generated at 2022-06-21 08:25:45.263765
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    class C(A):
        pass

    a = A()
    b = B()
    c = C()
    assert a is b
    assert a is c
    assert b is c

# Generated at 2022-06-21 08:25:53.747380
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    # Test that inheritance from a single ABCMeta-based class works
    class A(object):
        __metaclass__ = ABCMeta
    class B(A):
        pass

    assert issubclass(B, A)

    # Test that inheritance from a single Singleton-based class works
    class C(object):
        __metaclass__ = Singleton
    class D(C):
        pass

    assert not issubclass(D, A)

    # Test that inheritance from a single class-based on _ABCSingleton works
    class E(object):
        __metaclass__ = _ABCSingleton
    class F(E):
        pass

    assert issubclass(F, E)

    # Test that inheritance from multiple ABCMeta-based classes works
    class G(A):
        pass
    class H(G):
        pass



# Generated at 2022-06-21 08:25:55.475884
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import ansible.constants
    # Test that it is a singleton class
    assert GlobalCLIArgs() is GlobalCLIArgs()



# Generated at 2022-06-21 08:26:05.259904
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object, metaclass=_ABCSingleton):
        def __init__(self):
            self.value = 'a'
        def get_value(self):
            return self.value

    class B(A):
        def __init__(self):
            self.value = 'b'
        def get_value(self):
            return self.value

    assert A() is A()
    assert B() is B()
    assert A() != B()
    isinstance(A(), A)
    isinstance(B(), A)
    assert A().get_value() == 'a'
    assert B().get_value() == 'b'

# Generated at 2022-06-21 08:26:11.811437
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Test immutability of CLIArgs"""
    from ansible.module_utils.common.validation import boolean
    from ansible.module_utils.common.text.converters import to_text
    from ansible.utils.unsafe_proxy import UnsafeProxy

    argv = ['--extra-vars={}'.format(to_text(UnsafeProxy({'foo': 'bar'})))]
    args = CLIArgs.from_options(boolean(argv))

    # __setattr__ and __delattr__ are not defined on ImmutableDict so these should raise AttributeError
    # but we want to test that they raise AttributeError whatever it is called.
    try:
        args.foo = 'baz'
    except AttributeError:
        pass
    else:
        assert False, "args should be immutable"



# Generated at 2022-06-21 08:26:17.481971
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {"key1": "value1",
                 "key2": ["value2", "value2.2"],
                 "key3": {"key3.1": "value3.1", "key3.2": "value3.2", "key3.3": ["value3.3", "value3.3.2"]}}

    test_immutable_dict = CLIArgs(test_dict)

    assert test_immutable_dict == test_dict

# Generated at 2022-06-21 08:26:28.193422
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import collections
    import json
    import random

    options = collections.namedtuple('options', ['a', 'b', 'c'])

    # It is not possible to create a mutable mapping from the command line because ansible
    # treats command line arguments as "--foo=bar" or "--foo '{}'" which it then parses into
    # a native python types for the "bar" value.  So we need to let python change it back into
    # a json/yaml type first and then parse it into a mutable object ourselves.
    a = {'a1': 's', 'a2': [1, 2, 3], 'a3': {'a': {'b': {'c': 1}}}}

# Generated at 2022-06-21 08:26:36.984911
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'list': [1, 2], 'tuple': (3, 4)})
    assert isinstance(args['list'], tuple)
    assert isinstance(args['tuple'], tuple)
    assert len(args['list']) == 2
    assert len(args['tuple']) == 2
    assert args['list'][0] == 1
    assert args['list'][1] == 2
    assert args['tuple'][0] == 3
    assert args['tuple'][1] == 4

# Generated at 2022-06-21 08:26:43.494463
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class MyBaseException(Exception):
        pass

    class MyException(MyBaseException):
        pass

    try:
        GlobalCLIArgs.from_options(Mock)
    except MyBaseException as e:
        assert str(e) == "Mock object contains no args"
    except Exception as e:
        raise MyException("Unexpected exception: %s" % e)
    else:
        raise MyException("Didn't get expected exception")



# Generated at 2022-06-21 08:26:51.607125
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'a': 'b', 'c': 'd'})

    # Make sure each attribute is read-only
    try:
        args['a'] = 'e'
    except TypeError:
        pass
    else:
        raise AssertionError('CLI args should be read only.')

    # Make sure we keep immutable arguments immutable
    try:
        args['immutable'] = 5
    except TypeError:
        pass
    else:
        raise AssertionError('Immutable arguments should not be modified.')



# Generated at 2022-06-21 08:26:56.034910
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _A(object):
        __metaclass__ = _ABCSingleton

    class _B(object):
        __metaclass__ = _ABCSingleton

    # For _ABCSingleton to work, we should be able to instantiate one of each class
    _A()
    _B()

# Generated at 2022-06-21 08:27:03.769035
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingletonMeta(object):
        __metaclass__ = _ABCSingleton
        pass

    class Something(SingletonMeta):
        pass

    class Other(SingletonMeta):
        pass

    class SomethingElse(Something, Other):
        pass

    # test for unambiguous class construction
    global_something = Something()
    assert(isinstance(global_something, (Something, Other)))
    assert(isinstance(global_something, SomethingElse))

# Generated at 2022-06-21 08:27:10.467578
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Verify that _ABCSingleton metaclass works as expected"""

    # pylint: disable=invalid-name
    class A(object):
        """Class that has a metaclass of _ABCSingleton"""
        __metaclass__ = _ABCSingleton
    a = A()
    assert a
    a1 = A()
    assert a1
    assert a is a1

    class B(object):
        """Class that has a metaclass of _ABCSingleton and is an ABCMeta class"""
        __metaclass__ = _ABCSingleton
        __metaclass__ = ABCMeta
    b = B()
    assert b
    b1 = B()
    assert b1
    assert b is b1


# Generated at 2022-06-21 08:27:13.470937
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _TestClass(_ABCSingleton):
        pass

    # Make sure this works without raising an exception
    _TestClass()



# Generated at 2022-06-21 08:27:18.260273
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('-o', action="append", dest='options', default=['default_opt_value'])
    args = parser.parse_args(sys.argv[1:])
    GlobalCLIArgs.from_options(args)

# Generated at 2022-06-21 08:27:25.086980
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli import CLI
    CLI([], version="test")
    assert "version" in GlobalCLIArgs
    assert GlobalCLIArgs["version"] == "test"
    assert GlobalCLIArgs["help"] is False
    assert GlobalCLIArgs["roles_path"] == '~/.ansible/roles:/usr/share/ansible/roles'
    assert GlobalCLIArgs["extra_vars"] == {}
    assert GlobalCLIArgs["ssh_common_args"] == ''
    assert GlobalCLIArgs["sftp_extra_args"] == ''
    assert GlobalCLIArgs["scp_extra_args"] == ''
    assert GlobalCLIArgs["ssh_extra_args"] == ''
    assert GlobalCLIArgs["timeout"] == 10

# Generated at 2022-06-21 08:27:31.710897
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': ['1', '2', '3'], 'b': 'c', 'd': {'e': 'f', 'g': 'h', 'i': ['1', '2', '3']}, 'j': ['1', '2', '3'], 'k': {'l': ['1', '2', '3']}}
    test_args = CLIArgs(test_dict)
    assert test_args == test_dict

# Generated at 2022-06-21 08:27:40.198044
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():  # pragma: no cover
    class A(object, metaclass=_ABCSingleton):
        pass
    c1 = A()
    c2 = A()
    assert c1 == c2

# Generated at 2022-06-21 08:27:43.297550
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    my_dict = {'a': ['b', 'c', 'd']}
    result_dict = {'a': ('b', 'c', 'd')}
    assert CLIArgs(my_dict) == result_dict

# Generated at 2022-06-21 08:27:50.815394
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    a = dict(a1=1, a2=2)
    b = dict(b1=dict(b11=11, b12=12), b2='b2')
    c = dict(c1=dict(c11=dict(c111=111), c12=dict(c121=121, c122=122)), c2=22)
    d = dict(a=a, b=b, c=c)

    cli_args = CLIArgs(d)

    # Check if it's a subclass of ImmutableDict
    assert isinstance(cli_args, ImmutableDict) is True, \
        "cli_args isn't a subtype of ImmutableDict"

    # Make sure that cli_args is not mutable

# Generated at 2022-06-21 08:28:02.203958
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyClass(object):
        __metaclass__ = _ABCSingleton

    m1 = MyClass()
    m2 = MyClass()
    assert id(m1) == id(m2)
    assert m1 is m2

    try:
        class MyClass(object):
            __metaclass__ = _ABCSingleton

        m3 = MyClass()
        assert False, "Should never get here"
    except TypeError as e:
        assert "with a metaclass that does not subclass type" in str(e)


# Generated at 2022-06-21 08:28:08.612161
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """ Verify one instance of GlobalCLIArgs exists """
    from ansible.utils.display import Display

    display = Display()
    display.verbosity = 4
    args1 = GlobalCLIArgs({'display': display})
    display.verbosity = 5
    args2 = GlobalCLIArgs({'display': display})

    assert id(args1) == id(args2)
    assert args1['display'].verbosity == args2['display'].verbosity


# Generated at 2022-06-21 08:28:13.139337
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser(description='CLI Args Test')
    parser.add_argument('-a', '--aarg', action='store_true')
    parser.add_argument('-b', '--barg', action='store_true')
    args = parser.parse_args([])
    foo = GlobalCLIArgs.from_options(args)
    assert foo['aarg'] is False
    assert foo['barg'] is False

# Generated at 2022-06-21 08:28:21.709529
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.splitter import split_args

    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    connection = Connection()
    connection.init_options(options=split_args(module.params['_raw_params']))
    cli_args = CLIArgs.from_options(options=connection.options)
    assert cli_args.get('module_path', None)

# Generated at 2022-06-21 08:28:23.146843
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ABCSingletonTest(GlobalCLIArgs):
        pass

# Generated at 2022-06-21 08:28:25.761823
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton
    class Bar(Foo):
        pass
    assert Bar is Foo

# Generated at 2022-06-21 08:28:30.656960
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(A):
        def __new__(cls):
            raise ValueError()

    class C(A):
        def __new__(cls):
            return super(C, cls).__new__(cls)

    assert B() is B()
    assert C() is C()

# Generated at 2022-06-21 08:28:44.334231
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import ansible.utils.args

    test_dict = {"foo": "something"}
    assert isinstance(ansible.utils.args.CLIArgs(test_dict), ansible.utils.args.CLIArgs)

# Generated at 2022-06-21 08:28:48.676335
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Unit test for constructor of class GlobalCLIArgs
    """
    input_dict = {'foo': 'bar', 'baz': ['qux', 'quux']}
    args = GlobalCLIArgs(input_dict)
    assert ImmutableDict(input_dict) == args

# Generated at 2022-06-21 08:28:51.614372
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABCSingletonTest(six.with_metaclass(_ABCSingleton)):
        def __init__(self):
            pass

    _ABCSingletonTest()

# Generated at 2022-06-21 08:28:59.975119
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # pylint: disable=too-few-public-methods, unused-variable

    @add_metaclass(_ABCSingleton)
    class A(object):
        pass

    @add_metaclass(_ABCSingleton)
    class B(object):
        pass

    @add_metaclass(_ABCSingleton)
    class C(A):
        pass

    @add_metaclass(_ABCSingleton)
    class D(A, B):
        pass


if __name__ == '__main__':
    test__ABCSingleton()

# Generated at 2022-06-21 08:29:03.161546
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Opt:
        def __init__(self, name):
            self.name = name
    args = [Opt(n) for n in ('foo', 'bar')]
    GlobalCLIArgs.from_options(args)

# Generated at 2022-06-21 08:29:10.649983
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli import CLI
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultSecret
    cli = CLI(['-i', 'foo', '-k', 'bar', '-s', '-v', '-e', 'ansible_connection=local', '--vault-password-file', 'password.txt'])
    cli.parse()
    GlobalCLIArgs(cli.args)

    class args:
        connection = 'local'
    class options:
        connection = 'local'
    class vault_secret:
        password = 'password'

    vault_password_file = 'password.txt'
    vault_ids = []

# Generated at 2022-06-21 08:29:20.235278
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args_dict = {'_ansible_debug': True, '_ansible_diff': True, '_ansible_verbosity': 5, '_ansible_version': True}
    immutable_dict = CLIArgs(args_dict)

    # Assert _ansible_debug is immutable
    try:
        immutable_dict['_ansible_debug'] = False
    except TypeError:
        pass
    except Exception:
        raise Exception('Non-mutable object changed. Code needs to be fixed.')
    finally:
        assert immutable_dict['_ansible_debug'] == args_dict['_ansible_debug']


# Generated at 2022-06-21 08:29:29.363026
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import Binary, StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    import json


# Generated at 2022-06-21 08:29:37.353791
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import optparse
    from ansible.cli.command import _translate_to_ansible_command

    parser = optparse.OptionParser()
    parser.add_option('-c', '--connection', dest='connection',
                      help=('connection type (network_cli/ssh, etc)'),
                      default='smart')

    parser.add_option('-f', '--forks', dest='forks', help='Specify number of parallel processes to use')

    parser.add_option('-m', '--module-path', dest='module_path',
                      help='specify path(s) to module library (default=None)',
                      default=None)

    parser.add_option('-a', '--args', dest='module_args',
                      help=('module arguments'), default='')

    parser.add_

# Generated at 2022-06-21 08:29:39.949923
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton, object):
        pass
    assert Test() is Test()

# Generated at 2022-06-21 08:30:13.133693
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test the unique constructor of the class CLIArgs
    """
    dict_list = [{'foo': [1, 2, 3]}, {'bar': [5, 6, 7]}]
    dict_list_result = [{'foo': [1, 2, 3]}, {'bar': [5, 6, 7]}]
    dict_tuple = ({'foo': [1, 2, 3]}, {'bar': [5, 6, 7]})
    dict_tuple_result = ({'foo': (1, 2, 3)}, {'bar': (5, 6, 7)})
    dict_dict = {'foo': {'foo': 'bar', 'bar': 'foo'}, 'bar': {'bar': 'foo', 'foo': 'foo'}}

# Generated at 2022-06-21 08:30:19.310071
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Use name that is extremely unlikely to be used by anyone else
    # This name will prevent any one else from extending this class
    # because it doesn't start with Test
    class Test__ABCSingleton(_ABCSingleton):
        pass

    Test__ABCSingleton = Test__ABCSingleton('Test__ABCSingleton', (object,), {})
    test = Test__ABCSingleton()
    assert test is Test__ABCSingleton()

# Generated at 2022-06-21 08:30:20.430795
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs(dict())  # Should not raise exception

# Generated at 2022-06-21 08:30:31.014761
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils import context_objects as co
    def str_to_num(a):
        return int(a) + 1

# Generated at 2022-06-21 08:30:37.668539
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'arg1': 'value', 'arg2': {'nestedarg1': 'nestedvalue', 'nestedarg2': [1, 2, 'a']}}
    cli_args = CLIArgs(mapping)

    assert cli_args == mapping
    assert cli_args['arg1'] == 'value'
    assert cli_args['arg2']['nestedarg1'] == 'nestedvalue'
    assert cli_args['arg2']['nestedarg2'][2] == 'a'



# Generated at 2022-06-21 08:30:43.932284
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # pylint: disable=protected-access
    def check_empty(args, keys):
        for key in keys:
            assert key not in args
    check_empty(GlobalCLIArgs(), ('fake1', 'fake2'))
    args = GlobalCLIArgs()
    args.update({'fake1': 1, 'fake2': 2})
    check_empty(GlobalCLIArgs(), ('fake1', 'fake2'))
    args._GlobalCLIArgs__dict__.clear()
    check_empty(args, ('fake1', 'fake2'))
    args.update({'fake1': 1, 'fake2': 2})
    check_empty(args, ('fake1', 'fake2'))
    delargs = args.__class__()
    delargs.update({'fake1': 1, 'fake2': 2})

# Generated at 2022-06-21 08:30:46.937683
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    with pytest.raises(TypeError):
        GlobalCLIArgs()

# Generated at 2022-06-21 08:30:57.135568
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    GlobalCLIArgs.__init__() should create an immutable dictionary

    The GlobalCLIArgs class should make a deep copy of the arguments passed to it,
    including converting all of the items inside of it to immutable data structures.
    """
    import copy

# Generated at 2022-06-21 08:31:02.158319
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cliargs = CLIArgs(vars(parse_cli_args()))
    assert isinstance(cliargs, ImmutableDict)
    assert isinstance(cliargs, Mapping)
    assert isinstance(cliargs, Container)
    assert not isinstance(cliargs, Sequence)
    assert not isinstance(cliargs, Set)



# Generated at 2022-06-21 08:31:14.162164
# Unit test for constructor of class CLIArgs
def test_CLIArgs():   # pylint: disable=too-many-locals
    import os
    import tempfile
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib
    from ansible.cli import CLI
    from ansible.cli.argument_parser import CLIArgumentParser

    options = CLIArgumentParser().parse_args()

    # create dataloader
    loader = DataLoader()

    # create vault secrets
    vault_secrets = VaultLib([])

    # create the cli
    cli = CLI(
        options,
        os.getcwd(),
        loader,
        vault_secrets,
        None,
    )

    # Grab the args from the options
    # pylint: disable=protected-access
    args = cli._get_cmd