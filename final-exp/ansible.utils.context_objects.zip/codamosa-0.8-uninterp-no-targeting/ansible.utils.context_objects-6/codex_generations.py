

# Generated at 2022-06-21 08:22:12.373349
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Tests that the constructor doesn't mutate args
    d = {'test': 'test', 'test2': 'test2'}
    s = cls = CLIArgs(d)
    assert d == s


# Generated at 2022-06-21 08:22:14.416246
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(type("Test", (_ABCSingleton,), {}), _ABCSingleton)

# Generated at 2022-06-21 08:22:17.477810
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    a = CLIArgs(dict(a=1, b=2))
    assert isinstance(a, ImmutableDict)
    assert isinstance(a, CLIArgs)


# Generated at 2022-06-21 08:22:25.608821
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class GlobalCLIArgs(ImmutableDict):
        """
        Globally hold a parsed copy of cli arguments.

        Only one of these exist per program as it is for global context
        """
        def __init__(self, *args, **kwargs):
            super(GlobalCLIArgs, self).__init__(*args, **kwargs)

    class TestClass(object):
        """
        Class which will be compared with GlobalCLIArgs
        """
        __metaclass__ = _ABCSingleton

    test = TestClass()
    global_instance = GlobalCLIArgs()
    assert test == global_instance

# Generated at 2022-06-21 08:22:27.974716
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class test(object):
        __metaclass__ = _ABCSingleton

    a = test()
    b = test()
    assert a == b

# Generated at 2022-06-21 08:22:33.254819
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common._collections_compat import OrderedDict
    test_dict = OrderedDict((('key1', 1), ('key2', 2), ('key3', 3)))
    cli_args = CLIArgs(test_dict)
    assert cli_args['key1'] == 1
    assert cli_args['key2'] == 2
    assert cli_args['key3'] == 3

# Generated at 2022-06-21 08:22:37.574427
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs.clear_instance()
    args = {'a': 1, 'b': 'c'}
    GlobalCLIArgs.__init__(args)
    assert GlobalCLIArgs() == args



# Generated at 2022-06-21 08:22:43.220426
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Create a mock cmd line arguments object to pass in to GlobalCLIArgs
    class options:
        pass

    options.dummy = "test"
    options.verbosity = 2
    GlobalCLIArgs.from_options(options)
    assert GlobalCLIArgs["dummy"] == "test"
    assert GlobalCLIArgs["verbosity"] == 2

# Generated at 2022-06-21 08:22:49.109285
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        pass

    class B(object):
        pass

    class C(A, metaclass=_ABCSingleton):
        pass

    class D(A, metaclass=_ABCSingleton):
        pass

    class E(A, D, B, metaclass=_ABCSingleton):
        pass



# Generated at 2022-06-21 08:22:57.093418
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import ansible, ansible.cli, ansible.config
    fake_options = ansible.cli.CLI.base_parser(constants=ansible.constants, usage="test")
    opts = fake_options.parse_args(['--ansible-config=%s' % ansible.config.DEFAULT_CONFIG_PATH])
    global_args = GlobalCLIArgs.from_options(opts)
    assert isinstance(global_args['ansible_config'], text_type)
    assert global_args['ansible_config'] == ansible.config.DEFAULT_CONFIG_PATH

# Generated at 2022-06-21 08:23:04.151817
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    opts = {'foo' : 'bar', 'baz' : 'qux'}
    global_cli_args = GlobalCLIArgs(opts)
    assert global_cli_args['foo'] == 'bar'
    assert global_cli_args['baz'] == 'qux'


# Generated at 2022-06-21 08:23:10.839688
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass
    class B(A):
        pass
    class C(B):
        pass

    assert A.__instance is None
    assert B.__instance is None
    assert C.__instance is None

    with A() as a, B() as b, C() as c:
        assert a is A.__instance
        assert b is A.__instance
        assert c is A.__instance

    assert A.__instance is None
    assert B.__instance is None
    assert C.__instance is None

# Generated at 2022-06-21 08:23:17.425693
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Unit test for class _ABCSingleton
    """
    class ABCMetaSubclass(metaclass=_ABCSingleton):
        pass

    class SingletonSubclass(metaclass=_ABCSingleton):
        pass

    class ABCMetaSubclassSingletonSubclass(_ABCSingleton, SingletonSubclass):
        pass

    class SingletonSubclassABCMetaSubclass(SingletonSubclass, _ABCSingleton):
        pass

# Generated at 2022-06-21 08:23:29.473057
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'foo': 'bar',
               'baz': 123,
               'qux': ['a', 'b'],
               'grault': {'garply': 1,
                          'fred': 2,
                          'plugh': 3
                         },
               'waldo': ['fred', 'plugh', 'xyzzy', 'thud']
              }
    obj = CLIArgs(mapping)
    assert obj == mapping
    mapping['grault']['garply'] = 7
    assert obj != mapping
    assert obj['grault'] == mapping['grault']
    assert obj['grault']['garply'] != mapping['grault']['garply']
    assert obj['grault'] != mapping['grault']
    mapping['foo'] = 'baz'
    assert obj != mapping
    assert obj['foo']

# Generated at 2022-06-21 08:23:41.259581
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import tempfile
    import ansible.release
    import ansible.utils.version as version

    # use a temporary file for the output
    (handle, tmp_path) = tempfile.mkstemp()

    # Put tempfile handle into context

# Generated at 2022-06-21 08:23:45.046129
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    @add_metaclass(_ABCSingleton)
    class TestABCSingleton(Container):
        """Test Class"""
        pass

    test_obj = TestABCSingleton()
    # raise an error when instantiate TestABCSingleton
    assert False

# Generated at 2022-06-21 08:23:49.290002
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from ansible.module_utils import six
    from ansible.module_utils.six.moves import reload_module

    reload_module(six)
    reload_module(Singleton)
    reload_module(GlobalCLIArgs)

    class SingletonTest(six.with_metaclass(_ABCSingleton, object)):
        pass
    class SingletonTest2(six.with_metaclass(Singleton, SingletonTest)):
        pass

    a = SingletonTest()
    b = SingletonTest2()
    assert a is b

# Generated at 2022-06-21 08:23:57.983859
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import AnsibleMapping
    from ansible.module_utils.common.dict_transformations import camel_dict_to_snake_dict

    args = GlobalCLIArgs({'foo': 'bar'})

    # Ensure that the constructed object is truly immutable
    try:
        args['blah'] = 'blah'
        raise AssertionError('faild to detect modification of a immutable object')
    except TypeError:
        pass

    # Ensure that the class is a singleton
    args.update({'foo': 'baz'})
    assert args['foo'] == 'baz'

    # Ensure that dict_transformations has it's own custom immutable dict to catch more modifications
    # and that it inherited that from CLIArgs
    assert isinstance(args, AnsibleMapping)

# Generated at 2022-06-21 08:24:01.420345
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(A):
        pass

    assert id(A()) == id(A())
    assert isinstance(A(), B)

# Generated at 2022-06-21 08:24:02.707705
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert GlobalCLIArgs() == CLIArgs({})

# Generated at 2022-06-21 08:24:15.431636
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import json
    import os
    import tempfile

    # Create a temporary file and write a list of arguments to it
    tmp_file = tempfile.NamedTemporaryFile(delete=False)
    tmp_file.write(b'[\n')
    tmp_file.write(b'  { "connection": "smart" },\n')
    tmp_file.write(b'  { "module_path": "' + json.dumps(os.getcwd()).encode('utf-8') + b'" }\n')
    tmp_file.write(b']\n')
    tmp_file.close()

    # Parse the temporary file into a CLIArgs object
    args = CLIArgs.from_options(parse_cli_args(tmp_file.name))

    # Make sure the arguments were parsed correctly

# Generated at 2022-06-21 08:24:21.768471
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Unit test for constructor of class CLIArgs
    """
    data = dict(one=1, two=2, three=dict(name='bob'))
    cli_args = CLIArgs(data)
    assert data == cli_args
    # Check behaviour of converting to immutable
    data['three']['name'] = 'mary'
    assert 'mary' == data['three']['name']
    assert 'bob' == cli_args['three']['name']


# global_cli_args is used by other files
global_cli_args = GlobalCLIArgs({})

# Generated at 2022-06-21 08:24:30.869971
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import tests.utils as utils
    from ansible.cli import CLI

    sys.argv = [sys.argv[0], '--version']

    cli = CLI(args=sys.argv[1:])
    cli.parse()
    options = cli.options

    args = GlobalCLIArgs.from_options(options)

    assert isinstance(args, CLIArgs)
    assert len(args) == 1
    assert args['version']
    assert len(args.keys()) == 1
    assert utils.is_immutable_mapping(args)


GlobalCLIArgs = GlobalCLIArgs()

# Generated at 2022-06-21 08:24:41.026106
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import is_immutable
    result = CLIArgs({
        'a': 'b',
        'c': {
            'd': 'e',
        },
        'f': [
            'g',
            'h',
        ],
    })
    assert isinstance(result, CLIArgs)
    assert is_immutable(result)
    assert len(result) == 3
    assert isinstance(result['a'], text_type)
    assert isinstance(result['c'], ImmutableDict)
    assert len(result['c']) == 1
    assert isinstance(result['f'], tuple)
    assert len(result['f']) == 2
    return result

# Generated at 2022-06-21 08:24:49.292434
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.cli import CLI
    from ansible.module_utils._text import to_text
    import json

    parser = CLI.base_parser()
    options = parser.parse_args(['-K', 'example.yaml', '-b', '-v'])
    args = CLIArgs.from_options(options)

    assert args['become_ask_pass'] is True
    assert args['module_path'] == [u'example.yaml']
    assert json.loads(to_text(args['verbosity'])) == 3

    # Test supported container types are converted to immutable types
    assert json.loads(to_text(args['module_path'])) == [u'example.yaml']
    assert json.loads(to_text(args['module_path'])) == [u'example.yaml']

# Generated at 2022-06-21 08:24:57.775591
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    id1 = GlobalCLIArgs.id
    from ansible.cli.arguments import parse_cli_args
    args = parse_cli_args([])
    assert GlobalCLIArgs.id == id1
    options = vars(args)
    GlobalCLIArgs.from_options(options)
    # The singleton's id (and state) should not have changed because we passed the same arguments
    assert GlobalCLIArgs.id == id1
    options['connection'] = 'smart'
    # The singleton's id (and state) should have changed because we passed different arguments
    assert GlobalCLIArgs.id != id1

# Generated at 2022-06-21 08:25:00.068270
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = GlobalCLIArgs(dict(foo="bar"))
    assert isinstance(a, GlobalCLIArgs)
    assert a["foo"] == "bar"

# Generated at 2022-06-21 08:25:04.626000
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton
        def __init__(self, key, value):
            self.key = key
            self.value = value
    class Bar(object, metaclass=_ABCSingleton):
        def __init__(self, key, value):
            self.key = key
            self.value = value

# Generated at 2022-06-21 08:25:07.269816
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs({'test_key': 'test_value'})
    assert global_cli_args['test_key'] == 'test_value'

# Generated at 2022-06-21 08:25:09.861084
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Test GlobalCLIArgs is a Singleton and only allows one instance.
    """
    my_options = GlobalCLIArgs.from_options(options=None)
    assert my_options == GlobalCLIArgs._instance

# Generated at 2022-06-21 08:25:16.863161
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # noinspection PyTypeChecker
    GlobalCLIArgs.from_options(None)

# Generated at 2022-06-21 08:25:24.919480
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        def __init__(self):
            self.value = 'is_a'

    class B(A):
        def __init__(self):
            self.value = 'is_not_a'

    class C(metaclass=_ABCSingleton):
        def __init__(self):
            self.value = 'is_c'

    a1 = A()
    a2 = A()
    b1 = B()
    c1 = C()
    c2 = C()

    assert a1.value == 'is_a'
    assert a2.value == 'is_a'
    assert a1 is a2
    assert b1.value == 'is_not_a'
    assert b1 is not a1

# Generated at 2022-06-21 08:25:33.357242
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        pass
    options_obj = Options()
    options_obj.test_list = [1, 2, 3]
    options_obj.test_dict = {'a': 'aval', 'b': 'bval'}
    options_obj.test_str = "test"

    cli_args = CLIArgs.from_options(options_obj)

    assert isinstance(cli_args.get('test_list'), tuple)
    assert isinstance(cli_args.get('test_str'), text_type)

# Generated at 2022-06-21 08:25:37.241981
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass

    assert B is B()
    assert A is B()
    assert A is not C()
    assert B is not C()
    assert B() is B()

# Generated at 2022-06-21 08:25:42.913060
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class foo(object):
        pass

    class bar(foo):
        __metaclass__ = _ABCSingleton

    class baz(bar):
        pass

    bar_object = bar()
    baz_object = baz()

    assert bar_object is baz_object
    assert isinstance(bar_object, bar)
    assert isinstance(baz_object, baz)

# Generated at 2022-06-21 08:25:52.371430
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = {'hello': 'world', 'my': {'dict': 'value', 'other': 'value'}, 'flags': ('who', 'what', 'where')}
    arg_obj = GlobalCLIArgs(args)

    # Verify that this is an instance of both ImmutableDict and GlobalCLIArgs
    assert isinstance(arg_obj, ImmutableDict)
    assert isinstance(arg_obj, GlobalCLIArgs)

    # Make sure the constructor recursively makes the data immutable
    assert isinstance(arg_obj['my'], ImmutableDict)
    assert isinstance(arg_obj['flags'], tuple)
    for flag in arg_obj['flags']:
        assert isinstance(flag, text_type)
    assert isinstance(arg_obj['my']['other'], text_type)

# Generated at 2022-06-21 08:25:59.831931
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test if CLIArgs behaves as expected

    This test is meant to be run on single object only, so all other objects should be mocked.
    """
    class MockContainer:
        def __init__(self, value):
            self.value = value

    class MockMapping(MockContainer, Mapping):
        def __len__(self):
            return len(self.value)

        def __iter__(self):
            return iter(self.value)

        def __getitem__(self, key):
            return self.value[key]

    class MockSet(MockContainer, Set):
        def __contains__(self, key):
            return key in self.value

    class MockSequence(MockContainer, Sequence):
        def __getitem__(self, idx):
            return self.value[idx]

# Generated at 2022-06-21 08:26:04.566515
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingleton1(GlobalCLIArgs):
        pass

    class TestSingleton2(GlobalCLIArgs):
        pass

    assert TestSingleton1 == TestSingleton2

    class TestSingleton3(GlobalCLIArgs):
        def __init__(self):
            pass

    assert TestSingleton1 == TestSingleton3


# Generated at 2022-06-21 08:26:06.515052
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = GlobalCLIArgs.from_options(object())
    b = GlobalCLIArgs.from_options(object())
    assert a is b

# Generated at 2022-06-21 08:26:08.586335
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SomeClass(object):
        class __metaclass__(_ABCSingleton):
            pass

    assert SomeClass() is SomeClass()

# Generated at 2022-06-21 08:26:15.645763
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABCSingleton(object):
        __metaclass__ = _ABCSingleton

    # If this doesn't raise an error, the test passes
    TestABCSingleton()

# Generated at 2022-06-21 08:26:23.640407
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    '''
    Test creation of CLIArgs.
    '''
    from ansible.module_utils.common.collections import MutableMapping
    import itertools
    import copy
    import random


    def gen_pairs(min_size, max_size, min_num, max_num, sort=True):
        '''
        Generate a sequence of tuples.

        The tuples will contain a key and value that are randomly generated.
        The length of the tuples will be between min_num and max_num.
        The number of tuples produced will be randomly generated.
        '''
        num_pairs = random.randint(min_num, max_num)
        for i in range(num_pairs):
            key = random.randint(min_size, max_size)
            value = random.rand

# Generated at 2022-06-21 08:26:33.620430
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # import os
    # print("PID: {0}".format(os.getpid()))
    # sys.exit(1)
    import sys
    from ansible.cli import CLI

    cli = CLI(args=sys.argv[1:])

    # import os
    # print("PID: {0}".format(os.getpid()))
    # sys.exit(1)

    # python -m test -t test/units/test_ansible_module_utils_arguments.py::test_GlobalCLIArgs
    test_cli_args = GlobalCLIArgs(cli.parser.parse_args(args=sys.argv[1:]))
    assert test_cli_args is GlobalCLIArgs.instance()

# Generated at 2022-06-21 08:26:42.526364
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Create a mutable mapping
    test_dict = {'a': True, 'b': {'b1': False, 'b2': [1, 2, 3]}, 'c': [{'c1': True}, {'c2': False}]}

    # Reverse order of list in 'b' key
    test_dict['b']['b2'].reverse()

    # Remove element 1 from list in 'b' key
    del test_dict['b']['b2'][1]

    # Remove key 'b2' from 'b' key
    del test_dict['b']['b2']

    # Remove element 0 from list in 'c' key
    del test_dict['c'][0]

    # Convert mutable mapping into immutable mapping

# Generated at 2022-06-21 08:26:55.143381
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import yaml
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.cli import CLI
    from ansible.utils.display import Display

    display = Display()
    cli = CLI(args=sys.argv[1:], callback=display.display, runas_opts=True)
    opt = cli.parser.parse_args(sys.argv[1:])
    opt_dict = vars(opt)
    GlobalCLIArgs(opt_dict)
    # Test if object is instance of ImmutableDict
    assert isinstance(opt_dict, ImmutableDict)
    # Test if object is instance of GlobalCLIArgs
    assert isinstance(opt_dict, GlobalCLIArgs)

    # Test if object is instance of yaml.SafeDumper


# Generated at 2022-06-21 08:27:02.818899
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Test that the metaclass can determine which constructor to call
    """

    class UnitTestABCSingleton(_ABCSingleton):

        def __init__(self):
            self.cls_initializer_called = True

        @classmethod
        def __class_getitem__(mcls, params):
            return type.__class_getitem__(mcls, params)

    class ABCSingletonChild(UnitTestABCSingleton):

        def __new__(cls):
            obj = object.__new__(cls)
            obj._initializer_called = True
            return obj


# Generated at 2022-06-21 08:27:10.152551
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    import unittest

    class First(metaclass=_ABCSingleton):
        pass

    class Second(First):
        pass

    class Third(First):
        pass

    assert issubclass(Second, Third)
    assert issubclass(Third, Second)

    class Fourth(Second, Third):
        pass

    assert issubclass(Fourth, Second)
    assert issubclass(Fourth, Third)
    assert isinstance(Fourth(), Second)
    assert isinstance(Fourth(), Third)

    class Fifth(Third, Second):
        pass

    assert issubclass(Fifth, Second)
    assert issubclass(Fifth, Third)
    assert isinstance(Fifth(), Second)
    assert isinstance(Fifth(), Third)

    class Sixth(First):
        pass

    class Seventh(Sixth):
        pass

   

# Generated at 2022-06-21 08:27:17.633524
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import pytest
    obj = {"a": 1, "b": {"c": [1, 2, 3], "d": {"e": 5}}}
    args = CLIArgs(obj)
    assert obj["a"] == args["a"]
    assert obj["b"]["c"] == args["b"]["c"]
    assert obj["b"]["d"]["e"] == args["b"]["d"]["e"]
    with pytest.raises(TypeError):
        args["nonexistent"] = 1

# Generated at 2022-06-21 08:27:22.433760
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_cli_args = CLIArgs({"foo": [1, 2], "bar":("baz", 11), "bam": {"foo":"bar", "baz":1}, "boo": {"foo": "bar"}})
    for arg, test_value in test_cli_args.items():
        assert(isinstance(test_value, (str, binary_type, tuple, frozenset, ImmutableDict)))

# Generated at 2022-06-21 08:27:31.800040
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.module_utils.common.collections import GlobalCLIArgs

    test_args = {'one': 1, 'two': 2, 'three': 3}
    cliargs = GlobalCLIArgs(test_args)
    assert cliargs['one'] == test_args['one']
    assert cliargs['two'] == test_args['two']
    assert cliargs['three'] == test_args['three']

    # make sure we can't modify the dict
    with pytest.raises(TypeError):
        cliargs['one'] = 'won'

# Generated at 2022-06-21 08:27:44.948894
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyABCSingleton(_ABCSingleton):
        pass
    class MyClass(metaclass=MyABCSingleton):
        pass
    a = MyClass()
    b = MyClass()
    assert a == b
    assert not a is b


# Generated at 2022-06-21 08:27:47.417854
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(GlobalCLIArgs):
        pass
    assert(isinstance(A(), A))
    assert(GlobalCLIArgs() == A())
    assert(id(GlobalCLIArgs()) == id(A()))

# Generated at 2022-06-21 08:27:53.348634
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.display import Display
    from ansible.module_utils.common.collections import is_sequence

    display = Display()
    display.verbosity = 1

    args = GlobalCLIArgs.from_options(display)
    assert not display.verbosity == args.get('verbosity')

    assert is_sequence(args)
    assert not is_sequence(display)



# Generated at 2022-06-21 08:28:04.786545
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    class Foo:
        pass

    # Test passing a set in place of a list
    try:
        GlobalCLIArgs({'foo': {'bar': {'a': 7, 'b': 9}, 'foobar': {'a': 7, 'b': 9}, 'maybe': {'a': 7, 'b': 9}}})
        raise AssertionError("Should have raised TypeError")
    except TypeError:
        pass

    # Test passing a string in place of a list
    try:
        GlobalCLIArgs({'foo': {'bar': {'a': 7, 'b': 9}, 'foobar': 'a string', 'maybe': {'a': 7, 'b': 9}}})
        raise AssertionError("Should have raised TypeError")
    except TypeError:
        pass

    # Test passing an object

# Generated at 2022-06-21 08:28:13.170638
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options(object):
        my_binary = None
        my_foo = "bar"
        my_dict = {"a": 1}
        my_list = [1, 2, 3]
        my_set = set([1, 2, 3])

    options = Options()
    args = CLIArgs.from_options(options)

    assert isinstance(args, CLIArgs)
    assert args.my_foo == "bar"
    assert args.my_dict == ImmutableDict({"a": 1})
    assert args.my_list == (1, 2, 3)
    assert args.my_set == frozenset([1, 2, 3])

    # assign should not work as we're immutable

# Generated at 2022-06-21 08:28:25.329516
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    input_dict = {'A': 1, 'B': (1, 2, 3), 'C': {'X': 1, 'Y': 2}}
    cli_args = CLIArgs(input_dict)

    # Test the constructor
    assert cli_args.get('A') == 1

    # Test that it is immutable
    try:
        cli_args['A'] = 2
    except TypeError:
        assert True
    else:
        assert False

    # Test recursively making immutable
    assert isinstance(cli_args['B'], tuple)
    assert isinstance(cli_args['C'], ImmutableDict)
    assert isinstance(cli_args['C']['X'], int)

# Generated at 2022-06-21 08:28:33.177981
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class CurrentModule:
        pass

    import sys
    # Inject new module into sys.modules
    sys.modules[__name__] = CurrentModule

    # Create a singleton class with the _ABCSingleton metaclass
    @add_metaclass(_ABCSingleton)
    class Test:
        pass

    t1 = Test()
    t2 = Test()
    # Compare the same thing to itself
    assert t1 == t1 is t1
    # Compare two instances of the same class
    assert t1 is t2
    # Compare two instances of the same class that were retrieved from
    # a different module than the one the class was created in
    assert t1 is CurrentModule.Test()

# Generated at 2022-06-21 08:28:35.406985
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton
    class Bar(Foo):
        pass
    assert Foo() == Bar()

# Generated at 2022-06-21 08:28:41.099795
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({'foo': 'bar', 'baz': {'qux': ['quux', 'quuux']}})
    assert args.foo == 'bar'
    assert args.baz.qux == ('quux', 'quuux')

if __name__ == "__main__":
    # Run local unit tests
    test_CLIArgs()

# Generated at 2022-06-21 08:28:44.237308
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = {'something': {'another': {'answer': 42}}}
    GlobalCLIArgs(args)
    toplevel = args['something']
    with pytest.raises(AttributeError):
        toplevel['another'] = {}

# Generated at 2022-06-21 08:29:05.811682
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({'hello': 1, 'world': {'foo': 'bar'}})
    assert isinstance(args.hello, int)
    assert isinstance(args.world.foo, text_type)

# Generated at 2022-06-21 08:29:12.064298
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs({'arg_one': 'value_one', 'arg_two': {'sub_arg_one': 'value_two'}})
    assert cli_args == {'arg_one': 'value_one', 'arg_two': {'sub_arg_one': 'value_two'}}

# Generated at 2022-06-21 08:29:18.742880
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _TestClass1(metaclass=_ABCSingleton):
        pass
    class _TestClass2(_TestClass1):
        pass
    class _TestClass3(_TestClass2):
        pass
    class _TestClass4(_TestClass3):
        pass
    class _TestClass5(_TestClass4):
        pass
    class _TestClass6(_TestClass5):
        pass
    class _TestClass7(_TestClass6):
        pass


# Generated at 2022-06-21 08:29:26.006591
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingletonSubclass1(object):
        pass
    class SingletonSubclass2(object):
        pass

    assert isinstance(SingletonSubclass1(), SingletonSubclass1)
    assert isinstance(SingletonSubclass2(), SingletonSubclass2)
    assert not isinstance(SingletonSubclass1(), SingletonSubclass2)
    assert not isinstance(SingletonSubclass2(), SingletonSubclass1)


# Generated at 2022-06-21 08:29:31.675848
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs([('a', 1), ('b', 2), ('c', 3)])
    assert(len(cli_args) == 3)
    assert(cli_args['a'] == 1)
    assert(cli_args['b'] == 2)
    assert(cli_args['c'] == 3)



# Generated at 2022-06-21 08:29:38.303123
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import tempfile
    import os
    import os.path
    import random
    random_integer = random.randint(0, 100)
    temp_file_name = os.path.join(tempfile.gettempdir(), "test_GlobalCLIArgs_%d" % random_integer)
    test_dict = {'foo':'bar',
                 'answer':42,
                 'list':[1,2,3,4,5],
                 'dict':{'one':1, 'two':2}}

# Generated at 2022-06-21 08:29:44.134427
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    my_mapping = {'my key': 'my value'}
    dict1 = CLIArgs(my_mapping)
    assert dict1.get('my key') == 'my value'
    assert isinstance(dict1, Mapping)
    assert not isinstance(dict1, MutableMapping)

# Generated at 2022-06-21 08:29:48.714247
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class X(object):
        __metaclass__ = _ABCSingleton
    class Y(X):
        pass

    assert GlobalCLIArgs._instances == {}
    assert GlobalCLIArgs() != GlobalCLIArgs()
    assert X._instances == {}
    assert X() != X()
    assert Y._instances == {}
    assert Y() != Y()



# Generated at 2022-06-21 08:30:00.867471
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import mock

    # setup the mock
    options = mock.Mock()
    options.verbosity = 1
    options.one_line = None
    options.tree = None
    options.module_path = None
    options.connection = "smart"
    options.remote_user = "root"
    options.ask_pass = False
    options.private_key_file = None
    options.ssh_common_args = None
    options.ssh_extra_args = None
    options.sftp_extra_args = None
    options.scp_extra_args = None
    options.become = None
    options.become_method = None
    options.become_user = None
    options.become_ask_pass = False
    options.ask_value_pass = False

# Generated at 2022-06-21 08:30:06.991869
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestMeta(object):
        __metaclass__ = _ABCSingleton

    class TestMeta2(object):
        __metaclass__ = _ABCSingleton

    assert TestMeta is TestMeta2

    class TestMeta3(TestMeta):
        pass

    assert TestMeta3 is not TestMeta
    class TestMeta4(TestMeta):
        pass

    assert TestMeta4 is not TestMeta
    assert TestMeta3 is not TestMeta4

# Generated at 2022-06-21 08:30:49.779370
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    assert issubclass(_ABCSingleton, Singleton)
    assert issubclass(_ABCSingleton, ABCMeta)

# Generated at 2022-06-21 08:30:52.492213
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
        def __init__(self):
            raise Exception
    a = A()
    b = A()
    assert a is b

# Generated at 2022-06-21 08:31:00.427693
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    # Test the string cases
    assert CLIArgs({'test': 'string'}) == {'test': 'string'}
    assert CLIArgs({'test': u'string'}) == {'test': u'string'}
    assert CLIArgs({'test': b'string'}) == {'test': b'string'}

    # Test the Mapping cases
    assert CLIArgs({'test': {'test': 'string'}}) == {'test': {'test': 'string'}}
    assert CLIArgs({'test': {'test': u'string'}}) == {'test': {'test': 'string'}}
    assert CLIArgs({'test': {'test': b'string'}}) == {'test': {'test': 'string'}}

# Generated at 2022-06-21 08:31:06.287689
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    cli_args = GlobalCLIArgs({'a': 1, 'b': {'c': 2}, 'd': [3, 4, 5]})
    assert cli_args.get('a') == 1
    assert cli_args.get('b', {}).get('c') == 2
    assert cli_args.get('d', [])[0] == 3

# Generated at 2022-06-21 08:31:16.533020
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collection_loader import AnsibleCollectionLoader
    import os
    import sys
    import json


# Generated at 2022-06-21 08:31:28.059503
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import math
    """
    Test that the given dictionary is converted to immutable data types.
    """
    a = CLIArgs({'a': {'b': 'b', 'c': ['c', ['d']]}, 'e': 'e', 'f': ['f', {'g': 'g'}]})
    assert isinstance(a, CLIArgs)
    assert isinstance(a['a'], ImmutableDict)
    assert isinstance(a['a']['c'], tuple)
    assert isinstance(a['a']['c'][1], tuple)
    assert isinstance(a['f'], tuple)
    assert isinstance(a['f'][1], ImmutableDict)
    assert a['a'] == {'b': 'b', 'c': ('c', ('d',))}

# Generated at 2022-06-21 08:31:31.988793
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A is B
    assert not issubclass(A, B)

# Generated at 2022-06-21 08:31:40.923377
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import os
    import sys

    from ansible.cli import CLI
    from ansible.utils.display import Display
    from ansible import constants as C

    # We have to mock up some requirements since we can't access the cmdline
    options = CLI.base_parser(constants=C).parse_known_args(('--version',))[0]
    display = Display()
    cli = CLI(args=options, display=display)

    # Global args are set in the CLI object by the time we get to the task queue manager
    assert isinstance(cli.options, GlobalCLIArgs)

    # Try setting the global args again which should fail
    failed_cli = CLI(args=options, display=display)
    assert cli.options is failed_cli.options

# Generated at 2022-06-21 08:31:41.759121
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = CLIArgs.from_options(None)
    assert isinstance(GlobalCLIArgs(options), GlobalCLIArgs)

# Generated at 2022-06-21 08:31:43.861679
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton):
        pass