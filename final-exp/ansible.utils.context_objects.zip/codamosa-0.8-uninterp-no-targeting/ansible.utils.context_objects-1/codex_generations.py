

# Generated at 2022-06-21 08:22:14.671486
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = {'key1': 'value1'}

    global_args = GlobalCLIArgs(args)

    assert args['key1'] == global_args['key1']


# Generated at 2022-06-21 08:22:18.881908
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({"foo": "bar", "baz": "qux"})
    GlobalCLIArgs({
        "bar": "foo",
        "baz": {"qux": "quux", "flag": "value"}
    })



# Generated at 2022-06-21 08:22:27.639308
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict1 = {'a': 1, 'b': 2, 'c': {'d': 3, 'e': [1, 2, 3, {'f': 4, 'g': 5}]}}
    # test that the constructor is not recursive
    test = CLIArgs(dict1)
    assert id(dict1) == id(test)
    assert test['c'] == dict1['c']
    # test the recursion works
    test = CLIArgs(_make_immutable(dict1))
    assert id(dict1) != id(test)
    assert id(dict1['c']) != id(test['c'])



# Generated at 2022-06-21 08:22:34.657460
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Check that we recursively convert any dictionaries, lists, and sets into immutable versions
    original = {'a': {'b': [1, 2, 3], 'c': 'four'}, 'd': {'e': {'f': set([1, 2, 3]), 'g': [4, 5, 6]}}}
    cli_args = CLIArgs(original)
    assert isinstance(cli_args, CLIArgs)
    for key, value in original.items():
        assert isinstance(cli_args[key], ImmutableDict)
        for sub_key, sub_value in value.items():
            if isinstance(sub_value, Set):
                assert isinstance(cli_args[key][sub_key], frozenset)

# Generated at 2022-06-21 08:22:47.009731
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    #pylint: disable=unused-import,redefined-builtin
    from ansible.utils.display import Display
    from ansible.module_utils.common._collections_compat import MutableMapping

    #pylint: disable=protected-access
    # __new__ creates an instance of this class and adds it to __instances__
    # then __init__ comes along and adds some more data, but that happens after
    # the instance is placed in the __instances__ dict.
    # We need to reset the __instances__ dict to allow us to re-instantiate this class
    GlobalCLIArgs._ABCSingleton__instances.clear()
    assert not GlobalCLIArgs._ABCSingleton__instances
    # Since we have reset the __instances__ dict, we can now create a new instance
   

# Generated at 2022-06-21 08:22:51.978430
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import unittest
    from ansible.module_utils._text import to_native

    class TestGlobalCLIArgs(unittest.TestCase):
        def setUp(self):
            self.global_cliargs = GlobalCLIArgs({'host_key_auto_add': False})

        def tearDown(self):
            del self.global_cliargs

        def runTest(self):
            self.global_cliargs = GlobalCLIArgs({'host_key_auto_add': False})
            self.assertEqual(self.global_cliargs['host_key_auto_add'], False)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestGlobalCLIArgs)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-21 08:23:02.804753
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = CLIArgs({'a': 1})
    assert options['a'] == 1

    options = CLIArgs({'a': {'b': 1}})
    assert options['a']['b'] == 1

    options = CLIArgs({'a': [1]})
    assert options['a'][0] == 1

    options = CLIArgs({'a': [{'b': 1}, {'b': 2}]})
    assert options['a'][0]['b'] == 1
    assert options['a'][1]['b'] == 2

    options = CLIArgs({'a': {'b': [1, 2]}})
    assert options['a']['b'][0] == 1
    assert options['a']['b'][1] == 2


# Generated at 2022-06-21 08:23:08.535279
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from collections import OrderedDict
    from ansible.module_utils.common.collections import ImmutableDict, ImmutableList, ImmutableSet
    a = CLIArgs(ImmutableDict([('a', 10), ('b', 20), ('c', 30)]))
    assert isinstance(a, ImmutableDict)
    assert a.keys() == ImmutableList(['a', 'b', 'c'])
    assert a.values() == ImmutableList([10, 20, 30])

    # Passing in dict with dict values, should give us back tuple of dicts
    b = CLIArgs({'a': {'b': 40, 'c': 50}})
    assert isinstance(b, ImmutableDict)
    assert b.keys() == ImmutableList(['a'])

# Generated at 2022-06-21 08:23:14.680518
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import datetime
    import json

    a = CLIArgs.from_options(
        argparse.Namespace(arg='value', arg2=[1,2,3])
    )
    # Make sure the new object is immutable
    with pytest.raises(TypeError):
        a['arg'] = 'some other value'
    with pytest.raises(TypeError):
        a['arg2'].append('4')

    assert a == {
        "arg": "value",
        "arg2": [1,2,3]
    }

    # Make sure we can compare the immutable object to a new mutable object
    b = {}
    b.update(a)
    b['arg'] = 'some other value'
    b['arg2'].append('4')

    assert a != b

    # Make sure the data is

# Generated at 2022-06-21 08:23:18.569240
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestOne(object):
        pass
    class TestTwo(object):
        pass
    assert TestOne() is TestOne()
    assert TestTwo() is TestTwo()
    assert TestOne() is not TestTwo()


# Generated at 2022-06-21 08:23:29.866331
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        pass

    class B(object):
        def __init__(self, x):
            self.x = x

    class C(object):
        __metaclass__ = _ABCSingleton

    class D(object):
        def __init__(self, x):
            self.x = x
        __metaclass__ = _ABCSingleton

    a = A()
    b = B(a)
    c = C()
    d = D(a)

    assert a is a
    assert b.x is a
    assert c is c
    assert d.x is a
    assert c is D()
    assert d is D(a)
    assert d is D(b)

# Generated at 2022-06-21 08:23:41.358216
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    class Opt(object):
        def __init__(self, d):
            self.__dict__.update(d)
        def __contains__(self, item):
            return item in self.__dict__
        def __getattr__(self, item):
            return self.__dict__[item]

    opt = Opt({
        'foo': 'bar',
        'baz': {'qux': 'quux', 'corge': [4, 5, 6]},
        'glendale': {'glendale': 'glendale'}
    })

    # Create an object that implements both from_options() and __call__()
    class Foo(object):
        def __init__(self, __mapping):
            self.result = __mapping


# Generated at 2022-06-21 08:23:44.731678
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(A(), A)
    assert isinstance(A(), object)
    assert A() is A()



# Generated at 2022-06-21 08:23:50.815112
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test a normal dict can be turned into a CLIArgs object
    """

    # create a dict that should be typed appropriately to survive being
    # turned into a CLIArgs object
    test_dict = {
        'a': 1,
        'b': '2',
        'c': {
            'x': 1,
            'y': '2',
            'z': (1, 2, 3, {'alpha': 1, 'beta': '2'})
        },
        'd': (1, 2, 3, {'alpha': 1, 'beta': '2'})
    }

    # make a copy of the test dict, but use immutable_dict to create the
    # dict object that is used to compare against
    test_dict_immutable = ImmutableDict(test_dict)

    # make the CLIArgs object and then

# Generated at 2022-06-21 08:23:52.725778
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert GlobalCLIArgs({'a':'a'}) == {'a': 'a'}

# Generated at 2022-06-21 08:23:56.714796
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABCSingleton(object):
        __metaclass__ = _ABCSingleton

    try:
        class TestABCSingleton2(TestABCSingleton):
            pass
    except TypeError:
        raise AssertionError("_ABCSingleton should not make new classes that inherit from the original read-only")
    else:
        # No exception occurred, test passed
        pass

# Generated at 2022-06-21 08:24:08.611390
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Verify that GlobalCLIArgs object is a Singleton and doesn't allow modification.
    """
    # Test that GlobalCLIArgs is a Singleton.
    args1 = GlobalCLIArgs({'verbose': 1})
    args2 = GlobalCLIArgs({'verbose': 2})
    assert args1 is args2
    assert args1 == args2

    # Test that we cannot modify an instance.
    try:
        args1['verbose'] = 2
    except TypeError:
        pass
    else:
        raise RuntimeError()
    assert args1['verbose'] == 1

    # Test that we cannot replace an instance with another one.

# Generated at 2022-06-21 08:24:10.378357
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert type(GlobalCLIArgs.from_options(type("options", (object, ), {}))) is GlobalCLIArgs

# Generated at 2022-06-21 08:24:13.657726
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(_ABCSingleton):
        pass

    class TestClass2(_ABCSingleton):
        pass

    assert TestClass() is TestClass()
    assert TestClass2() is TestClass2()
    assert TestClass() is not TestClass2()

# Generated at 2022-06-21 08:24:19.224873
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # pylint: disable=missing-docstring
    class Foo(_ABCSingleton, text_type):
        def __new__(cls, value):
            return super(Foo, cls).__new__(cls, value)

    class Bar(Foo):
        def __new__(cls, value):
            return super(Bar, cls).__new__(cls, value)

    foo1 = Foo("foo")
    foo2 = Foo("foo")
    bar1 = Bar("bar")
    bar2 = Bar("bar")
    assert foo1 is foo2
    assert bar1 is bar2
    assert foo1 is not bar1

# Generated at 2022-06-21 08:24:24.198119
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class TestABC(metaclass=_ABCSingleton):
        pass

    assert not issubclass(TestABC, Singleton)

# Generated at 2022-06-21 08:24:30.871334
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    g1 = GlobalCLIArgs({'a': 'hello', 'b': 'goodbye'})
    g2 = GlobalCLIArgs({'c': 'hello', 'b': 'goodbye', 'a': 'hello'})
    g3 = GlobalCLIArgs({'a': 'hello', 'b': 'goodbye'})

    assert g1 == g2
    assert g1 is g2
    assert g1 != g3
    assert g1 is not g3

# Generated at 2022-06-21 08:24:35.389864
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs({"a": ["1", "2", "3"]})
    assert isinstance(global_cli_args, GlobalCLIArgs)
    assert isinstance(global_cli_args, ImmutableDict)


# Generated at 2022-06-21 08:24:37.682444
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Example(_ABCSingleton):
        pass

    class Example2(_ABCSingleton):
        pass

    assert not issubclass(Example, Example2)

# Generated at 2022-06-21 08:24:47.422954
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # test dict
    dict_dict = dict(a=1, b=2, c=dict(d=4))
    # test frozenset
    frozenset_dict = dict(a=1, b=2, c=frozenset({3, 4, 5}))
    # test tuple
    tuple_dict = dict(a=1, b=2, c=[3, 4, 5])
    # test nested container
    nested_dict = dict(a=1, b=2, c=frozenset({3, 4, 5}), d=dict(e=[6, 7, 8], f=9))

    # test dict, dict, tuple and nested_dict can be initialized
    CLIArgs(dict_dict)
    CLIArgs(frozenset_dict)
    CLIArgs(tuple_dict)
    CLIArgs

# Generated at 2022-06-21 08:24:49.451929
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A:
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    A()
    B()

# Generated at 2022-06-21 08:24:53.302298
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = {'test': 'abc'}
    gca = GlobalCLIArgs(args)
    assert type(gca) == GlobalCLIArgs
    assert gca == args
    assert gca['test'] == 'abc'

# Generated at 2022-06-21 08:24:56.157046
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    x = {'a': {'b': 'c'}}
    y = CLIArgs(x)
    assert(x == dict(y))



# Generated at 2022-06-21 08:25:02.568416
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class TestArgs(GlobalCLIArgs):
        pass

    test_args = TestArgs(dict(
        arg1=1,
        arg2=dict(
            arg3=3,
            arg4=4,
        ),
    ))
    assert test_args == dict(
        arg1=1,
        arg2=dict(
            arg3=3,
            arg4=4,
        ),
    )

# Generated at 2022-06-21 08:25:11.996652
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test that we can convert from an argparse options object to an ImmutableDict
    """
    from argparse import Namespace

    options = Namespace()
    options.version = "2.4.1.0-20141230"
    options.help = False
    options.inventory = "/root/.ansible/tmp6UcFy1"
    options.listhosts = None
    options.syntax = None
    options.connection = "ssh"
    options.module_path = None
    options.forks = 5
    options.remote_user = "root"
    options.private_key_file = None
    options.ssh_common_args = None
    options.ssh_extra_args = None
    options.sftp_extra_args = None
    options.scp_extra_args = None
   

# Generated at 2022-06-21 08:25:24.531872
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import io
    import unittest
    import ansible.constants
    from ansible.utils import context_objects as co
    from ansible.utils.context_objects import GlobalCLIArgs

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_global_cli_args(self):
            # First make a mock object for options and then make an immutable version of it
            # using CLIArgs.
            options = object()
            options.foo = "bar"
            options.baz = "bar"
            cli_args = CLIArgs.from_options(options)

            old_stdout = sys.stdout
            old_stderr = sys.stderr

            # In order to test the singleton, we have to make sure the GlobalCLIArgs class is
            # empty.
           

# Generated at 2022-06-21 08:25:36.171153
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.config.cliargs import GlobalCLIArgs
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar

    g = GlobalCLIArgs.from_options(options=Templar(loader=None).available_variables['options'])


# Generated at 2022-06-21 08:25:38.544479
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class DummyClass(object):
        __metaclass__ = _ABCSingleton
    instance1 = DummyClass()
    instance2 = DummyClass()
    assert instance1 is instance2

# Generated at 2022-06-21 08:25:41.516205
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_args = {'foo': 1, 'bar': 2}
    args = GlobalCLIArgs(test_args)
    assert args['foo'] == 1
    assert args['bar'] == 2

# Generated at 2022-06-21 08:25:44.796678
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {"foo": "bar", "baz": "qux", "quux": "quuz"}
    CLIArgs(args)

# Generated at 2022-06-21 08:25:46.944434
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class _TestClass(object):
        __metaclass__ = _ABCSingleton

    _TestClass()



# Generated at 2022-06-21 08:25:51.303403
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import doctest

    # Skip GlobalCLIArgs as it is a singleton
    modules = [
        CLIArgs,
    ]

    results = doctest.testmod(modules=modules, optionflags=doctest.NORMALIZE_WHITESPACE | doctest.ELLIPSIS)
    if results.failed:
        raise ValueError("Doctest failed for module")

# Generated at 2022-06-21 08:25:57.186140
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # create an object with a class
    cli_args = CLIArgs({'a': 'b'})
    assert isinstance(cli_args, immutable.ImmutableDict)
    assert isinstance(cli_args, CLIArgs)
    assert cli_args == ImmutableDict({'a': 'b'})
    with pytest.raises(TypeError):
        cli_args['a'] = 'c'
    with pytest.raises(TypeError):
        cli_args.update({'b': 'c'})

# Generated at 2022-06-21 08:26:08.084987
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'foo': 'bar', 'baz': ['a', 'b', 'c'], 'frob': {'a': 1, 'b': 2, 'c': 3}, 'nog': set(['d', 'e', 'f'])}
    cli_args = CLIArgs(test_dict)
    assert cli_args == test_dict

    test_dict = {'foo': {'wiz': 'bang'}, 'baz': ['a', 'b', 'c'], 'frob': {'a': 1, 'b': 2, 'c': 3}, 'nog': set(['d', 'e', 'f'])}
    cli_args = CLIArgs(test_dict)
    assert cli_args == test_dict


# Generated at 2022-06-21 08:26:17.702382
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest

    test_args = {
        'foo': [
            'bar',
            'baz'
        ],
        'string': 'this is an example',
        'list': [
            'blah',
            'blahblah'
        ],
        'dict': {
            'a': 'b',
            'c': 'd'
        }
    }

    with pytest.raises(TypeError):
        GlobalCLIArgs(test_args)

    GlobalCLIArgs(test_args)
    assert test_args == GlobalCLIArgs()
    assert test_args is not GlobalCLIArgs()
    assert type(test_args['dict']) == dict
    assert type(GlobalCLIArgs()['dict']) == ImmutableDict


# Generated at 2022-06-21 08:26:26.954022
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            self.value = 123

    class Bar(object):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            self.value = 456

    assert Foo is Foo()
    assert Bar is Bar()
    assert Foo is not Bar
    assert Foo().value == 123
    assert Bar().value == 456

# Generated at 2022-06-21 08:26:36.837704
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Create an CLIArgs object and ensure it is always immutable
    """
    mapping = {
        'foo': 'bar',
        'one': 'two',
        'baz': ['a', 'b', 'c', 'd', 'e'],
        'qux': {'a': '1', 'b': 2, 'c': {'d': '3', 'e': ['f', 'g', 'h']}},
    }
    args = CLIArgs(mapping)

    # Verify we get the values we expect for the keys
    assert args['foo'] == 'bar'
    assert args['qux']['c']['e'][1] == 'g'

    # Verify that the data is immutable
    try:
        args['foo'] = 'baz'
    except TypeError:
        pass

# Generated at 2022-06-21 08:26:39.981175
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    try:
        GlobalCLIArgs(a=1, b=2)
    except TypeError:
        pass
    else:
        assert False, "GlobalCLIArgs() doesn't raise TypeError when called with no args"

# Generated at 2022-06-21 08:26:44.098306
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # test for __init__()
    test_dict = {'a': 1, 'b': 2}
    args = CLIArgs(test_dict)
    assert args['a'] == 1
    assert args['b'] == 2



# Generated at 2022-06-21 08:26:52.429120
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Make sure the CLIArgs object properly converts a list of
    command line arguments into an ImmutableDict
    """
    arguments = {
        "ask_sudo_pass": False,
        "ask_vault_pass": False,
        "become_ask_pass": False,
        "become": False,
        "become_method": "sudo",
        "become_user": "root",
    }
    arguments_obj = CLIArgs(arguments)
    assert arguments == arguments_obj



# Generated at 2022-06-21 08:26:57.164594
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class test1(object):
        __metaclass__ = _ABCSingleton

    class test2(object):
        __metaclass__ = _ABCSingleton

    try:
        class test3(test1, test2):
            pass
    except TypeError:
        pass
    else:
        raise AssertionError('_ABCSingleton meta class should not allow multiple inheritance')

# Generated at 2022-06-21 08:27:03.274728
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class options(object):
        foo = 'foo'
        bar = 'bar'

    for args in [GlobalCLIArgs.from_options(options()), GlobalCLIArgs.from_options(options())]:
        assert isinstance(args, ImmutableDict)
        assert 'foo' in args
        assert 'bar' in args

# Generated at 2022-06-21 08:27:10.338797
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.parsing.convert_bool import boolean

# Generated at 2022-06-21 08:27:18.760344
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():  # type: () -> None
    """
    Test that the _ABCSingleton metaclass is working as designed.

    We've made _ABCSingleton a metaclass that supports combining the features of ABCMeta and
    Singleton.  This test checks that it behaves as expected.
    """

    @add_metaclass(_ABCSingleton)
    class TestClass(object):
        pass

    try:
        # Classes based on ABCMeta must be abstract
        TestClass()
    except TypeError:
        pass
    else:
        assert False, 'ABCMeta class not abstract'



# Generated at 2022-06-21 08:27:21.101758
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs({'foo': 'bar'})
    assert isinstance(cli_args, ImmutableDict)



# Generated at 2022-06-21 08:27:27.731739
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_args = GlobalCLIArgs({"foo": "bar"})
    assert isinstance(global_args, GlobalCLIArgs)
    assert isinstance(global_args, CLIArgs)


# Generated at 2022-06-21 08:27:33.614730
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(metaclass=_ABCSingleton):
        pass

    class B(A):
        pass
    # Sanity
    assert A() is A()
    assert B() is B()

    # If there were no MRO magic, this would fail due to the super _new_ method
    # not calling _init_ on class A
    assert A() is B()

# Generated at 2022-06-21 08:27:44.592530
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-21 08:27:46.220949
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object, metaclass=_ABCSingleton):
        pass

    assert isinstance(A(), A)
    assert A() is A()

# Generated at 2022-06-21 08:27:51.875357
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object):
        __metaclass__ = _ABCSingleton

    t1 = Test()
    try:
        t2 = Test()
    except TypeError as e:
        assert 'Can\'t instantiate abstract class Test' in str(e)
    else:
        assert False, "Instantiating a test class with metaclass _ABCSingleton should fail"

# Generated at 2022-06-21 08:27:54.425869
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs({'test': 'value'})
    assert isinstance(cli_args, CLIArgs)



# Generated at 2022-06-21 08:27:57.701675
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import ansible.cli.arguments as arguments

    parser = arguments.create_parser()
    options, _ = parser.parse_known_args()
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-21 08:28:07.911095
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Make sure we can create two different instances of _ABCSingleton derived classes
    """
    class TestClass1(object):
        __metaclass__ = _ABCSingleton

    class TestClass2(object):
        __metaclass__ = _ABCSingleton

    class TestClass3(_ABCSingleton):
        pass

    class TestClass4(_ABCSingleton):
        pass

    test1 = TestClass1()
    test2 = TestClass2()
    test3 = TestClass3()
    test4 = TestClass4()

    assert test1 != test2
    assert test1 != test3
    assert test1 != test4
    assert test2 != test3
    assert test2 != test4
    assert test3 != test4

# Generated at 2022-06-21 08:28:10.675994
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingletonABC(metaclass=_ABCSingleton):
        pass

    # Test that a singleton instance is actually in memory
    # and that it is the same each time
    assert SingletonABC() is SingletonABC()



# Generated at 2022-06-21 08:28:15.250250
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import ansible.constants as C

    args = GlobalCLIArgs({u'hello': C.DEFAULT_DEBUG})
    assert(args.get(u'hello') == C.DEFAULT_DEBUG)

# Generated at 2022-06-21 08:28:31.818099
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():  # pylint: disable=invalid-name
    """
    Smoke test for class _ABCSingleton.

    When used as a metaclass, this is a class factory.  The factory should
    create a class which is a Singleton and an ABCMeta.  Thus the created
    class should have the methods of both Singleton and ABCMeta
    """
    class SingletonABC(metaclass=_ABCSingleton):  # pylint: disable=abstract-method
        pass

    # Make sure we are a singleton and not a normal class
    assert SingletonABC.__new__ is Singleton.__new__, "__new__ is not Singleton.__new__"
    assert SingletonABC.__init__ is Singleton.__init__, "__init__ is not Singleton.__init__"

    # Make sure the methods are there


# Generated at 2022-06-21 08:28:34.521338
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Base(object, metaclass=_ABCSingleton):
        pass

    Base()
    Base()
    assert Base().__dict__ == Base().__dict__


# Generated at 2022-06-21 08:28:36.622776
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABSingleton(object):
        __metaclass__ = _ABCSingleton

    TestABSingleton()

# Generated at 2022-06-21 08:28:40.974889
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs()
    GlobalCLIArgs({'foo': True})
    GlobalCLIArgs({'foo': True, 'bar': False})
    GlobalCLIArgs({'foo': True, 'bar': False, 'bam': True})



# Generated at 2022-06-21 08:28:51.998575
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import tempfile
    import shutil
    import re
    import json
    from ansible.config.manager import ConfigManager
    from ansible.galaxy.role_cache import RoleCache
    from ansible.galaxy.role_repository import RoleRepository
    from ansible.galaxy.token_auth import NoAuthToken, GalaxyTokenAuth
    from ansible.galaxy.api import GalaxyAPI
    from ansible.galaxy.api_server import GalaxyAPIServer
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.common._collections_compat import (Container, Mapping, Sequence, Set)
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils.singleton import Singleton

# Generated at 2022-06-21 08:29:02.803828
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _TestABCSingleton1Class(object):
        __metaclass__ = _ABCSingleton

    class _TestABCSingleton2Class(_TestABCSingleton1Class):
        # This should not cause an exception
        pass

    class _TestABCSingleton3Class(object):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            # This should not be called
            raise RuntimeError()

    # This should not cause an exception
    _TestABCSingleton1Class()

    # This should not cause an exception
    _TestABCSingleton2Class()

    # This should cause an exception
    try:
        _TestABCSingleton3Class()
        assert False
    except RuntimeError:
        pass

# Generated at 2022-06-21 08:29:04.122172
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs.instance('hello', world=2, worker=True)


# Generated at 2022-06-21 08:29:10.379144
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test to class CLIArgs constructor
    """
    args = CLIArgs({'ANSIBLE_PIPELINING': False, 'ANSIBLE_SSH_RETRIES': 5,\
					'ANSIBLE_STDOUT_CALLBACK': 'json', 'ANSIBLE_CONFIG': 'fakefile',\
					'ANSIBLE_REMOTE_USER': 'root', 'ANSIBLE_FORKS': 5, 'ANSIBLE_SUBSET': None})
    assert args['ANSIBLE_SUBSET'] is None
    assert args['ANSIBLE_PIPELINING'] is False
    assert args['ANSIBLE_STDOUT_CALLBACK'] == 'json'

# Generated at 2022-06-21 08:29:14.785731
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(_ABCSingleton):
        pass

    class B(_ABCSingleton):
        pass

    assert isinstance(A(), A)
    assert not isinstance(A(), B)
    assert isinstance(B(), B)
    assert not isinstance(B(), A)

# Generated at 2022-06-21 08:29:16.175959
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        pass
    Test()



# Generated at 2022-06-21 08:29:31.010192
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Make sure the constructor for GlobalCLIArgs works without raising an exception.
    """
    GlobalCLIArgs({'hello': 'world'})

# Generated at 2022-06-21 08:29:32.961067
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli.arguments import options
    GlobalCLIArgs.from_options(options)
    assert GlobalCLIArgs() is GlobalCLIArgs()

# Generated at 2022-06-21 08:29:39.722049
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli import CLI
    from ansible.module_utils.common._collections_compat import MutableMapping
    mapping = MutableMapping()
    mapping['foo'] = 'bar'
    options = CLI.base_parser(mutable_defaults=False).parse_args(['--foo=bar'])
    args1 = GlobalCLIArgs(mapping)
    assert args1['foo'] == 'bar'
    args2 = GlobalCLIArgs.from_options(options)
    assert args2['foo'] == 'bar'

# Generated at 2022-06-21 08:29:45.768650
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    class MyClass(GlobalCLIArgs):
        pass

    options = ImmutableDict(dict(a=1, b=2))
    MyGlobalClass = MyClass.from_options(options)
    assert MyGlobalClass['a'] == 1
    assert MyGlobalClass['b'] == 2



# Generated at 2022-06-21 08:29:49.289436
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
        pass

    class B(object):
        __metaclass__ = _ABCSingleton
        pass

    assert A == A
    assert type(A) == type(A)
    assert type(A) != type(B)

# Generated at 2022-06-21 08:29:56.533516
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    class TestClass2(object):
        __metaclass__ = _ABCSingleton

    c1 = TestClass()
    c2 = TestClass()
    c3 = TestClass2()

    assert c1 is c2
    assert c1 is not c3
    assert c2 is not c3

# Generated at 2022-06-21 08:29:58.378400
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-21 08:30:09.007097
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.facts.core import get_system_facts
    from ansible.module_utils.facts.hardware.sdk.junos import JunosHardware
    from ansible.module_utils.facts.hardware.sdk.junos import JunosHardwareSDK
    from ansible.module_utils.facts.network.generic import GenericNetwork
    from ansible.module_utils.facts.network.junos import JunosNetwork
    from ansible.module_utils.facts.network.junos import JunosNetworkSDK
    from ansible.module_utils.facts.network.linux import LinuxNetwork
    from ansible.module_utils.facts.network.nxos import NxosNetwork
    from ansible.module_utils.facts.network.nxos import NxosNetworkSDK

# Generated at 2022-06-21 08:30:13.862301
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class MyABCSingleton(object):
        __metaclass__ = _ABCSingleton
        def __init__(self, name):
            self.name = name

    # Second instance should use the first
    m1 = MyABCSingleton('m1')
    m2 = MyABCSingleton('m2')
    assert m1 is m2
    assert m1.name == 'm1'

# Generated at 2022-06-21 08:30:17.961773
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        def __init__(self):
            self.test = 'test'

    a = Test()
    b = Test()

    assert a.test == b.test
    assert a is b
    assert type(a.test) == type(b.test)

# Generated at 2022-06-21 08:30:51.706295
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    import argparse
    parser = argparse.ArgumentParser(description="Test GlobalCLIArgs")
    parser.add_argument('-a', '--arg-a', action='store_true', help="a help")
    parser.add_argument('-b', '--arg-b', action='store_true', help="b help")
    args = parser.parse_args()
    GlobalCLIArgs.from_options(args)

    # We would raise an exception if it doesn't work
    pass

# Generated at 2022-06-21 08:30:58.098526
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict_data = {'a': {'b': {'c': 'd'}}}
    cli_args1 = CLIArgs(dict_data)
    assert cli_args1['a']['b']['c'] == 'd'

    dict_data = {'a': {'b': {'c': {'d': 'e'}}}}
    cli_args2 = CLIArgs(dict_data)
    assert cli_args2['a']['b']['c']['d'] == 'e'

# Generated at 2022-06-21 08:31:09.864751
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    my_dict = {
        'bool': True,
        'int': 1,
        'list': ['a', 'b', 'c'],
        'tuple': ('a', 'b', 'c'),
        'set': {'a', 'b', 'c'},
        'dict': {'a': 'b', 'c': 'd'},
        'str': 'string',
        'bytes': b'bytes',
        'unicode': u'unicode'
    }

    mapping = _make_immutable(my_dict)

    cli_args = CLIArgs(mapping)
    assert isinstance(cli_args, CLIArgs)
    assert cli_args['bool'] is True
    assert cli_args['int'] == 1

# Generated at 2022-06-21 08:31:12.449660
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ChildClass(object, metaclass=_ABCSingleton):
        pass
    assert ChildClass() is ChildClass()

# Generated at 2022-06-21 08:31:13.972972
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class X(object):
        __metaclass__ = _ABCSingleton

    assert issubclass(X, Singleton)

# Generated at 2022-06-21 08:31:18.013184
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs(vars({'one': 1, 'two': 2}))
    assert isinstance(args, CLIArgs)
    assert args['one'] == 1
    assert args['two'] == 2
    assert len(args) == 2
    assert repr(args) == "CLIArgs(ImmutableDict({'one': 1, 'two': 2}))"
    assert str(args) == '{"one": 1, "two": 2}'


# Generated at 2022-06-21 08:31:25.057123
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    _a = {'b': ['c', 'd', 'e'], 'f': 'g'}
    _c = GlobalCLIArgs(_a)
    assert _c == ImmutableDict({'b': ('c', 'd', 'e'), 'f': 'g'}), 'Test failed.'


# Generated at 2022-06-21 08:31:36.113921
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.utils.vars import combine_vars

    class Options(object):
        debug = False
        module_path = None
        listhosts = None
        syntax = None
        diff = False
        private_key_file = ['/path/to/key']
        host_key_checking = False

    class PlayContext(object):
        def __init__(self):
            self.connection = 'local'

# Generated at 2022-06-21 08:31:42.016482
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Demonstrate how to construct an instance of GlobalCLIArgs

    This is not a real unit test, but a demonstration of how to construct an instance of GlobalCLIArgs.
    """
    # pylint: disable=protected-access
    # Inject the shared instance into the metaclass
    GlobalCLIArgs._shared_state = {'test_one': 'one', 'test_two': 2}
    # get the CLIArgs instance
    instance = GlobalCLIArgs()
    # pylint: enable=protected-access

# Generated at 2022-06-21 08:31:49.569569
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    map = {'test_flag': True, 'test_list': ['foo', 'bar'], 'test_dict': {'foo': 'bar'}}
    obj = CLIArgs(map)
    assert isinstance(obj, ImmutableDict)
    assert obj == map
    # Change a mutable object (list in this case)
    obj['test_list'].append('baz')
    # Test that it changed
    assert obj != map
