

# Generated at 2022-06-21 08:22:22.483980
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import ImmutableList
    from ansible.module_utils.common.collections import ImmutableSet

    temp = CLIArgs({'integer': 42, 'string': 'string', 'dict': {'key': 'value'}, 'list': [1, 2, 3], 'set': {'a', 'b', 'c'}})

    assert isinstance(temp['integer'], int)
    assert isinstance(temp['string'], str)
    assert isinstance(temp['dict'], ImmutableDict)
    assert isinstance(temp['list'], ImmutableList)
    assert isinstance(temp['set'], ImmutableSet)
    assert temp['integer'] == 42

# Generated at 2022-06-21 08:22:24.591531
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Parent(object):
        __metaclass__ = _ABCSingleton

    class Child(Parent):
        def __init__(self):
            self.a = 1

    class Child2(Parent):
        def __init__(self):
            self.a = 2

    assert Child() == Child()
    assert Child() != Child2()

# Generated at 2022-06-21 08:22:33.302588
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import os
    import sys
    import unittest

    class TestGlobalCLIArgs(unittest.TestCase):

        def test_singleton(self):
            args = GlobalCLIArgs({'foo': 'bar'})

            # This is a singleton.  If you make a new instance of this class, it should actually be
            # the same object as the one already created.
            args2 = GlobalCLIArgs({'bar': 'baz'})
            self.assertEqual(args2, args)

            # Subclasses that don't have a __init__ method should still work
            class Subclass1(GlobalCLIArgs):
                pass
            class Subclass2(GlobalCLIArgs):
                pass
            self.assertEqual(Subclass1(), Subclass2())

            # Subclasses that do have a __init__ method should

# Generated at 2022-06-21 08:22:45.797149
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo', type=int, nargs=2, help="foo help")
    parser.add_argument('--bar', type=str, action="append", help="bar help")
    args = parser.parse_args([])
    mapping = vars(args)
    # Do we get an error when constructing?
    test_args = CLIArgs(mapping)
    # Are the values immutable?
    try:
        test_args['foo'][1] = 3
    except TypeError as e:
        pass
    else:
        raise AssertionError("Values in CLIArgs() class are mutable")
    try:
        test_args['bar'].append("test")
    except AttributeError as e:
        pass

# Generated at 2022-06-21 08:22:57.182665
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_dict = {
        'ansible_host': 'ansible.example.com',
        'connection': 'ssh',
        'private_key_file': '/root/.ssh/id_rsa',
        'inventory_paths': ['/root/ansible/hosts'],
        'roles_path': '/root/ansible/roles',
        'verbosity': 1,
        'verbose': True,
        'debug': True,
        'interpreter_python': '/usr/bin/python3',
    }
    # Check that a new dictionary of values is set
    test_GlobalCLIArgs = GlobalCLIArgs(test_dict)
    assert test_GlobalCLIArgs == ImmutableDict(test_dict)

    # Check that we can set a new dictionary of values

# Generated at 2022-06-21 08:23:04.204236
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class ParsedArgs():
        def __init__(self, **kwargs):
            self.__dict__ = kwargs
            self.__dict__ = _make_immutable(kwargs)

    args = ParsedArgs(foo='foo', bar='bar', baz='baz')
    test = CLIArgs(vars(args))
    assert test.foo == 'foo'
    assert test.bar == 'bar'
    assert test.baz == 'baz'

# Generated at 2022-06-21 08:23:07.380569
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.parsing.dataloader import DataLoader
    from ansible.cli.arguments import options

    from ansible.config.manager import ConfigManager

    # Create config manager
    config_manager = ConfigManager(options)
    dataloader = DataLoader()
    config = config_manager.get_config_data(dataloader)
    cliargs = CLIArgs(config.options)



# Generated at 2022-06-21 08:23:10.009202
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        """A class that uses the _ABCSingleton metaclass"""
        __metaclass__ = _ABCSingleton

    assert issubclass(A, object)



# Generated at 2022-06-21 08:23:15.267219
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.constants import (CLI_COMMON_ARGS, get_config, get_config_value, DEFAULTS)
    from ansible.cli import CLI
    from ansible.utils.path import unfrackpath

    parser = CLI.base_parser(desc=CLI_COMMON_ARGS, usage='%(prog)s someprog [options] path', epilog=None)
    parser.add_argument('args', metavar='args', nargs='*', help='The rest of the command line arguments')

    # This is a hack to prevent the THREAD_TIMEOUT default being changed by the config
    # ansible.cfg file.  We don't want the global options affected by that config file.
    # So here we set it to a different than the configured value (None) so it stays the
    # default value

# Generated at 2022-06-21 08:23:22.230913
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {'name': ['First', 'Second'], 'arg2': 'Another Arg'}
    cli_args = CLIArgs(args)
    assert isinstance(cli_args, CLIArgs)
    assert isinstance(cli_args, ImmutableDict)
    assert cli_args == args
    assert cli_args.get('name') == tuple(args['name'])



# Generated at 2022-06-21 08:23:25.933309
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class DummyABCSingleton(object):
        __metaclass__ = _ABCSingleton

# Generated at 2022-06-21 08:23:28.731229
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    a = CLIArgs({'a': 1, 'b': 2})
    assert a['a'] == 1
    assert a['b'] == 2


# Generated at 2022-06-21 08:23:38.045857
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    arg_dict = {'hi': 'hi', 'bye': list('bye'), 'guys': {'all': 'together', 'now': {'ladies': 'ladies', 'gents': 'gents'}}}
    instance = CLIArgs(arg_dict)
    assert instance['hi'] == 'hi'
    assert instance['bye'] == ('b', 'y', 'e')
    assert instance['guys']['all'] == 'together'
    assert instance['guys']['now']['ladies'] == 'ladies'
    assert instance['guys']['now']['gents'] == 'gents'


# Generated at 2022-06-21 08:23:44.683320
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options:
        def __init__(self):
            self.debug = {'name': 1}
            self.var = [1, True, {'var': [1, 2, True, 'abc']}]
    cli_args = CLIArgs.from_options(Options())
    assert cli_args == {'debug': {'name': 1}, 'var': (1, True, {'var': (1, 2, True, 'abc')})}

# Generated at 2022-06-21 08:23:51.513946
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    try:
        global_cli_args_1 = GlobalCLIArgs.from_options(CLIArgs(dict()))
        global_cli_args_2 = GlobalCLIArgs.from_options(CLIArgs(dict()))
        assert global_cli_args_1 is global_cli_args_2
    except Exception as e:
        raise AssertionError("GlobalCLIArgs instance was not singleton. Exception was: %s" % str(e))

# Generated at 2022-06-21 08:23:57.729312
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class Test1(metaclass=_ABCSingleton):  # pylint: disable=abstract-method
        pass
    assert issubclass(Test1, Singleton)
    try:
        class Test2(metaclass=_ABCSingleton):  # pylint: disable=abstract-method
            pass
    except TypeError:
        pass
    else:
        assert False, "Expected TypeError"

    class Test3(metaclass=_ABCSingleton):  # pylint: disable=abstract-method
        pass
    assert issubclass(Test3, Singleton)

# Generated at 2022-06-21 08:23:58.331813
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    pass

# Generated at 2022-06-21 08:24:04.044848
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Ensure that a class created with the ABCSingleton metaclass is a class that satisfies the
    requirements for both ABCMeta and Singleton.
    """
    class S(metaclass=_ABCSingleton):
        pass
    assert issubclass(S, ABCMeta)
    assert issubclass(S, Singleton)



# Generated at 2022-06-21 08:24:07.534215
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton
    class Bar(Foo):
        pass
    foo = Foo()
    bar = Bar()
    assert foo is bar

# Generated at 2022-06-21 08:24:17.771479
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import os, sys
    import tempfile
    import shutil
    import unittest

    from ansible.cli import CLI
    from ansible.errors import AnsibleError, AnsibleOptionsError
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import ImmutableDict

    from ansible.release import __version__

    TESTS_DIR = os.path.dirname(__file__)

    # Setup
    option_parser = CLI.base_parser(
        usage="ansible-test [options]",
        desc="Tools for testing Ansible itself"
    )
    option_parser.disable_interspersed_args()
    cli_options, cli_args = option_parser.parse_args(args=())

    # Verify existing object

# Generated at 2022-06-21 08:24:22.194380
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs.from_options("hello")
    assert isinstance(global_cli_args, GlobalCLIArgs)
    assert isinstance(global_cli_args, ImmutableDict)

# Generated at 2022-06-21 08:24:26.267776
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # We expect global_args to be an instance of CLIArgs.
    global_args = CLIArgs(dictionary={"hello": "world"})
    assert global_args == {"hello": "world"}
    assert isinstance(global_args, CLIArgs)


# Generated at 2022-06-21 08:24:28.835480
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class test(_ABCSingleton):
        pass
    t1 = test()
    t2 = test()
    assert t1 == t2

# Generated at 2022-06-21 08:24:40.476359
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.config.args import CLIArgs
    from ansible.compat.tests.mock import patch
    from ansible.compat.six import StringIO
    from ansible.config.manager import ConfigManager

    my_list = [1, 2, 3, 4]
    my_dict = {'key1': 'value1', 'key2': 'value2'}
    my_set = set(['one', 'two'])
    my_tuple = ('a', 'b', 'c')
    my_frozenset = frozenset(['a', 'b'])
    my_str = 'some_string'
    my_unicode = u'test unicode 字符串'

    # Setup a fake options object with
    fake_opts = ConfigManager.option_helpers.config_

# Generated at 2022-06-21 08:24:45.988797
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # This test is a bit weird since the singleton pattern means you can't
    # create more than one instance of a class.  In this case,
    # ``GlobalCLIArgs`` has already been created.  So if we create more than
    # one instance, the second instance must be considered a duplicate of the
    # first and be the same object.

    cli_args = GlobalCLIArgs({})

    assert cli_args is GlobalCLIArgs({})

# Generated at 2022-06-21 08:24:48.562365
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class X(_ABCSingleton):
        pass

    class Y(_ABCSingleton):
        pass

    assert X is Y

# Generated at 2022-06-21 08:24:59.421956
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-21 08:25:07.739688
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class FakeOptions(object):
        def __init__(self):
            self.test = True
            self.verbose = False
            self.foo = "bar"
            self.bar = {1: 2, 3: 4}
            self.baz = ["one", 2, 3]

    options = FakeOptions()
    cli_args = CLIArgs.from_options(options)
    assert cli_args.test == options.test
    assert cli_args.verbose == options.verbose
    assert cli_args.foo == options.foo
    assert cli_args.bar == options.bar
    assert cli_args.baz == options.baz

# Generated at 2022-06-21 08:25:14.960391
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict_2d = {'key1': {'key1_1': 'val1_1', 'key1_2': 'val1_2'}}
    dict_1d = {'key1': 'val1', 'key2': 'val2'}
    list_1d = {'list1': ['val1', 'val2', 'val3']}
    list_2d = {'list1': ['val1', {'key2_2': 'val2_2'}, 'val3']}
    list_empty = {'list1': []}
    set_empty = {'set1': frozenset()}
    set_1d = {'set1': frozenset(['val1', 'val2', 'val3'])}

# Generated at 2022-06-21 08:25:24.036945
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    x = GlobalCLIArgs({'foo': 'bar', 'baz': 'qux'})
    assert x['foo'] == 'bar'
    assert x['baz'] == 'qux'
    assert len(x) == 2
    assert set(x.keys()) == set(['foo', 'baz'])
    assert set(x.values()) == set(['bar', 'qux'])
    assert set(x.items()) == set(dict(foo='bar', baz='qux').items())
    assert x.copy() == dict(foo='bar', baz='qux')
    assert x == dict(foo='bar', baz='qux')

    y = GlobalCLIArgs({'foo': 'bar', 'baz': 'qux'})
    assert x is y
    assert x == y


# Generated at 2022-06-21 08:25:37.906103
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Ensure that we can't modify the arguments after we pass them in
    args = {
        'boolean_flag': True,
        'none_flag': None,
        'integer_flag': 1,
        'string_flag': 'hello',
        'list_flag': ['first', 'second', 'third'],
        'dict_flag': {
            'key1': 'value1',
            'key2': 'value2',
            'key3': 'value3'
        },
        'set_flag': set('12345'),
    }
    cli_args = CLIArgs(args)

    try:
        cli_args['boolean_flag'] = False
        assert False
    except AttributeError:
        assert True


# Generated at 2022-06-21 08:25:39.484961
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton



# Generated at 2022-06-21 08:25:44.599959
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Make sure that the CLIArgs constructor accepts a dict and sets
    a field on the result that looks like the dict.
    """
    cli_args = CLIArgs({'foo': 'bar'})
    assert cli_args['foo'] == 'bar'

# Generated at 2022-06-21 08:25:46.755520
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class X(metaclass=_ABCSingleton):
        pass
    assert isinstance(X(), X)


# Generated at 2022-06-21 08:25:53.221485
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import types
    import unittest

    class TestGlobalCLIArgs(unittest.TestCase):

        def test_constructor(self):
            cliargs = GlobalCLIArgs.from_options(types.SimpleNamespace(foo='bar'))
            self.assertEqual(cliargs['foo'], 'bar')

    # Run Unit Test
    loader = unittest.TestLoader()
    tests = loader.loadTestsFromTestCase(TestGlobalCLIArgs)
    suite = unittest.TestSuite(tests)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-21 08:25:54.502846
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton
    Foo()
    Foo()

# Generated at 2022-06-21 08:26:04.345862
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # start with simple test to see if the __init__ function is ok
    test_data = {
        'test_data': [
            'test1',
            {'test2': 'test2'},
            ['test3', 'test4'],
            {'test5': set(['test6', 'test7'])},
            (1, 2, 3),
            'test8',
        ]
    }

    result = CLIArgs(test_data).copy()

    for test_key in test_data:
        assert result[test_key] == test_data[test_key]


# test for the from_options function in class CLIArgs

# Generated at 2022-06-21 08:26:07.605965
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSingletonParent(object):
        __metaclass__ = _ABCSingleton

    class TestSingletonChild(TestSingletonParent):
        pass

    instance_parent = TestSingletonParent()
    instance_child = TestSingletonChild()

    assert instance_parent is instance_child

# Generated at 2022-06-21 08:26:10.619358
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    This is a test function
    """
    input_dict = {"a": "b"}

    cliargs = CLIArgs(input_dict)
    assert cliargs == {"a": "b"}

# Generated at 2022-06-21 08:26:12.710307
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs.from_options(object()) is not None, 'Failed to create CLIArgs instance'



# Generated at 2022-06-21 08:26:27.045513
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        pass

    assert type(A) != _ABCSingleton
    assert issubclass(A, _ABCSingleton) is False
    assert isinstance(A(), _ABCSingleton) is False
    assert isinstance(A(), Singleton) is False

    class B(object):
        __metaclass__ = _ABCSingleton

    assert type(B) == _ABCSingleton
    assert issubclass(B, _ABCSingleton) is True
    assert isinstance(B(), _ABCSingleton) is True
    assert isinstance(B(), Singleton) is True

# Generated at 2022-06-21 08:26:29.444277
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    obj = GlobalCLIArgs({'hello': 'world'})
    assert obj == ImmutableDict({"hello": "world"})

# Generated at 2022-06-21 08:26:36.500624
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    obj = CLIArgs(dict(a=True, b=dict(c=True)))

    assert obj == {'a': True, 'b': {'c': True}}
    assert obj['a'] == True
    assert obj['b'] == {'c': True}
    assert obj['b']['c'] == True

    with pytest.raises(TypeError):
        obj['a'] = False
    with pytest.raises(TypeError):
        obj['b'] = False
    with pytest.raises(TypeError):
        obj['b']['c'] = False

# Generated at 2022-06-21 08:26:38.067774
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object, metaclass=_ABCSingleton):
        pass

    TestClass()  # Should not raise any exception

# Generated at 2022-06-21 08:26:50.067282
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():  # pragma: no cover
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.errors import AnsibleError

    class FooSingleton(object, metaclass=_ABCSingleton):
        pass

    class BarSingleton(FooSingleton):
        pass

    # Non-Singleton class based on FooSingleton
    class Foo(object):
        pass

    # Make sure we can't have more than one instance of our Singleton classes
    foo_singleton = FooSingleton()
    bar_singleton = BarSingleton()
    assert foo_singleton is bar_singleton

    # Make sure that we can't have more than one instance of our Singleton classes

# Generated at 2022-06-21 08:26:55.143437
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(_ABCSingleton):
        a = 1000
        def __init__(self):
            self.a = 1001
        def test(self, a):
            return 1002 + a

    assert TestClass.a == 1000
    assert TestClass().a == 1001
    assert TestClass().test(100) == 1102

# Generated at 2022-06-21 08:26:57.768487
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    test_dict = {}
    try:
        GlobalCLIArgs(test_dict)
    except TypeError:
        pass
    assert GlobalCLIArgs(test_dict) is GlobalCLIArgs.getInstance()

# Generated at 2022-06-21 08:27:04.242324
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dict = {'a': 1, 'b': [1, 2], 'c': {'a': 1}, 'd': {'a', 'b'}}
    args = CLIArgs(dict)
    # test the constructor works
    assert dict['a'] == args['a']
    assert dict['b'] == args['b']
    assert dict['c'] == args['c']
    assert dict['d'] == args['d']


# Generated at 2022-06-21 08:27:11.757897
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    program_args = {
        'lookup_plugins': '/usr/share/ansible/plugins/lookup',
        'forks': [1, 2, 3]
    }
    test_args = GlobalCLIArgs(program_args)
    assert test_args['lookup_plugins'] == [u'/usr/share/ansible/plugins/lookup']
    assert test_args['forks'] == (1, 2, 3)


# Generated at 2022-06-21 08:27:21.897650
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    assert A.__class__ == _ABCSingleton

if __name__ == '__main__':
    import unittest

    class TestCLIArgs(unittest.TestCase):
        def test_basic_list(self):
            args = CLIArgs.from_options(type('obj', (object,), {'foo': [1, 2, 3]}))
            assert args['foo'] == (1, 2, 3)
            assert isinstance(args['foo'], tuple)

        def test_list_with_list(self):
            args = CLIArgs.from_options(type('obj', (object,), {'foo': [[1, 2], 3]}))
            assert args['foo'] == ((1, 2), 3)

# Generated at 2022-06-21 08:27:36.710383
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _TestABCSingleton(metaclass=_ABCSingleton):
        pass

    _TestABCSingleton()
    _TestABCSingleton()

# Generated at 2022-06-21 08:27:39.109848
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test1(_ABCSingleton):
        pass
    class Test2(_ABCSingleton):
        pass
    assert Test1 is Test2

# Generated at 2022-06-21 08:27:47.020932
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    mapping = {'a': '1', 'b': [1, 2, 3], 'c': '2'}
    a = CLIArgs(mapping)
    mapping['c'] = '3'
    # Assert c has not changed
    assert a['c'] == '2'
    # Cannot add new element
    try:
        a['d'] = '4'
        assert False
    except TypeError:
        pass
    try:
        a['c'] = '4'
        assert False
    except TypeError:
        pass
    # Cannot change existing element
    try:
        a['b'].append(4)
        assert False
    except TypeError:
        pass

# Generated at 2022-06-21 08:27:57.897228
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs.from_options([
        '--force-handlers',
        '--connection=winrm',
        '--extra-vars', '{"author": "Dagobert", "test": 1}',
        'host.1=host1', 'host.2=host2',
        'host3',
        'host4',
        'command1'
    ])
    assert args['force_handlers'] is True
    assert args['connection'] == 'winrm'
    assert args['extra_vars'] == {'author': 'Dagobert', 'test': 1}
    assert args['host'] == ('host.1=host1', 'host.2=host2', 'host3', 'host4')
    assert args['command'] == ('command1',)

# Generated at 2022-06-21 08:28:01.852218
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _TestABCSingleton(object):
        __metaclass__ = _ABCSingleton
    x = _TestABCSingleton()
    y = _TestABCSingleton()
    assert x is y
    assert isinstance(x, _TestABCSingleton)

# Generated at 2022-06-21 08:28:11.405869
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class testclass_ABCSingleton(object):
        __metaclass__ = _ABCSingleton
    class testclass_ABCSingleton_metaclass(object):
        __metaclass__ = _ABCSingleton
    class testclass_Singleton(object):
        __metaclass__ = Singleton
    class testclass_Singleton_metaclass(object):
        __metaclass__ = Singleton
    class testclass_ABCSingleton_Singleton(object):
        __metaclass__ = _ABCSingleton
        def __init__(self, foo):
            self.foo = foo
        def bar(self):
            pass
    class testclass_Singleton_ABCSingleton(object):
        __metaclass__ = _ABCSingleton
        def __init__(self, foo):
            self.foo = foo
       

# Generated at 2022-06-21 08:28:16.018739
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    class B(A):
        pass
    assert isinstance(A(), A)
    assert isinstance(B(), A)

# Generated at 2022-06-21 08:28:23.697133
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import nose

    gca = GlobalCLIArgs({'a': 1, 'b': 'asd'})
    assert gca == {'a': 1, 'b': 'asd'}

    # Check that the second instance of GlobalCLIArgs is the same object
    gca2 = GlobalCLIArgs({'a': 1, 'b': 'asd'})
    assert gca == gca2

    # Check that we cannot overwrite the data in gca
    nose.tools.assert_raises(
        TypeError,
        gca.__setitem__, 'a', 2
    )

# Generated at 2022-06-21 08:28:26.522048
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = GlobalCLIArgs.from_options({'foo': 'bar'})
    assert GlobalCLIArgs.from_options({'foo': 'bar'}) == options

# Generated at 2022-06-21 08:28:28.852966
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _(object):
        __metaclass__ = _ABCSingleton
    class X(_):
        pass
    assert issubclass(X, _)

# Generated at 2022-06-21 08:28:58.518053
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.parsing.dataloader import DataLoader

    # This should fail as the configuration should get processed later
    args = GlobalCLIArgs()

    assert isinstance(args, CLIArgs)
    assert isinstance(args, GlobalCLIArgs)



# Generated at 2022-06-21 08:29:05.075713
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs.from_options({'connection': 'local'}) == {'connection': 'local'}
    assert CLIArgs.from_options({'connection': u'local'}) == {'connection': 'local'}
    assert CLIArgs.from_options({'connection': u'local'.encode('utf8')}) == {'connection': 'local'}
    assert CLIArgs.from_options({'connection': 'local'}) == GlobalCLIArgs.from_options({'connection': 'local'})

# Generated at 2022-06-21 08:29:17.809075
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    dict1 = {'test': 'value1', 'test1': 'value2', 'test2': 'value3'}
    dict2 = {'test': {'test1': 'value1', 'test2': 'value2', 'test3': 'value3'}, 'test1': {'test1': 'value1', 'test2': 'value2', 'test3': 'value3'}, 'test2': {'test1': 'value1', 'test2': 'value2', 'test3': 'value3'}}

# Generated at 2022-06-21 08:29:20.478936
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert isinstance(GlobalCLIArgs({}), GlobalCLIArgs)
    assert isinstance(GlobalCLIArgs({}), CLIArgs)

# Generated at 2022-06-21 08:29:29.525510
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import os

    # Build a dict of dicts to test with

# Generated at 2022-06-21 08:29:35.283986
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    # Arrange
    global_args = {}
    global_args['testarg'] = text_type('testvalue')

    # Act
    global_args = CLIArgs(global_args)

    # Assert
    # Assert.Equal(global_args.get('testarg'), "testvalue")
    # Assert.IsNone(global_args.get('wrongkey'))
    assert(global_args.get('testarg') == 'testvalue')
    assert(global_args.get('wrongkey') is None)

# Generated at 2022-06-21 08:29:46.989634
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser(description='Process some integers.')
    parser.add_argument('names', metavar='N', type=str, nargs='+', help='an integer for the accumulator')
    parser.add_argument('--sum', dest='accumulate', action='store_const',
                        const=sum, default=max, help='sum the integers (default: find the max)')
    args = parser.parse_args(['a', 'b', 'c'])
    ga = GlobalCLIArgs(vars(args))
    iargs = CLIArgs(vars(args))
    # Test that we can add arguments
    assert ga.keys() == iargs.keys()
    assert ga['names'] == iargs['names']

# Generated at 2022-06-21 08:29:55.491415
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = {'one': 'one', 'mapping': {'two': 'two'}, 'sequence': [3, 'three'], 'set': {4, 'four'}}
    cli_args = GlobalCLIArgs(args)
    assert cli_args == {'one': 'one', 'mapping': ImmutableDict({'two': 'two'}), 'sequence': (3, 'three'), 'set': frozenset({4, 'four'})}

# Generated at 2022-06-21 08:30:00.335055
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs({
        'test': 'testvalue',
        'dict': {'foo': 'bar'},
        'list': ['foo', 'bar', 'baz'],
        'set': {'foo', 'bar', 'baz'}
    })

    assert isinstance(args, CLIArgs)
    assert args['test'] == 'testvalue'
    assert args['dict'] == ImmutableDict({
        'foo': 'bar'
    })
    assert args['list'] == ('foo', 'bar', 'baz')
    assert args['set'] == frozenset(['foo', 'bar', 'baz'])

# Generated at 2022-06-21 08:30:11.287980
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils._text import to_text, to_native
    from ansible.module_utils.common.collections import is_sequence
    from ansible.module_utils.common.json_utils import jsonify


# Generated at 2022-06-21 08:31:14.088084
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(argument_spec=dict(
        foo=dict(type='str', default='bar'),
        baz=dict(type='bool', default=False),
    ))
    args = CLIArgs(vars(m._options))
    assert args['foo'] == 'bar'
    assert args['baz'] is False

    dict_like = dict(foo='bar', baz=True)
    args = CLIArgs(dict_like)
    assert args['foo'] == 'bar'
    assert args['baz'] is True
    assert args.get('baz') is True
    assert args.get('bar') is None

    dict_like = dict(foo='bar', baz=[1, 2, 3])
    args = CLIArgs(dict_like)

# Generated at 2022-06-21 08:31:19.806670
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Basic unit test to make sure all constructors work.
    """
    import sys
    import os
    import tempfile
    import subprocess
    import json

    options_py_file = tempfile.NamedTemporaryFile(mode="wt", suffix='.py')
    options_py_file.write("""
from ansible.module_utils.common.collections import ImmutableDict
ANSIBLE_ARGS=ImmutableDict({
    'delegate_to': 'test1',
    'test_list': ['test', 'test2'],
    'test_list2': ['test', 'test3'],
    'test_dict': {'test': 'test4'},
    'test_dict2': {'test': 'test5'},
    'test_int': 1
})
""")
    options

# Generated at 2022-06-21 08:31:31.180618
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Immutable mappings can only be created from other mappings or iterators
    assert isinstance(CLIArgs({'test': 'X'}), ImmutableDict)
    # Mappings can be nested to any arbitrary depth
    assert isinstance(CLIArgs({'test': {'test_2': {'test_3': 'X'}}}), ImmutableDict)
    # Immutable mappings are read-only after they are created
    try:
        CLIArgs({'test': 'Y'})['test'] = 'X'
    except TypeError:
        pass
    else:
        assert False, 'Expected exception because we are trying to change the value of a read-only dict'
    # Sequences are not mappings and an exception should be raised when one is passed in

# Generated at 2022-06-21 08:31:40.546911
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    data = {
        'one': 1,
        'two': 2,
        'three': [4, 5]
    }
    instance = CLIArgs(data)

    assert data == dict(instance)
    assert data['one'] == instance['one']
    assert data['two'] == instance['two']
    assert data['three'] == instance['three']

    data['three'].append(6)
    assert data['three'] != instance['three']
    assert data['three'][:-1] == instance['three']

    data['three'] = [1, 2, 3]
    assert data['three'] != instance['three']
    assert instance['three'] == (4, 5)

    data['three'] = (4, 5)
    assert data['three'] == instance['three']

# Generated at 2022-06-21 08:31:41.406153
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_cli_args = GlobalCLIArgs()
    assert global_cli_args is GlobalCLIArgs()



# Generated at 2022-06-21 08:31:43.461077
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    pass

# Generated at 2022-06-21 08:31:49.172385
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Base1(metaclass=_ABCSingleton):
        pass

    class Base2(metaclass=_ABCSingleton):
        pass

    class Base3(metaclass=_ABCSingleton):
        pass

    class Derived1(Base1, Base2):
        pass

    class Derived2(Base1, Base2, Base3):
        pass

# Generated at 2022-06-21 08:31:50.200747
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({'a': 'b'})

# Generated at 2022-06-21 08:31:58.809877
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _Foo(_ABCSingleton):
        pass

    class _Bar(_Foo):
        pass

    class _Baz(_Foo):
        pass

    _foo = _Foo()
    _bar = _Bar()
    _baz = _Baz()

    # Make sure the Singleton base class worked
    assert id(_bar) == id(_baz) == id(_foo)

    # Make sure the ABCMeta base class worked
    assert issubclass(_Foo, ABCMeta)
    assert issubclass(_Bar, ABCMeta)
    assert issubclass(_Baz, ABCMeta)


# Generated at 2022-06-21 08:32:01.586788
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            pass

    ts1 = TestClass()
    ts2 = TestClass()
    assert ts1 is ts2