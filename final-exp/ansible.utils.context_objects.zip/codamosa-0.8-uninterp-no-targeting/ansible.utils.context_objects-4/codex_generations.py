

# Generated at 2022-06-21 08:22:13.385951
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class FooMeta(type):
        pass

    class BarMeta(_ABCSingleton, FooMeta):
        pass



# Generated at 2022-06-21 08:22:17.162215
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs.from_options(None)
    assert isinstance(args, CLIArgs)
    assert isinstance(args, ImmutableDict)
    assert isinstance(args, Mapping)
    assert isinstance(args, GlobalCLIArgs)

# Generated at 2022-06-21 08:22:27.919126
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    x = {'foo': {'bar': [1, 2]}, 'baz': True}

    cli = CLIArgs(x)

    assert isinstance(cli, Mapping)
    assert isinstance(cli, ImmutableDict)
    assert isinstance(cli, CLIArgs)

    assert cli['foo'] == {'bar': [1, 2]}
    assert cli['baz']

    assert isinstance(cli['foo'], Mapping)
    assert isinstance(cli['foo'], ImmutableDict)

    assert cli['foo']['bar'] == [1, 2]

    assert isinstance(cli['foo']['bar'], Sequence)
    assert isinstance(cli['foo']['bar'], tuple)

    # Check for recursiveness by changing the contents of the list and seeing if
    # the

# Generated at 2022-06-21 08:22:38.550193
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.listify import listify_lookup_plugin_terms

    mock_cli_args_dict = {
        'one': 1,
        'two': 2,
        'three': 3,
        'four': 4,
        'five': 5,
        'six': 6,
        'seven': 7,
        'eight': 8,
        'nine': 9,
        'ten': 10,
        'eleven': 11,
        'twelve': 12,
        'lookup_terms': listify_lookup_plugin_terms('{{ foo }}, {{ bar }}, {{ baz }}'),
        'roles_path': 'test_roles_path'
    }
    mock_cli_args = CLIArgs(mock_cli_args_dict)

    assert mock_cli_args['one'] == 1

# Generated at 2022-06-21 08:22:44.880698
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test that the constructor produces an immutable dict
    new_dict = {"a": 1, "b": 2, "c": 3}
    new_mapping = CLIArgs(new_dict)
    new_mapping["a"] = 2
    del new_mapping["b"]
    try:
        new_mapping.update({"z": 3})
    except AttributeError:
        pass

# Generated at 2022-06-21 08:22:48.458082
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    c1 = GlobalCLIArgs.from_options(None)
    c2 = GlobalCLIArgs.from_options(None)
    assert(c1 is c2)

# Generated at 2022-06-21 08:22:52.163523
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ABCSingletonTestClass(object):
        __metaclass__ = _ABCSingleton

    class ABCSingletonTestSubclass(ABCSingletonTestClass):
        "test"

    assert ABCSingletonTestClass() == ABCSingletonTestSubclass()

# Generated at 2022-06-21 08:22:55.194750
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import ansible.cli.CLI as CLI
    parser = CLI.base_parser()
    options = parser.parse_args()
    global_args = GlobalCLIArgs()
    global_args.from_options(options)

# Generated at 2022-06-21 08:23:01.444440
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    foo = {'a': ['foo', 'bar', 'baz'], 'b': {'c': ['d', 'e'], 'f': 'g'}, 'h': ['i', 'j']}
    bar = {'a': ('foo', 'bar', 'baz'), 'b': {'c': ('d', 'e'), 'f': 'g'}, 'h': ('i', 'j')}
    assert CLIArgs(foo) == bar

# Generated at 2022-06-21 08:23:11.059254
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass1(object):
        """
        Simple test class to make sure that _ABCSingleton is working
        """
        pass

    class TestClass2(object):
        """
        Simple test class to make sure that _ABCSingleton is working
        """
        pass

    assert issubclass(TestClass1, TestClass2) is False
    assert isinstance(TestClass1(), TestClass2) is False

    class TestClass3(_ABCSingleton, TestClass1):
        """
        Simple test class to make sure that _ABCSingleton is working
        """
        pass

    class TestClass4(TestClass3, TestClass2):
        """
        Simple test class to make sure that _ABCSingleton is working
        """
        pass

    assert issubclass(TestClass4, TestClass2) is True

# Generated at 2022-06-21 08:23:17.327150
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton):
        pass

    class Bar(_ABCSingleton):
        pass

    # This is a crummy test, but it should cause an error if the bug is present
    foo = Foo.__new__(Foo)
    bar = Bar.__new__(Bar)

# Generated at 2022-06-21 08:23:24.988227
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import tempfile
    with tempfile.NamedTemporaryFile(delete=True) as tmp_f:
        options = {'host_key_checking':True,
                   'private_key_file':'/tmp/foo'}
        tmp_f.write(str(options))
        tmp_f.flush()
        cli_args = CLIArgs.from_options(options)
        assert cli_args['host_key_checking']

# Generated at 2022-06-21 08:23:33.181258
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options():
        def __init__(self):
            self.cache = False
            self.listhosts = True
            self.subset = "all"
            self.tags = ["install", "configure"]
            self.skip_tags = ["skipme","skipmetoo"]

    options = Options()
    cli_args = CLIArgs.from_options(options)
    assert cli_args["cache"] is False
    assert cli_args["listhosts"] is True
    assert cli_args["subset"] == "all"
    assert cli_args["tags"] == ("install", "configure")
    assert cli_args["skip_tags"] == ("skipme", "skipmetoo")
    # Set should be converted to frozenset
    assert isinstance(cli_args["tags"], tuple)

# Generated at 2022-06-21 08:23:34.196168
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs({})

# Generated at 2022-06-21 08:23:36.763239
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs(dict(one=1, two=2))
    assert isinstance(cli_args, CLIArgs)



# Generated at 2022-06-21 08:23:37.897274
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs(dict())

# Generated at 2022-06-21 08:23:45.976149
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli.arguments import options
    import sys
    import_errors = []
    for module in 'json', 'yaml', 'yaml.scanner', 'yaml.parser', 'yaml.composer':
        try:
            __import__(module)
        except ImportError:
            import_errors.append(module)
    if import_errors:
        sys.exit("ERROR: Missing required module(s): %s" % ', '.join(import_errors))
    GlobalCLIArgs.from_options(options)

# Generated at 2022-06-21 08:23:56.117487
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.six import iteritems, string_types

    import json
    def to_json(obj):
        """Return a representation of a value, suitable for debugging or serialization"""
        return json.dumps(obj, default=lambda o: o.__dict__, indent=2, sort_keys=True)

    def test_type(obj, expected_type):
        try:
            assert isinstance(obj, expected_type), "expected type {} but got {}: {}".format(expected_type, type(obj), to_json(obj))
            return obj
        except AssertionError as e:
            import sys
            raise AssertionError(str(e)).with_traceback(sys.exc_info()[2])

    # Test that immutable containers work

# Generated at 2022-06-21 08:24:08.117034
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.collections import ImmutableDict

    class TestMapping(Mapping):
        def __init__(self, mapping):
            self._mapping = mapping

        def __getitem__(self, item):
            return self._mapping[item]

        def __iter__(self):
            return iter(self._mapping)

        def __len__(self):
            return len(self._mapping)

    mapping = TestMapping({"a": 1, "b": {'c': 2, 'd': [1, 2, 3]}, "e": [4, 5, [6, 7]]})
    global_args = GlobalCLIArgs(mapping)
    assert type(global_args) == Imm

# Generated at 2022-06-21 08:24:09.968328
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    pass

# Generated at 2022-06-21 08:24:19.510393
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from collections import namedtuple
    def _get_options():
        Option = namedtuple("Option", "option arg help action")
        opts = {}
        for o in ("--test", "--test-int", "--test-list"):
            opts[o] = Option(option=o, arg=None, help="Test option", action="store")
        return opts

    import sys
    sys.argv = ["-t"]
    from ansible.utils.args import parse_args
    args = GlobalCLIArgs.from_options(parse_args(options=_get_options()))

    assert isinstance(args, GlobalCLIArgs)
    assert isinstance(args, ImmutableDict)

    assert args["test"] == True
    assert type(args["test"]) is bool

    # test that we can't

# Generated at 2022-06-21 08:24:30.652725
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Unit test to make sure that the constructor of class GlobalCLIArgs is working OK
    """

    # pylint: disable=unused-variable
    def _test_immutable(original, expected, should_raise=False):
        """
        Helper method to test if an object is immutable or not
        :param original: An object to be tested
        :param expected: If should_raise is false, this is the object that we expect a deep copy of
        original to be identical to
        :param should_raise: If this is True, we expect TypeError, otherwise not
        :return: None
        """
        args = dict(test=original)
        try:
            immutable_args = GlobalCLIArgs(args)
        except TypeError:
            if not should_raise:
                raise
            return

# Generated at 2022-06-21 08:24:40.327634
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    toplevel = {}
    toplevel["key1"] = "value1"
    toplevel["key2"] = {"key3": ["value3"]}
    toplevel["key4"] = ["value4"]
    toplevel["key5"] = set(["value5"])
    cliargs = CLIArgs(toplevel)
    assert cliargs["key1"] == "value1"
    assert cliargs["key2"] == ImmutableDict({"key3":tuple(["value3"])})
    assert cliargs["key4"] == ("value4",)
    assert cliargs["key5"] == frozenset(["value5"])

# Generated at 2022-06-21 08:24:46.232537
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _Foo(object):
        """A fake object to test _ABCSingleton"""
        __metaclass__ = _ABCSingleton

    class _Bar(_Foo):
        """A fake object to test _ABCSingleton"""
        pass

    try:
        class _Baz(_Foo):
            """A fake object to test _ABCSingleton"""
            __metaclass__ = ABCMeta
    except TypeError:
        print("Now _ABCSingleton is defined and tested")

# Generated at 2022-06-21 08:24:48.252104
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs(dict())

# Generated at 2022-06-21 08:24:49.537333
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # no exception should be thrown
    cli_args = GlobalCLIArgs({})

# Generated at 2022-06-21 08:24:51.635803
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    x = GlobalCLIArgs(dict(foo="bar"))
    assert x.get('foo') == 'bar'


# Generated at 2022-06-21 08:25:01.784381
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class options(object):
        def __init__(self, vars):
            for key, value in vars.items():
                setattr(self, key, value)

    opt1 = options({'test1': {'boolvar': True,
                              'intvar': 36,
                              'listvar': ['item1', 'item2'],
                              'dictvar': {'sub1': 'value1',
                                          'sub2': ['value2', 'value3']},
                              'setvar': ['item3', 'item4']}
                    })
    args = CLIArgs(vars(opt1))
    assert args['test1']['boolvar'] is True
    assert args['test1']['intvar'] == 36

# Generated at 2022-06-21 08:25:05.558540
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs.reset()
    assert GlobalCLIArgs.__instance__ is None
    GlobalCLIArgs({"foo": "bar"})
    assert GlobalCLIArgs.__instance__ is not None
    assert GlobalCLIArgs.__instance__.get("foo") == "bar"



# Generated at 2022-06-21 08:25:15.095437
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    initial_toplevel = [{'key': 'value'}, {'key1': 'value1', 'key2': 'value2'}, 3, 'string', ['list'], ('tuple',), {'set': 'set'}]
    for item in initial_toplevel:
        global_args = GlobalCLIArgs.from_options(item)
        # global_args is an ImmutableDict, so it can't be modified
        assert not isinstance(global_args, Mapping)
        assert not isinstance(global_args, Sequence)
        assert not isinstance(global_args, Set)

# Generated at 2022-06-21 08:25:25.605231
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """Make sure metaclass ordering is correct"""
    class _Foo(object):
        __metaclass__ = _ABCSingleton
    class _Bar(object):
        __metaclass__ = _ABCSingleton

    assert issubclass(_Bar, _Foo)

# Generated at 2022-06-21 08:25:30.264435
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class C1(object):
        __metaclass__ = _ABCSingleton

    class C2(object):
        __metaclass__ = _ABCSingleton

    assert C1() is C1()
    assert C1() is C2()

# Generated at 2022-06-21 08:25:37.861712
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test the CLIArgs constructor
    """
    cliargs = CLIArgs({'one': {'two': {'three': ['a', 'b', 'c']}}})

    assert isinstance(cliargs, ImmutableDict)
    assert isinstance(cliargs['one'], ImmutableDict)
    assert isinstance(cliargs['one']['two'], ImmutableDict)
    assert isinstance(cliargs['one']['two']['three'], tuple)
    assert cliargs == {'one': {'two': {'three': ('a', 'b', 'c')}}}


# Generated at 2022-06-21 08:25:48.181026
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # pylint: disable=attribute-defined-outside-init
    class TestGlobalCLIArgs(GlobalCLIArgs):
        def __init__(self, *args, **kwargs):
            self.instance = None
            super(TestGlobalCLIArgs, self).__init__(*args, **kwargs)

        def __call__(self, *args, **kwargs):
            if self.instance is None:
                self.instance = super(TestGlobalCLIArgs, self).__call__(*args, **kwargs)
            return self.instance

    cli_args = TestGlobalCLIArgs({'foo': 'bar'})
    assert cli_args is cli_args()
    assert cli_args is TestGlobalCLIArgs()

# Generated at 2022-06-21 08:25:54.827027
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Create a mutable dictionary
    mutable_dict = {'a': 'hello', 'b': 'world'}
    # Create an instance of CLIArgs by passing the mutable_dict
    args = CLIArgs(mutable_dict)
    # Assert that the instance is not mutable
    assert isinstance(args, ImmutableDict)
    # Assert that the arguments are as per the mutable_dict
    assert args.get('a') == 'hello'
    assert args.get('b') == 'world'

# Generated at 2022-06-21 08:26:04.739975
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    o = {
        'a': 'one',
        'b': [1, 2, 3],
        'c': {
            'a': 'one',
            'b': [1, 2, 3],
            'c': 'two'
        }
    }

    args = CLIArgs.from_options(o)
    assert args['a'] == 'one'
    assert args['b'] == (1, 2, 3)
    assert args['c']['a'] == 'one'
    assert args['c']['b'] == (1, 2, 3)
    assert args['c']['c'] == 'two'



# Generated at 2022-06-21 08:26:14.578766
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Unit test for CLIArgs"""
    test_options = ['--list-hosts', '--vault-password-file', './ansible.cfg', '--vault-id', 'test@prompt', 'inventory', '--vault-password-file', 'test.pass', '--vault-id', 'test@prompt', '--syntax-check']
    from ansible.cli import CLI
    from ansible.parsing.splitter import split_args


# Generated at 2022-06-21 08:26:18.812905
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import ansible.constants as C
    from ansible.cli.galaxy import GalaxyCLI

    my_cli = GalaxyCLI(command='all', args=[])
    cli_args = GlobalCLIArgs.from_options(my_cli.parser.parse_args())
    assert cli_args is GlobalCLIArgs.instance()
    assert cli_args['debug'] == C.DEFAULT_DEBUG

# Generated at 2022-06-21 08:26:21.055663
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    assert type(A) is _ABCSingleton



# Generated at 2022-06-21 08:26:31.291517
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Make a sample dictionary that we can convert to a CLIArgs object
    sample_dict = {"key1": {"key2": {"key3": "value3"}}}

    # Make a new CLIArgs object out of the sample dict
    temp_args = CLIArgs(sample_dict)

    # Check that the sample dict and temp args are equivalent
    assert sample_dict == temp_args

    # Make a new dict that isn't the same as the original
    new_dict = {'key1': temp_args['key1']}

    # Check that the new dict isn't the same as the original
    assert new_dict != sample_dict

    # Check that the new dict is the same as the new CLIArgs object
    assert new_dict == temp_args


# Generated at 2022-06-21 08:26:52.044573
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    classes = (
        _ABCSingleton('test_ABCSingleton_A', (), {}),
        _ABCSingleton('test_ABCSingleton_B', (), {}),
        _ABCSingleton('test_ABCSingleton_C', (), {}),
    )
    for cls in classes:
        assert cls.__abstractmethods__ == set(), '%s.__abstractmethods__ == set()' % repr(cls)
        assert issubclass(cls, ABCMeta), 'issubclass(%s, ABCMeta)' % repr(cls)
    assert len(set(classes)) == 1, 'Only one thing should be returned'

# Generated at 2022-06-21 08:27:01.014428
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import os
    import re
    import tempfile

    class TestArgs(object):
        _ansible_module_list = False
        _ansible_module_name = "ping"
        _ansible_module_name_prefix = 'ansible.module_utils.'
        _ansible_module_name_prefix_sep = '.'
        become = None
        become_ask_pass = False
        become_user = None
        check = False
        connection = "smart"
        create_dirs = True
        diff = False
        extra_vars = []
        force_handlers = False
        force_pipelining = False
        forks = 100
        help = False
        private_key_file = None
        inventory = ["/etc/ansible/hosts"]
        listhosts = None
        listtasks = False

# Generated at 2022-06-21 08:27:07.915599
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyABCSingleton(_ABCSingleton):
        pass

    class MySingletonSingleton(MyABCSingleton):
        pass

    class MyABCMetaSingleton(MyABCSingleton):
        pass

    assert issubclass(MyABCSingleton, Singleton)
    assert issubclass(MyABCSingleton, ABCMeta)
    assert issubclass(MySingletonSingleton, Singleton)
    assert issubclass(MySingletonSingleton, ABCMeta)
    assert issubclass(MyABCMetaSingleton, Singleton)
    assert issubclass(MyABCMetaSingleton, ABCMeta)

test__ABCSingleton()

# Generated at 2022-06-21 08:27:19.864339
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import copy
    import sys
    import unittest

    class TestCLIArgs(unittest.TestCase):

        def setUp(self):
            # Create a deepcopy of sys.modules so that we can reset it
            # before each test.
            self.sys_modules = copy.deepcopy(sys.modules)

        def tearDown(self):
            # Reset.
            #
            # Doing this with copy.deepcopy instead of dict.copy() makes sure that any
            # changes to the sys.modules dict in one test don't carry over to another.
            sys.modules = copy.deepcopy(self.sys_modules)

        def test_singleton(self):
            """
            Make sure that we only can create one instance of the singleton
            """
            from ansible.utils.args import CLIArgs

            # We should be

# Generated at 2022-06-21 08:27:23.400418
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    result = CLIArgs.from_options(MockOptions())
    assert isinstance(result, CLIArgs)
    assert result.foo == 'bar'
    assert result.bar == 'foo'
    assert result.baz == 1



# Generated at 2022-06-21 08:27:28.148885
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.utils.encrypt import do_encrypt, do_decrypt
    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor
    from ansible.parsing.dataloader import DataLoader
    from ansible.cli import CLI

    test_vault_password = u'$ANSIBLE_VAULT;1.1;AES256\n' \
                            '31343038646632323564663535623133313662643936663062363261623931646265653433353831\n' \
                            '3564663033626663353132383933633838333564396537643339356430623365\n'
    vault = VaultLib([], None, 1)
   

# Generated at 2022-06-21 08:27:30.601223
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    assert len({id(A()), id(A())}) == 1

# Generated at 2022-06-21 08:27:42.011700
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import MutableMapping

    test_dict = MutableMapping()

# Generated at 2022-06-21 08:27:47.489738
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestABCSingleton(object, metaclass=_ABCSingleton):
        pass

    class TestABCSingleton2(TestABCSingleton):
        pass

    class TestABCSingleton3(TestABCSingleton):
        pass

    assert isinstance(TestABCSingleton(), TestABCSingleton)
    assert isinstance(TestABCSingleton2(), TestABCSingleton2)
    assert isinstance(TestABCSingleton3(), TestABCSingleton3)



# Generated at 2022-06-21 08:27:58.630064
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    mapping = {
        'foo': 'bar',
        'baz': {'another': 'dict'},
        'list': ['yes', 'it', 'is']
    }

    args = GlobalCLIArgs.from_options(mapping)

    # Make sure mapping is unchanged
    assert mapping['foo'] == 'bar'
    assert mapping['baz']['another'] == 'dict'
    assert mapping['list'][1] == 'it'

    # Make sure we have an ImmutableDict, not a dict
    assert isinstance(args, ImmutableDict)

    # Make sure we can access things via the singleton
    assert args['foo'] == 'bar'
    assert args['baz']['another'] == 'dict'
    assert args['list'][1] == 'it'

    # Make sure we can access

# Generated at 2022-06-21 08:28:28.009594
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({
        'a': 'b',
        'c': {
            'd': 'e',
            'f': [
                'g',
                'h',
            ],
        },
    })
    assert(args == {
        'a': 'b',
        'c': ImmutableDict({
            'd': 'e',
            'f': tuple(['g', 'h']),
        }),
    })



# Generated at 2022-06-21 08:28:35.728765
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.collections import is_immutable
    from ansible.module_utils.common.text.converters import to_bytes, to_text
    import copy
    import sys


    # Need to convert our command line arguments to a dictionary before we can use it.

    # Gather the command line arguments, making sure that we had no errors
    arguments = sys.argv[1:]
    test_parsed, test_errors = GlobalCLIArgs.parse(arguments, error_on_unknown_args=False)

    # If we had errors, print out the error and exit the program
    if test_errors:
        sys.stderr.write("%s\n" % ("\n".join(test_errors)))

# Generated at 2022-06-21 08:28:46.597929
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(ImmutableDict):
        pass

    class B(A):
        pass

    assert A.__mro__ == (A, ImmutableDict, object)
    assert isinstance({}, A)
    assert not isinstance({}, B)

    class C(A, metaclass=_ABCSingleton):
        pass

    assert C.__mro__ == (C, ImmutableDict, object)
    assert isinstance({}, C)

    class D(ImmutableDict, metaclass=_ABCSingleton):
        pass

    assert D.__mro__ == (D, ImmutableDict, object)
    assert isinstance({}, D)

    class E(metaclass=_ABCSingleton):
        pass

    assert E.__mro__ == (E, object)

# Generated at 2022-06-21 08:28:52.049833
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Make sure we can construct an instance of GlobalCLIArgs from a parsed command line
    """
    from ansible.cli import CLI
    global_args = GlobalCLIArgs.from_options(CLI.base_parser(['ansible', '--version']).parse_args())
    assert isinstance(global_args, GlobalCLIArgs)

# Generated at 2022-06-21 08:29:00.593575
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import types
    import sys

    # Make sure that there is only one instance of GlobalCLIArgs
    g1 = getattr(sys.modules[__name__], 'GlobalCLIArgs')
    # Need to use hasattr here because __special__ is not always in __dict__
    assert hasattr(g1, types.__special__)
    assert vars(g1).get(types.__special__) == Singleton.__special__
    g2 = getattr(sys.modules[__name__], 'GlobalCLIArgs')
    assert g1 is g2


# Generated at 2022-06-21 08:29:09.342956
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import unittest
    import argparse

    class TestGlobalCLIArgs(unittest.TestCase):

        def test_simple(self):
            # GlobalCLIArgs is a singleton
            option_parser = argparse.ArgumentParser()
            option_parser.add_argument('--test-arg', action='store', dest='test_arg', help='test arg')
            option_parser.add_argument('--test-arg2', action='store', dest='test_arg2', help='test arg2')
            options = option_parser.parse_args(['--test-arg', 'hello'])
            # pylint: disable=protected-access
            GlobalCLIArgs.__new__ = CLIArgs.__new__
            # pylint: enable=protected-access
            GlobalCLIArgs.from_options(options)


# Generated at 2022-06-21 08:29:13.007062
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _One(object):
        __metaclass__ = _ABCSingleton

    class _Two(object):
        __metaclass__ = _ABCSingleton

    _One()
    _Two()
    _Two()

# Generated at 2022-06-21 08:29:22.650691
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    from types import ModuleType
    from . import action


    # Standard use case
    assert isinstance(CLIArgs(), CLIArgs)
    assert isinstance(GlobalCLIArgs(), CLIArgs)
    assert isinstance(GlobalCLIArgs(), GlobalCLIArgs)

    # Correctly handles inheritance
    class module(ModuleType):
        pass

    assert isinstance(module, module)

    # Does not mess up old use case
    assert isinstance(action, type)

    # Does not mess up new use case
    assert isinstance(GlobalCLIArgs(), type)
    assert isinstance(CLIArgs(), type)


# Unit tests for GlobalCLIArgs

# Generated at 2022-06-21 08:29:32.961551
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Test basic operation
    class Foo(_ABCSingleton):
        pass

    assert isinstance(Foo(), Foo)

    # Test that singleton works
    x = Foo()
    y = Foo()
    assert x is y

    # Test that ABCMeta works
    class Bar(Foo):
        pass

    assert isinstance(Bar(), Bar)
    assert isinstance(Bar(), Foo)
    assert issubclass(Bar, Foo)

    # Test that inheritance works
    class Foo2(_ABCSingleton):
        foo = 1
    class Bar2(Foo2):
        pass

    assert Foo2.foo == Bar2.foo

# Generated at 2022-06-21 08:29:34.202495
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import doctest
    doctest.testmod(verbose=True)


# Generated at 2022-06-21 08:30:23.929380
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    GlobalCLIArgs.__new__(GlobalCLIArgs, {"a": 1, "b": {"c": 2, "d": [3], "f": {"g": 4}}})

# Generated at 2022-06-21 08:30:34.249819
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    sample_args = {
        'key': 'value',
        'key2': ['list', 'of', 'values'],
        'key3': ['list', 'of', 'list', ['of', 'list']],
        'key4': { 'dictionary': 'of values' },
        'key5': { 'dictionary': 'of dictionary', 'inside': {'dictionary': 'of values, again' } },
        'key6': { 'dictionary': 'of list, again', 'inside': ['of', 'list, again'] },
    }
    cli_args = CLIArgs(sample_args)
    assert isinstance(cli_args, CLIArgs)
    assert not isinstance(cli_args, GlobalCLIArgs)
    assert isinstance(cli_args, dict)

# Generated at 2022-06-21 08:30:37.511542
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    cli_args = CLIArgs({"foo": {"bar": "baz"}})
    assert cli_args["foo"] == ImmutableDict({"bar": "baz"})
    assert cli_args["foo"]["bar"] == "baz"

# Generated at 2022-06-21 08:30:39.553515
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        pass
    class B(A):
        __metaclass__ = _ABCSingleton
    assert issubclass(B, Singleton)

# Generated at 2022-06-21 08:30:41.848607
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    value = {"key": "value"}
    cliargs = CLIArgs(value)
    assert cliargs["key"] == "value"

# Generated at 2022-06-21 08:30:43.313028
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    o = CLIArgs({'a':'b'})

# Generated at 2022-06-21 08:30:54.891911
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs({}) == ImmutableDict({})
    assert CLIArgs(dict(a=1, b=2)) == ImmutableDict(dict(a=1, b=2))
    assert CLIArgs(dict(a=1, b=[2, 3])) == ImmutableDict(dict(a=1, b=(2, 3)))
    assert CLIArgs(dict(a=1, b=(2, 3))) == ImmutableDict(dict(a=1, b=(2, 3)))
    assert CLIArgs(dict(a=1, b=[2, [3, 4]])) == ImmutableDict(dict(a=1, b=(2, (3, 4))))

# Generated at 2022-06-21 08:30:57.371690
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _SubClass(_ABCSingleton):
        pass

    assert issubclass(_SubClass, Singleton)
    assert issubclass(_SubClass, ABCMeta)

# Generated at 2022-06-21 08:31:02.718162
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Unit test for constructor of class _ABCSingleton()
    """
    @add_metaclass(_ABCSingleton)
    class MySubclass(_ABCSingleton):
        pass

    instance1 = MySubclass()
    assert isinstance(instance1, MySubclass)

    instance2 = MySubclass()
    assert isinstance(instance2, MySubclass)

# Generated at 2022-06-21 08:31:05.268776
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    Foo()

