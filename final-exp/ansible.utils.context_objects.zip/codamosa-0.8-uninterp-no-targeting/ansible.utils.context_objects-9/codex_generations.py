

# Generated at 2022-06-21 08:22:24.060197
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    testd = {'a': 1, 'b': set([2, 3])}
    test_ref = {'a': 1, 'b': frozenset({2, 3})}
    test_obj = set([4, 5])
    test_ref_obj = {4, 5}
    testd['c'] = test_obj
    test_ref['c'] = frozenset(test_ref_obj)

    testd = CLIArgs(testd)
    assert isinstance(testd, ImmutableDict)
    for key, value in testd.items():
        if isinstance(value, ImmutableDict):
            for k, v in test_ref[key].items():
                assert testd[key][k] == test_ref[key][k]

# Generated at 2022-06-21 08:22:32.947535
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class MyABCSingleton(metaclass=_ABCSingleton):
        pass

    class MyABCSingleton2(MyABCSingleton):
        pass

    class MyABCSingleton3(MyABCSingleton):
        pass

    # Test for singletonness
    assert isinstance(MyABCSingleton(), MyABCSingleton)
    assert isinstance(MyABCSingleton(), MyABCSingleton2)
    assert isinstance(MyABCSingleton(), MyABCSingleton3)
    assert MyABCSingleton2() == MyABCSingleton3()
    assert MyABCSingleton() == MyABCSingleton2()
    assert MyABCSingleton() == MyABCSingleton3()

    # Test for ABCMeta inheritance
    m1 = MyABCSingleton()
    assert m1.__class__ == MyABCSingleton

# Generated at 2022-06-21 08:22:37.623896
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test CLIArgs
    """
    cli_args = CLIArgs.from_options(options=CLIFakeOptions())
    assert cli_args == {'example_key': 'example_value', 'example_list_key': ['value1', 'value2']}



# Generated at 2022-06-21 08:22:50.377253
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    global_args_dict = {'check': False,
                        'diff': True,
                        'module_args': {'a': 'test', 'b': 'test', 'c': 'test', 'd': 'test'},
                        'module_path': '.',
                        'no_log': False,
                        'playbook_dir': '/Users/ouyang/Desktop/ansible',
                        'syntax': False,
                        'tags': [],
                        'truncate': 0,
                        'vault_password_file': None,
                        'vault_identity_list': None,
                        'vault_prompt': False,
                        'version': False,
                        'warnings': False}

    cli_args = CLIArgs.from_options(global_args_dict)
    print(cli_args.keys())
    print

# Generated at 2022-06-21 08:22:58.708983
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class OriginalGlobalCLIArgs(CLIArgs):
        pass

    original_global_cliargs = OriginalGlobalCLIArgs({'foo': 'bar'})
    assert original_global_cliargs.__class__.__name__ == 'OriginalGlobalCLIArgs'

    global_cliargs = GlobalCLIArgs({'foo': 'bar'})
    assert global_cliargs.__class__.__name__ == 'GlobalCLIArgs'

    def create_GlobalCLIArgs(*args, **kwargs):
        return GlobalCLIArgs(*args, **kwargs)

    with pytest.raises(TypeError):
        create_GlobalCLIArgs()

# Generated at 2022-06-21 08:23:07.832408
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from .cli import CLI
    from .common_argparser import create_common_parser
    from .connection import Connection

    parser = create_common_parser(
        Connection,
        '2.0',
        'Ansible Runner test')
    options = parser.parse_args()

    cli = CLI(
        options=options,
    )

    # Unit test case: ``Run GlobalCLIArgs() constructor''
    # Check whether the GlobalCLIArgs() constructor runs successfully.
    # Arrange
    test_input = cli.options

    # Act
    actual_result = GlobalCLIArgs(test_input)

    # Assert
    assert actual_result is not None

# Generated at 2022-06-21 08:23:13.709429
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingletonABCBase(object):
        __metaclass__ = _ABCSingleton

        def __init__(self, a):
            self.a = a

    class SingletonABCChild(SingletonABCBase):
        def __init__(self, a, b):
            super(SingletonABCChild, self).__init__(a)
            self.b = b

    instance = SingletonABCChild(1, 2)
    new_instance = SingletonABCChild(3, 4)
    assert instance is new_instance
    assert instance.a == 1
    assert new_instance.a == 1
    assert instance.b == 2
    assert new_instance.b == 2

# Generated at 2022-06-21 08:23:22.809543
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser(prog='test_GlobalCLIArgs')
    parser.add_argument('--test', action='store_true')
    args = parser.parse_args()
    GlobalCLIArgs.from_options(args)
    assert GlobalCLIArgs().get('test') == True
    # Test for expected exception
    try:
        GlobalCLIArgs().pop('test')
    except TypeError as e:
        print(e)
        assert True
    else:
        assert False

# Generated at 2022-06-21 08:23:32.181473
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import unittest

    # Create a new GlobalCLIArgs object
    from ansible.cli.arguments import ArgumentParser
    parser = ArgumentParser()
    parser.parse_args()
    args = GlobalCLIArgs(vars(parser.args))

    # Look for a command line flag
    if 'verbosity' in args:
        verbosity = int(args['verbosity'])
    else:
        verbosity = None

    # Define a test object
    class MyTestObject(unittest.TestCase):
        def test_something(self):
            self.assertEqual(verbosity, 0)
            sys.exit(not self.test_something.__doc__)

    # Find tests and run them
    loader = unittest.TestLoader()

# Generated at 2022-06-21 08:23:43.880149
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options:
        pass

    # Create an option object with different data types
    options = Options()
    options.foo = True
    options.bar = False
    options.baz = 1
    options.qux = 'a'
    options.quux = ['b', 'c']
    options.corge = {'d': 0}
    options.grault = {0, 1}
    # Convert options to a GlobalCLIArgs object
    data = GlobalCLIArgs.from_options(options)
    # Check the length of data
    assert len(data) == 7
    # Check the value of length of data
    assert len(data) == 7
    # Check the value of data

# Generated at 2022-06-21 08:23:52.948568
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-21 08:24:02.108599
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    d = {'abc': [10, 20, 30], 'def': {'key': {'subkey': 'subval'}, 'subsubkey': 'subsubvalue'}}
    args = GlobalCLIArgs(d)

    assert isinstance(args['def'], ImmutableDict)
    assert isinstance(args['def']['subsubkey'], text_type)
    assert args['def']['subsubkey'] == 'subsubvalue'

    # Can't modify the contents of a object that is an instance of GlobalCLIArgs
    try:
        args['def']['subsubkey'] = 'subsubvalue2'
    except TypeError as e:
        assert isinstance(e, TypeError)
        assert "object does not support item assignment" in str(e)

# Generated at 2022-06-21 08:24:09.460038
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    Unit test for constructor of class GlobalCLIArgs
    """
    if GlobalCLIArgs._singleton_instance is None:
        GlobalCLIArgs.__metaclass__._singleton_instance = GlobalCLIArgs()

    # call the private constructor for testing
    GlobalCLIArgs()._new_instance({'foo': ['bar', 'baz']})
    assert(GlobalCLIArgs().get('foo') == ('bar', 'baz'))

# Generated at 2022-06-21 08:24:19.218697
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Unit test for constructor of class CLIArgs"""

    # Check that a module option is converted to an ImmutableDict
    module_option = CLIArgs.from_options(ImmutableDict(dict(ANSIBLE_MODULE_ARGS={'ansible_module_args': 'ansible_module_args'})))
    assert 'ANSIBLE_MODULE_ARGS' in module_option
    assert module_option['ANSIBLE_MODULE_ARGS'] == ImmutableDict(dict(ansible_module_args='ansible_module_args'))

    # Check that a module option with a list is converted to an ImmutableDict

# Generated at 2022-06-21 08:24:21.848150
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestClass(object):
        __metaclass__ = _ABCSingleton

    a = TestClass()
    b = TestClass()

    assert a is b

# Generated at 2022-06-21 08:24:29.156717
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        pass

    class B(A):
        __metaclass__ = _ABCSingleton
        pass

    class C(A):
        pass

    assert A() != A()
    # Both A() and B() have __metaclass__ = _ABCSingleton.  So they should both be singletons.
    assert A() == B()
    # C() has a different metaclass than A() and B() so it should not be a singleton
    assert A() != C()

# Generated at 2022-06-21 08:24:37.202304
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test CLIArgs class constructor

    Verify that the class constructor passes a tuple to the super class constructor.
    """

    mapping = {'a': True, 'b': 123, 'c': 'string'}
    test_cli_args = CLIArgs(mapping)

    assert isinstance(test_cli_args, ImmutableDict)
    assert isinstance(test_cli_args, CLIArgs)
    assert test_cli_args == ImmutableDict({'a': True, 'b': 123, 'c': 'string'})


# Generated at 2022-06-21 08:24:47.107003
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    mapping = {
        'some_flag': True,
        'some_other_flag': False,
        'some_unrelated_flag': None,
        'some_mapping': {
            'key': 'value',
            'a_list': [None, True, 1, 'a'],
            'a_dict': {'a': 'dict', 'nested': {'inside': 'a dict'}},
            'a_set': {None, True, 1, 'a'}
        }
    }

    args = GlobalCLIArgs(mapping)

    assert args == mapping
    assert args.some_flag is True
    assert args.some_other_flag is False
    assert args.some_unrelated_flag is None
    assert args.some_mapping == mapping['some_mapping']
    assert args.some

# Generated at 2022-06-21 08:24:48.344946
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    pass


# Generated at 2022-06-21 08:24:51.189081
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    mapping = {'foo': 'bar'}
    assert isinstance(GlobalCLIArgs(mapping), CLIArgs)
    assert GlobalCLIArgs(mapping)['foo'] == 'bar'


# Generated at 2022-06-21 08:25:02.738235
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    x = CLIArgs({'a': 'b', 'c': {'d': 'e'}, 'f': ['g', 'h']})
    assert isinstance(x, Mapping)
    assert x['a'] == 'b'
    assert isinstance(x['c'], Mapping)
    assert x['c']['d'] == 'e'
    assert isinstance(x['f'], Sequence)
    assert x['f'][0] == 'g'
    assert x['f'][1] == 'h'

    # Make sure __init__ doesn't modify the arguments
    y = {'a': 'b', 'c': {'d': 'e'}, 'f': ['g', 'h']}
    z = CLIArgs(y)

# Generated at 2022-06-21 08:25:12.091507
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    from ansible.cli import CLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()

    play_context = PlayContext()
    cli_options = CLI.base_parser(constants=CLI._get_constants(), usage=CLI.base_parser.usage)
    options, args = cli_options.parse_args([])
    options.extra_vars = ['@/tmp/test.yml']
    options.inventory = '/tmp/test.ini'
    options.subset = 'test'
    options.module_path = ''
    options.forks = 10
    options.become = True
    options.become_method = 'sudo'

# Generated at 2022-06-21 08:25:23.110635
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    options = {
        'host_pattern': ['localhost'],
        'module_path': ['/root/ansible/modules'],
        'private_key_file': ['id_rsa'],
        'verbosity': 5,
        'forks': 5,
        'foo': 'bar',
        'bam': ['baz', 'buz'],
        'mutable': [{'a': 'b'}],
    }
    args = CLIArgs.from_options(options)
    assert args.get('host_pattern') == ('localhost',)
    assert args.get('module_path') == ('/root/ansible/modules',)
    assert args.get('private_key_file') == ('id_rsa',)
    assert args.get('verbosity') == 5

# Generated at 2022-06-21 08:25:27.311203
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton
    a = Foo()
    b = Foo()
    assert a is b, 'Foo failed to use _ABCSingleton'

# Generated at 2022-06-21 08:25:33.165733
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class ExampleSingleton(with_metaclass(_ABCSingleton)):
        def __init__(me):
            pass

    class ExampleSingleton2(with_metaclass(_ABCSingleton)):
        def __init__(me):
            pass

    assert ExampleSingleton() == ExampleSingleton()
    assert id(ExampleSingleton()) == id(ExampleSingleton())

    # Make sure two subclasses with the same metaclass are not equal
    assert ExampleSingleton() != ExampleSingleton2()

# Generated at 2022-06-21 08:25:44.086238
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class TestSubclass(Singleton):
        pass

    class TestSubclass2(Singleton, ABCMeta):
        pass

    class TestSubclass3(TestSubclass):
        pass

    assert issubclass(TestSubclass3, TestSubclass), "Subclass didn't inherit from superclass"
    assert not issubclass(TestSubclass2, TestSubclass), "Incorrect class inheritence"
    assert issubclass(_ABCSingleton, ABCMeta), "ABCMeta class not inherited by _ABCSingleton"
    assert issubclass(_ABCSingleton, Singleton), "Singleton class not inherited by _ABCSingleton"
    assert not issubclass(TestSubclass, _ABCSingleton), "Incorrect class inheritance"
    assert not issubclass(TestSubclass2, _ABCSingleton), "Incorrect class inheritence"
    assert not iss

# Generated at 2022-06-21 08:25:53.090502
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.six import StringIO

    from ansible.module_utils import basic
    from ansible.module_utils.common._collections_compat import (Container, Mapping, Sequence, Set)

    class Parser(basic.AnsibleModule):
        def __init__(self, argspec, **kwargs):
            super(Parser, self).__init__(argument_spec=argspec, **kwargs)


# Generated at 2022-06-21 08:25:56.802033
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        pass

    class Test2(_ABCSingleton):
        pass

    Test2()
    Test2()
    assert id(Test()) == id(Test())
    assert id(Test2()) == id(Test2())
    assert id(Test()) != id(Test2())

# Generated at 2022-06-21 08:26:05.166538
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Y(metaclass=_ABCSingleton):
        pass
    class Y2(metaclass=_ABCSingleton):
        pass
    y = Y()
    y2 = Y2()
    assert isinstance(y, Y)
    # This is pretty much what the error would look like if the class wasn't made right.
    # It is much more verbose than a normal isinstance error.
    # This test is very important because that is the whole reason we needed to make this in the first place.
    assert isinstance(y, Y2) == False

# Generated at 2022-06-21 08:26:15.014075
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from ansible.module_utils.common.collections import AnsibleMapping
    import json

    # Test normal init
    args = CLIArgs(AnsibleMapping({'hello': 'world', 'foo': 'bar'}))

    # Test classmethod from_options
    class Options(object):
        pass
    opts = Options()
    opts.hello = 'world'
    opts.foo = 'bar'
    args = CLIArgs.from_options(opts)

    # Test that it is immutable
    assert isinstance(args, CLIArgs)
    # This is what we are testing
    try:
        args['hello'] = 'not world'
    except TypeError:
        pass
    else:
        # Should not get here
        raise AssertionError("CLIArgs mutation should fail")

    # Test that we

# Generated at 2022-06-21 08:26:23.842916
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():

    class Ancestor(object):
        pass

    class Descendant(Ancestor):
        __metaclass__ = _ABCSingleton

        def __init__(self):
            self.value = 42

    d1 = Descendant()
    d2 = Descendant()

    assert id(d1) == id(d2)
    assert d1.value == d2.value

# Generated at 2022-06-21 08:26:27.152742
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    assert GlobalCLIArgs.instance() == GlobalCLIArgs.instance()
    assert GlobalCLIArgs.instance() != CLIArgs({})
    assert GlobalCLIArgs.instance() == CLIArgs.instance()

# Generated at 2022-06-21 08:26:36.381925
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    args = argparse.Namespace()
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar', action='append')
    parser.add_argument('--baz', type=int)
    parser.parse_args(['--foo', 'foo_value', '--bar', 'a', '--bar', 'b', '--baz', '99'], namespace=args)
    global_cli_args = GlobalCLIArgs.from_options(args)
    assert global_cli_args['foo'] == 'foo_value'
    assert global_cli_args['bar'] == ('a', 'b')
    assert global_cli_args['baz'] == 99

# Generated at 2022-06-21 08:26:38.989502
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    @add_metaclass(_ABCSingleton)
    class test_class(Singleton):
        pass

    test_singleton = test_class()

# Generated at 2022-06-21 08:26:42.477604
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():

    import pytest

    GCA = GlobalCLIArgs({'a': 'b'})

    with pytest.raises(TypeError):
        GlobalCLIArgs({'a': 'b'})

# Generated at 2022-06-21 08:26:50.272581
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    s_dict = {"a": "b", "c": "d", "e": ["f", "g"], "h": {"i": "j"}}
    c = CLIArgs(s_dict)
    for key, value in c.items():
        if key == "e":
            assert c[key] == ("f", "g")
        elif key == "h":
            assert c[key] == ImmutableDict({"i": "j"})
        else:
            assert c[key] == value

# Generated at 2022-06-21 08:26:59.853485
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    d = {
        'a': set([1, 2, 3]),
        'b': {
            'c': {
                '1': text_type('str'),
                '2': binary_type('binary'),
                '3': [1, [2, 3], 4, 5],
            },
        },
    }

    # The dictionary container types and contents should not change
    a = CLIArgs(d)
    assert a == d
    # But the container and content types should be converted
    assert isinstance(a, ImmutableDict)
    assert isinstance(a['a'], frozenset)
    assert not isinstance(a['b'], dict)
    assert not isinstance(a['b']['c'], dict)
    assert isinstance(a['b']['c'], ImmutableDict)

# Generated at 2022-06-21 08:27:01.913211
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.display import Display
    GlobalCLIArgs.from_options(Display)

# Generated at 2022-06-21 08:27:09.769931
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Make sure CLIArgs makes a deep copy and then marks it as immutable
    """
    import copy
    import sys
    import unittest
    from contextlib import contextmanager

    # setup
    class_under_test = CLIArgs.__class__
    class_under_test_name = class_under_test.__name__
    class_under_test_instance_name = '_%s__instance' % class_under_test_name

    mutable_dict = {
        'complex_key': {
            'complex_key': {
                'simple_key': 'simple_value'
            }
        }
    }
    original_mutable_dict = copy.deepcopy(mutable_dict)
    mutable_list = ['hello', 'world']

# Generated at 2022-06-21 08:27:13.424902
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    immutable_dict = CLIArgs({'foo': 'bar'})
    assert isinstance(immutable_dict, ImmutableDict)
    assert immutable_dict['foo'] == 'bar'

# Generated at 2022-06-21 08:27:26.468011
# Unit test for constructor of class GlobalCLIArgs

# Generated at 2022-06-21 08:27:34.357105
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import pytest
    from ansible.cli.arguments import get_default_args

    # Using pytest fixture to be able to pass the optional arguement 'default_args' to ansible_runner.run()
    @pytest.fixture(scope="module")
    def default_args_fixture():
        return get_default_args()

    default_args = default_args_fixture()
    assert isinstance(GlobalCLIArgs.from_options(default_args), GlobalCLIArgs)

# Generated at 2022-06-21 08:27:37.809684
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    testdict = {'baz': 'true', 'foo': 'false', 'list': ['one', 'two', 'three'], 'dict': {'subkey': 'subvalue'}}
    testargs = CLIArgs(testdict)
    if(testargs != testdict):
        print("Error in test_CLIArgs, Dictionary comparison failed")
        print("Original dictionary = ", testdict)
        print("Modified dictionary = ", testargs)
        exit(1)


# Generated at 2022-06-21 08:27:39.801919
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # Make sure it doesn't error
    class MyClass(metaclass=_ABCSingleton):
        pass

# Generated at 2022-06-21 08:27:48.538445
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = CLIArgs.from_options(Mock())
    assert args == {
        'module_path': [],
        'inventory': [],
        'ask_pass': False,
        'ask_vault_pass': False,
    }
    # Test that we can't change it afterwards
    with pytest.raises(AttributeError):
        args['module_path'] = []
        args['inventory'] = []
        args['ask_pass'] = False
        args['ask_vault_pass'] = False
    # Test that we can't delete it afterwards
    with pytest.raises(AttributeError):
        del args['module_path']
        del args['inventory']
        del args['ask_pass']
        del args['ask_vault_pass']

# Generated at 2022-06-21 08:28:00.120635
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # pylint: disable=unused-variable

    class Test(object):
        __metaclass__ = _ABCSingleton

    @add_metaclass(_ABCSingleton)
    class TestABC(object):

        @classmethod
        def call(cls):
            return cls()

    @add_metaclass(_ABCSingleton)
    class TestABC2(TestABC):
        # pylint: disable=unnecessary-pass

        def __init__(self):
            pass

    assert TestABC() is not TestABC2()
    assert TestABC.call() is not TestABC2()
    assert TestABC() is TestABC.call()
    assert TestABC2() is TestABC2.call()
    assert TestABC2() is not TestABC.call()
    assert Test() is Test()



# Generated at 2022-06-21 08:28:01.898891
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class SingletonTester(object):
        pass
    assert issubclass(SingletonTester, Singleton)

# Generated at 2022-06-21 08:28:03.223052
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    _ = GlobalCLIArgs({'foo': 'bar'})

# Generated at 2022-06-21 08:28:07.060266
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = ImmutableDict({'extra_vars': '{"foo": "bar"}'})
    GlobalCLIArgs.from_options(options)
    assert GlobalCLIArgs is not None, 'Could not create GlobalCLIArgs'

# Generated at 2022-06-21 08:28:10.252736
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton
    with pytest.raises(TypeError):
        class A(object):
            __metaclass__ = _ABCSingleton
            def __init__(self, *args, **kwargs):
                pass

# Generated at 2022-06-21 08:28:30.655603
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    a = {'a': 1, 'b': [1, 2, 3]}
    b = GlobalCLIArgs(a)

    assert isinstance(b, GlobalCLIArgs)
    assert(b['a'] == a['a'])
    assert(b['b'] == a['b'])
    assert(b.get('a_bogus_key') is None)
    assert(b.get('a_bogus_key', 33) == 33)

# Generated at 2022-06-21 08:28:36.962526
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.common.collections import ImmutableDict, GlobalCLIArgs
    import copy

    # testing a simple dictionary
    singleton_object = GlobalCLIArgs(ImmutableDict({"a": 1, "b": 2, "c": 3}))

    # check the GlobalCLIArgs is created
    assert isinstance(singleton_object, GlobalCLIArgs)

    # check it is a ImmutableDict object
    assert isinstance(singleton_object, ImmutableDict)

    # check it is a singleton object
    assert singleton_object is copy.copy(singleton_object)

    # check it can not be mutated
    try:
        singleton_object['d'] = 4
        assert False
    except TypeError:
        assert True

    # check it is not a dictionary but is a

# Generated at 2022-06-21 08:28:41.739636
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    assert CLIArgs(dict(a=set([1, 2, 3]), b=dict(b1=set([1, 2, 3]), b2=set([4, 5, 6])))) == ImmutableDict({'a': frozenset([1, 2, 3]), 'b': ImmutableDict({'b1': frozenset([1, 2, 3]), 'b2': frozenset([4, 5, 6])})})
    assert CLIArgs(dict(a=set([1, 2, 3]), b=set([4, 5, 6]))) == ImmutableDict({'a': frozenset([1, 2, 3]), 'b': frozenset([4, 5, 6])})


# Generated at 2022-06-21 08:28:47.661593
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Add the metaclass and class to the module globals so we can find them.
    globals()[_ABCSingleton.__name__] = _ABCSingleton
    globals()['GlobalCLIArgs'] = GlobalCLIArgs
    # Initialize the class and add a copy of it as a global variable
    options = {}
    globals()['GlobalCLIArgs'] = GlobalCLIArgs.from_options(options)


# Generated at 2022-06-21 08:28:59.826659
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Example of how to use _ABCSingleton
    """
    # pylint: disable=missing-docstring,too-few-public-methods,too-many-instance-attributes
    class TestClass(object):
        __metaclass__ = _ABCSingleton
        def __init__(self, value1, value2, value3):
            self.value1 = value1
            self.value2 = value2
            self.value3 = value3

    class TestClass2(object):
        __metaclass__ = _ABCSingleton
        def __init__(self, value1, value2, value3):
            self.value1 = value1
            self.value2 = value2
            self.value3 = value3


# Generated at 2022-06-21 08:29:08.298907
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # fake global args
    global_args = {'ANSIBLE_MODULE_ARGS': {'one': 1, 'two': [2, 2], 'three': {'a': 'A', 'b': 'B'},
                                           'four': ['one', 'two', 'three', 4]}}
    args = GlobalCLIArgs(global_args)

    # Make sure all values are immutable
    assert args['ANSIBLE_MODULE_ARGS'] == {'one': 1,
                                           'two': (2, 2),
                                           'three': ImmutableDict({'a': 'A', 'b': 'B'}),
                                           'four': ('one', 'two', 'three', 4)}, 'args was %s' % args

# Generated at 2022-06-21 08:29:20.434518
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.cli import CLI
    from ansible.module_utils._text import to_text
    import os
    import tempfile
    import textwrap
    import yaml

    # Use a temporary directory because this is where we are creating temp files.
    with tempfile.TemporaryDirectory() as temp_dir:
        test_dir = temp_dir
        testdata_dir = os.path.join(os.path.dirname(__file__), '..', 'testdata')
        connection_loader_yaml = os.path.join(testdata_dir, 'connection_loader.yml')
        connection_loader_data = yaml.safe_load(to_text(open(connection_loader_yaml).read()))
        connection_loader_data['connection'] = 'test'
        tmp_connection_loader_yaml = temp

# Generated at 2022-06-21 08:29:27.890404
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Dummy1(_ABCSingleton):
        @staticmethod
        def get():
            return 1
    d1_1 = Dummy1.get()
    d1_2 = Dummy1.get()
    assert d1_1 == d1_2

    class Dummy2(_ABCSingleton):
        @staticmethod
        def get():
            return 2
    d2_1 = Dummy2.get()
    d2_2 = Dummy2.get()
    assert d2_1 == d2_2

    assert d1_1 != d2_1

# Generated at 2022-06-21 08:29:36.761005
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = GlobalCLIArgs({
        'limit': '127.0.0.1',
        'sun_limit': '::1',
        'boolean_limit': True,
        'none_limit': None,
        'list_limit': [1, 2, 3],
        'tuple_limit': (1, 2, 3),
        'set_limit': set([1, 2, 3]),
        'dict_limit': {'a': 1, 'b': 2, 'c': 3},
    })

    assert isinstance(args['limit'], text_type)
    assert isinstance(args['sun_limit'], text_type)
    assert isinstance(args['boolean_limit'], bool)
    assert args['none_limit'] is None
    assert isinstance(args['list_limit'], tuple)

# Generated at 2022-06-21 08:29:43.430413
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test _CLIArgs constructors
    """

    from ansible.cli import CLI
    from ansible.utils.display import Display

    display = Display()
    cli = CLI(None, display)
    cli.parse()
    cliargs = CLIArgs.from_options(cli.parser.args)
    assert cliargs['connection'] == 'smart'

# Generated at 2022-06-21 08:30:16.362716
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        __metaclass__ = _ABCSingleton

    class B(object):
        __metaclass__ = _ABCSingleton

    assert A() is A()
    assert B() is B()
    assert A() is not B()

# Generated at 2022-06-21 08:30:27.733496
# Unit test for constructor of class CLIArgs

# Generated at 2022-06-21 08:30:32.851817
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    arg1 = {'module_path': '/a/b/c'}
    arg2 = {'module_path': '/a/b/c', 'connection': 'local'}
    args1 = GlobalCLIArgs(arg1)
    args2 = GlobalCLIArgs(arg2)
    assert (args1 == args2) and id(args1) == id(args2)

# Generated at 2022-06-21 08:30:36.886856
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """ __init__() should only run once.  This implies that the metaclass used is a Singleton metaclass """
    a = GlobalCLIArgs.from_options(None)
    b = GlobalCLIArgs.from_options(None)
    # Check if object 'a' is the same as object 'b'
    assert a is b

# Generated at 2022-06-21 08:30:43.373213
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(metaclass=_ABCSingleton):
        pass
    class Test2(metaclass=_ABCSingleton):
        pass
    test = Test()
    test2 = Test2()
    assert test is Test()
    assert isinstance(test, Test)
    assert test2 is Test2()
    assert isinstance(test2, Test2)
    assert not isinstance(test, Test2)
    assert not isinstance(test2, Test)
    with pytest.raises(TypeError, match="^Can't instantiate abstract class Test with abstract methods __subclasshook__"):
        Test()
    with pytest.raises(TypeError, match="^Can't instantiate abstract class Test2 with abstract methods __subclasshook__"):
        Test2()

# Generated at 2022-06-21 08:30:54.933817
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    # Create some fake arguments
    parser.add_argument('-r', '--robots', action='store_true')
    parser.add_argument('-f', '--foo', type=int, default=10)
    parser.add_argument('-c', '--chips', type=int, default=10)
    parser.add_argument('-s', '--sauce', type=int, default=10)
    # Get some fake command line arguments and construct a CLIArgs object
    args = parser.parse_args(['-r', '-f', '42', '-c', '99', '-s', '34'])
    cli_args = CLIArgs.from_options(args)
    # Check the CLIArgs object

# Generated at 2022-06-21 08:30:58.319122
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.utils.display import Display

    display_obj = Display()

    # Sanity check that this is a singleton
    # pylint: disable=protected-access
    assert repr(display_obj._singletons) == repr({'GlobalCLIArgs': GlobalCLIArgs})

# Generated at 2022-06-21 08:31:09.950561
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'option_one': 1,
                 'option_two': 'two',
                 'option_three': {'suboption_one': 'subone', 'suboption_two': 'subtwo'}}
    test_dict_two = {'option_one': 1,
                     'option_two': 'two',
                     'option_three': (1, 2)}
    test_dict_three = {'option_one': 1,
                       'option_two': 'two',
                       'option_three': {'suboption_one': 'subone', 'suboption_two': (1, 2)}}

# Generated at 2022-06-21 08:31:13.261586
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = CLIArgs({"k": {"v": "nested"}})
    assert args == {"k": {"v": "nested"}}

    args = GlobalCLIArgs({"k": {"v": "nested"}})
    assert args == {"k": {"v": "nested"}}

# Generated at 2022-06-21 08:31:17.141577
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Make sure the metaclass behaves when base classes are ABCMeta but not Singleton
    """
    class cls(Sequence):
        @classmethod
        def __subclasshook__(cls, other):
            return False

    @add_metaclass(cls)
    class cls2(object):
        pass

    assert cls2.__class__ is cls

