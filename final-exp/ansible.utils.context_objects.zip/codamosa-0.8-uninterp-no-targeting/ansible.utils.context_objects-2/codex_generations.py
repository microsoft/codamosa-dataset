

# Generated at 2022-06-21 08:22:16.977599
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    with CLIArgs({}) as cli_args:
        assert cli_args is not None



# Generated at 2022-06-21 08:22:22.243765
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Test that the _ABCSingleton wrapper class works as expected.

    A bug here could cause a class with the wrong metaclass to be defined and then errors would be
    seen when trying to use it.
    """
    class _TestSingleton(GlobalCLIArgs):
        pass

    assert _TestSingleton.__class__.__name__ == '_ABCSingleton'

# Generated at 2022-06-21 08:22:28.024943
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--foo", nargs='+', default=[1,2,3])
    options = parser.parse_args(['--foo', '4', '5', '6'])
    myargs = GlobalCLIArgs.from_options(options)
    assert myargs['foo'] == (4, 5, 6)


# Generated at 2022-06-21 08:22:32.175055
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    global_args_obj_1 = GlobalCLIArgs.from_options({'foo': 'bar'})
    global_args_obj_2 = GlobalCLIArgs.from_options({'foo': 'bar'})
    assert id(global_args_obj_1) == id(global_args_obj_2)


__all__ = (
    'CLIArgs',
    'GlobalCLIArgs',
)

# Generated at 2022-06-21 08:22:37.421268
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # given
    mutable_dict = {"ansible_host": "1.1.1.1"}

    # when
    global_args = GlobalCLIArgs(mutable_dict)

    # then
    assert isinstance(global_args["ansible_host"], text_type)



# Generated at 2022-06-21 08:22:41.981349
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    class Options:
        func1 = 'value1'
        func2 = 'value2'
    opts = Options()
    cli_args = CLIArgs.from_options(opts)
    assert cli_args.get('func1') == 'value1'



# Generated at 2022-06-21 08:22:45.974231
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 'test', 'b': 123}
    dict_result = CLIArgs(test_dict)
    assert isinstance(dict_result, ImmutableDict)  # ensure object is immutable


# Generated at 2022-06-21 08:22:51.476787
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    # We will test this by calling its constructor with various nested python data structures and
    # ensure that Container based types are converted to ImmutableDict, ScalarTypes are unchanged,
    # and that the ImmutableDict that is the result of the conversion can't be converted into a
    # MutableDict at the top level (which would make it a container that isn't immutable)
    import pytest
    from ansible.parsing.yaml.objects import AnsibleBaseComplex
    from ansible.module_utils.common.collections import MutableMapping, MutableSequence, MutableSet

    def test_conversion_of_containers_recursively(container):
        """Recursively call through a data structure and make sure all containers are ImmutableDict"""

# Generated at 2022-06-21 08:22:55.284996
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    target = CLIArgs({'a':1, 'b':2})
    assert target['a'] == 1
    assert target['b'] == 2
    assert 'a' in target
    assert 'b' in target
    assert 'c' not in target



# Generated at 2022-06-21 08:22:58.405859
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    '''
    CLIArgs: set mutable default options inside constructor
    '''
    bools = {'true': True, 'false': False}
    a = CLIArgs.from_options(ImmutableDict({'check': True, 'diff': False}))
    assert a['check'] is True
    a['check'] = False
    assert a['check'] is True
    assert bools[a['check']] is True
    a['check'] = False
    assert bools[a['check']] is False

# Generated at 2022-06-21 08:23:10.874969
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import argparse

    # Setup arg parser
    parser = argparse.ArgumentParser()
    parser.add_argument('--foo')
    parser.add_argument('--bar', action='append')
    options = parser.parse_args(['--foo', 'something', '--foo', 'nothing', '--bar', '123', '--bar', '456'])

    # test raw
    cli_args = CLIArgs.from_options(options)
    assert cli_args == {'foo': ('something', 'nothing'), 'bar': ('123', '456')}
    assert cli_args['foo'] == ('something', 'nothing')
    assert cli_args.get('foo') == ('something', 'nothing')
    assert cli_args.get('foo', 'default') == ('something', 'nothing')
    assert cli_

# Generated at 2022-06-21 08:23:23.704547
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    from collections import OrderedDict
    from ansible import constants as C

    class TestOptions(object):
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    class TestCLIArgs(CLIArgs):
        # Override the constructor to pass our test options instead of real ones
        @classmethod
        def from_options(cls, options):
            return cls(vars(options))

    # Test that an option which is not a container
    options = TestOptions(check=True)
    assert TestCLIArgs.from_options(options).check is True

    # Test that an option which is a container
    options = TestOptions(module_path=[])

# Generated at 2022-06-21 08:23:32.729009
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.errors import AnsibleError
    import re
    import pprint
    class MockOptionParser:

        def __init__(self, *keys):
            self.values = {}
            self.keys = keys
            self.args = ['/usr/bin/ansible']
            self.obj = {}
            self.allowed_opts = []
            self.option_groups = []
            self.values['module_path'] = []
            self.required = []

        def add_option(self, *kargs, **kwargs):
            self.key = kargs[1].lstrip('-').replace('-', '_')
            self.values[self.key] = kwargs.get('default', None)

# Generated at 2022-06-21 08:23:44.394617
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Test with a text string
    mapping = {'key_1': 'value_1'}
    args = CLIArgs(mapping)
    assert isinstance(args['key_1'], text_type)

    # Test with a binary string
    mapping = {'key_1': b'value_1'}
    args = CLIArgs(mapping)
    assert isinstance(args['key_1'], text_type)

    # Test with a dictionary
    mapping = {'key_1': {'key_2': 'value_2'}}
    args = CLIArgs(mapping)
    assert isinstance(args['key_1'], ImmutableDict)

    # Test with a set
    mapping = {'key_1': {'key_2', 'value_2'}}
    args = CLIArgs(mapping)


# Generated at 2022-06-21 08:23:46.594444
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(object):
        __metaclass__ = _ABCSingleton

    assert Foo is Foo()

# Generated at 2022-06-21 08:23:48.376263
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # this should just not error out
    class Foo(_ABCSingleton):
        pass

# Generated at 2022-06-21 08:23:56.825372
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # test CLIArgs
    # test that immutablity is applied
    cli_args = CLIArgs({'a': '1', 'b': [1, 2, 3]})
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args['b'], tuple)

    # test that GlobalCLIArgs is a singleton
    cli_args_singleton_1 = GlobalCLIArgs({'a': '1', 'b': [1, 2, 3]})
    cli_args_singleton_2 = GlobalCLIArgs.from_options({'a': '1', 'b': [1, 2, 3]})
    assert cli_args_singleton_1 is cli_args_singleton_2

# Generated at 2022-06-21 08:24:00.923072
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(_ABCSingleton):
        pass

    class B(_ABCSingleton):
        pass

    assert A() is A()
    assert B() is B()
    assert A().__class__ is A.__class__
    assert A is not B


# Generated at 2022-06-21 08:24:12.165858
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        def __init__(self):
            self.module_path = 'a'
            self.connection = 'b'
            self.module_name = 'c'
            self.forks = 1
            self.remote_user = 'd'
            self.private_key_file = None
            self.ssh_common_args = ''
            self.ssh_extra_args = ''
            self.sftp_extra_args = ''
            self.scp_extra_args = ''
            self.become = 0
            self.become_method = 'e'
            self.become_user = 'f'
            self.verbosity = 0
            self.check = 0
            self.listhosts = None
            self.listtasks = None
            self.listtags = None
            self

# Generated at 2022-06-21 08:24:21.369153
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """Test for constructor of class GlobalCLIArgs"""
    import pytest
    from ansible.utils.singleton import SingletonException

    # Create a dict we can use for our test
    test_dict = {
        'test_key': 'test_value_1',
        'test_key_2': 'test_value_2'
    }

    # Create an instance of GlobalCLIArgs using a dict
    test_args_obj = GlobalCLIArgs(test_dict)

    # Make sure the argument passed in was converted to a dict
    assert type(test_args_obj) == ImmutableDict

    # Make sure that the constructor of GlobalCLIArgs converted what we passed in to an
    # ImmutableDict

# Generated at 2022-06-21 08:24:34.671367
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import collections
    import unittest

    class GlobalCLIArgsTest(unittest.TestCase):
        def setUp(self):
            self.mock_option_list = [
                'ansible_debug',
                'ansible_host_key_checking',
                'ansible_forks',
                'ansible_inventory',
                'ansible_module_path',
                'ansible_connection',
                'ansible_library',
            ]

# Generated at 2022-06-21 08:24:37.394272
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class X(Y, metaclass=_ABCSingleton):
        pass

    class Y(object):
        pass

    X()
    assert issubclass(X, Y)

# Generated at 2022-06-21 08:24:43.498360
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    args = {'extra_vars': {'foo': 'bar'}, 'module_path': '/foo', 'module_args': 'foobar'}
    global_cli_args = GlobalCLIArgs(args)
    assert global_cli_args['extra_vars'] == {'foo': 'bar'}
    assert global_cli_args['module_path'] == '/foo'
    assert global_cli_args['module_args'] == 'foobar'

# Generated at 2022-06-21 08:24:43.957432
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    pass

# Generated at 2022-06-21 08:24:49.961538
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'a': 'b'}
    test_immutable_dict = {'a': 'b'}
    test_list = ['a', 'b']
    test_immutable_list = ('a', 'b')

    assert CLIArgs(test_dict) == test_immutable_dict
    assert CLIArgs(test_list) == test_immutable_list

    assert isinstance(CLIArgs(test_dict), ImmutableDict)
    assert not isinstance(CLIArgs(test_dict), dict)
    assert isinstance(CLIArgs(test_list), tuple)
    assert not isinstance(CLIArgs(test_list), list)

# Generated at 2022-06-21 08:24:54.574707
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class a(object):
        __metaclass__ = _ABCSingleton

    class b(object):
        __metaclass__ = _ABCSingleton

    assert a() is a()
    try:
        a() == b()
    except TypeError:
        pass
    else:
        raise Exception()

# Generated at 2022-06-21 08:24:57.009431
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    options = ImmutableDict({'options': 'are cool'})
    GlobalCLIArgs(Mapping({'options': options}))

# Generated at 2022-06-21 08:24:59.780673
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(_ABCSingleton):
        pass
    a = Foo()
    b = Foo()
    assert(id(a) == id(b))

# Generated at 2022-06-21 08:25:08.168343
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Foo(metaclass=_ABCSingleton):
        pass
    class Bar(Foo):
        pass
    class Baz(Foo):
        pass
    assert Foo() is None  # __call__ returns None
    assert Foo() is None  # __call__ returns None
    assert Foo() is None  # __call__ returns None
    assert Foo() is None  # __call__ returns None
    assert Bar() is not None  # __call__ returns not None
    assert Bar() is not None  # __call__ returns not None
    assert Bar() is not None  # __call__ returns not None
    assert Bar() is not None  # __call__ returns not None
    assert Baz() is not None  # __call__ returns not None
    assert Baz() is not None  # __call__ returns not None
    assert Baz() is not None 

# Generated at 2022-06-21 08:25:20.139761
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """Unit test for constructor of class CLIArgs"""
    import sys
    from collections import OrderedDict
    from ansible.utils.listify import listify_lookup_plugin_terms

    options = GlobalCLIArgs.from_options(GlobalCLIArgs.default_options)
    assert options.get('module_path') is None
    assert options.get('connection_plugins') is None
    assert options.get('lookup_plugins') is not None
    assert options.get('module_utils') is not None
    assert options.get('roles_path') is None
    assert options.get('force_handlers') is False
    assert options.get('vault_password_files') is None
    assert options.get('vault_identity_list') is None
    assert options.get('new_vault_identity_list')

# Generated at 2022-06-21 08:25:35.217576
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import collections
    mapping = collections.OrderedDict()
    mapping['a'] = 'alpha'
    mapping['b'] = 'beta'
    mapping['c'] = [1, 2, 3]

    x = CLIArgs(mapping)
    assert isinstance(x, Mapping)
    assert isinstance(x, ImmutableDict)
    assert isinstance(x, CLIArgs)

    # We should be able to get the keys in the same order we set them
    assert list(x.keys()) == list(mapping.keys())

    # We should get back the same values we set
    assert x['a'] == mapping['a']
    assert x['b'] == mapping['b']
    assert x['c'] == mapping['c']

    # We should be able to nest a new CLIArgs object inside a CLIArgs object
    mapping2

# Generated at 2022-06-21 08:25:42.491766
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # test making an empty dict
    args = {'foo': [], 'bar': []}
    options = CLIArgs(args)
    assert args == options
    # test making a dict with a dict in it
    args = {'foo': [], 'bar': {'bing': 'bong'}}
    options = CLIArgs(args)
    assert args == options
    # test making a dict with an list in it
    args = {'foo': [], 'bar': ['bing', 'bong']}
    options = CLIArgs(args)
    assert args == options
    # test making a dict with an tuple in it
    args = {'foo': [], 'bar': ('bing', 'bong')}
    options = CLIArgs(args)
    assert args == options

# Generated at 2022-06-21 08:25:52.025363
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # pylint: disable=too-many-branches,too-many-statements,too-many-nested-blocks
    container_types = (list, set, dict, tuple)
    options = dict(
        option1=0,
        option2='foo',
        option3=True,
        option4=False,
        option5=[0, 'foo', True, False],
        option6={0, 'foo', True, False},
        option7={'foo': 0, 'bar': 'foo'},
        option8=('foo', 0),
    )
    cli_args = CLIArgs.from_options(options)
    assert isinstance(cli_args, ImmutableDict)
    assert isinstance(cli_args, Mapping)
    assert len(cli_args.items()) == len(options.items())

# Generated at 2022-06-21 08:25:59.625035
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    dummy_dict = {
        "item1": "value1",
        "item2": {
            "item2a": "value2a",
            "item2b": ["value2b1", "value2b2", {'item2b3': 'value2b3'}]
        }
    }
    dummy_cli_args = CLIArgs(dummy_dict)
    assert dummy_cli_args is not None
    assert "item1" in dummy_dict
    assert "item2" in dummy_cli_args
    assert "item2a" in dummy_cli_args["item2"]
    assert "item2b" in dummy_cli_args["item2"]
    assert "item2b3" in dummy_cli_args["item2"]["item2b"][2]

# Generated at 2022-06-21 08:26:09.349325
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    parsed_args = {
        'my_flag': True,
        'my_list_flag': ['1', '2', '3'],
        'my_dict_flag': {
            'first': 'value',
            'second': 'value2',
            'third': 'value3'
        }
    }

    # Test constructor by passing in a mutable dictionary and make sure it gets converted to an
    # ImmutableDict
    args = CLIArgs(parsed_args)

    # Test ImmutableDict behaviour
    assert args == parsed_args
    assert args.get('my_dict_flag') == parsed_args['my_dict_flag']
    assert args.get('my_dict_flag').get('first') == parsed_args['my_dict_flag']['first']

# Generated at 2022-06-21 08:26:18.616793
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # we expect the empty dictionary to be returned if the constructor is passed None
    assert CLIArgs(None) == {}

    # make sure an uncertain object is tossed into an empty dictionary
    assert CLIArgs(5) == {}
    assert CLIArgs("foo") == {}
    # make sure a simple dictionary comes back
    my_dict = {}
    assert CLIArgs(my_dict) == my_dict
    # make sure a list is not converted
    my_dict2 = {'list_val': [1, 2, 3]}
    assert CLIArgs(my_dict2) == my_dict2
    # make sure a set is converted
    my_dict3 = {'set_val': set()}
    assert CLIArgs(my_dict3) == {'set_val': frozenset()}
    # make sure a dictionary is converted
    my_dict

# Generated at 2022-06-21 08:26:20.867390
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    g = GlobalCLIArgs({'foo': ['bar', 'quux']})
    assert isinstance(g, GlobalCLIArgs)

# Generated at 2022-06-21 08:26:31.908805
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {'foo': 'bar', 'baz': {'maz': 1}, 'naz': set(['n', 'a', 'z']), 'maz': [9, 8, 7, 6]}
    cli_args = CLIArgs(args)

    assert isinstance(cli_args, ImmutableDict), 'should be ImmutableDict'
    assert cli_args, 'should have values'
    assert args['foo'] == cli_args['foo'], 'values should be the same'
    assert args['baz'] == cli_args['baz'], 'values should be the same'
    assert args['naz'] == cli_args['naz'], 'values should be the same'
    assert args['maz'] == cli_args['maz'], 'values should be the same'

#

# Generated at 2022-06-21 08:26:35.519587
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(_ABCSingleton):
        def __init__(self, x):
            self.x = x

    a = Test(1)
    b = Test(2)
    assert a is b
    assert a.x == 2
    assert b.x == 2

# Generated at 2022-06-21 08:26:39.542115
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Unit test for constructor of class _ABCSingleton
    """
    class MyClass(object):
        __metaclass__ = _ABCSingleton
        pass
    class NewClass(MyClass):
        __metaclass__ = _ABCSingleton
        pass
    NewClass()

# Generated at 2022-06-21 08:26:51.040540
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import unittest

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_instantiate(self):
            gcl = GlobalCLIArgs({'foo': 'bar'})
            self.assertIsInstance(gcl, GlobalCLIArgs)
            self.assertEqual(gcl.get('foo'), 'bar')

    unittest.main()

# Generated at 2022-06-21 08:26:55.078843
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object):
        pass

    class B(object):
        pass

    # Here, A and B are both instances of _ABCSingleton,
    # and so should be singletons
    a = A()
    b = B()

    assert a is b

# Generated at 2022-06-21 08:27:00.366749
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    args = {u'case_sensitive': False, u'ignore_files': []}
    a = CLIArgs(args)
    assert isinstance(a, ImmutableDict)
    assert isinstance(a, CLIArgs)

    # Make sure we deep-copy those args
    args[u'ignore_files'].append(u'foo')
    assert a[u'ignore_files'] == []
    assert isinstance(a[u'ignore_files'], tuple)



# Generated at 2022-06-21 08:27:08.947405
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.module_utils.six import PY2
    from ansible.module_utils.common._collections_compat import MutableMapping

    gca_instance = GlobalCLIArgs.instance()
    assert isinstance(gca_instance, ImmutableDict)
    assert isinstance(gca_instance, GlobalCLIArgs)

    # Normally, we would have used pytest's assert_reproduces_exception to verify this raises the
    # correct exception.  However, there is a bug in pytest 3.2.5 that prevents that from working.
    # See https://github.com/pytest-dev/pytest/issues/3186
    try:
        gca_instance['fake_key'] = 'fake_value'
    except Exception as e:
        if PY2:
            expected_exception = Type

# Generated at 2022-06-21 08:27:20.400255
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    # This is a separate function so that the namespace does not contain the
    # actual class thus verifying that the class is created properly and
    # can be instantiated

    class ABCSingletonExample(_ABCSingleton):
        pass

    # Next we verify that the class can be instantiated
    abc_singleton = ABCSingletonExample()

    # And now we verify that it is a singleton
    abc_singleton_second = ABCSingletonExample()

    # To avoid this error in coverage.py::
    #   TypeError: cannot create 'abc.ABCMeta' instances
    #   You have to use ABCMeta.__new__ to create one.
    # we have to use type() to create our metaclass
    assert abc_singleton is abc_singleton_second

# Generated at 2022-06-21 08:27:32.284940
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import sys
    import argparse
    from ansible.module_utils.common.text.converters import to_text, to_bytes

    parser = argparse.ArgumentParser()
    parser.add_argument("-s", action="append")
    parser.add_argument("-b", action="append")
    parser.add_argument("-d", action="append")
    parser.add_argument("-l", type=int, action="append")
    parser.add_argument("-t", action="append")

    options, args = parser.parse_known_args(sys.argv[1:])

    cli_args = CLIArgs.from_options(options)
    assert cli_args.get("d") is None
    assert cli_args.get("l") is None

# Generated at 2022-06-21 08:27:43.626956
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    c1 = CLIArgs.from_options(Mapping({'a': 1, 'b': 2}))
    assert isinstance(c1, ImmutableDict)
    assert c1['a'] == 1
    assert c1['b'] == 2
    c2 = CLIArgs.from_options(Mapping({'a': 1, 'b': 2}))
    assert c1 == c2
    c1 = CLIArgs.from_options(Mapping({'a': 1, 'b': Set(['1', '2', '3'])}))
    assert c1['b'] == frozenset(('1', '2', '3'))
    c1 = CLIArgs.from_options(Mapping({'a': 1, 'b': Sequence(['1', '2', '3'])}))

# Generated at 2022-06-21 08:27:53.713351
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    import unittest
    from optparse import OptionParser

    from ansible.utils.color import ANSIBLE_COLOR, COLOR_HIGHLIGHT

    class TestGlobalCLIArgs(unittest.TestCase):
        def test_constructor(self):
            parser = OptionParser()
            parser.add_option(
                '-T', '--timeout', dest='timeout', type='int',
                help='connection timeout in seconds')
            (options, args) = parser.parse_args()
            global_cli_args = GlobalCLIArgs.from_options(options)
            self.assertIsInstance(global_cli_args, GlobalCLIArgs)
            self.assertIsInstance(global_cli_args, ImmutableDict)
            self.assertIsInstance(global_cli_args, dict)
            self.assertNotIsInstance

# Generated at 2022-06-21 08:28:05.158235
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Testing when values are not container types
    assert CLIArgs({'a': '4', 'b': 7}) == {'a': '4', 'b': 7}

    # Testing when a value is a list
    assert CLIArgs({'a': ['4', '5']}) == {'a': ('4', '5')}

    # Testing when a value is another dict
    assert CLIArgs({'a': {'b': 7}}) == {'a': {'b': 7}}

    # Testing when a value is a set
    assert CLIArgs({'a': {7, 8, 9, 7}}) == {'a': frozenset({7, 8, 9})}

    # Testing when a value is a nested dict and list
    assert CLIArgs({'a': {'b': [1, {'c': 'd'}]}})

# Generated at 2022-06-21 08:28:09.542566
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class A(object, metaclass=_ABCSingleton):
        pass
    assert isinstance(A(), A)
    assert isinstance(A(), object)

    class B(object):
        __metaclass__ = _ABCSingleton
    assert isinstance(B(), B)
    assert isinstance(B(), object)

# Generated at 2022-06-21 08:28:31.601054
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        VERBOSITY = 0
        LOG_PATH = '/dev/null'
        TREE = None
        FORK = 0
        MODULE_PATH = []
        MODULE_NEWSTYLE = True
        KEEP_REMOTE_FILES = False
        REMOTE_TMP = None
        LISTTAGS = False
        LISTTASKS = False
        SYNTAX = False
        FORCE_HANDLERS = False
        STEP_PLUGINS = False
        DIFF = False
        CHECK = False
        UNSAFE_WRITABLES_MODE = False
        UNSAFE_WRITABLES_CONFIRM = False
        UNSAFE_WRITABLES_ARE_OK = False
        BECOME = False
        BECOME_ASK_PASS = False
        BEC

# Generated at 2022-06-21 08:28:34.082172
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _ABCSingletonTest(object):
        __metaclass__ = _ABCSingleton

    assert _ABCSingletonTest() is _ABCSingletonTest()

# Generated at 2022-06-21 08:28:38.730258
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test1(object):
        pass

    class _SingletonTest(_ABCSingleton):
        pass

    t1 = Test1()
    t2 = Test1()
    ts = _SingletonTest()

    assert t1 is not t2
    assert ts is _SingletonTest()

# Generated at 2022-06-21 08:28:41.665934
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    expected_result = ImmutableDict({'a': '1', 'b': '2'})
    assert CLIArgs({'a': '1', 'b': '2'}) == expected_result


# Generated at 2022-06-21 08:28:50.067938
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    class Options(object):
        def __init__(self):
            self.host_key_checking = False
            self.verbosity = 5

    class GlobalCLIArgs(CLIArgs):
        pass

    global_cli_args = GlobalCLIArgs.from_options(Options())
    assert isinstance(global_cli_args, GlobalCLIArgs)
    assert 'host_key_checking' in global_cli_args
    assert 'verbosity' in global_cli_args

    assert global_cli_args['host_key_checking'] is False
    assert global_cli_args['verbosity'] == 5

# Generated at 2022-06-21 08:29:01.922381
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    """
    Unit test for class _ABCSingleton
    """
    class test_class_a(object):
        def test_method_a(self):
            return "test_method_a"

    class test_class_b(test_class_a):
        def test_method_b(self):
            return "test_method_b"

    class Foo(Singleton):
        pass

    class Bar(Foo):
        pass

    test_foo = Foo()
    test_bar = Bar()

    assert isinstance(test_bar, Foo)
    assert isinstance(test_foo, Foo)
    assert not isinstance(test_bar, Bar)
    assert not isinstance(test_foo, Bar)

    class A(object):
        pass

    class B(A):
        pass


# Generated at 2022-06-21 08:29:10.008662
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    # Check that calling constructor on different instances of subclass results in different types
    class B(CLIArgs):
        pass
    a = CLIArgs({'print': False, 'help': False})
    b = B({'print': False, 'help': False})
    assert not isinstance(a, B)
    assert isinstance(b, B)
    # Check that mutable items are converted to immutable in constructor
    mutable_vars = {'a': 'A', 'b': [1, 2, 3], 'c': {1: 'A', 2: 'B', 3: 'C'}, 'd': set([1, 2, 3])}
    immutable_vars = CLIArgs(mutable_vars)
    # Check that contents are unchanged

# Generated at 2022-06-21 08:29:22.177034
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    import sys
    import json
    import itertools
    import copy
    import random

    types = (int, float, text_type, binary_type, list, dict, set)

    # All types are immutable so it's okay to share them between dictionaries
    common_types = {
        int: 0,
        float: 0.2,
        text_type: u"abc",
        binary_type: b"abc",
        dict: dict(a=1, b=2, c=3),
        set: set([1, 2, 3]),
    }

    def recurse_type(fuzzy, depth, klass):
        """Recursively generate a dictionary of random types and sizes"""
        if isinstance(klass, (list, set)):
            # Recursively build a list or set of items
            item_

# Generated at 2022-06-21 08:29:24.441893
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Concrete(_ABCSingleton):
        pass

    assert Concrete._abc_negative_cache_version == False
    assert Concrete._abc_registry == set()

# Generated at 2022-06-21 08:29:35.982966
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test CLIArgs for basic constructor
    """
    kwargs = dict(
        extra_vars=dict(
            key1=dict(
                key2=1,
            ),
            key3=[
                dict(
                    key4=[1, 2, 3],
                ),
                dict(
                    key5=dict(
                        key6=1,
                    ),
                ),
            ]
        ),
    )

    cli_args = CLIArgs(kwargs)

    assert isinstance(cli_args['extra_vars']['key1'], ImmutableDict)
    assert cli_args['extra_vars']['key1']['key2'] == 1

    assert isinstance(cli_args['extra_vars']['key3'], tuple)

# Generated at 2022-06-21 08:30:09.083699
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    """
    Test class CLIArgs constructor when it takes a non-immutable object.
    """
    options = {'a': {'a': 1, 'b': 2, 'c': 3}, 'b': (1, 2, 3, 4), 'c': (1, [2, 3, 4])}
    cli_args = CLIArgs(options)
    assert cli_args['a'] is not options['a']
    assert cli_args['b'] is not options['b']
    assert cli_args['c'] is not options['c']
    assert cli_args['c'][1] is not options['c'][1]



# Generated at 2022-06-21 08:30:15.613164
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    # Not too much to test since this is just a singleton version of the regular CLIArgs object

    a = GlobalCLIArgs({'key1': 'value1', 'key2': 2})

    assert isinstance(a, dict)
    assert a.data == {'key1': 'value1', 'key2': 2}
    assert a.data is not a
    assert a == {'key1': 'value1', 'key2': 2}
    assert 'key1' in a
    assert 'key1' in a
    assert 'key3' not in a



# Generated at 2022-06-21 08:30:21.272472
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    test_dict = {'ansible_connection': 'ssh', 'module_path': '/path/to/modules'}
    test_instantiate_cliargs = CLIArgs(test_dict)
    assert test_instantiate_cliargs.ansible_connection == 'ssh'
    assert test_instantiate_cliargs.module_path == '/path/to/modules'



# Generated at 2022-06-21 08:30:32.022969
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    from ansible.parsing.plugin_docs import get_docstring

    def _test_basic(d):
        argv = ['/bin/foo']
        for a in d['args']:
            argv.append(a)
        get_docstring.options = get_docstring.parser.parse_args(argv)
        GlobalCLIArgs.from_options(get_docstring.options)

    _test_basic({'args': []})
    _test_basic({'args': ['-f', '/m1/a']})
    _test_basic({'args': ['--force', '--other-arg', 'foo', '-c', 'bar', '-c', 'baz']})

# Generated at 2022-06-21 08:30:35.328930
# Unit test for constructor of class GlobalCLIArgs
def test_GlobalCLIArgs():
    """
    This is the unit test for the constructor of class GlobalCLIArgs
    It is needed as GlobalCLIArgs is a Singleton object
    """
    GlobalCLIArgs.from_options(GlobalCLIArgs.from_options({'answer': 42}))

# Generated at 2022-06-21 08:30:42.586243
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    d = {'a': 1, 'b': 2, 'c': {'d1': 1, 'd2': 2}, 'e': {'f': {'g': 3}}}
    i = CLIArgs(d)
    assert(str(i) == str(d))
    assert(list(i.keys()) == ['a', 'b', 'c', 'e'])
    assert(i['a'] == 1)
    assert(i['b'] == 2)
    assert(list(i['c'].keys()) == ['d1', 'd2'])
    assert(i['c']['d1'] == 1)
    assert(i['c']['d2'] == 2)
    assert(list(i['e'].keys()) == ['f'])

# Generated at 2022-06-21 08:30:49.079914
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class Test(object):
        __metaclass__ = _ABCSingleton

        def __init__(self, arg):
            self.arg = arg

    one = Test(1)
    two = Test(2)
    assert one is two

    assert issubclass(Test, object)
    assert isinstance(one, Test)



# Generated at 2022-06-21 08:30:58.356232
# Unit test for constructor of class CLIArgs
def test_CLIArgs():

    args = CLIArgs({'a':1, 'b':2, 'c':3})
    assert isinstance(args, ImmutableDict)
    assert (args.a, args.b, args.c) == (1,2,3)

    args = CLIArgs({'a':[1,2,3], 'b':(4,5), 'c':{'d':6}})
    assert (args.a, args.b, args.c) == (tuple([1,2,3]), tuple((4,5)), ImmutableDict({'d':6}))

    args = CLIArgs({'a':{1,2,3}, 'b':{4,5}, 'c':{'d':6}})

# Generated at 2022-06-21 08:31:09.995325
# Unit test for constructor of class _ABCSingleton
def test__ABCSingleton():
    class _Meta(metaclass=_ABCSingleton):
        pass
    class NoMeta(object):
        pass
    class ImplNoMeta(_Meta, NoMeta):
        pass
    class ImplMeta(_Meta, metaclass=_ABCSingleton):
        pass
    assert _Meta is not NoMeta
    assert _Meta is not ImplNoMeta
    assert _Meta is ImplMeta
    assert NotImplemented is _Meta(NoMeta, NoMeta)
    assert NotImplemented is _Meta(NoMeta, ImplNoMeta)
    assert NotImplemented is _Meta(NoMeta, ImplMeta)
    assert NotImplemented is _Meta(ImplNoMeta, NoMeta)
    assert NotImplemented is _Meta(ImplNoMeta, ImplNoMeta)
    assert NotImplemented is _Meta(ImplNoMeta, ImplMeta)
   

# Generated at 2022-06-21 08:31:13.928708
# Unit test for constructor of class CLIArgs
def test_CLIArgs():
    options = CLIArgs({'test_arg': 'hello'})
    assert options.test_arg == 'hello'

    options = CLIArgs({'test_arg': {'nested_args': 'hello'}})
    assert isinstance(options.test_arg, ImmutableDict)
    assert options.test_arg.nested_args == 'hello'
