

# Generated at 2022-06-21 12:34:42.221518
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-21 12:34:54.484912
# Unit test for function encode

# Generated at 2022-06-21 12:34:58.492410
# Unit test for function register
def test_register():
    import sys
    import os
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import test_codec
    test_codec.register()

# Generated at 2022-06-21 12:34:59.504124
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None

# Generated at 2022-06-21 12:35:00.074150
# Unit test for function register
def test_register():
    assert not register()

# Generated at 2022-06-21 12:35:09.734355
# Unit test for function encode
def test_encode():
    # Test that the function encodes 7 encoded utf8 characters
    # correctly,
    # and returns the original string (which contains those utf8 encoded
    # characters)
    test_str = u'\\xF0\\x9F\\x91\\x8D\\xF0\\x9F\\x91\\x8E'
    test_str_bytes = bytes(test_str.encode())
    (out_str_bytes, consumed) = encode(test_str)
    assert out_str_bytes == test_str_bytes, \
        'Encode did not work correctly'
    assert consumed == len(test_str), \
        'Encode did not return correct number of characters consumed'

    # Test that the function returns an error if an invalid utf8
    # sequence is provided

# Generated at 2022-06-21 12:35:21.211285
# Unit test for function encode
def test_encode():
    try:
        codecs.getencoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)  # type: ignore

    def _test(s):
        encoded, _ = encode(s)
        b, _ = codecs.getencoder(NAME)(s)
        assert encoded == b

    _test('')

# Generated at 2022-06-21 12:35:22.356266
# Unit test for function register
def test_register():
    pass


# Generated at 2022-06-21 12:35:27.180514
# Unit test for function encode
def test_encode():
    assert encode('hello, world') == (b'h\\xe\\le\\lo\\,\\ w\\o\\r\\ld', 12)
    assert encode('hello, world!') == (
        b'h\\xe\\le\\lo\\,\\ w\\o\\r\\ld\\!',
        13
    )



# Generated at 2022-06-21 12:35:34.445241
# Unit test for function decode
def test_decode():
    # We have to expose the actual decode function as a global so that
    # it can be imported.
    # noinspection PyUnresolvedReferences
    from eutf8h.eutf8h_raw import decode

    data1 = b'\\x66\\x6f\\x6f'
    data2 = b'\\x23\\x42\\x6f\\x6f'
    data3 = b'\\x66\\x6f\\x6f\x23\\x42\\x6F\\x6f'
    print(data1)
    print(data2)
    print(data3)
    out1, _ = decode(data1)
    out2, _ = decode(data2)
    out3, _ = decode(data3)
    print(out1)
    print(out2)

# Generated at 2022-06-21 12:35:51.070764
# Unit test for function encode
def test_encode():
    # Test case 1
    test_input_text = 'A'
    test_input_errors = 'strict'
    test_expected_bytes = cast(bytes, b'A')
    test_expected_int = 1
    test_output_bytes, test_output_int = encode(
        text=test_input_text,
        errors=test_input_errors
    )
    # Print the test case and results
    fmt_str = (
        'In:  text={0}\n'
        '     errors={1}\n'
        'Out: bytes={2}\n'
        '     int={3}'
    )

# Generated at 2022-06-21 12:35:56.515253
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup_error('eutf8h') is codecs.strict_errors
    assert codecs.lookup_error('eutf8h') is codecs.strict_errors
    assert codecs.lookup_error('eutf8h') is codecs.strict_errors



# Generated at 2022-06-21 12:36:05.221469
# Unit test for function encode
def test_encode():
    # Test for narrow python build.
    if sys.maxunicode == 0xFFFF:
        assert encode('\xC0') == (b'\\\\xc0', 1)
        assert encode('\xE0') == (b'\\\\xe0', 1)
        assert encode('\xF0') == (b'\\\\xf0', 1)
    # Test for wide python build.
    else:
        assert encode('\U00010000') == (b'\\\\xf0\\\\x90\\\\x80\\\\x80', 1)
        assert encode('\U00010010') == (b'\\\\xf0\\\\x90\\\\x80\\\\x90', 1)
        assert encode('\U00010020') == (b'\\\\xf0\\\\x90\\\\x80\\\\xa0', 1)


# Generated at 2022-06-21 12:36:07.749939
# Unit test for function register
def test_register():
    assert None == codecs.getdecoder(NAME)
    register()
    assert None != codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:36:09.011896
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-21 12:36:12.482111
# Unit test for function encode
def test_encode():
    print()
    print('# Testing...')
    assert b'\\x61\\x62' == encode('\u0061\u0062', 'strict')[0]
    print('# eutf8h encode is working.')



# Generated at 2022-06-21 12:36:24.561691
# Unit test for function decode
def test_decode():
    """Unit test for function 'decode'."""

    # Test literal text.
    assert decode(b'hello') == ('hello', 5)
    assert decode(b'hello\\x0a') == ('hello\n', 8)
    assert decode(b'hello\\x0a', 'ignore') == ('hello', 7)
    assert decode(b'hello\\x0a', 'replace') == ('hello�', 8)

    # Test escaped hexadecimal
    assert decode(b'hello\\u0020') == ('hello ', 9)
    assert decode(b'hello\\x20') == ('hello ', 8)
    # Test long escaped hexadecimal
    assert decode(b'hello\\u000020') == ('hello ', 11)
    assert decode(b'hello\\x00000020') == ('hello ', 13)

    # Test backsl

# Generated at 2022-06-21 12:36:31.335388
# Unit test for function encode
def test_encode():
    """Test the function :func:`encode`."""
    # Unit test #1.
    text = (
        "\x80\xe2\x80\x80"
        "\xe2\x80\x80"
        "\xe2\x80\x80"
    )
    # noinspection SpellCheckingInspection
    exp = (
        "\\xc2\\x80"
        "\\xe0\\xa0\\x80"
        "\\xe0\\xa0\\x80"
        "\\xe0\\xa0\\x80"
    )
    got = encode(text)
    exp = exp.encode('utf-8')
    assert got == (exp, 11), got

    # Unit test #2.

# Generated at 2022-06-21 12:36:36.878273
# Unit test for function encode
def test_encode():
    text = 'This is a utf-8 string, é.\x00'
    expected = (b'This is a utf-8 string, \\xe9.\\x00', len(text))
    out, _ = encode(text)
    assert out == expected[0]



# Generated at 2022-06-21 12:36:48.115015
# Unit test for function decode
def test_decode():
    assert decode(b'\\u0048\\u0065\\u006c\\u006c\\u006f') == ('Hello', 30)
    assert decode(b'\\u0068\\u0065\\u006c\\u006c\\u006f') == ('hello', 30)
    assert decode(b'\\u007A') == ('z', 6)

    assert decode(b'\\u0041\\u0042\\u0043') == ('ABC', 18)

    assert decode(b'\\x48\\x65\\x6c\\x6c\\x6f') == ('Hello', 30)
    assert decode(b'\\x41\\x42\\x43') == ('ABC', 18)

    assert decode(b'\\x68\\x65\\x6c\\x6c\\x6f') == ('hello', 30)


# Generated at 2022-06-21 12:37:00.928319
# Unit test for function register
def test_register():
    #
    # Test situation where codec is registered
    #
    register()
    codecs.getdecoder(NAME)  # Expect no error to be raised here.

    #
    # Test situation where codec is already registered
    #
    try:
        codecs.register(_get_codec_info)   # type: ignore
    except LookupError:
        pass
    else:
        raise AssertionError('expected LookupError')

# unit test for encode

# Generated at 2022-06-21 12:37:12.281912
# Unit test for function encode
def test_encode():
    assert encode('This is a \u03b1\u03b2\u03b3\u03b4\u03b5\u03b6') \
        == b'This is a \u03b1\u03b2\u03b3\u03b4\u03b5\u03b6'
    assert encode('This is a \u03b1\u03b2\u03b3\u03b4\u03b5\u03b6', 'strict') \
        == b'This is a \\xCE\\xB1\\xCE\\xB2\\xCE\\xB3\\xCE\\xB4\\xCE\\xB5\\xCE\\xB6'

# Generated at 2022-06-21 12:37:15.721534
# Unit test for function decode
def test_decode():
    text_bytes = b'\\x68\\69\\x56'
    result = decode(text_bytes)
    assert result == ('hiV', 3)


# Generated at 2022-06-21 12:37:25.467128
# Unit test for function decode
def test_decode():
    # Test for decoding 01 bytes
    assert decode(b'\x01')[0] == '\u0001'

    # Test for decoding 20 bytes
    assert decode(b'\x20')[0] == ' '

    # Test for decoding FF bytes
    assert decode(b'\xFF')[0] == '\u00FF'

    # Test for decoding three byte utf-8 byte sequence
    assert decode(b'\xE2\x82\xAC')[0] == '€'

    # Test for decoding four byte utf-8 byte sequence
    assert decode(b'\xF0\x90\x8D\x88')[0] == '𐍈'

    # Test for decoding escaped characters

# Generated at 2022-06-21 12:37:35.885907
# Unit test for function decode
def test_decode():
    """

    """
    # First, we'll check that if an error occurs in "unicode_escape",
    # then an error is also raised in 'eutf8h'.
    utf8_bytes = b'\x80'   # Invalid utf8 byte
    data = r'\x80'
    data_bytes = data.encode('ascii')
    try:
        data_bytes.decode('unicode_escape')
        raise Exception("Should have raised an error.")
    except UnicodeDecodeError as e:
        # noinspection PyBroadException
        try:
            decode(data_bytes)
            raise Exception("Should have raised an error.")
        except UnicodeDecodeError as d:
            assert e.start == d.start
            assert e.end == d.end
            assert e.reason == d.reason



# Generated at 2022-06-21 12:37:41.242052
# Unit test for function decode
def test_decode():
    assert decode(b'\\xC2\\xA2', 'replace') == ('¢', 14)
    assert decode(b'\\xC2\\xA2', 'ignore') == ('', 14)


if __name__ == '__main__':
    register()
    test_decode()

# Generated at 2022-06-21 12:37:48.966862
# Unit test for function decode
def test_decode():
    assert decode(
        b'This is a string of bytes',
    ) == ('This is a string of bytes', 24)

    assert decode(
        b'This is a string of \\x66\\x6f\\x6f bytes',
    ) == ('This is a string of foo bytes', 33)

    assert decode(
        b'Escaped hexadecimal \\x6\\x6\\x64 \\x36\\x36\\x34',
    ) == ('Escaped hexadecimal fd 664', 31)


# Generated at 2022-06-21 12:37:55.303279
# Unit test for function decode
def test_decode():
    text = '\\xE2\\x9C\\x93'  # U+2713 is the check mark character
    text_bytes = text.encode('utf-8')
    # print(text_bytes)
    out, _ = decode(text_bytes)
    assert out == '✓'



# Generated at 2022-06-21 12:38:05.381485
# Unit test for function register
def test_register():
    register()

# This unit test can be run directly from this file's folder by running
#
#    python3 -m test_eutf8h
#
# or by running
#
#    pytest test_eutf8h.py
#
# If your unit test crashes, the information the error message prints may
# not appear in a command line shell's window.  The command line shell's
# window may close before you have a chance to read the error message.
# If this happens, run the command line shell again to try running
# the unit test again.  If the error message still doesn't appear,
# there could be a problem with your command line shell.  If you are
# using Windows 10, you might try using PowerShell or Git Bash.



# Generated at 2022-06-21 12:38:11.772734
# Unit test for function register
def test_register():
    """Register the encoding.

     The 'utf8_hex' encoding was developed for this module.

    .. code-block:: none

        >>> import sys
        >>> import eutf8h

        >>> eutf8h.register()

        >>> codecs.lookup('utf8_hex')
        <codecs.CodecInfo object at 0x7f5de9d0e340>

    """
    pass



# Generated at 2022-06-21 12:38:27.741418
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


if __name__ == "__main__":
    test_register()

# Generated at 2022-06-21 12:38:36.496860
# Unit test for function decode
def test_decode():
    # Test for proper operation
    assert decode(b'\\x30') == ('0', 3), 'Failed for \\x30'
    assert decode(b'\\x30', 'strict') == ('0', 3), 'Failed for \\x30, strict'
    assert decode(b'\\x30', 'backslashreplace') == ('\x30', 3), \
        'Failed for \\x30, backslashreplace'
    assert decode(b'\\x30', 'replace') == ('?', 3), 'Failed for \\x30, replace'
    assert decode(b'\\x30', 'ignore') == ('', 3), 'Failed for \\x30, ignore'

    # Failure due to invalid escape sequence.
    try:
        decode(b'\\xZ')
    except Exception:
        pass

# Generated at 2022-06-21 12:38:41.509412
# Unit test for function encode
def test_encode():
    assert encode('\x80') == (b'\\200', 1)
    assert encode('\U0001F1E6') == (b'\\U0001F1E6', 1)
    assert encode('\U0001F1E6\U0001F1E7') == (b'\\U0001F1E6\\U0001F1E7', 1)



# Generated at 2022-06-21 12:38:51.861960
# Unit test for function decode

# Generated at 2022-06-21 12:39:00.911695
# Unit test for function encode
def test_encode():
    assert encode('abc') == (b'abc', 3)
    assert encode('abcdef') == (b'abcdef', 6)
    assert encode('\\x41bcdef') == (b'Abcdef', 7)
    assert encode('\\x41\\x42\\x43\\x44') == (b'ABCD', 7)
    assert encode('\\x41\\x42\\x43\\x44\\x45\\x46\\x47\\x48') == (
        b'ABCDEFGH',
        11,
    )
    assert encode('\\x41\\x42\\x43\\x44\\x45\\x46\\x47\\x48\\x49') == (
        b'ABCDEFGHI',
        12
    )

# Generated at 2022-06-21 12:39:12.476444
# Unit test for function encode

# Generated at 2022-06-21 12:39:15.142528
# Unit test for function decode
def test_decode():
    decoded_byte, count = decode(b'\xe2\x98\x83')
    assert decoded_byte == '\u2603'
    assert count == 1


# Generated at 2022-06-21 12:39:25.468966
# Unit test for function decode
def test_decode():
    raw_bytes = b'\\x62\\x69\\x6e'  # bytes literal
    decoded_str, num_bytes = decode(raw_bytes)
    assert decoded_str == 'bin'
    assert num_bytes == len(raw_bytes)

    raw_bytes = b'\\u0041\\u0042\\u0043'  # bytes literal
    decoded_str, num_bytes = decode(raw_bytes)
    assert decoded_str == 'ABC'
    assert num_bytes == len(raw_bytes)

    raw_bytes = b'\\uD834\\uDD1E'  # bytes literal
    decoded_str, num_bytes = decode(raw_bytes)
    assert decoded_str == '𝄞'
    assert num_bytes == len(raw_bytes)


# Unit

# Generated at 2022-06-21 12:39:35.582713
# Unit test for function decode
def test_decode():
    assert decode(r'\x2d\x2e\x2f\x6a\x73\x6d\x73\x62\x68'
                  r'\x2e\x73\x65\x72\x76\x69\x63\x65\x73'
                  r'\x2e\x63\x6f\x6d\x2f\x7a\x69\x70\x68') \
           == ('-./jsmssh.services.com/ziph', 30)
    assert decode(r'\x5a', errors='ignore') == ('', 2)
    assert decode(b'\xff') == (codecs.BOM_UTF16_LE.decode('utf-8'), 1)

# Generated at 2022-06-21 12:39:38.479736
# Unit test for function decode
def test_decode():
    assert decode(b'\\xe0\\xbd\\xa0\\xe0\\xbe\\x9f\\xe0\\xbe \\xe0\\xbe \\xe0\\xbe\\xa5') == ('འཟའ འ འཥ', 23)


# Generated at 2022-06-21 12:40:11.802169
# Unit test for function decode
def test_decode():
    # Given
    input = b'\\xc3\\xb1O\\xc3\\xb1O\\xc2\\xb0'

    # When
    output, _ = decode(input)

    # Then
    assert output == 'ñOñO°'


# Generated at 2022-06-21 12:40:15.816171
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    for encoding in (NAME,):
        try:
            codecs.lookup(encoding)
        except LookupError:
            raise AssertionError(f'encoding {encoding} is not registered')

# Generated at 2022-06-21 12:40:25.758207
# Unit test for function encode
def test_encode():
    # Test case 1: String doesn't contain any hexadecimal strings
    assert(encode('hello') == (b'hello', 5))
    assert(encode(u'hello') == (b'hello', 5))
    assert(encode(b'hello') == (b'hello', 5))
    assert(encode(bytearray(b'hello')) == (b'hello', 5))

    # Test case 2: String contains hexadecimal string with one ASCII character
    assert(encode('\x44') == (b'\\x44', 3))
    assert(encode(u'\x44') == (b'\\x44', 3))
    assert(encode(b'\x44') == (b'\\x44', 3))

# Generated at 2022-06-21 12:40:30.520767
# Unit test for function decode
def test_decode():
    """Test for function decode."""
    bytes_in = 'abc\\x20d'
    out, _ = decode(bytes_in)
    assert out == 'abc d'

    bytes_in = '\\xD3\\x01'
    out, _ = decode(bytes_in)
    assert out == 'Г\x01'



# Generated at 2022-06-21 12:40:31.807863
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)


# Generated at 2022-06-21 12:40:33.582982
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)



# Generated at 2022-06-21 12:40:37.389325
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        _register()
        assert codecs.getdecoder(NAME) is not None
    else:
        _register()

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:40:43.296267
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)  # type: ignore
    except LookupError:
        raise

if __name__ == '__main__':
    r"""
    CommandLine:
        python -m eutf8h
        python -m eutf8h --allexamples
    """
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:40:45.256232
# Unit test for function register
def test_register():
    import sys
    register()
    assert NAME in sys.getdefaultencoding()  # type: ignore

# Generated at 2022-06-21 12:40:55.083224
# Unit test for function encode

# Generated at 2022-06-21 12:42:04.020587
# Unit test for function register
def test_register():
    """Test importing the codec, registering the codec, and
    then importing codecs.
    """
    import sys
    import os
    import importlib

    # noinspection PyProtectedMember
    site_packages = importlib.util.get_parent_dir(
        os.path.abspath(  # type: ignore
            sys.modules[__name__].__file__
        )
    )
    sys.path.append(site_packages)  # type: ignore

    module_path = importlib.util.module_path(NAME, os.path.abspath(site_packages))
    module = importlib.import_module(NAME)  # type: ignore
    assert module.NAME == NAME

    # Register the codec
    module.register()

    # Import codecs, which will trigger the codec to be loaded.

# Generated at 2022-06-21 12:42:15.263056
# Unit test for function register
def test_register():
    register()
    try:
        codecs.lookup_error('eutf8h')
    except LookupError:
        raise AssertionError('eutf8h is not a lookup error name')


if __name__ == '__main__':
    register()

    text = 'ABC 123'
    print(f'Text: {text}')
    b = text.encode(NAME)
    print(f'Encoded: {b}')
    d = b.decode(NAME)
    print(f'Decoded: {d}')
    assert text == d

    text = '🐦'
    print(f'Text: {text}')
    b = text.encode(NAME)
    print(f'Encoded: {b}')
    d = b.decode(NAME)

# Generated at 2022-06-21 12:42:25.965626
# Unit test for function decode
def test_decode():
    was = r'\xE2\x9D\xA4'
    now = decode(was.encode('utf-8'))[0]
    assert was.encode('utf-8') == now.encode('utf-8')

    was = r'This is a test \\xA5'
    now = decode(was.encode('utf-8'))[0]
    assert was.encode('utf-8') == now.encode('utf-8')

    was = r'This is a test \\xA5\xA5'
    now = decode(was.encode('utf-8'))[0]
    assert was.encode('utf-8') == now.encode('utf-8')

    was = r'This is a test \\xA5\\xA5'
    now = decode

# Generated at 2022-06-21 12:42:27.526445
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    codecs.getdecoder(NAME)

test_register()

# Generated at 2022-06-21 12:42:37.067409
# Unit test for function decode
def test_decode():
    from eutf8h import decode

    # Define the expected output
    expected = 'abc123!@#'

    # Define test cases
    test_cases = [
        b'abc123!@#',
        b'\\x61\\x62\\x63\\x31\\x32\\x33\\x21\\x23\\x40',
        b'\\61\\62\\63\\31\\32\\33\\21\\23\\40',
    ]

    # Verify that the function 'decode' returns the expected output
    # for each of the test cases
    for test_case in test_cases:
        assert decode(test_case)[0] == expected



# Generated at 2022-06-21 12:42:40.401435
# Unit test for function register
def test_register():
    eutf8h.register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise TestFailure(
            'register method did not register encoder as expected.'
        )



# Generated at 2022-06-21 12:42:46.493774
# Unit test for function encode
def test_encode():
    # Test that the function encodes strings into a bytes object of escaped utf8 hexadecimal
    assert encode('hello world!') == (b'hello world!', len('hello world!'))  # Printable ASCII
    assert encode('1234567890') == (b'1234567890', len('1234567890'))   # Digits
    assert encode('aBcDeFgHiJkLmNoPqRsTuVwXyZ') == (b'aBcDeFgHiJkLmNoPqRsTuVwXyZ', len('aBcDeFgHiJkLmNoPqRsTuVwXyZ'))  # Lowercase and uppercase ASCII

# Generated at 2022-06-21 12:42:53.600554
# Unit test for function register
def test_register():
    global NAME
    # Test if the codec is already available.
    # It should be available after a first call of this function.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
    try:
        # Retrieve the codec object.
        codecs.getdecoder(NAME)
    except LookupError:
        # Codec object not available.
        assert False

# Generated at 2022-06-21 12:42:58.436199
# Unit test for function register
def test_register():
    _old_decoder = codecs.getdecoder(NAME)
    codecs.register(_get_codec_info)
    _new_decoder = codecs.getdecoder(NAME)
    assert _new_decoder is not _old_decoder
    assert _new_decoder is _get_codec_info(NAME)



# Generated at 2022-06-21 12:43:01.788668
# Unit test for function encode
def test_encode():
    text = '\\x01'
    data = b'\x01'

    # Test output of bytes against expected bytes.
    out = encode(text)[0]
    assert out == data

    # Test that the returned data is of type bytes
    assert isinstance(out, bytes)

    # Test that the returned data is of type bytes
    assert isinstance(encode(text)[1], int)

