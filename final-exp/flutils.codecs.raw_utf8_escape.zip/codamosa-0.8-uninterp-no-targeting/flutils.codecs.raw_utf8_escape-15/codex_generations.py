

# Generated at 2022-06-21 12:34:49.188407
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, "Codec should be registered"
    else:
        pass     # No error, test passed



# Generated at 2022-06-21 12:34:53.268051
# Unit test for function register
def test_register():
    from unittest import TestCase

    class RegisterTest(TestCase):

        def test_register(self):
            from utf8h import NAME
            self.assertIn(NAME, codecs.decode.cache)

    register()



# Generated at 2022-06-21 12:34:59.087963
# Unit test for function decode
def test_decode():
    assert decode(b'\\xc3\\xa9') == ('é', 1)
    assert decode(b'\\xc3\\xa9', 'replace') == ('\ufffd', 1)
    assert decode(b'\\xc3\\xa9', 'ignore') == ('', 1)
    assert decode(b'\\xc3\\xa9', 'strict') == ('é', 1)
    assert decode(b'\\xc3\\xa9', 'backslashreplace') == ('é', 1)
    assert decode(b'\\xc3\\xa9', 'xmlcharrefreplace') == ('&#xe9;', 1)

    assert decode(b'\\xc3\\xa9', 'strict') == ('é', 1)
    assert decode(b'\\xc3\\xa9', 'strict') == ('é', 1)


# Generated at 2022-06-21 12:35:00.959590
# Unit test for function decode
def test_decode():
    assert decode(b'\\xC3\\xA9') == ('é', 5)



# Generated at 2022-06-21 12:35:03.168463
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    assert NAME == codecs.lookup(NAME).name


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:35:12.523251
# Unit test for function encode

# Generated at 2022-06-21 12:35:14.619818
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:35:17.416234
# Unit test for function decode
def test_decode():
    b = b'\\x61\\x62\\x63'
    assert(decode(b) == ('abc', 3))



# Generated at 2022-06-21 12:35:28.977001
# Unit test for function decode
def test_decode():
    data_d = b'\\x48\\x65\\x6c\\x6c\\x6f\\x20\\x77\\x6f\\x72"\
        b"\\x6c\\x64\\xe2\\x98\\x84'
    out, length = decode(data_d)
    assert out == "Hello world☄"
    assert len(data_d) == length

    data_d = b'\\x48\\x65\\x6c\\x6c\\x6f\\x20\\x77\\x6f\\x72"\
        b"\\x6c\\x64\\xe2\\x98\\x84'
    out, length = decode(bytearray(data_d))
    assert out == "Hello world☄"
    assert len(data_d) == length

    data

# Generated at 2022-06-21 12:35:35.315707
# Unit test for function encode
def test_encode():

    # No illegal characters
    assert encode('abcdef') == (b'abcdef', 6)

    # No illegal characters
    assert encode('abc\\x23ef') == (b'abc\\x23ef', 9)

    # Illegal characters
    try:
        assert encode('abc\\xGef')
    except UnicodeEncodeError as e:
        assert e.encoding == 'eutf8h'
        assert e.object == 'abc\\xGef'
        assert e.start == 5
        assert e.end == 8
        assert e.reason == 'unmatched ' + '\\'

    # No illegal characters
    assert encode('abc\\x23ef\\x24') == (b'abc\\x23ef\\x24', 12)

    # Illegal characters

# Generated at 2022-06-21 12:35:52.220298
# Unit test for function encode
def test_encode():
    in_str = 'I have a \\x80 string'
    out_bytes, consumed = encode(in_str)
    assert consumed == len(in_str)
    assert out_bytes == b'I have a \\x80 string'
    # Test a different error severity.
    out_bytes, consumed = encode(in_str, 'ignore')
    assert consumed == len(in_str)
    assert out_bytes == b'I have a string'

    in_str = 'I have \\x00 a \\u0080 string'
    try:
        encode(in_str, 'strict')
    except UnicodeEncodeError as e:
        assert e.object == in_str
        assert e.encoding == 'eutf8h'
        assert e.start == 11
        assert e.end == 12

# Generated at 2022-06-21 12:36:03.104448
# Unit test for function decode
def test_decode():
    assert decode(b'\\x74') == ('t', 2)
    assert decode(b'\\x74\\x66\\x69') == ('tfi', 6)
    assert decode(b'\\xe2\\x98\\x80') == ('\u2604', 6)
    assert decode(b'\\x74\\xe2\\x98\\x80\\x66\\x69') == \
        ('t\u2604fi', 12)
    assert decode(b'\\x74\\xe2\\x98\\x80\\x66\\xe2\\x98\\x80') == \
        ('t\u2604f\u2604', 18)

# Generated at 2022-06-21 12:36:14.169984
# Unit test for function decode
def test_decode():
    assert decode(b'U+005C') == ('\\', 6)
    assert decode(b'\\x04') == ('\x04', 5)
    assert decode(b'\\xfa') == ('ú', 5)
    assert decode(b'\\xC3\\xBA') == ('ú', 9)
    assert decode(b'\\u03bb') == ('λ', 6)
    assert decode(b'\\ud801\\udc37') == ('𝐷', 14)
    assert decode(b'x') == ('x', 1)
    assert decode(b'\\') == ('\\', 1)
    assert decode(b'\\xfd') == ('ý', 5)
    assert decode(b'\\U0001D538', '') == ('𝔸', 11)

# Generated at 2022-06-21 12:36:25.928152
# Unit test for function encode
def test_encode():
    from unittest.mock import patch
    from typing import cast

    user_string_obj = UserString('\N{BLACK HEART SUIT}abcd')


# Generated at 2022-06-21 12:36:31.981054
# Unit test for function encode
def test_encode():
    assert codecs.encode(r'\u7E41\u9AD4\u8A71', 'eutf8h') == b'\\xE7\\xB9\\x81\\xE9\\xAB\\x94\\xE8\\xAA\\xB1'

if __name__ == '__main__':
    register()
    print('Encoding example:',
          codecs.encode(r'\u7E41\u9AD4\u8A71', 'eutf8h'))
    print('Decoding example:',
          codecs.decode(b'\\xE7\\xB9\\x81\\xE9\\xAB\\x94\\xE8\\xAA\\xB1', 'eutf8h'))

    test_encode()

# Generated at 2022-06-21 12:36:44.367352
# Unit test for function encode
def test_encode():
    coder = codecs.getencoder('eutf8h')
    assert coder is not None

    # Test a non-escaped string of ASCII characters
    text_str = 'abcdefghijklmnopqrstuvwxyz'
    text_bytes_utf8, count = coder(text_str)
    assert count == len(text_str)
    assert text_bytes_utf8 == b'abcdefghijklmnopqrstuvwxyz'

    # Test a non-escaped string of non-ASCII characters
    text_str = '\u0100\u0101\u0102\u0103\u0104\u0105\u0106\u0107\u0108'
    text_bytes_utf8, count = coder(text_str)

# Generated at 2022-06-21 12:36:47.287808
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)  # type: ignore
    assert codecs.getdecoder(NAME) is not None  # type: ignore



# Generated at 2022-06-21 12:36:50.592320
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)  # type: ignore
    codecs.getdecoder(NAME)
    answer = codecs.lookup(NAME)
    assert NAME in answer.name


# Generated at 2022-06-21 12:37:01.437384
# Unit test for function encode
def test_encode():
    assert encode('hello') == (b'hello', 5)
    assert encode('\u00f6') == (b'\\xc3\\xb6', 1)
    assert encode('\u00f6'.encode('utf-8')) == (b'\\xc3\\xb6', 1)
    assert encode('\u00f6'.encode('latin1')) == (b'\\xc3\\xb6', 1)

    # Check that the 'strict' option produces the same result
    # as the default 'strict' option
    assert encode('hello', 'strict') == encode('hello')
    assert encode('\u00f6', 'strict') == encode('\u00f6')

# Generated at 2022-06-21 12:37:05.473200
# Unit test for function decode
def test_decode():
    assert decode(b'\x20\x3D\x3D\x3D\x3D\x3D\x3D\x22\x22') == (' ====', 9)



# Generated at 2022-06-21 12:37:21.716642
# Unit test for function encode

# Generated at 2022-06-21 12:37:33.113665
# Unit test for function encode
def test_encode():
    assert (encode('100', errors='strict') == (b'\\31\\32\\30', 3))
    assert (encode('100', errors='replace') == (b'\\31\\32\\30', 3))
    assert (encode('100', errors='ignore') == (b'\\31\\32\\30', 3))
    assert (encode('100', errors='xmlcharrefreplace') == (b'\\31\\32\\30', 3))
    assert (encode('ABC', errors='strict') == (b'ABC', 3))
    assert (encode('\u00a9', errors='strict') == (b'\\xc2\\xa9', 1))
    assert (encode(
        '\u00a9', errors='xmlcharrefreplace'
    ) == (b'&#xA9;', 1))

# Generated at 2022-06-21 12:37:38.734796
# Unit test for function encode
def test_encode():
    from unittest.mock import patch

    encode_mock = patch('eutf8h.eutf8h.encode')
    encode_mock.start()

    try:
        text = 'abc'
        encode(text)
        encode.assert_called_once_with(text, 'strict')

        text = 'abc'
        errors = 'ignore'
        encode(text, errors)
        encode.assert_called_with(text, errors)

    finally:
        encode_mock.stop()



# Generated at 2022-06-21 12:37:45.194628
# Unit test for function decode
def test_decode():
    codecs.register(_get_codec_info)

    text = 'yo, \xCE\xBD\xCE\xB9\xCE\xBF\xCF\x82 \xCE\xB1\xCF\x81\xCE\xB5\xCE\xB9\xCE\xB1!'
    data = text.encode('eutf8h')

    assert text == data.decode('eutf8h')



# Generated at 2022-06-21 12:37:57.982130
# Unit test for function encode
def test_encode():
    encoder = codecs.getencoder(NAME)

    assert encoder(r'\x00', 'strict') == (b'\\x00', 1)
    assert encoder(r'\x01', 'strict') == (b'\\x01', 1)
    assert encoder(r'\x02', 'strict') == (b'\\x02', 1)
    assert encoder(r'\xfb', 'strict') == (b'\\xfb', 1)
    assert encoder(r'\xfc', 'strict') == (b'\\xfc', 1)
    assert encoder(r'\xfd', 'strict') == (b'\\xfd', 1)
    assert encoder(r'\xfe', 'strict') == (b'\\xfe', 1)
    assert enc

# Generated at 2022-06-21 12:38:10.265466
# Unit test for function register
def test_register():
    register()

    def _decode_escaped_utf8_hex(data: bytes) -> str:
        return codecs.decode(data, NAME)

    def _encode_escaped_utf8_hex(text: str) -> bytes:
        return codecs.encode(text, NAME)

    assert _encode_escaped_utf8_hex('') == b''
    assert _encode_escaped_utf8_hex('\n') == b'\\x0a'
    assert _encode_escaped_utf8_hex('\x01') == b'\\x01'
    assert _encode_escaped_utf8_hex('\u2713') == b'\\xe2\\x9c\\x93'

# Generated at 2022-06-21 12:38:18.802207
# Unit test for function encode
def test_encode():
    assert encode('ABCDEFG')[0] == b'ABCDEFG'
    assert encode('\\x48')[0] == b'H'
    assert encode('\\x48\\x65\\x6c\\x6c\\x6f\\x20\\x57\\x6f\\x72\\x6c\\x64')[0] == b'Hello World'
    assert encode('\\xe6\\x97\\xa5\\xe6\\x9c\\xac\\xe8\\xaa\\x9e')[0] == b'\xe6\x97\xa5\xe6\x9c\xac\xe8\xaa\x9e'

# Generated at 2022-06-21 12:38:20.949207
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    assert codecs.getdecoder(NAME)


# Unit tests for function decode

# Generated at 2022-06-21 12:38:29.165673
# Unit test for function encode
def test_encode():
    assert encode('\\x41', 'strict') == (b'\\x41', 1)
    assert encode('\u0100', 'strict') == (b'\\x41\\x80', 1)
    assert encode('\u0100', 'ignore') == (b'\\x41', 1)
    assert encode('\\x12\\x34', 'strict') == (b'\\x12\\x34', 4)
    assert encode('\\x12\\x34', 'replace') == (b'\\x12\\xfffd', 4)
    assert encode('\\x12\\x34', 'ignore') == (b'\\x12\\x34', 4)
    assert encode('\\x12\\x34', 'surrogatepass') == (b'\\x12\\x34', 4)

# Generated at 2022-06-21 12:38:37.369078
# Unit test for function encode
def test_encode():
    assert encode('\\xc2\\xa2') == b'\\\\xc2\\\\xa2', \
        "encode('\\xc2\\xa2') should return b'\\\\xc2\\\\xa2'"

    assert encode('\\xc2\\xa2', 'strict') == b'\\\\xc2\\\\xa2', \
        "encode('\\xc2\\xa2', 'strict') should return b'\\\\xc2\\\\xa2'"

    assert encode('\\xc2\\xa2') == b'\\\\xc2\\\\xa2', \
        "encode('\\xc2\\xa2') should return b'\\\\xc2\\\\xa2'"

    with pytest.raises(UnicodeEncodeError, match='eutf8h'):
        encode('\\xDEADBEEF')

# Generated at 2022-06-21 12:38:47.821947
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    try:
        codecs.getencoder('eutf8h')
    except LookupError:
        assert False

# Generated at 2022-06-21 12:38:58.036488
# Unit test for function decode

# Generated at 2022-06-21 12:39:09.656502
# Unit test for function decode
def test_decode():
    from io import StringIO
    from collections import deque

    utf8_hex: str = \
        '{\\xE4}{\\xBD}{\\xA0}{\\xE5}{\\xA5}{\\xBD}{\\xE6}{\\x98}{\\xAF}{}'
    utf8_bytes: bytes = utf8_hex.format(*(chr(n) for n in range(209, 215)))

    utf8_hex_esc: str = '{\\x5C}{\\x78}{0:X}'
    utf8_esc_esc: bytes = b'\\'
    utf8_esc_esc_bytes: bytes = utf8_hex_esc.format(utf8_esc_esc[0]).encode(
        'utf-8'
    )
    utf8

# Generated at 2022-06-21 12:39:18.630432
# Unit test for function encode
def test_encode():
    # Basic test with no hexadecimal characters
    num_given_chars, encoding = encode('The quick brown fox jumps over the lazy dog')
    assert num_given_chars == 43
    assert encoding == b'The quick brown fox jumps over the lazy dog'

    # Basic test with hexadecimal character
    num_given_chars, encoding = encode('Æ')
    assert num_given_chars == 1
    assert encoding == b'\\xc3\\x86'

    # Escaped hexadecimal literal
    num_given_chars, encoding = encode('\\xAB')
    assert num_given_chars == 4
    assert encoding == b'\\xAB'

    # ASCII new line
    num_given_chars, encoding = encode('\n')
    assert num_given_chars == 1

# Generated at 2022-06-21 12:39:22.589667
# Unit test for function register
def test_register():
    """Tests the function register()
    """
    register()
    codecs.getencoder(NAME)  # Should not raise a LookupError
    codecs.getdecoder(NAME)  # Should not raise a LookupError



# Generated at 2022-06-21 12:39:24.032658
# Unit test for function register
def test_register():
    register()
    codecs.lookup_error('strict')


register()

# Generated at 2022-06-21 12:39:34.773045
# Unit test for function decode
def test_decode():
    assert decode(b'') == ('' , 0)
    assert decode(b'abc') == ('abc', 3)
    assert decode(b'\\u0123') == ('\u0123', 7)
    assert decode(b'\\xff') == ('\xff', 4)
    assert decode(b'\\x00') == ('\x00', 4)
    assert decode(b'\\x80') == ('\x80', 4)
    assert decode(b'\\xc2\\x80') == ('\xc2\x80', 8)
    assert decode(b'\\xe0\\xa0\\x80') == ('\xe0\xa0\x80', 12)
    assert decode(b'\\xf0\\x90\\x80\\x80') == ('\xf0\x90\x80\x80', 16)



# Generated at 2022-06-21 12:39:35.979994
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup_error('strict') == codecs.strict_errors

# Generated at 2022-06-21 12:39:44.933122
# Unit test for function decode
def test_decode():
    # Test \uHHHH unicode escape sequences
    s0 = b"\\xE5\\x8A\\xA0\\xE5\\xBF\\xAB\\xE5\\xB7\\xAE\\xE5\\x8A\\xA0"
    s1 = "\\u52a0\\u5feb\\u5e06\\u52a0"
    assert decode(s0) == (s1, len(s0))
    assert decode(s1) == (s1, len(s0))
    assert decode(s1, 'replace') == (s1, len(s0))
    assert decode(s1, 'ignore') == ('', 8)
    assert decode(s1, 'backslashreplace') == (s1, len(s0))

    # Test \UHHHHHHHH unicode escape sequences

# Generated at 2022-06-21 12:39:55.618364
# Unit test for function decode
def test_decode():
    assert decode(b'\\x64') == ('d', 2)
    # assert decode(b'\\x80') == ('\uFFFD', 2)
    try:
        decode(b'\\x80')
    except UnicodeDecodeError:
        pass
    else:
        raise RuntimeError('test_decode_error_level_strict')
    try:
        decode(b'\\x80', 'replace')
    except UnicodeDecodeError:
        raise RuntimeError('test_decode_error_level_replace')
    else:
        pass
    try:
        decode(b'\\x80', 'ignore')
    except UnicodeDecodeError:
        raise RuntimeError('test_decode_error_level_ignore')
    else:
        pass

# Generated at 2022-06-21 12:40:17.604187
# Unit test for function encode
def test_encode():
    a = encode('ñ')
    assert a == (b"\\xc3\\xb1", 1)
    a = encode('ñ', 'replace')
    assert a == (b"\\xef\\xbf\\xbd", 1)
    # print("--test_encode")


# Generated at 2022-06-21 12:40:22.624873
# Unit test for function decode
def test_decode():
    # Test decode
    print(decode(b'\\x5Fasd', 'strict'))
    print(decode(b'\\x5Fasd\\x7Fads'))
    print(decode(b'\\x7Fads'))
    print(decode(b'alo\\xFFasd'))
    print('------------------------------')



# Generated at 2022-06-21 12:40:30.577057
# Unit test for function encode
def test_encode():

    # Count the number of steps through the while loop.
    step_num = 0

    # Variables used to test the while loop.
    tests_passed = 0
    tests_failed = 0

    # Test valid escape sequences.
    # Test 1:  \x20
    step_num = step_num + 1
    try:
        out = encode('\\x20')
        if out == (b'\\x20', 3):
            tests_passed = tests_passed + 1
        else:
            tests_failed = tests_failed + 1
    except Exception:
        tests_failed = tests_failed + 1
    # Test 2:  \xFF
    step_num = step_num + 1

# Generated at 2022-06-21 12:40:39.822286
# Unit test for function encode
def test_encode():
    assert encode('abc') == (b'abc', 3)
    assert encode('abc\\x20') == (b'abc\\x20', 7)
    assert encode('abc\\x80') == (b'abc\\xc2\\x80', 7)
    assert encode('\\x80') == (b'\\xc2\\x80', 3)
    assert encode('\\x80\\xc3\\xa9') == (b'\\xc2\\x80\\xc3\\xa9', 7)
    assert encode('\\xc3\\xa9') == (b'\\xc3\\xa9', 3)
    assert encode('\\xc3a9') == (b'\\xc3a9', 3)
    assert encode('\\U00099999') == (b'\\xf2\\x94\\x87\\x99', 5)

# Generated at 2022-06-21 12:40:42.168957
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-21 12:40:44.179002
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:40:54.090514
# Unit test for function decode
def test_decode():
    assert decode(b'\\xA3') == ('£', 4)
    assert decode(b'\\x3D') == ('=', 4)
    assert decode(b'\\x3D\\x3D') == ('==', 8)
    assert decode(b'\\x2A\\x2A\\x2A') == ('***', 12)
    assert decode(b'\\x1b') == ('\x1b', 4)
    assert decode(b'\\x1b\\x5b') == ('\x1b[', 8)
    assert decode(b'\\x1b\\x5b\\x31') == ('\x1b[1', 12)
    assert decode(b'\\x1b\\x5b\\x33') == ('\x1b[3', 12)

# Generated at 2022-06-21 12:40:54.708898
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-21 12:40:59.082906
# Unit test for function decode
def test_decode():
    assert decode(b'\\x48', 'strict') == ('H', 1)
    assert decode(b'\\x48\\x65\\x6c\\x6c\\x6f', 'strict') == ('Hello', 5)
    assert decode(b'Hello', 'strict') == ('Hello', 5)
    assert decode(b'\\xe0\\x80\\x80', 'strict') == ('\u0000', 3)
    assert decode(b'\\xe0\\x80\\x80', 'ignore') == ('', 3)
    assert decode(b'\\xe0\\x80\\x80', 'replace') == ('?', 3)
    assert decode(b'\\xe0\\x80\\x80', 'backslashreplace') == ('\\xe0\\x80\\x80', 3)

# Generated at 2022-06-21 12:41:05.058975
# Unit test for function encode
def test_encode():
    input_text = "Hello\\x56orld"
    expected_bytes = b"Hello\\x56orld"
    output_bytes, chars_consumed = encode(input_text)
    assert output_bytes == expected_bytes
    assert chars_consumed == len(input_text)


# Generated at 2022-06-21 12:41:43.181857
# Unit test for function decode
def test_decode():
    dst = decode(b'\\xe2\\x8c\\x93')
    assert dst == ('✓', 9)



# Generated at 2022-06-21 12:41:44.207038
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-21 12:41:52.420839
# Unit test for function encode
def test_encode():
    # Test 1
    text = "Hello, \x0A\x0D\x09\x08\t\n\t\n\n\r\t\t\t\n\t\t\t\\n"
    output = b"Hello, \\x0a\\x0d\\x09\\x08\\t\\n\\t\\n\\n\\r\\t\\t\\t\\n\\t\\t\\t\\x0a"
    assert encode(text) == (output, len(text))


# Generated at 2022-06-21 12:41:54.913376
# Unit test for function encode
def test_encode():
    assert encode('Luke') == (b'\\x4c\\x75\\x6b\\x65', 4)
    assert encode('\u260f') == (b'\\xE2\\x98\\x8F', 1)
    assert encode('\u260f\u260e') == (b'\\xE2\\x98\\x8F\\xE2\\x98\\x8E', 2)


# Generated at 2022-06-21 12:41:58.631625
# Unit test for function decode
def test_decode():
    """

    :return:
    """
    assert decode(b'z') == ('z', 1)
    assert decode(b'\\x61') == ('a', 4)
    assert decode(b'\\x61\\x62') == ('ab', 7)



# Generated at 2022-06-21 12:42:01.837359
# Unit test for function decode
def test_decode():
    text = '\\x41\\x5a\\xe5\\x86\\xb5'
    decode_str, consume_int = decode(bytes(text, 'utf-8'))
    assert decode_str == 'AZ镵'
    assert consume_int == len(text)

# Generated at 2022-06-21 12:42:07.146406
# Unit test for function decode
def test_decode():
    tests = [
        (
            b'\\x74\\x65\\x73\\x74',
            'test',
        ),
        (
            b'\\x65\\x75\\x74\\x66\\x38\\x68\\x65\\x78\\x74\\x65\\x73\\x74',
            'eutf8hextest',
        ),
        (
            b'abc',
            'abc',
        ),
        (
            b'\\x30',
            '0',
        ),
    ]

    for arg1, ref in tests:
        out, n = decode(arg1)
        print(f'got: {out},{n}, expected: {ref},{len(arg1)}')
        assert n == len(arg1)
        assert out == ref



# Generated at 2022-06-21 12:42:18.673494
# Unit test for function decode
def test_decode():
    """
    Unit test for function decode
    """
    # Input

# Generated at 2022-06-21 12:42:20.326075
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME)



# Generated at 2022-06-21 12:42:25.573543
# Unit test for function register
def test_register():
    # Fix unicode representation for these tests.
    sys.stdout = codecs.getwriter('utf8')(sys.stdout.detach())

    register()

    try:
        codecs.getencoder(NAME)
    except LookupError as e:
        raise AssertionError(str(e))

    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise AssertionError(str(e))

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:43:44.923888
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)



# Generated at 2022-06-21 12:43:47.476329
# Unit test for function register
def test_register():
    register()
    from codecs import getdecoder
    decoder = getdecoder(NAME)
    assert decoder is not None

# Generated at 2022-06-21 12:43:57.072032
# Unit test for function decode
def test_decode():
    # Test 1
    data = b'\\u00e0\\u00e1\\u00e2\\u00e3\\u00e4\\u00e5\\u00e6'
    data = cast(bytes, data)
    expected = 'àáâãäåæ'
    actual, _ = decode(data)
    assert actual == expected

    # Test 2
    data = b'\\xE0\\xE1\\xE2\\xE3\\xE4\\xE5\\xE6'
    data = cast(bytes, data)
    expected = 'àáâãäåæ'
    actual, _ = decode(data)
    assert actual == expected

    # Test 3
    data = b'\\xe0\\xe1\\xe2\\xe3\\xe4\\xe5\\xe6'
   

# Generated at 2022-06-21 12:43:58.924446
# Unit test for function decode
def test_decode():
    assert decode(b'\\x41\\x42\\x43') == ('ABC', 12)



# Generated at 2022-06-21 12:44:09.571439
# Unit test for function encode
def test_encode():
    # noinspection PyUnusedLocal
    def test_case(text: str, errors: str, expected: bytes) -> None:
        act = encode(text, errors)
        assert act == expected

    test_case(
        text='a',
        errors='strict',
        expected=b'a',
    )

    test_case(
        text='\\x1f',
        errors='strict',
        expected=b'\\x1f',
    )

    test_case(
        text='a\\xC2b',
        errors='strict',
        expected=b'a\\xc2b',
    )


# Generated at 2022-06-21 12:44:12.997967
# Unit test for function decode
def test_decode():
    expected = 'hello world!'
    str_hex = r'hello\x20world\x21'
    result = decode(str_hex.encode('utf8'))
    assert (result[0] == expected)
    print('Unit test Decode Passed')


# Generated at 2022-06-21 12:44:24.291137
# Unit test for function decode
def test_decode():
    assert decode(b"") == ("", 0)
    assert decode(b"8") == ("8", 1)
    assert decode(b"88") == ("88", 2)
    assert decode(b"8\x88") == ("8\u2260", 3)
    assert decode(b"\\x88\\x81") == ("\u2261\u2051", 7)

    assert decode(b"\\x88\\x81") == ("\u2261\u2051", 7)
    assert decode(b"\\x88\\x81",'strict') == ("\u2261\u2051", 7)
    assert decode(b"\\x88\\x81",'ignore') == ("\u2261", 5)

# Generated at 2022-06-21 12:44:25.998881
# Unit test for function encode
def test_encode():
    print(encode(r'\xFF\xFF'))
    return


# Generated at 2022-06-21 12:44:37.285583
# Unit test for function decode
def test_decode():

    # Unit test for function decode
    def _test_decode(
            # The input bytes
            data: _ByteString,

            # The expected output
            expected: str,

            # The expected number of output bytes consumed
            expected_byte_count: Optional[int] = None,

            # The errors type
            errors: str = 'strict',
    ) -> None:

        # The function under test
        decode_uut = decode

        # The actual output decoded string
        actual_decoded: str

        # The actual number of output bytes consumed
        actual_byte_count: int

        # Run the function under test
        actual_decoded, actual_byte_count = decode_uut(
            data=data,
            errors=errors,
        )

        # Verify the actual output matches the expected output
        assert actual_decoded