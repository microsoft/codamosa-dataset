

# Generated at 2022-06-21 12:34:52.581136
# Unit test for function decode
def test_decode():
    test_str_hex = '\\xe2\\x9c\\xa8'

    test_bytes_hex = test_str_hex.encode('latin1')

    test_str, chars_consumed = decode(test_bytes_hex)

    assert test_str == '\u2728'

    assert chars_consumed == 1



# Generated at 2022-06-21 12:34:55.854243
# Unit test for function decode
def test_decode():
    text = 'Hello, World!'
    data = text.encode('utf-8')
    for i in range(len(data)):
        data_ = data[:i]
        out, _ = decode(data_)
        assert out == text
    data = b'\xe2\x82\xac'  # Euro symbol
    out, _ = decode(data)
    assert out == '€'


# Generated at 2022-06-21 12:35:05.996913
# Unit test for function decode
def test_decode():
    assert decode(b'\\x61')[0] == 'a'
    assert decode(b'\\x61\\x62')[0] == 'ab'
    assert decode(b'\\x61\\x62\\x63')[0] == 'abc'
    assert decode(b'\\x61\\x62\\x63\\x64')[0] == 'abcd'
    assert decode(b'\\x61\\x62\\x63\\x64\\x65')[0] == 'abcde'
    assert decode(b'\\x61\\x62\\x63\\x64\\x65\\x66')[0] == 'abcdef'
    assert decode(b'\\x61\\x62\\x63\\x64\\x65\\x66\\x67')[0] == 'abcdefg'

# Generated at 2022-06-21 12:35:09.552559
# Unit test for function register
def test_register():
    register()
    test_data = 'hello world'
    encoded_data, _ = encode(test_data)
    decoded_data, _ = decode(
        encoded_data,
        errors='strict'
    )
    assert test_data == decoded_data


register()

# Generated at 2022-06-21 12:35:16.478313
# Unit test for function decode
def test_decode():
    hex_str: str = r'\xc3\xa9\xc3\x89'
    hex_str_bytes = hex_str.encode('utf8')
    decoded_str, decoded_len = decode(hex_str_bytes)
    assert decoded_str == 'éÉ'
    assert decoded_len == len(hex_str_bytes)

    hex_str = 'asdf'
    hex_str_bytes = hex_str.encode('utf8')
    decoded_str, decoded_len = decode(hex_str_bytes, 'strict')
    assert decoded_str == hex_str
    assert decoded_len == len(hex_str_bytes)

    # Illegal UTF-8 byte sequences
    # \x80 is illegal because it is a byte continuation byte.
    illegal_hex_str

# Generated at 2022-06-21 12:35:28.411929
# Unit test for function decode
def test_decode():
    """Unit test for function decode"""

    # Empty input
    assert decode(b'') == ('', 0)

    # One 7-bit latin-1 character
    assert decode(b'a') == ('a', 1)

    # One escaped hexadecimal string
    assert decode(b'\\x20') == (' ', 3)

    # Multibyte utf8 string with mixed escaped hexadecimal strings.
    # The string is the character '\u23E0' in hexadecimal.
    assert decode(b'\\xE2\\x8C\\xA0\\x20') == ('\u23E0 ', 9)

    # Invalid escaped characters (characters out of range)
    try:
        decode(b'\\xGG')
        assert False
    except UnicodeDecodeError:
        pass

    # Invalid

# Generated at 2022-06-21 12:35:35.042792
# Unit test for function encode
def test_encode():
    text_input1 = 'hi'
    out1 = 'hi'
    assert encode(text_input1) == (out1.encode(), len(text_input1))

    text_input2 = 'X'
    out2 = '\\x58'
    assert encode(text_input2) == (out2.encode(), len(text_input2))

    text_input3 = 'foo\x00'
    out3 = 'foo\\x00'
    assert encode(text_input3) == (out3.encode(), len(text_input3))

    text_input4 = 'a\ua000b'
    out4 = 'a\\uA000b'
    assert encode(text_input4) == (out4.encode(), len(text_input4))


# Generated at 2022-06-21 12:35:46.942751
# Unit test for function decode
def test_decode():
    # Test decoding escaped utf8 characters as hexadecimal
    assert decode(b'\\xc3\\xa4') == ('ä', 7)

    # Test decoding regular utf8 characters
    assert decode(b'\\xe2\\x80\\xa6') == ('…', 13)

    # Test decoding escaped utf8 characters as hexadecimal
    assert decode(b'\\xc3\\xa4') == ('ä', 7)

    # Test decoding regular utf8 characters
    assert decode(b'\\xe2\\x80\\xa6') == ('…', 13)

    # Test returning a string and the number of bytes consumed.
    assert decode(b'\\xc3\\xa4-\\xe2\\x80\\xa6') == ('ä-…', 20)

    # Test decoding with surrogates

# Generated at 2022-06-21 12:35:51.932313
# Unit test for function encode
def test_encode():
    assert encode('\x20') == b'\\x20'
    assert encode('\x80') == b'\\xc2\\x80'
    assert encode('\x00') == b'\\xc0\\x80'
    assert encode('\x7f') == b'\\x7f'



# Generated at 2022-06-21 12:36:02.933257
# Unit test for function decode

# Generated at 2022-06-21 12:36:09.740383
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)  # Should not raise an error



# Generated at 2022-06-21 12:36:18.228723
# Unit test for function decode
def test_decode():
    # Convert memoryview and bytearray objects to bytes.
    # data_bytes = bytes(data)

    # Convert the given 'errors', that are of type UserString into a str.
    # errors_input = str(errors)

    # Convert the utf8 bytes into a string of latin-1 characters.
    # This basically maps the exact utf8 bytes to the string. Also,
    # this converts any escaped hexadecimal sequences \\xHH into
    # \xHH bytes.
    text_str_latin1 = b'\\xC2\\xA0'.decode('unicode_escape')

    # Convert the string of latin-1 characters (which are actually
    # utf8 characters) into bytes.
    text_bytes_utf8 = text_str_latin1.encode('latin1')

    #

# Generated at 2022-06-21 12:36:28.542728
# Unit test for function decode
def test_decode():
    # The following are valid utf8 hexadecimal representing a latin capital
    # 'A' (0x41 in hexadecimal)
    # '\xFF' is an invalid utf8 hexadecimal
    # '\x41' is an invalid utf8 hexadecimal because it is a single hexadecimal
    # digit
    # '\x41' is also an invalid utf8 hexadecimal because it is not valid
    # unicode
    # '\u0041' is valid unicode, but not valid utf8 hexadecimal
    strs = [
        'A',
        '\\x41',
        '\\x41A',
        '\\x1F',
        '\\xFF',
        '\\u0041'
    ]

    # Create bytes to test.
    data

# Generated at 2022-06-21 12:36:41.700394
# Unit test for function encode
def test_encode():
    test_data = [
        'abcdefg',
        # 'a\\x61b\\x62c\\x63d\\x64e\\x66f\\x67',
        'a\\x61b\\x62c\\x63d\\x63e\\x66f\\x67',
        'a\\x61b\\x62c\\x63d\\x63e\\x66f\\x67',
        'hello world',
        '\U00010100',
        '\U00010100',
    ]

# Generated at 2022-06-21 12:36:44.997246
# Unit test for function register
def test_register():
    NAME = __name__.split('.')[-1]

    assert NAME == 'eutf8h'

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()

    assert codecs.getdecoder(NAME) is not None

# Generated at 2022-06-21 12:36:46.412210
# Unit test for function register
def test_register():
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:36:50.207502
# Unit test for function decode
def test_decode():
    s = bytes(r'\x72\x65\x73\x75\x6c\x74', 'ascii')
    r = decode(s)
    assert r == ('result', 6)

    s = bytes(r'\x61', 'ascii')
    r = decode(s)
    assert r == ('\\x61', 2)


# Generated at 2022-06-21 12:36:57.787959
# Unit test for function decode
def test_decode():
    text_escaped = 'A\\x61\\x62c\\x63\n'
    (text, length) = decode(text_escaped)
    assert text == 'Abc\n'
    assert length == len(text_escaped)
    # Unit test for function encode
    (bytes, length) = encode(text)
    assert bytes == text_escaped.encode('utf-8')
    assert length == len(text)

# Generated at 2022-06-21 12:37:09.251196
# Unit test for function encode
def test_encode():

    # Test unprintable characters.
    out, _ = encode('\u1F631', 'strict')
    assert out == b'\\xf0\\x9f\\x98\\xb1'

    # Test non-ascii characters.
    out, _ = encode('\u305D', 'strict')
    assert out == b'\\xe3\\x81\\x9d'

    # Input is of type UserString.
    class DummyStr(UserString):
        def __new__(cls, *args, **kwargs):
            return super(DummyStr, cls).__new__(cls, *args, **kwargs)
        pass
    dummy = DummyStr('\u305D')
    out, _ = encode(dummy, 'strict')

# Generated at 2022-06-21 12:37:17.472510
# Unit test for function register
def test_register():
    # noinspection PyUnresolvedReferences
    from . import encoder_utf8_hex
    del encoder_utf8_hex  # Mock import
    register()
    assert codecs.lookup_error(NAME) is codecs.lookup_error('eutf8h')
    assert codecs.lookup(NAME) is not None


if __name__ == '__main__':
    print(encode(b'\\123'))
    print(decode(b'\\x2b\\x2b\\x2b'))

# Generated at 2022-06-21 12:37:29.581049
# Unit test for function register
def test_register():
    # The (initial) codecs.getdecoder(NAME) lookup should fail.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise NameError('test_register: The initial codecs.getdecoder(NAME) '
                        'lookup should fail.')
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise NameError('test_register: The codecs.getdecoder(NAME) lookup '
                        'should not fail.')


# Generated at 2022-06-21 12:37:38.677241
# Unit test for function encode
def test_encode():
    import pytest
    from pprint import pprint
    from _test_funcs import test_function_output, test_function_output_regex

    # Test that no exceptions are raised.
    test_function_output(encode, [
        (b'abc', 'strict'),
    ])

    # Test that exceptions are raised.
    with pytest.raises(AssertionError):
        pprint(encode(b'abc', 'strict'))
    with pytest.raises(AssertionError):
        pprint(encode(b'\\x61\\x61', 'strict'))

    # Test that non exceptions are not raised.

# Generated at 2022-06-21 12:37:47.969877
# Unit test for function encode
def test_encode():
    str_latin1 = '\x7F\x00\x80\xFF'
    str_utf8 = str_latin1.encode('utf-8')

    assert encode('\x7F\x00\x80\xFF') == (str_utf8, 4)
    assert (
        encode('\\x7F\\x00\\x80\\xFF') ==
        (str_utf8, 8)
    )
    assert (
        encode('\\x7F\\x00\\x80\\xFF ', errors='ignore') ==
        (str_utf8, 8)
    )
    assert (
        encode('\\x7F\\x00\\x80\\xFF ', errors='replace') ==
        (str_utf8 + b'\xEF\xBF\xBD', 8)
    )


# Generated at 2022-06-21 12:37:59.950523
# Unit test for function encode
def test_encode():
    s = '\u25a0'  # unicode block character
    assert '\\xe2\\x96\\xa0' == encode(s)[0].decode('utf-8'), \
        'expected \\xe2\\x96\\xa0, got {}'.format(encode(s)[0].decode('utf-8'))

    s = '\\U00025a0'  # unicode block character (16 bit)
    assert '\\xe2\\x96\\xa0' == encode(s)[0].decode('utf-8'), \
        'expected \\xe2\\x96\\xa0, got {}'.format(encode(s)[0].decode('utf-8'))

    s = '\\xE2\\x96\\xA0'  # unicode block character (8 bit)

# Generated at 2022-06-21 12:38:12.420627
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode('Hello world!', 'ignore') == (b'Hello\\20world!', 12)

# Generated at 2022-06-21 12:38:19.713370
# Unit test for function decode
def test_decode():
    # Basic tests

    # Empty string test
    empty_str: _ByteString = cast(bytes, b'')
    empty_str_converted, length_consumed = decode(empty_str)
    assert length_consumed == 0
    assert empty_str_converted == ''

    # Normal string test
    normal_str: _ByteString = cast(bytes, b'a')
    normal_str_converted, length_consumed = decode(normal_str)
    assert length_consumed == 1
    assert normal_str_converted == 'a'

    # Convert a utf8 hexadecimal sequence test
    utf8_converted_str: _ByteString = \
        cast(bytes, b"\\x3C\\x3F\\x70\\x68\\x70")
    utf8_converted_str

# Generated at 2022-06-21 12:38:22.560470
# Unit test for function encode
def test_encode():
    assert b"1234\\x01" == encode("1234\x01")[0]
    assert b'\\x0a' == encode('\x0a')[0]

# Unit tests for function decode

# Generated at 2022-06-21 12:38:30.122856
# Unit test for function encode
def test_encode():
    # Test for converting a latin-1 char (that are not utf8)
    # into a string of escaped utf8 hex.
    assert encode('\u1234') == (b'\\xe1\\x88\\xb4', 1)

    # Test for converting a printable char (that are not utf8)
    # into a string of escaped utf8 hex.
    assert encode('\u00A8') == (b'\\xc2\\xa8', 1)

    # Test for converting a unicode char (that are utf8)
    # into a string of escaped utf8 hex.
    assert encode('\u1F600') == (b'\\xf0\\x9f\\x98\\x80', 1)

    # Test for converting a string of escaped utf8 hex.

# Generated at 2022-06-21 12:38:32.117591
# Unit test for function register
def test_register():

    try:
        codecs.getencoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)  # type: ignore



# Generated at 2022-06-21 12:38:41.738428
# Unit test for function decode
def test_decode():
    # Test string = "Néstor"
    # Test string = "N\xc3\xa9stor"
    # Test string = "\xc3\x90\xc2\x94\xc3\x90\xc2\xb5"
    # Test string = b'N\x00e\x00s\x00t\x00o\x00r\x00'
    # Test string = b'\xc3\x90\xc2\x94\xc3\x90\xc2\xb5'

    name_str = "Néstor"
    name_bytes = b'N\xc3\xa9stor'
    name_bytes_eutf8h = b'N\x5c\x78\xc3\xa9\x73\x74\x6f\x72'
    name

# Generated at 2022-06-21 12:38:55.534759
# Unit test for function encode
def test_encode():
    test_string = "\\x61"
    actual = encode(test_string)
    expected = (b"\\x61", 1)
    assert actual == expected

    test_string = "a"
    actual = encode(test_string)
    expected = (b"a", 1)
    assert actual == expected

    test_string = "c"
    actual = encode(test_string)
    expected = (b"c", 1)
    assert actual == expected

    test_string = "あ"
    actual = encode(test_string)
    expected = (b"\\xe3\\x81\\x82", 1)
    assert actual == expected

    test_string = "\\xe3"
    actual = encode(test_string)
    expected = (b"a", 1)
    assert actual == expected


# Generated at 2022-06-21 12:38:57.868941
# Unit test for function decode
def test_decode():
    data = b'\\xC2\\xA2\\xC2\\xA3'
    errors = 'strict'
    return decode(data, errors)


# Generated at 2022-06-21 12:39:03.471568
# Unit test for function register
def test_register():
    register()
    obj = codecs.getdecoder(NAME)
    assert obj is _get_codec_info(NAME)
    assert obj.name == NAME
    assert isinstance(obj.encode, type(lambda x: x))
    assert isinstance(obj.decode, type(lambda x: x))



# Generated at 2022-06-21 12:39:14.212824
# Unit test for function encode
def test_encode():
    assert encode('a') == (b'a', 1)
    assert encode('abc') == (b'abc', 3)
    assert encode('\n') == (b'\\A', 1)
    assert encode('ab\ncd') == (b'ab\\Acd', 5)
    assert encode('\nab\ncd') == (b'\\Aab\\Acd', 7)
    assert encode('\u0061') == (b'a', 1)
    assert encode('\u0061\u0062') == (b'ab', 2)
    assert encode('a\u0061b') == (b'aab', 3)
    assert encode('ab\u0061c') == (b'abac', 3)
    assert encode('a\u0061c') == (b'aac', 2)
    assert encode

# Generated at 2022-06-21 12:39:15.552489
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# Generated at 2022-06-21 12:39:17.566431
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)

# Generated at 2022-06-21 12:39:29.051555
# Unit test for function encode
def test_encode():
    e = encode('a', 'strict')
    assert e == (b'a', 1)

    e = encode('a', 'ignore')
    assert e == (b'a', 1)

    e = encode('a', 'replace')
    assert e == (b'a', 1)

    e = encode('a', 'surrogateescape')
    assert e == (b'a', 1)

    e = encode('a', 'surrogatepass')
    assert e == (b'a', 1)

    e = encode('a', 0)
    assert e == (b'a', 1)

    e = encode(u'b', 'strict')
    assert e == (b'b', 1)

    e = encode(u'b', 'ignore')
    assert e == (b'b', 1)

    e = encode

# Generated at 2022-06-21 12:39:38.432370
# Unit test for function decode
def test_decode():
    s = b'\\xE0\\xB8\\xA7\\xE0\\xB8\\xB4\\xE0\\xB8\\x99\\xE0\\xB8\\x94\\xE0\\xB8' \
        b'\\xB5\\xE0\\xB8\\xAB'
    d = decode(s)[0]
    assert d == '็์๙๔๵ห'

    s = b'\\xE0\\xB8X'
    try:
        decode(s)
        assert False
    except UnicodeDecodeError as e:
        assert e.reason == 'invalid continuation byte'

    s = b'\\xA0'

# Generated at 2022-06-21 12:39:48.368611
# Unit test for function encode
def test_encode():
    assert encode("Hello, world!") == (b'Hello, world!', 13)
    assert encode("Hello, 世界") == (b'Hello, \\xe4\\xb8\\x96\\xe7\\x95\\x8c', 19)
    assert encode("Hello, \\xe4\\xb8\\x96\\xe7\\x95\\x8c") == (
        b'Hello, \\xe4\\xb8\\x96\\xe7\\x95\\x8c', 24)
    assert encode("Hello, \\xe4\\xb8\\x96\\xe7\\x95\\x8c", errors='strict') == (
        b'Hello, \\xe4\\xb8\\x96\\xe7\\x95\\x8c', 24)

# Generated at 2022-06-21 12:39:54.545426
# Unit test for function decode
def test_decode():
    # test_decode_sample
    input = b'A\\x41\\x41\\x41'
    output = decode(input)[0]
    assert output == 'AAA'
    # test_decode_error
    input = b'\\x41\\x41\\x41'
    try:
        decode(input)
        assert False
    except UnicodeDecodeError:
        assert True



# Generated at 2022-06-21 12:40:15.425807
# Unit test for function register
def test_register():
    # Test to make sure that the codec is not registered before registration.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        assert False, f'{NAME} codec should not be registered before registration'

    # Test to make sure that the codec is registered after registration.
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, f'{NAME} codec should be registered after registration'



# Generated at 2022-06-21 12:40:18.258466
# Unit test for function register
def test_register():

    # Make the function reloaded
    import importlib
    importlib.reload(sys.modules[__name__])

    # Make sure the function is reloaded
    import codecs

    codecs.getdecoder(NAME)

# Generated at 2022-06-21 12:40:20.836790
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)    # type: ignore



# Generated at 2022-06-21 12:40:23.970626
# Unit test for function encode
def test_encode():
    s = '\u4e2d\u6587'
    print(codecs.encode(s, 'eutf8h'))
    # print(encode(s))


# Generated at 2022-06-21 12:40:32.929631
# Unit test for function decode
def test_decode():
    assert decode(b'\\x20') == (' ', 3)
    assert decode(b'\\xC3') == ('\uFFFD', 6)
    assert decode(b'\\xC3\\x20') == ('\u0020', 9)
    assert decode(b'\\xC3', errors='ignore') == ('', 6)
    assert decode(b'\\xC3\\x20', errors='ignore') == ('', 9)
    assert decode(b'\\xC3', errors='replace') == ('�', 6)
    assert decode(b'\\xC3\\x20', errors='replace') == ('� ', 9)
    assert decode(b'\\xC3', errors='xmlcharrefreplace') == ('&#195;', 7)

# Generated at 2022-06-21 12:40:41.066117
# Unit test for function decode
def test_decode():
    result = decode(b'\\u3050\\u0000\\u3060\\u3051\\u3061')
    expected = '\u3050\u0000\u3060\u3051\u3061'
    assert result[0] == expected
    assert result[1] == 22
    assert decode(b'\\u0000')[0] == '\u0000'
    assert decode(b'\\x00')[0] == '\x00'
    assert decode(b'\\xA2')[0] == '\xa2'
    assert decode(b'\\xA2', 'ignore')[0] == ''
    assert decode(b'\\u11A2')[0] == '\u11a2'
    assert decode(b'\\u11A2', 'ignore')[0] == ''

# Generated at 2022-06-21 12:40:51.561201
# Unit test for function decode
def test_decode():
    # all the strings were copied from encode.c of shellshock 's source code.
    def _do_test(in_, out_):
        out = codecs.decode(in_, 'eutf8h')
        assert out == out_
    _do_test(b"\x5c\x78\x30\x61", "\\x0a")  # '\x0a'

# Generated at 2022-06-21 12:40:57.887706
# Unit test for function decode

# Generated at 2022-06-21 12:41:03.832868
# Unit test for function register
def test_register():
    from unittest import TestCase

    class RegisterTestCase(TestCase):
        def test_register(self):
            register()
            self.assertTrue(True)

    test_case = RegisterTestCase()
    test_case.test_register()


# Generated at 2022-06-21 12:41:08.685536
# Unit test for function decode
def test_decode():
    old_text = "ä"
    old_text_utf8 = old_text.encode('utf-8')
    old_text_escaped = old_text_utf8.decode('unicode_escape')
    new_text, _ = decode(old_text_escaped)

    assert old_text == new_text


# Generated at 2022-06-21 12:41:40.261482
# Unit test for function encode
def test_encode():
    assert encode('\u0fff') == b'\\xef\\xbf\\xbf'



# Generated at 2022-06-21 12:41:42.959564
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


register()



# Generated at 2022-06-21 12:41:54.292299
# Unit test for function decode

# Generated at 2022-06-21 12:41:58.982914
# Unit test for function encode

# Generated at 2022-06-21 12:42:09.419019
# Unit test for function register
def test_register():
    #
    # This function should be called only once per interpreter session.
    # We do this instead of registering the codec in a more traditional
    # way to prevent memory leaks.
    #
    register()

    # Verify that the codec has been registered.
    codecs.getencoder(NAME)


if __name__ == '__main__':
    test_register()



# Generated at 2022-06-21 12:42:11.827883
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore
    assert codecs.getdecoder(NAME)


# Generated at 2022-06-21 12:42:13.156194
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-21 12:42:19.142885
# Unit test for function decode
def test_decode():
    data_byte_array = bytearray(
        b'\\x48\\x65\\x6c\\x6c\\x6f\\x20\\xe4\\xbd\\xa0\\xe5\\xa5\\xbd',
    )

    assert (
        decode(data_byte_array)[0]
        ==
        'Hello 你好'
    )


# Generated at 2022-06-21 12:42:19.870805
# Unit test for function register
def test_register():
    import codecs
    register()
    print(codecs.getdecoder(NAME))

# Generated at 2022-06-21 12:42:28.101272
# Unit test for function encode
def test_encode():
    str_input = 'ķ\u00a7ñ÷\u20ac'
    bytes_output = encode(str_input)[0]
    assert bytes_output == b'\\xcc\\xba\\xa7\\xc3\\xb1\\xc3\\xb7\\xe2\\x82\\xac'

    # Test for error correctness
    err = 'replace'
    byte_input = b'\xc2\x80' * 5
    byte_output = encode(byte_input, err)[0]
    assert byte_output == b'\\x80\\x80\\x80\\x80\\x80'

    err = 'backslashreplace'
    byte_input = b'\xc2\x80' * 5
    byte_output = encode(byte_input, err)[0]

# Generated at 2022-06-21 12:43:38.110598
# Unit test for function register
def test_register():
    assert codecs.lookup_error('strict') is codecs.strict_errors
    orig_getdecoder = codecs.getdecoder
    try:
        codecs.getdecoder = lambda name: None if name == NAME else orig_getdecoder(name)
        register()
        assert codecs.getdecoder(NAME) is not None

    finally:
        codecs.getdecoder = orig_getdecoder


register()

# Generated at 2022-06-21 12:43:45.225181
# Unit test for function encode
def test_encode():
    assert b'\\x41\\x42\\x43\\x44\\xf0\\x9f\\x98\\x81' == encode('ABCD😁')
    assert b'\\x2d' == encode(r'\-')
    assert b'\\x41\\x5c\\x78\\x34\\x32\\x2a' == encode(r'A\x42*')
    assert b'\\x5c\\x5c\\x5c\\x78\\x35\\x6b\\x6f' == encode(r'\\x5ko')



# Generated at 2022-06-21 12:43:47.670606
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False
    assert True


# Generated at 2022-06-21 12:43:51.001540
# Unit test for function register
def test_register():
    assert codecs.lookup_error('test') is ValueError
    register()
    assert codecs.lookup_error(NAME) is UnicodeDecodeError



# Generated at 2022-06-21 12:43:53.447890
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        msg = f'Codec {NAME!r} is not registered'
        assert msg == str(e)
    else:
        assert True, 'Codec is registered'



# Generated at 2022-06-21 12:44:00.614173
# Unit test for function decode
def test_decode():
    assert decode(b'foo')[0] == 'foo'
    assert decode(b'foo\\xC0')[0] == 'fooÀ'
    assert decode(b'foo\\xC0')[1] == len(b'foo\\xC0')
    assert decode(b'foo\\xC0', 'replace')[0] == 'foo�'
    assert decode(b'foo\\xC0', 'replace')[1] == len(b'foo\\xC0')
    assert decode(b'foo\\xC0', 'replace')[0] == 'foo�'
    assert decode(b'foo\\xC0', 'replace')[1] == len(b'foo\\xC0')
    assert decode(b'foo\\xC0\\x80', 'replace')[0] == 'foo�'

# Generated at 2022-06-21 12:44:10.480699
# Unit test for function encode
def test_encode():
    # Tests for the encode function
    assert encode('') == (b'', 0)
    assert encode('abc') == (b'abc', 3)
    assert encode('\x80') == (b'\\xc2\\x80', 1)
    assert encode('\u1234') == (b'\\xe1\\x88\\xb4', 1)
    assert encode('\U00012345') == (b'\\xf0\\x92\\x8d\\x85', 1)
    assert encode('\x80\U00012345') == (b'\\xc2\\x80\\xf0\\x92\\x8d\\x85', 2)
    assert encode('\n') == (br'\xa', 1)
    assert encode('\n\n') == (br'\xa\xa', 2)

# Generated at 2022-06-21 12:44:12.167406
# Unit test for function register
def test_register():
    """
    Test for function 'register'
    """
    codecs.getencoder(NAME)

# Generated at 2022-06-21 12:44:23.309168
# Unit test for function decode
def test_decode():
    # Test 1: '\x01\x02'
    data_bytes = b'\\x01\\x02'
    expected = b'\x01\x02'
    out, count = decode(data_bytes)
    assert out.encode() == expected
    assert count == len(data_bytes)

    # Test 2: '\x1f\x80\x04\x00\x01'
    data_bytes = b'\\x1f\\x80\\x04\\x00\\x01'
    expected = b'\x1f\x80\x04\x00\x01'
    out, count = decode(data_bytes)
    assert out.encode() == expected
    assert count == len(data_bytes)

    # Test 3: '\x61'

# Generated at 2022-06-21 12:44:33.026838
# Unit test for function decode
def test_decode():
    input_bytes = b'c\x61\x66\x00\\x42\\x43\\x44\\x45\\x46\\x47\\x48\\x49\\x4a\\x4b\\x4c\\x4d\\x4e\\x4f\\x50\\x51\\x52\\x53\\x54\\x55\\x56\\x57\\x58\\x59\\x5a'
    out_str, consumed_bytes = codecs.decode(input_bytes, NAME)
    print(out_str)
    print(consumed_bytes)
    assert out_str == 'caf\x00BCDEFGHIJKLMNOPQRSTUVWXYZ'
    assert consumed_bytes == 56
    assert out_str == decode(input_bytes)[0]

