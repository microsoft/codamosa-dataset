

# Generated at 2022-06-21 12:34:48.198980
# Unit test for function register
def test_register():
    register()
    assert True



# Generated at 2022-06-21 12:35:00.025161
# Unit test for function encode
def test_encode():  # type: ignore
    register()

    def foo(text: _Str) -> Tuple[bytes, int]:
        return text.encode(NAME)   # type: ignore

    assert foo('apple') == (b'a\\x70\\x70\\x6c\\x65', 5)
    assert foo('orange') == (b'o\\x72\\x61\\x6e\\x67\\x65', 6)
    assert foo('banana') == (b'b\\x61\\x6e\\x61\\x6e\\x61', 6)

# Generated at 2022-06-21 12:35:01.859959
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:35:05.236375
# Unit test for function register
def test_register():
    old_list = codecs.registered_error_handlers
    old_dict = codecs.decoding_error_registry
    register()
    new_list = codecs.registered_error_handlers
    new_dict = codecs.decoding_error_registry
    assert new_list == old_list
    assert new_dict == old_dict



# Generated at 2022-06-21 12:35:11.660811
# Unit test for function encode
def test_encode():
    """
    >>> assert encode('') == (b'', 0)
    >>> assert encode('a') == (b'a', 1)
    >>> assert encode('🐍') == (b'\\\\xf0\\\\x9f\\\\x90\\\\x8d', 1)
    >>> assert encode('') == (b'', 0)
    >>> assert encode('a') == (b'a', 1)
    >>> assert encode('🐍') == (b'\\\\xf0\\\\x9f\\\\x90\\\\x8d', 1)
    """
    pass

# Generated at 2022-06-21 12:35:22.883214
# Unit test for function encode
def test_encode():
    inp = 'this string is english'
    out = b'this string is english'
    assert encode(inp) == (out, len(inp))

    inp = 'this string is what € sign looks like'
    out = b'this string is what \\xe2\\x82\\xac sign looks like'
    assert encode(inp) == (out, len(inp))

    inp = 'this string is what \xac\x20\xac\x20 sign looks like'
    out = b'this string is what \\xac\\x20\\xac\\x20 sign looks like'
    assert encode(inp) == (out, len(inp))



# Generated at 2022-06-21 12:35:26.788960
# Unit test for function decode
def test_decode():
    s = "abcdéfgh"
    x = codecs.encode(s, encoding="eutf8h")
    x = codecs.decode(x, encoding="eutf8h")
    assert x == s



# Generated at 2022-06-21 12:35:34.219380
# Unit test for function decode
def test_decode():
    """Unit test for function decode"""

    # Test the function for a valid escaped utf8 hexadecimal input
    expected_output = """\
This is a test:
To see if it works with \\xC2\\xA2, \\xE2\\x82\\xAC,
\\xF0\\x9D\\x84\\x9E, \\xF0\\x9F\\x8D\\x80."""

    text = b'\
This is a test:\n\
To see if it works with \\xC2\\xA2, \\xE2\\x82\\xAC,\n\
\\xF0\\x9D\\x84\\x9E, \\xF0\\x9F\\x8D\\x80.'

    actual_output, _ = decode(text)
    assert actual_output == expected

# Generated at 2022-06-21 12:35:37.354281
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


if __name__ == "__main__":
    test_register()

# Generated at 2022-06-21 12:35:38.659114
# Unit test for function register
def test_register():
    import codecs
    register()



# Generated at 2022-06-21 12:35:43.593855
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None

# Generated at 2022-06-21 12:35:55.731174
# Unit test for function encode
def test_encode():
    # Case 1:
    print('Case 1:')
    ins = '\U0001f30f'
    in_bytes = ins.encode('utf-8')
    print('in: {}'.format(ins))
    print('in_bytes: {}'.format(in_bytes))

    outs, _ = encode(ins)
    print('out: {}'.format(outs))
    out_bytes, _ = encode(in_bytes)
    print('out_bytes: {}'.format(out_bytes))

    # Case 2:
    print('Case 2:')
    ins = '\U0001f30f\\u1234'
    in_bytes = ins.encode('utf-8')
    print('in: {}'.format(ins))
    print('in_bytes: {}'.format(in_bytes))


# Generated at 2022-06-21 12:36:04.825486
# Unit test for function decode
def test_decode():
    data_bytes = b'\\x65\\x71\\x75\\x61\\x6c\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00\\x00'
    s, _ = decode(data_bytes)
    assert s == 'equal', 'Input: {} = Output: {}'.format(data_bytes, s)

    data_bytes = b'\\xC3\\xA9\\xC3\\xA9gal'
    s, _ = decode(data_bytes)
    assert s == 'éégal', 'Input: {} = Output: {}'.format(data_bytes, s)


# Generated at 2022-06-21 12:36:07.490322
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    assert codecs.getdecoder(NAME) is not None

# Generated at 2022-06-21 12:36:13.485743
# Unit test for function decode
def test_decode():
    input_data = b'\\xe7\\x8b\\x97\\xe3\\x81\\x8c\\xe3\\x81\\x82\\xe3\\x81\\x84'
    output_data, num_input_bytes_consumed = decode(input_data)
    assert output_data == '狗があい'
    assert num_input_bytes_consumed == len(input_data)



# Generated at 2022-06-21 12:36:25.343976
# Unit test for function encode

# Generated at 2022-06-21 12:36:30.696796
# Unit test for function encode
def test_encode():
    # noinspection PyUnresolvedReferences
    from .test.test_data import encode_test_cases
    for _input, expect in encode_test_cases:
        out, _ = encode(_input)
        assert out == expect, (
            'Encode of "%s" did not produce the expected output.\n'
            'Expected output: %r\nActual output: %r' %
            (_input, expect, out)
        )

# Generated at 2022-06-21 12:36:35.601884
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError()
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:36:46.713596
# Unit test for function encode
def test_encode():
    assert encode('abc') == (b'abc', 3)
    assert encode('a\u0243') == (b'a\\xca\\x83', 2)
    assert encode('a\u0243', 'ignore') == (b'a\\x83', 1)
    assert encode('a\u0243', 'replace') == (b'a\\u0243', 1)
    assert encode('a\u0243', 'surrogateescape') == (b'a\\udcc3', 1)
    assert encode('a\u0243', 'backslashreplace') == (b'a\\\\u0243', 1)
    assert encode('\x01\x02\x03') == (b'\\x01\\x02\\x03', 3)

# Generated at 2022-06-21 12:36:53.902493
# Unit test for function encode
def test_encode():
    text = r'hi\x80\xC0\xC1\xC2\xE0\xE1\xE2\xF0\xF1\xF2\n'
    assert encode(text) == (b'hi\\x80\\xC0\\xC1\\xC2\\xE0\\xE1\\xE2\\xF0\\xF1\\xF2\\n', 15)



# Generated at 2022-06-21 12:37:03.668937
# Unit test for function encode
def test_encode():
    assert encode('hello') == (b'hello', 5)
    assert encode('\\xF0\\x9F\\x91\\x8D') == (
        b'\\\\uD83D\\\\uDC4D',
        len('\\xF0\\x9F\\x91\\x8D')
    )



# Generated at 2022-06-21 12:37:08.584730
# Unit test for function encode
def test_encode():
    assert encode('a') == (b'a', 1)
    assert encode('a\N{GREEK CAPITAL LETTER DELTA}') == (b'a\\xce\\x94', 3)
    assert encode('a\N{GREEK CAPITAL LETTER DELTA}', 'ignore') \
        == (b'a', 1)



# Generated at 2022-06-21 12:37:20.311208
# Unit test for function encode
def test_encode():
    # Test basic encode.
    assert encode('a')[0] == b'a'
    assert encode('A')[0] == b'A'
    assert encode('aaa')[0] == b'aaa'
    assert encode('ABCDEFGHIJKLMNOPQRSTUVWXYZ'
                  '0123456789')[0] == b'ABCDEFGHIJKLMNOPQRSTUVWXYZ'\
                                      b'0123456789'
    assert encode('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~'
                  '~~~~~~~~~~~~~~~~~~~~~~~~~~~~')[0] == \
        b'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~'\
        b'~~~~~~~~~~~~~~~~~~~~~~~~~~~~'

    # Test basic utf-8.
    assert encode('Б')[0] == b'\\xD0\\x91'
    assert encode('б')

# Generated at 2022-06-21 12:37:24.902932
# Unit test for function register
def test_register():
    # noinspection PyUnresolvedReferences
    assert NAME not in codecs.__dict__['_cache']
    register()
    # noinspection PyUnresolvedReferences
    assert NAME in codecs.__dict__['_cache']


# Generated at 2022-06-21 12:37:35.492542
# Unit test for function decode

# Generated at 2022-06-21 12:37:46.446695
# Unit test for function decode
def test_decode():
    assert decode('\\x72') == ('r', 2)
    assert decode('\\xc3\\xbc') == ('ü', 5)
    assert decode('\\xc3\\xbc') == ('ü', 5)

    with pytest.raises(UnicodeDecodeError):
        decode('\\x')

    assert decode('\\x72', 'ignore') == ('', 2)
    assert decode('\\xc3\\xbc', 'ignore') == ('', 5)
    assert decode('\\x', 'ignore') == ('', 2)
    assert decode('\\x', 'ignore') == ('', 2)
    assert decode('\\X', 'ignore') == ('\\X', 3)
    assert decode('\\', 'ignore') == ('\\', 2)
    assert decode('\\x\\x', 'ignore') == ('\\x', 4)

# Generated at 2022-06-21 12:37:48.144957
# Unit test for function register
def test_register():
    codecs.getencoder('eutf8h')
    codecs.getdecoder('eutf8h')


# Generated at 2022-06-21 12:37:53.289430
# Unit test for function encode
def test_encode():
    assert encode('\u00A9') == (b'\xc2\xa9', 1)
    assert encode('\\xA9') == (b'\xc2\xa9', 3)
    assert encode('\\n') == (b'\n', 2)
    assert encode('\\u00A9') == (b'\xc2\xa9', 6)
    assert encode('\\u00A9\\n') == (b'\xc2\xa9\n', 8)



# Generated at 2022-06-21 12:38:01.793903
# Unit test for function decode
def test_decode():
    """
    Decode 'eutf8h' format.
    """
    s = '\\u00c8mmanuel'
    u = '\u00c8mmanuel'
    expected_type = str
    expected = u, len(s)
    actual = decode(s)
    try:
        assert actual == expected
    except AssertionError:
        print(f'Expected: {expected}')
        print(f'Actual: {actual}')
        raise
    try:
        assert isinstance(actual[0], expected_type)
    except AssertionError:
        print(f'Expected: {expected}')
        print(f'Actual: {actual}')
        raise



# Generated at 2022-06-21 12:38:14.196729
# Unit test for function decode
def test_decode():
    # Registers the codec
    register()

    # Test the function with a utf8 string
    data = codecs.decode('\\xe2\\x98\\xba', NAME)
    assert(data == '☺')

    # Test the function with an ascii string
    data = codecs.decode('A', NAME)
    assert(data == 'A')

    # Test the function with an escaped utf8 hexadecimal string and a
    # 'strict' error level
    data = codecs.decode('A\\xFF', NAME)
    assert(data == 'A\xff')

    # Test the function with an escaped utf8 hexadecimal string and a
    # 'replace' error level
    data = codecs.decode('A\\xFF', NAME, 'replace')

# Generated at 2022-06-21 12:38:22.210554
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore


# Generated at 2022-06-21 12:38:25.988858
# Unit test for function register
def test_register():
    """Test for function register."""
    # This test is really just to avoid the pylint error
    # warning about the register function being unused,
    # and it can not actually test the functionality of
    # the function.
    register()  # noqa: F841


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:38:33.161479
# Unit test for function decode
def test_decode():
    assert decode(b'\xe4\xb8\xad\xe6\x96\x87') == \
           ("中文", 4), "Decode failed, b'\\xe4\\xb8\\xad\\xe6\\x96\\x87' is not decoded correctly"
    assert decode(b'\\xe4\\xb8\\xad\\xe6\\x96\\x87') == \
           ("中文", 19), "Decode failed, b'\\\\xe4\\\\xb8\\\\xad\\\\xe6\\\\x96\\\\x87' is not decoded correctly"



# Generated at 2022-06-21 12:38:43.458696
# Unit test for function decode
def test_decode():
    """
    This test case will check the decode function.

    The decode function takes in the escaped utf8 hexadecimal bytes
    and returns a string.

    The function takes in two parameters :

        1. data which is of type bytes or bytearray or memoryview.

        2. error which is of type str or UserString
    """
    # Test case 1
    # This test case will check if data is of type bytes
    # or bytearray or memoryview. If not then it raises
    # TypeError.
    try:
        decode(1)
    except TypeError:
        pass

    # Test case 2
    # This test case will check if data contains invalid
    # escaped utf8 hexadecimal. If so then it raises
    # UnicodeDecodeError.

# Generated at 2022-06-21 12:38:53.599204
# Unit test for function encode
def test_encode():
    text = '\\xe8\\x9f\\xbd\\xe3\\x81\\x8c\\xe3\\x82\\x99\\xe3\\x81\\x9f\\xe3\\x81\\x97\\xe3\\x81\\x9f\\xe3\\x81\\x8d\\xe3\\x81\\xaa\\xe3\\x81\\x84'

# Generated at 2022-06-21 12:38:58.035859
# Unit test for function encode
def test_encode():
    assert encode(r'\x41') == (b'\\\x41', 3)
    assert encode(r'\u0001\x41') == (b'\\\x01\\\x41', 7)
    assert encode(r'\U00000001\u0001') == (b'\\\x01\\\x01', 11)

# Generated at 2022-06-21 12:39:04.075233
# Unit test for function register
def test_register():
    # noinspection PyUnresolvedReferences
    from eutf8h_codecs import register as _register
    _register()
    # noinspection PyUnresolvedReferences
    from eutf8h_codecs import NAME as _NAME
    # noinspection PyUnresolvedReferences
    import codecs
    codecs.getdecoder(_NAME)



# Generated at 2022-06-21 12:39:14.721932
# Unit test for function encode
def test_encode():
    # Test utf8 input
    in_str = 'અભ્યાસે સાથે સાથે માહિતી મળે છે.'
    in_bytes = in_str.encode('utf-8')

    out, count = encode(in_str)

    assert out == in_bytes
    assert len(out) == len(in_bytes)
    assert count == len(in_str)

    # Test quoted hexadecimal string

# Generated at 2022-06-21 12:39:24.807662
# Unit test for function encode
def test_encode():
    assert encode('hello')[0] == b'hello'
    assert encode('h\\xe9llo')[0] == b'h\\xC3\\xA9llo'
    assert encode('hello\\u3060')[0] == b'hello\\xE3\\x81\\xA0'
    try:
        encode('bye\\u3060')
    except UnicodeEncodeError as e:
        assert e.encoding == NAME
        assert e.object == 'bye\\u3060'
        assert e.start == 0
        assert e.end == 4
        assert e.reason == 'invalid continuation byte'
    else:
        assert False, "UnicodeEncodeError not raised"

# Generated at 2022-06-21 12:39:35.407753
# Unit test for function encode
def test_encode():
    out = encode('测试', errors='strict')
    assert out == (b'\\xe6\\xb5\\x8b\\xe8\\xaf\\x95', 5)

    out = encode('测试', errors='replace')
    assert out == (b'\\xe6\\xb5\\x8b\\xe8\\xaf\\x95', 5)

    out = encode('测试', errors='ignore')
    assert out == (b'\\xe6\\xb5\\x8b\\xe8\\xaf\\x95', 5)

    out = encode('测试', errors='backslashreplace')
    assert out == (b'\\xe6\\xb5\\x8b\\xe8\\xaf\\x95', 5)


# Generated at 2022-06-21 12:39:55.919285
# Unit test for function register
def test_register():
    register()
    # Check that registering the encode and decode functions
    # works.
    codecs.decode('\\x41', 'eutf8h')
    codecs.decode(b'\\x41', 'eutf8h')
    codecs.decode(bytearray(b'\\x41'), 'eutf8h')
    codecs.decode(memoryview(b'\\x41'), 'eutf8h')


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:40:00.129988
# Unit test for function decode
def test_decode():
    # Given
    data = b'\\x66\\x6F\\x6F\\x20\\x62\\x61\\x72\\x20\\xF0\\x9F\\x98\\x81\\x21'
    
    # When
    decoded = decode(data)
    
    # Then
    assert decoded == ('foo bar 😁!', 26)



# Generated at 2022-06-21 12:40:05.260620
# Unit test for function decode
def test_decode():
    # This is: Happy coding!
    src = b'Happy\\x20coding\\x21'

    # Decode the string
    result = decode(src)

    # Convert the result into a single string
    result_str = result[0] + ' ' + str(result[1])

    # Compare the result to the expected value
    assert result_str == "Happy coding! 10"



# Generated at 2022-06-21 12:40:16.068396
# Unit test for function decode
def test_decode():
    assert decode(b'\\x61') == ('a', 5)
    assert decode(b'\\x32\\x32') == ('"', 6)
    assert decode(b'\\x32\\x32') == ('"', 6)
    assert decode(b'\\xc3\\x9f') == ('ß', 6)
    assert decode(b'\\xe2\\x9b\\x94') == ('♔', 9)

    assert decode(b'\\x61\\x61') == ('aa', 10)
    assert decode(b'\\xc3\\x9f\\xc3\\x9f') == ('ßß', 12)
    assert decode(b'\\xe2\\x9b\\x94\\xe2\\x9b\\x94') == ('♔♔', 18)


# Generated at 2022-06-21 12:40:18.506449
# Unit test for function register
def test_register():
    register()
    text = 'abc\xA3defghij'
    assert codecs.encode(text, 'eutf8h') == b'abc\\xA3defghij'

# Generated at 2022-06-21 12:40:27.993964
# Unit test for function decode
def test_decode():
    """Test the decode function.
    """
    module = sys.modules[__name__]
    test_decode_bytes = module.__dict__['test_decode_bytes']
    test_decode_str = module.__dict__['test_decode_str']

    def test(
            data_bytes: bytes,
            out: str,
            s: int
    ) -> None:
        assert s == len(data_bytes)
        data_bytes_ = (data_bytes*2)[:s]
        _out, _s = decode(data_bytes_, 'strict')
        assert _s == s
        assert _out == out

        _out, _s = decode(data_bytes_, 'replace')
        assert _s == s
        assert _out == out


# Generated at 2022-06-21 12:40:37.469109
# Unit test for function decode
def test_decode():
    data1 = b"\\x41\\x42\\x43"
    data2 = b"\\xE1\\xBB\\xA5\\xE1\\xBA\\xA4\\xE1\\xBA\\xAF"
    data3 = b"\\xE1\\xAA\\xBB\\xE1\\xAB\\xA4"
    data4 = b"\\xE1\\xAB\\xA4\\xE1\\xAA\\xBB"
    print(decode(data1))
    print(decode(data2))
    print(decode(data3))
    print(decode(data4))
if __name__ == '__main__':
    test_decode()

# Generated at 2022-06-21 12:40:39.692500
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-21 12:40:42.879246
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.decode.__code__.co_names
    assert NAME in codecs.encode.__code__.co_names



# Generated at 2022-06-21 12:40:53.128137
# Unit test for function decode
def test_decode():
    assert decode('привет') == ('привет', 8)
    assert decode('\\xd0\\xbf\\xd1\\x80\\xd0\\xb8\\xd0\\xb2\\xd0\\xb5\\xd1\\x82') == ('привет', 26)
    assert decode('\\xd0\\xbf\\xd1\\x80\\xd0\\xfe\\xd0\\xba\\xd0\\xba') == ('пр\xfeкк', 22)
    assert decode('\\xd0\\xbf\\xd1\\x80\\xd0\\xfe\\xd0\\xba\\xd0\\xba', errors='strict') == ('пр\xfeкк', 22)

# Generated at 2022-06-21 12:41:24.420224
# Unit test for function encode
def test_encode():
    text = r'I love \\xF0\\x9F\\x8C\\x94'
    encoded = rb'I love \xf0\x9f\x8c\x94'
    assert encode(text)[0] == encoded, f'AssertionError: {text}'



# Generated at 2022-06-21 12:41:25.865440
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:41:28.395465
# Unit test for function register
def test_register():
    codecs.register(lambda name: None)
    codecs.lookup(NAME)
    codecs.lookup_error('strict')

register()

# Generated at 2022-06-21 12:41:37.998366
# Unit test for function encode
def test_encode():
    inputs = [
        '',
        'foo',
        '\\x81',
        '\\x81foo',
        'foo\\x81',
        '\\x81foo\\x81',
        'a\\x81a',
        'foo\\x81a\\x81a',
        '\\ff',
        '\\xff',
        '\\xfffoo',
        'foo\\xff',
        '\\x00',
        '\\x00foo',
        'foo\\x00',
        '\\xfffoo\\xff',
        'a\\xffa',
        'foo\\xffa\\xffa',
    ]

    # Get the bytes for each input string.

# Generated at 2022-06-21 12:41:38.777830
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-21 12:41:46.992822
# Unit test for function encode
def test_encode():
    # Unit test for function encode
    assert encode(u'\u0628') == b'\\x0628'
    assert encode(u'\u0628', errors='strict') == b'\\x0628'
    assert encode(u'﻿') == b'\xef\xbb\xbf'
    assert encode(u'', errors='strict') == b''
    assert encode(u'', errors='strict') == b''
    assert encode(u'', errors='strict') == b''
    assert encode(u'') == b''
    assert encode(u'a') == b'a'
    assert encode(u'\x00') == b'\\x00'
    assert encode(u'\x01') == b'\\x01'

# Generated at 2022-06-21 12:41:48.425161
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)



# Generated at 2022-06-21 12:41:58.714669
# Unit test for function encode
def test_encode():
    print(encode(  # type: ignore[no-redef]
        "This is a string without any escaped utf8 hexadecimal"))
    print(encode(  # type: ignore[no-redef]
        "This is a string with escaped utf8 hexadecimal: \\xf0\\x9f\\x98\\x80"
    ))


if __name__ == '__main__':
    register()
    # Examples
    print(encode(  # type: ignore[no-redef]
        "This is a string without any escaped utf8 hexadecimal"))
    print(encode(  # type: ignore[no-redef]
        "This is a string with escaped utf8 hexadecimal: \\xf0\\x9f\\x98\\x80"
    ))

    test_

# Generated at 2022-06-21 12:42:04.507332
# Unit test for function decode
def test_decode():
    print('TEST: decode')
    text = r'\xF0\x9F\x92\x93'
    data = codecs.encode(text, 'eutf8h')
    expected_out = str(chr(0xF0) + chr(0x9F) + chr(0x92) + chr(0x93))
    out, _ = codecs.decode(data, 'eutf8h')
    print('\t', repr(out))
    assert out == expected_out
    assert len(out) == 1
    assert len(data) == 8


# Generated at 2022-06-21 12:42:09.466897
# Unit test for function decode
def test_decode():
    # Test bytes with no escaped utf8 hexadecimal
    assert decode(b'abc') == ('abc', 3)
    # Test bytes with escaped utf8 hexadecimal
    assert decode(br'\x61\x62\x63') == ('abc', 9)


# Generated at 2022-06-21 12:43:06.057766
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-21 12:43:11.807109
# Unit test for function encode
def test_encode():
    """
    Unit test for function encode()
    """
    assert encode('a', 'strict') == (b'a', 1)
    assert encode('\u03b1', 'strict') == (b'\\u03b1', 1)
    assert encode('\xdf', 'strict') == (b'\\xdf', 1)
    assert encode('\u03b1\xdf', 'strict') == (b'\\u03b1\\xdf', 2)
    assert encode('a\u03b1\xdf') == (b'a\\u03b1\\xdf', 3)
    assert encode('\u03b1\xdfa') == (b'\\u03b1\\xdfa', 3)

# Generated at 2022-06-21 12:43:17.106837
# Unit test for function register
def test_register():
    register()
    decode(b'\\x45', 'strict')
    decode(b'\\x41\\x42\\x43', 'strict')
    decode(b'\\x2f', 'strict')
    decode(b'\\x23', 'strict')
    decode(b'\\x45\\xA9', 'strict')


# Generated at 2022-06-21 12:43:21.202224
# Unit test for function encode
def test_encode():
    print(encode('abc'))
    print(encode('\\u1234'))
    print(encode('\u1234'))
    print(encode('\u1234', errors='ignore'))
    print(encode('\u1234', errors='replace'))

    # print(encode('\u1234', errors='strict'))



# Generated at 2022-06-21 12:43:30.268055
# Unit test for function decode
def test_decode():
    assert decode(b'\\xE5\\x85\\x83') == ('元', 9)
    assert decode(b'\\xE5\\x85\\x83\\xC2\\xA2') == ('元¢', 11)
    assert decode(b'\\u03A0') == ('Π', 6)
    assert decode(b'\\u03A0\\u03D0') == ('Πϐ', 12)
    assert decode(b'\\u03A0\\u03D0\\xD9\\xA9\\xD8\\xA7\\xD9\\x84\\xD8\\xA8\\xD9\\x8A\\xD8\\xAF') == ('Πϐ٩البيد', 66)

# Generated at 2022-06-21 12:43:34.373212
# Unit test for function encode
def test_encode():
    text = "Weé're꞉"
    exp_text = b'W\\xc3\\xa9e\\x27re\\xea\\x9e\\x89'
    test_text = encode(text)
    assert test_text[0] == exp_text
    assert test_text[1] == len(text)



# Generated at 2022-06-21 12:43:37.200367
# Unit test for function decode
def test_decode():
    data = b'\\xC2\\xA2'
    out, consumed = decode(data)
    assert out == '¢'
    assert consumed == len(data)



# Generated at 2022-06-21 12:43:46.359461
# Unit test for function encode
def test_encode():
    text = '\u0410\u0411\u0412'
    data = b'\\x0410\\x0411\\x0412'
    out, consumed = encode(text)
    assert out == data
    assert consumed == len(text)

    text = '\\u0410\\u0411\\u0412'
    data = b'\\\\x0410\\\\x0411\\\\x0412'
    out, consumed = encode(text)
    assert out == data
    assert consumed == len(text)

    text = '\u0410\\u0411\u0412'
    data = b'\\x0410\\\\x0411\\x0412'
    out, consumed = encode(text)
    assert out == data
    assert consumed == len(text)


# Generated at 2022-06-21 12:43:56.576957
# Unit test for function decode
def test_decode():
    # Test 1
    out, size = decode(r'\x40\x41\x42'.encode('utf-8'), 'strict')
    assert out == '\u0040\u0041\u0042'
    assert size == 7
    # Test 2
    out, size = decode(r'\x42'.encode('utf-8'), 'strict')
    assert out == '\u0042'
    assert size == 3
    # Test 3
    out, size = decode(r'\x41\x30'.encode('utf-8'), 'strict')
    assert out == '\u0041\u0030'
    assert size == 5
    # Test 4
    out, size = decode(r'\x41\x30\x41'.encode('utf-8'), 'strict')
   

# Generated at 2022-06-21 12:44:08.040235
# Unit test for function encode
def test_encode():
    assert encode("abc") == (b"abc", 3)
    assert encode("abc\\xE9") == (b"abc\\xe9", 6)
    assert encode("abc\\u2192") == (b"abc\\xe2\\x86\\x92", 7)
    assert encode("abc\\U0001F60D") == (b"abc\\xf0\\x9f\\x98\\x8d", 10)
    assert encode("abc\\xE9\\u2192\\U0001F60D") == (b"abc\\xe9\\xe2\\x86\\x92\\xf0\\x9f\\x98\\x8d", 20)   # noqa