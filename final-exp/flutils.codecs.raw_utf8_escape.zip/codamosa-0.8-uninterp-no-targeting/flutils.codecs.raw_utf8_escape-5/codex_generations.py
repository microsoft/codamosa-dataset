

# Generated at 2022-06-21 12:35:03.017136
# Unit test for function encode
def test_encode():
    _text = '\u65e5\u672c\u8a9e'
    _expected_bytes = b'\\xE6\\x97\\xA5\\xE6\\x9C\\xAC\\xE8\\xAA\\x9E'
    _actual = encode(_text, 'strict')
    assert _actual[0] == _expected_bytes
    assert _actual[1] == 4
    _actual = encode(_text, 'ignore')
    assert _actual[0] == _expected_bytes
    assert _actual[1] == 4



# Generated at 2022-06-21 12:35:12.443805
# Unit test for function encode
def test_encode():
    print('test_encode()')

    # Test for "unescaped" ASCII characters (which should remain the same)
    text = 'aA0ö'
    expected_output = 'aA0ö'
    output, consumed = encode(text)  # type: ignore
    output = output.decode('utf-8')
    print(output)
    print(expected_output)
    assert expected_output == output

    # Test for "escaped" ASCII characters (which should be escaped)
    text = r'\a\A\0\r\n\t\f'
    expected_output = r'\\x07\\x07\\x00\\r\\n\\t\\f'
    output, consumed = encode(text)  # type: ignore
    output = output.decode('utf-8')
    print(output)


# Generated at 2022-06-21 12:35:25.289640
# Unit test for function register
def test_register():
    import codecs
    codecs.register(register)
    b = b'\xE3\x81\x8A\xE3\x82\x93\xE3\x81\xAB\xE3\x81\x8F\xE5\xA0\xB4\xE5\x90\x88\xE3\x81\x97\xE3\x81\xA6\xE8\xA9\xB1\xE3\x82\x8A\xE3\x81\x99\xE3\x80\x82'.decode('eutf8h')
    print(b)

# Generated at 2022-06-21 12:35:28.058193
# Unit test for function decode
def test_decode():
    decoded, size = decode(b'\\x31\\x32\\x33')
    assert decoded == '123' and size == len(b'\\x31\\x32\\x33')


# Generated at 2022-06-21 12:35:34.899487
# Unit test for function decode

# Generated at 2022-06-21 12:35:36.227452
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-21 12:35:37.525080
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-21 12:35:49.040618
# Unit test for function encode
def test_encode():
    def _assert_encode(
            text: _Str,
            expected_bytes: bytes,
            errors: str = 'strict',
            expected_num_chars: int = len(text)
    ) -> None:
        bytes_actual, num_chars_actual = encode(text, errors=errors)
        assert bytes_actual == expected_bytes
        assert num_chars_actual == expected_num_chars

    _assert_encode('', b'')
    _assert_encode('a', b'a')
    _assert_encode('abc', b'abc')
    _assert_encode('α', b'\\xce\\xb1')
    _assert_encode('Α', b'\\xce\\x91')

# Generated at 2022-06-21 12:36:01.166790
# Unit test for function encode
def test_encode():
    assert encode(
        text='abcdefg',
    ) == (
        b'abcdefg',
        7
    )

    assert encode(
        text='\xe3\x81\x82\xe3\x81\x84',
    ) == (
        b'\\xe3\\x81\\x82\\xe3\\x81\\x84',
        6
    )

    assert encode(
        text='😀',
    ) == (
        b'\\xf0\\x9f\\x98\\x80',
        4
    )

    assert encode(
        text='\\x00',
    ) == (
        b'\\x00',
        2
    )
    assert encode(
        text='\\x01',
    ) == (
        b'\\x01',
        2
    )



# Generated at 2022-06-21 12:36:04.379308
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-21 12:36:15.962386
# Unit test for function decode
def test_decode():
    # noinspection PyUnresolvedReferences
    """
    >>> test_decode()
    'TEST'
    """
    assert decode(b'\\125\\116\\106\\107') == ('TEST', 15)



# Generated at 2022-06-21 12:36:26.849890
# Unit test for function decode
def test_decode():
    # Test 1: ascii string.
    ascii_str = 'This is a test string.'
    ascii_bytes = ascii_str.encode('ascii')
    ascii_bytes_utf8h, _ = encode(ascii_bytes)
    ascii_bytes_utf8h_decoded, _ = decode(ascii_bytes_utf8h)
    assert ascii_bytes_utf8h_decoded == ascii_str

    # Test 2: utf-8 string.
    utf8_str = '\u2713: This is a UTF-8 test string'
    utf8_bytes = utf8_str.encode('utf-8')
    utf8_bytes_utf8h, _ = encode(utf8_bytes)
    utf

# Generated at 2022-06-21 12:36:30.203251
# Unit test for function decode
def test_decode():
    value = decode(b'\\xe2\\x85\\xab\\xe2\\x85\\xac')
    assert value == ('ⅫⅬ', 10)



# Generated at 2022-06-21 12:36:31.781964
# Unit test for function register
def test_register():
    # when you need to test the registration of the codec.
    register()

# Generated at 2022-06-21 12:36:39.397653
# Unit test for function register
def test_register():
    # noinspection SpellCheckingInspection
    test_str = r'\xe8\xac\x9b\xe8\xac\x9b'
    try:
        result = test_str.encode(NAME).decode(NAME)
    except LookupError:
        register()
        result = test_str.encode(NAME).decode(NAME)
    assert result == '講講'

# Generated at 2022-06-21 12:36:49.930498
# Unit test for function encode
def test_encode():
    # Verify encode() - success case:
    # Given a utf8 string, convert it to escaped utf8 hexadecimal.
    #
    # The utf8 string contains a non-ascii character and an escaped
    # utf8 hexadecimal character (\\xa5) that is converted to a utf8
    # hexadecimal (\xa5) character.
    #
    # Also, the utf8 escaped hexadecimal character references a
    # valid utf8 hexadecimal byte.
    str_input = '\u02c6\xa5\xa5\xa5\t'
    str_expected = b'\\u02c6\\xa5\\xa5\\xa5\\t'
    (str_out, consumed) = encode(str_input, 'strict')
    assert str_out

# Generated at 2022-06-21 12:36:52.555097
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    codecs.getdecoder(NAME)
    assert True


# register()

# Generated at 2022-06-21 12:37:02.430498
# Unit test for function encode
def test_encode():
    test_str = 'abc123가나다'
    t_bytes, t_len = encode(test_str)

    assert t_len == len(test_str), (
        "encode() returns incorrect 't_len' (%s), should be %s"
        % (t_len, len(test_str)))

    assert t_bytes == b'abc123\\xe0\\xb0\\x80\\xe0\\xb8\\x82\\xe0\\xb8\\xa2', (
        "encode() returns incorrect 't_bytes' (%s), should be %s"
        % (t_bytes, b'abc123\\xe0\\xb0\\x80\\xe0\\xb8\\x82\\xe0\\xb8\\xa2'))

    test_str = '\\x41'
    t_

# Generated at 2022-06-21 12:37:03.448998
# Unit test for function decode
def test_decode():
    with open('./test_decode.txt') as fh:
        content = fh.read()
        print(decode(content))



# Generated at 2022-06-21 12:37:14.645384
# Unit test for function encode
def test_encode():
    from datetime import datetime
    start = datetime.now()

    # Some simple test cases
    assert encode('abc')[0] == b"abc"
    assert encode('\nA\t')[0] == b"\\nA\\t"
    assert encode('\u200D')[0] == b'\\xE2\\x80\\x8D'

    # These are some of the tests from the official Python codecs
    # documentation.
    # https://docs.python.org/3/library/codecs.html#codec-base-classes

# Generated at 2022-06-21 12:37:35.712992
# Unit test for function encode
def test_encode():
    in_str = '"Hello, world!" – is the traditional\t\n'\
             'greeting that English speakers use'
    in_bytes, _ = encode(in_str)
    out_bytes = b'"Hello, world!" - is the traditional\\t\\n'\
                b'greeting that English speakers use'
    assert in_bytes == out_bytes


# Generated at 2022-06-21 12:37:46.551508
# Unit test for function decode

# Generated at 2022-06-21 12:37:54.049979
# Unit test for function encode

# Generated at 2022-06-21 12:37:55.073589
# Unit test for function register
def test_register():
    pass

# Generated at 2022-06-21 12:38:06.182525
# Unit test for function decode
def test_decode():
    # Test decode with a string reference of utf-8 hexadecimal bytes.
    text = r'\x41\x42\x43\x44\x45\x46\x47\x48\x49\x50'
    text_bytes = text.encode('utf-8')
    out_txt, out_size = decode(text)
    assert out_txt == 'ABCDEFGHIP'
    assert out_size == len(text_bytes)

    # Test decode with a string reference of utf-8 hexadecimal bytes
    # with an unknown utf-8 hexadecimal byte.
    text = r'\x41\x42\x43\x44\x45\x46\x47\x48\x49\xFF'
    text_bytes = text.encode('utf-8')


# Generated at 2022-06-21 12:38:13.044451
# Unit test for function encode
def test_encode():
    assert encode(r'\xFF\xFF') == b'\\\\xFF\\\\xFF', \
        r'Failed to encode raw bytes r"\xFF\xFF" properly.'
    # try:
    #     encode(r'\xFF' + 'a')
    # except UnicodeEncodeError:
    #     pass
    # else:
    #     raise AssertionError('Should have raised a UnicodeEncodeError.')



# Generated at 2022-06-21 12:38:23.463042
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode('abc') == (b'abc', 3)
    assert encode('123') == (b'123', 3)
    assert encode('\u00e9') == (b'\\xc3\\xa9', 1)
    assert encode('\\u00e9') == (b'\\\\u00e9', 1)
    assert encode('\\\\u00e9') == (b'\\\\\\u00e9', 1)
    assert encode('\\\u00e9') == (b'\\\\xc3\\xa9', 1)
    assert encode('\\\u00e9') == (b'\\\\xc3\\xa9', 1)
    assert encode('\\\u00e9') == (b'\\\\xc3\\xa9', 1)

# Generated at 2022-06-21 12:38:26.508616
# Unit test for function register
def test_register():
    assert 'eutf8h' not in codecs.__dict__['_cache']
    register()
    assert 'eutf8h' in codecs.__dict__['_cache']



# Generated at 2022-06-21 12:38:30.013385
# Unit test for function register
def test_register():
    codecs.lookup('ascii')
    
    try:
        codecs.lookup(NAME)
    except LookupError:
        register()
        codecs.lookup(NAME)
    assert True


# Generated at 2022-06-21 12:38:32.424209
# Unit test for function encode
def test_encode():
    assert encode("Hello") == (b'Hello', 5)
    assert encode("Hello \\U0001f600") == (b'Hello \xf0\x9f\x98\x80', 15)



# Generated at 2022-06-21 12:38:47.055069
# Unit test for function register
def test_register():
    register()
    decoder = codecs.getdecoder(NAME)
    assert isinstance(decoder, tuple)
    assert len(decoder) == 2
    assert isinstance(decoder[0], types.FunctionType)
    assert isinstance(decoder[1], types.FunctionType)

# Generated at 2022-06-21 12:38:54.781040
# Unit test for function encode
def test_encode():
    assert encode('test') == (b't\\x65\\x73\\x74', 4)
    assert encode('古') == (b'\\xe5\\x8f\\xa4', 1)
    assert encode('검') == (b'\\xea\\xb2\\x80', 1)
    assert encode('\u1F72') == (b'\\xF0\\x9F\\x94\\xB2', 1)

# Generated at 2022-06-21 12:39:02.316553
# Unit test for function encode
def test_encode():
    assert encode('abc') == (b'abc', 3)
    assert encode('abc\xff') == (b'abc\\xff', 4)
    assert encode('\U0001f601') == (b'\xf0\x9f\x98\x81', 1)
    assert encode('\xff\U0001f601') == (b'\\xff\xf0\x9f\x98\x81', 6)
    assert encode(r'\xff\U0001f601') == (b'\\\\xff\\xf0\\x9f\\x98\\x81', 12)
    assert encode('abc\t\\') == (b'abc\\t\\\\', 6)

# Generated at 2022-06-21 12:39:13.375766
# Unit test for function register
def test_register():
    from .test_eutf8h_codec import (
        rstr_hex,
        rstr_hex_scapes,
        rstr_hex_scapes_test,
    )

    # Register the codecs.
    register()

    # Create a codecs encode and decode objects.
    e = codecs.getencoder(NAME)
    d = codecs.getdecoder(NAME)

    # Decode some escaped utf8 hexadecimal.
    # Return the number of bytes in the data that was used.
    _, start = d(rstr_hex_scapes_test)

    # Encode some utf8 bytes.
    # Return the number of characters in the data that was used.
    b, end = e(rstr_hex_scapes_test)

    # Test that the start and end counters are

# Generated at 2022-06-21 12:39:17.408899
# Unit test for function encode
def test_encode():
    try:
        encoded = encode('\xf3\xf5\xc7')
        assert encoded == (b'\\xf3\\xf5\\xc7', 3)
    except UnicodeEncodeError:
        assert False
    try:
        encode('12345á卐가')
        assert False
    except UnicodeEncodeError:
        pass



# Generated at 2022-06-21 12:39:19.099436
# Unit test for function register
def test_register():
    """Function register()."""
    from . import codecs

    codecs.register()



# Generated at 2022-06-21 12:39:30.546148
# Unit test for function decode
def test_decode():
    # Test the empty string
    data = b''
    errors = 'strict'
    out = decode(data, errors)
    assert out == ('', 0)

    # Test a string without escaped utf8 hexadecimal
    data = b'Hello World.'
    errors = 'strict'
    out = decode(data, errors)
    assert out == ('Hello World.', len(data))

    # Test a string with escaped hexadecimal that reference invalid utf8
    # bytes.
    data = b'\\x01\\x02'
    errors = 'strict'
    try:
        decode(data, errors)
    except UnicodeDecodeError:
        pass
    else:
        raise AssertionError('Error not raised')

    # Test a string with escaped hexadecimal

# Generated at 2022-06-21 12:39:37.081097
# Unit test for function decode
def test_decode():
    pass
    # assert decode(b'\\xe6\\x9d\\xb1\\xe4\\xba\\xac') == '東京'
    # assert decode(b'\\xe9\\x9f\\xb3\\xe6\\xa5\\xbd') == '音楽'
    # assert decode(b'\\xef\\xbc\\x8e') == '．'
    # assert decode(b'\\xf0\\x9f\\x92\\x9d') == '💝'

# Generated at 2022-06-21 12:39:39.218341
# Unit test for function decode
def test_decode():
    assert (
        decode(b'\\xE2\\xA2\\xAC') == (
            '\u2124',
            8
        )
    )



# Generated at 2022-06-21 12:39:39.962085
# Unit test for function register
def test_register():
    codecs.encode('', NAME)

# Generated at 2022-06-21 12:40:17.692231
# Unit test for function encode
def test_encode():
    from textwrap import dedent
    src_text_formatted = dedent("""\
        This is the text to be encoded for testing purposes.
        This text can contain escaped utf8 hexadecimal such as \\xC2
        or \\x20AC. (Just a euro symbol.)
        """)

    expected_result = dedent("""\
        This is the text to be encoded for testing purposes.
        This text can contain escaped utf8 hexadecimal such as \\xC2
        or \\x20AC. (Just a euro symbol.)
        """)

    encoded, _ = encode(src_text_formatted)

    assert encoded.decode('utf-8') == expected_result



# Generated at 2022-06-21 12:40:27.291987
# Unit test for function decode
def test_decode():
    # Test decoding text of one character
    s, _ = decode(b'\\x41')
    assert s == 'A'

    # Test decoding text of one character with leading and trailing space
    s, _ = decode(b' \\x41')
    assert s == ' A'
    s, _ = decode(b'\\x41 ')
    assert s == 'A '
    s, _ = decode(b' \\x41 ')
    assert s == ' A '

    # Test decoding text of one character with 2 leading and 2 trailing space
    s, _ = decode(b'   \\x41')
    assert s == '   A'
    s, _ = decode(b'\\x41   ')
    assert s == 'A   '
    s, _ = decode(b'   \\x41   ')

# Generated at 2022-06-21 12:40:32.877244
# Unit test for function decode
def test_decode():
    bytes_eutf8h = b'\\x7F\\x80\\x81\\xC2\\x80\\xC2\\x81\\xC3\\x80\\xC3\\x81'
    s = decode(bytes_eutf8h)[0]
    assert s == '\x7F\x80\x81\u0080\u0081\u00C0\u00C1'



# Generated at 2022-06-21 12:40:35.693925
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    out = codecs.getdecoder(NAME)

    assert out is not None



# Generated at 2022-06-21 12:40:37.847219
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:40:49.403735
# Unit test for function decode
def test_decode():
    func = decode
    args = ()


# Generated at 2022-06-21 12:40:57.915787
# Unit test for function decode

# Generated at 2022-06-21 12:41:10.672942
# Unit test for function decode
def test_decode():
    assert decode(b'\\x23\\x24\\x25\\x26') == ('#$%&', 10)
    assert decode(b'\\x23\\x24\\x25\\x26', 'strict') == ('#$%&', 10)
    assert decode(b'\\x23\\x24\\x25\\x26', 'ignore') == ('#$%&', 10)
    assert decode(b'\\x23\\x24\\x25\\x26', 'replace') == ('#$%&', 10)
    assert decode(b'\\x23\\x24\\x25\\x26', 'backslashreplace') == ('#$%&', 10)
    assert decode(b'\\x23\\x24\\x25\\x26', 'xmlcharrefreplace') == ('#$%&', 10)

# Generated at 2022-06-21 12:41:17.207479
# Unit test for function decode
def test_decode():
    # Testing decode with various inputs,
    # expected results and expected number of inputs consumed.
    decode_pairs = [
        (b'h', 'h', 1),
        (b'hello world', 'hello world', 11),
        (b'\\\\', '\\', 2),
        (b'\\x68', 'h', 4),
        (b'\\x68\\x65\\x6C\\x6C\\x6F\\x20\\x77\\x6F\\x72\\x6C\\x64',
         'hello world', 22),
    ]

    for data, output, inputs_consumed in decode_pairs:
        result, inputs_consumed_result = decode(data)
        assert result == output
        assert inputs_consumed_result == inputs_consumed


# Generated at 2022-06-21 12:41:26.978287
# Unit test for function encode

# Generated at 2022-06-21 12:42:27.117125
# Unit test for function decode
def test_decode():
    assert decode(b'\\x73\\x74\\x72\\x69\\x6E\\x67') == ('string', 22)  # type: ignore
    assert decode(b'\\x68\\x65\\x78') == ('hex', 10)  # type: ignore


# Generated at 2022-06-21 12:42:28.000138
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-21 12:42:39.242147
# Unit test for function decode
def test_decode():
    test_data = (
        (  # Test 1
            '\\x41\\x42\\x43',
            'ABC',
        ),
        (  # Test 2
            '\\xC3\\xA9\\x74\\x72',
            'ét',
        ),
        (  # Test 3
            '\\xC3\\xA9\\x74\\x72',
            'ét',
        ),
        (  # Test 4
            '\\xE2\\x99\\xA5',
            '♥',
        ),
        (  # Test 5
            '\\xE2\\x99\\xA5',
            '♥',
        ),
    )
    for test in test_data:
        out, consumed = decode(test[0])
        print(f'out={out}')
       

# Generated at 2022-06-21 12:42:41.311047
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)
    assert NAME in codecs.__all__

# Generated at 2022-06-21 12:42:44.156667
# Unit test for function encode
def test_encode():
    text = '彐彑\uD852\uDf96'
    out, consumed = encode(text)
    assert out == b'\\u5f50\\ud840\\udf96'
    assert consumed == 5



# Generated at 2022-06-21 12:42:51.601111
# Unit test for function decode
def test_decode():
    # Test for decode with normal input.
    data = b'\\xE2\\x82\\xAC'
    assert decode(data)[0] == '€'

    # Test for decode with invalid input.
    data = b'\\xE2\\x82\\xAC'
    assert decode(data)[0] == '€'

    # Test for encode with empty input.
    data = b''
    assert decode(data) == ('', 0)



# Generated at 2022-06-21 12:42:56.123963
# Unit test for function encode
def test_encode():
    assert encode('abc') == (b'abc', 3)
    assert encode('\\xF8') == (b'\\xF8', 3)
    assert encode('\\xF8\\xB3') == (b'\\xF8\\xB3', 7)
    assert encode('abc\\xF8\\xB3') == (b'abc\\xF8\\xB3', 10)
    assert encode('Δ', errors='replace') == (b'?', 1)
    assert encode('Δ', errors='strict') == (b'\\xCE\\x94', 2)
    assert encode('Δ', errors='ignore') == (b'', 0)



# Generated at 2022-06-21 12:43:05.721437
# Unit test for function decode
def test_decode():
    # Test ascii.
    txt = 'ascii \\x41'
    txt_utf8 = decode(txt.encode('eutf8h'))
    assert txt_utf8[0] == 'ascii A'
    assert txt_utf8[1] == len(txt)

    # Test ascii and utf8.
    txt = u'this is utf-8: \\xe2\\xa9\\xa0.\n'
    txt_utf8 = decode(txt.encode('eutf8h'))
    assert txt_utf8[0] == u'this is utf-8: \u2620.\n'
    assert txt_utf8[1] == len(txt)

    # Test \\uHHHH.

# Generated at 2022-06-21 12:43:11.699037
# Unit test for function decode
def test_decode():
    assert decode('hello') == ('hello', 5)
    assert decode('\\x65llo') == ('ello', 7)
    assert decode('\\x65llo') == ('ello', 7)
    assert decode('h\\x65llo') == ('hello', 8)
    assert decode('h\\x65llo') == ('hello', 8)
    assert decode('h\\x65\\x6clo') == ('hello', 9)
    assert decode('h\\x65llo') == ('hello', 8)
    assert decode('h\\x65\\x6clo') == ('hello', 9)
    assert decode('\\x00\\x01\\x02\\x03\\x04\\x05') == ('\x00\x01\x02\x03\x04\x05', 15)     # type: ignore[comparison-overlap,unreach

# Generated at 2022-06-21 12:43:16.711075
# Unit test for function register
def test_register():
    before = codecs.lookup(NAME)
    register()
    after = codecs.lookup(NAME)
    assert before != after
    assert after == codecs.CodecInfo(  # type: ignore  # noqa: F821
        name=NAME,
        encode=encode,
        decode=decode,
    )

