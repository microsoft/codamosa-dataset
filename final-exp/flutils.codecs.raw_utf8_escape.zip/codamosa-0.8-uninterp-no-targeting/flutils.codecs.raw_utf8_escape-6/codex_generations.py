

# Generated at 2022-06-21 12:35:17.911275
# Unit test for function encode
def test_encode():
    """
    :rtype: (None)
    :return: (None)
    """
    test_pairs = (
        # text, errors
        (b'Hello', 'strict'),
        (b'Tak\xc4\x85', 'strict'),
        (b'Tak\xc4', 'strict'),
    )
    for text, errors in test_pairs:
        print('\n*********************************')
        print('text:', text)
        print('errors:', errors)
        out_bytes, consumed = encode(text, errors)
        print('out_bytes:', out_bytes)
        print('consumed:', consumed)



# Generated at 2022-06-21 12:35:21.934412
# Unit test for function register
def test_register():
    register()
    print('[%s]' % codecs.getdecoder(NAME))  # type: ignore

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:35:31.684947
# Unit test for function encode

# Generated at 2022-06-21 12:35:43.285719
# Unit test for function decode

# Generated at 2022-06-21 12:35:45.164900
# Unit test for function register
def test_register():
    # Verify that the codec is registered
    assert codecs.getdecoder(NAME) is not None

# Generated at 2022-06-21 12:35:52.730808
# Unit test for function decode
def test_decode():
    assert decode(b'\\x61') == ('a', 3)
    assert decode(b'\\xC3\\xA9') == ('é', 6)
    assert decode(b'\\x61\\xC3\\xA9') == ('aé', 9)
    assert decode(b'\\x61\\xC3\\xA9\\x62') == ('aéb', 12)
    assert decode(b'\\u61\\uC3\\uA9') == ('aé', 6)



# Generated at 2022-06-21 12:36:03.376066
# Unit test for function decode

# Generated at 2022-06-21 12:36:14.208622
# Unit test for function decode
def test_decode():
    assert decode(b'\\xC2') == ('À', 3)
    assert decode(br'\x00') == ('\x00', 3)
    assert decode(b'\\x') == ('\\x', 2)
    assert decode(b'\\xC2', 'ignore') == ('', 3)
    assert decode(b'\\xC2', 'replace') == ('ï', 3)
    assert decode(b'\\xC2', 'backslashreplace') == ('\\xc2', 3)
    assert decode(br'\x00', 'backslashreplace') == ('\\x00', 3)
    assert decode(b'\\xC2\\xA2', 'xmlcharrefreplace') == ('&#194;&#162;', 5)

# Generated at 2022-06-21 12:36:18.632888
# Unit test for function encode
def test_encode():
    # Test encode without escaped utf8 hexadecimal bytes.
    test_string = 'Hello world.'
    expected_result = b'Hello world.'
    expected_characters_consumed = len(test_string)
    actual_result, actual_characters_consumed = encode(test_string)
    assert actual_result == expected_result
    assert actual_characters_consumed == expected_characters_consumed

    # Test encode with escaped utf8 hexadecimal bytes.
    test_string = '\\xE2\\x98\\xBA'
    expected_result = b'\\xe2\\x98\\xba'
    expected_characters_consumed = len(test_string)
    actual_result, actual_characters_consumed = encode(test_string)
    assert actual_result == expected_result


# Generated at 2022-06-21 12:36:21.786775
# Unit test for function register
def test_register():
    # Ensure that the codec has not been registered before
    # we run this test. This is important because there
    # is no unregister function.
    try:
        codecs.getdecoder(NAME)
        raise RuntimeError(
            f'The {NAME} codec has already been registered.'
        )
    except LookupError:
        pass

    register()

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise RuntimeError(
            f'The {NAME} codec has not been registered.'
        )



# Generated at 2022-06-21 12:36:50.559707
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-21 12:36:56.454031
# Unit test for function register
def test_register():  # type: ignore
    """Test the register() function."""
    assert not hasattr(codecs, NAME)
    register()
    assert hasattr(codecs, NAME)
    assert codecs.getdecoder(NAME) is not None
    delattr(codecs, NAME)



# Generated at 2022-06-21 12:37:04.015597
# Unit test for function register
def test_register():
    from codecs import CodecInfo
    from typing import NoReturn
    from unittest.mock import Mock

    # Note that the given encoding name is 'eutf8h' (not 'eutf8h_test').
    # This is because codecs.getdecoder() is triggered by '__init__.py', which
    # registers the actual name 'eutf8h'
    enc_name = NAME
    codecs.register = Mock(wraps=codecs.register)
    codecs.getdecoder = Mock(side_effect=LookupError)
    register()
    codecs.getdecoder.assert_called_with(enc_name)
    codecs.register.assert_called_with(_get_codec_info)
    args, kwargs = codecs.register.call_args
    obj_info: CodecInfo

# Generated at 2022-06-21 12:37:15.216538
# Unit test for function decode
def test_decode():
    # Test decoding a single escaped UTF8 hexadecimal code point
    assert decode(bytes.fromhex('e2ac'))[0] == 'ᬬ'

    # Test decoding an escaped UTF8 hexadecimal sequence for a surrogate pair
    assert decode(bytes.fromhex('edbd8ce6b89b'))[0] == '\ud83c\udf1b'

    # Test decoding an escaped UTF8 hexadecimal sequence with an invalid
    # hexadecimal character
    with pytest.raises(UnicodeDecodeError):
        decode(bytes.fromhex('edbd8ce6b89z'))

    # Test decoding an escaped UTF8 hexadecimal sequence with an invalid
    # UTF8 byte sequence

# Generated at 2022-06-21 12:37:25.192205
# Unit test for function decode
def test_decode():
    """Test the decode function.

    Returns:
        bool: ``True`` if the test passes, ``False`` otherwise.
    """
    import struct
    import binascii


# Generated at 2022-06-21 12:37:31.775085
# Unit test for function decode
def test_decode():
    test_string = '\\x68\\x65\\x6c\\x6c\\x6f \\\\x77\\x6f\\x72\\x6c\\x64\\x21'

    value, _ = decode(test_string)
    assert value == 'hello \\world!'
    assert len(value) == 12

    value, _ = decode('\\xff')
    assert value == '\ufffd'


# Generated at 2022-06-21 12:37:39.729773
# Unit test for function decode
def test_decode():
    # Test decode with a string of escaped utf8 hexadecimal that
    # references valid utf8 bytes.
    data_bytes = b'\\x65\\x6c\\x75\\xc4\\x90'
    text_str, len_consumed = decode(data_bytes)
    assert text_str == 'eluĐ'
    assert len_consumed == len(data_bytes)

    # Test decode with a string of escaped utf8 hexadecimal that
    # references invalid utf8 bytes.
    data_bytes = b'\\x65\\x6c\\x75\\xc4'
    try:
        decode(data_bytes)
    except UnicodeDecodeError as e:
        assert e.encoding == 'eutf8h'
        assert e.object == data_bytes

# Generated at 2022-06-21 12:37:43.726053
# Unit test for function decode
def test_decode():
    data: bytes = b'\\xe5'
    out_str, out_int = decode(data)
    assert isinstance(out_str, str)
    assert isinstance(out_int, int)
    assert out_str == 'å'
    assert out_int == 2

# Generated at 2022-06-21 12:37:46.750148
# Unit test for function encode
def test_encode():
    assert encode(r'\x00\x01\x02\x03\x04') == (b'\\\\x00\\\\x01\\\\x02\\\\x03\\\\x04', 25)


# Generated at 2022-06-21 12:37:54.168506
# Unit test for function encode
def test_encode():
    assert encode("hello") == (b"hello", 5)
    assert encode("\xA3") == (br"\c2\xa3", 1)
    assert encode("\\xA3") == (b"\xc2\xa3", 4)
    assert encode("\\u1234") == (b"\xe1\x88\xb4", 6)
    assert encode("\\U0010FFFF") == (b"\xf4\x8f\xbf\xbf", 10)
    assert encode("\\uD800") == (b"\xed\xa0\x80", 6)
    assert encode("\\U0001D11E") == (b"\xf0\x9d\x84\x9e", 10)

# Generated at 2022-06-21 12:38:49.969368
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError('Failed to register codec.')



# Generated at 2022-06-21 12:38:59.564322
# Unit test for function decode
def test_decode():
    assert decode(b'abc') == ('abc', 3)
    assert decode(b'\\x41bc') == ('Abc', 7)
    assert decode(b'\\x41\\x42\\x43') == ('ABC', 9)

    # Test surrogate pairs
    surrogate_pair = '\\uD83D\\uDE0A'
    assert decode(surrogate_pair.encode('utf-8')) == ('\\uD83D\\uDE0A', 14)

    surrogate_pair = '\\xFC'
    assert decode(surrogate_pair.encode('utf-8')) == ('\\u00FC', 6)

    assert decode(b'\\xFC') == ('ü', 6)

    surrogate_pair = '\\uD83D\\uDE0A'

# Generated at 2022-06-21 12:39:12.006443
# Unit test for function encode
def test_encode():
    expected = b'\\x41'
    actual = codecs.encode('A', encoding=NAME)
    assert actual == expected

    expected = b'\\x41\\x62'
    actual = codecs.encode('Ab', encoding=NAME)
    assert actual == expected

    expected = b'\\xC2\\xA9'
    actual = codecs.encode('©', encoding=NAME)
    assert actual == expected

    expected = b'\\xE5'
    actual = codecs.encode('å', encoding=NAME)
    assert actual == expected

    expected = b'\\xF0\\x9F\\x92\\xA9'
    actual = codecs.encode('💩', encoding=NAME)
    assert actual == expected


# Generated at 2022-06-21 12:39:14.928090
# Unit test for function encode
def test_encode():
    # Test that the following does not raise an error.
    encode(text='\x13\x15\x17\x19\x1B\x1D\x1F\x7F')

    # Test that the following raises an error.
    encode(text='\xAB\xCD\xEF')



# Generated at 2022-06-21 12:39:17.765884
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise Exception('Expected exception was not raised.')

    register()

    codecs.getdecoder(NAME)

# Generated at 2022-06-21 12:39:29.312357
# Unit test for function encode

# Generated at 2022-06-21 12:39:36.266408
# Unit test for function decode
def test_decode():
    s = "\\xE2\\x98\\xA3"  # U+2603 ❄  SNOWMAN
    expected_result = "❄"
    actual_result = decode(s)
    try:
        assert actual_result[0] == expected_result
        print("Decode test passed.")
    except AssertionError:
        print("Decode test failed:")
        print("%s != %s" % (actual_result, expected_result))
    except Exception as e:
        print("Failed to run decode test.")
        print(e)


# Generated at 2022-06-21 12:39:45.608147
# Unit test for function decode

# Generated at 2022-06-21 12:39:56.263408
# Unit test for function decode
def test_decode():
    # decode() should return a tuple of the output and the number of bytes read
    # If a string that is not escaped utf8 hexadecimal is passed in, the
    # output should simply be the input, and the number of bytes read should be
    # 1
    assert decode("test") == ("test", 1)
    # If a string of escaped utf8 hexadecimal is passed in, the output should
    # be the decoded string, and the number of bytes read should be the length
    # of the input string
    assert decode("\\x61bc") == ("abc", 4)
    # If the input string contains a hex code that does not translate to a
    # valid utf8 byte, a UnicodeDecodeError should be thrown
    with pytest.raises(UnicodeDecodeError):
        decode("\\x55")
    #

# Generated at 2022-06-21 12:40:00.735283
# Unit test for function decode
def test_decode():
    # noinspection PyTypeChecker
    data = b'\\xE0\\xAE\\xB0'
    out, bytes_consumed = decode(data)
    out_expect = 'ர'
    bytes_consumed_expect = 9
    assert out == out_expect
    assert bytes_consumed == bytes_consumed_expect



# Generated at 2022-06-21 12:41:55.934109
# Unit test for function decode
def test_decode():
    data = b'\\xff'
    expected = '\xff'
    assert expected == decode(data)[0]

# Generated at 2022-06-21 12:42:04.268221
# Unit test for function encode
def test_encode():
    register()

    # noinspection PyUnresolvedReferences
    corrupted_utf8_hex = '\\xC3\\xB1\\xC2'
    # noinspection PyUnresolvedReferences
    corrupted_utf8_hex_bytes = b'\\xC3\\xB1\\xC2'
    # noinspection PyUnresolvedReferences
    corrupted_utf8_hex_bytes_len = len(corrupted_utf8_hex_bytes)
    # noinspection PyUnresolvedReferences
    corrupted_utf8_hex_str_len = len(corrupted_utf8_hex)

    # Check the number of given characters consumed

# Generated at 2022-06-21 12:42:07.564648
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    codecs.encode('\U0001F633', 'eutf8h')



# Generated at 2022-06-21 12:42:19.092890
# Unit test for function decode
def test_decode():
    # Test decode with normal text
    test_data = b'ABCDEFG'
    result = decode(test_data)
    print(result)
    assert result[0] == 'ABCDEFG'

    # Test decode with normal unicode
    test_data = b'\xcf\x90\xcf\x91\xcf\x92\xcf\x93\xcf\x94\xcf\x95'
    result = decode(test_data)
    print(result)
    assert result[0] == 'αβγδεζ'

    # Test decode with error handling
    test_data = b'\xcf\x90\xcf\x91\xcf\x92\xcf\x93\xcf\x94\xcf\x95\x0d0'
    result = decode

# Generated at 2022-06-21 12:42:25.790319
# Unit test for function decode
def test_decode():
    # Basic test
    test = 'A \\x41 \\x41 \\x41'
    test_bytes = bytes(test, 'latin1')
    output, length = decode(test_bytes)
    assert length == len(test_bytes)
    assert output == "A AAA"
    # Test of unicode decode error
    try:
        output, length = decode(bytes('\\x41 \\x41 \\x41', 'latin1'))
    except UnicodeDecodeError:
        pass
    # Test input sanity
    try:
        decode(b"")  # type: ignore
    except TypeError:
        pass
    # Test of errors arg
    try:
        output, length = decode(bytes('\\x41 \\x41 \\x41', 'latin1'), 'ignore')
    except UnicodeDecodeError:
        pass


# Generated at 2022-06-21 12:42:27.000643
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)


# Generated at 2022-06-21 12:42:38.025380
# Unit test for function decode
def test_decode():
    def chk(s1, s2):
        e1 = codecs.encode(s2, 'unicode-escape')
        d1 = codecs.decode(e1, 'eutf8h')
        assert s1 == d1, (s1, d1)

    chk('', '')
    chk('a', 'a')
    chk('a b', 'a b')
    chk('a\nb', 'a\nb')
    chk('\x7f', '\x7f')
    chk('\n', '\n')
    chk('a\x7f', 'a\x7f')
    chk('\u1234', '\u1234')
    chk('a\u1234', 'a\u1234')

# Generated at 2022-06-21 12:42:45.547291
# Unit test for function decode
def test_decode():
    output = decode(b'\\x0aHello\\x20world!')
    assert output == ('\nHello world!', 15)

    output = decode(b'\\x0aHello\\x20\\x0aworld!')
    assert output == ('\nHello \nworld!', 17)

    # Test that erroneous escaped sequences are handled appropriately
    with pytest.raises(UnicodeDecodeError) as excinfo:
        decode(b'\\x0aHello\\x20\\x0aworld\\xff!')
    assert excinfo.value.reason == \
        "invalid continuation byte"

    # Test that multiple erroneous escaped sequences are handled appropriately

# Generated at 2022-06-21 12:42:56.732703
# Unit test for function decode
def test_decode():
    def get_hex(utf8_bytes: bytes) -> str:
        out = ''
        for byte in utf8_bytes:
            out += hex(byte)[2:]
        return out

    def check_utf8(utf8_bytes: bytes) -> None:
        str_input = utf8_bytes.decode('utf-8')
        bytes_input = str_input.encode('ascii')
        text_output, bytes_consumed = decode(bytes_input)
        if text_output != str_input:
            utf8_bytes_hex = get_hex(utf8_bytes)

# Generated at 2022-06-21 12:42:59.371453
# Unit test for function register
def test_register():
    before = str(codecs.getdecoders())
    register()
    after = str(codecs.getdecoders())
    assert before != after