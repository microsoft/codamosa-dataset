

# Generated at 2022-06-21 12:34:44.976942
# Unit test for function register
def test_register():
    status = 'Registered' if _get_codec_info(NAME) else 'N_Registered'
    print(f'{NAME} status: {status}')


# Generated at 2022-06-21 12:34:57.577152
# Unit test for function decode
def test_decode():
    # Test empty string
    test_str = b''
    test_bytes = b''
    assert decode(test_bytes) == (test_str, len(test_bytes))

    # Test ASCII printable characters
    test_str = 'abc'
    test_bytes = b'abc'
    assert decode(test_bytes) == (test_str, len(test_bytes))

    # Test ASCII non-printable characters
    test_str = '\n'
    test_bytes = b'%0A'
    assert decode(test_bytes) == (test_str, len(test_bytes))

    # Test invalid utf8 byte errors with strict policy
    test_bytes = b'\xed'
    with pytest.raises(UnicodeDecodeError):
        decode(test_bytes)

    # Test invalid utf

# Generated at 2022-06-21 12:35:00.424791
# Unit test for function decode
def test_decode():
    assert decode(b'\\\\x41') == ('\\A', 5)
    assert decode(b'\\\\\\x41') == ('\\\\A', 6)



# Generated at 2022-06-21 12:35:04.453998
# Unit test for function decode
def test_decode():
    assert decode(b'\\xe2\\x98\\xba') == ('\N{WHITE SMILING FACE}', 10)
    assert decode(b'\\xe2\\x98\\xba\\xe2\\x8f\\xbf') == ('\N{WHITE SMILING FACE}\N{SQUARE FOOT}', 14)



# Generated at 2022-06-21 12:35:13.529109
# Unit test for function decode
def test_decode():
    """
    The unit test for function decode.
    """
    assert decode(b'\\x00') == ('\x00', 3)
    assert decode(b'\\x61') == ('a', 3)
    assert decode(b'\\x62') == ('b', 3)
    assert decode(b'\\x63') == ('c', 3)
    assert decode(b'\\x64') == ('d', 3)
    assert decode(b'\\x65') == ('e', 3)
    assert decode(b'\\x66') == ('f', 3)
    assert decode(b'\\x67') == ('g', 3)
    assert decode(b'\\x68') == ('h', 3)
    assert decode(b'\\x69') == ('i', 3)

# Generated at 2022-06-21 12:35:26.346498
# Unit test for function encode
def test_encode():
    # Encoding the str 'b@r' into escaped utf8 hexadecimal
    bytes_encoded_utf8_hex, length = encode('b@r', 'strict')
    assert bytes_encoded_utf8_hex == b'b\\x40r'
    assert length == 3

    bytes_encoded_utf8_hex, length = encode('b@r', 'replace')
    assert bytes_encoded_utf8_hex == b'?\\x40r'
    assert length == 3

    bytes_encoded_utf8_hex, length = encode('b@r', 'ignore')
    assert bytes_encoded_utf8_hex == b'br'
    assert length == 3

    # Encoding the str 'b@r' with a regular expression
    # 'b@(.)' into escaped utf8 hexadec

# Generated at 2022-06-21 12:35:32.371923
# Unit test for function decode
def test_decode():
    # Test with valid utf8 hexadecimal string
    _test_decode('')
    _test_decode('\\x01')
    _test_decode('\\x01\\x02')
    _test_decode('\\x01\\x02\\x03')

    # Test with invalid utf8 hexadecimal string
    with pytest.raises(UnicodeDecodeError):
        decode(b'\\x-1')
    with pytest.raises(UnicodeDecodeError):
        decode(b'\\x1')



# Generated at 2022-06-21 12:35:35.431478
# Unit test for function decode
def test_decode():
    assert decode(b'\\x20') == (' ', 2)
    assert decode(b'\\x41\\x42\\x43\\x44') == ('ABCD', 8)



# Generated at 2022-06-21 12:35:36.450809
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-21 12:35:48.248758
# Unit test for function encode
def test_encode():
    result = encode('\x0a')
    expected = (b'\\0a', 1)
    assert result == expected

    result = encode('\a')
    expected = (b'\\07', 1)
    assert result == expected

    result = encode(u'\u2665')
    expected = (b'\\xe2\\x99\\xa5', 4)
    assert result == expected

    result = encode('\x0a')
    expected = (b'\\0a', 1)
    assert result == expected

    result = encode('\U0001f355')
    expected = (b'\\xf0\\x9f\\x8d\\x95', 4)
    assert result == expected

    result = encode('\\x0a')
    expected = (b'\\\\0a', 3)
    assert result == expected

    result

# Generated at 2022-06-21 12:36:00.482715
# Unit test for function encode
def test_encode():
    test_text = '\\u03a8\\x80\\u03a7\\x81'
    expected_bytes = b'\\u03a8\\x80\\u03a7\\x81'

    actual_bytes, actual_len = encode(test_text)

    assert expected_bytes == actual_bytes

    assert len(test_text) == actual_len



# Generated at 2022-06-21 12:36:04.634453
# Unit test for function register
def test_register():
    # noinspection PyUnresolvedReferences
    from eutf8h.eutf8h import register
    from eutf8h.eutf8h import NAME
    from eutf8h.eutf8h import decode
    import codecs
    # noinspection PyUnresolvedReferences
    register()

    test_1 = codecs.getdecoder(NAME)
    assert test_1[0] == decode


# Generated at 2022-06-21 12:36:15.111344
# Unit test for function encode
def test_encode():
    assert encode('abc') == (b'abc', 3)
    assert encode(b'abc') == (b'abc', 3)
    assert encode('A\\u0C84\\u0E83\\u0F0E') == (b'A\\u0C84\\u0E83\\u0F0E', 18)
    assert encode('\\x41\\u0C84\\u0E83\\u0F0E') == (b'A\\u0C84\\u0E83\\u0F0E', 18)
    assert encode('\\u0C84\\u0E83\\u0F0E', 'ignore') == (b'', 18)

# Generated at 2022-06-21 12:36:18.394922
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)
        assert True
    else:
        assert False


# Generated at 2022-06-21 12:36:28.636458
# Unit test for function encode
def test_encode():
    print('Testing encode')

# Generated at 2022-06-21 12:36:41.765417
# Unit test for function decode
def test_decode():
    # Test invalid escape sequences
    try:
        decode('\\x')
    except UnicodeDecodeError as e:
        print(e)

    # Test invalid unicode escape sequence
    try:
        decode('\\u1234')
    except UnicodeDecodeError as e:
        print(e)

    # Test invalid utf8 bytes
    try:
        decode('\\x80')
    except UnicodeDecodeError as e:
        print(e)

    # Test valid unicode escape sequence
    print(decode('\\u263a'))
    print(decode(b'\\u263a'))

    # Test invalid unicode escape sequence
    try:
        decode('\\u263g')
    except UnicodeDecodeError as e:
        print(e)


# Generated at 2022-06-21 12:36:51.618606
# Unit test for function decode
def test_decode():
    # Test a single utf-8 character.
    data = codecs.escape_encode(b'a')[0]
    data = data[1:-1] + b'\\x61'
    data = data.decode('eutf8h')

    assert data == 'a'

    # Test an utf-8 character that requires three bytes.
    data = codecs.escape_encode(b'\u03b2')[0]
    data = data[1:-1] + b'\\xce\\xb2'
    data = data.decode('eutf8h')

    assert data == '\u03b2'

    # Test an utf-8 character that requires four bytes.
    data = codecs.escape_encode(b'\U00012c34')[0]

# Generated at 2022-06-21 12:36:55.046841
# Unit test for function register
def test_register():
    register()

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise RuntimeError('not registered')



# Generated at 2022-06-21 12:37:02.426991
# Unit test for function encode
def test_encode():
    test_string = str('tëst' + '\N{SOFT HYPHEN}' + 'string')
    print('test_string:', repr(test_string))
    print('type(test_string):', type(test_string))
    print('test_string.encode(utf8):', repr(test_string.encode('utf8')))
    print('test_string.encode(eutf8h):', repr(test_string.encode('eutf8h')))
    print('test_string.encode(eutf8h, \'strict\'):', repr(test_string.encode('eutf8h', 'strict')))


# Generated at 2022-06-21 12:37:03.718310
# Unit test for function register
def test_register():
    register()
    obj = codecs.getdecoder(NAME)
    assert obj is not None

# Generated at 2022-06-21 12:37:25.966580
# Unit test for function encode
def test_encode():
    text_input = "Hello World\n"
    bytes_output, number_of_bytes_consumed = encode(text_input)
    assert bytes_output == b'Hello World\\xa\\n'
    assert number_of_bytes_consumed == 12

    text_input = "1234567890"
    bytes_output, number_of_bytes_consumed = encode(text_input)
    assert bytes_output == b'1234567890'
    assert number_of_bytes_consumed == 10

    text_input = "t\\xca\\xbc"
    bytes_output, number_of_bytes_consumed = encode(text_input)
    assert bytes_output == b't\\xca\\xbc'
    assert number_of_bytes_consumed == 6


# Generated at 2022-06-21 12:37:36.201800
# Unit test for function decode

# Generated at 2022-06-21 12:37:37.758394
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:37:41.794684
# Unit test for function register
def test_register():
    """Unit test for function register()"""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-21 12:37:49.206529
# Unit test for function encode
def test_encode():
    out, _ = encode('\\x41')
    assert out == b'\\x41'

    out, _ = encode('\\x41\\x42')
    assert out == b'\\x41\\x42'

    out, _ = encode('\\x41\\x42\\x43')
    assert out == b'\\x41\\x42\\x43'

    out, _ = encode('\\x41\\x42\\x43\\x44')
    assert out == b'\\x41\\x42\\x43\\x44'

    out, _ = encode('\\x41\\x42\\x43\\x44\\x45')
    assert out == b'\\x41\\x42\\x43\\x44\\x45'


# Generated at 2022-06-21 12:38:00.740288
# Unit test for function encode
def test_encode():
    plain_text = "This is a test string"
    plain_text_bytes_utf8 = plain_text.encode('utf8')
    plain_text_escaped = plain_text_bytes_utf8.decode('unicode_escape')
    escape_text_bytes_utf8 = plain_text_escaped.encode('latin1')
    escaped_text = escape_text_bytes_utf8.decode('utf8')
    output_bytes, length = encode(escaped_text)
    assert(len(output_bytes) == len(plain_text_bytes_utf8))
    output_text = output_bytes.decode('utf8')
    assert(escaped_text == output_text)
    assert(length == len(output_text))

    plain_text = "ẟ"
    plain_text

# Generated at 2022-06-21 12:38:05.901124
# Unit test for function encode
def test_encode():
    codecs.register(_get_codec_info)   # type: ignore
    assert encode('abcdèfg') == (b'abcd\\xe8fg', 7)
    assert encode('è') == (b'\\xe8', 1)


# Generated at 2022-06-21 12:38:16.509315
# Unit test for function decode
def test_decode():
    test_str_01 = "ab\\x65fg\\x68\\x69jkl"
    test_str_02 = "\\x41\\x42\\x43\\x44\\x45\\x46\\x47\\x48\\x49"
    test_str_03 = "\\x41\\x42\\x43\\x44\\x45\\x46\\x47\\x48\\x49\\x4A"

    assert decode(b'ab\\x65fg\\x68\\x69jkl')[0] == test_str_01
    assert decode(b'\\x41\\x42\\x43\\x44\\x45\\x46\\x47\\x48\\x49')[0] == test_str_02

# Generated at 2022-06-21 12:38:26.425072
# Unit test for function encode
def test_encode():
    text_str = 'This is a test.!'
    out, n = encode(text_str)
    assert out == b'This\\x20is\\x20a\\x20test\\x2E\\x21'
    assert n == len(text_str)

    text_str = '\n'
    out, n = encode(text_str)
    assert out == b'\\x0A'
    assert n == len(text_str)

    text_str = '\xFF\xFE\xFD'
    out, n = encode(text_str)
    assert out == b'\\xFF\\xFE\\xFD'
    assert n == len(text_str)

    text_str = '\u2234'
    out, n = encode(text_str)

# Generated at 2022-06-21 12:38:34.169259
# Unit test for function decode
def test_decode():
    # Test conversion of a escaped hexadecimal byte sequence to a unicode
    # character.
    data = b'\\xe2\\x98\\x84'
    expected = '☄'
    result = decode(data)[0]
    assert result == expected

    # Test conversion of a non-printable unicode character to a escaped
    # hexadecimal byte sequence.
    data = '\\u26C4'
    expected = b'\\xe2\\x9b\\x84'
    result = encode(data)[0]
    assert result == expected


if __name__ == '__main__':
    test_decode()

# Generated at 2022-06-21 12:39:06.611039
# Unit test for function register
def test_register():
    register()
    codecs_decode = codecs.getdecoder(NAME)
    assert codecs_decode(b'\x41\x42\x43') == ('ABC', 3)
    codecs_encode = codecs.getencoder(NAME)
    assert codecs_encode('ABC') == (b'\x41\x42\x43', 3)


# Generated at 2022-06-21 12:39:09.702942
# Unit test for function encode
def test_encode():
    """Test function eutf8h.encode.
    """
    from etest import test_encode_str
    test_encode_str(__name__)

# Generated at 2022-06-21 12:39:14.721770
# Unit test for function encode
def test_encode():
    text = 'I ♥ \\\\xFF'
    assert encode(text)[0] == b'I \\u2764 \\\\\\xFF'
    # Test that an invalid escaped utf8 hexadecimal produces a
    # UnicodeEncodeError.
    with pytest.raises(UnicodeEncodeError):
        encode('I ♥ \\xG1')



# Generated at 2022-06-21 12:39:24.806434
# Unit test for function encode
def test_encode():
    print('testing encode')

    assert encode('') == b'', \
        '''The function encode() should return the correct output.'''

    assert encode('ab') == b'ab', \
        '''The function encode() should return the correct output.'''

    assert encode('a\\x41b') == b'ab', \
        '''The function encode() should return the correct output.'''

    assert encode('a\\\\x41b') == b'a\\x41b', \
        '''The function encode() should return the correct output.'''

    assert encode('a\\x41\\x41b') == b'a\\x41\\x41b', \
        '''The function encode() should return the correct output.'''


# Generated at 2022-06-21 12:39:35.407039
# Unit test for function decode
def test_decode():
    assert decode(b'\\x41')[0] == 'A'
    assert decode(b'\\x41\\x42')[0] == 'AB'
    assert decode(b'\\x41\\x42\\x43')[0] == 'ABC'
    assert decode(b'\\x41\\x42\\x43\\x44')[0] == 'ABCD'
    assert decode(b'\\x61\\x62\\x63\\x64')[0] == 'abcd'
    assert decode(b'\\x41\\x42\\x43\\x44\\x45')[0] == 'ABCDE'
    assert decode(b'\\x61\\x62\\x63\\x64\\x65')[0] == 'abcde'

# Generated at 2022-06-21 12:39:39.614139
# Unit test for function encode
def test_encode():
    """Test the encode function with various inputs and outputs.

    """
    assert encode('') == (b'', 0)
    assert encode('a string with no escapes') == (
        b'a string with no escapes',
        20,
    )
    assert encode('\\x00\\x01\\x02\\x03\\x04\\x05\\x06\\x07') == (
        b'\\x00\\x01\\x02\\x03\\x04\\x05\\x06\\x07',
        16,
    )
    assert encode('a string with \\x00\\x01') == (
        b'a string with \\x00\\x01',
        17,
    )

# Generated at 2022-06-21 12:39:49.570004
# Unit test for function encode
def test_encode():
    assert encode('a') == (b'a', 1)
    assert encode('abc') == (b'abc', 3)
    assert encode('ab\U0001f600') == (b'ab\\U0001f600\n', 7)
    assert encode('ab\U0001f600c') == (b'ab\\U0001f600c', 9)
    assert encode('ab\u0003\U0001f600\r') == (
        b'ab\\x03\\U0001f600\\r', 13)
    assert encode('ab\u0003\U0001f600\rc') == (
        b'ab\\x03\\U0001f600\\rc', 15)
    try:
        encode('\U0001f600\u0003')
    except UnicodeEncodeError:
        pass

# Generated at 2022-06-21 12:39:57.419112
# Unit test for function encode
def test_encode():
    sample_input = 'abc\u6587\u5b57xyz'
    output_bytes, len_input = encode(sample_input)
    output_bytes_expected = (
        b'abc\\\\xe6\\\\x96\\\\x87\\\\xe5\\\\xad\\\\x97xyz'
    )
    sample_input_expected = 'abc\\u6587\\u5b57xyz'

    assert output_bytes == output_bytes_expected
    assert len_input == len(sample_input_expected)

if __name__ == '__main__':
    test_encode()
    register()

# Generated at 2022-06-21 12:40:05.222336
# Unit test for function decode
def test_decode():
    """Unit test for :func:`~eutf8h.decode`"""
    test_data = [
        (
            b'abc',
            'abc',
        ),
        (
            b'\\xc3\\xa1\\xc3\\xa9\\xc3\\xad\\xc3\\xb3\\xc3\\xba',
            'áéíóú',
        ),
        (
            b'\\xe1\\xe9\\xed\\xf3\\xfa',
            'áéíóú',
        ),
    ]
    for (data, expected) in test_data:
        assert decode(data)[0] == expected



# Generated at 2022-06-21 12:40:07.567006
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.__all__
    assert codecs.getdecoder(NAME)() is not None



# Generated at 2022-06-21 12:42:01.663756
# Unit test for function decode
def test_decode():
    assert decode(b'\\x41') == ('A', 3)
    assert decode(b'\\x6f\\x6F') == ('oo', 6)
    assert decode(b'\\x6f\\x6F', 'ignore') == ('', 6)
    assert decode(b'\\x6f\\x6F', 'replace') == ('?', 6)
    assert decode(b'\\x6f\\x6F', 'backslashreplace') == ('\\x6f\\x6F', 6)
    assert decode(b'\\x6f\\x6F', 'xmlcharrefreplace') == ('&#x6f;&#x6F;', 6)


# Generated at 2022-06-21 12:42:08.249123
# Unit test for function decode
def test_decode():
    input_str: str = r'The \xed\xac\x85\xe1\xbd\xb9'
    ref_str: str = 'The 𬅹'  # U+1D789

    try:
        out_str, _ = decode(input_str, errors=None)
    except TypeError:
        out_str, _ = decode(input_str)
    assert ref_str == out_str



# Generated at 2022-06-21 12:42:12.013790
# Unit test for function register
def test_register():
    # Test for re-registering the codec.
    codecs.register(_get_codec_info)   # type: ignore
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False



# Generated at 2022-06-21 12:42:14.062328
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME)
    assert codecs.getincrementaldecoder(NAME)


# Generated at 2022-06-21 12:42:19.056034
# Unit test for function encode
def test_encode():
    text = "Bonjour"
    expected_result = b"Bonjour"
    actual_result, _ = encode(text)
    assert actual_result == expected_result, \
        f"The value of text: {actual_result}, is not {expected_result}"



# Generated at 2022-06-21 12:42:21.498530
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME)
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:42:30.565786
# Unit test for function encode
def test_encode():
    assert encode('a') == (b'a', 1)
    assert encode('\xFF') == (b'\\xFF', 1)
    assert encode('\xFF') == (b'\\xFF', 1)
    assert encode('\xFF') == (b'\\xFF', 1)
    assert encode('\xFF\xFF') == (b'\\xFF\\xFF', 2)
    assert encode('\xFF\xFF') == (b'\\xFF\\xFF', 2)
    assert encode('\xFF\xFF') == (b'\\xFF\\xFF', 2)
    assert encode('\xFF\xFF\xFF') == (b'\\xFF\\xFF\\xFF', 3)

# Generated at 2022-06-21 12:42:41.755089
# Unit test for function encode
def test_encode():
    # Test when text is a string
    assert encode('a') == (b'a', 1)
    assert encode('ab') == (b'ab', 2)
    assert encode('a\\x61b') == (b'aab', 5)
    assert encode('\\x61bc') == (b'abc', 5)
    assert encode('\\x61b\\x63') == (b'ab\\x63', 7)
    assert encode('\\x61\\x62\\x63') == (b'abc', 7)
    assert encode('a\xc3\xbc') == (b'a\\\\xc3\\\\xbc', 4)
    assert encode('abc', 'strict') == (b'abc', 3)

    # Test when text is a UserString
    assert encode(UserString('a')) == (b'a', 1)


# Generated at 2022-06-21 12:42:43.261479
# Unit test for function register
def test_register():
    # Try registering the codec. If this returns without raising an
    # exception then we are set.
    register()



# Generated at 2022-06-21 12:42:54.457903
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode('\n') == (b'\\n', 0)
    assert encode('\uFF7F') == (b'\\x7f', 0)
    assert encode('a') == (b'a', 0)
    assert encode('\uFF7F') == (b'\\x7f', 0)
    assert encode('\u00FF') == (b'\\xff', 0)
    assert encode('\u0100') == (b'\\xc0\\x80', 0)
    assert encode('\u0FFF') == (b'\\xdf\\xbf', 0)
    assert encode('\u1000') == (b'\\xe0\\xa0\\x80', 0)