

# Generated at 2022-06-21 12:34:46.036540
# Unit test for function register
def test_register():
    NAME_HEX = "eutf8h"
    codecs.register(_get_codec_info)
    codecs.getdecoder(NAME_HEX)

# Generated at 2022-06-21 12:34:49.494808
# Unit test for function encode
def test_encode():
    from eutf8h_testdata import TEST_DATA
    for text, expected_bytes in TEST_DATA:
        actual_bytes = encode(text)[0]
        assert actual_bytes == expected_bytes


# Generated at 2022-06-21 12:35:01.394422
# Unit test for function encode
def test_encode():
    assert encode(r'\x01\x02\x03') == (
        b'\\x01\\x02\\x03',
        5
    )
    assert encode(r'\\x01\\x02\\x03') == (
        b'\\x01\\x02\\x03',
        14
    )
    assert encode(r'\x23\x00\x01\x33\x91\x00\x01\xFF') == (
        b'\\x23\\x00\\x01\\x33\\x91\\x00\\x01\\xFF',
        17
    )
    assert encode('字') == (b'\\xE5\\xAD\\x97', 2)
    assert encode('字') == (b'\\xE5\\xAD\\x97', 2)

# Generated at 2022-06-21 12:35:07.849007
# Unit test for function decode

# Generated at 2022-06-21 12:35:16.521163
# Unit test for function encode
def test_encode():
    assert encode('\x80\x81\x82', errors='strict') == (b'\\xC2\\x80\\xC2\\x81\\xC2\\x82', 3)
    assert encode('\x80\x81\x82', errors='ignore') == (b'\\xC2\\x80', 1)
    assert encode('\x80\x81\x82', errors='replace') == (b'\\xC2\\x80?\\xC2\\x82', 3)
    assert encode('\x80\x81\x82', errors='backslashreplace') == (b'\\xC2\\x80\\\\xC2\\\\x81\\\\xC2\\\\x82', 3)

# Generated at 2022-06-21 12:35:19.781647
# Unit test for function register
def test_register():
    """A unit test function for function register.

    """
    register()
    assert codecs.getdecoder(NAME) is not None  # type: ignore

# Generated at 2022-06-21 12:35:21.109646
# Unit test for function register
def test_register():

    # unregister the codec to ensure that all tests are running clean
    codecs.lookup(NAME).name        # noqa: F821



# Generated at 2022-06-21 12:35:23.258856
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)

# Generated at 2022-06-21 12:35:25.573502
# Unit test for function register
def test_register():
    register()

# No unit test for function _get_codec_info


# Generated at 2022-06-21 12:35:33.496729
# Unit test for function encode
def test_encode():
    assert encode('abc') == (b'abc', 3)
    assert encode('123') == (b'123', 3)
    assert encode('ABC') == (b'ABC', 3)
    assert encode('\x0a\x0b\x0c') == (b'\\x0a\\x0b\\x0c', 3)
    assert encode('\x7f\x80\x81') == (b'\\x7f\\x80\\x81', 3)
    assert encode('\xfe\xff\xff') == (b'\\xfe\\xff\\xff', 3)
    assert encode('\x11\x22\x33') == (b'\\x11\\x22\\x33', 3)
    assert encode('?') == (b'?', 1)

# Generated at 2022-06-21 12:35:39.397618
# Unit test for function register
def test_register():
    obj = codecs.lookup(NAME)
    assert obj is not None
    assert obj.decode('\\xe5') == 'å'



# Generated at 2022-06-21 12:35:50.513092
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode('a') == (b'a', 1)
    assert encode('あ') == (b'\\e3\\81\\82', 2)
    assert encode('aあ') == (b'a\\e3\\81\\82', 3)
    assert encode('\\x30') == (b'\\x30', 3)
    assert encode('a\\x30') == (b'a\\x30', 4)
    assert encode('\\x30a') == (b'\\x30a', 4)
    assert encode('a\\x30a') == (b'a\\x30a', 5)
    assert encode('\\') == (b'\\\\', 2)
    assert encode('a\\') == (b'a\\\\', 3)

# Generated at 2022-06-21 12:36:02.189916
# Unit test for function decode

# Generated at 2022-06-21 12:36:13.567443
# Unit test for function decode
def test_decode():
    # Basic conversion
    print('test_decode: Basic conversion')
    encoded_string_bytes = b'\\u10C8\\u10CD\\u10C7'  # ჈ჍჇ
    decoded_string, consumed_bytes_number = decode(encoded_string_bytes)
    print(
        'Original string:', encoded_string_bytes,
        'Decoded string:', decoded_string,
        'consumed_bytes_number:', consumed_bytes_number
    )

    # Test with errors
    print('test_decode: Test with errors')

    err_str_in_encoded_string_bytes = b'\\u10C8\\u10CD\\u10C7\\uFFFD'  # ჈ჍჇ�
    err_str_in_dec

# Generated at 2022-06-21 12:36:25.389274
# Unit test for function encode
def test_encode():
    text = 'Hello! \u20AC'
    byte_text = b'Hello! \\xe2\\x82\\xac'

    assert encode(text) == (byte_text, len(text))
    assert encode(text, 'ignore') == (byte_text, len(text))
    assert encode(text, 'replace') == (byte_text, len(text))
    assert encode(text, 'strict') == (byte_text, len(text))

    text = '\\xac'
    with pytest.raises(UnicodeEncodeError):
        encode(text)
    assert encode(text, 'ignore') == (b'', 1)
    assert encode(text, 'replace') == (b'\\xff', 1)

# Generated at 2022-06-21 12:36:30.453937
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        assert False, 'This module should not yet be registered.'
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'This module should now be registered.'


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:36:43.256082
# Unit test for function encode
def test_encode():
    name = 'encode'

# Generated at 2022-06-21 12:36:52.034046
# Unit test for function encode
def test_encode():

    print('test_encode')
    print('=' * 10)

    # Create text input
    text_input = 'a'
    print(f'text_input: {text_input}')
    # Convert text input into a string of escaped utf8 hexadecimal.
    out_bytes, _ = encode(text_input)
    # Convert the string of escaped utf8 hexadecimal back into a string.
    out_str = out_bytes.decode('utf8')
    print(f'out_str:    {out_str}')
    # Test if the input and output is the same
    assert(out_str == text_input)

    # Create text input
    text_input = 'ä'
    print(f'text_input: {text_input}')
    # Convert text into a string of escaped ut

# Generated at 2022-06-21 12:36:55.503531
# Unit test for function register
def test_register():
    import sys
    import io
    import unittest


# Generated at 2022-06-21 12:37:07.409463
# Unit test for function encode

# Generated at 2022-06-21 12:37:23.037602
# Unit test for function encode
def test_encode():
    # noinspection SpellCheckingInspection
    text = 'abc123!@#$%^&*()'
    actual = encode(text)
    expect = (b'abc123!@#$%^&*()', 14)
    assert actual == expect

    # noinspection SpellCheckingInspection
    text = '这是一个测试'
    actual = encode(text)
    expect = (
        b'\\xe8\\xbf\\x99\\xe6\\x98\\xaf\\xe4\\xb8\\x80\\xe4\\xb8\\xaa\\xe6\\xb5\\x8b\\xe8\\xaf\\x95',
        14
    )
    assert actual == expect

    # noinspection SpellCheckingInspection

# Generated at 2022-06-21 12:37:34.046553
# Unit test for function decode

# Generated at 2022-06-21 12:37:45.890978
# Unit test for function decode
def test_decode():
    def _test_decode(
            data: _ByteString,
            expected_result: str,
            expected_consumed: int,
            errors: _Str = 'strict'
    ) -> None:
        result, consumed = decode(data, errors)
        assert isinstance(result, str)
        assert isinstance(consumed, int)
        assert consumed > 0
        assert isinstance(result, str)
        assert consumed == expected_consumed
        assert result == expected_result


# Generated at 2022-06-21 12:37:58.074205
# Unit test for function encode
def test_encode():

    assert encode('abcde') == (b'abcde', 5)
    assert encode('\\x41\\x42\\x43\\x44\\x45') == (b'\\x41\\x42\\x43\\x44\\x45', 22)
    assert encode('\\x41\\x42\\x43\\x44\\x45', 'replace') == (b'\\x41\\x42\\x43\\x44\\x45', 22)
    assert encode('\\x41\\x42\\x43\\x44\\x45', 'ignore') == (b'\\x41\\x42\\x43\\x44\\x45', 22)

# Generated at 2022-06-21 12:38:04.573378
# Unit test for function encode
def test_encode():

    if __name__ == '__main__':
        print(encode('AAA404040404040404040404040404040404040'))
        print(encode('AAA40404040404040404040404040404040404'))
        print(encode('AAA4040404040404040404040404040404040'))


# Generated at 2022-06-21 12:38:07.507171
# Unit test for function register
def test_register():
    try:
        register()
        codecs.getdecoder(NAME)
    except LookupError:
        assert False
    assert True



# Generated at 2022-06-21 12:38:17.296844
# Unit test for function decode
def test_decode():
    assert decode(r'\x48\x65\x6c\x6c\x6f\x20\x57\x6f\x72\x6c\x64') == ('Hello World',10)
    assert decode(b'\x48\x65\x6c\x6c\x6f\x20\x77\x6f\x72\x6c\x64') == ('Hello world',10)
    assert decode(r'\xe4\xbd\xa0\xe5\xa5\xbd',errors='strict') == ('你好',5)
    assert decode(r'\xe4\xbd\xa0\xe5\xa5\xbd',errors='ignore') == ('',0)

# Generated at 2022-06-21 12:38:26.060665
# Unit test for function register
def test_register():
    import os
    import sys
    import unittest

    register()

    try:
        from .test_eutf8h import Test_eutf8h_Codec
        Test_eutf8h_Codec.register = register  # type: ignore
        unittest.main(
            argv=(
                [os.path.basename(sys.argv[0])] +
                sys.argv[1:]
            ),
            testRunner=unittest.TextTestRunner(
                verbosity=2,
                failfast=True,
                buffer=False
            )
        )
    except IndexError:
        pass
    finally:
        os._exit(0)



# Generated at 2022-06-21 12:38:35.491139
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    register()
    utf8_bytes = b'\xF0\x9F\x92\xA9'
    utf8_hex_bytes = b'\\xf0\\x9f\\x92\\xa9'
    decoder = codecs.getdecoder(NAME)
    utf8_hex_bytes_decoded = decoder(utf8_hex_bytes)[0]
    assert utf8_bytes.decode('utf-8') == utf8_hex_bytes_decoded
    encoder = codecs.getencoder(NAME)
    utf8_hex_bytes_encoded = encoder(utf8_hex_bytes_decoded)[0]
    assert utf8_hex_bytes == utf8_hex_bytes_enc

# Generated at 2022-06-21 12:38:45.870352
# Unit test for function encode
def test_encode():
    # Test encoding string to bytes
    assert encode('abcd') == (b'\\x61\\x62\\x63\\x64', 4)
    assert encode('\\x61\\x62\\x63\\x64') == (b'\\x61\\x62\\x63\\x64', 8)
    assert encode('\x61\x62\x63\x64') == (b'\\x61\\x62\\x63\\x64', 4)
    assert encode('\u2603') == (b'\\xe2\\x98\\x83', 1)
    assert encode('\U0001f600') == (b'\\xf0\\x9f\\x98\\x80', 1)

# Generated at 2022-06-21 12:38:56.214308
# Unit test for function encode
def test_encode():
    expected = b'\\61\\62\\63'
    actual = encode('abc')
    assert expected == actual



# Generated at 2022-06-21 12:38:57.076949
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-21 12:39:00.028510
# Unit test for function register
def test_register():
    def test_try_decoder():
        try:
            codecs.getdecoder(NAME)
        except LookupError as e:
            raise Exception(e)

    codecs.register(_get_codec_info)
    test_try_decoder()



# Generated at 2022-06-21 12:39:12.104473
# Unit test for function encode
def test_encode():
    assert encode('\n') == (b'\\x5Cx5C\n', 1)
    assert encode('\u00a5') == (b'\\x5Cx5Cxa5', 2)
    assert encode('\\x05') == (b'\\x5Cx5Cx5Cx30\n', 5)
    assert encode('\\x05', 'backslashreplace') == (b'\\\\x05', 4)
    try:
        encode('\\x05', 'ignore')
    except UnicodeEncodeError:
        pass
    else:
        raise AssertionError('Encode error not raised.')
    try:
        encode('\\x05', 'strict')
    except UnicodeEncodeError:
        pass
    else:
        raise AssertionError('Encode error not raised.')

# Generated at 2022-06-21 12:39:20.487015
# Unit test for function decode

# Generated at 2022-06-21 12:39:26.678415
# Unit test for function encode
def test_encode():
    def t(text: _Str, expected: bytes) -> None:
        actual = encode(text=text, errors='strict')
        assert actual[0] == expected

    t('', b'')
    t('\x00', b'\\x00')
    t('hello', b'hello')
    t('hello\u4040', b'hello\\u4040')



# Generated at 2022-06-21 12:39:31.922310
# Unit test for function register
def test_register():
    test_name = 'test_register'
    print(test_name)
    register()
    try:
        codecs.getdecoder(NAME)
        print('%s: PASSED' % test_name)
    except LookupError as e:
        print('%s: FAILED with %s' % (test_name, str(e)))



# Generated at 2022-06-21 12:39:34.118717
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    decoder = codecs.getdecoder(NAME)
    assert decoder is not None



# Generated at 2022-06-21 12:39:38.852465
# Unit test for function decode
def test_decode():
    # Unit test for function decode
    unhexlify = codecs.getdecoder('unicode_escape')[0]
    assert decode(unhexlify(b'\\xE2\\x82\\xAC')) == ('€', 11)
    assert decode(unhexlify(b'\\xE2\\x82\\xAC'), 'strict') == ('€', 11)



# Generated at 2022-06-21 12:39:43.156855
# Unit test for function register
def test_register():
    import locale
    locale.setlocale(locale.LC_ALL, 'en_US.UTF-8')
    register()
    try:
        codecs.lookup(NAME)
    except LookupError as e:
        raise AssertionError(e)


test_register()


# Unit tests for function encode

# Generated at 2022-06-21 12:40:02.914590
# Unit test for function register
def test_register():
    #
    # test the codect.register() function
    #
    codecs.register(_get_codec_info)
    assert codecs.lookup(NAME)



# Generated at 2022-06-21 12:40:06.256250
# Unit test for function encode
def test_encode():
    in_string = 'A\x61\u0061'
    expect_output = '\\x41\\x61\\x61'
    expect_bytes = expect_output.encode('utf-8')
    output_bytes, _ = encode(in_string)
    assert expect_bytes == output_bytes



# Generated at 2022-06-21 12:40:07.698614
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore

# Generated at 2022-06-21 12:40:18.219463
# Unit test for function encode
def test_encode():
    assert encode('abc') == (b'abc', 3)
    assert encode('abc\x01') == (b'abc\\x01', 5)
    assert encode('💩') == (b'\\xf0\\x9f\\x92\\xa9', 3)
    assert encode('💩\x01') == (b'\\xf0\\x9f\\x92\\xa9\\x01', 5)
    assert encode('\xff') == (b'\\xff', 3)
    assert encode('\\xff') == (b'\\x5c\\x66\\x66', 6)
    assert encode('\\xFF') == (b'\\x5c\\x66\\x66', 6)
    assert encode('\\xff\\xFF') == (b'\\xff\\x5c\\x66\\x66', 10)
   

# Generated at 2022-06-21 12:40:19.869452
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)

# Generated at 2022-06-21 12:40:23.478543
# Unit test for function register
def test_register():
    old_decoder = codecs.getdecoder(NAME)
    codecs.register(_get_codec_info)
    new_decoder = codecs.getdecoder(NAME)
    assert new_decoder != old_decoder

# Generated at 2022-06-21 12:40:31.501555
# Unit test for function encode
def test_encode():
    assert encode('a') == (b'a', 1)
    assert encode('a\\') == (b'a\\\\', 2)
    assert encode('ä') == (b'\\xc3\\xa4', 1)
    assert encode('å') == (b'\\xc3\\xa5', 1)
    assert encode('ä\\') == (b'\\xc3\\xa4\\\\', 2)
    assert encode('å\\') == (b'\\xc3\\xa5\\\\', 2)
    assert encode('äå') == (b'\\xc3\\xa4\\xc3\\xa5', 2)
    assert encode('\\xE2\\x9C\\xA8') == (b'\\xe2\\x9c\\xa8', 1)

# Generated at 2022-06-21 12:40:32.990713
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:40:42.123750
# Unit test for function decode
def test_decode():
    out = decode(b'\\x30\\x78\\x31\\x32\\x38\\x3a\\x31\\x32\\x38\\x2e\\x30\\x2e\\x30\\x2e\\x30\\x3a\\x31\\x32\\x38\\x30\\x30')
    assert out[0] == '0x128:128.0.0.0:12800'
    assert out[1] == 25

    out = decode(b'\\x30\\x78\\x31\\x32\\x38\\x3a\\x31\\x32\\x38\\x2e\\x30\\x2e\\x30\\x2e\\x30\\x3a\\x31\\x32\\x38\\x30\\x30', errors='replace')

# Generated at 2022-06-21 12:40:43.486087
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:41:27.572917
# Unit test for function decode
def test_decode():
    """Test function decode
    """
    data = bytes(b'\\x57\\x65\\x20\\x6C\\x6F\\x76\\x65\\x20\\x74\\x68\\x65\\x20\\x6C\\x69\\x66\\x65\\x2E')
    out, consumed = decode(data)
    assert consumed == 17
    assert out == 'We love the life.'

# Generated at 2022-06-21 12:41:32.818623
# Unit test for function encode
def test_encode():
    input: str = 'abcde\xf6\xad\xad\xbf\xbf'
    expected_output: bytes = b'abcde\\xf6\\xad\\xad\\xbf\\xbf'
    actual_output, _ = encode(input)
    assert actual_output == expected_output



# Generated at 2022-06-21 12:41:34.954543
# Unit test for function register
def test_register():
    register()
    decoder = codecs.getdecoder(NAME)  # type: ignore

# Add custom codec to set of standard codecs
register()

# Generated at 2022-06-21 12:41:42.614509
# Unit test for function decode
def test_decode():
    assert decode(br'\\u2665') == ('♥', 5)
    assert decode(br'\\u0000') == ('\u0000', 6)
    assert decode(br'\\U00000000') == ('\u0000', 10)
    assert decode(br'\\u0041') == ('A', 6)
    assert decode(br'\\u0001') == ('\u0001', 6)
    assert decode(br'\\U00000001') == ('\u0001', 10)
    assert decode(br'\\u0001') == (decode(b'U00000001')[0], 6)


# Generated at 2022-06-21 12:41:47.820847
# Unit test for function decode
def test_decode():
    test_str_hex = b'\\x41\\x42\\x43'
    test_str_out, test_int_out = decode(test_str_hex)
    assert test_str_out == 'ABC'
    assert test_int_out == len(test_str_hex)



# Generated at 2022-06-21 12:41:52.421011
# Unit test for function register
def test_register():
    register()
    try:
        decoded = codecs.decode(b'\\110\\x41\\x42\\x43', NAME)   # type: ignore
        assert decoded == r'\NABC'
    except LookupError:
        assert False

test_register()


# Generated at 2022-06-21 12:42:01.764329
# Unit test for function encode
def test_encode():
    codecs.register(_get_codec_info)

    # Test case 1
    try:
        codecs.encode('\u08e8', NAME)
    except UnicodeEncodeError as e:
        assert (
            e.encoding == NAME
        ), 'encoding error'
        assert (
            e.reason == "invalid continuation byte"
        ), 'reason error'
        assert (
            e.object == '\u08e8'
        ), 'object error'
        assert (
            e.start == 0
        ), 'start error'
        assert (
            e.end == 1
        ), 'end error'
    else:
        assert False, 'encoding no error'

    # Test case 2
    new_str, count = codecs.encode('\u00e8', NAME)

# Generated at 2022-06-21 12:42:13.036213
# Unit test for function decode
def test_decode():
    assert decode(b'\x6A')[0] == 'j'
    assert decode(b'\x61\x62\x7A')[0] == 'abz'
    assert decode(b'\x61\x62\x7a')[0] == 'abz'
    assert decode(b'\x61\x62 \x7A')[0] == 'ab z'
    assert decode(b"\x61\\n")[0] == r'a\n'
    assert decode(b"\x61\\\x6e")[0] == r'a\x6e'
    assert decode(b'\x61\x62\x7A')[0] == 'abz'

# Generated at 2022-06-21 12:42:24.139006
# Unit test for function decode
def test_decode():
    assert decode(b'\\xc3\\xbfNULL') == ('\xefNULL', 6)
    assert decode(b'\\x00\\xf0\\x00') == ('\x00\xf0\x00', 6)
    assert decode(b'\\x00\\xf0\\x00', 'replace') == \
        ('\x00\ufffd\x00', 6)
    assert decode(b'\\x00\\xf0\\x00', 'ignore') == ('\x00\x00', 6)
    assert decode(b'\\x00\\xf0\\x00', 'backslashreplace') == \
        ('\x00\\xf0\\x00', 6)
    assert decode(b'\\x00\\x00', 'surrogatepass') == ('\x00\x00', 6)

# Generated at 2022-06-21 12:42:27.646350
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)


if __name__ == '__main__':
    test_register()

# vim: ts=4 sw=4 et

# Generated at 2022-06-21 12:43:54.244351
# Unit test for function encode
def test_encode():
    text = 'This is a test: 0xF0\\x90\\x85\\x88'

    # 你好
    bytes_decoded, count = encode(text)
    bytes_raw = b'This is a test: 0xF0\\x90\\x85\\x88'
    if bytes_decoded != bytes_raw:
        raise Exception(
            'encode({}): {}; {}'.format(
                text,
                bytes_decoded,
                bytes_raw,
            )
        )



# Generated at 2022-06-21 12:44:00.982275
# Unit test for function encode
def test_encode():
    assert encode('foo', errors='a') == (b'foo', 3)
    assert encode('\\x61\\x62', errors='a') == (b'\\x61\\x62', 8)
    assert encode('\\x61\\x62', errors='b') == (b'\\x61\\x62', 8)
    assert encode('\\x61\\x62', errors='c') == (b'\\x61\\x62', 8)
    assert encode('\\x61\\x62', errors='d') == (b'\\x61\\x62', 8)
    assert encode('\\x61\\x62', errors='e') == (b'\\x61\\x62', 8)
    assert encode('\\x61\\x62', errors='f') == (b'\\x61\\x62', 8)

# Generated at 2022-06-21 12:44:10.479200
# Unit test for function encode
def test_encode():
    """Perform unit testing for function encode."""

    # high-order function testing

    def test_encode_value_error(
            test_text: _Str,
            test_errors: _Str
    ) -> None:
        with pytest.raises(ValueError):
            encode(test_text, test_errors)

    def test_encode_unicode_encode_error(
            test_text: _Str,
            test_errors: _Str
    ) -> None:
        with pytest.raises(UnicodeEncodeError):
            encode(test_text, test_errors)

    def test_encode_with_expected_bytes(
            test_text: _Str,
            test_errors: _Str,
            expected_bytes: bytes,
    ) -> None:
        actual_bytes, actual_

# Generated at 2022-06-21 12:44:12.166411
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:44:20.412198
# Unit test for function decode
def test_decode():
    test_data = [
        ('\\xC3\\xA9', 'é'),
        ('\\x61\\x62\\x63', 'abc'),
        ('\\x61\\x62\\x63\\xC3\\xA9', 'abcé')
    ]
    for test_str, expected in test_data:
        actual = decode(test_str.encode('utf-8'))[0]
        print(f'Expected: {expected}, Actual: {actual}')
        assert actual == expected


# Generated at 2022-06-21 12:44:22.821727
# Unit test for function decode
def test_decode():
    assert decode(
        b'\\u65e5\\u672c\\u8a9e',
    ) == ('日本語', 18)



# Generated at 2022-06-21 12:44:32.501041
# Unit test for function decode
def test_decode():
    s = bytes(b'\\xC3\\xBC')
    ds, size = decode(s)
    assert ds == 'ü'
    assert size == len(s)

    s = bytes(b'\\x61\\xC3\\xBC')
    ds, size = decode(s)
    assert ds == 'aü'
    assert size == len(s)

    # Test handling of invalid ascii escape sequences
    ds, size = decode(bytes(b'\\x61\\xC3\\xBC\\x61\\xC3'), 'replace')
    assert ds == 'aüa�'
    assert size == 5

    ds, size = decode(bytes(b'\\x61\\xC3\\xBC\\x61\\xC3'), 'ignore')

# Generated at 2022-06-21 12:44:37.879836
# Unit test for function encode
def test_encode():
    test_str = '\ufb00'
    expected = b'\\xf0\\xae\\x80\\x80'
    out_bytes, num_consumed = encode(test_str)
    assert out_bytes == expected
    assert num_consumed == 1


# Generated at 2022-06-21 12:44:47.066283
# Unit test for function register
def test_register():
    # Get the codec for the name 'eutf8h'
    codecs.getdecoder('eutf8h')   # type: ignore


if __name__ == '__main__':
    # Test the functions register and getdecoder.
    test_register()

    # Test the function encode.
    import unittest

    # noinspection PyMissingOrEmptyDocstring