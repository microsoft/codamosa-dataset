

# Generated at 2022-06-21 12:34:52.837864
# Unit test for function decode
def test_decode():
    print("Testing function decode")
    assert decode("\\x61") == ("a", 4)
    assert decode("\\x41") == ("A", 4)
    assert decode("\\x61\\x62") == ("ab", 7)
    assert decode("\\x41\\x42") == ("AB", 7)
    assert decode("\\x61\\x62\\x63") == ("abc", 10)
    assert decode("\\x41\\x42\\x43") == ("ABC", 10)
    print("Done")


# Generated at 2022-06-21 12:34:58.739205
# Unit test for function decode
def test_decode():
    assert decode(b'\\xE1\\x84\\xA0\\xE1\\x85\\xA7\\xE1\\x86\\xA8') == ('ᄠᅧᆨ', 26)
    assert decode(b'\\xE1\\x84\\xA0\\xE1\\x85\\xA7\\xE1\\x86\\xA8', 'ignore') == ('ᄠᅧ', 24)
    assert decode(b'\\xE1\\x84\\xA0\\xE1\\x85\\xA7\\xE1\\x86\\xA8', 'replace') == ('ᄠᅧ�', 26)

# Generated at 2022-06-21 12:35:02.940597
# Unit test for function decode
def test_decode():
    assert decode(b'\\x41')[0] == 'A'
    assert decode(b's\\xc3\\xa9\\xea\\xf3\\xea\\x70\\xe8\\x66\\x65\\xea\\x70\\xea')[0] == 'sééõépèfeépé'


# Generated at 2022-06-21 12:35:04.271355
# Unit test for function decode
def test_decode():
    _, _ = decode('\\xC3\\x80')


# Generated at 2022-06-21 12:35:12.510295
# Unit test for function decode
def test_decode():
    str_input = r'\xe5\xb0\x8f\xe5\xb0\x8f\xe5\xb0\x8f'
    str_output = '小小小'
    s = str_input.encode('eutf8h')
    assert decode(s)[0] == str_output

    str_input = r'\xe5\xb0\x8f\xe5\xb0\x8f\xe5\xb0\x8f'
    str_output = '小小小'
    s = str_input.encode('eutf8h')
    assert decode(s)[0] == str_output


# Generated at 2022-06-21 12:35:25.334729
# Unit test for function decode
def test_decode():
    test_data_str = (
        'const int kVotedForDefault = -1;\\u000a'
        'const int kMaxLogEntries = 1024;\\u000a'
        'const int kMaxPeers = 5;\\u000a'
    )
    test_data_bytes = test_data_str.encode('utf-8')
    str_out, int_out = decode(test_data_bytes)
    assert str_out == 'const int kVotedForDefault = -1;\\n' \
                      'const int kMaxLogEntries = 1024;\\n' \
                      'const int kMaxPeers = 5;\\n'
    assert int_out == len(test_data_bytes)


# Generated at 2022-06-21 12:35:29.974679
# Unit test for function decode
def test_decode():
    # Unit tests:
    test_0 = decode(b'')
    assert test_0[0] == ''
    assert test_0[1] == 0

    test_1 = decode(b'12')
    assert test_1[0] == '1'
    assert test_1[1] == 1

    test_2 = decode(b'hello')
    assert test_2[0] == 'hello'
    assert test_2[1] == len('hello')

    test_3 = decode(b'\\x41\\x42\\x43')
    assert test_3[0] == 'ABC'
    assert test_3[1] == 9

    test_4 = decode(b'\\x00\\x01\\x02\\x03\\x04')

# Generated at 2022-06-21 12:35:30.773687
# Unit test for function register
def test_register():
    codecs.lookup(NAME)



# Generated at 2022-06-21 12:35:35.523665
# Unit test for function decode
def test_decode():
    input_hex = b'\\x1b\\x28\\x42'
    exp_result_str = '\x1b(B'
    exp_result_len = 9
    result_str, result_len = decode(input_hex)
    assert result_str == exp_result_str
    assert result_len == exp_result_len


# Generated at 2022-06-21 12:35:42.393029
# Unit test for function register
def test_register():
    """Test the function register in this module."""
    # Verify that the codec is not registered.
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)

    # Register the codec.
    register()

    # Verify that the codec is registered.
    assert isinstance(codecs.getdecoder(NAME), codecs.CodecInfo)



# Generated at 2022-06-21 12:35:48.488047
# Unit test for function encode
def test_encode():
    assert encode('a') == (b'a', 1)
    assert encode('hello world') == (b'hello world', 11)
    assert encode('OK') == (b'OK', 2)
    assert encode('\u0627\u0644\u0633\u0639\u0648\u062f\u064a\u0629') == (b'\\xd8\\xa7\\xd9\\x84\\xd8\\xb3\\xd8\\xb9\\xd9\\x88\\xd8\\xb1\\xd9\\x8a\\xd8\\xa9', 12)
    assert encode('\u0622\u0632') == (b'\\xd8\\xa2\\xd8\\xb2', 4)

# Generated at 2022-06-21 12:36:00.774489
# Unit test for function encode
def test_encode():
    assert encode('a') == (b'a', 1)
    assert encode('abc') == (b'abc', 3)
    assert encode(r'\x41') == (b'\\x41', 3)
    assert encode(r'\x41\x41') == (b'\\x41\\x41', 6)
    assert encode(r'\\x41') == (b'\\\\x41', 4)
    assert encode(r'\\\x41') == (b'\\\\\\x41', 5)
    assert encode(br'\x41') == (b'\\x41', 3)
    assert encode(br'\x41\x41') == (b'\\x41\\x41', 6)
    assert encode(br'\\x41') == (b'\\\\x41', 4)

# Generated at 2022-06-21 12:36:12.664445
# Unit test for function encode
def test_encode():
    # *********************************************
    # *** This is what we want to encode
    # *********************************************
    x = '\N{LATIN SMALL LETTER A WITH ACUTE}'
    latin1 = x.encode('latin1')
    utf8 = latin1.decode('latin1').encode('utf8')
    xhex = utf8.hex()

    # *********************************************
    # *** This is the input to the function 'encode'
    # *********************************************
    in_ = '\\x%s' % xhex

    # *********************************************
    # *** This is the output from the function 'encode'
    # *********************************************
    out, n = encode(in_)

    assert n == 1

    assert out == utf8


# Generated at 2022-06-21 12:36:14.207710
# Unit test for function register
def test_register():
    register()


# Unit tests
# noinspection DuplicatedCode

# Generated at 2022-06-21 12:36:18.601883
# Unit test for function decode
def test_decode():
    assert decode(b'\\xC3\\xB1') == ('ñ', 8)
    assert decode(b'X\\xC3\\xB1') == ('Xñ', 8)
    assert decode(b'\\xC3\\xB1X') == ('ñX', 8)
    assert decode(b'') == ('', 0)
    assert decode(b'\\x00') == ('\x00', 4)
    assert decode(b'\\xC3\\xB1', 'replace') == ('ñ', 8)
    assert decode(b'X\\xC3\\xB1', 'replace') == ('Xñ', 8)
    assert decode(b'\\xC3\\xB1X', 'replace') == ('ñX', 8)
    assert decode(b'', 'replace') == ('', 0)

# Generated at 2022-06-21 12:36:21.539117
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


if __name__ == "__main__":
    # execute only if run as a script
    test_register()

# Generated at 2022-06-21 12:36:25.716880
# Unit test for function decode
def test_decode():
    in_data = b'\\xe6\\x99\\xae\\xe9\\x80\\x9a'
    out_str, out_len = eutf8h.decode(in_data)
    assert out_str == '普通' and out_len == 10

# Generated at 2022-06-21 12:36:31.876903
# Unit test for function decode
def test_decode():
    assert decode(
        b']\\xC2\\xA1\\xC2\\xBF',
    ) == (']\u00a1\u00bf', 12)
    assert decode(
        b']\\xC2\\xA1\\xC2\\xBF\\n',
    ) == (']\u00a1\u00bf\n', 13)
    assert decode(
        b'\\xC2',
    ) == ('\u00c2', 4)
    assert decode(
        b'\\xC2h',
    ) == ('\u00c2h', 4)
    assert decode(
        b'\\xC2h\\xC2h\\xC2hh',
    ) == ('\u00c2h\u00c2h\u00c2hh', 12)

# Generated at 2022-06-21 12:36:44.294800
# Unit test for function decode
def test_decode():
    # noinspection SpellCheckingInspection
    assert decode(b'\\xD0\\xA3\\xD0\\xB4\\xD0\\xB0\\xD1\\x80\\xD0\\xB5') == \
        ('Ударе', 10)

    # noinspection SpellCheckingInspection
    assert decode(b'\\xD0\\xA1\\xD0\\xB8\\xD0\\xB3\\xD1\\x80\\xD0\\xB0') == \
        ('Сигра', 10)

    # noinspection SpellCheckingInspection

# Generated at 2022-06-21 12:36:52.245541
# Unit test for function encode
def test_encode():
    print('Test encode')
    # Test with empty string
    text = ''
    text_bytes, _ = encode(text)
    print(f'{text} -> {text_bytes}')
    assert(text_bytes == b'')
    
    # Test with white space
    text = ' '
    text_bytes, _ = encode(text)
    print(f'{text} -> {text_bytes}')
    assert(text_bytes == b' ')
    
    # Test with all printable characters
    printable_str = ''.join(chr(i) for i in range(32, 127))
    text_bytes, _ = encode(printable_str)
    print(f'{printable_str} -> {text_bytes}')

# Generated at 2022-06-21 12:37:03.845693
# Unit test for function decode
def test_decode():
    assert(decode(b'A') == ('A', 1))
    assert(decode(b'\\x41') == ('A', 4))
    assert(decode(b'ABC') == ('ABC', 3))
    assert(decode(b'ABC\\x20DEF') == ('ABC DEF', 9))
    assert(decode(b'ABC\\x20DEF\\x20') == ('ABC DEF ', 11))
    assert(decode(b'\\x67\\x61\\x6d\\x65\\x6e\\x6f\\x6f\\x76\\x65\\x72')
           == ('gamenoover', 18))
    assert(decode(b'\\xef\\xbd\\xa1\\xef\\xbd\\xa5')
           == ('ちゅ', 12))

# Generated at 2022-06-21 12:37:15.007733
# Unit test for function decode
def test_decode():
    assert decode(b'a') == ('a', 1)
    assert decode(b'\\x42') == ('B', 3)
    assert decode(b'\\x7f') == ('\u007f', 3)
    assert decode(b'\\x0a') == ('\n', 3)
    assert decode(b'\\x61\\x62\\x63') == ('abc', 9)
    assert decode(b'\\x61\\x62\\x63', 'strict') == ('abc', 9)
    assert decode(b'\\x61\\x62\\x63', 'ignore') == ('', 9)
    assert decode(b'\\x61\\x62\\x63', 'replace') == ('ab?', 9)

# Generated at 2022-06-21 12:37:25.061349
# Unit test for function encode
def test_encode():

    # Test no string
    #
    # Expected output:
    #   b'', len('')

    test_text_input: str = ''
    test_errors_input: str = 'strict'

    got: bytes
    got_len: int

    got, got_len = encode(test_text_input, test_errors_input)
    print(f'({repr(got)}, {repr(got_len)})')
    assert got == b''
    assert got_len == len(test_text_input)

    # Test string consisting of only ascii characters
    #
    # Expected output:
    #   b'hello world', len('hello world')

    test_text_input: str = 'hello world'
    test_errors_input: str = 'strict'

    got: bytes

# Generated at 2022-06-21 12:37:35.605615
# Unit test for function encode
def test_encode():
    a = encode('abc”')
    assert a[0] == b'abc\\xe2\\x80\\x9d'
    b = encode('“abc”')
    assert b[0] == b'\\xe2\\x80\\x9cabc\\xe2\\x80\\x9d'
    c = encode('a“bc”d')
    assert c[0] == b'a\\xe2\\x80\\x9cbc\\xe2\\x80\\x9dd'
    d = encode('abc\u0082')
    assert d[0] == b'abc\\x82'
    e = encode('abc\uFFFD')
    assert e[0] == b'abc\\xef\\xbf\\xbd'
    f = encode('\uFFFDabc\uFFFD')


# Generated at 2022-06-21 12:37:46.515846
# Unit test for function decode
def test_decode():
    # The following test is from the Python3 built-in utf-8-1 codec.
    test_str: str = '\u0663\u0661\u0664 '

    test_str_hex: str = '\\u0663\\u0661\\u0664\\x20'

    test_bytes: bytes = test_str.encode(NAME)

    test_bytes_hex: bytes = test_str_hex.encode('utf-8')

    assert test_bytes == test_bytes_hex

    test_bytes: bytes = test_str.encode(NAME)

    assert test_bytes == test_bytes_hex

    assert decode(test_bytes) == (test_str, len(test_bytes))

    assert decode(test_bytes_hex) == (test_str, len(test_bytes_hex))

   

# Generated at 2022-06-21 12:37:58.358690
# Unit test for function decode
def test_decode():
    from textwrap import dedent

    # noinspection PyShadowingNames
    def test_decode(data, expected, errors='strict'):
        data = bytes(data, 'utf-8')
        out, count = decode(data, errors)
        assert out == expected, (
            f"data: {data!r}, out: {out!r}, expected: {expected!r}"
        )
        assert count == len(data), (
            f"data: {data!r}, count: {count}, expected: {len(data)}"
        )

    test_decode(
        '\\x01',
        '\x01',
        'strict',
    )

    test_decode(
        '\\x01',
        '\x01',
        'ignore',
    )


# Generated at 2022-06-21 12:38:08.518408
# Unit test for function decode
def test_decode():
    assert decode(b'\\xc3\\xa3o') == ('ão', 8)
    assert decode(b'\\xaa', 'strict') == ('ª', 4)

    assert decode(b'\\xaa', 'ignore') == ('', 4)
    assert decode(b'\\xaa', 'replace') == ('�', 4)
    assert decode(b'\\xaa', 'backslashreplace') == ('\\xaa', 4)

    assert decode(b'\\xaa', 'xmlcharrefreplace') == ('&#170;', 4)


if __name__ == '__main__':
    test_decode()

# Generated at 2022-06-21 12:38:14.480337
# Unit test for function encode
def test_encode():
    # Examples taken from https://docs.python.org/3/library/codecs.html#encodings-and-unicode
    assert encode('abc') == (b'abc', 3)
    assert encode('\u0776\u0764\u0780') == (b'\\u0db8\\u0dd4\\u0dc0', 3)
    assert encode('ab\U00020061c') == (b'ab\\U0004d06c', 3)



# Generated at 2022-06-21 12:38:24.791808
# Unit test for function encode
def test_encode():
    import io
    import sys

    print('\nTesting encode')

    cases = (
        ('', ''),
        ('a', 'a'),
        ('ab', 'ab'),
        ('abc', 'abc'),
        ('abcde', 'abcde'),
        ('abcdef', 'abcdef'),
        ('\x80', '\\xc2\\x80'),
        ('\xa0', '\\xc2\\xa0'),
        ('\xc0', '\\xc3\\x80'),
        ('\xe0', '\\xc3\\xa0'),
        ('\xeb', '\\xc3\\xab'),
        ('\xed', '\\xc3\\xad'),
    )

    has_utf8 = 'UTF-8' in codecs.charmap_build().getencoding()

# Generated at 2022-06-21 12:38:34.667792
# Unit test for function decode
def test_decode():
    h = codecs.getdecoder(NAME)
    assert(h)

    o, _ = h(b'\\x41\\x42\\x43', 'strict')
    assert(o == 'ABC')

    o, _ = h(b'\\x41\\x42\\x43', 'ignore')
    assert (o == 'ABC')

    o, _ = h(b'\\x41\\x42\\x43', 'replace')
    assert (o == 'ABC')

    o, _ = h(b'\\x41\\x42\\x43', 'backslashreplace')
    assert (o == 'ABC')

    o, _ = h(b'\\x41\\x42\\x43', 'surrogateescape')
    assert (o == 'ABC')


# Generated at 2022-06-21 12:38:45.358810
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, ('Unable to register codec %s to codecs module', NAME)



# Generated at 2022-06-21 12:38:51.619008
# Unit test for function encode
def test_encode():
    utf8_string = 'Hello World! 你好，世界！'

    # Encode the string
    (utf8_hex_bytes, _) = encode(utf8_string)

    # Decode the string
    (utf8_unhex_string, _) = decode(utf8_hex_bytes)

    # Make sure the decoded string matches the original string.
    assert utf8_string == utf8_unhex_string



# Generated at 2022-06-21 12:38:55.121456
# Unit test for function decode
def test_decode():
    r"""
    >>> decode(b'\\xF0\\x9F\\x98\\x80') == ('\U0001f600', 10)
    True
    >>> decode(b'\\U0001f600') == ('\U0001f600', 10)
    True
    >>> decode(b'\\U0001f600\\U0001f600') == ('\U0001f600\U0001f600', 20)
    True
    """



# Generated at 2022-06-21 12:38:58.154896
# Unit test for function decode
def test_decode():
    assert decode(b'\\x41\\x42\\x43') == ('ABC', 12)
    assert decode(b'\\x41\\x42\\x43') == ('ABC', 12)



# Generated at 2022-06-21 12:39:02.414327
# Unit test for function decode
def test_decode():
    data = b'abcdefg'
    input_text = '\\x61\\x62\\x63\\x64\\x65\\x66\\x67'
    out, _ = decode(data)
    assert out == input_text



# Generated at 2022-06-21 12:39:06.420324
# Unit test for function encode
def test_encode():
    input_text = 'a\x80'
    output_bytes, _ = encode(input_text)

    input_text = 'a\\x80'
    output_bytes_expected, _ = encode(input_text)

    assert output_bytes == output_bytes_expected

# Generated at 2022-06-21 12:39:16.596616
# Unit test for function register

# Generated at 2022-06-21 12:39:27.529758
# Unit test for function encode
def test_encode():
    inputs = (
        # String Input
        'Test String',
        # String from utf8 hexadecimal reference
        '\ud800\udf00',
        # String with escaped hexadecimal
        '\\x45\\x66\\x61\\x6D',
    )

    expect_output = (
        # Expect output as a bytes object
        b'Test String',
        # Expect a utf8 hexadecimal reference
        b'\\xF0\\x90\\x8C\\x80',
        # Expect a escaped hexadecimal
        b'\\x45\\x66\\x61\\x6D',
    )

    for string_input, expect in zip(inputs, expect_output):
        # Convert a string into escaped utf8.
        output_bytes, _ = encode(string_input)

# Generated at 2022-06-21 12:39:37.540364
# Unit test for function decode
def test_decode():
    # Examples taken from https://docs.python.org/3/library/codecs.html

    # Example 1
    # >>> codecs.decode('\xC3\xB1', 'latin_1')
    # '\xf1'

    r = decode(b'\xC3\xB1')
    assert r == ('\xf1', 1)

    # Example 2
    # >>> codecs.decode(b'\xE2\x82\xAC', 'utf_8')
    # '\u20ac'

    r = decode(b'\xE2\x82\xAC')
    assert r == ('\u20ac', 1)

    # Example 3
    # >>> codecs.decode(b'\xc2\xa2', 'iso8859_1')
    # '\

# Generated at 2022-06-21 12:39:47.435603
# Unit test for function encode
def test_encode():
    assert encode('a') == (b'a', 1)
    assert encode('abc') == (b'abc', 3)
    assert encode('a b c') == (b'a b c', 5)
    assert encode('1') == (b'1', 1)
    assert encode('12') == (b'12', 2)
    assert encode('123') == (b'123', 3)
    assert encode('12 3') == (b'12 3', 4)
    assert encode(' ') == (b' ', 1)
    assert encode('  ') == (b'  ', 2)
    assert encode('   ') == (b'   ', 3)
    assert encode('\n') == (b'\n', 1)
    assert encode('\n\n') == (b'\n\n', 2)

# Generated at 2022-06-21 12:39:56.002391
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-21 12:39:57.870323
# Unit test for function encode
def test_encode():
    assert encode('hello') == (b'\\68\\65\\6c\\6c\\6f', 5)



# Generated at 2022-06-21 12:40:06.791401
# Unit test for function decode
def test_decode():
    plain = b'abcdefghijklmnopqrstuvwxyz'
    plain_ascii = plain.decode()
    hex_ascii = '\\x61\\x62\\x63\\x64\\x65\\x66\\x67\\x68\\x69\\x6A\\x6B\\x6C' \
                '\\x6D\\x6E\\x6F\\x70\\x71\\x72\\x73\\x74\\x75\\x76\\x77' \
                '\\x78\\x79\\x7A'
    assert decode(hex_ascii)[0] == plain_ascii

    plain_xF8 = b'\xC4\xB1'
    plain_xF8_ascii = plain_xF8.decode()

   

# Generated at 2022-06-21 12:40:15.291032
# Unit test for function decode
def test_decode():
    # Test with normal string
    s = "test string"
    s_, l = decode(s)
    assert s_ == "test string"
    assert l == 11

    # test with unicode char
    u = u'\u2295'
    u_, l = decode(u)
    assert u_ == u
    assert l == 1

    # test with utf8 hex char
    u = b'\\xE2\\x8a\\x95'
    u_, l = decode(u)
    assert u_ == u'\u2295'
    assert l == 3


# Generated at 2022-06-21 12:40:19.498240
# Unit test for function decode
def test_decode():
    try:
        # noinspection PyUnresolvedReferences
        from . import _test_decode
    except ImportError:
        print("_test_decode.py not found")
        return

    print("test_decode BEGIN")
    _test_decode.test_decode()
    print("test_decode END")



# Generated at 2022-06-21 12:40:28.765484
# Unit test for function encode
def test_encode():
    assert encode('this is a string\u0123\u0123') == b'this is a string\\u0123\\u0123'
    assert encode('this is a string\u0123\u0123', 'ignore') == b'this is a string\\u0123\\u0123'
    assert encode('this is a string\u0123\u0123', 'replace') == b'this is a string\\u0123\\ufffd'
    assert encode('this is a string\u0123\u0123', 'xmlcharrefreplace') == b'this is a string&#291;&#291;'
    assert encode('this is a string\u0123\u0123', 'backslashreplace') == b'this is a string\\u0123\\ufffd'

# Generated at 2022-06-21 12:40:31.972117
# Unit test for function decode
def test_decode():
    src = b'\\x41\\x42\\x43'
    expected_out = b'ABC'
    out, consumed = decode(src)
    assert out == expected_out
    assert consumed == len(src)



# Generated at 2022-06-21 12:40:40.675324
# Unit test for function decode
def test_decode():
    data_bytes = b'\\xC3\\xA6'
    res = codecs.decode(data_bytes, NAME)
    assert res[0] == 'æ'
    assert res[1] == len(data_bytes)

    data_bytes = b'\\xC3\\xA6' + b'\\xC3\\xA6'
    res = codecs.decode(data_bytes, NAME)
    assert res[0] == 'ææ'
    assert res[1] == len(data_bytes)

    data_bytes = b'\\xC3\\xA6'
    res = codecs.decode(data_bytes, NAME, errors='ignore')
    assert res[0] == ''
    assert res[1] == len(data_bytes)


# Generated at 2022-06-21 12:40:51.348907
# Unit test for function encode

# Generated at 2022-06-21 12:40:59.284256
# Unit test for function encode
def test_encode():
    text = 'Hello'
    out, _ = encode(text)
    assert out == b'Hello'
    text = '\x04'
    out, _ = encode(text)
    assert out == b'\\x04'
    text = '\\x04'
    out, _ = encode(text)
    assert out == b'\\x04'
    text = '\\x04x'
    out, _ = encode(text)
    assert out == b'\\x04x'
    text = '\u2665'
    out, _ = encode(text)
    assert out == b'\\xe2\\x99\\xa5'
    text = '\U0001F44D'
    out, _ = encode(text)
    assert out == b'\\xf0\\x9f\\x91\\x8d'


# Generated at 2022-06-21 12:41:26.036153
# Unit test for function encode
def test_encode():
    assert encode('\\xFF') == (b'\\xFF', 2)
    assert encode('\\xC3\\x83') == (b'\\xC3\\x83', 5)
    assert encode('\\u03A3') == (b'\\xCE\\xA3', 6)
    assert encode('a\\xFF') == (b'a\\xFF', 3)
    assert encode('a\\xC3\\x83') == (b'a\\xC3\\x83', 6)
    assert encode('a\\u03A3') == (b'a\\xCE\\xA3', 7)
    assert encode('a\\u03A3\\xFF') == (b'a\\xCE\\xA3\\xFF', 9)
    assert encode('a\\u03A3\\xC3\\x83')

# Generated at 2022-06-21 12:41:33.017626
# Unit test for function register
def test_register():
    def can_get_name():
        name = codecs.getdecoder(NAME)[0].__name__
        assert name == NAME

    register()
    try:
        can_get_name()
    finally:
        codecs.lookup_error(NAME)
        assert NAME not in codecs.__dict__


if __name__ == '__main__':
    test_register()


if __name__ == '__main__':
    pass

# Generated at 2022-06-21 12:41:40.009726
# Unit test for function encode
def test_encode():
    print(encode('hello'))
    print(encode(r'\x48\x65\x6c\x6c\x6f'))
    print(encode(r'x\x0a0\x0A'))
    print(encode(r'abc\0def'))
    print(encode(r'\xE2\x98\x83'))  # SNOWMAN
    print(encode(r'x\x0a0\x0A'))
    print(encode(r'\u00F0\u009F\u0087\u00B0\u00F0'))
    print(encode(r'\U0001F46E'))

# Generated at 2022-06-21 12:41:41.308317
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getdecoder(NAME)()

# Generated at 2022-06-21 12:41:48.528871
# Unit test for function decode
def test_decode():
    # Decode an escaped utf8 hex
    out, len_ = decode(b'\\xc2\\xa2')
    assert len_ == 10 and out == '¢'

    # Decode a mixed string of escaped utf8 hex and ascii characters
    out, len_ = decode(b'\\xc2\\xa2 is \\x32\\x30\\x25')
    assert len_ == 28 and out == '¢ is 20%'

    # Invoke the function with an invalid encoded character
    try:
        out, len_ = decode(b'\\xc2\\xa2 is \\x32UNKNOWN\\x25')
    except UnicodeDecodeError as e:
        assert e.encoding == 'eutf8h'
        assert e.start == 18
        assert e.end == 19

# Generated at 2022-06-21 12:41:54.585719
# Unit test for function decode
def test_decode():
    # No exception raised.
    decode('a\\xE2\\x98\\x83')
    decode('a\\xE2\\x98\\\\x83')

    # Exception raised.
    try:
        decode('a\\xE2\\x98\\\\x\\x83')
    except UnicodeDecodeError:
        pass

    # Empty bytes not consumed.
    assert decode(bytes(0)) == ("", 0)



# Generated at 2022-06-21 12:42:02.566626
# Unit test for function decode
def test_decode():
    u = 'Test of unicode \u00c3\u201a\u201d.'
    b = b'Test of unicode \\xC3\\x88\\xE2\\x80\\x9A\\xE2\\x80\\x9D.'
    assert(u.encode('utf8') == b)
    assert(u == decode(b)[0])
    assert(len(b) == decode(b)[1])
    assert(u.encode('utf8') == decode(b)[0].encode('utf8'))
    try:
        decode(b'Test of unicode \\xC3\\')
        assert(False)
    except UnicodeDecodeError:
        pass



# Generated at 2022-06-21 12:42:13.892140
# Unit test for function encode
def test_encode():
    assert encode('hello') == (b'hello', 5)
    assert encode('hello world') == (b'hello world', 11)
    assert encode('hello\t\\x60\\x61\\x62\\x63\\x64\\x65\\x66\\x67\\x68\\x69') == (b'hello\\x09\\\\x60\\\\x61\\\\x62\\\\x63\\\\x64\\\\x65\\\\x66\\\\x67\\\\x68\\\\x69', 25)
    assert encode('\\x60\\x61\\x62\\x63\\x64\\x65\\x66\\x67\\x68\\x69') == (b'\\x60\\x61\\x62\\x63\\x64\\x65\\x66\\x67\\x68\\x69', 20)

# Generated at 2022-06-21 12:42:24.939135
# Unit test for function encode
def test_encode():
    assert encode('1') == (b'1', 1)
    assert encode('1\n') == (b'1\\n', 2)
    assert encode('1\n2') == (b'1\\n2', 3)
    assert encode('1\n2\n\n') == (b'1\\n2\\n\\n', 5)
    assert encode('\t') == (b'\\x09', 1)
    assert encode('\n') == (b'\\x0a', 1)
    assert encode('あ') == (b'\\xe3\\x81\\x82', 1)
    assert encode('あ\n') == (b'\\xe3\\x81\\x82\\n', 2)

# Generated at 2022-06-21 12:42:34.596221
# Unit test for function register
def test_register():
    import sys
    #
    # Create a test codec module
    #
    sys.modules[__name__ + '.test_register'] = None
    import test_register
    test_register.NAME = NAME
    test_register.codec = __import__(__name__)
    #
    # Register the codec
    #
    test_register.register()
    #
    # Save the codec info
    #
    codec_info = codecs.lookup(NAME)
    #
    # Check to see if the codec and test_register codec_info match
    #
    assert codec_info == test_register.codec_info, \
        "test_register failed"

    del sys.modules[__name__ + '.test_register']

# Generated at 2022-06-21 12:43:19.323819
# Unit test for function register
def test_register():
    from test import support
    import codecs
    from types import ModuleType

    # Check to see if eutf8h codec is already registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        # If registered, just return.
        return

    saved = support.import_fresh_module(NAME,
                                        fresh=['codecs'])
    from importlib import reload

    # Redo the registration.
    reload(NAME)

    # Check to see if eutf8h codec is registered.
    codecs.getdecoder(NAME)

    # Make sure the new codec was saved.
    module = support.import_fresh_module(NAME,
                                         fresh=['codecs'])
    assert saved is not module
    assert saved.__dict__ == module

# Generated at 2022-06-21 12:43:24.007028
# Unit test for function encode
def test_encode():
    assert b'a' == encode('a')[0]
    assert b'\\xC2\\xA2' == encode('¢')[0]
    assert b'\\xE2\\x82\\xAC' == encode('€')[0]
    assert b'\\xF0\\x9D\\x84\\x9E' == encode('𝄞')[0]
    assert b'\\xF1\\xA4\\xB4\\xB4' == encode('꒴')[0]
    assert b'\\xE2\\x82\\xAC\\xC2\\xA2\\xF0\\x9D\\x84\\x9E\\xF1\\xA4\\xB4\\xB4' == encode('€¢𝄞꒴')[0]

# Generated at 2022-06-21 12:43:25.189171
# Unit test for function encode
def test_encode():
    # TODO: Come up with unit tests
    pass



# Generated at 2022-06-21 12:43:29.984860
# Unit test for function encode
def test_encode():
    text_input = 'this is a test of escaped utf8 bytes \\xc3\\xa9'
    encoding = 'eutf8h'
    test_bytes, consumed = encode(text_input)
    test_string = test_bytes.decode(encoding)
    assert test_string == "this is a test of escaped utf8 bytes \\\\xc3\\\\xa9"
    assert consumed == len(text_input)


# Generated at 2022-06-21 12:43:36.263225
# Unit test for function decode
def test_decode():
    assert decode(b'\\x61\\x62', 'strict') == ('ab', 4)
    assert decode(b'\\x61\\x62', 'replace') == ('ab', 4)
    assert decode(b'\\x61\\x62', 'ignore') == ('', 4)
    assert decode(b'\\x61\\x62', 'surrogateescape') == ('ab', 4)
    assert decode(b'\\x61\\x62', 'surrogatepass') == ('ab', 4)


# Generated at 2022-06-21 12:43:39.006290
# Unit test for function decode
def test_decode():
    assert decode(b'\\xf0\\x9f\\x98\\x8b') == ('💋', 14)



# Generated at 2022-06-21 12:43:40.911980
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)


# Generated at 2022-06-21 12:43:47.810334
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""
    assert encode('foo') == (b'foo', 3)
    assert encode('foo\x80') == (b'foo\\x80', 5)
    assert encode('foo\xf0\x80\x80\x80') == (b'foo\\xf0\\x80\\x80\\x80', 15)
    assert encode('foo\xed\xa0\x80') == (b'foo\\xed\\xa0\\x80', 11)
    assert encode('foo\xed\xbf\xbf') == (b'foo\\xed\\xbf\\xbf', 11)
    assert encode('foo\xee\x80\x80') == (b'foo\\xee\\x80\\x80', 11)
    assert encode('foo\xef\xbf\xbf')

# Generated at 2022-06-21 12:43:57.265756
# Unit test for function decode
def test_decode():
    output = decode(b'\\x63\\x6f\\x64\\x65\\x63\\x73', errors='strict')
    assert output[0] == 'codecs'
    assert output[1] == 12

    output = decode(b'\\x63\\x6f\\x64\\x65\\x63\\x73', errors='ignore')
    assert output[0] == 'codes'
    assert output[1] == 6

    output = decode(b'\\x63\\x6f\\x64\\x65\\x63\\x73', errors='replace')
    assert output[0] == 'codecs'
    assert output[1] == 12

    output = decode(b'\\x63\\x6f\\x64\\x65\\x63\\x73', errors='surrogateescape')
    assert output

# Generated at 2022-06-21 12:44:03.106342
# Unit test for function encode
def test_encode():
    text = 'This is a test for the eutf8h codec.'
    text += '\u1F600'
    out_bytes, out_len = encode(text)
    text_bytes = text.encode('utf8')
    assert out_bytes == text_bytes
    assert out_len == len(text)



# Generated at 2022-06-21 12:44:39.502673
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)


# Generated at 2022-06-21 12:44:40.478493
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-21 12:44:41.312627
# Unit test for function decode
def test_decode():
    pass


# Generated at 2022-06-21 12:44:48.234876
# Unit test for function decode
def test_decode():
    from eutf8h_example import text_hex, text_hex_bytes, text_utf8
    assert decode(text_hex_bytes) == (text_utf8, len(text_hex_bytes))
    assert text_hex_bytes.decode('eutf8h') == text_utf8
    assert bytes(text_hex_bytes).decode('eutf8h') == text_utf8
    assert memoryview(text_hex_bytes).decode('eutf8h') == text_utf8
    assert bytearray(text_hex_bytes).decode('eutf8h') == text_utf8
