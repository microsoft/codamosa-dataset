

# Generated at 2022-06-21 12:34:57.670453
# Unit test for function decode
def test_decode(): # type: ignore
    """Ensure the :func:`decode` function works correctly."""
    # Test decoding ascii, without escaping
    out = decode(b'hello')
    assert out == ('hello', 5)

    # Test decoding ascii, with escaping
    out = decode(b'he\\x61\\x6co')
    assert out == ('hello', 9)

    # Test decoding non-ascii
    out = decode(b'hello \\xf0\\x9f\\x92\\xa9')
    assert out == ('hello 💩', 14)

    # Test decoding non-ascii, with escaping
    out = decode(b'hello \\x00 \\xf0\\x9f\\x92\\xa9')
    assert out == ('hello \x00 💩', 18)

    # Test decoding invalid utf

# Generated at 2022-06-21 12:35:07.521139
# Unit test for function encode
def test_encode():
    assert encode('hi') == (b'hi', 2)
    assert encode('é') == (b'\\xc3\\xa9', 1)
    assert encode('\U0001f9b0') == (
        b'\\xf0\\x9f\\xa6\\xb0',
        1
    )
    assert encode('\u005c') == (b'\\\\', 1)
    assert encode('\u005c\u005c') == (b'\\\\', 2)
    assert encode('\u005c\u005c\u005c') == (b'\\\\\\', 2)
    assert encode('\u005c\u005c\u005cx') == (b'\\\\\\\\x', 4)

# Generated at 2022-06-21 12:35:15.316489
# Unit test for function register
def test_register():
    import pytest

    def test_register_1():
        codecs.register(_get_codec_info)
        with pytest.raises(codecs.CodecRegistryError):
            codecs.register(_get_codec_info)
        codecs.unregister(_get_codec_info)

    def test_register_2():
        codecs.register(_get_codec_info)
        with pytest.raises(LookupError):
            codecs.getdecoder(NAME)
        codecs.unregister(_get_codec_info)

    def test_register_3():
        codecs.register(_get_codec_info)
        decode_func = codecs.getdecoder(NAME)
        assert decode_func is decode
        codecs.unregister(_get_codec_info)


# Generated at 2022-06-21 12:35:27.652843
# Unit test for function encode

# Generated at 2022-06-21 12:35:29.692613
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False



# Generated at 2022-06-21 12:35:35.667609
# Unit test for function decode
def test_decode():
    data = b'\\xe2\\x80\\x9d\\xe2\\x80\\x98\\xe2\\x80\\x99'
    str_out = decode(data)[0]
    assert str_out == '”‘’'

    data = b'\\xe2\\x80\\x9d\n\\xe2\\x80\\x98\\xe2\\x80\\x99'
    with pytest.raises(UnicodeDecodeError):
        str_out = decode(data, errors='strict')

    str_out = decode(data, errors='replace')[0]
    assert str_out == '”\n‘’'

    str_out = decode(data, errors='ignore')[0]
    assert str_out == '”‘’'


# Generated at 2022-06-21 12:35:38.761835
# Unit test for function register
def test_register():
    if '.'.join(__name__.split('.')[-2:]) == '__main__':
        register()


# Generated at 2022-06-21 12:35:49.996868
# Unit test for function encode
def test_encode():
    # Test for encode.
    input_str = '\x68\x65\x6c\x6c\x6f\x20\x77\x6f\x72\x6c\x64\x20' \
                '\xe0\xa4\xb5\xe0\xa5\x80'
    input_bytes = input_str.encode('utf-8')
    expected_output_bytes = \
        b'\\x68\\x65\\x6c\\x6c\\x6f\\x20\\x77\\x6f\\x72\\x6c\\x64\\x20' \
        b'\\xe0\\xa4\\xb5\\xe0\\xa5\\x80'

    result = encode(input_str)
    assert result == (expected_output_bytes, 12)



# Generated at 2022-06-21 12:36:01.900529
# Unit test for function encode
def test_encode():
    text = 'hello world'
    text_bytes, length_consumed = encode(text)
    assert text_bytes == b'hello world'
    assert length_consumed == 11

    text = 'hello \x7fworld'
    text_bytes, length_consumed = encode(text)
    assert text_bytes == b'hello \\x7fworld'
    assert length_consumed == 12

    text = 'hello \\x7fworld'
    text_bytes, length_consumed = encode(text)
    assert text_bytes == b'hello \\x5cx7fworld'
    assert length_consumed == 13

    text = 'hello \\x7f\x7fworld'
    text_bytes, length_consumed = encode(text)

# Generated at 2022-06-21 12:36:13.485256
# Unit test for function decode
def test_decode():
    from io import BytesIO
    from io import StringIO
    # Test for empty file
    data = BytesIO(b'')
    exp_result = '', 0
    assert decode(data.read()) == exp_result
    # Test for single character
    data = BytesIO(b'c')
    exp_result = 'c', 1
    assert decode(data.read()) == exp_result
    # Test for single byte escaped hexadecimal
    data = BytesIO(b'\\x65')
    # exp_result = '\x65', 1
    exp_result = 'e', 1
    assert decode(data.read()) == exp_result
    # Test for single byte escaped hexadecimal
    data = BytesIO(b'\\x65')
    exp_result = '\x65', 1

# Generated at 2022-06-21 12:36:19.375105
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None

if __name__ == '__main__':
    # Unit test for each function
    test_register()

# Generated at 2022-06-21 12:36:29.141164
# Unit test for function encode

# Generated at 2022-06-21 12:36:42.054077
# Unit test for function encode
def test_encode():
    unit_tests = {
        'Hello world': b'Hello world',
        'Hello world\n': b'Hello world\\x0A',
        r'Hello world\n': b'Hello world\\x0A',
        r'Hello world\\n': b'Hello world\\x5Cn',
        r'Hello world\\': b'Hello world\\x5C',
        '浣犲ソ': b'\\xE6\\xB5\\xA3\\xE7\\x8A\\xB2\\xE3\\x82\\xBD',
        '浣犲ソ\n': b'\\xE6\\xB5\\xA3\\xE7\\x8A\\xB2\\xE3\\x82\\xBD\\x0A',
    }


# Generated at 2022-06-21 12:36:48.880929
# Unit test for function decode
def test_decode():
    output = "this is a test"
    input_bytes = "this\\x20is\\x20a\\x20test"
    #input_bytes = r"this\x20is\x20a\x20test"
    output_bytes, len_bytes = decode(input_bytes.encode('unicode_escape'))
    print(output_bytes)
    print(len_bytes)
    assert(output_bytes == output)


# Generated at 2022-06-21 12:36:59.343066
# Unit test for function encode
def test_encode():
    assert encode('abc') == (b'abc', 3)
    assert encode('abc\u00FF') == (b'abc\\xFF', 7)
    assert encode('abc\u00FF', 'ignore') == (b'abc', 7)
    assert encode('abc\u00FF', 'replace') == (b'abc\\uFFFD', 7)
    assert encode('\u00FF', 'xmlcharrefreplace') == (b'&#255;', 3)
    assert encode('abc\u00FF', 'xmlcharrefreplace') == (b'abc&#255;', 7)
    assert encode('abc\u00FF', 'eutf8h') == (b'abc\\xFF', 7)



# Generated at 2022-06-21 12:37:10.963470
# Unit test for function decode

# Generated at 2022-06-21 12:37:13.810812
# Unit test for function register
def test_register():
    """Test that when this function runs, the codec is available."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:37:24.423460
# Unit test for function decode
def test_decode():

    assert decode(b'\\xe6\\x97\\xa5\\xe6\\x9c\\xac\\xe8\\xaa\\x9e') \
        == ('日本語', 24)
    assert decode(b'\\xe6\\x97\\xa5\\xe6\\x9c\\xac\\xe8\\xaa\\x9e\\xf0\\x9f\\x8c\\x80\\xe0\\xaf\\x80\\xe3\\x80\\x80') == ('日本語👀︀　', 32)

# Generated at 2022-06-21 12:37:35.097525
# Unit test for function encode
def test_encode():
    assert encode('\\u0040') == (b'@', 6)
    assert encode('\\x40') == (b'@', 4)
    assert encode('\\120') == (b'@', 4)
    assert encode('\\t') == (b'\t', 2)
    assert encode('\\n') == (b'\n', 2)
    assert encode('\\r') == (b'\r', 2)
    assert encode('\\b') == (b'\b', 2)
    assert encode('\\f') == (b'\f', 2)
    assert encode('\\v') == (b'\x0b', 2)
    assert encode('\\0') == (b'\x00', 2)
    assert encode('\\00') == (b'\x00', 3)

# Generated at 2022-06-21 12:37:46.364667
# Unit test for function decode
def test_decode():
    from . import eutf8h  # type: ignore
    # Valid utf8H
    data = '"\\u0024\\u20AC\\u00A2\\U0001F4B0"'
    safe = eutf8h.decode(data)[0]
    assert safe == '"$€¢💰"'

    # Valid, but decodes to undefined utf8H
    data = b'"\\uD800\\u9999\\uD800\\u0024\\uD800\\u0099"'
    safe = eutf8h.decode(data)[0]
    assert safe == '"\\ud800\\u9999\\ud800$\\ud800™"'

    # Invalid utf8H

# Generated at 2022-06-21 12:38:01.766364
# Unit test for function decode
def test_decode():
    assert decode(b'a') == ('a', 1)
    assert decode(b'abc', 'strict') == ('abc', 3)
    assert decode(b'ab') == ('ab', 2)
    assert decode(b'\xe2\x82\xac') == ('€', 3)
    assert decode(b'\xe2\x82\xac') == ('€', 3)
    assert decode(b'\xe2\x82\xac', 'strict') == ('€', 3)
    assert decode(b'\xc3\xa4', 'strict') == ('ä', 2)
    assert decode(b'\xe2\x82\xac', 'replace') == ('€', 3)
    assert decode(b'\xe2\x82\xac', 'ignore') == ('', 3)

# Generated at 2022-06-21 12:38:03.947095
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore

# Generated at 2022-06-21 12:38:15.424708
# Unit test for function decode
def test_decode():
    # Test 1
    s = u'\\u0030'
    expected = u'0'
    result = codecs.decode(s, NAME, 'strict')
    assert result[0] == expected

    # Test 2
    s = u'\\x19'
    expected = u'\x19'
    result = codecs.decode(s, NAME, 'strict')
    assert result[0] == expected

    # Test 3
    # s = u'\\xff'
    s = u'\\xff'
    expected = u'\xff'
    result = codecs.decode(s, NAME, 'strict')
    assert result[0] == expected

    # Test 4
    s = u'\\u00ff'
    expected = u'\xff'

# Generated at 2022-06-21 12:38:17.251165
# Unit test for function register
def test_register():
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-21 12:38:26.951761
# Unit test for function encode
def test_encode():
    # type: () -> None
    """Tests the encode function."""
    from encoding_utils import _each_utf8_hex, _reduce_utf8_hex

    # Testing to see if encode returns bytes

    def _each_utf8_hex(text: str) -> Generator[str, None, None]:
        for char in text:
            if ord(char) < 128 and char.isprintable():
                yield char
                continue
            utf8_bytes = char.encode('utf8')
            for utf8_byte in utf8_bytes:
                str_hex = '\\%s' % hex(utf8_byte)[1:]
                yield str_hex


# Generated at 2022-06-21 12:38:34.220664
# Unit test for function decode
def test_decode():
    """
    >>> test_decode()
    'Hello World'
    """
    # noinspection SpellCheckingInspection
    t = b"\\x48\\x65\\x6c\\x6c\\x6f\\x20\\x57\\x6f\\x72\\x6c\\x64" \
        b"\\u202c\\x48\\x65\\x6c\\x6c\\x6f\\x20\\x57\\x6f\\x72\\x6c\\x64"
    assert decode(t)[0] == 'Hello World\u202cHello World'



# Generated at 2022-06-21 12:38:35.814952
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)  # type: ignore

# Generated at 2022-06-21 12:38:46.287425
# Unit test for function encode
def test_encode():
    # Checking if the encoding for a string containing only ASCII characters
    # is done correctly.
    result = encode('abcdefghijlmnop', 'strict')
    assert result[0] == b'abcdefghijlmnop'
    assert result[1] == 16

    # Checking if the encoding for a string containing more than ASCII
    # characters is done correctly.
    result = encode('abcdéééééééfghijlmnop', 'strict')
    assert result[0] == b'abcd\\xc3\\xa9\\xc3\\xa9\\xc3\\xa9\\xc3\\xa9' \
                        b'\\xc3\\xa9\\xc3\\xa9\\xc3\\xa9fghijlmnop'
    assert result[1] == 21

    # Checking if the encoding for a string

# Generated at 2022-06-21 12:38:56.547156
# Unit test for function encode
def test_encode():
    s = '\U0001f64c'
    assert encode(s) == (b'\\xf0\\x9f\\x99\\x8c', 1)
    assert encode(s, 'ignore') == (b'', 1)
    assert encode(s, 'replace') == (b'\\ufffd', 1)

    s = '\six\steam'
    assert encode(s) == (b'\\six\\steam', 7)

    s = 'six\steam'
    assert encode(s) == (b'six\\steam', 6)

    s = 'six\steam'
    assert encode(s, 'ignore') == (b'six\\steam', 7)

    s = 'six\steam'
    assert encode(s, 'replace') == (b'six\\steam', 7)

    s = 'six\steam'
   

# Generated at 2022-06-21 12:38:58.467133
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore
    codecs.getdecoder(NAME)


# Generated at 2022-06-21 12:39:12.053803
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)


# Generated at 2022-06-21 12:39:19.945631
# Unit test for function decode
def test_decode():
    assert decode(b'foo') == ('foo', 3)
    assert decode(b'foo\\x2c') == ('foo,', 6)
    assert decode(b'foo\\x2c\\x66') == ('foo,f', 9)
    assert decode(b'foo\\x2c\\x2c') == ('foo,', 6)
    assert decode(b'foo\\x2c\\x2c\\x66') == ('foo,f', 9)
    assert decode(b'foo\\x2cbar') == ('foo,bar', 9)
    assert decode(b'foo\\x2cbar\\x2c') == ('foo,', 6)
    assert decode(b'foo\\x2cbar\\x2c\\x66') == ('foo,f', 9)

# Generated at 2022-06-21 12:39:31.280085
# Unit test for function encode
def test_encode():
    assert encode('\x01\x7f') == (b'\\x01\\x7f', 2)
    assert encode('\x80\xFF') == \
        (b'\\xc2\\x80\\xc3\\xbf'.upper(), 2)
    assert encode('\u0100\u07FF') == \
        (b'\\xc4\\x80\\xdf\\xbf'.upper(), 2)
    assert encode('\u0800\uFFFF') == \
        (b'\\xe0\\xa0\\x80\\xef\\xbf\\xbf'.upper(), 2)
    assert encode('\U00010000') == \
        (b'\\xf0\\x90\\x80\\x80'.upper(), 1)

# Generated at 2022-06-21 12:39:40.206749
# Unit test for function encode
def test_encode():
    s = "ciao"
    assert encode(s) == (b'ciao', 4)
    assert encode(s, "ignore") == (b'ciao', 4)
    assert encode(s, "replace") == (b'ciao', 4)
    assert encode(s, "surrogateescape") == (b'ciao', 4)
    assert encode(s, "xmlcharrefreplace") == (b'ciao', 4)
    s = "\u00e8"

    assert encode(s) == (b'\xc3\xa8', 2)
    assert encode(s, "replace") == (b'\xc3\xa8', 2)
    assert encode(s, "surrogateescape") == (b'\xc3\xa8', 2)

# Generated at 2022-06-21 12:39:42.293288
# Unit test for function encode
def test_encode():
    assert encode('\\x20') == b'\\\\x20'
    assert encode('hi') == b'hi'
    assert encode('\\u2318') == b'\\\\u2318'


# Generated at 2022-06-21 12:39:47.758533
# Unit test for function decode
def test_decode():
    binary_input_1 = b'Hello'
    binary_input_2 = b'\\x48\\x65\\x6c\\x6c\\x6f'
    expected_output = 'Hello'

    output_1, _ = decode(binary_input_1)
    output_2, _ = decode(binary_input_2)

    assert (output_1 == expected_output)
    assert (output_2 == expected_output)


# Generated at 2022-06-21 12:39:50.879166
# Unit test for function decode
def test_decode():
    data = b'\\xe2\\x80\\xaf'
    expected = '\u200b'
    actual = decode(data)
    assert expected == actual



# Generated at 2022-06-21 12:40:00.404733
# Unit test for function decode
def test_decode():
    """Test the function decode with a list of test cases"""

# Generated at 2022-06-21 12:40:08.483861
# Unit test for function encode
def test_encode():
    # noinspection PyUnusedLocal
    test_data = [
        ('', b'', 0),
        ('', b'a', 2),
        ('abc', b'abc', 0),
        ('abc', b'abc', 0),
        ('abc', b'abc', 3),
        ('abc', b'abc', 6),
        ('[a]\x6d', b'[a]\\x6d', 4),
        ('[a]', b'[a]\\x6d', 3),
        ('', b'\\x80', 3),
        ('[a]\x80', b'[a]\\x80', 5),
    ]
    for text, data, consumed in test_data:
        _bytes, _consumed = encode(text)

# Generated at 2022-06-21 12:40:15.338250
# Unit test for function encode
def test_encode():
    assert encode(r'\x41\x21') == b'\\x41\\x21'
    assert encode(r'A\x41') == b'A\\x41'
    assert encode(r'A\x41\x21') == b'A\\x41\\x21'
    assert encode(r'A\x41\x00') == b'A\\x41\\x00'
    assert encode(r'\x0f\xff') == b'\\x0f\\xff'


# Generated at 2022-06-21 12:40:41.872424
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME) is not None

# Generated at 2022-06-21 12:40:43.205760
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:40:49.095256
# Unit test for function register
def test_register():
    from cmc import codecs

    # Register the codec with the codec registry.
    register()
    name = 'eutf8h'

    # Get the codec from the registry.
    try:
        get_codec = codecs.getdecoder(name)
    except LookupError:
        get_codec = None

    assert get_codec is not None


# Unit test function decode

# Generated at 2022-06-21 12:40:57.703350
# Unit test for function decode
def test_decode():
    assert decode('\\x6b\\x6f\\x6d\\x6f\\x64\\x2e\\x6d\\x65') == ('komod.me', 16)

    assert decode('\\x6b\\x6f\\x6d\\x6f\\x64\\x2e\\x6d\\x65\\x20\\xe2\\x9c\\x93') == ('komod.me ✔', 20)

    assert decode('\\x6b\\x6f\\x6d\\x6f\\x64\\x2e\\x6d\\x65\\x20\\xe2\\x9c\\x93\\x5e\\x5b\\x5d\\x7b\\x7d\\x7c') == ('komod.me ✔^[]{}|', 26)


# Generated at 2022-06-21 12:41:09.928408
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode('abc def') == (b'abc def', 7)
    assert encode('\u1234') == (b'\\u1234', 1)
    assert encode('\u1234', errors='strict') == (b'\\u1234', 1)
    assert encode('\u1234', errors='replace') == (b'\\uFFFD', 1)
    assert encode('\u1234', errors='ignore') == (b'', 1)

    try:
        encode('\u1234', errors='foo')
    except ValueError as e:
        assert str(e) == 'unknown error handling code: foo'
    else:
        assert False, 'ValueError exception expected'


# Generated at 2022-06-21 12:41:13.269524
# Unit test for function decode
def test_decode():
    input = [b'abc', b'abc\x01']
    try:
        decode(input[0])
        assert True
    except UnicodeDecodeError:
        assert False
    try:
        decode(input[1])
        assert False
    except UnicodeDecodeError:
        assert True


# Generated at 2022-06-21 12:41:24.429183
# Unit test for function decode

# Generated at 2022-06-21 12:41:31.143955
# Unit test for function register
def test_register():
    # Ensure the codec is not available yet.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(
            'codecs.getdecoder(%s) must fail' % NAME
        )

    # Register the codec
    register()

    # Ensure the codec is now available.
    codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:41:39.234494
# Unit test for function decode
def test_decode():
    import string
    import binascii
    src = bytes('helloworld', 'utf8')
    # print(src)
    result = codecs.encode(src, 'hex')
    # print(result)
    src2 = codecs.decode(result, 'hex')
    # print(src2)
    assert src==src2

    # src3 = codecs.decode(src, 'hex')
    src3 = codecs.decode(src, 'eutf8h')

    print(binascii.hexlify(src))
    # print(src3)
    # print(str(src3, 'utf8'))
    # print(codecs.encode(binascii.hexlify(src), 'hex'))
    # print(codecs.encode(binas

# Generated at 2022-06-21 12:41:47.349967
# Unit test for function encode
def test_encode():
    assert encode('This is a utf-8 string.') == (
        b'This is a utf-8 string.',
        23,
    )
    assert encode(r'This is a utf-8 string \x7f') == (
        b'This is a utf-8 string \\x7f',
        26,
    )
    assert encode('\u2588\u2588') == (b'\\xe2\\x96\\x88\\xe2\\x96\\x88', 1)
    assert encode(r'\XE2\X96\X88') == (b'\\xe2\\x96\\x88', 1)
    assert encode(r'\Xe2\X96\X88') == (b'\\xe2\\x96\\x88', 1)

# Generated at 2022-06-21 12:42:19.534125
# Unit test for function decode
def test_decode():
    data = b'''
    this is a test
    \\xE4\xBD\\xA0\\xE5\\xA5\\xBD = ni hao\\x3F
    \\xF0\\x9F\\x90\\x91 = flies

    \\xEE\\x80\\x80 = intern unicode \\u{ef4080}
    \\xef\\x40\\x80 = external unicode \\u{ef4080}
    '''
    codecs.register(_get_codec_info)
    text, consumed = codecs.decode(data, NAME)
    assert consumed == len(data)
    lines = text.splitlines()
    assert lines[0] == 'this is a test'
    assert lines[1] == '你好 = ni hao?'

# Generated at 2022-06-21 12:42:24.552791
# Unit test for function decode
def test_decode():
    print('\n')
    print('Testing decode')
    text_input = 'abc\x82\x88\xEB\x84'
    out, length = decode(text_input)
    print('text_input: %s' % str(text_input))
    print('out: %s' % out)
    print('length: %s' % str(length))
    return



# Generated at 2022-06-21 12:42:26.297743
# Unit test for function register
def test_register():
    assert not codecs.lookup(NAME)
    register()
    assert codecs.lookup(NAME)


# Generated at 2022-06-21 12:42:36.334294
# Unit test for function decode
def test_decode():
    err = 'strict'
    in_bytes = b'\\xd0\\x84\\xd0\\x8f\\xd0\\x89\\xd0\\x8a\\xd0\\x8d\\xd0\\x8e'

    if sys.version_info[0] == 2:
        out = u'\u0424\u044f\u0449\u044a\u044d\u044e'
    else:
        out = '\u0424\u044f\u0449\u044a\u044d\u044e'

    inout = decode(in_bytes, err)

    assert inout[0] == out
    assert inout[1] == len(in_bytes)


# Generated at 2022-06-21 12:42:44.716102
# Unit test for function encode

# Generated at 2022-06-21 12:42:53.053000
# Unit test for function encode
def test_encode():
    assert encode('\x00') == (b'\\x00', 1)
    assert encode('\x00\x00') == (b'\\x00\\x00', 2)
    assert encode('\u20ac') == (b'\\xe2\\x82\\xac', 1)
    assert encode('\u20ac\u20ac') == (b'\\xe2\\x82\\xac\\xe2\\x82\\xac', 2)
    assert encode('\u20ac', 'replace') == (b'?', 1)


# Generated at 2022-06-21 12:42:55.232449
# Unit test for function decode
def test_decode():
    assert decode(b'\\x41\\x74') == ('At', 6)


if __name__ == '__main__':
    test_decode()

# Generated at 2022-06-21 12:42:58.428184
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        assert False
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-21 12:43:01.466333
# Unit test for function register
def test_register():
    from unittest import TestCase

    class UnitReg(TestCase):
        def test_register(self):
            register()
            #Ensure the register function does not throw an exception
            self.assertTrue(True)


# Generated at 2022-06-21 12:43:09.563617
# Unit test for function encode
def test_encode():
    assert encode('C') == (b'C', 1)
    assert encode('\u2665') == (b'\\xe2\\x99\\xa5', 1)
    assert encode('\u2665') == (b'\\xe2\\x99\\xa5', 1)
    assert encode('\U0001F60A') == (b'\\xf0\\x9f\\x98\\x8a', 1)
    assert encode('\U0001F60A') == (b'\\xf0\\x9f\\x98\\x8a', 1)
    assert encode('\U0001F60A') == (b'\\xf0\\x9f\\x98\\x8a', 1)
    assert encode('\U0001F60A') == (b'\\xf0\\x9f\\x98\\x8a', 1)


# Generated at 2022-06-21 12:44:07.074048
# Unit test for function decode
def test_decode():
    print("\n\nTesting decode")
    text = 'This is an example message'
    print("Original: " + text)
    text_as_bytes = text.encode()
    text_as_eutf8h = decode(text_as_bytes)[0]
    print("Encode: " + text_as_eutf8h)
    text_from_eutf8h = decode(text_as_eutf8h.encode())[0]
    print("Decode: " + text_from_eutf8h)
    success = (text == text_from_eutf8h)
    print("Success: " + str(success))
    if not success:
        text_as_bytes = text.encode('utf_8', errors='strict')
        print(text_as_bytes)
        text_

# Generated at 2022-06-21 12:44:09.471830
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)
    # codecs.register(_get_codec_info)



# Generated at 2022-06-21 12:44:11.396727
# Unit test for function encode

# Generated at 2022-06-21 12:44:17.690883
# Unit test for function register
def test_register():
    register()
    (bytes, length) = codecs.getencoder(NAME)('1234')
    assert bytes == b'\\x31\\x32\\x33\\x34' and length == 4
    (text, length) = codecs.getdecoder(NAME)(bytes)
    assert text == '1234' and length == 4


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:44:27.814803
# Unit test for function decode
def test_decode():
    # Test '\\x74'
    assert decode(b'\\x74') == ('t', 0)

    # Test '\\xe2\\x99\\xa8'
    assert decode(b'\\x74\\x74\\x74\\x74') == ('tttt', 0)

    # Test '\\x74', args(errors)
    assert decode(b'\\x74', 'strict') == ('t', 0)

    # Test '\\x74', args(errors)
    assert decode(b'\\x74', 'ignore') == ('', 0)

    # Test '\\x74', args(errors)
    assert decode(b'\\x74', 'replace') == ('\uFFFD', 0)

    # Test '\\x74', args(errors)

# Generated at 2022-06-21 12:44:38.905557
# Unit test for function encode
def test_encode():
    """Unit test for function encode()."""
    assert encode('Hello "Richard"\n', 'strict') == (
        b'Hello \\"Richard\\"\\n',
        17
    )
    assert encode('Hello "Richard"\n', 'replace') == (
        b'Hello \\"Richard\\"\\n',
        17
    )
    assert encode('Hello "Richard"\n', 'ignore') == (
        b'Hello \\"Richard\\"\\n',
        17
    )
    assert encode('Hello "Richard"\n', 'backslashreplace') == (
        b'Hello \\\\"Richard\\\\"\\n',
        17
    )
    assert encode('Hello "Richard"\n', 'xmlcharrefreplace') == (
        b'Hello \\"Richard\\"\\n',
        17
    )


# Generated at 2022-06-21 12:44:46.281469
# Unit test for function decode
def test_decode():

    # byte_str_utf8 = bytes('\\x66\\x6F\\x6F\\xC2\\xA2\\xF0\\x9F\\x92\\xA9'.encode('utf-8'))
    byte_str_utf8 = bytes('\\x66\\x6F\\x6F\\xC2\\xA2\\xF0\\x9F\\x92\\xA9'.encode('unicode_escape'))

    decoded_str, _ = decode(byte_str_utf8)

    assert decoded_str == 'foo¢💩'

