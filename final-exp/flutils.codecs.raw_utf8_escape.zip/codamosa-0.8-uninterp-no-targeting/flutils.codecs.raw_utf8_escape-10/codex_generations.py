

# Generated at 2022-06-21 12:34:49.908223
# Unit test for function decode

# Generated at 2022-06-21 12:34:52.575183
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)
    assert codecs.lookup_error('eutf8h')

# Generated at 2022-06-21 12:34:54.119943
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)


# Generated at 2022-06-21 12:34:57.474132
# Unit test for function register
def test_register():
    """
    Unit tests for function register
    """
    register()

    codec = codecs.getdecoder(NAME)

    assert codec is not None



# Generated at 2022-06-21 12:35:01.438140
# Unit test for function register
def test_register():

    register()

    codecs.lookup_error('strict')
    codecs.lookup_error('ignore')
    codecs.lookup_error('replace')

    codecs.lookup('eutf8h')
    codecs.lookup('eutf8h')



# Generated at 2022-06-21 12:35:07.849433
# Unit test for function decode

# Generated at 2022-06-21 12:35:08.812218
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-21 12:35:10.147343
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None

# Generated at 2022-06-21 12:35:12.758423
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getdecoder(NAME)
    # codecs.getencoder(NAME)  # todo: throws because of incorrect implementation
    register()  # idempotency test

# Generated at 2022-06-21 12:35:25.768521
# Unit test for function encode
def test_encode():
    #
    # A call to encode() with a simple string that is all printable
    # characters should return the same string back and should not
    # include any escaped hexadecimal sequences.
    #
    assert encode('abcdABCD1234!@#$') == (b'abcdABCD1234!@#$', 14)
    #
    # A call to encode() with a string that contains a single
    # non-printable character, '\t', should return the string with
    # the non-printable characters converted into escaped hexadecimal
    # sequence.
    #
    assert encode('ab\tcd\t') == (b'ab\\x09cd\\x09', 8)
    #
    # A call to encode() with a string that contains multiple
    # non-printable characters, '\t', should return the string

# Generated at 2022-06-21 12:35:46.330084
# Unit test for function decode
def test_decode():
    assert decode(b'hello') == ('hello', 5)
    assert decode(b'\xF0\x9F\x98\x83') == ('😃', 4)
    assert decode(b'\xE2\x9A\x97') == ('⚗', 3)

    assert decode(b'\\xF0\\x9F\\x98\\x83') == ('😃', 18)
    assert decode(b'\\xE2\\x9A\\x97') == ('⚗', 12)

    assert decode(b'\\xBB') == ('»', 6)

    assert decode(br'\u001D') == ('\x1D', 6)

    assert decode(b'\\u001D') == ('\x1D', 6)

    assert decode(b'\\x20', 'replace')

# Generated at 2022-06-21 12:35:52.627235
# Unit test for function decode
def test_decode():
    for data in (b'', b'a', b'aa', b'\x81'):
        assert NAME == data.decode(NAME)[1:]
        assert NAME == data.decode(NAME, 'strict')[1:]
        assert NAME == data.decode(NAME, 'ignore')[1:]
        assert NAME == data.decode(NAME, 'replace')[1:]



# Generated at 2022-06-21 12:35:58.825347
# Unit test for function register
def test_register():
    register()
    r = codecs.encode('foo', NAME)
    assert r == b'\\102\\111\\111'
    r = codecs.encode(r, NAME)
    assert r == b'\\102\\111\\111'
    assert codecs.encode(r) == b'foo'


# Generated at 2022-06-21 12:36:05.952445
# Unit test for function register
def test_register():
    register()

    codec_info = codecs.getdecoder(NAME)  # type: ignore
    test_str = 'This is a test string with some \\U0001F600 and some bad ' \
               'bytes \\xDE\\xAD\\xBE\\xEF.'
    enc_out: bytes = encode(test_str)[0]
    dec_out: str = decode(enc_out)[0]
    assert test_str == dec_out, 'Encoding and decoding failed.'
    codec_info = codecs.getdecoder(NAME)  # type: ignore[attr-defined]
    dec_out: str = codec_info.decode(enc_out)[0]
    assert test_str == dec_out, 'Encoding and decoding failed.'
    codec_info = codecs.getencoder(NAME)  # type: ignore[

# Generated at 2022-06-21 12:36:16.206003
# Unit test for function decode
def test_decode():
    """Unit test for function decode."""
    msg_bytes = b'M\x00e\x00s\x00s\x00a\x00g\x00e\x00'
    exp_str = 'Message'
    test_str, c_consumed = decode(msg_bytes)
    assert test_str == exp_str

    msg_bytes = b'M\x00e\\x00s\x00s\x00a\x00g\x00e\\x00'
    exp_str = 'Me\\x00sage\\x00'
    test_str, c_consumed = decode(msg_bytes)
    assert test_str == exp_str


# Generated at 2022-06-21 12:36:27.020168
# Unit test for function decode
def test_decode():
    print(decode(b'\\xce\\xa9'))
    # print(decode(b'\\xff'))
    print(decode(b'\\xce\\xa9\\xe1\\xbd\\xb9\\xcf\\x83\\xce\\xbc\\xce\\xb5'))
    # print(decode(b'\\xe1\\xbd\\xb9\\xcf\\x83\\xce\\xbc\\xce\\xb5'))
    # print(decode(b'\\xe1\\xbd\\xb9\\xcf\\x83'))
    # print(decode(b'\\xe1\\xbd\\xb9'))
    # print(decode(b'\\xce\\xa9\\xe1\\xbd\\xb9\\xcf\\x83\\xce\\xbc\\

# Generated at 2022-06-21 12:36:30.697150
# Unit test for function decode
def test_decode():
    assert decode(b'\\xe6\\x97\\xa5\\xe6\\x9c\\xac\\xe8\\xaa\\x9e') == ('日本語', 18)

# Generated at 2022-06-21 12:36:43.510056
# Unit test for function decode
def test_decode():
    """
    Quick and dirty unit test function.
    """
    str_input = r'\xfc\x84\x84\x84\x84\x84\x84'
    str_input = codecs.decode(str_input, "unicode_escape")
    str_input = b'\\xfc\\xcc\\xcc\\xcc\\xcc\\xcc\\xcc'
    str_input = codecs.decode(str_input, "unicode_escape")
    str_input = "\\xfc\\xcc\\xcc\\xcc\\xcc\\xcc\\xcc"
    str_bytes = str_input.encode("utf-8")
    str_input = str_bytes.decode()
    str_bytes = codecs.encode(str_input, "unicode_escape")

# Generated at 2022-06-21 12:36:52.052219
# Unit test for function register
def test_register():
    with ut.tmpfile() as fname:
        with open(fname, 'wb') as fout:
            fout.write(b'abc\x00\x12\x00\x00\x03')
        with open(fname, 'rb') as fin:
            text = fin.read().decode('eutf8h')
        assert text == 'abc\\\\0\\x12\\\\x00\\\\x00\\\\x03'



# Generated at 2022-06-21 12:37:02.317707
# Unit test for function decode
def test_decode():

    def _test_decode(
            data: _ByteString,
            expected: str,
            errors: _Str = 'strict'
    ) -> None:
        """Test :function:`decode`

        Args:
            data (bytes or bytearray or memoryview): The escaped utf8
                hexadecimal bytes.
            expected (str): The expected string.
            errors (str or :obj:`~UserString`): The error checking level.

        Raises:
            AssertionError: if the string returned is not the expected.
        """
        out, length = decode(data, errors=errors)
        assert out == expected, f'decode returned {out} not {expected}'

    # >>> '''\x22\x22\x22\x22\x22\x22\x22\x

# Generated at 2022-06-21 12:37:25.284983
# Unit test for function encode
def test_encode():
    # Test with no escape sequences
    text = 'Hello World!'
    text_utf8_bytes = text.encode('utf8')
    actual_bytes = encode(text)[0]
    assert text_utf8_bytes == actual_bytes

    # Test with escape sequences
    text = 'Hello\tWorld!\n'
    text_utf8_bytes = text.encode('utf8')
    actual_bytes = encode(text)[0]
    assert text_utf8_bytes == actual_bytes

    # Test with utf8 characters
    text = 'Hello\tWorld!\n\u00a3\u20ac\u20b9'
    text_utf8_bytes = text.encode('utf8')
    actual_bytes = encode(text)[0]
    assert text_utf8_bytes == actual_bytes

   

# Generated at 2022-06-21 12:37:30.024729
# Unit test for function decode
def test_decode():  # type: ignore
    assert decode(b'\\x41') == ('A', 4)
    assert decode(b'\\x63\\xF3\\xA0\\x80\\xE2\\xBF\\xB8') == ('c\xf3\\U00020000\\U0010FFFF', 26)


# Generated at 2022-06-21 12:37:31.178973
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-21 12:37:32.748172
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:37:40.332593
# Unit test for function register
def test_register():
    # Get the current codec search function, then replace it with
    # a function that always returns the name.
    test_getdecoder: Optional[
        Callable[[str], codecs.CodecInfo]
    ]
    try:
        test_getdecoder = codecs.getdecoder
    except LookupError:
        test_getdecoder = None
    codecs.getdecoder = lambda x: _get_codec_info(x)

    # Register the eutf8h codec
    register()

    # Check the codecs.getdecoder
    try:
        codecs.lookup(NAME)
    except LookupError:
        raise AssertionError(
            'expected to find codec %s' % NAME
        )

    # Restore the original codec search function.
    if test_getdecoder:
        codecs

# Generated at 2022-06-21 12:37:44.939692
# Unit test for function encode
def test_encode():
    # Test a string with printable characters
    test_str = 'This is a test'
    result: bytes
    expected = b'This is a test'
    result, length = encode(test_str)  # type: ignore[call-arg]
    assert result == expected

    # Test a string with printable characters and a hexadecimal character
    test_str = 'This is a \\xfa test'
    result: bytes
    expected = b'This is a \\xfa test'
    result, length = encode(test_str)  # type: ignore[call-arg]
    assert result == expected

    # Test a string with printable characters and a hexadecimal sequence
    test_str = 'This is a \\xFF test'
    result: bytes
    expected = b'This is a \\xFF test'
    result,

# Generated at 2022-06-21 12:37:57.727510
# Unit test for function encode
def test_encode():

    # Invalid utf8 bytes (\\xff)
    out, count = encode('🐕\\xff', 'strict')
    assert count == len('🐕\\xff')
    assert out == b'\\xf0\\x9f\\x90\\x95\\xff'

    # Invalid utf8 bytes (\\xff)
    try:
        out, count = encode('🐕\\xff', 'ignore')
        assert False
    except UnicodeEncodeError as e:
        assert count == len('🐕\\xff')
        assert out == b''
        assert e.encoding == 'eutf8h'
        assert e.object == '🐕\\xff'
        assert e.start == len('🐕')
        assert e.end == len('🐕') + 1

# Generated at 2022-06-21 12:38:09.895414
# Unit test for function encode
def test_encode():
    assert encode('a') == (b'a', 1)
    assert encode('\\x5c') == (b'\\\\x5c', 4)
    assert encode('\\x5c\\x5c') == (b'\\\\x5c\\\\x5c', 8)
    assert encode('\\x5c\\x5c\\x5c') == (b'\\\\x5c\\\\x5c\\\\x5c', 12)
    assert encode('\\x5c\\x5c\\x5c\\x5c') == (b'\\\\x5c\\\\x5c\\\\x5c\\\\x5c', 16)
    assert encode('\\x5c\\x5c\\x5c\\x5c\\x5c') == (b'\\\\x5c\\\\x5c\\\\x5c\\\\x5c\\\\x5c', 20)

# Generated at 2022-06-21 12:38:18.649361
# Unit test for function encode
def test_encode():
    """A unit test for testing the "encode" function.

    """
    # Unit test #0: ensure that an empty string encodes to an empty string
    assert ''.encode('eutf8h') == b''

    # Unit test #1: ensure that we can encode a normal ascii string
    assert 'hello'.encode('eutf8h') == b'hello'

    # Unit test #2: ensure that we can encode a ascii string with \xHH escape
    assert 'hello\\x20'.encode('eutf8h') == b'hello '

    # Unit test #3: ensure that we can encode a ascii string with \xHH
    #               escape that reference non-ascii bytes
    assert '\\xF1'.encode('eutf8h') == b'\xc3\xb1'

   

# Generated at 2022-06-21 12:38:27.684833
# Unit test for function register
def test_register():
    register()
    assert codecs.getaliases().get(NAME) == 'eutf8h'
    assert decode(b'\\x61')[0] == 'a'
    assert decode(b'\\x3c') == ('<', 3)
    assert decode(b'a\\x3c') == ('a<', 4)
    assert decode(b'\\x61\\x61\\x61\\x61') == ('aaaa', 8)
    assert decode(b'\\x61\\') == ('\\', 4)
    assert decode(b'\\x61\\x62') == ('ab', 6)
    assert decode(b'\\x61\\x62\\x63') == ('abc', 9)
    assert decode(b'\\x61\\x62\\x63\\x64') == ('abcd', 12)

# Generated at 2022-06-21 12:38:48.214021
# Unit test for function encode
def test_encode():
    assert encode('abc') == (b'\\61\\62\\63', 3)
    assert encode('abc😀') == (b'\\61\\62\\63\\xf0\\x9f\\x98\\x80', 7)
    assert encode('a😀d') == (b'\\61\\xf0\\x9f\\x98\\x80\\64', 7)
    assert encode('a\\x80d') == (b'\\61\\x80\\64', 5)


# Generated at 2022-06-21 12:38:56.668328
# Unit test for function encode
def test_encode():
    text = 'abc 123 !@#$ %^&*()'
    text_input = text.encode('utf-8')
    text_bytes, _length = encode(text)
    assert text_input == text_bytes
    text = '\\x80\\xff'
    text_input = text.encode('unicode_escape')
    text_bytes, _length = encode(text)
    assert text_input == text_bytes
    text = '\\x80\\xff'
    text_input = text.encode('unicode_escape')
    text_bytes, _length = encode(text)
    assert text_input == text_bytes



# Generated at 2022-06-21 12:39:02.969878
# Unit test for function encode
def test_encode():
    # Import modules for unit testing.
    import unittest

    # Define the unit tests within the function.

# Generated at 2022-06-21 12:39:09.228359
# Unit test for function encode
def test_encode():

    from eutf8h.tests.escape_tests import TESTS_ENCODE

    errors = [
        '', 'strict',
    ]
    for error in errors:
        for test in TESTS_ENCODE:
            text_input = test[0]
            expected_output = test[1]
            actual_output = encode(text_input, error)
            assert expected_output == actual_output



# Generated at 2022-06-21 12:39:16.897884
# Unit test for function encode
def test_encode():
    text = 'Test1\u2018\u2019\u201c\u201d'
    # noinspection SpellCheckingInspection
    expected = b"Test1\\xe2\\x80\\x98\\xe2\\x80\\x99\\xe2\\x80\\x9c\\xe2\\x80\\x9d"
    result, length = encode(text)
    assert expected == result, '{expected} != {actual}'.format(
        expected=expected,
        actual=result,
    )
    assert 16 == length, '{expected} != {actual}'.format(
        expected=16,
        actual=length,
    )



# Generated at 2022-06-21 12:39:18.624287
# Unit test for function decode
def test_decode():
    assert decode(b'\\xE2\\x80\\xA8') == ('\u2028', 9)

# Generated at 2022-06-21 12:39:26.579803
# Unit test for function decode
def test_decode():
    test_decode_data = [
        ('a\\x65', 'ae'),
        ('\\x61e', 'ae'),
        ('a\\x65b', 'aeb'),
        ('\\x61eb', 'aeb'),
        ('\\xC3\\xA1', 'á'),
        ('\\u00C1', 'Á'),
        ('\\U000000C1', 'Á'),
    ]
    for value, expected in test_decode_data:
        actual, len_consumed = decode(value)
        assert actual == expected

# Generated at 2022-06-21 12:39:31.878483
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder('eutf8h')[0] == encode
    assert codecs.getdecoder('eutf8h')[0] == decode
    try:
        codecs.getdecoder('eutf8h')
    except LookupError:
        pytest.fail('register() should not have unregistered the eutf8h codec')



# Generated at 2022-06-21 12:39:35.584725
# Unit test for function decode
def test_decode():
    print('Decoding the following ...')
    data = b'\\x41\\x42\\x43\\xE3\\x81\\x82'
    encoded_str, _ = decode(data)
    print(repr(encoded_str))
    print()



# Generated at 2022-06-21 12:39:36.822847
# Unit test for function register
def test_register():
    register()

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:40:15.645954
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)



# Generated at 2022-06-21 12:40:18.129078
# Unit test for function decode
def test_decode():
    assert decode(b'\\xC3\\xB1')[0] == 'ñ'
    return


if __name__ == '__main__':
    test_decode()

# Generated at 2022-06-21 12:40:23.970754
# Unit test for function decode
def test_decode():
    _tests = {
        b'T\\u00EAst3': 'Têst3',
        b'T\\x65\\x63s\\x74\\x32': 'Test2',
        b'Test\\x31': 'Test1',
    }

    for _bytes, expected in _tests.items():
        decoded, _ = decode(_bytes, errors='strict')
        assert decoded == expected



# Generated at 2022-06-21 12:40:31.722612
# Unit test for function decode
def test_decode():
    # test convert bytes to str with default errors
    assert decode(b'\\xF0\\x9f\\x92\\xa9')[0] == '💩'
    # test convert bytes to str with 'replace' errors
    assert decode(b'\\xCE\\xB1', errors='replace')[0] == '\xCE\xB1'
    assert decode(b'\\xF0\\x9f\\x92\\xa9', errors='replace')[0] == '😩'
    # test convert bytes to str with 'ignore' errors
    assert decode(b'\\xCE\\xB1', errors='ignore')[0] == ''
    assert decode(b'\\xF0\\x9f\\x92\\xa9', errors='ignore')[0] == ''
    # test convert bytes to str with 'name

# Generated at 2022-06-21 12:40:40.548069
# Unit test for function register

# Generated at 2022-06-21 12:40:42.124077
# Unit test for function register
def test_register():
    import sys
    sys.setrecursionlimit(100000)
    register()

# Generated at 2022-06-21 12:40:52.464857
# Unit test for function encode
def test_encode():
    assert encode(r'\xF0\x9F\x8F\x86\\xF0\\x9F\\x8F\\x86\\xF0\\\\x9F\\\\x8F\\\\x86') == b'\\U0001f3c6\\\\xF0\\\\x9F\\\\x8F\\\\x86\\\\xF0\\\\\\\\x9F\\\\\\\\x8F\\\\\\\\x86'
    assert encode(r'\xF0\x9F\x8F\x86\\xF0\\x9F\\x8F\\x86\\xF0\\\\x98\\\\x80\\xF0\\x9F\\x8F\\x86') == b'\\U0001f3c6\\\\xF0\\\\x9F\\\\x8F\\\\x86\\\\xF0\\\\\\\\x98\\\\\\\\x80\\U0001f3c6'

# Generated at 2022-06-21 12:40:54.002615
# Unit test for function register
def test_register():
    # Test the register function adds a new codec
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore

# Generated at 2022-06-21 12:41:00.475596
# Unit test for function encode
def test_encode():
    import unittest
    #                       c0       80   90   8f   8e   100  d0   d8   df
    str_input = 'Aa\xC0\x80\x90\x8F\x8E\x8F\xD0\xD8\xDF\xE8\xE9\xEA'
    expected_output = b'AaMozillaMozilla\\xe8\\xe9\\xea'
    str_output, n = encode(str_input)
    assert str_output == expected_output, "encode output does not match"
    assert n == len(str_input), "number of characters does not match"


# Generated at 2022-06-21 12:41:01.984397
# Unit test for function decode
def test_decode():
    test_seq = [
        'test1'
        'test2'
    ]

    for s in test_seq:
        data_bytes = s.encode('eutf8h')
        out, _ = decode(data_bytes)
        assert out == s


# Generated at 2022-06-21 12:42:20.761230
# Unit test for function encode
def test_encode():
    text_input = r'\xC2\xA3 \xd0\x90 \xf0\x90\x8c\x80'
    bytes_output, _ = encode(text_input)
    assert bytes_output == b'\\xc2\\xa3 \\xd0\\x90 \\xf0\\x90\\x8c\\x80'

    text_input = r'\\xC2\\xA3 \\xd0\\x90 \\xf0\\x90\\x8c\\x80'
    bytes_output, _ = encode(text_input)
    assert bytes_output == b'\\\\xc2\\\\xa3 \\\\xd0\\\\x90 \\\\xf0\\\\x90\\\\x8c\\\\x80'


# Generated at 2022-06-21 12:42:23.659412
# Unit test for function decode
def test_decode():
    codecs.register(_get_codec_info)
    test_bytes=b'\\x3f'
    test_bytes_hex = codecs.decode(test_bytes, 'eutf8h')
    assert test_bytes_hex=='?'
    print('test passed!!')


# Generated at 2022-06-21 12:42:27.771401
# Unit test for function decode
def test_decode():
    data_bytes = b'\\x61\\x62\\x63\\x64\\x65'
    expected_out = 'abcde'
    expected_len = 10
    actual_out, actual_len = decode(data_bytes, errors='strict')
    assert actual_out == expected_out
    assert actual_len == expected_len

# Generated at 2022-06-21 12:42:29.928882
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None
    codecs.lookup(NAME)



# Generated at 2022-06-21 12:42:36.845523
# Unit test for function encode
def test_encode():
    assert b'\\xE2\\x82\\xAC' == encode('€', 'strict')[0]

    text = '€'
    actual_bytes, actual_n = encode(text)
    assert b'\\xE2\\x82\\xAC' == actual_bytes
    assert len(text) == actual_n

    with pytest.raises(UnicodeEncodeError):
        encode('ת', 'strict')



# Generated at 2022-06-21 12:42:45.001580
# Unit test for function encode

# Generated at 2022-06-21 12:42:47.961107
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


# Generated at 2022-06-21 12:42:52.970412
# Unit test for function encode
def test_encode():
    test_string = 'abc\xe2\x9a\xbd\xef\xb8\x8f'

    actual = encode(test_string)[0].decode('UTF-8')
    expected = 'abc\\\\xe2\\\\x9a\\\\xbd\\\\xef\\\\xb8\\\\x8f'

    assert actual == expected


# Generated at 2022-06-21 12:42:56.284422
# Unit test for function register
def test_register():

    assert NAME not in codecs.__dict__

    register()

    assert NAME in codecs.__dict__['codec_aliases']['aliases']
    assert NAME in codecs.__dict__['_forget_codec']



# Generated at 2022-06-21 12:43:04.806404
# Unit test for function decode
def test_decode():
    # Test 1: ascii
    assert b'hello' == codecs.encode(
        codecs.decode(b'hello', 'eutf8h'),
        'ascii',
    )

    # Test 2: utf-8
    assert b'\xe2\x9c\x93' == codecs.encode(
        codecs.decode(b'\\xe2\\x9C\\x93', 'eutf8h'),
        'utf-8',
    )

    # Test 3: empty string
    assert b'' == codecs.encode(
        codecs.decode(b'', 'eutf8h'),
        'ascii',
    )