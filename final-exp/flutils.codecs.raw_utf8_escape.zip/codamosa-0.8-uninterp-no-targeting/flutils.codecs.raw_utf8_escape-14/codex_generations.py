

# Generated at 2022-06-21 12:34:46.144715
# Unit test for function encode
def test_encode():
    # Test encoding a valid character
    (utf_bytes, _) = encode('👨\u200d💻')
    assert utf_bytes == b'\\xf0\\x9f\\x91\\xa8\\xcc\\x8d\\xf0\\x9f\\x92\\xbb'



# Generated at 2022-06-21 12:34:58.579597
# Unit test for function encode
def test_encode():
    assert encode('a') == (b'a', 1)
    assert encode('\\x40') == (b'@', 4)
    assert encode('\\x00') == (b'\\x00', 4)
    assert encode('\\xFF') == (b'\\xFF', 4)
    assert encode('\\x7F') == (b'\\x7F', 4)
    assert encode('\\x80') == (b'\\xC2\\x80', 4)
    assert encode('\\u0000') == (b'\\x00', 6)
    assert encode('\\u007F') == (b'\\x7F', 6)
    assert encode('\\u0080') == (b'\\xC2\\x80', 6)

# Generated at 2022-06-21 12:35:05.462490
# Unit test for function decode
def test_decode():
    assert decode('\\xC3\\xA9\\xC3\\xA8') == ('éè', 12)
    assert decode('\\xC3\\xA9\\xC3\\xA8', errors='replace') == ('éè', 12)
    assert decode('\\xC3\\xA9\\xC3\\xA8', errors='ignore') == ('', 12)
    assert decode('\\xC3\\xA9\\xC3\\xA8', errors='surrogateescape') == ('', 12)

    assert decode('\\xC3\\xA9\\xC3\\xA8\\xC3') == ('éè', 12)
    assert decode('\\xC3\\xA9\\xC3\\xA8\\xC3', errors='replace') == ('éè', 12)

# Generated at 2022-06-21 12:35:14.090168
# Unit test for function register
def test_register():
    import sys
    from os import path
    from time import sleep
    from subprocess import Popen
    test_file = path.abspath(__file__)
    test_dir = path.dirname(test_file)
    test_script = path.join(test_dir, 'test_eutf8h.py')
    if sys.argv[0] == path.basename(test_file):
        # We are testing the module "eutf8h.py", so we need to run the unit
        # test in another process.
        proc = Popen(test_script)
        proc.wait()
        return
    register()

# Generated at 2022-06-21 12:35:18.408188
# Unit test for function decode
def test_decode():
    result = decode("\\xe6\\x96\\x87\\xe6\\x9c\\xac")
    assert (result[0] == '文本')
    assert (result[1] == 13)



# Generated at 2022-06-21 12:35:26.268603
# Unit test for function decode
def test_decode():
    # Get the output from the module
    text = 'č'
    # text_bytes = text.encode('utf-8')
    out, size = decode(text)
    # Get the expected output
    expected_out: str = '\\xc4\\x8d'
    expected_size: int = 1
    # Make sure the expected output matches the module output

# Generated at 2022-06-21 12:35:31.938188
# Unit test for function decode
def test_decode():
    # str
    assert decode(b'\\x61\\x62\\x63')[0] == 'abc'

    # bytearray
    assert decode(bytearray(b'\\x61\\x62\\x63'))[0] == 'abc'

    # memoryview
    assert decode(memoryview(b'\\x61\\x62\\x63'))[0] == 'abc'

    # bytes
    assert decode(b'\\x61\\x62\\x63') == ('abc', 9)



# Generated at 2022-06-21 12:35:34.240503
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


__all__ = ('encode', 'decode', 'NAME', 'register')

# Generated at 2022-06-21 12:35:46.021718
# Unit test for function encode

# Generated at 2022-06-21 12:35:48.148434
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getdecoder('eutf8h')
    return


# Generated at 2022-06-21 12:36:01.671183
# Unit test for function encode
def test_encode():
    assert encode('dog') == (b'dog', 3)
    assert encode('d\\x61g') == (b'd\\x61g', 5)
    assert encode('d\\u0061g') == (b'd\\x61g', 6)
    assert encode('d\\u0061\\u0074') == (b'd\\x61\\x74', 9)
    assert encode('d\\x61\\u0074') == (b'd\\x61\\x74', 8)
    assert encode('d\\u0061\\x74') == (b'd\\x61\\x74', 8)
    assert encode('d\\u0061\\x74\\u0061') == (b'd\\x61\\x74\\x61', 13)

# Generated at 2022-06-21 12:36:13.317817
# Unit test for function encode
def test_encode():
    """Test the encode function."""

    # Test for good input.
    assert encode('abcde') == (b'abcde', 5)
    assert encode('abcde\n') == (b'abcde\\0a', 6)
    assert encode('abcde\t') == (b'abcde\\09', 6)
    assert encode('abcde\x01') == (b'abcde\\01', 6)
    assert encode('\u9f4a\u4e00\u4e8c') == (b'\\e9\\bd\\8a\\e4\\b8\\80\\e4\\ba\\x82', 15)  # noqa: E501

# Generated at 2022-06-21 12:36:25.204318
# Unit test for function decode
def test_decode():

    # Test decoding of utf8 hex
    text_str = 'Hello world'
    text_str_utf8h = '\\x48\\x65\\x6c\\x6c\\x6f\\x20\\x77\\x6f\\x72\\x6c\\x64'
    text_bytes_utf8h = text_str_utf8h.encode('utf-8')

    assert decode(text_bytes_utf8h)[0] == text_str

    # Test decoding of latin-1 characters
    text_str = '\x00'
    text_str_utf8h = '\\x00'
    text_bytes_utf8h = text_str_utf8h.encode('utf-8')

    assert decode(text_bytes_utf8h)[0] == text_str

# Generated at 2022-06-21 12:36:35.852628
# Unit test for function decode
def test_decode():
    # assert decode(b'Hello World', 'strict') == ('Hello World', 11)
    assert decode(b'Hello World', 'strict') == ('Hello World', 11)
    assert decode(b'Hello World', 'strict') == ('Hello World', 11)
    assert decode(b'\\x48\\x65\\x6c\\x6c\\x6f\\x20\\x57\\x6f\\x72\\x6c\\x64', 'strict') == ('Hello World', 22)
    assert decode(b'\\x48\\x65\\x6c\\x6c\\x6f \\x57\\x6f\\x72\\x6c\\x64', 'strict') == ('Hello World', 21)

# Generated at 2022-06-21 12:36:39.850953
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    if False:
        test_register()

# Generated at 2022-06-21 12:36:50.549486
# Unit test for function encode
def test_encode():

    # Call encode with error checking set to strict.
    text = 'This is a \\xe2\\x98\\x83'
    errors = 'strict'
    try:
        text_encoded, length_consumed = encode(text, errors=errors)
        assert isinstance(text_encoded, bytes)
    except UnicodeEncodeError:
        pass

    # Call encode with error checking set to replace.
    errors = 'replace'
    text_encoded, length_consumed = encode(text, errors=errors)
    assert isinstance(text_encoded, bytes)
    assert text_encoded == b'This is a \\xe2\\x98\\x83'

    # Call encode with error checking set to backslashreplace.
    errors = 'backslashreplace'

# Generated at 2022-06-21 12:36:55.602141
# Unit test for function register
def test_register():
    register()
    decoder = codecs.getdecoder(NAME)
    assert decoder is not None
    assert decoder is not None
    assert decoder is not None

if __name__ == '__main__':
    test_register()
    print('Pass')

# Generated at 2022-06-21 12:37:01.535008
# Unit test for function encode
def test_encode():
    """
    >>> test_encode()
    True
    """
    codec_info = codecs.lookup(NAME)
    # noinspection PyProtectedMember
    assert codec_info.name == NAME
    # noinspection PyProtectedMember
    assert codec_info.encode == encode  # type: ignore[arg-type]
    # noinspection PyProtectedMember
    assert codec_info.decode == decode  # type: ignore[arg-type]
    return True



# Generated at 2022-06-21 12:37:07.082870
# Unit test for function encode
def test_encode():
    a = 'a\u03a3'
    assert a == 'a\N{greek capital letter sigma}'
    assert a.encode('eutf8h') == b'a\\xce\\xa3'
    assert a.encode('eutf8h').decode('eutf8h') == a



# Generated at 2022-06-21 12:37:10.414386
# Unit test for function register
def test_register():
    register()
    try:
        # noinspection PyUnresolvedReferences
        codecs.getdecoder(NAME)
    except LookupError:
        raise Exception(f'Codec {NAME} not registered')
test_register()



# Generated at 2022-06-21 12:37:15.824564
# Unit test for function decode
def test_decode():
    try:
        assert decode(b'hello world') == ('hello world', 11)
    except UnicodeDecodeError:
        pass


# Generated at 2022-06-21 12:37:18.242801
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-21 12:37:22.993725
# Unit test for function encode
def test_encode():
    s = 'Hello,\u03bc\u03bc\u03bct\xe9\xff!'
    assert encode(s)[0] == b'Hello,\\\\u03bc\\\\u03bc\\\\u03bc\\\\u03bct\\\\xE9\\\\xFF!'
    assert encode(s)[1] == len(s)


# Generated at 2022-06-21 12:37:28.661210
# Unit test for function decode
def test_decode():
    assert decode(b'\\x41\\x62\\x63') == ('Abc', 8)
    assert decode(
        b'\\x41\\x62\\x63',
        errors='ignore'
    ) == ('', 8)
    assert decode(
        b'\\x41\\x62\\x3',
    ) == ('Ab\\x3', 8)



# Generated at 2022-06-21 12:37:32.361718
# Unit test for function encode
def test_encode():
    s = 'hi\u00A7world'
    r = encode(s)
    assert r == (b'\\x68\\x69\\xa7\\x77\\x6f\\x72\\x6c\\x64', 8)



# Generated at 2022-06-21 12:37:40.014039
# Unit test for function encode
def test_encode():
    # Define the codec instance
    codec_instance = codecs.lookup(NAME)
    # Define the given escaped utf8 hexadecimal string

# Generated at 2022-06-21 12:37:48.485071
# Unit test for function encode
def test_encode():
    test_str: str = "This is a test string"
    test_str_utf8: str = "Ελληνικά: Πάμε στη μαγειρειά και γιορτάζουμε και" \
        "τελειώνουμε τις συναντήσεις μας με επιτυχία"

    val = encode(test_str)
    assert val == (b"This is a test string", len(test_str))
    val = encode(test_str_utf8)

# Generated at 2022-06-21 12:37:52.758157
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert True
    else:
        assert False
        assert codecs.getdecoder(NAME)
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False
    else:
        assert True
        assert codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:38:02.016820
# Unit test for function decode
def test_decode():
    _Str = Union[str, UserString]

    decoder_error_checker = (
        (
            codecs.strict_decode,
            UnicodeDecodeError,
        ),
        (
            codecs.ignore_decode,
            None,
        ),
        (
            codecs.replace_decode,
            None,
        ),
    )

    for decoder, error in decoder_error_checker:
        decoder_name = decoder.__name__
        print(decoder_name)

        if error is not None:
            assert error.__name__ in decoder_name

        # Decode an escaped utf8 representing a latin-1 character.
        # All the decoders should be able to decode this.

# Generated at 2022-06-21 12:38:14.284185
# Unit test for function register
def test_register():
    test_cases = [
        # Test case without a codec that exists.
        {
            "name": "eutf8h",
            "expected_exception_type": LookupError,
        },
        # Test case with a codec that exists.
        {
            "name": "utf-8-sig",
            "expected_exception_type": None,
        },
    ]

    for test_case in test_cases:

        name = test_case["name"]
        expected_exception_type = test_case["expected_exception_type"]

        # Try to get the decoder for the given 'name'.
        # If that fails, then that is fine.
        try:
            codecs.getdecoder(name)
        except LookupError:
            pass

        # Try to register.

# Generated at 2022-06-21 12:38:21.041686
# Unit test for function register
def test_register():
    import codecs
    from . import eutf8h
    register()
    codecs.register(eutf8h._get_codec_info)

# Generated at 2022-06-21 12:38:29.224900
# Unit test for function decode
def test_decode():
    assert decode(b'o') == ('o', 1)
    assert decode(b'\\x6f') == ('o', 6)
    assert decode(b'\\x6f ') == ('o ', 6)
    assert decode(b'\\x6f w') == ('o w', 6)
    assert decode(b'\\x6f \\x77') == ('o w', 8)
    assert decode(b'\\x6f \\x77 ') == ('o w ', 8)
    assert decode(b'\\x6f \\x77') == ('o w', 8)
    assert decode(b'\\x6f\\x77') == ('ow', 8)
    assert decode(b'\\x6F\\x77') == ('oW', 8)

# Generated at 2022-06-21 12:38:36.655795
# Unit test for function register

# Generated at 2022-06-21 12:38:40.904060
# Unit test for function register
def test_register():
    def test_get_decoder(name):
        try:
            return codecs.getdecoder(name)
        except LookupError:
            return None

    assert not test_get_decoder(NAME)
    register()
    assert test_get_decoder(NAME)



# Generated at 2022-06-21 12:38:51.325857
# Unit test for function decode
def test_decode():

    # Test the handling of escaped utf8 hexadecimal bytes.
    assert decode(b' ')[0] == ' '
    assert decode(b'\x00')[0] == '\x00'
    assert decode(b'\x20')[0] == '\x20'
    assert decode(b'\x22')[0] == '\x22'
    assert decode(b'\x25')[0] == '\x25'
    assert decode(b'\x28')[0] == '\x28'
    assert decode(b'\x29')[0] == '\x29'
    assert decode(b'\x2a')[0] == '\x2a'
    assert decode(b'\x2b')[0] == '\x2b'

# Generated at 2022-06-21 12:38:57.942749
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    # Unit test for function encode
    def test_encode():
        text: str = 'Hello World! \U0001F60E'
        errors: str = 'strict'
        errors: str = 'ignore'
        errors: str = 'replace'
        errors: str = 'backslashreplace'
        bytes_output, consumed = encode(text, errors)
        print('encode', repr(bytes_output), consumed)

    # Unit test for function decode
    def test_decode():
        text: bytes = b'Hello World! \\U0001F60E'
        errors: str = 'strict'
        errors: str = 'ignore'
        errors: str = 'replace'
        str_output, consumed = decode(text, errors)

# Generated at 2022-06-21 12:38:59.543428
# Unit test for function encode
def test_encode():
    assert encode('hello') == (b'h\x65\x6c\x6c\x6f', 5)



# Generated at 2022-06-21 12:39:12.008186
# Unit test for function register
def test_register():
    import sys
    import pytest
    from unittest_decorator import allow_in_subpackage

    try:
        codecs.getdecoder(NAME)
        has_been_registered = True
    except LookupError:
        has_been_registered = False

    module = sys.modules[__name__]
    module.register()

    if has_been_registered:
        # Since the codec was already registered, no changes should
        # have been made.
        assert module.encode == encode
        assert module.decode == decode

# Generated at 2022-06-21 12:39:12.973897
# Unit test for function encode
def test_encode():
    pass


# Generated at 2022-06-21 12:39:20.272784
# Unit test for function register
def test_register():
    register()
    with open("testfile.txt", "w") as f:
        f.write("\xE9\x9C\xB3\xE0\xB8\xA3\xE0\xB8\x9C\xE0\xB8\xA2\xE0\xB8\xB2")
    with open("testfile.txt", "r", encoding="eutf8h") as f:
        content = f.read()
        assert content == "\xE9\x9C\xB3\xE0\xB8\xA3\xE0\xB8\x9C\xE0\xB8\xA2\xE0\xB8\xB2"


# Generated at 2022-06-21 12:39:38.927071
# Unit test for function decode
def test_decode():
    # Fixture values for codec.decode
    # (data, errors)
    fixture: [_ByteString, _Str]