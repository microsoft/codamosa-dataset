

# Generated at 2022-06-21 12:34:47.438389
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-21 12:34:59.345447
# Unit test for function encode
def test_encode():
    text_input = '12'
    out, consumed = encode(text_input)
    assert out == b'12'
    assert consumed == 2
    text_input = '12\x0056'
    out, consumed = encode(text_input)
    assert out == b'12\\x0056'
    assert consumed == 4
    text_input = 'sj'
    out, consumed = encode(text_input)
    assert out == b'sj'
    assert consumed == 2
    text_input = 'sj\x00lk'
    out, consumed = encode(text_input)
    assert out == b'sj\\x00lk'
    assert consumed == 4
    text_input = '12\x0056\xFF\xA0\u20AC'
    out, consumed = encode(text_input)

# Generated at 2022-06-21 12:35:08.996375
# Unit test for function decode

# Generated at 2022-06-21 12:35:14.462522
# Unit test for function register
def test_register():
    # Take the name out of the scope of the test register function.
    name = NAME
    codecs.register(
        lambda name_p: (  # type: ignore
            None
            if name_p != name
            else codecs.CodecInfo(  # type: ignore
                name=name,
                encode=encode,  # type: ignore[arg-type]
                decode=decode,  # type: ignore[arg-type]
            )
        )
    )



# Generated at 2022-06-21 12:35:27.045816
# Unit test for function encode
def test_encode():
    # encode: str, errors -> bytes, int
    # Decode the given string of escaped utf8 hexadecimal.

    # Convert the string into utf-8 bytes
    text_input = 'méxico'
    text_bytes_utf8 = text_input.encode('utf-8')
    text_bytes_utf8 = cast(bytes, text_bytes_utf8)
    text_bytes_utf8_hex = '\\x6D\\xC3\\xA9\\x78\\x69\\x63\\x6F'
    assert text_bytes_utf8_hex == text_bytes_utf8.decode('unicode_escape')

    # Convert the utf8 bytes into a string of latin-1 characters.
    # This basically maps the exact utf8 bytes to the string. Also,
    # this

# Generated at 2022-06-21 12:35:29.524705
# Unit test for function register
def test_register():
    codecs.lookup(NAME)

if __name__ == '__main__':
    register()
    test_register()
    print('Registered codec eutf8h')

# Generated at 2022-06-21 12:35:35.591123
# Unit test for function encode
def test_encode():
    print('Testing encode ...')
    assert encode('\\x5F') == (b'_', 2)
    assert encode('\\uD1B3') == (b'\\uD1B3', 6)
    assert encode('\\U00000043') == (b'\\U00000043', 10)
    assert encode('\n') == (b'\\n', 1)
    assert encode('a') == (b'a', 1)
    assert encode('\u00E1') == (b'\\u00E1', 6)

    test_bytes = b'\\uD1B3'
    test_bytes_latin1 = test_bytes.decode('unicode_escape')
    test_bytes_utf8 = test_bytes_latin1.encode('latin1')
    test_str = test_bytes_utf8

# Generated at 2022-06-21 12:35:47.444244
# Unit test for function register
def test_register():
    from functools import lru_cache
    from unittest.mock import patch
    from pytest import approx

    @lru_cache(None)
    def _getdecoder_from_cache(name: str) -> Optional[codecs.CodecInfo]:
        try:
            return codecs.getdecoder(name)
        except LookupError:
            return None

    def _get_decoder(name: str) -> Optional[codecs.CodecInfo]:
        try:
            return codecs.lookup(name)
        except LookupError:
            return None

    with patch('codecs.lookup', new=_get_decoder):
        with patch('codecs._cache.getdecoder', new=_getdecoder_from_cache):

            register()
            # Test the registered codec

# Generated at 2022-06-21 12:35:49.947743
# Unit test for function register
def test_register():
    # Try to register the codec and then try to deregister it
    register()
    codecs.unregister(NAME)


# Generated at 2022-06-21 12:36:01.901130
# Unit test for function encode
def test_encode():
    from random import randint
    from random import choice
    from typing import Sequence
    from typing import Optional
    from typing import Union
    from typing import TypeVar
    from typing import Generic
    from typing import Callable
    from typing import Any
    from typing import cast
    from typing import TYPE_CHECKING

    if TYPE_CHECKING:
        from typing import List
        from typing import Tuple
        from typing import Type
        from typing import TypeVar

    _T = TypeVar('_T')          # type: ignore
    _ExpectedType = TypeVar('_ExpectedType')  # type: ignore


# Generated at 2022-06-21 12:36:16.586275
# Unit test for function encode
def test_encode():
    assert encode('abc') == (b'abc', 3)
    assert encode('ab\x7fx') == (b'ab\\x7f', 5)
    assert encode('ab\x80x') == (b'ab\\x7f\\x9f', 6)
    assert encode('ab\x80\x80x') == (b'ab\\x7f\\x9f\\x7f\\x9f', 7)
    assert encode('ab\x80\x80\x80x') == (b'ab\\x7f\\x9f\\x7f\\x9f\\x7f\\x9f', 8)

# Generated at 2022-06-21 12:36:27.270969
# Unit test for function encode
def test_encode():
    assert encode('Hello World!') == (b'Hello World!', len('Hello World!'))
    assert encode('你好世界') == (b'\\xe4\\xbd\\xa0\\xe5\\xa5\\xbd\\xe4\\xb8\\x96\\xe7\\x95\\x8c', len('你好世界'))
    assert (
        encode('\\x41\\x42\\x43\\x44\\x45') ==
        (b'\\x41\\x42\\x43\\x44\\x45', len('\\x41\\x42\\x43\\x44\\x45'))
    )
    assert encode(
        '\\x41\\x42\\x43\\x44\\x45你好世界',
        errors='ignore'
    )

# Generated at 2022-06-21 12:36:28.365104
# Unit test for function register
def test_register():
    test_case_1()


# Generated at 2022-06-21 12:36:41.637905
# Unit test for function encode
def test_encode():
    string1 = 'Hello World'
    string2 = '外国人'
    string3 = 'złom'
    string4 = '¡¡'
    string5 = '💩'
    string6 = 'Ω'
    string7 = '\\x80'
    string8 = '\\x80\\xFF'
    string9 = '😊YOLO\\x80\\xFF'
    string10 = '😊YOLO\\x80\\xFf'
    string11 = '\\x80\u3042\\xFF'


# Generated at 2022-06-21 12:36:43.425497
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME)
    assert codecs.getdecoder(NAME)

# Generated at 2022-06-21 12:36:52.029060
# Unit test for function encode
def test_encode():
    text = 'Hello World'
    assert encode(text) == (b'Hello World', 11)

    text = 'Hello\x20World'
    assert encode(text) == (b'Hello\\x20World', 12)

    text = '𝓼'
    assert encode(text) == (b'\\xf0\\x93\\x93\\xbc', 1)

    text = 'Hello\\x20World'
    assert encode(text) == (b'Hello\\x20World', 14)

    text = '𝒉𝒆𝒍𝒍𝒐\\x20𝒘𝒐𝒓𝒍𝒅'

# Generated at 2022-06-21 12:36:58.665644
# Unit test for function encode
def test_encode():
    # Test 1
    text_input = "abcd"
    text_expected = b'abcd'
    assert encode(text_input)[0] == text_expected
    # Test 2
    text_input = "a\\x80"
    text_expected = b"a\xc2\x80"
    assert encode(text_input)[0] == text_expected



# Generated at 2022-06-21 12:37:07.859749
# Unit test for function decode
def test_decode():
    # Test string
    text = '\ufeff'

    # Convert back to bytes
    text_bytes_utf8 = text.encode('utf-8')

    # Convert each byte to its escaped utf8 hexadecimal string
    hex_str = reduce(lambda a, b: f"{a}{b}", _each_utf8_hex(text_bytes_utf8.decode()))

    # Decode the escaped utf8 hexadecimal bytes
    decoded_text = decode(hex_str.encode())[0]

    assert text == decoded_text


# Generated at 2022-06-21 12:37:19.405583
# Unit test for function encode
def test_encode():
    assert encode('\u0040') == (b'\\40', 1)
    assert encode('\u00a2') == (b'\\a2', 1)
    assert encode('\u1ef6') == (b'\\e1\\bb\\b6', 3)
    assert encode('\u1f60') == (b'\\e1\\bd\\a0', 3)

    assert encode('\u0040 ') == (b'\\40 ', 1)
    assert encode(' \u00a2') == (b' \\a2', 2)
    assert encode('\u1ef6 ') == (b'\\e1\\bb\\b6 ', 3)
    assert encode(' \u1f60') == (b' \\e1\\bd\\a0', 4)


# Generated at 2022-06-21 12:37:24.267904
# Unit test for function decode
def test_decode():
    """
    >>> decode(b'\\xDF')
    ('ß', 5)
    >>> decode(b'\\xC3\\x9F')
    ('ß', 6)
    >>> decode(b'\\x66\\x6f\\x6f\\x62\\x61\\x72')
    ('foobar', 21)
    """
    pass



# Generated at 2022-06-21 12:37:37.604986
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        assert False, f'LookupError "{e}"'



# Generated at 2022-06-21 12:37:47.615706
# Unit test for function decode
def test_decode():
    assert decode(b'\\x41') == ('A', 3)
    assert decode(b'\\x4e') == ('N', 3)
    assert decode(b'\\x59') == ('Y', 3)
    assert decode(b'\\x5a') == ('Z', 3)

    assert decode(b'\\x5a\\x5a\\x5a\\x5a') == ('ZZZZ', 9)

    assert decode(b'\\xe3\\x81\\x82') == ('あ', 9)
    assert decode(b'\\xe5\\x8d\\x8a') == ('半', 9)
    assert decode(b'\\xe6\\x97\\xa5') == ('日', 9)
    assert decode(b'\\xef\\xbc\\x81') == ('！', 9)


# Generated at 2022-06-21 12:37:53.551252
# Unit test for function decode
def test_decode():
    bs = b'\\x01\\x02\\x03\\x04\\x05'
    _, consumed = codecs.getdecoder(NAME)(bs)
    assert consumed == len(bs)

    bs = b'\\x01\\x02\\x03\\x04\\x05'
    _, consumed = codecs.getdecoder(NAME)(bs)  # type: ignore
    assert consumed == len(bs)

    bs = b'\\x01\\x02\\x03\\x04\\x05'
    _, consumed = decode(bs)
    assert consumed == len(bs)



# Generated at 2022-06-21 12:37:57.022015
# Unit test for function register
def test_register():
    from os import name as os_name
    if os_name != 'nt':
        register()
        codecs.getdecoder(NAME)



# Generated at 2022-06-21 12:38:01.846401
# Unit test for function decode
def test_decode():
    a = b'HelloWorld'
    b = b'\\x48\\x65\\x6c\\x6c\\x6f\\x4c\\x4f\\x4e\\x47'
    assert decode(b)[0] == 'HelloWorld'
    assert decode(a)[0] != 'HelloWorld'


# Generated at 2022-06-21 12:38:10.707129
# Unit test for function register
def test_register():
    # Clear out any existing encoder/decoder of this name
    codecs.lookup(NAME)
    register()
    codecs.lookup(NAME)
    pass


# Execute test code when this file is run as a script
exec('''
if __name__ == '__main__':
    import sys
    def _main():
        args = sys.argv[1:]
        if args and args[0] == 'register':
            register()
        else:
            test_register()
    _main()
''')

# Generated at 2022-06-21 12:38:15.271019
# Unit test for function decode
def test_decode():
    assert decode(b'\\x41\\x42\\x43')[0] == 'ABC'
    assert decode(b'\\x41\\x42\\x43')[1] == 9
    assert decode(b'\\u041A\\u043A\\u0430')[0] == 'ККа'
    assert decode(b'\\u041A\\u043A\\u0430')[1] == 12



# Generated at 2022-06-21 12:38:19.071137
# Unit test for function encode
def test_encode():
    assert encode('中文') == (b'\\xe4\\xb8\\xad\\xe6\\x96\\x87', 2)
    assert encode('') == (b'', 0)



# Generated at 2022-06-21 12:38:27.958180
# Unit test for function decode
def test_decode():
    assert decode(b'\\x41\\x42') == ('\x41\x42', 6)
    assert decode(b'\\x41\\x42', 'strict') == ('\x41\x42', 6)
    assert decode(b'\\x41\\xc3\\x42') == ('\x41\xc3\x42', 9)
    assert decode(b'\\x41\\xc3\\x42', 'strict') == ('\x41\xc3\x42', 9)

    assert decode(b'\\x41\\xc3\\x42', 'ignore') == ('\x41', 6)
    assert decode(b'\\x41\\xc3\\x42', 'replace') == ('\x41\ufffd', 9)


# Generated at 2022-06-21 12:38:30.725727
# Unit test for function decode
def test_decode():
  str_bytes = bytes('\\x11\\x22\\x33', 'utf-8')
  assert decode(str_bytes) == ('\u0011"3', 12)


# Generated at 2022-06-21 12:38:50.276167
# Unit test for function decode
def test_decode():
    """Tests the decode function.
    """
    test1 = decode(b"abc")[0]
    if test1 != "abc":
        raise Exception("test_decode_1")
    test2 = decode(b"\xe4\xb8\xad\xe6\x96\x87")[0]
    if test2 != "中文":
        raise Exception("test_decode_2")
    test3 = decode(b"\\xe4\\xb8\\xad\\xe6\\x96\\x87")[0]
    if test3 != "中文":
        raise Exception("test_decode_3")
    test4 = decode(b"\\xe0")[0]
    if test4 != "\uf8ff":
        raise Exception("test_decode_4")
    test5 = decode

# Generated at 2022-06-21 12:38:59.814298
# Unit test for function decode
def test_decode():
    assert decode(
        b'\\u00e6_\\u00e6_\\u00e6',
        errors='strict'
    ) == ('æ_æ_æ', 15)

    assert decode(
        b'x\\x00x',
        errors='strict'
    ) == ('x\x00x', 5)

    assert decode(
        b'x\\x00\\x00x',
        errors='strict'
    ) == ('x\x00\x00x', 7)

    assert decode(
        b'x\\x00\\x00x',
        errors='ignore'
    ) == ('xx', 3)

    assert decode(
        b'x\\x00\\x00x',
        errors='replace'
    ) == ('x�x', 7)


# Generated at 2022-06-21 12:39:01.447034
# Unit test for function encode
def test_encode():
    pass


# Generated at 2022-06-21 12:39:04.378138
# Unit test for function register
def test_register():
    import sys
    codecs.register(_get_codec_info)   # type: ignore
    sys.getrecursionlimit()


# Generated at 2022-06-21 12:39:09.751418
# Unit test for function encode
def test_encode():
    # print(encode('Hello world!'))
    # print(encode('ライフ イズ ストレンジ'))
    # print(encode('\x80\xff'))
    # print(encode('\x80\xff', errors='ignore'))
    # print(encode('\x80\xff', errors='replace'))
    pass



# Generated at 2022-06-21 12:39:18.696081
# Unit test for function decode

# Generated at 2022-06-21 12:39:30.183030
# Unit test for function encode
def test_encode():
    # Empty string
    assert encode('', errors='strict') == (b'', 0)
    assert encode('', errors='replace') == (b'', 0)
    assert encode('', errors='ignore') == (b'', 0)

    # Ascii
    assert encode('abc', errors='strict') == (b'abc', 3)
    assert encode('abc', errors='replace') == (b'abc', 3)
    assert encode('abc', errors='ignore') == (b'abc', 3)

    # Ascii-ish
    assert encode('a\x7f', errors='strict') == (b'a\\x7f', 2)
    assert encode('a\x7f', errors='replace') == (b'a\ufffd', 2)

# Generated at 2022-06-21 12:39:32.254681
# Unit test for function register
def test_register():
    """Test that the eutf8h codec register works."""
    register()
    codecs.getdecoder(NAME)  # type: ignore



# Generated at 2022-06-21 12:39:38.310477
# Unit test for function encode
def test_encode():
    assert (b'\\x41\\xE2\\x82\\xAC', 4) == encode('A€')
    assert (b'\\u05D0\\U0001D11E', 4) == encode('א𝄞')

    # Test for UnicodeEncodeError

# Generated at 2022-06-21 12:39:40.154158
# Unit test for function register
def test_register():
    import builtins
    builtins.__dict__.get('register', register)()

register()

# Generated at 2022-06-21 12:39:59.242827
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)  # type: ignore   # noqa: F841



# Generated at 2022-06-21 12:40:07.349709
# Unit test for function encode
def test_encode():
    data = "ab\\u03bb\\u03b7\\u03b1\\u03bb\\u0020\\u03bc\\u03b3\\u03b9\\u03bc\\u03b1\\u03b2\\u03bb\\u03ac\\u03b0\\u03b9"
    result, result_len = encode(data)
    assert result == b'ab\\\\u03bb\\\\u03b7\\\\u03b1\\\\u03bb\\\\u0020\\\\u03bc\\\\u03b3\\\\u03b9\\\\u03bc\\\\u03b1\\\\u03b2\\\\u03bb\\\\u03ac\\\\u03b0\\\\u03b9'
    assert result_len == len(data)


# Generated at 2022-06-21 12:40:15.687448
# Unit test for function encode
def test_encode():
    text_input = "The quick brown fox jumps over the lazy dog"
    _bytes, _ = encode(text_input)
    assert isinstance(_bytes, bytes)
    text_output, _ = decode(_bytes)
    assert text_input == text_output

    text_input = "The quick \\x42\\x45\\x47 brown \\x42\\x45\\x47 fox jumps over the lazy dog"
    _bytes, _ = encode(text_input)
    assert isinstance(_bytes, bytes)
    text_output, _ = decode(_bytes)
    assert text_input == text_output



# Generated at 2022-06-21 12:40:19.536598
# Unit test for function encode
def test_encode():
    assert encode('abcd') == (b'a\x62\x63\x64', 4)
    assert encode(b'abcd') == (b'a\x62\x63\x64', 4)
    assert encode('ø') == (b'\\xc3\\xb8', 1)



# Generated at 2022-06-21 12:40:25.092932
# Unit test for function encode
def test_encode():
    # The string data is UTF-8 text.
    # This function should convert the string into a series of escaped
    # UTF-8 bytes.
    data = 'å'
    # data = '\u00a5'
    # result = b'\\\\xc3\\\\xa5'
    expected = b'\\xc3\\xa5'
    actual = encode(data)[0]
    assert actual == expected



# Generated at 2022-06-21 12:40:26.330848
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore



# Generated at 2022-06-21 12:40:31.190203
# Unit test for function decode
def test_decode():
    assert decode(b'\\x41\\x42') == ('AB', 7)
    assert decode(b'\\x41\\x42', ) == ('AB', 7)
    assert decode(b'\\u1234') == ('ሴ', 6)
    assert decode(b'\\u1234', ) == ('ሴ', 6)



# Generated at 2022-06-21 12:40:31.775372
# Unit test for function register
def test_register():
    _ = register

# Generated at 2022-06-21 12:40:40.574302
# Unit test for function decode
def test_decode():
    codecs.register(_get_codec_info)
    # input expected output start end

# Generated at 2022-06-21 12:40:43.805892
# Unit test for function decode
def test_decode():
    assert '筆' == decode(b'\xe7\xad\x86')
    assert '筆' == decode(b'\\xe7\\xad\\x86')



# Generated at 2022-06-21 12:41:27.795829
# Unit test for function register
def test_register():
    # Register the codec for the first time. This should create the
    # codec.
    register()
    codec = codecs.getdecoder(NAME)  # type: ignore
    assert encode.__code__ == codec.encode.__code__  # type: ignore
    assert decode.__code__ == codec.decode.__code__  # type: ignore
    # Register the codec for the second time. This should not replace
    # the codec.
    register()
    codec = codecs.getdecoder(NAME)  # type: ignore
    assert encode.__code__ == codec.encode.__code__  # type: ignore
    assert decode.__code__ == codec.decode.__code__  # type: ignore

# Generated at 2022-06-21 12:41:32.662987
# Unit test for function register
def test_register():
    """Unit test for the function register."""
    try:
        register()
        assert codecs.lookup(NAME)
    except LookupError:
        assert False


NAME_ENCODER = '_' + NAME


# noinspection PySameParameterValue

# Generated at 2022-06-21 12:41:35.464886
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(
            'Could not register codec (%s).' % NAME
        )



# Generated at 2022-06-21 12:41:44.724702
# Unit test for function encode
def test_encode():
    test = 'abcdef'
    out = b'abcdef'
    assert encode(test) == (out, 6)
    test = 'abc\x80'
    out = b'abc\\x80'
    assert encode(test) == (out, 5)
    test = 'abc\x81'
    out = b'abc\\x81'
    assert encode(test) == (out, 5)
    test = 'abc\xc2\x80'
    out = b'abc\\xc2\\x80'
    assert encode(test) == (out, 6)
    test = 'abc\xe0\xa0\x80'
    out = b'abc\\xe0\\xa0\\x80'
    assert encode(test) == (out, 8)

# Generated at 2022-06-21 12:41:47.425084
# Unit test for function register
def test_register():
    register()

# if __name__ == '__main__':
#     register()

# Generated at 2022-06-21 12:41:57.619862
# Unit test for function encode
def test_encode():
    assert encode("abc") == (b'a', 1)
    assert encode("ä") == (b'\\xc3', 1)
    assert encode("ä", 'ignore') == (b'', 1)
    assert encode("ä", 'replace') == (b'\\ufffd', 1)
    assert encode("\u3000", 'replace') == (b'\\xe3\\x80\\x80', 2)
    assert encode("\u3042", 'replace') == (b'\\xe3\\x81\\x82', 3)
    assert encode("\u3042") == (b'\\xe3\\x81\\x82', 3)
    assert encode("\\xFF") == (b'\\xFF', 4)
    assert encode("\\xFF", 'ignore') == (b'', 4)

# Generated at 2022-06-21 12:42:05.216540
# Unit test for function encode
def test_encode():
    assert encode('', '') == (b'', 0)
    assert encode('abc', '') == (b'abc', 3)
    assert encode('abc', 'backslashreplace') == (b'abc', 3)
    assert encode('€', '') == (b'\\xe2\\x82\\xac', 1)
    assert encode('€', 'backslashreplace') == (b'\\xe2\\x82\\xac', 1)
    assert encode('a\\x80', '') == (b'a\\x80', 4)
    assert encode('a\\x80', 'backslashreplace') == (b'a\\x80', 4)
    assert encode('a\\x80€', '') == (b'a\\x80\\xe2\\x82\\xac', 5)

# Generated at 2022-06-21 12:42:07.474174
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME)

# noinspection PyUnionType

# Generated at 2022-06-21 12:42:18.573604
# Unit test for function register
def test_register():
    register()
    out = codecs.encode('\U0001f604', 'eutf8h')
    assert out == b'\\xF0\\x9F\\x98\\x84'
    out = codecs.decode('\\xF0\\x9F\\x98\\x84', 'eutf8h')
    assert out.encode('utf8') == b'\xf0\x9f\x98\x84'


if __name__ == '__main__':
    register()
    out = codecs.encode('\U0001f604', 'eutf8h')
    print(out)
    out = codecs.decode('\\xF0\\x9F\\x98\\x84', 'eutf8h')
    print(out)

# Generated at 2022-06-21 12:42:22.583702
# Unit test for function decode
def test_decode():
    assert decode(b'banana\\x00') == ('banana\x00', 10)
    assert decode(b'banana\\x00', 'replace') == ('banana�', 10)
    assert decode(b'\\xe2', 'ignore') == ('', 4)

# Generated at 2022-06-21 12:43:54.787923
# Unit test for function encode
def test_encode():
    # A string of ascii characters
    IN = 'abcABC'
    EXPECTED = b'abcABC'
    GROUND_TRUTH = IN.encode('utf8')
    assert GROUND_TRUTH == EXPECTED
    assert encode(IN) == (EXPECTED, len(IN))

    # A string of ascii characters with escaped hexadecimal for a \u2212 minus sign
    IN = 'adfadf-\\u2212adf'
    EXPECTED = b'adfadf-\\xe2\\x88\\x92adf'
    GROUND_TRUTH = IN.encode('utf8')
    assert GROUND_TRUTH == EXPECTED
    assert encode(IN) == (EXPECTED, len(IN))

    # A string of ascii characters with escaped hexadec

# Generated at 2022-06-21 12:44:06.760873
# Unit test for function decode
def test_decode():
    """Unit tests for function decode from module
    :mod:`%(MODULE)s`."""

# Generated at 2022-06-21 12:44:17.648938
# Unit test for function register
def test_register():
    from codecs import register_error, lookup_error
    from functools import partial
    from sys import getdefaultencoding

    # Exception: When the specified error handler name is not found.
    # This can occur if the error handler was not registered using
    # the register_error() function.
    # noinspection PyBroadException
    class EUTF8H_Error(LookupError):
        pass

    # Register the codec
    register()

    # Get the default encoding
    default_encoding = getdefaultencoding()

    # Register a custom error handler
    register_error('eutf8h', EUTF8H_Error)

    # Get the custom error handler
    eutf8h_error = lookup_error('eutf8h')


# Generated at 2022-06-21 12:44:27.809664
# Unit test for function decode
def test_decode():
    # Test escaped utf8 hexadecimal characters.
    assert decode('\\x61\\x62\\x63') == ('abc', 11)
    assert decode('ab\\xc3\\x9f') == ('abß', 7)
    assert decode('\\xe2\\x99\\xa5') == ('\u2665', 9)

    # Test unicode character.
    assert decode('\\u2665') == ('\u2665', 6)
    assert decode('\\N{WHITE HEART SUIT}') == ('\u2665', 20)
    assert decode('\\N{BLACK HEART SUIT}') == ('\u2665', 21)

    # Test surrogate pairs.
    assert decode('\\U0001d11e') == ('\U0001d11e', 10)

# Generated at 2022-06-21 12:44:38.893892
# Unit test for function register
def test_register():
    # If a codec is already registered with the given name, do nothing.
    register()

    # If a codec is already registered with the given name, do nothing.
    register()


if __name__ == '__main__':

    test_register()

    # Unit test for function encode
    out_bytes, _ = encode('\\xC2\\x80')
    assert out_bytes == b'\\xc2\\x80'
    out_bytes, _ = encode('\\xC2\\x80')
    assert out_bytes == b'\\xc2\\x80'

    # Unit test for function decode
    out, _ = decode(b'\\xc2\\x80')
    assert out == '\u0080'

    # Unit test for function encode

# Generated at 2022-06-21 12:44:47.800307
# Unit test for function decode
def test_decode():
    # No input
    assert decode(b'', 'strict') == ('', 0)
    assert decode(b'', 'ignore') == ('', 0)

    # Regular text
    assert decode(b'abc') == ('abc', 3)
    assert decode(b'abcdefg') == ('abcdefg', 7)

    # ASCII hexadecimal