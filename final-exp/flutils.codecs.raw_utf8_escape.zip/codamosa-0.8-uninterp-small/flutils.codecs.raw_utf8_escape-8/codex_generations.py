

# Generated at 2022-06-25 17:10:42.875411
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is _get_codec_info(NAME)



# Generated at 2022-06-25 17:10:45.732323
# Unit test for function register
def test_register():
    try:
        codecs.getencoder(NAME)
    except LookupError:
        register()
    assert codecs.lookup(NAME) is not None



# Generated at 2022-06-25 17:10:47.109825
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:10:53.584183
# Unit test for function register
def test_register():
    assert NAME not in codecs.__dict__
    assert NAME not in codecs.__dict__['__builtins__']['__dict__']

    codecs.register(_get_codec_info)

    assert isinstance(codecs.__dict__[NAME], codecs.CodecInfo)
    assert isinstance(codecs.__dict__['__builtins__']['__dict__'][NAME], codecs.CodecInfo)



# Generated at 2022-06-25 17:10:56.561474
# Unit test for function register
def test_register():
    obj = codecs.lookup(NAME)
    assert obj is not None


# Generated at 2022-06-25 17:11:00.694730
# Unit test for function register
def test_register():
    reg1 = codecs.getdecoder(NAME)
    register()
    reg2 = codecs.getdecoder(NAME)
    assert reg1 == reg2

# Generated at 2022-06-25 17:11:01.638819
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:11:11.834273
# Unit test for function register
def test_register():

    # Get the current encode
    original_encode = getattr(__builtins__, 'encode', None)  # type: ignore

    ORIGINAL_ENCODE_IS_PRESENT = True
    if original_encode is None:
        ORIGINAL_ENCODE_IS_PRESENT = False

    ORIGINAL_ENCODE_IS_OVERRIDDEN = False
    if 'encode' in globals():
        ORIGINAL_ENCODE_IS_OVERRIDDEN = True


# Generated at 2022-06-25 17:11:14.624602
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-25 17:11:19.779912
# Unit test for function register
def test_register():
    # Make sure that the function 'encode' is registered
    import codecs
    codecs.getencoder(NAME)
    # Make sure that the function 'decode' is registered
    codecs.getdecoder(NAME)


# Generated at 2022-06-25 17:11:27.108953
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:11:28.622431
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:11:29.598817
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:11:34.252096
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:11:37.445251
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        # noinspection PyUnreachableCode
        assert False
    else:
        assert True



# Generated at 2022-06-25 17:11:38.633609
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:11:39.416036
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:11:41.396789
# Unit test for function register
def test_register():
    assert register() is None



# Generated at 2022-06-25 17:11:47.219617
# Unit test for function register
def test_register():
    import sys
    import pathlib
    sys.path.insert(0, str(pathlib.Path(__file__).parent.absolute()))

    from test import test_module_register
    test_module_register.test(NAME, register)



# Generated at 2022-06-25 17:12:00.442912
# Unit test for function register
def test_register():
    # Call 'register' here, so that it's already registered for the
    # 'encode' and 'decode' functions below.
    register()
    text = '华人／华人民共和国＠あいうえお'
    text_encoded = text.encode('eutf8h')

# Generated at 2022-06-25 17:12:05.899791
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    register()

# Generated at 2022-06-25 17:12:07.776124
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:12:12.623471
# Unit test for function register
def test_register():
    # Make sure that the codec isn't already registered.
    # This test shouldn't fail because the codec wasn't registered yet.
    with pytest.raises(LookupError):
        __ = codecs.getdecoder(NAME)

    # Register the codec
    register()

    # The codec should now be registered.
    codecs.getdecoder(NAME)

    # The codec should now be registered.
    codecs.getencoder(NAME)



# Generated at 2022-06-25 17:12:13.674651
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


test_case_0()

# Generated at 2022-06-25 17:12:17.107327
# Unit test for function register
def test_register():
    """A test for the 'register' function

    """
    register()



# Generated at 2022-06-25 17:12:17.711663
# Unit test for function register
def test_register():
    pass

# Generated at 2022-06-25 17:12:18.792527
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:12:28.304405
# Unit test for function register
def test_register():
    """
    Tests that function register works properly.
    """

    # Arrange
    test_register.out = ''
    test_register.decode = None
    test_register.encode = None

    # Act
    register()

    # Assert
    try:
        test_register.encode = codecs.getencoder(NAME)
    except LookupError:
        print('Failed to get encoder.')
        return


# Generated at 2022-06-25 17:12:29.245509
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:12:33.220881
# Unit test for function register
def test_register():
    assert NAME not in codecs.encode.__code__.co_varnames



# Generated at 2022-06-25 17:12:45.266904
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:12:47.421761
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:12:58.050910
# Unit test for function register
def test_register():

    # Setup
    module = __name__
    module_name = module.split('.')[-1]
    function_name = 'register'

    # Exercise
    exec(
        f'def test_func():\n'
        f'    {module}.{function_name}()\n',
        globals(),
        locals(),
    )
    exec(
        f'import {module}\n'
        f'{module}.{function_name}()\n',
        globals(),
        locals(),
    )
    test_func()

    # Verification
    _ = codecs.getdecoder(module_name)
    _ = codecs.getencoder(module_name)

    # Cleanup
    pass



# Generated at 2022-06-25 17:13:08.274089
# Unit test for function register
def test_register():
    register()

    cases = [
        ('utf8h', NAME),
        ('eutf8h', NAME),
        ('\\xef\\xbf\\xbd\\xef\\xbf\\xbd', '\\xef\\xbf\\xbd\\xef\\xbf\\xbd'),
    ]

    for case in cases:
        name = case[0]
        codec = case[1]
        print(name, codec)

        try:
            codec = codecs.getdecoder(name)
            print(codec)
        except LookupError:
            print('not found')

        try:
            codec = codecs.getencoder(name)
            print(codec)
        except LookupError:
            print('not found')



# Generated at 2022-06-25 17:13:09.147677
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:13:14.145403
# Unit test for function register
def test_register():
    # pylint: disable=unused-import
    import codecs
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:13:19.620808
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError('codec already registered')
    register()
    codecs.getencoder(NAME)  # shouldn't raise exception
    codecs.getdecoder(NAME)  # shouldn't raise exception



# Generated at 2022-06-25 17:13:20.949527
# Unit test for function register
def test_register():
    from eutf8h import register
    register()



# Generated at 2022-06-25 17:13:22.092344
# Unit test for function register
def test_register():

    # No exception expected
    register()
    register()



# Generated at 2022-06-25 17:13:22.877981
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:13:46.073819
# Unit test for function register
def test_register():
    """
    Unit test for function :mod:`register`.
    """
    register()
    codecs.register(_get_codec_info)
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:13:53.090399
# Unit test for function register
def test_register():
    import sys
    import io

    # If the module hasn't been registered, it will raise an exception.
    if NAME not in sys.stdout.encoding:
        sys.stdout = io.TextIOWrapper(
            sys.stdout.buffer,
            encoding=NAME,
            errors='strict',
            write_through=True,
        )


# Generated at 2022-06-25 17:14:07.239529
# Unit test for function register
def test_register():
    # Ensure that each test case is independent.
    sys.modules.pop('test_eutf8h', None)
    import test_eutf8h
    test_eutf8h.test_case_0()
    sys.modules.pop('test_eutf8h', None)

    import csv
    csv_tuple = None
    try:
        with open('/tmp/test_csv_reader.csv', 'r') as f:
            csv_reader = csv.reader(f)
            csv_tuple = next(csv_reader)
    except FileNotFoundError:
        with open('/tmp/test_csv_reader.csv', 'w') as f:
            csv_writer = csv.writer(f)

# Generated at 2022-06-25 17:14:08.221915
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:14:09.353036
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:14:13.084684
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()



# Generated at 2022-06-25 17:14:15.020721
# Unit test for function register
def test_register():
    from . import eutf8h

    eutf8h.register()

    try:
        codecs.getdecoder(eutf8h.NAME)
    except LookupError:
        assert False



# Generated at 2022-06-25 17:14:17.090127
# Unit test for function register
def test_register():
    """
    Test function register
    """
    register()

# Generated at 2022-06-25 17:14:18.631968
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:14:19.604316
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:14:57.077557
# Unit test for function register
def test_register():
    try:
        test_case_0()
    except Exception as err:
        print(f'Test case 0 failed ({err})')
        assert False
    else:
        print('Test case 0 passed')



# Generated at 2022-06-25 17:15:02.708339
# Unit test for function register
def test_register():
    try:
        codecs.getencoder(NAME)
    except LookupError:
        # https://github.com/python/cpython/blob/master/Lib/test/test_codecs.py#L358
        raise Exception('register function has not registered the codec')



# Generated at 2022-06-25 17:15:03.400388
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-25 17:15:06.091225
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


# Generated at 2022-06-25 17:15:09.935527
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
        assert False, 'Should not have previously existed.'
    except LookupError:
        pass

    register()

    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:15:10.907664
# Unit test for function register
def test_register():
    reg = register()
    assert reg is None

# Generated at 2022-06-25 17:15:16.929700
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(
            "The codec name '%s' could not be retrieved by "
            "the codecs.getdecoder() function."
            % NAME
        )



# Generated at 2022-06-25 17:15:18.569547
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)


# Generated at 2022-06-25 17:15:21.825923
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:15:27.895696
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getencoder(NAME)
    except LookupError:
        raise Exception('Codec must be registered')
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise Exception('Codec must be registered')



# Generated at 2022-06-25 17:16:53.482866
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:16:58.485044
# Unit test for function register
def test_register():
    """Verify that the codec is registered."""
    register()
    try:
        codecs.getencoder(NAME)
    except LookupError:
        raise AssertionError(
            'Failed to register the eutf8h codec.'
        )



# Generated at 2022-06-25 17:16:59.634428
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:17:02.074219
# Unit test for function register
def test_register():
    register()

    # Make sure codec is actually registered.
    assert codecs.getdecoder(NAME), 'Codec not registered.'



# Generated at 2022-06-25 17:17:07.091275
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
    assert codecs.lookup(NAME) == _get_codec_info(NAME)



# Generated at 2022-06-25 17:17:11.389014
# Unit test for function register
def test_register():
    ##############################################
    #
    # Test Case 0:
    #   register()
    #
    ##############################################
    test_case_0()

    ##############################################
    #
    # Test Case 1:
    #   codecs.register(_get_codec_info)
    #
    ##############################################
    codecs.register(_get_codec_info)   # type: ignore



# Generated at 2022-06-25 17:17:12.596354
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:17:18.301655
# Unit test for function register
def test_register():
    """
    Test register
    """
    register()
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)
    # codecs.lookup(NAME)


# Generated at 2022-06-25 17:17:23.431467
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()
        assert True
        return
    assert False


# Generated at 2022-06-25 17:17:27.551508
# Unit test for function register
def test_register():
    try:
        codecs.getencoder(NAME)
    except LookupError:
        assert False, 'Did not register the codec'
    else:
        assert True, 'Registered the codec'


# Unit tests for function decode