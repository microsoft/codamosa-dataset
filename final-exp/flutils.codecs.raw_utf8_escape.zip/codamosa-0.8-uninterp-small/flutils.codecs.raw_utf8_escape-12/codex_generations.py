

# Generated at 2022-06-25 17:10:43.230527
# Unit test for function register
def test_register():
    #  Import the built-ins
    from json import loads as _loads, dumps as _dumps
    from io import BytesIO

    #  Import the functions
    from eutf8h import encode, decode

    text = r'\\x61\u0061\\x62\x62'

    expected_str = 'aab'
    expected_bytes = b'\\x61a\\x62b'

    out_str = text.encode(NAME).decode(NAME)
    assert out_str == expected_str

    out_bytes = expected_str.encode(NAME)
    assert out_bytes == expected_bytes

    out_str = decode(expected_bytes, errors='strict')[0]
    assert out_str == expected_str

    out_bytes = encode(out_str, errors='strict')[0]

# Generated at 2022-06-25 17:10:44.317603
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:10:52.715728
# Unit test for function register
def test_register():
    from contextlib import redirect_stdout
    from io import StringIO
    import unittest

    class TestRegister(unittest.TestCase):
        def test_register(self):
            _actual_out: StringIO = StringIO()

            with redirect_stdout(_actual_out):
                register()

            _expected_out = ''

            self.assertEqual(_actual_out.getvalue().strip(), _expected_out)

    unittest.main()



# Generated at 2022-06-25 17:11:01.025097
# Unit test for function register
def test_register():
    # Arrange
    import codecs
    import importlib
    importlib.reload(codecs)
    # register()

    # Act
    actual = codecs.getdecoder('eutf8h')

    # Assert
    expected = (
        '[<function decode at 0x7fdae6ea8c80>, '
        '<function encode at 0x7fdae6ea8e18>]'
    )
    assert str(actual).replace(' ', '') == expected

# Generated at 2022-06-25 17:11:02.387570
# Unit test for function register
def test_register():

    # This should succeed
    register()

    # This should fail
    register()

# Generated at 2022-06-25 17:11:03.238846
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:11:08.710867
# Unit test for function register
def test_register():

    # Arrange
    register()

    # Act
    codecs.lookup(NAME)

    # Assert
    assert True



# Generated at 2022-06-25 17:11:09.739273
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:11:10.706622
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:11:12.423609
# Unit test for function register
def test_register():
    register()

    obj = codecs.getdecoder(NAME)
    assert obj is not None



# Generated at 2022-06-25 17:11:20.530637
# Unit test for function register
def test_register():
    register()
    decoder_info = codecs.getdecoder(NAME)
    assert NAME == decoder_info.name
    # assert decode == decoder_info.decode  # type: ignore[unreachable,comparison-overlap]
    # assert encode == decoder_info.encode  # type: ignore[unreachable,comparison-overlap]



# Generated at 2022-06-25 17:11:21.399362
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:11:22.026219
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME) is not None



# Generated at 2022-06-25 17:11:27.210256
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder('eutf8h')
    except LookupError:
        test_case_0()
        try:
            codecs.getdecoder('eutf8h')  # type: ignore
        except LookupError:
            assert False, 'Could not find encoding: eutf8h'



# Generated at 2022-06-25 17:11:28.980864
# Unit test for function register
def test_register():
    """
    Duplicate registration is ok.
    """
    register()
    register()



# Generated at 2022-06-25 17:11:32.827204
# Unit test for function register
def test_register():
    try:
        test_case_0()
    except LookupError:
        assert False
    assert True

# Generated at 2022-06-25 17:11:34.800383
# Unit test for function register
def test_register():
    # This test checks to see if the codec is registered.
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:11:38.632409
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)  # type: ignore



# Generated at 2022-06-25 17:11:45.300287
# Unit test for function register
def test_register():
    text = 'foo'
    encoded = '\\x66\\x6f\\x6f'
    encoded_bytes = encoded.encode('ascii')
    decoded_bytes, consumed_bytes = codecs.escape_decode(encoded_bytes)
    decoded_str = decoded_bytes.decode('utf8')
    assert text == decoded_str
    assert len(encoded_bytes) == consumed_bytes



# Generated at 2022-06-25 17:11:47.030312
# Unit test for function register
def test_register():
    register()
    _ = codecs.getencoder(NAME)
    _ = codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:11:51.248065
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:11:54.813692
# Unit test for function register
def test_register():
    register()
    #
    # Should succeed.
    #
    codecs.decode('foo', 'eutf8h')



# Generated at 2022-06-25 17:11:56.885898
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME) is not None



# Generated at 2022-06-25 17:11:57.868275
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:12:00.874401
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:12:02.052065
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:12:03.573122
# Unit test for function register
def test_register():
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 17:12:04.669268
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:12:05.527335
# Unit test for function register
def test_register():
    register()   # type: ignore



# Generated at 2022-06-25 17:12:11.884921
# Unit test for function register
def test_register():
    assert codecs.encode('abcd', 'eutf8h') == b'\\x61\\x62\\x63\\x64'
    assert codecs.decode(b'\\x61\\x62\\x63\\x64', 'eutf8h') == 'abcd'

# Generated at 2022-06-25 17:12:18.948849
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:12:20.007074
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:12:21.216636
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:12:30.504935
# Unit test for function register
def test_register():
    codec = 'eutf8h'
    try:
        codecs.lookup(codec)
    except LookupError:
        r = False
    else:
        r = True
    assert r is False

    register()

    try:
        codecs.lookup(codec)
    except LookupError:
        r = False
    else:
        r = True
    assert r is True


# Generated at 2022-06-25 17:12:31.435086
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:12:32.993887
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:12:37.988690
# Unit test for function register
def test_register():
    # Assign
    codec_info = codecs.lookup(NAME)

    # Act
    encode_func = codec_info.encode('')
    decode_func = codec_info.decode(b'')

    # Assert
    assert encode_func == encode
    assert decode_func == decode



# Generated at 2022-06-25 17:12:39.903954
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()



# Generated at 2022-06-25 17:12:42.196695
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getencodings()



# Generated at 2022-06-25 17:12:42.962689
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:13:02.521320
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        _ = codecs.getencoder(NAME)


if __name__ == '__main__':
    test_register()
    s = 'ls'
    b = encode(s)[0]
    # print(encode(s))
    # print(b)
    print(decode(b))

# Generated at 2022-06-25 17:13:06.568278
# Unit test for function register
def test_register():
    from pytest import raises

    with raises(LookupError):
        codec = codecs.getdecoder(NAME)

    register()

    codec = codecs.getdecoder(NAME)
    assert codec is not None


# Generated at 2022-06-25 17:13:07.907485
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:13:15.046445
# Unit test for function register
def test_register():

    codecs.register(_get_codec_info)   # type: ignore
    codecs.getdecoder(NAME)  # type: ignore
    codecs.getencoder(NAME)  # type: ignore



# Generated at 2022-06-25 17:13:18.889171
# Unit test for function register
def test_register():
    # noinspection PyUnresolvedReferences
    assert decode(b'\\xe2\\x82\\xac') == ('\u20ac', 11)



# Generated at 2022-06-25 17:13:19.814603
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:13:20.821610
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:13:24.423859
# Unit test for function register
def test_register():
    try:
        codecs.getencoder(NAME)
    except LookupError:
        assert False
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False
    assert True



# Generated at 2022-06-25 17:13:25.752001
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:13:26.776203
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:14:04.209474
# Unit test for function register
def test_register():
    # Save original state of the codecs module.
    old_getdecoder = codecs.getdecoder
    codecs.getdecoder = None

    # Register the codecs.
    register()

    # Check that the new getdecoder is installed.
    assert codecs.getdecoder(NAME) != old_getdecoder

    # Restore original state of the codecs module.
    codecs.getdecoder = old_getdecoder



# Generated at 2022-06-25 17:14:10.013823
# Unit test for function register
def test_register():
    if __name__ == "__main__":
        register()

# Generated at 2022-06-25 17:14:12.470932
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:14:15.425809
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore



# Generated at 2022-06-25 17:14:17.093169
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:14:18.681796
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:14:23.520340
# Unit test for function register
def test_register():
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)
    register()
    codecs.getdecoder(NAME)
    # Should not raise the LookupError.
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:14:31.011393
# Unit test for function register
def test_register():
    msg = None
    try:
        register()
    except Exception as e:
        msg = f'Exception: {e}'
    assert msg is None, msg


# Generated at 2022-06-25 17:14:33.900004
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME) is encode  # type: ignore
    assert codecs.getdecoder(NAME) is decode  # type: ignore



# Generated at 2022-06-25 17:14:35.801730
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:15:31.733560
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:15:41.517513
# Unit test for function register
def test_register():
    from io import StringIO
    from sys import stderr
    from types import ModuleType

    # Save the old stderr
    # noinspection PyTypeChecker
    old_stderr: StringIO = stderr

    # Create a new object for stderr
    # noinspection PyTypeChecker
    stderr: StringIO = StringIO()

    # Assign the new stderr
    sys.stderr = stderr

    # Get the codecs module
    codecs_mod = sys.modules[codecs.__name__]

    # Mock the codecs.register function
    def codecs_register(codec_info: codecs.CodecInfo) -> None:     # type: ignore[no-redef]
        assert isinstance(codec_info, codecs.CodecInfo)

   

# Generated at 2022-06-25 17:15:47.623142
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert True
    else:
        assert False
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False
    else:
        assert True


# Generated at 2022-06-25 17:15:57.521398
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        assert codecs.getdecoder(NAME) is not None
    else:
        assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-25 17:15:59.949215
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:16:07.055386
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()


# Generated at 2022-06-25 17:16:09.039536
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    test_case_0()
    test_register()

# Generated at 2022-06-25 17:16:10.058633
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:16:13.128155
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 17:16:14.150673
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-25 17:18:43.668773
# Unit test for function register
def test_register():

    # Invalid type can't be registered
    def test():
        codecs.register(lambda name: None)

    test.expected_exception = TypeError
    with raises(test):
        register()



# Generated at 2022-06-25 17:18:45.681689
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        pass



# Generated at 2022-06-25 17:18:47.368919
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-25 17:18:49.474103
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:18:55.340430
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:19:00.302750
# Unit test for function register
def test_register():
    expected_codec_name = __name__.split('.')[-1]
    codecs.register(_get_codec_info)

    assert codecs.lookup(expected_codec_name) is not None


# Given a str type, this function returns the number of utf8 bytes
# that would be required to encode the given str type.

# Generated at 2022-06-25 17:19:02.786146
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder('eutf8h')
        assert True
    except LookupError:
        assert False



# Generated at 2022-06-25 17:19:04.386236
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:19:06.202725
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:19:07.623315
# Unit test for function register
def test_register():
    test_case_0()
