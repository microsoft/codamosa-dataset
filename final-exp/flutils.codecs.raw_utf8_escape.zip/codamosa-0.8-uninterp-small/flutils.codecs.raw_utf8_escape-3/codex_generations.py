

# Generated at 2022-06-25 17:10:43.127931
# Unit test for function register
def test_register():
    test_case_0()

    expected_codec_info = codecs.CodecInfo(
        name='eutf8h',
        encode=encode,
        decode=decode,
    )
    actual_codec_info = codecs.CodecInfo(
        name='eutf8h',
        encode=encode,
        decode=decode,
    )

# Generated at 2022-06-25 17:10:48.090396
# Unit test for function register
def test_register():
    register()
    # Test if the encoder exists
    try:
        codecs.getencoder(NAME)
    except LookupError:
        raise AssertionError('Codec does not exist')
    # Test if the decoder exists
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError('Codec does not exist')


# Generated at 2022-06-25 17:10:52.046859
# Unit test for function register
def test_register():
    # Call function with no args.
    try:
        test_case_0()
    except Exception as e:
        assert False, f'Exception: {e}'


# Generated at 2022-06-25 17:10:52.991471
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:10:58.484906
# Unit test for function register
def test_register():
    assert NAME not in codecs.__dict__  # Test that this was not previously loaded.
    register()
    codecs.getencoder(NAME)  # Test that this is a registered encoder.
    codecs.getdecoder(NAME)  # Test that this is a registered decoder.

# Generated at 2022-06-25 17:10:59.402421
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:11:00.344337
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:11:01.407795
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:11:02.472122
# Unit test for function register
def test_register():
    pass


# Generated at 2022-06-25 17:11:05.493212
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-25 17:11:18.477960
# Unit test for function register
def test_register():
    """
    Test the function register.
    The function adds a decoder to the dictionary of codecs.
    :return: None
    """
    register()  # type: ignore
    # Creating a file to write escaped utf8 hexadecimal bytes
    orig_file_path = 'orig.txt'

# Generated at 2022-06-25 17:11:20.313052
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getencodings()


# unit test for function decode

# Generated at 2022-06-25 17:11:21.615962
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME)



# Generated at 2022-06-25 17:11:29.353451
# Unit test for function register
def test_register():

    # Test case 0: Register the codec
    test_case_0()

    # Test case 1: Register the codec a second time
    test_case_0()

    # Test case 2: Verify that the codec can be retrieved
    item = codecs.getdecoder(NAME)  # type: ignore
    assert item
    assert isinstance(item, tuple)
    assert callable(item[0])

    # Test case 3: Decode the codec
    in_bytes = b'\\x61\\x20abcd'
    out, out_length = item[0](in_bytes)
    assert out == '\\x61 abcd'
    assert out_length == len(in_bytes)



# Generated at 2022-06-25 17:11:34.953937
# Unit test for function register
def test_register():
    """test_register()
    """
    codec_names = codecs.list_encodings()
    assert NAME not in codec_names

    register()
    codec_names = codecs.list_encodings()
    assert NAME in codec_names



# Generated at 2022-06-25 17:11:42.655598
# Unit test for function register
def test_register():
    register()
    from collections import namedtuple
    CodInfo = namedtuple('CodInfo', 'name encode decode')
    codinfo_eutf8h = CodInfo(
        name=NAME,
        encode=encode,
        decode=decode,
    )
    assert codecs.lookup(NAME) == codinfo_eutf8h


# Generated at 2022-06-25 17:11:43.511296
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:11:56.160428
# Unit test for function register
def test_register():
    my_name = 'eutf8h'
    codecs.register(_get_codec_info)   # type: ignore
    try:
        codecs.getencoder(my_name)
        codecs.getdecoder(my_name)
    except LookupError:
        raise AssertionError(
            'codecs.getencoder(), codecs.getdecoder() returned LookupError',
        )

# Generated at 2022-06-25 17:11:57.206727
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:12:00.299308
# Unit test for function register
def test_register():
    if NAME not in codecs.__dict__['__all__']:  # type: ignore
        register()
    assert NAME in codecs.__dict__['__all__']  # type: ignore



# Generated at 2022-06-25 17:12:02.880919
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:12:03.578356
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-25 17:12:04.956370
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()
    else:
        pass

# Generated at 2022-06-25 17:12:05.820235
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:12:10.130711
# Unit test for function register
def test_register():
    register()

    assert codecs.getdecoder(NAME)

    assert codecs.getencoder(NAME)



# Generated at 2022-06-25 17:12:12.023583
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert True



# Generated at 2022-06-25 17:12:15.890715
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:12:17.628967
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:12:22.681323
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError('register() failed')
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError('register() failed')
    else:
        pass


# Generated at 2022-06-25 17:12:28.688391
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()

    test_bytes = b'\\\\x41\\\\x42\\\\x43\\\\x44\\\\x45\\\\x46'
    # This test raises an exception if the decoder is not registered.
    demo_obj = codecs.getdecoder(NAME)  # type: ignore
    out, size = demo_obj(test_bytes)
    assert out == 'ABCDEF'
    assert size == len(test_bytes)



# Generated at 2022-06-25 17:12:32.858222
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:12:34.447038
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:12:36.970491
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-25 17:12:41.619672
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:12:47.834282
# Unit test for function register
def test_register():
    register()

    # Check that the codecs defined in this module exist.
    assert codecs.getencoder(NAME)
    assert codecs.getdecoder(NAME)
    assert codecs.getincrementalencoder(NAME)
    assert codecs.getincrementaldecoder(NAME)



# Generated at 2022-06-25 17:12:50.598860
# Unit test for function register
def test_register():
    try:
        register()
    except Exception as e:
        raise AssertionError('function register raised an exception'.format(e))



# Generated at 2022-06-25 17:12:52.214753
# Unit test for function register
def test_register():
    register()
    codecs.lookup(NAME)


# Generated at 2022-06-25 17:12:54.618561
# Unit test for function register
def test_register():
    # Test that the codecs cache has no record of this codec.
    codecs.register(_get_codec_info)   # type: ignore



# Generated at 2022-06-25 17:12:57.093482
# Unit test for function register
def test_register():
    # Function is called and nothing happens
    register()



# Generated at 2022-06-25 17:12:58.324516
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:13:05.936760
# Unit test for function register
def test_register():
    for _ in range(4):
        test_case_0()



# Generated at 2022-06-25 17:13:10.200409
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)

    try:
        codecs.getencoder('z')
    except LookupError as e:
        pass

    try:
        codecs.getdecoder('z')
    except LookupError as e:
        pass



# Generated at 2022-06-25 17:13:13.385857
# Unit test for function register
def test_register():
    # the function is expected to not raise an exception
    register()



# Generated at 2022-06-25 17:13:15.759327
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
    assert codecs.getdecoder(NAME) is not None


# noinspection SpellCheckingInspection

# Generated at 2022-06-25 17:13:18.232111
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:13:20.349988
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-25 17:13:23.222453
# Unit test for function register
def test_register():
    try:
        codecs.getencoder(NAME)
    except LookupError:
        assert False

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False



# Generated at 2022-06-25 17:13:25.162831
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:13:25.894664
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:13:36.848879
# Unit test for function register
def test_register():
    """Unit tests for the function :func:`register`."""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise Exception
    finally:
        try:
            codecs.lookup(NAME)
            codecs.lookup_error(NAME)
            codecs.lookup_error(NAME + '_error')
        except LookupError:
            raise Exception from None



# Generated at 2022-06-25 17:13:51.982066
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        assert hasattr(codecs, 'getdecoder')



# Generated at 2022-06-25 17:13:56.655462
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.__dict__['__all__']
    assert NAME in codecs.__dict__['__codecs']
    assert NAME in codecs.__dict__['__aliases']
    assert codecs.__dict__['__codecs'][NAME].__name__ == 'CodecInfo'



# Generated at 2022-06-25 17:13:58.247814
# Unit test for function register
def test_register():
    print('Testing function register')
    test_case_0()


# Generated at 2022-06-25 17:14:04.659063
# Unit test for function register
def test_register():

    data_in = "Hello\nWorld!"
    register()
    data_out = data_in.encode(NAME)

    data_out_expected = data_in.encode('utf-8')

    assert data_out_expected == data_out, data_out



# Generated at 2022-06-25 17:14:14.924221
# Unit test for function register
def test_register():
    # Method 1: unit tests
    test_case_0()

    # Method 2: doctest
    import doctest
    import sys
    from pathlib import Path
    from typing import Optional
    from typing import Sequence

    # Find the path of this file/module
    path = Path(__file__)

    # Find the code of this file/module
    # noinspection PyBroadException
    with open(path, 'r', encoding='utf-8') as file:
        code: str = file.read()
        # The test file may contain the main() function
        # which will be executed.
        # So, we will make a copy of the code, and
        # remove the main() function code, so that
        # it won't be executed.
        # The main() function will be restored at the
        # end of this test function.


# Generated at 2022-06-25 17:14:18.834378
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-25 17:14:23.350659
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()
    assert codecs.getdecoder(NAME) == _get_codec_info(NAME)


# Generated at 2022-06-25 17:14:27.873468
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)



# Generated at 2022-06-25 17:14:32.021561
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:14:33.493268
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-25 17:15:04.355046
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
        raise Exception('test_register')
    except LookupError:
        pass
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:15:06.767191
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:15:08.638425
# Unit test for function register
def test_register():
    # Test that the variable 'register' is callable
    assert callable(register)



# Generated at 2022-06-25 17:15:11.090379
# Unit test for function register
def test_register():
    """
    Test that the module is registered with the system codecs.
    """
    codecs.lookup_error('eutf8h')



# Generated at 2022-06-25 17:15:12.129524
# Unit test for function register
def test_register():
    codecs.getencoder(NAME)



# Generated at 2022-06-25 17:15:15.205396
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:15:17.842015
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
    return codecs.getdecoder(NAME)


# Generated at 2022-06-25 17:15:21.920935
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)
    assert codecs.getincrementalencoder(NAME)
    assert codecs.getincrementaldecoder(NAME)


# Generated at 2022-06-25 17:15:23.902747
# Unit test for function register
def test_register():
    assert codecs.getdecoder(NAME)


# Generated at 2022-06-25 17:15:28.110021
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:16:31.041478
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-25 17:16:32.222055
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:16:36.216089
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getencoder(NAME)
    except LookupError:
        assert False, 'encoder not installed'
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'decoder not installed'



# Generated at 2022-06-25 17:16:42.286046
# Unit test for function register
def test_register():

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise Exception(f"'{NAME}' codec should have been registered")



# Generated at 2022-06-25 17:16:46.221258
# Unit test for function register
def test_register():
    """Unit test for function :mod:`~codec_eutf8h.register`."""
    register()
    assert codecs.lookup(NAME) is not None


# Generated at 2022-06-25 17:16:49.415598
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getencoder(NAME)  # type: ignore
    assert NAME in codecs.getdecoder(NAME)  # type: ignore


# Generated at 2022-06-25 17:16:50.253799
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:16:52.780293
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        assert False, \
            f'Codec name={NAME} was not registered: {str(e)}'



# Generated at 2022-06-25 17:16:57.693139
# Unit test for function register
def test_register():
    try:
        codecs.lookup(NAME)
    except LookupError:
        register()
        codecs.lookup(NAME)

# Generated at 2022-06-25 17:17:02.039436
# Unit test for function register
def test_register():
    from codecs import lookup
    from types import CodeType

    # Check that ``NAME`` is registered.
    assert lookup(NAME) is not None

    # Check that ``NAME`` is a codec.
    assert lookup(NAME).__class__ is CodeType


# Generated at 2022-06-25 17:19:22.890952
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)


# Generated at 2022-06-25 17:19:24.498591
# Unit test for function register
def test_register():
    # return a codec info object if the codec exists
    assert codecs.getencoder(NAME) is not None

# Generated at 2022-06-25 17:19:30.287253
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
    obj = codecs.getdecoder(NAME)

    assert obj.name == NAME
    assert obj.encode is not None
    assert obj.decode is not None



# Generated at 2022-06-25 17:19:33.086729
# Unit test for function register
def test_register():
    text = 'Hello'
    bytes_encoded = text.encode(NAME)
    assert text == bytes_encoded.decode(NAME)



# Generated at 2022-06-25 17:19:38.456519
# Unit test for function register
def test_register():
    try:
        import sys
        del sys.modules['eutf8h']
        test_case_0()
    except KeyError:
        test_case_0()
    except ImportError:
        test_case_0()
    finally:
        import sys
        import eutf8h
        sys.modules['eutf8h'] = eutf8h


# Generated at 2022-06-25 17:19:39.389431
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:19:40.252602
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:19:41.481202
# Unit test for function register
def test_register():
    test_case_0()
    real_import('eutf8h')


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-25 17:19:46.139098
# Unit test for function register
def test_register():
    test_case_0()

###############################################################################
if __name__ == '__main__':
    test_register()

# Generated at 2022-06-25 17:19:46.800976
# Unit test for function register
def test_register():
    test_case_0()