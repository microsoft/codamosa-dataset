

# Generated at 2022-06-25 17:10:34.113310
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False


# Generated at 2022-06-25 17:10:38.938975
# Unit test for function encode
def test_encode():
    src_text = 'hello world!'
    exp_bytes = b'hello world!'
    exp_int = 12

    actual_bytes, actual_int = encode(src_text)

    assert actual_bytes == exp_bytes
    assert actual_int == exp_int


# Generated at 2022-06-25 17:10:46.048702
# Unit test for function decode
def test_decode():
    s0: str
    s1: str
    i0: int
    i1: int

    # setup
    codecs.register(_get_codec_info)

    # case 0

# Generated at 2022-06-25 17:10:54.385730
# Unit test for function encode
def test_encode():
    register()
    text = 'Í\xee\x80\xb0\xef\xbf\xbd\xe2\x80\xa8\xee \xee\\xee'
    out_bytes, _ = codecs.encode(text, NAME)  # type: ignore[arg-type]
    assert out_bytes == b'\\xc3\\x8d\\xee\\x80\\xb0\\xef\\xbf\\xbd\\xe2' \
                        b'\\x80\\xa8\\xee \\xee\\\\xee'


# Generated at 2022-06-25 17:11:03.046027
# Unit test for function encode
def test_encode():
    register()
    assert encode('hello') == (b'hello', 5)
    assert encode('🦄') == (b'\\xF0\\x9F\\xA6\\x84', 1)
    assert encode('hello 🦄🍍') == (b'hello \\xF0\\x9F\\xA6\\x84\\xF0\\x9F\\x8D\\x8D', 9)
    # assert encode('🦄🍍') == (b'\\xF0\\x9F\\xA6\\x84\\xF0\\x9F\\x8D\\x8D', 2)
    # assert encode('\\xF0\\x9F\\xA6\\x84\\xF0\\x9F\\x8D\\x8D') == (b'\\xF0\\

# Generated at 2022-06-25 17:11:12.575157
# Unit test for function encode
def test_encode():
    # Test 0
    text = '0x00\\0xFFFF'
    result_bytes, result_len = text.encode(NAME)
    expected_bytes = bytes(b'0x30x7830x30\\\\0xFFFF')
    assert result_bytes == expected_bytes

    # Test 1
    text = '\\x00\\xFFFF'
    result_bytes, result_len = text.encode(NAME)
    expected_bytes = bytes(b'\\\\0x30x7830x30\\\\0xFFFF')
    assert result_bytes == expected_bytes

    # Test 2
    text = '\\x00\\uFFFF'
    result_bytes, result_len = text.encode(NAME)
    expected_bytes = bytes(b'\\\\0x30x7830x30\\\\uFFFF')

# Generated at 2022-06-25 17:11:18.019811
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getincrementalencoder(NAME) is not None
    assert codecs.getincrementaldecoder(NAME) is not None


# Generated at 2022-06-25 17:11:18.879108
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:11:26.840594
# Unit test for function decode
def test_decode():
    # Test for simple decode
    s = decode(b'\\x61\\x62\\x63')[0]
    assert(s == 'abc')
    # Test for decoding non-printable charaters
    s = decode(b'\\x0bab\\x01')[0]
    assert(s == '\x0bab\x01')
    # Test for decoding into surrogate pairs
    s = decode(b'\\xf0\\x90\\x80\\x80')[0]
    assert(s == '\U00010000')



# Generated at 2022-06-25 17:11:31.817401
# Unit test for function decode
def test_decode():

    test_str = 'hello world'
    test_str_hex = 'hello \x57orld'
    test_bytes = test_str_hex.encode('utf8')
    test_bytes_hex = 'hello \\x57orld'
    test_bytes_hex = test_bytes_hex.encode('utf8')

    assert test_str == decode(test_bytes, errors='replace')[0]
    assert test_str == decode(test_bytes, errors='ignore')[0]
    assert test_str == decode(test_bytes, errors='surrogateescape')[0]

    with pytest.raises(UnicodeDecodeError):
        decode(test_bytes, errors='strict')[0]

    assert test_str == decode(test_bytes_hex, errors='replace')[0]
    assert test_

# Generated at 2022-06-25 17:11:34.979080
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:11:36.897453
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:11:38.098098
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:11:41.086899
# Unit test for function register
def test_register():  # type: ignore
    register()
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:11:45.417323
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:11:47.504561
# Unit test for function register
def test_register():
    register()
    # Try to register again. The following line should not raise an error.
    register()
    print('Testing Function: register()', file=sys.stderr)



# Generated at 2022-06-25 17:11:50.911665
# Unit test for function register
def test_register():
    register()
    with pytest.raises(LookupError):
        codecs.getdecoder('NoneExisting')
    obj = codecs.getdecoder(NAME)
    assert obj is not None
    assert isinstance(obj, codecs.CodecInfo)
    assert obj.name == NAME
    assert isinstance(obj.encode, types.FunctionType)
    assert isinstance(obj.decode, types.FunctionType)



# Generated at 2022-06-25 17:11:52.963104
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME)
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:12:05.255152
# Unit test for function register
def test_register():
    # Test registering the encoding
    register()

    # Test obtaining the codec info
    codec_info = codecs.getdecoder(NAME)

    # Test the given codec info returns the correct encoding
    assert codec_info[1]("\u0411").decode(NAME) == '\\xd0\\x91'

    # Test the given codec info decodes correctly
    assert codec_info[0]("\\xd0\\x91".encode(NAME)).decode() == "\u0411"

    # Test that the given codec info throws an exception when given invalid
    # escaped utf8 hexadecimal.
    with pytest.raises(UnicodeDecodeError):
        codec_info[0]("\\xd0\x91".encode(NAME)).decode()

    # Test encoding to a file

# Generated at 2022-06-25 17:12:08.809244
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME) is not None


# Generated at 2022-06-25 17:12:11.394676
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:12:19.190721
# Unit test for function register
def test_register():
    from io import BytesIO
    from io import TextIOWrapper

    test_case_0()

    # Make sure the codec was register
    codecs.getdecoder(NAME)

    # Make sure the codec is able to decode
    text = textwrap.dedent("""
        s = '\u263a'
        print(s)
        """)
    buf = BytesIO()
    with TextIOWrapper(buf, NAME) as fp:
        fp.write(text)
    buf.seek(0)
    exec(buf.read().decode())

    # Make sure the codec is able to encode
    text = textwrap.dedent("""
        s = '\u263a'
        print(s)
        """).encode()
    buf = BytesIO()

# Generated at 2022-06-25 17:12:19.836806
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-25 17:12:21.796320
# Unit test for function register
def test_register():
    """
    Test the function register()
    """
    test_case_0()



# Generated at 2022-06-25 17:12:31.078777
# Unit test for function register
def test_register():
    # Test with only ASCII characters
    assert codecs.escape_decode(b'abc')[0].decode('utf-8') == 'abc'
    assert codecs.escape_decode(b'abc ')[0].decode('utf-8') == 'abc '
    assert codecs.escape_decode(b'abc >')[0].decode('utf-8') == 'abc >'
    assert codecs.escape_decode(b'abc > ')[0].decode('utf-8') == 'abc > '
    assert codecs.escape_decode(b'abc a')[0].decode('utf-8') == 'abc a'
    assert codecs.escape_decode(b'abc a ')[0].decode('utf-8') == 'abc a '
    assert codecs.escape_decode

# Generated at 2022-06-25 17:12:31.902970
# Unit test for function register
def test_register():

    test_case_0()



# Generated at 2022-06-25 17:12:37.377819
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getencoder(NAME)
        codecs.getdecoder(NAME)
        encoder_info = codecs.lookup(NAME)
        encoder_info.decode()
        encoder_info.encode()
    except LookupError:
        assert False


# Generated at 2022-06-25 17:12:39.412167
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME)
    assert codecs.getdecoder(NAME)


# Generated at 2022-06-25 17:12:41.611759
# Unit test for function register
def test_register():
    register()
    __import__('codecs').getdecoder(NAME)



# Generated at 2022-06-25 17:12:45.250449
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:12:52.021657
# Unit test for function register
def test_register():
    print('TESTING: {}.register'.format(NAME))
    register()
    try:
        assert codecs.getdecoder(NAME)
    except LookupError:
        raise


# Generated at 2022-06-25 17:12:52.992202
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:12:54.293442
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)



# Generated at 2022-06-25 17:12:58.221550
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:13:01.171348
# Unit test for function register
def test_register():
    """
    Test register.
    """
    test_case_0()


if __name__ == '__main__':
    # TODO: Use pytest and write unit tests
    test_register()

# Generated at 2022-06-25 17:13:02.154901
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:13:03.100392
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:13:05.320819
# Unit test for function register
def test_register():
    test_case_0()
    pass



# Generated at 2022-06-25 17:13:10.029217
# Unit test for function register
def test_register():
    # noinspection DuplicatedCode
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        codecs.register(_get_codec_info)   # type: ignore
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False
    else:
        assert True



# Generated at 2022-06-25 17:13:13.265492
# Unit test for function register
def test_register():
    register()
    codecs.lookup('eutf8h')



# Generated at 2022-06-25 17:13:22.545953
# Unit test for function register
def test_register():
    # Ensure that the entry doesn't exist.
    with pytest.raises(LookupError):
        codecs.getencoder(NAME)
    # Register the new codec
    register()
    # Test for the entry's existance
    a = codecs.getencoder(NAME)
    assert a is not None



# Generated at 2022-06-25 17:13:24.297143
# Unit test for function register
def test_register():  # noqa: D103
    test_case_0()

# Generated at 2022-06-25 17:13:25.531709
# Unit test for function register
def test_register():
    register()
    test_case_0()

# Generated at 2022-06-25 17:13:30.291569
# Unit test for function register
def test_register():
    register()
    # noinspection PyUnresolvedReferences
    codecs.getdecoder(NAME)

# Generated at 2022-06-25 17:13:31.189788
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:13:34.902128
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:13:38.334770
# Unit test for function register
def test_register():
    # Check that NAME is not already registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise RuntimeError('NAME should not be registered.')
    # Register NAME.
    register()
    # Check that NAME is registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise RuntimeError('NAME should be registered.')



# Generated at 2022-06-25 17:13:42.405525
# Unit test for function register
def test_register():
    try:
        register()
    except TypeError:
        print('TypeError on register()')
    except Exception as e:
        print('Exception on register():', type(e))


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-25 17:13:44.630151
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:13:56.932495
# Unit test for function register
def test_register():
    register()

    # Test whether the codec functions are successfully
    # registered.
    assert codecs.getencoder(NAME) == (encode, 0)
    assert codecs.getdecoder(NAME) == (decode, 0)

    # Test whether the codecs are registered in both codecs and
    # encodings modules.
    assert codecs.getencoder(NAME) == encodings.getencoder(NAME)
    assert codecs.getdecoder(NAME) == encodings.getdecoder(NAME)

    # Test whether the codec functions are successfully
    # registered with the str type.
    assert str.encode(str, NAME) is str.encode(str, NAME)
    assert str.decode(str, NAME) is str.decode(str, NAME)

    # Test whether the codec functions are successfully


# Generated at 2022-06-25 17:14:09.391677
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:14:10.509829
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:14:23.802664
# Unit test for function register
def test_register():
    obj = cast(codecs.CodecInfo, codecs.getencoder(NAME))

    actual = obj.encode('$', 'strict')
    expected = (b'$', 1)
    assert actual == expected

    actual = obj.encode('$', 'ignore')
    expected = (b'', 0)
    assert actual == expected

    actual = obj.encode(b'$', 'strict')
    expected = (b'\\x24', 1)
    assert actual == expected

    actual = obj.encode(b'$', 'ignore')
    expected = (b'', 0)
    assert actual == expected

    actual = obj.encode(b'\x24', 'strict')
    expected = (b'\\x24', 1)
    assert actual == expected


# Generated at 2022-06-25 17:14:24.612117
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:14:26.120832
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:14:26.907450
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:14:34.700622
# Unit test for function register
def test_register():
    # Register the codec
    register()

    # Check that the codec was registered properly.
    err = None
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        err = e

    assert err is None, (
        'The codec was not registered properly. The following error was '
        'raised:%s' % str(err)
    )



# Generated at 2022-06-25 17:14:49.334241
# Unit test for function register
def test_register():

    # Test that a TypeError is raised if no arguments are given.
    a = codecs.register  # type: ignore
    b = lambda: a()
    with pytest.raises(TypeError):
        b()

    # Test that a ValueError is raised if too few arguments are given.
    a = codecs.register  # type: ignore
    b = lambda: a(exact=1)
    with pytest.raises(ValueError):
        b()

    # Test that a ValueError is raised if too many arguments are given.
    a = codecs.register  # type: ignore
    b = lambda: a(exact=1, encode=2, decode=3, streamreader=4, streamwriter=5)
    with pytest.raises(ValueError):
        b()

    # Test that a TypeError is raised if

# Generated at 2022-06-25 17:14:50.301446
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:14:54.755314
# Unit test for function register
def test_register():
    register()
    try:
        a = codecs.getencoder(NAME)
        b = codecs.getdecoder(NAME)
    except LookupError:
        raise ValueError


# Generated at 2022-06-25 17:15:20.177217
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:15:23.038328
# Unit test for function register
def test_register():
    # Simply test that the function does not raise any exceptions
    register()


# Unit tests for function decode

# Generated at 2022-06-25 17:15:25.608682
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:15:28.661400
# Unit test for function register
def test_register():
    import codecs

    # Arrange
    # Act
    register()

    # Assert
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False
    assert True


# Test for function register

# Generated at 2022-06-25 17:15:29.343960
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-25 17:15:38.463568
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()


# Generated at 2022-06-25 17:15:42.350082
# Unit test for function register
def test_register():

    register()
    try:
        codecs.lookup(NAME)
    except LookupError:
        pytest.fail(
            'Could not find encoded utf8 hexadecimal codec in codecs '
            'registry: NAME: %s.' % NAME
        )



# Generated at 2022-06-25 17:15:43.535931
# Unit test for function register
def test_register():
    # Test for registered name
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:15:46.725513
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-25 17:15:51.010188
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:16:48.537955
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:16:53.483820
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:16:56.745176
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:16:58.394114
# Unit test for function register
def test_register():
    register()
    try:
        ob = codecs.getdecoder(NAME)
        assert ob.name == NAME
    except LookupError:
        assert False


# Generated at 2022-06-25 17:17:02.603912
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:  # type: ignore[no-untyped-call]
        msg = f"'{NAME}' codec could not be registered."
        raise LookupError(msg)



# Generated at 2022-06-25 17:17:06.342114
# Unit test for function register
def test_register():
    print('\nFunction: test_register')
    test_case_0()


if __name__ == '__main__':
    register()

# Generated at 2022-06-25 17:17:07.090231
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:17:10.131789
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)
    else:
        raise AssertionError('register function failed')

# Generated at 2022-06-25 17:17:11.246509
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:17:12.364613
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:19:39.150993
# Unit test for function register
def test_register():
    register()
    # Check the test case from the coder's documentation.
    text_in = 'test🐕test'
    text_out = 'test\\xf0\\x9f\\x90\\x95test'
    data_bytes = text_out.encode('utf8')
    out, bytes_consumed = codecs.decode(data_bytes, NAME)
    assert text_in == out
    assert bytes_consumed == len(data_bytes)
    data_bytes, bytes_consumed = codecs.encode(text_in, NAME)
    out_str = data_bytes.decode('utf8')
    assert text_out == out_str
    assert bytes_consumed == len(text_in)



# Generated at 2022-06-25 17:19:41.307865
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-25 17:19:46.139074
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False


# Generated at 2022-06-25 17:19:46.802219
# Unit test for function register
def test_register():
    assert callable(register)



# Generated at 2022-06-25 17:19:47.437413
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:19:53.330099
# Unit test for function register
def test_register():
    register()
    name = "eutf8h"
    codec = codecs.getdecoder(name)
    assert codec is not None
    assert isinstance(codec, tuple)
    assert codec[0].__name__ == decode.__name__
    assert codec[0].__self__.__class__.__name__ == "eutf8h"

# Generated at 2022-06-25 17:19:55.866604
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:20:00.992894
# Unit test for function register
def test_register():
    u_str = 'Hello World'
    out = encode(u_str)
    register()
    assert out == (b'Hello\\x20World', len(u_str))



# Generated at 2022-06-25 17:20:03.562405
# Unit test for function register
def test_register():
    assert NAME not in codecs.getdecoders()
    register()
    assert NAME in codecs.getdecoders()

# Generated at 2022-06-25 17:20:05.130877
# Unit test for function register
def test_register():

    # Check the codecs are registered.
    assert codecs.getdecoder(NAME)

