

# Generated at 2022-06-25 17:10:44.898516
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)

    r = codecs.getdecoder(NAME)
    assert isinstance(r, tuple)
    assert r[0] == decode
    assert r[1] == encode



# Generated at 2022-06-25 17:10:46.397091
# Unit test for function register
def test_register():
    register()
    codecs.lookup(NAME)



# Generated at 2022-06-25 17:10:51.319320
# Unit test for function register
def test_register():
    try:
        codecs.lookup(NAME)
    except LookupError:
        # Register the codec.
        register()
        assert codecs.lookup(NAME) is not None
        return True
    else:
        return True


# Generated at 2022-06-25 17:10:54.799778
# Unit test for function register
def test_register():
    """
    This function unit test the function named register().
    """
    try:
        # Unit test for function register()
        codecs.getdecoder(NAME)
    except LookupError as e:
        # If this error is raised, then the function named register()
        # did not actually register for some reason.
        assert False, e.args



# Generated at 2022-06-25 17:11:00.774013
# Unit test for function register
def test_register():
    # Test for when NAME is already registered
    # Remove NAME from the list of registered codecs
    if NAME in codecs.__all__:
        import copy
        codecs.__all__ = copy.copy(codecs.__all__)
        codecs.__all__.remove(NAME)

    test_case_0()

    assert NAME in codecs.__all__



# Generated at 2022-06-25 17:11:03.152492
# Unit test for function register
def test_register():
    from tests import utils as _utils
    test_case_0()
    # Should not fail.
    _utils.msg_test_success('test_register')


# Generated at 2022-06-25 17:11:05.928112
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()

# Generated at 2022-06-25 17:11:08.662245
# Unit test for function register
def test_register():
    test_case_0()
    # Test that it can be re-registered without errors.
    register()



# Generated at 2022-06-25 17:11:13.026409
# Unit test for function register
def test_register():
    try:
        # This should succeed.
        codecs.getdecoder(NAME)
    except LookupError:
        # If it fails, then this test case failed.
        raise AssertionError(
            'Failed to register escape-utf8-hexadecimal codec',
        )


# Generated at 2022-06-25 17:11:14.910441
# Unit test for function register
def test_register():
    register()
    obj = codecs.getdecoder(NAME)
    assert obj is not None


# Generated at 2022-06-25 17:11:21.317961
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 17:11:23.606270
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:11:26.999484
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:11:29.410387
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-25 17:11:34.728663
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-25 17:11:36.892415
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:11:38.097680
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:11:42.907553
# Unit test for function register
def test_register():
    t = codecs.getencoder(NAME)
    assert t[0](u'abc') == (b'abc', 3)


if __name__ == '__main__':
    from pytest import main

    main([__file__])

# Generated at 2022-06-25 17:11:43.990080
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:11:46.115750
# Unit test for function register
def test_register():
    test_case_0()

    # The 'eutf8h' codec is now registered. No error should be returned.
    test_case_1()


# Test cases for function encode

# Generated at 2022-06-25 17:11:56.633553
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:11:57.170403
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-25 17:11:58.140050
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:12:08.337945
# Unit test for function register
def test_register():
    # Test python 3.8
    try:
        codecs_cache = codecs.cache_gencodecs
    except AttributeError:
        pass
    else:
        codecs_cache.clear()
        register()
        assert NAME in codecs.cache_gencodecs
        codecs_cache.clear()
    # Test python 3.6, 3.7
    try:
        codecs_cache = codecs.cache
    except AttributeError:
        pass
    else:
        codecs_cache.clear()
        register()
        assert NAME in codecs.cache_gencodecs
        codecs_cache.clear()



# Generated at 2022-06-25 17:12:09.551430
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:12:11.585717
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# Generated at 2022-06-25 17:12:18.337320
# Unit test for function register
def test_register():
    """Test function :func:`register()`.
    """
    register()
    assert codecs.getdecoder('eutf8h') is not None


# Generated at 2022-06-25 17:12:21.879634
# Unit test for function register
def test_register():
    import codecs
    name = __name__.split('.')[-1]
    try:
        codecs.getencoder(name)
    except LookupError:
        register()
        codecs.getencoder(name)



# Generated at 2022-06-25 17:12:22.720054
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:12:28.065850
# Unit test for function register
def test_register():

    # Ensure that the NAME codec is not registered
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError('The NAME codec should not be registered')

    # Register the NAME codec
    register()

    # Make sure the NAME codec is registered
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:12:40.165149
# Unit test for function register
def test_register():
    assert not hasattr(codecs, 'getdecoder')
    test_case_0()
    assert hasattr(codecs, 'getdecoder')


# Generated at 2022-06-25 17:12:43.049374
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise RuntimeError('codec %s is not registered' % NAME)



# Generated at 2022-06-25 17:12:44.917048
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()



# Generated at 2022-06-25 17:12:53.324478
# Unit test for function register
def test_register():
    register()

    assert codecs.lookup_error('strict') == 'strict'

    assert codecs.getdecoder(NAME) == decode

    assert codecs.getencoder(NAME) == encode

    codecs.register(_get_codec_info)

    assert codecs.lookup_error('strict') == 'strict'

    assert codecs.getdecoder(NAME) == decode

    assert codecs.getencoder(NAME) == encode


# Test for function _each_utf8_hex

# Generated at 2022-06-25 17:12:59.618871
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder('eutf8h')
    except LookupError:
        pass
    else:
        raise AssertionError('The codec "eutf8h" has not been registered')

    register()

    try:
        codecs.getdecoder('eutf8h')
    except LookupError:
        raise AssertionError(
            'The codec "eutf8h" has been registered, but is not in the '
            'codec registry.'
        )
    else:
        pass



# Generated at 2022-06-25 17:13:01.298420
# Unit test for function register
def test_register():
    register()

    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-25 17:13:11.474672
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        assert False
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False



# Generated at 2022-06-25 17:13:14.838411
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()



# Generated at 2022-06-25 17:13:15.723676
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:13:18.163388
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:13:38.734814
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:13:41.941817
# Unit test for function register
def test_register():
    test_case_0()

    NAME = __name__.split('.')[-1]

    assert codecs.lookup(NAME) is not None



# Generated at 2022-06-25 17:13:44.286883
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:13:48.853563
# Unit test for function register
def test_register():
    try:
        register()
        codecs.getdecoder(NAME)
        assert True
    except LookupError:
        assert False, f'Unable to register codec: {NAME}.'



# Generated at 2022-06-25 17:13:50.294534
# Unit test for function register
def test_register():
    assert("eutf8h" in codecs.__dict__['_cache'])

# Generated at 2022-06-25 17:13:51.875746
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:13:52.997914
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:13:57.348362
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:13:58.380659
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:14:08.268778
# Unit test for function register
def test_register():
    # Check for function register
    assert callable(register)
    # Check for the name
    assert register.__name__ == 'register'
    # Check for the signature
    assert inspect.signature(register) == inspect.Signature()
    assert register() is None
    # Check for the name registered
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None
    # Check again
    register()
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-25 17:14:49.155167
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:14:50.179112
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:14:52.808980
# Unit test for function register
def test_register():
    register()
    # If registered, then the following will not cause a LookupError
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:14:57.504315
# Unit test for function register
def test_register():

    # Register the codec
    register()

    # This should not raise an error
    codecs.getdecoder(NAME)

    # This should raise an error
    # noinspection PyBroadException
    try:
        codecs.getdecoder(NAME + 'x')
        assert False
    except LookupError:
        pass



# Generated at 2022-06-25 17:15:09.473245
# Unit test for function register
def test_register():
    utf8_hex = 'O\xcc\x81i! \xcf\x89! \xce\xbf\xce\xbb\xce\xbf\xcf\x82! Voi\xcc\x87 la\xcc\x88\n'
    encoded = 'Oi! \\u03a9! \\u03bf\\u03bb\\u03bf\\u03c2! Voi\\u0307 la\\u0308\\n'
    capital_a = "A"
    capital_a_escaped = "\\x41"
    assert encode(utf8_hex) == (encoded.encode('utf8'), len(utf8_hex))

# Generated at 2022-06-25 17:15:10.489893
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:15:11.456964
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:15:12.455028
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:15:15.624119
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:15:16.552015
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:16:45.226823
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:16:48.031763
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-25 17:16:52.748511
# Unit test for function register
def test_register():
    """Test that register() creates the codec 'eutf8h'."""
    # assert eutf8h not in codecs.list_encodings()
    # assert eutf8h not in codecs.list_decodings()

    # eutf8h.register()

    # assert eutf8h in codecs.list_encodings()
    # assert eutf8h in codecs.list_decodings()

    pass



# Generated at 2022-06-25 17:16:59.803688
# Unit test for function register
def test_register():

    # Test codecs.register is called.
    from mock_decorators import spy_on

    spy_on(codecs.register)
    register()
    assert codecs.register.was_called()  # type: ignore

    # Test codecs.register was called with CodecInfo
    codec_info = codecs.register.spy_return_value  # type: ignore
    assert isinstance(codec_info, codecs.CodecInfo)
    assert codec_info.encode == encode
    assert codec_info.decode == decode


# Unit test function encode

# Generated at 2022-06-25 17:17:01.939019
# Unit test for function register
def test_register():
    register()
    codecs.register(_get_codec_info)  # type: ignore



# Generated at 2022-06-25 17:17:02.910766
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:17:05.501600
# Unit test for function register
def test_register():
    pass


# Generated at 2022-06-25 17:17:09.507504
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:17:10.706136
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:17:14.488911
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pytest.fail('The codec must be registered.')

