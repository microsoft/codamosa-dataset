

# Generated at 2022-06-25 17:10:42.529923
# Unit test for function register
def test_register():
    """Test if calling the function register succeeds."""
    # noinspection PyProtectedMember
    test_case_0()


if __name__ == '__main__':
    register()
    register()

    # text = 'Hello World'
    # text = '€'
    # text = '\x20'
    # text = '\x80'
    # text = '\xc2\x80'
    # text = '\xe2\x82\xac'
    # text = '\\xe2\\x82\\xac'
    # text = '\\x21'
    text = '€'
    # text = '\\xe2\\x82\\xac'

    # text = '\\x9f'
    # text = '\\x80'

    # text = '\\xc3\\xbf'


# Generated at 2022-06-25 17:10:54.103954
# Unit test for function decode
def test_decode():
    # Test decode for no args
    assert decode() == (b'', 0)
    # Test decode for one arg
    assert decode(b'') == ('', 0)
    # Test decode for one arg
    assert decode(b'a') == ('a', 1)
    # Test decode for one arg
    assert decode(b'\\x41') == ('A', 3)
    # Test decode for two arg
    assert decode(b'\\x41', b'strict') == ('A', 3)
    # Test decode for two arg
    assert decode(b'\\x41', b'replace') == ('A', 3)
    # Test decode for two arg
    assert decode(b'\\x41', b'ignore') == ('A', 3)
    # Test decode for two arg

# Generated at 2022-06-25 17:10:59.953043
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 17:11:04.508094
# Unit test for function register
def test_register():
    print("Unit test for function register")
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)
        print("encoding registered successfully")
    else:
        print("encoding already registered")

# Generated at 2022-06-25 17:11:09.162583
# Unit test for function register
def test_register():
    assert NAME not in codecs.getdecoder('utf8')
    register()
    assert NAME in codecs.getdecoder('utf8')


# noinspection PyUnusedLocal

# Generated at 2022-06-25 17:11:10.205463
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:11:11.565873
# Unit test for function register
def test_register():
    # No exception should be raised
    register()


test_case_0()

# Generated at 2022-06-25 17:11:12.096073
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:11:18.047438
# Unit test for function register
def test_register():
    """Test if the codec is registered."""
    try:
        codecs.getencoder(NAME)
    except LookupError:
        test_case_0()
        # Reraise the exception as a failure if the codec is not registered.
        raise AssertionError(
            f'Codec "{NAME}" must be registered') from None



# Generated at 2022-06-25 17:11:18.912088
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:11:27.210197
# Unit test for function register
def test_register():
    register()
    x = codecs.getencoder(NAME)
    assert x[0].__name__ == 'encode'
    assert x[1] == encode
    x = codecs.getdecoder(NAME)
    assert x[0].__name__ == 'decode'
    assert x[1] == decode



# Generated at 2022-06-25 17:11:28.954487
# Unit test for function register
def test_register():
    try:
        register()
    except Exception:
        failed()
    else:
        passed()


# Generated at 2022-06-25 17:11:33.216910
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()


# Generated at 2022-06-25 17:11:37.975628
# Unit test for function register
def test_register():

    register()



# Generated at 2022-06-25 17:11:42.924726
# Unit test for function register
def test_register():
    """
    Test function register()
    """
    try:
        codecs.getencoder(NAME)
    except LookupError:

        # register()

        codecs.getencoder(NAME)

        codecs.lookup(NAME)



# Generated at 2022-06-25 17:11:45.677988
# Unit test for function register
def test_register():
    y_expected: LookupError = None
    try:
        test_case_0()
    except LookupError as e:
        y_expected = e
    assert(y_expected is not None)


# Generated at 2022-06-25 17:11:46.521780
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:11:49.425441
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:11:52.174396
# Unit test for function register
def test_register():

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)  # type: ignore



# Generated at 2022-06-25 17:11:53.076933
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:12:05.673329
# Unit test for function register
def test_register():
    register()
    # codecs.register_error('eutf8h', codecs.lookup_error('ignore'))

    # Run the 'encode' function with utf8 hexadecimal.
    text = '\\xc3\\x82\\xc2\\xaa'
    expected = {
        'strict': b'\\xc3\\x82\\xc2\\xaa',
        'ignore': b'\\xc3\\x82',
        'replace': b'\\xc3\\x82?',
    }
    for errors in expected:
        out = codecs.encode(text, NAME, errors=errors)
        assert out == expected[errors]

    # Run the 'decode' function with utf8 hexadecimal.
    data = b'\\xc3\\x82\\xc2\\xaa'
    expected

# Generated at 2022-06-25 17:12:17.730611
# Unit test for function register
def test_register():
    with codecs.open(filename=__file__, mode='r', encoding='eutf8h') as f:
        lines = f.read().splitlines()
        assert lines[0] == '#!/usr/bin/env python3.5'
        assert lines[1] == '# -*- coding: utf-8 -*-'
        assert lines[2] == '"""Escaped utf8 hexadecimal codec."""'
        assert lines[3] == ''
        assert lines[4] == 'import codecs'
        assert lines[5] == 'from collections import UserString'
        assert lines[6] == 'from typing import ByteString as _ByteString'
        assert lines[7] == 'from typing import (  # noqa: F401'
        assert lines[8] == '    Generator,'

# Generated at 2022-06-25 17:12:21.347254
# Unit test for function register
def test_register():
    register()

    try:
        codecs.getencoder(NAME)
    except LookupError:
        assert False

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False



# Generated at 2022-06-25 17:12:27.075151
# Unit test for function register
def test_register():

    # Test to verify that the given codec `NAME` is not already
    # registered.
    with pytest.raises(LookupError):
        # noinspection PyTypeChecker
        codecs.getdecoder(NAME)

    # Register the codec.
    register()

    # Test to verify that the codec `NAME` is registered.
    # noinspection PyTypeChecker
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:12:28.222641
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:12:35.378907
# Unit test for function register
def test_register():
    import collections

    # Register the codec
    register()

    # Check the codec is registered
    result = codecs.getdecoder(NAME)
    assert result is not None
    assert isinstance(result, collections.namedtuple)
    result = codecs.getencoder(NAME)
    assert result is not None
    assert isinstance(result, collections.namedtuple)



# Generated at 2022-06-25 17:12:37.514930
# Unit test for function register
def test_register():
    register()      # type: ignore

# Unit tests for function encode

# Generated at 2022-06-25 17:12:38.519586
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:12:43.464978
# Unit test for function register
def test_register():
    register()
    _foo = """
        >>> import codecs
        >>> foo = codecs.getdecoder('eutf8h')
        >>> foo
        <function decode at 0x...>
        >>> foo = codecs.getencoder('eutf8h')
        >>> foo
        <function encode at 0x...>
    """
    import doctest
    doctest.run_docstring_examples(register, globals(), verbose=True)

# Generated at 2022-06-25 17:12:45.848151
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise RuntimeError('eutf8h is already registered')

    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:12:52.214052
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:12:53.164404
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:12:57.400464
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder('eutf8h')
    except LookupError:
        register()
        codecs.getdecoder('eutf8h')
        codecs.getencoder('eutf8h')



# Generated at 2022-06-25 17:12:58.464530
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:13:09.136901
# Unit test for function register
def test_register():
    # Make sure the codecs module's getdecoder() method
    # raises a LookupError when a non-existent codec is
    # specified.
    with pytest.raises(LookupError):
        codecs.getdecoder('xxxx')
    codecs.register(  # type: ignore
        codecs.CodecInfo(  # type: ignore
            name='xxxx',
        )
    )
    codecs.getdecoder('xxxx')
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)

    # Register the codec and make sure it is registered.
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pytest.fail()

    # Register the codec again and make sure it is registered.
    register()

# Generated at 2022-06-25 17:13:15.077488
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getencoder(NAME)
    except LookupError:
        assert False
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False



# Generated at 2022-06-25 17:13:19.677588
# Unit test for function register
def test_register():
    """Test function register."""
    # Register the codec 'eutf8h'
    test_case_0()
    # Check if the codec is registered
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:13:20.701047
# Unit test for function register
def test_register():
    test_case0()



# Generated at 2022-06-25 17:13:22.470230
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


# Generated at 2022-06-25 17:13:26.819367
# Unit test for function register
def test_register():
    """Test case for register()"""
    register()

    # Try to register the codec again
    try:
        register()
    except Exception:
        raise AssertionError("The function register raised an unexpected exception.")



# Generated at 2022-06-25 17:13:34.060168
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:13:36.044208
# Unit test for function register
def test_register():
    test_case_0()



# Generated at 2022-06-25 17:13:37.023864
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-25 17:13:40.676996
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()



# Generated at 2022-06-25 17:13:43.703757
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, "Codec registration failed."
    assert True


# Generated at 2022-06-25 17:13:45.187908
# Unit test for function register
def test_register():
    # Perform test
    test_case_0()


# Generated at 2022-06-25 17:13:50.566531
# Unit test for function register
def test_register():
    codecs.register(None)

    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()



# Generated at 2022-06-25 17:13:55.733405
# Unit test for function register
def test_register():
    """
    ..todo:: This can be done better.
    """
    print('test_register')
    try:
        register()
        print('test_register: no exception')
    except Exception:
        print('test_register: exception')
    else:
        print('test_register: no exception')



# Generated at 2022-06-25 17:13:57.523407
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:13:59.472091
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False



# Generated at 2022-06-25 17:14:10.366186
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:14:12.789269
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:14:13.643254
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:14:15.730380
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:14:16.653658
# Unit test for function register
def test_register():
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:14:19.412042
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-25 17:14:24.193317
# Unit test for function register
def test_register():
    """Coverage for 'register' function"""
    old_getdecoder = codecs.getdecoder
    codecs.getdecoder = lambda _: None
    try:
        register()
    finally:
        codecs.getdecoder = old_getdecoder



# Generated at 2022-06-25 17:14:26.264046
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-25 17:14:30.792690
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()



# Generated at 2022-06-25 17:14:34.729942
# Unit test for function register
def test_register():
    try:
        codecs.getencoder(NAME)
        codecs.getdecoder(NAME)
    except LookupError:
        test_case_0()
    else:
        try:
            codecs.getencoder(NAME)
            codecs.getdecoder(NAME)
        except LookupError:
            raise Exception('Error in function register()')



# Generated at 2022-06-25 17:15:01.990580
# Unit test for function register
def test_register():
    """
Unit test for function 'register'.

Return:
    None: None.
    """
    register()
    assert codecs.lookup_error('eutf8h')[0] == NAME



# Generated at 2022-06-25 17:15:05.920909
# Unit test for function register
def test_register():
    register()
    # print(repr(codecs.lookup_error('eutf8h')))
    pass


if __name__ == '__main__':
    test_case_0()
    # test_register()

# Generated at 2022-06-25 17:15:09.346151
# Unit test for function register
def test_register():
    # Test for module level function codecs.register()
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'Codec eutf8h not registered'
    assert True


# Generated at 2022-06-25 17:15:15.624756
# Unit test for function register
def test_register():
    register()

    # Test that the UTF-8 Hexadecimal codec was registered.
    try:
        codecs.getencoder(NAME)
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, "Failed to register codec %s" % NAME



# Generated at 2022-06-25 17:15:16.818558
# Unit test for function register
def test_register():

    # Unit test where the codec is already registered
    register()


# Generated at 2022-06-25 17:15:26.243823
# Unit test for function register
def test_register():

    eutf8h_codec = codecs.getdecoder(NAME)

    assert eutf8h_codec is not None

    assert eutf8h_codec == decode

    text_input = 'Hello, World!'
    text_expected = b'\\x48\\x65\\x6c\\x6c\\x6f\\x2c\\x20\\x57\\x6f\\x72\\x6c\\x64\\x21'
    text_output, text_consumed = eutf8h_codec(text_input, 'strict')

    assert text_output == text_expected
    assert text_consumed == len(text_input)


# Generated at 2022-06-25 17:15:27.297093
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:15:28.519174
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:15:30.919034
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:15:33.452967
# Unit test for function register
def test_register():
    try:
        codecs.getencoder(NAME)
    except LookupError as e:
        assert False, str(e)


# Generated at 2022-06-25 17:16:27.828612
# Unit test for function register
def test_register():
    test_case_0()

# Generated at 2022-06-25 17:16:30.577160
# Unit test for function register
def test_register():
    test_case_0()
    register()

# Generated at 2022-06-25 17:16:35.345298
# Unit test for function register
def test_register():
    test_case_0()
    with pytest.raises(LookupError):
        codecs.register(NAME, encode, decode, incrementaldecoder=None,
                        incrementaldecode=None)
    try:
        test_case_0()
    finally:
        del codecs.codecs_map[NAME]



# Generated at 2022-06-25 17:16:36.227843
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:16:42.498953
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup_error('eutf8h')
    assert codecs.getencoder(NAME)
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:16:45.070829
# Unit test for function register
def test_register():
    pass
    # register()
    # temp_codecs = codecs.getdecoder(NAME)



# Generated at 2022-06-25 17:16:52.481534
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
        decoder = codecs.getdecoder(NAME)  # type: ignore
    else:
        decoder = codecs.getdecoder(NAME)  # type: ignore

    text = 'abc'
    out_bytes, nbytes = decoder(text)
    assert len(out_bytes) == nbytes == len(text)
    assert out_bytes == b'a\x62\x63'



# Generated at 2022-06-25 17:16:57.903386
# Unit test for function register
def test_register():
    assert not isinstance(codecs.getdecoder(NAME), codecs.CodecInfo)
    register()
    assert isinstance(codecs.getdecoder(NAME), codecs.CodecInfo)



# Generated at 2022-06-25 17:17:00.314220
# Unit test for function register
def test_register():
    # Register the codec
    register()

    # Ensure the codec is registered
    codecs.getencoder(NAME)



# Generated at 2022-06-25 17:17:01.465794
# Unit test for function register
def test_register():
    test_case_0()


# Generated at 2022-06-25 17:19:08.030943
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getencoder(NAME)
    except LookupError:
        assert(False)
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert(False)



# Generated at 2022-06-25 17:19:17.311639
# Unit test for function register
def test_register():
    """
    Purpose:
        Make sure that the codec is registered by calling register().

    Pre-conditions:
        :func:`test_case_0` must be called before running this function.

    Test-cases:
        - None.

    Returns:
        None.

    Raises:
        None.

    """
    # The codec must be registered as a Decoder.
    try:
        # Try retrieving the Decoder.
        decoder_codec = codecs.getdecoder(NAME)
    except LookupError:
        # Raise an error.
        raise AssertionError(
            "The codec '%s' must be registered as a decoder."
            % NAME
        )

# Generated at 2022-06-25 17:19:28.417385
# Unit test for function register
def test_register():
    register()

    try:
        codecs.getencoder(NAME)
    except LookupError:
        pytest.fail(
            'The codec declared by NAME %s was not registered by '
            'function register().' % NAME
        )
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pytest.fail(
            'The codec declared by NAME %s was not registered by '
            'function register().' % NAME
        )



# Generated at 2022-06-25 17:19:35.034786
# Unit test for function register
def test_register():

    register()
    registered_codec_info = codecs.getdecoder(NAME)
    assert registered_codec_info.name == NAME
    assert registered_codec_info.encode.__name__ == 'encode'
    assert registered_codec_info.decode.__name__ == 'decode'

    master_str = 'aß€hi'
    master_str_escaped = 'a\\\\xc3\\\\x9f\\\\xe2\\\\x82\\\\xac\\\\x68\\\\x69'
    master_bytes = master_str.encode('utf8')

    # Encode the string input as escaped utf8 bytes.
    result_bytes, num_encoded = registered_codec_info.encode(master_str)
    assert num_encoded == len(master_str)
    # Decode the escaped

# Generated at 2022-06-25 17:19:39.354195
# Unit test for function register
def test_register():
    from importlib import reload

    import binascii

    from eutf8h import eutf8hex as eutf8h

    register()

    assert eutf8h.NAME == 'eutf8hex'

    reload(eutf8h)

    assert eutf8h.NAME == 'eutf8hex'


# Generated at 2022-06-25 17:19:40.664437
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME)  # type: ignore


# Generated at 2022-06-25 17:19:49.404859
# Unit test for function register
def test_register():
    print('test_register()')

    try:
        from test import support
        # noinspection PyPackageRequirements
        from test.support import check_warnings
    except ImportError:
        print('test_register() skipped')
        print('test_case_0 skipped')

    # Basic functionality test
    support.import_module(NAME, deprecated=True)

    # Run 'test_register()' a second time to verify that it does not
    # complain about the module being already registered.
    support.import_module(NAME, deprecated=True)



# Generated at 2022-06-25 17:19:53.360531
# Unit test for function register
def test_register():
    """
    Unit test of function register.
    """
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-25 17:19:54.802064
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-25 17:20:00.650086
# Unit test for function register
def test_register():
    register()

    codecs.register(_get_codec_info)  # type: ignore
    with pytest.raises(LookupError):
        codecs.register(_get_codec_info)  # type: ignore

