

# Generated at 2022-06-11 22:04:44.528036
# Unit test for function register
def test_register():
    import codecs
    codecs.register(_get_codec_info)
    assert codecs.lookup(NAME) == codecs.CodecInfo(  # type: ignore
        name=NAME,
        encode=encode,  # type: ignore[arg-type]
        decode=decode,  # type: ignore[arg-type]
    )



# Generated at 2022-06-11 22:04:54.256249
# Unit test for function register
def test_register():
    """Unit test for function `register`."""

    try:
        codecs.getencoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError('encoder is defined before register()')

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError('decoder is defined before register()')

    register()

    try:
        codecs.getencoder(NAME)
    except LookupError:
        raise AssertionError('encoder is not defined after register()')

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError('decoder is not defined after register()')


if __name__ == '__main__':
    test_

# Generated at 2022-06-11 22:04:56.587624
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)('a')   # type: ignore
    codecs.getdecoder(NAME)(b'a')  # type: ignore
    codecs.lookup(NAME)            # type: ignore



# Generated at 2022-06-11 22:05:07.508735
# Unit test for function register
def test_register():

    def _test_except_LookupError():
        # Register the codec.
        register()

        # No exception should be raised
        codecs.getdecoder(NAME)

        # An exception should be raised
        try:
            codecs.getencoder(NAME)
        except LookupError:
            pass
        else:
            assert False, 'Expected a LookupError to be raised'

    # Register the codec.
    register()

    # No exception should be raised
    codecs.getdecoder(NAME)

    # An exception should be raised
    try:
        codecs.getencoder(NAME)
    except LookupError:
        pass
    else:
        assert False, 'Expected a LookupError to be raised'

    # Unregister the codec.
    codecs.unregister(NAME)

    _test

# Generated at 2022-06-11 22:05:09.576220
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    register()
    test_register()

# Generated at 2022-06-11 22:05:18.027508
# Unit test for function register
def test_register():
    import tempfile
    from importlib import reload as reload_module
    from importlib import util as util_module

    # Write a simple file to test the function _get_codec_info.
    path = f'{NAME}.py'
    with tempfile.TemporaryDirectory() as dname:
        with codecs.open(path, 'wb', encoding='utf-8') as f:
            f.write("""
# This is a test file. It should be ignored by the
# Escaped UTF-8 hexadecimal codec.

print("Hello World!")
            """.lstrip())

        # Load a module from the file path.
        spec = util_module.spec_from_file_location(NAME, path)
        test_module = util_module.module_from_spec(spec)
        spec.loader.exec_module

# Generated at 2022-06-11 22:05:27.462815
# Unit test for function register
def test_register():
    """Test function register."""
    import os
    import sys
    import shutil
    import tempfile
    import unittest.mock
    import unittest

    def get_temp_file_path() -> str:
        fd, file_path = tempfile.mkstemp()
        os.close(fd)
        return file_path

    def get_temp_dir_path() -> str:
        return tempfile.mkdtemp()

    def remove_file(file_path: str) -> None:
        try:
            os.remove(file_path)
        except FileNotFoundError:
            pass

    def remove_dir(dir_path: str) -> None:
        try:
            shutil.rmtree(dir_path)
        except FileNotFoundError:
            pass


# Generated at 2022-06-11 22:05:37.089043
# Unit test for function register
def test_register():
    # noinspection SpellCheckingInspection
    test_utf8_str = 'こんにちは'

    # noinspection SpellCheckingInspection
    test_eutf8h_str = reduce(lambda a, b: f'{a}{b}', _each_utf8_hex(test_utf8_str))

    register()

    # noinspection SpellCheckingInspection
    test_eutf8h_bytes: bytes = test_eutf8h_str.encode('utf-8')

    # noinspection SpellCheckingInspection
    test_utf8_bytes: bytes = test_utf8_str.encode('utf-8')

    # Decode the bytes into a str

# Generated at 2022-06-11 22:05:37.995209
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)



# Generated at 2022-06-11 22:05:39.691172
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:05:53.275054
# Unit test for function register
def test_register():

    def test_register_encoder(obj):
        if obj is not None:
            assert isinstance(obj, codecs.CodecInfo)
            assert hasattr(obj, 'name')
            assert isinstance(obj.name, str)
            assert obj.name == NAME
            assert hasattr(obj, 'encode')
            assert callable(obj.encode)
            assert hasattr(obj, 'decode')
            assert callable(obj.decode)

    def test_register_decoder(obj):
        if obj is not None:
            assert isinstance(obj, codecs.CodecInfo)
            assert hasattr(obj, 'name')
            assert isinstance(obj.name, str)
            assert obj.name == NAME
            assert hasattr(obj, 'encode')

# Generated at 2022-06-11 22:05:54.379838
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:05:55.583545
# Unit test for function register
def test_register():
    '''
    :return:
    '''
    register()



# Generated at 2022-06-11 22:05:58.672204
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:06:01.988323
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise RuntimeError(f'Unable to register codec: {e}')



# Generated at 2022-06-11 22:06:05.570757
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME)  # type: ignore
    assert codecs.getdecoder(NAME)  # type: ignore



# Generated at 2022-06-11 22:06:09.814918
# Unit test for function register
def test_register():
    register()

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:06:16.188566
# Unit test for function register
def test_register():
    test_tuple = (
        ('''abc''', 3),
        ('''\\u0020''', 6),
        ('''\\x20''', 4),
        ('''\\u0020\\u0020\\u0020''', 18),
        ('''\\x20\\x20\\x20''', 12),
        ('''\\u0020\\x20\\u0020''', 12),
    )

    for test in test_tuple:

        expected = test[0]
        encoded_bytes, consumed = encode(test[0])
        decoded_str, consumed = decode(encoded_bytes)
        assert consumed == test[1]
        assert decoded_str == expected



# Generated at 2022-06-11 22:06:17.533915
# Unit test for function register
def test_register():
    _ = register()


# Unit tests

# Generated at 2022-06-11 22:06:20.459213
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    try:
        codec = codecs.getdecoder(NAME)
        assert codec[1] == decode
    except LookupError as e:
        assert False, f'import failed: {e}'

# Generated at 2022-06-11 22:06:29.910755
# Unit test for function register
def test_register():
    # noinspection SpellCheckingInspection
    # Test that the codec is already known
    assert NAME in codecs.__all__

    # Test that the codec is successfully registered
    assert codecs.getdecoder(NAME) is not None

    # Test that the codec is successfully registered
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-11 22:06:32.728842
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-11 22:06:38.119725
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)  # type: ignore
    # noinspection PyTypeChecker
    codecs.getdecoder(NAME)   # type: ignore
    # noinspection PyTypeChecker
    codecs.getencoder(NAME)   # type: ignore
    codecs.unregister(NAME)  # type: ignore



# Generated at 2022-06-11 22:06:40.009227
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:06:44.560828
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert True
    else:
        assert False
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False
    else:
        assert True




# Generated at 2022-06-11 22:06:45.270537
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:06:49.555955
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:06:52.969399
# Unit test for function register
def test_register():
    """Tests :func:`register`."""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-11 22:06:54.444198
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:06:58.049803
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-11 22:07:07.769548
# Unit test for function register
def test_register():  # pragma: no cover
    """
    Codec testing is complex.  Just ensuring that this runs without crashing
    is a good start.
    """
    register()

    assert codecs.lookup(NAME)



# Generated at 2022-06-11 22:07:11.668133
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        assert codecs.getencoder(NAME)
        assert codecs.getdecoder(NAME)
        return
    # Todo how to implement this test.
    assert False, 'Codec already registered.'

# Generated at 2022-06-11 22:07:22.162997
# Unit test for function register
def test_register():
    from eutf8h import codec
    codec.register()
    decoder = codecs.getdecoder(codec.NAME)
    b'test' == decoder(b'test')[0]
    b'test' == decoder(b'\\74\\65\\73\\74')[0]
    b'test' == decoder(b'\\x74\\x65\\x73\\x74')[0]
    b'test' == decoder(b'\\x7\\x65\\x73\\x74')[0]
    b'test' == decoder(b'\\x7test')[0]



# Generated at 2022-06-11 22:07:25.655401
# Unit test for function register
def test_register():
    assert NAME not in codecs.conftable

    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:07:27.280467
# Unit test for function register
def test_register():
    """Unit test for function register."""
    import tests.test_eutf8h
    assert tests.test_eutf8h.register() is None

if __name__ == '__main__':
    register()
    test_register()

# Generated at 2022-06-11 22:07:35.642356
# Unit test for function register
def test_register():
    # Test the function that registers this module with the Python
    # codecs module.

    # Get the name of this module.
    module_name = __name__.split('.')[-1]

    # Unregister the module with the codecs module.
    try:
        codecs.getdecoder(module_name)
    except LookupError:
        pass
    else:
        codecs.unregister(module_name)   # type: ignore

    # Register the module with the codecs module.
    register()

    # Get the codec info for this module.
    codec_info = codecs.getdecoder(module_name)

    # Assert the codec_info is an object of type codecs.CodecInfo.
    assert (isinstance(codec_info, codecs.CodecInfo))

    # assert codec_info.

# Generated at 2022-06-11 22:07:39.058501
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'Failed to register codecs.getdecoder'



# Generated at 2022-06-11 22:07:40.280833
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:07:50.786672
# Unit test for function register
def test_register():

    def dummy():
        global codecs
        global NAME

        # The 'codecs' module is set to None to force this function
        # to call 'codecs.register'.
        codecs = None

        class _DummyClass:
            @staticmethod
            def getdecoder(decoder_name: str) -> None:
                assert decoder_name == NAME

                class _DummyDecoder:
                    @staticmethod
                    def decode(obj: bytes, errors: str) -> Tuple[str, int]:
                        assert obj == b'\x41\x41\x42'
                        assert errors == 'strict'
                        return '', 0
                return _DummyDecoder

            @staticmethod
            def register(obj: Optional[codecs.CodecInfo]) -> None:
                assert obj

        codecs = _D

# Generated at 2022-06-11 22:07:57.543311
# Unit test for function register
def test_register():
    registration_count = len(codecs.aliases.aliases)
    register()
    assert len(codecs.aliases.aliases) == registration_count + 1


# -----------------------------------------------------------------------------
# Copyright (C) 2020 Angelos Evripiotis.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License

# Generated at 2022-06-11 22:08:07.369386
# Unit test for function register
def test_register():
    register()
    assert 'eutf8h' in codecs.getencodings()
    assert 'eutf8h' in codecs.getdecodings()



# Generated at 2022-06-11 22:08:07.944550
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-11 22:08:15.144668
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


try:
    # pylint: disable=unused-import
    from typing import Literal  # pylint: disable=unused-import
except ImportError:
    from typing_extensions import Literal  # type: ignore

__all__ = [
    'Literal',  # for mypy
    'NAME',
    'test_register',
]

# Generated at 2022-06-11 22:08:15.606474
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:08:16.919961
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 22:08:20.744797
# Unit test for function register
def test_register():
    # Test that register() works as intended.
    if NAME == 'eutf8h':
        try:
            codecs.getencoder(NAME)
        except LookupError:
            raise Exception(
                'register() failed to register the codec')


# Generated at 2022-06-11 22:08:24.641509
# Unit test for function register
def test_register():
    NAME = __name__.split('.')[-1]
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-11 22:08:27.159586
# Unit test for function register
def test_register():
    """
    Tests register function.
    """
    register()
    getdecoder = codecs.getdecoder(NAME)
    assert getdecoder

# Generated at 2022-06-11 22:08:29.699798
# Unit test for function register
def test_register():
    """
    Test that the codec is registered.
    """
    codec_info = codecs.getdecoder(NAME)
    assert codec_info is not None


# Generated at 2022-06-11 22:08:34.026836
# Unit test for function register
def test_register():
    register()
    try:
        c = codecs.getdecoder(NAME)    # type: ignore
    except LookupError:
        assert False, 'Failed to register the codec'
    assert NAME in repr(c)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:08:51.341974
# Unit test for function register
def test_register():
    """Unit test for function :obj:`~register`.
    """
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:08:52.830105
# Unit test for function register
def test_register():
    assert NAME == 'eutf8h'
    codecs.register(_get_codec_info)



# Generated at 2022-06-11 22:08:53.911059
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:08:56.047394
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore



# Generated at 2022-06-11 22:08:58.875844
# Unit test for function register
def test_register():
    register()
    # codecs.register(_get_codec_info)



# Generated at 2022-06-11 22:09:02.750764
# Unit test for function register
def test_register():
    '''
    This function tests the function register.
    '''
    # Call the function to register the codec.
    register()

    # Verify the codec was registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError('The codec was not registered.')



# Generated at 2022-06-11 22:09:07.071849
# Unit test for function register
def test_register():
    """Test that function register will add the eutf8h codec."""
    codecs.getdecoder('utf8h')   # type: ignore
    register()
    codecs.getdecoder(NAME)   # type: ignore



# Generated at 2022-06-11 22:09:10.201000
# Unit test for function register
def test_register():
    import codecs

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()


codecs.register(_get_codec_info)  # type: ignore

# Generated at 2022-06-11 22:09:19.457450
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)


if __name__ == '__main__':
    register()
    print('Registered eutf8h codec')

# Generated at 2022-06-11 22:09:20.585568
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:09:46.057458
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    # Test it out.
    register()
    input_str = r'Hello World!\x00\xFF'
    output_bytes = input_str.encode('eutf8h')
    print(repr(output_bytes))
    output_str = output_bytes.decode('eutf8h')
    print(repr(output_str))

# Generated at 2022-06-11 22:09:46.556363
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-11 22:09:48.389856
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:09:51.435562
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore


# Generated at 2022-06-11 22:09:58.722595
# Unit test for function register
def test_register():
    import functools

    def assert_is_codec_info(info):
        assert isinstance(info, codecs.CodecInfo)
        assert_is_codec_info = functools.partial(assert_is_codec_info)

    register()

    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)

    info = _get_codec_info(NAME)
    assert_is_codec_info(info)


# Generated at 2022-06-11 22:10:00.837386
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)  # type: ignore
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-11 22:10:08.086372
# Unit test for function register
def test_register():
    """
    Test that the codec is not yet registered
    """
    print('Testing register()')
    try:
        # This should raise an exception, because the codec is not yet
        # registered
        codecs.getdecoder(NAME)
        print('ERROR: codec ' + NAME + ' is already registered')
        return
    except LookupError:
        pass

    # Perform a registration
    register()

    # Now the codec should be registered inside the codecs module
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        print('ERROR: codec ' + NAME + ' is not yet registered')
        return
    print('OK')



# Generated at 2022-06-11 22:10:13.050029
# Unit test for function register
def test_register():
    register()
    try:
        utf8_hex_bytes = b'\xc2\xa9'  # ©
        bytes_at_offset = utf8_hex_bytes[:1]
        chars = bytes_at_offset.decode(NAME)
        assert isinstance(chars, str)
        assert chars == '©'
    except LookupError:
        assert False, 'LookupError, register failed.'

# Generated at 2022-06-11 22:10:15.139153
# Unit test for function register
def test_register():
    # Test that the codec_info is registered
    info = codecs.lookup(NAME)
    assert info.name == NAME


register()

# Generated at 2022-06-11 22:10:16.656883
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:11:03.946952
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:11:07.739736
# Unit test for function register
def test_register():

    # Execute the side effect of registering the codec.
    register()

    # Test that the codec was registered properly.
    codecs.getdecoder(NAME)
    try:
        codecs.getencoder(NAME)
    except LookupError:
        raise AssertionError('Encoder was not registered.')

test_register()


# Generated at 2022-06-11 22:11:11.675272
# Unit test for function register
def test_register():
    register()
    for codec_tuple in codecs.iterencode(''):
        codec_name = codec_tuple[0]
        if codec_name == NAME:
            return
    raise RuntimeError('Unable to register eutf8h codec')


# Generated at 2022-06-11 22:11:17.958551
# Unit test for function register
def test_register():
    from importlib import reload
    import eutf8h_codec
    reload(eutf8h_codec)
    eutf8h_codec.register()
    assert NAME not in eutf8h_codec.__all__
    assert NAME in codecs.__all__


if __name__ == '__main__':
    test_register()

    print('Running tests...')
    import doctest
    doctest.testmod()
    print('Done.')

# Generated at 2022-06-11 22:11:19.811540
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)  # type: ignore



# Generated at 2022-06-11 22:11:24.444336
# Unit test for function register
def test_register():
    import eutf8h
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(eutf8h._get_codec_info)



# Generated at 2022-06-11 22:11:27.229877
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert True
    else:
        assert False



# Generated at 2022-06-11 22:11:33.850008
# Unit test for function register
def test_register():
    import sys
    import traceback
    from ._test_utils import m

    try:
        register()
    except Exception as e:
        m(str(e))
        m(traceback.format_exc())
        raise

    assert NAME in sys.__dict__
    assert isinstance(encode, type(sys.__dict__[NAME]))
    assert isinstance(decode, type(sys.__dict__[NAME]))


# Generated at 2022-06-11 22:11:34.730123
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)

# Generated at 2022-06-11 22:11:35.788808
# Unit test for function register
def test_register():
    register()
    # noinspection PyTypeChecker
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-11 22:13:11.135231
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:13:13.349377
# Unit test for function register
def test_register():
    register()
    msg = 'Register should succeed because NAME is not already registered.'
    assert codecs.getdecoder(NAME), msg

# Generated at 2022-06-11 22:13:15.416977
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:13:21.935780
# Unit test for function register
def test_register():
    # Verify the codec is not registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError('Codec should not be registered.')
    # Register the codec
    register()
    # Verify the codec is registered
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:13:26.932392
# Unit test for function register
def test_register():
    """Unit test for function register."""
    # pylint: disable=protected-access
    # noinspection PyTypeChecker
    assert codecs.__all__[-1] == '_get_codec_info'

    # noinspection PyProtectedMember
    del codecs.__all__[-1]
    codecs.register(_get_codec_info)  # type: ignore


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:13:28.718048
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME)
    assert codecs.getdecoder(NAME)

register()

# Generated at 2022-06-11 22:13:32.972320
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)  # should not fail


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:13:35.667968
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)


if __name__ == "__main__":
    test_register()

# Generated at 2022-06-11 22:13:41.949412
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
    encoder = codecs.getencoder(NAME)       # type: ignore
    decoder = codecs.getdecoder(NAME)       # type: ignore
    assert encoder is not None
    assert decoder is not None



# Generated at 2022-06-11 22:13:42.759207
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)