

# Generated at 2022-06-11 22:04:42.846583
# Unit test for function register
def test_register():
    register()
    text = 'Hello World'
    text_bytes = text.encode(NAME)    # type: ignore[attr-defined]
    assert text == text_bytes.decode(NAME)



# Generated at 2022-06-11 22:04:44.047906
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:04:45.185696
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-11 22:04:46.852484
# Unit test for function register
def test_register():
    register()
    codecs.lookup(NAME)



# Generated at 2022-06-11 22:04:47.919504
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:04:50.126105
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    assert NAME in codecs.getdecoder('eutf8h')


# Generated at 2022-06-11 22:04:54.482525
# Unit test for function register
def test_register():
    register()
    decoder = codecs.getdecoder(NAME)
    assert decoder(b'\\x45\\x54\\x55\\x46\\x38\\x48', 'strict')[0] == 'ETUF8H'



# Generated at 2022-06-11 22:04:56.527746
# Unit test for function register
def test_register():
    print('test function "register"')
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise RuntimeError('"register" failed')



# Generated at 2022-06-11 22:05:00.226559
# Unit test for function register
def test_register():
    import codecs

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore

# Importing this module will automatically register the encoder.
register()

# Generated at 2022-06-11 22:05:08.576256
# Unit test for function register
def test_register():
    register()
    # Result of function getdecoder.
    # The encoding was added to the codec registry
    decoder = codecs.getdecoder(NAME)
    # Result of function getencoder.
    # The encoding was added to the codec registry
    encoder = codecs.getencoder(NAME)
    assert isinstance(decoder, tuple)
    assert isinstance(encoder, tuple)
    assert len(decoder) == 2
    assert len(encoder) == 2
    assert isinstance(decoder[0], callable)
    assert isinstance(encoder[0], callable)



register()


if __name__ == "__main__":
    test_register()

# Generated at 2022-06-11 22:05:11.535813
# Unit test for function register
def test_register():   # type: ignore
    codecs.register(_get_codec_info)  # type: ignore

# Generated at 2022-06-11 22:05:13.103898
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:05:18.874350
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
        raise AssertionError(
            f'Codec already register: {NAME!r}'
        )
    except LookupError:
        pass
    register()
    codecs.getdecoder(NAME)  # type: ignore

if __name__ == '__main__':
    register()
    codecs.getdecoder(NAME)  # type: ignore
    ut = 'A\u00A0Z'
    assert ut == codecs.decode(codecs.encode(ut, NAME), NAME)

# Generated at 2022-06-11 22:05:24.400582
# Unit test for function register
def test_register():
    # Test that the codec is not registed
    try:
        codecs.getdecoder(NAME)
        raise ValueError('Expected LookupError exception')
    except LookupError:
        pass

    # Register the codec
    register()

    # Test that the codec is now registered
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:05:28.203732
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    assert(codecs.getdecoder(NAME))



# Generated at 2022-06-11 22:05:33.969601
# Unit test for function register
def test_register():
    register()
    test_text = '\\x41\\x42\\x43\\x44'
    data = test_text.encode(NAME)
    out_text = codecs.decode(data, NAME)
    assert(out_text == 'ABCD')



# Generated at 2022-06-11 22:05:40.995020
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)

        decoder = codecs.getdecoder(NAME)

        # Test decode function.
        assert decoder(b'\x41\x42\x43') == ('ABC', 3)
        assert decoder(b'\x41\x42\x43', errors='replace') == ('ABC', 3)
        assert decoder(b'\x41\x42\x43', errors='ignore') == ('', 0)
        assert decoder(b'\x41\x42\x43', errors='strict') == ('ABC', 3)
        assert decoder(b'\x41\x42\x43', errors='strict') == ('ABC', 3)

        # Test an invalid

# Generated at 2022-06-11 22:05:48.655112
# Unit test for function register
def test_register():
    del codecs.decode
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        assert False
    register()
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    import pytest
    if pytest.main() == 0:
        print('PASSED')

# Generated at 2022-06-11 22:05:50.965177
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-11 22:05:54.060985
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    assert NAME in codecs.getencodings()

# Generated at 2022-06-11 22:05:58.717844
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:06:02.451812
# Unit test for function register
def test_register():
    import codecs
    from eutf8h import _get_codec_info

    try:
        codecs.getdecoder('eutf8h')
    except LookupError:
        codecs.register(_get_codec_info)

# Generated at 2022-06-11 22:06:03.116509
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:06:08.454667
# Unit test for function register
def test_register():
    NAME = __name__.split('.')[-1]
    codecs.register(_get_codec_info)   # type: ignore
    assert codecs.getdecoder(NAME) is _get_codec_info(NAME)


if __name__ == '__main__':
    import doctest

    # noinspection PyUnresolvedReferences
    doctest.testmod()

# Generated at 2022-06-11 22:06:09.935292
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME)


# Generated at 2022-06-11 22:06:11.514111
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:06:15.597036
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME) == _get_codec_info(NAME)

# Generated at 2022-06-11 22:06:23.067994
# Unit test for function register
def test_register():
    import sys
    # test_register()
    # sys.modules[__name__].__loader__.load_module(__name__)

    # return # uncomment this to skip test_register()

    # Try to register an already-existing codec entry.
    # This should raise a LookupError exception.
    try:
        codecs.register(_get_codec_info)  # type: ignore
    except LookupError as e:
        pass
    except Exception as e:
        raise AssertionError(
            'Got the wrong exception. Got: %s' % e
        )
    else:
        raise AssertionError(
            'Failed to get a LookupError exception'
        )


# Generated at 2022-06-11 22:06:33.951071
# Unit test for function register
def test_register():
    re_str = r'^eutf8h$'
    re_bytes = re_str.encode(NAME)
    codecs.register(_get_codec_info)  # type: ignore
    out_str = codecs.decode(re_bytes, NAME)
    out_bytes = codecs.encode(re_str, NAME)
    assert out_str == re_str
    assert out_bytes == re_bytes
    codecs.encode(re_str, NAME)
    codecs.decode(re_bytes, NAME)
    non_ascii = u'\u4e00\u4e02'
    non_ascii_bytes = '\\4e\\00\\4e\\02'.encode(NAME)

# Generated at 2022-06-11 22:06:35.288531
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:06:46.101507
# Unit test for function register
def test_register():
    codecs.register(lambda x: codecs.lookup('utf-8') if x == 'test' else None)
    register()
    test = codecs.getencoder(NAME)
    assert test is not None
    codecs.register(_get_codec_info)


# Generated at 2022-06-11 22:06:53.575732
# Unit test for function register
def test_register():
    import codecs  # noqa: F401
    import sys

    for i in range(len(sys.modules[__name__].__dict__)):
        codecs.register(_get_codec_info)
        # codecs.__all__ += (NAME,)
    # codecs.lookup(NAME)
    # codecs.getdecoder(NAME)
    # codecs.getencoder(NAME)


# Generated at 2022-06-11 22:06:54.534148
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:06:57.394282
# Unit test for function register
def test_register():
    # NOTE: This has a side effect. It registers the codec.
    register()   # type: ignore



# Generated at 2022-06-11 22:07:01.495154
# Unit test for function register
def test_register():

    # Test that the encoding is registered if it was not already registered.
    codecs.register(_get_codec_info)
    codecs.getdecoder(NAME)  # this should not throw any exceptions

    # Test that the encoding is not registered if it was already registered.
    register()  # this should not throw any exceptions

# Generated at 2022-06-11 22:07:02.680807
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:07:07.305307
# Unit test for function register
def test_register():
    from contextlib import contextmanager
    from io import StringIO

    @contextmanager
    def suppress_stdout():
        import sys
        save_stdout = sys.stdout
        sys.stdout = StringIO()
        yield
        sys.stdout = save_stdout

    with suppress_stdout():
        register()


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:07:08.921613
# Unit test for function register
def test_register():
    register()
    decoder_get = codecs.getdecoder(NAME)
    assert decoder_get is not None


# Generated at 2022-06-11 22:07:10.250039
# Unit test for function register
def test_register():
    codecs.lookup(NAME)


register()

# Generated at 2022-06-11 22:07:14.354014
# Unit test for function register
def test_register():
    # Create codecs.register alias
    register_alias = codecs.register

    # Remove the codecs.register function
    del codecs.register

    # Attempt to register the codec.
    # This should raise an AttributeError because of codecs.register has
    # been removed.
    try:
        register()
        assert False
    except AttributeError:
        # Restore the codecs.register function
        codecs.register = register_alias

# Generated at 2022-06-11 22:07:27.925358
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:07:32.248116
# Unit test for function register
def test_register():
    register()  # type: ignore
    codecs.getdecoder(NAME)  # type: ignore
    codecs.getencoder(NAME)  # type: ignore


test_register()

# Generated at 2022-06-11 22:07:33.413757
# Unit test for function register
def test_register():
    register()
    codecs.lookup_error('eutf8h')

# Generated at 2022-06-11 22:07:35.460429
# Unit test for function register
def test_register():
    register()
    register()
    out, _ = codecs.getdecoder(NAME)(b'\\\\xC2\\xA2')
    assert out == '\\xC2\\xA2'



# Generated at 2022-06-11 22:07:38.510091
# Unit test for function register
def test_register():
    """Test to ensure that the codec is registered."""
    assert not codecs.lookup('eutf8h')
    register()
    assert codecs.lookup('eutf8h')

# Generated at 2022-06-11 22:07:42.114925
# Unit test for function register
def test_register():
    global codecs
    codecs = __import__('codecs')
    _get_codec_info(NAME)
    register()
    _get_codec_info(NAME)

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:07:48.765974
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
        has_been_registered = True
    except LookupError:
        has_been_registered = False
    assert has_been_registered is False

    register()
    has_been_registered = False
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        has_been_registered = False
    assert has_been_registered is True

# Generated at 2022-06-11 22:07:51.423540
# Unit test for function register
def test_register():
    codec_info = codecs.lookup(NAME)
    assert codec_info.name == NAME
    assert codec_info.encode == encode
    assert codec_info.decode == decode



# Generated at 2022-06-11 22:07:52.609469
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:07:56.696991
# Unit test for function register
def test_register():
    register()
    a = 'Luis Felipe López Acevedo'
    b = 'Luis Felipe López Acevedo'.encode(NAME)
    assert a == b.decode(NAME)


# Generated at 2022-06-11 22:08:24.086571
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:08:26.271497
# Unit test for function register
def test_register():
    if NAME in codecs.getdecoder(NAME):
        pass
    else:
        register()

# Generated at 2022-06-11 22:08:29.346888
# Unit test for function register
def test_register():
    # pylint: disable=protected-access, deprecated-method

    # Register the codec
    register()

    # Check that the codec is registered.
    assert codecs._search_function(NAME) is not None


register()

# Generated at 2022-06-11 22:08:32.834015
# Unit test for function register
def test_register():
    # This is a bit of a hack, as it tests the entire module, and not just
    # the function register().
    register()
    assert codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:08:34.385956
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:08:36.428223
# Unit test for function register
def test_register():
    _get_codec_info(NAME)



# Generated at 2022-06-11 22:08:37.226721
# Unit test for function register
def test_register():
    """Should not raise exception"""
    register()



# Generated at 2022-06-11 22:08:37.760523
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:08:39.834873
# Unit test for function register
def test_register():
    # Register the codec
    register()

    # Test that the codec name is registered.
    codecs.getdecoder(NAME)  # type: ignore


# Generated at 2022-06-11 22:08:43.370787
# Unit test for function register
def test_register():
    before = codecs.getencoder(NAME)
    register()
    after = codecs.getencoder(NAME)
    assert before is not after



# Generated at 2022-06-11 22:09:41.014379
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
        assert False
    except LookupError:
        register()
        assert codecs.getdecoder(NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:09:45.221653
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)
# Test: Test encoding of \\xC3\\xBC encoded as \\x5C\\x78\\x43\\x33\\x5C\\x78\\x58\\x33

# Generated at 2022-06-11 22:09:51.352957
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-11 22:09:51.950281
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:09:53.333834
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)



# Generated at 2022-06-11 22:09:54.490790
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)      # type: ignore



# Generated at 2022-06-11 22:09:55.717210
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-11 22:09:57.303923
# Unit test for function register
def test_register():
    _test_register(NAME)



# Generated at 2022-06-11 22:09:58.808585
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:10:01.188395
# Unit test for function register
def test_register():
    register()
    # Assert the codec has been registered.
    assert not isinstance(codecs.getdecoder(NAME), LookupError)


# Generated at 2022-06-11 22:12:11.646381
# Unit test for function register
def test_register():
    __name__ = '__main__'
    register()


# Generated at 2022-06-11 22:12:16.924224
# Unit test for function register
def test_register():
    try:
        # Register the codec.
        register()
        # Attempt to use the codec.
        data = 'hi'
        out, _ = codecs.getdecoder(NAME)(data)
        assert out == 'hi'
        out, _ = codecs.getencoder(NAME)(out)
        assert out == b'hi'
    finally:
        codecs.register(_get_codec_info)

# Generated at 2022-06-11 22:12:21.274037
# Unit test for function register
def test_register():
    import codecs
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
    assert codecs.getencoder(NAME)
    assert codecs.getdecoder(NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:12:24.394675
# Unit test for function register
def test_register():
    assert NAME not in codecs.__dict__
    register()
    assert NAME in codecs.__dict__


# Generated at 2022-06-11 22:12:29.205036
# Unit test for function register
def test_register():
    """

    """

    # The codec was not registered so an error should be raised.
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)

    # Register the codec.
    register()

    # Get the codec's CodecInfo object.
    codec_info_obj = codecs.getdecoder(NAME)

    # Assert that the codec name matches the expected value.
    assert codec_info_obj.name == NAME


# Generated at 2022-06-11 22:12:32.646937
# Unit test for function register
def test_register():
    if not codecs.lookup(NAME):
        register()
        if not codecs.lookup(NAME):
            raise AssertionError(
                "Failed to register 'eutf8h' codec in the codecs module."
            )



# Generated at 2022-06-11 22:12:36.307218
# Unit test for function register
def test_register():
    if __name__ == '__main__':
        try:
            codecs.getencoder(NAME)
        except LookupError:
            codecs.register(_get_codec_info)
        # codecs.getencoder(NAME)

if __name__ == '__main__':
    # test_register()
    pass

# Generated at 2022-06-11 22:12:37.333574
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME) is not None

# Generated at 2022-06-11 22:12:40.181844
# Unit test for function register
def test_register():
    """Test the function register."""
    _register = register
    register()
    assert codecs.getdecoder(NAME) == decode
    assert codecs.getencoder(NAME) == encode

# Generated at 2022-06-11 22:12:41.412847
# Unit test for function register
def test_register():
    register()
