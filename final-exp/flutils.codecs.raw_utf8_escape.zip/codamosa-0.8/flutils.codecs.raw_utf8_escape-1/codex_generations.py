

# Generated at 2022-06-11 22:04:41.716426
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-11 22:04:50.918789
# Unit test for function register
def test_register():
    with tempfile.TemporaryDirectory() as tempdir:
        filename = os.path.join(
            tempdir,
            f'{NAME}.txt',
        )
        with open(filename, 'w', encoding=NAME) as file:
            file.write('\u00e9')
            file.write('\\xC3')
            file.write('\\xA9')
            file.close()
        with open(filename, 'r') as file2:
            assert file2.read() == '\\xC3\\xA9\\xC3\\xA9'
            file2.close()

# Generated at 2022-06-11 22:04:54.933178
# Unit test for function register
def test_register():
    register()
    try:
        # noinspection PyUnresolvedReferences
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(
            'The codec %s has not been registered correctly.' % NAME
        )



# Generated at 2022-06-11 22:04:58.274156
# Unit test for function register
def test_register():
    register()
    obj = codecs.getdecoder(NAME)  # type: ignore
    assert obj is type(obj)
    assert obj is not None


test_register()

# Generated at 2022-06-11 22:05:03.194226
# Unit test for function register
def test_register():
    # Test that the codec name is not in the codecs list
    assert NAME not in codecs.list_encodings()
    codecs.register(_get_codec_info)   # type: ignore
    # Test that the codec name is in the codecs list
    assert NAME in codecs.list_encodings()



# Generated at 2022-06-11 22:05:07.508516
# Unit test for function register
def test_register():
    """
    Make sure register() function works.
    """
    from importlib import reload
    reload(codecs)
    register()
    try:
        reload(codecs)
        assert(codecs.getdecoder('eutf8h'))
    except LookupError:
        assert False

# Generated at 2022-06-11 22:05:08.456842
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)

# Generated at 2022-06-11 22:05:14.822864
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        assert False, "CodecInfo for NAME should not exist."

    register()

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'CodecInfo for NAME should exist.'


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:05:17.047241
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise EnvironmentError('Function register() failed to register.')



# Generated at 2022-06-11 22:05:23.088167
# Unit test for function register
def test_register():
    # Verify the codec is not registered.
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)

    # Register the codec.
    register()

    # Verify the codec is registered.
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:05:28.497893
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert True
    else:
        assert False



# Generated at 2022-06-11 22:05:36.954118
# Unit test for function register
def test_register():
    NAME = "test-register"
    global NAME

    # Test that NAME is not registered
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert True
    else:
        assert False

    # Try to register NAME
    register()

    # Test that NAME is now registered
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False
    else:
        assert True



# Generated at 2022-06-11 22:05:37.879837
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore

register()

# Generated at 2022-06-11 22:05:39.317886
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:05:42.081070
# Unit test for function register
def test_register():
    from codecs import lookup
    from unittest.mock import patch
    from escutf8.base import codec_info

    register()
    with patch('escutf8.base.codec_info', new=codec_info):
        info = lookup(NAME)
        assert info.name == NAME
        assert info.encode == encode
        assert info.decode == decode

# Generated at 2022-06-11 22:05:47.793753
# Unit test for function register
def test_register():
    register()
    name: Optional[str] = None
    for codec_tuple in codecs.__dict__['_cache'].values():
        name = codec_tuple[0]
        if name == NAME:
            break
    assert str(name) == NAME  # nosec: B101



# Generated at 2022-06-11 22:05:49.482274
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:05:50.965144
# Unit test for function register
def test_register():
    import _test_module
    _test_module.test_register(NAME, register)

# Generated at 2022-06-11 22:05:56.305133
# Unit test for function register
def test_register():
    import codecs

    _codecs = 'eutf8h'

    try:
        codecs.getdecoder(_codecs)
        assert False
    except LookupError:
        assert True
    register()
    try:
        codecs.getdecoder(_codecs)
        assert True
    except LookupError:
        assert False



# Generated at 2022-06-11 22:06:03.251214
# Unit test for function register
def test_register():
    register()
    obj = codecs.getdecoder(NAME)
    def _test_decode():
        decode(b'a')
        codecs.decode(b'a', NAME)
    def _test_encode():
        encode(b'a')
        codecs.encode(b'a', NAME)
    obj(_test_decode)
    obj(_test_encode)

if __name__ == '__main__':
    register()

# Generated at 2022-06-11 22:06:11.659201
# Unit test for function register
def test_register():
    import codecs

    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:06:14.212108
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:06:16.913543
# Unit test for function register
def test_register():
    codec_info = codecs.lookup("eutf8h")
    assert codec_info.name == NAME


# Generated at 2022-06-11 22:06:19.272912
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'Codec failed to register'



# Generated at 2022-06-11 22:06:22.487819
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError('Cannot get codec decoder')


# Generated at 2022-06-11 22:06:23.935343
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:06:34.256384
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    register()
    s = 'Ǒ'
    b1 = s.encode(NAME)
    s1 = b1.decode(NAME)
    assert s == s1
    print(repr(b1))
    assert len(s) == len(s1)
    assert len(s) == len(b1) == len(s1)
    # assert s == s1
    # assert b1 == s1.encode(NAME, 'strict')
    # print(s, '->', s1)
    # print(b1, '->', b1.decode(NAME))
    # print(b1, '->', b1.decode(NAME, 'strict'))
    # print(repr(b1))


# Generated at 2022-06-11 22:06:34.982849
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:06:36.503696
# Unit test for function register
def test_register():
    try:
        register()
    except Exception:
        pass



# Generated at 2022-06-11 22:06:37.995848
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)  # type: ignore

# Generated at 2022-06-11 22:06:55.967908
# Unit test for function register
def test_register():
    # Test that the 'eutf8h' codec has not been registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError()

    # Test that the 'eutf8h' codec has been successfully registered.
    register()
    codecs.getdecoder(NAME)


_StrPair
_ByteStringPair
_StrStrPair
_StrByteStringPair



# Generated at 2022-06-11 22:06:59.553810
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'Codec "%s" not found' % NAME



# Generated at 2022-06-11 22:07:06.361251
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    try:
        assert NAME in codecs.getaliases()
        assert NAME in codecs.getaliases()
        assert NAME in codecs.getencodings()
    finally:
        del codecs.getencodings()[NAME]
        del codecs.getencodings()[NAME]
        del codecs.getaliases()[NAME]
        del codecs.getaliases()[NAME]
        del codecs.getaliases()[NAME]
        del codecs.getaliases()[NAME]

# Generated at 2022-06-11 22:07:07.499684
# Unit test for function register
def test_register():
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-11 22:07:11.028615
# Unit test for function register
def test_register():
    orig_getdecoder = codecs.getdecoder

    def mock_getdecoder(encoding):
        # type: (str) -> codecs.CodecInfo
        if encoding == NAME:
            raise LookupError
        return orig_getdecoder(encoding)

    with mock.patch.object(codecs, 'getdecoder', mock_getdecoder):
        register()

    assert codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:07:14.946914
# Unit test for function register
def test_register():
    register()
    # noinspection PyUnresolvedReferences
    import codecs
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:07:16.261414
# Unit test for function register
def test_register():
    import codecs
    codecs.register(_get_codec_info)

# Generated at 2022-06-11 22:07:18.852637
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# Generated at 2022-06-11 22:07:21.332247
# Unit test for function register
def test_register():
    import sys

    c = sys.modules['eutf8h']
    del sys.modules['eutf8h']
    import eutf8h
    sys.modules['eutf8h'] = c

    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:07:25.509488
# Unit test for function register
def test_register():
    # If not already registered, register "eutf8h" codec.
    codecs.register(_get_codec_info)



# Generated at 2022-06-11 22:07:48.852896
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError


# Generated at 2022-06-11 22:07:51.205987
# Unit test for function register
def test_register():
    """Unit test for function register"""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise


# Generated at 2022-06-11 22:07:53.685866
# Unit test for function register
def test_register():
    register()

    assert NAME == 'eutf8h'
    assert codecs.getencoder(NAME)
    assert codecs.getdecoder(NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:07:54.976188
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-11 22:08:00.758903
# Unit test for function register
def test_register():
    import sys
    import unittest

    # If the 'eutf8h' codec is not registered, then register it.
    try:
        codecs.getdecoder('eutf8h')
    except LookupError:
        register()

    # Define a test case class that tests the 'eutf8h' codec.
    class Test_eutf8h(unittest.TestCase):
        # Unit test for function encode
        def test_encode(self):
            # Encoding only ascii characters
            text = 'The quick, brown fox.'
            text_encoded, text_consumed = codecs.encode(
                text,
                'eutf8h',
                errors='strict',
            )
            self.assertEqual(text, text_encoded.decode('eutf8h'))


# Generated at 2022-06-11 22:08:04.313384
# Unit test for function register
def test_register():
    import codecs
    codecs.register(_get_codec_info)
    try:
        _ = codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError('Failed to register codec.eutf8h')



# Generated at 2022-06-11 22:08:06.387232
# Unit test for function register
def test_register():
    """
    """
    print('\nUnit test for function register')
    register()
    print('Passed')


# Generated at 2022-06-11 22:08:08.880045
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore


# Generated at 2022-06-11 22:08:15.349194
# Unit test for function register
def test_register():
    global NAME

    NAME = 'test'

    codecs.register = Mock()

    codecs.getdecoder = Mock(
        side_effect=LookupError,
        return_value=Mock()
    )

    register()

    assert (
        codecs.register.call_args_list ==
        [call(_get_codec_info)]
    )



# Generated at 2022-06-11 22:08:20.884763
# Unit test for function register
def test_register():
    """
    Test _get_codec_info, _each_utf8_hex and _codec_info.

    """
    obj = _get_codec_info(NAME)
    assert obj is not None

    assert bytes not in (bytes, bytearray, memoryview, type(None))
    assert bytes == cast(type, bytes)

    assert bytes is not None
    assert bytearray is not None
    assert memoryview is not None



# Generated at 2022-06-11 22:09:06.512644
# Unit test for function register
def test_register():
    register()

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert(False)


# Generated at 2022-06-11 22:09:13.570993
# Unit test for function register

# Generated at 2022-06-11 22:09:15.475339
# Unit test for function register
def test_register():
    func = _get_codec_info
    codecs.register(func)   # type: ignore



# Generated at 2022-06-11 22:09:20.442862
# Unit test for function register
def test_register():
    """Unit testing for the function `register` in the module."""
    register()
    try:
        codecs.getencoder(NAME)
    except LookupError:
        assert False, 'getencoder failed'
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'getdecoder failed'



# Generated at 2022-06-11 22:09:25.557235
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)


if __name__ == '__main__':

    register()

    text = 'Hello\u0080 World!\u00A0 How are you doing?'

    text_bytes_utf8, consumed = encode(text, 'replace')
    text_str = decode(text_bytes_utf8, 'strict')[0]
    print(text_str)

    print(text)

# Generated at 2022-06-11 22:09:28.666628
# Unit test for function register
def test_register():
    register()
    # noinspection PyUnresolvedReferences
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:09:30.423719
# Unit test for function register
def test_register():
    assert codecs.getdecoder(NAME) == _get_codec_info(NAME)



# Generated at 2022-06-11 22:09:32.748002
# Unit test for function register
def test_register():
    codecs.register = lambda _: None
    import eutf8hex
    eutf8hex.register()
    assert codecs.getencoder(NAME)

# Generated at 2022-06-11 22:09:39.883588
# Unit test for function register
def test_register():

    # Confirm that we can't currently decode 'eutf8h' public codec.
    try:
        codecs.getdecoder('eutf8h')
        assert False, 'FAIL codecs.getdecoder(\'eutf8h\')'
    except LookupError:
        assert True, 'PASS codecs.getdecoder(\'eutf8h\')'

    # Register the 'eutf8h' codec
    register()

    # Confirm that we can decode 'eutf8h' public codec.
    try:
        codecs.getdecoder('eutf8h')
        assert True, 'PASS codecs.getdecoder(\'eutf8h\')'
    except LookupError:
        assert False, 'FAIL codecs.getdecoder(\'eutf8h\')'

    # Check that we

# Generated at 2022-06-11 22:09:41.555393
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:11:18.688426
# Unit test for function register
def test_register():
    assert NAME not in codecs.list_encodings()
    register()
    assert NAME in codecs.list_encodings()
    return


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:11:19.978411
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:11:25.287357
# Unit test for function register
def test_register():
    register()

    out = codecs.getdecoder(NAME)
    assert out is not None
    assert out[1] == decode
    assert out[2] == 'strict'



# Generated at 2022-06-11 22:11:26.624259
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) != None


# Generated at 2022-06-11 22:11:31.620392
# Unit test for function register
def test_register():
    import string
    import unittest

    class TestRegister(unittest.TestCase):
        def test_register(self) -> None:
            # type: () -> None
            codecs.register(_get_codec_info)

            for i in range(1000):
                text = ''.join(string.ascii_letters)
                text_bytes = text.encode(NAME)
                text_str = text_bytes.decode(NAME)
                self.assertEqual(text, text_str)

    unittest.main()


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:11:37.537008
# Unit test for function register
def test_register():
    # Test that the codec has not been registered yet
    try:
        _ = codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise Exception('The codec has already been registred.')

    # Register the codec
    register()

    # Test that the codec has been registered
    try:
        _ = codecs.getdecoder(NAME)
    except Exception as e:
        raise e
    else:
        pass
    finally:
        pass



# Generated at 2022-06-11 22:11:42.751114
# Unit test for function register
def test_register():
    from sys import modules
    from importlib import reload

    name = 'scalpl.cutter._eutf8h'
    mod = modules.get(name)
    if mod:
        reload(mod)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:11:43.561730
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:11:46.300950
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore



# Generated at 2022-06-11 22:11:47.071027
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)