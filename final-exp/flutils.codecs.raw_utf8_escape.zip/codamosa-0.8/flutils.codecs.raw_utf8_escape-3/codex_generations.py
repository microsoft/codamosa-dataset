

# Generated at 2022-06-11 22:04:37.789918
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)

# Generated at 2022-06-11 22:04:41.229884
# Unit test for function register
def test_register():

    assert NAME in codecs.getdecoder('eutf8h')

# Generated at 2022-06-11 22:04:46.141561
# Unit test for function register
def test_register():
    T_NAME = __name__ + '.register'
    print('{}. Testing..'.format(T_NAME))
    register()
    codecs.getdecoder(NAME)
    print('{}. OK: no exception raised.'.format(T_NAME))



# Generated at 2022-06-11 22:04:49.847299
# Unit test for function register
def test_register():
    # Required for integration testing - pylint: disable=unused-variable
    from unittest import TestCase
    class Register(TestCase):  # type: ignore
        def test_register(self):
            register()




# Generated at 2022-06-11 22:04:51.931840
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-11 22:04:56.248422
# Unit test for function register
def test_register():
    import codecs
    codecs.register(_get_codec_info)
    try:
        codecs.getencoder(NAME)
    except LookupError as e:
        raise e
        print('Failed to find codec', NAME)
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise e
        print('Failed to find codec', NAME)



# Generated at 2022-06-11 22:05:07.250202
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME) is not None


if __name__ == '__main__':
    # Unit test for function encode
    def test_encode():
        text = 'H㏒āíóú'
        out = b'H\\xE3\\x8F\\x92\\xC4\\x81\\xC3\\xAD\\xC3\\xB3\\xC3\\xBA'
        assert encode(text)[0] == out
        assert encode(text)[1] == len(text)

    test_encode()

    # Unit test for function decode
    def test_decode():
        text = 'H㏒āíóú'

# Generated at 2022-06-11 22:05:08.546672
# Unit test for function register
def test_register():
    """Check to see if the codec has already been registered"""
    register()



# Generated at 2022-06-11 22:05:11.269697
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)  # type: ignore


# Unit tests for function encode:

# Generated at 2022-06-11 22:05:13.775604
# Unit test for function register
def test_register():
    register()
    codec = codecs.getdecoder(NAME)
    assert codec[0] is decode
    codec = codecs.getencoder(NAME)
    assert codec[0] is encode


# Generated at 2022-06-11 22:05:16.625695
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:05:20.237532
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore



# Generated at 2022-06-11 22:05:20.883760
# Unit test for function register
def test_register():
    register()

register()

# Generated at 2022-06-11 22:05:23.330043
# Unit test for function register
def test_register():
    register()
    eutf8h_codec_info = codecs.getdecoder(NAME)
    assert NAME == eutf8h_codec_info.name



# Generated at 2022-06-11 22:05:32.061717
# Unit test for function register
def test_register():
    """Test the function :func:`register`."""
    try:
        codecs.lookup_error(NAME)
        assert False, 'should not be able to lookup NAME before register'
    except LookupError:
        pass
    register()
    assert codecs.lookup_error(NAME)
    codecs.register(_get_codec_info)
    assert codecs.lookup_error(NAME)
    try:
        codecs.register(_get_codec_info)
    except LookupError:
        pass



# Generated at 2022-06-11 22:05:34.016091
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore


# Generated at 2022-06-11 22:05:37.228376
# Unit test for function register
def test_register():
    '''
    Test that the name that the register function is registering
    is not already registered.
    '''
    with patch.object(codecs, 'getdecoder', return_value=None):
        register()



# Generated at 2022-06-11 22:05:37.910999
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:05:40.783484
# Unit test for function register
def test_register():
    register()
    message = "Hằng thì nói cái nào mà thế thì để của người kia mà"
    encoded = message.encode('eutf8h')
    decoded = encoded.decode('eutf8h')
    assert(message == decoded)

# Generated at 2022-06-11 22:05:52.593673
# Unit test for function register
def test_register():
    import unittest
    import sys
    from contextlib import contextmanager

    @contextmanager
    def my_stderr():
        old_stderr = sys.stderr
        sys.stderr = res = StringIO()
        try:
            yield res
        finally:
            sys.stderr = old_stderr

    # Test that the codec is registered.
    # class TestCodec(unittest.TestCase):
    #     def test_register(self):
    #         with my_stderr() as out:
    #             register()
    #         self.assertIn('registering ', out.getvalue())

    # Test that the codec is already registered.

# Generated at 2022-06-11 22:05:55.138097
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-11 22:06:06.703693
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    # Unit test for function decode
    def test_decode():
        out_str, _ = decode(b'\\xe2\\x98\\x83')
        assert out_str == '\N{WHITE SUN WITH RAYS}'

        out_str, _ = decode(b'\\xe2\\x98\\x83\\xe2\\x98\\x83')
        assert out_str == '\N{WHITE SUN WITH RAYS}\N{WHITE SUN WITH RAYS}'

    # Unit test for function encode
    def test_encode():
        out_bytes, _ = encode('\N{WHITE SUN WITH RAYS}')
        assert out_bytes == b'\\xe2\\x98\\x83'


# Generated at 2022-06-11 22:06:10.569340
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:06:21.982633
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore


# This is the script that is run when this file is executed.
if __name__ == '__main__':
    register()

    # If a utf8 hexadecimal escapes an invalid utf8 byte, an error is thrown.
    bad_utf8 = '\\xf1\\x80'
    try:
        bad_utf8.encode(NAME)
    except UnicodeEncodeError as e:
        assert e.encoding == NAME
        assert e.object == bad_utf8
        assert e.start == 0
        assert e.end == 2

    # If a utf8 escapes an invalid utf8 byte, an error is thrown.
    bad_utf8 = '\xf1\x80'

# Generated at 2022-06-11 22:06:23.941225
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)

register()



# Generated at 2022-06-11 22:06:25.320173
# Unit test for function register
def test_register():
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:06:30.773865
# Unit test for function register
def test_register():
    old_codec_info_map = codecs.codec_info_map.copy()
    try:
        register()
        assert NAME in codecs.codec_info_map
    finally:
        codecs.codec_info_map = old_codec_info_map


# noinspection PyUnusedLocal

# Generated at 2022-06-11 22:06:34.561910
# Unit test for function register
def test_register():
    """Test function register().

    Try to register the codec. If already registered, the function
    will return silently.

    """
    register()



# Generated at 2022-06-11 22:06:35.874668
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:06:46.175789
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)
    finally:
        codecs.unregister(_get_codec_info)


if __name__ == "__main__":
    test_register()
    print(encode('This\u00a0is\u00a0a\u00a0test'))
    print(decode(b'This\\xC2\\xA0is\\xC2\\xA0a\\xC2\\xA0test'))
    print(decode(b'This\\xC2\\xA0is\\xC2\\xA0a\\xC2\\xA0test', 'replace'))
    print(encode('\xC2\xA0'))

# Generated at 2022-06-11 22:06:55.566521
# Unit test for function register
def test_register():
    try:
        codecs.getencoder(NAME)
    except LookupError:
        register()
        _codec_info = codecs.getencoder(NAME)
        assert _codec_info is not None
        assert _codec_info.encode is not None
        assert _codec_info.decode is not None

# Generated at 2022-06-11 22:06:57.886143
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)  # type: ignore
    except LookupError:
        pass
    else:
        raise Exception(
            'Registered codec {!r} should not exist.'.format(NAME)
        )
    from eutf8h import register
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:07:01.896997
# Unit test for function register
def test_register():
    register()
    with pytest.raises(UnicodeDecodeError) as err:
        codecs.decode('abc', encoding=NAME)
    assert str(err.value) == "'eutf8h' codec can't decode byte 0x61 in position 0: end of string in escape sequence"


# Generated at 2022-06-11 22:07:03.551679
# Unit test for function register
def test_register():
    try:
        import eutf8h
        eutf8h.register()
    except LookupError:
        pass

# Generated at 2022-06-11 22:07:05.587892
# Unit test for function register
def test_register():
    register()
    # noinspection PyUnresolvedReferences
    data = codecs.getdecoder(NAME)


register()



# Generated at 2022-06-11 22:07:06.378387
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-11 22:07:08.446735
# Unit test for function register
def test_register():
    """Test the function register()."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:07:15.895435
# Unit test for function register
def test_register():
    test_getdecoder = None
    test_getencoder = None
    log_str = ''

    def mock_getdecoder(charset: str) -> codecs.CodecInfo:
        nonlocal test_getdecoder
        test_getdecoder = charset
        return codecs.CodecInfo(
            name=charset,
            encode=None,
            decode=None,
        )

    def mock_getencoder(charset: str) -> codecs.CodecInfo:
        nonlocal test_getencoder
        test_getencoder = charset
        return codecs.CodecInfo(
            name=charset,
            encode=None,
            decode=None,
        )


# Generated at 2022-06-11 22:07:21.848170
# Unit test for function register
def test_register():
    # Check that this codec is not registered yet.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        # Register this codec.
        register()

        # Check that this codec was successfully registered.
        codecs.getdecoder(NAME)

        return

    raise RuntimeError('module is already registered')



# Generated at 2022-06-11 22:07:25.860229
# Unit test for function register
def test_register():
    assert 'eutf8h' not in codecs.codecs
    register()
    assert 'eutf8h' in codecs.codecs

# Generated at 2022-06-11 22:07:35.377559
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)  # type: ignore
    assert codecs.getdecoder(NAME) is not None  # type: ignore



# Generated at 2022-06-11 22:07:36.537616
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-11 22:07:38.972065
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder('eutf8h')
    codecs.getencoder('eutf8h')

# Generated at 2022-06-11 22:07:43.164465
# Unit test for function register
def test_register():
    assert NAME not in codecs.lookup()
    register()
    codecs.lookup(NAME)
    for key in codecs.lookup(NAME):
        assert key in ['encode', 'decode', 'incrementalencoder', 'incrementaldecoder', 'streamwriter', 'streamreader']


# Generated at 2022-06-11 22:07:45.396942
# Unit test for function register
def test_register():

    register()

    assert codecs.lookup(NAME)


# Generated at 2022-06-11 22:07:46.783475
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore

# Generated at 2022-06-11 22:07:52.242618
# Unit test for function register
def test_register():
    """Test function :function:`~register`"""
    register()
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)
    assert codecs.lookup(NAME)
    text = '\\x21'
    assert codecs.lookup(NAME).encode(text)[0] == b'!'
    assert codecs.lookup(NAME).decode(b'\x21')[0] == '!'



# Generated at 2022-06-11 22:07:53.236551
# Unit test for function register
def test_register():
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-11 22:07:59.235602
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore

    text_str = '\u0264'
    text_bytes_utf8 = text_str.encode('utf8')
    text_bytes_utf8 = cast(bytes, text_bytes_utf8)
    text_bytes_utf8_str_hex = bytes(text_bytes_utf8).hex()
    text_bytes_utf8_str_hex_str = '\\x%s' % text_bytes_utf8_str_hex

    data = text_bytes_utf8_str_hex_str.encode(NAME)

    out = data.decode(NAME)

    assert out == text_str


test_register()

# Generated at 2022-06-11 22:08:00.802748
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder('eutf8h')

# Generated at 2022-06-11 22:08:20.795058
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    try:
        codecs.lookup_error('eutf8h')
    except LookupError as e:
        assert str(e) == "unknown error handler name 'eutf8h'"



# Generated at 2022-06-11 22:08:25.655474
# Unit test for function register
def test_register():
    """Test this module's register function."""
    import sys
    import eutf8hex
    sys.modules['eutf8hex'] = eutf8hex
    import eutf8h
    eutf8h.register()
    del sys.modules['eutf8hex']
    del sys.modules['eutf8h']

# Generated at 2022-06-11 22:08:28.946606
# Unit test for function register
def test_register():
    try:
        # noinspection PyUnresolvedReferences
        import test_register
        import codecs
        codecs.getdecoder(NAME)
    except LookupError:
        raise Exception



# Generated at 2022-06-11 22:08:39.312311
# Unit test for function register
def test_register():
    NAME = 'eutf8h'
    codecs.register(_get_codec_info)
    decoder = codecs.getdecoder(NAME)
    try:
        decoder.decode(b'\\xe2\\x82\\xac')
    except UnicodeDecodeError:
        pass


if __name__ == '__main__':
    import unittest
    from lib.helpers.str_helper import from_hex

    class TestEscapedUtf8HexCodec(unittest.TestCase):

        def test_register(self):
            """Ensure that the codec is installed."""
            self.assertIsNotNone(
                codecs.getdecoder(NAME),
                '%r is not installed.' % NAME,
            )


# Generated at 2022-06-11 22:08:51.172448
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    register()
    try:
        encoded_data = u'\\x80\\x81\\x82\\x83'.encode(NAME, 'strict')
    except UnicodeEncodeError as e:
        # print(f'{e.__class__.__name__}: {e}')
        print(f'{e.__class__.__name__}: {e.encoding} {e.object} {e.start} '
              f'{e.end} {e.reason}')
    else:
        print(f'encoded_data: {encoded_data}')


# Generated at 2022-06-11 22:08:52.112809
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)

# Generated at 2022-06-11 22:08:54.256355
# Unit test for function register
def test_register():
    # codecs.register(_get_codec_info)
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:08:57.778693
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False

if __name__ == '__main__':
    sys.exit(test_register())

# Generated at 2022-06-11 22:08:59.103988
# Unit test for function register
def test_register():
    # noinspection PyUnresolvedReferences
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    register()
    test_register()
    print(help(register))

# Generated at 2022-06-11 22:08:59.994700
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:09:37.063558
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    codecs.getdecoder(NAME)
    try:
        codecs.getencoder(NAME)
    except LookupError:
        raise AssertionError()


# Generated at 2022-06-11 22:09:38.265953
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:09:40.669836
# Unit test for function register
def test_register():
    register()
    info = codecs.getdecoder(NAME)
    assert info.name == NAME

# Generated at 2022-06-11 22:09:42.719942
# Unit test for function register
def test_register():
    # Function register should not raise an exception.
    register()

# Unit tests for function encode

# Generated at 2022-06-11 22:09:43.926670
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)


# Generated at 2022-06-11 22:09:50.574318
# Unit test for function register
def test_register():
    # Verify that register is not called.
    _orig_get_codec_info = codecs.getdecoder
    _mock_get_codec_info = mock.MagicMock(  # type: ignore
        return_value=None,
        side_effect=_orig_get_codec_info
    )
    with mock.patch('codecs.getdecoder', _mock_get_codec_info):
        register()
        _mock_get_codec_info.assert_called_once_with(NAME)
        _mock_get_codec_info.side_effect = None
    assert not _mock_get_codec_info.called

    # Verify that register is called.

# Generated at 2022-06-11 22:09:53.203938
# Unit test for function register
def test_register():
    # There is no way for me to know that this function is already
    # registered. For example, if I run the test suite more than
    # once.
    register()



# Generated at 2022-06-11 22:09:55.355154
# Unit test for function register
def test_register():
    """Just ensure the codec is registered.

    """
    register()
    assert NAME in codecs.list_encodings()



# Generated at 2022-06-11 22:09:59.440981
# Unit test for function register
def test_register():
    register()
    codecs.decode(
        '\\x61\\x62\\x63',
        encoding=NAME
    )
    codecs.encode(
        'hello world',
        encoding=NAME
    )

# Generated at 2022-06-11 22:10:00.955341
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:11:23.494168
# Unit test for function register
def test_register():
    class C:
        pass
    # noinspection PyTypeChecker
    codecs.register(C())



# Generated at 2022-06-11 22:11:24.442811
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:11:28.686184
# Unit test for function register
def test_register():
    register()
    # Make sure the codec is registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise RuntimeError(
            f'Codec name "{NAME}" is not registered.'
            f' Exception caught: {str(e)}'
        )


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:11:29.868316
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore


# Generated at 2022-06-11 22:11:34.261928
# Unit test for function register
def test_register():
    if __name__ != '__main__':
        return

    from importlib import reload

    reload(__import__('codecs'))

    register()

    from codecs import getdecoder, getencoder

    getencoder(NAME)
    getdecoder(NAME)



# Generated at 2022-06-11 22:11:35.564584
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-11 22:11:36.478186
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:11:37.789876
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-11 22:11:39.854440
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:11:41.058195
# Unit test for function register
def test_register():
    pass

# Generated at 2022-06-11 22:14:27.904428
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:14:32.605255
# Unit test for function register
def test_register():
    '''Register the codec function for encoding and decoding with
    the given codec name.

    Args:
        None.

    Returns:
        None.

    Raises:
        None.

    '''
    register()
    codecs.getdecoder(NAME)
    # codecs.getencoder(NAME)



# Generated at 2022-06-11 22:14:33.415423
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)