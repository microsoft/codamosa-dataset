

# Generated at 2022-06-11 22:04:42.881240
# Unit test for function register
def test_register():
    register()
    utf8_b = 'Some utf8 with an invalid sequence like \\xA6B'.encode('utf-8')
    eutf8hex = encode(utf8_b)[0]
    # noinspection PyTypeChecker
    assert decode(eutf8hex)[0] == 'Some utf8 with an invalid sequence like \xA6B'  # type: ignore[call-overload]



# Generated at 2022-06-11 22:04:44.610997
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)
        assert codecs.getdecoder(NAME)
        return
    raise Exception('Codec already registered')

# Generated at 2022-06-11 22:04:54.288274
# Unit test for function register
def test_register():
    """Test the module's ``register()`` function."""
    register()
    name = NAME
    # If a codec is already registered, then a LookupError is
    # raised.
    try:
        codecs.register(_get_codec_info)   # type: ignore
    except LookupError:
        pass
    else:
        raise Exception(
            'codecs.register() did not raise an exception'
        )
    try:
        codecs.getdecoder(name)
    except LookupError:
        raise Exception(
            f'eutf8h codec not registered for codecs.getdecoder()'
        )

# Generated at 2022-06-11 22:04:55.342518
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:04:56.874378
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getencodings()



# Generated at 2022-06-11 22:04:58.019922
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore



# Generated at 2022-06-11 22:04:58.596276
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:05:01.237586
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)
    finally:
        register()

# Generated at 2022-06-11 22:05:07.131002
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        if True:
            codecs.register(_get_codec_info)
        else:
            raise
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise Exception(
            'Failed to register codec for %s' % NAME
        )


# Generated at 2022-06-11 22:05:08.743424
# Unit test for function register
def test_register():
    # Given
    register()

    # When
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:05:15.238680
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:05:18.237901
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)
    codecs.getincrementalencoder(NAME)
    codecs.getincrementaldecoder(NAME)

test_register()



# Generated at 2022-06-11 22:05:23.449053
# Unit test for function register
def test_register():
    try:
        # noinspection PyUnresolvedReferences
        codecs.getdecoder(NAME)
    except LookupError:
        assert True
    else:
        assert False


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:05:27.616488
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)



# Generated at 2022-06-11 22:05:37.310572
# Unit test for function register
def test_register():
    from codecs import lookup
    from itertools import chain

    register()
    name = NAME

    # We need to get the codec again, otherwise we get an error during
    # the register.
    codec = lookup(name)

    assert codec.name == name

    text_str = 'I am [\\x74\\x68\\x65] text string'

    text_str_expect = 'I am [\u0074\u0068\u0065] text string'

    text_bytes = text_str.encode('eutf8h')

    text_bytes_expect = text_str_expect.encode('utf-8')

    assert text_bytes == text_bytes_expect

    text_decode = text_bytes.decode(name)

    assert text_decode == text_str_expect



# Generated at 2022-06-11 22:05:38.230916
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:05:39.418676
# Unit test for function register
def test_register():
    # The following function call is required for the registration to take effect.
    register()
    _ = codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:05:43.295224
# Unit test for function register
def test_register():
    register()

    entry = codecs.lookup(NAME)

    assert entry.name == NAME
    assert entry.encode(('b', 'a')) == (b'\\x62\\x61', 2)
    assert entry.decode(b'\\x62\\x61') == ('b\u0061', 4)
    assert entry.encode(('b', '\u0061')) == (b'\\x62\\x61', 2)
    assert entry.decode(b'\\x62\\x61') == ('b\u0061', 4)



# Generated at 2022-06-11 22:05:45.765593
# Unit test for function register
def test_register():
    """Test the register function"""
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:05:52.478958
# Unit test for function register
def test_register():
    # pylint: disable=missing-docstring
    register()
    name = NAME
    codec = codecs.getdecoder(name)
    assert (codec.__name__ == 'decode')
    codec = codecs.getencoder(name)
    assert (codec.__name__ == 'encode')
    try:
        codecs.getdecoder('not_found')
    except LookupError:
        pass

# Generated at 2022-06-11 22:05:59.435153
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:06:01.626215
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:06:05.284760
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    obj = codecs.getdecoder(NAME)
    assert obj[0].__name__ == 'decode'



# Generated at 2022-06-11 22:06:09.772557
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getencodings()

# Generated at 2022-06-11 22:06:10.345184
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:06:16.279276
# Unit test for function register
def test_register():
    """Unit test for function register()"""
    try:
        codecs.getdecoder(NAME)
        assert False
    except LookupError:
        assert True
    register()
    codecs.getdecoder(NAME)  # should not raise an exception


# Generated at 2022-06-11 22:06:21.460505
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)
    out_bytes, consumed = codecs.getencoder(NAME)('a')
    assert out_bytes == b'\\x61'
    assert consumed == 1

    out_str, consumed = codecs.getdecoder(NAME)(b'a')
    assert out_str == 'a'
    assert consumed == 1



# Generated at 2022-06-11 22:06:33.558023
# Unit test for function register
def test_register():
    from builtins import UnicodeEncodeError
    from builtins import UnicodeDecodeError
    from enum import Enum
    from itertools import count
    from typing import Dict
    from typing import List
    from typing import Tuple

    class _Test(Enum):
        """Test char-to-char conversion."""

        @classmethod
        def _gen(cls) -> Generator[Tuple[str, str], None, None]:
            for char in cls:
                # The first and last characters are the '\' and 'x'
                # escape character.
                yield '\\', '\\'
                str_hex = hex(char.value)[2:]
                if len(str_hex) % 2 == 1:
                    str_hex = '0' + str_hex

# Generated at 2022-06-11 22:06:36.645867
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getencoder(NAME)
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'codec.register failed'

# Generated at 2022-06-11 22:06:38.118136
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:06:57.956908
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    try:
        eutf8h_decode = codecs.getdecoder(NAME)
        assert eutf8h_decode
        eutf8h_encode = codecs.getencoder(NAME)
        assert eutf8h_encode
    except LookupError:
        assert False



# Generated at 2022-06-11 22:07:01.948344
# Unit test for function register
def test_register():
    assert codecs.lookup_error('eutf8h') is UnicodeDecodeError
    assert codecs.lookup_error('EUTF8H') is UnicodeEncodeError
    assert codecs.lookup(NAME) is not None
    assert codecs.lookup(NAME).name == NAME
    pass



# Generated at 2022-06-11 22:07:03.636711
# Unit test for function register
def test_register():
    register()
    result = codecs.getdecoder(NAME)
    assert result is not None



# Generated at 2022-06-11 22:07:05.945074
# Unit test for function register
def test_register():
    # Register the codec
    register()

    # Test that the codec has been registered
    with codec_manager('eutf8h') as manager:
        assert manager.name == NAME

# Generated at 2022-06-11 22:07:07.071166
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)



# Generated at 2022-06-11 22:07:08.983771
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME).name == NAME, 'codecs.register failed'
    codecs.lookup  # type: ignore



# Generated at 2022-06-11 22:07:11.233988
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME)
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:07:14.530766
# Unit test for function register
def test_register():
    register()
    # Success if function does not raise an exception
    assert True



# Generated at 2022-06-11 22:07:17.695629
# Unit test for function register
def test_register():
    for name in [NAME, 'foo']:
        codecs.register(_get_codec_info)
        a = codecs.lookup(name)
        assert a



# Generated at 2022-06-11 22:07:23.930717
# Unit test for function register
def test_register():
    obj = codecs.CodecInfo(  # type: ignore
        name=NAME,
        encode=encode,
        decode=decode,
    )
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(obj)

    try:
        assert codecs.getdecoder(NAME)
    finally:
        obj = codecs.lookup(NAME)
        codecs.unregister(obj)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:07:48.204176
# Unit test for function register
def test_register():

    # The call to function register should be ignored when this file
    # is imported as a module.
    if '__main__' == __name__:
        register()


# Generated at 2022-06-11 22:07:55.916530
# Unit test for function register
def test_register():
    # Create a custom codec
    class MyCodec(object):
        class Codec(object):
            def encode(self, text: str, errors: str) -> Tuple[bytes, int]:
                return text.encode(errors), len(text)

            def decode(self, data: bytes, errors: str) -> Tuple[str, int]:
                return data.decode(errors), len(data)

        def __init__(self) -> None:
            self.codec = MyCodec.Codec()

        def register_codec(self) -> None:
            codecs.register(self._get_codec_info)

        def _get_codec_info(self, name: str) -> Optional[codecs.CodecInfo]:
            if name == 'mycodec':
                obj = codecs.CodecInfo

# Generated at 2022-06-11 22:07:57.653787
# Unit test for function register
def test_register():
    register()
    # noinspection PyUnresolvedReferences
    assert NAME in codecs.getdecoder(NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:08:06.433722
# Unit test for function register
def test_register():
    from jotdown.build.text import text_register
    # Temporarily deregister the current codecs.
    codecs.getdecoder(NAME)
    for name in text_register.POSSIBLE_NAMES:
        try:
            codecs.getdecoder(name)
        except LookupError:
            codecs.register(text_register._get_codec_info)
    # Resume the regular codecs, and register the current codec.
    register()
    for name in text_register.POSSIBLE_NAMES:
        try:
            codecs.getdecoder(name)
        except LookupError:
            codecs.register(text_register._get_codec_info)

# Generated at 2022-06-11 22:08:10.485404
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)  # type: ignore
    codecs.getencoder(NAME)  # type: ignore
    codecs.getincrementalencoder(NAME)  # type: ignore
    codecs.getincrementaldecoder(NAME)  # type: ignore


# Generated at 2022-06-11 22:08:11.431513
# Unit test for function register
def test_register():
    codecs.lookup(NAME)

# Generated at 2022-06-11 22:08:19.962055
# Unit test for function register
def test_register():
    assert codecs.lookup_error('strict').name == 'strict'
    assert codecs.lookup_error('replace').name == 'replace'
    assert codecs.lookup_error('ignore').name == 'ignore'
    assert codecs.lookup_error('backslashreplace').name == 'backslashreplace'
    assert codecs.lookup_error('namereplace').name == 'namereplace'
    assert codecs.lookup_error('xmlcharrefreplace').name == 'xmlcharrefreplace'
    assert codecs.lookup_error('surrogateescape').name == 'surrogateescape'
    assert codecs.lookup_error('surrogatepass').name == 'surrogatepass'
    codecs.register(_get_codec_info)

# Generated at 2022-06-11 22:08:26.579029
# Unit test for function register
def test_register():
    codecs._cache.clear()
    codecs._unknown_error_encode.clear()
    register()


__all__ = [
    'encode',
    'decode',
    'register',
]

if __name__ == '__main__':
    import sys
    register()
    print(encode(sys.argv[1]))
    print(decode(sys.argv[1].encode(NAME)))

# Generated at 2022-06-11 22:08:30.959536
# Unit test for function register
def test_register():
    # noinspection SpellCheckingInspection
    uniquestring = '\u0278\u0279'
    orig_str = '%s%s' % (NAME, uniquestring)
    utf_bytes = orig_str.encode('utf-8')
    register()
    out = utf_bytes.decode(NAME)
    assert(out == orig_str)

# Generated at 2022-06-11 22:08:40.131428
# Unit test for function register
def test_register():
    register()

    def hello(name: str) -> str:
        return 'hello ' + name

    ho = hello('world')
    ho = hello(ho)

    # noinspection DuplicatedCode
    def encode(*args, **kwargs) -> Tuple[bytes, int]:
        return encode(*args, **kwargs)

    # noinspection DuplicatedCode
    def decode(*args, **kwargs) -> Tuple[str, int]:
        return decode(*args, **kwargs)

    assert codecs.getdecoder(NAME) == (decode, 0)

    assert codecs.getencoder(NAME) == (encode, 0)

    # following will throw an exception unless codec is registered.
    # codecs.decode('hello world', 'eutf8h')



# Generated at 2022-06-11 22:09:26.414586
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:09:28.818050
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-11 22:09:31.000682
# Unit test for function register
def test_register():
    import sys
    try:
        sys.getfilesystemencoding()
    except LookupError:
        register()



# Generated at 2022-06-11 22:09:33.647891
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False
    else:
        assert True



# Generated at 2022-06-11 22:09:37.487520
# Unit test for function register
def test_register():
    import sys
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
    finally:
        assert codecs.getdecoder(NAME).decode   # type: ignore
        print('Test {} is successful'.format(sys._getframe().f_code.co_name))


# Generated at 2022-06-11 22:09:44.997777
# Unit test for function register
def test_register():
    # noinspection PyUnresolvedReferences
    from codecs import lookup
    # noinspection PyUnresolvedReferences
    from _testcapi import register_module, get_codec_name  # type: ignore
    name = get_codec_name('eutf8h')

    # Register the codec as a module
    register_module(name)

    # Get the registered codec
    out = lookup(name)

    # Check that the codec returned is the expected codec
    assert out.name == NAME
    assert out.encode == encode
    assert out.decode == decode



# Generated at 2022-06-11 22:09:47.040143
# Unit test for function register
def test_register():
    _register()
    # do the function under test
    register()
    # Now make sure the function call had the desired effect
    codecs.getdecoder(NAME)

test_register()

# Generated at 2022-06-11 22:09:53.373506
# Unit test for function register
def test_register():
    register()

    # noinspection PyProtectedMember
    codecs.__all__.remove('register')
    # noinspection PyProtectedMember
    assert NAME in codecs.__all__
    register()  # Call it again to ensure there is no error.
    # noinspection PyProtectedMember
    codecs.__all__.append('register')
    assert NAME in codecs.__all__



# Generated at 2022-06-11 22:09:54.529952
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.__all__  # type: ignore

# Generated at 2022-06-11 22:09:57.205065
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:11:38.622095
# Unit test for function register
def test_register():
    register()
    assert 'eutf8h' in codecs.__all__
    assert 'eutf8h' in str(codecs.__dict__)
    assert isinstance(codecs.getdecoder(NAME), codecs.CodecInfo)  # type: ignore

# Codepage use of this codec
test_register()

# Generated at 2022-06-11 22:11:45.291418
# Unit test for function register
def test_register():
    register()

    assert codecs.getdecoder(NAME)


if __name__ == '__main__':
    test_register()

    d: str = codecs.decode('\\xf0\\x9f\\x98\\x80', 'eutf8h')
    assert d == '\U0001f600'
    e: bytes = codecs.encode('\U0001f600', 'eutf8h')
    assert e == b'\\xf0\\x9f\\x98\\x80'
    print(e)
    print(d)

# Generated at 2022-06-11 22:11:46.562473
# Unit test for function register
def test_register():
    """Register this codec if it isn't already."""
    register()



# Generated at 2022-06-11 22:11:49.143743
# Unit test for function register
def test_register():
    register()

    assert NAME == codecs.getencoder(NAME)[0]
    assert NAME == codecs.getdecoder(NAME)[0]


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:11:51.585353
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError('Function register() failed to register.')



# Generated at 2022-06-11 22:11:53.514137
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:11:54.387484
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:11:59.146029
# Unit test for function register
def test_register():
    # import sys
    # print(sys.getdefaultencoding())
    # print(sys.stdout.encoding)
    # print(sys.getfilesystemencoding())
    # print(sys.getfilesystemencodeerrors())

    codecs.register(_get_codec_info)  # type: ignore



# Generated at 2022-06-11 22:12:00.580164
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:12:03.462798
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        assert False, 'Codec already registered'

    register()

    codecs.getdecoder(NAME)

