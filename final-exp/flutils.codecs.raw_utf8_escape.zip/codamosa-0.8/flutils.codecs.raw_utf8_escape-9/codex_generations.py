

# Generated at 2022-06-11 22:04:43.771798
# Unit test for function register
def test_register():
    register()
    assert 'eutf8h' == codecs.getdecoder(NAME)(b'\\xd0\\x90')[0]

# Generated at 2022-06-11 22:04:46.187831
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    test = codecs.getdecoder(NAME)
    assert test


# Generated at 2022-06-11 22:04:47.766293
# Unit test for function register
def test_register():
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:04:49.448026
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:04:51.174373
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    print('PASS: function test_register')



# Generated at 2022-06-11 22:04:54.376191
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-11 22:05:00.765274
# Unit test for function register
def test_register():
    register()
    # Make sure 'eutf8h' does not raise a LookupError
    out = codecs.getdecoder('eutf8h')
    assert isinstance(out, tuple)
    assert len(out) == 2
    f_decode = out[0]
    assert f_decode is decode
    f_increment = out[1]
    assert f_increment is codecs.increment_decode

    # Make sure 'eutf8h' does not raise a LookupError
    out = codecs.getencoder('eutf8h')
    assert isinstance(out, tuple)
    assert len(out) == 2
    f_encode = out[0]
    assert f_encode is encode
    f_increment = out[1]
    assert f_increment is codecs.incre

# Generated at 2022-06-11 22:05:03.125709
# Unit test for function register
def test_register():
    register()  # Register the codec
    codecs.getdecoder(NAME)  # Test that the codec exists
    text = "\\x61"
    text_encoded = b"\x61"
    assert decode(text_encoded)[0] == text[1:]


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:05:08.184915
# Unit test for function register
def test_register():
    old_decoder = codecs.getdecoder(NAME)  # type: ignore
    register()
    new_decoder = codecs.getdecoder(NAME)  # type: ignore
    assert(old_decoder != new_decoder)
    assert encode(NAME) == new_decoder('eutf8h')[0] # type: ignore

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:05:17.540655
# Unit test for function register
def test_register():
    original_getdecoder = codecs.getdecoder
    original_register = codecs.register

    class _GetDecoderMock:
        def __call__(self, codec):
            assert codec == NAME
            raise LookupError()

    getdecoder_mock = _GetDecoderMock()

    class _RegisterMock:
        def __init__(self):
            self.called = False

        def __call__(self, codecinfo):
            assert codecinfo.name == NAME
            self.called = True

    register_mock = _RegisterMock()

    try:
        codecs.getdecoder = getdecoder_mock
        codecs.register = register_mock

        register()

        assert register_mock.called is True
    finally:
        codecs.getdecoder = original_getdec

# Generated at 2022-06-11 22:05:20.172191
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None

# Generated at 2022-06-11 22:05:23.087894
# Unit test for function register
def test_register():
    """Check that the codec has registered.
    """
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:05:23.972495
# Unit test for function register
def test_register():
    codecs.getencoder(NAME)

register()

# Generated at 2022-06-11 22:05:29.305505
# Unit test for function register
def test_register():
    register()
    codec = codecs.getdecoder(NAME)
    # pickle.loads
    test_str = 'This is Python\\x00'
    _, _ = codec(test_str.encode(NAME))



# Generated at 2022-06-11 22:05:31.228422
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)


# Generated at 2022-06-11 22:05:32.924455
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:05:35.762258
# Unit test for function register
def test_register():
    try:
        test = codecs.getdecoder(NAME)
    except LookupError:
        register()
        test = codecs.getdecoder(NAME)

register()

# Generated at 2022-06-11 22:05:41.680181
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        # codecs.getdecoder(NAME) didn't raise a LookupError,
        # so it's registered
        return

    register()

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise Exception('Not get it registered')
    else:
        pass

# Generated at 2022-06-11 22:05:49.944507
# Unit test for function register
def test_register():
    # First run test to check that the module is not already registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(f'Module already registered: {NAME}')

    register()

    # Now test that the module is registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(f'Module not registered: {NAME}')

# Generated at 2022-06-11 22:05:51.964915
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)      # type: ignore
    assert codecs.getencoder(NAME)      # type: ignore

# Generated at 2022-06-11 22:05:58.020482
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-11 22:06:01.673246
# Unit test for function register
def test_register():
    # Clear cache
    del codecs.decode.cache[NAME]
    del codecs.encode.cache[NAME]
    register()
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)



# Generated at 2022-06-11 22:06:05.284362
# Unit test for function register
def test_register():

    register()

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError("Codec cannot be found")

# Generated at 2022-06-11 22:06:09.373472
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)

# Generated at 2022-06-11 22:06:13.020969
# Unit test for function register
def test_register():
    # type: () -> None
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        pytest.fail(e)


# Generated at 2022-06-11 22:06:15.645714
# Unit test for function register
def test_register():
    assert(codecs.getdecoder(NAME) is not None)


# Generated at 2022-06-11 22:06:22.045903
# Unit test for function register
def test_register():
    register()
    be = codecs.getencoder(NAME)  # type: ignore
    bd = codecs.getdecoder(NAME)  # type: ignore
    assert be == cast(codecs.CodecInfo, _get_codec_info(NAME)).encode  # type: ignore
    assert bd == cast(codecs.CodecInfo, _get_codec_info(NAME)).decode  # type: ignore
    _ = cast(codecs.CodecInfo, _get_codec_info(NAME)).name
    assert _ == NAME



# Generated at 2022-06-11 22:06:25.171284
# Unit test for function register
def test_register():
    """
    Register the codec.
    """
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:06:26.316911
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:06:32.709462
# Unit test for function register
def test_register():   # pragma: no cover
    # Get the codecs function so we can delete the codecs.
    _codecs = codecs.__dict__['_codecs']
    # Delete the codec from the list.
    del _codecs[NAME]
    # Register the codec.
    register()
    # Check that the codec is registered.
    assert NAME in codecs.__dict__['_codecs']

# Generated at 2022-06-11 22:06:41.881668
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getdecoder(NAME).name


# Generated at 2022-06-11 22:06:44.017691
# Unit test for function register
def test_register():
    register()

    assert NAME == codecs.getdecoder(NAME).name

# Generated at 2022-06-11 22:06:47.565651
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    print(encode('test {test} test'))
    print(decode(b'test\\x20\\x7Btest\\x7D\\x20test'))

# Generated at 2022-06-11 22:06:51.928882
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise RuntimeError('Failed to register codec: %s', NAME)



# Generated at 2022-06-11 22:06:53.723710
# Unit test for function register
def test_register():
    register()

    assert codecs.lookup(NAME) is not None



# Generated at 2022-06-11 22:06:55.426219
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:06:56.458853
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:06:59.719148
# Unit test for function register
def test_register():
    from codecs import getdecoder, getencoder

    register()

    print(getdecoder(NAME))

    print(getencoder(NAME))



# Generated at 2022-06-11 22:07:08.634893
# Unit test for function register
def test_register():
    _register = codecs.register
    _getdecoder = codecs.getdecoder

    def _register_fake(codec: codecs.CodecInfo):
        if codec.name == NAME:
            class _Codec:
                def encode(
                        self,
                        text: _Str,
                        errors: _Str=''
                ) -> Tuple[bytes, int]:
                    return codec.encode(text, errors)    # type: ignore

                def decode(
                        self,
                        data: _ByteString,
                        errors: _Str=''
                ) -> Tuple[str, int]:
                    return codec.decode(data, errors)    # type: ignore
            globals()['_Codec'] = _Codec

    # Register the codec, then check that it is registered, then unregister it.
    codecs_register

# Generated at 2022-06-11 22:07:12.612252
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise RuntimeError('decoding function was already registered')
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise RuntimeError('decoding function failed to register')



# Generated at 2022-06-11 22:07:31.468685
# Unit test for function register
def test_register():
    codectest.register(NAME, register, encode, decode)

# Generated at 2022-06-11 22:07:34.764802
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore


# Execute codectools.py as a script
if __name__ == '__main__':
    print('Executed as a script')
    test_register()
else:
    print('Imported as a module')
    register()

# Generated at 2022-06-11 22:07:35.641798
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-11 22:07:36.832466
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:07:37.464782
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:07:39.107749
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)  # type: ignore

# Generated at 2022-06-11 22:07:40.326253
# Unit test for function register
def test_register():
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:07:50.831116
# Unit test for function register
def test_register():
    import sys
    import operator

    # Check that the module can be imported.
    try:
        import eutf8h
    except ImportError:
        raise ImportError(
            "The module eutf8h failed to import. This error is raised"
            " to prevent unit tests from passing while the module"
            " is not importable."
        )

    # Force register the codec.
    eutf8h.register()

    # Check that the codec is registered.
    if NAME not in sys.modules[__name__].__dict__:
        raise Exception(
            "The codec is not registered in the module's __dict__."
        )

    # Check that the codec is registered in the codecs module.

# Generated at 2022-06-11 22:07:53.074698
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        pytest.fail(str(e))


# Generated at 2022-06-11 22:07:55.439081
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder('eutf8h')
    except LookupError:
        assert True
    else:
        assert False
    register()
    codecs.getdecoder('eutf8h')
    assert True

# Generated at 2022-06-11 22:08:29.302991
# Unit test for function register
def test_register():
    # noinspection PyTypeChecker
    codecs.register(lambda name: _get_codec_info(name))



# Generated at 2022-06-11 22:08:39.491287
# Unit test for function register
def test_register():
    """This unit test verifies that the codec registers itself correctly with
    :obj:`codecs`.
    """

    # Function 'register' should be called to register the codec.
    register()

    # Verify that the codec is registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'Codec is not registered.'



# Generated at 2022-06-11 22:08:39.950447
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-11 22:08:51.964991
# Unit test for function register
def test_register():
    register()
    assert NAME not in codecs.encode('')
    assert codecs.encode('', encoding=NAME)[0].decode('utf-8') == ''
    assert NAME in codecs.encode(NAME)[0].decode('utf-8')
    assert codecs.encode('\x80', encoding=NAME)[0].decode('utf-8') == '\\x80'
    assert codecs.encode('\x80', encoding='utf8')[0] == b'\xc2\x80'
    assert codecs.decode(codecs.encode('\x80', encoding=NAME), encoding=NAME) == '\x80'
    assert codecs.decode(codecs.encode('\x80', encoding=NAME), encoding='utf8') == '\x80'

# Generated at 2022-06-11 22:08:55.140460
# Unit test for function register
def test_register():

    def test_func():
        register()

    assert not codecs.lookup(NAME)

    test_func()

    assert codecs.lookup(NAME)



# Generated at 2022-06-11 22:08:56.678516
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

register()

# Generated at 2022-06-11 22:08:59.736334
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False
    assert True



# Generated at 2022-06-11 22:09:03.194250
# Unit test for function register
def test_register():
    import codecs
    from importlib import reload
    from . import eutf8h
    reload(eutf8h)
    eutf8h.register()
    try:
        codecs.lookup_error(eutf8h.NAME)
    except LookupError:
        assert False


# Generated at 2022-06-11 22:09:06.792449
# Unit test for function register
def test_register():
    """Test that the codec is registered."""
    assert NAME in codecs.__all__
    register()  # type: ignore
    assert NAME in codecs.__all__



# Generated at 2022-06-11 22:09:13.062618
# Unit test for function register
def test_register():
    # Save the system's current registered codecs.
    curr_reg = codecs.codecs_registered.copy()

    # Register the 'eutf8h' codec
    register()

    # Check if 'eutf8h' is registered
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError("'eutf8h' codec is not registered.")

    # Remove the 'eutf8h' codec
    new_reg = curr_reg.copy()
    try:
        new_reg.remove(NAME)
    except ValueError:
        pass
    codecs.codecs_registered = new_reg



# Generated at 2022-06-11 22:10:19.238679
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:10:20.119182
# Unit test for function register
def test_register():
    register()
    codecs.lookup(NAME)

# Generated at 2022-06-11 22:10:21.266080
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME) is _get_codec_info(NAME)

# Generated at 2022-06-11 22:10:23.360432
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:10:27.219735
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    assert codecs.lookup(NAME)
    codecs.unregister(NAME)
    assert codecs.lookup(NAME) is None



# Generated at 2022-06-11 22:10:32.926769
# Unit test for function register
def test_register():
    # Encode a string into escaped utf8 hexadecimal bytes
    # using the encode() function.
    data_bytes, consumed = encode('\u03b1')
    assert '\\xce\\xb1'.encode('utf-8') == data_bytes

    # Decode the escaped utf8 hexadecimal bytes into a string
    # using the decode() function.
    data, consumed = decode(data_bytes)
    assert '\u03b1' == data


# Register this codec
register()


# Generated at 2022-06-11 22:10:36.341765
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError('codec not registered')

register()

# Generated at 2022-06-11 22:10:37.367692
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)

register()

# Generated at 2022-06-11 22:10:41.643256
# Unit test for function register
def test_register():
    # We need to put this code into the __main__ namespace, otherwise
    # the test will fail.
    del codecs.lookup_error
    register()
    del codecs.lookup_error


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:10:45.180724
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME)
    assert codecs.getdecoder(NAME)


if __name__ == '__main__':
    register()
    test_register()

# Generated at 2022-06-11 22:13:21.300927
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:13:23.605856
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:13:25.141362
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)  # type: ignore



# Generated at 2022-06-11 22:13:27.147524
# Unit test for function register
def test_register():
    register()

    obj = codecs.getdecoder(NAME)  # type: ignore
    assert obj is not None
    assert obj.name == NAME



# Generated at 2022-06-11 22:13:28.908761
# Unit test for function register
def test_register():

    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False


# Generated at 2022-06-11 22:13:38.673547
# Unit test for function register
def test_register():
    register()
    pass


if __name__ == '__main__':
    # unit test for the module
    # Simple text
    text_in = 'Hello World'
    text_bytes_out, text_bytes_out_len = encode(text_in)
    text_str_out, text_str_out_len = decode(text_bytes_out)
    assert text_str_out == text_in
    assert text_bytes_out_len == text_str_out_len

    # Accented text
    text_in = '¡Hola Mundo!'
    text_bytes_out, text_bytes_out_len = encode(text_in)
    text_str_out, text_str_out_len = decode(text_bytes_out)
    assert text_str_out == text_in
    assert text

# Generated at 2022-06-11 22:13:40.808525
# Unit test for function register
def test_register():
    register()

    expected = NAME
    actual = codecs.getdecoder(NAME)
    assert actual



# Generated at 2022-06-11 22:13:46.866702
# Unit test for function register
def test_register():
    from sys import (
        modules,
        path,
    )
    from os import (
        path,
        remove,
    )

    # Register this module as a codec for testing.
    # Note that it should have already been registered
    # as a codec.
    register()

    # Create a temp file for importing this module
    # as a library.
    path_to_save = path.abspath(
        '__mimikatz_codecs.txt')
    path_module = path.abspath(path.join(
        path.dirname(
            path.abspath(__file__)),  # type: ignore[attr-defined]
        f'{__name__}.py'
    ))

# Generated at 2022-06-11 22:13:48.296685
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-11 22:13:50.555048
# Unit test for function register
def test_register():
    assert not codecs.getdecoder(NAME)
    register()
    assert codecs.getdecoder(NAME)

