

# Generated at 2022-06-11 22:04:43.026508
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:04:46.967501
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:04:48.417548
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    register()

# Generated at 2022-06-11 22:04:50.742820
# Unit test for function register
def test_register():
    # Test the register() function.
    # Using 'register' should not raise an error under normal
    # circumstances.
    register()



# Generated at 2022-06-11 22:04:53.439105
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)  # type: ignore


# Generated at 2022-06-11 22:04:55.837440
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)
    # codecs.getincrementalencoder(NAME)
    # codecs.getincrementaldecoder(NAME)


# Generated at 2022-06-11 22:04:59.857297
# Unit test for function register
def test_register():
    # Try to remove the codec from the codec maps if it is already registered.
    # This call should be safe even if the codec is not registered and may be
    # used to force the codec to be registered.
    codecs.register(_get_codec_info)



# Generated at 2022-06-11 22:05:05.060730
# Unit test for function register
def test_register():
    # First, unregister the codec if it is registered
    try:
        codecs.getdecoder(NAME)
        codecs.__all__.remove(NAME)
    except LookupError:
        pass

    # Register the codec
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise



# Generated at 2022-06-11 22:05:15.813478
# Unit test for function register
def test_register():
    from test.support import captured_stdout, import_fresh_module
    from platform import python_implementation
    from io import StringIO
    from sys import stdout

    # import_fresh_module is available in Python 3.4, not 3.3
    if python_implementation() == 'PyPy' or python_implementation() == 'IronPython':
        return

    try:
        import_fresh_module('eutf8h')
    except ImportError:
        return

    # Capture print output
    out = StringIO()
    with captured_stdout(out):
        import_fresh_module('eutf8h')

    # Check that the codec has been registered
    text = 'Hello \\xF0\\x9F\\x92\\xA9!'
    utf8_bytes = text.encode(NAME)
    text_

# Generated at 2022-06-11 22:05:23.088005
# Unit test for function register
def test_register():
    import sys
    import unittest
    the_name = f"{__name__}.{NAME}"

    class TestRegister(unittest.TestCase):
        def test_register(self):
            self.assertTrue(the_name in sys.modules)
            self.assertTrue(NAME in codecs.__dict__)

    # Run the unit tests

# Generated at 2022-06-11 22:05:26.923618
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:05:30.156365
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pytest.fail('Failed to register the codec')

# Generated at 2022-06-11 22:05:33.828524
# Unit test for function register
def test_register():
    mod = sys.modules[__name__]
    delattr(mod, 'test_register')
    register()
    assert hasattr(mod, 'test_register')



# Generated at 2022-06-11 22:05:39.038297
# Unit test for function register
def test_register():
    pass
    # assert NAME in codecs.__all__  # type: ignore
    # assert NAME not in codecs.decode.__code__.co_varnames  # type: ignore
    # assert NAME in codecs.decode.__defaults__  # type: ignore



# Generated at 2022-06-11 22:05:41.469866
# Unit test for function register
def test_register():
    import sys
    sys.modules[__name__] = sys.modules['__main__']
    register()
    import pytest
    with pytest.raises(LookupError):
        register()

# Generated at 2022-06-11 22:05:52.914286
# Unit test for function register
def test_register():
    # Re-register the codec on each call.
    # Unregister the codec, if already registered.
    try:
        codecs.unregister(NAME)
    except LookupError:
        pass

    # Register the codec
    register()

    # Register the codec again; Check for no error.
    # If this passes, then at unregister, the
    # codec will not be found (and hence no
    # error).
    register()

    # Unregister the codec
    codecs.unregister(NAME)

    # Unregister the codec again; Check for no error.
    # NOTE:
    #   This test is necessary because after a codec
    #   is registered, it is then registered on each
    #   call to this function.
    codecs.unregister(NAME)



# Generated at 2022-06-11 22:05:59.500620
# Unit test for function register
def test_register():
    # Unregister the codec if it is already registered.
    try:
        codecs.lookup_error('eutf8h')
    except LookupError:
        pass
    else:
        codecs.unregister('eutf8h')

    assert '\\x80' == b'\\x80'.decode('unicode_escape')
    assert '\\x80' == b'\\x80'.decode('eutf8h')
    assert b'\\x80' == '\\x80'.encode('unicode_escape')
    assert b'\\x80' == '\\x80'.encode('eutf8h')
    assert 'T' == b'T'.decode('eutf8h')
    assert '\n' == b'\n'.decode('eutf8h')


# Generated at 2022-06-11 22:06:02.448714
# Unit test for function register
def test_register():
    register()
    decoder = codecs.getdecoder(NAME)
    assert '\\x8c' == decoder(b'\\\\x8c')[0]

# Generated at 2022-06-11 22:06:05.615359
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)



# Generated at 2022-06-11 22:06:10.570239
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:06:17.486447
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-11 22:06:23.308103
# Unit test for function register
def test_register():
    register()

    # Make sure that the NAME only appears once in the sorted
    # registered codecs.
    codecs_sorted = sorted(codecs.registered_codecs)

    # if NAME in codecs_sorted: # TYPE_CHECKING
    #     codecs_sorted.remove(NAME)

    assert codecs_sorted.count(NAME) == 1, (
        "The codec did not register itself in codecs.register_codecs() properly."
    )



if __name__ == '__main__':
    # Unit test for function register
    test_register()



# Generated at 2022-06-11 22:06:25.565268
# Unit test for function register
def test_register():
    for encoding in codecs.encodings_map.keys():
        if encoding == NAME:
            break
    else:
        assert False



# Generated at 2022-06-11 22:06:27.558565
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:06:29.143206
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:06:41.239072
# Unit test for function register
def test_register():
    # noinspection PyUnresolvedReferences
    """Test the module's :func:`encode <register>` function

    The module's :func:`encode <register>` function is tested with
    the following Python version info.
    ::
    """

    import platform

    print(platform.win32_ver())
    print('Python', platform.python_version())
    print('Compiler', platform.python_compiler())
    print('Build', platform.python_build())
    print('Architecture', platform.architecture())
    print()

    # Test the module's register() function
    # It is important to test this function first before the import
    # statement that imports the codec's functions. This ensures that
    # the codec's functions are registered.
    #
    # It is also important to test the register() function first
   

# Generated at 2022-06-11 22:06:44.162601
# Unit test for function register
def test_register():
    """
    Unit tests to ensure that the codec registration is successful.
    """
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:06:47.416304
# Unit test for function register
def test_register():
    try:
        import codecs
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        try:
            import codecs
            codecs.getdecoder(NAME)
        except LookupError:
            assert False, f'{NAME} is not registered'



# Generated at 2022-06-11 22:06:49.652191
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)



# Generated at 2022-06-11 22:06:51.038625
# Unit test for function register
def test_register():
    assert codecs.getdecoder(NAME) is decode


# Generated at 2022-06-11 22:06:59.195041
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:07:00.433793
# Unit test for function register
def test_register():
    codecs.encode('test', 'eutf8h')


# Generated at 2022-06-11 22:07:03.825467
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
    assert codecs.getdecoder(NAME) is not None

# Generated at 2022-06-11 22:07:07.903276
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
        raise Exception('Name is registered')
    except LookupError:
        ...
    register()
    assert codecs.getdecoder(NAME) is not None  # type: ignore



# Generated at 2022-06-11 22:07:09.424651
# Unit test for function register
def test_register():
    register()

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:07:10.782803
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME) is not None


# Generated at 2022-06-11 22:07:18.529286
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert True
    else:
        assert False
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', DeprecationWarning)
        register()
        try:
            codecs.getdecoder(NAME)
        except LookupError:
            assert False
        else:
            assert True

# Generated at 2022-06-11 22:07:19.165162
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-11 22:07:22.541810
# Unit test for function register
def test_register():
    import sys
    import unittest

    class Test(unittest.TestCase):
        def test(self):
            register()
            if NAME in sys.modules:
                del sys.modules[NAME]
            register()

    unittest.main()

# Generated at 2022-06-11 22:07:29.192616
# Unit test for function register
def test_register():
    # 'eutf8h' is not registered yet
    if 'eutf8h' not in map(lambda x: x.name, codecs.iter_codecs()):
        register()
    assert 'eutf8h' in map(lambda x: x.name, codecs.iter_codecs())


# Unit testcase for function encode
# noinspection PyUnresolvedReferences

# Generated at 2022-06-11 22:07:44.034474
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore
    obj = codecs.getdecoder(NAME)   # type: ignore
    assert obj.__name__ == NAME, obj
    assert obj.__doc__ == decode.__doc__
    codecs.register(obj)   # type: ignore

# Generated at 2022-06-11 22:07:47.648857
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    try:
        codecs.getdecoder(NAME)
        return True
    except LookupError:
        return False


register()

# Generated at 2022-06-11 22:07:49.238839
# Unit test for function register
def test_register():
    """Test function ``register``.
    """
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:07:50.254467
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:07:52.540788
# Unit test for function register
def test_register():
    try:
        codecs.getencoder(NAME)
        codecs.getdecoder(NAME)
    except LookupError as e:
        assert False, e



# Generated at 2022-06-11 22:07:55.951863
# Unit test for function register
def test_register():
    """Unit test for the function register."""
    register()

    # This should now succeed.
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:07:57.448068
# Unit test for function register
def test_register():
    register()
    assert NAME == codecs.getdecoder(NAME).name
    assert NAME == codecs.getencoder(NAME).name



# Generated at 2022-06-11 22:07:58.462459
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:07:59.635626
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-11 22:08:02.793755
# Unit test for function register
def test_register():
    # Add a codec to the codecs module.
    register()

    # Verify that the codec was added.
    assert codecs.getdecoder(NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:08:25.969200
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.encode("", NAME)[0]



# Generated at 2022-06-11 22:08:27.014802
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:08:29.263132
# Unit test for function register
def test_register():
    register()
    out = codecs.getdecoder(NAME)
    assert out is not None
    assert out.__name__ == NAME



# Generated at 2022-06-11 22:08:38.183281
# Unit test for function register
def test_register():
    # Get the current codecs
    current_codecs = codecs.register(_get_codec_info)
    current_codec_names = []
    for codec in current_codecs:
        current_codec_names.append(codec[0])

    # Call function register
    register()

    # Get the new codecs
    new_codecs = codecs.register(_get_codec_info)
    new_codec_names = []
    for codec in new_codecs:
        new_codec_names.append(codec[0])

    assert new_codec_names == current_codec_names + [NAME]



# Generated at 2022-06-11 22:08:40.402939
# Unit test for function register
def test_register():
    # Execute
    register()

    # Verify
    out = codecs.getdecoder(NAME)
    assert out is not None
    assert out.encode('') == (b'', 0)



# Generated at 2022-06-11 22:08:42.627669
# Unit test for function register
def test_register():
    assert codecs.lookup(NAME) is not None



# Generated at 2022-06-11 22:08:49.199312
# Unit test for function register
def test_register():
    from .test_utils import get_encoded_decoded_str

    register()
    text_orig = '\u4f4f\u4e2d\u56fd\u4eba\u5bb6'
    text_encoded, text_decoded = get_encoded_decoded_str(text_orig, __name__)

    assert text_encoded == text_decoded

# Generated at 2022-06-11 22:08:57.779226
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        # Test register()
        register()
        try:
            codecs.getdecoder(NAME)
        except LookupError:
            # Test _get_codec_info()
            obj = _get_codec_info(NAME)
            assert obj is not None
            assert obj.name == NAME
            # Test the codec is registered
            codecs.getdecoder(NAME)
        else:
            raise Exception('Register did not fail as expected')
    else:
        raise Exception('Register did not fail as expected')


register()

# Generated at 2022-06-11 22:08:58.817185
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None
    codecs.lookup(NAME)



# Generated at 2022-06-11 22:09:01.442505
# Unit test for function register
def test_register():
    try:
        from eutf8h import codec as _codec
        codecs.register(_codec._get_codec_info)
        assert True
    except LookupError:
        assert False

# Generated at 2022-06-11 22:09:45.898346
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False

# Generated at 2022-06-11 22:09:47.230143
# Unit test for function register
def test_register():
    register()
    print(codecs.lookup(NAME))


# Generated at 2022-06-11 22:09:49.296258
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore

register()

# Generated at 2022-06-11 22:09:57.847946
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore
    assert NAME in codecs.getdecoder('eutf8h')


if __name__ == '__main__':  # pragma: no cover

    # Run unit tests
    test_register()

    # Run the codec specific tests in codecs.test
    # noinspection PyPackageRequirements
    import codecs
    codecs.register(_get_codec_info)   # type: ignore
    # noinspection PyPackageRequirements
    import test

    test.test_main(NAME)

# Generated at 2022-06-11 22:09:59.673006
# Unit test for function register
def test_register():

    codecs.register(_get_codec_info)  # type: ignore



# Generated at 2022-06-11 22:10:08.223486
# Unit test for function register
def test_register():
    """ Test the module function registe, that instantially register
        the escape_utf8hex codec at the codecs module.

        See:

            https://docs.python.org/3/library/codecs.html#codecs.register
    """
    codecs.register(_get_codec_info)  # type: ignore
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:10:13.114365
# Unit test for function register
def test_register():
    register()
    str = 'a\x80'
    str_utf8_hex = 'a\\x80'
    bytes_utf8_hex = codecs.encode(str, NAME)
    str_converted_bytes = codecs.decode(bytes_utf8_hex, NAME)
    assert str == str_converted_bytes
    assert str_utf8_hex == str_converted_bytes

# Generated at 2022-06-11 22:10:13.980303
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:10:15.060034
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:10:23.603854
# Unit test for function register
def test_register():
    register()
    def test_encoder():
        # noinspection PyUnresolvedReferences
        return codecs.getencoder(NAME)  # type: ignore

    def test_decoder():
        # noinspection PyUnresolvedReferences
        return codecs.getdecoder(NAME)  # type: ignore

    if test_encoder() is not None:
        print('Successfully registered the encoder')

    if test_decoder() is not None:
        print('Successfully registered the decoder')

    # code_str = '代码'
    # eutf8h_text = '\\xe4\\xbb\\xa3\\xe7\\xa0\\x81'
    #
    # eutf8h_bytes = eutf8h_text.encode('utf-8')
    #
    # eutf

# Generated at 2022-06-11 22:11:05.289703
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:11:07.643309
# Unit test for function register
def test_register():
    register()
    codec = codecs.getdecoder(NAME)
    assert NAME == codec.name
    assert NAME == codec.encode.__name__
    assert NAME == codec.decode.__name__



# Generated at 2022-06-11 22:11:11.896426
# Unit test for function register
def test_register():
    global codec_info
    codec_info = codecs.lookup(NAME)
    in_ = 'abc\x80'
    out = codec_info.encode(in_)[0]
    in_ = codec_info.decode(out)[0]
    assert in_ == 'abc\x80'

# Generated at 2022-06-11 22:11:13.830728
# Unit test for function register
def test_register():
    assert REGISTER_CALLED is False
    register()
    assert REGISTER_CALLED is True



# Generated at 2022-06-11 22:11:16.322942
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)



# Generated at 2022-06-11 22:11:19.587716
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getcodec(NAME)
    except LookupError as e:
        e.args = \
            'codec \'eutf8h\' is not registered. ' \
            'Please file a bug report!',
        raise e


# Generated at 2022-06-11 22:11:22.259630
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:11:25.415819
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME)         # type: ignore



# Generated at 2022-06-11 22:11:26.496453
# Unit test for function register
def test_register():
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:11:27.646123
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)     # type: ignore


# Generated at 2022-06-11 22:12:53.768632
# Unit test for function register
def test_register():
    test_text = '£'
    test_encoded_bytes = b'\\xc2\\xa3'

    register()
    text_bytes, _ = encode(test_text)
    assert test_encoded_bytes == text_bytes

    text_str, _ = decode(test_encoded_bytes)
    assert text_str == test_text


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:12:59.321256
# Unit test for function register
def test_register():
    """If this doesn't throw an exception, then the test is successful."""
    # If the eutf8h codec doesn't exist, then create it.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()

    # Try to get the codec again.
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:13:03.716080
# Unit test for function register
def test_register():
    # GIVEN: Codec is already registered.
    # WHEN: Codec is registered again.
    # THEN: No exception is raised.
    # AND: No exception is raised for codec lookup.
    register()


# Generated at 2022-06-11 22:13:05.022112
# Unit test for function register
def test_register():
    register()
    result = codecs.getdecoder(NAME)
    assert result is decode
    result = codecs.getencoder(NAME)
    assert result is encode



# Generated at 2022-06-11 22:13:05.811848
# Unit test for function register
def test_register():
    decode('', 'strict')



# Generated at 2022-06-11 22:13:07.136297
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# Generated at 2022-06-11 22:13:10.487318
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:13:12.086360
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)



# Generated at 2022-06-11 22:13:12.746205
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-11 22:13:13.652575
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)