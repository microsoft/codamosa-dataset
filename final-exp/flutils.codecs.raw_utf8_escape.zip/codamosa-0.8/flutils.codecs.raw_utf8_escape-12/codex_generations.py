

# Generated at 2022-06-11 22:04:44.095918
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
        raise RuntimeError("The required codecs are already registered")
    except LookupError:
        register()
        get = codecs.getdecoder(NAME)
        assert get


# Generated at 2022-06-11 22:04:44.813483
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:04:46.349971
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore



# Generated at 2022-06-11 22:04:51.893816
# Unit test for function register
def test_register():
    if NAME not in codecs.__dict__['_cache']:
        print('Registering eutf8h')
        register()
        assert NAME in codecs.__dict__['_cache']
        del codecs.__dict__['_cache'][NAME]
    else:
        print('Already Registered eutf8h')


if __name__ == '__main__':
    # Run the register function
    test_register()

# Generated at 2022-06-11 22:04:52.541648
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-11 22:04:55.198247
# Unit test for function register
def test_register():
    # When register is called successfully...
    # ...a decorator should be applied to the function,
    # that has the object 'codecs.CodecInfo' attached to it.
    assert hasattr(register, "_CODEC_INFO")

# Generated at 2022-06-11 22:04:56.873674
# Unit test for function register
def test_register():
    register()
    codecs.lookup(NAME)



# Generated at 2022-06-11 22:05:00.671170
# Unit test for function register
def test_register():
    """Test function register()"""

    def test1():
        """Test function register()."""
        try:
            codecs.getdecoder(NAME)
            return False
        except LookupError:
            pass
        register()
        try:
            codecs.getdecoder(NAME)
        except LookupError:
            return False
        return True

    assert test1(), 'Failed on codecs.register(_get_codec_info)()'


# Generated at 2022-06-11 22:05:08.603163
# Unit test for function register
def test_register():

    # Test the codec is not already registered
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise Exception('Codec is already registered')

    # Test the codec is successfully registered
    register()
    codecs.getdecoder(NAME)  # no exception

    # Test the codec cannot be registered again
    try:
        register()
    except LookupError:
        pass
    else:
        raise Exception('Codec should not be registered again')

    # Test the codec can be registered again after unregistering
    codecs.unregister(NAME)
    register()



# Generated at 2022-06-11 22:05:12.075751
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)  # type: ignore
    out = codecs.getdecoder(NAME)  # type: ignore
    assert out


register()

# Generated at 2022-06-11 22:05:22.510535
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:05:27.499303
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)
    codecs.getincrementalencoder(NAME)
    codecs.getincrementaldecoder(NAME)



# Generated at 2022-06-11 22:05:32.858370
# Unit test for function register
def test_register():
    # Ensure that the eutf8h codec is not registered.
    try:
        codecs.getdecoder(NAME)
        raise Exception('Codec eutf8h is already registered')
    except LookupError:
        pass

    # Register the eutf8h codec.
    register()

    # Ensure that the eutf8h codec is registered.
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:05:40.079376
# Unit test for function register
def test_register():
    """Test the function :obj:`register`."""
    from eutf8h._test_common import assert_output
    from eutf8h._test_common import TestData
    from eutf8h._test_common import TestError

    assert_output(
        TestData(
            '''
            >>> import eutf8h
            >>> eutf8h.register()
            ''',
            TestError(''),
        )
    )


register()

# Generated at 2022-06-11 22:05:41.533023
# Unit test for function register
def test_register():
    """
    Test the register function.
    """
    # This should not raise any exceptions
    register()



# Generated at 2022-06-11 22:05:53.213015
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    test_register()

    # Unit test for function decode
    def test_decode():
        text = '\\x6c\\x6f\\x6e\\x67\\x20\\x74\\x65\\x78\\x74'
        data = codecs.escape_decode(text)[0]
        out = codecs.decode(data, NAME)
        assert out[0] == 'long text', out[0]

    test_decode()

    # Unit test for function encode
    def test_encode():
        text = 'long text'
        data = codecs.encode(text, NAME)

# Generated at 2022-06-11 22:05:55.192572
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:05:56.252769
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:05:56.972423
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-11 22:05:58.578831
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:06:15.797540
# Unit test for function register
def test_register():
    register()
    _ = codecs.getdecoder(NAME)


_ = test_register()

# Generated at 2022-06-11 22:06:17.859482
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:06:19.753345
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    codecs.getdecoder(NAME)
    assert True


# Generated at 2022-06-11 22:06:21.523435
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:06:23.175396
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-11 22:06:25.978039
# Unit test for function register
def test_register():
    register()
    data = codecs.getdecoder(NAME)
    assert codecs.decode(b'\\xc3\\xa1', NAME) == ('á', 6)



# Generated at 2022-06-11 22:06:32.555800
# Unit test for function register
def test_register():
    # noinspection PyProtectedMember
    assert codecs._builtin_decoders.get(NAME) is None
    assert codecs.getdecoder(NAME) is None
    register()
    # noinspection PyProtectedMember
    assert codecs._builtin_decoders.get(NAME) is not None
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-11 22:06:35.826205
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    try:
        codecs.lookup('eutf8h')
    except LookupError:
        raise Exception()



# Generated at 2022-06-11 22:06:43.447453
# Unit test for function register
def test_register():
    # The codec should not be registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        # Register so that the NAME of the codec will be
        # registered.
        register()
        # Now that the codec is registered, getdecoder
        # should not raise an exception.
        codecs.getdecoder(NAME)
    else:
        # We should not have reached this point because
        # LookupError should have been raised.
        raise RuntimeError("We got past the exception.")



# Generated at 2022-06-11 22:06:44.385829
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:07:15.511931
# Unit test for function register
def test_register():
    # Make sure register works.
    register()
    # Make sure codecs.getdecoder registers this codec in modules.
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:07:17.447170
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup_error('strict') is not None

# Generated at 2022-06-11 22:07:19.820219
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False

# Generated at 2022-06-11 22:07:30.449419
# Unit test for function register
def test_register():
    """Unit test for function :func:`register`.

    The function is tested by:

    1. Registering the codec and ensure that it can be looked up in the
       codec registry by it's name.
    2. Deregister the codec and ensure that it can no longer be looked
       up in the codec registry by it's name.
    """
    # Ensure that the codec can be looked up in the codec registry by
    # it's name.
    codecs.register(_get_codec_info)   # type: ignore
    assert codecs.getencoder(NAME) is not None

    # Ensure that the codec can no longer be looked up in the codec
    # registry by it's name.
    codecs.unregister(NAME)
    assert codecs.getdecoder(NAME) is None

# Generated at 2022-06-11 22:07:33.108632
# Unit test for function register
def test_register():
    register()
    obj = codecs.getdecoder(NAME)
    assert obj()[0].encode('utf-8') == b'a\\xe1\\xb0\\x82'



# Generated at 2022-06-11 22:07:38.777614
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None


if __name__ == '__main__':
    # Perform unit tests when run as a module
    register()

    # Unit test for function encode
    def test_encode():
        text_out, _ = encode('Hello, \\u00C3\\xA1rv\\u00C3\\xADzt\\u0171r\\u0151 '
                             't\\u00FCk\\u00F6rf\\u00FCr\\u00F3g\\u00E9p.')

# Generated at 2022-06-11 22:07:49.447418
# Unit test for function register
def test_register():
    # Given
    import os
    import stat

    import tempfile
    from codecs import decode as codecs_decode
    from codecs import encode as codecs_encode
    import contextlib

    # When

    # Then
    os.name == 'posix'  # pragma: no branch
    if not os.name == 'posix':
        return  # pragma: no cover
    with tempfile.TemporaryDirectory() as temp_dir:
        os.chmod(temp_dir, 0o600)
        temp_file = os.path.join(temp_dir, 'file.txt')
        with open(temp_file, 'w', encoding=NAME) as fh:
            fh.write('ä')

# Generated at 2022-06-11 22:07:50.824515
# Unit test for function register
def test_register():
    # codecs.getdecoder(NAME)
    register()

# Generated at 2022-06-11 22:07:51.565055
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:07:58.101923
# Unit test for function register
def test_register():
    register()
    cod = codecs.getdecoder(NAME)
    reg = codecs.CodecInfo(  # type: ignore
        name=NAME,
        encode=encode,  # type: ignore[arg-type]
        decode=decode,  # type: ignore[arg-type]
    )
    assert cod == reg



# Generated at 2022-06-11 22:08:56.896787
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:08:58.347865
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getencoder(NAME)  # type: ignore
        codecs.getdecoder(NAME)  # type: ignore
    except LookupError:
        raise Exception(f'Failed to register codec {NAME}')

# Generated at 2022-06-11 22:09:00.847102
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore


decode_hex_utf8 = decode
encode_hex_utf8 = encode

register()

# Generated at 2022-06-11 22:09:02.368056
# Unit test for function register
def test_register():
    codecs.lookup_error('test')
    register()
    codecs.lookup_error(NAME)

# Generated at 2022-06-11 22:09:10.153248
# Unit test for function register
def test_register():
    """Unit test for function register"""

    def test_register_completed_successfully() -> None:
        register()
        try:
            codecs.getencoder(NAME)
        except LookupError:
            raise Exception(
                f'Cannot get an encoder for codec name: {NAME}'
            )
        try:
            codecs.getdecoder(NAME)
        except LookupError:
            raise Exception(
                f'Cannot get an decoder for codec name: {NAME}'
            )

    test_register_completed_successfully()

# Generated at 2022-06-11 22:09:12.657059
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:09:20.418434
# Unit test for function register
def test_register():
    from unittest.mock import Mock, patch

    def _getdecoder_mock(encoding):
        if encoding == NAME:
            raise LookupError(
                f"unknown encoding: {encoding}"
            )
    mock_getdecoder = Mock(wraps=_getdecoder_mock)

    mock_codecs_register = Mock()

    with patch(
        'codecs.getdecoder',
        new=mock_getdecoder,
    ):
        with patch(
            'codecs.register',
            new=mock_codecs_register,
        ):
            register()

    assert mock_getdecoder.call_count == 1
    assert mock_getdecoder.call_args_list[0][0] == (NAME,)

# Generated at 2022-06-11 22:09:23.416172
# Unit test for function register
def test_register():
    register()
    coder = codecs.getdecoder(NAME)
    assert coder and coder[0] == decode
    coder = codecs.getencoder(NAME)
    assert coder and coder[0] == encode

# Generated at 2022-06-11 22:09:33.904977
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore


if __name__ == '__main__':
    # Run unit tests
    test_register()

    # Register the codec
    register()

    # Test string encoding
    text = "Μπορώ να φάω"
    bytes, _ = codecs.getencoder(NAME)(text, errors='strict')
    s = bytes.decode('utf8')
    print(s)

    # Test string decoding
    bytes = b'\\xCE\\x9C\\xCE\\xB2\\xCF\\x81\\xCF\\x8E \\xCE\\xBD\\xCE\\xB1 \\xCF\\x86\\xCE\\xAC\\xCF\\x89'

# Generated at 2022-06-11 22:09:34.853475
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:11:46.486567
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
        raise Exception(f'Codec {NAME} is already registered')
    except LookupError:
        register()
        try:
            codecs.getdecoder(NAME)
        except LookupError:
            raise Exception(f'Codec {NAME} failed to register')


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:11:51.973049
# Unit test for function register
def test_register():
    def getdecoder(name):
        if name == "eutf8h":
            return encode, decode
        raise LookupError(name)
    codecs_patch = Mocker()
    codecs_patch.patch(target=codecs, attribute="getdecoder",
        side_effect=getdecoder)
    with codecs_patch:
        register()
    assert codecs.getdecoder("eutf8h") == (encode, decode)



# Generated at 2022-06-11 22:11:53.513434
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME)



# Generated at 2022-06-11 22:11:54.388287
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:11:55.187726
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:11:56.702188
# Unit test for function register
def test_register():
    register()
    codecs.decode(b'', NAME)


# Generated at 2022-06-11 22:11:59.146781
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME)
    assert codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:12:00.373132
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:12:06.171780
# Unit test for function register
def test_register():
    # noinspection PyUnusedLocal
    def test_func(text: _Str = '') -> None:
        # noinspection PyGlobalUndefined
        global NAME
        NAME = 'not valid'
        try:
            # noinspection PyUnusedLocal
            from eutf8h import NAME
        except ImportError:
            NAME = 'not valid'
        register()
        try:
            codecs.getdecoder(NAME)
        except LookupError:
            pass

    test_func()


# Generated at 2022-06-11 22:12:07.161641
# Unit test for function register
def test_register():
    import os
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:13:59.802914
# Unit test for function register
def test_register():
    # pylint: disable=unused-import
    from __pkginfo__ import version, author
    register()
    codecs.getdecoder(NAME)  # Should not raise an exception


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:14:02.496380
# Unit test for function register
def test_register():
    # Try to register the codec.
    register()

    # Test that Python can find the encoder and decoder.
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-11 22:14:03.406328
# Unit test for function register
def test_register():
    assert codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:14:09.911096
# Unit test for function register
def test_register():
    if __name__ == '__main__':
        print('In test_register')
        register()
        text_str = 'abcd\x80'
        text_bytes = text_str.encode(NAME)
        print('text_str=', repr(text_str))
        print('text_bytes=', repr(text_bytes))
        print('text_str=', text_str)
        print('text_bytes=', text_bytes)
        text_bytes_other = text_str.encode('utf8')
        print('text_bytes_other=', repr(text_bytes_other))
        text_view = memoryview(text_bytes)
        text_str2 = text_view.tobytes().decode(NAME)
        print('text_str2=', repr(text_str2))

# Generated at 2022-06-11 22:14:12.007791
# Unit test for function register
def test_register():
    register()
    # codecs.register(_get_codec_info)   # type: ignore



# Generated at 2022-06-11 22:14:15.294872
# Unit test for function register
def test_register():
    NAME = 'eutf8h'
    codecs.register(_get_codec_info)   # type: ignore
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)


# Generated at 2022-06-11 22:14:18.116009
# Unit test for function register
def test_register():
    """Unit test for function register"""

    # Ensure that the NAME codec is not registered.
    codecs.register(_get_codec_info)

    # Ensure that the NAME codec is registered.
    register()

# Generated at 2022-06-11 22:14:19.455342
# Unit test for function register
def test_register():
    register()
    _ = codecs.getdecoder(NAME)
    assert True



# Generated at 2022-06-11 22:14:20.780775
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getencodings()



# Generated at 2022-06-11 22:14:23.366639
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    decoder = codecs.getdecoder(NAME)

    assert NAME == decoder.name

