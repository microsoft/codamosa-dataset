

# Generated at 2022-06-11 22:04:53.026107
# Unit test for function register
def test_register():
    register()

    # Make sure the encoding can be found.
    codecs.getdecoder(NAME)

    # Make sure the decoding function matches
    # the one we registered.
    decoder = codecs.getdecoder(NAME)  # type: ignore
    assert decoder.__name__ == decode.__name__  # type: ignore

    # Make sure the encoding function matches
    # the one we registered.
    encoder = codecs.getencoder(NAME)  # type: ignore
    assert encoder.__name__ == encode.__name__  # type: ignore



# Generated at 2022-06-11 22:04:58.900409
# Unit test for function register
def test_register():
    register()

# Code necessary to run unit tests.
if __name__ == '__main__':

    def test():
        test_register()
        ut = '\\u{1F600}\\x41\\u{1F600}\\x41'
        result = ut.encode(NAME)
        assert result == b'\\xf0\\x9f\\x98\\x80\\x41\\xf0\\x9f\\x98\\x80\\x41'
        assert ut == result.decode(NAME)
        ut = '\\xf0\\x9f\\x98\\x80\\x41\\xf0\\x9f\\x98\\x80\\x41'
        result = ut.encode(NAME)

# Generated at 2022-06-11 22:05:03.049815
# Unit test for function register
def test_register():
    def _assert_it(name: str) -> None:
        try:
            codecs.getdecoder(name)
        except LookupError:
            msg = 'failed to register %r' % name
            raise Exception(msg)
    _assert_it(NAME)



# Generated at 2022-06-11 22:05:04.732614
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)  # type: ignore



# Generated at 2022-06-11 22:05:07.697352
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)  # type: ignore


# Generated at 2022-06-11 22:05:13.306667
# Unit test for function register
def test_register():
    register()
    obj = codecs.getdecoder(NAME)
    text = 'hello world'
    assert obj(text)[0] == text
    text = 'hello \u03B5\u03B2\u03B4\u03BF\u03C2'
    assert obj(text)[0] == text

# Generated at 2022-06-11 22:05:14.648068
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)



# Generated at 2022-06-11 22:05:16.272410
# Unit test for function register
def test_register():
    register()
    # codecs.register(_get_codec_info)   # type: ignore

# Generated at 2022-06-11 22:05:19.780798
# Unit test for function register
def test_register():
    register()
    assert 'eutf8h' in str(codecs.CodecInfo.__dict__['__slots__'])


# Generated at 2022-06-11 22:05:20.930225
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:05:35.720564
# Unit test for function register
def test_register():
    register()
    assert('eutf8h' in codecs.getdecoder(NAME).__dict__)



# Generated at 2022-06-11 22:05:37.327011
# Unit test for function register
def test_register():
    import codecs
    codecs.lookup(NAME)



# Generated at 2022-06-11 22:05:39.459316
# Unit test for function register
def test_register():
    # Add the codec to the global codecs library
    register()

    # Try to get the decoder for the codec
    codecs.getdecoder(NAME)


# Type Hint
CodecInfo = codecs.CodecInfo
FuncType = codecs.FuncType

# Generated at 2022-06-11 22:05:42.807304
# Unit test for function register
def test_register():
    with contextlib.ExitStack() as stack:
        mock_getdecoder = stack.enter_context(
            mock.patch.object(codecs, 'getdecoder')
        )
        mock_register = stack.enter_context(
            mock.patch.object(codecs, 'register')
        )
        mock_getdecoder.side_effect = LookupError
        register()
        mock_register.assert_called_once()  # type: ignore


# Generated at 2022-06-11 22:05:50.275911
# Unit test for function register
def test_register():
    # Remove any old encodings.
    try:
        codecs.lookup(NAME).name  # Check if name exists.
    except LookupError:
        pass

# Generated at 2022-06-11 22:05:52.246460
# Unit test for function register
def test_register():
    # Ensure that the function itself is callable
    pass

    # Ensure that the function doesn't raise an exception
    register()



# Generated at 2022-06-11 22:05:54.381300
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME)

register()

# Generated at 2022-06-11 22:06:01.937685
# Unit test for function register
def test_register():
    with tempfile.TemporaryDirectory() as tmpdir:
        try:
            codecs.getdecoder(NAME)
        except LookupError:
            # Register the codec.
            register()
            codecs.getdecoder(NAME)
        else:
            # Unregister the codec.
            codecs.unregister(NAME)
            with pytest.raises(LookupError):
                codecs.getdecoder(NAME)
            # Register the codec.
            register()
            codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:06:03.075914
# Unit test for function register
def test_register():
    register()
    codecs.lookup(NAME)

# Generated at 2022-06-11 22:06:03.802684
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-11 22:06:36.652811
# Unit test for function register
def test_register():
    import codecs
    codecs.register(_get_codec_info)   # type: ignore
    utf8h_decoder = codecs.getdecoder(NAME)
    assert utf8h_decoder(b'\\x4e\\x4b')[0] == '\u4e4b'

# Generated at 2022-06-11 22:06:39.809456
# Unit test for function register
def test_register():
    """A unit test for the register() function"""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False
    return


# Generated at 2022-06-11 22:06:43.973329
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME)('foo') == (b'f\\x6f\\x6f', 3)
    assert codecs.getdecoder(NAME)(b'f\\x6f\\x6f') == ('foo', 5)



# Generated at 2022-06-11 22:06:45.839730
# Unit test for function register
def test_register():
    register()

    assert NAME in codecs.getencodings()
    assert NAME in codecs.getdecodings()



# Generated at 2022-06-11 22:06:48.197042
# Unit test for function register
def test_register():

    register()


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:06:49.659170
# Unit test for function register
def test_register():
    register()
    try:
        codec = codecs.getdecoder(NAME)
    except LookupError:
        pytest.fail('Codec not registered')


# Generated at 2022-06-11 22:06:51.038663
# Unit test for function register
def test_register():
    assert codecs.getdecoder(NAME) is not None


register()

# Generated at 2022-06-11 22:07:02.889171
# Unit test for function register
def test_register():
    class MyString(UserString):
        pass

    def func_encode(
            text,
            errors='strict'
    ) -> Tuple[bytes, int]:
        return encode(text, errors)

    def func_decode(
            data,
            errors='strict'
    ) -> Tuple[str, int]:
        return decode(data, errors)

    name = __name__.split('.')[-1]
    ci = codecs.CodecInfo(  # type: ignore
        name=name,
        encode=func_encode,  # type: ignore[arg-type]
        decode=func_decode,  # type: ignore[arg-type]
    )
    try:
        codecs.getdecoder(name)
    except LookupError:
        codecs.register(ci)

# Generated at 2022-06-11 22:07:04.153141
# Unit test for function register
def test_register():
    register()
    # codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:07:07.997066
# Unit test for function register
def test_register():
    """Test whether codec is registered."""
    # codec 'eutf8h' should not exist at first
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)

    # codec 'eutf8h' should exist after calling register()
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:08:03.635990
# Unit test for function register
def test_register():
    assert isinstance(register, types.FunctionType)

# Generated at 2022-06-11 22:08:06.012995
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)  # type: ignore


# Generated at 2022-06-11 22:08:08.516010
# Unit test for function register
def test_register():
    # noinspection PyUnresolvedReferences
    from encodings import utf_8
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:08:09.848338
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

register()

# Generated at 2022-06-11 22:08:11.679267
# Unit test for function register
def test_register():
    """Unit test for function register
    """
    codecs.register(_get_codec_info)   # type: ignore

# Generated at 2022-06-11 22:08:15.736559
# Unit test for function register
def test_register():
    # This should register the codec to the standard library
    assert not codecs.lookup(NAME)
    register()
    assert codecs.lookup(NAME)


# Generated at 2022-06-11 22:08:16.466080
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:08:21.386295
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore
    if codecs.getdecoder(NAME) is not None:
        # codecs.getdecoder(NAME) returns a CodecInfo object
        codecs.getdecoder(NAME)
    else:
        # codecs.getdecoder(NAME) returns a NoneType object.
        None

# Generated at 2022-06-11 22:08:25.970058
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError("register() function failed.")

if __name__ == '__main__':
    test_register()     # pragma: no cover

# Generated at 2022-06-11 22:08:27.414825
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:10:25.014729
# Unit test for function register
def test_register():
    def do_register():
        register()

    def do_register_get_decoder():
        register()
        obj = codecs.getdecoder(NAME)

    def do_register_get_decoder_decode():
        register()
        obj = codecs.getdecoder(NAME)
        text_bytes = b'\\x41\\x42\\x43'
        obj(text_bytes)

    def do_register_get_encoder():
        register()
        obj = codecs.getencoder(NAME)

    def do_register_get_encoder_encode():
        register()
        obj = codecs.getencoder(NAME)
        text_str = '\\x41\\x42\\x43'
        obj(text_str)

    #
    # Errors
    #


# Generated at 2022-06-11 22:10:28.135494
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getencodings()
    assert NAME in codecs.getdecodings()



# Generated at 2022-06-11 22:10:29.528895
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getdecoders()

# Generated at 2022-06-11 22:10:33.128199
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME) is not None, 'Encoder registration failed'
    assert codecs.getdecoder(NAME) is not None, 'Decoder registration failed'



# Generated at 2022-06-11 22:10:45.587280
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    register()
    # Unit test for function encode
    for i in range(0, 127):
        char = chr(i)
        assert encode(char) == (char.encode('utf-8'), 1)

    assert encode('®') == (b'\\xc2\\xae', 1)
    assert encode('\\a') == (b'a', 1)
    assert encode('\\\\') == (b'\\\\', 1)
    assert encode('\\xF0\\x9F\\x92\\x99') == (b'\\xf0\\x9f\\x92\\x99', 1)

# Generated at 2022-06-11 22:10:47.056943
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)  # type: ignore

register()

# Generated at 2022-06-11 22:10:48.957278
# Unit test for function register
def test_register():
    codec_info = codecs.lookup(NAME)
    assert codec_info is not None
    assert codec_info.name == NAME



# Generated at 2022-06-11 22:10:51.814908
# Unit test for function register
def test_register():
    register()
    codecs.lookup_error('strict')
    codecs.lookup_error('ignore')
    codecs.lookup_error('replace')


# Generated at 2022-06-11 22:10:56.511032
# Unit test for function register
def test_register():
    def _do_register():
        codecs.register(_get_codec_info)

    # First run of the register function should work
    _do_register()

    # Subsequent runs of the register function should fail
    with pytest.raises(ValueError):
        _do_register()

if __name__ == '__main__':
    register()

# Generated at 2022-06-11 22:11:07.258238
# Unit test for function register
def test_register():
    print('Testing register')
    NAME_TEST = NAME + '_test'

    # Test that we can register and unregister

# Generated at 2022-06-11 22:13:11.603548
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-11 22:13:12.340978
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME) is not None

# Generated at 2022-06-11 22:13:13.992069
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# Generated at 2022-06-11 22:13:22.525753
# Unit test for function register
def test_register():
    import sys
    old_names = set(sys.modules.keys())
    try:
        register()
    except ImportError:
        pass
    else:
        new_names = set(sys.modules.keys())
        for name in new_names - old_names:
            if name.startswith(NAME):
                module = sys.modules[name]
                if hasattr(module, '__path__'):
                    print(name)
                    print('    ', module.__path__)



# Generated at 2022-06-11 22:13:24.699790
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:13:26.722050
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)
    assert True

# Generated at 2022-06-11 22:13:28.785700
# Unit test for function register
def test_register():
    """Test the :obj:`register` function."""
    register()
    codecs.getencoder(NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:13:32.680968
# Unit test for function register
def test_register():
    """Test 'register' function in codecs module."""
    register()
    codecs.getdecoder(__name__.split('.')[-1])

# Generated at 2022-06-11 22:13:36.008439
# Unit test for function register
def test_register():
    import codecs
    codecs.register(_get_codec_info)
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False
    return True

# Generated at 2022-06-11 22:13:40.062617
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore


if __name__ == '__main__':
    test_register()