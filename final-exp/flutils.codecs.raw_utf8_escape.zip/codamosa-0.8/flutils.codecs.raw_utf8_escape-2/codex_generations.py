

# Generated at 2022-06-11 22:04:46.126075
# Unit test for function register
def test_register():
    # The NAME codec should be registered by default.
    # Remove it if it was previously registered.
    try:
        codecs.lookup(NAME)
    except LookupError:
        pass
    else:
        codecs.unregister(NAME)

    # Verify that NAME codec is NOT registered.
    try:
        codecs.lookup(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError

    # Register the NAME codec.
    register()

    # Verify that the NAME codec IS registered.
    codecs.lookup(NAME)



# Generated at 2022-06-11 22:04:48.203325
# Unit test for function register
def test_register():
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:04:50.517765
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup_error(NAME) == codecs.strict_errors
    assert codecs.lookup(NAME).name == NAME

# Generated at 2022-06-11 22:04:53.760884
# Unit test for function register
def test_register():
    register()
    obj = codecs.getdecoder(NAME)  # type: ignore
    assert obj is not None



# Generated at 2022-06-11 22:04:59.247189
# Unit test for function register
def test_register():
    # Clear the codecs cache
    codecs.clear_cache()

    # Register the 'eutf8h' codec
    register()

    # Get the 'eutf8h' codec
    codec = codecs.getdecoder(NAME)
    assert codec

    # Get the name and the description
    codec_name, codec_desc = codec.__name__.split('_', 1)
    assert codec_name == NAME

    # Make sure the codec is registered
    for codec_info in codecs.getdecoders():
        if codec_info.name == NAME:
            break
    else:
        raise AssertionError("The '%s' type is not registered." % NAME)


# Run unit tests if the module is run directly
if __name__ == '__main__':
    test_register()

    # Test encoding of the

# Generated at 2022-06-11 22:05:07.217084
# Unit test for function register
def test_register():
    test_name = '_test_name'
    ci = codecs.CodecInfo(
        NAME,
        encode=lambda string, errors: None,
        decode=lambda byte_string, errors: None,
    )
    codecs.register(lambda name: None if name != test_name else ci)

    # Make sure that our encoder is registered.
    assert type(codecs.getencoder(test_name)) == type(ci.encode)
    assert type(codecs.getdecoder(test_name)) == type(ci.decode)

# Generated at 2022-06-11 22:05:10.187431
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)

# Unit tests

# Generated at 2022-06-11 22:05:11.464711
# Unit test for function register
def test_register():
    register()
    codecs.decode(b'\\x61', 'eutf8h')



# Generated at 2022-06-11 22:05:12.792582
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)


# Generated at 2022-06-11 22:05:20.052354
# Unit test for function register
def test_register():
    from typing import overload
    from unittest.mock import Mock
    class MockCodecs:
        @overload
        def register(self, obj) -> None: ...
        @overload
        def register(self, search_function) -> None: ...
        def register(self, search_function):
            pass
        @overload
        def getdecoder(self, name: str) -> codecs.CodecInfo: ...
        @overload
        def getdecoder(self, name: str) -> None: ...
        def getdecoder(self, name: str) -> Optional[codecs.CodecInfo]:
            if name == NAME:
                raise LookupError
            return None
    mock_codecs = MockCodecs()
    mock_get_codec_info = Mock()
    mock_get_cod

# Generated at 2022-06-11 22:05:22.852757
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:05:27.617672
# Unit test for function register
def test_register():
    codecs.lookup_error('eutf8h')
    register()
    try:
        _ = codecs.getdecoder(NAME)
    except LookupError:
        register()

register()

# Generated at 2022-06-11 22:05:32.428709
# Unit test for function register
def test_register():
    """Register the codec.

    Note:
        This will unregister the codec if it is already registered.
    """
    register()
    assert NAME in codecs.__dict__['_cache']  # type: ignore[attr-defined]


# Generated at 2022-06-11 22:05:42.632045
# Unit test for function register
def test_register():
    from test.support import import_fresh_module
    from test.support.script_helper import assert_python_ok
    from test import script_helper
    from test.script_helper import assert_python_failure

    eutf8h_m = import_fresh_module('eutf8h', blocked=['_pytest'])
    eutf8h_m.register()

    spec = script_helper.assert_python_ok('-Eutf8h', '-c',
        """\
        # coding: eutf8h

        text = '\\eutf8h\\xc3\\xb1'
        print(text)""")
    expected = '\nñ\n'
    assert spec.out == expected

    # We make sure that the codecs module can handle this name.

# Generated at 2022-06-11 22:05:43.511531
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:05:47.589581
# Unit test for function register
def test_register():
    if NAME in codecs.__dict__['_cache']:
        del(codecs.__dict__['_cache'][NAME])

    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:05:50.918983
# Unit test for function register
def test_register():
    register()

    # Check to see if codec has been registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise RuntimeError(e) from e


# Generated at 2022-06-11 22:05:52.807274
# Unit test for function register
def test_register():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 22:05:56.656381
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)  # no exception means pass
    codecs.getdecoder(NAME)  # no exception means pass
    try:
        codecs.getencoder('aaaaaaaaa')  # should throw LookupError
        assert False
    except LookupError:
        pass


# Generated at 2022-06-11 22:05:58.718735
# Unit test for function register
def test_register():
    import codecs
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:06:05.119128
# Unit test for function register
def test_register():
    # Arrange
    # Act
    register()

    # Assert
    codec = codecs.getencoder(NAME)
    assert codec is not None

# Generated at 2022-06-11 22:06:06.029503
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:06:09.880019
# Unit test for function register
def test_register():
    register()

    # noinspection PyUnresolvedReferences
    assert NAME in codecs.decoders
    # noinspection PyUnresolvedReferences
    assert NAME in codecs.encoders
    assert codecs.lookup(NAME)
    assert codecs.lookup_error('strict')


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:06:12.288216
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    # There is no way to directly test register() since it will throw an
    # exception if NAME is already registered. Instead, just call
    # the function.

# Generated at 2022-06-11 22:06:15.796340
# Unit test for function register
def test_register():
    import codecs
    codecs.register(_get_codec_info)   # type: ignore


# Generated at 2022-06-11 22:06:19.273573
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        assert e.args[0] == 'eutf8h'
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:06:21.047707
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:06:23.176767
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:06:25.518011
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME)
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:06:27.485853
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:06:36.550480
# Unit test for function register
def test_register():
    register()
    # noinspection PyUnresolvedReferences
    codecs.getdecoder(NAME)

register()
test_register()

# Generated at 2022-06-11 22:06:40.370148
# Unit test for function register
def test_register():
    """Unit test for function register
    """

    register()
    try:
        codecs.getencoder(NAME)
    except LookupError:
        assert False, 'Function register should have registered the eutf8h codec'

    assert True



# Generated at 2022-06-11 22:06:42.691209
# Unit test for function register
def test_register():
    def test():
        sys.stdout.write(f'{NAME}: ')
        register()
        try:
            codecs.lookup(NAME)
            sys.stdout.write('ok\n')
        except LookupError:
            sys.stdout.write('fail\n')
            raise
    test()



# Generated at 2022-06-11 22:06:44.731676
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-11 22:06:45.468250
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:06:48.147775
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None

# Generated at 2022-06-11 22:06:50.855459
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise Exception("Shouldn't be able to decode before registering.")
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise Exception("Failed to register.")


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:06:55.444813
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        # Register the codec.
        register()

        # Confirm that the codec was registered successfully.
        codecs.getdecoder(NAME)  # type: ignore



# Generated at 2022-06-11 22:06:58.305622
# Unit test for function register
def test_register():
    register()
    name = __name__ + '.hoge'
    try:
        codecs.getdecoder(name)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore



# Generated at 2022-06-11 22:06:59.916325
# Unit test for function register
def test_register():
    func = register
    func()


if __name__ == '__main__':
    register()
    print('Registration test:')
    print('Failed if exceptions are raised, succeeded otherwise.')
    print('Exiting...')

# Generated at 2022-06-11 22:07:14.485531
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-11 22:07:16.261395
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-11 22:07:18.474711
# Unit test for function register
def test_register():
    register()
    _ = codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:07:20.468286
# Unit test for function register
def test_register():
    register()  # type: ignore
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:07:28.738911
# Unit test for function register
def test_register():
    import sys
    import unittest

    class _Test(unittest.TestCase):  # type: ignore
        def test(self):
            register()
            codecs.getdecoder(NAME)

    obj = _Test()
    if sys.version_info >= (3, 5):
        obj.test()
    else:
        obj.skipTest('Test only for Python 3.5 or later.')


# The unit test for testing this source code's functions

# Generated at 2022-06-11 22:07:29.828810
# Unit test for function register
def test_register():
    assert codecs.lookup(NAME)



# Generated at 2022-06-11 22:07:32.585660
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError('Cannot getdecoder.')


# Generated at 2022-06-11 22:07:34.102762
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:07:34.964764
# Unit test for function register
def test_register():
    codecs.lookup(NAME)



# Generated at 2022-06-11 22:07:36.874677
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None

# Generated at 2022-06-11 22:08:15.853224
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()


# Generated at 2022-06-11 22:08:26.458761
# Unit test for function register
def test_register():
    from . import print_unicode_hex

    register()

    name = 'eutf8h'
    # name = 'eutf8h'
    # name = 'utf8'

    def test_str(str_orig: str) -> None:
        print('\nTest: ', str_orig)
        str_encoded = str_orig.encode(name)
        print_unicode_hex.print_unicode_hex(str_encoded)
        str_decoded = str_encoded.decode(name)
        print('Text:\t', str_decoded)
        # print(str_orig)
        # print(str_decoded)
        assert str_decoded == str_orig

    def test_bytes(bytes_orig: bytes) -> None:
        print('\nTest: ', bytes_orig)

# Generated at 2022-06-11 22:08:30.370437
# Unit test for function register
def test_register():
    import codecs

    try:
        codecs.getdecoder('eutf8h')
    except LookupError:
        codecs.register(_get_codec_info,)
    else:
        raise KeyError(
            'Codec `eutf8h` is already registered.'
        )



# Generated at 2022-06-11 22:08:31.930702
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME)



# Generated at 2022-06-11 22:08:40.727839
# Unit test for function register
def test_register():
    # First, unregister and then re-register.
    codecs.lookup(NAME)
    register()
    register()

    # Encoding
    test_str = '毎日が|\\x41'
    test_bytes = codecs.encode(test_str, NAME)
    assert test_bytes == b'\\xe6\\xaf\\x8e\\xe6\\x97\\xa5' \
        b'\\xe3\\x81\\x8c|\\x5c\\x7834\\x31'
    test_str_decoded = codecs.decode(test_bytes, NAME)
    assert test_str_decoded == test_str

    # Decoding

# Generated at 2022-06-11 22:08:45.789853
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)
    codecs.getincrementalencoder(NAME)
    codecs.getincrementaldecoder(NAME)




# Generated at 2022-06-11 22:08:48.624910
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except Exception as e:
        raise e


# Generated at 2022-06-11 22:08:52.000688
# Unit test for function register
def test_register():
    global NAME
    NAME = 'abc123abc'
    register()
    try:
        # noinspection PyUnusedLocal
        test = codecs.getdecoder(NAME)
    except LookupError:
        assert False




# Generated at 2022-06-11 22:09:00.380068
# Unit test for function register
def test_register():
    """Check whether the codec is registered."""
    # codecs.getdecoder(NAME) -> test
    # codecs.lookup(NAME).name == NAME
    # codecs.lookup(NAME).decode is decode
    # codecs.lookup(NAME).encode is encode
    codecs.getdecoder(NAME)
    assert codecs.lookup(NAME).name == NAME
    assert codecs.lookup(NAME).decode is decode
    assert codecs.lookup(NAME).encode is encode


# Generated at 2022-06-11 22:09:02.866624
# Unit test for function register
def test_register():
    assert codecs.lookup_error(NAME) == (decode, encode)
    assert codecs.lookup_error('eutf8h') == (decode, encode)



# Generated at 2022-06-11 22:10:01.967754
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-11 22:10:06.262363
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        return False

    return True


# Generated at 2022-06-11 22:10:08.179932
# Unit test for function register
def test_register():
    assert isinstance(encode, codecs.CodecInfo.encode)
    assert isinstance(decode, codecs.CodecInfo.decode)

# Generated at 2022-06-11 22:10:14.030048
# Unit test for function register
def test_register():
    # If a codec has already been registered, call register() will
    # overwrite the previous codec.
    codecs.register(lambda name: codecs.CodecInfo(  # type: ignore
        name="test_foo",
        encode=lambda x, y: (x, y),
        decode=lambda x, y: (x, y),
    ))
    # Register again
    register()
    # Check that the codec is registered
    assert register() is None
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-11 22:10:15.398380
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME)



# Generated at 2022-06-11 22:10:18.479991
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)
    codecs.lookup(NAME)



# Generated at 2022-06-11 22:10:21.116580
# Unit test for function register
def test_register():
    from os import remove
    from sys import getfilesystemencoding

    # Setup
    register()
    # Act
    output = codecs.lookup(NAME)  # type: ignore

    # Assert
    assert output is not None

    # Tear down
    del output


# Generated at 2022-06-11 22:10:23.602332
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.__all__
    assert codecs.lookup(NAME)

# Generated at 2022-06-11 22:10:27.527361
# Unit test for function register
def test_register():
    import sys
    register()
    result = (sys.getdefaultencoding(), sys.getfilesystemencoding())
    expected = ('utf-8', 'utf-8')
    assert result == expected



# Generated at 2022-06-11 22:10:30.124702
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)

register()

# Generated at 2022-06-11 22:12:51.909378
# Unit test for function register
def test_register():
    import sys
    import inspect

    save_registry = codecs.__dict__['_registry']
    try:
        # For the codecs_registry unit test
        # Save the current codecs global state
        codecs._registry = {}
        codecs._search_function = None
        # Empty the encodings global state
        encoding = inspect.getmodule(sys.getdefaultencoding)
        encoding._cache = {}
        encoding._unknown = None
        encoding._complain_about_unset_encoding = False
        # Register the module
        register()
        # Test it
        codecs.getencoder(NAME)
        codecs.getdecoder(NAME)
        # Clean up
        codecs._cache.clear()
    finally:
        codecs.__dict__['_registry'] = save_registry

# Generated at 2022-06-11 22:13:04.479689
# Unit test for function register
def test_register():
    register()  # type: ignore
    codecs.getencoder(NAME)   # type: ignore
    codecs.getdecoder(NAME)   # type: ignore

if __name__ == '__main__':
    import unittest
    import sys

    class TestEutf8h(unittest.TestCase):
        def test_register(self):
            register()
            codecs.getencoder(NAME)
            codecs.getdecoder(NAME)

        def test_escape_unicode_characters(self):
            register()
            actual = b'\\x5E'.decode(NAME)
            expect = '^'
            self.assertEqual(actual, expect)

        def test_escape_unicode_surrogate_pair(self):
            register()

# Generated at 2022-06-11 22:13:10.076905
# Unit test for function register
def test_register():
    """Unit test for function register.
    """

    # Clear the codec map cache
    del(codecs.cache[__name__])

    # The codec should not be registered yet
    try:
        r = codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise RuntimeError(
            f'Codec "{NAME}" was unexpectedly registered.'
        )

    # Register the codec
    register()

    # The codec should be registered now
    try:
        r = codecs.getdecoder(NAME)
    except LookupError:
        raise RuntimeError(
            f'Codec "{NAME}" was unexpectedly not registered.'
        )


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:13:17.771912
# Unit test for function register
def test_register():
    from typing import List
    from unittest.mock import (
        ANY,
        Mock,
        patch,
        )

    mock_getdecoder = Mock()
    mock_getdecoder.side_effect = LookupError()

    with patch(
            'codecs.getdecoder',
            mock_getdecoder,
            create=True,
    ):
        with patch(
                'codecs.register',
                return_value=None,
                autospec=True,
        ) as mock_register:
            register()
            mock_register.assert_any_call(ANY)

            mock_getdecoder.reset_mock()

            mock_getdecoder.side_effect = lambda x: x in ['ascii']
            register()

# Generated at 2022-06-11 22:13:21.554810
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert True
    else:
        assert False

# Generated at 2022-06-11 22:13:26.363026
# Unit test for function register
def test_register():
    """Unit test for function register."""
    # Register the codec
    register()

    # Test the codec
    try:
        b'\x41'.decode(NAME)
    except:
        raise AssertionError('Could not decode simple utf8 string')

    try:
        '\xE2\x9C\x93'.encode(NAME)
    except:
        raise AssertionError('Could not decode simple utf8 string')

# Generated at 2022-06-11 22:13:27.422785
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:13:28.100462
# Unit test for function register
def test_register():
    register()
    return

# Generated at 2022-06-11 22:13:30.120875
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        assert codecs.getdecoder(NAME)

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:13:35.508858
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    decoder = codecs.getdecoder(NAME)
    assert decoder is not None
    codecs.register(_get_codec_info)
    decoder = codecs.getdecoder(NAME)
    assert decoder is not None

