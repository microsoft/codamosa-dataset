

# Generated at 2022-06-11 22:04:42.364884
# Unit test for function register
def test_register():
    test_str = '\xe2\x96\x90'
    codecs.register(_get_codec_info)
    codecs.charmap_build('eutf8h')
    codecs.charmap_decode(b'\\xe2\\x96\\x90', 'eutf8h', 'strict')
    codecs.charmap_encode(test_str, 'eutf8h')


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:04:48.844528
# Unit test for function register
def test_register():
    # Register the codec if it hasn't already been registered.
    register()

    # Get the codec info object that was registered.
    codec_info = codecs.getdecoder(NAME)

    # Assert the codec info object is the same object as used by the
    # _get_codec_info function.
    assert codec_info == _get_codec_info(NAME)

    encode = codec_info.encode  # type: ignore

    # Test error checking.
    with pytest.raises(AttributeError):
        codec_info.encode(b'test', errors='strict')

    with pytest.raises(UnicodeEncodeError):
        encode('\U0010FFFF')

    # Test actual encode function.
    out, out_size = encode('\U0010FFFF', errors='ignore')

# Generated at 2022-06-11 22:04:54.187296
# Unit test for function register
def test_register():
    """Ensure that the encoding is available."""

    register()

    def _test(data: str) -> str:
        encoded = data.encode(NAME)
        decoded = encoded.decode(NAME)
        return decoded

    assert _test('hello') == 'hello'
    assert _test('日本語') == '日本語'
    assert _test('{\\xE6}') == 'æ'



# Generated at 2022-06-11 22:04:56.527556
# Unit test for function register
def test_register():
    register()
    assert 'eutf8h' in codecs.encode('Hello, world!', 'eutf8h').decode()

if __name__ == '__main__':
    test_register() # Run unit test

# Generated at 2022-06-11 22:05:00.167073
# Unit test for function register
def test_register():
    """Test the eutf8h encoding class.

    :return: None
    """
    register()
    assert codecs.lookup(NAME) is not None


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:05:03.974665
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)
        register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-11 22:05:10.316175
# Unit test for function register
def test_register():
    # codec_info = codecs.getdecoder(NAME)
    assert NAME in codecs.__dict__
    assert NAME in codecs.__dict__[NAME].__dict__

    assert encode is codecs.__dict__[NAME].__dict__['encode']
    assert decode is codecs.__dict__[NAME].__dict__['decode']



# Generated at 2022-06-11 22:05:14.233574
# Unit test for function register
def test_register():
    # Check that we haven't registered the codec
    try:
        codecs.getdecoder('eutf8h')
        raise AssertionError('codec is already registered')
    except LookupError:
        pass
    # Register codec
    register()
    # Codec should now be registered
    assert codecs.getdecoder('eutf8h')



# Generated at 2022-06-11 22:05:15.209966
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:05:18.444816
# Unit test for function register
def test_register():
    from eutf8h import codec
    from test.support.script_helper import assert_python_ok
    assert_python_ok('-c', "import eutf8h.codec; eutf8h.codec.register()")
    assert codecs.lookup_error('eutf8h') == codec.decode

# Generated at 2022-06-11 22:05:21.606646
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:05:22.569229
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:05:27.621203
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    try:
        codecs.getdecoder('unknown')
    except LookupError:
        pass
    else:
        assert False, 'Unknown should not exist'



# Generated at 2022-06-11 22:05:31.186156
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)
    codecs.lookup_error(NAME)
    codecs.lookup_error(NAME.upper())
    codecs.lookup_error(NAME.lower())


# Generated at 2022-06-11 22:05:33.914420
# Unit test for function register
def test_register():
    register()
    assert NAME == codecs.getdecoder(NAME)[0].name


# Generated at 2022-06-11 22:05:37.420000
# Unit test for function register
def test_register():
    """This is a unit test for function :func:`register`."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:05:39.338363
# Unit test for function register
def test_register():
    register()
    utf8h_decoder = codecs.getdecoder(NAME) # type: ignore

    utf8h_decoder('\\x41')


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:05:40.482483
# Unit test for function register
def test_register():
    # Register the codec
    register()

    # Verify that the codec is now available
    codecs.lookup(NAME)

# Generated at 2022-06-11 22:05:44.038686
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)
    assert codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:05:54.288102
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME) == encode
    assert codecs.getdecoder(NAME) == decode
    assert codecs.encode(__file__, NAME) == b'\\x2f\\x75\\x73\\x72\\x2f\\x6d\\x62\\x2f\\x73\\x62\\x2f\\x70\\x77\\x65\\x62\\x74\\x65\\x73\\x74\\x2f\\x6d\\x6f\\x64\\x75\\x6c\\x65\\x2e\\x70\\x79\\x00'

# Generated at 2022-06-11 22:05:59.753684
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)


# Generated at 2022-06-11 22:06:09.940055
# Unit test for function register
def test_register():
    from copy import copy
    from sys import modules
    from functools import reduce
    import codecs
    from types import ModuleType
    register()
    # Get the codecs module
    codecs_module: ModuleType = modules['codecs']

    # Get the codecs module's 'getdecoder' function.
    getdecoder: codecs.CodecInfo = getattr(codecs_module, 'getdecoder')

    # Get the codecs.CodecInfo object for the 'eutf8h' codec
    codec_info: codecs.CodecInfo = getdecoder('eutf8h')

    # Get the codecs.CodecInfo object's 'decode' and 'encode' functions.
    decode: codecs.CodecInfo = getattr(codec_info, 'decode')

# Generated at 2022-06-11 22:06:11.217882
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:06:13.206840
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:06:13.970518
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:06:20.611919
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        assert False, "register() - the codec is already registered"
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, "register() - codecs.getdecoder() raised exception"


if __name__ == '__main__':
    # Unit test
    test_register()

# Generated at 2022-06-11 22:06:24.726443
# Unit test for function register
def test_register():
    register()

    text = 'this is a test'
    text_bytes = text.encode(NAME)
    text_str = text_bytes.decode(NAME)

    assert text == text_str



# Generated at 2022-06-11 22:06:25.768641
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)

# Generated at 2022-06-11 22:06:34.537626
# Unit test for function register
def test_register():
    tests = [
        (None, ''),
        ('\n', '\\a'),
        ('\t', '\\t'),
        ('\r', '\\d'),
        ('\f', '\\c'),
        ('\\', '\\\\'),
        (' ', '\\x20'),
        ('\u202e', '\\xe2\\x80\\xae'),
    ]
    for (test_input, test_output) in tests:
        test_output_bytes = encode(test_output)[0]
        register()
        test_output_bytes_other = codecs.encode(test_input, NAME)[0]
        assert test_output_bytes == test_output_bytes_other


# Generated at 2022-06-11 22:06:35.103991
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:06:42.368573
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise RuntimeError
    # return True

# Generated at 2022-06-11 22:06:44.340854
# Unit test for function register
def test_register():
    import doctest

    doctest.testmod()


# Generated at 2022-06-11 22:06:47.746363
# Unit test for function register
def test_register():
    register()
    # This should not raise an exception.
    codecs.getdecoder(NAME)

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:06:58.319082
# Unit test for function register
def test_register():
    """
    This function is a unit test for the function :func:`~register` and
    :func:`~getdecoder`. It does not execute any other unit tests.
    """
    register()

    try:
        codecs.getencoder(NAME)
    except LookupError as e:
        raise AssertionError(f'The encoding {NAME} has not been registered.') from e

    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise AssertionError(f'The encoding {NAME} has not been registered.') from e



# Generated at 2022-06-11 22:07:04.112387
# Unit test for function register
def test_register():
    import sys
    import pycodestyle

    stream = getattr(sys.stdout, 'buffer', sys.stdout)
    # avoid pylint warning "unsubscriptable-object"
    noqa = sys.stdout  # type: ignore
    repo = pycodestyle.StyleGuide().options.reporter
    stream.write(repo([], noqa).encode())
    # Uncomment the below line when 'test_register' is a unit test.
    # register()

# Generated at 2022-06-11 22:07:05.290310
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)



# Generated at 2022-06-11 22:07:14.310945
# Unit test for function register
def test_register():
    # noinspection PyProtectedMember
    codec_name_list = list(codecs._codecs_search_path.keys())
    is_eutf8h_codec = NAME in codec_name_list
    if is_eutf8h_codec:
        raise NameError(f'Codec name {NAME} is already in codecs')
    register()
    codec_name_list = list(codecs._codecs_search_path.keys())
    assert NAME in codec_name_list


if __name__ == '__main__':
    test_register()

    text = u'\u30C6\u30B9\u30C8\u3067\u3059\u3002'
    b = text.encode(NAME)

# Generated at 2022-06-11 22:07:15.782893
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:07:21.789861
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
        assert False
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
        assert True

    try:
        codecs.getdecoder(NAME)
        assert True
    except LookupError:
        assert False


# Generated at 2022-06-11 22:07:27.549276
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME) is not None
    codecs.lookup_error(NAME) is not None
    assert codecs.decode('hello', NAME) == 'hello'  # noqa
    

# Generated at 2022-06-11 22:07:45.511414
# Unit test for function register
def test_register():
    import sys
    import unittest
    import eutf8h

    class TestRegister(unittest.TestCase):
        def test_00_register(self):
            self.assertNotIn(
                NAME, sys.modules['encodings'].aliases.aliases)
            eutf8h.register()
            self.assertIn(NAME, sys.modules['encodings'].aliases.aliases)

    unittest.main(argv=['first-arg-is-ignored'], exit=False)

# Generated at 2022-06-11 22:07:46.926667
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(__name__)


# Generated at 2022-06-11 22:07:51.136741
# Unit test for function register
def test_register():
    import builtins
    # Test setup
    current_encoders = builtins.__dict__['__codecs__'].encode.copy()

    # Test function
    register()

    # Test teardown
    builtins.__dict__['__codecs__'].encode = current_encoders



# Generated at 2022-06-11 22:07:53.888275
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError('codecs.getdecoder(NAME) failed to raise LookupError')



# Generated at 2022-06-11 22:07:56.421282
# Unit test for function register
def test_register():
    import sys

    # If this module is imported, the codec is *already* registered.
    # We must 'unregister' it before we can register again.
    if NAME in sys.modules:
        del sys.modules[NAME]
    register()
    assert NAME in sys.modules

# Generated at 2022-06-11 22:07:58.539753
# Unit test for function register
def test_register():

    """
    Unit test for function register
    """

    # Assume that the codec is not registered.
    assert NAME not in codecs.__dict__

    register()

    # Assume that the codec is registered.
    assert NAME in codecs.__dict__



# Generated at 2022-06-11 22:08:00.126893
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:08:03.593117
# Unit test for function register
def test_register():
    register()
    ret = codecs.getencoder(NAME)  # type: ignore
    assert ret is not None
    ret = codecs.getdecoder(NAME)  # type: ignore
    assert ret is not None



# Generated at 2022-06-11 22:08:06.705760
# Unit test for function register
def test_register():
    """
    # Testing register() to register and use this codec.
    """

    codecs.register(_get_codec_info)
    assert isinstance(codecs.getdecoder(NAME)(), tuple)



# Generated at 2022-06-11 22:08:11.157949
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise TypeError('Cannot test: codec already registered')

    register()

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise TypeError('Codec not registered')

# Generated at 2022-06-11 22:08:33.280652
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)



# Generated at 2022-06-11 22:08:34.107064
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:08:36.466565
# Unit test for function register
def test_register():
    # Unit test for function register
    print(f'{NAME}.test_register()')
    register()



# Generated at 2022-06-11 22:08:38.906763
# Unit test for function register
def test_register():
    def assert_func(b: bytes) -> None:
        assert codecs.getdecoder(NAME) is not None

    assert_func(b'\x01\x02')



# Generated at 2022-06-11 22:08:39.681835
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:08:47.299241
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)
    else:
        raise AssertionError(
            'Codec %s is already registered.' % NAME
        )
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(
            'Codec %s is not registered.' % NAME
        )
    else:
        pass



# Generated at 2022-06-11 22:08:49.583473
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:09:01.062087
# Unit test for function register
def test_register():
    try:
        import test_test_test  # noqa: F401
        raise RuntimeError('test_test_test should not be importable')
    except LookupError:
        test_test_test_imported = False
    else:
        test_test_test_imported = True

    decode('hello')
    decode('not_valid_escaped_utf8')

    register()

    try:
        import test_test_test  # noqa: F401
    except LookupError:
        test_test_test_imported = False
    else:
        test_test_test_imported = True
    if not test_test_test_imported:
        raise RuntimeError('test_test_test is not importable')


# Generated at 2022-06-11 22:09:02.253421
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:09:05.170031
# Unit test for function register
def test_register():
    register()
    reg = codecs.getencoder(NAME)
    assert reg



# Generated at 2022-06-11 22:09:52.508418
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:09:55.497767
# Unit test for function register
def test_register():
    try:
        # noinspection PyUnresolvedReferences
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore

# Generated at 2022-06-11 22:10:02.475766
# Unit test for function register
def test_register():
    # Verify that the codec name is not already available.
    try:
        codecs.getdecoder(NAME)
        return False
    except LookupError:
        pass
    # Add the codec name with the codec.
    register()
    # Verify that the codec name is available.
    try:
        codecs.getdecoder(NAME)
        return True
    except LookupError:
        return False



# Generated at 2022-06-11 22:10:11.718897
# Unit test for function register
def test_register():
    # This should fail because the codec has not been registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        pass
    else:
        raise AssertionError(
            'codecs.getdecoder() should have raised a LookupError exception'
        )

    register()

    # Now that the codec has been registered, this should not raise
    # an exception.
    codecs.getdecoder(NAME)  # type: ignore



# Generated at 2022-06-11 22:10:15.174580
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore


if __name__ == '__main__':
    test_register()
    register()
    print(NAME)

# Generated at 2022-06-11 22:10:17.394449
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)   # should not raise



# Generated at 2022-06-11 22:10:19.743546
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.__all__
    assert codecs.lookup(NAME) == _get_codec_info(NAME)



# Generated at 2022-06-11 22:10:20.817724
# Unit test for function register
def test_register():
    _get_codec_info(NAME)
    register()


# Generated at 2022-06-11 22:10:21.874615
# Unit test for function register
def test_register():
    register()
try:
    register()
except:
    pass

# Generated at 2022-06-11 22:10:27.086299
# Unit test for function register
def test_register():
    """Test the function :func:`register`."""
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:12:17.702545
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        assert codecs.getdecoder(NAME) is not None
        codecs.unregister(NAME)


# If the module isn't being tested, then register the codec.
if __name__ != '__main__':
    test_register()

# Generated at 2022-06-11 22:12:18.901880
# Unit test for function register
def test_register():
    register()
    codecs.lookup(NAME)



# Generated at 2022-06-11 22:12:19.673390
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-11 22:12:29.151373
# Unit test for function register
def test_register():
    register()
    assert 'eutf8h' in codecs.getencoder('eutf8h')

if __name__ == '__main__':
    register()
    str1 = '\U0001F600'
    str2 = '\\U0001F600'
    str3 = '\\U0001F6XX'
    str1_raw = r'\U0001F600'
    str2_raw = r'\\U0001F600'
    str3_raw = r'\\U0001F6XX'
    str4 = '\\!\\@\\#\\$\\%\\^\\&\\*\\(\\)\\-'
    str4_raw = r'\\!\\@\\#\\$\\%\\^\\&\\*\\(\\)\\-'

# Generated at 2022-06-11 22:12:30.057928
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)

# Generated at 2022-06-11 22:12:34.246264
# Unit test for function register
def test_register():
    try:
        test_decoder = codecs.getdecoder(NAME)
        test_encoder = codecs.getencoder(NAME)
    except LookupError:
        register()
        test_decoder = codecs.getdecoder(NAME)
        test_encoder = codecs.getencoder(NAME)
    return test_decoder, test_encoder



# Generated at 2022-06-11 22:12:39.307940
# Unit test for function register
def test_register():
    '''
    Test the module function register().
    '''

    # Unregister the encoding
    found = None
    while True:
        try:
            codecs.lookup(NAME)
            found = True
            break
        except LookupError:
            break
    if found is not None:
        codecs.unregister(NAME)

    # Register the encoder and ensure it is registered.
    register()
    try:
        _ = codecs.lookup(NAME)
    except LookupError:
        raise AssertionError('Could not find eutf8h codec')

    return



# Generated at 2022-06-11 22:12:41.606734
# Unit test for function register
def test_register():
    # This function does nothing but verify that typing imports can be found
    codecs.register(_get_codec_info)   # type: ignore

# Generated at 2022-06-11 22:12:44.418627
# Unit test for function register
def test_register():
    register()
    test_str = "I love \\xC2\\xA9"
    test_bytes = codecs.encode(test_str, NAME)
    assert codecs.decode(test_bytes, NAME) == test_str
    return

# Generated at 2022-06-11 22:12:46.740111
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

