

# Generated at 2022-06-11 22:04:37.550106
# Unit test for function register
def test_register():
    codecs.register = lambda a: None
    register()

# Generated at 2022-06-11 22:04:41.467749
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
# end unit test

register()

# Generated at 2022-06-11 22:04:46.349837
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getencoder(NAME)
    except LookupError:
        assert False
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False
    assert True


# Generated at 2022-06-11 22:04:48.222773
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        return True
    return False


# Register the eutf8h codec if it has not already been registered.
register()



# Generated at 2022-06-11 22:04:50.517848
# Unit test for function register
def test_register():
    import codecs
    codecs.register(_get_codec_info)
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-11 22:04:51.814022
# Unit test for function register
def test_register():
    register()
    _get_codec_info(NAME)

# Generated at 2022-06-11 22:04:54.144623
# Unit test for function register
def test_register():
    register()
    try:
        decode(b'test')
    except UnicodeDecodeError:
        assert False
    else:
        assert True



# Generated at 2022-06-11 22:04:56.903798
# Unit test for function register
def test_register():
    try:
        codecs.lookup_error('eutf8h')
    except LookupError:
        pass
    else:
        assert False, 'codec "eutf8h" should not be registered'
    register()
    assert codecs.lookup_error('eutf8h') is not None


# Generated at 2022-06-11 22:04:57.421695
# Unit test for function register
def test_register():
    register()




# Generated at 2022-06-11 22:04:59.258046
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None  # type: ignore



# Generated at 2022-06-11 22:05:07.136661
# Unit test for function register
def test_register():
    # Get the currently registered codecs
    current_codecs = codecs.__dict__['_cache']

    # Delete the codecs cache
    del codecs.__dict__['_cache']

    # Register the codec
    register()

    # Check the codec has been registered
    assert codecs.__dict__['_cache'] != current_codecs

    # Restore the codecs cache.
    codecs.__dict__['_cache'] = current_codecs


# Generated at 2022-06-11 22:05:08.791411
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-11 22:05:12.195785
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise RuntimeError(f'failed: {e}')


# Generated at 2022-06-11 22:05:13.053932
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:05:16.424385
# Unit test for function register
def test_register():

    try:
        codecs.getdecoder('eutf8h')
    except LookupError:
        pass
    else:
        assert False
    register()
    codecs.getdecoder('eutf8h')
    return


# noinspection PyUnresolvedReferences

# Generated at 2022-06-11 22:05:23.749896
# Unit test for function register
def test_register():
    test_name = "eutf8h"
    register()
    assert codecs.lookup(test_name)
    codecs.lookup(test_name).decode(b"\\x41\\x42\\x43", "strict")
    assert codecs.lookup(test_name).decode(b"\\x41\\x42\\x43", "strict") == ("ABC", 10)


# Generated at 2022-06-11 22:05:26.923384
# Unit test for function register
def test_register():  # pragma: no cover
    register()



# Generated at 2022-06-11 22:05:28.779090
# Unit test for function register
def test_register():
    # assert int(codecs.encode('a', NAME)[0], 16) == ord('a')
    pass

# Generated at 2022-06-11 22:05:32.176361
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
    assert codecs.getdecoder(NAME) is not None

# Generated at 2022-06-11 22:05:32.874995
# Unit test for function register
def test_register():
    pass # test_register

# Generated at 2022-06-11 22:05:37.780881
# Unit test for function register
def test_register():
    try:
        test_ = codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)
        test_ = codecs.getdecoder(NAME)
    assert test_ is not None



# Generated at 2022-06-11 22:05:39.791440
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


__all__ = [
    'encode',
    'decode',
    'NAME',
    'register',
    'test_register',
]

# Generated at 2022-06-11 22:05:43.801046
# Unit test for function register
def test_register():
    register()
    # noinspection PyProtectedMember
    x = codecs._cache.getdecoder(NAME)
    assert x[0] == decode
    assert x[1] == decode

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:05:47.220801
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore
    codec = codecs.getdecoder(NAME)
    assert codec



# Generated at 2022-06-11 22:05:49.481659
# Unit test for function register
def test_register():
    """Test that register() registers the codec.

    """
    codecs.register(_get_codec_info)

# Generated at 2022-06-11 22:05:52.593301
# Unit test for function register
def test_register():
    """
    Test that the register function successfully registers our module.
    :return: None
    """
    codecs.register(_get_codec_info)  # type: ignore
    assert codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:05:54.399950
# Unit test for function register
def test_register():
    register()
    codecs.register(_get_codec_info)



# Generated at 2022-06-11 22:05:57.020567
# Unit test for function register
def test_register():
    """Unit tests for function register."""
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:05:58.248916
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:05:59.558879
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:06:08.993851
# Unit test for function register
def test_register():
    """Unit test for function register."""
    codecs.register(_get_codec_info)   # type: ignore
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getincrementalencoder(NAME) is not None
    assert codecs.getincrementaldecoder(NAME) is not None
    assert codecs.getreader(NAME) is not None
    assert codecs.getwriter(NAME) is not None



# Generated at 2022-06-11 22:06:18.239202
# Unit test for function register
def test_register():
    # Make sure the NAME is not already registered.
    from types import ModuleType
    module = ModuleType(NAME)
    orig_module = sys.modules[NAME]
    sys.modules[NAME] = module
    register()
    sys.modules[NAME] = orig_module

    # Make sure the NAME is registered.
    from types import ModuleType
    module = ModuleType(NAME)
    sys.modules[NAME] = module
    register()
    assert sys.modules[NAME] == module
    del sys.modules[NAME]
    del module



# Generated at 2022-06-11 22:06:21.016399
# Unit test for function register

# Generated at 2022-06-11 22:06:24.633825
# Unit test for function register
def test_register():
    try:
        codecs.lookup(NAME)
    except LookupError:
        register()
        codecs.lookup(NAME)


# Generated at 2022-06-11 22:06:28.808249
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is decode
    assert codecs.getencoder(NAME) is encode


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:06:31.370780
# Unit test for function register
def test_register():
    register()
    obj = codecs.getdecoder(NAME)
    assert obj is not None
    print('Function: test_register() - PASSED')



# Generated at 2022-06-11 22:06:33.005150
# Unit test for function register
def test_register():
    register()
    test = codecs.getdecoder(NAME)
    assert test[0] == NAME


# Generated at 2022-06-11 22:06:34.561772
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None

# Generated at 2022-06-11 22:06:37.721622
# Unit test for function register
def test_register():
    if 'eutf8h' not in codecs.decoder_aliases.keys():
        register()
        assert 'eutf8h' in codecs.decoder_aliases.keys()


# Generated at 2022-06-11 22:06:39.327360
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None

# Generated at 2022-06-11 22:06:48.045222
# Unit test for function register
def test_register():
    import codecs
    codecs.register(register)


if __name__ == '__main__':
    register()
    test_register()

# Generated at 2022-06-11 22:06:49.859282
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:06:51.259631
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:06:54.868867
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)    # type: ignore
    try:
        codecs.lookup(NAME)
    except LookupError:
        assert False


# Generated at 2022-06-11 22:06:58.294908
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder('eutf8h')
    except LookupError:
        # The codec has not been registered.
        register()
        codecs.getdecoder('eutf8h')

# Generated at 2022-06-11 22:07:00.899416
# Unit test for function register
def test_register():
    register()
    # Check if register worked.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, "Failed to add 'eutf8h' codec."



# Generated at 2022-06-11 22:07:03.502840
# Unit test for function register
def test_register():
    """Unit test for function register."""

    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:07:05.409755
# Unit test for function register
def test_register():
    """
    Test register()

    :return:
    """
    # codecs.register(_get_codec_info)



# Generated at 2022-06-11 22:07:06.378301
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:07:08.014861
# Unit test for function register
def test_register():
    """
    This unit test will only pass if the given codec name does not
    already exist.
    """
    register()



# Generated at 2022-06-11 22:07:21.487452
# Unit test for function register
def test_register():
    register()
    _ = codecs.getencoder(NAME)
    _ = codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:07:25.655782
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME)
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:07:26.283306
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:07:26.958072
# Unit test for function register
def test_register():
    register()

register()


# Helper Functions

# Generated at 2022-06-11 22:07:29.620436
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)  # type: ignore
    assert codecs.getdecoder(NAME)  # type: ignore
    assert codecs.getencoder(NAME)  # type: ignore



# Generated at 2022-06-11 22:07:30.973450
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-11 22:07:33.926294
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)  # type: ignore
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False


# Generated at 2022-06-11 22:07:35.323954
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise



# Generated at 2022-06-11 22:07:37.002174
# Unit test for function register
def test_register():
    register()
    assert NAME == codecs.lookup(NAME).name



# Generated at 2022-06-11 22:07:39.455448
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    print(globals().keys())
    print('done')

# Generated at 2022-06-11 22:08:03.337580
# Unit test for function register
def test_register():
    from codecs import lookup
    register()

    try:
        lookup(NAME)
    except LookupError:
        raise RuntimeError("Can't find '%s' codec", NAME)

# Generated at 2022-06-11 22:08:06.526086
# Unit test for function register
def test_register():
    if codecs.lookup(NAME) is not None:
        raise Exception('Register function must not be called when codec'
                        ' is already registered.')
    register()
    codecs.lookup(NAME)


# Generated at 2022-06-11 22:08:09.384129
# Unit test for function register
def test_register():
    codecs.register(lambda name: None)
    register()
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)
    assert codecs.lookup(NAME)

# Generated at 2022-06-11 22:08:15.128842
# Unit test for function register
def test_register():
    assert codecs.getdecoder(NAME) is decode
    assert codecs.getencoder(NAME) is encode

    register()  # Should not register again
    assert codecs.getdecoder(NAME) is decode
    assert codecs.getencoder(NAME) is encode


register()



# Generated at 2022-06-11 22:08:24.986212
# Unit test for function register
def test_register():
    import sys
    import os
    import unittest

    # Import the eutf8h module to test.
    import eutf8h

    class Test(unittest.TestCase):
        def test_register(self):
            _, name = os.path.split(__file__)

            # Import the module containing the function under test.
            if name == 'register':
                if name in sys.modules:
                    del sys.modules[name]
                import register
                reload(register)

            register.register()

            # Import the module containing the function under test.
            if name == 'register':
                reload(register)

            self.assertEqual(
                id(eutf8h.encode),
                id(register.encode)
            )

# Generated at 2022-06-11 22:08:28.006177
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)  # type: ignore
    codecs.getencoder(NAME)  # type: ignore



# Generated at 2022-06-11 22:08:31.317747
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
        return True
    return False


# Optional __main__ entry
if __name__ == '__main__':
    register()

# Generated at 2022-06-11 22:08:32.596529
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:08:34.823109
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'Codec not registered'
    else:
        assert True



# Generated at 2022-06-11 22:08:36.213261
# Unit test for function register
def test_register():
    register()

    obj = codecs.getdecoder(NAME)  # type: ignore
    _ = obj



# Generated at 2022-06-11 22:09:32.930161
# Unit test for function register

# Generated at 2022-06-11 22:09:35.275337
# Unit test for function register
def test_register():
    register()

    # Test if the codec is registered:
    if not codecs.getdecoder(NAME):
        raise RuntimeError('Codec not registered.')



# Generated at 2022-06-11 22:09:38.822314
# Unit test for function register
def test_register():
    def test_register_success():
        register()
        try:
            codecs.getdecoder(NAME)
        except LookupError:
            assert False, 'codec not registered'

    test_register_success()

# Generated at 2022-06-11 22:09:39.777034
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:09:45.662211
# Unit test for function register
def test_register():
    """Test the function register.

    Test the function register by loading it and unloading it.

    """
    global NAME, encode, decode
    codecs.register(_get_codec_info)
    decode_ = codecs.getdecoder(NAME)
    encode_ = codecs.getencoder(NAME)
    decode_('a', 'strict')
    encode_('a', 'strict')
    assert True


# Generated at 2022-06-11 22:09:49.298361
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pytest.fail("Unable to register codec: %s" % NAME)


register()

# Generated at 2022-06-11 22:09:54.691378
# Unit test for function register
def test_register():
    def getdecoder(encoding: str) -> Optional[codecs.CodecInfo]:
        try:
            return codecs.getdecoder(encoding)
        except LookupError:
            return None
    regd = getdecoder(NAME)
    register()
    regd_post = getdecoder(NAME)
    assert regd is None
    assert regd_post is not None

# Generated at 2022-06-11 22:10:05.434042
# Unit test for function register
def test_register():
    assert codecs.getdecoder(NAME)


if __name__ == '__main__':
    register()
    test_register()
    assert '𐀀'.encode('eutf8h') == b'\\xf0\\x90\\x80\\x80'
    assert '𐀀'.encode('utf-8') == '𐀀'.encode('eutf8h').decode('eutf8h').encode(
        'utf-8')
    assert '𐀀'.encode('utf-8') == '\\\\xf0\\\\x90\\\\x80\\\\x80'.encode(
        'eutf8h').decode('eutf8h').encode('utf-8')

# Generated at 2022-06-11 22:10:14.920631
# Unit test for function register
def test_register():
    # Test that codecs.getdecoder(NAME) works after we called
    # codecs.register(_get_codec_info).

    register()

    # Test that we can decode a string of escaped utf8 hex
    # characters.

# Generated at 2022-06-11 22:10:16.737134
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)  # type: ignore



# Generated at 2022-06-11 22:12:07.637754
# Unit test for function register
def test_register():
    register()
    decoder = codecs.getdecoder(NAME)
    assert decoder == decode



# Generated at 2022-06-11 22:12:11.192030
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# Generated at 2022-06-11 22:12:14.727513
# Unit test for function register
def test_register():
    from codecs import lookup as _lookup
    register()
    cod = _lookup(NAME)
    assert isinstance(cod, codecs.CodecInfo)
    assert cod.name == NAME


# Generated at 2022-06-11 22:12:15.626785
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:12:20.817341
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        print(f'The {NAME} codec is not registered')
    else:
        print(f'The {NAME} codec is already registered')
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        print(f'The {NAME} codec is not registered')
    else:
        print(f'The {NAME} codec is already registered')


# Generated at 2022-06-11 22:12:22.818520
# Unit test for function register
def test_register():
    import codecs
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:12:25.617050
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'Failed to register!'



# Generated at 2022-06-11 22:12:27.000154
# Unit test for function register
def test_register():

    # This function should raise nothing.
    register()



# Generated at 2022-06-11 22:12:27.990213
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:12:36.468652
# Unit test for function register
def test_register():
    """Unit test for function register."""

    # Import module sys and module io.
    import sys
    import io

    # Strip the path and get the current module name.
    module_name = __file__.rsplit('/', 1)[-1].split('.')[0]

    # Register the codec.
    register()

    # Check that the codec has been registered.
    # name, encode, decode, incrementaldecode, flush = codecs.lookup(NAME)
    name = codecs.lookup(NAME).name
    assert name == NAME

    # Get the codec by name.
    codec_information = codecs.getincrementalencoder(NAME)  # type: ignore

    # Check that the codec is the same object.
    assert codec_information.__objclass__.__name__ == module_name

    # Write a