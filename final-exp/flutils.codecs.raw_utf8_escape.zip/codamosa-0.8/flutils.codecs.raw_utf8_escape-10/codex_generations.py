

# Generated at 2022-06-11 22:04:42.033154
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-11 22:04:46.399126
# Unit test for function register
def test_register():
    try:
        codecs.getencoder(NAME)
    except LookupError:
        raise AssertionError(f'codec {NAME} is not registered')


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:04:49.306793
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-11 22:04:51.417844
# Unit test for function register
def test_register():  # pragma: no cover
    register()
    assert codecs.lookup(NAME)[0] == 'eutf8h'



# Generated at 2022-06-11 22:04:53.478904
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:04:55.632992
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()

__all__ = [
    'decode',
    'encode',
    'register',
]

# Generated at 2022-06-11 22:05:00.493568
# Unit test for function register
def test_register():
    if NAME not in codecs.__all__:
        register()
        assert NAME in codecs.__all__


_codec_info = _get_codec_info(NAME)

if _codec_info is not None:
    codecs.register(_codec_info)  # type: ignore

del _codec_info



# Generated at 2022-06-11 22:05:01.868193
# Unit test for function register
def test_register():
    assert codecs.getdecoder(NAME) is not None

# Generated at 2022-06-11 22:05:03.243098
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None

# Generated at 2022-06-11 22:05:04.256074
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-11 22:05:12.036225
# Unit test for function register
def test_register():
    obj0 = codecs.getdecoder(NAME)
    assert obj0 is not None



# Generated at 2022-06-11 22:05:19.668866
# Unit test for function register
def test_register():
    import re
    import sys

    # Determine if the module is already registered.
    already_registered = True
    for value in codecs.codecs_gen():
        if value.name == NAME:
            already_registered = False

    # Register the module.
    if not already_registered:
        sys.stdout.write('Registering module %s\n' % NAME)
        register()

    # Search for registered module.
    found_module = False
    for value in codecs.codecs_gen():
        if value.name == NAME:
            found_module = True
            break

    # Return the results.
    if not found_module:
        raise LookupError('Failed to register module %s\n' % NAME)

    sys.stdout.write('Registered module %s\n' % NAME)




# Generated at 2022-06-11 22:05:23.642047
# Unit test for function register
def test_register():
    # Remove NAME from the list of codecs
    codecs.lookup(NAME).pop()

    # Register NAME as a codec
    register()

    # Verify that the NAME is registered
    assert codecs.lookup(NAME)



# Generated at 2022-06-11 22:05:28.174104
# Unit test for function register
def test_register():
    assert _get_codec_info('eutf8h')
    register()
    assert codecs.getencoder('eutf8h')



# Generated at 2022-06-11 22:05:32.175374
# Unit test for function register
def test_register():
    """Perform a unit test of function :func:`register`."""
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:05:34.560261
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:05:35.471245
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:05:40.345673
# Unit test for function register
def test_register():
    import codecs
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
    assert str(codecs.lookup(NAME).name) == NAME


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:05:41.273752
# Unit test for function register
def test_register():
    assert codecs.getdecoder(NAME) is not None

# Generated at 2022-06-11 22:05:49.142990
# Unit test for function register
def test_register():
    # Register the encoding
    register()

    # Confirm the encoding is registered
    got = codecs.lookup(NAME)  # type: ignore
    expected = codecs.CodecInfo(  # type: ignore
        name=NAME,
        encode=encode,  # type: ignore[arg-type]
        decode=decode,  # type: ignore[arg-type]
    )
    assert got == expected



# Generated at 2022-06-11 22:05:55.155786
# Unit test for function register
def test_register():
    register()
    # noinspection PyUnresolvedReferences
    from . import eutf8h
    assert NAME == eutf8h.NAME



# Generated at 2022-06-11 22:05:57.786009
# Unit test for function register
def test_register():
    # noinspection PyUnresolvedReferences
    codecs.encode('abc', 'eutf8h')


# Run register on import
register()

# Generated at 2022-06-11 22:06:01.417541
# Unit test for function register
def test_register():
    encode('x')
    decode('x'.encode('utf8'))

__all__ = [
    'register',
    'encode',
    'decode',
    'NAME',
    'codecs',
]

# Generated at 2022-06-11 22:06:07.903272
# Unit test for function register
def test_register():
    # print(f"{__name__} starting")

    # Actually call register()
    register()

    # Show that the eutf8h codec can now be found.
    # print(f"Available codecs: {codecs.__dict__['_cache'].keys()}")
    # assert NAME in codecs.__dict__['_cache'].keys()
    codecs.getdecoder(NAME)  # This should not raise an error.

# Generated at 2022-06-11 22:06:11.575848
# Unit test for function register
def test_register():
    NAME = __name__.split('.')[-1]
    codecs.register(_get_codec_info)   # type: ignore
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pytest.fail("Unable to register %s function" % NAME)



# Generated at 2022-06-11 22:06:17.106573
# Unit test for function register
def test_register():
    register()

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:06:21.256971
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
        raise Exception(
            "EUTF8H codec already registered. "
            "Run \"python3 -m utf8h_test\" from "
            "the module root directory to test."
        )
    except LookupError:
        pass
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:06:33.301776
# Unit test for function register
def test_register():
    import types
    import unicodedata
    test_string = unicodedata.lookup('LATIN CAPITAL LETTER A WITH ACUTE')
    test_string = test_string + '\x00\x00'
    codecs.register(_get_codec_info)
    # Register should be idempotent; test this property by registering twice.
    codecs.register(_get_codec_info)
    # Test the encode function
    encode1 = codecs.getencoder('eutf8h')
    encode2 = encode   # type: ignore
    for call_encode in (encode1, encode2):
        result, length = call_encode(test_string)
        assert result == '\xc3\x81\x00\x00'
        assert length == len(test_string)
    # Test the

# Generated at 2022-06-11 22:06:34.194755
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-11 22:06:36.451341
# Unit test for function register
def test_register():
    reg = codecs.getdecoder(NAME)
    assert reg(b'\\xC2\\xA2')[0] == '¢'

# Generated at 2022-06-11 22:06:47.400815
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)  # type: ignore
    codecs.getdecoder(NAME)  # type: ignore



# Generated at 2022-06-11 22:06:56.716186
# Unit test for function register
def test_register():
    from test.support.script_helper import assert_python_ok

    register()
    with open('/dev/null', 'w') as f:
        assert_python_ok('-c', '"a\\u1234"', stdout=f, stderr=f)
        assert_python_ok(
            '-c',
            '"a\\u1234".encode("eutf8h")',
            stdout=f,
            stderr=f
        )


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:07:01.831219
# Unit test for function register
def test_register():
    # Create a CodecRegistryError using a dummy codec name.
    try:
        codecs.getdecoder('dummy')
        raise RuntimeError('Should have raised LookupError')
    except LookupError:
        pass
    # Register the codec
    register()
    # Verify that the codec is registered
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:07:05.669976
# Unit test for function register
def test_register():
    register()
    print(codecs.getencoder(NAME)('\\u2600'))
    print(codecs.getencoder(NAME)('\\u1f420'))
    print(codecs.getencoder(NAME)('\\x61'))



# Generated at 2022-06-11 22:07:14.757075
# Unit test for function register
def test_register():
    # Call the test with stdout redirected
    from io import StringIO
    import sys
    from contextlib import contextmanager

    from nose.tools import assert_equal

    @contextmanager
    def captured_output():
        """Redirect stdout."""
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    # First, test that the codec is not registered

# Generated at 2022-06-11 22:07:15.374645
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-11 22:07:17.742831
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False


# Generated at 2022-06-11 22:07:20.960764
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-11 22:07:24.884916
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:07:27.886334
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)


# Generated at 2022-06-11 22:07:47.691182
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:07:51.093248
# Unit test for function register
def test_register():
    """Test if codec is registered.

    If `test_register` is **not** the **first** codec test run,
    then the codec **may have already been** registered.

    """
    # Get the codec info
    _get_codec_info(NAME)

# Generated at 2022-06-11 22:07:58.401806
# Unit test for function register
def test_register():
    # Check if codecs_encode_utf8_hex is already registered with codecs.
    try:
        codecs.getdecoder(NAME)
        registered = True
    except LookupError:
        registered = False

    # If codecs_encode_utf8_hex is not registered, then register it.
    if not registered:
        codecs.register(_get_codec_info)

    # Check if codecs_encode_utf8_hex was registered.
    try:
        codecs.getdecoder(NAME)
        registered = True
    except LookupError:
        registered = False

    assert registered is True


# def test_ignore():
#     data = codecs.decode('\\xe2\\x82\\xac', NAME)
#     assert data == '€'
#
#     data = codec

# Generated at 2022-06-11 22:08:00.922117
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-11 22:08:07.556625
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME) is not None


if __name__ == '__main__':
    register()
    hex_bytes = b'\\x4f\\x16'
    hex_str = hex_bytes.decode(NAME)
    assert hex_str == '\U00034f16'
    assert hex_bytes == hex_str.encode(NAME)
    assert hex_str.encode('utf-8') == b'\xf0\x9d\x8f\x96'

# Generated at 2022-06-11 22:08:10.728625
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.__all__
    assert codecs.getencoder(NAME) == encode
    assert codecs.getdecoder(NAME) == decode


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:08:16.781145
# Unit test for function register
def test_register():
    # Test for when the codec exists
    codecs.getdecoder(NAME)

    # Test for when the codec does not exist
    try:
        codecs.getdecoder('THIS-CODEC-DOESNT-EXIST')
    except LookupError:
        pass
    else:
        raise AssertionError(
            'A LookupError should have been raised'
        )

# Generated at 2022-06-11 22:08:18.318980
# Unit test for function register
def test_register():
    register()
    # noinspection PyUnresolvedReferences
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:08:19.698077
# Unit test for function register
def test_register():
    # The function is only registered once
    register()
    register()

# Generated at 2022-06-11 22:08:24.174787
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    test_register()

"""
At the time of writing, this module exactly matches the `test_eutf8h`
test_eutf8h.py file.
"""

import codecs
import unittest



# Generated at 2022-06-11 22:08:59.345399
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore


# Generated at 2022-06-11 22:09:05.135361
# Unit test for function register
def test_register():
    import io

    if not NAME.startswith('_'):
        register()

        # Create a file-like buffer.
        buffer = io.BytesIO()

        # Register the codec into the buffer.
        buffer.encoding = NAME

        # Write to the buffer.
        buffer.write(b'\xe2\x88\x80')

        # Read from the buffer and see if the content is correct.
        buffer.seek(0)
        bytes_in = buffer.read()
        assert bytes_in == b'\xe2\x88\x80'

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:09:06.672629
# Unit test for function register
def test_register():
    import codecs
    codecs.register(_get_codec_info)    # type: ignore



# Generated at 2022-06-11 22:09:10.077592
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    _ = codecs.getdecoder(NAME)
    codecs.register(_get_codec_info)
    codecs.register(_get_codec_info)



# Generated at 2022-06-11 22:09:15.428099
# Unit test for function register
def test_register():
    import codecs
    try:
        codecs.getencoder('eutf8h')
        print('eutf8h codec registered')
    except LookupError:
        codecs.register(eutf8h.register)
        print('eutf8h codec registered')


if __name__ == '__main__':
    register()

# Generated at 2022-06-11 22:09:22.707699
# Unit test for function register
def test_register():
    from unittest.mock import patch
    from importlib import reload
    reload(codecs)
    codecs_getdecoder = codecs.getdecoder(NAME)
    codecs_getencoder = codecs.getencoder(NAME)
    assert codecs_getencoder('') == (b'', 0)
    assert codecs_getdecoder(b'')[0] == ''
    del codecs.getdecoder, codecs.getencoder, codecs.register
    with patch(__name__ + '.codecs') as codecs:
        register()
        assert codecs.register.call_count == 1
    assert codecs.getencoder('') == (b'', 0)
    assert codecs.getdecoder(b'')[0] == ''


# Generated at 2022-06-11 22:09:24.334634
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:09:27.354676
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)     # type: ignore
    decoder = codecs.getdecoder(NAME)
    assert NAME == decoder.__name__      # type: ignore



# Generated at 2022-06-11 22:09:28.720936
# Unit test for function register
def test_register():
    assert codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:09:36.856089
# Unit test for function register
def test_register():
    """test_register"""
    register()
    encoded = 'ă'.encode(NAME)
    decoded = encoded.decode(NAME)
    assert decoded == 'ă'


if __name__ == '__main__':
    register()
    assert bytes('\\x04', NAME) == (4, )
    assert bytes('\\x4', NAME) == (4, )
    assert bytes('\\xE2\\x82\\xAC', NAME) == bytes('€', 'utf8')
    assert '\\xE2\\x82\\xAC'.encode(NAME) == bytes('€', 'utf8')
    assert b'\\xE2\\x82\\xAC'.decode(NAME) == '€'

# Generated at 2022-06-11 22:10:55.989448
# Unit test for function register
def test_register():
    """Unit test for function register.
    """

    # Function 'codecs.getdecoder' throws an exception if the codec
    # is not registered.
    try:
        codecs.getdecoder('eutf8h')
    except LookupError:
        pass
    else:
        raise AssertionError('Codec is registered.')
    #
    # Call function 'register' and then retest.
    register()
    try:
        assert codecs.getdecoder('eutf8h') is not None
    except LookupError:
        raise AssertionError('Codec is not registered.')



# Generated at 2022-06-11 22:10:57.401916
# Unit test for function register
def test_register():
    register()
    obj = codecs.getdecoder(NAME)
    assert obj.name == NAME


register()

# Generated at 2022-06-11 22:11:05.333599
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
        raise ValueError('codecs.getdecoder(NAME) should not exist.')
    except LookupError as e:
        pass  # codecs.getdecoder is expected to raise LookupError error

    codecs.register(_get_codec_info)
    codecs.getdecoder(NAME)  # codecs.getdecoder is expected not to raise error

    codecs.register(_get_codec_info)



# Generated at 2022-06-11 22:11:07.674347
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore


# Unit tests for function encode

# Generated at 2022-06-11 22:11:11.587349
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)  # type: ignore
    _decoder = codecs.getdecoder(NAME)  # type: ignore
    assert _decoder



# Generated at 2022-06-11 22:11:15.342986
# Unit test for function register
def test_register():
    assert NAME not in codecs.getencodings()
    assert NAME not in codecs.getdecodings()
    register()
    assert NAME in codecs.getencodings()
    assert NAME in codecs.getdecodings()

# Generated at 2022-06-11 22:11:17.110333
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME)
    assert codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:11:19.102216
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getencodings()


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:11:29.392993
# Unit test for function register
def test_register():
    # Remove the codec names of the codecs registered.
    names = codecs.__dict__['_cache'].copy()
    for k in names:
        del codecs.__dict__['_cache'][k]
        del sys.modules['codecs'].__dict__[k]
        del sys.modules['encodings.__dict__'][k]

    # Assert that the codec names are removed.
    assert not set(names) & set(codecs.__dict__['_cache'])

    # Register the codec
    register()

    # Assert that the codec name is registered.
    assert set(names) & set(codecs.__dict__['_cache'])


if __name__ == '__main__':
    import doctest

# Generated at 2022-06-11 22:11:30.917738
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:14:24.553867
# Unit test for function register
def test_register():
    """Ensure that the codec is registered."""
    register()
    codec_info = codecs.lookup(NAME)
    assert codec_info is not None
    del codec_info


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:14:33.928068
# Unit test for function register
def test_register():
    import pytest
    from .test_data import (
        test_cases,
        expected_text,
        expected_bytes,
        expected_bytes_hex,
    )

    for case in test_cases:
        given_text = case[0]
        given_bytes = case[1]

        given = given_text

        actual_text, _ = codecs.decode(given, NAME)
        actual_bytes, _ = codecs.encode(given, NAME)

        assert actual_text == expected_text
        assert actual_bytes == expected_bytes

        given = given_bytes

        actual_text, _ = codecs.decode(given, NAME)
        actual_bytes, _ = codecs.encode(given, NAME)

        assert actual_text == expected_text
        assert actual_bytes == expected_bytes

       

# Generated at 2022-06-11 22:14:35.755454
# Unit test for function register
def test_register():
    """No unit tests currently available."""
    pass

register()