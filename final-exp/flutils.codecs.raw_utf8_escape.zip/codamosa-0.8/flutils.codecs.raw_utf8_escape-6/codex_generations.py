

# Generated at 2022-06-11 22:04:42.117634
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:04:44.273069
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:04:45.863830
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)



# Generated at 2022-06-11 22:04:55.136260
# Unit test for function register
def test_register():
    class CodecsMock:
        def getencoder(self, codec: str):...
        def getdecoder(self, codec: str):...
        def register(self, codec_info):...

    codecs_mock = CodecsMock()
    with mock.patch.multiple(
        __name__ + '.codecs',
        getencoder=lambda name: codecs_mock.getencoder(name),
        getdecoder=lambda name: codecs_mock.getdecoder(name),
        register=lambda codec_info: codecs_mock.register(codec_info),
    ):
        register()

        assert codecs_mock.getdecoder.call_count == 1
        assert codecs_mock.register.call_count == 1

# Generated at 2022-06-11 22:04:56.873907
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup_error('eutf8h')

# Generated at 2022-06-11 22:04:57.566159
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)



# Generated at 2022-06-11 22:04:59.394301
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore


# Generated at 2022-06-11 22:05:03.572937
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)
        print(f'Codec {NAME} registered successfully.')


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:05:09.794086
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        # codec not registered
        pass
    else:
        # codec registered
        raise AssertionError()

    register()

    # codec was not registered before and now it's registered
    codecs.getdecoder(NAME)


del _ByteString
del _Str
del UserString

# Generated at 2022-06-11 22:05:17.982262
# Unit test for function register
def test_register():
    import sys
    if 'win' in sys.platform:
        # On windows, the register function
        # is called by the installer.
        # This means that, it is possible to
        # not find the codec in order to register it.
        code_found = False
    else:
        # On other platforms, the register function
        # is called by the install function.
        # This means that, it is not possible to
        # find the codec in order to register it.
        code_found = True

    try:
        codecs.getdecoder('eutf8h')
    except LookupError:
        assert code_found is False
    else:
        assert code_found is True

    register()


# Generated at 2022-06-11 22:05:21.862025
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:05:22.852746
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:05:26.000434
# Unit test for function register
def test_register():
    register()
    assert NAME == codecs.getdecoder(NAME).name


# Generated at 2022-06-11 22:05:35.616590
# Unit test for function register
def test_register():
    import sys
    # noinspection PyUnresolvedReferences
    import eutf8h
    sys.modules[__name__] = eutf8h
    eutf8h.register()
    assert eutf8h.NAME == 'eutf8h'
    with pytest.raises(UnicodeEncodeError):
        eutf8h.encode("A\u2764\ufe0fZ")
    fr_message_orig = "Mélangez les cartes"
    fr_hex_bytes = b"M\\xC3\\xA9langez les cartes"
    fr_hex_message = fr_hex_bytes.decode("eutf8h")
    assert fr_hex_message == fr_message_orig


# Generated at 2022-06-11 22:05:38.835869
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getdecoder(NAME)
    assert NAME in codecs.getencoder(NAME)

# Generated at 2022-06-11 22:05:39.965017
# Unit test for function register
def test_register():
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:05:44.760328
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise Exception('Expected LookupError')
    register()
    codecs.getdecoder(NAME)  # type: ignore[no-untyped-call]


# Generated at 2022-06-11 22:05:45.765892
# Unit test for function register
def test_register():
    codecs.lookup(NAME)



# Generated at 2022-06-11 22:05:54.992141
# Unit test for function register
def test_register():
    try:
        codecs.lookup(NAME)
    except LookupError:
        register()


if __name__ == '__main__':

    test_register()

    import sys
    import argparse
    import locale


# Generated at 2022-06-11 22:05:55.775734
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:06:00.731314
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME) != None  # type: ignore
    assert codecs.getdecoder(NAME) != None  # type: ignore


# Generated at 2022-06-11 22:06:01.422264
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-11 22:06:03.447637
# Unit test for function register
def test_register():
    """Unit test of function register."""
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:06:06.271251
# Unit test for function register
def test_register():
    codecs.lookup_error('eutf8h')
    register()
    codecs.lookup_error('eutf8h')



# Generated at 2022-06-11 22:06:10.570309
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)  # test
unittest.FunctionTestCase.test_register = test_register



# Generated at 2022-06-11 22:06:12.843997
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:06:22.076012
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup_error('strict') is None
    assert codecs.lookup_error('ignore') is None
    assert codecs.lookup_error('replace') is None
    assert codecs.lookup_error('xmlcharrefreplace') is None
    assert codecs.lookup_error('backslashreplace') is None
    assert codecs.lookup_error('namereplace') is None
    assert codecs.lookup_error('surrogateescape') is None
    assert codecs.lookup_error('surrogatepass') is None
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-11 22:06:24.451297
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:06:28.259801
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore

# Generated at 2022-06-11 22:06:29.951850
# Unit test for function register
def test_register():
    from . import codecs_utf8hex as module
    assert module.register() is None



# Generated at 2022-06-11 22:06:36.064113
# Unit test for function register
def test_register():
    import sys
    register()
    assert sys.getdefaultencoding() == NAME

# Generated at 2022-06-11 22:06:38.078418
# Unit test for function register
def test_register():
    try:
        codecs.getencoder(NAME)
    except LookupError:
        register()

# Generated at 2022-06-11 22:06:44.647259
# Unit test for function register
def test_register():
    test_codec = 'foo'
    with pytest.raises(LookupError):
        codecs.getdecoder(test_codec)
        codecs.getencoder(test_codec)
    codecs.register(lambda name: (lambda obj, errors: (obj, len(obj)) if name == test_codec else None))
    codecs.getdecoder(test_codec)
    codecs.getencoder(test_codec)


# Generated at 2022-06-11 22:06:50.586181
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise AssertionError(str(e)) from None


if __name__ == '__main__':
    register()
    codecs.getdecoder(NAME)

    test_register()

# Generated at 2022-06-11 22:06:58.653860
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME).encode('a')[0] == b'a'
    assert codecs.lookup(NAME).decode(b'a')[0] == 'a'
    assert codecs.lookup(NAME).decode(b'\\xe2\\x82\\xac')[0] == '€'
    assert codecs.lookup(NAME).encode('€')[0] == b'\\xe2\\x82\\xac'

# Generated at 2022-06-11 22:07:02.090357
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:07:03.828419
# Unit test for function register
def test_register():
    register()
    try:
        assert codecs.getdecoder(NAME)
    except LookupError:
        assert False

# Generated at 2022-06-11 22:07:07.574962
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
    assert isinstance(codecs.getdecoder(NAME), codecs.CodecInfo)



# Generated at 2022-06-11 22:07:10.583054
# Unit test for function register
def test_register():
    try:
        codecs_name = NAME
        codecs.getdecoder(codecs_name)
    except LookupError:
        codecs.register(get_codec_info)

# Generated at 2022-06-11 22:07:13.931813
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-11 22:07:28.040590
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.registered_error_handlers  # type: ignore
    assert NAME in codecs.registered_incremental_decoders  # type: ignore
    assert NAME in codecs.registered_incremental_encoders  # type: ignore



# Generated at 2022-06-11 22:07:31.785786
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# Generated at 2022-06-11 22:07:36.577378
# Unit test for function register
def test_register():
    register()
    s = 'a\x80\u2122'
    t = b'a\\x80\\u2122'

    assert codecs.encode(s, 'eutf8h') == t
    assert codecs.decode(t, 'eutf8h') == s


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:07:37.563347
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.__dict__

# Generated at 2022-06-11 22:07:41.195557
# Unit test for function register
def test_register():

    # call register function
    register()

    try:
        codecs.getdecoder(NAME)
    except LookupError as e:  # pragma: no cover
        print('Unable to register codec "%s": %s' % (NAME, e))

# Generated at 2022-06-11 22:07:43.496147
# Unit test for function register
def test_register():
    assert codecs.lookup(NAME) is encode
    assert codecs.lookup(NAME)[1] is decode



# Generated at 2022-06-11 22:07:47.606858
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
    assert codecs.getdecoder(NAME)

register()

# Generated at 2022-06-11 22:07:51.320987
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
    obj = codecs.getdecoder(NAME)
    assert obj is not None
    assert obj.name == NAME


# Generated at 2022-06-11 22:07:52.941160
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-11 22:07:55.853483
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert NAME not in codecs.getdecoders() and NAME not in codecs.getencoders()

test_register()
register()


del (
    _ByteString,
    _Str
)

# Generated at 2022-06-11 22:08:18.341573
# Unit test for function register
def test_register():

    def _():
        codecs.getdecoder(NAME)
        codecs.getencoder(NAME)

    # 1. Not currently registered
    with pytest.raises(LookupError) as e:
        _()
    assert e.value.args[0] == 'unknown encoding: %s' % NAME

    # 2. Register
    register()

    # 3. Now registered
    _()



# Generated at 2022-06-11 22:08:22.056776
# Unit test for function register
def test_register():
    from sys import modules
    from importlib.util import find_spec

    register()
    modules[NAME]['register']()
    modules[NAME]['register']()
    assert find_spec(NAME) is not None


# Generated at 2022-06-11 22:08:24.269400
# Unit test for function register
def test_register():
    register()
    decoder = codecs.getdecoder(NAME)
    assert decoder is not None


# Generated at 2022-06-11 22:08:31.687742
# Unit test for function register
def test_register():
    """Unit test for function register."""
    import sys
    import unittest

    class TestRegister(unittest.TestCase):
        """Unit test for function register."""

        def test_register(self):
            """Unit test for function register."""
            sys.modules.pop(__name__, None)
            register()
            import_module(__name__)
            unregister()

        def test_unregister(self):
            """Unit test for function unregister."""
            unregister()
            with self.assertRaises(LookupError):
                import_module(__name__)

    unittest.main()



# Generated at 2022-06-11 22:08:33.281865
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# Generated at 2022-06-11 22:08:34.466061
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None

# Generated at 2022-06-11 22:08:38.751440
# Unit test for function register
def test_register():
    # On the first time this module is called, register this module
    # with the codecs module.
    register()

    # Get the CodecInfo for this module.
    obj = codecs.getdecoder(NAME)

    # Test that the CodecInfo has the correct codec name.
    assert obj.name == NAME



# Generated at 2022-06-11 22:08:45.708484
# Unit test for function register
def test_register():
    # noinspection PyUnresolvedReferences,PyUnusedLocal
    import types
    test_module = types.ModuleType('encodef8h', 'Custom Module Type')

    test_module.NAME = NAME
    test_module.encode = encode
    test_module.decode = decode

    # noinspection PyUnusedLocal
    import encodef8h
    encodef8h._get_codec_info = lambda a: None
    encodef8h.register()

# Generated at 2022-06-11 22:08:50.062694
# Unit test for function register
def test_register():
    codecs.__dict__['lookup_error']['eutf8h'] = None
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        return False
    return True


if __name__ == '__main__':
    register()

# Generated at 2022-06-11 22:08:50.815174
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:09:30.610542
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:09:35.394496
# Unit test for function register
def test_register():
    import unittest

    from .test_suite import test_cases

    class TestCase(test_cases.TestCase):
        def test_register(self):
            self.assertIsNone(self.locals.get('register'))

    register()
    test_case = TestCase()
    test_case.test_register()
    del register

# Generated at 2022-06-11 22:09:37.311101
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:09:47.040632
# Unit test for function register
def test_register():
    import re
    from pathlib import Path
    from typing import Pattern, Union

    from eutf8h import encode, decode


# Generated at 2022-06-11 22:09:49.065598
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:09:51.293582
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:09:55.354925
# Unit test for function register
def test_register():
    # Allow for the exception, which is expected if the codec is unable to
    # register.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    # Register the codec.
    register()
    # Confirm the codec was registered.
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:09:56.739454
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:10:00.424842
# Unit test for function register
def test_register():
    # Run the code once to make sure that it is registered.
    # If it fails the first time, then it will fail the second time.
    register()
    register()
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:10:08.914338
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    print('Registering codec')
    register()

    # print(codecs.lookup(NAME))

    print('\nTest encode')
    in_str = 'This is a test. \\u1f9c0'
    out_bytes, _ = encode(in_str)
    out_str = out_bytes.decode('utf-8')
    print(quote(in_str))
    print(out_str)

    print('\nTest decode')
    in_str = 'This is a test. \\u1f9c0'
    in_bytes = in_str.encode('utf-8')
    out_str, _ = decode(in_bytes)
    print(quote(in_str))
    print(out_str)

# Generated at 2022-06-11 22:11:36.152261
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
        codecs.getdecoder(NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:11:41.325394
# Unit test for function register
def test_register():
    codecs.getdecoder(NAME)
    assert codecs.lookup(NAME) == cast(codecs.CodecInfo, _get_codec_info(NAME))

# Generated at 2022-06-11 22:11:43.375491
# Unit test for function register
def test_register():
    register()
    if 'register' in sys.argv:
        print('eutf8h registered')


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:11:45.317570
# Unit test for function register
def test_register():
    register()
    assert codecs.register(_get_codec_info)


# Generated at 2022-06-11 22:11:49.814208
# Unit test for function register
def test_register():
    from io import BytesIO
    register()
    b = BytesIO()
    b.write(b'\\u0430\\u0431\\u0432')
    b.seek(0)
    b.read().decode(NAME)


# Run the register test if this file is run as the main file.
if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:11:52.836531
# Unit test for function register
def test_register():
    assert 'test' not in codecs.__dict__
    assert 'test' not in encoding
    register()
    assert NAME in codecs.__dict__
    assert NAME in encoding
    assert NAME in codecs.__dict__
    assert NAME in encoding

# Generated at 2022-06-11 22:12:02.384511
# Unit test for function register
def test_register():
    register()
    # pylint: disable=unused-variable
    try:
        import __main__
    except ImportError:
        # This code will fail if the test is not run in an IDE with
        # the current directory added to the system path.
        global NAME
        codec = __loader__.lookup(NAME).load()
    else:
        import sys
        current_dir = os.path.dirname(__file__)
        parent_dir = current_dir.rsplit(os.sep, 1)[0]
        sys.path.insert(0, parent_dir)
        import encoding_utf8_hex
        codec = encoding_utf8_hex
    finally:
        assert codecs.getdecoder(NAME) is not None
        assert codecs.getencoder(NAME) is not None


# Generated at 2022-06-11 22:12:06.782300
# Unit test for function register
def test_register():
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")

        # Trigger a warning that the codec had already been registered.
        register()

        assert len(w) == 1
        assert issubclass(w[-1].category, RuntimeWarning)
        assert 'already been registered' in str(w[-1].message)


# Generated at 2022-06-11 22:12:07.759838
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:12:11.191419
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    # Run unit tests.
    test_register()