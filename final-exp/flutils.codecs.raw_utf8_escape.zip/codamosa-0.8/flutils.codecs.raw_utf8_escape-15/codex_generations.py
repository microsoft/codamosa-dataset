

# Generated at 2022-06-11 22:04:40.813908
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        assert codecs.getdecoder(NAME)
        return
    raise AssertionError('Codec %s was already registered.' % NAME)

# Generated at 2022-06-11 22:04:51.174390
# Unit test for function register
def test_register():
    assert codecs.lookup(NAME)   # type: ignore
    assert codecs.lookup(NAME).name == NAME    # type: ignore
    test_string = 'Hello, world!'
    assert codecs.lookup(NAME).encode(test_string, errors='ignore') == (    # type: ignore
        b'Hello,\\x20world!',
        len(test_string)
    )
    assert codecs.lookup(NAME).decode(b'Hello,\\x20world!', errors='ignore') == (    # type: ignore
        'Hello, world!',
        14
    )


if __name__ == '__main__':
    test_register()
    print('Passed unit tests.')

# Generated at 2022-06-11 22:04:58.834243
# Unit test for function register
def test_register():
    # Remove the codec from the registered codecs
    codecs.lookup('eutf8h')

    # Register the module
    register()

    # Get the codec
    codec = codecs.lookup('eutf8h')

    assert codec is not None
    assert codec.name == NAME
    assert codec.encode('') == (b'', 0)
    assert codec.encode('Hello!').decode('utf-8') == (b'Hello!', 6)
    assert codec.encode('\u0161').decode('utf-8') == (b'\\u0161', 2)
    assert codec.encode('\u0161', 'replace').decode('utf-8') == (b'?', 1)

# Generated at 2022-06-11 22:04:59.451135
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:05:05.541916
# Unit test for function register
def test_register():
    def test_is_registered(name: str) -> bool:
        return codecs.lookup(name) is not None

    orig_registered = test_is_registered(NAME)
    register()
    assert test_is_registered(NAME)

    # Restore the original state
    if not orig_registered:
        codecs.lookup(NAME)._is_registered = False  # type: ignore
    else:
        register()



# Generated at 2022-06-11 22:05:15.484014
# Unit test for function register
def test_register():
    # type: () -> None
    import sys

    try:
        register()
    except LookupError:
        pass

    assert NAME in sys.modules
    assert 'eutf8h' in sys.modules
    assert sys.modules[NAME] == sys.modules['eutf8h']
    assert 'eutf8h.register' not in sys.modules
    assert 'eutf8h.encode' not in sys.modules
    assert 'eutf8h.decode' not in sys.modules
    assert 'eutf8h.test_encoder' not in sys.modules
    assert 'eutf8h.test_decoder' not in sys.modules
    assert 'eutf8h.test_register' not in sys.modules



# Generated at 2022-06-11 22:05:16.537468
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:05:26.737846
# Unit test for function register
def test_register():
    # Get the list of codecs that are currently registered
    codecs_registered = codecs.__dict__['getencodings']()

    # If the eutf8h codec is already registered, then unregister it.
    if NAME in codecs_registered:
        codecs.__dict__['__unregister_encoding'](NAME)

    # Register the eutf8h codec
    codecs.__dict__['register'](_get_codec_info)

    # Confirm that the eutf8h codec was successfully registered
    codecs_registered = codecs.__dict__['getencodings']()
    assert NAME in codecs_registered

    # Unregister the eutf8h codec
    codecs.__dict__['__unregister_encoding'](NAME)

    # Confirm that the eutf8h codec was successfully un

# Generated at 2022-06-11 22:05:28.659114
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)  # type: ignore
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:05:30.620741
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:05:33.898023
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME)

# Generated at 2022-06-11 22:05:41.132899
# Unit test for function register
def test_register():
    codecs_list = [
        codec for codec in codecs.__dict__.keys() if codec.endswith('encode')
    ]
    codecs_list.sort()
    if NAME not in codecs_list:
        register()
        codecs_list = [
            codec for codec in codecs.__dict__.keys() if codec.endswith('encode')
        ]
        codecs_list.sort()
        assert NAME in codecs_list

# Generated at 2022-06-11 22:05:43.993687
# Unit test for function register
def test_register():
    import sys

    register()
    #noinspection PyUnresolvedReferences
    assert NAME in sys.__dict__['modules']


# Generated at 2022-06-11 22:05:46.635347
# Unit test for function register
def test_register():
    import core.eutf8h
    core.eutf8h.register()
    decoder = codecs.getdecoder(NAME)
    assert decoder

# Generated at 2022-06-11 22:05:52.362310
# Unit test for function register
def test_register():

    codecs.register(_get_codec_info)   # type: ignore

    try:
        codecs.getencoder(NAME)
    except LookupError:
        raise AssertionError('Decoder not registered')

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError('Encoder not registered')



# Generated at 2022-06-11 22:05:53.975046
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-11 22:05:56.550444
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:06:07.941901
# Unit test for function register
def test_register():
    # noinspection PyGlobalUndefined
    global TEST_REGISTER_RAN
    # noinspection PyGlobalUndefined
    global TEST_ENCODE_RAN

    TEST_REGISTER_RAN = False
    TEST_ENCODE_RAN = False

    def test_get_codec_info(name: str) -> Optional[codecs.CodecInfo]:
        nonlocal TEST_REGISTER_RAN
        if name == NAME:
            TEST_REGISTER_RAN = True
            return codecs.CodecInfo(  # type: ignore
                name=NAME,
                encode=test_encode,  # type: ignore[arg-type]
                decode=test_decode,  # type: ignore[arg-type]
            )
        return None


# Generated at 2022-06-11 22:06:18.818135
# Unit test for function register
def test_register():
    register()
    verif = __import__('codecs').getdecoder(NAME)
    assert verif[0](b'\x00')[0] == '\\00'
    assert verif[0](b'\x00')[1] == 1
    assert verif[0](b'\x00')[0] == '\\00'
    assert verif[0](b'\x00')[1] == 1
    assert verif[0](b'\x00')[0] == '\\00'
    assert verif[0](b'\x00')[1] == 1
    assert 1

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:06:20.798755
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False



# Generated at 2022-06-11 22:06:28.570397
# Unit test for function register
def test_register():

    codecs.register(_get_codec_info)  # type: ignore  # noqa: F841
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:06:31.846202
# Unit test for function register
def test_register():
    """Unit test for function register"""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)
        assert True

# Generated at 2022-06-11 22:06:39.327520
# Unit test for function register
def test_register():
    from utf8h_codec import utf8h_codec_decode
    from utf8h_codec import utf8h_codec_encode
    register()  # type: ignore
    actual = codecs.getdecoder(NAME)  # type: ignore
    expected = utf8h_codec_decode
    assert actual == expected
    actual = codecs.getencoder(NAME)   # type: ignore
    expected = utf8h_codec_encode
    assert actual == expected

# Generated at 2022-06-11 22:06:40.493083
# Unit test for function register
def test_register():
    """
    Unit test for function register.
    """
    register()

# Generated at 2022-06-11 22:06:42.450010
# Unit test for function register
def test_register():
    register()
    decoder = codecs.getdecoder(NAME)
    assert decoder.__doc__ == decode.__doc__
    encoder = codecs.getencoder(NAME)
    assert encoder.__doc__ == encode.__doc__



# Generated at 2022-06-11 22:06:44.339627
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore



# Generated at 2022-06-11 22:06:48.100571
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-11 22:06:49.906723
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()

# Generated at 2022-06-11 22:06:50.888698
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)

# Generated at 2022-06-11 22:06:52.063801
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)

# Generated at 2022-06-11 22:07:00.856586
# Unit test for function register
def test_register():
    import utf8hex
    utf8hex.register()

# Generated at 2022-06-11 22:07:09.440889
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    register()
    print(NAME)
    tests = [
        'A',
        '\r',
        '\n',
        '\r\n',
        '\\n',
        '\\r',
        '\\r\\n',
        '\\x0D',
        '\\x0A',
        '\\x0D\\x0A',
        '\\u0041',
        '\\u203F',
        '\\u2616',
        '\\x41',
        '\u2616',
    ]

    for i, test in enumerate(tests):
        text = '%s' % test

# Generated at 2022-06-11 22:07:14.625391
# Unit test for function register
def test_register():

    # noinspection PyUnusedLocal
    def test(
            data: _ByteString,
            error: _Str
    ) -> Tuple[str, int]:
        return decode(data, error)

    register()
    text = '\xF0\x9F\x8F\x86'
    codecs.register_error(NAME, test)
    t = codecs.decode(text.encode(NAME), NAME, NAME)
    assert t == '😆'


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:07:20.653119
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(
            '%s codec is already registered' % NAME
        )
    register()
    codecs.getdecoder(NAME)
    print('%s codec is successfully registered' % NAME)



# Generated at 2022-06-11 22:07:23.441895
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getdecoder(NAME)


# Generated at 2022-06-11 22:07:29.724928
# Unit test for function register
def test_register():
    from .test_util import temp_encoding

    register()
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None

    # Assert that any error when trying to register a second time is
    # caught and not thrown into the calling code.
    register()

    # Assert that the encoding can be used within a context manager.
    with temp_encoding(NAME):
        pass

# Generated at 2022-06-11 22:07:31.449284
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:07:35.635734
# Unit test for function register
def test_register():
    register()
    text = 'abc\\xE2\\x83\\xA3'
    text_bytes = codecs.encode(text, NAME)
    text_out = codecs.decode(text_bytes, NAME)
    assert text == text_out


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:07:38.189810
# Unit test for function register
def test_register():
    # Unable to test because of the following:
    #   Module 'codecs' has no 'register' member
    pass



# Generated at 2022-06-11 22:07:40.235213
# Unit test for function register
def test_register():
    register()
    assert NAME == codecs.getdecoder(NAME).name  # type:ignore


# Generated at 2022-06-11 22:07:48.821411
# Unit test for function register
def test_register():
    def _test():
        register()
        tr

# Generated at 2022-06-11 22:07:52.634385
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    import doctest
    argv = sys.argv
    sys.argv = argv[:1]
    doctest.testmod()
    sys.argv = argv

# Generated at 2022-06-11 22:07:56.214776
# Unit test for function register
def test_register():
    try:
        codecs.getencoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore

# Generated at 2022-06-11 22:07:58.177323
# Unit test for function register
def test_register():
    register()

    cls = codecs.getdecoder(NAME)[0]
    assert cls == decode
    cls = codecs.getencoder(NAME)[0]
    assert cls == encode

# Generated at 2022-06-11 22:07:59.227128
# Unit test for function register
def test_register():
    pass # TODO



# Generated at 2022-06-11 22:08:08.975079
# Unit test for function register
def test_register():
    def test_register_impl():
        register()

        def _get_codec_info_test() -> None:
            codecs.getencoder(NAME)
            codecs.getdecoder(NAME)
            codecs.getincrementalencoder(NAME)
            codecs.getincrementaldecoder(NAME)
            codecs.getreader(NAME)
            codecs.getwriter(NAME)

        # Check that all the codecs functions return a proper
        # object.
        try:
            _get_codec_info_test()
        except LookupError:
            # If the codec is already registered then the
            # _get_codec_info function will return None.
            # Catch this here and unregister the codecs.
            codecs.unregister(_get_codec_info)
            _get_codec

# Generated at 2022-06-11 22:08:11.158392
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)  # type: ignore
    assert codecs.getencoder(NAME)  # type: ignore

# Generated at 2022-06-11 22:08:13.049386
# Unit test for function register
def test_register():
    import codecs
    register()
    codecs.getencoder(NAME)

# Generated at 2022-06-11 22:08:15.735231
# Unit test for function register
def test_register():
    register()
    assert NAME == codecs.getdecoder(NAME).name



# Generated at 2022-06-11 22:08:26.224397
# Unit test for function register
def test_register():
    register()
    codec = codecs.getdecoder(NAME)
    assert codec.name == NAME
    assert codec.encode(NAME, 'strict')[0].decode() == '\\\\x' + hex(ord(NAME[0]))[2:].upper()
    assert codec.decode('\\\\x' + hex(ord(NAME[0]))[2:].upper())[0] == NAME


if __name__ == '__main__':
    register()
    print(NAME)

    try:
        print(codecs.getdecoder('name'))
    except LookupError:
        print('not registered')

    try:
        print(codecs.getdecoder(NAME))
    except LookupError:
        print('not registered')

    register()


# Generated at 2022-06-11 22:08:45.458971
# Unit test for function register
def test_register():
    # If a TypeError is raised here, then this unit test has failed.
    codecs.register(_get_codec_info)  # type: ignore



# Generated at 2022-06-11 22:08:51.128101
# Unit test for function register
def test_register():
    # Unregister if already registered
    try:
        codecs.lookup(NAME)
    except LookupError:
        pass
    else:
        codecs.unregister(NAME)
    register()
    assert NAME == codecs.lookup(NAME).name  # type: ignore[attr-defined]
    codecs.unregister(NAME)



# Generated at 2022-06-11 22:09:02.136367
# Unit test for function register
def test_register():
    import sys
    import pprint
    module = sys.modules[__name__]
    dir_list = dir(module)
    # print(dir_list)
    dir_list.sort()
    print('\nTest for function register')
    print('Search for function codecs.register')
    for name in dir_list:
        obj = getattr(module, name)
        if obj.__class__.__name__ != 'function':
            continue
        client = getattr(obj, 'client', None)
        if client is not None and client.__name__ == 'codecs':
            print('Accessing function:', obj.__name__)
        dir_list = dir(obj)
        dir_list = sorted(dir_list)

# Generated at 2022-06-11 22:09:11.979717
# Unit test for function register
def test_register():
    # Test for:
    #   - codecs.register(get_codec_info) by getdecoder
    #       if NAME is not found in codecs.
    #   - The use of codecs.getencoder(NAME) and
    #       codecs.getdecoder(NAME) after codecs.register(get_codec_info)
    #       if NAME is not found in codecs.

    # If NAME is not found in codecs, then the following function will
    # raise a LookupError
    try:
        codecs.getdecoder(NAME)
        assert ValueError(
            "Expected the name {NAME} to not exist in the codecs."
        )
    except LookupError as e:
        pass

    # If NAME is not found in codecs, then the following function will
    # raise a Lookup

# Generated at 2022-06-11 22:09:14.441638
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False


# Generated at 2022-06-11 22:09:16.044235
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:09:17.886217
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-11 22:09:28.824104
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME)
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-11 22:09:31.408474
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore


# Generated at 2022-06-11 22:09:37.097539
# Unit test for function register
def test_register():
    register()
    b = codecs.encode('a', NAME)
    assert b == b'\\61'
    assert codecs.decode(b, NAME) == 'a'


if __name__ == '__main__':
    import sys
    test_register()
    if len(sys.argv) > 1:
        print(f'{sys.argv[1]} -> {codecs.encode(sys.argv[1], NAME)}')
    else:
        print(f'No input')

# Generated at 2022-06-11 22:10:11.327632
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getencoder(NAME)
    except LookupError:
        assert False
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False



# Generated at 2022-06-11 22:10:15.474436
# Unit test for function register
def test_register():
    # Load the codec if it is not loaded.
    register()

    # Decode some bytes of escaped utf8 hexadecimal into a string.
    decode('\\xe2\\x90\\xb0')

# Generated at 2022-06-11 22:10:17.763174
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

# Generated at 2022-06-11 22:10:19.587062
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)  # type: ignore # pylint: disable=no-member


# Generated at 2022-06-11 22:10:24.352061
# Unit test for function register
def test_register():
    from encodings import utf_8_var_width
    codecs_map = utf_8_var_width.getregentry()

    try:
        codecs_map.pop('eutf8h')
    except KeyError:
        pass

    register()

    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise RuntimeError(f"Codec lookup failed: {e}")

    assert NAME in codecs_map


# Call the registration function when run
register()

# Generated at 2022-06-11 22:10:31.215921
# Unit test for function register
def test_register():
    # pylint: disable=unused-variable
    from importlib import reload  # nosec

    from unit_tests.unit_test_lib import assert_

    # pylint: enable=unused-variable

    register()

    reload(codecs)   # nosec

    # Tests
    assert_(codecs.getencoder)
    assert_(codecs.getdecoder)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-11 22:10:32.041474
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:10:36.601073
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    assert codecs.lookup(NAME)
    codecs.register(_get_codec_info)
    assert codecs.lookup(NAME)

# Unit tests for function encode

# Generated at 2022-06-11 22:10:38.889928
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)



# Generated at 2022-06-11 22:10:42.358062
# Unit test for function register
def test_register():
    from unittest import TestCase

    class Test(TestCase):
        def test_1(self):
            register()
            codecs.getdecoder(NAME)

    test = Test()
    test.test_1()

# Unit tests for function encode

# Generated at 2022-06-11 22:11:58.131993
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-11 22:12:00.742972
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        assert False, f'register failed with exception {e}'


if __name__ == '__main__':
    register()

# Generated at 2022-06-11 22:12:06.546880
# Unit test for function register
def test_register():
    import traceback
    # First, unregister the codec, if registered.
    codecs.lookup(NAME)
    try:
        codecs.lookup(NAME)
    except LookupError:
        # There was no registered codec.
        pass
    else:
        # There was already a registered codec.
        codecs.lookup_error(NAME)

    # Now, register the codec.
    register()

    # Verify that the codec was registered correctly.
    codecs.lookup(NAME)

# Generated at 2022-06-11 22:12:07.541607
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None

# Generated at 2022-06-11 22:12:14.896145
# Unit test for function register
def test_register():
    import sys
    import types

    m = types.ModuleType('codecs')
    m.getdecoder = getattr(sys.modules['codecs'], 'getdecoder')
    m.register = lambda x: None

    sys.modules['codecs'] = m

    try:
        register()
    except LookupError:
        raise

# Generated at 2022-06-11 22:12:17.091876
# Unit test for function register
def test_register():
    register()
    test_codec = codecs.getdecoder(NAME)
    assert test_codec is not None
    assert test_codec.__name__ == NAME



# Generated at 2022-06-11 22:12:27.234297
# Unit test for function register
def test_register():
    import sys
    import importlib

    try:
        importlib.reload(sys.modules['encodings'])
    except KeyError:
        import encodings
        sys.modules['encodings'] = encodings

    register()

    try:
        import encodings.eutf8h
    except ImportError:
        codecs.register(_get_codec_info)

    from encodings import eutf8h

    inf = codecs.lookup(NAME)

    assert eutf8h.NAME == NAME
    assert eutf8h._get_codec_info == inf
    assert eutf8h._get_codec_info(NAME) is inf
    assert eutf8h.encode == encode
    assert eutf8h.decode == decode



# Generated at 2022-06-11 22:12:28.678122
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-11 22:12:29.628947
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-11 22:12:30.302940
# Unit test for function register
def test_register():
    register()
