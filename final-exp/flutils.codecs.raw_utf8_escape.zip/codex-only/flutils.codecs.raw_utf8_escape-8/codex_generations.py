

# Generated at 2022-06-23 17:55:52.422410
# Unit test for function decode
def test_decode():
    assert decode(b'\\xC2\\x80') == (u'\U00000080', 5)
    assert decode(b'\\xc3\\x82\\xc3\\x80') == (u'\U000000c2\U00000080', 9)
    assert decode(b'some_text') == ('some_text', 9)
    assert decode(b'') == ('', 0)
    assert decode(b'some\\xC2text') == (u'some�text', 11)
    assert decode(b'\\xDF\\xBF') == (u'\U0000dfff', 5)


# Generated at 2022-06-23 17:56:01.849680
# Unit test for function encode
def test_encode():
    assert encode('\\x20') == (b'\\x20', 2)
    assert encode('\\x20\\x66') == (b'\\x20\\x66', 4)
    assert encode('\\x01\\x11') == (b'\\x01\\x11', 4)
    assert encode('\\xaa\\x80\\xbb') == (b'\\xaa\\x80\\xbb', 6)
    assert encode('\\xaa\\x80\\xbb\\x08') == (b'\\xaa\\x80\\xbb\\x08', 8)
    assert encode('\\x01\\xaa\\x80\\xbb\\x08') == (b'\\x01\\xaa\\x80\\xbb\\x08', 10)

# Generated at 2022-06-23 17:56:11.585647
# Unit test for function decode
def test_decode():
    # decode()
    decoded, num_bytes = decode(b'\\44\\65\\66\\61\\75\\6c\\74\\6d\\65')
    assert decoded == 'Defaultme'
    assert num_bytes == 10

    decoded, num_bytes = decode(b'I am typing \\74\\69\\70\\69\\6e\\67 at 12:00 AM')
    assert decoded == 'I am typing typing at 12:00 AM'
    assert num_bytes == 31

    decoded, num_bytes = decode(b'\\41\\62\\63\\64\\65\\66\\67\\68\\69\\6a\\6b\\6c\\6d\\6e\\6f\\70\\71\\72\\73'
                                b'\\74\\75\\76\\77\\78\\79\\7a')
    assert dec

# Generated at 2022-06-23 17:56:21.587711
# Unit test for function register
def test_register():
    register()
    ret_value = codecs.getdecoder(NAME)
    assert ret_value is not None
    assert isinstance(ret_value, tuple)
    assert len(ret_value) == 2
    decoder_func = ret_value[0]
    assert callable(decoder_func)
    # noinspection PyTypeChecker
    decoder_func.__code__            # type: ignore
    assert isinstance(decoder_func.__code__, type(code))  # type: ignore
    assert decoder_func.__name__ == 'decode'
    assert decoder_func.__module__ == __name__
    encoder_func = ret_value[1]
    assert callable(encoder_func)
    # noinspection PyTypeChecker
    encoder_func.__code__           

# Generated at 2022-06-23 17:56:25.344603
# Unit test for function encode
def test_encode():
    # Test input string
    text = '1234abc'
    escaped_text = encode(text)
    assert escaped_text == b'1234abc', 'encode() test failed: invalid bytes output'


# Generated at 2022-06-23 17:56:31.206052
# Unit test for function decode
def test_decode():
    if __name__ == '__main__':
        import sys

        if len(sys.argv) > 1:
            decode_dispose(sys.argv[1])
        else:
            import nose
            nose.runmodule()
            # nose.run(argv=['nose', '-v', '--with-doctest'])



# Generated at 2022-06-23 17:56:42.233328
# Unit test for function decode
def test_decode():
    # Text of an utf-8 character, that corresponds to the 3 byte
    # utf-8 sequence of 0xE2, 0x82, 0xAC.
    test_text = '€'

    # The utf-8 character, escaped utf8 hexadecimal encoding.
    test_bytes_e = b'\\xe2\\x82\\xac'

    # Convert the test_text into utf8 bytes.
    test_bytes = test_text.encode('utf8')

    # Decode the test_bytes_e into a string.
    test_text_decoded, nbytes = decode(test_bytes_e)

    # result should be the same as test_text.
    assert(test_text == test_text_decoded)



# Generated at 2022-06-23 17:56:49.761091
# Unit test for function decode
def test_decode():
    for i, o in (
        (
            r'\x61',
            'a',
        ),
        (
            r'\xC3\xB1',
            'ñ',
        ),
        (
            r'\xC3\xB1\x20\xC3\xB1',
            'ñ ñ',
        ),
        (
            r'\x61\x62\x63\x64\x65\x66',
            'abcdef',
        ),
        (
            r'\xC3\xB1\x20\xC3\xB1\x20\xC3\xB1',
            'ñ ñ ñ',
        ),
    ):
        assert decode(i.encode('utf8')) == (o, len(i))



# Generated at 2022-06-23 17:56:51.375041
# Unit test for function register
def test_register():
    register()
    codecs.decode('', NAME)
    codecs.encode('', NAME)



# Generated at 2022-06-23 17:56:55.106619
# Unit test for function decode
def test_decode():
    input = b'\\x48\\x65\\x6C\\x6C\\x6F\\x20\\x57\\x6F\\x72\\x6C\\x64'
    expected = ('Hello World', len(input))
    assert decode(input) == expected



# Generated at 2022-06-23 17:57:02.743052
# Unit test for function encode

# Generated at 2022-06-23 17:57:10.518743
# Unit test for function register
def test_register():
    # noinspection PyUnresolvedReferences
    import codecs
    codecs.lookup_error = 'strict'
    register()
    buf = codecs.decode(r'\x41', 'eutf8h')
    assert buf == 'A'
    buf = codecs.encode('A', 'eutf8h')
    assert buf == r'\x41'

if __name__ == '__main__':
    # Unit testing
    test_register()

# Generated at 2022-06-23 17:57:19.942356
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode('123') == (b'1', 1)
    assert encode('\u00e9') == (b'\\xc3\\xa9', 1)
    assert encode('\\xc3\\xa9') == (b'\\xc3\\xa9', 2)
    assert encode('\\xc\\xc') == (b'\\xc3\\xa9', 1)
    assert encode('\\xc\\xc\\xc') == (b'\\xc3\\xa9', 2)
    assert encode('\\xc\\xc\\xc\\xc') == (b'\\xc3\\xa9', 3)
    assert encode('\\xc\\xc\\xc\\xc\\xc') == (b'\\xc3\\xa9', 4)
    assert encode('\\xc\\xc\\xc\\xc\\xc\\xc')

# Generated at 2022-06-23 17:57:22.637285
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-23 17:57:30.604653
# Unit test for function encode
def test_encode():
    """
    This applies utf-8 codepoints to the encode function,
    and checks whether the utf-8 byte sequence is converted
    to escaped utf-8 hexadecimal in the correct format
    :return:
    """
    assert encode('€') == b'\\xe2\\x82\\xac'
    assert encode('€1') == b'\\xe2\\x82\\xac1'
    assert encode('\n') == b'\\x0a'
    assert encode('\r') == b'\\x0d'
    assert encode('\r\n') == b'\\x0d\\x0a'



# Generated at 2022-06-23 17:57:31.230849
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-23 17:57:32.223831
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-23 17:57:41.936745
# Unit test for function encode
def test_encode():
    input_text: str = 'Hello, world!\n'
    output_bytes: bytes = b'Hello, world!\\n'
    out: Tuple[bytes, int] = encode(input_text)
    assert len(out) == 2
    assert out[1] == len(input_text)  # the number of characters consumed.
    assert out[0] == output_bytes
    input_text = 'Hello, world!\\n'
    output_bytes = b'Hello, world!\\n'
    out = encode(input_text)
    assert len(out) == 2
    assert out[1] == len(input_text)  # the number of characters consumed.
    assert out[0] == output_bytes
    input_text = 'H'
    output_bytes = b'H'

# Generated at 2022-06-23 17:57:43.462803
# Unit test for function register
def test_register():
    register()
    register()
    codecs.getdecoder(NAME)  # no error expected



# Generated at 2022-06-23 17:57:53.320754
# Unit test for function encode
def test_encode():
    """
    >>> test_encode()
    Original: \\xF0\\x9F\\xA6\\x84
    Escaped : \\x5c\\x78\\x46\\x30\\x5c\\x78\\x39\\x46\\x5c\\x78\\x41\\x36\\x5c\\x38\\x34
    """
    original = '\\xF0\\x9F\\xA6\\x84'
    escaped, length = encode(original)
    print('Original:', original)
    print('Escaped :', escaped.decode('ascii'))



# Generated at 2022-06-23 17:57:56.974388
# Unit test for function encode
def test_encode():
    result = encode('aaa\u0123')
    try:
        assert result == (b'aaa\\u0123', len('aaa\u0123'))
    except AssertionError:
        print('test_encode: FAILED')
    else:
        print('test_encode: PASSED')


# Generated at 2022-06-23 17:57:58.722032
# Unit test for function register
def test_register():
    register()
    _ = codecs.getdecoder(NAME)



# Generated at 2022-06-23 17:58:09.847378
# Unit test for function decode
def test_decode():
    assert decode(b'Hello')[0] == 'Hello'
    assert decode(b'Hello\\xa2World')[0] == 'Hello\xa2World'
    assert decode(b'Hello\\xa2World')[0] == 'Hello\xa2World'
    assert decode(b'Hello\\xa2World')[0] == 'Hello\xa2World'
    assert decode(b'\\xc3\\xbe')[0] == 'þ'
    assert decode(b'\\xc3\\xbe\\xc3\\xbe')[0] == 'þþ'
    assert decode(b'\\xc3\\xbe\\xc3\\xbe\\xc3\\xbe\\xc3\\xbe')[0] == 'þþþþ'

# Generated at 2022-06-23 17:58:20.146352
# Unit test for function decode
def test_decode():
    text_input = str('\\x61')
    text_bytes_utf8 = text_input.encode('utf-8')
    text_bytes_utf8 = cast(bytes, text_bytes_utf8)
    text_str_latin1 = text_bytes_utf8.decode('unicode_escape')
    text_bytes_utf8 = text_str_latin1.encode('latin1')
    text_str = text_bytes_utf8.decode('utf-8')
    out_bytes, out_int = decode(text_input)
    assert out_bytes == text_str
    assert out_int == 2


# Generated at 2022-06-23 17:58:31.035210
# Unit test for function encode
def test_encode():
    assert encode('hello world') == (
        b'hello\\x20world',
        11
    )
    assert encode('test of utf8 \U0001f607') == (
        b'test\\x20of\\x20utf8\\x20\\xf0\\x9f\\x98\\x87',
        20
    )
    assert encode(' ') == (
        b'\\x20',
        1
    )
    assert encode('\n') == (
        b'\\xa',
        1
    )
    assert encode('\t') == (
        b'\\x9',
        1
    )
    assert encode('\r') == (
        b'\\xd',
        1
    )

# Generated at 2022-06-23 17:58:34.959331
# Unit test for function encode
def test_encode():
    text_input = 'My name is R\u00f3binson Crusoe'
    errors_input = 'strict'
    expected = (
        b'My name is R\\xf3binson Crusoe',
        len(text_input)
    )
    assert encode(text_input, errors_input) == expected


# Generated at 2022-06-23 17:58:42.404695
# Unit test for function register
def test_register():
    register()
    if codecs.lookup(NAME):
        print(NAME, 'lookup successful')
        print(
            'Name:', NAME, 'Encode:', encode('\N{GREEK CAPITAL LETTER OMEGA}')
        )
    else:
        print(NAME, 'lookup failed')


if __name__ == "__main__":
    print(
        encode(
            '\N{GREEK CAPITAL LETTER OMEGA} \N{GREEK CAPITAL LETTER OMEGA}'
        )
    )
    test_register()

# Generated at 2022-06-23 17:58:50.529694
# Unit test for function decode

# Generated at 2022-06-23 17:58:58.482472
# Unit test for function decode
def test_decode():
    assert decode(b'\\x24', 'strict') == ('$', 5)
    assert decode(b'\\x24', 'replace') == ('$', 5)
    assert decode(b'\\x24', 'ignore') == ('', 5)

    # Introducing invalid utf8 bytes results in a decode error
    try:
        decode(b'\\x00', 'strict')
    except UnicodeDecodeError as e:
        assert e.start == 1
        assert e.end == 2



# Generated at 2022-06-23 17:58:59.886755
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME).name == NAME



# Generated at 2022-06-23 17:59:02.179356
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.encode('', NAME)[0].decode(NAME)
    assert codecs.decode(b'', NAME) == ('', 0)

# Generated at 2022-06-23 17:59:12.456207
# Unit test for function decode
def test_decode():
    assert decode(b"\\x65\\x66\\x67") == ('efg', 9)
    assert decode(b"\\x61\\x62\\x63\\x64\\x65\\x66\\x67") == ('abcdefg', 21)
    assert decode(b"\\x66\\x6f\\x6f\\x6e") == ('noon', 12)

    # Unit test for function decode
    assert decode(b"\\x66\\x6f\\x6f\\x6f") == ('fooo', 12)
    assert decode(b"\\x61\\x6d\\x75\\x73\\x65\\x20\\x6f\\x66\\x20\\x73\\x66") == (
        'amuse of sf', 33)

# Generated at 2022-06-23 17:59:17.338079
# Unit test for function register
def test_register():
    # noinspection PyUnresolvedReferences
    from . import codec_info
    import sys

    try:
        register()

        # Assert that the codec is in the collection of codecs in
        # the codecs module.
        assert codec_info.NAME in sys.modules['codecs'].__all__

    finally:
        codecs.unregister(_get_codec_info)



# Generated at 2022-06-23 17:59:20.613112
# Unit test for function encode
def test_encode():
    assert b'\\x48\\x65\\x6c\\x6c\\x6f\\x20\\x57\\x6f\\x72\\x6c\\x64' == encode(
        'Hello World')



# Generated at 2022-06-23 17:59:22.583549
# Unit test for function register
def test_register():
    assert not codecs.getdecoder(NAME)
    register()
    assert codecs.getdecoder(NAME)


# Generated at 2022-06-23 17:59:33.497822
# Unit test for function decode
def test_decode():
    for given_data_input in (
            b'\\x50\\x72\\x69\\x6e\\x74\\xA9\\x74\\x68\\x69\\x73',
            bytearray(b'\\x50\\x72\\x69\\x6e\\x74\\xA9\\x74\\x68\\x69\\x73'),
            memoryview(b'\\x50\\x72\\x69\\x6e\\x74\\xA9\\x74\\x68\\x69\\x73')
    ):
        given_data_output, num_given_data_bytes = decode(given_data_input)

        assert isinstance(given_data_output, str)
        assert num_given_data_bytes == len(given_data_input)


# Generated at 2022-06-23 17:59:43.672173
# Unit test for function decode
def test_decode():
    print('expecting: ä')
    print('received :', decode(b'\\xc3\\xa4')[0])
    print('expecting: \\xc3\\xa4')
    print('received :', decode(b'\\\\xc3\\\\xa4')[0])
    print('expecting: \\xc3\\xa4')
    print('received :', decode(b'\\\\xc3\\\\xa4')[0])
    print('expecting: ä  🌘  🌗')
    print('received :', decode(b'\\xc3\\xa4  \\xf0\\x9f\\x8c\\x98  \\xf0\\x9f\\x8c\\x97')[0])



# Generated at 2022-06-23 17:59:46.625578
# Unit test for function encode
def test_encode():
    assert encode('abc') == (b'abc', 3)
    assert encode('abc\\x41') == (b'abcB', 6)
    return


# Generated at 2022-06-23 17:59:56.353829
# Unit test for function decode
def test_decode():
    # normal cases
    assert decode(b'abc') == (
        'abc', 3
    )
    assert decode(b'ab\\x63') == (
        'abc', 5
    )

    assert decode(b'\\xE3\\x81\\x82') == (
        'あ', 9
    )

    assert decode(b'\\xE3\\x81\\x82\\xE3\\x81\\x84') == (
        'あい', 18
    )

    assert decode(b'\\xE3\\x81\\x82\\xE3\\x81\\x84\\xE3\\x81\\x86') == (
        'あいう', 27
    )


# Generated at 2022-06-23 18:00:07.159910
# Unit test for function encode
def test_encode():
    assert encode('a') == (b'a', 1)
    assert encode('a\u0600') == (b'a\\xd8\\x00', 2)
    assert encode('a\u0600b') == (b'a\\xd8\\x00b', 3)
    assert encode('\U00010000') == (b'\\xf0\\x90\\x80\\x80', 4)
    assert encode('\u0600') == (b'\\xd8\\x00', 2)
    assert encode('\xd8\x00') == (b'\\xd8\\x00', 2)
    assert encode('\u0600', 'surrogateescape') == (b'\\xd8\\x00', 2)

# Generated at 2022-06-23 18:00:16.389656
# Unit test for function encode
def test_encode():
    # Test basic functionality with single escaped hexadecimal
    assert encode(r'a\x6bc') == (b'a\\x6bc', 4)
    assert encode(r'a\xfbc') == (b'a\\xfbc', 4)
    assert encode(r'a\x6bc', 'ignore') == (b'abc', 4)
    assert encode(r'a\x6bc', 'replace') == (b'ab?c', 4)

    # Test that escaping hexadecimal references to non-printable ascii
    # characters, like LF (\n) or SOH (\x01), works properly.
    assert encode(r'a\x01b') == (b'a\\x01b', 4)

# Generated at 2022-06-23 18:00:17.261798
# Unit test for function register
def test_register():
    return

# Generated at 2022-06-23 18:00:25.383003
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    assert NAME == codecs.getdecoder(NAME).name
    encode_func = codecs.getencoder(NAME)
    assert NAME == encode_func.name
    decode_func = codecs.getdecoder(NAME)
    assert NAME == decode_func.name
    orig_text_bytes = codecs.encode('\u00ff\u00aa', 'utf-8')
    text_bytes_utf8 = encode_func(orig_text_bytes)[0]
    assert 1 == text_bytes_utf8.count(b'\\x')
    assert 1 == text_bytes_utf8.count(b'\\xff')
    assert 1 == text_bytes_utf8.count(b'\\xaa')
    unescape_text_bytes_utf8 = text_

# Generated at 2022-06-23 18:00:32.908469
# Unit test for function encode
def test_encode():
    s = '\\xC3\\x81\\xC3\\x82\\xC3\\x81\\xC3\\x82\\xE2\\x80\\x9C\\xC3'
    s += '\\x81\\xC3\\x82\\xE2\\x80\\x9C\\xE2\\x80\\x9D\\xC3\\x81\\xC3'
    s += '\\x82\\xE2\\x80\\x9D\\xC3\\x81\\xC3\\x82'
    s += '\\xE2\\x80\\x98\\xC3\\x81\\xC3\\x82\\xC3\\x81\\xC3\\x82'

# Generated at 2022-06-23 18:00:38.922218
# Unit test for function decode
def test_decode():
    data = _Str('\\xce\\xb1\\xce\\xb2\\xce\\xb3')
    result = decode(data, 'strict')
    assert result == ('αβγ', len(data))

    data = _Str('\\xce\\xb1x')
    result = decode(data, 'strict')
    assert result == ('αx', len(data))

    data = _Str('\\xce\\xb1\\xce\\xb2\\xce\\xb3\\xce')
    result = decode(data, 'strict')
    assert result == ('αβγ', len(data))

    data = _Str('\\xce\\xb1\\xce\\xb2\\xce\\xb3\\xce\\xb4\\xce\\xb5\\xce\\')
    result = decode(data, 'ignore')

# Generated at 2022-06-23 18:00:49.157226
# Unit test for function encode
def test_encode():
    data: str = 'foo\tbar\nbaz\n'
    out, length = encode(data)
    assert out == b'foo\\x09bar\\x0abaz\\x0a'
    out, length = encode('f\x00o\x00o\x00')
    assert out == b'f\\x00o\\x00o\\x00'
    out, length = encode('f\xffo\xffo\xff')
    assert out == b'f\\xFFo\\xFFo\\xFF'
    out, length = encode('foo')
    assert out == b'foo'
    out, length = encode('f\xffoo')
    assert out == b'f\\xFFoo'
    out, length = encode('\U0001f4a9')

# Generated at 2022-06-23 18:01:01.310680
# Unit test for function encode

# Generated at 2022-06-23 18:01:12.507066
# Unit test for function encode
def test_encode():
    assert encode(r'\xe2\x82\xac', 'strict') == (b'\\\\xE2\\\\x82\\\\xAC', 15)
    assert encode('\\xe2\\x82\\xac', 'strict') == (b'\\\\xE2\\\\x82\\\\xAC', 15)
    assert encode('\\xE2\\x82\\xAC', 'strict') == (b'\\\\xE2\\\\x82\\\\xAC', 15)
    assert encode(r'\xE2\x82\xAC', 'strict') == (b'\\\\xE2\\\\x82\\\\xAC', 15)

    assert encode(r'\u20ac', 'strict') == (b'\\\\xE2\\\\x82\\\\xAC', 15)
    assert encode(r'\U00000020ac', 'strict')

# Generated at 2022-06-23 18:01:14.585223
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-23 18:01:23.864411
# Unit test for function encode
def test_encode():
    # One byte characters.
    assert encode('A') == (b'A', 1)
    assert encode('a') == (b'a', 1)
    assert encode('0') == (b'0', 1)
    assert encode('\n') == (b'\n', 1)
    assert encode('\r') == (b'\r', 1)

    # Two byte characters.
    assert encode('€') == (b'C2\\x80', 1)
    assert encode('£') == (b'C2\\xa3', 1)
    assert encode('中') == (b'E4\\xb8\\xad', 1)
    assert encode('\u200b') == (b'E2\\x80\\x8b', 1)

    # Three byte characters.

# Generated at 2022-06-23 18:01:25.436970
# Unit test for function register
def test_register():
    register()
    _ = codecs.getdecoder(NAME)


# Generated at 2022-06-23 18:01:29.202346
# Unit test for function register
def test_register():
    register()
    obj = codecs.getdecoder(NAME)  # type: ignore
    assert isinstance(obj, codecs.CodecInfo)
    assert obj.encode == encode
    assert obj.decode == decode

# Generated at 2022-06-23 18:01:36.706743
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getencoder(NAME)
    except LookupError:
        print("FAIL: codec with name '%s' not found by codecs.getencoder" % NAME)
        return
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        print("FAIL: codec with name '%s' not found by codecs.getdecoder" % NAME)
        return
    print("PASS: codec registered with name '%s'" % NAME)


# Generated at 2022-06-23 18:01:37.338371
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-23 18:01:46.271153
# Unit test for function encode
def test_encode():
    """Test cases for encode"""
    def t(text: str, errors: str, expected: bytes) -> None:
        actual = encode(text, errors)
        assert actual[0] == expected, (text, errors, expected, actual)

    t('$', 'strict', b'\\x24')
    t('\\', 'strict', b'\\x5c')
    t('\\x24', 'strict', b'\\x24')
    t('\\x5c', 'strict', b'\\50c')
    t('\\x0000024', 'strict', b'\\24')
    t('\\x000005c', 'strict', b'\\5c')
    t('\\x000005c', 'ignore', b'\\5c')

# Generated at 2022-06-23 18:01:54.018300
# Unit test for function encode
def test_encode():
    # Convert the string of latin-1 characters (which are actually
    # utf8 characters) into bytes.
    test_str = '\xe7\x8a\xac\xe7\xab\x8b\xe8\x8a\x9d'
    test_bytes = test_str.encode('latin1')
    test_str2 = bytes(b'\\xe7\\x8a\\xac\\xe7\\xab\\x8b\\xe8\\x8a\\x9d').decode('unicode_escape')
    test_bytes2 = test_str2.encode('latin1')
    assert test_bytes == test_bytes2

# Generated at 2022-06-23 18:02:02.896051
# Unit test for function encode
def test_encode():
    # Test with the plain printable ASCII chars.
    # The result should be the same.
    test_str = '0123456789' \
               'abcdefghijklmnopqrstuvwxyz' \
               'ABCDEFGHIJKLMNOPQRSTUVWXYZ' \
               '!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~'
    test_bytes = b'0123456789' \
                 b'abcdefghijklmnopqrstuvwxyz' \
                 b'ABCDEFGHIJKLMNOPQRSTUVWXYZ' \
                 b'!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~'

# Generated at 2022-06-23 18:02:06.102111
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)  # type: ignore
    decode('\\xe3')



# Generated at 2022-06-23 18:02:15.733111
# Unit test for function encode
def test_encode():
    # Test hexadecimals conversion
    assert encode('\\x6e\\x6f\n') == (b'\\x6e\\x6e\\x6f', 6)

    # Test hexadecimal conversion with number
    assert encode('\\x6e\\x6f\\x6e\\x6f\\x6e\\x6f\n') == (
        b'\\x6e\\x6e\\x6f\\x6e\\x6e\\x6f\\x6e\\x6e\\x6f',
        9
    )

    # Test hexadecimal conversion with number
    # HACK: I know the last '\\x6f' should be '\\x6e', but it doesn't
    #       work for literal strings for some reason.

# Generated at 2022-06-23 18:02:18.172294
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    assert(NAME in codecs.getdecoder(NAME))


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 18:02:21.032178
# Unit test for function register
def test_register():
    import sys
    import contextlib
    with contextlib.redirect_stdout(sys.stderr):
       codecs.register(_get_codec_info)



# Generated at 2022-06-23 18:02:30.759259
# Unit test for function encode
def test_encode():
    s = "abC"
    assert encode(s) == (b"abC",3)
    s = "a\u0301bc"
    assert encode(s) == (b"a\\xC3\\x81bc",2)
    s = r"a\x81bc"
    assert encode(s) == (b"a\\xC3\\x81bc",5)
    s = 'a\xC3\x81bc'
    assert encode(s) == (b"a\\xC3\\x81bc",5)
    s = "ab\uD800\uDC00C"
    assert encode(s) == (b"ab\\xF0\\x90\\x80\\x80C",2)
    s = r"ab\U00010000C"

# Generated at 2022-06-23 18:02:37.628999
# Unit test for function register
def test_register():
    codecs.register(codecs.getencoder("hex"))   # type: ignore
    codecs.register(codecs.getdecoder("hex"))   # type: ignore
    register()
    codecs.encode("abづα\x00\x01\x41", "eutf8h")
    codecs.decode("ab\\xE3\\x81\\xA5\\xCE\\xB1\\00\\01\\41", "eutf8h")

# Generated at 2022-06-23 18:02:44.857573
# Unit test for function decode
def test_decode():
    out, length = decode(b'\\xc3\\xbf', 'strict')
    assert out == 'ÿ'
    assert length == 7
    out, length = decode(b'\\xc3\\xbf', 'replace')
    assert out == '���'
    assert length == 7
    out, length = decode(b'\\xc3\\xbf', 'ignore')
    assert out == ''
    assert length == 7
    out, length = decode(b'\\xc3\\xbf', 'xmlcharrefreplace')
    assert out == '&#255;'
    assert length == 7

    out, length = decode(b'\\xc3\\xbf\\xc3\\xa1', 'strict')
    assert out == 'ÿá'
    assert length == 14


# Generated at 2022-06-23 18:02:52.982740
# Unit test for function encode
def test_encode():
    in_str = r'\xF0\x9F\x92\xA9\xF0\x9F\x92\xA9'
    out_str = '\\xf0\\x9f\\x92\\xa9\\xf0\\x9f\\x92\\xa9'
    out_bytes, length = encode(in_str)
    assert length == len(in_str)
    assert out_bytes.decode('utf-8') == out_str


# Generated at 2022-06-23 18:03:03.878254
# Unit test for function encode
def test_encode():
    result = encode("1234567890")
    assert result == (b"1234567890", 10)

    result = encode("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
    assert result == (b"ABCDEFGHIJKLMNOPQRSTUVWXYZ", 26)

    result = encode("abcdefghijklmnopqrstuvwxyz")
    assert result == (b"abcdefghijklmnopqrstuvwxyz", 26)

    result = encode("\xde\xad\xbe\xef")
    assert result == (b"\\xde\\xad\\xbe\\xef", 4)

    result = encode("\xe3\x81\x82")
    assert result == (b"\\xE3\\x81\\x82", 3)



# Generated at 2022-06-23 18:03:04.703629
# Unit test for function register
def test_register():
    register()

# Generated at 2022-06-23 18:03:10.578282
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(
            'Got codecs.getdecoder for %s, but expected LookupError' % NAME
        )

    register()

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(
            'Got LookupError for codecs.getdecoder for %s,'
            ' but expected codecs.CodecInfo' % NAME
        )


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-23 18:03:16.366583
# Unit test for function register
def test_register():
    import sys
    import types

    def check(module, function_name) -> None:
        function = getattr(module, function_name, None)
        assert function and isinstance(function, types.FunctionType)

    sys.modules[__name__] = types.ModuleType(__name__)
    register()
    check(sys.modules[__name__], NAME)



# Generated at 2022-06-23 18:03:27.171138
# Unit test for function encode
def test_encode():
    # Test string:
    # '!\x01\n'
    test_input = r'!\x01\n'
    test_output = (b'!\\x01\\n', 3)

    assert encode(test_input) == test_output

    # Test string:
    # '!\x01\n'
    test_input = r'!\x01\n'
    test_output = (b'!\\x01\\n', 3)
    assert encode(test_input, 'ignore') == test_output

    # Test string:
    # '!\x01\n'
    test_input = r'!\x01\n'
    test_output = (b'!\\x01\\n', 3)
    assert encode(test_input, 'replace') == test_output

    # Test string

# Generated at 2022-06-23 18:03:37.625129
# Unit test for function encode
def test_encode():
    assert encode('hello') == (b'hello', 5)
    assert encode(u'hello') == (b'hello', 5)
    assert encode('hello\n') == (b'hello\\x0A', 6)
    assert encode('café') == (b'caf\\xC3\\xA9', 5)
    assert encode('coffee\u2615') == (b'coffee\\xE2\\x98\\x95', 10)
    assert encode('\uD800') == (b'\\xF0\\x90\\x80\\x80', 4)
    assert encode('\uDC00') == (b'\\xF0\\x90\\x80\\x80', 4)

# Generated at 2022-06-23 18:03:44.091524
# Unit test for function decode
def test_decode():
    import pytest
    # test kana characters
    assert decode(b'\\xe3\\x81\\x82\\xe3\\x82\\x8c\\xe3\\x82\\xab')[0] == 'あれか'
    assert decode(b'\\xe3\\x81\\x82\\xe3\\x82\\x8c\\xe3\\x82\\xab')[1] == 12
    # test kanji characters
    assert decode(b'\\xe6\\x96\\xa4')[0] == '関'
    assert decode(b'\\xe6\\x96\\xa4')[1] == 6
    # test escaped utf8 hexadecimal with invalid utf8 bytes

# Generated at 2022-06-23 18:03:49.277022
# Unit test for function encode
def test_encode():
    text = "سأنشئ مخرج"
    baseline = '\\xd8\\xb3\\xd8\\xa3\\xd9\\x86\\xd8\\xb4\\xd8\\xa6\\20' \
               '\\xd9\\x85\\xd8\\xae\\xd8\\xb1\\xd8\\xac'

    actual = encode(text)[0].decode('utf8')
    assert actual == baseline

# Generated at 2022-06-23 18:04:00.220106
# Unit test for function encode
def test_encode():
    assert encode('\\x41\x42') == b'\\\\x41\\x42'
    assert encode('\\xA0\xA1\xA2') == b'\\\\xA0\\xA1\\xA2'
    assert encode('\\x41\\x42') == b'\\\\x41\\\\x42'
    assert encode('\\xA0\\xA1\\xA2') == b'\\\\xA0\\\\xA1\\\\xA2'
    assert encode('\\x41\\x42', 'ignore') == b'\\\\x41\\\\x42'
    assert encode('\\xA0\\xA1\\xA2', 'ignore') == b'\\\\xA0\\\\xA1\\\\xA2'



# Generated at 2022-06-23 18:04:12.180418
# Unit test for function encode
def test_encode():

    # This test ensures that escaped utf8 hexadecimal is converted to
    # utf8 bytes and returned as bytes.
    assert encode('\\u0123'.encode('utf-8')) == (b'\\u0123', 6)

    # This test ensures that the default error handling is set to
    # 'strict'.
    exc_raised = False
    try:
        encode('\\udc00'.encode('utf-8'))
    except UnicodeEncodeError as e:
        exc_raised = True
        assert e.reason == 'invalid continuation byte'
        assert e.start == 2
        assert e.end == 3
        assert e.encoding == NAME
        assert e.object == '\\udc00'
    assert exc_raised

    # This test ensures that the error handling can be set to 'ignore'.


# Generated at 2022-06-23 18:04:15.219156
# Unit test for function encode
def test_encode():
    assert encode('\\u1234') == (b'\\xE1\\x88\\xB4', 7)  # noqa

# Generated at 2022-06-23 18:04:20.861381
# Unit test for function encode
def test_encode():
    with open(r"D:\myspace\space\post_econet2\__init__.py") as f:
        input_string = f.read()

    result_bytes, _ = encode(input_string)
    with open(r"D:\myspace\space\post_econet2\__init__.py", mode='wb') as f:
        f.write(result_bytes)
    print(result_bytes)


# Generated at 2022-06-23 18:04:31.987978
# Unit test for function encode
def test_encode():
    # Test a str that do not contain escaped utf8 hexadecimal.
    text = 'Hello World'
    text_bytes, _ = encode(text)
    assert text_bytes == b'Hello World'
    text_bytes_exp = text.encode('utf-8')
    assert text_bytes_exp == text_bytes

    # Test a str that contain escaped utf8 hexadecimal.
    text = '\\x48\\x65\\x6c\\x6c\\x6f\\x20\\x57\\x6f\\x72\\x6c\\x64'
    text_bytes, _ = encode(text)
    assert text_bytes == b'Hello World'
    text_bytes_exp = text.encode('utf-8')
    assert text_bytes_exp == text_bytes

    # Test a User

# Generated at 2022-06-23 18:04:41.033842
# Unit test for function decode
def test_decode():
    assert decode(b'\\xC2\\xE1\\xF4') == ('áô', 3)
    assert decode(b'foo\\xC2\\xE1\\xF4bar') == ('fooáôbar', 9)
    assert decode(b'\\xC2bar\\xF4') == ('ábarô', 6)
    assert decode(b'\\xE1\\xF4') == ('áô', 4)
    assert decode(b'foo\\xE1\\xF4bar') == ('fooáôbar', 8)
    assert decode(b'\\xE1bar\\xF4') == ('ábarô', 6)
    assert decode(b'\\xF4\\xC2\\xE1') == ('ôá', 6)

# Generated at 2022-06-23 18:04:52.582203
# Unit test for function encode
def test_encode():
    actual = encode('\u27a1')
    expected = (b'\\xe2\\x9e\\xa1', 1)
    assert actual == expected

    actual = encode('\U0001f631')
    expected = (b'\\xf0\\x9f\\x98\\xb1', 1)
    assert actual == expected

    actual = encode('\u2192')
    expected = (b'\\xe2\\x86\\x92', 1)
    assert actual == expected

    actual = encode(
        '\u2192'
        '\u27a1'
        '\U0001f631'
        '\u263a',
    )

# Generated at 2022-06-23 18:05:04.842785
# Unit test for function encode

# Generated at 2022-06-23 18:05:16.668901
# Unit test for function decode
def test_decode():
    # Example 1
    # Convert the utf8 bytes into a string of escaped hexadecimal
    utf8_bytes = bytes([0x48, 0x65, 0x6c, 0x6c, 0x6f, 0x20, 0x77, 0x6f, 0x72,
                        0x6c, 0x64, 0x21])
    escaped_hex = utf8_bytes.hex()
    escaped_hex = '\\x' + escaped_hex

    # Decode the escaped hexadecimal string into utf8 bytes
    decoded_bytes, decoded_bytes_len = decode(escaped_hex)

    # Convert the utf8 bytes into a string
    decoded_str = decoded_bytes.decode('utf-8')

    # Assert

# Generated at 2022-06-23 18:05:22.597705
# Unit test for function register
def test_register():
    register()
    obj = codecs.getdecoder(NAME)  # type: ignore
    assert obj.name == NAME
    assert obj.encode == encode  # type: ignore[arg-type]
    assert obj.decode == decode  # type: ignore[arg-type]


# Generated at 2022-06-23 18:05:34.473389
# Unit test for function decode
def test_decode():
    import codecs
    codecs.register(_get_codec_info)  # type: ignore
    #
    # basic tests
    #
    assert codecs.decode('\\x65\\x66\\x67', 'eutf8h') == 'efg'
    #
    # test for handling of invalid utf8 bytes
    #
    with pytest.raises(UnicodeDecodeError, match='eutf8h'):
        codecs.decode('\\xFF', 'eutf8h')
    with pytest.raises(UnicodeDecodeError, match='eutf8h'):
        codecs.decode('\\x80\\xC0', 'eutf8h')

# Generated at 2022-06-23 18:05:38.964897
# Unit test for function encode
def test_encode():
    utf8_h_e = codecs.getencoder(NAME)  # type: ignore
    utf8_t = 'abc\u2665'
    exp = r'abc\\xe2\\x99\\xa5'.encode('utf-8')
    out, out_s = utf8_h_e(utf8_t)
    assert out == exp
    assert out_s == len(utf8_t)


# Generated at 2022-06-23 18:05:47.406142
# Unit test for function decode
def test_decode():
    assert decode(b'CD\\xbd\\xba\\xbb\\xba\\xba\\xbb\\xbe') == ('CD���', 16)
    assert decode(b'\\x00\\x01\\x02\\x03\\x04\\x05\\x06\\x07\\x08\\t\\n\\x0b\\x0c\\r\\x0e\\x0f') == ('\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f', 30)