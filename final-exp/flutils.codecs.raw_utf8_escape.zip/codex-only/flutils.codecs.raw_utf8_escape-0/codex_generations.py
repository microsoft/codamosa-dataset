

# Generated at 2022-06-23 17:55:53.064785
# Unit test for function register
def test_register():
    register()

    # Check if `NAME` can be encode and decode.
    print(codecs.encode(NAME, NAME))
    print(codecs.decode(NAME, NAME))

    # Check if `NAME` is in the registered decoders
    for name in codecs.getdecoders():
        print(name)
        if name == NAME:
            raise AssertionError('%s is not in registered decoders' % NAME)

    # Check if `NAME` is in the registered encoders
    for name in codecs.getencoders():
        if name == NAME:
            raise AssertionError('%s is not in registered encoders' % NAME)



# Generated at 2022-06-23 17:56:02.472246
# Unit test for function decode
def test_decode():
    assert decode(b'\\x73\\x74\\x72\\x69\\x6E\\x67', 'strict') == ('string', 6)
    assert decode(b'\\xC3\\xA9', 'strict') == ('é', 4)
    assert decode(b'\\xC3', 'strict') == ('\u0323', 2)
    assert decode(b'\\xC3\\\\xC3', 'strict') == ('\u0323\\xC3', 6)
    assert decode(b'\\xC3\\xC3', 'strict') == ('\u0323\u0323', 6)
    assert decode(b'\\u0323', 'strict') == ('\u0323', 6)

# Generated at 2022-06-23 17:56:12.061279
# Unit test for function encode
def test_encode():
    result_bytes, _ = encode('abcd')
    assert result_bytes == b'abcd'

    result_bytes, _ = encode("\U00000081\U00000082\U00000083\U00000084")
    assert result_bytes == b'\\xC2\\x81\\xC2\\x82\\xC2\\x83\\xC2\\x84'

    result_bytes, _ = encode("\U00000081\U00000082\U00000083\U00000084")
    assert result_bytes == b'\\xC2\\x81\\xC2\\x82\\xC2\\x83\\xC2\\x84'

    result_bytes, _ = encode(r"\xC2\x81\xC2\x82\xC2\x83\xC2\x84")
    assert result

# Generated at 2022-06-23 17:56:21.653117
# Unit test for function decode
def test_decode():
    print("Executing unit test for function decode...")

    # Test 1:
    print("Test 1:")

# Generated at 2022-06-23 17:56:33.069848
# Unit test for function register
def test_register():
    import sys
    from functools import partial
    from typing import Dict
    mod = sys.modules[__name__]
    for key in dir(mod):
        if key.startswith('_'):
            continue
        value = getattr(mod, key)
        if callable(value):
            if key == 'register':
                continue
            codecs.register(partial(value, NAME))
    register()
    codecs.register(_get_codec_info)
    encoding = NAME
    utf8_bytes = b'\xf0\x90\x80\x80'
    text = utf8_bytes.decode('utf-8')
    text_hex = ''.join(each_hex for each_hex in _each_utf8_hex(text))
    text_hex_bytes = text_hex

# Generated at 2022-06-23 17:56:43.397060
# Unit test for function decode
def test_decode():
    # type: () -> None
    task_1 = b'\\x48\\x65\\x6c\\x6c\\x6f\\x2c\\x20\\x77\\x6f\\x72\\x6c\\x64'
    out, size = decode(task_1)
    expected_out = 'Hello, world'
    assert out == expected_out, 'Wrong decode'

    task_2 = b'\\xe4\\xbd\\xa0\\xe5\\xa5\\xbd\\xef\\xbc\\x8c\\xe4\\xb8\\x96\\xe7\\x95\\x8c'
    out, size = decode(task_2)
    expected_out = '你好，世界'
    assert out == expected_out, 'Wrong decode'

#

# Generated at 2022-06-23 17:56:50.422809
# Unit test for function encode
def test_encode():
    text = 'a中文简体b'
    text_bytes, _ = encode(text)

    assert text_bytes == b'a\\xe4\\xb8\\xad\\xe6\\x96\\x87\\xe7\\xae\\x80\\xe4' \
                          b'\\xbd\\x93b'

    text = 'a\\xe4\\xb8\\xad\\xe6\\x96\\x87\\xe7\\xae\\x80\\xe4\\xbd\\x93b'
    text_bytes, _ = encode(text, 'ignore')

    assert text_bytes == b'a\\xe4\\xb8\\xad\\xe6\\x96\\x87\\xe7\\xae\\x80\\xe4' \
                          b'\\xbd\\x93b'

    text

# Generated at 2022-06-23 17:56:59.404037
# Unit test for function encode
def test_encode():
    name = 'encode'
    result: bytes = encode('This is a test\n')
    assert result == b'This is a test\\xa'

    result = encode('This is a test\n')
    assert result == b'This is a test\\xa'

    result = encode('This is a test\n', 'strict')
    assert result == b'This is a test\\xa'

    result = encode('\u200e')
    assert result == b'\\xe2\\x80\\x8e'

    result = encode('\u200e', 'strict')
    assert result == b'\\xe2\\x80\\x8e'

    result = encode('\u200e', 'ignore')
    assert result == b''

    result = encode('\u200e', 'replace')
    assert result == b'?'

# Generated at 2022-06-23 17:57:11.593126
# Unit test for function encode
def test_encode():
    # Convert some test strings into escaped utf8 hexadecimal bytes.
    def _encode_test_str(test_str: str) -> bytes:
        test_bytes, _ = encode(test_str.encode('utf-8'))
        return test_bytes

    # Unit tests for encode
    assert _encode_test_str('') == b''
    assert _encode_test_str('abc') == b'abc'
    assert _encode_test_str('\nabc') == b'\\nabc'
    assert _encode_test_str('\u20ac') == b'\\xe2\\x82\\xac'
    assert _encode_test_str('\u20ac\u20ac') == b'\\xe2\\x82\\xac\\xe2\\x82\\xac'

# Generated at 2022-06-23 17:57:19.594421
# Unit test for function decode
def test_decode():
    assert decode(b'\\x41') == ('A', 3)
    assert decode(b'\\x41\\x42') == ('AB', 6)
    assert decode(b'\\x41\\x62') == ('Ab', 6)
    assert decode(b'\\xC2\\xA2') == ('¢', 6)
    assert decode(b'\\xE2\\x82\\xAC') == ('€', 9)
    assert decode(b'\\xF0\\x9D\\x84\\x9E') == ('𝄞', 12)
    assert decode(b'\\x1b') == ('\x1b', 4)



# Generated at 2022-06-23 17:57:30.100051
# Unit test for function encode

# Generated at 2022-06-23 17:57:39.076368
# Unit test for function encode
def test_encode():
    # Create a string with some utf-8 characters that are not likely
    # to print when the string is printed.
    char_list = [
        '☘',  # Green Shamrock
        '☯',  # Yin-Yang
        '☠',  # Skull and Crossbones
        '☃',  # Snowman
        '☂',  # Umbrella with Rain Drops
        '☹',  # Frowning Face
        '☠',  # Skull and Crossbones
    ]
    test_str = char_list[3]
    for i in range(1, len(char_list)):
        test_str = f'{test_str}-{char_list[i]}'

    # Convert the string into escaped utf8 hexadecimal.

# Generated at 2022-06-23 17:57:40.495390
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-23 17:57:44.156209
# Unit test for function encode
def test_encode():
    assert encode(
        'Hello, World!\\xaa\\xc2\\x80\\xc3\\x80\\xc3\\xbf\\n',
        errors='strict'
    ) == (
        b'Hello, World!\\\\xaa\\\\xc2\\\\x80\\\\xc3\\\\x80\\\\xc3\\\\xbf\\\\n',
        34
    )

# Generated at 2022-06-23 17:57:55.728817
# Unit test for function encode
def test_encode():
    assert encode('abcde') == (b'abcde', 5)
    assert encode('abcde\\x61') == (b'abcd\\x61', 10)
    assert encode('\\ud800\\udc00\uD800') == (b'\\xf0\\x90\\x80\\x80\\xed\\xa0\\x80', 4)
    assert encode('\r\n\r\n') == (b'\\r\\n\\r\\n', 4)
    assert encode('hi') == (b'hi', 2)
    assert encode('\\x61') == (b'\\x61', 4)
    assert encode(b'\\x61'.decode('unicode_escape')) == (b'\\x61', 4)


# Generated at 2022-06-23 17:57:59.221656
# Unit test for function register
def test_register():
    assert codecs.lookup('eutf8h') is None
    register()
    assert codecs.lookup('eutf8h')



# Generated at 2022-06-23 17:58:10.308787
# Unit test for function encode
def test_encode():
    # Test for simple ascii
    text = 'hello'
    out, length = encode(text,errors='strict')
    assert out == b'hello'
    assert length == 5

    # Test for utf8 character
    text = '\x7e'
    out, length = encode(text,errors='strict')
    assert out == b'\\x7e'
    assert length == 3

    # Test for utf8 unrecognised character
    text = '\x81'
    try:
        out, length = encode(text, errors='strict')
    except UnicodeDecodeError as e:
        assert e.reason == 'invalid start byte'
        assert e.start == 0
        assert e.end == 1

# Generated at 2022-06-23 17:58:19.906680
# Unit test for function decode
def test_decode():
    assert(decode(b'\\x41\\x42', 'strict') == ('AB', 6))
    assert(decode(b'\\u0041\\u0042', 'strict') == ('AB', 14))
    assert(decode(b'\\u0041\\u0042', 'replace') == ('AB', 14))
    assert(decode(b'\\u0041\\u0042', 'ignore') == ('', 14))
    assert(decode(b'\\u0041\\u0042\\u0043', 'surrogateescape') == ('ABC', 22))



# Generated at 2022-06-23 17:58:22.485509
# Unit test for function register
def test_register():
    import codecs
    codecs.register(_get_codec_info)
    codecs.getdecoder(NAME)


# Generated at 2022-06-23 17:58:24.251551
# Unit test for function register
def test_register():
    from . import _test_register
    _test_register(NAME)


# Generated at 2022-06-23 17:58:33.931003
# Unit test for function encode

# Generated at 2022-06-23 17:58:38.087493
# Unit test for function decode
def test_decode():
    data = b'\\u0e20\\u0e32\\u0e29\\u0e32\\u0e44\\u0e17\\u0e22\\x20'
    decoded_value, consumed_bytes_count = decode(data, errors="strict")
    print(f"{decoded_value}, {consumed_bytes_count}")
    print()


# Generated at 2022-06-23 17:58:47.818794
# Unit test for function decode
def test_decode():
    # Base test
    assert decode(b'S\\xE9bastien\\x20Haille') == ('Sébastien Haille', len(b'S\\xE9bastien\\x20Haille'))
    # Invalid hexadecimal (first value)
    assert decode(b'S\\xE9bastien\\ZHaille') == ('S\\xE9bastien\\ZHaille', len(b'S\\xE9bastien\\ZHaille'))
    # Invalid hexadecimal (second value)
    assert decode(b'S\\xE9bastien\\xFHaille') == ('S\\xE9bastien\\xFHaille', len(b'S\\xE9bastien\\xFHaille'))
    # Missing final value


# Generated at 2022-06-23 17:58:49.195916
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)  # type: ignore



# Generated at 2022-06-23 17:58:55.510503
# Unit test for function encode
def test_encode():
    class Test:

        def __init__(self, errors: _Str = 'strict'):
            self.errors = errors

        def __call__(self) -> None:
            test_str_input = ''
            test_bytes_result = b''
            test_int_result = 0
            test_tuple_result = (test_bytes_result, test_int_result)

            test_str_input = 'abc\u1234'
            test_bytes_result = b'abc\\xe1\\x88\\xb4'
            test_int_result = 5
            test_tuple_result = (test_bytes_result, test_int_result)
            test_bytes_result, test_int_result = encode(test_str_input)

# Generated at 2022-06-23 17:59:01.873623
# Unit test for function decode
def test_decode():
    assert decode(b'\\xc3\\xa9') == ('\u00e9', 8)
    assert decode(b'\\xe2\\x82\\xac') == ('\u20ac', 12)
    assert decode(b'\\xf0\\x9f\\x92\\xa9') == ('\U0001F4A9', 24)
    #assert decode(b'\\x41\\x20\\xe2\\x98\\xba') == ('A \u263a', 24)


# Generated at 2022-06-23 17:59:07.559211
# Unit test for function decode
def test_decode():
    assert decode(b'\\x61') == ('a', 3)
    assert decode(b'abc') == ('abc', 3)
    assert decode(b'abc\\x61') == ('abca', 7)
    assert decode(b'\\x20') == (' ', 3)
    assert decode(b'\\xE2\\x82\\xAC') == ('€', 11)
    assert decode(b'\\U000020AC\\xE2') == ('€\xE2', 15)
    assert decode(b'\\u0020\\U000020AC') == (' €', 15)
    assert decode(b'\\u0020\\U000020Ac') == (' €', 15)
    assert decode(b'\\u0020\\U000020AC\\xE2\\x82') == (' €€', 21)

# Generated at 2022-06-23 17:59:12.812435
# Unit test for function decode
def test_decode():
    assert decode(b'\\xC4\\x98\\xC4\\xA5\\xC5\\xA5') == ('Ęĥť', 6)
    assert decode(b'\\xC4\\xA5\\xC5\\xA5') == ('ĥť', 4)
    assert decode(b'\\xC5\\xA5') == ('ť', 2)

# Generated at 2022-06-23 17:59:15.356237
# Unit test for function register
def test_register():
    NAME = 'eutf8h'
    codecs.register(_get_codec_info)
    codecs.getdecoder(NAME)



# Generated at 2022-06-23 17:59:17.851599
# Unit test for function register
def test_register():
    """Unit test for function "register".
    """
    codecs.register(_get_codec_info)  # type: ignore
    codecs.getdecoder(NAME)



# Generated at 2022-06-23 17:59:22.320314
# Unit test for function encode
def test_encode():
    test_input = hex(ord('ⁱ'))
    assert encode(test_input) == (b'\\\\u2071', len(test_input))
    test_input = hex(ord('φ'))
    assert encode(test_input) == (b'\\\\u03c6', len(test_input))



# Generated at 2022-06-23 17:59:33.297984
# Unit test for function decode

# Generated at 2022-06-23 17:59:42.792422
# Unit test for function encode
def test_encode():
    assert encode('hello') == (b'\\x68\\x65\\x6c\\x6c\\x6f', 5)
    assert encode('\U0001F606') == (b'\\xf0\\x9f\\x98\\x86', 4)
    assert encode('\U0001F606\U0001F606') == (b'\\xf0\\x9f\\x98\\x86\\xf0\\x9f\\x98\\x86', 8)
    assert encode('hello\U0001F606') == (b'\\x68\\x65\\x6c\\x6c\\x6f\\xf0\\x9f\\x98\\x86', 9)



# Generated at 2022-06-23 17:59:54.012246
# Unit test for function decode
def test_decode():
    data = bytes('\\x41', 'utf-8')
    str_out, bytes_consumed = decode(data)
    assert str_out == 'A'
    assert bytes_consumed == 3
    data = bytes('\\x61', 'utf-8')
    str_out, bytes_consumed = decode(data)
    assert str_out == 'a'
    assert bytes_consumed == 3

# Generated at 2022-06-23 18:00:05.669269
# Unit test for function encode
def test_encode():
    # Test only ascii characters
    t1 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    t2 = 'abcdefghijklmnopqrstuvwxyz'
    t3 = '1234567890'
    t4 = t1 + t2 + t3
    # Test all ascii chars
    t5 = bytes(range(128))
    # Test some non ascii chars
    t6 = b'\x99\xF0\xA0\xA2\xF8'
    # Test some non ascii chars that are not valid
    t7 = b'\xFF\xF0\xA0\xF8'


# Generated at 2022-06-23 18:00:09.525780
# Unit test for function encode
def test_encode():
    text = 'Hello World\ud842\udfb7'
    result = encode(text)
    assert result == (b'Hello World\\xf0\\x9f\\x8e\\xb7', len(text))



# Generated at 2022-06-23 18:00:11.349831
# Unit test for function register
def test_register():
    import codecs

    register()
    codecs.getencoder(NAME)  # type: ignore

# Generated at 2022-06-23 18:00:14.347839
# Unit test for function register
def test_register():
    import sys
    before = sys.modules.copy()
    register()
    after = sys.modules.copy()

    # Ensure sys.modules didn't change
    assert before == after


# Generated at 2022-06-23 18:00:18.342184
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-23 18:00:22.002580
# Unit test for function register
def test_register():
    register()

    dec_1 = codecs.getdecoder(NAME)
    dec_2 = codecs.getdecoder(NAME)

    assert dec_1 is dec_2



# Generated at 2022-06-23 18:00:26.532306
# Unit test for function register
def test_register():
    """Unit test for function :func:`register``."""

    obj1 = codecs.getdecoder(NAME)  # type: ignore
    obj2 = codecs.getdecoder(NAME)  # type: ignore

    assert obj1 == obj2



# Generated at 2022-06-23 18:00:31.754719
# Unit test for function decode
def test_decode():
    assert decode(b'\\xC3\\xA9') == ('é', 8)
    assert decode(b'\\xC3\\\\xA9') == ('\\xC3', 5)
    assert decode(b'\\xC3\\xA9') == ('é', 8)
    assert decode(b'\\xC3\\\\\\xA9') == ('\\\\xA9', 5)



# Generated at 2022-06-23 18:00:38.653902
# Unit test for function encode
def test_encode():
    # Test the function encode against example 14.12 in the
    # standard library documentation.
    text = '\u3042\u3044\u3046\u3048\u304a'
    assert encode(text)[0] == b'\\xe3\\x81\\x82\\xe3\\x81\\x84\\xe3\\x81\\x86\\xe3\\x81\\x88\\xe3\\x81\\x8a'



# Generated at 2022-06-23 18:00:39.738850
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-23 18:00:49.163868
# Unit test for function decode
def test_decode():
    # Testing for positive
    x = r'\u0041'
    assert decode(b'\\u0041') == ('A', 8)
    assert decode(b'\\U0041') == ('A', 8)
    assert decode(x.encode('utf-8')) == ('A', 8)

    assert decode(b'\\U0041\\U0042') == ('AB', 16)
    assert decode(b'\\U0041\\u0042') == ('AB', 16)

    assert decode(b'\\x41\\x42') == ('AB', 6)
    assert decode(b'\\x41\\X42') == ('AB', 6)



# Generated at 2022-06-23 18:00:58.076879
# Unit test for function encode
def test_encode():
    input_string = "a\\x61b\\x62c\\x63"
    expected_bytes = bytes([
        0x61, 0x5c, 0x78, 0x36, 0x31, 0x62, 0x5c, 0x78, 0x36,
        0x32, 0x63, 0x5c, 0x78, 0x36, 0x33
    ])
    actual_bytes = encode(input_string)
    assert actual_bytes == expected_bytes



# Generated at 2022-06-23 18:00:59.794914
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 18:01:05.086248
# Unit test for function register
def test_register():
    global NAME

    NAME = 'test_register'

    _ = codecs.getdecoder(NAME)   # type: ignore
    _ = codecs.getencoder(NAME)   # type: ignore


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 18:01:14.885938
# Unit test for function encode
def test_encode():
        assert encode('你好') == (b'\\xe4\\xbd\\xa0\\xe5\\xa5\\xbd', 2)
        assert encode('Hello') == (b'Hello', 5)
        assert encode('你好') == (b'\\xe4\\xbd\\xa0\\xe5\\xa5\\xbd', 2)
        assert encode('你好') == (b'\\xe4\\xbd\\xa0\\xe5\\xa5\\xbd', 2)
        assert encode('\u0000') == (b'\\x00', 1)  # \u0000 is a NUL char
        assert encode('\u0000\u0000') == (b'\\x00\\x00', 2)

# Generated at 2022-06-23 18:01:23.737739
# Unit test for function decode
def test_decode():
    # Test 1: should pass
    data = b'\\xc3\\xab\\xc2\\xaf\\xe1\\x9c\\xa4'
    assert decode(data) == ('ëïᜤ', 9)

    # Test 2: should fail
    data = b'\\xc3\\xab\\xc2\\xaf\\xe1\\x9c\\xaaaaaaaaaaaad'
    try:
        decode(data)
    except UnicodeDecodeError:
        pass
    else:
        raise AssertionError

    # Test 3: should pass
    data = b'\\xc3\\xab\\xc2\\xaf\\xe1\\x9c\\xaaaaaaaaaaaad'
    assert decode(data, 'replace') == ('ëïᜤ���', 9)

    # Test 4: should pass
    data = b

# Generated at 2022-06-23 18:01:25.886740
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# Generated at 2022-06-23 18:01:29.100330
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)  # type: ignore
    getdecoder = codecs.getdecoder(NAME)  # type: ignore



# Generated at 2022-06-23 18:01:36.026951
# Unit test for function register
def test_register():
    from io import StringIO as _StringIO
    from textwrap import dedent as _dedent
    out = _StringIO()
    register()
    out.write('{}\n'.format(codecs.lookup(NAME)))
    out.write('{}\n'.format(codecs.lookup(NAME).name))
    out.write('{}\n'.format(codecs.lookup(NAME).encode))
    out.write('{}\n'.format(codecs.lookup(NAME).decode))

    out.seek(0)
    actual = out.read()

# Generated at 2022-06-23 18:01:41.304969
# Unit test for function encode
def test_encode():
    assert encode('a') == (b'a', 1)
    assert encode('\u1f4a1') == (b'\\xf0\\x9f\\x92\\xa1', 1)
    assert encode('a\u1f4a1') == (b'a\\xf0\\x9f\\x92\\xa1', 2)
    assert encode('') == (b'', 0)



# Generated at 2022-06-23 18:01:52.999868
# Unit test for function decode
def test_decode():
    assert decode(b'\\x61') == ('a', 5)
    assert decode(b'\\x61', 'strict') == ('a', 5)
    assert decode(b'\\x61', 'ignore') == ('', 5)
    assert decode(b'\\x61', 'replace') == ('\ufffd', 5)
    assert decode(b'\\x61', 'backslashreplace') == ('\\x61', 5)
    assert decode(b'\\xc3\\xa9') == ('é', 10)
    assert decode(b'\\303\\251') == ('é', 10)
    assert decode(b'\\x80') == ('\uFFFD', 5)
    assert decode(b'\\xD834\\xDD1E') == ('\U0001D11E', 15)

# Generated at 2022-06-23 18:01:55.221112
# Unit test for function register
def test_register():
    register()
    _ = codecs.getencoder(NAME)
    _ = codecs.getdecoder(NAME)

# Generated at 2022-06-23 18:02:03.507725
# Unit test for function encode
def test_encode():
    assert(
        encode('\u0041') == (b'\\x41', 1)
    )
    assert(
        encode('\u2070') == (b'\\xe2\\x81\\xb0', 1)
    )
    assert(
        encode('\u24B6') == (b'\\xe2\\x92\\xb6', 1)
    )
    assert(
        encode('\u1E9E') == (b'\\xc4\\xb9\\xe2\\x80\\x8e', 1)
    )
    assert(
        encode('\\') == (b'\\\\', 1)
    )
    assert(
        encode('\\x41') == (b'\\\\x41', 1)
    )

# Generated at 2022-06-23 18:02:07.234854
# Unit test for function register
def test_register():
    r"""Test for function register.
    """
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    test_register()

# Generated at 2022-06-23 18:02:11.402207
# Unit test for function encode
def test_encode():
    char = chr(160)
    text_input = char
    text_output = encode(text_input)
    text_expected = (b'\\xa0', 1)
    assert text_output == text_expected



# Generated at 2022-06-23 18:02:22.817192
# Unit test for function encode
def test_encode():

    # Test: Function 'encode'
    assert encode(b'\\x45') == b'\\\\x45'
    assert encode('\\x45') == b'\\\\x45'
    assert encode('\\x45') == encode(b'\\x45')
    assert encode('\u0045') == b'\\\\x45'
    assert encode('\u0045') == encode(b'\u0045')
    assert encode('Ё') == b'\\\\xd0\\\\x95\\\\xcc\\\\x88'

# Generated at 2022-06-23 18:02:28.641478
# Unit test for function decode
def test_decode():
    data_input = b'\\U0001F638'
    data_output = b''
    errors_input = b'strict'
    errors_output = b'replace'
    data_input_len = len(data_input)
    data_output_len = len(data_output)
    assert (decode(data_input, errors_input) ==
            (u'\U0001F638', data_input_len))
    assert (decode(data_output, errors_output) ==
            (u'', data_output_len))
    assert (decode(data_input, errors_output) ==
            (u'\U0001F638', data_input_len))
    assert (decode(data_output, errors_input) ==
            (u'', data_output_len))

# Unit

# Generated at 2022-06-23 18:02:32.306605
# Unit test for function decode
def test_decode():
    assert decode(b'\\x41') == ('A', 3)
    assert decode(b'\\u0307') == ('̇', 6)



# Generated at 2022-06-23 18:02:41.794192
# Unit test for function encode
def test_encode():
    """Unit test for :func:`encode`"""
    # The following are utf8 characters by their hexadecimal value.
    # 0xC2A2 is the cent sign.
    # 0xE282AC is the euro sign.
    # 0xE28892 is the peso sign.
    # 0xE28891 is the lira sign.
    # 0xE28893 is the ruble sign.
    # 0xE288B4 is the won sign.
    # 0xF09F92A5 is the yen sign.
    # 0xF0A2A2A2 is the capital letter V.
    # 0xF0A4A4A4 is the capital letter X.
    # 0xF0A6A6A6 is the capital letter Z.

    # 0xC2A2 is

# Generated at 2022-06-23 18:02:49.930315
# Unit test for function encode
def test_encode():
    assert encode('0') == (b'0', 1)
    assert encode('0\x01') == (b'0\\x01', 2)

    assert encode('0\x01', 'strict') == (b'0\\x01', 2)
    assert encode('0\x01', 'replace') == (b'0\\xFFFD', 2)
    assert encode('0\x01', 'surrogateescape') == (b'0\\x01', 2)
    assert encode('0\x01', 'ignore') == (b'0', 1)
    assert encode('0\x01', 'surrogatepass') == (b'0\\xFFFD', 2)
    assert encode('0\x01', 'backslashreplace') == (b'0\\xFFFD', 2)

# Generated at 2022-06-23 18:02:55.012164
# Unit test for function encode
def test_encode():
    """Test the encode function

    Returns:
        None

    Raises:
        AssertionError if the test fails
    """

    assert(encode('')[0] == b'')
    assert(encode('abc')[0] == b'abc')
    assert(encode('\x80')[0] == b'\\x80')



# Generated at 2022-06-23 18:03:05.178736
# Unit test for function decode

# Generated at 2022-06-23 18:03:14.295760
# Unit test for function encode
def test_encode():
    """Simple test for function encode."""


# Generated at 2022-06-23 18:03:25.415434
# Unit test for function decode

# Generated at 2022-06-23 18:03:36.482922
# Unit test for function register
def test_register():
    # Save the current codecs dictionary.
    saved_codecs = dict(codecs.__dict__)

    # Call the register function to register the eutf8h codec.
    register()

    # Check to see if the encode, decoder and incrementa codecs were
    # registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'getdecoder for %s failed' % NAME

    try:
        codecs.getencoder(NAME)
    except LookupError:
        assert False, 'getencoder for %s failed' % NAME

    try:
        codecs.getincrementalencoder(NAME)
    except LookupError:
        assert False, 'getincrementalencoder for %s failed' % NAME


# Generated at 2022-06-23 18:03:43.458934
# Unit test for function decode
def test_decode():
    """
    TESTING FUNCTION decode()
    """
    print("\nUnit Testing decode()")

    print("\nInput:\t\"\\\\xE2\\\\x80\\\\x9C\"")
    in_bytes = b"\\xE2\\x80\\x9C"
    print("Output:\t", end="")
    cyphertext, length = decode(data=in_bytes, errors="strict")
    print("\"%s\"\t%d" % (cyphertext, length))
    # print("\nExpecting:\t(\"\\u201c\", 3)\n")

    print("\nInput:\t\"\\\\xE2\\\\x80\\\\x9D\"")
    in_bytes = b"\\xE2\\x80\\x9D"
    print("Output:\t", end="")
   

# Generated at 2022-06-23 18:03:45.956935
# Unit test for function encode
def test_encode():
    inp = '\\xR\\xA'
    out, _ = encode(inp)
    assert out == b'\\x0D\\x0A'


# Generated at 2022-06-23 18:03:48.315056
# Unit test for function register
def test_register():
    register()
    # Use getdecoder to attempt to get encoding object
    # for the aeutf8h codec.
    _ = codecs.getdecoder(NAME)

# Generated at 2022-06-23 18:04:00.342395
# Unit test for function decode
def test_decode():
    def T(test_input: _ByteString, expected: str) -> None:
        actual, consumed = decode(test_input)
        if actual != expected:
            msg = '\nExpected: %r\nActual:   %r' % (expected, actual)
            raise AssertionError(msg)
        if consumed != len(test_input):
            msg = '\nExpected consumed: %r\nActual consumed:   %r' % (
                len(test_input), consumed
            )
            raise AssertionError(msg)

    T(b'', '')
    T(b'abc', 'abc')
    T(b'a\\x200bc', 'a\u00200bc')
    T(b'a\\x20fbc', 'a\u0020fbc')

# Generated at 2022-06-23 18:04:09.660975
# Unit test for function register
def test_register():
    # Test that the codecs cannot be looked up before registering the codec.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        assert False, 'expected LookupError'

    # Test that the codecs can be looked up after registering the codec.
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'unexpected LookupError'


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 18:04:17.042655
# Unit test for function register
def test_register():
    # Remove the codecs that were added by this module.
    codecs.lookup(NAME)

    try:
        codecs.lookup(NAME)
    except LookupError:
        pass
    else:
        raise Exception('Expected LookupError')

    register()

    try:
        codecs.lookup(NAME)
    except LookupError:
        raise Exception('Unexpected LookupError')
    else:
        pass

# Generated at 2022-06-23 18:04:22.987711
# Unit test for function encode
def test_encode():
    input_str = '\u30a1'
    output_str_bytes, output_str_len = encode(input_str)
    print(f'Input string: {input_str}')
    print(f'Output string length: {output_str_len}')
    print(f'Output string: {output_str_bytes}')
    assert output_str_bytes == b"\\xe3\\x82\\xa1"
    assert output_str_len == 1


# Generated at 2022-06-23 18:04:33.843934
# Unit test for function encode
def test_encode():
    text_input = '\u26A1'
    text_output_str = '\\xe2\\x9a\\xa1'
    text_output_bytes = b'\\xe2\\x9a\\xa1'

    text_output, _ = encode(text_input)
    assert isinstance(text_output, bytes)
    assert text_output == text_output_bytes

    text_output, _ = encode(text_input, errors='ignore')
    assert isinstance(text_output, bytes)
    assert text_output == b''

    text_output, _ = encode(text_input, errors='replace')
    assert isinstance(text_output, bytes)
    assert text_output == b'?'

    text_output, _ = encode(text_input, errors='surrogateescape')

# Generated at 2022-06-23 18:04:41.667488
# Unit test for function encode
def test_encode():
    # Test various unicode characters.
    text = 'Test\x0e\x0f\x1b\x1c\x1d\u000b\u000c\u0085\u2028\u2029'
    out, consumed = encode(text)
    assert consumed == len(text)
    assert out == \
           b'Test\\x0e\\x0f\\x1b\\x1c\\x1d\\x0b\\x0c\\x85\\xe2\\x80\\xa8\\xe2\\x80\\xa9'
    assert text == out.decode('unicode_escape')

    # Test various escaped hexadecimal sequences.


# Generated at 2022-06-23 18:04:43.353263
# Unit test for function decode
def test_decode():
    data = b'\\x61\\x62\\x63\\x64'
    text = 'abcd'
    cod = eutf8h.Codec()
    out = cod.decode(data)[0]
    assert text == out



# Generated at 2022-06-23 18:04:53.774257
# Unit test for function encode

# Generated at 2022-06-23 18:04:56.725498
# Unit test for function register
def test_register():
    import codecs
    codecs.getdecoder(NAME)  # raises LookupError if not registered



# Generated at 2022-06-23 18:05:00.972667
# Unit test for function encode
def test_encode():
    # Given
    text = r'\xed\xac\x80'

    # When
    data, nchars = encode(text)

    # Then
    assert data == rb'\\xed\\xac\\x80'
    assert nchars == 3


# Generated at 2022-06-23 18:05:03.329002
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 18:05:05.939117
# Unit test for function register
def test_register():
    codecs.lookup_error('eutf8h')


# Run test_register
test_register()

# The class to handle the encoding.
# noinspection PyUnusedLocal

# Generated at 2022-06-23 18:05:11.046397
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)


if __name__ == '__main__':
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
    assert codecs.getdecoder(NAME)

# Generated at 2022-06-23 18:05:19.428810
# Unit test for function encode
def test_encode():
    assert encode('\\x41') == b'\\x0041'
    assert encode('\\x01') == b'\\x0001'
    assert encode('\\x81\\x82') == b'\\x0081\\x0082'
    assert encode('\\xC3\\xA9') == b'\\x00C3\\x00A9'
    assert encode('\\xF0\\x90\\x80\\x81') == b'\\x00F0\\x0090\\x0080\\x0081'

    assert encode('\\x61') == b'\\x0061'
    assert encode('\\x41') == b'\\x0041'
    assert encode('\\xC3\\xA9') == b'\\x00C3\\x00A9'

# Generated at 2022-06-23 18:05:26.873846
# Unit test for function encode

# Generated at 2022-06-23 18:05:32.877618
# Unit test for function decode
def test_decode():
    data = b'\\xE5'
    out, length = decode(data)
    assert(out == 'å')
    assert(length == 2)
    data = b'\\xE5\\xE5\\xE5'
    out, length = decode(data)
    assert(out == 'ååå')
    assert(length == 6)



# Generated at 2022-06-23 18:05:34.070874
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-23 18:05:43.679611
# Unit test for function encode