

# Generated at 2022-06-23 17:55:52.947987
# Unit test for function decode
def test_decode():
    assert decode(b'\\x41')[0] == "A"
    assert decode(b'\\x41\\x42')[0] == "AB"
    assert decode(b'\\x41\\x42\\x43')[0] == "ABC"
    assert decode(b'\\x41\\x42\\x43\\x44')[0] == "ABCD"
    assert decode(b'\\x41\\x42\\x43\\x44\\x45')[0] == "ABCDE"
    assert decode(b'\\x41\\x42\\x43\\x44\\x45\\x46')[0] == "ABCDEF"
    assert decode(b'\\x41\\x42\\x43\\x44\\x45\\x46\\x47')[0] == "ABCDEFG"

# Generated at 2022-06-23 17:56:02.413716
# Unit test for function decode
def test_decode():
    """Test the decode method"""
    assert decode(b'\\x41') == ('A', 3)
    assert decode(b'\\x41\\x42') == ('AB', 6)
    assert decode(b'\\x41\\x41') == ('AA', 6)
    assert decode(b'\\xe3\\x81\\x82') == ('あ', 9)
    assert decode(b'\\xe3\\x81\\x82\\xe3\\x81\\x82') == ('ああ', 12)
    assert decode(b'\\xe3\\x81\\x82\\xe3\\x81\\x81') == ('ああ', 12)

    # Test invalid utf8 hexadecimal

# Generated at 2022-06-23 17:56:12.024671
# Unit test for function register
def test_register():
    # Ensure that the codec is not registered.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise
    # Register the codec and ensure that it is registered.
    register()
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    import unittest

    class EncodeTestCase(unittest.TestCase):

        def setUp(self):
            self.input = 'This is\x00binary.'

        def test_1(self):
            encoded_text, consumed_chars = encode(self.input)
            self.assertEqual(encoded_text, b"This is\\x00binary.")
            self.assertEqual(consumed_chars, len(self.input))

# Generated at 2022-06-23 17:56:13.871787
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-23 17:56:18.194437
# Unit test for function decode
def test_decode():
    assert decode(r'\x41\x42\x43') == ('ABC', 12)
    assert decode(r'\x00\x61\x62\x63') == ('abc', 16)
    assert decode(r'\x61\x00\x62\x63') == ('a\x00bc', 16)
    assert decode(r'\x61\x62\x63\x00') == ('abc\x00', 16)
    assert decode('') == ('', 0)


# TODO: Add more decode test cases.



# Generated at 2022-06-23 17:56:24.564445
# Unit test for function encode
def test_encode():
    result = encode('ABC\\x41')
    assert result == (b'ABC\\\\x41', 5)
    result = encode('\\x00\\x01\\x02\\x03\\x04\\x05\\x06\\x07')
    assert result == (b'\\\\x00\\\\x01\\\\x02\\\\x03\\\\x04\\\\x05\\\\x06\\\\x07', 17)
    result = encode('ABC\\x7f\\x80\\x81\\x82\\x83\\x84\\x85\\x86\\x87')
    assert result == (b'ABC\\\\x7f\\\\xC2\\\\x80\\\\xC2\\\\x81\\\\xC2\\\\x82\\\\xC2\\\\x83\\\\xC2\\\\x84\\\\xC2\\\\x85\\\\xC2\\\\x86\\\\xC2\\x87', 18)

# Generated at 2022-06-23 17:56:31.587000
# Unit test for function decode
def test_decode():

    assert codecs.decode("\\x41\\x42\\x43", "eutf8h") == "ABC"
    assert codecs.decode("\\x79", "eutf8h") == "y"

    assert codecs.decode("\\x66\\x6f\\x6f", "eutf8h") == "foo"

    assert codecs.decode("\\xe2\\x82\\xac", "eutf8h") == "€"



# Generated at 2022-06-23 17:56:42.760418
# Unit test for function encode
def test_encode():
    # Simple ASCII
    assert encode(u'Hello World') == (b'Hello World', 11)

    # Simple ASCII, with space
    assert encode(u'Hello\nWorld') == (b'Hello\\nWorld', 11)

    # Simple ASCII, with hex
    assert encode(u'\\x20') == (b'\\x20', 4)

    # Simple ASCII, with hex, with space
    assert encode(u'\\x20\\n') == (b'\\x20\\n', 7)

    # Simple ASCII, with hex, with space, with hex
    assert encode(u'\\x20\\n\\x20') == (b'\\x20\\n\\x20', 11)

    # Simple ASCII, with hex, with space, with hex, with space
    assert encode(u'\\x20\\n\\x20\\n')

# Generated at 2022-06-23 17:56:44.876781
# Unit test for function register
def test_register():
    """Unit test for function utf8_hex.register."""
    codecs.getdecoder(NAME)


# unit test for the encode function.

# Generated at 2022-06-23 17:56:51.095090
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode('q') == (b'q', 1)
    assert encode('02') == (b'\\x30\\x32', 2)
    assert encode('q&') == (b'q\\x26', 2)
    assert encode('ö') == (b'\\xc3\\xb6', 1)
    assert encode('öl') == (b'\\xc3\\xb6l', 2)
    assert encode('eö') == (b'e\\xc3\\xb6', 2)
    assert encode('öe') == (b'\\xc3\\xb6e', 2)
    assert encode('eeö') == (b'ee\\xc3\\xb6', 3)
    assert encode('öee') == (b'\\xc3\\xb6ee', 3)
   

# Generated at 2022-06-23 17:57:00.131904
# Unit test for function encode
def test_encode():
    # The output is a string of escaped utf8 hexadecimal and the number
    # of input characters consumed.
    result = encode('ação')
    assert result[0] == b'\\x61\\xc3\\xa7\\xc3\\xa3o'
    assert result[1] == 5

    result = encode('a\xE7\xE3o')
    assert result[0] == b'\\x61\\xc3\\xa7\\xc3\\xa3o'
    assert result[1] == 5

    result = encode('a\u00E7\u00E3o')
    assert result[0] == b'\\x61\\xc3\\xa7\\xc3\\xa3o'
    assert result[1] == 5

    result = encode('a\\xE7\\xE3o')


# Generated at 2022-06-23 17:57:12.319908
# Unit test for function encode
def test_encode():
    import io
    import unittest

    class TestEncode(unittest.TestCase):
        def test_encode_basic(self) -> None:
            data_out = b'\\xe2\\x82\\xac\\xe2\\x88\\x9e\\xe2\\xab\\xaa'
            str_in = '€⸮\u2aba'
            str_in_bytes = str_in.encode('utf8')
            data_out_bytes = encode(str_in)[0]
            self.assertEqual(str_in_bytes, data_out_bytes)


# Generated at 2022-06-23 17:57:20.768703
# Unit test for function register
def test_register():
    from unittest import mock
    import types

    with mock.patch.object(
        codecs,
        'register',
        return_value=None
    ) as mock_register:
        register()
        mock_register.assert_called_once()


if __name__ == '__main__':
    import unittest

    class TestEncode(unittest.TestCase):
        def test_utf8_hex_encode_invalid(self):
            input = '\\xZZ'
            self.assertRaises(UnicodeEncodeError, encode, input, 'strict')
            self.assertRaises(UnicodeEncodeError, encode, input, 'ignore')
            self.assertRaises(UnicodeEncodeError, encode, input, 'replace')

# Generated at 2022-06-23 17:57:23.501736
# Unit test for function decode
def test_decode():
    assert decode(b'\\x61\\x62') == ('\x61\x62', 4)
    assert decode(b'\\x61\\x62', 'ignore') == ('\x61\x62', 4)
    assert decode(b'\\x61\\x62', 'replace') == ('\x61\x62', 4)


# Generated at 2022-06-23 17:57:33.402469
# Unit test for function encode
def test_encode():
    # Test 1
    text_input = '1.5'
    expected = b'1.5'
    actual, _ = encode(text_input)
    assert expected == actual, 'Test 1: failed'

    # Test 2
    text_input = 'A'
    expected = b'A'
    actual, _ = encode(text_input)
    assert expected == actual, 'Test 2: failed'

    # Test 3
    text_input = '\x7a'
    expected = b'\\x7a'
    actual, _ = encode(text_input)
    assert expected == actual, 'Test 3: failed'

    # Test 4
    text_input = '\x7a'
    expected = b'\x7a'
    actual, _ = encode(text_input, 'ignore')
    assert expected == actual

# Generated at 2022-06-23 17:57:35.856982
# Unit test for function register
def test_register():
    register()
    assert (type(codecs.getencoder(NAME)) is codecs.CodecInfo)  # type: ignore



# Generated at 2022-06-23 17:57:37.764281
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


# Generated at 2022-06-23 17:57:41.736395
# Unit test for function decode
def test_decode():
    # Arrange
    target = decode
    data = b'\\x70\\x6f\\x6f\\x6c'
    exceptions = ()
    expect = ('pool', 4)
    # Act
    actual = target(data)
    # Assert
    assert actual == expect



# Generated at 2022-06-23 17:57:43.540672
# Unit test for function register
def test_register():
    import sys
    assert NAME not in sys.modules
    register()
    assert NAME in sys.modules

# Unit test function 'encode'

# Generated at 2022-06-23 17:57:55.451887
# Unit test for function decode
def test_decode():
    assert decode(b'\\x74\\x68\\x69\\x73\\x20\\x69\\x73\\x20\\x61\\x20\\x73\\x74\\x72\\x69\\x6e\\x67') == ('this is a string', 20)
    assert decode(b'\\x74\\x68\\x69\\x73\\x20\\x69\\x73\\x20\\x61\\x20\\x73\\x74\\x72\\x69\\x6e\\x67\\x20\\x77\\x69\\x74\\x68\\x20\\x30') == ('this is a string with 0', 28)

# Generated at 2022-06-23 17:57:58.058823
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)  # Should not throw LookupError

# Generated at 2022-06-23 17:57:59.465296
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-23 17:58:03.196736
# Unit test for function register
def test_register():
    import codecs
    from eutf8hex import encode, decode
    register()
    assert codecs.getencoder(NAME)
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-23 17:58:05.761123
# Unit test for function decode
def test_decode():
    assert decode(b'\\xF0\\x9F\\x98\\x80') == ('\U0001f600', 16)


# Generated at 2022-06-23 17:58:08.244274
# Unit test for function register
def test_register():
    # for unit test, call `register` twice. Shouldn't raise an exception.
    register()
    register()

test_register()

# Generated at 2022-06-23 17:58:19.953910
# Unit test for function encode

# Generated at 2022-06-23 17:58:21.382276
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None


# Generated at 2022-06-23 17:58:22.843891
# Unit test for function decode
def test_decode():
    text_input = "\\xE3\\x82\\x8D\\xE3\\x82\\x8B"
    assert decode(text_input.encode()) == ("ろる", 7)



# Generated at 2022-06-23 17:58:26.636305
# Unit test for function encode
def test_encode():
    utf8 = "\u03c3\u03c4\u03c5"
    assert encode(utf8)[0] == b'\\\\xcf\\\\x83\\\\xcf\\\\x84\\\\xcf\\\\x85'



# Generated at 2022-06-23 17:58:34.837709
# Unit test for function encode
def test_encode():
    for i in range(0x0,0xFFF):
        hexByte = hex(i)[2:]
        if( len(hexByte) == 2 ):
            result = encode( "\\x"+hexByte )[0]
            if( result != i.to_bytes(1,'big') ):
                raise AssertionError( "\\x"+hexByte+" was not encoded correctly" )
        else:
            result = encode( "\\x0"+hexByte )[0]
            if( result != i.to_bytes(1,'big') ):
                raise AssertionError( "\\x0"+hexByte+" was not encoded correctly" )
    print("Encode Test Passed")


# Generated at 2022-06-23 17:58:44.844022
# Unit test for function decode
def test_decode():
    """
    This function is a unit test for the decode function.
    """
    print("Testing decode()")
    print("\tTest case 1")
    bytes_i = b'\\xc3\\xa9'  # string bytes
    str_o = u"\u00e9"  # unicode string
    str_out, _ = codecs.decode(bytes_i, NAME)
    if str_out == str_o:
        print("\tTest case 1 passed.")
    else:
        print("\tTest case 1 failed.")
    print("\tTest case 2")
    bytes_i = b'\\xc3\\x\\x'  # string bytes
    str_o = u'\u00c3\u00b7\u00f7'

# Generated at 2022-06-23 17:58:54.189497
# Unit test for function encode
def test_encode():
    str_out = encode('abc')
    assert str_out == (b'abc', 3)
    str_out = encode('\\x0b')
    assert str_out == (b'\\x0b', 4)
    str_out = encode('x\\x0b')
    assert str_out == (b'x\\x0b', 5)
    str_out = encode('\\x0bx')
    assert str_out == (b'\\x0bx', 5)
    str_out = encode('x\\x0bx')
    assert str_out == (b'x\\x0bx', 6)
    str_out = encode('\\x0b\\x0b')
    assert str_out == (b'\\x0b\\x0b', 8)

# Generated at 2022-06-23 17:59:03.481802
# Unit test for function encode
def test_encode():
    """Test function encode."""
    text = 'a \x41  \x80  \x90  \xFF  \x100'
    text_hex = 'a \\x41  \\xc2\\x80  \\xc2\\x90  \\xc3\\xbf  \\xc4\\x80'
    text_bytes = text_hex.encode('utf-8')
    assert encode(text)[0] == text_bytes
    assert encode(text)[1] == len(text)

    text = 'a \x41  \x80  \x90  \xFF  \x100'
    text_hex = 'a \\x41  \\x80  \\x90  \\xFF  \\x100'
    text_bytes = text_hex.encode('utf-8')
    assert encode(text)[0] == text

# Generated at 2022-06-23 17:59:13.119453
# Unit test for function decode

# Generated at 2022-06-23 17:59:22.495213
# Unit test for function encode
def test_encode():
    assert encode('abc') == (b'abc', 3)
    assert encode('abcΩ') == (b'abc\xce\xa9', 4)
    assert encode('abc\xce\xa9') == (b'abc\xce\xa9', 4)
    assert encode('abc\xce\xa9') == (b'abc\xce\xa9', 4)
    assert encode('abc\\xce\\xa9') == (b'abc\xce\xa9', 8)
    assert encode('abc‼') == (b'abc\xe2\x80\xbc', 4)
    assert encode('abc\\xe2\\x80\\xbc') == (b'abc\xe2\x80\xbc', 12)

    # noinspection SpellCheckingInspection

# Generated at 2022-06-23 17:59:27.013954
# Unit test for function register
def test_register():
    # type: () -> None
    """Unit test for function register"""
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getdecoder('not_a_decoder') is None



# Generated at 2022-06-23 17:59:27.960693
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 17:59:29.258526
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    register()

# Generated at 2022-06-23 17:59:40.775157
# Unit test for function register
def test_register():
    from sys import modules

    # uninstall the eutf8h codec
    try:
        codecs.lookup('eutf8h')
        del modules[__name__]
    except LookupError:
        pass

    # import the eutf8h codec
    import eutf8h  # isort:skip

    # register the eutf8h codec
    eutf8h.register()

    # lookup the eutf8h codec
    codecs.lookup('eutf8h')

    # Test that trying to register the eutf8h codec again
    # will raise a RuntimeError.
    try:
        eutf8h.register()
    except RuntimeError as e:
        if "eutf8h codec is already registered" not in str(e):
            raise e

    del modules[__name__]

# Generated at 2022-06-23 17:59:47.805962
# Unit test for function register
def test_register():
    # Register the codec
    register()

    # Make sure the codec is registered.
    codec = codecs.getdecoder(NAME)
    assert codec is not None

    # Make sure the codec registered by register() is the same as the codec
    # registered for the eutf8h codec.
    codec_eutf8h = codecs.getdecoder('eutf8h')
    assert codec == codec_eutf8h


# Unit Test for function encode

# Generated at 2022-06-23 17:59:52.636903
# Unit test for function encode
def test_encode():
    testcase = ('a\ud7ff\u00ea'
                '\u0000\x80\ue000\uffff')

    expected = b'a\\ud7ff\\xea\\x00\\x80\\uE000\\uFFFF'

    encoded = encode(testcase)[0]

    assert encoded == expected



# Generated at 2022-06-23 17:59:54.801162
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-23 18:00:06.234294
# Unit test for function decode
def test_decode():
    """Test for function decode"""
    assert decode(b'\\xe4\\xbd\\xa0\\xe5\\xa5\\xbd') == ('你好', 12)

    # Check for invalid utf8 bytes
    data = b'\\xf0\\x28\\x8c\\xbc'
    try:
        decode(data)
    except UnicodeDecodeError as e:
        err = e
    assert err.start == 0
    assert err.end == 4

    # Check for invalid utf8 hexadecimal
    data = b'\\xf1\\xf0\\x28\\x8c\\xbc'
    try:
        decode(data)
    except UnicodeDecodeError as e:
        err = e
    assert err.start == 0
    assert err.end == 1



# Generated at 2022-06-23 18:00:07.356542
# Unit test for function register
def test_register():
    pass

# Generated at 2022-06-23 18:00:15.602539
# Unit test for function decode
def test_decode():
    tests = (
        (
            r'\xe0\xa5\xa4\xe0\xa4\x95\xe0\xa5\x8d\xe0\xa4\xaf' +
            r'\xe0\xa4\xbc\xe0\xa5\x8d\xe0\xa4\xb0\xe0\xa4\xbf',
            u'तॅक्य्य्रि',
        ),
    )
    for test in tests:
        out, len_ = decode(test[0])
        assert out == test[1]
        assert len_ == len(test[0])



# Generated at 2022-06-23 18:00:17.944633
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-23 18:00:18.639782
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 18:00:19.477708
# Unit test for function decode
def test_decode():
    assert decode(b'abc') == ('abc', 3)



# Generated at 2022-06-23 18:00:20.529181
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-23 18:00:32.296491
# Unit test for function encode
def test_encode():
    assert encode('a') == (b'a', 1)
    assert encode('\t') == (b'\\x09', 1)
    assert encode('\xff') == (b'\\xff', 1)
    assert encode('\u1234') == (b'\\xe1\\x88\\xb4', 1)

    try:
        encode('\u0000\x28\x29')
    except UnicodeEncodeError:
        assert True
    else:
        assert False

    try:
        encode('\x28\u0000\x29')
    except UnicodeEncodeError:
        assert True
    else:
        assert False

    try:
        encode('\x28\x29\u0000')
    except UnicodeEncodeError:
        assert True
    else:
        assert False



# Generated at 2022-06-23 18:00:38.505809
# Unit test for function encode
def test_encode():
    assert encode('Hello world') == (b'Hello world', 11)
    assert encode('\\x41') == (b'\x41', 3)
    assert encode('\\x41bcde\\x42') == (b'\x41bcde\x42', 9)
    assert encode('\\x41\\x42\\x43\\x44') == (b'\x41\x42\x43\x44', 9)
    assert encode('\\x41\\x42\\x43\\x44\\x45') == (b'\x41\x42\x43\x44\x45', 11)
    assert encode('\\x41\\x42\\x43\\x44\\x45\\x46') == (b'\x41\x42\x43\x44\x45\x46', 13)

# Generated at 2022-06-23 18:00:46.731048
# Unit test for function decode
def test_decode():
    data_hex = b'\\xC3\\x85\\xC3\\x84\\xC3\\x96\\xC3\\x9C'
    out, n = decode(data_hex)
    expected = "ÅÄÖÜ"
    assert out == expected
    assert n == len(data_hex)
    try:
        out, n = decode(b'\\xC3\\xAA')
        assert False
    except UnicodeDecodeError as e:
        assert e.reason == 'invalid continuation byte'


# Generated at 2022-06-23 18:00:54.804997
# Unit test for function encode
def test_encode():
    assert encode('\xF6') == (b'\xE0\xBE\xB6', 1)
    assert encode('\xC3\xB6') == (b'\xE0\xBE\xB6', 1)
    assert encode('\xF6\xC3') == (b'\xE0\xBE\xB6\xE0\xBF\x83', 2)
    assert encode('\xC3\xB6\xF6') == (b'\xE0\xBE\xB6\xE0\xBE\xB6', 2)
    assert encode('\xC3\xB6\xC3') == (b'\xE0\xBE\xB6\xE0\xBF\x83', 2)

# Generated at 2022-06-23 18:01:03.683516
# Unit test for function encode
def test_encode():
    # Test that a non-string input raises a TypeError
    try:
        encode(b'foo')  # type: ignore
    except TypeError:
        pass
    else:
        assert False, 'Expected a TypeError'

    # Test that a non-string error input raises a TypeError
    try:
        encode('foo', b'bar')  # type: ignore
    except TypeError:
        pass
    else:
        assert False, 'Expected a TypeError'

    # Test that an empty string is correctly converted
    assert encode('', 'strict') == (b'', 0)

    # Test that a simple string is correctly converted
    assert encode('hello, world') == (b'hello, world', 12)

    # Test that escaped utf-8 hexadecimal is correctly converted

# Generated at 2022-06-23 18:01:13.924272
# Unit test for function decode
def test_decode():
    # Invalid hex
    with pytest.raises(UnicodeDecodeError):
        decode(b'\\xE')
    with pytest.raises(UnicodeDecodeError):
        decode(b'\\x0')
    with pytest.raises(UnicodeDecodeError):
        decode(b'\\xz')
    with pytest.raises(UnicodeDecodeError):
        decode(b'\\xg')
    with pytest.raises(UnicodeDecodeError):
        decode(b'\\xZ')
    with pytest.raises(UnicodeDecodeError):
        decode(b'\\xG')
    with pytest.raises(UnicodeDecodeError):
        decode(b'\\x')

# Generated at 2022-06-23 18:01:23.516854
# Unit test for function decode
def test_decode():
    print("Testing decode function")
    str1 = b'\x43\x6f\x64\x65\x20\x22\\x43\\x6f\\x64\\x65\\x22\\x20\\x73\\x75\\x63' \
           b'\\x63\\x65\\x73\\x73\\x66\\x75\\x6c\\x6c\\x79\\x20\\x64\\x65\\x63\\x6f' \
           b'd\\x65\\x64\\x20'
    str2 = b'\x01\x02\x03\\x4a\\x4b\\x4c\\x4d\\x4e\\x4f\\x50\\x51\\x52\x03\x04'

    # print(decode(str1))
    # print

# Generated at 2022-06-23 18:01:26.889295
# Unit test for function encode
def test_encode():
    unicode_val = u'\u20ac'

    # This should match
    assert b'\\xe2\\x82\\xac' == unicode_val.encode('eutf8h')



# Generated at 2022-06-23 18:01:35.365389
# Unit test for function decode
def test_decode():
    test_case: Tuple[bytes, str, str] = (
        b'\\x61\\x62\\x63\\x64\\x65\\x66\\x67\\x68\\x69\\x6a',
        'abcdefghij',
        'strict'
    )

    test_input: bytes = test_case[0]
    expected_out: str = test_case[1]
    expected_errors: str = test_case[2]


    with pytest.raises(UnicodeDecodeError) as ue:
        decode(test_input, expected_errors)

    assert ue.value.encoding == 'eutf8h'
    assert ue.value.object == test_input
    assert ue.value.start == 0
    assert ue.value.end == 4

# Generated at 2022-06-23 18:01:41.043180
# Unit test for function encode
def test_encode():
    test_str = '\\xC3\\xA9'
    test_str_bytes = 'é'.encode('utf8')
    out = encode(test_str)
    assert(out == test_str_bytes)

    # Error checking
    test_str = '\\xE0\\xA4\\xA9'
    with pytest.raises(UnicodeEncodeError):
        encode(test_str)



# Generated at 2022-06-23 18:01:52.579431
# Unit test for function encode

# Generated at 2022-06-23 18:02:02.359713
# Unit test for function decode
def test_decode():

    text = '\\320\\270\\320\\276\\320\\262\\320\\260'
    expected = 'ЯЮЬЬ'

    data, count = decode(text.encode(), 'eutf8h')
    assert data == expected
    assert count == len(text)

    text = '\\320\\270\\320\\276\\320\\262\\320\\260\\320'
    expected = 'ЯЮЬЬР'

    data, count = decode(text.encode(), 'eutf8h')
    assert data == expected
    assert count == len(text) - 1

    text = '\\320\\270\\320\\276\\320\\262\\320\\260\\320X'
    expected = 'ЯЮЬЬР'


# Generated at 2022-06-23 18:02:08.913140
# Unit test for function register
def test_register():
    import codecs
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        import pytest
        register()
        # noinspection PyTypeChecker
        codecs.getdecoder(NAME)
    else:
        pytest.fail('ERROR: function had no effect.')


# Generated at 2022-06-23 18:02:16.744543
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getencoders()
    assert NAME in codecs.getdecoders()
    assert NAME in codecs.getincrementalencoders()
    assert NAME in codecs.getincrementaldecoders()
    assert NAME in codecs.getaliases()

    # Test each of the codecs.CodecInfo methods.
    obj = codecs.getdecoder(NAME)    # type: ignore
    assert obj.__dict__ == dict(  # type: ignore
        name=NAME,
        encode=encode,  # type: ignore[arg-type]
        decode=decode,  # type: ignore[arg-type]
    )

    obj = codecs.getencoder(NAME)    # type: ignore

# Generated at 2022-06-23 18:02:19.394363
# Unit test for function register
def test_register():
    """test_register
    """
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False
    assert True

# Generated at 2022-06-23 18:02:27.177145
# Unit test for function decode
def test_decode():
    # Test for single character
    assert decode(b'\\x41') == ('A', 5)
    assert decode(b'\\u0041') == ('A', 6)
    assert decode(b'\\U00000041') == ('A', 10)

    # Test for multi-character
    assert decode(b'\\u0041\\U00000041') == ('AA', 16)
    assert decode(b'\\U00000041\\u0041') == ('AA', 16)

    # Test for invalid data
    with pytest.raises(UnicodeDecodeError):
        decode(b'\\x41\\x42')
    with pytest.raises(UnicodeDecodeError):
        decode(b'\\u0041\\42')

# Generated at 2022-06-23 18:02:37.746621
# Unit test for function encode
def test_encode():
    ENCODINGS = (
        ('abcde',
         '\\61\\62\\63\\64\\65'),
        ('\\x61',
         '\\61'),
        ('\\x61\\x62',
         '\\61\\62'),
        ('\\x61\\x62\\x63\\x64\\x65',
         '\\61\\62\\63\\64\\65'),
    )

    for text_input, expected_output in ENCODINGS:
        output, _ = encode(text_input)
        output = cast(bytes, output)
        output_str = output.decode('utf-8')
        assert output_str == expected_output, '\n'\
            f'{text_input} != {output}'



# Generated at 2022-06-23 18:02:44.937092
# Unit test for function decode
def test_decode():

    assert decode(b'\\x7f\\x80\\xc2\\x80\\xc2\\x81\\xc2\\xbf\\xdf\\xbf') == (
        '\x7f\x80\x80\x81\xbf\xbf',
        10,
    )

    assert decode(b'\\x7f\\x80\\xc2\\x80\\xc2\\x81\\xc2\\xbf\\xdf\\xbf', 'ignore') == (
        '\x7f\x80\x80\x81\xbf\xbf',
        10,
    )


# Generated at 2022-06-23 18:02:56.166026
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    import sys, unittest

    python_version = sys.version_info

    args = sys.argv[1:]

    unit_tests_path = './unit_tests'
    unit_tests = [
        'test_register',
    ]

    if python_version.major >= 3 and python_version.minor >= 6:
        unit_tests.insert(0, 'TestCase')

    unittest_module = unittest.defaultTestLoader.discover(
        start_dir=unit_tests_path,
        pattern='test_*.py',
    )


# Generated at 2022-06-23 18:03:01.326497
# Unit test for function decode
def test_decode():
    decode_str = "ExplodingKittens\\E2\\98\\BA"
    expected = "ExplodingKittens☺"
    actual = decode(decode_str)
    if actual[0] != expected:
        print ("failed decode test")
        print ("expected:", expected)
        print ("actual:  ", actual[0])
    else:
        print ("passed decode test")
        print ("expected:", expected)
        print ("actual:  ", actual[0])


# Generated at 2022-06-23 18:03:04.476567
# Unit test for function encode
def test_encode():
    input = r'\xff'
    encoded = '汉'
    output = codecs.encode(encoded, 'eutf8h')
    assert input.encode('latin1') == output

# Generated at 2022-06-23 18:03:09.423451
# Unit test for function register
def test_register():
    import sys
    from pytest import raises

    if NAME in sys.modules:
        mod = sys.modules[NAME]
        del sys.modules[NAME]

    try:
        with raises(LookupError):
            codecs.getdecoder(NAME)

        register()
        assert codecs.getdecoder(NAME) is not None
    finally:
        if NAME in sys.modules:
            if mod is not None:
                sys.modules[NAME] = mod
            else:
                del sys.modules[NAME]

# Generated at 2022-06-23 18:03:10.623523
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)



# Generated at 2022-06-23 18:03:22.631286
# Unit test for function decode
def test_decode():
    data = b'\\x41\\x42\\x43'
    out = decode(data)
    assert out[0] == 'ABC'
    assert out[1] == 3
    data = b'\\x41\\x42\\x43A\\x42\\x43'
    out = decode(data)
    assert out[0] == 'ABCABC'
    assert out[1] == 6
    data = b'\\x41\\x42\\x43\\x41\\x42\\x43'
    out = decode(data)
    assert out[0] == 'ABCABC'
    assert out[1] == 6
    data = b'\\x41\\x42\\x43\\x41\\x42\\xD0\\x80\\x43'
    out = decode(data)

# Generated at 2022-06-23 18:03:23.515436
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None

# Generated at 2022-06-23 18:03:31.438420
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode('ab') == (b'ab', 2)
    assert encode('abcde') == (b'abcde', 5)
    assert encode('\x80') == (b'\\xc2\\x80', 1)
    assert encode('\xc2\x81') == (b'\\xc2\\x81', 1)
    assert encode('\xc3\x82') == (b'\\xc3\\x82', 1)
    assert encode('\xe1\xbc\xa1') == (b'\\xe1\\xbc\\xa1', 1)
    assert encode('\xf1\xb2\xa3\xd4') == (b'\\xf1\\xb2\\xa3\\xd4', 1)

# Generated at 2022-06-23 18:03:38.458080
# Unit test for function encode
def test_encode():
    assert encode('ab') == (b'a\\x62', 2)
    assert encode('abc') == (b'a\\x62c', 3)
    assert encode('a\\x62c') == (b'a\\x62c', 5)
    assert encode('a\\x62\\x63') == (b'a\\x62c', 7)
    assert encode('a\\x62\\x63') == (b'a\\x62c', 7)
    assert encode('a\\x62\\x63\\x64') == (b'a\\x62c\\x64', 9)



# Generated at 2022-06-23 18:03:49.353672
# Unit test for function encode

# Generated at 2022-06-23 18:03:54.695279
# Unit test for function register
def test_register():
    codecs.register(lambda n: None)  # type: ignore
    register()
    codecs.register(lambda n: None)  # type: ignore
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pytest.fail('Failed to register %s' % NAME)

# Generated at 2022-06-23 18:04:00.042663
# Unit test for function encode
def test_encode():
    # Note: This is not a comprehensive test of this function.
    assert encode(r'\x40') == (b'\\@', 2)
    assert encode(r'\x40\x41') == (b'\\@A', 4)
    assert encode(r'a\x40\x41\x42b') == (b'a\\@ABb', 8)

# Generated at 2022-06-23 18:04:12.176579
# Unit test for function encode
def test_encode():
    """Testing function encode"""
    # print(encode('Hi'))
    # print(encode('Hi\u00A0\u03A9'))
    # print(encode('Hi\u00A0\u03A9', errors='ignore'))

    func = encode
    assert func('Hi') == (b'Hi', 2)  # no replace
    assert func('Hi\u00A0\u03A9') == (b'Hi\\xA0\\x3B9', 3)  # replace
    assert func('Hi\u00A0\u03A9', errors='replace') == (
        b'Hi\\xA0\\x3F\\x3F', 3)  # replace
    assert func('Hi\u00A0\u03A9', errors='ignore') == (b'Hi', 2)

# Generated at 2022-06-23 18:04:23.074089
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-23 18:04:26.413786
# Unit test for function decode
def test_decode():
    assert decode(b'fischer') == ('fischer', 7)
    assert decode(b'\\x66\\x69\\x73\\x63\\x68\\x65\\x72') == ('fischer', 25)



# Generated at 2022-06-23 18:04:29.021998
# Unit test for function register
def test_register():
    register()
    try:
        # Try to get both the encoder and decoder.
        codecs.getencoder(NAME)
        codecs.getdecoder(NAME)
    except LookupError:
        print(
            'Unable to get encoder or decoder from codec '
            'registry with name %s' % (NAME)
        )

# Generated at 2022-06-23 18:04:39.206364
# Unit test for function decode
def test_decode():
    errors = 'strict'
    data = b'\\xc3\\xbf'
    out, _ = decode(data, errors)
    assert out == '\ufffd'
    data = b'\\xc3'
    out, _ = decode(data, errors)
    assert out == '\udcc3'
    data = b'\\xc3\\xbf'
    errors = 'replace'
    out, _ = decode(data, errors)
    assert out == '\ufffd'
    errors = 'ignore'
    out, _ = decode(data, errors)
    assert out == ''
    errors = 'surrogateescape'
    out, _ = decode(data, errors)
    assert out == '\udcff'
    errors = 'backslashreplace'
    out, _ = decode(data, errors)
   

# Generated at 2022-06-23 18:04:44.140251
# Unit test for function register
def test_register():
    # Register this codec.
    register()

    # Get the codec decoder info.
    info = codecs.getdecoder(NAME)

    # Make sure that the codec name is as expected.
    assert info.name == NAME


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 18:04:51.900745
# Unit test for function decode
def test_decode():

    print("Unit test started\n")


# Generated at 2022-06-23 18:05:04.114534
# Unit test for function decode

# Generated at 2022-06-23 18:05:07.329702
# Unit test for function register
def test_register():
    save_codec_info = _get_codec_info(NAME)
    try:
        _get_codec_info(NAME)
        assert False, 'Should have raised an exception.'
    except LookupError:
        # What we want
        pass
    register()
    _ = _get_codec_info(NAME)



# Generated at 2022-06-23 18:05:09.623066
# Unit test for function decode
def test_decode():
    assert decode(b'\\xe0\\x80\\x80') == ('\u0000', 11)


# Generated at 2022-06-23 18:05:12.504913
# Unit test for function decode
def test_decode():
    # TODO: make this a test
    if __name__ == "__main__":
        import doctest
        doctest.testmod()

# Generated at 2022-06-23 18:05:16.855283
# Unit test for function encode
def test_encode():
    text = 'foo\x99\x99\x99bar\x99\x99\x99baz\x99\x99\x99'
    out = encode(text)[0].decode('utf-8')
    assert out == "foo\\x99\\x99\\x99bar\\x99\\x99\\x99baz\\x99\\x99\\x99"



# Generated at 2022-06-23 18:05:26.370415
# Unit test for function decode
def test_decode():
    assert decode(b'\\xC3\\xB1') == ('ñ', 8)
    assert decode(b'\\u2302') == ('\ue000', 8)
    assert decode(b'\\U0002F937') == ('\U0002f937', 24)
    assert decode(b'\\xC3\\xB1') == ('ñ', 8)
    assert decode(b'\\u2302') == ('\ue000', 8)
    assert decode(b'\\U0002F937') == ('\U0002f937', 24)
    assert decode(b'\\u2302\\U0002F937') == ('\ue000\U0002f937', 32)
    assert decode(b'\\xC3\\xBD\\U0002F937') == ('ý\U0002f937', 32)

# Generated at 2022-06-23 18:05:29.260638
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getdecoder(NAME)
    assert NAME in codecs.getencoder(NAME)

register()



# Generated at 2022-06-23 18:05:33.598756
# Unit test for function decode
def test_decode():
    assert decode('\\x41') == ('A', 4)
    assert decode('\\x41\\x41') == ('AA', 6)
    assert decode('\\x41\\x41\\x42') == ('AAB', 8)
    return 0


# Generated at 2022-06-23 18:05:35.031747
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 18:05:44.208871
# Unit test for function encode
def test_encode():
    assert encode('abc') == (b'abc', 3)
    assert encode(chr(0xA9)) == (b'\\xc2\\xa9', 1)
    assert encode(
        str('\\xc3\\x80\\xc3\\x82\\xc3\\x84\\xc3\\xa0')
    ) == (b'\\xc3\\x80\\xc3\\x82\\xc3\\x84\\xc3\\xa0', 4)
    assert encode(
        str('\\xc3\\x80\\xc3\\x82\\xc3\\x84\\xc3\\xa0\\xef\\xbb\\xbf')
    ) == (b'\\xc3\\x80\\xc3\\x82\\xc3\\x84\\xc3\\xa0\\xef\\xbb\\xbf', 5)