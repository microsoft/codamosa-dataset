

# Generated at 2022-06-23 17:55:47.426009
# Unit test for function register
def test_register():
    register()

    assert codecs.lookup_error('eutf8h').name == NAME
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-23 17:55:49.983845
# Unit test for function decode
def test_decode():
    assert decode(b'\\x65\\x66') == ('ef', 4)


# Generated at 2022-06-23 17:56:00.349759
# Unit test for function decode
def test_decode():
    from itertools import zip_longest
    from random import randint
    from codecs import encode

    # Define some strings that are of latin-1 or utf-8 characters.
    # Note that the string of utf-8 characters is longer than 8 bits.
    latin1_str = chr(randint(0, 127))
    utf8_str = '\u00b7'

    # Convert the strings into utf-8 bytes.
    latin1_bytes = latin1_str.encode('latin1')
    utf8_bytes = utf8_str.encode('utf-8')

    # Convert the utf-8 bytes into escaped utf-8 hexadecimal bytes.
    escaped_utf8_hex_bytes = encode(utf8_str, 'eutf8h')



# Generated at 2022-06-23 17:56:06.574777
# Unit test for function decode
def test_decode():
    def test_decode_single(text_escaped: str, expected: str) -> None:
        actual, _ = decode(text_escaped)
        assert actual == expected

    def test_decode_multiple(text_list: list, expected_list: list) -> None:
        for text_escaped, expected in zip(text_list, expected_list):
            actual, _ = decode(text_escaped)
            assert actual == expected

    # Test a single character
    test_decode_single(b'\\x20', ' ')
    test_decode_single(b'\\x61', 'a')
    test_decode_single(b'\\x62', 'b')
    test_decode_single(b'\\x63', 'c')

# Generated at 2022-06-23 17:56:14.016822
# Unit test for function encode
def test_encode():
    """

    Returns:

    """

    # The test string.
    test_str = '\u1061'

    # The expected bytes.
    expected_bytes = b'\\xE1\\x81\\xA1'

    # Convert the test string into utf-8 bytes.
    test_bytes = test_str.encode('utf-8')

    # Convert the test utf-8 bytes into a string of escaped hexadecimal.
    out_bytes, len_out_bytes = encode(test_bytes)

    # Raise an exception if the output is not equal to the expected bytes.
    assert len_out_bytes == len(test_bytes)
    assert expected_bytes == out_bytes



# Generated at 2022-06-23 17:56:17.641342
# Unit test for function encode
def test_encode():
    text_example = '\\xC3\\xBC'
    utf8_hex_text = encode(text_example)[0]  # type: ignore
    assert utf8_hex_text == b'\\\\xC3\\\\xBC'



# Generated at 2022-06-23 17:56:19.831500
# Unit test for function decode
def test_decode():
    from .regtest import assert_equal

    assert_equal(decode('M\\xC3\\xA9\\x6Dico'), 'Médico')



# Generated at 2022-06-23 17:56:27.198946
# Unit test for function decode
def test_decode():
    assert decode(b'\\xC2\\xA2;') == ('¢', 5)
    assert decode(b'\\xC2\\xA2\\xE2\\x82\\xAC;') == ('¢€;', 11)
    assert decode(b'\\xE2\\x82\\xAC;') == ('€;', 7)
    assert decode(b'\\xE2\\x82\\xAC') == ('€', 6)



# Generated at 2022-06-23 17:56:35.978371
# Unit test for function encode
def test_encode():
    assert encode('a') == (b'a', 1)
    assert encode('\n') == (b'\\xa', 1)
    assert encode('\\') == (b'\\\\', 1)
    assert encode('\\a') == (b'\\a', 2)
    assert encode('abc') == (b'a\\b\\c', 3)
    assert encode('\\x61') == (b'\\61', 3)
    assert encode('\\x61\\x62\\x63') == (b'\\61\\62\\63', 9)
    assert encode('\\u0061') == (b'\\61', 6)
    assert encode('\\u0061\\u0062\\u0063') == (b'\\61\\62\\63', 18)
    assert encode('\\U00000061') == (b'\\61', 10)
   

# Generated at 2022-06-23 17:56:46.107463
# Unit test for function encode
def test_encode():
    assert encode('a') == (b'a', 1)
    assert encode('a\\x6') == (b'a\\x6', 3)
    assert encode('a\\x61') == (b'a\\x61', 4)
    assert encode('a\\x61\\x62') == (b'a\\x61\\x62', 7)
    assert encode('a\\x61\\x62\\x63') == (b'a\\x61\\x62\\x63', 10)
    assert encode('a\\x61\\x62\\x63\\x64') == (b'a\\x61\\x62\\x63\\x64', 13)

# Generated at 2022-06-23 17:56:52.010488
# Unit test for function decode
def test_decode():
    assert decode(b'\\x73\\x74\\x72\\x69\\x6e\\x67') == ('string', 6)
    assert decode(b'\\xe2\\x9d\\xa4\\xf0\\x9f\\x92\\xa9') == ('💩', 4)
    assert decode(b'\\xe5\\x8a\\x9b\\xe5\\x90\\x8d\\xe4\\xba\\xba') == ('力名人', 4)


# Generated at 2022-06-23 17:56:59.262666
# Unit test for function encode
def test_encode():
    assert encode('a') == (b'a', 1)
    assert encode('aé') == (b'a\\xc3\\xa9', 2)
    assert encode('a\\x00') == (b'a\\x00', 3)
    assert encode('a\\x00é') == (b'a\\x00\\xc3\\xa9', 5)
    assert encode('a\\x00\\x00') == (b'a\\x00\\x00', 5)
    assert encode('\\x00') == (b'\\x00', 3)
    assert encode('\\x00\\x00') == (b'\\x00\\x00', 5)



# Generated at 2022-06-23 17:57:11.486891
# Unit test for function decode
def test_decode():
    assert decode(b'\\x61')[0] == 'a'
    assert decode(b'\\x61')[1] == 4

    assert decode(b'ABC')[0] == 'ABC'
    assert decode(b'ABC')[1] == 3

    assert decode(b'\\xe2\\x82\\xac')[0] == '€'
    assert decode(b'\\xe2\\x82\\xac')[1] == 9

    assert decode(
        b'\\xe2\\x82\\xac is a symbol for "\\x45\\x75\\x72\\x6f" (euro)'
    )[0] == '€ is a symbol for "EURO" (euro)'

# Generated at 2022-06-23 17:57:20.384274
# Unit test for function encode
def test_encode():
    text = 'some ascii text 123 !@#$%^&*'
    out, consumed = encode(text)
    assert consumed == len(text)
    assert out == b'some ascii text 123 !@#$%^&*'

    text = 'some ascii text 123 !@#$%^&*\u00f1'
    out, consumed = encode(text)
    assert consumed == len(text)
    assert out == b'some ascii text 123 !@#$%^&*\\xc3\\xb1'

    # Test with a UserString
    from UserString import UserString

    text = UserString(text)
    out, consumed = encode(text)
    assert consumed == len(text)
    assert out == b'some ascii text 123 !@#$%^&*\\xc3\\xb1'

# Generated at 2022-06-23 17:57:23.452818
# Unit test for function encode
def test_encode():
    """
    >>> test_encode()
    >>> print('Привет')
    Привет
    """



# Generated at 2022-06-23 17:57:33.358862
# Unit test for function encode
def test_encode():
    assert encode('hello') == (b'hello', 5)
    assert encode('hello\\xE2\\x82\\xAC') == (b'hello\\xe2\\x82\\xac', 17)
    assert encode('hello\\x80') == (b'hello\\xc2\\x80', 9)
    assert encode('\\xC2') == (b'\\x00', 5)
    assert encode('\\u2345') == (b'\\xe2\\x8d\\x85', 7)
    assert encode('\\U00012345') == (b'\\xf0\\x92\\x8d\\x85', 11)
    assert encode('\\U00100000') == (b'\\xf4\\x80\\x80\\x80', 11)

# Generated at 2022-06-23 17:57:43.188076
# Unit test for function encode
def test_encode():
    s = 'Hello World'
    expected_bytes = b'Hello World'
    expected_length = len(expected_bytes)

    # Convert
    test_bytes, test_length = encode(s)

    assert(expected_bytes == test_bytes)
    assert(expected_length == test_length)

    # Convert
    s = '你好'
    expected_bytes = b'\\xe4\\xbd\\xa0\\xe5\\xa5\\xbd'
    expected_length = len(expected_bytes)

    test_bytes, test_length = encode(s)

    assert(expected_bytes == test_bytes)
    assert(expected_length == test_length)

    # Convert
    s = '\\xe4\\xbd\\xa0\\xe5\\xa5\\xbd'

# Generated at 2022-06-23 17:57:54.502531
# Unit test for function decode
def test_decode():
    """Unit test for function decode."""
    # Valid utf8 hexadecimal input.
    INPUT = '☺'
    # UTF8 Hexadecimal bytes representation of '☺'
    OUTPUT = '\\xe2\\x98\\xba'

    # Input string into bytes.
    input_bytes = INPUT.encode()

    # Convert the bytes into escaped hexadecimal.
    escaped_hexadecimal_bytes = encode(input_bytes)[0]

    # Convert the escaped hexadecimal bytes into a string.
    out_str = escaped_hexadecimal_bytes.decode('utf-8')

    # Get the escaped hexadecimal bytes from the output.
    assert out_str == OUTPUT



# Generated at 2022-06-23 17:58:07.120452
# Unit test for function encode
def test_encode():
    # Test 1
    text = ('\u03a9'
            ' \\u1d306'
            ' \\U0001d306'
            ' \\xFF'
            )
    text_out = b'\\u03a9 \\u1d306 \\u1d306 \\xFF'
    text_out_len = text.__len__()
    text_out_bytes, text_out_len_out = encode(text)
    assert text_out_bytes == text_out
    assert text_out_len == text_out_len_out

    # Test 2
    text = ('\u03a9'
            ' \\u1d306'
            ' \\U0001d306'
            ' \\xFF'
            )

# Generated at 2022-06-23 17:58:14.923075
# Unit test for function encode
def test_encode():

    result = encode('a')
    assert result == (b'a', 1)

    result = encode('你好，世界。')
    assert result == (b'\\xe4\\xbd\\xa0\\xe5\\xa5\\xbd\\xef\\xbc\\x8c\\xe4\\xb8\\x96\\xe7\\x95\\x8c\\xe3\\x80\\x82', 10)

    result = encode('你好，世界。', 'replace')
    assert result == (b'\\xe4\\xbd\\xa0\\xe5\\xa5\\xbd\\xef\\xbc\\x8c\\xe4\\xb8\\x96\\xe7\\x95\\x8c\\xe3\\x80\\x82', 10)

    result = encode

# Generated at 2022-06-23 17:58:27.256157
# Unit test for function encode
def test_encode():
    """
    Test function encode
    """
    # Test normal bytes
    test_bytes = b"abcdefghijklmnopqrstuvwxyz123456789"
    test_bytes_escaped_hex = b"\\61\\62\\63\\64\\65\\66\\67\\68\\69\\6a\\6b\\6c\\6d\\6e\\6f\\70\\71\\72\\73\\74\\75\\76\\77\\78\\79\\7a\\31\\32\\33\\34\\35\\36\\37\\38\\39"
    [out_bytes, out_num_chars] = encode(test_bytes)
    assert out_bytes == test_bytes_escaped_hex
    assert out_num_chars == 36

    # Test extended ascii

# Generated at 2022-06-23 17:58:31.255572
# Unit test for function register
def test_register():
    # noinspection PyPep8Naming
    # noinspection PyUnusedLocal
    def test_register_helper(name_input: str):
        codecs.register(_get_codec_info)

    test_register_helper(NAME)
    test_register_helper(NAME)



# Generated at 2022-06-23 17:58:41.470438
# Unit test for function encode
def test_encode():
    assert encode('hello', 'strict') == (b'hello', 5)
    assert encode('hello\nworld') == (b'hello\\a\\nworld', 11)
    assert encode('hello\tworld') == (b'hello\\t\\world', 11)
    assert encode('hello\xef\xbe\xad\xde') == (
        b'hello\\xef\\xbe\\xad\\xde', 9
    )
    assert encode('hello\xef\xbe\xad\xde') == (
        b'hello\\xef\\xbe\\xad\\xde', 9
    )
    assert encode(u'hello\xef\xbe\xad\xde') == (
        b'hello\\xef\\xbe\\xad\\xde', 9
    )

# Generated at 2022-06-23 17:58:50.298837
# Unit test for function register
def test_register():
    # This unit test only serves as a canary test for function
    # _get_codec_info. _get_codec_info is called directly by this
    # canary test function.
    codec_info = codecs.CodecInfo(  # type: ignore
        name=NAME,
        encode=encode,  # type: ignore[arg-type]
        decode=decode,  # type: ignore[arg-type]
    )
    assert _get_codec_info(NAME) == codec_info

if __name__ == '__main__':
    register()

# Generated at 2022-06-23 17:58:54.351443
# Unit test for function decode
def test_decode():
    assert decode(b'foo') == ('foo', 3)
    assert decode(b'foo\\u0042bar') == ('foobar', 10)



# Generated at 2022-06-23 17:59:03.572234
# Unit test for function decode
def test_decode():
    from nose.tools import assert_equal
    from nose.tools import assert_in
    from nose.tools import assert_raises
    from nose.tools import assert_true

    test_case = (
        (b'abc', 'abc'),
        (b'\\x41Bc', 'ABc'),
        (b'\\x41\\x42\\x43', 'ABC'),
        (b'\\x41\\x42\\x43', 'ABC'),
        (b'\\x41\\x42\\x43', 'ABC'),
        (b'\\x41\\x42\\x43', 'ABC'),
        (b'\\x41\\x42\\x43', 'ABC'),
    )

    for case in test_case:
        data_bytes, out_str = case
        result = decode(data_bytes)
        assert_

# Generated at 2022-06-23 17:59:13.145162
# Unit test for function decode
def test_decode():

    # Test that the 'eutf8h' codec decodes a single byte utf8 character
    # that maps to a character that requires 1 byte.
    utf8_byte_1_byte = bytes([ord('A')])
    result = decode(utf8_byte_1_byte)
    assert result == ('A', 1)

    # Test that the 'eutf8h' codec decodes multiple bytes utf8 character
    # that maps to a character that requires 2 bytes.
    utf8_byte_2_bytes = bytes([0xC3, 0x80])
    result = decode(utf8_byte_2_bytes)
    assert result == ('À', 2)

    # Test that the 'eutf8h' codec decodes multiple bytes utf8 character
    # that maps to a character that requires 3 bytes.
    utf

# Generated at 2022-06-23 17:59:17.620419
# Unit test for function encode
def test_encode():
    """
    Unit test for function encode
    """
    # Given
    given_text = '\u0121'
    given_errors = 'strict'
    expected = (b'\\0c\\xa1', 2)

    # When
    actual = encode(given_text, given_errors)

    # Then
    assert actual == expected



# Generated at 2022-06-23 17:59:26.715130
# Unit test for function encode
def test_encode():
    output = encode('Hello World')[0]
    expected_output = b'\\x48\\x65\\x6c\\x6c\\x6f\\x20\\x57\\x6f\\x72\\x6c\\x64'
    assert output == expected_output

    output = encode('A\u263A')[0]
    expected_output = b'\\x41\\xe2\\x98\\xba'
    assert output == expected_output

    output = encode("\u2713")[0]
    expected_output = b'\\xe2\\x9c\\x93'
    assert output == expected_output



# Generated at 2022-06-23 17:59:35.034752
# Unit test for function decode
def test_decode():
    assert decode(b'\\x41')[0] == 'A'
    assert decode(b'\\x41')[1] == 4
    assert decode(b'\\x41', 'ignore')[0] == ''
    assert decode(b'\\x41', 'replace')[0] == '\ufffd'
    assert decode(b'\\x41', 'strict')[0] == 'A'
    assert decode(b'\\x41', 'xmlcharrefreplace')[0] == '&#65;'
    assert decode(b'\\x41', 'backslashreplace')[0] == '\\x41'
    assert decode(b'\\x41', 'namereplace')[0] == '\\N{LATIN CAPITAL LETTER A}'

# Generated at 2022-06-23 17:59:40.997452
# Unit test for function decode
def test_decode():
    assert decode(b'\x41') == ('A', 1)
    assert decode(b'\\x41') == ('A', 4)
    assert decode(b'\\x41\\x41') == ('AA', 7)
    assert decode(b'\\x41\\x41\\x41') == ('AAA', 10)
    assert decode(b'\\x41\\x41\\x41\\x41') == ('AAAA', 13)
    
    assert decode(b'\x41\x41\x41\x41') == ('AAAA', 4)
    assert decode(b'1\\x41\\x41\\x41\\x41') == ('1AAAA', 9)
    assert decode(b'1\\x41\\x41\\x41\\x41\\x41') == ('1AAAAA', 10)

# Generated at 2022-06-23 17:59:52.591702
# Unit test for function encode
def test_encode():
    for text in [
        r'\xff',
        r'\u003c',
        r'\U0001F407',
        r'\x00\x01\x02\x03\x04\x05\x06\x07',
        r'\x08\t\n\x0b\x0c\r\x0e\x0f',
        r'\x10\x11\x12\x13\x14\x15\x16\x17',
        r'\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f',
    ]:
        encoded: Tuple[bytes, int] = encode(text)
        expected: str = text.encode('utf-8').decode('unicode_escape')
       

# Generated at 2022-06-23 18:00:05.053769
# Unit test for function encode
def test_encode():
    # noinspection SpellCheckingInspection
    val = 'value'
    sb = bytes(val.encode('utf-8'))

    # noinspection PyTypeChecker
    expected = (
        b'\\x76\\x61\\x6c\\x75\\x65',
        5
    )
    assert encode(val) == expected

    # noinspection PyTypeChecker
    expected = (
        b'\\xEF\\xBF\\xBD\\xEF\\xBF\\xBD',
        5
    )
    assert encode('\ufffd\ufffd') == expected

    # noinspection PyTypeChecker
    expected = (
        b'\\xEF\\xBF\\xBD',
        1
    )
    assert encode('\ufffd') == expected

    # noinspection PyTypeChecker

# Generated at 2022-06-23 18:00:15.148801
# Unit test for function decode
def test_decode():
    assert decode(b'B\\xc3\\x93\\xc5\\x9f\\xc3\\x9c') == ('BÓŞÜ', 15)
    assert decode(b'B\\xc3\\x93\\xc5\\x9f\\xc3\\x9c', 'ignore') == ('BO', 15)
    assert decode(b'B\\xc3\\x93\\xc5\\x9f\\xc3\\x9c', 'replace') == ('BÓŞÜ', 15)
    assert decode(b'A\\xE1\\xBD\\xB8\\xCE\\xB9') == ('Ωι', 10)
    assert decode(b'A\\xE1\\xBD\\xB8\\xCE\\xB9', 'ignore') == ('A', 10)

# Generated at 2022-06-23 18:00:22.612139
# Unit test for function register
def test_register():
    from codecs import lookup
    # Before the register function is called,
    #   the codec must not be found.
    try:
        lookup(NAME)
        assert False, 'Codec must not be registered yet.'
    except LookupError:
        pass
    register()
    # After the register function is called,
    #   the codec must be found.
    try:
        codecs.lookup(NAME)
    except LookupError as e:
        assert False, 'Codec must be registered now.'
        print(e)


# Generated at 2022-06-23 18:00:32.736106
# Unit test for function encode
def test_encode():
    assert encode('\\xC3\\xA1b\\xC3\\xA9c') == b'\\xC3\\xA1b\\xC3\\xA9c'
    assert encode('\\xC3\\xA1b\\xC3\\xA9c', 'ignore') == b'\\xC3\\xA1b\\xE9'
    assert encode('\\xC3\\xA1b\\xC3\\xA9c', 'replace') == b'\\xC3\\xA1b\\xEF\\xBF\\xBD'
    assert encode('\\xC3\\xA1b\\xC3\\xA9c', 'strict') == b'\\xC3\\xA1b\\xC3\\xA9c'

# Generated at 2022-06-23 18:00:35.747750
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME) == encode
    assert codecs.getdecoder(NAME) == decode


# Generated at 2022-06-23 18:00:37.251266
# Unit test for function register
def test_register():
    if _get_codec_info(NAME) is not None:
        register()

# Generated at 2022-06-23 18:00:46.586749
# Unit test for function decode
def test_decode():
    # noinspection PyArgumentList
    data_bytes_input = '\\xe3\\x81\\x82\\xe3\\x81\\x84\\xe3\\x81\\x86'.encode(NAME)
    expected_str = 'あいう'
    expected_int = 21
    actual_str, actual_int = codecs.decode(data_bytes_input, NAME)
    if actual_str != expected_str:
        raise ValueError('DID NOT MATCH')
    if actual_int != expected_int:
        raise ValueError('DID NOT MATCH')
    return None



# Generated at 2022-06-23 18:00:54.174215
# Unit test for function register
def test_register():
    # This should not throw an exception.
    register()


if __name__ == '__main__':

    # Register a new encoding scheme called 'eutf8h'.
    register()

    # Encode a string with invalid utf8 characters.
    data, count = codecs.getencoder(NAME)(
        r'\x81\x82',
        'strict'
    )  # type: ignore[arg-type]

    # Decode the resulting hexadecimal bytes.
    text, count = codecs.getdecoder(NAME)(
        data,
        'strict'
    )  # type: ignore[arg-type]

    # The text should be the same as the original.
    assert r'\x81\x82' == text

    # Re-encode the text, which should raise an error.
   

# Generated at 2022-06-23 18:01:02.350669
# Unit test for function encode
def test_encode():
    text_input = 'abcdefghijklmnopqrstuvwxyz0123456789'
    text_bytes = codecs.escape_decode(text_input)[0]
    out = encode(text_input)
    assert out == (text_bytes, 36)
    text_input = '\x1b3\x1b3\x1b3'
    out = encode(text_input)
    assert out == (b'\\1b3\\1b3\\1b3', 6)
    text_input = '\x1b'
    out = encode(text_input)
    assert out == (b'\\1b', 2)
    text_input = '\x1b'
    out = encode(text_input, 'replace')
    assert out == (b'?', 2)
    text

# Generated at 2022-06-23 18:01:11.152527
# Unit test for function decode
def test_decode():
    assert decode('\\xc3\\xbc') == 'ü'
    assert decode('\\xc3\\xbc', 'strict') == 'ü'
    assert decode(b'\\xc3\\xbc', 'strict') == 'ü'
    assert decode(b'\\xc3\\xbc') == 'ü'
    assert decode(bytearray([92, 99, 51, 92, 120, 99, 51])) == 'ü'
    assert decode(bytearray([92, 99, 51, 92, 120, 99, 51, 92, 120, 99, 51])) == 'ü\u202f'



# Generated at 2022-06-23 18:01:23.254856
# Unit test for function encode
def test_encode():
    assert encode('abc') == (b'abc', 3)
    assert encode('abc\\xE2\\x80\\x99') == (b'abc\xe2\x80\x99', 12)
    assert encode('\\xE2\\x80\\x99') == (b'\xe2\x80\x99', 9)
    assert encode('\\xE2\\x80') == (b'\xe2\x80', 7)

# Generated at 2022-06-23 18:01:29.748293
# Unit test for function encode
def test_encode():
    text_str = ''.join(
        [
            '\\x61',  # a
            '\\x62',  # b
            '\\x63',  # c
        ]
    )
    text_bytes1 = cast(bytes, b'abc')
    text_bytes2, _ = encode(text_str)
    assert text_bytes1 == text_bytes2



# Generated at 2022-06-23 18:01:40.485395
# Unit test for function decode
def test_decode():
    assert decode(b'\\x65\\x73\\x5f\\x74\\x68\\x69\\x73') == ('es_this', 7)
    assert decode(b'\\x65\\x73\\x5F\\x74\\x68\\x69\\x73') == ('es_this', 7)
    assert decode(b'\\x65\\x73\\x74\\x68\\x69\\x73') == ('esthis', 6)
    assert decode(b'\\x65\\x73\\x74\\x68\\x69', errors='ignore') == ('es', 4)
    assert decode(b'\\x65\\x73\\x74\\x68\\x69') == ('esthi', 5)

# Generated at 2022-06-23 18:01:40.960816
# Unit test for function encode
def test_encode():
    pass

# Generated at 2022-06-23 18:01:51.615754
# Unit test for function decode
def test_decode():
    # Unit test would go here
    if __name__ == '__main__':
        import sys
        if 2 < len(sys.argv) < 5:
            decode_bytes = sys.argv[1].encode('utf8')
            decode_errors = sys.argv[2]
            decode_result = decode(decode_bytes, decode_errors)
            print('returned: %s %d' % decode_result)
            print('expected: %s %d' % (sys.argv[3], int(sys.argv[4])))
        else:
            print('Usage: python -m %s bytes errors expected expected_length' % (NAME,))
            exit(2)



# Generated at 2022-06-23 18:01:53.188277
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    test_register()


# vim: set ts=4 sw=4 expandtab:

# Generated at 2022-06-23 18:01:55.443116
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

register()


# Generated at 2022-06-23 18:02:03.846333
# Unit test for function encode
def test_encode():
    text = 'x'
    expected = b'x'
    actual = encode(text)[0]
    assert expected == actual

    text = 'x\x80'
    expected_bytes = b'x\\x80'
    actual_bytes = encode(text)[0]
    assert expected_bytes == actual_bytes

    text = '\\x80'
    expected = b'\\x80'
    actual = encode(text)[0]
    assert expected == actual

    text = '\\x80\\x00\\x01'
    expected_bytes = b'\\x80\\x00\\x01'
    actual_bytes = encode(text)[0]
    assert expected_bytes == actual_bytes

    text = '\\x80\\x00\\x01\\x7F'

# Generated at 2022-06-23 18:02:07.288272
# Unit test for function decode
def test_decode():
    """Unit test for function ``decode``."""
    print(decode(b'\\x41\\x42\\x43\\x64'))



# Generated at 2022-06-23 18:02:08.268831
# Unit test for function register
def test_register(): pass



# Generated at 2022-06-23 18:02:10.243492
# Unit test for function register
def test_register():
    # noinspection PyProtectedMember
    codecs.lookup(NAME)



# Generated at 2022-06-23 18:02:17.109746
# Unit test for function encode
def test_encode():
    import unittest
    from .test_data import TEST_DATA

    class TestEncode(unittest.TestCase):
        def test_encode(self):

            for in_str, in_errors, out_bytes, out_offset in TEST_DATA:
                with self.subTest(
                    # in_str=in_str,
                    in_str=in_str,
                    in_errors=in_errors,
                    out_bytes=out_bytes,
                    out_offset=out_offset,
                ):
                    result_bytes, result_offset = encode(in_str, in_errors)
                    self.assertEqual(result_bytes, out_bytes)
                    self.assertEqual(result_offset, out_offset)

    return TestEncode



# Generated at 2022-06-23 18:02:21.793371
# Unit test for function encode
def test_encode():
    assert encode('hello') == b'hello'
    assert encode('你好') == b'\\xe4\\xbd\\xa0\\xe5\\xa5\\xbd'
    assert encode('\n') == b'\\n'
    assert encode('\\xab') == b'\\\\xab'



# Generated at 2022-06-23 18:02:31.200389
# Unit test for function decode
def test_decode():
    # Happy path
    text_bytes = bytes()
    text_bytes += b'\xE3\x81\x93\xE3\x82\x93\xE3\x81\xAB'
    text_bytes += b'\xE3\x81\xA1\xE3\x82\x87\xE3\x81\x86\xE3\x81\x94'
    text_bytes += b'\xE3\x81\x8F\xE3\x81\x91\xE3\x81\xA8\xE3\x81\x8D'

# Generated at 2022-06-23 18:02:37.350888
# Unit test for function register
def test_register():
    """Test that the codec is registered."""
    register()
    codec_info = codecs.getdecoder(NAME)   # type: ignore
    assert codec_info.name == NAME
    assert codec_info.encode == encode
    assert codec_info.decode == decode

#     import pycodestyle
# pycodestyle.main(['--statistics', '--count', 'eutf8h.py'])

# Generated at 2022-06-23 18:02:39.681072
# Unit test for function decode
def test_decode():
    print(decode('\\x41'))
    print(decode('\\u0041'))
    print(decode('\\U00000041'))



# Generated at 2022-06-23 18:02:42.047620
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)
    return

# Generated at 2022-06-23 18:02:43.546990
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore

# Generated at 2022-06-23 18:02:50.669720
# Unit test for function encode
def test_encode():
    # assert encode('A') == b'A', encode('A')
    # assert encode('A\\x41') == b'A\\x41', encode('A\\x41')
    # assert encode('\\x41') == b'A', encode('\\x41')
    # assert encode('\\x41A') == b'A\\x41', encode('\\x41A')
    # assert encode('\\x41\\x41') == b'\\x41\\x41', encode('\\x41\\x41')
    # assert encode('testing') == b'testing', encode('testing')
    assert encode('\\x80') == b'\\xc2\\x80', encode('\\x80')
    assert encode('\\x80A') == b'\\xc2\\x80A', encode('\\x80A')

# Generated at 2022-06-23 18:02:52.297833
# Unit test for function register
def test_register():
    """Test function register"""
    register()


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 18:03:03.840280
# Unit test for function encode
def test_encode():
    assert (encode('\0') == (b'\\0', 1))
    assert (encode('\u1234\u5678') == (b'\\xe1\\x88\\xb4\\xe5\\x99\\xb8', 2))
    assert (encode('a\u1234\u5678b') == (b'a\\xe1\\x88\\xb4\\xe5\\x99\\xb8b', 3))

    # This should not raise an exception
    assert (encode(
        '\\xFF',
        errors='ignore'
    ) == (b'\\xff', 1))

    # This should not raise an exception
    assert (encode(
        '\\xZ',
        errors='ignore'
    ) == (b'\\xz', 1))

    # This should not raise an exception

# Generated at 2022-06-23 18:03:11.144701
# Unit test for function encode
def test_encode():
    # Test 1
    input_str = 'abc123'
    expected_str = b'abc123'
    actual_str, count_str = encode(input_str)
    assert actual_str == expected_str
    assert count_str == 6

    # Test 2
    input_str = '\xFF\xF0\x00'
    expected_str = b'\\xFF\\xF0\\x00'
    actual_str, count_str = encode(input_str)
    assert actual_str == expected_str
    assert count_str == 4

    # Test 3
    input_str = '\\xFF\\xF0\\x00'
    expected_str = b'\\xFF\\xF0\\x00'
    actual_str, count_str = encode(input_str)
    assert actual_str

# Generated at 2022-06-23 18:03:23.069739
# Unit test for function decode

# Generated at 2022-06-23 18:03:30.627382
# Unit test for function decode
def test_decode():
    """unit test for function decode(
            data: _ByteString,
            errors: _Str = 'strict'
        ) -> Tuple[str, int]:
    """

# Generated at 2022-06-23 18:03:39.705379
# Unit test for function decode
def test_decode():
    # Test cases for error checking
    t1 = '\\x80'
    _, n1 = decode(t1, 'strict')
    assert n1 == 2
    try:
        _, n2 = decode(t1, 'surrogateescape')
        assert False
    except UnicodeDecodeError:
        assert True
    try:
        _, n3 = decode(t1, 'replace')
        assert False
    except UnicodeDecodeError:
        assert True
    try:
        _, n4 = decode(t1, 'backslashreplace')
        assert False
    except UnicodeDecodeError:
        assert True
    try:
        _, n5 = decode(t1, 'ignore')
        assert False
    except UnicodeDecodeError:
        assert True
    # Test cases for the actual decoding
    t2

# Generated at 2022-06-23 18:03:42.919709
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        assert codecs.getdecoder(NAME)



# Generated at 2022-06-23 18:03:51.220522
# Unit test for function decode
def test_decode():
    print("Unit test for function decode")
    d1 = b'QQ\\xe7\\x8c\\x9b\\xe5\\x9c\\x93\\xe6\\x95\\x99\\xe8\\x82\\xb2\\xe5\\xa4\\xa7\\xe5\\xad\\xa6'
    d2 = b'\\xe6\\x95\\x99\\xe8\\x82\\xb2\\xe5\\xa4\\xa7\\xe5\\xad\\xa6\\xe5\\x8d\\xa1'
    d3 = b'\\xe6\\x95\\x99\\xe8\\x82\\xb2\\xe5\\xa4\\xa7\\xe5\\xad\\xa6'
    d4 = b'\\x2a\\x2a\\x2a'

# Generated at 2022-06-23 18:04:01.770723
# Unit test for function decode
def test_decode():
    """
    Unit test for function decode().
    """
    import unittest
    import unittest.mock
    from typing import Callable

    # Create a mock codecs.register so that the codec info is not
    # actually registered. Also, when the codec info is registered,
    # we do not get the correct codec info, because of the mock.
    # So, for these tests, the codec will not be registered.
    @unittest.mock.patch('esccodes.eutf8h.codecs.register', unittest.mock.Mock())
    class TestESCUTF8hCodec(unittest.TestCase):

        def setUp(self) -> None:
            self.data = b''

        def tearDown(self) -> None:
            self.data = b''


# Generated at 2022-06-23 18:04:05.108740
# Unit test for function register
def test_register():
    def is_registered(name: str) -> bool:
        try:
            return codecs.lookup(name) is not None
        except LookupError:
            return False

    assert is_registered(NAME)
    codecs.unregister(NAME)
    assert not is_registered(NAME)
    register()
    assert is_registered(NAME)



# Generated at 2022-06-23 18:04:12.405671
# Unit test for function encode
def test_encode():
    assert encode('A') == (b'A', 1)
    assert encode('@') == (b'@', 1)
    assert encode('\n') == (b'\\0a', 1)
    assert encode('𐌀') == (b'\\xf0908080', 1)
    assert encode('𐌀𐌁𐌂𐌃') == (
        b'\\xf0908080\\xf0908081\\xf0908082\\xf0908083',
        4,
    )

# Generated at 2022-06-23 18:04:16.888312
# Unit test for function decode
def test_decode():
    assert decode(br'\x6f\x6c\x6c\x6f\x20\x77\x6f\x72\x6c\x64') \
        == ('hello world', 10)



# Generated at 2022-06-23 18:04:25.395468
# Unit test for function encode
def test_encode():
    assert encode('\\x00\\x01') == (b'\\x00\\x01', 8)
    assert encode('\\x00\\x01', 'ignore') == (b'\\x00\\x01', 8)
    assert encode('\\x00\\x01', 'replace') == (b'\\x00\\x01', 8)
    assert encode('\\x00\\x01', 'surrogateescape') == (b'\\x00\\x01', 8)
    assert encode('\\x00\\x01', 'backslashreplace') == (b'\\x00\\x01', 8)
    assert encode('\\x00\\x01', 'xmlcharrefreplace') == (b'\\x00\\x01', 8)

# Generated at 2022-06-23 18:04:27.598571
# Unit test for function decode
def test_decode():
    try:
        import pytest
    except ImportError:
        raise SystemExit(
            'Please install pytest: pip3 install pytest --user'
        )
    else:
        pytest.main([__file__])
    return



# Generated at 2022-06-23 18:04:38.280439
# Unit test for function decode
def test_decode():
    """Routine to test the use of the decode function"""
    value = decode(b'\\x78\\x79\\x7A')
    assert value[0] == 'xyz'
    assert value[1] == 3
    try:
        decode(b'\\x78\\x79\\x7')
    except UnicodeDecodeError:
        print('Failed to decode b\'\\x78\\x79\\x7\'')

    try:
        decode(b'\\x78\\x79\\x')
    except UnicodeDecodeError:
        print('Failed to decode b\'\\x78\\x79\\x\'')

    try:
        decode(b'\\x78\\x79')
    except UnicodeDecodeError:
        print('Failed to decode b\'\\x78\\x79\'')


# Generated at 2022-06-23 18:04:50.344083
# Unit test for function decode
def test_decode():
    assert decode(b'\\xe2\\x99\\xa5') == ('\u2665', 10)
    assert decode(b'\\xe2\\x99\\xa5\\xe2\\x99\\xa5') == ('\u2665\u2665', 20)
    assert decode(b'\\xe2\\x99\\xa5\\xe2\\x99\\xa5\\n') == ('\u2665\u2665\n', 21)
    assert decode(b'\\xe2\\x99\\xa5\\xe2\\x99\\xa5\\n', 'ignore') == ('\u2665\u2665\n', 21)
    assert decode(b'\\xe2\\x99\\xa5\\xe2\\x99\\xa5\\n', 'replace') == ('\u2665\ufffd\n', 21)


# Generated at 2022-06-23 18:05:03.197708
# Unit test for function encode
def test_encode():
    # return codecs.getdecoder(NAME)
    # codecs.register(_get_codec_info)   # type: ignore

    text = "HelloWorld"
    out_bytes, _ = encode(text)
    assert out_bytes == b'HelloWorld'

    text = "HelloWorldÇ"
    out_bytes, _ = encode(text)
    assert out_bytes == b'HelloWorld\\xc7'

    # text = "\x0f\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19"
    # out_bytes, _ = encode(text)
    # print(out_bytes)
    # assert out_bytes == b'\\x0f\\x10\\x11\\x12\\x13\\x14\\x15\\x16\\

# Generated at 2022-06-23 18:05:10.342382
# Unit test for function decode
def test_decode():
    # Test that decode can process input strings which normalize
    # characters to a single representation.
    assert decode(b'\\xce\\xb1\\xcc\\x81') == ('ά', 8)
    assert decode(b'\\xce\\x03') == ('\\xce\\x03', 4)
    assert decode(b'\\xce') == ('\\xce', 2)
    assert decode(b'\\x') == ('\\x', 0)

    # Test that encode can proccess input strings which have characters
    # that have multiple representations.
    assert encode('ά') == (b'\\xce\\xb1\\xcc\\x81', 2)

# Generated at 2022-06-23 18:05:15.076098
# Unit test for function encode
def test_encode():
    text_str = '\\xefABC'
    text_bytes = codecs.escape_decode(text_str)[0]
    assert text_str == encode(text_bytes)[0].decode('utf-8')

    text_str = 'ABC\\xef'
    text_bytes = codecs.escape_decode(text_str)[0]
    assert text_str == encode(text_bytes)[0].decode('utf-8')

    text_str = '\\xef\\xef'
    text_bytes = codecs.escape_decode(text_str)[0]
    assert text_str == encode(text_bytes)[0].decode('utf-8')

    text_str = '\\xef\\x30'
    text_bytes = codecs.escape_decode(text_str)[0]
   

# Generated at 2022-06-23 18:05:25.602657
# Unit test for function register
def test_register():
    import io
    import sys

    register()
    try:
        sys.stdout.write('\u263a')
    except UnicodeEncodeError:
        print(
            '\033[31;1m'
            'UnicodeEncodeError raised'
            '\033[0m'
        )
    sys.stdout = io.TextIOWrapper(
        sys.stdout.buffer,
        encoding='eutf8h'
    )
    #sys.stdout = io.TextIOWrapper(
    #    sys.stdout.buffer,
    #    encoding='eutf8h',
    #    errors='surrogateescape',
    #)
    sys.stdout.write('\u263a')
    print()


if __name__ == '__main__':
    test_register

# Generated at 2022-06-23 18:05:36.027054
# Unit test for function decode
def test_decode():
    assert decode(b'\\317\\202\\305\\241\\x41\\304\\207', 'strict') == ('한국어', 20)
    assert decode(b'\\317\\202\\305\\241\\x41\\304\\207', 'replace') == ('한국어', 20)
    assert decode(b'\\317\\202\\305\\241\\x41\\304\\207', 'ignore') == ('한국어', 20)
    assert decode(b'\\317\\202\\305\\241\\x41', 'strict') == ('한국', 15)
    assert decode(b'\\317\\202\\305\\241\\x41', 'replace') == ('한국', 15)

# Generated at 2022-06-23 18:05:37.853899
# Unit test for function decode
def test_decode():
    assert decode(b'\\xC3\\xA4\\x69') == ('äi', 5)



# Generated at 2022-06-23 18:05:39.518440
# Unit test for function register
def test_register():
    register()

    # Check that the codec was registered.
    codecs.getdecoder(NAME)



# Generated at 2022-06-23 18:05:41.504166
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore
    codecs.getdecoder(NAME)


# Generated at 2022-06-23 18:05:47.736019
# Unit test for function encode
def test_encode():
    out = encode('abc\u5256', 'strict')
    assert out == (b'abc\\u5256', 7)
    out = encode('abc\u5256', 'ignore')
    assert out == (b'abc', 3)
    out = encode('abc\u5256', 'replace')
    assert out == (b'abc?', 3)

    out = encode('abc\\x00\\x01', 'replace')
    assert out == (b'abc?', 11)
    out = encode('abc\\x00\\x01', 'ignore')
    assert out == (b'abc', 3)

