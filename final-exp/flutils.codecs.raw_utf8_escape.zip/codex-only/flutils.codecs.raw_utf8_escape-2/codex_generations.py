

# Generated at 2022-06-23 17:55:56.688443
# Unit test for function encode
def test_encode():
    """Test the encode function"""

    # Test 1
    in_str = '\\x48\\x65\\x6C\\x6C\\x6F\\x20\\x57\\x6F\\x72\\x6C\\x64\\x21'
    expected_out_bytes = b'\\x48\\x65\\x6C\\x6C\\x6F\\x20\\x57\\x6F\\x72\\x6C\\x64\\x21'
    expected_num_chars = len(expected_out_bytes)
    if bytes != type(expected_out_bytes):
        raise AssertionError('test_encode: 1: '
                             'bytes type expected, but it was not found')

# Generated at 2022-06-23 17:55:57.812328
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 17:56:09.428570
# Unit test for function encode
def test_encode():
    text = ('chào mừng đến với python\n'
            '"中国"\n'
            '"\\u4e2d\\u56fd"\n'
            '"\\u4e2du56fd"\n'
            '"\\uFFFD"')

# Generated at 2022-06-23 17:56:16.590224
# Unit test for function encode
def test_encode():
    input_text = 'a'
    bytes_expected = b'a'
    output_bytes, output_len = encode(input_text)
    if bytes_expected != output_bytes or output_len != 1:
        raise Exception('Test for function encode failed.')

    input_text = 'abcdefg'
    bytes_expected = b'abcdefg'
    output_bytes, output_len = encode(input_text)
    if bytes_expected != output_bytes or output_len != 7:
        raise Exception('Test for function encode failed.')

    input_text = '\x80'
    bytes_expected = b'\\xc2\\x80'
    output_bytes, output_len = encode(input_text)

# Generated at 2022-06-23 17:56:17.808268
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME)



# Generated at 2022-06-23 17:56:24.397235
# Unit test for function register
def test_register():
    from sys import modules as sys_modules
    from sys import stderr, stdout

    register()
    try:
        module_name = __name__.split('.')[-1]
        codecs.getdecoder(module_name)
        print(
            f'\nFunction {module_name}.register() has been tested.',
            end='\n...\n',
            file=stdout,
        )
        print(
            f'The module {module_name} has been registered.',
            end='\n...\n',
            file=stdout,
        )
    except LookupError:
        print(
            f'\nFunction {module_name}.register() has been tested.',
            end='\n...\n',
            file=stderr,
        )

# Generated at 2022-06-23 17:56:26.210825
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)



# Generated at 2022-06-23 17:56:27.839304
# Unit test for function register
def test_register():
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 17:56:36.338432
# Unit test for function register
def test_register():
    register()
    # noinspection PyUnresolvedReferences
    assert codecs.getdecoder(NAME) is not None


if __name__ == '__main__':
    # Unit test for function encode
    def test_encode():
        text = '$'
        assert text == '$'

# Generated at 2022-06-23 17:56:46.188775
# Unit test for function encode
def test_encode():
    assert encode('abc') == (b'abc', 3)
    assert encode('abc\x00') == (b'abc\\x00', 5)
    assert encode('abc\x7f') == (b'abc\\x7f', 5)
    assert encode('abc\x80') == (b'abc\\xc2\\x80', 7)
    assert encode('abc\xff') == (b'abc\\xc3\\xbf', 7)
    assert encode('abc\u0100') == (b'abc\\xc4\\x80', 7)
    assert encode('abc\uffff') == (b'abc\\xef\\xbf\\xbf', 9)
    assert encode('abc\U00010000') == (b'abc\\xf0\\x90\\x80\\x80', 11)

# Generated at 2022-06-23 17:56:53.728751
# Unit test for function register
def test_register():
    import os
    import doctest
    # a. Test the register function itself
    codecs.register(_get_codec_info)
    # b. Test this module using the doctest module
    current_path = os.path.dirname(__file__)
    test_file_name = os.path.join(current_path, 'eutf8h.py')
    with open(test_file_name) as fh:
        doctest.testmod(
            # module='eutf8h',
            module=fh,
            optionflags=doctest.ELLIPSIS,
        )

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 17:57:01.861606
# Unit test for function decode

# Generated at 2022-06-23 17:57:14.412261
# Unit test for function encode
def test_encode():
    text = 'abc'
    assert text == decode(encode(text)[0])[0]

    text = 'abc\u0100'
    assert text == decode(encode(text)[0])[0]

    text = 'abc\\xff'
    assert text == decode(encode(text)[0])[0]

    try:
        decode(encode('abc\\xFF')[0])
    except UnicodeEncodeError:
        pass
    else:
        raise Exception('Should have seen UnicodeEncodeError')

    try:
        decode(encode('abc\\x1a')[0])
    except UnicodeEncodeError:
        pass
    else:
        raise Exception('Should have seen UnicodeEncodeError')


# Generated at 2022-06-23 17:57:20.482437
# Unit test for function encode
def test_encode():
    assert encode(
        text='Iñtërnâtiônàlizætiøn',
        errors='strict'
    ) == (
        b'I\\xc3\\xb1t\\xc3\\xabrn\\xc3\\xa2ti\\xc3\\xb4n\\xc3\\xa0'
        b'liz\\xc3\\xa6ti\\xc3\\xb8n',
        26
    )



# Generated at 2022-06-23 17:57:30.875318
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)


if __name__ == '__main__':
    import sys
    import argparse

    parser = argparse.ArgumentParser(
        description=('Convert an escaped utf8 hexadecimal string or bytes to'
                     ' a bytes or string.')
    )
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument(
        '--string',
        type=str,
        metavar='escaped-utf8-hex-string',
        help=('The escaped utf8 hexadecimal string to convert.')
    )

# Generated at 2022-06-23 17:57:37.034730
# Unit test for function decode
def test_decode():
    data = b'\\xC2\\xA2'
    out, consumed = decode(data)
    assert consumed == 4
    assert out == '¢'

    data = b'\\x20\\x20'
    out, consumed = decode(data)
    assert consumed == 4
    assert out == '  '

    data = b'\\x20\\x20\\xC2\\xA2'
    out, consumed = decode(data)
    assert consumed == 8
    assert out == '  ¢'



# Generated at 2022-06-23 17:57:38.705383
# Unit test for function encode
def test_encode():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:57:46.424619
# Unit test for function encode
def test_encode():
    good_strs = [
        'Good morning, teachers!',
        'That\'s a nice cup of ねこ. \\u3042\r\n',
        'Test \\u3042 testing.',
    ]

    for good_str in good_strs:
        print('*** Unit test for function encode() ***')
        encoded: bytes
        encoded, _ = encode(good_str)
        try:
            decoded: str
            decoded, _ = codecs.decode(encoded, 'utf-8')
        except UnicodeDecodeError as error:
            (_, end_offset, _) = error.args
            print('At byte offset %r of byte string:' % end_offset)
            print(repr(good_str))
            print(repr(encoded[:end_offset]))
            end_

# Generated at 2022-06-23 17:57:50.985023
# Unit test for function encode
def test_encode():
    assert encode("Hello, world!") == (b'Hello, world!', 13)
    assert encode("Hello, world!") == (b'Hello, world!', 13)
    assert encode("🧣") == (b'\\xf0\\x9f\\xa7\\xa3', 1)
    assert encode("🧣") == (b'\\xf0\\x9f\\xa7\\xa3', 1)
    assert encode("🧣") == (b'\\xf0\\x9f\\xa7\\xa3', 1)
    assert encode("🧣") == (b'\\xf0\\x9f\\xa7\\xa3', 1)
    assert encode("🧣") == (b'\\xf0\\x9f\\xa7\\xa3', 1)

# Generated at 2022-06-23 17:57:54.250402
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        codecs.lookup_error(NAME)

    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-23 17:57:57.151594
# Unit test for function register
def test_register():
    register()
    assert isinstance(codecs.getencoder(NAME), codecs.CodecInfo)
    assert isinstance(codecs.getdecoder(NAME), codecs.CodecInfo)

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 17:58:08.742748
# Unit test for function decode
def test_decode():
    assert decode(b"\\u00E9") == ('é', 5)
    assert decode(b"\\xFF") == ('ÿ', 4)
    assert decode(b"abc\\u00E9\\xFF") == ('abcéÿ', 13)
    assert decode(b"\\u00E9\\xFF", errors="ignore") == ('', 5)
    assert decode(b"\\u00E9\\xFF\\xFF", errors="ignore") == ('ÿ', 9)
    assert decode(b"\\u00E9\\xFF", errors="replace") == ('é�', 5)
    assert decode(b"\\u00E9\\xFF", errors="surrogateescape") == ('é\xFF', 5)
    assert decode(b"\\u00E9\\xFF", errors="xmlcharrefreplace")

# Generated at 2022-06-23 17:58:20.493563
# Unit test for function encode
def test_encode():
    assert encode("A") == (b'\\x41', 1)
    assert encode("A\n\t") == (b'\\x41\\xa0\\x9', 3)
    assert encode("A\u1234") == (b'\\x41\\xe1\\x88\\xb4', 3)
    assert encode("A\U00010203") == (b'\\x41\\xf0\\x90\\x81\\x83', 5)
    assert encode("A\u1234\U00010203") == (b'\\x41\\xe1\\x88\\xb4\\xf0\\x90\\x81\\x83', 7)

# Generated at 2022-06-23 17:58:31.347320
# Unit test for function encode
def test_encode():
    assert encode('\n') == b"\\n"
    assert encode('123') == b"123"
    assert encode('\xC2\xA2') == b"\\xc2\\xa2"
    assert encode('\u00A2') == b"\\xc2\\xa2"
    assert encode('\u00A9') == b"\\xc2\\xa9"
    assert encode('\U0001F61D') == b"\\xf0\\x9f\\x98\\x9d"
    assert encode('"\U0001F61D"') == b'\\"\\xf0\\x9f\\x98\\x9d\\"'

# Generated at 2022-06-23 17:58:37.334276
# Unit test for function decode
def test_decode():
    assert decode(b'a') == ('a', 1)
    assert decode(b'\\x61') == ('a', 4)
    assert decode(b'\\xe4\\xbd\\xa0') == ('你', 9)
    assert decode(b'\\xe4\\xbd\\xa0') == ('你', 9)
    assert decode(b'\\xe4\\xbd\\xa0\\x5f\\x6d\\x6f\\x6f\\x6f') == ('你_mo̲o̲o̲', 25)



# Generated at 2022-06-23 17:58:40.836154
# Unit test for function register
def test_register():
    register()
    # Convert the given 'text', that are of type UserString into a str.
    # if isinstance(text, UserString):
    #     text_input = str(text)
    # else:


# Generated at 2022-06-23 17:58:43.218702
# Unit test for function decode
def test_decode():
    assert decode(b"\\x0A\\x22\\x42\\x0A\\x22\\x42") == ("\n\"B\n\"B", 18)



# Generated at 2022-06-23 17:58:45.531796
# Unit test for function decode
def test_decode():
    data = b'\\x62\\x61\\x72'
    out, length = decode(data)
    assert out == 'bar'
    assert length == len(data)


# Generated at 2022-06-23 17:58:52.555210
# Unit test for function encode
def test_encode():
    # Test valid input with no error handling
    #
    # Input: "abc\0xab\0xcd"
    # Input: "\0x61\0x62\0x63\0xab\0xcd"
    # Output: b'\\x61\\x62\\x63\\xab\\xcd'
    #
    text = 'abc\xab\xcd'
    text1 = '\x61\x62\x63\xab\xcd'
    out_bytes = encode(text)
    out_bytes1 = encode(text1)
    assert out_bytes == out_bytes1

    # Test valid input with strict error handling
    #
    # Input: "abc\0xab\0xcd"
    # Input: "\0x61\0x62\0x63\0xab\

# Generated at 2022-06-23 17:58:58.289974
# Unit test for function encode
def test_encode():
    """Test function _encode()."""

    def _test_encode_helper(
            text: str,
            errors: str,
            out_bytes: bytes,
            char_count: int
    ) -> None:
        """Helper function for method test_encode"""

        text_bytes, text_count = encode(text, errors)

        if text_bytes != out_bytes:
            raise AssertionError(
                'Invalid text_bytes. '
                'Expected: %s, Actual: %s' % (
                    repr(out_bytes),
                    repr(text_bytes),
                )
            )


# Generated at 2022-06-23 17:59:03.790463
# Unit test for function encode
def test_encode():
    # Unit test for function encode
    assert encode('Hello, world!') == (b'Hello,\\x20world!', 13)
    assert encode('\x00\x01\x02\x03\x04\x05\x06\x07') == (b'\\x00\\x01\\x02\\x03\\x04\\x05\\x06\\x07', 8)
    assert encode('\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f') == (b'\\x08\\x09\\x0a\\x0b\\x0c\\x0d\\x0e\\x0f', 8)

# Generated at 2022-06-23 17:59:07.400885
# Unit test for function encode
def test_encode():
    txt = 'a   b'
    expected = rb'a\\x20\\x20b'
    actual = encode(txt)
    assert actual == expected


# Generated at 2022-06-23 17:59:14.564901
# Unit test for function decode

# Generated at 2022-06-23 17:59:24.291808
# Unit test for function decode
def test_decode():
    assert decode(b'abc')[0] == 'abc'

    assert decode(b'\x41')[0] == 'A'

    assert decode(b'\\x41')[0] == 'A'

    assert decode(b'\\xc2\\x84')[0] == '\u0084'

    assert decode(b'\\xe2\\x80\\x84')[0] == '\u204A'

    # Invalid UTF-8 bytes

# Generated at 2022-06-23 17:59:28.095672
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    assert codecs.lookup(__name__.split('.')[-1])
    assert codecs.lookup(NAME)


# Generated at 2022-06-23 17:59:35.695869
# Unit test for function encode
def test_encode():
    assert encode('%', 'strict') == (b'\\x25', 1)
    assert encode('%', 'replace') == (b'\\x25', 1)
    assert encode('%', 'ignore') == (b'', 1)
    assert encode('A%A', 'strict') == (b'A\\x25A', 3)
    assert encode('A%A', 'replace') == (b'A\\x25A', 3)
    assert encode('A%A', 'ignore') == (b'AA', 3)
    assert encode('ab', 'strict') == (b'\\x61\\x62', 2)
    assert encode('ab', 'replace') == (b'\\x61\\x62', 2)
    assert encode('ab', 'ignore') == (b'', 2)

# Generated at 2022-06-23 17:59:36.656786
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)

# Generated at 2022-06-23 17:59:37.409606
# Unit test for function encode
def test_encode():  # noqa
    pass

# Generated at 2022-06-23 17:59:49.461609
# Unit test for function decode
def test_decode():
    output = '\\x61\\x62\\x63'
    data = b'abc'
    text, consume_count = decode(data)
    assert text == output
    assert consume_count == len(output)

    data = b'\\x61\\x62\\x63'
    text, consume_count = decode(data)
    assert text == output
    assert consume_count == len(output)

    output = '\\x61\\x62\\x63\\x64'
    data = b'abcd\\x65'
    text, consume_count = decode(data)
    assert text == output
    assert consume_count == len(output)

    output = '\\x61\\x62\\x63\\x64'
    data = b'\\x61bcd\\x65\\'

# Generated at 2022-06-23 17:59:51.486660
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise



# Generated at 2022-06-23 17:59:56.255580
# Unit test for function decode
def test_decode():
    decode_input = '\\xE6\\x97\\xA5\\xE6\\x9C\\xAC\\xE8\\xAA\\x9E'
    decode_expected = '日本語'
    decode_tuple = decode(decode_input)
    decode_output = decode_tuple[0]
    assert decode_expected == decode_output


# Generated at 2022-06-23 17:59:58.508752
# Unit test for function register
def test_register():
    _ = register


# noinspection PyMissingTypeHints

# Generated at 2022-06-23 18:00:08.206837
# Unit test for function encode
def test_encode():
    assert b'\\x42\\62\\x62\\x33\\x32' == encode('Bbb32')
    assert b'\\x42\\xe2\\x82\\xac\\x62\\x33\\x32' == encode('B€b32')
    assert b'\\x42\\xe2\\x82\\xac\\x62\\x33\\x32\\x42' == encode('B€b32B')
    assert b'\\x42\\xe2\\x82\\xac\\x62\\x33\\x32\\x42' == encode('B\\xe2\\x82\\xacb32B')
    assert b'\\x42\\xe2\\x82\\xac\\x62\\x33\\x32\\x42' == encode('B\\xE2\\x82\\xACb32B')
    assert b

# Generated at 2022-06-23 18:00:13.659851
# Unit test for function register
def test_register():

    # codecs.lookup('locale.iso2022_jp')  # type: ignore

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(
            f'codecs.getdecoder({NAME}) should raise a LookupError'
        )

    register()

    assert codecs.getdecoder(NAME)  # type: ignore



# Generated at 2022-06-23 18:00:18.024878
# Unit test for function decode
def test_decode():
    data = b'\\xf0\\x9f\\x92\\xa9\\x61'
    expected_value = '👩a'
    expected_description = 'utf-8'
    actual_value, actual_description = decode(data)
    assert actual_value == expected_value
    assert actual_description == expected_description
    # Do nothing if the codec has already been registered.
    register()


# Generated at 2022-06-23 18:00:25.786748
# Unit test for function encode
def test_encode():
    print("Testing encode...")
    # Test 1: Test a string that contains characters that can be interpreted
    #         by the codec
    #         Expected output: b"\\xc3\\x98stland\\xc3\\xa5"
    input = "Østlandå"
    result = encode(input)
    assert result[0] == b"\\xc3\\x98stland\\xc3\\xa5"
    # Test 2: Test a string that contains characters that cannot be interpreted
    #         by the codec
    #         Expected output: b"\\xc3\\x98stland\\xc3\\xa5\\xe2\\x80\\x9c"
    input = "Østlandå“"
    result = encode(input)

# Generated at 2022-06-23 18:00:27.524241
# Unit test for function decode
def test_decode():
    assert decode(b'\\xC2\\xA9')[0] == '©'



# Generated at 2022-06-23 18:00:30.717256
# Unit test for function decode
def test_decode():
    tests = (
        (b'\\u\\x41', 'A'),
        (b'\\u\\xC3\\x84', 'Ä'),
    )
    for data_input, expected in tests:
        actual = decode(data_input)[0]
        assert actual == expected



# Generated at 2022-06-23 18:00:35.037927
# Unit test for function register
def test_register():
    """Test for function register"""
    register()
    assert codecs.getencoder(NAME)
    assert codecs.getdecoder(NAME)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 18:00:40.850119
# Unit test for function register
def test_register():
    # type: () -> None

    assert NAME not in codecs.__dict__

    register()
    assert NAME in codecs.__dict__

    # Confirm that dictionary entry is an object of class CodecInfo
    codec = codecs.__dict__[NAME]
    assert isinstance(codec, codecs.CodecInfo)



# Generated at 2022-06-23 18:00:49.963389
# Unit test for function decode
def test_decode():
    def _set_up():
        class codecspy:  # type: ignore
            def decode(self, data, errors='strict'):  # type: ignore
                return '', 0

        codecs.getdecoder = codecspy().decode

    _set_up()
    # noinspection PyUnresolvedReferences
    assert b'\x41'.decode('eutf8h') == ''
    assert b'\\x41'.decode('eutf8h') == ''
    assert b'\\x41\\x42'.decode('eutf8h') == ''
    assert b'\\x41\\x42\\x43'.decode('eutf8h') == ''



# Generated at 2022-06-23 18:00:56.141614
# Unit test for function register
def test_register():
    """Test the register function."""
    register()
    assert NAME in codecs.__all__
    try:
        codecs.register(_get_codec_info)
    except LookupError:
        pass
    else:
        assert False, "This register() function should raise a LookupError"

# Generated at 2022-06-23 18:00:59.795926
# Unit test for function decode
def test_decode():
    data = b'\\x65\\x6e\\x63\\x6f\\x64\\x65\\x20\\x70\\x6f\\x6f\\x72'
    exp = 'encode pooor'
    assert decode(data)[0] == exp

# Generated at 2022-06-23 18:01:08.284747
# Unit test for function decode
def test_decode():
    assert decode(b'\x41\xE2\x89\xA2\xCE\x91\x2E') == ('A≢Α.', 7)
    assert decode(b'\x41\xE2\x89\xA2\xCE\x91.') \
        == ('A≢Α.', 7)
    assert decode(b'\x41\xE2\x89\xA2\xCE\x91') \
        == ('A≢Α', 6)
    assert decode(b'\x41\xE2\x89\xA2\xCE') \
        == ('A≢', 5)
    assert decode(b'\x41\xE2\x89\xA2') \
        == ('A≢', 4)
    assert decode

# Generated at 2022-06-23 18:01:13.451105
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)
    else:
        raise AssertionError('Codec not registered')

    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 18:01:20.330830
# Unit test for function decode
def test_decode():
    decoded = decode(b'\\xC2\\xA2\\xC2\\xA3')
    assert decoded[0] == '¢£'
    assert decoded[1] == 8
    try:
        decoded = decode(b'\\xC2\\xA2\\xC2\\xA')
    except UnicodeDecodeError as e:
        assert e.reason == 'truncated data'


# Generated at 2022-06-23 18:01:21.674474
# Unit test for function encode
def test_encode():
    import unittest
    unittest.main(module='test_eutf8h', exit=False)

# Generated at 2022-06-23 18:01:30.851547
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    from sys import argv, stdin
    try:
        text = stdin.readline()
        if argv[1] == 'e':
            encoded_data, _ = encode(text)
            stdout.write(encoded_data)
        elif argv[1] == 'd':
            decoded_data, _ = decode(text)
            stdout.write(decoded_data)
    except Exception as e:
        stderr.write(str(e))
        exit(1)

# Generated at 2022-06-23 18:01:34.536831
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)   # type: ignore
    codecs.getencoder(NAME)   # type: ignore
    codecs.lookup(NAME)   # type: ignore



# Generated at 2022-06-23 18:01:38.536346
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
        assert False
    except LookupError:
        pass
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False


# Generated at 2022-06-23 18:01:46.980134
# Unit test for function decode
def test_decode():
    test_cases = (
        # This is an example from the RFC
        [
            b'\\x65',
            'e',
        ],
        [
            # This is one of the examples from the RFC
            b'\\xff\\x55\\x3c',
            '\xffU<'
        ],
        # This is a test case added by the author.
        [
            b'\\x62\\x61\\x6e\\x61\\x6e\\x61',
            'banana'
        ]
    )

    for test_case in test_cases:
        data = test_case[0]
        expected = test_case[1]

# Generated at 2022-06-23 18:01:49.268897
# Unit test for function decode
def test_decode():
    result = decode("\\xc3\\xbf")
    assert result == ("ÿ", 7)


if __name__ == '__main__':
    test_decode()

# Generated at 2022-06-23 18:01:52.993651
# Unit test for function register
def test_register():
    """

    Returns:

    """
    register()
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 18:02:02.538212
# Unit test for function encode
def test_encode():
    input_text = 'Hello\\x21 World\\x21\\n'
    expected_bytes = b'Hello\\x21 World\\x21\\n'
    assert encode(input_text)[0] == expected_bytes
    assert encode(input_text)[1] == len(input_text)

    input_text = 'Hello World'
    expected = b'Hello World'
    assert encode(input_text)[0] == expected
    assert encode(input_text)[1] == len(input_text)

    input_text = '\\x41\\x42\\x43\\u00E0\\u00E1\\u00E2\\u00E3\\u00E4\\u00E5'

# Generated at 2022-06-23 18:02:14.302086
# Unit test for function encode
def test_encode():

    # Test 1: Basic test.
    actual = codecs.encode(
        '© 2020, Novartis',  # © → \xC2\xA9
        'eutf8h',
    )
    expected = b'\\xC2\\xA9 2020, Novartis'
    assert actual == expected

    # Test 2: Test that the Unicode string '©' (hexadecimal 0xC2A9),
    # is correctly encoded using the 'eutf8' codec.
    actual = codecs.encode(
        '\u00A9',  # © → \u00A9
        'eutf8h',
    )
    expected = b'\\xC2\\xA9'
    assert actual == expected

    # Test 3: Test that the Unicode string '©'
    # is still encoded with

# Generated at 2022-06-23 18:02:24.007875
# Unit test for function encode
def test_encode():
    """Tests the function `encode` with various inputs and outputs."""
    # Test string with no utf8 hexadecimal (expected to pass)
    str_in = 'Hello world!'
    assert encode(str_in) == (b'Hello world!', 12)

    # Test string with utf8 hexadecimal for a single byte character
    str_in = '\\x42'
    assert encode(str_in) == (b'\x42', 5)

    # Test string with utf8 hexadecimal for a multi byte character
    str_in = '\\xE2\\x82\\xAC'
    assert encode(str_in) == (b'\xE2\x82\xAC', 15)

    # Test string with utf8 hexadecimal that is invalid

# Generated at 2022-06-23 18:02:27.609041
# Unit test for function encode
def test_encode():
    text = '\\u00FF'
    assert encode(text) == (b'\\xC3\\xBF', 5)

    text = '\\u00FF \\\\xFF'
    assert encode(text) == (b'\\xC3\\xBF \\xFF', 12)

# Generated at 2022-06-23 18:02:30.002560
# Unit test for function encode
def test_encode():
    print(encode("\x00\x01\x02\x03\x04\x05\x06\x07"))



# Generated at 2022-06-23 18:02:35.980401
# Unit test for function decode
def test_decode():

    data = b'\\xe3\\x81\\x93\\xe3\\x82\\x93\\xe3\\x81\\xab\\xe3\\x81\\xa1\\xe3\\x81\\xaf'

    out, count = decode(data)

    assert out == 'こんにちは'
    assert count == len(data)



# Generated at 2022-06-23 18:02:47.325734
# Unit test for function encode
def test_encode():
    text_input_1 = r'\\x60'
    text_input_2 = r'\\x60\\x7e\\x7f'
    text_input_3 = r'\\xC0'
    text_input_4 = r'\\xEF\\xBF\\xBF'

    for text_input in (
            text_input_1,
            text_input_2,
            text_input_3,
            text_input_4,
    ):
        data = text_input.encode('utf-8')
        text, _ = encode(text_input, 'strict')
        assert text == data

        text, _ = encode(text_input, 'ignore')
        assert text == data

        text, _ = encode(text_input, 'replace')
        assert text == data

        text, _ = encode

# Generated at 2022-06-23 18:02:57.337310
# Unit test for function decode
def test_decode():
    decoded_str = decode(b'Testing\\x20one two three four five')
    assert decoded_str[0] == 'Testing one two three four five'
    decoded_str = decode(b'Testing\\x20one\\x20two\\x20three\\x20four\\x20five')
    assert decoded_str[0] =='Testing one two three four five'
    decoded_str = decode(b'Testing \\x20one \\x20two \\x20three \\x20four \\x20five')
    assert decoded_str[0] == 'Testing  one  two  three  four  five'
    decoded_str = decode(b'Testing\\x20one three five')
    assert decoded_str[0] == 'Testing one three five'

# Generated at 2022-06-23 18:02:59.704744
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-23 18:03:06.394167
# Unit test for function register
def test_register():
    # Coverage doesn't include return at the end of the funciton
    # unless this assert is added.
    assert _get_codec_info is not None
    register()
    assert _get_codec_info is not None
    def __test_register_exception():
        try:
            global NAME
            NAME = 'fake_encoding_name'
            register()
        except:
            pass
        else:
            assert False, "Expected an exception"
    # Coverage doesn't include this except clause unless the
    # except clause is called.
    __test_register_exception()



# Generated at 2022-06-23 18:03:15.165529
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)  # type: ignore
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        raise AssertionError(f'Failed to register {NAME}') from e

    # Cleanup
    codecs.register(None)   # type: ignore



# Generated at 2022-06-23 18:03:26.175977
# Unit test for function encode
def test_encode():
    text = 'hello world'
    out_bytes, size = encode(text)
    assert out_bytes == text.encode('ascii'), \
        'encode("hello world") != "hello world".encode("ascii")'
    assert size == 11, 'size of output wrong'

    text = '東方project'
    out_bytes, size = encode(text)
    assert out_bytes == '\\e6\\9d\\b1\\e6\\96\\b9project'.encode('ascii'), \
        'encode("東方project") != \\e6\\9d\\b1\\e6\\96\\b9project'
    assert size == 4, 'size of output wrong'

    text = '\\xe6\\x9d\\xb1\\xe6\\x96\\xb9project'


# Generated at 2022-06-23 18:03:31.541635
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)
    assert codecs.getdecoder(NAME) is not None


__all__ = (
    'encode',
    'decode',
    'NAME',
    'register',
)

# Generated at 2022-06-23 18:03:40.218069
# Unit test for function decode

# Generated at 2022-06-23 18:03:49.640853
# Unit test for function encode
def test_encode():
    # Test 1
    str_input = 'Hello World'
    str_output = 'Hello World'
    tuple_output = encode(str_input)
    str_output_repr = repr(str_output.encode('utf-8'))
    tuple_output_repr = repr(tuple_output)
    assert str_output_repr == tuple_output_repr,\
        'Failed to encode simple string'

    # Test 2
    str_input = b'Hello World'
    str_output = 'Hello World'
    tuple_output = encode(str_input)
    str_output_repr = repr(str_output.encode('utf-8'))
    tuple_output_repr = repr(tuple_output)

# Generated at 2022-06-23 18:03:57.894854
# Unit test for function register
def test_register():

    # Test that the codec is registered
    # Test Case 1:
    codecs.register(_get_codec_info)
    # Test Case 2:
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise Exception('The codec is not registered')
    # Test Case 3:
    # codecs.codec_error: unregistering already registered codec 'eutf8h'
    try:
        codecs.unregister(NAME)
    except Exception:
        pass


# Generated at 2022-06-23 18:03:58.931490
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-23 18:04:09.146155
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)  # type: ignore
        assert False, \
            'This function should not run, it is a unit test.'
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
        codecs.getdecoder(NAME)  # type: ignore


try:
    codecs.getdecoder(NAME)  # type: ignore
except LookupError:
    codecs.register(_get_codec_info)   # type: ignore

test_register.test_name = 'test_register'



# Generated at 2022-06-23 18:04:20.901410
# Unit test for function decode
def test_decode():
    """Test the function decode"""

    def _test_decode(func, data: _ByteString, errors: _Str = 'strict') -> \
            Tuple[str, int]:
        return func(data, errors)

    assert _test_decode(decode, b'The quick brown fox\\x20jumps over the'
                                 b'\\x20lazy dog') == \
           ('The quick brown fox jumps over the lazy dog', 56)

    # Test that the function decode properly converts a string of
    # utf8 hexadecimal.
    assert _test_decode(decode, b'\\x41\\x42\\x43') == ('ABC', 6)

    # Test that the function decode properly decodes an empty string.
    assert _test_decode(decode, b'') == ('', 0)

   

# Generated at 2022-06-23 18:04:23.457460
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore



# Generated at 2022-06-23 18:04:25.424412
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getdecoder('eutf8h')



# Generated at 2022-06-23 18:04:36.398782
# Unit test for function encode
def test_encode():
    assert encode('abc') == (b'abc', 3)
    assert encode('abc\\xef\\xbb\\xbfxyz') == (b'abc\xef\xbb\xbfxyz', 11)
    assert encode('안녕') == (b'\\xec\\x95\\x88\\xeb\\x85\\x95', 6)
    assert encode('한글') == (b'\\xed\\x95\\x9c\\xea\\xb8\\x80', 6)
    assert encode('\\xed\\x95\\x9c\\xea\\xb8\\x80') == (b'\\xed\\x95\\x9c\\xea\\xb8\\x80', 12)
    assert encode('') == (b'', 0)


test_encode()




# Generated at 2022-06-23 18:04:39.555945
# Unit test for function register
def test_register():
    register()
    assert NAME not in codecs.getencoders()
    assert NAME in codecs.getdecoders()


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 18:04:51.640613
# Unit test for function decode
def test_decode():
    test1 = b'h\\xe4\\x9f\\xbf\\xf8\\x91\\x92\\x93\\x94\\x95\\x96\\x97\\x98\\x99\\x9a\\x9b'  # noqa: E501
    test2 = b'h\\xe4\\x9f\\xbf\\xf8\\x91\\x92\\x93\\x94\\x95\\x96\\x97\\x98\\x99\\x9a\\x9b\\x9c'  # noqa: E501
    test3 = b'\\xe4\\x9f\\xbf\\xf8\\x91\\x92\\x93\\x94\\x95\\x96\\x97\\x98\\x99\\x9a\\x9b\\x9c'  # noqa: E501


# Generated at 2022-06-23 18:05:03.836710
# Unit test for function encode
def test_encode():
    # Test type UserString
    test_input = UserString('\\x41\\x80')
    test_expected = b'\\x41\\x80'
    test_result = encode(test_input, errors='strict')
    assert test_expected == test_result[0]
    assert len(test_input) == test_result[1]

    # Test type str
    test_input = '\\x41\\x80'
    test_expected = b'\\x41\\x80'
    test_result = encode(test_input, errors='strict')
    assert test_expected == test_result[0]
    assert len(test_input) == test_result[1]

    # Test bytes input
    test_input = '\\x80'
    test_expected = b'\\xc2\\x80'
    test

# Generated at 2022-06-23 18:05:10.709432
# Unit test for function encode
def test_encode():
    assert(encode('\u007f') == (b'\\x7f', 1))
    assert(encode('\u0080') == (b'\\xc2\\x80', 1))
    assert(encode('\u2713') == (b'\\xe2\\x9c\\x93', 1))
    assert(encode('\ud800\udc00') == (b'\\xf0\\x90\\x80\\x80', 2))
    assert(encode('1\u2713') == (b'1\\xe2\\x9c\\x93', 2))
    assert(encode('1\u2713') == (b'1\\xe2\\x9c\\x93', 2))

# Generated at 2022-06-23 18:05:14.205241
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
        raise AssertionError('Codec should not be registered')
    except LookupError:
        return
    raise AssertionError('LookupError should be raised')



# Generated at 2022-06-23 18:05:21.412479
# Unit test for function decode
def test_decode():
    assert decode(b'\\x68\\x65\\x6c\\x6c\\x6f\\x20\\x77\\x6f\\x72\\x6c\\x64') == ('hello world',
        11)
    assert decode(b'\\xe4\\xbd\\xa0\\xe5\\xa5\\xbd') == ('你好', 5)
    assert decode(b'\\xf0\\x90\\x8d\\x8c\\xf0\\x90\\x8c\\x80') == ('𐍈𐌀', 8)
    assert decode(b'\\xc3\\xa9\\xc3\\xaa\\xc3\\xab\\xc3\\xac') == ('éêëî', 8)

# Generated at 2022-06-23 18:05:29.614539
# Unit test for function decode
def test_decode():
    # Assert that correct output occurs for correct input.
    assert decode(b'Hello World') == ('Hello World', 11)

    # Assert that correct output occurs for correct input with
    # escaped hexadecimal '\\xHH'
    assert decode(b'\\x41\\x42\\x43') == ('ABC', 9)

    # Assert that correct output occurs for correct input with
    # escaped hexadecimal '\\xHH' that references different
    # numbers of bytes.
    assert decode(b'\\x41\\xC3\\xB1') == ('Añ', 9)

    # Assert that exception occurs for incorrect input with
    # escaped hexadecimal '\\xHH' that references invalid bytes.

# Generated at 2022-06-23 18:05:38.776534
# Unit test for function decode
def test_decode():
    print('\n\nTest function "decode"...')

    # Decode a string of escaped utf8 hex characters, and print the resulting string.
    str_in = u'\\x0D\\x0A'    # \x0D\x0A or CR LF
    print(f'In:  {str_in}')
    str_out, _ = decode(str_in)
    print(f'Out: {str_out}')

    # Decode a string of escaped utf8 hex characters that has invalid utf8 bytes.
    # With the default errors='strict', this raises a UnicodeDecodeError.
    str_in = u'\\x0D\\x1A'    # \x0D\x1A or CR SUB
    print(f'In:  {str_in}')
    str_out

# Generated at 2022-06-23 18:05:45.502666
# Unit test for function encode
def test_encode():
    # Test the encode function with a given string
    text_input = 'h\\xe9llo\n'
    expected_bytes = b'h\\xe9llo\\n'
    expected_len = 6
    
    actual_bytes, actual_len = encode(text_input)
    assert actual_bytes == expected_bytes
    assert actual_len == expected_len

    # Test the encode function with a given string
    text_input = 'h\\\\xe9llo'
    expected_bytes = b'h\\\\xe9llo'
    expected_len = 8
    
    actual_bytes, actual_len = encode(text_input)
    assert actual_bytes == expected_bytes
    assert actual_len == expected_len

    # Test the encode function with a given string & error for invalid escaped sequence