

# Generated at 2022-06-23 17:55:57.115130
# Unit test for function encode
def test_encode():
    assert b'h\\xe2\\x98\\x8e\\x0a' == encode('\x68\u260E\x0A')
    assert b'hello\\x0a' == encode('hello\x0A')
    assert b'\\x0a' == encode('\x0A')
    assert b'\\x0a' == encode(u'\x0A')
    assert b'\\x0a' == encode(b'\x0A')
    assert b'' == encode('')
    assert b'' == encode(u'')
    assert b'' == encode(b'')
    assert b'hello\\x0a' == encode(u'hello\x0A')
    assert b'hello\\x0a' == encode(b'hello\x0A')

# Generated at 2022-06-23 17:56:04.547295
# Unit test for function decode
def test_decode():
    assert decode(b'\\x63')[0] == "c"
    assert decode(b'\\x63', errors="ignore")[0] == ""
    assert decode(b'\\x63', errors="replace")[0] == "�"
    assert decode(b'\\x63', errors="strict")[0] == "c"
    assert decode(b'\\x63', errors="namereplace")[0] == "c"
    assert decode(b'\\x63', errors="xmlcharrefreplace")[0] == "c"
    assert decode(b'\\x63', errors="surrogateescape")[0] == "c"
    assert decode(b'\\x63', errors="backslashreplace")[0] == "c"
    assert decode(b'\\x63', errors="strict")[0]

# Generated at 2022-06-23 17:56:08.899995
# Unit test for function decode
def test_decode():
    data_bytes = b'\\xE2\\x98\\x83'
    errors = 'strict'
    actual = decode(data_bytes, errors)
    excepted_str = '☃'
    excepted_consumed_bytes = 3
    assert actual == (excepted_str, excepted_consumed_bytes)



# Generated at 2022-06-23 17:56:18.898989
# Unit test for function register
def test_register():
    import json
    import sys
    import test.support

    # Test for the existence of utf-8 hexadecimal codec.
    codecs.getdecoder(NAME)

    # Test that the unicode_escape codec can encode and decode
    # escaped utf8 hexadecimal bytes.
    text = 'Hello, こんにちは。'
    text_bytes_utf8 = text.encode('utf-8')
    text_str_hex_escaped = text_bytes_utf8.decode('unicode_escape')
    text_bytes_hex_escaped = text_str_hex_escaped.encode('latin1')
    text_bytes_utf8_2 = text_bytes_hex_escaped.decode('utf-8')
    text_2 = text_bytes_utf8_2


# Generated at 2022-06-23 17:56:24.888508
# Unit test for function decode
def test_decode():
    assert decode(b'\\xC3\\xA9hello\\x20world') == ('éhello world', 20)
    assert decode(b'\\xC3\\xA9hello\\x20world', errors='strict') == ('éhello world', 20)
    assert decode(b'\\xC3\\xA9hello\\x20world', errors='replace') == ('�hello world', 20)
    assert decode(b'\\xC3\\xA9hello\\x20world', errors='ignore') == ('hello world', 20)
    assert decode(b'\\xC3\\xA9hello\\x20world\\xFF') == ('éhello world', 20)
    assert decode(b'\\xC3\\xA9hello\\x20world\\xFF', errors='strict') == ('éhello world', 20)

# Generated at 2022-06-23 17:56:34.857439
# Unit test for function register
def test_register():
    import os
    from io import TextIOWrapper
    from re import compile as re_compile

    register()

    escaped_utf8_bytes = bytes(
        b'\\xc3\\xa9\\xc3\\x86\\xc5\\x93\\xc5\\x93\\xc4\\xb1',
        encoding='eutf8h',
    )

    escaped_utf8_str = str(
        '\\xc3\\xa9\\xc3\\x86\\xc5\\x93\\xc5\\x93\\xc4\\xb1',
        encoding='eutf8h',
    )

    escaped_utf8_binary_io = TextIOWrapper(
        io.BytesIO(escaped_utf8_bytes),
        encoding='eutf8h',
    )

    escaped_utf8_text_io = Text

# Generated at 2022-06-23 17:56:45.555743
# Unit test for function encode
def test_encode():
    assert encode('test \x41') == (b'\\x74\\x65\\x73\\x74 \\x41', 10)
    # assert encode('test \x41', 'replace') == (b'\\122\\x74\\x65\\x73\\x74 \\x41', 10)
    assert encode('test \xE2\x9C\x93 \xF0\x9F\x98\xA5') == (b'\\x74\\x65\\x73\\x74 \\342\\234\\223 \\360\\237\\230\\245', 23)
    assert encode('test \u2713 \U0001f525') == (b'\\x74\\x65\\x73\\x74 \\342\\234\\223 \\360\\237\\230\\245', 23)

# Generated at 2022-06-23 17:56:48.591600
# Unit test for function register
def test_register():
    """
    >>> import eutf8h
    >>> register()
    >>> codecs.decode('\\x61', 'eutf8h')
    'a'
    >>> codecs.encode('a', 'eutf8h')
    b'\\\\x61'
    """


# Generated at 2022-06-23 17:56:53.011232
# Unit test for function register
def test_register():
    codecs.register         # type: ignore[name-defined]
    codecs.getdecoder       # type: ignore[name-defined]
    codecs.lookup           # type: ignore[name-defined]
    codecs.lookup_error     # type: ignore[name-defined]


# Register the codecs
register()

# Generated at 2022-06-23 17:56:54.417290
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder('eutf8h')   # type: ignore

# Generated at 2022-06-23 17:57:07.109744
# Unit test for function decode
def test_decode():
    import mypy_extensions

    assert ''.encode('eutf8h') ==  b''
    assert 'a'.encode('eutf8h') ==  b'a'
    assert '\x01'.encode('eutf8h') ==  b'\\x01'
    assert '\\x01'.encode('eutf8h') ==  b'\\x01'
    assert '\\xff'.encode('eutf8h') ==  b'\\xff'
    assert '\\x00'.encode('eutf8h') ==  b'\\x00'
    assert '\\x80'.encode('eutf8h') ==  b'\\x80'
    assert '\\x81'.encode('eutf8h') ==  b'\\x81'

# Generated at 2022-06-23 17:57:18.254622
# Unit test for function encode
def test_encode():
    def str_to_utf8(text: str) -> bytes:
        return bytes(text.encode('utf-8'))

    def str_to_latin1(text: str) -> bytes:
        return bytes(text.encode('latin1'))

    def str_to_eutf8h(text: str) -> bytes:
        return encode(text)[0]

    def str_to_hex(text: str) -> str:
        return ' '.join(['\\x%02x' % i for i in str_to_utf8(text)])

    def assert_is_eutf8h_same_as_utf8(text: str) -> None:
        assert str_to_eutf8h(text) == str_to_utf8(text)

# Generated at 2022-06-23 17:57:21.525367
# Unit test for function encode
def test_encode():
    text_input = '\\x41\\x42'
    out_bytes = encode(text_input)
    # print(out_bytes)



# Generated at 2022-06-23 17:57:27.825321
# Unit test for function decode
def test_decode():
    print('\nTesting function decode...')
    data = '\\x4a\\x4e'
    expected = 'JN'
    actual = decode(data)[0]
    try:
        assert expected == actual
        print('Expected value matches actual')
    except AssertionError:
        print('Test failed: decode("%s")' % data)
        print('Expected: "%s"' % expected)
        print('Actual:   "%s"' % actual)



# Generated at 2022-06-23 17:57:35.107358
# Unit test for function encode
def test_encode():
    text_input = 'Hello'
    text_bytes = b'Hello'
    text_encoded, text_encoded_length = encode(text_input)
    try:
        assert(text_encoded == text_bytes and text_encoded_length == len(text_input))
        print('Unit test PASSED: ' + type(encode).__name__ + '()')
        return True
    except AssertionError as e:
        print('Unit test FAILED: ' + type(encode).__name__ + '()')
        print(str(e))
        return False



# Generated at 2022-06-23 17:57:42.095220
# Unit test for function encode
def test_encode():
    encode('a')
    encode('ab')
    encode('\\x61')
    encode('\\x61b')
    encode('a\\x62')
    encode('\\x61\\x62')
    encode('a\\x62c')
    encode('\\x61b\\x63')
    encode('a\\x62b\\x63')
    encode('\\x61\\x62\\x63')
    encode('a\\x62\\x63c')
    encode('\\x61b\\x63c')
    encode('a\\x62b\\x63c')
    encode('\\x61\\x62c\\x63')
    encode('a\\x62\\x63\\x64c')
    encode('ab\\x63cd')
    encode('\\x61\\x62\\x63cd')

# Generated at 2022-06-23 17:57:47.451567
# Unit test for function decode
def test_decode():
    codec = 'eutf8h'

    # TypeError test
    try:
        codecs.decode(1, codec)
    except TypeError:
        pass
    else:
        raise AssertionError(
            'TypeError not raised for codecs.decode(1, codec)')
    # decode a utf8 encoded decimal.
    # the decimal '1027' is encoded in utf8 as
    # \xe4\x80\xa87
    # The hexadecimal for each utf8 encoded byte is
    # \xE4 = 1110 0100
    # \x80 = 1000 0000
    # \xA7 = 1010 0111
    # The escaped utf8 hexadecimal for each utf8 encoded byte is
    # \\xE4 = \xA4
    # \\x80 = \x

# Generated at 2022-06-23 17:57:57.036944
# Unit test for function decode
def test_decode():
    # Test 1: Test decoding with hexadecimal characters that are
    #         within the ascii range.
    data = b'\x30\x31\x32\x33\x34\x35\x36\x37' \
           b'\x38\x39\x61\x62\x63\x64\x65\x66'
    result = decode(data)
    assert result == ('0123456789abcdef', 16), result

    # Test 2: Test decoding of escaped hexadecimal characters that
    #         are within the latin-1 range.

# Generated at 2022-06-23 17:58:08.698496
# Unit test for function decode
def test_decode():
    print('testing decode')

    # Test decoding a string with an escaped hexadecimal
    encoded_string = b'\\x41\\x42\\x43'
    decoded_string = decode(encoded_string)
    print(f'decoded_string = {decoded_string}')
    assert decoded_string == ('ABC', 9)

    # Test decoding a string with a regular hexadecimal
    encoded_string = b'\\xab\\xcd'
    decoded_string = decode(encoded_string)
    print(f'decoded_string = {decoded_string}')
    assert decoded_string == ('\xab\xcd', 6)

    # Test decoding a string with a regular hexadecimal

# Generated at 2022-06-23 17:58:11.512413
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore


if __name__ == '__main__':
    codecs.register(_get_codec_info)   # type: ignore

# Generated at 2022-06-23 17:58:14.586898
# Unit test for function encode
def test_encode():
    text = 'hi\\x80'
    expected = b'hi\\xc2\\x80'
    actual = encode(text)
    assert actual == (expected, len(text))



# Generated at 2022-06-23 17:58:26.861653
# Unit test for function encode
def test_encode():
    assert encode('aa\xFF\xFFbb\xFFcc') == (b'aa\\xff\\xFFbb\\xffcc', 8)
    assert encode(u'aa\xFF\xFFbb\xFFcc') == (b'aa\\xff\\xFFbb\\xffcc', 8)
    assert encode('aa\xFFbb\xFFcc') == (b'aa\\xffbb\\xffcc', 8)
    assert encode(u'aa\xFFbb\xFFcc') == (b'aa\\xffbb\\xffcc', 8)
    assert encode('aa\xFF\xFFbb\xFFcc', errors='ignore') == (
        b'aa\\xFF\\xFFbb\\xffcc',
        7,
    )

# Generated at 2022-06-23 17:58:30.947911
# Unit test for function register
def test_register():
    """
    Ensure that the 'eutf8h' codec is registered with Python
    """
    register()
    assert NAME in codecs.__dict__['_codec_search_cache']
    assert NAME in codecs.__dict__['_codec_alias_cache']

# Unit tests for function encode

# Generated at 2022-06-23 17:58:38.807593
# Unit test for function encode

# Generated at 2022-06-23 17:58:41.295336
# Unit test for function decode
def test_decode():
    input_str = '\xc3\xa9'

    input_bytes = input_str.encode('utf-8')

    escaped_bytes = codecs.encode(input_bytes, 'eutf8h')
    assert escaped_bytes == b'\\xc3\\xa9'

    decoded_str = codecs.decode(escaped_bytes, 'eutf8h')
    assert decoded_str == input_str



# Generated at 2022-06-23 17:58:52.193738
# Unit test for function decode
def test_decode():
    assert decode(b'\\x6f') == ('o', 3)
    assert decode(b'\\xC3\\xB6') == ('ö', 7)
    assert decode(b'\\x6f\\xC3\\xB6') == ('oö', 10)
    assert decode(b'\\x6f\\xc3\\x\\xB6') == (r'o\x\x', 12)
    assert decode(b'\\x6f\\xc3\\xB6') == ('oö', 10)
    assert decode('\\x6f\\xc3\\xB6'.encode('utf8')) == ('oö', 10)

    assert decode(b'\\x6f\\xc3\\xb6') == ('oö', 10)
    assert decode(b'\\X6f\\xc3\\xb6')

# Generated at 2022-06-23 17:58:56.998874
# Unit test for function encode
def test_encode():
    s = 'abc\\xfe\\xed\\x00\\x01\\xff'
    c1 = 'abc\xfe\xed\x00\x01\xff'
    b = b'abc\xfe\xed\x00\x01\xff'
    c2 = 'abc\\xfe\\xed\\x00\\x01\\xff'
    assert c1 == s
    assert b == s.encode(NAME)
    assert c2 == s.encode(NAME).decode(NAME)
    print('Success')

if __name__ == '__main__':
    test_encode()

# Generated at 2022-06-23 17:59:02.714790
# Unit test for function encode
def test_encode():
    assert encode('\\x3a') == (b'\\x3a', 4)
    assert encode(str('')) == (b'', 0)
    assert encode('\\x33') == (b'\\x33', 4)
    assert encode('\\x30') == (b'\\x30', 4)
    assert encode('\\x2f') == (b'\\x2f', 4)
    assert encode('\\x31') == (b'\\x31', 4)
    assert encode('\\x30') == (b'\\x30', 4)
    assert encode('\\x30') == (b'\\x30', 4)
    assert encode('\\x32') == (b'\\x32', 4)
    assert encode('\\x30') == (b'\\x30', 4)
    assert encode('\\x31')

# Generated at 2022-06-23 17:59:08.010896
# Unit test for function decode
def test_decode():
    in_str = b'\\x48\\x65\\x6C\\x6C\\x6F\\x20\\x41\\x70\\x70\\x6C\\x65'
    out, count = decode(in_str)
    assert out == 'Hello Apple'
    assert count == 12


# Generated at 2022-06-23 17:59:14.858496
# Unit test for function decode
def test_decode():
    # Test for simple printable character
    assert decode(b'a') == ('a', 1)

    # Test for simple non-printable character for ASCII
    assert decode(b'\\x0a') == ('\n', 4)

    # Test for hexadecimal sequence for ASCII
    assert decode(b'\\x61') == ('a', 4)

    # Test for hexadecimal sequence for ASCII with uppercase letters
    assert decode(b'\\x41') == ('A', 4)

    # Test for hexadecimal sequence for non-ASCII characters
    assert decode(b'\\xc0') == ('À', 4)

    # Test for a mix of printable and non-printable characters

# Generated at 2022-06-23 17:59:20.365327
# Unit test for function register
def test_register():
    """Make sure that the codec is not already registered. Remove the codec,
    if it is already registered, so that it can be registered
    and tested."""
    try:
        codecs.lookup_error(NAME)
    except LookupError:
        pass
    else:
        raise ValueError('Codec already registered')
    try:
        codecs.lookup_error(NAME)
    except LookupError:
        pass
    else:
        raise ValueError('Codec already registered')



# Generated at 2022-06-23 17:59:30.906362
# Unit test for function register
def test_register():
    del codecs.encode_error_registry['eutf8h']
    del codecs.decode_error_registry['eutf8h']


# Generated at 2022-06-23 17:59:37.869064
# Unit test for function register
def test_register():
    # First check that the NAME codec is not known to the codecs
    # module.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError(
            'Codec eutf8h should not exist in codecs module.'
        )
    # Then register the NAME codec to the codecs module.
    register()
    # Then check if the newly registered codec is known to the codecs
    # module.



# Generated at 2022-06-23 17:59:49.913021
# Unit test for function register
def test_register():
    register()

    ci = codecs.getdecoder(NAME)
    assert ci is not None, 'Failed to register codec'
    assert ci.name.lower() == NAME.lower(), 'Codec does not have name %s' % NAME
    assert ci.encode('') == (b'', 0)
    assert ci.decode(b'') == ('', 0)
    assert ci.encode(u'\u03A3') == (b'\\xce\\xa3', 2)
    assert ci.encode('\u03A3') == (b'\\xce\\xa3', 2)
    assert ci.decode(b'\\xce\\xa3') == ('Σ', 4)

# Generated at 2022-06-23 17:59:58.064652
# Unit test for function decode
def test_decode():
    escape_bytes = b'\\xe4\\xbd\\xa0\\xe5\\xa5\\xbd\\xc2\\xb7\\xe4\\xb8\\x96' \
                   b'\\xe7\\x95\\x8c\\xc2\\xb7\\xe4\\xba\\xba\\xe6\\xb0\\x91\\xc2\\xb7\\xe5\\xb8\\x88\\xe5\\x85\\xa5\\xe9\\x9d\\xa2\\xc2\\xbb'

# Generated at 2022-06-23 18:00:02.942568
# Unit test for function decode
def test_decode():
    # setup test data
    data = b'\\xE2\\x98\\xA0'
    exp = '☠'
    out, _ = decode(data)
    assert exp == out, 'Expected "%s" but got "%s"' % (exp, out)


# Generated at 2022-06-23 18:00:14.263570
# Unit test for function decode
def test_decode():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()

    assert(
        decode(
            bytes('\\xe2\\x9c', 'unicode_escape'),
        )[0]
        ==
        '\\xe2\\x9c'
    )
    assert(
        decode(
            bytes('\\u2603', 'unicode_escape'),
        )[0]
        ==
        '\u2603'
    )
    assert(
        decode(
            bytes('\\U0001f0a1', 'unicode_escape'),
        )[0]
        ==
        '\\ud83c\\udca1'
    )

# Generated at 2022-06-23 18:00:24.740633
# Unit test for function encode
def test_encode():
    assert encode('a') == (b'a', 1)
    assert encode('\\x61') == (b'\\x61', 4)
    assert encode('☺') == (b'\\xe2\\x98\\xba', 1)
    assert encode('\\xe2\\x98\\xba') == (b'\\xe2\\x98\\xba', 11)
    assert encode('\\U0001F600') == (b'\\xf0\\x9f\\x98\\x80', 13)
    assert encode('\\U0001F601') == (b'\\xf0\\x9f\\x98\\x81', 13)
    assert encode('\\U0001F602') == (b'\\xf0\\x9f\\x98\\x82', 13)

# Generated at 2022-06-23 18:00:25.991325
# Unit test for function register
def test_register():

    register()


# Generated at 2022-06-23 18:00:33.557072
# Unit test for function decode
def test_decode():
    src_str = 'abc\\x65'
    out_str, _ = decode(src_str.encode('utf-8'))
    assert out_str == 'abce'

    # Test invalid escaping of utf8 hex.
    src_str = '\\x'
    try:
        decode(src_str.encode('utf-8'))
    except UnicodeDecodeError as e:
        assert e.reason == 'incomplete escape'

    # Test invalid escaping of utf8 hex.
    src_str = '\\x0'
    try:
        decode(src_str.encode('utf-8'))
    except UnicodeDecodeError as e:
        assert e.reason == 'incomplete escape'

    # Test invalid escaping of utf8 hex.
    src_str = '\\x0g'
   

# Generated at 2022-06-23 18:00:36.019923
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.__dict__['_cache']

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 18:00:45.941743
# Unit test for function decode
def test_decode():
    """Unit test for function decode."""

    # Convert escaped utf8 hexadecimal bytes into a string.
    try:
        text_bytes_eutf8h = b'\\x20\\xe2\\x99\\xa5\\x20'  # ' ♥ '
        text_str_py3_3_7, _ = codecs.decode(text_bytes_eutf8h, NAME)  # type: ignore
        assert text_str_py3_3_7 == ' ♥ '
    except LookupError:
        pass  # codec 'eutf8h' is not available in Python 3.3.7



# Generated at 2022-06-23 18:00:53.804643
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    utf8_hex = codecs.getdecoder(NAME)
    assert utf8_hex('\\x6f')[0] == 'o'
    assert utf8_hex('\\x62')[0] == 'b'
    assert utf8_hex('\\xC3\\xB6')[0][0] == '\xf6'
    assert utf8_hex('\\xC3\\xB6')[0][0] == '\xf6'
    assert utf8_hex('\\xC3\\xB6')[0][0] == '\xf6'
    assert utf8_hex('\\xC3\\xB6')[0][-1] == '\xf6'



# Generated at 2022-06-23 18:01:03.077387
# Unit test for function decode
def test_decode():
    assert decode(b'\\xE6\\x96\\x87') == ('文', 8)
    assert decode(b'Hello World!\\xE6\\x96\\x87') == ('Hello World!文', 21)
    assert decode(b'\\xE6\\x96\\x87Hello World!') == ('文Hello World!', 21)
    assert decode(b'\\xE4\\xB8\\x80\\xE4\\xBA\\x8C\\xE4\\xB8\\x89') == ('一二三', 20)
    assert decode(b'\\xE4\\xB8\\x80\\xE4\\xBA\\x8C\\xE4\\xB8\\x89Hello World!') == ('一二三Hello World!', 31)

# Generated at 2022-06-23 18:01:04.909663
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-23 18:01:14.759979
# Unit test for function encode
def test_encode():
    assert encode('A') == b'A'
    assert encode('A', 'strict') == b'A'
    assert encode('A', 'ignore') == b'A'
    assert encode('A', 'replace') == b'A'
    assert encode('\n') == b'\\a'
    assert encode('\n', 'strict') == b'\\a'
    assert encode('\n', 'ignore') == b'\\a'
    assert encode('\n', 'replace') == b'\\a'
    assert encode('\u2713') == b'\\xe2\\x9c\\x93'
    assert encode('\u2713', 'strict') == b'\\xe2\\x9c\\x93'

# Generated at 2022-06-23 18:01:19.024825
# Unit test for function decode
def test_decode():
    bytes_str = '\\x54\\x65\\x73\\x74'
    out, length = decode(bytes_str)
    assert out == 'Test'
    assert length == len(bytes_str)



# Generated at 2022-06-23 18:01:25.347707
# Unit test for function encode
def test_encode():
    plain_str: str = u'1\u2028'
    plain_str2: str = u'3\u202e'

    text: str = plain_str
    out, _ = encode(text)
    assert out == plain_str.encode('utf-8')

    text: str = plain_str2
    out, _ = encode(text)
    assert out == plain_str2.encode('utf-8')

    text: str = u'\\x31\\x20\\xe2\\x80\\xa8'
    out, _ = encode(text)
    assert out == plain_str.encode('utf-8')

    text: str = u'\\x33\\x20\\xe2\\x80\\xae'
    out, _ = encode(text)
    assert out == plain_str2.en

# Generated at 2022-06-23 18:01:34.753889
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode('a') == (b'a', 1)
    assert encode('\\') == (b'\\\\', 1)
    assert encode('\\x') == (b'\\\\x', 2)
    assert encode('\\x0') == (b'\\\\x0', 3)
    assert encode('\\x0G') == (b'\\\\x0G', 4)
    assert encode('\\x0G\\x2') == (b'\\\\x0G\\\\x2', 6)
    assert encode('\\x0G\\x2a') == (b'\\\\x0G\\\\x2a', 7)
    assert encode('\\x0G\\x2a\\x') == (b'\\\\x0G\\\\x2a\\\\x', 8)

# Generated at 2022-06-23 18:01:44.326015
# Unit test for function encode
def test_encode():
    assert encode('\u007f') == (b'\\x7f', 1)
    assert encode('\x80') == (b'\\xc2\\x80', 1)
    assert encode('\u00ff') == (b'\\xc3\\xbf', 1)
    assert encode('\u0100') == (b'\\xc4\\x80', 1)
    assert encode('\u07ff') == (b'\\xdf\\xbf', 1)
    assert encode('\u0800') == (b'\\xe0\\xa0\\x80', 1)
    assert encode('\uffff') == (b'\\xef\\xbf\\xbf', 1)
    assert encode('\U00010000') == (b'\\xf0\\x90\\x80\\x80', 1)

# Generated at 2022-06-23 18:01:49.566667
# Unit test for function encode
def test_encode():
    """Test function :func:`encode`."""
    register()
    data = b'\\N{UPPER HALF BLOCK}\x80\u1234\\x05\\xAA\\x55\\x66\x67\\x8D'
    assert data == encode(data)[0]
    assert data == codecs.encode(data, 'eutf8h')[0]



# Generated at 2022-06-23 18:02:01.149879
# Unit test for function encode
def test_encode():
    assert encode("This is a test of the encoding process.") == \
        (b'\\x54\\x68\\x69\\x73\\x20\\x69\\x73\\x20\\x61\\x20\\x74\\x65\\x73'
         b'\\x74\\x20\\x6f\\x66\\x20\\x74\\x68\\x65\\x20\\x65\\x6e\\x63\\x6f'
         b'\\x64\\x69\\x6e\\x67\\x20\\x70\\x72\\x6f\\x63\\x65\\x73\\x73\\x2e',
         47)

# Generated at 2022-06-23 18:02:05.828867
# Unit test for function decode
def test_decode():
    data_bytes = b'\\0\\61\\62\\63'
    out, i = decode(data_bytes)
    assert out == 'abc'
    assert i == 5



# Generated at 2022-06-23 18:02:13.081701
# Unit test for function decode
def test_decode():
    test_decode_bytes = b'\\x61\\x62\\x63'
    test_decode_expected = 'abc'
    test_decode_result = decode(test_decode_bytes)
    test_decode_result_str = test_decode_result[0]
    if test_decode_expected == test_decode_result_str:
        print("test_decode: pass")
    else:
        print("test_decode: fail")


# Generated at 2022-06-23 18:02:23.130567
# Unit test for function decode
def test_decode():
    assert decode(b'\\xC2\\xA2') == ('¢', 6)
    assert decode(b'\\xE2\\x82\\xAC') == ('€', 9)
    assert decode(b'\\xF0\\x9D\\x84\\x9E') == ('𝄞', 12)
    assert decode(b'\\xF4\\x8F\\xBF\\xBE') == ('🏾', 12)
    assert decode(b'\\xF8\\x80\\x80\\x80\\x80') == ('🏾', 15)
    assert decode(b'\\xFC\\x80\\x80\\x80\\x80\\x80') == ('🏾', 18)
    assert decode(b'\\x80') == ('', 3)

# Generated at 2022-06-23 18:02:31.231941
# Unit test for function register
def test_register():
    import sys
    import types

    if NAME in sys.modules:
        del sys.modules[NAME]

    assert NAME not in sys.modules
    assert NAME not in sys.modules[__name__].__dict__

    register()

    assert NAME in sys.modules
    assert NAME in sys.modules[__name__].__dict__
    assert isinstance(
        sys.modules[__name__].__dict__[NAME],
        types.ModuleType
    )

    # noinspection PyUnresolvedReferences
    from . import escaped_utf8_hex

    assert escaped_utf8_hex.NAME == NAME

    assert escaped_utf8_hex.encode == encode
    assert escaped_utf8_hex.decode == decode



# Generated at 2022-06-23 18:02:37.390255
# Unit test for function decode
def test_decode():
    data = b"\\xe6\\x97\\xa5\\xe6\\x9c\\xac"
    errors = "strict"
    out, size = decode(data, errors)
    assert out == '日本'
    assert size == 4
    try:
        data = b"\\xff"
        decode(data, errors)
        assert False
    except UnicodeDecodeError:
        pass



# Generated at 2022-06-23 18:02:38.461159
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-23 18:02:40.568768
# Unit test for function decode
def test_decode():
    destination = decode('\\x41\\x42\\x43', 'strict')
    assert destination[0] == 'ABC'
    assert destination[1] == 8



# Generated at 2022-06-23 18:02:46.411351
# Unit test for function decode
def test_decode():
    # Unit test for function decode
    def decode_test(payload: bytes, expected: str) -> None:
        actual, _ = decode(payload)
        assert actual == expected

    decode_test(b'\\x9B', '\u009B')
    decode_test(b'\\x9B\\x9C', '\u009B\u009C')
    decode_test(b'\\x9B\\x9C\\x9D', '\u009B\u009C\u009D')
    decode_test(b'\\x9B\\x9C\\x9D\\x9E', '\u009B\u009C\u009D\u009E')

# Generated at 2022-06-23 18:02:57.173697
# Unit test for function encode

# Generated at 2022-06-23 18:02:58.991421
# Unit test for function register
def test_register():
    register()
    result = codecs.getdecoder(NAME)
    assert result == _get_codec_info(NAME)



# Generated at 2022-06-23 18:03:08.042352
# Unit test for function encode
def test_encode():
    assert encode('\\xyz') == (b'\\\\xyz', 5)
    assert encode('ಠ_ಠ') == (b'\\xe0\\xb2\\xa0\\_\\xe0\\xb2\\xa0', 8)
    assert (
        encode(
            'ಠ_ಠ',
            errors='ignore'
        ) == (b'\\xe0\\xb2\\xa0\\_\\xe0\\xb2\\xa0', 8)
    )
    assert (
        encode(
            'ಠ_ಠ',
            errors='replace'
        ) == (b'\\xe0\\xb2\\xa0\\_\\xe0\\xb2\\xa0', 8)
    )

# Generated at 2022-06-23 18:03:14.452396
# Unit test for function encode
def test_encode():
    assert encode('abcde', 'strict') == (b'abcde', 5)
    assert encode('abcd\xe5ef', 'strict') == (b'abcd\\xe5ef', 6)
    assert encode('abcd\xe5\xef', 'strict') == (b'abcd\\xe5\\xef', 6)
    assert encode('abcd\xe5\xef', 'ignore') == (b'abcd', 4)
    # The following raises an UnicodeEncodeError.
    # uencode('abcd\xe5\xef', 'replace')



# Generated at 2022-06-23 18:03:16.565508
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise ValueError('Code was not registered')

# Generated at 2022-06-23 18:03:18.755663
# Unit test for function register
def test_register():
    global description

    description = "Unit tests for function 'register'"

    register()

    # No exception raised



# Generated at 2022-06-23 18:03:19.696874
# Unit test for function register
def test_register():
    # This will try to register the codec, but will
    # not do anything if it is already registered.
    register()

# Generated at 2022-06-23 18:03:23.679816
# Unit test for function encode
def test_encode():
    text = 'Hi, \\u0040'
    out_bytes_expected = b'Hi, \\40'

    out_bytes, _ = encode(text)
    assert out_bytes == out_bytes_expected


# Generated at 2022-06-23 18:03:26.136764
# Unit test for function decode
def test_decode():
    test_data = b'\\x41\\x42\\x43'
    result, _ = decode(test_data)
    assert result == 'ABC'



# Generated at 2022-06-23 18:03:36.691372
# Unit test for function decode

# Generated at 2022-06-23 18:03:43.576589
# Unit test for function encode
def test_encode():
    assert (b'\\64\\65\\66', 3) == encode('abc')
    assert (b'\\65\\6e\\67\\65\\6c', 5) == encode('angel')
    assert (b'\\e1\\b9\\91\\e1\\b9\\9a', 4) == encode('ᶑᶚ')
    assert (b'\\c9\\bb', 2) == encode('ᵻ')
    assert (b'\\e1\\be\\80\\e1\\be\\bc\\e1\\bf\\a0\\e1\\bf\\a3', 4) == encode(
        'ᾀᾼῠΰ'
    )

# Generated at 2022-06-23 18:03:51.610636
# Unit test for function decode
def test_decode():
    assert decode(b'\\x48\\x65\\x6c\\x6c\\x6f') == ('Hello', len(b'\\x48\\x65\\x6c\\x6c\\x6f'))  # noqa: E501
    assert decode(b'A\\x48\\x65\\x6c\\x6c\\x6fB') == ('AHelloB', len(b'A\\x48\\x65\\x6c\\x6c\\x6fB'))  # noqa: E501
    assert decode(b'\\x66\\x6f\\x6f', 'ignore') == ('f', len(b'\\x66'))  # noqa: E501

# Generated at 2022-06-23 18:03:59.410255
# Unit test for function encode
def test_encode():
    in_str = '0\u00A7\u00A9\u00A9'
    out_bytes = b'0\\xC2\\xA7\\xC2\\xA9\\xC2\\xA9'
    assert encode(in_str) == (out_bytes, len(in_str))
    with pytest.raises(TypeError) as e:
        encode(b'0')
    assert f"argument 1 must be str or unicode, not 'bytes'" in str(e.value)


# Generated at 2022-06-23 18:04:11.754936
# Unit test for function encode
def test_encode():
    try:
        encode(bytearray(b'\\x41'))
    except AttributeError:
        pass
    else:
        assert False, 'encode failed'
    try:
        encode(memoryview(b'\\x41'))
    except AttributeError:
        pass
    else:
        assert False, 'encode failed'
    try:
        encode(b'\\x41')
    except TypeError:
        pass
    else:
        assert False, 'encode failed'

    assert encode('') == (b'', 0)
    assert encode('\x00') == (b'\\x00', 1)
    assert encode('\x01') == (b'\\x01', 1)
    assert encode('\x02') == (b'\\x02', 1)

# Generated at 2022-06-23 18:04:15.731322
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME) is not None
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-23 18:04:26.453920
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    # Unit test code
    import unittest

    class Test_eutf8h(unittest.TestCase):
        def test_decode(self):
            self.assertEqual(
                decode(b'\\x65\\x6e\\x67\\x6c\\x69\\x73\\x68'),
                ('english', 7),
            )
            self.assertEqual(
                decode(b'\\x65\\x6e\\x67\\x6c\\x69\\x73\\x68\\x20'),
                ('english', 8),
            )

# Generated at 2022-06-23 18:04:31.274351
# Unit test for function decode
def test_decode():
    assert decode(b'\\x41'*12 + b'\\x20' + b'\\x42'*13) == ('AAAAAAAAAAAA BBBBBBBBBBBBB', 26)
    assert decode(b'\\xe2\\x82\\xac') == ('€', 5)
    assert decode(b'\\u20ac') == ('€', 6)
    assert decode(b'\\U000020ac') == ('€', 10)
    assert decode(b'\\xc3\\xa9') == ('é', 5)
    assert decode(b'\\u00e9') == ('é', 6)
    assert decode(b'\\U000000e9') == ('é', 10)
    assert decode(b'\\xe2\\x82\\xac', 'replace') == ('�', 5)

# Generated at 2022-06-23 18:04:39.648669
# Unit test for function register
def test_register():
    register()
    text_in = 'abc \\xE2\\x80\\x99'
    text_out = 'abc \xE2\x80\x99'
    try:
        text_encoded = text_in.encode(NAME)
        text_decoded = text_encoded.decode(NAME)
    except LookupError:
        pytest.fail("Register function failed to add NAME")
    if text_decoded != text_in:
        pytest.fail("register did not decode correctly")
    if not text_decoded == text_out:
        pytest.fail("register did not encode correctly")


if __name__ == '__main__':
    pytest.main()

# Generated at 2022-06-23 18:04:45.965068
# Unit test for function decode
def test_decode():
    for input_data, expected_result in (
            (b'\\x0A', '\n'),
            (b'\\xC2\\xA2', u'¢'),
            (b'\\x9F\\x92', u'𝒒'),
            (b'\\u001F', u'\u001F'),
            ):
        actual_result, _ = decode(input_data)
        assert actual_result == expected_result

# Generated at 2022-06-23 18:04:48.084359
# Unit test for function decode
def test_decode():
    data = b'\\xA9\\xB0'
    expected = '©°'
    assert expected == decode(data)[0]



# Generated at 2022-06-23 18:04:52.513340
# Unit test for function decode
def test_decode():
    input = b'abc\\xE2\\x98\\x83\\xF0\\x9F\\x92\\xA9'
    output = codecs.decode(input, NAME)
    expect = 'abc☃💩'
    assert output == expect



# Generated at 2022-06-23 18:04:58.347762
# Unit test for function register
def test_register():
    register()
    out = codecs.lookup(NAME)
    assert out.name == NAME
    assert out.encode('abc') == (b'abc', 3)
    assert out.decode(b'abc') == ('abc', 3)



# Generated at 2022-06-23 18:05:08.182117
# Unit test for function encode
def test_encode():
    t = r'Hi,\x20\x61\x62\'\x63\x64\x65\x66\x67'
    want = r'Hi, ab\x27\x63defg'.encode('utf8')
    got = encode(t, errors='strict')
    assert got[0] == want, 'Encoding failed'
    assert got[1] == len(t), 'Encoding failed'

    t = 'Hi,\x20\x61\x62\'\x63\x64\x65\x66\x67'
    want = 'Hi, ab\'cdefg'.encode('utf8')
    got = encode(t, errors='replace')
    assert got[0] == want, 'Encoding failed'
    assert got[1] == len(t), 'Encoding failed'



# Generated at 2022-06-23 18:05:12.761390
# Unit test for function register
def test_register():
    # Initialize the codecs indexing cache
    codecs.__init__()
    assert NAME not in codecs.__dict__['_cache']
    register()
    assert NAME in codecs.__dict__['_cache']


register()

# Generated at 2022-06-23 18:05:20.957054
# Unit test for function encode
def test_encode():
    assert encode('\U000F0000') == (b'\\xf0\\x90\\x80\\x80', 1)
    assert encode('\U000F0000\U0000FFFF') == (b'\\xf0\\x90\\x80\\x80\\xef\\xbf\\xbf', 2)
    assert encode('\U000F0000\U0000FFFF') == (b'\\xf0\\x90\\x80\\x80\\xef\\xbf\\xbf', 2)
    assert encode('a가😀b') == (b'a\\xea\\xb0\\x80\\xf0\\x9f\\x98\\x80b', 4)

# Generated at 2022-06-23 18:05:29.308024
# Unit test for function encode
def test_encode():
    """
    Unit test for function encode
    """

    # Note: Since the function encode() escapes utf8 hexadecimal,
    # the output of the following test should be exactly the same as
    # the input.

    # Test for basic utf8 characters
    utf8_data_dict = {
        'f': 'f',
        '\u00e9': '\u00e9',
        '\u20ac': '\u20ac',
        '\u5f20': '\u5f20'
    }
    for text, expected in utf8_data_dict.items():
        out_bytes, n = encode(text)
        out_text = out_bytes.decode('utf-8')

# Generated at 2022-06-23 18:05:32.248681
# Unit test for function encode
def test_encode():
    encode("x")
    encode("x")
    str = "test"
    encode("test")
    
    

# Generated at 2022-06-23 18:05:35.727764
# Unit test for function register
def test_register():
    register_input: codecs.CodecInfo = _get_codec_info(NAME)
    if register_input is not None:
        codecs.register(register_input)   # type: ignore



# Generated at 2022-06-23 18:05:37.141720
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-23 18:05:46.068083
# Unit test for function encode
def test_encode():
    def _test_encode(expected: bytes, *args, **kwargs) -> None:
        actual: bytes
        actual, _ = encode(*args, **kwargs)
        if actual != expected:
            raise ValueError(
                f'Expected: {expected!r}'
                f'\nGot     : {actual!r}'
                f'\ntext: {args[0]!r}'
                f'\nerrors: {kwargs.get("errors")!r}'
            )

    _test_encode(b'\\x41', 'A')
    _test_encode(b'\\x65\\xF1\\x4D', 'eñM')
    _test_encode(b'\\x6F\\x6C\\xA0\\x6C', 'ol¡l')