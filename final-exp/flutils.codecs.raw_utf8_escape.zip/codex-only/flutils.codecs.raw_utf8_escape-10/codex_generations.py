

# Generated at 2022-06-23 17:55:58.500353
# Unit test for function decode
def test_decode():
    try:
        foo = codecs.getdecoder(NAME)
    except LookupError:
        foo = codecs.register(_get_codec_info)

    with pytest.raises(TypeError):
        # noinspection PyTypeChecker
        foo = foo(None, None)
        del foo

    with pytest.raises(TypeError):
        # noinspection PyTypeChecker
        foo = foo(b'', None)
        del foo

    with pytest.raises(TypeError):
        # noinspection PyTypeChecker
        foo = foo(None, '')
        del foo

    # Good calls
    foo = foo(b'', '')
    assert isinstance(foo, tuple) and len(foo) == 2
    assert isinstance(foo[0], str)

# Generated at 2022-06-23 17:56:09.703611
# Unit test for function encode
def test_encode():
    s = 'abcd'
    rt = encode(s) 
    assert rt[0] == b'a\\x62\\x63\\x64'
    assert rt[1] == 4

    s = '\\x'
    rt = encode(s) 
    assert rt[0] == b'\\\\x'
    assert rt[1] == 2

    s = '\\x5'
    rt = encode(s) 
    assert rt[0] == b'\\\\x5'
    assert rt[1] == 3

    s = '\\x5f'
    rt = encode(s) 
    assert rt[0] == b'\\\\x5f'
    assert rt[1] == 4

    s = '\\x5f_啊'
    rt

# Generated at 2022-06-23 17:56:13.886322
# Unit test for function decode
def test_decode():
    assert decode(b'\\x66\\x6f\\x6f\\x62\\x61\\x72') == ('foobar', 6)
    assert decode(b'\\xe2\\x80\\x99') == ('’', 3)
    assert decode(b'\\xe3\\x82\\x86\\xe3\\x82\\x93') == ('ゆん', 6)


# Generated at 2022-06-23 17:56:20.719505
# Unit test for function decode
def test_decode():
    assert decode(b'\\xC3\\xA3\\xC3\\xA7\\xC3\\xA9') == ("ãçé", 16)
    assert decode(b'\\xC3') == ("Ã", 4)
    assert decode(b'\\xC3\\xA3') == ("Ã£", 8)
    assert decode(b'\\xC3\\xA3') == ("Ã£", 8)
    assert decode(b'\\xC3\\xA3\\xC3\\xA7\\xC3\\xA9') == ("Ã£çé", 16)

# Generated at 2022-06-23 17:56:32.380433
# Unit test for function encode
def test_encode():
    assert encode('hello world') == (b'hello world', 11)
    assert encode('a\nb\r\r\n') == (b'a\\x0ab\\x0d\\x0d\\x0a', 8)
    assert encode('\u2603') == (b'\\xe2\\x98\\x83', 2)
    assert encode('\u2603☃') == (b'\\xe2\\x98\\x83\\xe2\\x98\\x83', 2)
    assert encode('\U0001F4A9') == (b'\\xf0\\x9f\\x92\\xa9', 4)

# Generated at 2022-06-23 17:56:39.025677
# Unit test for function encode
def test_encode():
    # Given
    text = 'a b c \xcc \xdd \xee \xff'

    # When
    out, consumed = encode(text, errors='strict')

    # Then
    assert out == b'a b c \\xc3\\x8c \\xc3\\x9d \\xc3\\xae \\xc3\\xbf'
    assert consumed == len(text)



# Generated at 2022-06-23 17:56:48.853940
# Unit test for function encode
def test_encode():
    assert encode('A') == (b'A', 1)
    assert encode('AB') == (b'AB', 2)
    assert encode('\\x1A') == (b'\\x1a', 3)
    assert encode('\\x41') == (b'A', 3)
    assert encode('\\x00') == (b'\\x00', 3)
    assert encode('\\x41\\x00') == (b'A\\x00', 5)
    assert encode('\\x41\\x42') == (b'AB', 5)
    assert encode('\\U0010FFFF') == (b'\\xf4\\x8f\\xbf\\xbf', 11)

# Generated at 2022-06-23 17:56:54.276714
# Unit test for function encode
def test_encode():
    inp_test = 'b\'\\xc2\\xa9\'\\xA9'
    out_test = b'\\xc2\\xa9\\xC2\\xA9'
    assert encode(inp_test)[0] == out_test


# Generated at 2022-06-23 17:57:06.952253
# Unit test for function encode

# Generated at 2022-06-23 17:57:18.155069
# Unit test for function encode
def test_encode():
    from binascii import unhexlify
    import unittest

    class _TestEncode(unittest.TestCase):
        def _assert(
                self,
                text: str,
                expected_bytes: bytes,
                expected_len: int,
        ) -> None:
            encoded, length = encode(text)
            self.assertEqual(expected_len, length)
            self.assertEqual(expected_bytes, encoded)

        def test_normal(self):
            text = "abcd"
            bytes_hex = b'61626364'
            self._assert(
                text=text,
                expected_bytes=unhexlify(bytes_hex),
                expected_len=len(text),
            )


# Generated at 2022-06-23 17:57:24.721358
# Unit test for function register
def test_register():
    # Codec has NOT been registered before calling register
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert True
    else:
        assert False

    # After calling register, the codec has been registered
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False
    else:
        assert True


# Generated at 2022-06-23 17:57:34.530204
# Unit test for function decode
def test_decode():
    assert decode(b'\\x41') == ('A', 4)
    assert decode(b'\\x41\\x42') == ('AB', 8)

    assert decode(b'\\x41\\x42', 'ignore') == ('A', 8)
    assert decode(b'\\x41\\x42', 'replace') == ('A\ufffd', 8)
    assert decode(b'\\x41\\x42', 'surrogateescape') == \
        ('A\udc02', 8)
    assert decode(b'\\x41\\x42', 'surrogatepass') == \
        ('AB', 8)

    assert decode(b'\\x41\\x42', 'backslashreplace') == \
        ('A\\x42', 8)

    assert decode(b'\\x41\\x42', 'xmlcharrefreplace')

# Generated at 2022-06-23 17:57:42.788045
# Unit test for function register
def test_register():
    import sys
    import os
    os.environ['PYTHONPATH'] = os.pathsep.join(sys.path)
    from pkg_resources import load_entry_point
    register()
    name = 'python'
    module = 'foo.bar'
    func = 'baz'
    # noinspection PyProtectedMember
    sys.modules[module] = _MockModule(func)
    # noinspection PyTypeChecker
    codecs.register(load_entry_point(name, name, module))
    assert codecs.decode('eutf8h:\\xe3\\x81\\x82', NAME) == 'あ'



# Generated at 2022-06-23 17:57:48.143930
# Unit test for function register
def test_register():
    # codec register
    from eutf8h import register
    register()

    # codec lookup
    codecs.getencoder(NAME)  # type: ignore
    codecs.getdecoder(NAME)  # type: ignore
    codecs.lookup(NAME)  # type: ignore

# Generated at 2022-06-23 17:57:57.435242
# Unit test for function decode

# Generated at 2022-06-23 17:58:08.915271
# Unit test for function encode
def test_encode():
    a = encode('a')
    assert type(a) == tuple
    assert a[0] == b'a'
    assert a[1] == 1
    a = encode('a\x80')
    assert a[0] == b'a\\x80'
    assert a[1] == 2
    a = encode('┬┴┤├┼┘┌└┴┬├┤')

# Generated at 2022-06-23 17:58:12.052969
# Unit test for function register
def test_register():
    register()
    import sys
    import warnings
    warnings.filterwarnings("ignore", "unicode escape codec has been registered")
    sys.getdefaultencoding()


if __name__ == '__main__':
    # Unit test for function register
    test_register()

# Generated at 2022-06-23 17:58:24.201572
# Unit test for function decode
def test_decode():
    assert decode(
        b'\\x41\\x42\\x43',
    ) == ('ABC', 9)

    assert decode(
        b'\\x0a\\x0b\\x0c',
    ) == ('\n\v\f', 9)

    assert decode(
        b'\\x7f',
    ) == ('\x7f', 4)

    assert decode(
        b'\\x80\\x81\\x82',
    ) == ('\x80\x81\x82', 9)

    assert decode(
        b'\\xff\\xf8\\xf0',
    ) == ('\xff\xf8\xf0', 9)


# Generated at 2022-06-23 17:58:33.893954
# Unit test for function encode
def test_encode():
    assert encode(
        "This is the first test string!"
    ) == (b"This is the first test string!", 31)

    assert encode(
        "This is the second \\\\test string!"
    ) == (b"This is the second \\\\test string!", 31)

    assert encode(
        "This is the third \\x41test string!"
    ) == (b"This is the third \\x41test string!", 31)

    assert encode(
        "This is the fourth \\x55test string!"
    ) == (b"This is the fourth \\x55test string!", 31)

    assert encode(
        "This is the fifth \\x55\\x55test string!"
    ) == (b"This is the fifth \\x55\\x55test string!", 31)


# Generated at 2022-06-23 17:58:40.482052
# Unit test for function decode

# Generated at 2022-06-23 17:58:41.419692
# Unit test for function register
def test_register():
    register()
    assert True


# Generated at 2022-06-23 17:58:52.297095
# Unit test for function decode
def test_decode():
    text_bytes = b'\\xF0\\x9D\\x84\\x9E'
    text_str, _ = decode(text_bytes)
    assert text_str == '𝄞'
    text_bytes = b'This is a test.\\xF0\\x9D\\x84\\x9E'
    text_str, _ = decode(text_bytes)
    assert text_str == 'This is a test.𝄞'
    text_bytes = b'\\xC2\\xA2\\xC2\\xA3\\xC2\\xA4'
    text_str, _ = decode(text_bytes)
    assert text_str == '¢£¤'

# Generated at 2022-06-23 17:58:56.037732
# Unit test for function encode
def test_encode():
    input = '\xB1\xF9'
    output = b'\\xc2\\xb1\\xc3\\xb9'
    assert encode(input) == (output, 2)



# Generated at 2022-06-23 17:59:01.031272
# Unit test for function register
def test_register():
    register()

    # Check for the encoder
    try:
        codecs.getencoder(NAME)
    except LookupError:
        assert False, 'The encoder is not found'

    # Check for the decoder
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'The decoder is not found'



# Generated at 2022-06-23 17:59:02.657802
# Unit test for function register
def test_register():

    register()
    assert codecs.lookup(NAME)


# Generated at 2022-06-23 17:59:12.699921
# Unit test for function encode
def test_encode():
    # Test for function encode()

    e_str = 'b\xC3\xA1'
    e_str_hex = 'b\\xc3\\xa1'
    e_bytes = b'b\xc3\xa1'

    # Test the encode() function with its default input arguments.

    e_func_output = encode(e_str)
    e_func_output_bytes_1, e_func_output_int_1 = e_func_output
    e_func_output_bytes_2, e_func_output_int_2 = codecs.escape_encode(e_bytes)

    assert e_func_output_bytes_1 == e_func_output_bytes_2
    assert e_func_output_int_1 == e_func_output_int_2

    # Test the encode() function with

# Generated at 2022-06-23 17:59:19.390677
# Unit test for function decode
def test_decode():
    # Test decode by comparing it to the unescape_utf8_hex function
    from .unescape_utf8_hex import unescape_utf8_hex
    for i in range(0, 256):
        test_utf8_bytes = bytearray([i])
        test_escaped_utf8_hex = bytes(
            unescape_utf8_hex(test_utf8_bytes)
        )
        assert decode(test_escaped_utf8_hex)[0] == test_utf8_bytes.decode()


if __name__ == '__main__':
    test_decode()

# Generated at 2022-06-23 17:59:30.589717
# Unit test for function encode

# Generated at 2022-06-23 17:59:33.179695
# Unit test for function register
def test_register():
    if 'eutf8h' not in [name for _, name in codecs.lookup_error('strict')]:
        register()


register()

# Generated at 2022-06-23 17:59:44.657381
# Unit test for function decode
def test_decode():
    """ Given escaped utf8 hexadecimal bytes, verify the expected text """

# Generated at 2022-06-23 17:59:55.098109
# Unit test for function decode
def test_decode():
    try:
        import doctest  # noqa
        doctest.testmod()  # noqa
        return
    except ImportError:  # pragma: no cover
        pass

    # Simple tests
    assert decode('Python') == ('Python', 6)

# Generated at 2022-06-23 18:00:02.593076
# Unit test for function decode
def test_decode():
    # print(decode(b'\\x46\\x6f\\x6f\\x20\\x62\\x61\\x72\\x21'))
    decoded = decode(b'\\x46\\x6f\\x6f\\x20\\x62\\x61\\x72\\x21')[0]
    assert decoded == 'Foo bar!'
    return None


# Generated at 2022-06-23 18:00:13.746508
# Unit test for function encode
def test_encode():
    assert encode('abc') == (b'abc', 3)
    assert encode('\\xe2\\x82\\xac') == (b'\\xE2\\x82\\xAC', 5)
    assert encode('\\xe2\\x82\\xAC') == (b'\\xE2\\x82\\xAC', 5)
    assert encode('\ud83d\udc4d') == (b'\\xF0\\x9F\\x91\\x8D', 1)
    assert encode('\ud83d\ude4d') == (b'\\xF0\\x9F\\xB9\\x8D', 1)
    assert encode('\ud83d\udd4d') == (b'\\xF0\\x9F\\x94\\x8D', 1)

# Generated at 2022-06-23 18:00:24.268217
# Unit test for function decode
def test_decode():
    assert decode(b'\\x48\\x65\\x6c\\x6c\\x6f\\x20\\x57\\x6f\\x72\\x6c\\x64') == ('Hello World', 25)
    assert decode(b'\\x48\\x65\\x6c\\x6c\\x6f\\x20\\x57\\x6f\\x72\\x6c\\x64', 'ignore') == ('Hello World', 25)
    assert decode(b'\\x48\\x65\\x6c\\x6c\\x6f\\x20\\x57\\x6f\\x72\\x6c\\x64', 'replace') == ('Hello World', 25)

# Generated at 2022-06-23 18:00:34.982221
# Unit test for function encode
def test_encode():
    out = encode('Jill said: "Jack went up the hill, but then came down."')
    expected = 'Jill said: "Jack went up the hill, but then came down."'
    assert out == expected

    out = encode('Jill said: "\f"')
    expected = b'Jill said: \x0c'
    assert out == expected

    out = encode('Jill said: "\u0019"')
    expected = b'Jill said: \x19'
    assert out == expected

    out = encode('Jill said: "\U0001F638"')
    expected = b'Jill said: \xf0\x9f\x98\xb8'
    assert out == expected

    out = encode('Jill said: "\x80"')
    expected = b'Jill said: \\x80'


# Generated at 2022-06-23 18:00:46.944289
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)
    # Make sure we can still test this function.
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore

register()


if __name__ == '__main__':
    import traceback
    import doctest
    trace = traceback.extract_stack(limit=2)[0]
    filename = trace[0]
    if filename == '<doctest eutf8h.py[0-9]*>':
        # test()
        doctest.testmod()
    else:
        import timeit

# Generated at 2022-06-23 18:00:55.021397
# Unit test for function register
def test_register():
    import functools

    # Register the 'eutf8h' codec
    register()
    assert NAME in codecs.getencodings()

    # Test the 'eutf8h' codec encoder
    text = 'a𐀀b𐀁b𐀁c𐀂d𐀃e𐀄f'
    out_bytes, n = codecs.getencoder(NAME)(text)
    out_str = out_bytes.decode('utf-8')

# Generated at 2022-06-23 18:01:03.769775
# Unit test for function decode

# Generated at 2022-06-23 18:01:06.779577
# Unit test for function register
def test_register():
    from tests import test_register as tr
    tr.register(module_name=__name__)


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 18:01:15.684909
# Unit test for function decode
def test_decode():
    assert decode(b'a') == ('a', 1)
    assert decode('a') == ('a', 1)
    assert decode('\\x61') == ('a', 4)
    assert decode('\\x61\\x62') == ('ab', 7)
    assert decode('\\x61\\x62\\x63') == ('abc', 10)
    assert decode('\\x61\\x62\\x63') == ('abc', 10)
    assert decode('\\x61\\x62\\x63\\x64') == ('abcd', 13)

    # Test with errors
    assert decode('\\xa', 'ignore') == ('', 4)
    assert decode('\\xa', 'replace') == ('\ufffd', 6)
    assert decode('\\xa', 'backslashreplace') == ('\\x0a', 10)


# Generated at 2022-06-23 18:01:20.761415
# Unit test for function encode
def test_encode():
    print("Test started")
    print("Testing encode function")
    print("Passed")
    if(encode("你好")[0]!=b"\\xe4\\xbd\\xa0\\xe5\\xa5\\xbd"):
        print("Failed")
    else:
        print("Passed")


# Generated at 2022-06-23 18:01:32.389789
# Unit test for function decode
def test_decode():
    """
    Unit test for function decode
    """
    # test: decode("\xE7\xA0\x81")
    first = b"\\xE7\\xA0\\x81"
    second = b"\xe7\xa0\x81"
    assert decode(first) == decode(second)

    # test: decode("\xCE\x91\xCE\x92\xCE\x93")
    first = b"\\xCE\\x91\\xCE\\x92\\xCE\\x93"
    second = b"\xce\x91\xce\x92\xce\x93"
    assert decode(first) == decode(second)

    # test: decode("\xE7\xA0\x81\xCE\x91\xCE\x92\xCE\

# Generated at 2022-06-23 18:01:42.674853
# Unit test for function encode
def test_encode():
    assert encode('\\x61\\x00') == (b'a\\x00', 2)
    assert encode('🍓🍑') == (b'\\xf0\\x9f\\x8d\\x93\\xf0\\x9f\\x8d\\x91', 4)
    assert encode('🍓🍑', errors='strict') == (b'\\xf0\\x9f\\x8d\\x93\\xf0\\x9f\\x8d\\x91', 4)
    assert encode('🍓🍑', errors='ignore') == (b'', 0)
    assert encode('🍓🍑', errors='replace') == (b'?\\x00?\\x00', 2)

# Generated at 2022-06-23 18:01:45.256037
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.__all__

# Generated at 2022-06-23 18:01:54.517922
# Unit test for function encode
def test_encode():
    # Test with string of ascii
    assert encode('abc') == (b'abc', 3)

    # Test with string that references invalid utf8 bytes.
    try:
        encode('\\x61\\x62\\xFF\\x63')
    except UnicodeEncodeError:
        pass
    else:
        assert False

    # Test with string that references invalid utf8 bytes.
    try:
        encode('\\x61\\x62\\xFF\\x63', 'ignore')
    except UnicodeEncodeError:
        assert False

    # Test with string that references invalid utf8 bytes.
    assert encode('\\x61\\x62\\xFF\\x63', 'ignore') == (b'\\x61\\x62\\xFF\\x63', 11)

    # Test with string that has a unicode character

# Generated at 2022-06-23 18:01:58.731076
# Unit test for function decode
def test_decode():
    """Unit test for function decode."""
    assert decode(b'Four score and \x7b\x22W\x22\x3a\x22tu\x22\x7d') == ('Four score and {\\x22W\\x22:\\x22tu\\x22}', 23)



# Generated at 2022-06-23 18:02:05.286462
# Unit test for function encode
def test_encode():
    # encode the empty string
    text = ''
    result = encode(text)
    assert result == (b'', 0)

    text = '\x00\x01\x02'
    result = encode(text)
    assert result == (b'\\x00\\x01\\x02', 3)

    text = '\t\n'
    result = encode(text)
    assert result == (b'\\x09\\x0a', 2)

    text = 'ABC'
    result = encode(text)
    assert result == (b'ABC', 3)

    text = 'ABC\U0001F638'
    result = encode(text)
    assert result == (b'ABC\\xf0\\x9f\\x98\\xb8', 5)

    text = 'ABC\\xFE'

# Generated at 2022-06-23 18:02:15.444546
# Unit test for function encode
def test_encode():
    # On some systems the codecs.encode function signature may have leading
    # arguments that must be ignored. These are used by the io.TextIOBase
    # class.
    try:
        _ = codecs.encode('0', NAME)
    except TypeError:
        encode = codecs.encode
    else:
        # noinspection PyUnusedLocal
        def encode(
                input,
                errors,
                _line_buffering=None,
                _flush=None
        ) -> Tuple[str, int]:
            return codecs.encode(input, NAME, errors)
    encode('\n', 'strict')
    encode('\n', 'replace')
    encode('\n', 'ignore')
    encode('abc', 'strict')
    encode('abc', 'replace')

# Generated at 2022-06-23 18:02:26.690353
# Unit test for function decode
def test_decode():
    # Unit test for function decode
    assert decode(b'\\x61\\x62\\x63') == ('abc', 12)

    # Unit test for function decode
    assert decode(b'\\x61\\x62\\x63', '') == ('abc', 12)

    # Unit test for function decode
    assert decode(b'\\x61\\x62\\x63', 'strict') == ('abc', 12)

    # Unit test for function decode
    assert decode(b'\\x61\\x62\\x63', 'strict') == ('abc', 12)

    # Unit test for function decode
    assert decode(b'\\x61\\x62\\x63', 'replace') == ('abc', 12)

    # Unit test for function decode

# Generated at 2022-06-23 18:02:38.131278
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise Exception('The codec is already registered')

    register()

    codec = None
    try:
        codec = codecs.getdecoder(NAME)
    except LookupError:
        raise Exception('if the codec is registered, then it should be '
                        'found in the codecs module')

    if codec.name != NAME:
        raise Exception('The codec name in the codecs module should be the '
                        'same as the codec name.')

    codecs.lookup_error(NAME)
    codecs.lookup_error('asdfasfd')

    try:
        codecs.lookup_error('eutf8h')
    except LookupError:
        pass

# Generated at 2022-06-23 18:02:41.593580
# Unit test for function decode
def test_decode():
    assert decode(b'\\xc3\\xa7', errors='strict') == ('c', 4)
    try:
        decode(b'\\xc3\\xa7\\', errors='strict')
    except UnicodeDecodeError as e:
        assert e.encoding == 'eutf8h'



# Generated at 2022-06-23 18:02:45.158025
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    assert hasattr(codecs, 'getdecoder')
    assert hasattr(codecs, 'getencoder')


# Generated at 2022-06-23 18:02:48.067701
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 18:02:57.877815
# Unit test for function encode
def test_encode():
    assert encode(r'test') == (b'test', 4)
    assert encode(r'test\ntest') == (b'test\\xa\\ntest', 10)
    assert encode(r'test\atest') == (b'test\\x07test', 10)
    assert encode(r'\x00') == (b'\\0\\0', 2)
    assert encode(r'\x10') == (b'\\x10', 2)
    assert encode(r'\xff') == (b'\\xFF', 2)
    assert encode(r'\u0040') == (b'\\40\\40', 2)
    assert encode(r'\u00ff') == (b'\\xFF', 2)
    assert encode(r'\u0100') == (b'\\xC4\\x80', 2)


# Generated at 2022-06-23 18:03:07.242077
# Unit test for function decode
def test_decode():
    import unittest

    class _TestCase(unittest.TestCase):

        def test_ascii_characters(self):
            byte_seq = '\\x61\\x62\\x63'
            byte_seq_b = byte_seq.encode('utf8')
            out, _ = decode(byte_seq_b)
            self.assertEqual(out, 'abc')

        def test_skipped_characters(self):
            byte_seq = 'ab\\x63d'
            byte_seq_b = byte_seq.encode('utf8')
            out, _ = decode(byte_seq_b)
            self.assertEqual(out, 'abc')


# Generated at 2022-06-23 18:03:15.546825
# Unit test for function encode
def test_encode():
    assert encode('Dąbrówki', 'ignore') == (
        b'\\x44\\xC4\\x85\\x62\\x72\\xC3\\xB3\\x77\\x6B\\x69', 10
    )
    assert encode('Dąbrówki', 'replace') == (
        b'\\x44\\xC4\\x85\\x62\\x72\\xC3\\xB3\\x77\\x6B\\x69', 10
    )
    assert encode('Dąbrówki', 'strict') == (
        b'\\x44\\xC4\\x85\\x62\\x72\\xC3\\xB3\\x77\\x6B\\x69', 10
    )

# Generated at 2022-06-23 18:03:18.959213
# Unit test for function register
def test_register():
    _ = codecs.getdecoder(NAME)
    codecs.register(_get_codec_info)   # type: ignore
    _ = codecs.getdecoder(NAME)


test_register()

# Generated at 2022-06-23 18:03:22.226149
# Unit test for function encode
def test_encode():
    assert encode('hello') == (b'hello', 5)
    assert encode('Ł') == (b'\\xc5\\x81', 1)



# Generated at 2022-06-23 18:03:30.199069
# Unit test for function register
def test_register():
    import os
    import sys
    import unittest

    class TestRegister(unittest.TestCase):
        """ Test the function register """
        def test_register_1(self):
            """ Test case 1: test the function register """
            register()
            import codecs
            codecs.register(_get_codec_info)
            with self.assertRaises(LookupError):
                codecs.getencoder(NAME)

    _filename = os.path.abspath(__file__)
    _folder = os.path.dirname(_filename)
    _folder = os.path.join(_folder, 'test')
    sys.path.insert(0, _folder)

    try:
        unittest.main()
    except SystemExit as e:
        if e.code != 0:
            raise



# Generated at 2022-06-23 18:03:36.281522
# Unit test for function encode
def test_encode():
    # Expected
    expected = b'\\x61\\x62'

    # Input
    ab = 'ab'

    # Output
    output = encode(ab)
    output_bytes = output[0]
    output_int = output[1]

    # The output bytes should be equal to the expected bytes
    assert output_bytes == expected

    # The output integer should equal to the length of the input.
    assert output_int == len(ab)


# Generated at 2022-06-23 18:03:43.329468
# Unit test for function decode
def test_decode():
    r"""Unit test for the function 'decode'.
    """

    # This is the raw input data
    data_bytes = b'\xE2\x80\x9C\xE2\x80\x9D'

    # This is the expected output data
    out_data_bytes = b'\u201C\u201D'

    # This is encoded input data for the decode function
    in_data_bytes = b'\\xE2\\x80\\x9C\\xE2\\x80\\x9D'

    # Perform the decode function
    out, len_in = decode(in_data_bytes)

    # Check to make sure that the decoded data is correct
    assert out_data_bytes == out.encode('utf-8')

    # Check to make sure the decoded length is correct

# Generated at 2022-06-23 18:03:47.326684
# Unit test for function encode
def test_encode():
    unichar: str = '\u3042'
    test_string = f'{unichar}'
    out = encode(test_string)
    expected_out = (b'\\xe3\\x81\\x82', 1)
    assert out == expected_out



# Generated at 2022-06-23 18:03:52.169822
# Unit test for function encode
def test_encode():
    value = 'A\\x7aB'
    encoded = b'A\\x7aB'
    encoded_len = 4
    actual = encode(value)
    assert actual == (encoded, encoded_len)



# Generated at 2022-06-23 18:03:57.010482
# Unit test for function decode
def test_decode():
    text = 'H\\x65\\x6c\\x6c\\x6f\\x20\\x77\\x6f\\x72\\' \
           'x6c\\x64'
    decode_text = codecs.decode(text, NAME)
    assert decode_text == 'Hello world'



# Generated at 2022-06-23 18:04:05.033134
# Unit test for function decode
def test_decode():
    #
    # Test decoding a lone backslash to itself
    #
    data = b'\\'
    errors = 'strict'
    ans = decode(data, errors)
    expect = r'\\'
    if ans[0] != expect:
        raise AssertionError('Test failed for lone backslash')
    #
    # Test decoding escaped hexadecimal octets to the correct utf8
    # character.
    #
    data = b'\\x26\\x23\\xFB\\x63\\xE0\\x26'
    errors = 'strict'
    ans = decode(data, errors)
    expect = '&#ûcà&'
    if ans[0] != expect:
        raise AssertionError(
            'Test failed for escaped hexadecimal octets to utf8 character')

# Generated at 2022-06-23 18:04:15.049370
# Unit test for function decode
def test_decode():
    # Convert literal data
    data_str = 'this is a test'
    data_bytes = ('\\74\\68\\69\\73\\20\\69\\73\\20\\61\\20\\74\\65\\73\\74') \
        .encode('ascii')

    out_str, out_int = decode(data_bytes, errors='strict')
    assert out_str == data_str
    assert out_int == len(data_bytes)

    out_str, out_int = decode(data_bytes, errors='replace')
    assert out_str == data_str
    assert out_int == len(data_bytes)

    out_str, out_int = decode(data_bytes, errors='ignore')
    assert out_str == data_str
    assert out_int == len(data_bytes)

    # Convert an

# Generated at 2022-06-23 18:04:24.355778
# Unit test for function decode
def test_decode():
    assert decode(b'A') == ('A', 1)
    assert decode(b'\\x01\\x02\\x03') == ('\u0001\u0002\u0003', 9)
    assert decode(b'\\x01\\x02\\x03', 'ignore') == ('\u0001\u0002\u0003', 9)
    assert decode(b'\\x01\\x02\\x03', 'replace') == ('\u0001\u0002\u0003', 9)
    assert decode(b'\\x01\\x02\\x03', 'xmlcharrefreplace') == ('\u0001\u0002\u0003', 9)
    assert decode(b'\\x01\\x02\\x03', 'backslashreplace') == ('\u0001\u0002\u0003', 9)



# Generated at 2022-06-23 18:04:25.589652
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)


# Generated at 2022-06-23 18:04:28.210174
# Unit test for function register
def test_register():
    register()
    encoder = codecs.getencoder(NAME)
    assert encoder
    decoder = codecs.getdecoder(NAME)
    assert decoder


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 18:04:38.793499
# Unit test for function encode
def test_encode():
    assert encode('') == (b'', 0)
    assert encode('a') == (b'a', 1)
    assert encode('\r') == (b'\\xd', 1)
    assert encode('\U0001f44f') == (b'\\xf0\\x9f\\x91\\x8f', 1)
    assert encode('\\x') == (b'\\x5c\\x78', 2)
    assert encode('\\xFf') == (b'\\x5c\\x78\\x46\\x66', 4)
    assert encode('\\xFx') == (b'\\x5c\\x78\\x46\\x78', 4)
    assert encode('\\xFg') == (b'\\x5c\\x78\\x46\\x67', 4)
    assert encode('\\x0')

# Generated at 2022-06-23 18:04:40.142316
# Unit test for function register
def test_register():
    register()
    _ = codecs.getdecoder(NAME)



# Generated at 2022-06-23 18:04:41.430107
# Unit test for function register
def test_register():
    register()

# Register this codec globally
register()

# Generated at 2022-06-23 18:04:53.130011
# Unit test for function encode
def test_encode():
    # Test a string that contains escaped utf8 hexadecimal sequences \xHH
    # and \xHH\xHH
    text_str = 'B\xC3\xA4\xF0\xA4\xAD\xA2z'
    out = encode(text_str)
    # print(out)
    expected = b'B\\xc3\\xa4\\xf0\\xa4\\xad\\xa2z'
    assert out[0] == expected

    # Test a string that contains an escaped utf8 hexadecimal sequence
    # \xHH, which is an invalid utf8 byte.
    text_str = 'B\x80z'
    out = encode(text_str)
    # print(out)
    expected = b'B\\x80z'

# Generated at 2022-06-23 18:05:05.118842
# Unit test for function encode
def test_encode():
    def case_test(text_input, expected_output):
        output = encode(text_input)
        assert type(output) == tuple
        assert len(output) == 2
        assert type(output[0]) == bytes
        assert type(output[1]) == int
        assert output[0] == expected_output
        assert output[1] == len(text_input)

    case_test(r'\x00\x01\x02\x03\x04', b'\\0\\1\\2\\3\\4')
    case_test('\x00\x01\x02\x03\x04', b'\\0\\1\\2\\3\\4')
    case_test(b'\x00\x01\x02\x03\x04', b'\\0\\1\\2\\3\\4')


# Generated at 2022-06-23 18:05:14.435594
# Unit test for function encode
def test_encode():
    b'\\x0a' == b'\\10'
    encode('text\\xa0') == b'text\\xa0'
    encode('text\\x1a\\x00a') == b'text\\x1a\\x00a'
    encode('text\\x00\\x1a') == b'text\\x00\\x1a'
    encode('text\\x1a\\x00') == b'text\\x1a\\x00'
    encode('text\\x1a\\x1a') == b'text\\x1a\\x1a'



# Generated at 2022-06-23 18:05:25.545649
# Unit test for function encode
def test_encode():
    assert encode('abc') == (b'abc', 3)
    assert encode('abc') == (b'abc', 3)
    assert encode('abc') == (b'abc', 3)
    assert encode('\\u0033') == (b'\\u0033', 7)
    assert encode('\\u0033') == (b'\\u0033', 7)
    assert encode('\\u0033') == (b'\\u0033', 7)
    assert encode('\\x01\\x02') == (b'\\x01\\x02', 9)
    assert encode('\\x01\\x02') == (b'\\x01\\x02', 9)
    assert encode('\\x01\\x02') == (b'\\x01\\x02', 9)

# Generated at 2022-06-23 18:05:35.987974
# Unit test for function encode
def test_encode():
    # In this test, ensure that the following values are returned from the
    # encode function. Note that the test data is the same as the data in
    # the standard eutf8h.py codecs module.
    assert encode('This \x24 is a test') == (b'This \\x24 is a test', 15)
    assert encode('\u20ac') == (b'\\xe2\\x82\\xac', 1)
    # The next line is commented out because it fails.
    # assert encode('\u20ac') == (b'\xe2\x82\xac', 1)
    assert encode('\u20ac', 'surrogateescape') == (b'\x80', 1)
    assert encode('\u20ac', 'surrogatepass') == (b'\xe2\x82\xac', 1)

# Generated at 2022-06-23 18:05:41.077147
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getencodings()


if __name__ == "__main__":
    test_register()

# Generated at 2022-06-23 18:05:44.647040
# Unit test for function decode
def test_decode():
    '''Test the decode() function.'''
    hi_str: str = 'hi'
    assert hi_str.encode('utf-8').decode('utf-8') == hi_str
    assert decode(encode(hi_str)[0])[0] == hi_str



# Generated at 2022-06-23 18:05:51.539582
# Unit test for function encode
def test_encode():
    """Test encoding function.

    >>> _test_str_in_out(test_encode)
    >>> _test_str_in_out(test_encode, 'asdfasdf\tasdfafasdf\\x3E', 'text')
    >>> _test_str_in_out(test_encode, 'asdfasdf\tasdfafasdf\\x3E', 'xmlcharrefreplace')
    >>> _test_str_in_out(test_encode, 'asdfasdf\tasdfafasdf\\x3E', 'ignore')
    >>> _test_str_in_out(test_encode, 'asdfasdf\tasdfafasdf\\x3E', 'replace')

    """
    pass

