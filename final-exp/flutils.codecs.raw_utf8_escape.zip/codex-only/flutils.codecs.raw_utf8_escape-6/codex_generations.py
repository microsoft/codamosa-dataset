

# Generated at 2022-06-23 17:55:53.889318
# Unit test for function encode
def test_encode():
    """
    一个测试encode函数的例子
    """

    text = '\\u4f60\\x61\\u597d'
    byte_text, num = encode(text)
    assert byte_text == b'\u4f60\x61\u597d'
    assert num == 12



# Generated at 2022-06-23 17:56:02.853735
# Unit test for function encode
def test_encode():
    msg = 'Error in encode function'
    # Test 1
    in_str = 'ABC'
    out_bytes, out_chars_consumed = encode(in_str)
    if out_bytes != b'ABC':
        raise Exception(msg)
    if out_chars_consumed != 3:
        raise Exception(msg)

    # Test 2
    in_str = '\u00e1'
    out_bytes, out_chars_consumed = encode(in_str)
    if out_bytes != b'\\xc3\\xa1':
        raise Exception(msg)
    if out_chars_consumed != 1:
        raise Exception(msg)

    # Test 3
    in_str = '\u00e1\u00e1'

# Generated at 2022-06-23 17:56:05.700186
# Unit test for function register
def test_register():
    from codecs import getdecoder, getencoder

    codecs.register(_get_codec_info)
    getdecoder(NAME)
    getencoder(NAME)



# Generated at 2022-06-23 17:56:14.176032
# Unit test for function decode
def test_decode():
    decoded = decode(b'\\x74\\x65\\x73\\x74\\x21')
    assert decoded[0] == 'test!'
    assert decoded[1] == 10

    decoded = decode(b'\\x21\\x20\\x74\\x65\\x73\\x74')
    assert decoded[0] == '! test'
    assert decoded[1] == 10

    decoded = decode(b'\\x1b\\x5b\\x30\\x6d')
    assert decoded[0] == '\x1b[0m'
    assert decoded[1] == 4

    decoded = decode(b'\\xef\\xbf\\xbd')
    assert decoded[0] == '�'
    assert decoded[1] == 3


# Generated at 2022-06-23 17:56:22.420695
# Unit test for function decode

# Generated at 2022-06-23 17:56:33.573437
# Unit test for function encode

# Generated at 2022-06-23 17:56:38.714019
# Unit test for function decode
def test_decode():
    assert decode(b':katt:') == (':katt:', 6)
    assert decode(b'\\xF6\\xe4') == ('öä', 6)
    assert decode(b'\\xF6\\xe4', 'backslashreplace') == ('\\xF6\\xe4', 6)



# Generated at 2022-06-23 17:56:47.913422
# Unit test for function encode
def test_encode():
    assert encode('Hello') == (b'Hello', 5)
    assert encode('\U0001f600') == (b'\\xf0\\x9f\\x98\\x80', 2)
    assert encode('\U0001f600') == ('\\xf0\\x9f\\x98\\x80'.encode('utf8'), 2)
    assert encode('\u2028') == (b'\\xe2\\x80\\xa8', 2)
    assert encode('\u2028') == ('\\xe2\\x80\\xa8'.encode('utf8'), 2)
    assert encode('🐺') == (b'\\xf0\\x9f\\x90\\xba', 2)
    assert encode('🐺') == ('\\xf0\\x9f\\x90\\xba'.encode('utf8'), 2)



# Generated at 2022-06-23 17:56:49.153544
# Unit test for function register
def test_register():
    if __name__ == '__main__':
        test_register()

# Generated at 2022-06-23 17:56:53.090898
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError('Failed to register the codec.')


# EOF

# Generated at 2022-06-23 17:56:54.190139
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-23 17:57:05.657693
# Unit test for function encode
def test_encode():
    assert encode('t\\x61t') == b't\\x61t'
    assert encode('\\x9f') == b'\\x9f'
    assert encode('\\u0041') == b'\\x41'
    assert encode('\\u0061') == b'\\x61'
    assert encode('\\U00000041') == b'\\x41'
    assert encode('\\U00000061') == b'\\x61'
    assert encode('\\U0001F600') == b'\\xF0\\x9F\\x98\\x80'
    assert encode('\\U000E01F0') == b'\\xF0\\x9D\\x80\\xB0'



# Generated at 2022-06-23 17:57:17.253226
# Unit test for function encode
def test_encode():
    assert encode('abc') == (b'abc', 3)

    assert encode('Abc') == (b'Abc', 3)

    assert encode('@bc') == (b'@bc', 3)

    assert encode('aBc') == (b'aBc', 3)

    assert encode('abC') == (b'abC', 3)

    assert encode('a\u00a0bc') == (b'a\\xa0bc', 4)

    assert encode('a\u00a0Bc') == (b'a\\xa0Bc', 4)

    assert encode('a\u00a0bC') == (b'a\\xa0bC', 4)

    assert encode('a\u00a0bc', 'ignore') == (b'a\\xa0bc', 4)


# Generated at 2022-06-23 17:57:18.373972
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 17:57:21.627496
# Unit test for function register
def test_register():
    try:
        register()
    except LookupError:
        pass
    except Exception:
        assert False


# Generated at 2022-06-23 17:57:31.823090
# Unit test for function encode
def test_encode():
    # print(encode('a'))
    assert encode('a') == (b'a', 1)

    assert encode('©') == (b'\\xc2\\xa9', 1)

    assert encode('®') == (b'\\xc2\\xae', 1)

    assert encode('Á') == (b'\\xc3\\x81', 1)

    assert encode('É') == (b'\\xc3\\x89', 1)

    assert encode('Î') == (b'\\xc3\\x8e', 1)

    assert encode('Ò') == (b'\\xc3\\x92', 1)

    assert encode('Ú') == (b'\\xc3\\x9a', 1)

    assert encode('À') == (b'\\xc3\\xa0', 1)


# Generated at 2022-06-23 17:57:35.190167
# Unit test for function decode
def test_decode():
    expected = '\u2603'
    actual = decode('\\xe2\\x98\\x83')
    assert actual == (expected, 8)

if __name__ == '__main__':
    codecs.register(decode)
    test_decode()

# Generated at 2022-06-23 17:57:43.691593
# Unit test for function register
def test_register():
    """Deprecated function to ensure backwards compatability."""
    warnings.warn(
        'DEPRECATED: The function {0} has been deprecated and will be '
        'removed after 2019-10-31.'.format(register.__name__),
        category=DeprecationWarning
    )
    register()
    return codecs.getdecoder(NAME)   # type: ignore

# run unit test if this file is executed.
# if __name__ == '__main__':
#     import sys
#     module = sys.modules[__name__]
#     func_name = 'test_register'
#     func: typing.Callable = module.__dict__[func_name]
#     func()

# Generated at 2022-06-23 17:57:55.610044
# Unit test for function register
def test_register():
    import os
    import sys

    # Assert that the codec is already register (meaning it has already
    # been tested)
    try:
        codecs.getdecoder(NAME)
        codecs.getencoder(NAME)
    except LookupError:
        pass
    else:
        return

    # Not registered, so register and then test it
    register()
    codecs.getdecoder(NAME)
    codecs.getencoder(NAME)

    # Validate that the test_register() function is 'self-contained (meaning
    # that it does not depend upon any global variables). So, first save
    # all variables from the global environment.
    env_vars = os.environ
    global_vars = globals()
    local_vars = locals()
    sys_path = sys.path
    sys_

# Generated at 2022-06-23 17:58:08.247625
# Unit test for function decode
def test_decode():
    text = decode(b'\\xe2\\x88\\x9e')
    assert text[0] == '∞'

    text = decode(b'\\xe2\\x88\\x9e', errors='replace')
    assert text[0] == '�'

    text = decode(b'\\xe2\\x99\\xa5')
    assert text[0] == '♥'

    text = decode(b'\\xe2\\x99\\xa5', errors='replace')
    assert text[0] == '�'

    text = decode(b'\\xe2\\x99\\xa5\\xe2\\x99\\xa5')
    assert text[0] == '♥♥'

    text = decode(b'\\xe2\\x99\\xa5\\xe2\\x99\\xa5', errors='replace')

# Generated at 2022-06-23 17:58:19.953652
# Unit test for function decode
def test_decode():

    # This function tests the function decode.

    # Test the decoding of escaped utf-8 hexadecimal
    assert decode(b'\\xC2\\xA9', 'strict') == ('©', 9)

    # Test the decoding of escaped utf-8 hexadecimal with error handling
    assert decode(b'\\xC2\\xA9', 'ignore') == ('', 2)
    assert decode(b'\\xC2\\xA9', 'replace') == ('�', 9)
    assert decode(b'\\xC2\\xA9', 'backslashreplace') == (r'\N{COPYRIGHT SIGN}', 9)

    # Test the decoding of non escaped utf-8 hexadecimal

# Generated at 2022-06-23 17:58:27.354141
# Unit test for function encode
def test_encode():
    try:
        codecs.getencoder(NAME)
    except LookupError:
        register()
    unescaped_data = 'A string with a newline\n'
    expected = unescaped_data.encode('utf-8')
    expected = codecs.escape_encode(expected)[0]
    encoded_data, consumed_count = encode(unescaped_data)
    assert consumed_count == len(unescaped_data)
    assert encoded_data == expected


# Generated at 2022-06-23 17:58:30.438399
# Unit test for function decode
def test_decode():
    print('Begin test for function decode')
    print(decode('test'))
    print(decode('test'))
    print(decode('test\\x04'))
    print(decode('test\\x04'))


# Generated at 2022-06-23 17:58:32.410583
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False


# Generated at 2022-06-23 17:58:39.700702
# Unit test for function encode
def test_encode():
    print('test encode')
    assert encode(chr(0)) == (b'\\x00', 1)
    assert encode(chr(1)) == (b'\\x01', 1)
    assert encode(chr(255)) == (b'\\xff', 1)
    assert encode('\n') == (b'\\x0a', 1)
    assert encode('\r') == (b'\\x0d', 1)
    assert encode('\t') == (b'\\x09', 1)
    assert encode('\v') == (b'\\x0b', 1)
    assert encode('\0') == (b'\\x00', 1)
    assert encode('\a') == (b'\\x07', 1)
    assert encode('\b') == (b'\\x08', 1)

# Generated at 2022-06-23 17:58:42.793742
# Unit test for function encode
def test_encode():
    this_text = r'\u00e0'
    this_errors = 'strict'
    out = encode(this_text, this_errors)
    assert out[0] == b'\\xe0\\x80\\xa0'



# Generated at 2022-06-23 17:58:49.248740
# Unit test for function decode
def test_decode():
    text = '\u9f8d\u64cd\u4f5c\u7cfb\u7edf'
    text_escaped = '\\u9f8d\\u64cd\\u4f5c\\u7cfb\\u7edf'
    text_bytes = codecs.getencoder('unicode_escape')(text, 'strict')[0]
    assert decode(text_bytes)[0] == text
    text_bytes = bytes(text_escaped, encoding='utf-8')
    assert decode(text_bytes)[0] == text


# Generated at 2022-06-23 17:58:55.716154
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)
    assert codecs.getencoder(NAME)[0] is encode
    assert codecs.getdecoder(NAME)[0] is decode


# Unit tests

# Generated at 2022-06-23 17:59:04.597458
# Unit test for function encode
def test_encode():
    """
    Test function encode with its parameters.
    """
    assert encode('abc', 'strict')[0] == b'abc'
    assert encode('abc', 'strict')[1] == 3
    assert encode('abc', 'strict') == (b'abc', 3)
    assert encode('a\u1234c', 'strict')[0] == b'a\\u1234c'
    assert encode('a\u1234c', 'strict')[1] == 3
    assert encode('a\u1234c', 'strict') == (b'a\\u1234c', 3)
    assert encode('a\u12345bc', 'ignore')[0] == b'a\\u12345bc'
    assert encode('a\u12345bc', 'ignore')[1] == 3
    assert encode

# Generated at 2022-06-23 17:59:09.050752
# Unit test for function encode
def test_encode():
    # Unit test for function encode
    def _encode(text: _Str) -> bytes:
        out_bytes, _len = encode(text)
        return out_bytes

    # Check that encode returns valid utf8 bytes
    assert _encode('abc') == b'abc'

    # Check that encode returns a bytes object
    assert isinstance(_encode('abc'), bytes)

    # Check that encode handles non-ascii characters
    assert _encode('\u03b1') == b'\\xce\\xb1'

    # Check that encode handles non-ascii characters
    assert _encode('\u039B') == b'\\xce\\x9b'

    # Check that encode handles escaped hexadecimal
    assert _encode('\\xce\\xb1') == b'\\xce\\xb1'

# Generated at 2022-06-23 17:59:11.826495
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)      # type: ignore

# Generated at 2022-06-23 17:59:21.385489
# Unit test for function encode
def test_encode():
    # Test an ascii string.
    assert encode('ascii text') == (b'ascii text', 9)

    # Test a latin-1 string.
    assert encode('á') == (b'\\xe1', 1)

    # Test a unicode string.
    assert encode('🏁') == (b'\\xf0\\x9f\\x8f\\x81', 1)

    # Test a unicode string containing escaped hexadecimal.
    assert encode('a\\xE1\\xe1') == (b'a\\xe1\\xe1', 6)

    # Test a unicode string containing escaped unicode hexadecimal.
    assert encode('a\\x{E1}\\x{e1}') == (b'a\\xe1\\xe1', 6)

    # Test an ascii string

# Generated at 2022-06-23 17:59:32.522438
# Unit test for function encode
def test_encode():
    input_str: _Str = '\u6C17\u6765\u5841\uFF08\u8A00\u8449\uFF09'
    #
    # The given string should contain 4 characters.
    assert(len(input_str) == 4)
    #
    # The string should contain utf8 characters
    # that are outside of the ascii range.
    for char in input_str:
        assert(ord(char) > 127)
    #
    output_tuple = encode(input_str)
    #
    # The given string should convert to 25 bytes of escaped utf8 hexadecimal.
    assert(len(output_tuple[0]) == 25)
    assert(output_tuple[1] == 4)

# Generated at 2022-06-23 17:59:43.819780
# Unit test for function encode
def test_encode():
    assert encode('\\x61') == (b'\\97', 2)
    assert encode('\\xC2\\xB0') == (b'\\202\\176', 4)
    assert encode('\\u0061') == (b'\\97', 2)
    assert encode('\\U00000061') == (b'\\97', 2)
    assert encode('\\u000061') == (b'\\97', 2)
    assert encode('\\u00C2B0') == (b'\\202\\176', 4)
    assert encode('\\U0002F800') == (b'\\240\\144\\128\\128', 8)
    assert encode('\\U00010000') == (b'\\240\\144\\128\\128', 8)
    assert encode('text \\x61') == (b'text \\97', 8)

# Generated at 2022-06-23 17:59:46.675350
# Unit test for function register
def test_register():
    def _test():
        codecs.register(_get_codec_info)
    pytest.raises(LookupError, _test)

# noinspection PyProtectedMember

# Generated at 2022-06-23 17:59:49.535183
# Unit test for function encode
def test_encode():
    b, n = encode(text="abc")
    assert b == b'abc'
    assert n == 3
    b, n = encode(text="\\x41")
    assert b == b'A'
    assert n == 1
    b, n = encode(text="\\u1234")
    assert b == b'\xe1\x88\xb4'
    assert n == 1



# Generated at 2022-06-23 17:59:57.838551
# Unit test for function decode

# Generated at 2022-06-23 18:00:07.743971
# Unit test for function encode
def test_encode():
    text = (
        '\\x00\\x01\\x02\\x03\\x04\\x05\\x06\\x07'
        '\\x08\\x09\\n\\x0b\\x0c\\r\\x0e\\x0f'
    )
    text_bytes_utf8, text_length = encode(text)

    # Check for the correct return type of function 'encode'.
    assert isinstance(text_bytes_utf8, bytes)

    # Check for the correct return length.
    assert text_length == len(text)

    # Check for the correct encoded values.

# Generated at 2022-06-23 18:00:16.858024
# Unit test for function decode
def test_decode():
    # Import modules
    import random

    # Create a list of random utf8 bytes
    bytes_list = []
    for i in range(50):
        bytes = random.randint(0, 255)
        bytes_list.append(bytes)

    # Create a pattern of escaped utf8 hexadecimal bytes
    str_esc_utf8 = r''
    for bytes in bytes_list:
        str_esc_utf8 += r"\%s" % hex(bytes)[2:]
    str_esc_utf8 = r'%s' % str_esc_utf8

    # Convert the escaped utf8 hexadecimal string into bytes.
    bytes_esc_utf8 = str_esc_utf8.encode('utf-8')

    # Convert the escaped utf8 hexadecimal bytes into a string.
    str

# Generated at 2022-06-23 18:00:25.153758
# Unit test for function decode
def test_decode():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)

    text_byte_utf8 = b"\\xc3\\x83\\xc2\\x81"
    text_byte_utf8_alt = b"\\xc3\\x83"
    text_byte_utf8_alt += b"\\xc2\\x81"

    for text_byte in [text_byte_utf8, text_byte_utf8_alt]:
        # noinspection PyTypeHints
        bytes_to_str, n_bytes = codecs.getdecoder(NAME)(text_byte)
        assert n_bytes == len(text_byte)
        assert bytes_to_str == "Á\x01"

    # noinspection PyTypeHints
   

# Generated at 2022-06-23 18:00:27.908459
# Unit test for function encode
def test_encode():
    """Test function :func:`encode`.

    """
    assert encode('\u2713') == b'\\xe2\\x9c\\x93'



# Generated at 2022-06-23 18:00:34.940130
# Unit test for function encode
def test_encode():
    assert encode(r'\xe6\xb5\xb7') == (b'\\xe6\\xb5\\xb7', 3)
    assert encode(r'\xe6\xb5\xb7\n') == (b'\\xe6\\xb5\\xb7\\n', 4)
    assert encode(r'\xe6\xb5\xb7山') == (b'\\xe6\\xb5\\xb7\\xe5\\xb1\\xb1', 5)
    assert encode(r'\xe6\xb5\xb7山\n') == (b'\\xe6\\xb5\\xb7\\xe5\\xb1\\xb1\\n', 6)

    assert encode('\xe6\xb5\xb7') == (b'\\xe6\\xb5\\xb7', 3)

# Generated at 2022-06-23 18:00:38.963782
# Unit test for function decode
def test_decode():
    assert decode(
        b'\\x66\\x71\\x69\\x7a\\x79\\xe8\\xa7\\xb6\\xe7\\x9a\\x84',
    ) == ('fqizy觶的', 13)
    assert decode(
        b'\\x66\\x71\\x69\\x7a\\x79\\xe8\\xa7\\xb6\\xe7\\x9a\\x84\\n',
    ) == ('fqizy觶的\n', 14)



# Generated at 2022-06-23 18:00:44.014509
# Unit test for function decode
def test_decode():
    text = "\\x70\\x69\\x20\\x77\\x61\\x73\\x20\\x68\\x65\\x72\\x65\\x20"
    out, length = decode(text)
    assert out == "pi was here"
    assert length == 36


# Generated at 2022-06-23 18:00:45.733081
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None

# Generated at 2022-06-23 18:00:52.458556
# Unit test for function encode
def test_encode():
    input_str = "\\xE3\\x81\\x93\\xE3\\x82\\x93\\xE3\\x81\\xAB\\xE3\\x81\\xA1\\xE3\\x81\\xAF"
    output_str = "こんにちは"

    test_input_str = input_str.encode('utf-8')
    print(test_input_str)
    test_output_str = cast(bytes, output_str.encode('utf-8'))
    print(test_output_str)
    assert encode(input_str)[0] == test_output_str


# Generated at 2022-06-23 18:01:02.279363
# Unit test for function decode
def test_decode():
    """
    Test the decode function.
    """

    # The tests are written in the following format:
    #
    # The key is the input to the decode function.
    # The value is a tuple of the expected output and the expected
    # number of characters consumed.
    #
    # On error, the key is the only thing shown to the user.

# Generated at 2022-06-23 18:01:13.138746
# Unit test for function decode
def test_decode():
    # Test basic utf-8 hexadecimal (\\xHH)
    assert decode(b'\\x41')[0] == 'A'
    assert decode(b'\\xc3\\xa9')[0] == 'é'
    assert decode(b'\\x45\\xc3\\xa9\\xe6\\xb0\\xb4')[0] == 'É水'

    # Test escaped utf8 hexadecimal (\\\\xHH)
    assert decode(b'\\\\x41')[0] == '\\A'
    assert decode(b'\\\\xc3\\\\xa9')[0] == '\\é'
    assert decode(b'\\\\x45\\\\xc3\\\\xa9\\\\xe6\\\\b0\\\\xb4')[0] == '\\É\\水'

    # Test escaped utf8 hexadecimal (

# Generated at 2022-06-23 18:01:20.603675
# Unit test for function decode
def test_decode():
    # Check that is returns the expected value
    data = b'\\x41'
    out = decode(data)
    assert out[0] == "A"
    assert out[1] == 3

    # Check that it raises an exception when invalid hexadecimal is given
    data = b'\\xXX'
    exception = False
    try:
        out = decode(data)
    except UnicodeDecodeError:
        exception = True
    assert exception



# Generated at 2022-06-23 18:01:22.041243
# Unit test for function register
def test_register():
    register()
    codecs.lookup_error('eutf8h')

# Generated at 2022-06-23 18:01:33.647153
# Unit test for function decode
def test_decode():
    data = '\\x48\\x65\\x6c\\x6c\\x6f\\x20\\x57\\x6f\\x72\\x6c\\x64\\x21'
    data = '\\U0001F638'
    data = '\\U0001F639'
    data = '\\U0001F63A'
    data = '\\U0001F63B'
    data = '\\U0001F63C'
    data = '\\U0001F63D'
    data = '\\U0001F63E'
    data = '\\U0001F63F'
    data = '\\U0001F640'
    data = '\\U0001F641'
    data = '\\U0001F642'
    data = '\\U0001F643'
    data = '\\U0001F644'
   

# Generated at 2022-06-23 18:01:35.184004
# Unit test for function register
def test_register():
    assert codecs.lookup(NAME) is not None


# Generated at 2022-06-23 18:01:44.473600
# Unit test for function decode

# Generated at 2022-06-23 18:01:48.251991
# Unit test for function register
def test_register():
    # -> None
    codecs.register(_get_codec_info)
    assert NAME in codecs.list_encodings()
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None
    import encodings  # type: ignore
    assert 'eutf8h' in dir(encodings)


register()



# Generated at 2022-06-23 18:01:58.054006
# Unit test for function decode
def test_decode():
    assert decode(b'\\xe2\\x9c\\x93') == ('✓', 10)
    assert decode(b'\\xe2\\x9c\\x93\\x0a\n') == ('✓\n', 10)
    assert decode(b'\\xe2\\x9c\\x93\n') == ('✓\n', 8)
    assert decode(b'\\xe2\\x9c\\x93\\x0d') == ('✓\r', 10)
    assert decode(b'\\xe2\\x9c\\x93\\x0d\n') == ('✓\r\n', 10)
    assert decode(b'\\xe2\\x9c\\x93\r') == ('✓\r', 8)

# Generated at 2022-06-23 18:01:59.581201
# Unit test for function decode
def test_decode():
    assert decode(b'\\x65\\x66\\x67') == ('efg', 11)



# Generated at 2022-06-23 18:02:04.838672
# Unit test for function encode
def test_encode():
    text = '☹'
    utf8_text = encode(text)[0]
    assert utf8_text == b'\\xe2\\x98\\xb9'

    text = '\U0001F639'
    utf8_text = encode(text)[0]
    assert utf8_text == b'\\xf0\\x9f\\x98\\xb9'

    text = '\ud83d\uab08'
    utf8_text = encode(text)[0]
    assert utf8_text == b'\\xf0\\x9f\\xa6\\x88'



# Generated at 2022-06-23 18:02:15.220787
# Unit test for function encode

# Generated at 2022-06-23 18:02:24.869264
# Unit test for function register
def test_register():
    register()
    str_eutf8h = 'こんにちは。'
    str_eutf8h_e = '\\xE3\\x81\\x93\\xE3\\x82\\x93\\xE3\\x81\\xAB\\xE3\\x81\\xA1\\xE3\\x81\\xAF\\xE3\\x80\\x82'

    # Encode str -> bytes
    bytes_eutf8h = codecs.encode(str_eutf8h, NAME)
    assert bytes_eutf8h == str_eutf8h_e.encode()

    # Decode bytes -> str
    str_eutf8h = codecs.decode(bytes_eutf8h, NAME)
    assert str_eutf8h == str_eutf8h_e

# Generated at 2022-06-23 18:02:25.583517
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 18:02:37.014440
# Unit test for function decode

# Generated at 2022-06-23 18:02:47.395144
# Unit test for function decode

# Generated at 2022-06-23 18:02:50.167812
# Unit test for function register
def test_register():
    try:
        assert register()
    except LookupError:
        assert False
    else:
        assert True

test_register()  # Run the test.



# Generated at 2022-06-23 18:02:53.432856
# Unit test for function register
def test_register():
    import codecs
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)
    return


# Generated at 2022-06-23 18:02:55.640880
# Unit test for function encode
def test_encode():
    assert encode('a') == (b'a', 1)
    assert encode('\n') == (b'\\x0a', 1)



# Generated at 2022-06-23 18:03:04.434889
# Unit test for function encode
def test_encode():
    assert encode('𝐒𝐓𝐀𝐑') == (b'\\xF0\\x9D\\x90\\x92\\xF0\\x9D\\x90\\xA3\\xF0\\x9D\\x90\\xA0\\xF0\\x9D\\x90\\xA1', 4)

# Generated at 2022-06-23 18:03:07.349497
# Unit test for function decode
def test_decode():
    data = b'\\xCE\\xBB\\xCE\\xB1\\xCF\\x82'
    result = '\xCE\xBB\xCE\xB1\xCF\x82'
    assert decode(data) == (result, len(data))

# Generated at 2022-06-23 18:03:19.061894
# Unit test for function decode
def test_decode():
    from test.support import run_unittest as _run_unittest
    from test.test_bytes import HexBytesTest as _HexBytesTest

    class TestDecode(_HexBytesTest):
        # The following 3 constants need to be overridden
        # for each encoding.
        encoding = NAME
        tstring = (
            '\\u0041\\u0042\\u0043\\u0044\\u0045\\u0046\\u0047\\u0048\\u0049'
            '\\u004a\\u004b\\u004c\\u004d\\u004e\\u004f\\u0050'
        )

# Generated at 2022-06-23 18:03:28.698035
# Unit test for function encode
def test_encode():
    test_strings = [
        'hello world',
        'привет мир',
        '\\xFF',
        '\\xed\\xa0\\x80',
        '\\xed\\xaf\\x80\\n'
    ]

    test_result = {
        'hello world': 'hello world',
        'привет мир': 'привет мир',
        '\\xFF': '\\xff',
        '\\xed\\xa0\\x80': '\\xed\\xa0\\x80',
        '\\xed\\xaf\\x80\\n': '\\xed\\xaf\\x80\\n'
    }

    for test_string in test_strings:
        assert encode(test_string)[0].dec

# Generated at 2022-06-23 18:03:33.048613
# Unit test for function decode
def test_decode():
    assert decode(b'\\xF0\\x9F\\x99\\x8F\\x20\\x68\\x65\\x6C\\x6C\\x6F\\x20\\x77\\x6F\\x72\\x6C\\x64') == ('🙏 hello world', 22)


# Generated at 2022-06-23 18:03:41.318338
# Unit test for function register
def test_register():
    # noinspection PyUnresolvedReferences
    """Test for the function codecs_eutf8h.register"""
    import io
    import textwrap
    from typing import IO

    from python_to_unicode.common import _c

    def _get_text_output(text: str) -> str:
        """Get the text output for the given text input."""
        register()
        text_output = ""
        data = text.encode(NAME)
        data = cast(bytes, data)
        data = data.decode(NAME)
        text_output += data
        return text_output

    def _main(
            file: IO[str],
            argv: Optional[Tuple[str, ...]] = None
    ) -> None:
        """Test if the function codecs_eutf8h.register works."""


# Generated at 2022-06-23 18:03:50.188276
# Unit test for function decode
def test_decode():
    from textwrap import dedent
    from sys import version_info

    # noinspection DuplicatedCode
    def do_test_function(
            data: _ByteString,
            expected: _Str,
            errors: _Str = 'strict'
    ) -> None:
        # noinspection DuplicatedCode
        def do_assert(
                out,
                data_len,
                expected_len,
                text_input,
                expected_input,
        ) -> None:
            assert out == expected_input
            assert data_len == expected_len
            assert len(out) == len(expected_input)
            assert text_input == expected_input

        out, text_len = decode(data, errors)
        text_input = cast(_Str, out)
        expected_input = cast(_Str, expected)

# Generated at 2022-06-23 18:03:56.815429
# Unit test for function register
def test_register():
    # noinspection PyUnusedLocal
    def _test_case(i):
        register()
        codecs.register(_get_codec_info)

    # Call function:
    _test_case(0)

    # Check exception
    # noinspection PyTypeChecker
    with pytest.raises(TypeError):
        codecs.register(None)



# Generated at 2022-06-23 18:04:00.551201
# Unit test for function encode
def test_encode():
    assert encode('Hello world!') == (b'H\\x65\\x6c\\x6c\\x6f\\x20\\x77\\x6f'
                                      b'\\x72\\x6c\\x64\\x21', 13)


# Generated at 2022-06-23 18:04:04.281161
# Unit test for function encode
def test_encode():
    result = encode('foo\\x42\\x42\\x42\\n')
    expect = (b'foo\\x42\\x42\\x42\\n', 13)
    assert result == expect



# Generated at 2022-06-23 18:04:06.752231
# Unit test for function register
def test_register():
    assert codecs.getdecoder('eutf8h') is not None

# Generated at 2022-06-23 18:04:10.284773
# Unit test for function register
def test_register():
    register()
    code_info = codecs.getdecoder(NAME)
    assert code_info.name == NAME
    assert code_info.encode == encode
    assert code_info.decode == decode

# Generated at 2022-06-23 18:04:21.432301
# Unit test for function decode

# Generated at 2022-06-23 18:04:32.391526
# Unit test for function decode
def test_decode():
    # Test function decode with the simplest case.
    test_data_1 = b'\\x65\\x66'
    test_result_1, _ = decode(test_data_1)
    assert test_result_1 == 'ef'

    # Test function decode with an escaped sequence that does not
    # represent a valid utf-8 byte
    test_data_2 = b'\\x96'
    try:
        decode(test_data_2)
        assert False
    except UnicodeDecodeError:
        pass

    # Test function decode with an escaped sequence that is not a
    # hexadecimal number.
    test_data_3 = b'\\x9k'
    try:
        decode(test_data_3)
        assert False
    except UnicodeDecodeError:
        pass

    # Test function decode with an

# Generated at 2022-06-23 18:04:42.038994
# Unit test for function encode
def test_encode():
    assert encode('a') == (b'a', 1)
    assert encode('abc') == (b'abc', 3)
    assert encode('\x00') == (b'\\0', 1)
    assert encode('\x01') == (b'\\1', 1)
    assert encode('\x02') == (b'\\2', 1)
    assert encode('\x03') == (b'\\x3', 1)
    assert encode('\x04') == (b'\\x4', 1)
    assert encode('\x05') == (b'\\x5', 1)
    assert encode('\x06') == (b'\\x6', 1)
    assert encode('\x07') == (b'\\a', 1)
    assert encode('\x08') == (b'\\b', 1)
    assert encode

# Generated at 2022-06-23 18:04:53.129733
# Unit test for function encode
def test_encode():
    # basic test case
    result_bytes, number_chars = encode('\\x61\\x62')
    assert result_bytes == b'ab'
    assert number_chars == 4

    # escaped backslash test case
    #  with two backslashes
    result_bytes, number_chars = encode('\\\\x61\\\\x62')
    assert result_bytes == b'ab'
    assert number_chars == 8

    #  with three backslashes
    result_bytes, number_chars = encode('\\\\\\x61\\\\\\x62')
    assert result_bytes == b'\\ab\\'
    assert number_chars == 8

    #  with four backslashes
    result_bytes, number_chars = encode('\\\\\\\\x61\\\\\\\\x62')
    assert result_bytes == b'\\\\ab\\\\'


# Generated at 2022-06-23 18:04:56.589864
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)
    assert codecs.getencoder(NAME)

# Generated at 2022-06-23 18:05:00.870146
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder('eutf8h')
    except LookupError:
        assert True
    else:
        assert False, "Codec 'eutf8h' exists"

if __name__ == "__main__":
    main()

# Generated at 2022-06-23 18:05:01.744658
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 18:05:02.629500
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-23 18:05:10.088245
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    test_encode = encode('€')
    assert test_encode == b'\\xe2\\x82\\xac', test_encode
    test_encode = encode('\\')
    assert test_encode == b'\\x5c', test_encode
    test_encode = encode('\n')
    assert test_encode == b'\n', test_encode
    test_decode = decode(b'\\xe2\\x82\\xac')
    assert test_decode == ('€', 5), test_decode
    test_decode = decode(b'\\x5c')
    assert test_decode == ('\\', 4), test_decode
    test_decode = decode(b'\n')
    assert test_decode

# Generated at 2022-06-23 18:05:19.124497
# Unit test for function decode
def test_decode():
    assert decode(b'This is a string.') == ('This is a string.', 17)
    assert decode(b'This is a string.') == ('This is a string.', 17)
    assert decode(b'\\x00\\x02\\x01\\x03This is a string.') == ('\u0002\u0001\u0003This is a string.', 20)
    assert decode(b'\\u00a2\\x7cThis is a string.') == ('¢|This is a string.', 14)
    assert decode(b'\\u00a2\\x7cThis is a string.') == ('¢|This is a string.', 14)
    assert decode(b'\\U000000a2\\x7cThis is a string.') == ('¢|This is a string.', 18)

# Generated at 2022-06-23 18:05:22.590763
# Unit test for function register
def test_register():
    """Unit test for function 'register'."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)



# Generated at 2022-06-23 18:05:26.924489
# Unit test for function register
def test_register():
    """
    Test to check if the codec has been registered.
    """
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore

# Generated at 2022-06-23 18:05:37.634685
# Unit test for function decode
def test_decode():
    """
    run pytest on this file
    """
    # test 1
    assert decode(b'\\x41') == ('A', 5)

    # test 2
    assert decode(b'\\x41\\x54') == ('AT', 7)

    # test 3
    assert decode(b'\\xc2\\x80') == ("\u0080", 7)

    # test 4
    assert decode(b'\\xc2\\x80\\x41') == ("\u0080A", 10)

    # test 5
    assert decode(b'\\xc2\\x80\\x41\\x54') == ("\u0080AT", 12)

    # test 6
    assert decode(b'\\xc2\\x80\\xc2\\x80') == ("\u0080\u0080", 14)

    # test 7


# Generated at 2022-06-23 18:05:40.090022
# Unit test for function register
def test_register():
    codec_info: codecs.CodecInfo = codecs.lookup(NAME)
    codec_info.getencoder('test')  # type: ignore



# Generated at 2022-06-23 18:05:48.210082
# Unit test for function encode
def test_encode():
    assert encode('abc') == (b'abc', 3), "abc"
    assert encode('\x7f') == (b'\x7f', 1), "\\7f"
    assert encode('\x80') == (b'\\x80', 1), "\\x80"

    assert encode('a\x80b') == (b'a\\x80b', 3), "a\\x80b"

    assert encode('\x7f\x80\x7f') == (b'\x7f\\x80\x7f', 3), "\\x7f\\x80\\x7f"

    assert encode('\x7f') == (b'\x7f', 1), "\\x7f"
    assert encode('\x80') == (b'\\x80', 1), "\\x80"


#