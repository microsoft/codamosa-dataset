

# Generated at 2022-06-23 17:55:58.782088
# Unit test for function encode
def test_encode():
    test_cases: List[Tuple[str, str, str]] = [
        (
            'apple',
            'apple',
            'apple',
        ),
        (
            'a\\x41pple',
            'aBpple',
            'a\\x42pple',
        ),
        (
            'a\\xE4pple',
            'äpple',
            '\\xC3\\xA4pple',
        ),
    ]
    for test_case in test_cases:
        text, expect_text, expect_bytes = test_case
        out_bytes, out_len = encode(text)
        assert out_bytes == expect_bytes.encode('utf-8')
        assert out_len == len(text)



# Generated at 2022-06-23 17:56:02.775458
# Unit test for function encode
def test_encode():
    inputStr = "\\x41\\x42"
    assert encode(
        inputStr,
        errors='strict'
    ) == (b'\\\\x41\\\\x42', 6)



# Generated at 2022-06-23 17:56:04.416509
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)
    return



# Generated at 2022-06-23 17:56:10.852256
# Unit test for function decode
def test_decode():
    tests = [
        ('\\x61', 'a'),
        ('\\x62\\x63', 'bc'),
        ('\\x41\\x42\\x43', 'ABC'),
        ('\\x1F\\x1E\\x1D\\x1C', '¼½¾⁄')
    ]

    for byte_str, expected_str in tests:
        result = decode(byte_str.encode('utf8'))
        print(result)
        assert result[0] == expected_str
    return


# Generated at 2022-06-23 17:56:13.824477
# Unit test for function encode
def test_encode():
    assert encode(b'\\x5e') == (b'\\\\x5e', 1)



# Generated at 2022-06-23 17:56:16.481347
# Unit test for function register
def test_register():
    register()
    obj = codecs.getdecoder(NAME)
    obj(b'\\x20')


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 17:56:23.639884
# Unit test for function encode
def test_encode():
    # '\xe6\x9c\xaa\xe8\x83\xbd\xe8\xa6\x96\xe8\x81\xbf\xe8\x87\xb3'
    # '\xe7\xbb\x99\xe5\xae\xa2\xe6\x88\xbf\xe6\x80\x95\xe4\xb8\x80\xe4\xbb\x87'
    # '\xe6\x89\x80\xe8\xa6\x81'
    text = '未能視能見至'
    text += '給客房怕一仇'
    text += '所要'


# Generated at 2022-06-23 17:56:25.752321
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)   # type: ignore

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 17:56:28.603714
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore
    assert codecs.getdecoder(NAME) is not None



# Generated at 2022-06-23 17:56:36.861210
# Unit test for function encode
def test_encode():
    text_input = str('Añg\xEBl')
    errors_input = str('strict')
    text_bytes_utf8 = text_input.encode('utf-8')
    text_str_latin1 = text_bytes_utf8.decode('unicode_escape')
    text_bytes_utf8 = text_str_latin1.encode('latin1')
    # Convert the utf8 bytes into a string.
    try:
        text_str = text_bytes_utf8.decode('utf-8', errors=errors_input)
    except UnicodeDecodeError as e:
        raise UnicodeEncodeError(
            'eutf8h',
            str(text_input),
            e.start,
            e.end,
            e.reason,
        )

    # Convert each character

# Generated at 2022-06-23 17:56:46.849003
# Unit test for function register
def test_register():
    # noinspection PyUnresolvedReferences
    from . import eutf8h

    # noinspection PyUnresolvedReferences
    from .eutf8h import encode  # type: ignore

    # noinspection PyUnresolvedReferences
    from .eutf8h import decode  # type: ignore

    # noinspection PyUnresolvedReferences
    from .eutf8h import register

    import sys
    if sys.stdout.encoding == 'utf-8':
        codecs_name = 'eutf8h'
    else:
        codecs_name = 'eutf8h_ascii'
    register()

    # Convert the string into utf-8 bytes.
    string_utf8 = encode('foo')

    # Register this codec.
    codecs.register(_get_codec_info)

    # Convert

# Generated at 2022-06-23 17:56:49.641276
# Unit test for function decode
def test_decode():
    data = b'\\u81ea\\x52\\u7531'
    out, length = decode(data)
    assert out == '自由'
    assert length == len(data)



# Generated at 2022-06-23 17:56:59.321094
# Unit test for function decode
def test_decode():
    assert decode(b'') == ('', 0)
    assert decode(b' ') == (' ', 1)
    assert decode(b'`') == ('`', 1)
    assert decode(b'@') == ('@', 1)
    assert decode(b'\x00') == ('\x00', 1)
    assert decode(b'\x12') == ('\x12', 1)
    assert decode(b'\x7F') == ('\x7F', 1)
    assert decode(b'\x80') == ('\u0080', 1)
    assert decode(b'\xFF') == ('\u00FF', 1)
    assert decode(b'\u0100') == ('\u0100', 2)
    assert decode(b'\u20AC') == ('\u20AC', 3)
    assert decode

# Generated at 2022-06-23 17:57:11.541194
# Unit test for function encode
def test_encode():

    # Unicode character 'LOVE' in Chinese
    # (4-digit escaped utf8 hexadecimal)
    # (utf8 hexadecimal bytes: E7 8E 8B)
    # (utf8 bytes: 0xE7 0x8E 0x8B)
    unicode_char = '\u7231'

    # Unicode character 'HEART' in Chinese
    # (6-digit escaped utf8 hexadecimal)
    # (utf8 hexadecimal bytes: F0 9F 92 AA)
    # (utf8 bytes: 0xF0 0x9F 0x92 0xAA)
    unicode_code_point = '\U0001F60A'

    # Unicode character 'CAT FACE WITH WRY SMILE'
    # (8-digit escaped utf8 hexadecimal)
   

# Generated at 2022-06-23 17:57:18.154635
# Unit test for function decode
def test_decode():
    lang = '\xea\xb8\x80\xed\x95\x9c\xec\x9a\xb0\xeb\xb2\x94'
    lang_expected = '영한우범'
    lang_bytes = lang.encode(encoding='eutf8h')
    lang_decoded = lang_bytes.decode(encoding='eutf8h', errors='strict')
    assert lang_decoded == lang_expected

# Generated at 2022-06-23 17:57:20.726766
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder('eutf8h')



# Generated at 2022-06-23 17:57:31.216150
# Unit test for function encode
def test_encode():
    """Test encode function."""
    # Test 1: empty string
    text = ''
    actual = encode(text)
    expected = (b'', 0)
    assert actual == expected

    # Test 2: printable ASCII
    text = 'Hello world'
    actual = encode(text)
    expected = (b'Hello world', 11)
    assert actual == expected

    # Test 3: non-printable ASCII
    text = '\x00\x01\x02\x03\x04\x05\x06\x07\x08\x0b\x0c\x0e\x0f'

# Generated at 2022-06-23 17:57:33.979734
# Unit test for function decode
def test_decode():
    data_bytes = bytes(b'\\xC2\\xB5')
    result = decode(data_bytes)
    assert result[0] == 'μ' and result[1] == 6



# Generated at 2022-06-23 17:57:39.122937
# Unit test for function encode
def test_encode():
    hex_bytes = b'abc \\xE1\\x88\\xB4 \\xF0\\x9F\\x98\\x81'
    expected_str = 'abc ሴ 😁'
    out_bytes, out_len = encode(expected_str)
    assert out_bytes == hex_bytes
    assert out_len == len(expected_str)



# Generated at 2022-06-23 17:57:44.833812
# Unit test for function decode
def test_decode():
    assert decode(b'\\x68\\x65\\x6c\\x6c\\x6f') == ('hello', 20)
    assert decode(b'\\x68\\x65\\x6c\\x6c\\x6f\\x20\\xe3\\x81\\x93\\xe3\\x82'
                  b'\\x93\\xe3\\x81\\xab\\xe3\\x81\\xa1\\xe3\\x81\\xaf') == \
        ('hello こんにちは', 40)
    return



# Generated at 2022-06-23 17:57:55.959052
# Unit test for function encode
def test_encode():
    assert encode(r'abc') == (b'abc', 3)
    assert encode(r'\x23') == (b'\x23', 4)
    assert encode(r'\x55') == (b'\x55', 4)
    assert encode(r'\x55\x56') == (b'\x55\x56', 7)
    assert encode(r'\x55\x56') == (b'\x55\x56', 7)
    assert encode(r'\u5678') == (b'\xe5\x99\xb8', 6)
    assert encode(r'\U12345678') == (b'\xf1\x88\xa4\xb8', 10)

# Generated at 2022-06-23 17:57:59.417109
# Unit test for function encode
def test_encode():
    encoded, consumed = encode('\u0100')
    assert consumed == 1
    assert encoded == b'\\xC4\\x80'



# Generated at 2022-06-23 17:58:01.466101
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore

# Generated at 2022-06-23 17:58:05.236056
# Unit test for function register
def test_register():
    register()
    from codecs import getdecoder, getencoder
    assert getdecoder(NAME)   # type: ignore
    assert getencoder(NAME)   # type: ignore

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 17:58:13.948948
# Unit test for function decode
def test_decode():
    assert decode(b'\\x41\\x42\\x43\\x44') == ('ABCD', 8)
    assert decode(b'\\x41\\x41') == ('\u0041\u0041', 4)
    assert decode(b'\\x41\\x42') == ('AB', 4)
    assert decode(b'\\x41\\x42\\x43') == ('ABC', 6)
    assert decode(b'\\x41\\x42\\x43\\x44') == ('ABCD', 8)
    assert decode(b'\\x41\\x42\\x43\\x44\\x45') == ('ABCDE', 10)
    assert decode(b'\\x41\\x42\\x43\\x44\\x45\\x46') == ('ABCDEF', 12)

# Generated at 2022-06-23 17:58:26.147531
# Unit test for function decode
def test_decode():
    test_str_short = 'hello world'
    test_str_long = '''
    hello world
    hello world
    hello world
    hello world
    hello world
    hello world
    hello world
    hello world
    hello world
    hello world
    hello world
    hello world
    hello world
    hello world
    hello world
    hello world
    hello world
    hello world
    hello world
    hello world
    hello world
    hello world
    hello world
    hello world
    hello world
    hello world
    hello world
    hello world
    '''
    test_str_long += test_str_long

    str_latin1 = test_str_short.encode('latin1').decode('unicode_escape')

# Generated at 2022-06-23 17:58:30.048648
# Unit test for function encode
def test_encode():
    result = encode('\udc80\udc80')
    assert result == (b'\\\\x80\\\\x80', 2)
    result = encode('\udc80\udc80', 'replace')
    assert result == (b'?\\\\x80', 1)



# Generated at 2022-06-23 17:58:38.236486
# Unit test for function encode

# Generated at 2022-06-23 17:58:43.605852
# Unit test for function register
def test_register():
    register()
    result = codecs.getdecoder(NAME)
    assert result is not None
    decoder = result[0]
    encoder = codecs.getencoder(NAME)[0]
    assert decoder is not None
    assert callable(decoder)
    assert encoder is not None
    assert callable(encoder)



# Generated at 2022-06-23 17:58:50.371270
# Unit test for function decode
def test_decode():
    assert decode(b'\\x61\\x62') == ('ab', 4)
    assert decode(b'\\x61') == ('a', 2)
    assert decode(b'\\x62') == ('b', 2)
    assert decode(b'\\x41\\x43\\x42') == ('ACB', 6)
    assert decode(b'\\xC3\\xA9') == ('é', 4)
    assert decode(b'\\xC2\\xA2') == ('¢', 4)
    assert decode(b'\\xED') == ('í', 2)
    assert decode(b'\\xE6\\x97') == ('없', 4)



# Generated at 2022-06-23 17:58:58.778506
# Unit test for function decode
def test_decode():
    out, len_bytes_used = decode('\\xe3\\x80\\x80')
    assert out == '\u3000'
    assert len_bytes_used == 5
    assert decode('\\xe3\\x80\\x80', 'strict') == (out, len_bytes_used)
    assert decode('\\xe3\\x80\\x80', 'ignore') == ('', len_bytes_used)
    assert decode('\\xe3\\x80\\x80', 'replace') == ('?', len_bytes_used)



# Generated at 2022-06-23 17:59:00.519786
# Unit test for function register
def test_register():
    """Test that if the eutf8h codec has been registered."""
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise codecs.LookupError(  # type: ignore
            f'{NAME} codec not registered'
        )



# Generated at 2022-06-23 17:59:11.615085
# Unit test for function encode
def test_encode():
    tests_passed = 0
    tests_failed = 0

    assert encode('') == (b'', 0)
    tests_passed += 1
    assert encode('a') == (b'a', 1)
    tests_passed += 1
    assert encode('abc') == (b'abc', 3)
    tests_passed += 1
    assert encode('\n') == (b'\\a', 1)
    tests_passed += 1
    assert encode('\r') == (b'\\d', 1)
    tests_passed += 1
    assert encode('\a') == (b'\\x07', 1)
    tests_passed += 1
    assert encode('''\\\a''') == (b'\\\\\\x07', 4)
    tests_passed += 1

# Generated at 2022-06-23 17:59:15.063409
# Unit test for function register
def test_register():
    register()
    test_str = 'Hi I Am Yoda'
    test_bytes = test_str.encode(NAME)
    test_bytes_utf8 = test_bytes.decode(NAME)
    assert test_bytes_utf8 == test_str

# Generated at 2022-06-23 17:59:16.282763
# Unit test for function register
def test_register():
    register()


if __name__ == "__main__":
    register()

# Generated at 2022-06-23 17:59:20.095239
# Unit test for function register
def test_register():
    '''Test function register'''
    import sys
    before = sys.modules.copy()
    register()
    after = sys.modules.copy()
    # Check that the module was registered
    assert set(after.keys()) - set(before.keys()) == {NAME}

# Unit tests for function encode

# Generated at 2022-06-23 17:59:22.492796
# Unit test for function register
def test_register():
    from unittest import TestCase
    class test_register(TestCase):
        def test_register(self):
            register()

    test_register().test_register()

# Generated at 2022-06-23 17:59:25.820367
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False



# Generated at 2022-06-23 17:59:37.007854
# Unit test for function register
def test_register():
    from contextlib import redirect_stdout
    from io import StringIO
    from importlib import reload
    import sys

    import eutf8h

    fout = StringIO()
    with redirect_stdout(fout):
        reload(eutf8h)

        _ = codecs.decode('\\x41\\x00', NAME)
        assert(_ == 'A\x00')

        _ = codecs.decode('\\x41\\x00\\x42', NAME)
        assert(_ == 'A\x00B')

        _ = codecs.decode('\\x41\\x00\\x42\\x42', NAME)
        assert (_ == 'A\x00BB')

    # fout.getvalue() == ''

    fout = StringIO()

# Generated at 2022-06-23 17:59:46.009188
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise RuntimeError('The codec eutf8h was not registered.')


if __name__ == '__main__':
    import sys
    text = sys.argv[1]
    errors = sys.argv[2]
    encoded, consumed = encode(text, errors)
    print('Encoded:', encoded)
    print('consumed', consumed)
    decoded, consumed = decode(encoded, errors)
    print('Decoded:', decoded)
    print('consumed', consumed)

# Generated at 2022-06-23 17:59:55.394889
# Unit test for function encode
def test_encode():
    assert encode('abc') == (b'abc', 3)
    assert encode('ÀÁÂÃÄÅ') == (b'\\xc3\\x80\\xc3\\x81\\xc3\\x82\\xc3\\x83\\xc3\\x84\\xc3\\x85', 6)
    assert encode(r'\x41\x42\x43') == (b'ABC', 3)
    assert encode(r'\xc3\x80') == (b'\\xc3\\x80', 2)
    # Invalid utf8
    try:
        encode(r'\xff')
    except UnicodeEncodeError:
        pass
    else:
        assert False, "Did not raise error"


# Generated at 2022-06-23 18:00:04.010922
# Unit test for function register
def test_register():
    register()
    ok = False
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        ok = False
    else:
        ok = True
    assert ok


#
# Copyright © 2020 by David Alberts (https://codepen.io/alberts/pen/YzYOvXp)

#
# Copyright © 2020 by David Alberts (https://codepen.io/alberts/pen/YzYOvXp)

# Generated at 2022-06-23 18:00:09.439141
# Unit test for function decode
def test_decode():
    s = b"\\x61\\x62\\x63\\x64\\x65"
    expected = b"abcde"
    assert decode(s)[0] == expected.decode("utf-8")


if __name__ == '__main__':
    register()
    test_decode()

# Generated at 2022-06-23 18:00:10.953519
# Unit test for function register
def test_register():
    register()
    codecs.lookup_error("test")

# Generated at 2022-06-23 18:00:19.818953
# Unit test for function register
def test_register():
    # Remove if already registered.
    try:
        codecs.lookup(NAME)
    except LookupError:
        pass

    # Verify that it was removed.
    with pytest.raises(LookupError):
        codecs.lookup(NAME)

    # Register it.
    register()

    # Verify that it was registered.
    try:
        codecs.lookup(NAME)
    except LookupError:
        pytest.fail('Failed to register "%s" codec' % NAME)



# Generated at 2022-06-23 18:00:25.612180
# Unit test for function register

# Generated at 2022-06-23 18:00:28.775378
# Unit test for function encode
def test_encode():
    assert encode("\u00B0") == b'\\xc2\\xb0'
    assert encode("\u00B0", "replace") == b'?'
    assert encode("\u00B0", "ignore") == b''


# Generated at 2022-06-23 18:00:32.848507
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        raise AssertionError('Failed to detect, that codec is not registered')

# Generated at 2022-06-23 18:00:34.931972
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-23 18:00:38.289730
# Unit test for function register
def test_register():
    # The 'eutf8h' codec should not be registered.
    with pytest.raises(LookupError):
        codecs.getdecoder('eutf8h')

    # Register the 'eutf8h' codec.
    register()

    # Now the codec should be registered successfully.
    codecs.getdecoder('eutf8h')



# Generated at 2022-06-23 18:00:48.337529
# Unit test for function encode
def test_encode():
    tests = [
        ('foo', b'foo'),
        ('fo\\x66o', b'foo'),
        ('\\x66oo', b'foo'),
        ('f\\x6fo', b'foo'),
        ('fo\\x6f', b'foo'),
        ('fo\\x6f', b'foo'),
        ('\\x66\\x6f\\x6f', b'foo'),
        ('\\x66\\x6f\\x6f', b'foo'),
    ]
    for text_in, bytes_out in tests:
        bytes_out_actual, consumed = encode(text_in)
        assert bytes_out_actual == bytes_out
        assert consumed == len(text_in)



# Generated at 2022-06-23 18:00:55.112771
# Unit test for function register
def test_register():
    register()

    # Retrieve the codec using the module's name
    codec = codecs.getdecoder(NAME)   # type: ignore
    assert codec.decode.__code__ == decode.__code__   # type: ignore

    # Test the codec with a printable string
    out, length = codec('test')   # type: ignore
    assert out == 'test'
    assert length == 4

    #
    # Test the codec with an unprintable string
    #

    # Create a string with an unprintable character
    test = 'test\u03A9'

    # Decode the string
    out, length = codec(test)   # type: ignore

    # Check if the string was decoded correctly
    assert out == test

    # Test the codec with an escaped utf8 hex

# Generated at 2022-06-23 18:01:03.030557
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""

    plain_str = '\x01\x02\x03\x04'
    escaped_str = '\\x01\\x02\\x03\\x04'

    assert encode(plain_str)[0] == escaped_str.encode('utf-8')

    plain_str = '\u0000\u000a\u000d\u0020\u0080\u00a0\u0100\u0800\u1000'
    escaped_str = '\\x00\\n\\r \\x80\\xa0\\x80\\x80\\x80\\u0800\\u1000'

    assert encode(plain_str)[0] == escaped_str.encode('utf-8')

    plain_str = '\u2001\u2002\u2003\u2004'
    escaped_str

# Generated at 2022-06-23 18:01:13.653857
# Unit test for function encode
def test_encode():
    from e8 import codecs_autoregister
    codecs_autoregister.register()

    print('Testing function encode')
    print('Testing function encode: \ẃei\xdf\xf6\xfc')

    utf8_bytes, length = encode('\ẃei\xdf\xf6\xfc')
    # print(utf8_bytes)
    # print(length)

    latin_1_string = str(utf8_bytes, encoding='latin-1')
    print(latin_1_string)

    utf8_bytes_from_latin = latin_1_string.encode('latin-1')
    print(utf8_bytes_from_latin)
    print(type(utf8_bytes_from_latin))


# Generated at 2022-06-23 18:01:23.375632
# Unit test for function encode
def test_encode():
    assert encode('hello') == (b'hello', 5)
    assert encode('\\x61') == (b'a', 1)
    assert encode('\\x61\\x62') == (b'ab', 2)
    assert encode('\\x61\\x62\\x63') == (b'abc', 3)
    assert encode('\\x61\\x62\\x63\\x64') == (b'abcd', 4)
    assert encode('\\x61\\x62\\x63\\x64\\x65') == (b'abcde', 5)
    assert encode('\\x61\\x62\\x63\\x64\\x65\\x66') == (b'abcdef', 6)

# Generated at 2022-06-23 18:01:28.032464
# Unit test for function register
def test_register():
    errors = []

    # Register the codec.
    try:
        register()
    except Exception as e:
        errors.append(e)
    else:
        pass

    # If the tests fail, then register the codec again.
    if errors:
        register()
        return errors



# Generated at 2022-06-23 18:01:35.801998
# Unit test for function decode
def test_decode():
    """
    Unit test for function decode

    Returns:
        None
    """
    input_data = '\uffff\u20ac'
    input_errors = 'strict'
    output = decode(input_data, input_errors)
    print(output)
    assert output == ('\uffff\u20ac', 9)

    input_data = '\u20ac'
    input_errors = 'ignore'
    output = decode(input_data, input_errors)
    print(output)
    assert output == ('\u20ac', 9)

    input_data = '\\x4a'
    input_errors = 'strict'
    output = decode(input_data, input_errors)
    print(output)
    assert output == ('\x4a', 3)


# Generated at 2022-06-23 18:01:38.428595
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getencodings()
    assert NAME in codecs.getdecodings()  # type: ignore



# Generated at 2022-06-23 18:01:41.643974
# Unit test for function decode
def test_decode():
    test_input_str = 'Test\\x2C\\xf0\\x9f\\x98\\x83'
    test_input_bytes = test_input_str.encode('utf-8')
    expected_output_str = 'Test,\U0001F603'
    test_output_str, consumed = decode(test_input_bytes)
    assert test_output_str == expected_output_str
    assert consumed == len(test_input_bytes)


# Generated at 2022-06-23 18:01:53.000466
# Unit test for function decode
def test_decode():
    # translate escaped utf8 to utf8 bytes
    assert decode(b'\\xE6\\xBF\\xBE\\xE5\\x8E\\xBB')[0] == '\u6ffecy\xbb'
    # translate escaped utf8 to utf8 bytes with error
    assert decode(b'\\xE6\\xBF\\xBE\\xE5\\x8E\\xBB')[1] == 8
    # translate escaped utf8 to utf8 bytes with error

# Generated at 2022-06-23 18:01:54.870019
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getdecoder(NAME)._name


# noinspection DuplicatedCode

# Generated at 2022-06-23 18:01:58.604371
# Unit test for function decode
def test_decode():
    str2 = "\\x5B\\x5D\\x5C\\x5C\\x5C\\x78\\x30\\x35\\x39"
    str = "[]\\\\\\x059"
    assert (decode(str2)[0] == str)


# Generated at 2022-06-23 18:02:01.667080
# Unit test for function decode
def test_decode():
    assert(decode(b'\\x41') == ('A', 3))
    assert(decode(b'\\x30\\x31') == ('01', 6))
    assert(decode(b'\\x81\\x84') == ('\u4E16', 6))


# Generated at 2022-06-23 18:02:14.077914
# Unit test for function encode
def test_encode():
    # Test for each possible unicode character
    for c in range(0, 256):
        i = chr(c)
        r = encode(i)
        assert r[1] == 1

    assert encode(u'\x01\x02\x05') == (b'\\x01\\x02\\x05', 3)

    assert encode(u'\x00') == (b'\\x00', 1)
    assert encode(u'\x01') == (b'\\x01', 1)
    assert encode(u'\x02') == (b'\\x02', 1)
    assert encode(u'\x05') == (b'\\x05', 1)

    assert encode(u'\u20ac') == (b'\\xe2\\x82\\xac', 1)

# Generated at 2022-06-23 18:02:22.271443
# Unit test for function encode
def test_encode():
    input_list = [
        ('The quick brown fox jumps over the lazy dog.', False),
        ('The quick brown \\x80 fox jumps over the lazy dog.', False),
        ('The quick brown \\\\x80 fox jumps over the lazy dog.', True),
        ('The quick brown \\\\x80 fox jumps over the lazy \\xF0\\x9F\\x98\\xB0.', True),
    ]

    for input_, expect_ in input_list:
        try:
            output = encode(input_, errors='strict')
            assert expect_
        except UnicodeEncodeError:
            assert not expect_



# Generated at 2022-06-23 18:02:28.272387
# Unit test for function decode
def test_decode():
    data = b'\\x41\\x42\\x43\\x44'
    out = decode(data)
    assert out == ('ABCD', 4)
    data = b'\\x22\\x27\\x5c\\x22\\x27\\x5c\\x5c\\x5c\\x5c'
    out = decode(data)
    assert out == ('"\'\\"\'\\\\\\\\', 9)



# Generated at 2022-06-23 18:02:39.554092
# Unit test for function decode
def test_decode():
    hex_b = b'\\x61\\x62\\x63\\u2217\\u2217'  # b'\\x61\\x62\\x63\\xE2\\x88\\x95\\xE2\\x88\\x95'
    utf8_b = codecs.decode(hex_b, 'eutf8h')
    utf8_s = utf8_b.decode('utf-8')
    assert utf8_b == b'abc\xe2\x88\x95\xe2\x88\x95'
    assert utf8_s == 'abc\N{MULTIPLICATION SIGN}\N{MULTIPLICATION SIGN}'

    hex_b = b'\\x61\\x62\\x63\\u2217\\u2217'  # b'\\

# Generated at 2022-06-23 18:02:46.948282
# Unit test for function decode
def test_decode():
    assert decode(b'\\x65\\x66\\x67') == ('efg', 9)
    assert decode(b'\\x65\\xF0\\x90\\x80\\x80') == ('e\U00010000', 13)
    assert decode(b'\\x65\\x66\\x67', 'ignore') == ('efg', 9)

    try:
        decode(b'\\x66\\xF0\\x90\\x80\\x80')
    except UnicodeDecodeError:
        pass



# Generated at 2022-06-23 18:02:57.256730
# Unit test for function decode
def test_decode():
    assert decode(b'') == ('', 0)
    assert decode(b'\\xa') == ('\n', 3)
    assert decode(b'\\xa\\xd') == ('\r', 3)
    assert decode(b'\\xA\\xD') == ('\r', 3)
    assert decode(b'\\n') == ('\\', 1)
    assert decode(b'\\r\\n ') == ('\r ', 3)
    assert decode(b'\\r\\n a') == ('\r a', 4)
    assert decode(b'\\r\\n a\\r\\n ') == ('\r a\r ', 7)
    assert decode(b'\\r\\na') == ('\r\na', 3)

# Generated at 2022-06-23 18:03:00.591727
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)   # type: ignore
    codecs.getdecoder(NAME)   # type: ignore



# Generated at 2022-06-23 18:03:02.854019
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None


# Generated at 2022-06-23 18:03:11.767586
# Unit test for function encode

# Generated at 2022-06-23 18:03:23.593111
# Unit test for function decode

# Generated at 2022-06-23 18:03:31.483588
# Unit test for function encode
def test_encode():
    """Unit test for function encode"""
    import unittest
    import io

    # This class derives from the class defined in
    # the module 'io' or 'io.TextIOBase'.
    class _MyStr(io.TextIOBase):

        def __init__(self, data):
            self._data = data
            self._index = 0

        def write(self, data):
            pass

        def read(self, size):
            if self._index < len(self._data):
                out = self._data[self._index: self._index + size]
                self._index += size
                return out
            else:
                return ''

        def readline(self):
            pass

        @property
        def encoding(self):
            return 'eutf8h'


# Generated at 2022-06-23 18:03:32.853848
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 18:03:38.649696
# Unit test for function encode
def test_encode():
    data = '\\xC3\\xA9p\\xC3\\xA9e\\n\\xC3\\xA9p\\xC3\\xA9e'
    out, n = encode(data)
    assert isinstance(out, bytes)
    assert len(data) == n
    in_data = out.decode('utf8')
    assert in_data == data

if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-23 18:03:46.047591
# Unit test for function decode
def test_decode():
    # This is a silly test because the input string does not contain any
    # escaped utf8 hexadecimal.
    str_in = 'This is a silly test because the input string does not contain any escaped utf8 hexadecimal.'
    out = bytes(str_in, encoding='eutf8h')
    str_out = out.decode(encoding='eutf8h')
    assert str_out == str_in


register()

# Unit tests for function decode

# Generated at 2022-06-23 18:03:59.088549
# Unit test for function register
def test_register():
    import glob
    import os
    import shutil
    import sys

    dir_pre_register = glob.glob('*')
    dir_pre_register.remove('test_register.py')
    dir_pre_register.remove('test_eutf8h_codec.py')

    register()

    dir_post_register = glob.glob('*')
    dir_post_register.remove('test_register.py')
    dir_post_register.remove('test_eutf8h_codec.py')

    assert dir_pre_register == dir_post_register
    assert 'eutf8h.cpython-37.pyc' in glob.glob('*.pyc')

    # Unit test for function encode
    text = '\U0001F600'
    b, _ = encode(text)

# Generated at 2022-06-23 18:04:11.534982
# Unit test for function decode

# Generated at 2022-06-23 18:04:17.558245
# Unit test for function decode
def test_decode():
    assert decode(b'\\xe2\\x80\\x99') == ("'", 15)
    assert decode(b'\\xe2\\x80\\x99') == ("'", 15)
    assert decode(b'\\xc3\\xb1') == ('ñ', 9)
    assert decode(b'\\xc3\\xb1') == ('ñ', 9)

# Generated at 2022-06-23 18:04:27.222172
# Unit test for function encode
def test_encode():
    # type: () -> None
    """This function is not intended to be used outside of unit testing.

    """
    assert encode('编码') == (b'\\xe7\\xbc\\x96\\xe7\\xa0\\x81', 2)
    assert encode('\\xE7\\xBC\\x96\\xE7\\xA0\\x81') == \
           (b'\\xe7\\xbc\\x96\\xe7\\xa0\\x81', 14)
    assert encode('\\xE7\\xBC\\x96\\xE7\\xA0\\x81') == \
        (b'\\xe7\\xbc\\x96\\xe7\\xa0\\x81', 14)

# Generated at 2022-06-23 18:04:38.149490
# Unit test for function register
def test_register():
    register()
    list(codecs.getdecoder('eutf8h'))
    list(codecs.getencoder('eutf8h'))


if __name__ == '__main__':
    register()
    in_text = '\\xE2\\x80\\x8D\\xE2\\x80\\x8B\\xE2\\x99\\xA5'
    out_text = in_text.encode('eutf8h')
    assert out_text == b'\\xe2\\x80\\x8d\\xe2\\x80\\x8b\\xe2\\x99\\xa5'
    assert in_text.encode('latin1') == out_text.decode('eutf8h').encode('latin1')

# Generated at 2022-06-23 18:04:41.679410
# Unit test for function encode
def test_encode():
    """
    >>> test_encode()
    True
    """
    expected = b'Hello \\xE2\\x80\\x99 world'
    actual, _ = encode('Hello \u2019 world')
    return expected == actual

# Generated at 2022-06-23 18:04:42.563269
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getencodings()



# Generated at 2022-06-23 18:04:53.348089
# Unit test for function encode
def test_encode():
    """Unit test for function encode

    """
    # Arrange
    from functools import reduce
    from collections import UserString

    def each_utf8_hex(text: str) -> Generator[str, None, None]:
        for char in text:
            if ord(char) < 128 and char.isprintable():
                yield char
                continue
            utf8_bytes = char.encode('utf8')
            for utf8_byte in utf8_bytes:
                str_hex = '\\%s' % hex(utf8_byte)[1:]
                yield str_hex

    test = reduce(lambda a, b: f'{a}{b}', each_utf8_hex('\\xFF'))
    test_bytes = test.encode('utf-8')

    # Act

# Generated at 2022-06-23 18:04:57.948973
# Unit test for function decode
def test_decode():
    assert isinstance(decode(b'\\xE5\\x80\\x9F\\xE5\\xA7\\x8B\\xE7\\x9A\\x84'), str)


# Generated at 2022-06-23 18:05:03.640159
# Unit test for function decode
def test_decode():
    print(repr(decode(b'\\x61\\x62\\x63')))
    print(repr(decode(b'\\x30\\x31\\x32\\x33')))
    print(repr(decode(b'\\xC3\\x84\\xC3\\x85')))
    print(repr(decode(b'\\xE2\\x80\\xA8')))


# Generated at 2022-06-23 18:05:10.615197
# Unit test for function decode

# Generated at 2022-06-23 18:05:19.182265
# Unit test for function encode
def test_encode():
    assert encode('\x00\x01', errors='ignore') == (b'\\x00\\x01', 2)
    assert encode('\x00\x01', errors='replace') == (b'\\x00\\x01', 2)
    assert encode('\x00\x01', errors='strict') == (b'\\x00\\x01', 2)
    assert encode('\x00\x01', errors='surrogatepass') == (b'\\x00\\x01', 2)
    assert encode('\x00\x01', errors='surrogateescape') == (b'\\x00\\x01', 2)
    assert encode('A', errors='') == (b'A', 1)
    assert encode('\u0080', errors='') == (b'\\x80', 2)

# Generated at 2022-06-23 18:05:28.527780
# Unit test for function encode
def test_encode():
    """Test the encode function of the eutf8h codec."""

    # Test that each character that is not an ASCII character and
    # is not printable, is encoded as the hexadecimal value
    # prefixed with the backslash character (\\).
    # This includes the ASCII control characters.
    for i in range(128, 256):
        char = chr(i)
        if char.isprintable():
            continue
        assert encode(char)[0].decode('utf8') == '\\%s' % hex(i)[1:]

    # Test that valid ASCII characters (and some not-ASCII characters) are
    # the same character after being encoded and decoded.
    test_str = 'this_is_a valid_test_string'
    encoded = encode(test_str)[0].decode('utf8')
   

# Generated at 2022-06-23 18:05:37.226329
# Unit test for function decode
def test_decode():
    # Get the input data
    with open('test_input.tst', 'rb') as f:
        data_input = f.read()

    # Get the expected output data
    with open('test_output.tst', 'rb') as f:
        data_expected = f.read()

    # Decode the input data to a string.
    str_out, _ = decode(data_input)

    # Convert the output string back into bytes
    data_out = str_out.encode(NAME)

    # Verify that the bytes that resulted from encoding the output
    # string is the same as the bytes that we expected.
    assert data_expected == data_out



# Generated at 2022-06-23 18:05:46.137355
# Unit test for function encode
def test_encode():
    in_str1 = 'abc'
    out_bytes1, out_len1 = encode(in_str1)
    assert out_bytes1 == b'abc'
    assert out_len1 == 3
    in_str2 = 'a\xC3\x8D'
    out_bytes2, out_len2 = encode(in_str2)
    assert out_bytes2 == b'a\\xc3\\x8d'
    assert out_len2 == 3
    in_str3 = 'a\\xc3\\x8D'
    out_bytes3, out_len3 = encode(in_str3)
    assert out_bytes3 == b'a\\xc3\\x8d'
    assert out_len3 == 5
    in_str4 = 'a\\xc3b'
    out_bytes4,

# Generated at 2022-06-23 18:05:47.694309
# Unit test for function register
def test_register():
    register()
    codecs.lookup_error('eutf8h')

