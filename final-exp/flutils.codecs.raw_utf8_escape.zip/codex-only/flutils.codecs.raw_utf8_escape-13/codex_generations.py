

# Generated at 2022-06-23 17:55:57.563599
# Unit test for function decode

# Generated at 2022-06-23 17:56:09.208010
# Unit test for function decode
def test_decode():
    assert decode(b'\\x7f\\x0a\\x0d') == ('\u007f\n\r', 9)
    assert decode(b'\\x7f\\x0a\\x0d', 'ignore') == ('\u007f\u000a\u000d', 9)
    assert decode(b'\\x7f\\x0a\\x0d', 'replace') == (
        '\u007f\uFFFD\uFFFD',
        9
    )

    try:
        decode(b'\\x7f\\x0a\\x0d', 'strict')
    except UnicodeDecodeError as e:
        assert e.encoding == 'eutf8h'
        assert e.object == b'\\x7f\\x0a\\x0d'

# Generated at 2022-06-23 17:56:15.049094
# Unit test for function encode
def test_encode():
    # Good test
    r = encode('\u05e9')
    assert r[0] == b'\\05e9'
    assert r[1] == 1
    assert r[0].decode('utf-8') == r[0].decode('eutf8h')
    # Test exclamation mark
    r = encode('\u0021')
    assert r[0] == '!'.encode('utf-8')
    assert r[1] == 1
    assert r[0].decode('utf-8') == r[0].decode('eutf8h')



# Generated at 2022-06-23 17:56:21.555563
# Unit test for function decode
def test_decode():
    assert decode(b'abcdef') == ('abcdef', 6)
    assert decode(b'\\x48\\x65\\x6C\\x6C\\x6F') == ('Hello', 10)
    assert decode(b'\\xF0\\x9F\\x98\\x80') == ('\U0001f600', 8)
    assert decode(b'\\xF0\\x9F\\x98\\x81') == ('\U0001f601', 8)
    assert decode(b'\\xF0\\x9F\\x98\\x92') == ('\U0001f612', 8)


# Generated at 2022-06-23 17:56:33.541491
# Unit test for function encode
def test_encode():
    print("test_encode")
    text_in_1 = "hello 世界"
    text_in_2 = r"hello \u4e16\\x20\u754c"
    text_in_3 = r"hello \\u4e16\\\\x20\\u754c"
    text_in_4 = r"hello \u4e16\\x20\u754c"
    text_in_5 = r"hello \\u4e16\\\\x20\\u754c"
    result1, len1 = encode(text_in_1)
    print(result1)
    assert result1 == b'hello \\xe4\\xb8\\x96\\xe7\\x95\\x8c'
    assert len1 == 9
    result2, len2 = encode(text_in_2)

# Generated at 2022-06-23 17:56:43.534820
# Unit test for function encode

# Generated at 2022-06-23 17:56:46.147307
# Unit test for function decode
def test_decode():
    data = b"\\x61\\x62\\x63\\x64\\x65"
    text, count = decode(data)
    assert text == 'abcde'
    assert count == len(data)


# Generated at 2022-06-23 17:56:48.020730
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.getencodings()
    register()


# Generated at 2022-06-23 17:56:58.296568
# Unit test for function decode
def test_decode():
    assert decode(R'''\n\r\t\v\v\f\a\b\\\x22\x27\x5c\x7f''', 'strict') == (
        R'''
\r\t\v\v\f\a\b\\"\'\x7f''',
        25,
    )
    assert decode(b'\\xFF', 'strict') == ('\xFF', 5)
    assert decode(b'\\xFF', 'ignore') == ('', 5)
    assert decode(b'\\xFF', 'replace') == ('\ufffd', 5)
    try:
        decode(b'\\xFF', 'namereplace')
    except UnicodeDecodeError:
        pass
    else:
        raise AssertionError('fail')

# Generated at 2022-06-23 17:57:01.163737
# Unit test for function register
def test_register():
    # noinspection PyUnresolvedReferences
    codecs.register(_get_codec_info)   # type: ignore


# Generated at 2022-06-23 17:57:02.613883
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)



# Generated at 2022-06-23 17:57:06.253967
# Unit test for function encode
def test_encode():
    assert encode('hello') == (b'hello', 5)
    assert encode('h\xe9llo') == (b'h\\xc3\\xa9llo', 5)


# Unit test function decode

# Generated at 2022-06-23 17:57:17.744269
# Unit test for function decode
def test_decode():
    # These are all valid examples
    assert decode(b"\\330\\237\\33\\n")[0] == "ㅃ"

# Generated at 2022-06-23 17:57:23.303254
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)
    data = '\u20ac'
    data_bytes = data.encode(NAME)
    data_bytes.decode(NAME)

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 17:57:33.225494
# Unit test for function decode
def test_decode():
    # Test the decoding of end coded bytes to utf-8
    word_list = []
    word_list.append(b'\\x41\\x42\\x43\\x44')
    word_list.append(b'\\x61\\x62\\x63\\x64')
    word_list.append(b'\\U0001D000')
    word_list.append(b'\\x41\\x62\\x43\\x64')
    word_list.append(b'\\x41\\x62\\x43\\x68')

    s = 'ABCD'
    for word in word_list:
        (decoded_word, _) = decode(word)
        assert decoded_word == s, \
            "Decoding failed for byte string:\n %s" % word

    # Test decoding of bytes with errors=st

# Generated at 2022-06-23 17:57:35.137223
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup_error('eutf8h') == codecs.lookup('eutf8h')


# Generated at 2022-06-23 17:57:42.123559
# Unit test for function encode

# Generated at 2022-06-23 17:57:47.904929
# Unit test for function decode
def test_decode():
    def assert_decode(
        data: _ByteString,
        errors: _Str = 'strict',
        result: bytes = b'\xe3\x81\x8a'
    ) -> None:
        out, length = decode(data, errors)
        assert result == data[:length]
        assert 'お' == out
        assert length == len(data)

    assert_decode(b'\\xe3\\x81\\x8a')
    assert_decode(b'\\xe3\\x81\\x8A')
    assert_decode(b'\\xE3\\x81\\x8a')
    assert_decode(b'\\xE3\\x81\\x8A')



# Generated at 2022-06-23 17:57:57.307495
# Unit test for function encode
def test_encode():
    assert encode(r'\x41') == (b'A', 1)
    assert encode(r'\x41\x42') == (b'AB', 2)
    assert encode(r'spam') == (b'spam', 4)
    assert encode(r'\xaa\u1234\U00010000') == \
        b'\xaa\xe1\x88\xb4\xf0\x90\x80\x80'

    try:
        encode(r'\xab\xcd')
        print('FAIL: Expected UnicodeEncodeError')
    except UnicodeEncodeError as e:
        assert e.encoding == 'eutf8h'
        assert e.object == r'\xab\xcd'
        assert e.start == e.end == 0



# Generated at 2022-06-23 17:58:08.786863
# Unit test for function encode
def test_encode():
    # Test a string that is all printable ASCII characters.
    text_input = 'abc ABC 123 !@# $%^ &*()'
    out = encode(text_input)
    assert out == (b'abc ABC 123 !@# $%^ &*()', 24)

    # Test a string that is all printable ASCII characters and escaped
    # hexadecimal characters.
    text_input = '\\x61\\x62\\x63\\x20ABC\\x20\\x31\\x32\\x33 ' \
                 '!@#\\x20$%\\x5e\\x20\\x26\\x2a\\x28\\x29'
    out = encode(text_input)

# Generated at 2022-06-23 17:58:11.049303
# Unit test for function decode
def test_decode():
    c_str = codecs.decode('\\xC3\\xA1', 'eutf8h')
    expected = 'á'
    assert expected == c_str



# Generated at 2022-06-23 17:58:21.180764
# Unit test for function encode
def test_encode():
    if __name__ == "__main__":
        test_str = "你好世界"
        codecs.register(_get_codec_info)
        encoded_bytestr = codecs.encode(test_str, 'eutf8h')
        print(encoded_bytestr)
        print(type(encoded_bytestr))
        # decode_bytestr = codecs.decode(encoded_bytestr, 'eutf8h')
        # print(decode_bytestr)
        # print(type(decode_bytestr))

        pass


# Generated at 2022-06-23 17:58:25.711231
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
        assert codecs.getdecoder(NAME) is not None

# Test for encode

# Generated at 2022-06-23 17:58:28.864342
# Unit test for function register
def test_register():
    register()
    is_registered = True
    try:
        codecs.lookup(NAME)
    except LookupError:
        is_registered = False
    assert is_registered



# Generated at 2022-06-23 17:58:31.605105
# Unit test for function decode
def test_decode():
    assert decode(
        b'\\x74\\x65\\x73\\x74\\x20\\x42',
    ) == ('test B', 8)


test_decode()


# Generated at 2022-06-23 17:58:32.978898
# Unit test for function register
def test_register():
    # Register the codec if it isn't registered.
    # This ensures that this is the codec that is used in this module.
    register()

# Generated at 2022-06-23 17:58:43.648002
# Unit test for function encode
def test_encode():
    assert encode('a') == (b'a', 1)
    assert encode('1') == (b'1', 1)
    assert encode('A') == (b'A', 1)
    assert encode('Z') == (b'Z', 1)
    assert encode(' ') == (b' ', 1)
    assert encode('\t') == (b'\t', 1)
    assert encode('\r') == (b'\r', 1)
    assert encode('\n') == (b'\n', 1)
    assert encode('\f') == (b'\f', 1)
    assert encode('\b') == (b'\b', 1)
    assert encode('\\') == (b'\\', 1)
    assert encode(':') == (b':', 1)

# Generated at 2022-06-23 17:58:44.234961
# Unit test for function decode
def test_decode():
    pass

# Generated at 2022-06-23 17:58:51.710511
# Unit test for function encode
def test_encode():
    assert encode('x') == (b'x', 1)
    assert encode('\\') == (b'\\\\', 1)
    assert encode('\\x') == (b'\\\\x', 2)
    assert encode(r'\\x') == (b'\\\\\\x', 3)
    assert encode('\\\\x') == (b'\\\\\\\\x', 4)

# Generated at 2022-06-23 17:59:02.590549
# Unit test for function decode
def test_decode():
    # Simple tests
    assert decode('\u00e2\u0082\u00ac') == ('\u00ac', 9)
    assert decode('\u00ac') == ('\u00ac', 3)
    assert decode('\xc3\xa9') == ('\u00e9', 6)
    # Hex tests
    assert decode('\\xc3\\xa9') == ('\u00e9', 6)
    assert decode('\\u00e9') == ('\u00e9', 6)
    assert decode('\\U000000e9') == ('\u00e9', 12)
    # Tests for ASCII input
    assert decode('\\x48\\x65\\x79') == ('Hey', 18)
    assert decode('H\\x65y') == ('Hey', 9)

# Generated at 2022-06-23 17:59:12.668844
# Unit test for function decode
def test_decode():
    # Test basic functionality
    test_input = r'\xC3\xA4\xC3\xB6\xC3\xBC\xC3\x9F'
    test_output = 'äöüß'
    assert decode(test_input) == (test_output, len(test_input))
    # Test 'strict' error mode
    test_input = r'\xC3\xA5\xC3\xB6\xC3\xBC\xC3\x9F'
    assert decode(test_input, 'strict') == (test_output, len(test_input))
    # Test 'ignore' error mode

# Generated at 2022-06-23 17:59:15.191376
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError(
            f'Expected {NAME} to be registered'
        )

# Generated at 2022-06-23 17:59:25.764954
# Unit test for function encode
def test_encode():
    text = '\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f'
    text += '\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f'
    text += ' !"#$%&\'()'
    text += '*+,-./0123456789:;<=>?'
    text += '@ABCDEFGHIJKLMNOPQRSTUVWXYZ['
    text += '\\]^_`abcdefghijklmnopqrstuvwxyz{|}~'
   

# Generated at 2022-06-23 17:59:31.259963
# Unit test for function register
def test_register():
    register()
    codecs.decode('\\x41', NAME)  # type: ignore
    codecs.decode('\\x41', NAME)  # type: ignore
    codecs.decode('\\x61', NAME)  # type: ignore
    codecs.decode('\\x41', NAME)  # type: ignore
    codecs.decode('\\x41', NAME)  # type: ignore


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 17:59:39.831905
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    data = codecs.decode('\\xC3\\xA9', 'eutf8h')
    assert data == 'é'
    assert codecs.decode('\\xC3\\xA9', 'eutf8h') == 'é'
    assert codecs.decode('\\xe9', 'eutf8h') == 'é'
    assert codecs.decode(bytes.fromhex('c3'), 'eutf8h') == 'Ã'
    assert codecs.decode(bytes.fromhex('c39e'), 'eutf8h') == 'é'

# Generated at 2022-06-23 17:59:51.486654
# Unit test for function encode
def test_encode():
    """Unit test for function ``encode``"""

    # error checking test
    try:
        encode('\\xff')
    except UnicodeEncodeError:
        pass

    # no error checking test
    encode('\\xff', 'ignore')   # type: ignore[arg-type]
    encode('\\xff', 'replace')   # type: ignore[arg-type]

    # regular test
    assert encode('abc') == (b'abc', 3)
    assert encode('abc\\xFF') == (b'abc\\xFF', 7)
    assert encode('\\xFF\\x00') == (b'\\xFF\\x00', 7)
    assert encode('\\x00\\xFF') == (b'\\x00\\xFF', 7)

# Generated at 2022-06-23 17:59:56.255880
# Unit test for function decode
def test_decode():
    encoding = 'eutf8h'

    data = b"\\xc3\\xa1\\xc2\\xad\\xc3\\xaa\\xe2\\x80\\x98\\xc2\\x91"
    errors = 'strict'
    expected = 'áíê‘′'

    actual = codecs.decode(data, encoding, errors)
    assert actual == (expected, len(data))



# Generated at 2022-06-23 18:00:02.248147
# Unit test for function register
def test_register():
    #  'eutf8h' is already registered. Unregister.
    try:
        codecs.lookup_error('strict')
    except LookupError:
        pass
    else:
        codecs.register_error(NAME, codecs.lookup_error('strict'))
    register()

# Generated at 2022-06-23 18:00:13.226675
# Unit test for function encode
def test_encode():
    assert encode('abc') == (b'abc', 3)
    assert encode('abcde') == (b'abcde', 5)
    assert encode('🚀') == (b'\\xf0\\x9f\\x9a\\x80', 1)
    assert encode('🌟') == (b'\\xf0\\x9f\\x8c\\x9f', 1)
    assert encode('🌿') == (b'\\xf0\\x9f\\x8c\\xbf', 1)
    assert encode('🌲') == (b'\\xf0\\x9f\\x8c\\xb2', 1)
    assert encode('😁') == (b'\\xf0\\x9f\\x98\\x81', 1)

# Generated at 2022-06-23 18:00:15.344114
# Unit test for function register
def test_register():
    register()
    assert codecs.lookup(NAME) is not None


# Generated at 2022-06-23 18:00:24.891590
# Unit test for function decode
def test_decode():
    """
    This function checks for decoding all types of utf8 hexadecimal bytes,
    and with all types of error handling
    """

# Generated at 2022-06-23 18:00:35.635783
# Unit test for function encode
def test_encode():
    # type: () -> None
    """Test the :obj:`eutf8h.encode` function.

    """

    # First test the basic case, converting an ascii string with no
    # unicode characters.
    input_str = 'Hello, this is a ascii string.'
    expected_str = 'Hello, this is a ascii string.'
    expected_len = len(expected_str)
    actual_str, actual_len = encode(input_str)
    assert actual_str == expected_str
    assert actual_len == expected_len

    # Make a list of tuples.
    # The first element of the tuple is the input string.
    # The second element of the tuple is the expected output string.

# Generated at 2022-06-23 18:00:45.992507
# Unit test for function decode
def test_decode():
    # Create 'data' bytestring with one utf8 character
    data = '\\xC3\\xA9'.encode('utf-8')

    # Decode the bytestring into a string
    out = decode(data)

    # Make sure the decoded string is correct
    assert out == ('é', 2)

    # Create data bytestring with escaped hexadecimal that is invalid utf8
    data = '\\x80'.encode('utf-8')

    # Try decoding the bytestring and make sure it raises an exception
    try:
        decode(data)
    except UnicodeDecodeError:
        pass
    else:
        assert False



# Generated at 2022-06-23 18:00:48.034032
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    obj = codecs.getdecoder(NAME)
    assert obj is not None


# Generated at 2022-06-23 18:00:52.261473
# Unit test for function decode
def test_decode():
    assert(decode(b'\\xe2\\x99\\xa5') == ('♥', 10))
    assert(decode(b'\\xe2\\x99\\xa5\\xe2\\x99\\xa5', errors='ignore') == ('', 10))
    assert(decode(b'\\xe2\\x99\\a\\xe2\\x99\\a', errors='ignore') == ('', 10))



# Generated at 2022-06-23 18:00:55.686100
# Unit test for function register
def test_register():
    from eutf8h import register
    register()
    codecs.getdecoder(NAME)


if __name__ == '__main__':
    test_register()
    print('Done.')

# Generated at 2022-06-23 18:00:57.511069
# Unit test for function register
def test_register():
    actual = codecs.lookup(NAME)
    assert NAME == actual.name



# Generated at 2022-06-23 18:01:01.672944
# Unit test for function decode
def test_decode():
    assert decode(b'\\xC2\\xB2', 'strict') == ('²', 7)
    assert decode(b'\\xC2\\xB2', 'ignore') == ('', 7)
    assert decode(b'\\xC2\\xB2', 'replace') == ('�', 7)


# Generated at 2022-06-23 18:01:09.505119
# Unit test for function register
def test_register():
    # noinspection PyShadowingNames
    def getdecoder(encoding: str) -> _get_codec_info:
        codecs.getdecoder(encoding)
    # noinspection PyShadowingNames
    def register() -> None:
        _get_codec_info(NAME)
    try:
        getdecoder(NAME)
    except LookupError:
        register()
    try:
        getdecoder(NAME)
    except LookupError:
        assert False

# Generated at 2022-06-23 18:01:12.560828
# Unit test for function encode
def test_encode():
    str_input = '\u02C9c'
    tuple_out = ('\\xcc\\xa9c', 3)
    assert encode(str_input) == tuple_out



# Generated at 2022-06-23 18:01:20.565064
# Unit test for function encode
def test_encode():
    in_str = '\\u20ac'
    in_str_bytes = codecs.encode(in_str, 'unicode-escape')
    assert in_str_bytes == b'\\u20ac'
    assert type(in_str_bytes) is bytes

    out_bytes, _ = encode(in_str)
    assert out_bytes == b'\\xe2\\x82\\xac'
    assert type(out_bytes) is bytes



# Generated at 2022-06-23 18:01:21.607420
# Unit test for function register
def test_register():
    _get_codec_info(NAME)

# Generated at 2022-06-23 18:01:25.339672
# Unit test for function register
def test_register():
    register()
    obj = codecs.lookup(NAME)  # type: ignore
    assert obj.name == NAME
    assert obj.encode == encode
    assert obj.decode == decode

# Generated at 2022-06-23 18:01:29.202429
# Unit test for function register
def test_register():
    """
    Unit test for function 'register'.
    """
    register()
    assert codecs.getdecoder(NAME) is not None

if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 18:01:32.687596
# Unit test for function decode
def test_decode():
    assert decode(b'\\xe4\\xb8\\x80') == ('一', 10)
    assert decode(b'\\xe4\\xb8\\x80', 'replace') == ('���', 10)
    assert decode(b'\\xe4\\xb8\\x80', 'ignore') == ('', 10)


# Generated at 2022-06-23 18:01:42.964092
# Unit test for function register
def test_register():
    from os import remove
    import imp

    # Register the codec
    register()

    # Get the module info
    module = imp.find_module('testing_eutf8h')
    if module[0] is not None:
        module[0].close()
    module_info = imp.find_module('testing_eutf8h', module[1])

    # Open the temp module file
    module_file = module_info[0]
    module_file_path = module_file.name
    module_file.close()

    # Try the import.
    import testing_eutf8h  # noqa
    from testing_eutf8h import testing_eutf8h

    # Test the module
    testing_eutf8h()

    # Remove the temporary module
    remove(module_file_path)

    # Unregister

# Generated at 2022-06-23 18:01:45.356540
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)   # type: ignore

# Generated at 2022-06-23 18:01:54.605400
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    register()
    #noinspection SpellCheckingInspection
    data = b"\\x74\\x68\\x69\\x73\\x20\\x69\\x73\\x20\\x61\\x20\\x74\\x65\\x73\\x74"
    print(data)
    print(type(data))

    # noinspection SpellCheckingInspection
    data_decoded = codecs.decode(data, encoding='eutf8h')
    print(data_decoded)
    print(type(data_decoded))
    print()

    # noinspection SpellCheckingInspection
    data_encoded = codecs.encode(data_decoded, encoding='eutf8h')
    print(data_encoded)

# Generated at 2022-06-23 18:01:58.681152
# Unit test for function register
def test_register():
    register()
    decoder = codecs.getdecoder(NAME)  # type: ignore   # noqa
    encoder = codecs.getencoder(NAME)  # type: ignore   # noqa
    assert decoder is not None
    assert encoder is not None

# Generated at 2022-06-23 18:02:01.138969
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, "Could not register codec"
    else:
        assert True, "Codec successfully registered"

# Generated at 2022-06-23 18:02:13.596899
# Unit test for function decode
def test_decode():
    assert decode(b'a') == ('a', 1)
    assert decode(b'\\x65') == ('e', 4)
    assert decode(b'\\x6E') == ('n', 4)
    assert decode(b'\\x61\\x6E') == ('an', 4)
    assert decode(b'\\x61\\x6E\\x6E') == ('ann', 4)
    assert decode(b'\\x61\\x6E\\x6E\\x\n') == ('ann', 4)
    assert decode(b'\\x61\\x6E\\x6E\\x\t') == ('ann', 4)
    assert decode(b'\\x61\\x6E\\x6E\\x\r') == ('ann', 4)

# Generated at 2022-06-23 18:02:14.971350
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)      # type: ignore



# Generated at 2022-06-23 18:02:24.709896
# Unit test for function encode
def test_encode():
    import unittest

    class TestEncode(unittest.TestCase):
        def test_1(self) -> None:
            self.assertEqual(
                encode('hello'),
                (b'hello', 5),
            )

        def test_2(self) -> None:
            self.assertEqual(
                encode('hello\\x{2022}'),
                (b'hello\\xe2\\x80\\xa2', 12),
            )

        def test_3(self) -> None:
            self.assertEqual(
                encode('hello\\x{2022}\\x{2023}'),
                (b'hello\\xe2\\x80\\xa2\\xe2\\x80\\xa3', 20),
            )

    unittest.main()


# Generated at 2022-06-23 18:02:32.702273
# Unit test for function decode
def test_decode():
    pass


if __name__ == '__main__':
    register()
    encoding = "eutf8h"

    print(codecs.getdecoder(encoding))

    text = "Test"
    encoded_bytes = text.encode(encoding)
    print(encoded_bytes)

    decoded_text, length = codecs.getdecoder(encoding)(encoded_bytes)
    print(decoded_text)
    print(length)

    encoded_bytes = codecs.getencoder(encoding)(decoded_text)
    print(encoded_bytes)
    print(encoded_bytes[0].decode(encoding))

    print(encoded_bytes[0].decode(encoding))

    print(str(encoded_bytes[0].decode(encoding)))
    # encoding

# Generated at 2022-06-23 18:02:39.111889
# Unit test for function register
def test_register():
    # Assert that the codec is not registered
    try:
        codecs.getencoder(NAME)
        raise AssertionError(
            'Function "register" must not be callable more than '
            'once after reloading module "eutf8h"'
        )
    except LookupError:
        pass

    codecs.register(_get_codec_info)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 18:02:48.674437
# Unit test for function encode
def test_encode():
    """Test encoding escaped utf8 hexadecimal."""

    assert encode('') == (b'', 0)
    assert encode('A') == (b'A', 1)
    assert encode('\\x65') == (b'e', 6)
    assert encode('\\x65F') == (b'eF', 8)
    assert encode('\\x65Fg') == (b'eFg', 9)
    assert encode('\\x65FgH') == (b'eFgH', 10)
    assert encode('\\x65FgHi') == (b'eFgHi', 11)
    assert encode('\\x65FgHiJ') == (b'eFgHiJ', 12)
    assert encode('\\x65FgHiJK') == (b'eFgHiJK', 13)


# Generated at 2022-06-23 18:02:58.280512
# Unit test for function encode
def test_encode():
    # noinspection SpellCheckingInspection
    str_test = '\u2022 \u2022 \u2022'  # \xe2\x80\xa2 \xe2\x80\xa2 \xe2\x80\xa2
    str_test_escaped = '\\xe2\\x80\\xa2 \\xe2\\x80\\xa2 \\xe2\\x80\\xa2'
    str_test_escaped_bytes = b'\\xe2\\x80\\xa2 \\xe2\\x80\\xa2 \\xe2\x80\xA2'
    str_test_escaped_bytes_error = b'\\xe2\\x80\\xa2 \\xE2\\x80\\xa2 \\xe2\x80\xA2'


# Generated at 2022-06-23 18:03:07.278100
# Unit test for function decode

# Generated at 2022-06-23 18:03:15.467154
# Unit test for function encode
def test_encode():
    tests = [
        ['中文',                  b'\\xe4\\xb8\\xad\\xe6\\x96\\x87',              6],
        ['B\xe2\x80\x99ville',    b'B\\xc3\\xa2\\xe2\\x80\\x99ville',            11],
        ['测',                    b'\\xe6\\xb5\\x8b',                              3],
    ]
    for test in tests:
        assert encode(test[0]) == (test[1], test[2])

# Generated at 2022-06-23 18:03:24.836023
# Unit test for function encode
def test_encode():
    assert encode('hello world') == (b'hello world', 11)
    assert encode('xxx') == (b'xxx', 3)
    assert encode('\\x48\\x65\\x6c\\x6c\\x6f\\x20\\x57\\x6f\\x72\\x6c\\x64') == (
        b'hello world',
        22,
    )
    assert encode('\\u263a') == (b'\\xE2\\x98\\xBA', 9)
    assert encode('\\U0001f600') == (b'\\xF0\\x9F\\x98\\x80', 13)



# Generated at 2022-06-23 18:03:28.513773
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore

# Generated at 2022-06-23 18:03:38.262833
# Unit test for function decode
def test_decode():
    # noinspection PyUnresolvedReferences
    """
    >>> test_decode()
    """
    assert decode(b'\\x63') == ('c', 5)
    assert decode(b'\\xc2\\xa2') == ('¢', 7)
    assert decode(b'\\xe2\\x82\\xac') == ('€', 9)
    assert decode(b'\\xf0\\x90\\x8d\\x88') == ('𐍈', 13)
    assert decode(b'\\x63\\xc2\\xa2\\xe2\\x82\\xac\\xf0\\x90\\x8d\\x88') == \
        ('c¢€𐍈', 31)

# Generated at 2022-06-23 18:03:41.242322
# Unit test for function decode
def test_decode():
    import doctest
    doctest.testmod()


# Generated at 2022-06-23 18:03:50.120694
# Unit test for function decode
def test_decode():
    assert decode(b'hello') == ('hello', 5)
    assert decode(b'\\u2764') == ('❤', 6)
    assert decode(b'\\x20') == (' ', 4)
    assert decode(b'\\x8a') == ('\x8a', 4)
    a = b'\\u2764\\x20\\x8a'
    assert decode(a) == ('❤ \x8a', 11)
    with pytest.raises(UnicodeDecodeError):
        decode(b'\\j2764')

    # Testing with utf8 hexadecimal ascii string
    a = b'a' * 34 + b'\\x20' + b'b' * 9 + b'\\x20' + b'c' * 56 + b'\\x20'
    a += b

# Generated at 2022-06-23 18:04:01.467246
# Unit test for function encode

# Generated at 2022-06-23 18:04:04.897657
# Unit test for function register
def test_register():
    # save the state of the codecs.aliases dictionary
    codecs_aliases_saved = copy.deepcopy(codecs.aliases.aliases)

    # test the function
    try:
        register()
    finally:
        # restore the state of the codecs.aliases dictionary
        codecs.aliases.aliases = codecs_aliases_saved

# Generated at 2022-06-23 18:04:15.002698
# Unit test for function decode

# Generated at 2022-06-23 18:04:17.042600
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)       # type: ignore


# Generated at 2022-06-23 18:04:18.028517
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-23 18:04:27.938224
# Unit test for function decode
def test_decode():
    """
    Unit test function decode

    Returns:
        None

    """
    samples = [
        ('hello world', 'hello world'),
        ('こんにちは世界', 'こんにちは世界'),
        ('\\4f60\\597d\\4e16\\754c', '你好世界'),
        ('\\x7a\\x65\\x72\\x6f', 'zero'),
        ('\\u0038', '8'),
        ('\\U00003039', '09'),
    ]
    for sample in samples:
        encoded, consumed = decode(sample[0])
        decoded = encoded
        print(f'{sample[0]} decodes to {decoded}')
        assert decoded == sample[1]


# Generated at 2022-06-23 18:04:30.301692
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)   # type: ignore
    assert codecs.getencoder(NAME)   # type: ignore

# Generated at 2022-06-23 18:04:32.391104
# Unit test for function register
def test_register():
    # noinspection PyUnresolvedReferences
    from . import eutf8h
    eutf8h.register()

# Generated at 2022-06-23 18:04:36.105456
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)   # type: ignore
    else:
        assert False

# Generated at 2022-06-23 18:04:46.784579
# Unit test for function encode

# Generated at 2022-06-23 18:04:53.419455
# Unit test for function decode
def test_decode():
    from eutf8h import decode
    from codecs import decode as codec_decode
    from io import BytesIO
    test_string = '\\x74\\x65\\x73\\x74\\x20\\x73\\x74\\x72\\x69n\\x67\\x20'
    codec_decode(test_string, "eutf8h")
    codec_decode(test_string, "eutf8h", "strict")
    codec_decode(test_string, "eutf8h", "ignore")
    codec_decode(test_string, "eutf8h", "replace")
    codec_decode(test_string, "eutf8h", "backslashreplace")
    codec_decode(test_string, "eutf8h", "xmlcharrefreplace")
    codec_dec

# Generated at 2022-06-23 18:05:05.189653
# Unit test for function encode
def test_encode():
    # Test empty string.
    assert encode('') == (b'', 0)

    # Test basic ASCII string.
    assert encode('ASCII') == (b'ASCII', 5)

    # Test string with non-ASCII characters.
    assert encode('Русский') == (
        b'\\xd0\\xa0\\xd1\\x83\\xd1\\x81\\xd1\\x81\\xd0\\xba\\xd0\\xb8\\xd0\\xb9',
        12
    )

    # Test string with escaped utf8 hexadecimal.

# Generated at 2022-06-23 18:05:14.060754
# Unit test for function decode
def test_decode():
    """
    >>> codecs.decode(b'\\x48\\x65\\x6c\\x6c\\x6f\\x20\\x77\\x6f\\x72\\x6c\\x64', 'eutf8h')
    'Hello world'
    """
    assert codecs.decode(b'\\x48\\x65\\x6c\\x6c\\x6f\\x20\\x77\\x6f\\x72\\x6c\\x64', 'eutf8h') == 'Hello world'


# Generated at 2022-06-23 18:05:21.723827
# Unit test for function decode
def test_decode():
    # Test case 1.
    # Pass:
    # a!=b
    # Expect:
    # b'a!=b'
    test_str_1 = 'a!=b'
    test_str_bytes_1 = b'a!=b'
    correct_str_1 = test_str_1

    str_1, length_1 = decode(test_str_bytes_1)
    assert str_1 == correct_str_1
    assert length_1 == len(test_str_1)

    # Test case 2.
    # Pass:
    # \x65,\x66\x67
    # Expect:
    # b'\x65\x66\x67'
    test_str_2 = '\\x65,\\x66\\x67'

# Generated at 2022-06-23 18:05:29.824535
# Unit test for function encode
def test_encode():
    """Test encoding to ensure that the output is reversed by decode"""

    simple_str_ascii = 'This string contains only ASCII characters'
    simple_str_utf8 = 'This string contains non-ASCII UTF-8 characters: 日本語'
    escape_str_one = 'This string contains a hex ASCII character: \\x61'
    escape_str_two = 'This string contains two hex ASCII characters: \\x61\\x62'
    escape_str_utf8 = 'This string contains a hex UTF-8 character: \\xe6\\x97\\xa5'

    def assert_reverse_decode(text: str):
        coded_bytes, coded_length = encode(text)
        decoded_str, decoded_length = decode(coded_bytes)
        assert text == decoded_str

# Generated at 2022-06-23 18:05:38.800654
# Unit test for function encode
def test_encode():
    # Test str (non-empty) with no escaped utf8 hexadecimal
    s = 'This is a test string.'
    b = encode(s)
    assert b == (b'This is a test string.', 24)

    # Test str (non-empty) with escaped utf8 hexadecimal
    s = r'\u1234\u5678'
    b = encode(s)
    assert b == (b'\\xe1\\x88\\xb4\\xe5\\x99\\xb8', 8)

    # Test str (non-empty) with a escaped hexadecimal that references an
    # invalid utf8 byte
    try:
        s = r'\xff'
    except UnicodeEncodeError as e:
        assert e.encoding == 'eutf8h'



# Generated at 2022-06-23 18:05:44.529563
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    assert codecs.lookup_error('eutf8h')
    assert not codecs.lookup_error('eutf8h')
    codecs.lookup_error('standard_error')
    assert not codecs.lookup_error('eutf8h')


register()

del register

# Generated at 2022-06-23 18:05:52.008932
# Unit test for function register
def test_register():
    from contextlib import ExitStack, redirect_stdout, redirect_stderr
    from io import StringIO
    from typing import IO
    from typing import cast

    from pyexpect import expect

    from eslutf8h import NAME

    def test_codec_name(fp: IO[str], name: str) -> None:
        """Test the given codec name.

        Args:
            fp: An opened file object to which to print the codec name.
            name: The codec name to print.

        Returns:
            None. The codec will be printed to the file object.

        """
        print(name, file=fp)

    with ExitStack() as stack:
        # Redirect stdout to a stream.
        fp_out = stack.enter_context(StringIO())