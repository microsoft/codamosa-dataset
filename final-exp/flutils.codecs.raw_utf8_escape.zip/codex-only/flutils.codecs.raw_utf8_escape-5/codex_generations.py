

# Generated at 2022-06-23 17:55:58.822712
# Unit test for function encode
def test_encode():
    assert encode(b'') == (b'', 0)
    assert encode('abc') == (b'abc', 3)
    assert encode('abc\\x20def') == (b'abc\\x20def', 11)
    assert encode('abc\\x20def\\x20ghi') == (b'abc\\x20def\\x20ghi', 17)
    assert encode('abc\\x20def\\x20ghi\\x20jkl') == (b'abc\\x20def\\x20ghi\\x20jkl', 23)
    assert encode('abc\\x20def\\x20ghi\\x20jkl\\x20mno') == (b'abc\\x20def\\x20ghi\\x20jkl\\x20mno', 29)



# Generated at 2022-06-23 17:56:09.836030
# Unit test for function encode
def test_encode():
    # Test both UserString and str
    _input_in: Union[str, UserString]
    _input_in = UserString('\\xE3\\x83\\x86\\xE3\\x82\\xB9\\xE3\\x83\\x88')
    _input_out, _input_consumed = encode(_input_in)
    _output: bytes = _input_out
    assert(_output == b'\xe3\x83\x86\xe3\x82\xb9\xe3\x83\x88')
    assert(_input_consumed == 36)

    _input_in = str('\\xE3\\x83\\x86\\xE3\\x82\\xB9\\xE3\x83\x88')

# Generated at 2022-06-23 17:56:10.512471
# Unit test for function register
def test_register():
    register()


# Generated at 2022-06-23 17:56:20.902096
# Unit test for function decode
def test_decode():
    assert decode(b'\\xa') == ('\n', 2)
    assert decode(b'd') == ('d', 1)
    assert decode(b'\\u3070\\u3071\\u3072\\u3075') == ('\u3070\u3071\u3072\u3075', 9)
    assert decode(b'\\U0001d11e') == ('\U0001D11E', 8)
    assert decode(b'\\u200b') == ('\u200b', 5)
    assert decode(b'a\\u3070\\u3071\\u3072\\u3075') == ('a\u3070\u3071\u3072\u3075', 13)
    assert decode(b'a\\U0001d11e') == ('a\U0001D11E', 11)
    assert decode

# Generated at 2022-06-23 17:56:32.585596
# Unit test for function encode
def test_encode():
    """Tests the encode() function by using it to encode a string.
    """
    print('Testing eutf8h.encode()')
    print('')

    text = 'man \xF1\xA8\xAA'
    print(f"The given text: {text.encode('unicode_escape').decode('ascii')}")
    print(f"The given text type: {type(text)}")
    print('')

    print(f"The encode() function's return value: {encode(text)}")
    print('')

    out_bytes, _ = encode(text)
    out_str = out_bytes.decode()
    print(f"The out_str: {out_str}")
    print('')

# Generated at 2022-06-23 17:56:42.357122
# Unit test for function decode
def test_decode():
    print('\n')
    print('--- Unit test for decode ---')
    while True:
        print('Enter a string in escaped utf8 hexadecimal:', end=' ')
        data = str(input())
        try:
            data_bytes = data.encode()
        except UnicodeEncodeError as e:
            print('%s. Skipping input.' % e)
            continue
        except UnicodeTranslateError as e:
            print('%s. Skipping input.' % e)
            continue
        out, len = decode(data_bytes, errors='strict')
        print('Output: %s' % out)
        print('Length of output: %s' % len)



# Generated at 2022-06-23 17:56:49.859092
# Unit test for function encode
def test_encode():
    # Testing an ASCII string
    out, num_consumed = encode('Hello world')
    assert out == b'Hello world'
    assert num_consumed == 11
    # Testing an ASCII string with escaped ASCII characters
    out, num_consumed = encode('Hello world\\x20')
    assert out == b'Hello world\\20'
    assert num_consumed == 12
    # Testing a utf-8 string with an escaped utf-8 character
    out, num_consumed = encode('Héllo world')
    assert out == b'H\\xc3\\xa9llo world'
    assert num_consumed == 11
    # Testing a utf-8 string with an escaped non-printable character
    out, num_consumed = encode('Hello\\x20\\xd0\\xaf world')

# Generated at 2022-06-23 17:57:01.109124
# Unit test for function encode
def test_encode():
    assert encode('Hello World!') == b'Hello World!'
    assert encode('\u2713') == b'\\xe2\\x9c\\x93'
    assert encode('\ud83d\ude01') == b'\\xed\\xa0\\xbd\\xed\\xb8\\x81'
    assert encode('\U0001f601') == b'\\xf0\\x9f\\x98\\x81'
    assert encode('\U0001f601\u2713') == b'\\xf0\\x9f\\x98\\x81\\xe2\\x9c\\x93'
    assert encode('\\u2713') == b'\\\\u2713'
    assert encode('\\\\u2713') == b'\\\\\\xe2\\x9c\\x93'

# Generated at 2022-06-23 17:57:06.750978
# Unit test for function encode
def test_encode():
    codecs.register(_get_codec_info)   # type: ignore
    encoded, length = codecs.encode("\u00B0\u00B0\u00B0\u00B0", "eutf8h")
    assert encoded == b"\\xc2\\xb0\\xc2\\xb0\\xc2\\xb0\\xc2\\xb0"


# Generated at 2022-06-23 17:57:18.052265
# Unit test for function decode
def test_decode():
    """
    >>> test_decode()
    True
    """

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        codecs.register(_get_codec_info)    # type: ignore

    assert decode(b'\\x61\\x62\\x63') == ('abc', 9)
    assert decode(b'\\x61\\x62\\x63', 'ignore') == ('abc', 9)
    assert decode(b'\\x61\\x62\\x63', 'replace') == ('abc', 9)
    assert decode(b'\\x61\\x62\\x63', 'backslashreplace') == ('abc', 9)
    assert decode(b'\\x61\\x62\\x63', 'namereplace') == ('abc', 9)

# Generated at 2022-06-23 17:57:20.635249
# Unit test for function register
def test_register():
    # register()

    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)



# Generated at 2022-06-23 17:57:31.164756
# Unit test for function decode
def test_decode():
    """
    Test function decode() with various examples
    """
    myStr = \
    b'\\xE5\\xB0\\x8F\\xE5\\x85\\x83\\xE5\\xA5\\xB3\\xE5\\xA5\\xB3\\xEF\\xBC\\x88\\xE6\\xB8\\xAC\\xE8\\xA9\\xA6\\xEF\\xBC\\x89'
    myStr2 = b'\\x80'
    myStr3 = b'\\xFE'
    myStr4 = b'\\xFF'

# Generated at 2022-06-23 17:57:33.979876
# Unit test for function register
def test_register():
    register()
    codecs.decode(r'H\x65llo w\x6Frld', NAME)
    codecs.encode(r'H\x65llo w\x6Frld', NAME)



# Generated at 2022-06-23 17:57:43.540798
# Unit test for function encode
def test_encode():
    text = 'Ж'
    text_bytes_utf8, length = encode(text)
    assert text_bytes_utf8 == b'\\xd0\\x96'
    assert length == 1

    text = '\ua000'
    text_bytes_utf8, length = encode(text)
    assert text_bytes_utf8 == b'\\ue000'
    assert length == 2

    text = '\U00012345'
    text_bytes_utf8, length = encode(text)
    assert text_bytes_utf8 == b'\\xf0\\x88\\x88\\x85'
    assert length == 4

    text = '\\x41'
    text_bytes_utf8, length = encode(text)
    assert text_bytes_utf8 == b'A'
    assert length == 5


# Generated at 2022-06-23 17:57:55.455623
# Unit test for function decode
def test_decode():
    # decode - Should decode only the escaped utf8 hexadecimal
    # characters.
    text = '\\xC2\\xA2 \\xE2\\x82\\xAC'
    expect = '¢ €'
    out, consumed = codecs.getdecoder(NAME)(text)    # type: ignore
    assert expect == out
    assert consumed == len(text)
    # decode - Should decode only the escaped utf8 hexadecimal
    # characters.
    text = 'abcd\\xC2\\xA2\\xE2\\x82\\xAC'
    expect = 'abcd¢€'
    out, consumed = codecs.getdecoder(NAME)(text)    # type: ignore
    assert expect == out
    assert consumed == len(text)
    # decode - Should raise ValueError if invalid utf8

# Generated at 2022-06-23 17:57:58.475232
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 17:58:02.572273
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    assert codecs.getdecoder(NAME)   # type: ignore
    try:
        codecs.getencoder(NAME)
    except LookupError:
        pass


# Generated at 2022-06-23 17:58:12.414036
# Unit test for function encode
def test_encode():
    assert encode('a') == (b'a', 1)

    error = 'strict'
    assert encode('a', error) == (b'a', 1)
    assert encode('hello', error) == (b'hello', 5)
    assert encode('\u0042', error) == (b'B', 1)
    assert encode('\u0042a', error) == (b'Ba', 2)
    assert encode('\u0042\u0063', error) == (b'Bc', 2)
    assert encode('\u0042\u0063a', error) == (b'Bca', 3)
    assert encode('\u0042\u0063\u0064', error) == (b'Bcd', 3)

# Generated at 2022-06-23 17:58:13.674397
# Unit test for function encode
def test_encode():
    assert encode('\\xe4') == b'\\\\34\\054'



# Generated at 2022-06-23 17:58:25.857517
# Unit test for function register
def test_register():
    # Save the current codecs.
    prev_getdecoder = codecs.getdecoder

    def _get_decoder_mock(name):
        if name == NAME:
            raise LookupError
        else:
            return prev_getdecoder(name)

    # Mock the codecs.
    codecs.getdecoder = _get_decoder_mock

    register()

    # Restore the previous codecs.
    codecs.getdecoder = prev_getdecoder



# Generated at 2022-06-23 17:58:35.524547
# Unit test for function decode
def test_decode():
    assert b'\\x79' == encode('y')[0]
    assert decode(b'\\x79')[0] == 'y'
    assert b'\\xe2\\x80\\xa6' == encode('\u2026')[0]
    assert decode(b'\\xe2\\x80\\xa6')[0] == '\u2026'
    assert b'\\xc3\\xa4' == encode('ä')[0]
    assert decode(b'\\xc3\\xa4')[0] == 'ä'
    assert b'\\xc3\\xa4\\xe2\\x80\\xa6\\xc3\\xa4' == \
        encode('ä\u2026ä')[0]

# Generated at 2022-06-23 17:58:45.365056
# Unit test for function register
def test_register():

    register()

    out_bytes, consumed = codecs.encode(u'abcdeabcdeabcde', NAME)
    assert out_bytes == b'abcdeabcdeabcde'
    assert consumed == 13

    out_bytes, consumed = codecs.encode(u'\\x06\\x06\\x06', NAME)
    assert out_bytes == b'\\x06\\x06\\x06'
    assert consumed == 6

    out_bytes, consumed = codecs.encode(u'\\x06\\x06\\x06', 'latin-1')
    assert out_bytes == b'\x06\x06\x06'
    assert consumed == 3

    out_bytes, consumed = codecs.encode(u'\\x06\\x06\\x06', 'utf-8')
    assert out_bytes == b

# Generated at 2022-06-23 17:58:54.596776
# Unit test for function encode
def test_encode():
    assert encode('hello') == (b'hello', 5)
    assert encode('\\x68\\x65\\x6C\\x6C\\x6F') == (b'\\x68\\x65\\x6C\\x6C\\x6F', 25)
    assert encode('\\x68\\x65\\x6C\\x6C\\x6F', errors='ignore') == (b'\\x68\\x65\\x6C\\x6C\\x6F', 25)
    with pytest.raises(UnicodeEncodeError):
        encode('\\x68\\x65\\x6C\\x6C\\x6F', errors='strict')

# Generated at 2022-06-23 17:59:03.717883
# Unit test for function encode
def test_encode():
    assert b'\\x61' == encode('a')[0]
    assert b'\\x41\\x42\\x43' == encode('ABC')[0]
    assert b'\\x00\\x80\\xff' == encode('\0\u0080\u00FF')[0]
    assert b'\\xef\\xbd\\xb0' == encode('あ')[0]
    assert b'\\xef\\xbf\\xbf' == encode('\uFFFF')[0]
    assert b'\\xef\\xbf\\xbf' == encode('\U0010FFFF')[0]
    assert b'\\xe4\\xb8\\xad\\xe6\\x96\\x87' == encode(
        '中文'
    )[0]
    assert b'\\xef\\xbf\\xbf'

# Generated at 2022-06-23 17:59:08.753084
# Unit test for function decode
def test_decode():
    # Test 1: Function decode() should return the string s, and the number of 
    # bytes of s consumed, which is the length of s.
    s = '\\xc3\\x97'
    expected = (s, len(s))
    actual = decode(s)
    assert expected == actual



# Generated at 2022-06-23 17:59:10.012736
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)


# Generated at 2022-06-23 17:59:14.366807
# Unit test for function register
def test_register():
    test_dummy_bytes = b'\\x61'
    test_dummy_str = 'a'
    test_dummy_int = 1

    assert decode(test_dummy_bytes) == (test_dummy_str, test_dummy_int)



# Generated at 2022-06-23 17:59:23.773590
# Unit test for function encode

# Generated at 2022-06-23 17:59:34.179330
# Unit test for function encode

# Generated at 2022-06-23 17:59:45.697071
# Unit test for function encode
def test_encode():
    # When called with no arguments, the function returns a byte
    # object with the same text that was passed in.  This is to
    # support pickling and unpickling.
    assert encode('') == (b'', 0)
    assert encode('abc') == (b'abc', 3)
    assert encode('abc\xde\xad') == (b'abc\\xde\\xad', 3)
    assert encode('\u2603') == (b'\\xe2\\x98\\x83', 1)

    # Throw UnicodeEncodeError if the string contains unmappable
    # characters.
    class UnicodeEncodeError_eutf8h(Exception):
        pass


# Generated at 2022-06-23 17:59:55.820646
# Unit test for function encode
def test_encode():
    one_byte_str = 'a'
    one_byte_encoded, consumed = encode(one_byte_str)
    one_byte_expected: bytes = b'a'
    one_byte_result = one_byte_encoded == one_byte_expected
    assert one_byte_result

    two_byte_expected: bytes = b'\\xc3\\xa5'
    two_byte_str = 'å'
    two_byte_encoded, consumed = encode(two_byte_str)
    two_byte_result = two_byte_encoded == two_byte_expected

    assert two_byte_result

    one_two_three_byte_str = '\U00024B62'
    one_two_three_byte_encoded, consumed = encode(one_two_three_byte_str)
    one_

# Generated at 2022-06-23 17:59:58.607634
# Unit test for function register
def test_register():
    codecs.lookup(NAME)


if __name__ == '__main__':
    register()

# Generated at 2022-06-23 18:00:08.240350
# Unit test for function encode
def test_encode():
    import pytest
    in_data = 'ABC 123 $£€ | ~ ! # % & / \ \n \t'

# Generated at 2022-06-23 18:00:12.423695
# Unit test for function decode
def test_decode():
    # given
    given_data = r'\x34\x35\x36\x37\x38'
    # when
    actual_out, actual_length = decode(given_data)
    # then
    expect_out = '45678'
    assert actual_out == expect_out


# Generated at 2022-06-23 18:00:23.336912
# Unit test for function decode
def test_decode():
    assert decode(bytes('hello', 'utf-8')) == ('hello', 5)
    assert decode(bytes('hello', 'utf-8')[:-1]) == ('hello', 4)
    assert decode(
        bytes('\\x30EncodeOnly\\x31DecodeOnly', 'unicode_escape')
    ) == ('0EncodeOnly1DecodeOnly', 27)
    assert decode(
        bytes('\\x30EncodeOnly\\x31DecodeOnly', 'unicode_escape')[:-1]
    ) == ('0EncodeOnly1DecodeOnly', 26)
    assert decode(
        bytes('\\x30EncodeOnly\\x31DecodeOnly\\x32EncodeAndDecode', 'unicode_escape')
    ) == ('0EncodeOnly1DecodeOnly2EncodeAndDecode', 46)

# Generated at 2022-06-23 18:00:28.081125
# Unit test for function register
def test_register():

    # Attempt to register this codec
    register()

    # Attempt to retrieve this codec
    # noinspection PyBroadException
    try:
        codecs_this = codecs.getdecoder(NAME)  # type: ignore
    except:
        codecs_this = None

    # Assert that this codec exists
    assert codecs_this



# Generated at 2022-06-23 18:00:28.988799
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 18:00:35.857919
# Unit test for function register
def test_register():
    # When codecs is not registered
    is_registered = NAME in codecs.getencodings()

    # With the given codec register
    register()

    # Then the given codec is registered
    assert NAME in codecs.getencodings()

    # When codecs is registered before
    is_registered = NAME in codecs.getencodings()

    # With the given codec register
    register()

    # Then the given codec is still registered
    assert NAME in codecs.getencodings()

# Generated at 2022-06-23 18:00:38.604259
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    register()
    _ = codecs.getdecoder(NAME)

# Generated at 2022-06-23 18:00:42.333348
# Unit test for function register
def test_register():
    """
    >>> import codecs
    >>> _info = codecs.getdecoder('eutf8h')
    >>> _info.name
    'eutf8h'
    """



# Generated at 2022-06-23 18:00:51.859413
# Unit test for function encode
def test_encode():
    # test 1
    text1 = '\\x50\\x6F\\x77\\x65\\x72\\x65\\x64\\x20\\x62\\x79\\x20\\x65\\x76\\x69\\x6C'
    encoded_text1, consumed_text1 = encode(text1)
    assert text1 == encoded_text1.decode('unicode_escape')
    assert consumed_text1 == len(text1)

    # test 2
    text2 = 'abc'
    encoded_text2, consumed_text2 = encode(text2)
    assert text2 == encoded_text2.decode('unicode_escape')
    assert consumed_text2 == len(text2)

    # test 3
    text3 = 'Поверед'
    encoded_text3, consumed_text

# Generated at 2022-06-23 18:01:01.884507
# Unit test for function encode
def test_encode():
    sample1 = 'abc'
    sample2 = 'abc\\x48\\x65\\x6c\\x6c\x6f\\x20\\x77\\x6F\\x72\\x6C\\x64'

    if NAME not in codecs.encode('', NAME).decode('utf-8'):
        raise AssertionError

    if codecs.encode(sample1, NAME).decode('utf-8') != sample1:
        raise AssertionError
    if codecs.encode(sample2, NAME).decode('utf-8') != 'abcHello world':
        raise AssertionError

    sample3 = 'abc\\x48\\x65\\x6c\\x6c\x6f\\x20\\x77\\x6F\\x72\\x6C\\x64'

# Generated at 2022-06-23 18:01:07.928049
# Unit test for function encode
def test_encode():
    test_str = "€é\\xE9"
    test_str_bytes = b'\\u20ac\\xe9\\\\xE9'
    out_bytes, out_len = encode(test_str)
    assert test_str_bytes == out_bytes, f"{test_str_bytes} != {out_bytes}"
    assert 3 == out_len


# Generated at 2022-06-23 18:01:10.765154
# Unit test for function decode
def test_decode():
    data = b'\\xc2\\x82\\xe2\\x82\\xac'
    out = decode(data)
    print(out)



# Generated at 2022-06-23 18:01:21.081284
# Unit test for function encode
def test_encode():
    # noinspection SpellCheckingInspection
    byte_string, length = encode(
        'Test string\t \n\\t\n\\t\\n\\t\\n \\t\\n \\t \\x62'
    )
    assert byte_string == b'Test string\\09\\20\\0a\\t\\n\\t\\n\\t\\n\\09\\n' \
                          b'\\20\\t\\09\\n\\20\\t\\20\\5c\\78\\62'
    assert length == 31



# Generated at 2022-06-23 18:01:32.650569
# Unit test for function decode
def test_decode():
    assert decode(b'\\x41\\x42\\x43')[0] == 'ABC'
    assert decode(b'\\xF4\\x8F\\xBF\\xBF')[0] == '\U0010FFFF'
    assert decode(b'\\x41\\x42\\x43\\x44\\x45\\x46\\x47\\x48')[0] == 'ABCDEFGH'
    assert decode(b'\\xC3\\x84\\xC3\\x85\\xC3\\x87\\xC3\\x89')[0] == 'ÄÅÇÉ'
    assert decode(b'\\x61\\x62\\x63\\x64\\x65\\x66\\x67\\x68')[0] == 'abcdefgh'

# Generated at 2022-06-23 18:01:36.952618
# Unit test for function decode
def test_decode():
    assert decode(
        b'\\xE3\\x81\\xBB\\xE3\\x82\\x8F\\xE3\\x81\\x84') == \
        ('\u30bb\u30ef\u30a4', 10)



# Generated at 2022-06-23 18:01:45.993601
# Unit test for function encode
def test_encode():
    assert encode('abc\\x20def') == (b'abc\\x20def', 10)
    assert encode('abc\\x20def', 'replace') == (b'abc\\x20def', 10)
    assert encode('abc\\x20def', 'ignore') == (b'abcdef', 8)
    assert encode('abc\\x20def', 'surrogateescape') == (b'abc\x80def', 8)
    assert encode('abc\\x20def', 'backslashreplace') == (b'abc\\x20def', 10)
    assert encode('abc\\x20def', 'xmlcharrefreplace') == (b'abc&#32;def', 10)

    assert encode('abc\\x80def') == (b'abc\\xc2\\x80def', 12)
    assert encode('abc\\x80def', 'replace')

# Generated at 2022-06-23 18:01:48.968930
# Unit test for function decode
def test_decode():
    input_str = '\xC3\xA1'
    output_str = '\\xc3\\xa1'
    assert decode(output_str.encode('utf-8'))[0] == input_str


# Generated at 2022-06-23 18:01:58.731214
# Unit test for function encode
def test_encode():
    text_input = 'this is a test'
    data, n = encode(text_input)
    assert data == b'this is a test'
    assert n == len(text_input)

    text_input = 'this is a test\u65e5'
    data, n = encode(text_input)
    assert data == b'this is a test\\xe6\\x97\\xa5'
    assert n == len(text_input)

    text_input = 'this is a test\\xe6\\x97\\xa5'
    data, n = encode(text_input)
    assert data == b'this is a test\\xe6\\x97\\xa5'
    assert n == len(text_input)

    text_input = '\\xe6\\xc2\\x97'

# Generated at 2022-06-23 18:02:05.199102
# Unit test for function encode
def test_encode():
    assert encode('', 'strict') == (b'', 0)

    # Something that is printable, not escaped
    assert encode('a', 'strict') == (b'a', 1)
    assert encode('abc', 'strict') == (b'abc', 3)

    assert encode('\n', 'strict') == (b'\n', 1)
    assert encode('\t', 'strict') == (b'\t', 1)
    assert encode('\\', 'strict') == (b'\\', 1)
    assert encode('\0', 'strict') == (b'\0', 1)
    assert encode('\x01', 'strict') == (b'\x01', 1)

    # Escaped printable characters

# Generated at 2022-06-23 18:02:13.780110
# Unit test for function encode
def test_encode():
    # Test for empty input
    out, len_data = encode('')
    assert len_data == 0
    assert out == b''

    with pytest.raises(UnicodeEncodeError) as e:
        encode('\\xBlah')  # type: ignore

    out, len_data = encode('A')
    assert len_data == 1
    assert out == b'A'  # type: ignore

    out, len_data = encode('\u1234')
    assert len_data == 1
    assert out == b'\\xe1\\x88\\xb4'  # type: ignore


# Generated at 2022-06-23 18:02:19.540395
# Unit test for function encode
def test_encode():
    for text, expected in (
        ('abc\n', b'abc\\n'),
        ('abc\x00\x01\x02', b'abc\\x00\\x01\\x02'),
        ('\ud800', b'\\xed\\xa0\\x80'),
        ('\U0001f914', b'\\xf0\\x9f\\xa4\\x94'),
    ):
        _test_encode(text, expected)



# Generated at 2022-06-23 18:02:22.228335
# Unit test for function register
def test_register():
    """Unit test for function register."""
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        assert False, 'Codec not registered'

# Generated at 2022-06-23 18:02:28.229576
# Unit test for function encode
def test_encode():
    assert encode('abcd') == (b'abcd', 4)
    assert encode('\\x41') == (b'\\x41', 3)
    assert encode('\\x41\\x42') == (b'\\x41\\x42', 6)
    assert encode('\\uD83D\\xDC8B') == (b'\\xED\\xA0\\xBD\\xED\\xB2\\x8B', 9)



# Generated at 2022-06-23 18:02:32.208345
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME) is not None
    assert codecs.getdecoder(NAME) is not None
    assert codecs.lookup(NAME) is not None

# Generated at 2022-06-23 18:02:41.727391
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)
    assert codecs.encode('test', 'eutf8h') == b"t\\x74\\x65\\x73\\x74"
    assert codecs.decode(b"t\\x74\\x65\\x73\\x74", 'eutf8h') == "test"
    assert codecs.encode('你好', 'eutf8h') == b"\\xe4\\xbd\\xa0\\xe5\\xa5\\xbd"
    assert codecs.decode(b"\\xe4\\xbd\\xa0\\xe5\\xa5\\xbd", 'eutf8h') == "你好"

# Generated at 2022-06-23 18:02:49.930072
# Unit test for function encode
def test_encode():
    from unittest import TestCase
    from .support import encode_test_data, encode_test_result, encode_test_errors

    # Create a test class, derived from the python unittest framework.
    # http://docs.python.org/3.3/library/unittest.html
    class TestEncode(TestCase):

        # Test the utf-8 encoder
        def test_encode(self):
            # Call 'encode' with the Unit test data
            for (str_, expected_str) in zip(encode_test_data, encode_test_result):
                with self.subTest(str_=str_):
                    out, consumed = encode(str_, 'strict')
                    actual_str = out.decode('utf-8')
                    # Test that the expected result is achieved

# Generated at 2022-06-23 18:02:59.305919
# Unit test for function encode
def test_encode():
    assert encode('a') == (b'a', 1)
    assert encode('ab') == (b'ab', 2)
    assert encode('123') == (b'123', 3)
    assert encode('\\u0041') == (b'\\x41', 7)
    assert encode('\\u00419') == (b'\\x419', 8)
    assert encode('\\u00419\\u0041') == (b'\\x419\\x41', 14)
    assert encode('\\x41') == (b'\\x41', 4)
    assert encode('\\x419') == (b'\\x419', 4)
    assert encode('\\x419\\x41') == (b'\\x419\\x41', 8)

# Generated at 2022-06-23 18:03:03.736870
# Unit test for function decode
def test_decode():
    text_bytes_utf8 = b'\x44\x61\x6c\x65\x32\x0a'  # 'Dale2\n'
    text_str_latin1 = text_bytes_utf8.decode('unicode_escape')
    text_bytes_utf8 = text_str_latin1.encode('latin1')
    text_str = text_bytes_utf8.decode('utf-8')

    # Convert each character into a string of escaped utf8 hexadecimal.
    out_str = reduce(lambda a, b: f'{a}{b}', _each_utf8_hex(text_str))

    assert decode(out_str.encode('utf-8')) == (text_str, len(text_str))



# Generated at 2022-06-23 18:03:11.082716
# Unit test for function decode
def test_decode():
    assert decode(b'\\x47\\x6f\\x6f\\x64\\x20\\x62\\x79') == \
           ('Good by', 0)
    assert decode(b'\\x47\\x6f\\x6f\\x64\\x20\\x62\\x79') == \
           ('Good by', 7)
    assert decode(b'\\x47\\x6f\\x6f\\x64\\x20\\x62\\x79') == \
           ('Good by', 7)
    assert decode(b'\\x47\\x6f\\x6f\\x64\\x20\\x62\\x79\\x2e') == \
           ('Good by.', 8)


# Generated at 2022-06-23 18:03:17.087592
# Unit test for function register
def test_register():
    codecs.register(_get_codec_info)
    obj = codecs.getdecoder(NAME)()
    assert obj.decode(b'h\\x65\\x6C\\x6C\\x6F\\x20\\x77\\x6F\\x72\\x6C\\x64') == ('hello world', 35)


if __name__ == '__main__':
    register()

# Generated at 2022-06-23 18:03:27.640418
# Unit test for function decode
def test_decode():
    # Function decode
    a = decode(b'\\xe2\\x98\\x83')
    assert a == ('☃', 7)
    a = decode(b'\\xe2\\x98\\x83', errors='strict')
    assert a == ('☃', 7)
    # Unrecognized escaped hexadecimal sequence
    try:
        decode(b'\\xe2\\x98\\x83\\x30')
    except UnicodeDecodeError as e:
        assert e.args == ('eutf8h', b'\\xe2\\x98\\x83\\x30', 11, 12, 'invalid start byte')
        assert e.reason == 'invalid start byte'
    # Test for given bytes that does not contain a single byte of
    # escaped hexadecimal sequence.

# Generated at 2022-06-23 18:03:37.867881
# Unit test for function register
def test_register():
    assert codecs.encode('a', NAME) == b'a'
    assert codecs.encode('a', NAME, 'ignore') == b'a'
    assert codecs.encode('a', NAME, 'surrogateescape') == b'a'
    assert codecs.encode('a', NAME, 'backslashreplace') == b'a'
    assert codecs.encode('a', NAME, 'xmlcharrefreplace') == b'a'

    assert codecs.decode(b'a', NAME) == 'a'
    assert codecs.decode(b'a', NAME, 'ignore') == 'a'
    assert codecs.decode(b'a', NAME, 'surrogateescape') == 'a'

# Generated at 2022-06-23 18:03:44.221729
# Unit test for function encode
def test_encode():
    text = 'a'
    expected = b'a'
    actual = encode(text)
    assert actual == (expected, 1)

    text = 'aa'
    expected = b'aa'
    actual = encode(text)
    assert actual == (expected, 2)

    text = 'aaa'
    expected = b'aaa'
    actual = encode(text)
    assert actual == (expected, 3)

    text = 'aaaa'
    expected = b'aaaa'
    actual = encode(text)
    assert actual == (expected, 4)

    text = 'a a'
    expected = b'a\x20a'
    actual = encode(text)
    assert actual == (expected, 3)

    text = 'a aa'
    expected = b'a\x20aa'
    actual = encode(text)


# Generated at 2022-06-23 18:03:51.853138
# Unit test for function encode
def test_encode():
    assert encode('hello world!') == (b'hello world!', 12)
    assert encode(u'hello world!') == (b'hello world!', 12)
    assert encode('hello \\u2028world!') == (b'hello \\u2028world!', 15)
    assert encode('hello \\u2028world!', errors='replace') == (
        b'hello ?world!',
        15,
    )
    assert encode('hello \\u2028world!', errors='ignore') == (
        b'hello world!',
        15,
    )
    assert encode('hello \\u2028world!', errors='strict') == (
        b'hello \\u2028world!',
        15,
    )
    assert encode('hello \\x00world!') == (b'hello \\x00world!', 15)

# Generated at 2022-06-23 18:03:52.568294
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-23 18:03:58.236978
# Unit test for function register
def test_register():
    data = b'\\xC3\\xA1\\xC3\\xA9\\xC3\\xAD\\xC3\\xB3\\xC3\\xBA'
    data_bytes = bytearray(data)
    out = codecs.decode(data_bytes, NAME)
    assert out == 'áéíóú'



# Generated at 2022-06-23 18:04:05.930476
# Unit test for function decode
def test_decode():
    data_bytes = (b'\\xe2\\x82\\xac'
                  b'\\xC2\\xA3'
                  b'\\x2A\\x2A\\x2A'
                  b'\\x20\\x20\\x20'
                  b'\\x0D\\x0A'
                  b'\\x0D\\x0A'
                  b'\\x0D\\x0A'
                  b'\\x0D\\x0A'
                  b'\\x0D'
                  b'\\x0A'
                  b'\\x0D'
                  b'\\x0A'
                  b'\\x0D'
                  b'\\x0A'
                  b'\\x0D'
                  b'\\x0A')

# Generated at 2022-06-23 18:04:09.563225
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        codecs.getdecoder(NAME)



# Generated at 2022-06-23 18:04:13.719103
# Unit test for function encode
def test_encode():
    my_str = '\\xC3\\xA5'
    bytes_result, _ = encode(my_str)
    assert b'\\xC3\\xA5' == bytes_result



# Generated at 2022-06-23 18:04:18.028000
# Unit test for function register
def test_register():
    import codecs
    register()
    try:
        # This should not raise a LookupError
        codecs.getdecoder(NAME)
    except LookupError:
        raise AssertionError('register function failed')
    else:
        codecs.lookup(NAME)

# Generated at 2022-06-23 18:04:24.633571
# Unit test for function register
def test_register():
    # Delete the codec if it is already registered.
    try:
        del codecs.decode_error_registry['eutf8h']
    except KeyError:
        pass
    except AttributeError:
        pass

    # Confirm the codec has been removed.
    with pytest.raises(LookupError):
        codecs.getdecoder(NAME)

    # Register it.
    register()

    # Confirm the codec has been registered.
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 18:04:25.873986
# Unit test for function decode
def test_decode():
    assert codecs.decode('\\x0D', 'eutf8h') == '\r'



# Generated at 2022-06-23 18:04:32.059979
# Unit test for function encode
def test_encode():
    # print('test_encode')
    assert b'\\x41' == encode('A')[0]
    assert b'\\x4B' == encode('K')[0]
    assert b'\\x41\\x42\\x43\\x44\\x45' == encode('ABCDE')[0]
    assert b'\\x41\\x42\\x43\\x44\\x45\n' == encode('ABCDE\n')[0]
    assert b'\\x41\\x42\\x43\\x44\\x45\\x20' == encode('ABCDE ')[0]
    assert b'\\x41\\x42\\x43\\x44\\x45\\x20\n' == encode('ABCDE \n')[0]

# Generated at 2022-06-23 18:04:41.061397
# Unit test for function encode
def test_encode():
    input_str = 'Bye, world. \\x00abc\\xFFdef'

    errors = 'strict'
    output_bytes, _ = encode(input_str, errors)
    assert output_bytes == b'Bye, world. \\x00abc\\xFFdef'

    errors = 'ignore'
    output_bytes, _ = encode(input_str, errors)
    assert output_bytes == b'Bye, world. \\x00abc\\xFFdef'

    errors = 'replace'
    output_bytes, _ = encode(input_str, errors)
    assert output_bytes == b'Bye, world. \\x00abc\\xFFdef'

    errors = 'backslashreplace'
    output_bytes, _ = encode(input_str, errors)

# Generated at 2022-06-23 18:04:41.981917
# Unit test for function decode
def test_decode():
    assert decode((b'\\xc3\\xa7')) == ('ç', 7)



# Generated at 2022-06-23 18:04:53.074833
# Unit test for function encode
def test_encode():
    # Test against a non-existing unicode character. Should raise an
    # 'UnicodeEncodeError'
    try:
        encode(u'\ud83d\ude20')
        assert False, 'Should never get here'
    except UnicodeEncodeError:
        assert True

    # Test various unicode characters
    test_str = 'a\xe2\x82\xac\xe3\x82\xae\xe3\x82\xb3\xe3\x82\xb5\xe3\x82\xa4'

# Generated at 2022-06-23 18:05:05.125884
# Unit test for function decode

# Generated at 2022-06-23 18:05:16.712748
# Unit test for function decode

# Generated at 2022-06-23 18:05:26.124986
# Unit test for function encode
def test_encode():
    assert encode('abc', 'ignore') == (b'abc', 3)
    assert encode('abc', 'replace') == (b'abc', 3)
    assert encode('abc', 'strict') == (b'abc', 3)
    assert encode('a\x00c', 'strict') == (b'a\\00c', 4)
    assert encode('a', 'strict') == (b'a', 1)
    try:
        encode('a\x00c', 'strict')
    except UnicodeEncodeError as e:
        assert e.encoding == 'eutf8h'
        assert e.object == 'a\x00c'
        assert e.start == 2
        assert e.end == 3
        assert e.reason == 'invalid continuation byte'


# Generated at 2022-06-23 18:05:28.063168
# Unit test for function register
def test_register():
    register()
    codecs.open('test_file.txt', 'r', NAME)

# Generated at 2022-06-23 18:05:29.990431
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)



# Generated at 2022-06-23 18:05:38.849666
# Unit test for function encode
def test_encode():
    text = '\u0f08\u0f0e\u0f09\u0f0a\u0f0f\u0f12'
    out = b'\\xe0\\xbd\\x88\\xe0\\xbd\\x8e\\xe0\\xbd\\x89\\xe0\\xbd\\x8a\\xe0\\xbd\\x8f\\xe0\\xbd\\x92'
    assert encode(text, 'strict') == (out, 6)

    # test that the input is converted to string
    # noinspection PyTypeChecker
    assert encode(UserString(text), 'strict') == (out, 6)

    # test that the input is converted to bytes
    # noinspection PyTypeChecker

# Generated at 2022-06-23 18:05:49.163375
# Unit test for function encode
def test_encode():
    assert encode(
        r'This is a test string.\xfa\xce\xbe\xef is not utf8.'
    ) == (
        b'This is a test string.\\xfa\\xce\\xbe\\xef is not utf8.',
        48
    )
    assert encode(
        r'This is a test string.\xfa\xce\xbe\xef is not utf8.',
        errors='ignore'
    ) == (
        b'This is a test string. is not utf8.',
        48
    )