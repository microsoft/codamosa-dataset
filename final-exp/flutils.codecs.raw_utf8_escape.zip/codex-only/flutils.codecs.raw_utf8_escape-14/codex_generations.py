

# Generated at 2022-06-23 17:55:57.729752
# Unit test for function encode
def test_encode():
    # Reference: https://en.wikipedia.org/wiki/UTF-8#Examples
    # Test 1
    text = 'Hello'
    out, consumed = encode(text)
    assert consumed == len(text)
    assert text.encode('utf-8') == out

    # Test 2
    text = 'ᚠᛇᚻ'
    out_expected = b'\\xe1\\x9a\\xa0\\xe1\\x9b\\x87\\xe1\\x9a\\xbb'
    out, consumed = encode(text)
    assert consumed == len(text)
    assert out_expected == out

    # Test 3
    text = '𐌈𐌂𐌀'

# Generated at 2022-06-23 17:56:01.419368
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        raise



# Generated at 2022-06-23 17:56:07.708647
# Unit test for function encode
def test_encode():
    test_text = 'simple text'
    test_bytes = b'simple text'
    result = encode(test_text)
    if result[0] != test_bytes:
        print("test_encode failed")
        print("  " + "test_text: " + test_text)
        print("  " + "test_bytes: " + str(test_bytes))
        print("  " + "result: " + str(result[0]))


# Generated at 2022-06-23 17:56:15.487508
# Unit test for function decode
def test_decode():
    assert decode('abc') == ('abc', 3)
    assert decode('abc')[0] == 'abc'
    assert decode(b'abc')[0] == 'abc'

    assert decode(b'abc')[0] == 'abc'
    assert decode(b'\\x61\\x62\\x63') == ('abc', 14)
    assert decode(b'\\x61\\x62\\x63')[0] == 'abc'
    assert decode(b'\\x61\\x62\\x63')[1] == 14
    assert decode(b'\\x61\\x62\\x63') == ('abc', 14)
    assert decode(b'\\xC2\\xA2') == ('¢', 8)
    assert decode(b'\\xC2\\xA2')[0] == '¢'
    assert decode

# Generated at 2022-06-23 17:56:21.031914
# Unit test for function encode
def test_encode():
    assert encode('abc') == (b'abc', 3)
    assert encode('\\x61') == (b'\\x61', 5)
    assert encode('\\x61\\x62\\x63') == (b'\\x61\\x62\\x63', 15)
    assert encode('\\xC3\\x82\\xC2\\xA9') == (b'\\u00c3\\u0082\\u00c2\\u00a9', 15)
    assert encode('\\U0000D55C') == (b'\\xed\\x95\\x9c', 9)
    assert encode('\\U0000D55C\\U0000AD6D') == (b'\\xed\\x95\\x9c\\xed\\x94\\xad', 21)


# Generated at 2022-06-23 17:56:32.703602
# Unit test for function decode
def test_decode():
    assert(decode('hello', errors='strict') == (
        'hello',
        5)
    )
    assert(decode('Hello \\u00d7 \\u00d8 World', errors='strict') == (
        'Hello × Ø World',
        20)
    )
    assert(decode('k\\xF6ttbullar \\\\x20', errors='strict') == (
        'köttbullar \x20',
        15)
    )

# Generated at 2022-06-23 17:56:34.102786
# Unit test for function register
def test_register():
    register()
    register()
    register()

# Generated at 2022-06-23 17:56:44.351257
# Unit test for function decode
def test_decode():
    # Test escape hexadecimal literal '\x0a' and regular characters
    # Test escape hexadecimal literal '\x0a' and regular characters
    assert decode(b'\\x0a', 'strict') == ('\n', 5)
    assert decode(b'\\x0aabcd', 'strict') == ('\na', 5)
    assert decode(b'foo\\x0a', 'strict') == ('foo\n', 7)
    assert decode(b'foo\\x0aabcd', 'strict') == ('foo\na', 7)

    # Test escape hexadecimal literal '\xFF'
    assert decode(b'\\xFF', 'strict') == ('\u00ff', 5)

# Generated at 2022-06-23 17:56:50.847555
# Unit test for function register
def test_register():
    # Register the codec.
    register()

    assert NAME not in codecs.getencodings()
    assert NAME not in codecs.getencodings_charmap()
    assert NAME not in codecs.getencodings_alias()
    assert NAME not in codecs.getdecodings()
    assert NAME not in codecs.getdecodings_charmap()
    assert NAME not in codecs.getdecodings_alias()
    assert NAME not in codecs.getaliases()

    # Test that the codec throws a LookupError exception.
    try:
        codecs.getencoder(NAME)
    except LookupError:
        pass
    else:
        assert False

    try:
        codecs.getdecoder(NAME)
    except LookupError:
        pass
    else:
        assert False

# Generated at 2022-06-23 17:56:51.973052
# Unit test for function decode
def test_decode():
    pass



# Generated at 2022-06-23 17:56:54.318749
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME)  # type: ignore
    assert codecs.getdecoder(NAME)  # type: ignore

# Generated at 2022-06-23 17:57:06.953245
# Unit test for function decode
def test_decode():
    """Test function decode."""
    from sys import version_info as _version_info

    def _as_bytes(x: _Str) -> bytes:
        if _version_info[0:2] < (3, 0):
            return x
        return x.encode('utf-8')

    # Test that the empty string returns an empty string.
    assert decode(b'') == ('', 0)

    # Test that a simple text string is decoded correctly.
    assert decode(b'Hello world!') == ('Hello world!', 12)

    # Test that a escaped utf8 hexadecimal string is decoded correctly.
    assert decode(b'\\xe8\\x8a\\xb1') == ('花', 6)

    # Test that a simple text string returns without any problems.
    assert decode(b'Hello world!')

# Generated at 2022-06-23 17:57:16.047719
# Unit test for function encode
def test_encode():
    print('Hello')
    input_text = 'C:\\Project\\☺☺.txt'
    out, consumed_count = encode(input_text)
    print('Hello')
    expected_out = b'C:\\\x50\x72\x6f\x6a\x65\x63\x74\\\xE2\x98\xBA\xE2\x98\xBA.\x74\x78\x74'
    assert out == expected_out
    assert consumed_count == len(input_text)


register()

# Generated at 2022-06-23 17:57:20.042080
# Unit test for function decode
def test_decode():
    assert decode(b'\\xC2\\xA2')[0] == '¢'
    assert decode(b'\xc2\xa2')[0] == '¢'



# Generated at 2022-06-23 17:57:25.003161
# Unit test for function decode
def test_decode():
    """Ensures decode() behaves as expected."""
    assert decode(b'\\x84\\x00\\x00\\x00') == ('🐊', 10)
    assert decode(b'\\x44') == ('D', 4)
    assert decode(b'\\x44', 'ignore') == ('', 4)



# Generated at 2022-06-23 17:57:34.735844
# Unit test for function decode
def test_decode():
    print('Test decode function')
    print('\n')
    print('With Input:')
    print('    data = bytearray(b\'\\x48\\x65\\x6c\\x6c\\x6f\\x3a\\x48\\x65\\x78\\x42\\x79\\x74\\x65\\x5f\\x31\\x32\\x33\\x34\\x35\\x36\\x37\\x38\\x39\\x30\\x21\\x21\')')
    print('    errors = \'strict\'')

# Generated at 2022-06-23 17:57:38.670009
# Unit test for function decode
def test_decode():
    data = b'\\xE1\\x84\\x83\\xE1\\x85\\xB5\\xE1\\x86\\xAB\\xE1\\x87\\x8C'
    out, consumed = decode(data)
    assert consumed == len(data)
    assert '딘ᇌ' == out



# Generated at 2022-06-23 17:57:46.400684
# Unit test for function register
def test_register():
    # noinspection PyUnresolvedReferences
    from sys import path
    import os
    import sys
    import unittest

    os_sep = os.sep
    module_package = os.path.join(__name__.split('.')[0], 'eutf8h')
    module_package = module_package.replace(os_sep, '.')
    module_name = __name__.split('.')[-1]
    module_name_full = '{}.{}'.format(module_package, module_name)

    if module_package in path:
        # noinspection PyUnresolvedReferences
        import eutf8h
        reload(eutf8h)
        del eutf8h
    else:
        path.insert(0, '.')


# Generated at 2022-06-23 17:57:56.314668
# Unit test for function encode
def test_encode():
    test_input = (
        '\\x41\\x42\\x43\\xe1\\xb8\\xad'
        '\\xe1\\x88\\xb4\\x41\\x42\\x43',
    )

    test_result = (
        b'\x41\x42\x43\xe1\xb8\xad'
        b'\xe1\x88\xb4\x41\x42\x43',
    )

    out, consumed = encode(test_input)
    assert out == test_result
    assert consumed == len(test_input)

    with pytest.raises(UnicodeEncodeError):
        out = encode(test_input + '\\x41\\xA')



# Generated at 2022-06-23 17:58:03.804889
# Unit test for function register
def test_register():
    register()

    # Make sure the codec can be decoded.
    s = '\\x74\\x65\\x73\\x74'
    b = s.encode(NAME)
    assert b == b'test'

    # Make sure the codec can be encoded.
    s = 'test'
    b = s.encode(NAME)
    assert b == b'\\x74\\x65\\x73\\x74'



# Generated at 2022-06-23 17:58:13.233915
# Unit test for function encode
def test_encode():
    tests = [
        ('hello world', b'hello world'),
        ('\\xC3\\x80\\xC3\\xA1', b'\\xC3\\x80\\xC3\\xA1'),
        ('\\xC3\\x80\\xE1', b'\\xC3\\x80\\xC3\\xA1'),
        ('\\xC3\\x80\\x70', b'\\xC3\\x80\\x70'),
    ]
    for text, bytes_out in tests:
        print('text: %r' % text)
        bytes_out_ec, _ = codecs.escape_encode(text.encode('utf8'))
        print('Expected: %r' % bytes_out_ec)
        bytes_out_eutf8h, _ = encode(text)

# Generated at 2022-06-23 17:58:25.364457
# Unit test for function encode

# Generated at 2022-06-23 17:58:28.874489
# Unit test for function register
def test_register():
    register()
    try:
        codecs.getdecoder(NAME)
    except LookupError as e:
        print(e)
        raise


# Generated at 2022-06-23 17:58:37.789138
# Unit test for function decode
def test_decode():
    # Convert the utf-8 bytes into a string.
    expected_str = 'a b c d e f g h i j k l m n o p q r s t u v w x y z'
    expected_bytes = expected_str.encode('utf-8')
    # Convert the utf8 bytes into a string of hexadecimal escaped-utf8.
    redirected_bytes = expected_bytes.decode('unicode_escape')
    redirected_bytes = redirected_bytes.encode('latin1')
    # Convert the escaped-utf8 hexadecimal string of escaped-utf8 bytes into a
    # string.
    redirected_bytes = redirected_bytes.decode('unicode_escape')
    redirected_str = redirected_bytes.decode('latin1')
    # Convert the escaped-utf8 hexadecimal string of escaped

# Generated at 2022-06-23 17:58:47.591522
# Unit test for function encode
def test_encode():
    input_str = 'hello'
    output_bytes, len_output_bytes = encode(input_str)
    assert output_bytes == b'hello'
    assert len_output_bytes == len(input_str)

    input_str = '\n'
    output_bytes, len_output_bytes = encode(input_str)
    assert output_bytes == b'\\x0a'
    assert len_output_bytes == len(input_str)

    input_str = '\x0a'
    output_bytes, len_output_bytes = encode(input_str)
    assert output_bytes == b'\\x0a'
    assert len_output_bytes == len(input_str)

    input_str = '\u3042'
    output_bytes, len_output_bytes = encode(input_str)


# Generated at 2022-06-23 17:58:55.855086
# Unit test for function encode
def test_encode():
    # type: () -> None
    """Unit test for function encode"""
    # Simple printable test cases.
    assert encode('\u263A')[0] == b'\xE2\x98\xBA'
    # Tests escaped string hexadecimal is converted to unicode and then
    # escaped.
    assert encode('\\u263A')[0] == b'\x5Cu263A'
    # Tests for unexpected trailing escape characters.
    assert encode('\\')[0] == b'\x5C'
    # Tests for unexpected trailing escape characters.
    assert encode('\\u')[0] == b'\x5Cu'
    # Tests for unexpected trailing escape characters.
    assert encode('\\u2')[0] == b'\x5Cu2'
    # Tests for unexpected trailing escape characters.
    assert encode

# Generated at 2022-06-23 17:59:04.436138
# Unit test for function encode
def test_encode():
    assert encode('text', 'strict') == (b'\x74\x65\x78\x74', 4)
    assert encode('text\u2765', 'ignore') == (b'\x74\x65\x78\x74', 4)
    assert encode('text\u2765', 'replace') == (b'\x74\x65\x78\x74\xef\xbf\xbd', 5)
    assert encode('text\u2765', 'replace') == (b'\x74\x65\x78\x74\xef\xbf\xbd', 5)

    assert encode('text\u2765', 'strict') == (b'\xe2\x9d\xa5', 2)


# Generated at 2022-06-23 17:59:08.965662
# Unit test for function decode
def test_decode():
    out, _ = decode(r'\xF0\x9F\x92\xA9\\xF0\x9F\x92\xA9')
    assert out == '\xF0\x9F\x92\xA9\\xF0\x9F\x92\xA9'

    out, _ = decode(r'\xF0\x9F\x92\xA9')
    assert out == '\xF0\x9F\x92\xA9'


# Generated at 2022-06-23 17:59:09.558841
# Unit test for function register
def test_register():
    register()



# Generated at 2022-06-23 17:59:12.821705
# Unit test for function encode
def test_encode():
    a = '\\u2663'
    result = encode(a)[0].decode('utf-8')
    print(result)


# Generated at 2022-06-23 17:59:13.732251
# Unit test for function register
def test_register():
    register()
    codecs.getdecoder(NAME)

# Generated at 2022-06-23 17:59:17.095039
# Unit test for function register
def test_register():
    """
    Tests the functionality of the function :func:`register`.
    """
    codecs.register(_get_codec_info)   # type: ignore
    try:
        codecs.getdecoder(NAME)
    except:
        assert False



# Generated at 2022-06-23 17:59:18.893110
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME) is not None
    assert codecs.getencoder(NAME) is not None



# Generated at 2022-06-23 17:59:25.252821
# Unit test for function encode
def test_encode():
    str_in = '\n\t!#$%&\'*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\x7f\u0080\u0081\u0082'
    out_bytes, _ = encode(str_in)
    assert out_bytes == b'\n\t!#$%&\'*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\\x7f\\xC2\\x80\\xC2\\x81\\xC2\\x82'


# Generated at 2022-06-23 17:59:30.356156
# Unit test for function encode
def test_encode():
    text = r'\u3231\u3232\u3233\u3234'
    expected = b'\\xE3\\x88\\xB1\\xE3\\x88\\xB2\\xE3\\x88\\xB3\\xE3\\x88\\xB4'
    out, n = encode(text)
    assert out == expected
    assert n == 4



# Generated at 2022-06-23 17:59:41.607749
# Unit test for function encode
def test_encode():
    # Test case:
    # The text contains only printable ASCII characters
    text = 'AbCdEfGhIjKlMnOpQrStUvWxYz'
    expected_output = text.encode('utf-8')
    expected_output = cast(bytes, expected_output)
    actual_output, consumed = encode(text)
    assert actual_output == expected_output
    assert consumed == len(text)

    # Test case:
    # The text contains some non-printable ASCII characters
    text = 'AbCdEfGhIjKlMn\x0AOpQrStUvWxYz'
    expected_output = text.encode('utf-8')
    expected_output = cast(bytes, expected_output)
    actual_output, consumed = encode(text)

# Generated at 2022-06-23 17:59:53.223994
# Unit test for function decode

# Generated at 2022-06-23 18:00:05.235226
# Unit test for function register
def test_register():
    from io import TextIOBase
    from io import BytesIO
    from io import UnsupportedOperation
    from io import SEEK_END

    codecs.register(_get_codec_info)  # type: ignore

    # Test that the codec is registered with proper codec info.
    codec_info = codecs.getdecoder(NAME)  # type: ignore
    assert codec_info.name == NAME

    # Test that the codec_info has the 'encode' and 'decode' attributes.
    assert hasattr(codec_info, 'encode')
    assert hasattr(codec_info, 'decode')

    # Test that the 'encode' and 'decode' attributes are callable functions.
    assert callable(codec_info.encode)
    assert callable(codec_info.decode)

    #

# Generated at 2022-06-23 18:00:09.117567
# Unit test for function encode
def test_encode():
    input_str = '\u263A'

    expected_result = b'\\xe2\\x98\\xba'

    actual_result, _ = encode(input_str)

    assert actual_result == expected_result



# Generated at 2022-06-23 18:00:17.984508
# Unit test for function encode
def test_encode():
    for test_tuple in TEST_CASES:
        test_input = test_tuple[0]
        test_output = test_tuple[1]

        test_output_bytes = bytes(test_output, encoding='utf8')
        test_output_bytes_len = len(test_output)

        print(f'Test Input: {test_input}')
        print(f'Test Output: {test_output}')

        try:
            output_bytes, output_bytes_len = encode(test_input)
        except UnicodeEncodeError as e:
            print(f'Error Type: {e}')
        else:
            print(f'Output Bytes: {output_bytes}')
            print(f'Output Bytes Length: {output_bytes_len}')
            assert output_bytes == test_output_

# Generated at 2022-06-23 18:00:19.602332
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.__dict__['_aliases'].keys()


# Generated at 2022-06-23 18:00:23.577333
# Unit test for function decode
def test_decode():
    test_data = [
        ('\\u03b1\\u03b2', 'αβ'),
        ('\\x61\\x62', 'ab'),
        ('\\u03b1\\x62', 'αb'),
    ]

    for test in test_data:
        escaped = test[0]
        not_escaped = test[1]
        escaped_bytes = escaped.encode('eutf8h')
        result = escaped_bytes.decode('eutf8h')
        assert(result == not_escaped)


# Generated at 2022-06-23 18:00:25.044462
# Unit test for function register
def test_register():
    register()
    assert NAME in codecs.__all__



# Generated at 2022-06-23 18:00:35.857010
# Unit test for function encode
def test_encode():
    assert encode('agd$%') == (b'a\\x67d$%', 5)
    assert encode('agd$') == (b'a\\x67d$', 5)
    assert encode('agd') == (b'a\\x67d', 3)
    assert encode('ag') == (b'a\\x67', 2)
    assert encode('a') == (b'a', 1)
    assert encode('') == (b'', 0)
    assert encode('\u00A1') == (b'\\xc2\\xa1', 1)
    assert encode('\u00A1!') == (b'\\xc2\\xa1!', 2)
    assert encode('\u0C9C') == (b'\\xe0\\xb2\\x9c', 1)

# Generated at 2022-06-23 18:00:47.721926
# Unit test for function decode
def test_decode():
    r"""
    Test decoding escaped utf8 hexadecimal encodings into strings.

        (1) Test decoding a string that contains characters that
            are printable in ASCII.

        (2) Test decoding a string that contains escaped utf8
            hexadecimal for a single character.

        (3) Test decoding a string that contains escaped utf8
            hexadecimal for a multi-byte character.

        (4) Test decoding a string that contains escaped utf8
            hexadecimal for a multi-byte character.
    """
    # Test 1
    test_str1 = 'abcdefg'
    test_bytes1 = test_str1.encode('eutf8h')
    out_str, out_bytes = test_bytes1.decode('eutf8h')
    assert test_str1 == out_str


# Generated at 2022-06-23 18:00:54.784500
# Unit test for function encode

# Generated at 2022-06-23 18:01:03.654664
# Unit test for function encode
def test_encode():
    """Unit test for function encode."""
    assert encode('hello world') == (
        b'hello world',
        11
    )
    assert encode('hello\\x21') == (
        b'hello!',
        9
    )
    assert encode('hello\\x21world') == (
        b'hello!world',
        13
    )
    # The following test will catch a bug where I was using
    # '\x' instead of '\\x' in the encode function.
    assert encode('hello\\\\x21world') == (
        b'hello\\x21world',
        15
    )
    assert encode('hello\\x21world\\x21') == (
        b'hello!world!',
        15
    )

# Generated at 2022-06-23 18:01:12.125057
# Unit test for function decode
def test_decode():
    assert decode(b'\\xC2\\xA1Hello') == ('¡Hello', 11)
    assert decode(b'\\x47\\x46\\x46\\x46') == ('GGGG', 8)
    assert decode(b'\\xC2\\xA1') == ('¡', 4)
    assert decode(b'\\x48\\x65\\x6c\\x6c\\x6f') == ('Hello', 10)
    assert decode(b'\\x47\\x46\\x46\\x46\\x20World') == ('GGGG World', 12)


# Unit test function encode

# Generated at 2022-06-23 18:01:14.590184
# Unit test for function register
def test_register():
    assert True


# Generated at 2022-06-23 18:01:21.301837
# Unit test for function decode
def test_decode():
    """TODO: Docstring for test_decode.

    :returns: TODO

    """
    assert decode(b'\\xC2\\xA2')[0] == '¢'
    assert decode(b'\\xC2\\n')[0] == '\u000a'
    assert decode(b'\\xC2\\xFF')[0] == 'ÿ'
    assert decode(b'\\xA0')[0] == '\xa0'



# Generated at 2022-06-23 18:01:32.869640
# Unit test for function encode
def test_encode():
    input_str = '"AB\\u007B"\\x9A'
    expected = b'\\"AB\\u007B\\"\\\\x9A'
    actual = encode(input_str)[0]
    assert actual == expected, 'Expected {} but got {}'.format(expected, actual)

    input_str = '\u9f3b'
    expected = b'\\xE9\\xBD\\xBB'
    actual = encode(input_str)[0]
    assert actual == expected, 'Expected {} but got {}'.format(expected, actual)

    input_str = '\udc04'
    expected = b'\\xED\\xB0\\x84'
    actual = encode(input_str)[0]
    assert actual == expected, 'Expected {} but got {}'.format(expected, actual)




# Generated at 2022-06-23 18:01:38.423171
# Unit test for function decode
def test_decode():
    # Check that a normal string decodes back to the same string
    result = codecs.decode("abc", 'eutf8h')
    assert result == (u"abc", 3)

    # Check that a string encoded with escape utf8 hexadecimal
    # codes is converted back to the original string
    result = codecs.decode("\\x41\\xB\\x308", 'eutf8h')
    assert result == (u"A\u0008\u0308", 15)

    # Check that a string with invalid escaped utf8 hexadecimal
    # codes will cause a UnicodeDecodeError
    err = None

# Generated at 2022-06-23 18:01:48.228008
# Unit test for function encode
def test_encode():
    out, length = encode('\\x80')
    assert out == b'\\xc2\\x80'
    assert length == 1

    out, length = encode('\\x7F')
    assert out == b'\\x7f'
    assert length == 1

    out, length = encode('\\u1234')
    assert out == b'\\xe1\\x88\\xb4'
    assert length == 1

    out, length = encode('\\U00012345')
    assert out == b'\\xf0\\x92\\x8d\\x85'
    assert length == 1

    # Invalid escaped hexadecimal
    out, length = encode('\\xT0')
    assert out == b'\\x80'
    assert length == 1

    out, length = encode('\\xT0', errors='ignore')
    assert out

# Generated at 2022-06-23 18:01:55.897227
# Unit test for function decode
def test_decode():
    assert decode('\\x41') == ('A', 2)
    assert decode('\\xc3\\xb1') == ('ñ', 4)
    assert decode('\\xe2\\x80\\xa2') == ('•', 6)
    assert decode('\\xf0\\x9f\\x8e\\x81') == ('🎁', 8)
    assert decode('\\xf4\\x8f\\xbf\\xbd') == ('\U0010ffff', 8)
    assert decode('\\xc3\\x28') == ('\x1a', 4)
    assert decode('\\xc3\\xba') == ('\x1a', 4)



# Generated at 2022-06-23 18:02:00.203312
# Unit test for function decode
def test_decode():
    # Create an example of escaped hexadecimal
    in_b = b'\\x41\\x42\\x43'

    # Decode the example into a string
    out, length = decode(in_b)

    # Ensure the output is correct
    assert out == 'ABC'

    # Ensure the length is correct
    assert length == 9

# Generated at 2022-06-23 18:02:01.331488
# Unit test for function register
def test_register():
    register()
    assert codecs.getdecoder(NAME)



# Generated at 2022-06-23 18:02:13.687116
# Unit test for function encode
def test_encode():
    # test basic
    assert encode('abcd')[0] == b'a\\x62\\x63\\x64'
    assert encode('abcd')[1] == 4

    # test empty string
    assert encode('')[0] == b''
    assert encode('')[1] == 0

    # test non-latin
    assert encode('안녕하세요')[0] == b'\\xec\\x95\\x88\\xeb\\x85\\x95\\xed\\x95\\x98\\xec\\x84\\xb8\\xec\\x9a\\x94'
    assert encode('안녕하세요')[1] == 5

# Generated at 2022-06-23 18:02:23.544096
# Unit test for function decode
def test_decode():
    """
    >>> test_decode()
    >>> test_decode() == '\\u5b57\\u4e32'
    """
    str_unicode = '\u5b57\u4e32'
    str_unicode_escaped: str = '\\u5b57\\u4e32'
    str_unicode_escaped_bytes_escape: bytes = b'\\\\u5b57\\\\u4e32'
    str_unicode_escaped_bytes_utf8: bytes = b'\\xe5\\xad\\x97\\xe4\\xb8\\xba'
    str_unicode_escaped_bytes_eutf8h: bytes = b'\\\\x5b\\\\x57\\\\x5c\\\\x5c\\\\x75\\\\x34\\\\x65\\\\x33\\\\x32'
    str

# Generated at 2022-06-23 18:02:25.295334
# Unit test for function register
def test_register():
    register()
    a = codecs.getdecoder(NAME)
    assert a is not None


# Generated at 2022-06-23 18:02:33.056224
# Unit test for function decode
def test_decode():
    # Good test cases
    assert (decode(b'\\xd3\\xab')[0] ==
            codecs.decode(b'\xd3\xab', 'utf-8', 'strict')[0])
    assert decode(b'\\xd3\\xab\\x0a')[0] == '\u05ab\n'
    assert decode(b'\\x00\\x01\\n')[0] == '\x00\x01\n'

    # Bad test cases
    try:
        decode(b'\\xd3\\xab\\x0a\\xff', 'strict')
        raise Exception('Should have raised UnicodeDecodeError')
    except UnicodeDecodeError as e:
        assert e.args[4] == 'invalid start byte'
        assert e.args[3] == 4




# Generated at 2022-06-23 18:02:42.282980
# Unit test for function encode
def test_encode():

    # Test 1 - Single character
    input_text = '\u1234'
    expected = b'\\xe1\\x88\\xb4'
    output = encode(input_text)
    assert output == (expected, 1)

    # Test 2 - Two characters
    input_text = '\u1234\u5678'
    expected = b'\\xe1\\x88\\xb4\\xe5\\x99\\xb8'
    output = encode(input_text)
    assert output == (expected, 2)

    # Test 3 - Single character that is ascii
    input_text = 'a'
    expected = b'a'
    output = encode(input_text)
    assert output == (expected, 1)

    # Test 4 - Single hex escaped character
    input_text = '\\x80'

# Generated at 2022-06-23 18:02:50.056203
# Unit test for function encode
def test_encode():
    # Test a simple case.
    assert encode('\0') == (b'\\x00', 1)

    # Test the entire range of utf8 characters
    with codecs.open('utf8_range.txt', encoding='utf8') as fp:
        utf8_range = fp.read()

    utf8_range_escaped_bytes, consumed = encode(utf8_range)
    assert consumed == len(utf8_range)

    utf8_range_escaped_str = utf8_range_escaped_bytes.decode('utf8')
    assert utf8_range_escaped_str == utf8_range

    # Test that a single bad utf8 character in the file causes an error.
    with open('utf8_range.txt', 'rb') as fp:
        utf

# Generated at 2022-06-23 18:02:59.379508
# Unit test for function encode
def test_encode():
    assert encode('abc') == (b'abc', 3)
    assert encode('☹') == (b'\\xe2\\x98\\xb9', 1)
    assert encode('\\xe2\\x98\\xb9') == (b'\\xe2\\x98\\xb9', 1)
    assert encode('\\xE2\\x98\\xB9') == (b'\\xe2\\x98\\xb9', 1)
    assert encode('\\xe2\\x98\\xb9\\xe2\\x98\\xb9') == \
        (b'\\xe2\\x98\\xb9\\xe2\\x98\\xb9', 2)

# Generated at 2022-06-23 18:03:00.552885
# Unit test for function register
def test_register():
    register()


if __name__ == '__main__':
    test_register()

# Generated at 2022-06-23 18:03:08.839002
# Unit test for function decode
def test_decode():
    codecs.register(u'eutf8h')
    # Test: decode with no errors
    text_in = br'\xE9'
    text_out = 'é'
    text_out_bytes = codecs.encode(text_out, 'eutf8h')
    text_out_bytes_in = text_out_bytes[0]
    text_out_bytes_out = text_in
    test_out = text_out_bytes_in == text_out_bytes_out
    if test_out is False:
        raise ValueError(
            f'{text_out_bytes_in!r} != {text_out_bytes_out!r}'
        )
    # Test: decode with no errors
    text_in = b'\xE9'
    text_out = 'é'
   

# Generated at 2022-06-23 18:03:14.668199
# Unit test for function encode
def test_encode():
    #   1. Test a simple string of ascii characters
    val = 'abc'
    res = encode(val)
    assert res == (b'abc', 3)

    #   2. Test a simple string of utf8 characters
    val = '\u2014'
    res = encode(val)
    assert res == (b'\\xe2\\x80\\x94', 1)

    #   3. Test a simple string of escaped utf8 characters
    val = '\\xe2\\x80\\x94'
    res = encode(val)
    assert res == (b'\\xe2\\x80\\x94', 1)

    #   4. Test an invalid escaped utf8 character
    val = '\\xfe'
    with pytest.raises(UnicodeEncodeError):
        encode(val)

   

# Generated at 2022-06-23 18:03:18.007520
# Unit test for function encode
def test_encode():
    text = 'Hello World!\n'
    # text = 'Hello World!\t\n'
    text_bytes, _ = encode(text)
    print(text_bytes)



# Generated at 2022-06-23 18:03:28.045790
# Unit test for function decode
def test_decode():
    assert decode(b'\\306\\205\\320\\275') == ('月', 6)
    assert decode(b'\\x30\\x65') == ('0e', 4)
    assert decode(b'\x30\x65') == ('0e', 4)
    assert decode(bytearray([0x30, 0x65])) == ('0e', 4)
    assert decode(bytes([0x30, 0x65])) == ('0e', 4)
    assert decode(memoryview([0x30, 0x65])) == ('0e', 4)

    assert decode(b'\\x30\\x65', 'ignore') == ('', 4)
    assert decode(b'\\x30\\x65', 'replace') == ('0�', 4)


# Generated at 2022-06-23 18:03:38.063948
# Unit test for function encode
def test_encode():
    # Test cases 1
    assert encode('\\xED') == b'\\\\xED'
    assert encode('\\xE3\\x81\\x8C') == b'\\\\xE3\\\\x81\\\\x8C'
    assert encode('\\xEF\\xBD\\x9E\\xEF\\xBC\\x9B') == b'\\\\xEF\\\\xBD\\\\x9E\\\\xEF\\\\xBC\\\\x9B'
    assert encode('\\xF0\\xA0\\x80\\x81\\xE3\\x81\\x8C') == b'\\\\xF0\\\\xA0\\\\x80\\\\x81\\\\xE3\\\\x81\\\\x8C'

# Generated at 2022-06-23 18:03:48.897775
# Unit test for function encode
def test_encode():
    assert encode(r'Hello World') == (b'Hello World', 11)
    assert encode('\u00A0') == (b'\\xc2\\xa0', 1)
    assert encode('\u20AC') == (b'\\xe2\\x82\\xac', 1)
    assert encode('\U0001F4A9') == (b'\\xf0\\x9f\\x92\\xa9', 1)
    assert encode('\\U0001F4A9') == (b'\\U0001F4A9', 1)
    assert encode(r'\U0001F4A9') == (b'\\\\U0001F4A9', 2)
    assert encode(r'\\U0001F4A9') == (b'\\\\\\U0001F4A9', 3)

# Generated at 2022-06-23 18:04:00.588086
# Unit test for function register
def test_register():
    from unittest import mock
    mock_name_codec = mock.Mock(autospec=codecs.CodecInfo)
    mock_register = mock.Mock()
    mock_getdecoder = mock.Mock(
        side_effect=[LookupError, mock_name_codec],
    )
    with mock.patch.object(
        codecs,
        'getdecoder',
        mock_getdecoder,
    ):
        with mock.patch.object(
            codecs,
            'register',
            mock_register,
        ):
            register()
            assert mock_getdecoder.call_count == 1
            assert mock_register.call_count == 1
    mock_getdecoder.assert_called_once_with(NAME)

# Generated at 2022-06-23 18:04:03.917800
# Unit test for function decode
def test_decode():
    assert decode(b'\\xED\\xA0\\xBD\\xED\\xB4\\xA2') == ('\U0001d622', 16)



# Generated at 2022-06-23 18:04:08.825724
# Unit test for function register
def test_register():
    register()
    # Assert that the codec has been registered.
    x = codecs.getdecoder(NAME)
    x = codecs.getencoder(NAME)


globals()['test_register'] = test_register

# Generated at 2022-06-23 18:04:11.153636
# Unit test for function register
def test_register():
    register()
    codecs.getencoder(NAME)
    codecs.getdecoder(NAME)
    return

# Generated at 2022-06-23 18:04:17.457045
# Unit test for function encode
def test_encode():
    s = '1234'
    expected_out_bytes = b'\\x31\\x32\\x33\\x34'
    expected_out_len = 4

    out_bytes, out_len = encode(s)

    assert out_bytes == expected_out_bytes
    assert out_len == expected_out_len



# Generated at 2022-06-23 18:04:19.048283
# Unit test for function decode
def test_decode():
    assert decode(b'\\xE5\\xA5\\xBD')[0] == '好'



# Generated at 2022-06-23 18:04:29.702196
# Unit test for function encode
def test_encode():
    in_str = '\x00\x01\x02\x03\x04\x05\x06\x07'    \
             '\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f'    \
             '\x10\x11\x12\x13\x14\x15\x16\x17'    \
             '\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f'    \
             '\x20\x21\x22\x23\x24\x25\x26\x27'    \
             '\x28\x29\x2a\x2b\x2c\x2d\x2e\x2f'

# Generated at 2022-06-23 18:04:33.843882
# Unit test for function decode
def test_decode():
    test_str = "\\xE2\\x80\\x99"
    test_bytes = test_str.encode("utf-8")
    result, length = decode(test_bytes)
    assert result == "\u2019"


# Generated at 2022-06-23 18:04:35.931084
# Unit test for function register
def test_register():
    try:
        register()
        assert codecs.lookup(NAME)
    except:
        assert False

# Generated at 2022-06-23 18:04:38.810306
# Unit test for function register
def test_register():
    try:
        codecs.getdecoder(NAME)
    except LookupError:
        register()
        assert codecs.getdecoder(NAME)

# Generated at 2022-06-23 18:04:50.953041
# Unit test for function encode
def test_encode():
    assert encode('汉语') == (b'\\xe6\\xb1\\x89\\xe8\\xaf\\xad', 4)
    assert encode('\xfc\xa1\xa1\xa1\xa1') == (b'\\xfc', 1)
    assert encode('\xfc\xa1\xa1\xa1\xa1', '') == (b'\\xfc', 1)
    assert encode(
            '\xfc\xa1\xa1\xa1\xa1', 'replace'
    ) == (b'\\xef\\xbf\\xbd', 1)  # U+FFFD
    assert encode(
            '\xfc\xa1\xa1\xa1\xa1', 'ignore'
    ) == (b'', 0)

# Generated at 2022-06-23 18:05:03.321795
# Unit test for function decode
def test_decode():
    # noinspection PyTypeChecker
    inputs_outputs = [
        # input data, errors, output, bytes consumed
        ['', 'strict', '', 0],
        ['\\x20', 'strict', ' ', 2],
        ['\\x61\\x62\\x63', 'strict', 'abc', 6],
        ['\\x61bc', 'strict', 'abc', 4],
        ['abc\\x62', 'strict', 'abc\\x62', 7],
        ['abc', 'replace', 'abc', 3],
        ['abc', 'ignore', 'abc', 3],
        ['abc', 'backslashreplace', 'abc', 3],
        ['\\x61\\x62\\x63', 'namereplace', '\\x61\\x62\\x63', 6],
    ]

# Generated at 2022-06-23 18:05:07.429149
# Unit test for function encode
def test_encode():
    assert encode('中文') == (b'\\xe4\\xb8\\xad\\xe6\\x96\\x87', 4)
    assert encode('Hello, 世界!') == (b'Hello, \\xe4\\xb8\\x96\\xe7\\x95\\x8c!', 9)
    assert encode('\u2190') == (b'\\xe2\\x86\\x90', 1)



# Generated at 2022-06-23 18:05:15.322195
# Unit test for function register
def test_register():

    # Initiate a CodecInfo.
    c = codecs.CodecInfo(
        name=NAME,
        encode=encode,  # type: ignore[arg-type]
        decode=decode  # type: ignore[arg-type]
    )

    # Register the codec.
    codecs.register(c)  # type: ignore

    # Get codec info again. If the codec doesn't exist then this will
    # raise a LookupError.
    codecs.getdecoder(NAME)


# Get the encoding name.

# Generated at 2022-06-23 18:05:25.601923
# Unit test for function decode

# Generated at 2022-06-23 18:05:36.026639
# Unit test for function encode
def test_encode():
    # test_encode_empty_string
    actual = encode(text='')
    expected = (b'', 0)
    assert actual == expected

    # test_encode_ascii_string
    actual = encode(text='hello')
    expected = (b'hello', 5)
    assert actual == expected

    # test_encode_utf8_escaped_hex_string
    actual = encode(text=r'foo\xE2\x99\xA5bar')
    expected = (b'foo\xC3\xA2\xC2\x99\xC2\xA5bar', 13)
    assert actual == expected

    # test_encode_utf8_escaped_hex_string_with_invalid_utf8_byte

# Generated at 2022-06-23 18:05:38.488823
# Unit test for function encode
def test_encode():
    text = "オ"
    actual, consumed = encode(text)
    expected = b'\\xe3\\x82\\xaa'
    assert actual == expected
    assert consumed == len(text)



# Generated at 2022-06-23 18:05:41.506411
# Unit test for function register
def test_register():
    register()
    assert codecs.getencoder(NAME)    # noqa
    assert codecs.getdecoder(NAME)    # noqa


if __name__ == '__main__':
    test_register()
    register()

# Generated at 2022-06-23 18:05:49.021391
# Unit test for function decode
def test_decode():
    x = b"\\xc3\\xbf\\xc3\\xbd\\xc3\\xbf\\xc3\\xbd"
    y = b"\\xe2\\x98\\x83"
    z = b"\\xe2\\x98\\x83\\xc3\\xbf\\xc3\\xbd\\xc3\\xbf\\xc3\\xbd"
    assert decode(x)[0] == "\xef\xbd\xbf"
    assert decode(y)[0] == "\xe2\x98\x83"
    assert decode(z)[0] == "\xe2\x98\x83\xef\xbd\xbf"
