

# Generated at 2022-06-24 04:59:59.651385
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert isinstance(settings, dict)
    for key, value in const.DEFAULT_SETTINGS.items():
        assert key in settings.keys()
        assert settings[key] == value
    assert settings.user_dir == None


# Generated at 2022-06-24 05:00:02.515776
# Unit test for constructor of class Settings
def test_Settings():
    path = Path('~/.thefuck')
    settings = Settings({'user_dir': path})
    print(settings.user_dir)

test_Settings()

# Generated at 2022-06-24 05:00:06.424856
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    S = Settings({'a': 1, 'b': 2})
    S.a = 1,
    S.b = 2
    S.c = 3
    assert S == {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-24 05:00:08.561443
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class Foo(object):
        pass
    foo = Foo()
    settings.foo = foo
    assert settings['foo'] is foo


# Generated at 2022-06-24 05:00:16.406764
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.slow_commands == ['lein']
    assert settings.require_confirmation

# Generated at 2022-06-24 05:00:18.912153
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings({"key": "value"})
    assert settings.get("key") == "value"


# Generated at 2022-06-24 05:00:23.802014
# Unit test for method init of class Settings
def test_Settings_init():
    d = {}
    d.update(const.DEFAULT_SETTINGS)
    d['user_dir'] = settings.user_dir
    d.update(settings._settings_from_file())
    d.update(settings._settings_from_env())
    assert settings == d

# Generated at 2022-06-24 05:00:26.402893
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings['debug'] is False
    assert settings['require_confirmation'] is True

# Generated at 2022-06-24 05:00:29.218974
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings['test_key'] = 'test_val'
    assert settings.test_key == 'test_val'


# Generated at 2022-06-24 05:00:34.794196
# Unit test for constructor of class Settings
def test_Settings():
    const.DEFAULT_SETTINGS['test'] = 10
    const.ENV_TO_ATTR['TEST'] = 'test'
    os.environ['TEST'] = '20'
    local_settings = dict(const.DEFAULT_SETTINGS)
    s = Settings(local_settings)
    s.init()
    assert s['test'] == 20
    assert s.test == 20


# Generated at 2022-06-24 05:00:38.919140
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    s.key = 'val'
    assert s['key'] == 'val'


# Generated at 2022-06-24 05:00:41.676982
# Unit test for constructor of class Settings
def test_Settings():
    assert 'rules' in settings
    assert 'alter_history' in settings
    assert 'wait_command' in settings



# Generated at 2022-06-24 05:00:51.183288
# Unit test for method init of class Settings
def test_Settings_init():
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'false'
    os.environ['THEFUCK_RULES'] = 'bash:python:cd:system'
    os.environ['THEFUCK_PRIORITY'] = 'bash=1:python=2:cd=3:system=4'
    os.environ['THEFUCK_EXCLUDE_RULES'] = 'system'
    os.environ['THEFUCK_WAIT_COMMAND'] = '5'
    os.environ['THEFUCK_HISTORY_LIMIT'] = '6'
    os.environ['THEFUCK_WAIT_SLOW_COMMAND'] = '7'
    os.environ['THEFUCK_SLOW_COMMANDS'] = 'git:python'
   

# Generated at 2022-06-24 05:00:55.955300
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings1 = Settings()
    settings1.key = 'value'
    assert settings1['key'] == 'value'



# Generated at 2022-06-24 05:01:01.073399
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.new_attr = "A new attr"
    assert settings["new_attr"] == "A new attr"
    assert settings.new_attr == "A new attr"


# Generated at 2022-06-24 05:01:10.285210
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from .logs import logging
    from .utils import memoize

    @memoize
    def rule():
        return lambda *args, **kwargs: 0

    test_settings = Settings(const.DEFAULT_SETTINGS)

    test_settings.example_setting = 'New settings value'
    assert test_settings['example_setting'] == 'New settings value'

    test_settings.log = logging.getLogger()
    assert test_settings['log'] == logging.getLogger()

    test_settings.require_confirmation = False
    assert not test_settings['require_confirmation']
    assert 'require_confirmation' in test_settings

    test_settings.rules = [rule, rule]
    assert len(test_settings['rules']) == 2

    test_settings.priority = {'rule': 0}

# Generated at 2022-06-24 05:01:13.217836
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    # Should return None if not exist
    assert settings.not_exist is None
    # Should return value if exists
    settings.test_value = "12"
    assert settings.test_value == "12"

# Generated at 2022-06-24 05:01:17.201947
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.init(None)
    assert settings.history_limit == 10
    assert settings.env == {'LANG': 'en_US.UTF-8', 'LC_ALL': 'en_US.UTF-8'}
    assert settings.require_confirmation == True


# Generated at 2022-06-24 05:01:25.374914
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from unittest import mock
    from tempfile import mkdtemp
    from shutil import rmtree

    def check_settings(settings, loaded_from_file=None, loaded_from_env=None,
                       loaded_from_args=None):
        assert settings.user_dir.endswith('/.config/thefuck')
        for setting in loaded_from_file.items():
            assert settings[setting[0]] == setting[1]
        for setting, env in const.ENV_TO_ATTR.items():
            if setting in loaded_from_env:
                assert settings[env] == loaded_from_env[setting]
        for setting in loaded_from_args.items():
            assert settings[setting[0]] == setting[1]


# Generated at 2022-06-24 05:01:27.436571
# Unit test for constructor of class Settings
def test_Settings():
    assert Settings(const.DEFAULT_SETTINGS)


# Generated at 2022-06-24 05:01:29.060490
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.__setattr__('require_confirmation', not settings.require_confirmation)
    assert not settings.require_confirmation


# Generated at 2022-06-24 05:01:35.906891
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.user_dir is not None
    assert settings.alter_history is True
    assert settings.num_close_matches == 3
    assert settings.wait_slow_command == 3
    assert settings.wait_command == 1
    assert settings.require_confirmation is True
    assert settings.no_colors is False
    assert settings.priority == {}
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == 100
    assert settings.instant_mode is False
    assert settings.slow_commands == ['(git|hg|bzr)']
    assert settings.debug is False
    assert settings.repeat is 1
    assert settings.rules == []
    assert settings.env == {}

# Generated at 2022-06-24 05:01:37.559340
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings()
    settings.name = 'Alice'
    assert settings.name == 'Alice'
    assert settings['name'] == 'Alice'


# Generated at 2022-06-24 05:01:44.211748
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.default_to == 'python'
    assert settings.require_confirmation == True
    assert settings.wait_command == 0
    assert settings.exclude_rules == []
    assert settings.no_colors == False
    assert settings.rules == const.DEFAULT_RULES
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'rebuild', 'sbt']
    assert settings.priority == {}
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.alter_history == False
    assert settings.debug == False
    assert settings.num_close_matches == 3
    assert settings.instant_mode == False
    assert settings.excluded_search_path_prefixes == []
    assert settings.repeat == 1 and not settings

# Generated at 2022-06-24 05:01:49.360530
# Unit test for method init of class Settings
def test_Settings_init():
    class Args(object):
        def __init__(self):
            self.yes = True
            self.debug = True

    settings.init(Args())
    assert not settings.require_confirmation
    assert settings.debug

# Generated at 2022-06-24 05:01:52.079680
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from fcntl import fcntl, F_SETSIG, F_GETSIG
    import signal
    assert settings.__setattr__('foo', 'bar')
    assert settings['foo'] == 'bar'


# Generated at 2022-06-24 05:01:53.703818
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.key = 'value'
    assert settings['key'] == 'value'


# Generated at 2022-06-24 05:01:57.061438
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test_attr = True
    assert settings['test_attr']

# Generated at 2022-06-24 05:02:03.860026
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import LOGS_HANDLER

    if os.name == 'nt':
        settings._get_user_dir_path = lambda: None
        settings.user_dir = None

    settings.init()
    assert len(LOGS_HANDLER.records) == 0, u'Unexpected error: {}'.format(
        LOGS_HANDLER.records[0].message)
    assert settings.user_dir, u'No user configuration directory'


settings.init()

# Generated at 2022-06-24 05:02:10.757847
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir is not None
    assert settings.require_confirmation is True
    assert settings.rules is not None
    assert settings.exclude_rules is not None
    assert settings.wait_command is 2
    assert settings.no_colors is False
    assert settings.priority == {}
    assert settings.alter_history is True
    assert settings.instant_mode is False


# Generated at 2022-06-24 05:02:17.876325
# Unit test for constructor of class Settings
def test_Settings():
    tmp_user_dir = Path('./.thefuck')
    tmp_user_dir.mkdir(parents=True)
    with tmp_user_dir.joinpath('settings.py').open(mode='w') as settings_file:
        settings_file.write(u'rules = [\'test rules\', \'DEFAULT_RULES\']')

# Generated at 2022-06-24 05:02:19.700682
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.no_colors == const.DEFAULT_SETTINGS['no_colors']



# Generated at 2022-06-24 05:02:21.879003
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.keys() != const.DEFAULT_SETTINGS

# Generated at 2022-06-24 05:02:23.627059
# Unit test for constructor of class Settings
def test_Settings():
    if settings.require_confirmation and settings.alter_history:
        assert True
    else:
        assert False


# Generated at 2022-06-24 05:02:32.484222
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import _exceptions, exception

    settings.init()

    assert 'require_confirmation' in settings
    assert 'debug' in settings
    assert 'repeat' in settings

    assert settings.require_confirmation == True
    assert settings.debug == False
    assert settings.repeat == 1
    assert settings.user_dir == Path('.thefuck').expanduser()

    args = MockArgs(yes=True, debug=True, repeat=2)
    settings.init(args)

    assert settings.require_confirmation == False
    assert settings.debug == True
    assert settings.repeat == 2
    assert settings.user_dir == Path('.thefuck').expanduser()

    # Should only one exception be had
    exception('Exception 1')
    exception('Exception 2')

    assert len(_exceptions) == 2


#

# Generated at 2022-06-24 05:02:34.976717
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.asdf = 'ghjk'
    assert settings.asdf == 'ghjk'
    assert settings['asdf'] == 'ghjk'


# Generated at 2022-06-24 05:02:37.682624
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.total_win = 'total_win'
    assert settings['total_win'] == settings.total_win


# Generated at 2022-06-24 05:02:44.989544
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import capture_logs

    settings['require_confirmation'] = True
    settings['wait_slow_command'] = -1
    settings['rules'] = []
    settings['exclude_rules'] = []
    settings['priority'] = {}
    settings['slow_commands'] = []
    settings['excluded_search_path_prefixes'] = []

    with capture_logs() as logs:
        settings.init()

    assert len(logs) == 2
    assert 'settings from file' in logs[0]
    assert 'settings from env' in logs[1]
    assert settings['require_confirmation'] == False
    assert settings['wait_slow_command'] == 0
    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['exclude_rules'] == []

# Generated at 2022-06-24 05:02:46.080883
# Unit test for constructor of class Settings
def test_Settings():
    assert settings._get_user_dir_path() == '~/.config/thefuck'

# Generated at 2022-06-24 05:02:56.000247
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, dict)
    assert len(const.DEFAULT_SETTINGS) == len(settings)
    assert settings.user_dir == Path(os.path.expanduser("~/.thefuck")).expanduser()
    assert settings.require_confirmation is True
    assert settings.wait_command == 0
    assert settings.history_limit == None

# Generated at 2022-06-24 05:02:57.141040
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.a = 'b'
    assert settings['a'] == 'b'



# Generated at 2022-06-24 05:03:00.805301
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    s = Settings()
    assert s._something == None


# Generated at 2022-06-24 05:03:04.311412
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    methods = [method for method in dir(settings)
               if callable(getattr(settings, method))]
    attributes = list(const.DEFAULT_SETTINGS.keys())
    assert all(
        attr in methods or attr in attributes
        for attr in settings)


# Generated at 2022-06-24 05:03:05.762078
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.test_value = 5
    assert settings['test_value'] == 5

# Generated at 2022-06-24 05:03:13.046891
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

    # Check settings from file
    from . import settings as _settings
    assert 'require_confirmation' in settings, 'Setting require_confirmation does not exist'
    assert settings['require_confirmation'] == _settings.require_confirmation, \
        'Setting require_confirmation is not correct'
    assert 'rules' in settings, 'Setting rules does not exist'
    assert type(settings['rules']) == list, 'Setting rules is not a list'
    assert len(settings['rules']) == len(const.DEFAULT_RULES), 'Setting rules is not correct'
    assert 'exclude_rules' in settings, 'Setting exclude_rules does not exist'
    assert type(settings['exclude_rules']) == list, 'Setting exclude_rules is not a list'

# Generated at 2022-06-24 05:03:15.686712
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.user_dir = 1
    assert settings.user_dir == 1


# Generated at 2022-06-24 05:03:26.017920
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import shutil
    from tempfile import gettempdir
    from mock import patch

    temp_dir = Path(gettempdir()).joinpath('thefuck')
    temp_dir.mkdir(exist_ok=True)
    rules_dir = temp_dir.joinpath('rules')
    rules_dir.mkdir(exist_ok=True)


# Generated at 2022-06-24 05:03:27.603607
# Unit test for constructor of class Settings
def test_Settings():
    from imp import reload
    from . import settings

    reload(settings)
    assert settings == const.DEFAULT_SETTINGS

# Generated at 2022-06-24 05:03:29.011620
# Unit test for constructor of class Settings
def test_Settings():
    assert settings == const.DEFAULT_SETTINGS



# Generated at 2022-06-24 05:03:39.677867
# Unit test for method init of class Settings
def test_Settings_init():
    """Lets run it from the tests to load it from
        thefuck.tests.settings.py. The real settings will be overwritten."""

    import thefuck.tests.settings as test_settings

    test_settings.settings = Settings(const.DEFAULT_SETTINGS)
    test_settings.settings.init()
    assert test_settings.settings._settings_from_env() == {
        'rules': ['fuck_you'],
        'priority': {'fuck_you': 456}
    }

    test_settings.settings = Settings(const.DEFAULT_SETTINGS)
    test_settings.settings.init()

# Generated at 2022-06-24 05:03:44.712497
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    new_settings = Settings({'require_confirmation': True})
    new_settings.new_setting = 'value'
    assert new_settings['new_setting'] == 'value'


# Generated at 2022-06-24 05:03:46.244803
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    new_settings = Settings(const.DEFAULT_SETTINGS)
    new_settings.__setattr__('a', True)
    new_settings.__setattr__('b', 3)
    assert new_settings == {'a': True, 'b': 3}


# Generated at 2022-06-24 05:03:53.524331
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == True
    assert settings.require_confirmation is not None
    assert settings.require_confirmation is not None
    assert settings.get('require_confirmation') is not None
    assert settings.require_confirmation == settings.get('require_confirmation')
    assert settings.require_confirmation == settings.__getattr__('require_confirmation')


# Generated at 2022-06-24 05:03:57.945994
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    """Unit test for `Settings.__setattr__()`"""
    settings = Settings()
    settings.test = 'a'
    assert settings['test'] == 'a'
    settings['test'] = 'b'
    assert settings['test'] == 'b'

# Generated at 2022-06-24 05:03:59.781564
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    _settings = Settings()
    _settings.foo = 'bar'
    assert _settings['foo'] == 'bar'

# Generated at 2022-06-24 05:04:03.973453
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings({'a': '1', 'b': '2'})
    assert s.a == '1'
    assert s.b == '2'


# Generated at 2022-06-24 05:04:07.955069
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.foo = 'bar'
    assert settings['foo'] == 'bar'


# Generated at 2022-06-24 05:04:09.454929
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.__setattr__('test', 1)
    assert settings['test'] == 1


# Generated at 2022-06-24 05:04:15.266459
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import capture_log
    args = object()
    settings.init(args=args)
    _, logs = capture_log(settings.init, args=args)
    assert 'Can\'t load settings from file' in logs
    assert 'Can\'t load settings from env' in logs

# Generated at 2022-06-24 05:04:17.587774
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.log_file = 'test_log_file'
    assert settings['log_file'] == 'test_log_file'


# Generated at 2022-06-24 05:04:22.727388
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    test_settings.hello = 'world'
    assert test_settings.hello == 'world'
    assert test_settings['hello'] == 'world'

# Generated at 2022-06-24 05:04:25.928495
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .logs import reset_exceptions_storage

    reset_exceptions_storage()
    exception.tracebacks = []
    settings.init()

    assert len(exception.tracebacks) == 0
    assert isinstance(settings, dict)
    assert isinstance(settings, Settings)



# Generated at 2022-06-24 05:04:27.549705
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation is True
    assert settings.rules == const.DEFAULT_RULES



# Generated at 2022-06-24 05:04:32.192709
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test_Settings___setattr__ = True
    assert settings.get('test_Settings___setattr__')


# Generated at 2022-06-24 05:04:34.098086
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    test_settings = Settings({'test_attr': 'test_value'})
    assert test_settings.test_attr is 'test_value'



# Generated at 2022-06-24 05:04:36.056927
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    # Given
    settings['test'] = 'test'

    # When
    result = settings.test

    # Then
    assert result == 'test'



# Generated at 2022-06-24 05:04:45.725703
# Unit test for method init of class Settings
def test_Settings_init():
    """Unit-test for method init of class Settings."""
    from .tests.utils import Mock, patch
    from .logs import exception

    args = Mock()

    settings = Settings(const.DEFAULT_SETTINGS)

# Generated at 2022-06-24 05:04:55.612291
# Unit test for method init of class Settings
def test_Settings_init():
    def dict_settings(settings):
        return dict(settings)

    class FakeUserDir():
        def joinpath(self, x):
            return '/wrong/path'

    class EnvVar(object):
        def __init__(self, name, value):
            self.name = name
            self.value = value

        def __enter__(self, *args):
            os.environ[self.name] = self.value

        def __exit__(self, *args):
            os.environ.pop(self.name)

    class FakeSettings(object):
        wait_command = 10
        require_confirmation = False
        no_colors = True
        rules = ['DEFAULT_RULES']
        exclude_rules = ['DEFAULT_RULES']
        priority = {'mv': 50}
        alter

# Generated at 2022-06-24 05:04:56.422882
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()



# Generated at 2022-06-24 05:04:57.962770
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # Given
    settings = Settings()
    # When
    settings.key = 'value'
    # Then
    assert settings['key'] == 'value'

# Generated at 2022-06-24 05:05:02.324969
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']



# Generated at 2022-06-24 05:05:07.392657
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    fake_settings = Settings({'a': 1})
    assert fake_settings.a == 1
    assert fake_settings.get('a') == 1



# Generated at 2022-06-24 05:05:16.602701
# Unit test for method init of class Settings
def test_Settings_init():
    # Create settings files
    const.SETTINGS_FILE = Path('/settings.py')
    const.SETTINGS_FILE.unlink(missing_ok=True)
    with const.SETTINGS_FILE.open(mode='w') as settings_file:
        settings_file.write(const.SETTINGS_HEADER)
        for setting in const.DEFAULT_SETTINGS.items():
            settings_file.write('# {} = {}\n'.format(*setting))

    # Create env
    from contextlib import contextmanager
    import os
    @contextmanager
    def set_env(**env_vars):
        old_env = dict(os.environ)
        os.environ.update(env_vars)
        try:
            yield
        finally:
            os.environ.clear()
           

# Generated at 2022-06-24 05:05:18.060114
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.test_value = 'test'
    assert settings.test_value == 'test'


# Generated at 2022-06-24 05:05:26.991184
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    import shutil
    import sys
    import os
    from .logs import exception

    # create mock_settings.py
    backup_syspath = sys.path

# Generated at 2022-06-24 05:05:33.117160
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['require_confirmation'] == True
    assert settings['history_limit'] == 10
    assert settings['rules'] == ['git_push', 'git_add', 'git_commit', 'pip']
    assert settings['exclude_rules'] == []
    assert settings['slow_commands'] == ['lein', 'gradle', 'mvn']
    assert settings['no_colors'] == False

# Generated at 2022-06-24 05:05:34.035942
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.python


# Generated at 2022-06-24 05:05:36.586467
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('require_confirmation') is True
    assert settings.get('repeat') == 3
    assert settings.get('alter_history') is False
    assert settings.get('rules') is const.DEFAULT_RULES
    assert settings.get('priority') == {}

# Generated at 2022-06-24 05:05:41.542814
# Unit test for method init of class Settings
def test_Settings_init():
    def get_settings():
        return {key: getattr(settings, key)
                for key in const.DEFAULT_SETTINGS.keys()}

    assert settings.init() == get_settings()
    assert settings.init(args=object) == get_settings()
    assert settings.init(args=type('Args', (object,), {'yes': True})) != get_settings()

# Generated at 2022-06-24 05:05:48.748961
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert not settings.no_colors
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.alter_history
    assert settings.wait_command == 0
    assert settings.wait_slow_command == 1
    assert settings.history_limit == 0
    assert settings.num_close_matches == 3
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == ['/usr/', '/usr/local/']
    assert not settings.require_slow_command
    assert settings.confirm_exit
    assert settings.repeat == 1
    assert not settings.instant_mode


# Generated at 2022-06-24 05:05:50.791790
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    test_Settings = Settings()
    test_Settings.name = 'value'
    assert test_Settings.name == 'value'


# Generated at 2022-06-24 05:06:01.450638
# Unit test for method init of class Settings
def test_Settings_init():
    # When we use new config resource '~/.config/thefuck'.
    settings._get_user_dir_path = lambda: Path('~/.config/thefuck')
    assert settings.init()

    # When we load settings from config file '~/.config/thefuck/settings.py'.
    settings._settings_from_file = lambda: {'sudo': 'True'}
    settings.init()
    assert settings['sudo'] == 'True'

    # When we load settings from env variable.
    os.environ['THEFUCK_SUDO'] = 'True'
    settings.init()
    assert settings['sudo'] == 'True'

    # When we combine settings from config file, env variable, and args.
    os.environ['THEFUCK_SUDO'] = 'True'

# Generated at 2022-06-24 05:06:06.166587
# Unit test for constructor of class Settings
def test_Settings():
    class AttrDict(object):
        pass
    arg = AttrDict()
    arg.yes = True
    arg.debug = True

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init(arg)

    assert settings['debug']
    assert not settings['require_confirmation']

    assert not settings['repeat']

# Generated at 2022-06-24 05:06:15.572353
# Unit test for constructor of class Settings
def test_Settings():
    # pylint: disable=protected-access
    assert settings._get_user_dir_path() == Path('~/.config/thefuck').expanduser()
    assert settings._settings_from_args({}) == {}
    assert settings._settings_from_args(Namespace(yes=True)) == {'require_confirmation': False}
    assert settings._settings_from_args(Namespace(no_colors=True)) == {}
    assert settings._settings_from_args(Namespace(debug=True)) == {'debug': True}
    assert settings._settings_from_args(Namespace(debug=False)) == {'debug': False}
    assert settings._settings_from_args(Namespace(repeat=5)) == {'repeat': 5}
    assert settings._settings_from_env() == {}
    assert settings._settings_from

# Generated at 2022-06-24 05:06:20.572518
# Unit test for method init of class Settings
def test_Settings_init():
    import argparse

    user_dir = Path('/')
    settings.user_dir = user_dir
    settings.init(args=None)

    assert const.DEFAULT_SETTINGS == settings
    assert user_dir.joinpath('rules').is_dir()

    user_dir = Path('/')
    settings.user_dir = user_dir
    args = argparse.Namespace(yes=None, debug=True, repeat=None)
    settings.init(args)

    assert const.DEFAULT_SETTINGS == settings
    assert user_dir.joinpath('rules').is_dir()

# Generated at 2022-06-24 05:06:25.225274
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('wait_command') == 1
    assert settings.get('wait_slow_command') == 3
    assert settings.get('history_limit') == 10
    assert settings.get('num_close_matches') == 3
    assert settings.get('alter_history') == True
    assert settings.get('instant_mode') == False
    assert settings.get('wait_command') == 1
    assert settings.get('require_confirmation') == True


# Generated at 2022-06-24 05:06:35.452823
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.require_confirmation == True
    assert settings.history_limit == None
    assert settings.rules == []
    assert settings.priority == {}
    assert settings.no_colors == False
    assert settings.wait_command == 0
    assert settings.wait_slow_command == 0
    assert settings.alter_history == False
    assert settings.repeat == False
    assert settings.slow_commands == []
    assert settings.instant_mode == False
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.debug == False
    assert settings.num_close_matches == 3
    

# Generated at 2022-06-24 05:06:37.915938
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    for key, value in const.DEFAULT_SETTINGS.items():
        assert value == settings[key]
        assert value == settings.get(key)
        assert value == getattr(settings, key)



# Generated at 2022-06-24 05:06:45.277042
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['rules'] == ['git_push', 'git_stash_and_pull', 'apt_get_install', 'pip_install', 'sudo']
    assert settings['slow_commands'] == const.SLOW_COMMANDS
    assert settings['exclude_rules'] == []
    assert settings['require_confirmation'] == True
    assert settings['alter_history'] == False
    assert settings['no_colors'] == False
    assert settings['instant_mode'] == False
    assert settings['wait_command'] == 2
    assert settings['wait_slow_command'] == 15
    assert settings['priority'] == {}
    assert settings['python3'] == False
    assert settings['history_limit'] == 10
    assert settings['excluded_search_path_prefixes'] == []
    assert settings['num_close_matches']

# Generated at 2022-06-24 05:06:56.688331
# Unit test for method init of class Settings
def test_Settings_init():
    args = type('FakeArgs', (object,),
                {'yes': True, 'debug': True, 'repeat': 1})()
    settings.update({'require_confirmation': True,
                     'debug': False,
                     'repeat': None})

# Generated at 2022-06-24 05:06:58.871320
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    """
    This test tests method `__setattr__` of class `Settings`.
    """

    a = Settings()
    a.test = 100
    assert a.test == 100



# Generated at 2022-06-24 05:07:04.097466
# Unit test for method init of class Settings
def test_Settings_init():
    class Args():
        yes = False
        debug = False
        repeat = False

    args1 = Args()
    assert settings.init(args1) == const.DEFAULT_SETTINGS
    args2 = Args()
    args2.yes = True
    assert settings.init(args2) == const.DEFAULT_SETTINGS
    args3 = Args()
    args3.debug = True
    assert settings.init(args3) == const.DEFAULT_SETTINGS
    args4 = Args()
    args4.repeat = True
    assert settings.init(args4) == const.DEFAULT_SETTINGS

# Generated at 2022-06-24 05:07:06.468402
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    s.a = 1
    assert s['a'] == 1



# Generated at 2022-06-24 05:07:07.941653
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.test_var = 'foo'
    assert settings.test_var == 'foo'


# Generated at 2022-06-24 05:07:10.197923
# Unit test for method init of class Settings
def test_Settings_init():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    test_settings.init()
    assert isinstance(test_settings, Settings)



# Generated at 2022-06-24 05:07:11.680857
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.foo = 123
    assert settings['foo'] == 123


# Generated at 2022-06-24 05:07:23.461218
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .logs import set_log
    from mock import patch
    from os import environ
    from os import linesep
    from StringIO import StringIO

    def exception_handler(*args, **kwargs):
        _, _, traceback_obj = args
        raise Exception(traceback_obj)

    with patch('os.environ', {'THEFUCK_CONFIRM': 'true', 'THEFUCK_DEBUG': 'true',
                              'THEFUCK_REPEAT': '5',
                              'THEFUCK_RULES': 'default:',
                              'THEFUCK_NO_COLOR': 'true',
                              'THEFUCK_PRIORITY': 'default=10:ls=5:another=15'}):
        settings_path = settings.user_dir.join

# Generated at 2022-06-24 05:07:27.998734
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings({})
    assert s['key'] == None

    s.key = 'value'
    assert s.key == 'value'



# Generated at 2022-06-24 05:07:29.713504
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings_copy = settings
    settings_copy.test = 'Test'
    assert settings.test == 'Test'


# Generated at 2022-06-24 05:07:38.950914
# Unit test for method init of class Settings
def test_Settings_init():
    """Unit test for method init of class Settings"""
    def _get_user_dir_path(self):
        return "~/.config/thefuck"
    settings.init()
    assert settings.user_dir == os.path.expanduser(_get_user_dir_path(settings))
    assert settings.require_confirmation == True
    assert settings.wait_command == 1
    assert settings.slow_commands == ["lein", ". /etc/profile"]
    assert settings.no_colors == False
    assert settings.priority == {"sudo": 100, "brew": 99}
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == ['/usr']
    assert settings.debug == False

#

# Generated at 2022-06-24 05:07:42.230213
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    s = Settings({'some_attr': 1})

    assert s.some_attr == 1
    assert s.__getattr__('some_attr') == 1



# Generated at 2022-06-24 05:07:45.496562
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    # When `settings` does not have attribute
    # Then raised AttributeError
    try:
        settings.test
        raise
    except AttributeError:
        pass
    # When `settings` has attribute
    # Then __getattr__ returns correct value
    settings.test = True
    assert settings.test == True

# Generated at 2022-06-24 05:07:46.702444
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = 10
    assert settings.test == 10

# Generated at 2022-06-24 05:07:48.233758
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.wait_slow_command == 3



# Generated at 2022-06-24 05:07:57.188490
# Unit test for method init of class Settings
def test_Settings_init():
    with tempfile.TemporaryDirectory() as temp_dir:
        settings = Settings({'user_dir': temp_dir})
        with open(settings.user_dir + 'settings.py', 'w') as settings_file:
            settings_file.write(const.SETTINGS_HEADER)
            for setting in const.DEFAULT_SETTINGS.items():
                settings_file.write('# {} = {}\n'.format(*setting))
        with open(settings.user_dir + 'settings.py', 'a') as settings_file:
            settings_file.write('wait_slow_command = 9')
        settings.init()
        assert(settings['wait_slow_command'] == 9)
        os.environ['THEFUCK_WAIT_SLOW_COMMAND'] = '7'
        settings.init()
       

# Generated at 2022-06-24 05:08:06.387369
# Unit test for method init of class Settings
def test_Settings_init():
    def _get_user_dir_path(self):
        return 'test_path'

    from .logs import exception
    from .system import Path
    from . import const

    setattr(Settings, '_get_user_dir_path', _get_user_dir_path)

    settings_file_content = const.SETTINGS_HEADER
    for setting in const.DEFAULT_SETTINGS.items():
        settings_file_content += u'# {} = {}\n'.format(*setting)

    # Test `init` with empty settings.py
    with settings['user_dir'].joinpath('settings.py').open(mode='w') as settings_file:
        settings_file.write(settings_file_content)

    # Test `init` with existing settings.py

# Generated at 2022-06-24 05:08:14.013548
# Unit test for constructor of class Settings
def test_Settings():
    env = dict()
    init_str = "".join(const.SETTINGS_HEADER.split())
    for key, value in const.DEFAULT_SETTINGS.items():
        if type(value) is list:
            env[key] = ':'.join(value)
        elif type(value) is dict:
            env[key] = ':'.join(['{}={}'.format(k,v) for k,v in value.items()])
        else:
            env[key] = str(value)
        init_str += '{} = {}\n'.format(key, env[key])

    user_dir = Path('test')
    user_dir.joinpath('settings.py').write_text(init_str)

    settings.update({'user_dir':user_dir})
    settings

# Generated at 2022-06-24 05:08:15.129520
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.slow_commands


# Generated at 2022-06-24 05:08:17.676228
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['require_confirmation'] is True
    assert settings.require_confirmation is True
    settings.require_confirmation = False
    assert settings.require_confirmation is False

# Generated at 2022-06-24 05:08:18.455117
# Unit test for method init of class Settings
def test_Settings_init():
    #todo: add test
    pass

# Generated at 2022-06-24 05:08:21.960729
# Unit test for constructor of class Settings
def test_Settings():
    settings.init()
    assert settings['debug'] == False
    assert settings['require_confirmation'] == True
    assert settings['wait_command'] == 1
    assert settings['slow_commands'] == ['lein', 'gradle']
    settings.update({'require_confirmation': False})
    assert settings['require_confirmation'] == False
    settings.clear()
    assert settings['debug'] == False
    assert settings['require_confirmation'] == True
    assert settings['wait_command'] == 1
    assert settings['slow_commands'] == ['lein', 'gradle']
    settings.update({'require_confirmation': False})
    assert settings['require_confirmation'] == False


# Generated at 2022-06-24 05:08:28.725010
# Unit test for method init of class Settings
def test_Settings_init():
    import settings
    import const

    # Test if the "exclude_rules" should be added to settings when excluded_search_path_prefixes was set in settings.py
    excluded_search_path_prefixes = ['/usr/bin/']
    with _mock_settings({'excluded_search_path_prefixes': excluded_search_path_prefixes}):
        settings.init()
        assert settings['exclude_rules'] == const.DEFAULT_RULES + excluded_search_path_prefixes


# Generated at 2022-06-24 05:08:37.800242
# Unit test for method init of class Settings
def test_Settings_init():
    args = None
    settings.init(args)

    assert settings['require_confirmation'] == True
    assert callable(settings['history_limit']) == False
    assert settings['history_limit'] >= 0
    assert settings['alter_history'] == True
    assert settings['instant_mode'] == False
    assert settings['wait_command'] >= 0
    assert settings['wait_slow_command'] >= 0
    assert settings['slow_commands'] >= 0
    assert settings['exclude_rules'] >= 0
    assert settings['priority'] >= 0
    assert settings['user_dir'] >= 0
    assert settings['log_file'] >= 0
    assert settings['no_colors'] >= 0
    assert settings['num_close_matches'] >= 0


# Generated at 2022-06-24 05:08:43.560417
# Unit test for method init of class Settings
def test_Settings_init():
    # Default settings
    settings.init()
    assert settings.binary_name == const.DEFAULT_SETTINGS['binary_name']
    assert settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']
    assert settings.timeout == const.DEFAULT_SETTINGS['timeout']
    assert settings.max_lines == const.DEFAULT_SETTINGS['max_lines']
    assert settings.alter_history == const.DEFAULT_SETTINGS['alter_history']
    assert settings.no_colors == const.DEFAULT_SETTINGS['no_colors']
    assert settings.debug == const.DEFAULT_SETTINGS['debug']
    assert settings.wait_command == const.DEFAULT_SETTINGS['wait_command']
    assert settings.slow_commands == const.DEFAULT_SETT

# Generated at 2022-06-24 05:08:46.158417
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['require_confirmation'] == True
    assert settings['wait_command'] == 1

# Generated at 2022-06-24 05:08:51.084696
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class Settings(dict):
        def __getattr__(self, item):
            return self.get(item)

        def __setattr__(self, key, value):
            self[key] = value

    test = Settings()
    test.name = 'test'
    assert test['name'] == 'test'
    assert test.name == 'test'



# Generated at 2022-06-24 05:08:58.051242
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.require_confirmation
    assert settings.rules == const.DEFAULT_RULES
    assert settings.priority == const.DEFAULT_PRIORITY
    assert settings.history_limit == 0
    assert settings.wait_command == 0
    assert settings.wait_slow_command == 15
    assert settings.alter_history == False
    assert settings.instant_mode == False
    assert settings.num_close_matches == 3
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == ['sudo']

# Generated at 2022-06-24 05:09:00.267894
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.command_not_found is None
    assert settings.require_confirmation is True


# Generated at 2022-06-24 05:09:01.271198
# Unit test for constructor of class Settings
def test_Settings():
    assert settings == const.DEFAULT_SETTINGS

# Generated at 2022-06-24 05:09:02.428389
# Unit test for constructor of class Settings
def test_Settings():
    for key in settings.keys():
        assert key in const.DEFAULT_SETTINGS.keys()


# Generated at 2022-06-24 05:09:06.256686
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == False
    assert settings.rules == const.DEFAULT_RULES

# Generated at 2022-06-24 05:09:07.802080
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.test_Settings___getattr___test = 1
    assert settings.test_Settings___getattr___test == 1

# Generated at 2022-06-24 05:09:14.654934
# Unit test for constructor of class Settings
def test_Settings():
    settings.init()
    settings_path = settings.user_dir.joinpath('settings.py')
    with settings_path.open('r') as f:
        assert f.read() == const.SETTINGS_HEADER
    os.environ['XDG_CONFIG_HOME'] = '/home/somebody/.config'
    settings.init()
    settings_path = settings.user_dir.joinpath('settings.py')
    with settings_path.open('r') as f:
        assert f.read() == const.SETTINGS_HEADER
    os.environ['XDG_CONFIG_HOME'] = ''
    settings.init()
    settings_path = settings.user_dir.joinpath('settings.py')

# Generated at 2022-06-24 05:09:19.704818
# Unit test for constructor of class Settings
def test_Settings():
    from thefuck.const import ENV_TO_ATTR, DEFAULT_SETTINGS
    assert (Settings() == DEFAULT_SETTINGS)
    assert (Settings.__getattr__(Settings(), "wait_command") == 3)

# Generated at 2022-06-24 05:09:23.622682
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.instant_mode == False
    assert settings.require_confirmation == True

    os.environ['THEFUCK_INSTANT_MODE'] = 'True'
    settings.init()
    assert settings.instant_mode == True
    del os.environ['THEFUCK_INSTANT_MODE']


# Generated at 2022-06-24 05:09:24.718505
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.a = 1
    assert settings['a'] == 1


# Generated at 2022-06-24 05:09:26.506065
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    Settings.__setattr__('var', 'A')
    assert Settings.get('var') == 'A'
    assert Settings.var == 'A'



# Generated at 2022-06-24 05:09:28.480092
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)
    assert settings.get('require_confirmation') is False
    assert settings.get('rules') is ['git_push', 'git_add', 'git_commit']


# Generated at 2022-06-24 05:09:31.674927
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings['rules'] == const.DEFAULT_RULES



# Generated at 2022-06-24 05:09:33.367063
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.__setattr__('key', 'value') == {'key': 'value'}


# Generated at 2022-06-24 05:09:38.367474
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    class cls(Settings):
        def __init__(self):
            self.update({'test_value': 'test_value'})
    tcls = cls()
    assert tcls.test_value == 'test_value'
    assert tcls.__getattr__('test_value') == 'test_value'


# Generated at 2022-06-24 05:09:43.136937
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.new_attr = 'some_value'
    assert settings['new_attr'] == 'some_value'


# Generated at 2022-06-24 05:09:53.495604
# Unit test for method init of class Settings
def test_Settings_init():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    test_settings.update = lambda dic: dic
    test_settings.init()

    assert test_settings == {
        'require_confirmation': True,
        'wait_command': 3,
        'rules': [],
        'env': {},
        'exclude_rules': [],
        'priority': {},
        'no_colors': False,
        'debug': False,
        'alter_history': True,
        'wait_slow_command': 15,
        'repeat': True,
        'instant_mode': False,
        'slow_commands': [],
        'excluded_search_path_prefixes': [],
        'history_limit': None,
        'num_close_matches': 3,
    }

# Generated at 2022-06-24 05:10:03.155787
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch
    from tempfile import mkdtemp
    from shutil import rmtree
    from unittest import TestCase

    def assert_all_items_in(items1, items2):
        all_in = True
        for item in items1:
            if item not in items2:
                all_in = False
        return all_in

    class SettingsInit(TestCase):
        def setUp(self):
            self.temp_dir = Path(mkdtemp())
            self.settings_path = self.temp_dir.joinpath('settings.py')

        def tearDown(self):
            rmtree(self.temp_dir)

        def _create_settings_file(self):
            self.settings_path.open(mode='w').close()
