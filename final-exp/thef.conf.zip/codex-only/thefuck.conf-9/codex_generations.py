

# Generated at 2022-06-24 05:00:09.032442
# Unit test for constructor of class Settings
def test_Settings():
    import mock
    with mock.patch('os.environ') as env:
        env.get.return_value = None

# Generated at 2022-06-24 05:00:16.673263
# Unit test for constructor of class Settings
def test_Settings():
    assert 'DEFAULT_RULES' in settings.keys()
    assert 'DEFAULT_RULE_NAMES' in settings.keys()
    assert 'require_confirmation' in settings.keys()
    assert 'wait_command' in settings.keys()
    assert 'slow_commands' in settings.keys()
    assert 'wait_slow_command' in settings.keys()
    assert 'rules' in settings.keys()
    assert 'aliases' in settings.keys()
    assert 'priority' in settings.keys()
    assert 'exclude_rules' in settings.keys()
    assert 'no_colors' in settings.keys()
    assert 'debug' in settings.keys()
    assert 'history_limit' in settings.keys()
    assert 'alter_history' in settings.keys()

# Generated at 2022-06-24 05:00:24.100705
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from .logs import set_logger
    logger = set_logger(is_debug=True)

    settings.new_key = 'value'
    assert settings['new_key'] == 'value'
    assert settings.new_key == 'value'

    logger.disabled = False
    settings.new_key = 'value2'
    assert settings['new_key'] == 'value2'
    assert settings.new_key == 'value2'



# Generated at 2022-06-24 05:00:25.426894
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings({})
    settings.test = 123
    assert settings.get('test') == 123


# Generated at 2022-06-24 05:00:27.660034
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.test = True
    assert settings['test'] == True
    settings.test = False
    assert settings['test'] == False


# Generated at 2022-06-24 05:00:29.034201
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.settings_name == 'settings'


# Generated at 2022-06-24 05:00:30.085471
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation

# Generated at 2022-06-24 05:00:32.367663
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.name = 'lzjun567'
    assert settings['name'] == 'lzjun567'


# Generated at 2022-06-24 05:00:43.203844
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import enable_debug, disable_debug
    enable_debug()
    settings.init()
    assert settings['require_confirmation'] == True
    assert settings['repeat'] == False
    assert settings['debug'] == True
    settings.init(args=argparse.Namespace(yes=True))
    assert settings['require_confirmation'] == False
    settings.init(args=argparse.Namespace(yes=False))
    assert settings['require_confirmation'] == True
    settings.init(args=argparse.Namespace(debug=1))
    assert settings['debug'] == 1
    settings.init(args=argparse.Namespace(debug=2))
    assert settings['debug'] == 2
    settings.init(args=argparse.Namespace(repeat=True))
    assert settings['repeat'] == True
    settings

# Generated at 2022-06-24 05:00:47.490548
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert const.DEFAULT_SETTINGS['require_confirmation'] == settings.require_confirmation

# Generated at 2022-06-24 05:00:58.023931
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('debug') == False
    assert settings.get('repeat') == False
    assert settings['rules'] == ['sudo_command', 'spell_command', 'git_command', 'svn_command', 'apt_command', 'python', 'perl', 'php', 'node', 'ruby', 'cd', 'brew', 'bundle', 'man', 'history', 'alias', 'apt_get']
    assert settings['exclude_rules'] == []
    assert settings['priority'] == {'sudo_command': 100, 'git_command': 70, 'cd': 50}
    assert settings['wait_command'] == 3
    assert settings['history_limit'] == 200
    assert settings['require_confirmation'] == False
    assert settings['no_colors'] == False
    assert settings['alter_history'] == True

# Generated at 2022-06-24 05:00:59.383384
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.fuck = 'fuck'
    assert settings['fuck'] == 'fuck'


# Generated at 2022-06-24 05:01:03.020452
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.foo = 'bar'
    assert settings['foo'] == 'bar'


# Generated at 2022-06-24 05:01:05.388826
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    obj = Settings()
    assert obj.a == None
    obj.a = 'hello world'
    assert obj.a == 'hello world'


# Generated at 2022-06-24 05:01:07.905039
# Unit test for method init of class Settings
def test_Settings_init():
    """Test the method init of class Settings

    :return:
    """
    test_settings = Settings()
    test_settings.init(args=None)

    # todo: need to be expanded

# Generated at 2022-06-24 05:01:13.612223
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    for key in const.DEFAULT_SETTINGS.keys():
        assert test_settings[key] == const.DEFAULT_SETTINGS[key]
        assert getattr(test_settings, key) == const.DEFAULT_SETTINGS[key]

# Generated at 2022-06-24 05:01:22.426094
# Unit test for method init of class Settings
def test_Settings_init():
    from .tests import Mock
    from . import logs
    from .logs import exception
    from .settings import Settings

    settings = Settings(const.DEFAULT_SETTINGS)
    old_user_dir = settings.user_dir
    mock_user_dir = Mock(name='test_settings_user_dir')
    mock_user_dir.joinpath = Mock(return_value=Mock(name='test_settings_user_dir/settings.py'))
    mock_user_dir.joinpath().is_file = Mock(return_value=True)
    settings.user_dir = mock_user_dir

    old_exception = logs.exception
    logs.exception = Mock(side_effect=lambda *args, **kwargs: None)
    settings.init()
    assert logs.exception.called

# Generated at 2022-06-24 05:01:23.531258
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.a = 10
    assert settings.a == 10


# Generated at 2022-06-24 05:01:32.633010
# Unit test for method init of class Settings
def test_Settings_init():
    settings_old = Settings(const.DEFAULT_SETTINGS)
    settings_old._settings_from_args = lambda x: {'require_confirmation': True}
    settings_old._settings_from_env = lambda: {'rules':'DEFAULT_RULES'}
    settings_old._settings_from_file = lambda: {'require_confirmation': True,
                                                'rules':'DEFAULT_RULES'}
    # Check result of method init of class settings
    assert settings_old.init() == {'require_confirmation': True,
                                   'rules':'DEFAULT_RULES'}


# Generated at 2022-06-24 05:01:41.857941
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    # Only for python 2
    if sys.version_info[0] != 2:
        return
    from mock import MagicMock

    # Create a Settings instance
    settings = Settings()

    # Mock class `re`
    settings.get = MagicMock(return_value="return_value")

    # Assertion
    assert settings.__getattr__("item") == "return_value"

    # We call __getattr__ with argument "item" and method `re.get`
    # with argument "item"
    settings.get.assert_called_with("item")



# Generated at 2022-06-24 05:01:45.825205
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.new_item_here = "test"
    assert settings["new_item_here"] == "test"

# Generated at 2022-06-24 05:01:52.197559
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.wait_slow_command == 5
    assert settings.require_confirmation == True
    assert settings.debug == False
    assert settings.history_limit == None
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.no_colors == False
    assert settings.priority == {}
    assert settings.alter_history == False
    assert settings.wait_command == 0
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.repeat == 1
    assert settings.num_close_matches == 3
    assert settings.instant_mode == False


# Generated at 2022-06-24 05:02:03.392916
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile, shutil

# Generated at 2022-06-24 05:02:05.294625
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings({'hello': 'world'})
    assert settings.hello == 'world'



# Generated at 2022-06-24 05:02:13.045232
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class F(object):
        def __init__(self):
            self.v = 0

        def __eq__(self, other):
            return self.v == other.v

    s = Settings()
    f1 = F()
    f2 = F()
    f1.v = f2.v = 1
    s.f = f1
    assert(s.f == f1)
    f1.v = f2.v = 2
    s.f = f2
    assert(s.f == f2)

# Generated at 2022-06-24 05:02:15.242281
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == True
    assert settings.__getattr__('require_confirmation') == True


# Generated at 2022-06-24 05:02:26.288037
# Unit test for constructor of class Settings
def test_Settings():
    from .system import Path
    from .const import DEFAULT_SETTINGS, ENV_TO_ATTR

    xdg_config_home = os.environ.get('XDG_CONFIG_HOME', '~/.config')
    user_dir = Path(xdg_config_home, 'thefuck').expanduser()
    legacy_user_dir = Path('~', '.thefuck').expanduser()

    assert settings.user_dir == user_dir
    assert settings.get_user_dir_path() == user_dir
    assert settings.normalized_user_dir == user_dir

    os.environ['XDG_CONFIG_HOME'] = legacy_user_dir.as_posix()
    user_dir = Path(legacy_user_dir, 'thefuck').expanduser()
    assert settings

# Generated at 2022-06-24 05:02:28.245913
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    a = Settings()
    a.test = True
    assert(a.get('test') == True)

test_Settings___setattr__()

# Generated at 2022-06-24 05:02:39.989340
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import capture
    from .system import TemporaryDirectory

    with TemporaryDirectory() as tmp_dir:
        user_dir = Path(tmp_dir, 'thefuck')
        settings_file = user_dir.joinpath('settings.py')
        os.environ['TF_DONT_WRITE_TO_CONFIG'] = 'true'
        user_dir.mkdir()
        settings.init()

        assert settings.user_dir == user_dir
        assert settings_file.is_file()
        assert settings_file.read() == const.SETTINGS_HEADER
        assert settings_file.joinpath('rules').is_dir()
        assert settings == const.DEFAULT_SETTINGS

        os.environ['TF_ALIAS'] = 'fuck'
        settings.init()

# Generated at 2022-06-24 05:02:42.421127
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test_a = 'test_a'
    assert settings['test_a'] == 'test_a'


# Generated at 2022-06-24 05:02:52.928439
# Unit test for method init of class Settings
def test_Settings_init():
    global settings

    # Check if settings are initialized
    assert settings

    # Test function _setup_user_dir
    assert getattr(settings, 'user_dir', None)

    # Test function _settings_from_files
    assert getattr(settings, 'require_confirmation', None)
    assert getattr(settings, 'require_confirmation', None)
    assert getattr(settings, 'slow_commands', None)

    # Test function _settings_from_env
    env = os.environ.copy()
    env['THEFUCK_REQUIRE_CONFIRMATION'] = 'False'
    settings_from_env = Settings(env)
    assert not settings_from_env['require_confirmation']

    # Test function _settings_from_args

# Generated at 2022-06-24 05:02:54.664308
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.correct_usage is True

# Generated at 2022-06-24 05:02:56.918929
# Unit test for constructor of class Settings
def test_Settings():
    assert not settings.user_rules
    assert settings.require_confirmation
    assert not settings.no_colors


if __name__ == '__main__':
    test_Settings()

# Generated at 2022-06-24 05:03:01.125759
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.test = 'test'
    assert settings['test'] == 'test'



# Generated at 2022-06-24 05:03:03.944101
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
  s = Settings()
  assert s.not_exist is None
  assert s['not_exist'] is None
  s.exist = 5
  assert s['exist'] == 5
  assert s.exist == 5


# Generated at 2022-06-24 05:03:10.385494
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init(None)
    assert settings.user_dir == settings._get_user_dir_path()
    settings_path = settings.user_dir.joinpath('settings.py')
    with settings_path.open(mode='r') as settings_file:
        for line in const.SETTINGS_HEADER.split('\n'):
            assert next(settings_file).strip() == line.strip()
        for setting in const.DEFAULT_SETTINGS.items():
            assert next(settings_file).strip() == '# {} = {}'.format(*setting)

test_Settings_init()

# Generated at 2022-06-24 05:03:12.093448
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = True
    assert settings['test'] is True

# Generated at 2022-06-24 05:03:22.799985
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile, shutil

    def set_env_value(attr, value):
        os.environ['THEFUCK_{}'.format(attr.upper())] = value

    def get_env_value(attr):
        return os.environ['THEFUCK_{}'.format(attr.upper())]

    def get_settings_value(attr):
        return settings[attr]

    def set_settings_value(attr, value):
        settings[attr] = value

    temp_dir = tempfile.mkdtemp()
    user_dir = Path(temp_dir, '.thefuck')
    settings.user_dir = user_dir
    settings.history = user_dir.joinpath('history')
    settings._init_settings_file()
    set_env_value('debug', 'true')

# Generated at 2022-06-24 05:03:31.919881
# Unit test for constructor of class Settings
def test_Settings():
    _settings = Settings(const.DEFAULT_SETTINGS)
    assert _settings['history_limit'] == 0
    assert _settings['no_colors'] == False
    assert _settings['require_confirmation'] == True
    assert _settings['wait_command'] == 1
    assert _settings['wait_slow_command'] == 15
    assert _settings['rules'] == ['fuck']
    assert _settings['exclude_rules'] == []
    assert _settings['excluded_search_path_prefixes'] == []
    assert _settings['priority'] == {}
    assert _settings['slow_commands'] == []
    assert _settings['num_close_matches'] == 3
    assert _settings['alter_history'] == False
    assert _settings['instant_mode'] == False
    assert _settings['repeat'] == False


# Unit

# Generated at 2022-06-24 05:03:34.444332
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.example_attr = 'example_value'
    assert settings['example_attr'] == 'example_value'

# Generated at 2022-06-24 05:03:35.652231
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.slow_commands == ['sudo']


# Generated at 2022-06-24 05:03:37.233428
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.global_set='global'
    assert settings.global_set == 'global'


# Generated at 2022-06-24 05:03:39.150275
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings({'a': 1})
    assert settings.a == 1
    assert settings.b is None


# Generated at 2022-06-24 05:03:40.575954
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    obj = Settings()
    obj.a = True
    assert obj['a'] == True



# Generated at 2022-06-24 05:03:42.772563
# Unit test for constructor of class Settings
def test_Settings():
    assert Settings() == const.DEFAULT_SETTINGS


# Generated at 2022-06-24 05:03:43.738446
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.init()
    settings.require_confirmation = False
    assert settings['require_confirmation'] == False


# Generated at 2022-06-24 05:03:45.556297
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings == const.DEFAULT_SETTINGS

# Generated at 2022-06-24 05:03:47.477201
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == False
    settings.require_confirmation = True
    assert settings.require_confirmation == True


# Generated at 2022-06-24 05:03:56.761194
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    mock_args = None
    settings._init_settings_file = lambda: None
    settings._settings_from_file = lambda: {}
    settings._settings_from_args = lambda args: {}

    settings.init(mock_args)
    assert settings == const.DEFAULT_SETTINGS, 'Should use default settings for empty settings.py'

    settings._settings_from_file = lambda: {'slow_commands': 'vim'}
    settings.init(mock_args)
    assert settings['slow_commands'] == ['vim'], 'Should overwrite default settings'
    assert settings['debug'] == False, 'Should use default settings for empty settings.py'

    mock_args = type('args', (), {'debug': True, 'yes': True})
    settings.init(mock_args)

# Generated at 2022-06-24 05:04:01.321901
# Unit test for method init of class Settings
def test_Settings_init():
    # assert_equal(settings, const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir == Path('.config/thefuck').expanduser()
    assert settings.require_confirmation

# Generated at 2022-06-24 05:04:08.554993
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    def update(settings):
        # Settings from file
        settings.update(dict(rules=['ls']))
        # Settings from env
        os.environ['THEFUCK_DEBUG'] = 'True'
        os.environ['THEFUCK_RULES'] = 'ls:ps'
        os.environ['THEFUCK_SEARCH_IN_PATH'] = 'False'
        # Settings from args
        return settings

    settings.init(FakeArgs(debug=True, yes=False))
    assert settings.debug is True
    assert settings.require_confirmation is False

    settings = Settings(update(const.DEFAULT_SETTINGS))
    assert settings.debug is None
    assert settings.require_confirmation is True

    fake_exception = Exception('Fake Exception')


# Generated at 2022-06-24 05:04:17.638599
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.priority == const.DEFAULT_SETTINGS['priority']
    assert settings.no_colors == const.DEFAULT_SETTINGS['no_colors']
    assert settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']
    assert settings.wait_command == const.DEFAULT_SETTINGS['wait_command']
    assert settings.wait_slow_command == const.DEFAULT_SETTINGS['wait_slow_command']
    assert settings.alter_history == const.DEFAULT_SETTINGS['alter_history']

# Generated at 2022-06-24 05:04:20.376313
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.get("wait_command") == 3
    settings.wait_command = 2
    assert settings.get("wait_command") == 2



# Generated at 2022-06-24 05:04:22.584650
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings['require_confirmation'] is True

# Generated at 2022-06-24 05:04:23.917778
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.key = 'value'
    assert settings['key'] == 'value'


# Generated at 2022-06-24 05:04:32.422450
# Unit test for method init of class Settings
def test_Settings_init():
    # Init settings
    settings.init()

    assert settings['rules_dir'] == Path('~', '.thefuck', 'rules').expanduser()
    assert settings['hist_file'] == Path('~', '.thefuck', 'history').expanduser()
    assert settings['wait_command'] == 1
    assert settings['require_confirmation'] == True
    assert settings['no_colors'] == False
    assert settings['history_limit'] == None
    assert settings['alter_history'] == False
    assert settings['wait_slow_command'] == 15
    assert settings['repeat'] == True
    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['exclude_rules'] == []
    assert settings['priority'] == {}
    assert settings['slow_commands'] == []

# Generated at 2022-06-24 05:04:34.062402
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    del settings['rules']
    value = 'test'
    settings['test'] = value
    assert settings.test == value



# Generated at 2022-06-24 05:04:35.121120
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.alias == const.DEFAULT_SETTINGS['alias']



# Generated at 2022-06-24 05:04:42.249494
# Unit test for method init of class Settings
def test_Settings_init():
    args = lambda yes, debug, repeat: type('args', (object,), {
        'yes': yes,
        'debug': debug,
        'repeat': repeat})

    # Can't load settings from file
    def broken_settings_from_file():
        raise Exception()

    settings_ = Settings({'key': 'value'})
    settings_.update({'rules': 'user_rules'})
    settings_.update({'require_confirmation': True})
    settings_.update({'alter_history': True})
    settings_.update({'wait_command': 4})
    settings_.update({'history_limit': 3})
    settings_.update({'wait_slow_command': 4})
    settings_.update({'slow_commands': ['slow_command']})
    settings_.update({'exclude_rules': ['exclude_rule']})

# Generated at 2022-06-24 05:04:44.674063
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from unittest.case import TestCase
    s = Settings()
    s.a = 1
    TestCase().assertEqual(s['a'], 1)


# Generated at 2022-06-24 05:04:50.152868
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class DummyArgs(object):
        yes = None
        debug = False
        repeat = False
    settings.init(DummyArgs())
    settings.require_confirmation = False
    assert settings.get('require_confirmation') == False
    settings.require_confirmation = True
    assert settings.get('require_confirmation') == True


# Generated at 2022-06-24 05:04:56.885167
# Unit test for method init of class Settings
def test_Settings_init():
    from .config import config
    from .system import Path
    from .utils import get_all_executables, get_all_search_paths

    settings.init()
    initial_paths = get_all_search_paths()
    settings.init(args=config)
    post_init_paths = get_all_search_paths()
    assert initial_paths == post_init_paths
    settings_dir = settings.user_dir.joinpath('settings.py')
    assert '# settings.py' in settings_dir.read_text()
    assert settings.user_dir in settings.search_paths
    assert settings.user_dir.joinpath('rules') in settings.search_paths


# Generated at 2022-06-24 05:05:06.502827
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import capture_log
    from .logs import is_debug
    from .logs import is_exception

    args = type('args', (object,), {'yes': True, 'debug': True, 'repeat': 3})

    captured_log = capture_log(settings.init)
    assert is_debug(captured_log)
    assert is_exception(captured_log)

# Generated at 2022-06-24 05:05:08.574134
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir.is_dir()
    assert settings.user_dir.joinpath('settings.py').is_file()

# Generated at 2022-06-24 05:05:09.900898
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == True
    assert settings.sudo_command == 'sudo'
    assert settings.alias == None



# Generated at 2022-06-24 05:05:11.610931
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules
test_Settings___getattr__.__test__ = False


# Generated at 2022-06-24 05:05:13.402991
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings()
    settings['KEY'] = 'VALUE'
    assert settings.KEY == 'VALUE'

# Generated at 2022-06-24 05:05:21.614422
# Unit test for constructor of class Settings
def test_Settings():
    from .logs import exception
    from .utils import get_closest

    settings.init()
    assert settings
    assert not settings['command']
    assert not settings['script']
    assert settings.get('require_confirmation')
    assert settings.get('repeat')
    assert settings.get('wait_command')

    settings.init(args=dict(yes=True, debug=False, repeat=2))
    assert not settings['require_confirmation']
    assert not settings['debug']
    assert settings['repeat'] == 2

    settings._settings_from_env = lambda: {'require_confirmation': False}
    settings.init()
    assert not settings['require_confirmation']

# Generated at 2022-06-24 05:05:23.447701
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['exclude_rules'] == ['git_push']
    assert settings['wait_command'] == 0
    assert settings['require_confirmation'] == True

# Generated at 2022-06-24 05:05:25.387570
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings_ = Settings()
    settings_.enable_experimental_instant_mode = True
    assert settings_.enable_experimental_instant_mode


# Generated at 2022-06-24 05:05:27.674038
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.key = 'value'
    assert settings['key'] == 'value'


# Generated at 2022-06-24 05:05:30.451988
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings()
    test_settings.test = 'TEST'
    assert test_settings['test'] == 'TEST'



# Generated at 2022-06-24 05:05:32.512225
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.attr = 123
    assert settings['attr'] == 123


# Generated at 2022-06-24 05:05:33.440115
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.no_colors


# Generated at 2022-06-24 05:05:35.077542
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert settings.no_colors == False
    assert settings.repeat == 1
    assert settings.history_limit == None

# Generated at 2022-06-24 05:05:43.840770
# Unit test for method init of class Settings
def test_Settings_init():
    """Test that the attribute `settings` is correctly filled."""
    # We use `object()` as a mock:
    sys.modules['settings'] = object()
    path = settings.user_dir.joinpath('settings.py')
    try:
        with path.open(mode='w') as settings_file:
            settings_file.write('foo = "bar"\n')

        # We change `settings.py` before to modify it from the env:
        os.environ['THEFUCK_WAIT_SLOW_COMMAND'] = '42'
        settings.init()
        assert settings['foo'] == 'bar'
        assert settings['wait_slow_command'] == 42
    finally:
        path.unlink()
        # We don't want to pollute `sys.modules`:

# Generated at 2022-06-24 05:05:45.393822
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    class EmptySettings(Settings):
        pass
    assert EmptySettings().get('test') is None


# Generated at 2022-06-24 05:05:50.117121
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.xxx = 'yyy'
    assert settings.xxx == 'yyy'
    assert settings['xxx'] == 'yyy'
    settings.yyy = 'zzz'
    assert settings.yyy == 'zzz'
    assert settings['yyy'] == 'zzz'
    assert len(settings.keys()) == 2

# Generated at 2022-06-24 05:05:51.571822
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation is True



# Generated at 2022-06-24 05:05:53.218913
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings(None)
    assert s == {}



# Generated at 2022-06-24 05:05:55.333823
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings({'black': 1, 'white': 1})
    settings.black = settings.black + 1
    assert settings.black == 2

# Generated at 2022-06-24 05:05:57.497942
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init(args)
    assert settings.no_colors

# Generated at 2022-06-24 05:06:00.700214
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    s = settings()
    settings.clear()
    settings.update(a=1, b=2, c=3)
    assert s.a == 1
    assert s.b == 2
    assert s.c == 3


# Generated at 2022-06-24 05:06:02.555777
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.history_limit == 20


# Generated at 2022-06-24 05:06:09.062041
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.slow_commands == ('sudo',)
    assert settings.wait_slow_command == 15
    assert settings.prioritize_match == False
    assert settings.priority == {}
    assert settings.exclude_rules == ()
    assert settings.debug == False
    assert settings.repeat == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.excluded_search_path_prefixes == ()
    assert settings.num_close_matches == 3

# Generated at 2022-06-24 05:06:11.134917
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    s = Settings()
    s['foo'] = 1
    assert s.foo == 1


# Generated at 2022-06-24 05:06:13.273349
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.new = 'test'
    assert settings['new'] == 'test'

# Generated at 2022-06-24 05:06:15.052379
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    s.a = 3
    assert s == {'a': 3}



# Generated at 2022-06-24 05:06:20.268030
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    # Check that DEFAULT_SETTINGS is returned for settings not set (or removed)
    for setting in settings.keys():
        if setting in ('rules', 'exclude_rules', 'priority'):
            assert settings[setting] == settings.default_settings[setting]
        else:
            assert settings[setting] == settings.default_settings[setting]


# Generated at 2022-06-24 05:06:25.762971
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    class Settings_(dict):
        """ Settings class that does not have a __setattr__ method """
        def __getattr__(self, item):
            return self.get(item)
    settings_ = Settings_()
    assert settings_['foo'] == settings_.foo, \
        'Settings.__getattr__ should return something equal to what get'
test_Settings___getattr__()

# Generated at 2022-06-24 05:06:28.769858
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.a = 1
    assert settings['a'] == 1


# Generated at 2022-06-24 05:06:33.727679
# Unit test for method init of class Settings
def test_Settings_init():
    """
    Test case: settings is successfully loaded from file and env
    """
    args = type('args', (object,),
                {'debug': False, 'repeat': None, 'yes': False})()
    settings.init(args)
    assert isinstance(settings, Settings)
    assert settings['rules'] == ['python', 'git', 'apt', 'vim']

# Generated at 2022-06-24 05:06:36.925359
# Unit test for constructor of class Settings
def test_Settings():
    settings.init() #Initialize
    settings.init(args=None)
    settings.init(args=True)

    assert settings.get('require_confirmation') == True
    assert settings.get('repeat') == False
    assert settings.get('debug') == False

# Generated at 2022-06-24 05:06:44.573770
# Unit test for constructor of class Settings
def test_Settings():
    from .logs import Logger
    from .executors import Instance

    settings = Settings()
    settings.init()

    assert settings.get('require_confirmation') is True
    assert settings.get('log_file') == '~/.config/thefuck/log'
    assert settings.get('log_level') == 'INFO'
    assert settings.get('history_limit') == None
    assert settings.get('wait_command') == 3
    assert settings.get('slow_commands') == []
    assert settings.get('wait_slow_command') == 15
    assert settings.get('alter_history') == False
    assert settings.get('instant_mode') == False

# Generated at 2022-06-24 05:06:48.517841
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    """Test for Settings() and __getattr__."""
    setting_test = Settings()
    setting_test['test_attribute'] = "test_value"
    assert setting_test.test_attribute == "test_value"



# Generated at 2022-06-24 05:06:51.728628
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    test_settings = Settings({'test_key': 'test_value'})
    assert test_settings.test_key == 'test_value'
    assert getattr(test_settings, 'test_key') == 'test_value'


# Generated at 2022-06-24 05:06:53.467836
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['require_confirmation']
    assert settings['repeat']


# Unit tests for init method of class Settings

# Generated at 2022-06-24 05:06:54.106115
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('require_confirmation') == True


# Generated at 2022-06-24 05:06:58.107937
# Unit test for constructor of class Settings

# Generated at 2022-06-24 05:06:58.871187
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.wait_command == 3



# Generated at 2022-06-24 05:06:59.892423
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules == ['git_add_--all.py']


# Generated at 2022-06-24 05:07:03.734205
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # Unit test for method __getattr__ of class Settings
    def test_Settings___getattr__():
        assert settings.debug

    settings.debug = False
    assert not settings.debug


# Unit-test for method __getattr__ of class Settings

# Generated at 2022-06-24 05:07:06.100747
# Unit test for constructor of class Settings
def test_Settings():
    assert const.DEFAULT_SETTINGS == dict(settings)

# Generated at 2022-06-24 05:07:08.994216
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    variables = {'A': 1, 'B': 2, 'C': 3}
    settings = Settings(variables)
    assert settings.A == 1
    assert settings.B == 2
    assert settings.C == 3


# Generated at 2022-06-24 05:07:10.153670
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings({"test":"test"})
    assert a["test"] == "test"

# Generated at 2022-06-24 05:07:13.119968
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings['require_confirmation'] is False
    assert settings.require_confirmation is False
    settings.require_confirmation = True
    assert settings['require_confirmation'] is True
    assert settings.require_confirmation is True


# Generated at 2022-06-24 05:07:15.234831
# Unit test for constructor of class Settings
def test_Settings():
    app_settings = Settings()
    assert app_settings.user_dir == '~/.thefuck'


# Generated at 2022-06-24 05:07:24.896034
# Unit test for constructor of class Settings
def test_Settings():
    from .logs import exception

    def assert_settings(settings_file, settings_env, settings_args, expected_settings):
        _settings = Settings(const.DEFAULT_SETTINGS)
        _settings._settings_from_file = lambda: settings_file
        _settings._settings_from_env = lambda: settings_env
        _settings._settings_from_args = lambda args: settings_args
        _settings.init()
        assert _settings == expected_settings

    assert_settings(
        {'require_confirmation': True},
        {'require_confirmation': False},
        {'require_confirmation': False},
        {'require_confirmation': False})

# Generated at 2022-06-24 05:07:28.249766
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.update({'a': 'b'})
    assert settings['a'] == 'b'


# Generated at 2022-06-24 05:07:32.947515
# Unit test for method init of class Settings
def test_Settings_init():
    # Test for init with empty args
    settings.init()
    for key, value in const.DEFAULT_SETTINGS.items():
        assert getattr(settings, key) == value
    # Test for init with args
    settings.init(args="args")
    assert settings.require_confirmation == False
    assert settings.debug == False
    assert settings.repeat == None

# Generated at 2022-06-24 05:07:38.621407
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    """Test for method `__getattr__` of class `Settings`

    Test if the value the giving key is correct.

    Args:
        None

    Returns:
        None

    Raises:
        None
    """

    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.get('USE_ARGV') == True
    assert settings.get('WAIT_COMMAND') == 0
    assert settings.get('TRACK_COMMANDS')==False


# Generated at 2022-06-24 05:07:39.994960
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation is not None


# Generated at 2022-06-24 05:07:43.204250
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    # test key existed
    assert settings.require_confirmation
    # test key didn't exist
    assert getattr(settings, 'abc') is None


# Generated at 2022-06-24 05:07:53.690689
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .utils import wrap_streams
    from .system import TemporaryDirectory
    from .compat import StringIO

    # Test case 1: load settings from default files
    settings.init()
    assert isinstance(settings.require_confirmation, bool)
    assert isinstance(settings.wait_command, int)
    assert isinstance(settings.wait_slow_command, int)
    assert isinstance(settings.num_close_matches, int)
    assert isinstance(settings.history_limit, int)
    assert isinstance(settings.alter_history, bool)
    assert isinstance(settings.instant_mode, bool)
    assert isinstance(settings.no_colors, bool)
    assert isinstance(settings.command_not_found, str)

# Generated at 2022-06-24 05:08:03.892939
# Unit test for method init of class Settings
def test_Settings_init():
    from unittest import mock

    def _settings_from_env():
        return None

    temp_settings = Settings(const.DEFAULT_SETTINGS)

    temp_settings._settings_from_env = _settings_from_env
    temp_settings.init()
    assert temp_settings.user_dir == settings.user_dir

    mocked_init_settings_file = mock.Mock()
    mocked_settings_from_file = mock.Mock()

    temp_settings._init_settings_file = mocked_init_settings_file
    temp_settings._settings_from_file = mocked_settings_from_file
    temp_settings.init()

    mocked_init_settings_file.assert_called_with()
    mocked_settings_from_file.assert_called_with()


# Generated at 2022-06-24 05:08:11.344751
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.init()
    assert settings.wait_command == 3
    assert settings.require_confirmation == True
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.exclude_rules == ['vagrant', 'sbt', 'gradle', 'lein', 'react-native', '/.*gradlew$/']
    assert settings.no_colors == False
    assert settings.alter_history == True
    assert settings.instant_mode == False


# Generated at 2022-06-24 05:08:22.574781
# Unit test for method init of class Settings
def test_Settings_init():
    settings.update({
        'history_limit': 10,
        'wait_slow_command': 5,
        'num_close_matches': 3,
        'require_confirmation': False,
        'no_colors': False,
        'debug': False,
        'alter_history': True,
        'wait_command': 2,
        'slow_commands': ['lein'],
        'exclude_rules': ['cd'],
        'excluded_search_path_prefixes': ['/some/path'],
        'instant_mode': False,
        'priority': {'anything': 1},
        'repeat': None
    })
    settings.init()
    assert settings['history_limit'] == 10
    assert settings['wait_slow_command'] == 5

# Generated at 2022-06-24 05:08:28.496094
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    class TestSettings(Settings):
        def __init__(self, *args, **kwargs):
            self.dict = {'key': 'value'}
            super(TestSettings, self).__init__(*args, **kwargs)

    config = TestSettings()
    assert config.key == config.dict.get('key')

# Generated at 2022-06-24 05:08:33.054077
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings({'foo': 'bar'})
    assert settings['foo'] == 'bar'
    settings.foo = 'baz'
    assert settings['foo'] == 'baz'
    settings.new_foo = 'bar'
    assert settings['new_foo'] == 'bar'



# Generated at 2022-06-24 05:08:33.822458
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.init() == None


# Generated at 2022-06-24 05:08:37.103740
# Unit test for method init of class Settings
def test_Settings_init():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    test_settings.init()

    assert test_settings.rules
    assert test_settings.priority


# Generated at 2022-06-24 05:08:38.621003
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.no_colors == False
    assert settings.__getattr__('no_colors') == False



# Generated at 2022-06-24 05:08:42.260783
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    settings.exclude_rules = []
    settings.rules = []
    assert settings.exclude_rules == []
    assert settings.rules == []
    assert settings.not_exist is None
    assert not settings.repeat


# Generated at 2022-06-24 05:08:45.684202
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    s.hello = 'world'
    assert s['hello'] == 'world'

# Generated at 2022-06-24 05:08:48.117234
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert 'require_confirmation' in settings.keys()


# Generated at 2022-06-24 05:08:52.097815
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.require_confirmation
    assert settings.priority == const.DEFAULT_PRIORITY



# Generated at 2022-06-24 05:09:01.786532
# Unit test for method init of class Settings
def test_Settings_init():
    from .tests.utils import support_file
    from .logs import exception

    settings_path = support_file('legacy_settings.py')
    user_dir = Path(settings_path).parent
    settings.init()

    assert settings['script'] == 'fuck'
    assert settings['priority'] == const.DEFAULT_SETTINGS['priority']
    assert settings['rules'] == const.DEFAULT_SETTINGS['rules']
    assert settings['exclude_rules'] == const.DEFAULT_SETTINGS['exclude_rules']
    assert settings['wait_command'] == const.DEFAULT_SETTINGS['wait_command']
    assert settings['require_confirmation'] == const.DEFAULT_SETTINGS['require_confirmation']
    assert settings['history_limit'] == const.DEFAULT_SETTINGS['history_limit']

# Generated at 2022-06-24 05:09:13.390004
# Unit test for method init of class Settings
def test_Settings_init():
    init_args = {
            'user_dir': Path('~/.config/thefuck'),
            'rules': ['git_push'],
            'exclude_rules': ['git_root'],
            'require_confirmation': False,
            'no_colors': True,
            'wait_command': 1.0,
            'history_limit': None,
            'wait_slow_command': 3.0,
            'slow_commands': [],
            'alter_history': True,
            'excluded_search_path_prefixes': [],
            'debug': False,
            'priority': {},
            'num_close_matches': 3,
            'instant_mode': False,
            'repeat': True
        }
    init_args_without_user_dir = init_args.copy()
   

# Generated at 2022-06-24 05:09:22.024914
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.require_confirmation == True
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.priority == const.DEFAULT_PRIORITY
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'gradle', 'rebuild', './build.sh', 'vagrant']
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.excluded_search_path_prefixes == []



# Generated at 2022-06-24 05:09:23.462713
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.success_exit_code = 0
    assert settings.success_exit_code is 0


# Generated at 2022-06-24 05:09:24.593321
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.test = "test"
    assert settings["test"] == "test"

# Generated at 2022-06-24 05:09:25.853915
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    s = Settings({'attr':'value'})
    assert 'value' == s.attr


# Generated at 2022-06-24 05:09:27.640666
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # Call __setattr__
    settings.slow_commands = 'ls, cd'
    assert settings['slow_commands'] == 'ls, cd'


# Generated at 2022-06-24 05:09:33.227459
# Unit test for method init of class Settings
def test_Settings_init():
    """
    Unit test for method init of class Settings

    Test for init with default values
    Test for init with environment variables
    Test for init with args

    Test for init after all when another object of class Settings is created

    """
    
    import os, tempfile, shutil, sys
    from thefuck.logs import exception
    from thefuck.system import Path
    import subprocess
    import unittest
    import mock
    from thefuck.settings import Settings
    
    # Test for init with default values
    settings = Settings()
    # Since the tests depend on the file system, we need to create a temporary directory
    temp_dir = tempfile.mkdtemp()
    # Set default values

# Generated at 2022-06-24 05:09:35.443792
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    s.var = "test"
    assert s.get("var") == "test"

# Generated at 2022-06-24 05:09:44.258783
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import logger, exception

    settings = Settings(
        {key: value for key, value in const.DEFAULT_SETTINGS.items()
         if key != 'debug'})
    settings.init()
    assert settings.debug is False

    args = object()
    settings = Settings({'debug': False})
    settings.init(args)
    assert settings.debug is False

    settings.init(args)
    assert settings.debug is False

    settings = Settings({'debug': True})
    settings.init(args)
    assert settings.debug is True

    settings.init(args)
    assert settings.debug is True

    args.debug = True
    settings = Settings({'debug': False})
    settings.init(args)
    assert settings.debug is True

    settings.init(args)

# Generated at 2022-06-24 05:09:45.141102
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation


# Generated at 2022-06-24 05:09:53.640585
# Unit test for method init of class Settings
def test_Settings_init():

    def _patch_environ(d):
        old_environ = os.environ
        os.environ = d
        return old_environ

    def _make_mock_args(args):
        class MockArgs:
            pass
        args_obj = MockArgs()
        for key in args:
            setattr(args_obj, key, args[key])
        return args_obj

    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_dir = Path(tmpdir)
        old_user_dir = settings.user_dir
        settings.user_dir = tmp_dir
        settings.init()
        assert settings == const.DEFAULT_SETTINGS

        settings.user_dir = old_user_dir

# Generated at 2022-06-24 05:09:55.237680
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.foo = 'bar'
    assert settings.foo == 'bar'

# Generated at 2022-06-24 05:09:57.112292
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.a = 'a'
    assert settings['a'] == 'a'

# Generated at 2022-06-24 05:09:58.590544
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules == const.DEFAULT_SETTINGS['rules']
