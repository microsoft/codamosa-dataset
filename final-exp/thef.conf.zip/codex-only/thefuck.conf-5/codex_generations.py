

# Generated at 2022-06-24 04:59:58.267899
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings(a_key='a_value')
    assert settings.__getattr__('a_key') == 'a_value'



# Generated at 2022-06-24 05:00:01.994241
# Unit test for method init of class Settings
def test_Settings_init():
    settings_copy = settings.copy()
    settings_copy.init()

    assert settings == settings_copy
    assert settings['rules'] == const.DEFAULT_RULES

# Generated at 2022-06-24 05:00:10.547494
# Unit test for method init of class Settings
def test_Settings_init():
    # Test loading settings from both source
    settings = Settings({})
    settings._get_user_dir_path = lambda: Path('/')
    settings._settings_from_file = lambda: {'history_limit': 10}
    settings._settings_from_env = lambda: {'require_confirmation': False}
    settings._settings_from_args = lambda args: {'no_colors': True}
    settings.init()
    assert settings.history_limit == 10
    assert settings.require_confirmation == False
    assert settings.no_colors == True
    assert settings.debug != None
    assert settings.exclude_rules is None


# Generated at 2022-06-24 05:00:19.669453
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import test_logger
    from .utils import wrap_streams

    test_logger.debug.reset_mock()
    with wrap_streams() as streams:
        settings._settings_from_file = lambda: {'rules': 'two'}
        settings._settings_from_env = lambda: {'rules': 'three'}
        settings._settings_from_args = lambda _: {'rules': 'four'}

        settings.init()

        assert settings == {'rules': 'four'}
        assert not streams.stderr.read()
        assert test_logger.debug.call_count == 0

    test_logger.debug.reset_mock()
    with wrap_streams() as streams:
        settings._settings_from_file = lambda: {'rules': 'two'}
       

# Generated at 2022-06-24 05:00:20.620057
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    m = Settings()
    m['k'] = 1
    assert m.k == 1



# Generated at 2022-06-24 05:00:30.029884
# Unit test for method init of class Settings
def test_Settings_init():
    from unittest import mock
    from .system import Path

    old_user_dir = settings.user_dir
    old_settings_file = Path(settings.user_dir, 'settings.py')
    settings_path = old_settings_file

    if settings_path.is_file():
        settings_path.unlink()

    with mock.patch('os.environ.get') as mock_get:
        mock_get.return_value = '/some/where'
        settings.init()
        assert settings.user_dir == Path('/some/where', '.thefuck')
        assert settings.user_dir.joinpath('settings.py').is_file()

    settings.user_dir = old_user_dir
    if settings_path.is_file():
        settings_path.unlink()

test_Settings_init

# Generated at 2022-06-24 05:00:38.559334
# Unit test for method init of class Settings
def test_Settings_init():
    env = {'TF_COLORIZE_OUTPUT': 'true',
           'TF_PRIORITY': 'fs_not_found=1:no_command=0:other=3'}
    args = Namespace(yes=False, debug=True, repeat=2)
    settings.init(args)
    assert(settings.rules == const.DEFAULT_RULES)
    assert(settings.priority == {'fs_not_found': 1, 'no_command': 0, 'other': 3})
    assert(settings.require_confirmation == False)
    assert(settings.colorize_output == True)

# Generated at 2022-06-24 05:00:39.408968
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.command == 'fuck'

# Generated at 2022-06-24 05:00:48.431013
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    s = Settings(const.DEFAULT_SETTINGS)
    assert s.rules == const.DEFAULT_RULES
    assert s.priority == {}
    assert s.require_confirmation == True
    assert s.no_colors == False
    assert s.wait_command == 1
    assert s.history_limit == 0
    assert s.wait_slow_command == 15
    assert s.slow_commands == ['(?i)vagrant']
    assert s.alter_history == False
    assert s.exclude_rules == []
    assert s.excluded_search_path_prefixes == []
    assert s.num_close_matches == 3
    assert s.instant_mode == False


# Generated at 2022-06-24 05:00:50.664387
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.__setattr__('key', 'value')
    assert settings['key'] == 'value'


# Generated at 2022-06-24 05:00:56.497785
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings._settings_from_env = lambda: dict(require_confirmation='False',
                                               rules=['fuck', 'fuck_you', 'fuck_yourself'])
    settings.init()
    assert settings.require_confirmation is False
    assert settings.rules == ['fuck', 'fuck_you', 'fuck_yourself']
    assert settings.get('wrong_name') is None


# Generated at 2022-06-24 05:01:00.846165
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings(dict(one=1, two=2, three=3))
    assert settings.one == 1
    assert settings.two == 2
    assert settings.three == 3


# Generated at 2022-06-24 05:01:03.786727
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings()
    settings.update({'key_1': 'value_1'})
    assert settings.key_1 == settings['key_1']


# Generated at 2022-06-24 05:01:06.749854
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.init()
    assert getattr(settings, 'require_confirmation')
    settings.require_confirmation = False
    assert not getattr(settings, 'require_confirmation')


# Generated at 2022-06-24 05:01:12.485208
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    tests = [
        {'settings': dict(attr='value'), 'attr': 'attr', 'value': 'value', 'result': dict(attr='value')},
        {'settings': dict(attr='value'), 'attr': 'attr', 'value': 'another', 'result': dict(attr='another')},
        {'settings': dict(attr='value'), 'attr': 'new attr', 'value': 'another', 'result': dict(attr='value', new_attr='another')}
    ]
    unit_test_for_method_of_class(tests, '__setattr__', Settings)


# Generated at 2022-06-24 05:01:15.674280
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings['user_dir'] = ''
    settings['rules'] = 'DEFAULT_RULES'
    
    settings.init()
    assert settings['rules'] == const.DEFAULT_RULES

# Generated at 2022-06-24 05:01:20.161460
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    class TestSettings(object):
        def __init__(self,a,b):
            self.a = a
            self.b = b
            self.c = self.a + self.b
    ts = TestSettings(1,2)
    assert ts.a == 1
    assert ts.b == 2
    assert ts.c == 3


# Generated at 2022-06-24 05:01:22.964823
# Unit test for method init of class Settings
def test_Settings_init():
    #need to be initialized first
    test_Settings_init_user_dir()
    test_settings_init_settings_from_file()
    test_settings_init_settings_from_env()
    test_settings_init_settings_from_args()


# Generated at 2022-06-24 05:01:24.260738
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from .tests.utils import eq_
    _settings = Settings()
    eq_(_settings.attr, None)


# Generated at 2022-06-24 05:01:29.782464
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules == const.DEFAULT_SETTINGS['rules']

"""
>>> from thefuck import settings
>>> settings.rules
['cd_parent', ...] # On Python 2, use `print(settings.rules)`
>>> settings.rules = ['ls']
>>> settings.rules
['ls']
"""


# Generated at 2022-06-24 05:01:33.887402
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    assert test_settings == const.DEFAULT_SETTINGS
    test_settings.update({'require_confirmation': False})
    assert test_settings.require_confirmation == False
    assert test_settings.get('require_confirmation') == False
    assert test_settings['require_confirmation'] == False



# Generated at 2022-06-24 05:01:34.906034
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('rules') == const.DEFAULT_SETTINGS.get('rules')



# Generated at 2022-06-24 05:01:35.912881
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.alter_history
    assert settings.instant_mode

# Generated at 2022-06-24 05:01:39.367210
# Unit test for method init of class Settings
def test_Settings_init():
    settings_init = Settings(const.DEFAULT_SETTINGS)
    settings_init.init()

    assert settings_init.get('require_confirmation') == True
    assert settings_init.get('wait_command') == 0

# Generated at 2022-06-24 05:01:45.495300
# Unit test for method init of class Settings
def test_Settings_init():
    import mock
    mock_user_dir = mock.MagicMock()
    mock_user_dir.joinpath = mock.Mock(
        side_effect=lambda path: os.path.join(mock_user_dir.directory, path))
    mock_user_dir.joinpath('settings.py').is_file = lambda: True
    with mock.patch.object(Settings, '_get_user_dir_path') as \
            mock_get_user_dir_path:
        mock_get_user_dir_path.return_value = mock_user_dir
        settings.init()
        assert mock_user_dir.joinpath('settings.py').is_file.called



# Generated at 2022-06-24 05:01:49.588158
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.alter_history is True
    assert settings.correct_me is None
    assert settings.BOGUS is None

# Generated at 2022-06-24 05:01:51.611839
# Unit test for constructor of class Settings
def test_Settings():
    from .system import get_alias

    assert const.DEFAULT_SETTINGS == settings
    assert settings.get_alias == get_alias
    assert settings.get_aliases == get_alias

# Generated at 2022-06-24 05:01:55.516499
# Unit test for method init of class Settings
def test_Settings_init():
    args = Mock(yes=True, debug=True, repeat=True)
    user_dir = Path('/home/user/.config/thefuck')
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.user_dir = user_dir
    settings.init(args)
    assert settings['require_confirmation'] == False
    assert settings['debug'] == True
    assert settings['repeat'] == True


# Generated at 2022-06-24 05:02:06.062169
# Unit test for method init of class Settings
def test_Settings_init():
    # test for method _init_settings_file
    settings._init_settings_file()
    with open(settings.user_dir.joinpath('settings.py').expanduser()) as f:
        string = ''.join(f.readlines())
    assert string == const.SETTINGS_HEADER
    settings.user_dir.joinpath('settings.py').unlink()

    # test for method _setup_user_dir
    try:
        settings._setup_user_dir()
    except:
        assert False
    settings.user_dir.rmdir()

    # test for method _get_user_dir_path
    assert settings._get_user_dir_path() == Path('~/.config/thefuck').expanduser()

    # test for method _settings_from_file
    settings.init()

# Generated at 2022-06-24 05:02:07.024950
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.user_dir == '/home/user/.config/thefuck'



# Generated at 2022-06-24 05:02:15.478377
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.user_dir
    assert settings.rules
    assert settings._get_user_dir_path()
    assert settings._rules_from_env('d:e')
    assert settings._priority_from_env('a=1:b=2')
    assert settings._val_from_env('TEST_NUM_CLOSE_MATCHES', 'num_close_matches') == 10
    assert settings._val_from_env('TEST_NUM_CLOSE_MATCHES', 'num_close_match') == 10
    assert settings._val_from_env('TEST_INSTANT_MODE', 'instant_mode') is True
    assert settings._settings_from_env()
    assert settings._settings_from_file()
    assert settings._settings_from_args(None)
    assert settings._settings_from_args(args)

# Generated at 2022-06-24 05:02:26.566968
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    import shutil
    import os
    import sys

    def cleanup(settings_file_path, user_dir_path, env_var_dict):
        if os.path.isfile(settings_file_path):
            os.remove(settings_file_path)
        if os.path.isdir(user_dir_path):
            shutil.rmtree(user_dir_path)
        for k in env_var_dict.keys():
            if k in os.environ:
                del os.environ[k]

    # Create
    settings_file_path = tempfile.mkstemp()[1]
    user_dir_path = tempfile.mkdtemp()

# Generated at 2022-06-24 05:02:28.509263
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    new_settings = Settings()
    new_settings.key = 'value'
    assert new_settings['key'] == 'value'


# Generated at 2022-06-24 05:02:33.082543
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    assert settings.init() == {'rules': [], 'exclude_rules': []}

# Generated at 2022-06-24 05:02:34.693499
# Unit test for constructor of class Settings
def test_Settings():
    settings2 = Settings(const.DEFAULT_SETTINGS)
    assert settings == settings2
    assert settings.user_dir == settings2.user_dir

# Generated at 2022-06-24 05:02:43.542221
# Unit test for method init of class Settings
def test_Settings_init():
    from .system import reset_settings

    # reset global settings for avoiding interferences between the tests 
    reset_settings()

    args = object()
    user_dir = object()
    setattr(settings, 'user_dir', user_dir)

    settings_path = os.path.join(user_dir, 'settings.py')
    settings_from_file = object()
    settings_from_env = object()
    settings_from_args = object()
    settings_loader_from_file = lambda: settings_from_file
    os_environ = {'TF_REQUIRE_CONFIRMATION': 'False'}
    os_path_isfile = lambda path: path == settings_path
    os_open = lambda path, mode: object()
    file_write = lambda content: None

# Generated at 2022-06-24 05:02:48.351161
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test1 = '1'
    settings.test2 = '2'
    assert settings.test1 == '1'
    assert settings.test2 == '2'
    assert settings['test1'] == '1'
    assert settings['test2'] == '2'


# Generated at 2022-06-24 05:02:50.693361
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    assert isinstance(settings, Settings)
    assert settings == const.DEFAULT_SETTINGS

# Generated at 2022-06-24 05:02:51.530173
# Unit test for constructor of class Settings
def test_Settings():
    settings.init()


# Generated at 2022-06-24 05:02:52.928995
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    s.a = 1
    assert s.get('a') == 1


# Generated at 2022-06-24 05:02:56.027313
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # Given:
    settings = Settings()

    # When:
    settings.attr = 'value'

    # Then:
    assert settings['attr'] == 'value'


# Generated at 2022-06-24 05:03:00.500951
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, dict)
    assert settings.__getattr__('require_confirmation') == settings.get('require_confirmation')
    assert settings.__setattr__('require_confirmation', True) == settings.update({'require_confirmation': True})
    assert settings.__setattr__('require_confirmation', settings.get('require_confirmation'))
    assert settings.__setattr__('require_confirmation', False) == settings.update({'require_confirmation': False})
    assert settings.__getattr__('require_confirmation') == settings.get('require_confirmation')

# Generated at 2022-06-24 05:03:09.807434
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.rules == const.DEFAULT_RULES
    assert settings.alter_history == const.DEFAULT_ALTER_HISTORY
    assert settings.wait_slow_command == const.DEFAULT_WAIT_SLOW_COMMAND
    assert settings.slow_commands == const.DEFAULT_SLOW_COMMANDS
    assert settings.priority == const.DEFAULT_PRIORITY
    assert settings.history_limit == const.DEFAULT_HISTORY_LIMIT
    assert settings.no_colors == const.DEFAULT_NO_COLORS
    assert settings.require_confirmation == const.DEFAULT_REQUIRE_CONFIRMATION
    assert settings.exclude_rules == const.DEFAULT_EXCLUDE_RULES
    assert settings.excluded_search_path_prefixes == const.DEFAULT_EX

# Generated at 2022-06-24 05:03:13.072400
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.get("key", "deafult_value") == "deafult_value"
    s["key"] = "val"
    assert s["key"] == "val"
    assert s.get("key1", "deafult_value") == "deafult_value"
    assert "key1" not in s


# Generated at 2022-06-24 05:03:14.986173
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    assert settings.get('no_colors') == const.DEFAULT_SETTINGS.get('no_colors')
    settings.no_colors = True
    assert settings.get('no_colors') == True


# Generated at 2022-06-24 05:03:16.787113
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.cmd = 'ls'
    assert settings['cmd'] == 'ls'


# Generated at 2022-06-24 05:03:19.184361
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    assert test_settings.get('command_not_found') == 'fuck'

# Generated at 2022-06-24 05:03:22.997644
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings()
    settings['key'] = 'value'
    assert settings.__getattr__('key') == 'value'


# Generated at 2022-06-24 05:03:28.659931
# Unit test for constructor of class Settings
def test_Settings():
    global settings

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir == const.DEFAULT_USER_DIR

    global settings
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init({'debug': True, 'repeat': True})
    assert not settings.require_confirmation
    assert settings.debug
    assert settings.repeat

# Generated at 2022-06-24 05:03:32.906545
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings({'key': 'value'})
    assert 'key' in settings
    settings.key = 'another_value'
    assert settings.get('key') == 'another_value'

# Generated at 2022-06-24 05:03:37.472350
# Unit test for method init of class Settings
def test_Settings_init():
    global settings

    import tempfile

    settings = Settings()
    settings.init()

    # Validate user_dir
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()

    # Mock settings.py file
    with tempfile.NamedTemporaryFile(mode='w') as settings_file:
        settings_file.write('# -*- coding: utf-8 -*-\n' + const.SETTINGS_HEADER)
        for setting in const.DEFAULT_SETTINGS.items():
            settings_file.write('{} = \'{}\'\n'.format(*setting))
        settings_file.flush()

        settings.init()

        for setting in const.DEFAULT_SETTINGS.keys():
            assert getattr(settings, setting) == const.DEFAULT_SETT

# Generated at 2022-06-24 05:03:39.330813
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.key = "value"
    assert settings.key == "value"
    assert settings["key"] == "value"


# Generated at 2022-06-24 05:03:45.460185
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.alterers == []
    assert settings.debug == False
    assert settings.alias == 'fuck'
    assert settings.priority == {}

if __name__ == '__main__':
    test_Settings()

# Generated at 2022-06-24 05:03:47.361657
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules == const.DEFAULT_SETTINGS['rules']
    assert settings.require.__class__.__name__ == 'bool'

# Generated at 2022-06-24 05:03:48.797652
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules
    assert settings.require_confirmation
    assert not settings.not_existing



# Generated at 2022-06-24 05:03:50.728595
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(a=1, b=2)
    assert settings.a == 1
    settings.c = 3
    assert settings.c == 3

# Generated at 2022-06-24 05:03:52.290730
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.no_colors == const.DEFAULT_SETTINGS['no_colors']

# Generated at 2022-06-24 05:03:55.987383
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.no_colors == False



# Generated at 2022-06-24 05:04:00.142496
# Unit test for method init of class Settings
def test_Settings_init():
    settings_ = Settings(const.DEFAULT_SETTINGS)
    settings_.init()
    assert settings_.rules == settings.rules
    assert settings_.exclude_rules == settings.exclude_rules
    assert settings_.priority == settings.priority
    assert settings_.no_colors == settings.no_colors
    assert settings_.require_confirmation == settings.require_confirmation
    assert settings_.wait_command == settings.wait_command
    assert settings_.history_limit == settings.history_limit
    assert settings_.debug == settings.debug
    assert settings_.alter_history == settings.alter_history
    assert settings_.repeat == settings.repeat
    assert settings_.wait_slow_command == settings.wait_slow_command
    assert settings_.slow_commands == settings.slow_commands
    assert settings_.excluded_search_path_prefixes

# Generated at 2022-06-24 05:04:08.471677
# Unit test for method init of class Settings

# Generated at 2022-06-24 05:04:14.982206
# Unit test for constructor of class Settings
def test_Settings():
    import settings
    assert settings.DEFAULT_SETTINGS["require_confirmation"] == True
    assert settings.DEFAULT_SETTINGS["settings_path"] == Path("~/.config/thefuck/settings.py")
    assert settings.DEFAULT_SETTINGS["rules_dir"] == Path("~/.config/thefuck/rules")

# unit test for method _get_user_dir_path()

# Generated at 2022-06-24 05:04:18.171497
# Unit test for constructor of class Settings
def test_Settings():
    from thefuck.utils import wrap_settings
    settings = wrap_settings(path="tests/bin/settings.py")
    assert settings.get("rules", []) == ['f', 'fuck', 'alias']

# Generated at 2022-06-24 05:04:22.867561
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.foo = 'bar'
    assert settings == {'foo': 'bar'}


# Generated at 2022-06-24 05:04:26.293584
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.require_confirmation
    assert not settings.no_colors
    assert not settings.debug
    assert settings.rules == const.DEFAULT_RULES
    assert settings.priority == const.DEFAULT_PRIORITY

# Generated at 2022-06-24 05:04:28.200493
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    assert test_settings.rules == const.DEFAULT_SETTINGS['rules']

# Generated at 2022-06-24 05:04:33.100057
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.user_dir
    assert settings.require_confirmation
    assert settings.debug
    assert settings.rules
    assert settings.no_colors
    assert settings.wait_command
    assert settings.exclude_rules
    assert settings.env_size
    assert settings.history_limit
    assert settings.priority
    assert settings.wait_slow_command
    assert settings.slow_commands
    assert settings.excluded_search_path_prefixes
    assert settings.alter_history
    assert settings.num_close_matches
    assert settings.instant_mode

# Generated at 2022-06-24 05:04:40.574897
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    # clear all settings
    for key in settings:
        settings.pop(key)
    settings.update(const.DEFAULT_SETTINGS)

    # clear cached user_dir
    if hasattr(settings, 'user_dir'):
        del settings.user_dir

    assert settings.user_dir.is_dir()

    # init
    settings.init()

    # check user_dir
    assert settings.user_dir.is_dir()

    # check load settings from file
    assert settings.rules == ['git_push']
    assert settings.alter_history == True
    assert settings.require_confirmation == True
    assert settings.no_colors == False

    # clear env vars
    os.environ.pop('THEFUCK_ALTER_HISTORY', None)
    os

# Generated at 2022-06-24 05:04:52.303450
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.rules == settings['rules']
    assert settings.require_confirmation == settings['require_confirmation']
    assert settings.priority == settings['priority']
    assert settings.wait_command == settings['wait_command']
    assert settings.wait_slow_command == settings['wait_slow_command']
    assert settings.alter_history == settings['alter_history']
    assert settings.no_colors == settings['no_colors']
    assert settings.exclude_rules == settings['exclude_rules']
    assert settings.debug == settings['debug']
    assert settings.history_limit == settings['history_limit']
    assert settings.num_close_matches == settings['num_close_matches']
    assert settings.instant_mode == settings['instant_mode']

# Generated at 2022-06-24 05:04:54.215303
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    obj = Settings({})
    obj.foo = 'bar'
    assert obj['foo'] == 'bar'


# Generated at 2022-06-24 05:04:59.096141
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    class Struct():
        def __init__(self, **entries):
            self.__dict__.update(entries)
    s = Struct(x = 1, y = 2)
    assert settings.__getattr__(s, 'x') == 1
    assert settings.__getattr__(s, 'y') == 2


# Generated at 2022-06-24 05:05:02.134040
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.wait_command == const.DEFAULT_WAIT_COMMAND



# Generated at 2022-06-24 05:05:09.544883
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.a = 1
    assert settings['a'] == 1
    assert settings.get('a') == 1
    assert settings.a == 1

    settings.b = {'c': 2}
    assert settings['b'] == {'c': 2}
    assert settings.get('b') == {'c': 2}
    assert settings.b == {'c': 2}

# Generated at 2022-06-24 05:05:11.215763
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.a = 1
    assert settings.get('a') == 1
    assert settings.a == 1

# Generated at 2022-06-24 05:05:15.706305
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    global settings
    settings.test_var_str = "123"
    assert settings["test_var_str"] == "123"

    settings.test_var_int = 123
    assert settings["test_var_int"] == 123

    settings.test_var_boolean = True
    assert settings["test_var_boolean"] == True


# Generated at 2022-06-24 05:05:17.546127
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    settings.init()
    assert ('require_confirmation' in settings and
            settings.get('require_confirmation'))

# Generated at 2022-06-24 05:05:18.980133
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.no_colors
    assert not hasattr(settings, 'test')


# Generated at 2022-06-24 05:05:20.351356
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings({'one' : '1',})

    assert settings.one == '1'


# Generated at 2022-06-24 05:05:21.103469
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.nonexistent is None



# Generated at 2022-06-24 05:05:32.012778
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir._path == os.environ.get('XDG_CONFIG_HOME', '~/.config') + "/thefuck"
    assert settings.rules == ['git_push', 'git_amend', 'git_add', 'git', 'sudo', 'pip', 'python', 'ruby', 'cd', 'brew', 'perl', 'apt-get', 'docker', 'javac', 'man', 'npm', 'cabal', 'php']
    assert settings.history_limit == None
    assert settings.wait_command == 3
    assert settings.no_colors == False
    assert settings.require_confirmation == True
    assert settings.wait_slow_command == 15
    assert settings.priority == {}
    assert settings.debug == False
    assert settings.exclude_rules == []

# Generated at 2022-06-24 05:05:34.479224
# Unit test for constructor of class Settings
def test_Settings():
    assert 'rules' in settings
    assert 'alter_history' in settings
    assert 'debug' in settings
    assert 'require_confirmation' in settings


# Generated at 2022-06-24 05:05:42.672718
# Unit test for method init of class Settings
def test_Settings_init():
    from .config import langs

    temp_dir = Path(__file__).parent.joinpath('test')
    user_dir = temp_dir.joinpath('user_dir')
    user_dir.mkdir(parents=True)
    settings.user_dir = user_dir

    xdg_config_home = temp_dir.joinpath('xcg')
    os.environ['XDG_CONFIG_HOME'] = text_type(xdg_config_home)

    user_dir_path = settings._get_user_dir_path()
    assert user_dir_path == temp_dir.joinpath('xcg', 'thefuck')

    # Setup initial user directory
    settings._setup_user_dir()

    # Create initial settings file
    settings_path = settings.user_dir.joinpath('settings.py')

# Generated at 2022-06-24 05:05:46.619016
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['require_confirmation'] == True
    assert settings['use_colors'] == True
    assert settings['wait_slow_command'] == 15
    assert settings['rules'] == []
    assert settings['exclude_rules'] == []
    assert settings['wait_command'] == 3
    assert settings['alter_history'] == True
    assert settings['no_colors'] == False
    assert settings['debug'] == False
    assert settings['exclude_search_path_prefixes'] == []
    assert settings['repeat'] == False
    assert settings['priority'] == {}
    assert settings['history_limit'] == 0
    assert settings['slow_commands'] == []
    assert settings['instant_mode'] == False


# Generated at 2022-06-24 05:05:48.094134
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = 1
    assert settings.test == 1


# Generated at 2022-06-24 05:05:50.946121
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    tmp_settings = Settings(const.DEFAULT_SETTINGS)
    assert tmp_settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']



# Generated at 2022-06-24 05:06:01.565639
# Unit test for method init of class Settings
def test_Settings_init():
    # Arrange
    from tempfile import mkdtemp
    from shutil import rmtree
    from .utils import create_settings_file

    base_dir = mkdtemp()
    settings_dir = mkdtemp(dir=base_dir)
    rules_dir = mkdtemp(dir=settings_dir)
    create_settings_file(settings_dir, 'rules', 'DEFAULT_RULES:git:npm')
    create_settings_file(rules_dir, 'git.py', const.RULE_TEMPLATE)
    os.environ['XDG_CONFIG_HOME'] = settings_dir
    os.environ['RULES'] = 'git'
    os.environ['EXCLUDED_SEARCH_PATH_PREFIXES'] = '/home'

# Generated at 2022-06-24 05:06:06.416793
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    import pytest
    from .system import Path
    from .utils import get_all_commands

    settings = Settings()
    settings.init()
    assert settings.get('__getattr__')

    settings = Settings()
    settings.init()
    assert settings.__getattr__('__getattr__')

    settings = Settings()
    settings.init()
    assert settings.get('require_confirmation')

    settings = Settings()
    settings.init()
    assert settings.__getattr__('require_confirmation')



# Generated at 2022-06-24 05:06:09.012495
# Unit test for constructor of class Settings
def test_Settings():
    import pytest
    new_settings = Settings(const.DEFAULT_SETTINGS)
    assert new_settings is not settings
    assert new_settings._settings_from_args(None) == {}
    assert new_settings._settings_from_env() == {}
    new_settings.init()
    assert new_settings.get('rules') == const.DEFAULT_RULES



# Generated at 2022-06-24 05:06:12.059297
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']
    assert settings['require_confirmation'] == const.DEFAULT_SETTINGS['require_confirmation']


# Generated at 2022-06-24 05:06:19.762761
# Unit test for constructor of class Settings
def test_Settings():
    from .logs import capture_log

    with capture_log() as logs:
        user_dir = settings._get_user_dir_path()
        assert not user_dir.is_dir()
        settings._setup_user_dir()
        assert user_dir.is_dir()
        settings._init_settings_file()
        assert user_dir.joinpath('settings.py').is_file()
        assert len(logs) == 1
        # TODO: Test init with args
    assert settings.user_dir == user_dir
    settings['fuck'] = 'shit'
    assert settings.fuck == 'shit'



# Generated at 2022-06-24 05:06:23.028905
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['confirm_exit'] == const.DEFAULT_SETTINGS['confirm_exit']
    assert settings.confirm_exit == const.DEFAULT_SETTINGS['confirm_exit']


# Generated at 2022-06-24 05:06:26.793462
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert settings.no_colors is False
    assert settings.priority == const.DEFAULT_PRIORITY
    assert settings.alias == const.DEFAULT_ALIAS
    assert not hasattr(settings, 'attribute_not_defined')



# Generated at 2022-06-24 05:06:28.887958
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == True
    assert settings.repeat == False


# Generated at 2022-06-24 05:06:31.138296
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.__setattr__('a', 1)
    assert settings['a'] == 1



# Generated at 2022-06-24 05:06:32.676654
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    st = Settings()
    st.key = 'value'
    assert st['key'] == 'value'


# Generated at 2022-06-24 05:06:34.230904
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.new_attribute = 'value'
    assert settings['new_attribute'] == 'value'

# Generated at 2022-06-24 05:06:42.462977
# Unit test for method init of class Settings
def test_Settings_init():
    """Test method init of class Settings"""
    from .logs import exception
    from .shells import Shell

    orig_exception = exception
    orig_sys_exit = sys.exit
    orig_const = {
        'ENV_TO_ATTR': const.ENV_TO_ATTR,
        'DEFAULT_SETTINGS': const.DEFAULT_SETTINGS}
    orig_load_source = load_source
    orig_environ = os.environ.get('TF_ARGS', None)
    orig_shell = Shell.from_shell()

    sys.exit = lambda: 0
    exception = lambda *args, **kwargs: 0
    load_source = lambda *args, **kwargs: 0
    os.environ['TF_ARGS'] = ''

    # Test the case init raises exception when calling _settings

# Generated at 2022-06-24 05:06:44.985055
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    args = ''
    settings.init(args)

test_Settings_init()

# Generated at 2022-06-24 05:06:47.995167
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # First check that the test is correct
    settings.foo = 'bar'
    assert settings['foo'] == 'bar'
    del settings['foo']


# Generated at 2022-06-24 05:06:51.648280
# Unit test for constructor of class Settings
def test_Settings():
    import mock
    with mock.patch.object(sys.modules['__main__'], '__file__', '/'):
        settings.init()
    assert settings['require_confirmation']
    assert settings['repeat'] is True
    assert settings['debug'] is False


# Generated at 2022-06-24 05:07:00.999177
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    import shutil
    import os
    import sys

    from .logs import log_exception

    from .const import SETTINGS_HEADER, DEFAULT_SETTINGS, ENV_TO_ATTR

    from .settings import Settings


# Generated at 2022-06-24 05:07:02.338801
# Unit test for constructor of class Settings

# Generated at 2022-06-24 05:07:05.621306
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.history_limit == 20

# Generated at 2022-06-24 05:07:08.359497
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import Logger

    settings = Settings(const.DEFAULT_SETTINGS)
    logger = Logger()
    settings.init()
    print(settings)


if __name__ == '__main__':
    test_Settings_init()

# Generated at 2022-06-24 05:07:13.047080
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

    assert set(settings.keys()) == set(const.DEFAULT_SETTINGS.keys())
    assert settings.user_dir == Path(settings._get_user_dir_path())
    assert settings.user_dir.joinpath('settings.py').is_file()



# Generated at 2022-06-24 05:07:23.641460
# Unit test for method init of class Settings
def test_Settings_init():
    from tests.tools import mock, patch

    settings_path = Path('path/to/settings.py')
    user_dir = Path('~/user-dir').expanduser()
    settings_file = u'# {} = {}\n'.format(*const.DEFAULT_SETTINGS.items()[0])

    with patch('thefuck.conf.Settings._get_user_dir_path',
               mock.Mock(return_value=user_dir)):
        with patch('thefuck.conf.load_source',
                   mock.Mock(return_value={})):
            with patch('thefuck.conf.Path.open',
                       mock.mock_open(read_data=settings_file)) as mock_open:
                settings.init()
                mock_open.assert_called_with(mode='w')
                mock_

# Generated at 2022-06-24 05:07:27.644953
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.test_key = 'test_value'
    assert settings.test_key == 'test_value'


# Generated at 2022-06-24 05:07:29.298859
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.__setattr__('key', 'value')
    assert settings['key'] == 'value'



# Generated at 2022-06-24 05:07:31.326363
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings({})

    settings.__setattr__('foo', 'bar')
    assert settings['foo'] == 'bar'

# Generated at 2022-06-24 05:07:34.756766
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # Initialize an object for handling settings
    s = Settings(const.DEFAULT_SETTINGS)
    s.init()

    # set an attribute and get the attribute
    s.key = 'value'
    assert s.key == 'value'

# Generated at 2022-06-24 05:07:45.238977
# Unit test for constructor of class Settings
def test_Settings():
    assert(settings.rules == ['cd_parent'])
    assert(settings.exclude_rules == [])
    assert(settings.priorities == {})
    assert(settings.require_confirmation == True)
    assert(settings.history_limit == None)
    assert(settings.wait_slow_command == 1)
    assert(settings.wait_command == 0)
    assert(settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant'])
    assert(settings.no_colors == False)
    assert(settings.debug == False)
    assert(settings.alter_history == True)
    assert(settings.instant_mode == False)
    assert(settings.excluded_search_path_prefixes == ['/usr', '/private'])

# Generated at 2022-06-24 05:07:55.274738
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import TestingLogger
    from .main import main

    class Arg(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    settings.init(Arg(yes=True))

    assert settings.require_confirmation is False
    assert settings.debug is False
    assert settings.repeat is None

    logger = TestingLogger()
    main(Arg(logger=logger), settings)
    assert logger.warning_msg == "Config path {} is deprecated. Please move to {}".format(
        Path('~', '.thefuck').expanduser(), Path('~/.config', 'thefuck').expanduser())

    settings._init_settings_file()
    user_settings_file = settings.user_dir.joinpath('settings.py')

# Generated at 2022-06-24 05:07:56.693786
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.require_confirmation
    assert settings.rules == const.DEFAULT_RULES

# Generated at 2022-06-24 05:07:59.014301
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    assert settings == {}
    settings.a = 1
    assert settings == {'a': 1}


# Generated at 2022-06-24 05:08:00.382831
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()

# Generated at 2022-06-24 05:08:07.998617
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    import settings as mod

    user_dir = Path(tempfile.mkdtemp())
    os.environ['THEFUCK_RULE'] = 'testrule1:testrule2:testrule3'
    settings_path = user_dir.joinpath('settings.py')
    with settings_path.open(mode='w') as settings_file:
        settings_file.write(const.SETTINGS_HEADER)
        for setting in const.DEFAULT_SETTINGS.items():
            settings_file.write(u'# {} = {}\n'.format(*setting))


# Generated at 2022-06-24 05:08:11.487164
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    """
    Test cases for __getattr__ method of Settings class.

    """
    settings = Settings({'attr': 'attr_val'})
    assert "attr_val" == settings.attr
    assert None == settings.attr_none_val



# Generated at 2022-06-24 05:08:16.004431
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()

    assert settings.user_dir is not None
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.wait_command == 1
    assert settings.require_confirmation
    assert settings.rules == const.DEFAULT_RULES


# Generated at 2022-06-24 05:08:17.857238
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.binary_name == const.DEFAULT_SETTINGS['binary_name']



# Generated at 2022-06-24 05:08:26.241195
# Unit test for constructor of class Settings
def test_Settings():
    from .logs import exception
    import six

    test_settings = Settings(const.DEFAULT_SETTINGS)

    assert test_settings.get('rules') == const.DEFAULT_SETTINGS.get('rules')
    assert test_settings.get('exclude_rules') == const.DEFAULT_SETTINGS.get('exclude_rules')
    assert test_settings.get('priority') == const.DEFAULT_SETTINGS.get('priority')
    assert test_settings.get('wait_command') == const.DEFAULT_SETTINGS.get('wait_command')
    assert test_settings.get('require_confirmation') == const.DEFAULT_SETTINGS.get('require_confirmation')
    assert test_settings.get('history_limit') == const.DEFAULT_SETTINGS.get('history_limit')


# Generated at 2022-06-24 05:08:29.149939
# Unit test for method init of class Settings
def test_Settings_init():
    args = type('args', (object,), {'yes': True, 'repeat': True})
    settings = Settings(const.DEFAULT_SETTINGS)
    settings._get_user_dir_path = lambda: Path('/user/dir')
    settings.init(args=args)
    assert settings.require_confirmation is False

# Generated at 2022-06-24 05:08:29.841030
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.rules == const.DEFAULT_RULES

# Generated at 2022-06-24 05:08:35.120187
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings(const.DEFAULT_SETTINGS)
    a.update(a._settings_from_env())
    assert a['require_confirmation'] == False
    assert a['history_limit'] == 0

# Generated at 2022-06-24 05:08:37.490756
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    local_settings = Settings(debug=True)
    assert local_settings.get("debug") is True
    assert local_settings.debug is True


# Generated at 2022-06-24 05:08:38.328016
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation is True

# Generated at 2022-06-24 05:08:39.006317
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings._git_aliases = []
    assert settings.git_aliases == []

# Generated at 2022-06-24 05:08:40.804186
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.init()
    settings.test = 1
    assert settings.test == 1
    del settings.test



# Generated at 2022-06-24 05:08:51.733748
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import _logger
    from unittest import mock
    args = mock.Mock()
    settings.init(args)

    assert settings['debug'] == args.debug
    assert settings['repeat'] == args.repeat
    assert settings['require_confirmation'] == (not args.yes)
    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['exclude_rules'] == []
    assert settings['alter_history'] == True
    assert settings['no_colors'] == False
    assert settings['wait_command'] == 1
    assert settings['history_limit'] == 1000
    assert settings['wait_slow_command'] == 15
    assert settings['slow_commands'] == []
    assert settings['excluded_search_path_prefixes'] == []

# Generated at 2022-06-24 05:08:56.725590
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # Test normal attr set
    settings.set_by_setattr = 'foo'
    assert settings['set_by_setattr'] == 'foo'
    assert settings.set_by_setattr == 'foo'

    # Test overwrite
    settings.set_by_setattr = 'bar'
    assert settings['set_by_setattr'] == 'bar'
    assert settings.set_by_setattr == 'bar'


# Generated at 2022-06-24 05:08:57.770447
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

# Generated at 2022-06-24 05:09:02.186204
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.require_confirmation
    assert settings.no_colors
    settings.init(args=None)
    settings.init(args=None)
    assert settings.require_confirmation
    assert settings.no_colors
    assert settings.repeat == 1
    assert not settings.debug



# Generated at 2022-06-24 05:09:13.414808
# Unit test for constructor of class Settings
def test_Settings():
    import unittest
    import mock
    from collections import OrderedDict
    from .logs import exception
    original_user_dir = settings.user_dir # to restore original user_dir for tests

    class MockException(Exception): pass

    class Test(unittest.TestCase):
        def test_getattr(self):
            s = Settings(dict(a='b'))
            self.assertEqual(s.a, 'b')

        def test_setattr(self):
            s = Settings(dict(a='b'))
            s.c = 'd'
            self.assertEqual(s.c, 'd')


# Generated at 2022-06-24 05:09:23.560710
# Unit test for method init of class Settings
def test_Settings_init():
    """Unit test for method init of class Settings.

    It must:
    - read settings from file,
    - read settings from env and
    - read settings from args.
    """
    from mock import Mock, patch

    # Mocks for file settings
    mock_open = Mock()
    mock_open.return_value.__enter__ = lambda s: s
    mock_open.return_value.__exit__ = Mock()
    mock_open.return_value.write = Mock()
    mock_open.return_value.read.return_value = 'foo = 1'
    mock_open.return_value.read.return_value = 'bar = 1'
    mock_settings_from_file = Mock(return_value={'foo': 1,
                                                 'bar': 1})

    # Mocks for env settings
    mock_

# Generated at 2022-06-24 05:09:26.770726
# Unit test for method init of class Settings
def test_Settings_init():
    """
    test_Settings_init is a unit test of init function of the class Settings
    when args is not given
    """
    _settings = Settings(const.DEFAULT_SETTINGS)
    _settings.init()
    assert _settings == const.DEFAULT_SETTINGS

if __name__ == '__main__':
    test_Settings_init()

# Generated at 2022-06-24 05:09:28.001189
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']


# Generated at 2022-06-24 05:09:32.370037
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir.endswith('thefuck')
    assert 'DEFAULT_RULES' in settings['rules']
    assert 'require_confirmation' in settings
    assert 'DEBUG' not in settings
    assert settings['repeat'] == 1
    old_dir, settings.user_dir = settings.user_dir, '/non/existing/path'
    try:
        settings.init()
    except:
        raise AssertionError('Expected to init with default values')
    finally:
        settings.user_dir = old_dir

test_Settings_init()

# Generated at 2022-06-24 05:09:41.982018
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init(args=None)
    assert settings.user_dir == '/home/test'
    assert settings.rules == ['fool_rule']
    assert settings.exclude_rules == [
        'fool_exclude_rule', 'fool_exclude_rule1']
    assert settings.priority == {
        'all': 5,
        'fool_rule': 10,
        'fool_exclude_rule': 5}
    assert settings.require_confirmation is True
    assert settings.wait_command == 0
    assert settings.wait_slow_command == 30
    assert settings.slow_commands == ['fool_slow_command']
    assert settings.excluded_search_path_prefixes == [
        'fool_excluded_search_path_prefixes']

# Generated at 2022-06-24 05:09:43.914269
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.a = 1
    assert settings['a'] == 1
    assert settings.a == 1


# Generated at 2022-06-24 05:09:52.805387
# Unit test for constructor of class Settings
def test_Settings():
    # set up
    expected_result = {'wait_slow_command': 3, 'wait_command': 1, 'priority': {'correct_cd_command': 80}, 'history_limit': 100}
    # test
    test_settings = Settings(expected_result)
    # assert
    assert test_settings.wait_slow_command == expected_result['wait_slow_command']
    assert test_settings.wait_command == expected_result['wait_command']
    assert test_settings.priority['correct_cd_command'] == expected_result['priority']['correct_cd_command']
    assert test_settings.history_limit == expected_result['history_limit']

# test for init() and init_settings_file()

# Generated at 2022-06-24 05:09:57.453950
# Unit test for constructor of class Settings
def test_Settings():
    default_settings = Settings(const.DEFAULT_SETTINGS)
    assert default_settings['rules'] == const.DEFAULT_RULES
    assert default_settings.require_confirmation is True
    assert default_settings.history_limit == 0
    assert default_settings.wait_command == 1
    assert default_settings.no_colors is False