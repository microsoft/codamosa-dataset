

# Generated at 2022-06-24 05:00:03.489893
# Unit test for method init of class Settings
def test_Settings_init():
    _settings = Settings(const.DEFAULT_SETTINGS)
    _settings.init()
    assert _settings.user_dir == Path('./resources')
    assert _settings['rules'] == const.DEFAULT_RULES
    assert _settings['exclude_rules'] == ()
    os.environ['THEFUCK_RULES'] = ':'.join(['sudo', 'git'])
    _settings.init()
    assert _settings['rules'] == ['sudo', 'git']


# Generated at 2022-06-24 05:00:10.066065
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from thefuck.shells import Bash
    from thefuck.types import Settings as SettingsType
    from .types import NoSuchCommand
    s = Settings()
    s.shell = Bash()
    assert isinstance(s, dict)
    assert isinstance(s, SettingsType)
    assert s.shell is not None
    s.shell.get_command_from_history.side_effect = NoSuchCommand()
    assert s.shell.get_command_from_history() is None


# Generated at 2022-06-24 05:00:19.669192
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.rules == const.DEFAULT_RULES and\
    settings.priority == const.DEFAULT_PRIORITY and\
    settings.wait_command == 3 and\
    settings.history_limit == None and\
    settings.no_colors == False and\
    settings.require_confirmation == True and\
    settings.wait_slow_command == 15 and\
    settings.require_delay == False and\
    settings.repeat == 1 and\
    settings.instant_mode == False and\
    settings.num_close_matches == 3 and\
    settings.alter_history == True and\
    settings.debug == False and\
    settings.slow_commands == ['(?i)vagrant'] and\
    settings.excluded_search_path_prefixes == [] and\
    settings.exclude

# Generated at 2022-06-24 05:00:24.084025
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    os.environ['TF_ALTER_HISTORY'] = 'True'
    os.environ['TF_PRIORITY'] = 'brew=100:brew_cask=100:pip=100:bower=100:npm=100'
    os.environ['TF_RULES'] = 'DEFAULT_RULES:brew:brew_cask:pip:bower:npm'
    os.environ['TF_EXCLUDE_RULES'] = 'brew_cask:bower'
    os.environ['TF_NO_COLORS'] = 'True'
    os.environ['TF_HISTORY_LIMIT'] = '42'
    os.environ['TF_WAIT_COMMAND'] = '2'

# Generated at 2022-06-24 05:00:34.555355
# Unit test for constructor of class Settings

# Generated at 2022-06-24 05:00:37.973634
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    my_settings = Settings()
    my_settings.my_var_0 = "value_0"
    assert my_settings['my_var_0'] == "value_0"


# Generated at 2022-06-24 05:00:39.357257
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.foo = 'bar'
    assert settings['foo'] == 'bar'



# Generated at 2022-06-24 05:00:42.092328
# Unit test for constructor of class Settings
def test_Settings():
    settings.init()
    assert settings['slow_commands'] == ['lein', 'rails']
    assert settings['require_confirmation'] == True
    assert settings['history_limit'] == None

# Generated at 2022-06-24 05:00:43.118082
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.python == 'python'


# Generated at 2022-06-24 05:00:46.773928
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == True


# Generated at 2022-06-24 05:00:49.770278
# Unit test for constructor of class Settings
def test_Settings():
    _settings = Settings(const.DEFAULT_SETTINGS)
    _settings.init()
    assert _settings['history_limit'] == 10
    assert _settings['require_confirmation'] == True



# Generated at 2022-06-24 05:00:52.381330
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == False
    assert settings.correct_all == False
    assert settings.enabled == True
    assert settings.rules == []


# Generated at 2022-06-24 05:01:02.356864
# Unit test for method init of class Settings
def test_Settings_init():
    # User dir exists and the settings.py config file is created
    import tempfile
    from distutils.version import LooseVersion
    from thefuck.const import __version__
    from .system import Path

    _settings = Settings(const.DEFAULT_SETTINGS)
    _settings._get_user_dir_path = lambda: Path(tempfile.mkdtemp())

    _settings.init()

    # Assert the settings.py config file is created
    assert Path(_settings.user_dir, 'settings.py').is_file()

    # Assert that the generated config file starts with the right content
    with Path(_settings.user_dir, 'settings.py').open() as f:
        assert f.read().startswith(const.SETTINGS_HEADER)

    # Assert that the config file is updated with new (default

# Generated at 2022-06-24 05:01:07.848252
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings({"leader":"wangliang", "age":20})
    assert test_settings["leader"] == "wangliang"
    assert test_settings["age"] == 20
    assert test_settings.leader == "wangliang"
    assert test_settings.age == 20


# Generated at 2022-06-24 05:01:09.279397
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    """Should get value from settings."""
    settings['key'] = 'value'
    assert settings.key == 'value'


# Generated at 2022-06-24 05:01:15.151296
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings = Settings(const.DEFAULT_SETTINGS)
    # set default_settings
    settings.init()
    assert settings['require_confirmation']
    assert settings['repeat'] == 3
    assert settings['wait_slow_command'] == 9
    assert settings['wait_command'] == 3

    # set settings from args
    settings.init(args=type('args', (object,), {'yes': True, 'debug': True, 'repeat': 4}))
    assert not settings['require_confirmation']
    assert settings['repeat'] == 4
    assert settings['debug']

    # set settings from env
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'False'
    os.environ['THEFUCK_DEBUG'] = 'True'

# Generated at 2022-06-24 05:01:16.759742
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.foo = 1
    assert settings.foo == 1


# Generated at 2022-06-24 05:01:18.466356
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.hello = 'world'
    assert not settings.get('hello') == None


# Generated at 2022-06-24 05:01:26.066025
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .rules import (base,
                        repeat,
                        git_dirty_worktree,
                        git_commited)

    expected_default_settings = const.DEFAULT_SETTINGS
    expected_default_settings['require_confirmation'] = True
    expected_default_settings['rules'] = [base.BaseRule,
                                          git_dirty_worktree.GitDirtyWorktreeRule,
                                          git_commited.GitCommitedRule,
                                          repeat.RepeatRule,
                                          ]

    expected_default_settings['exclude_rules'] = []
    expected_default_settings['history_limit'] = None
    expected_default_settings['priority'] = {}
    expected_default_settings['no_colors'] = False

# Generated at 2022-06-24 05:01:29.734600
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.num_close_matches == 4
    assert settings.__getattr__('history_limit') == None
    assert settings.__dict__ == {'num_close_matches': 4, 'history_limit': None}


# Generated at 2022-06-24 05:01:37.890552
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings(const.DEFAULT_SETTINGS)
    assert settings_test.get("alter_history") is True
    assert settings_test.get("no_colors") is False 
    assert settings_test.get("wait_command") == 0
    assert settings_test.get("wait_slow_command") == 3
    assert settings_test.get("require_confirmation") is True
    assert settings_test.get("slow_commands") == ["(?i)^python -m easy_install"]
    assert settings_test.get("excluded_search_path_prefixes") == []
    assert settings_test.get("priority") == {}
    assert settings_test.get("debug") is False


# Generated at 2022-06-24 05:01:39.350259
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    assert test_settings.rules == const.DEFAULT_SETTINGS['rules']


# Generated at 2022-06-24 05:01:45.607615
# Unit test for method init of class Settings
def test_Settings_init():
    s = Settings()
    s.init()
    d = {}
    d.update(const.DEFAULT_SETTINGS)
    d['user_dir'] = Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    d['history_limit'] = 10
    d['require_confirmation'] = True
    d['no_colors'] = False
    d['wait_command'] = 0.5
    d['repeat'] = True
    d['wait_slow_command'] = 10
    d['alter_history'] = False
    d['num_close_matches'] = 3
    d['instant_mode'] = True
    assert d == s

# Generated at 2022-06-24 05:01:50.052525
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.require_confirmation == True
    settings.init()

# Generated at 2022-06-24 05:01:51.212423
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    a = {'test': 1}
    s = Settings(a)
    assert s.test == a['test']

# Generated at 2022-06-24 05:01:53.160136
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # given
    settings = Settings()

    # when
    settings.foo = 'bar'

    # then
    assert settings._Settings__dict['foo'] == 'bar'


# Generated at 2022-06-24 05:02:04.105767
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch

    class MockSettings:
        pass

    mocks = MockSettings()
    mocks.settings = MockSettings()
    args = MockSettings()
    args.yes = True
    args.debug = True
    args.repeat = True

    with patch('thefuck.conf.settings', mocks.settings):
        with patch('thefuck.conf.settings._settings_from_args', return_value={}):
            with patch('thefuck.conf.settings._settings_from_env', return_value={'require_confirmation': False}):
                with patch('thefuck.conf.settings._settings_from_file', return_value={'alter_history': False}):
                    with patch('thefuck.conf.settings._setup_user_dir', return_value=None):
                        settings.init(args)

    assert mocks

# Generated at 2022-06-24 05:02:08.176669
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    try:
        settings.key = 'val'
        assert settings['key'] == 'val', settings['key']
    except:
        raise AssertionError


# Generated at 2022-06-24 05:02:09.658305
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.no_colors == const.DEFAULT_SETTINGS['no_colors']



# Generated at 2022-06-24 05:02:14.742648
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    import sys
    sys.modules['thefuck.settings'] = sys.modules['thefuck']
    from thefuck.settings import Settings

    settings = Settings({'test': 'Settings'})
    settings.test = 'Settings setattr'
    assert settings.test == 'Settings setattr'


# Generated at 2022-06-24 05:02:16.699889
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.attr = 'attr_value'
    assert settings['attr'] == 'attr_value'



# Generated at 2022-06-24 05:02:21.194732
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.get("slow_commands") == [
        'vagrant', 'git commit', 'lein', 'hg push', 'hg pull']
    settings.slow_commands = ['vagrant', 'lein']
    assert settings.get("slow_commands") == ['vagrant', 'lein']


# Generated at 2022-06-24 05:02:25.442653
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['command_not_found'] == 'zsh'
    assert settings['history_limit'] == 500
    assert settings['require_confirmation']
    assert settings['alternative_cd']
    assert settings['wait_slow_command'] == 7



# Generated at 2022-06-24 05:02:32.552434
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

    assert 'require_confirmation' in settings
    assert 'rules' in settings
    assert 'priority' in settings
    assert 'debug' in settings
    assert 'exclude_rules' in settings
    assert 'no_colors' in settings
    assert 'wait_command' in settings
    assert 'slow_commands' in settings
    assert 'alter_history' in settings
    assert 'excluded_search_path_prefixes' in settings
    assert 'priority' in settings
    assert 'history_limit' in settings
    assert 'wait_slow_command' in settings
    assert 'num_close_matches' in settings
    assert 'instant_mode' in settings



# Generated at 2022-06-24 05:02:34.154369
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.require_confirmation
    settings.require_confirmation = False
    assert settings.require_confirmation == False


# Generated at 2022-06-24 05:02:36.720609
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules


# Generated at 2022-06-24 05:02:37.813682
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation is True


# Generated at 2022-06-24 05:02:39.430817
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings['key'] = 'value'
    assert settings.key == 'value'
    assert settings.non_existing_key == None


# Generated at 2022-06-24 05:02:46.004683
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    from . import settings

    settings.init(args=None)
    assert settings.require_confirmation is True
    assert settings.no_colors is False
    assert settings.debug is False
    assert settings.wait_command == 3
    assert settings.history_limit == 9
    assert settings.wait_slow_command == 15
    assert settings.priority == {}
    assert settings.repeat is False
    assert settings.rules == []
    assert settings.exclude_rules == []
    assert settings.num_close_matches == 3
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'rebuild', 'go']
    assert settings.alter_history is False
    assert settings.excluded_search_path_prefixes == ['.', './']
    assert settings.instant_mode is False

# Generated at 2022-06-24 05:02:56.177767
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    def check_init(settings, file_content, env, args):
        """Check the settings given from a file, the environement and args."""
        with tempfile.NamedTemporaryFile('w') as settings_file:
            settings_file.write(file_content)
            settings_file.seek(0)
            settings.init(args)
            for key, value in env.items():
                assert settings[key] == value, 'setting {} should be {}'.format(key, value)

    check_init(settings,
               const.SETTINGS_HEADER + 'wait_command = 0\n',
               {'wait_command': 0},
               None)

# Generated at 2022-06-24 05:02:57.293615
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['require_confirmation'] is True
    assert settings['repeat'] is False

# Generated at 2022-06-24 05:03:01.167107
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    assert test_settings == settings


# Generated at 2022-06-24 05:03:03.701212
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings({'user_dir': '/usr/local/'})
    settings.__setattr__('key', 'value')
    assert settings.get('key') == 'value'


# Generated at 2022-06-24 05:03:12.258536
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    args = lambda x: type('', (object,), {'yes': '--yes' in x})(x)
    settings.reset(os)
    # Simulate exception when execute _init_settings_file
    with settings.user_dir.joinpath('settings.py').open(mode='w') as settings_file:
        settings_file.write('int(a)')
    with settings.user_dir.joinpath('settings.py').open(mode='r') as settings_file:
        exception.value = ''
        settings.init()
        assert exception.value == "Can't load settings from file (<unknown>, <unknown>, <unknown>)"
        exception.value = ''
        settings.init(args('--debug'))

# Generated at 2022-06-24 05:03:21.518879
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class SettingsTestObj(Settings):
        def __init__(self, a, b):
            self['a'] = a
            self['b'] = b

    ab_obj = SettingsTestObj(1, 2)
    assert ab_obj.a == 1
    assert ab_obj.b == 2
    ab_obj.c = 3
    assert ab_obj.c == 3
    assert isinstance(ab_obj, dict)
    assert ab_obj['a'] == 1
    assert ab_obj['b'] == 2
    assert ab_obj['c'] == 3
    assert set(ab_obj.values()) == set([1, 2, 3])


# Generated at 2022-06-24 05:03:24.966328
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    assert settings.key == None
    settings.key = 'value'
    assert settings.key == 'value'
    assert settings.get('key') == 'value'


# Generated at 2022-06-24 05:03:34.608078
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    settings.init()
    assert isinstance(settings.get('rules'), list)
    assert isinstance(settings.get('require_confirmation'), bool)
    assert isinstance(settings.get('slow_commands'), list)
    assert isinstance(settings.get('exclude_rules'), list)
    assert isinstance(settings.get('priority'), dict)
    assert isinstance(settings.get('history_limit'), int)
    assert isinstance(settings.get('wait_command'), int)
    assert isinstance(settings.get('wait_slow_command'), int)
    assert isinstance(settings.get('alter_history'), bool)
    assert isinstance(settings.get('no_colors'), bool)
    assert isinstance(settings.get('debug'), bool)

# Generated at 2022-06-24 05:03:36.206763
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()

# Generated at 2022-06-24 05:03:39.149482
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    global settings

    settings = Settings(a=0)

    assert settings.a == 0
    assert settings['a'] == 0
    assert settings.get('a') == 0
    assert settings.get('b') == None



# Generated at 2022-06-24 05:03:41.852509
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.clear()
    settings.test_key = 'test_val'
    assert settings['test_key'] == 'test_val'

# Generated at 2022-06-24 05:03:44.713007
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.temp = 1
    assert settings['temp'] == 1

# Generated at 2022-06-24 05:03:53.213657
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()

    # Unit test for _get_user_dir_path
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()

    # Unit test for _init_settings_file
    assert settings.user_dir.joinpath('settings.py').is_file()
    with settings.user_dir.joinpath('settings.py').open() as settings_file:
        header = settings_file.readline()
        assert header == '# -*- coding: utf-8 -*-\n'

        default_settings = settings_file.read().splitlines(False)

# Generated at 2022-06-24 05:03:56.085750
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.repeat == False

# Generated at 2022-06-24 05:03:58.834644
# Unit test for constructor of class Settings
def test_Settings():
    assert Settings().user_dir == Path(os.environ.get('XDG_CONFIG_HOME',
                                                      '~/.config'),
                                       'thefuck').expanduser()

# Generated at 2022-06-24 05:04:01.226956
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    x = Settings()
    x.set = 'set'
    assert x['set'] == 'set'

# Generated at 2022-06-24 05:04:06.613895
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings = Settings(const.DEFAULT_SETTINGS)

    settings.init(args=None)
    assert isinstance(settings['require_confirmation'], bool)

    settings.init(args=Namespace(yes=True))
    assert not settings['require_confirmation']

    settings.init(args=Namespace(debug=True))
    assert settings['debug']

    settings.init(args=Namespace(repeat=3))
    assert settings['repeat'] == 3


# Generated at 2022-06-24 05:04:08.247359
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.wait_slow_command == 3
    assert settings.MAX_HISTORY == 200


# Generated at 2022-06-24 05:04:13.098158
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    settings.init({'yes': True, 'debug': True, 'repeat': 1})

    assert settings['require_confirmation'] == False
    assert settings['debug'] == True
    assert settings['repeat'] == 1

# Generated at 2022-06-24 05:04:17.009615
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class MySettings(Settings):
        pass
    s = MySettings()
    s.key = 'value'
    assert s['key'] == 'value'
    assert s.key == 'value'



# Generated at 2022-06-24 05:04:26.604559
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings['require_confirmation'] == const.DEFAULT_SETTINGS['require_confirmation']
    assert settings['rules']              == const.DEFAULT_RULES

    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'False'
    os.environ['THEFUCK_HISTORY_LIMIT']        = '1'
    settings.init()
    assert settings['require_confirmation'] == False
    assert settings['history_limit']        == 1
    assert settings['rules']                == const.DEFAULT_RULES

    os.environ['THEFUCK_RULES']         = 'DEFAULT_RULES:bash'
    os.environ['THEFUCK_EXCLUDE_RULES'] = 'bash'
    settings.init()
   

# Generated at 2022-06-24 05:04:31.344415
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # It should return the attribute value when we get it.
    assert settings.__dict__ == {}

    # It should assign the attribute when we set it.
    settings.__setattr__('__test_key__', "__test_value__")
    assert settings['__test_key__'] == "__test_value__"
    assert settings.__dict__ == {'__test_key__': "__test_value__"}



# Generated at 2022-06-24 05:04:37.630329
# Unit test for constructor of class Settings
def test_Settings():
    assert settings._get_user_dir_path() == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.alter_history == True
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.require_confirmation == True
    assert settings.rules == ['fuck_alias']
    assert settings.slow_commands == []
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.history_limit == None
    assert settings.num_close_matches == 3
    assert settings.priority == {}
    assert settings.repeat == False
    assert settings.debug == False

# Generated at 2022-06-24 05:04:40.368656
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.fuck_onload_error
    assert settings.wait_command
    assert settings.command_not_found
    assert hasattr(settings, 'rules')
    assert hasattr(settings, 'alter_history')

# Generated at 2022-06-24 05:04:52.303719
# Unit test for method init of class Settings
def test_Settings_init():
    old_environ = os.environ
    old_user_dir = settings.user_dir

# Generated at 2022-06-24 05:04:53.760996
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.help_command == const.DEFAULT_SETTINGS['help_command']


# Generated at 2022-06-24 05:04:54.294609
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

# Generated at 2022-06-24 05:04:56.252662
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    global settings
    settings = Settings()

    settings.attributes = 'attributes_value'
    assert settings['attributes'] == 'attributes_value'


# Generated at 2022-06-24 05:05:05.837396
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

# Generated at 2022-06-24 05:05:10.619984
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings({'_test': 1})
    assert test_settings.get('_test') == 1
    setattr(test_settings, '_test', 2)
    assert test_settings.get('_test') == 2
    # Test to verify that the value is not overriden
    setattr(test_settings, '_test', 3)
    assert test_settings.get('_test') == 3

# Generated at 2022-06-24 05:05:13.807997
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.get('require_confirmation') == True
    assert settings.get('wait_command') == 3
    assert settings.get('history_limit') == None



# Generated at 2022-06-24 05:05:17.660474
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    s = Settings({"a": 1})
    assert s.a == 1
    assert s.get("a") == 1
    assert s["a"] == 1
    assert s.b is None
    assert s.get("b") is None
    assert s["b"] is None



# Generated at 2022-06-24 05:05:19.653049
# Unit test for method init of class Settings
def test_Settings_init():
    settings.update({'require_confirmation': True})
    settings.init(Mock())
    assert settings.get('require_confirmation') == False




# Generated at 2022-06-24 05:05:20.421651
# Unit test for method init of class Settings
def test_Settings_init():
    # TODO: implement
    assert False

# Generated at 2022-06-24 05:05:21.985197
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings['require_confirmation'] == True



# Generated at 2022-06-24 05:05:23.626381
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['require_confirmation'] is True
    assert settings['wait_command'] == 2
    assert type(settings['rules']) == list

# Generated at 2022-06-24 05:05:26.834767
# Unit test for constructor of class Settings
def test_Settings():
    var = Settings(const.DEFAULT_SETTINGS)
    assert(var.get('require_confirmation') == True)


# Generated at 2022-06-24 05:05:37.396137
# Unit test for constructor of class Settings
def test_Settings():
    from .logs import exception
    from .tests.utils import Command
    from os import environ
    environ['THEFUCK_WAIT_COMMAND'] = '123'

    s = Settings(const.DEFAULT_SETTINGS)
    s.init()
    assert s.user_dir == Path('~/.config/thefuck').expanduser()
    assert s.rules == const.DEFAULT_RULES
    assert s.exclude_rules == []
    assert s.priority == {}
    assert s.wait_command == 2
    assert s.wait_slow_command == 15
    assert s.alter_history == True
    assert s.history_limit == None
    assert s.no_colors == False
    assert s.require_confirmation == True
    assert s.wait_command == 2

# Generated at 2022-06-24 05:05:39.724663
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings({'A': 0})
    settings.__setattr__('A', 1)
    assert settings['A'] == 1



# Generated at 2022-06-24 05:05:41.994600
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, dict)
    assert isinstance(settings, Settings)
    for key in const.DEFAULT_SETTINGS.keys():
        assert getattr(settings,key) == const.DEFAULT_SETTINGS[key]


# Generated at 2022-06-24 05:05:49.335839
# Unit test for constructor of class Settings
def test_Settings():
    settings_from_default_settings = Settings(const.DEFAULT_SETTINGS)
    keys = list(const.DEFAULT_SETTINGS.keys())
    Settings_from_default_settings_keys = list(settings_from_default_settings.keys())
    assert keys == Settings_from_default_settings_keys
    for k, v in const.DEFAULT_SETTINGS.items():
        assert settings_from_default_settings[k] == v
    assert settings_from_default_settings.get('require_confirmation') == const.DEFAULT_SETTINGS['require_confirmation']
    assert settings_from_default_settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']
    settings_from_default_settings.require_confirmation = False
    assert settings_from_default_settings.require

# Generated at 2022-06-24 05:05:52.584564
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']
    assert settings.require_confirmation != const.DEFAULT_SETTINGS['repeat']


# Generated at 2022-06-24 05:05:55.371700
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules == const.DEFAULT_RULES


# Generated at 2022-06-24 05:05:57.069046
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.repeat = 2
    assert settings.repeat == 2

# Generated at 2022-06-24 05:06:07.014731
# Unit test for method init of class Settings
def test_Settings_init():
    from unittest.mock import patch
    from unittest import TestCase

    class MockSystem:
        def __init__(self, user_dir_path, settings_file_path,
                     settings_file_content, env_dict, args_dict,
                     settings_file_loaded_dict, settings_from_env_dict,
                     settings_from_args_dict):
            self.user_dir_path = user_dir_path
            self.settings_file_path = settings_file_path
            self.settings_file_content = settings_file_content
            self.env_dict = env_dict
            self.args_dict = args_dict
            self.settings_file_loaded_dict = settings_file_loaded_dict
            self.settings_from_env_dict = settings_from_env_dict

# Generated at 2022-06-24 05:06:17.334003
# Unit test for constructor of class Settings
def test_Settings():
    # When user config file doesn't exist and legacy '~/.thefuck/' directory is empty
    if not settings._get_user_dir_path().joinpath('settings.py').is_file() and\
        not settings._get_user_dir_path().joinpath('rules').is_dir():
            settings.init()
            assert not settings._get_user_dir_path().joinpath('settings.py').is_file()\
                and not settings._get_user_dir_path().joinpath('rules').is_dir()

    # When user config file and legacy '~/.thefuck/' directory are empty

# Generated at 2022-06-24 05:06:18.551207
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings == const.DEFAULT_SETTINGS


# Generated at 2022-06-24 05:06:28.248100
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation is True
    assert settings.require_confirmation_history is False
    assert settings.no_colors is False
    assert settings.wait_slow_command is 5
    assert settings.wait_command is 1
    assert settings.history_limit is 1000
    assert settings.alter_history is True
    assert settings.instant_mode is False
    assert settings.repeat is True

# Generated at 2022-06-24 05:06:32.132480
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings_test = Settings(const.DEFAULT_SETTINGS)
    settings_test.test_key = 'test_value'
    assert settings_test['test_key'] == 'test_value'
    assert settings_test.test_key == 'test_value'

# Generated at 2022-06-24 05:06:40.511339
# Unit test for method init of class Settings
def test_Settings_init():
    # Given
    class Args:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    args = Args(yes=True, debug=True, repeat=True)

    set_env = os.environ.copy()

# Generated at 2022-06-24 05:06:47.743404
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, dict)
    assert settings.rules == ['cd_parent', 'git_push', 'git_add', 'python_command', 'sudo']
    assert settings.alter_history == False
    assert settings.wait_slow_command == 3
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 0
    assert settings.debug == False
    assert settings.priority == {}
    assert settings.exclude_rules == []
    assert settings.history_limit == None
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'ios-deploy', 'carthage']
    assert settings.instant_mode == False
    assert settings.num_close_matches == 3

# Generated at 2022-06-24 05:06:49.134476
# Unit test for constructor of class Settings
def test_Settings():
    settings_1 = Settings()
    assert settings_1.user_dir == None
    settings_2 = Settings({'user_dir': 'test_dir'})
    assert settings_2.user_dir == 'test_dir'

# Generated at 2022-06-24 05:06:50.903562
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings['a'] = 'b'
    assert settings['a'] == 'b'


# Generated at 2022-06-24 05:06:53.921080
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.init()
    settings.__setattr__('slow_commands', 'hello')
    assert settings['slow_commands'] == 'hello'

# Generated at 2022-06-24 05:07:02.164935
# Unit test for method init of class Settings
def test_Settings_init():
    if sys.version_info < (3, 3):
        from mock import patch
        sys.modules['settings'] = type('settings', (), {'attrs': {}})
        with patch('thefuck.conf.Settings._settings_from_file',
                   return_value={'rules': ['some_rules']}) as settings_from_file, \
                patch('thefuck.conf.Settings._settings_from_env',
                      return_value={'rules': ['some_rules']}) as settings_from_env, \
                patch('thefuck.conf.Settings._settings_from_args',
                      return_value={'rules': ['some_rules']}) as settings_from_args:
            settings.init()
            assert settings['rules'] == ['some_rules']
            settings_from_file.assert_called_once_with()
            settings

# Generated at 2022-06-24 05:07:06.583360
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.a = 0
    assert settings['a'] == 0
    settings['a'] = 1
    assert settings.a == 1


# Generated at 2022-06-24 05:07:11.602903
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings_ = Settings(const.DEFAULT_SETTINGS)
    settings_.__setattr__('testing', '00')
    assert settings_.testing == "00"


# Generated at 2022-06-24 05:07:14.742334
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    from .logs import log
    log.debug('foo')  # Should be a pass


# Generated at 2022-06-24 05:07:18.081969
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    """Unit test for method __setattr__ of class Settings."""
    settings = Settings()
    settings.test = True
    assert settings['test'] is True



# Generated at 2022-06-24 05:07:19.541017
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings()
    assert settings.nonexistent_attribute == None


# Generated at 2022-06-24 05:07:21.382248
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.abracadabra = 42
    assert settings['abracadabra'] == 42


# Generated at 2022-06-24 05:07:22.667090
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = 'TEST'
    assert settings['test'] == 'TEST'

# Generated at 2022-06-24 05:07:29.824105
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    instance = settings
    _settings = {}
    keys = ["a","b"]
    values = ["a","b"]
    for key, value in zip(keys, values):
        _settings[key] = value
        instance.__setattr__(key, value)
        assert _settings[key] == instance.__getattr__(key)


# Generated at 2022-06-24 05:07:31.691160
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.attribute = 'value'
    assert settings.attribute == 'value'
    assert settings['attribute'] == 'value'


# Generated at 2022-06-24 05:07:32.830856
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert const.DEFAULT_SETTINGS['rules'] == settings.rules


# Generated at 2022-06-24 05:07:38.508022
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)

# Generated at 2022-06-24 05:07:41.393336
# Unit test for constructor of class Settings
def test_Settings():
    settings_in_const = dict(const.DEFAULT_SETTINGS)
    assert settings == settings_in_const


# Generated at 2022-06-24 05:07:43.744019
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('debug') == True



# Generated at 2022-06-24 05:07:54.220421
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import sys
    import tempfile
    from datetime import datetime
    from thefuck.conf.settings import Settings
    from thefuck.logs import log_exception, log_to_file, stop_log_to_file, log_to_file_path

    def get_settings():
        return {attr: getattr(settings, attr)
                for attr in const.DEFAULT_SETTINGS.keys()}

    # Save user env.
    orig_xdg_config_dir = os.environ.get('XDG_CONFIG_HOME')
    orig_xdg_config_dir_path = Path(orig_xdg_config_dir).expanduser() if orig_xdg_config_dir else None

    orig_settings = get_settings()


# Generated at 2022-06-24 05:07:57.111500
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    d = {'key': 'value'}
    settings = Settings(d)
    assert settings.key == 'value'


# Generated at 2022-06-24 05:08:00.504033
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    global settings
    settings = Settings({'a': 1})
    assert settings.a == 1
    assert settings['a'] == 1
    settings.b = 2
    assert settings.b == 2
    assert settings['b'] == 2


# Generated at 2022-06-24 05:08:11.454111
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from .rules import RulesCollection
    from .rules.export_aliases import export_aliases, get_all_aliases
    from .shells import shell
    from .types import Command

    alias = 'test_alias'
    shell_command = 'alias {}=test_command'.format(alias)
    shell_command_2 = 'alias {}=test_command_2'.format(alias)
    test_command = Command('test', '', '', '', '', time.time())
    test_command_2 = Command('test', '', '', '', '', time.time())


# Generated at 2022-06-24 05:08:19.130231
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert const.DEFAULT_SETTINGS.keys() == settings.keys()

    const.DEFAULT_SETTINGS['new_key'] = 'new_value'
    settings.init()
    assert const.DEFAULT_SETTINGS.keys() == settings.keys()

    assert settings.user_dir == Path('~/.thefuck').expanduser()



# Generated at 2022-06-24 05:08:20.651715
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.__getattr__('require_confirmation') == True


# Generated at 2022-06-24 05:08:23.398802
# Unit test for constructor of class Settings
def test_Settings():
    test_Settings = Settings({"test": 1})
    assert test_Settings["test"] == 1
    test_Settings.update({"test":2})
    assert test_Settings.test == 2
    test_Settings.init()

# Generated at 2022-06-24 05:08:35.433359
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings(const.DEFAULT_SETTINGS)
    settings_test.init()
    import os
    settings_test['wait_command'] = float(os.environ.get('THEFUCK_WAIT_COMMAND'))
    settings_test['wait_slow_command'] = float(os.environ.get('THEFUCK_WAIT_SLOW_COMMAND'))
    settings_test['history_limit'] = int(os.environ.get('THEFUCK_HISTORY_LIMIT'))
    settings_test['require_confirmation'] = bool(os.environ.get('THEFUCK_REQUIRE_CONFIRMATION') == 'True')

# Generated at 2022-06-24 05:08:43.966552
# Unit test for constructor of class Settings
def test_Settings():
    # Test for setting up user config dir.
    user_dir = Path('~', '.thefuck').expanduser()
    settings._setup_user_dir = lambda: user_dir
    settings._settings_from_file = lambda: {'test': 'settings'}
    settings._settings_from_env = lambda: {'test': 'env'}
    settings._settings_from_args = lambda: {'test': 'args'}

    if user_dir.is_dir():
        warn(u'Config path {} is deprecated.'.format(user_dir))
    assert settings.init().get('test') == 'args'
    assert settings.user_dir == user_dir

    # Test for setting up user config dir using XDG_CONFIG_HOME.
    old_user_dir = user_dir
    xdg_config_home

# Generated at 2022-06-24 05:08:48.457102
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # 1.
    settings.init()

    # 2.
    settings.clear()
    assert settings == {}

    # 3.
    settings.wait_slow_command = 3
    assert settings.wait_slow_command == 3

    # 4.
    settings.wait_slow_command = '3'
    assert settings.wait_slow_command == '3'

# Generated at 2022-06-24 05:08:52.255926
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    global settings
    new_settings = Settings()

    # Test 1:
    new_settings.__setattr__('debug', True)
    assert new_settings['debug']

    # Test 2:
    new_settings.debug = False
    assert not new_settings['debug']

    settings = new_settings


# Generated at 2022-06-24 05:08:53.683278
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.attr = 'Attribute'
    assert settings['attr'] == 'Attribute'


# Generated at 2022-06-24 05:08:57.674134
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['require_confirmation'] == const.DEFAULT_SETTINGS['require_confirmation']
    assert settings['rules'] == const.DEFAULT_SETTINGS['rules']
    assert settings['no_colors'] == const.DEFAULT_SETTINGS['no_colors']

# Generated at 2022-06-24 05:08:59.504376
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = 123
    assert settings.test == 123


# Generated at 2022-06-24 05:09:07.871598
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.require_confirmation == True
    assert settings.env == {u'LANG': u'en_US.UTF-8',
                            u'TERM': u'xterm-256color',
                            u'SHELL': u'/bin/bash',
                            u'TMUX': u'',
                            u'TERMINAL_EMULATOR': u'gnome-terminal'}
    assert settings.rules == ['fuck', 'git_push', 'ls', 'man', 'mvn', 'replace', 'sudo']
    assert settings.exclude_rules == []
    assert settings.exclude_commands == [u'sudo', u'git push']

# Generated at 2022-06-24 05:09:08.686381
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings is not None

# Generated at 2022-06-24 05:09:15.277818
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.user_dir.name == '.thefuck'

    # Call init() to init settings.py and user_dir
    settings.init()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.user_dir.name == '.config/thefuck'

    # Call init() again to suppress warning
    settings.init()

    settings_from_file = settings._settings_from_file()
    settings.init()
    settings_from_args = settings._settings_from_args(
        argparse.Namespace())
    settings_from_env = settings._settings_from_env()

    for key in const.DEFAULT_SETTINGS.keys():
        if key in settings_from_file:
            # settings from file
            assert settings[key] == settings_from_file[key]

# Generated at 2022-06-24 05:09:16.921441
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    print(settings.settings_module)
    assert settings.settings_module == 'thefuck.settings'

# Generated at 2022-06-24 05:09:21.535544
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test ==  1
    assert(settings["test"] == 1)

if __name__ == '__main__':
    test_Settings___setattr__()

# Generated at 2022-06-24 05:09:24.850891
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    class Settings(dict):
        def __getattr__(self, item):
            return self.get(item)

        def __setattr__(self, key, value):
            self[key] = value

    settings = Settings({'a': 1, 'b': 2})
    assert settings.a == 1
    assert settings.b == 2


# Generated at 2022-06-24 05:09:25.853021
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.__getattr__('require_confirmation') == False


# Generated at 2022-06-24 05:09:31.647530
# Unit test for method init of class Settings
def test_Settings_init():
    settings_file = const.SETTINGS_HEADER
    for key, value in const.DEFAULT_SETTINGS.items():
        settings_file += '# {} = {}\n'.format(key, value)
    with settings.user_dir.joinpath('settings.py').open('w') as settings_file:
        settings_file.write(settings_file)

    os.environ['THEFUCK_CONFIRM'] = 'false'
    os.environ['THEFUCK_TIMES'] = '1'

    settings.init()
    assert settings.repeat == 1
    assert settings.require_confirmation is False

    del os.environ['THEFUCK_CONFIRM']
    del os.environ['THEFUCK_TIMES']

# Generated at 2022-06-24 05:09:33.319031
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.foo = 1
    assert settings['foo'] == 1


# Generated at 2022-06-24 05:09:42.752381
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    class Test:
        def __init__(self):
            self.yes = False
            self.debug = False
            self.repeat = False
    test = Test()
    os.environ["THEFUCK_REQUIRE_CONFIRMATION"] = "True"
    os.environ["THEFUCK_DEBUG"] = "True"
    os.environ["THEFUCK_REPEAT"] = "2"
    os.environ["THEFUCK_ALIAS"] = "fuck"
    os.environ["THEFUCK_RULES"] = "DEFAULT_RULES:test_case"
    os.environ["THEFUCK_EXCLUDE_RULES"] = "test_case"
    os.environ["THEFUCK_WAIT_COMMAND"] = "120"
   

# Generated at 2022-06-24 05:09:44.311298
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.not_exist is None
    settings['exist'] = 1
    assert settings.exist == 1


# Generated at 2022-06-24 05:09:47.288338
# Unit test for method init of class Settings
def test_Settings_init():
    settings.update({"not_confirm_command": True,
                     "wait_command": 0,
                     "verbose": True,
                     "debug": True,
                     "help": True,
                     "yes": True})
    settings.init()


# Generated at 2022-06-24 05:09:48.422883
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.should_be_set = True
    assert settings.should_be_set == True



# Generated at 2022-06-24 05:09:52.940342
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    """Unit test for method __getattr__ of class Settings"""
    assert settings.rules == const.DEFAULT_SETTINGS['rules']


# Generated at 2022-06-24 05:09:54.801428
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == True
    assert settings.not_exist == None


# Generated at 2022-06-24 05:10:04.849795
# Unit test for method init of class Settings
def test_Settings_init():
    """Testing the initialization of Settings"""
    _settings = Settings(const.DEFAULT_SETTINGS)
    _settings.init()
    assert _settings['require_confirmation'] == True
    assert _settings['no_colors'] == False
    assert _settings['debug'] == False
    assert _settings['repeat'] == False
    assert _settings['wait_command'] == 1
    assert _settings['wait_slow_command'] == 15
    assert _settings['alter_history'] == True
    assert _settings['instant_mode'] == False
    assert _settings['rules'] == ['cp', 'ln', 'mv', 'python', 'python3']
    assert _settings['exclude_rules'] == []
    assert _settings['enabled_by_default'] == _settings['rules']
    assert _settings['require_confirmation'] == True
