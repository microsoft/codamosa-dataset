

# Generated at 2022-06-24 05:00:01.282130
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    attr = 'attribute'
    obj = Settings()
    obj.__setattr__(attr, text_type('value'))
    assert attr in obj
    obj[attr] = text_type('other value')
    assert obj[attr] == text_type('other value')

# Generated at 2022-06-24 05:00:02.746677
# Unit test for constructor of class Settings
def test_Settings():
    assert settings == dict(const.DEFAULT_SETTINGS)

# Generated at 2022-06-24 05:00:07.787633
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings['key_1'] = 'value_1'
    settings['key_2'] = 'value_2'
    assert settings.key_1 == 'value_1'
    assert settings.key_2 == 'value_2'
    assert 'key_1' in settings
    assert 'key_2' in settings


# Generated at 2022-06-24 05:00:10.426795
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, dict)
    for k, v in const.DEFAULT_SETTINGS.items():
        assert settings[k] == v


# Generated at 2022-06-24 05:00:14.089417
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.__setattr__('something', 'something')
    assert settings['something'] == 'something'


# Generated at 2022-06-24 05:00:15.492359
# Unit test for method init of class Settings
def test_Settings_init():
    # When
    settings.init(args=None)
    # Then
    assert settings.user_dir

# Generated at 2022-06-24 05:00:18.278295
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    obj = Settings()
    obj.__setattr__('a', 'b')
    assert obj.a == 'b'

# Generated at 2022-06-24 05:00:28.870036
# Unit test for method init of class Settings
def test_Settings_init():
    def clear_env():
        for var in const.ENV_TO_ATTR.keys():
            if var in os.environ:
                del os.environ[var]

    def check_settings(s):
        assert s['wait_slow_command'] == 4
        assert not s['require_confirmation']
        assert s['rules'] == ['Git', 'Gnome']
        assert s['exclude_rules'] == ['Python']
        assert s['instant_mode']
        assert s['slow_commands'] == ['some command']
        assert s['history_limit'] == 500
        assert s['wait_command'] == 1
        assert s['excluded_search_path_prefixes'] == ['/foo/bar']
        assert s['debug']
        assert s['alter_history']
        assert s['priority']

# Generated at 2022-06-24 05:00:31.178989
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.require_confirmation is True
    settings.require_confirmation = False
    assert settings.require_confirmation is False



# Generated at 2022-06-24 05:00:34.700950
# Unit test for constructor of class Settings
def test_Settings():
    # case 1
    s = Settings()
    assert isinstance(s, dict)
    # case 2
    s = Settings(const.DEFAULT_SETTINGS)
    assert s['require_confirmation'] == True


# Generated at 2022-06-24 05:00:38.801689
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.user_dir.is_dir()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.wait_command == 0.5
    assert settings.alter_history == True
    assert settings.repeat == const.MAX_REPEAT

# Generated at 2022-06-24 05:00:49.452340
# Unit test for method init of class Settings
def test_Settings_init():
    def _test_Settings_init_when_settings_file_not_exist():
        s = Settings(const.DEFAULT_SETTINGS)
        s.user_dir = Path('.tmp')
        s._init_settings_file()
        assert s.user_dir.joinpath('settings.py').is_file()
        s.user_dir.joinpath('settings.py').unlink()
        s.user_dir.rmdir()
    _test_Settings_init_when_settings_file_not_exist()

    def _test_Settings_init_when_settings_file_not_exist_and_not_create_dir():
        s = Settings(const.DEFAULT_SETTINGS)
        s.user_dir = Path('.tmp/tmp')
        s._init_settings_file()
        assert not Path

# Generated at 2022-06-24 05:00:58.841409
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import Mock
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.user_dir = Mock()
    settings.user_dir.joinpath = Mock(return_value = 'settings.py')
    settings._get_user_dir_path = Mock(return_value = '/home/user/.config/thefuck/')
    settings.init()
    assert settings.user_dir == '/home/user/.config/thefuck/'
    assert settings['require_confirmation'] == True
    assert settings['repeat'] == False
    assert settings['history_limit'] == None
    assert settings['no_colors'] == False

# Unit tests for method _get_user_dir_path of class Settings

# Generated at 2022-06-24 05:01:07.195077
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    init_settings = settings
    try:
        settings = Settings(const.DEFAULT_SETTINGS)
        settings.init()
        assert settings.user_dir.isdir()
        assert settings.user_dir.joinpath('rules').isdir()
        assert not settings.require_confirmation
        assert settings.num_close_matches == 3
        assert settings.note_no_command
        assert settings.history_limit == 20
    finally:
        settings = init_settings

# Generated at 2022-06-24 05:01:10.761829
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # TEST:
    #     Sets valid attributes
    settings.testing = True
    assert settings['testing'] is True
    settings.testing = False

    # TEST:
    #     Sets not valid attributes
    try:
        settings.__testing = True
    except (TypeError, AttributeError):
        pass
    else:
        assert False

    # TEST:
    #     Removes attributes
    del settings.testing
    assert 'testing' not in settings

# Generated at 2022-06-24 05:01:14.209329
# Unit test for method init of class Settings
def test_Settings_init():
    s = Settings()
    s.init()
    assert s['rules'] == const.DEFAULT_RULES
    assert s['require_confirmation'] == True
    assert s['no_colors'] == False
    assert s['debug'] == False


# Generated at 2022-06-24 05:01:15.860773
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.new_attr = 'value'
    assert settings['new_attr'] == 'value'

# Generated at 2022-06-24 05:01:18.666884
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.rules == const.DEFAULT_RULES
    assert settings.priority == {}
    assert settings.exclude_rules == []
    assert settings.require_confirmation is True
    assert settings.history_limit == 10

# Generated at 2022-06-24 05:01:20.203114
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.repeat = 'asd'
    assert settings['repeat'] == 'asd'


# Generated at 2022-06-24 05:01:21.426840
# Unit test for constructor of class Settings
def test_Settings():
    assert settings
    assert settings.get("require_confirmation")

# Generated at 2022-06-24 05:01:32.198735
# Unit test for constructor of class Settings
def test_Settings():
    from .tests.utils import support_dir

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.user_dir = support_dir('thefuck')

    # settings.py does not exist, a new one will be created:
    settings._init_settings_file()
    with settings.user_dir.joinpath('settings.py').open() as f:
        assert f.read() == const.SETTINGS_HEADER

    # settings.py exists, the original one will do nothing:
    settings._init_settings_file()
    with settings.user_dir.joinpath('settings.py').open() as f:
        assert f.read() == const.SETTINGS_HEADER

    # test _rules_from_env

# Generated at 2022-06-24 05:01:34.663946
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.__repr__() == str(const.DEFAULT_SETTINGS)
    assert settings.get('priority') == {'noop': 100, 'never': 0}



# Generated at 2022-06-24 05:01:43.048349
# Unit test for method init of class Settings
def test_Settings_init():
    s = Settings(const.DEFAULT_SETTINGS)
    try:
        s.init()
    except Exception:
        assert False, "Caught exception when trying to init settings"
    assert 'user_dir' in s
    assert 'require_confirmation' in s
    assert 'wait_command' in s
    assert 'slow_commands' in s
    assert 'commands' in s
    assert 'history_limit' in s
    assert 'no_colors' in s
    assert 'alter_history' in s
    assert 'wait_slow_command' in s
    assert 'rules' in s
    assert 'exclude_rules' in s
    assert 'num_close_matches' in s
    assert 'instant_mode' in s

# Generated at 2022-06-24 05:01:45.420205
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    setattr(s, 'test_key', 'test_value')
    assert s == {'test_key': 'test_value'}

# Generated at 2022-06-24 05:01:47.257312
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test_1 = 1
    assert settings['test_1'] == 1

#Unit test for method __getattr__ of class Settings

# Generated at 2022-06-24 05:01:53.675240
# Unit test for method init of class Settings
def test_Settings_init():
    from os import environ
    from sys import version_info

    def get_path():
        if version_info[0] < 3:
            return '~/.thefuck'
        else:
            return '~/.config/thefuck'

    def test_init_settings_file():
        settings.clear()
        settings.user_dir = get_path()
        settings._init_settings_file()
        assert (settings.user_dir + '/settings.py').is_file()

    def test_get_settings_from_file():
        settings.clear()
        settings.user_dir = get_path()
        settings.update(settings._settings_from_file())
        assert settings == const.DEFAULT_SETTINGS

    def test_get_settings_from_env():
        settings.clear()
        settings.user_dir

# Generated at 2022-06-24 05:01:56.065681
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.__setattr__("test_name", "test_value")
    assert settings.test_name == "test_value"

# Generated at 2022-06-24 05:02:00.036645
# Unit test for method init of class Settings
def test_Settings_init():
    class Args:
        debug = True
        repeat = True
        yes = True

    settings.init(Args)
    assert settings.require_confirmation == False
    assert settings.debug == True
    assert settings.repeat == True

# Generated at 2022-06-24 05:02:09.480554
# Unit test for method init of class Settings
def test_Settings_init():
    import mock
    import sys
    import thefuck.shells
    import thefuck.shells.zsh

    mock_args = mock.Mock()
    mock_args.yes = True
    mock_args.debug = False
    mock_args.repeat = False

    from_file = load_source(
                'settings',
                text_type(settings.user_dir.joinpath('settings.py')))
    from_file.require_confirmation = False
    from_file.debug = True
    from_file.repeat = 1
    from_file.no_colors = False
    from_file.wait_command = 4
    from_file.wait_slow_command = 15
    from_file.slow_commands = ["ls"]
    from_file.exclude_rules = ['not_exclude_rule']


# Generated at 2022-06-24 05:02:19.115937
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings['require_confirmation'] == True
    assert settings['rules'] == ['fuck', 'fuckit', 'fukit']
    assert settings['priority'] == {'fuck': 1, 'fuckit': 1, 'fukit': 1}
    assert settings['wait_command'] == 10
    assert settings['history_limit'] == None
    assert settings['wait_slow_command'] == 15
    assert settings['no_colors'] == False
    assert settings['debug'] == False
    assert settings['slow_commands'] == ['git']
    assert settings['exclude_rules'] == []
    assert settings['excluded_search_path_prefixes'] == []
    assert settings['history_file'] == '~/.thefuck/history'
    assert settings['alter_history']

# Generated at 2022-06-24 05:02:29.155308
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.history_limit == const.DEFAULT_SETTINGS['history_limit']
    assert settings.rules == const.DEFAULT_SETTINGS['rules']
    assert settings.priority == const.DEFAULT_SETTINGS['priority']
    assert settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']
    assert settings.no_colors == const.DEFAULT_SETTINGS['no_colors']
    assert settings.slow_commands == const.DEFAULT_SETTINGS['slow_commands']
    assert settings.wait_slow_command == const.DEFAULT_SETTINGS['wait_slow_command']
    assert settings.wait_command == const.DEFAULT_SETTINGS['wait_command']

# Generated at 2022-06-24 05:02:34.220159
# Unit test for constructor of class Settings
def test_Settings():
    def check_Settings():
        for k, v in const.DEFAULT_SETTINGS.items():
            assert settings.get(k) == v
    return check_Settings()

# Generated at 2022-06-24 05:02:43.509065
# Unit test for constructor of class Settings
def test_Settings():
    from .logs import _user_dir
    settings.init()

    assert settings.get('rules') == const.DEFAULT_RULES
    assert settings.get('require_confirmation') is True
    assert settings.get('no_colors') is False
    assert settings.get('wait_command') == 2
    assert settings.get('debug') is False
    assert settings.get('priority') == {}
    assert settings.get('history_limit') == 10
    assert settings.get('alter_history') is True
    assert settings.get('env') == {}
    assert settings.get('wait_slow_command') == 15
    assert settings.get('slow_commands') == []
    assert settings.get('exclude_rules') == []
    assert settings.get('excluded_search_path_prefixes') == []

# Generated at 2022-06-24 05:02:44.798159
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.no_colors == False
    assert settings.require_confirmation == True
    assert settings.repeat == False


# Generated at 2022-06-24 05:02:47.454670
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.no_colors == const.DEFAULT_SETTINGS['no_colors']
    settings.no_colors = True
    assert settings.no_colors == True


# Generated at 2022-06-24 05:02:53.209162
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    import unittest
    class test_Settings(unittest.TestCase):
        def test_set_key_value(self):
            val = 'test_string'
            attr_name = 'test_attr'
            settings.__setattr__(attr_name, val)
            self.assertEqual(settings[attr_name], val)
    
    # run
    unittest.main()

# Generated at 2022-06-24 05:03:02.773817
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import shutil

    from .logs import exception

    from .sort import rule_name_to_priority, priority_to_rule_name

    from .system import TempDir
    from .utils import memoize

    from .thefuck import main

    class Env():
        def __init__(self):
            self.env = {}
        def __setitem__(self, env, value):
            self.env[env] = value
        def __getitem__(self, env):
            return self.env.get(env, '')

    args = ['--yes', '--repeat', '10', '--debug', 'True']

    env = Env()
    rules = ['git_push', 'git_commit']

# Generated at 2022-06-24 05:03:11.599565
# Unit test for method init of class Settings
def test_Settings_init():
    import pytest
    from collections import namedtuple
    Args = namedtuple('Args', ['yes', 'debug', 'repeat'])
    class FakePath():
        def __init__(self, is_file, is_dir, joinpath):
            self.is_file = is_file
            self.is_dir = is_dir
            self.joinpath = joinpath
        def expanduser(self):
            return self
        def open(self, mode):
            self.mode = mode
            return open('/dev/null', 'w')

    def _get_user_dir_path(self):
        return FakePath(is_file=True,
                        is_dir=True,
                        joinpath=lambda subdir: self.user_dir)


# Generated at 2022-06-24 05:03:13.043546
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.attr = 'value'
    assert settings['attr'] == 'value'

# Generated at 2022-06-24 05:03:14.247806
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.get('require_confirmation') == True
    assert not hasattr(settings, "not_existed_attr")


# Generated at 2022-06-24 05:03:15.728932
# Unit test for constructor of class Settings
def test_Settings():
    default_settings = Settings(const.DEFAULT_SETTINGS)



# Generated at 2022-06-24 05:03:26.057301
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, dict)
    assert settings['require_confirmation']
    assert not settings['no_colors']
    assert not settings['alter_history']
    assert not settings['debug']
    assert settings['wait_slow_command'] == 3
    assert settings['wait_command'] == 1
    assert settings['history_limit'] == 10
    assert isinstance(settings['slow_commands'], list)
    assert settings['slow_commands'][0] == 'sudo'
    assert isinstance(settings['exclude_rules'], list)
    assert settings['exclude_rules'][0] == 'git-am'
    assert isinstance(settings['excluded_search_path_prefixes'], list)
    assert settings['excluded_search_path_prefixes'][0] == '/usr'
    assert isinstance

# Generated at 2022-06-24 05:03:27.004142
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.priority == 1

# Generated at 2022-06-24 05:03:34.104195
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert const.DEFAULT_SETTINGS['rules'] == ['git_push', 'git_add', 'pip_install', 'sudo']
    assert const.DEFAULT_SETTINGS['require_confirmation'] == True
    assert settings['rules'] == ['git_push', 'git_add', 'pip_install', 'sudo']
    assert settings['require_confirmation'] == True
    assert settings['no_colors'] == False
    assert settings['alter_history'] == False
    assert settings['repeat'] == None
    assert settings['history_limit'] == None
    assert settings['instant_mode'] == False
    assert settings['wait_command'] == 0


# Generated at 2022-06-24 05:03:35.739856
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']


# Generated at 2022-06-24 05:03:43.901190
# Unit test for constructor of class Settings
def test_Settings():
    mysettings = Settings()
    # constructor test
    assert(mysettings == const.DEFAULT_SETTINGS)
    assert(mysettings['require_confirmation'] == True)
    assert(mysettings['history_limit'] == None)
    assert(mysettings['alter_history'] == True)
    assert(mysettings['wait_slow_command'] == 15)
    assert(mysettings['wait_command'] == 1)
    assert(mysettings['no_colors'] == False)
    assert(mysettings['rules'] == [])
    assert(mysettings['exclude_rules'] == [])
    assert(mysettings['priority'] == {})
    assert(mysettings['instant_mode'] == False)
    assert(mysettings['slow_commands'] == [])
    assert(mysettings['debug'] == False)

# Generated at 2022-06-24 05:03:46.654071
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_targ = Settings()
    test_targ._set_ = '_set_'
    assert test_targ._set_ == '_set_'


# Generated at 2022-06-24 05:03:51.267554
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings({'a': 1, 'b': 2})
    settings.c = 3
    assert settings == {'a': 1, 'b': 2, 'c': 3}



# Generated at 2022-06-24 05:03:53.424101
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings == const.DEFAULT_SETTINGS
    assert settings.get('require_confirmation') == True
    assert settings.require_confirmation == True



# Generated at 2022-06-24 05:03:59.814754
# Unit test for constructor of class Settings
def test_Settings():
    from .logs import log
    def _test():
        class FakeLogging:
            def __init__(self):
                self.logs = []
            def exception(self, message, exception):
                self.logs.append((message, exception))
        fake_log = FakeLogging()
        fake_settings = {
            'slow_commands': ['git status'],
            'history_limit': 0
        }
        settings = Settings(fake_settings)
        settings.log = fake_log
        settings.init(FakeArgs())
        assert settings['slow_commands'] == fake_settings['slow_commands']
        assert settings['history_limit'] == fake_settings['history_limit']
        assert len(fake_log.logs) == 0


# Generated at 2022-06-24 05:04:07.386125
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert os.environ.copy() == environ_copy
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    if 'XDG_CONFIG_HOME' not in os.environ:
        assert settings.user_dir == Path('~/.config/thefuck').expanduser()

if __name__ == '__main__':
    environ_copy = os.environ.copy()
    os.environ['XDG_CONFIG_HOME'] = '~/.config'
    test_Settings_init()

# Generated at 2022-06-24 05:04:12.681743
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    attr_name = 'attr'
    key_name = 'key'
    attr_value = 'value'
    key_value = 'value'

    assert not hasattr(settings, attr_name)
    setattr(settings, attr_name, attr_value)
    assert attr_value == getattr(settings, attr_name)
    assert attr_value == settings.get(attr_name)

    assert key_name not in settings.keys()
    settings.__setattr__(key_name, key_value)
    assert key_value == settings.get(key_name)

# Generated at 2022-06-24 05:04:15.275848
# Unit test for constructor of class Settings
def test_Settings():
    assert Settings(const.DEFAULT_SETTINGS) == settings



# Generated at 2022-06-24 05:04:17.648164
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation


# Generated at 2022-06-24 05:04:22.220137
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    '''
    :return: Pass if __getattr__ of class Settings work correctly
    '''
    assert(settings.require_confirmation == False)
    assert(settings.repeat == 1)

# Generated at 2022-06-24 05:04:30.881197
# Unit test for constructor of class Settings
def test_Settings():
    from .system import Path
    from .logs import exception

    # initialize settings
    settings.init()
    assert settings.get('user_dir') == Path('~/.config/thefuck').expanduser()
    assert settings.get('require_confirmation') is True
    assert settings.get('wait_command') == 0
    assert settings.get('history_limit') == 10
    assert settings.get('wait_slow_command') == 15

# Generated at 2022-06-24 05:04:32.558652
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    from tests.utils import assert_equal
    settings = Settings(test=True)
    assert_equal(settings.test, True)


# Generated at 2022-06-24 05:04:40.120281
# Unit test for method init of class Settings
def test_Settings_init():
    path = Path('~/.thefuck').expanduser()
    results = settings._Settings__init()
    assert results['user_dir'] == path
    assert results['rules'] == const.DEFAULT_RULES
    assert results['exclude_rules'] == []
    assert results['priority'] == {'pwd': 2}
    assert results['wait_slow_command'] == 3
    assert results['no_colors'] == False
    assert results['wait_command'] == 1
    assert results['history_limit'] == None
    assert results['alter_history'] == True
    assert results['require_confirmation'] == False
    assert results['slow_commands'] == []
    assert results['excluded_search_path_prefixes'] == []
    assert results['num_close_matches'] == 3

# Generated at 2022-06-24 05:04:42.627920
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.slow_commands


# Generated at 2022-06-24 05:04:49.492160
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.__class__.__name__ == 'Settings'
    assert settings.get('wait_command') == 0
    assert settings.get('wait_slow_command') == 15
    assert settings.get('history_limit') == 1000
    assert settings.get('require_confirmation') == True
    assert settings.get('num_close_matches') == 3
    assert settings.get('no_colors') == False
    assert settings.get('alter_history') == True



# Generated at 2022-06-24 05:04:51.250616
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.testing = '123'
    assert settings.testing == '123'


# Generated at 2022-06-24 05:04:53.360737
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test_Settings___setattr__ = "test_Settings___setattr__"
    assert settings.test_Settings___setattr__ == "test_Settings___setattr__"


# Generated at 2022-06-24 05:04:55.152022
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.__getattr__('require_confirmation') == True
    assert settings.__getattr__('unknown_attr') == None


# Generated at 2022-06-24 05:04:56.780032
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings()
    settings.hello = 'world'
    assert settings.__getattr__('hello') == 'world'


# Generated at 2022-06-24 05:05:01.581986
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.require_confirmation
    settings.require_confirmation = False
    assert settings.require_confirmation is False


# Generated at 2022-06-24 05:05:09.591458
# Unit test for constructor of class Settings
def test_Settings():
    """
    Takes instance of class Settings
    Returns comparsion of settings_from_class and settings_from_env.
    """
    test_env = {'THEFUCK_RULES': 'python:bash'}
    sys.modules["__main__"].settings = Settings(const.DEFAULT_SETTINGS)
    settings_from_class = sys.modules["__main__"].settings._val_from_env(test_env, 'THEFUCK_RULES')
    settings_from_env = os.environ.get('THEFUCK_RULES')
    return settings_from_class == settings_from_env

if __name__ == '__main__':
    test_Settings()

# Generated at 2022-06-24 05:05:14.907583
# Unit test for method init of class Settings
def test_Settings_init():
    settings.clear()
    settings.init()

    user_dir = settings._get_user_dir_path()
    assert settings.user_dir == user_dir

    settings_path = user_dir.joinpath('settings.py')
    assert settings_path.is_file()

    settings_content = settings_path.read_text().strip()
    assert settings_content == const.SETTINGS_HEADER


# Generated at 2022-06-24 05:05:22.787488
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import tempfile
    from thefuck.logs import log_to_stderr
    from thefuck.utils import which
    from thefuck.rules.git_push import match
    from tests.utils import patch_os_environ, patch_open
    from six import text_type

    def setUp():
        # clear os.environ
        patch_os_environ({})

    def test_init_user_dir_creates_new_user_dir():
        # arrange
        setUp()
        settings = Settings(const.DEFAULT_SETTINGS)
        patch_os_environ({'XDG_CONFIG_HOME': tempfile.mkdtemp()})

        # act
        settings.init()
        user_dir = settings._get_user_dir_path()

        # assert

# Generated at 2022-06-24 05:05:25.101170
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    for k, v in const.DEFAULT_SETTINGS.items():
        assert settings.get(k) == v

# Generated at 2022-06-24 05:05:31.307131
# Unit test for constructor of class Settings
def test_Settings():
    class FakeSettings(Settings):
        def _init_settings_file(self):
            pass

        def _get_user_dir_path(self):
            return Path('~/some_dir')

    fake_settings = FakeSettings()
    fake_settings.init()

    assert fake_settings.user_dir == Path('~/some_dir').expanduser()



# Generated at 2022-06-24 05:05:32.412243
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.require_confirmation is True

# Generated at 2022-06-24 05:05:34.018313
# Unit test for constructor of class Settings
def test_Settings():
    new_settings = Settings(const.DEFAULT_SETTINGS)
    assert new_settings.get('require_confirmation')

# Generated at 2022-06-24 05:05:35.955829
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    s = Settings({'a': 'b'})
    assert s.a == 'b'



# Generated at 2022-06-24 05:05:40.149076
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings({'key': 'value'})
    assert test_settings.get('key') == 'value'
    assert test_settings.get('test_key') is None


# Generated at 2022-06-24 05:05:43.562111
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    assert s == {}
    s.foo = 'bar'
    assert s.foo == 'bar'
    assert s['foo'] == 'bar'
    assert s == {'foo': 'bar'}
    s.foo = 'baz'
    assert s.foo == 'baz'
    assert s['foo'] == 'baz'
    assert s == {'foo': 'baz'}


# Generated at 2022-06-24 05:05:52.430714
# Unit test for method init of class Settings
def test_Settings_init():
    def test_helper(args):
        settings['init'](args)
        return (settings['require_confirmation'],
                settings['debug'],
                settings['repeat'])

    assert (False, None, None) == test_helper(None)
    assert (False, None, None) == test_helper(object())
    assert (True, None, None) == test_helper(object())
    assert (True, True, None) == test_helper(object(debug=True))
    assert (False, None, 1) == test_helper(object(yes=True))
    assert (True, None, 1) == test_helper(object(repeat=1))



# Generated at 2022-06-24 05:05:54.226219
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.get('require_confirmation') == True

# Generated at 2022-06-24 05:06:00.489147
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from .logs import log
    from .utils import get_closest, wrap_settings

    settings.__setattr__('log', log)
    settings.__setattr__('get_closest', get_closest)
    settings.__setattr__('wrap_settings', wrap_settings)

    assert settings.log is log
    assert settings.get_closest is get_closest
    assert settings.wrap_settings is wrap_settings

# Generated at 2022-06-24 05:06:05.459530
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings({'key': 'value'})
    assert settings['key'] == 'value'
    assert settings.key == 'value'

    settings.key = 'new_value'
    assert settings['key'] == 'new_value'
    assert settings.key == 'new_value'

# Generated at 2022-06-24 05:06:08.799591
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings({'a': 1})
    assert settings.__getattr__('a') == 1



# Generated at 2022-06-24 05:06:10.845994
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    s = Settings(x = 1)
    assert s.x == 1

# Generated at 2022-06-24 05:06:19.729560
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    '''
    This test is used to verify the function of __setattr__ in class Settings.
    '''
    # Create a instance of Settings, which will be tested.
    testObj = Settings(const.DEFAULT_SETTINGS)
    # Create a list, the elements of which will be used to test the function of __setattr__.
    test_setattr = ["key1", "key2", "key3"]
    # Create a list, the elements of which will be used to test the function of __getattr__.
    test_getattr = []
    # Loop to test the function of __setattr__ and __getattr__.
    for i in range(len(test_setattr)):
        testObj.__setattr__(test_setattr[i], test_setattr[i])

# Generated at 2022-06-24 05:06:24.878494
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings()
    test_settings.test_key1 = 'test_value1'
    assert test_settings['test_key1'] == 'test_value1'
    test_settings.test_key1 = 'test_value2'
    assert test_settings['test_key1'] == 'test_value2'



# Generated at 2022-06-24 05:06:29.716640
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings(const.DEFAULT_SETTINGS)
    assert s == const.DEFAULT_SETTINGS


# Generated at 2022-06-24 05:06:31.668743
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    """Test method __getattr__ of class Settings

    Get attribute from settings and assert.
    """
    assert settings.debug



# Generated at 2022-06-24 05:06:39.818196
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.debug == False
    assert settings.repeat == False
    assert settings.no_colors == False
    assert settings.history_limit == None
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.alter_history == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt']
    assert settings.num_close_matches == 3
    assert settings.instant_mode == False
    assert settings.excluded_search_path_prefixes == []

# Generated at 2022-06-24 05:06:52.083951
# Unit test for method init of class Settings
def test_Settings_init():
    argv = ['thefuck']
    args = dict(yes=False,
                debug=False,
                repeat=None)

    old_environ = os.environ
    os.environ = {}

    settings.init(args)
    assert const.DEFAULT_SETTINGS == settings

    os.environ = dict(XDG_CONFIG_HOME=':',
                        require_confirmation='False',
                        debug='True',
                        repeat='3')

    settings.init(args)
    assert const.DEFAULT_SETTINGS['require_confirmation'] == settings.require_confirmation
    assert const.DEFAULT_SETTINGS['debug'] == settings.debug
    assert const.DEFAULT_SETTINGS['repeat'] == settings.repeat


# Generated at 2022-06-24 05:06:54.282424
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.foo = 42
    assert settings['foo'] == 42
    assert settings.foo == 42

# Generated at 2022-06-24 05:06:56.068733
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.a = 1
    assert settings == {'a': 1}



# Generated at 2022-06-24 05:06:57.836846
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.python == 'python3'
    assert settings.require_confirmation


# Generated at 2022-06-24 05:07:08.099002
# Unit test for method init of class Settings
def test_Settings_init():
    global settings

    # mock settings, os, sys
    import settings as settings_file
    from mock import Mock, patch
    sys = Mock()
    sys.exc_info = Mock(return_value=('foo', 1, 2))
    os = Mock()
    settings_file.__name__ = 'settings'
    settings = Settings(const.DEFAULT_SETTINGS)

    # init settings
    settings.init(None)

    # for test _init_settings_file
    settings.user_dir = Mock()
    settings.user_dir.joinpath().is_file.return_value = False
    settings.init(None)
    settings.user_dir.joinpath().open().write.assert_called_with(
        const.SETTINGS_HEADER)

# Generated at 2022-06-24 05:07:09.760836
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.test = True
    assert settings['test'] == True


# Generated at 2022-06-24 05:07:10.699598
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.DEBUG



# Generated at 2022-06-24 05:07:13.048079
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings()
    settings.foo = 'bar'
    assert settings.foo == 'bar'
    assert settings['foo'] == 'bar'
    assert settings.get('foo') == 'bar'


# Generated at 2022-06-24 05:07:15.598991
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    DummySettings = Settings()
    DummySettings.test = 'test'
    assert DummySettings['test'] == 'test'

# Generated at 2022-06-24 05:07:18.328091
# Unit test for method init of class Settings
def test_Settings_init():
    test_settings = Settings({})
    test_settings.init()
    assert hasattr(test_settings, 'require_confirmation')


# Generated at 2022-06-24 05:07:19.392220
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.rules == const.DEFAULT_RULES

# Generated at 2022-06-24 05:07:26.902700
# Unit test for method init of class Settings
def test_Settings_init():
    # Test for method _settings_from_file
    # Override the `user_dir` attribute when get the `settings` module
    class Fake(object):
        def __init__(self, path):
            self.path = path

        def joinpath(self, file_name):
            return Path(self.path).joinpath(file_name)

    fake = Fake(os.path.join(os.path.dirname(__file__), 'test_data'))
    settings._get_user_dir_path = lambda: fake

    # Test when the file `test_data/settings.py` exists
    settings.init()
    assert settings.get('no_colors') == True

    # Test when the file `test_data/settings.py` is not exists

# Generated at 2022-06-24 05:07:31.044896
# Unit test for constructor of class Settings
def test_Settings():
	settings.clear()
	settings.init()

	default_settings = const.DEFAULT_SETTINGS
	assert settings.user_dir is not None
	assert settings.get("require_confirmation") == default_settings['require_confirmation']
	assert settings.get("history_limit") == default_settings['history_limit']

# Generated at 2022-06-24 05:07:39.892846
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile

    class Args(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-24 05:07:43.408770
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.new_setting = 5
    assert settings['new_setting'] == 5
    assert settings.new_setting == 5

    settings.new_setting += 1
    assert settings['new_setting'] == 6


# Generated at 2022-06-24 05:07:49.661167
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['no_colors'] == False
    assert settings['require_confirmation'] == True
    assert settings['slow_commands'] == const.DEFAULT_SLOW_COMMANDS
    assert settings['history_limit'] == const.DEFAULT_HISTORY_LIMIT
    assert settings['wait_command'] == const.DEFAULT_WAIT_COMMAND

# Generated at 2022-06-24 05:07:51.942658
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    from .tests.utils import assert_equal
    settings['test'] = 'test'
    assert_equal(settings.test, 'test')

# Generated at 2022-06-24 05:07:53.251121
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules == const.DEFAULT_RULES



# Generated at 2022-06-24 05:07:55.651897
# Unit test for constructor of class Settings
def test_Settings():
    new_settings = Settings(const.DEFAULT_SETTINGS)
    assert new_settings['wait_command'] == settings['wait_command']

# Generated at 2022-06-24 05:08:05.714781
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile 
    import os

    home_dir = tempfile.mkdtemp()
    os.environ['HOME'] = home_dir
    del os.environ['XDG_CONFIG_HOME']
    settings.init(args=None)

    assert settings.user_dir == Path(home_dir, '/.thefuck')
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.repeat == False
    assert settings.wait_command == 3
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.alter_history == True
    assert settings.excluded_search_path_prefixes == []
    assert settings.instant_mode == False
    assert settings.history

# Generated at 2022-06-24 05:08:06.613837
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation



# Generated at 2022-06-24 05:08:17.405124
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('require_confirmation') == True
    assert settings.get('no_colors') == False
    assert settings.get('rules') == const.DEFAULT_RULES
    assert settings.get('sudo_command') == u'thefuck-sudo'
    assert settings.get('exclude_rules') == []
    assert settings.get('wait_command') == 3
    assert settings.get('alter_history') == False
    assert settings.get('instant_mode') == False
    assert settings.get('priority') == const.DEFAULT_PRIORITY
    assert settings.get('history_limit') == 1000
    assert settings.get('wait_slow_command') == 10
    assert settings.get('slow_commands') == ['lein', 'activator', 'sbt', 'mvn']
    assert settings.get

# Generated at 2022-06-24 05:08:18.524232
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    empty_settings = Settings()
    assert empty_settings.hello == None



# Generated at 2022-06-24 05:08:19.850146
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings({'DEBUG': True})
    assert settings.DEBUG is True


# Generated at 2022-06-24 05:08:28.737367
# Unit test for method init of class Settings
def test_Settings_init():
    args = lambda **kwargs: type('obj', (), kwargs)()
    from .tests.utils import mock
    from .utils import get_all_executables
    # Check that it updates settings with values from settings.py and env

# Generated at 2022-06-24 05:08:36.799567
# Unit test for constructor of class Settings
def test_Settings():
    # All the setting keys should be in the class variable
    # `const.DEFAULT_SETTINGS`.
    assert all(setting in const.DEFAULT_SETTINGS
               for setting in settings)
    # Default values should be correct.
    for setting, value in const.DEFAULT_SETTINGS.items():
        assert settings[setting] == value
    # Settings should be changeable.
    settings['require_confirmation'] = not settings['require_confirmation']
    assert settings['require_confirmation'] != \
            const.DEFAULT_SETTINGS['require_confirmation']
    # Settings object should be iterable.
    assert all(setting in settings for setting in settings)

# Generated at 2022-06-24 05:08:46.834127
# Unit test for constructor of class Settings

# Generated at 2022-06-24 05:08:48.338122
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    obj = Settings()
    assert obj.key == None


# Generated at 2022-06-24 05:08:52.738182
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings()
    test_settings.test_attr = 'test'
    assert test_settings['test_attr'] == 'test'



# Generated at 2022-06-24 05:08:57.193277
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    instance = Settings()
    instance.test = 'test'

    assert instance['test'] == 'test'


# Generated at 2022-06-24 05:09:00.173531
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.key_chain is None
    settings['key_chain'] = 'blah'
    assert settings.key_chain == 'blah'



# Generated at 2022-06-24 05:09:01.867275
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.foo = 'bar'
    assert settings.foo == 'bar'


# Generated at 2022-06-24 05:09:06.727985
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings.init()
    settings.init(namedtuple('args', 'yes debug repeat')(yes=True, debug=True, repeat=2))



# Generated at 2022-06-24 05:09:10.978960
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.some_key = 'some_value'
    assert settings['some_key'] == 'some_value'



# Generated at 2022-06-24 05:09:11.942834
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.test_attr = "test"
    assert settings.test_attr == "test"



# Generated at 2022-06-24 05:09:23.462817
# Unit test for method init of class Settings
def test_Settings_init():
    global settings

    old_user_dir = settings.user_dir
    settings = Settings(const.DEFAULT_SETTINGS)

    settings.init()
    assert settings.user_dir != old_user_dir
    assert settings.user_dir.joinpath('settings.py').is_file()

    old_user_dir = settings.user_dir
    settings = Settings(const.DEFAULT_SETTINGS)
    os.environ['THEFUCK_SHOW_SUGGESTION'] = 'False'
    os.environ['THEFUCK_RULES'] = 'test:test:test:test:test:test:test:test:test:test:test:test:test'
    os.environ['THEFUCK_PRIORITY'] = 'DEFAULT_RULES=666'
    settings.init()


# Generated at 2022-06-24 05:09:25.391427
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.hist_limit == const.DEFAULT_SETTINGS['history_limit']
    assert settings.fuc_with_invalid_attr == None



# Generated at 2022-06-24 05:09:32.452890
# Unit test for method init of class Settings
def test_Settings_init():
    from tempfile import mkdtemp
    from shutil import rmtree
    from six import StringIO
    from .logs import redirect_stdout
    
    def _run_test(settings_from_file, settings_from_env, settings_from_args, \
                  expected):
        settings_from_file = settings_from_file or {}
        settings_from_env = settings_from_env or {}
        settings_from_args = settings_from_args or {}
        expected = expected or {}
        settings.init(settings_from_args)
        settings.update(settings_from_env)
        settings.update(settings_from_file)
        for key, val in expected.items():
            assert settings[key] == val
        
    temp_dir = mkdtemp()

# Generated at 2022-06-24 05:09:38.512177
# Unit test for method init of class Settings
def test_Settings_init():
    work_settings = Settings()
    work_settings.init(None)

    import tempfile
    with tempfile.TemporaryDirectory() as tmp_path:
        os.environ['XDG_CONFIG_HOME'] = tmp_path
        tmp_user_dir = Path(tmp_path, 'thefuck')
        tmp_settings = Settings()
        tmp_settings.init(None)
        assert tmp_settings == work_settings

# Generated at 2022-06-24 05:09:42.835775
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test = Settings()
    test.test = 1
    assert test.get('test') == 1


# Generated at 2022-06-24 05:09:44.124051
# Unit test for constructor of class Settings
def test_Settings():
    """Test `Settings` contructor."""
    assert settings is not None

# Generated at 2022-06-24 05:09:47.370660
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.foo = 1
    assert settings.get('foo') == 1

# Generated at 2022-06-24 05:09:49.957701
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings({'a': 1, 'b': 2})
    assert s == {'a': 1, 'b': 2}
    s.a = 3
    assert s == {'a': 3, 'b': 2}


# Generated at 2022-06-24 05:10:00.419605
# Unit test for method init of class Settings
def test_Settings_init():
    # Test for function _settings_from_file
    def test_settings_from_file(monkeypatch):
        monkeypatch.setattr('thefuck.settings.Settings._get_user_dir_path', lambda _: Path('~/thefuck'))
        monkeypatch.setattr('thefuck.settings.Settings.user_dir', Path('~/thefuck'))
        assert settings._settings_from_file() == {'key':'value'}

    test_settings_from_file(monkeypatch)

    # Test for function _settings_from_env
    def test_settings_from_env(monkeypatch):
        monkeypatch.setattr('thefuck.settings.Settings.user_dir', Path('~/thefuck'))
        monkeypatch.setenv('TF_SHELL', 'bash')
        assert settings._settings_from_env()