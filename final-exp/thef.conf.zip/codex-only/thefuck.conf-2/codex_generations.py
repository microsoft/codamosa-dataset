

# Generated at 2022-06-24 05:00:03.632232
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    """Unit test for method __setattr__ of class Settings"""
    settings.__setattr__("test", "something")
    assert "something" == settings.get("test")
    assert "something" == settings.test

if __name__ == "__main__":
    import doctest
    print(doctest.testmod())

# Generated at 2022-06-24 05:00:14.363819
# Unit test for constructor of class Settings
def test_Settings():
    """Test for Settings class constructor."""
    from unittest.mock import patch
    from thefuck.settings import Settings

    with patch('thefuck.settings.os.environ', clear=True):
        assert 'rules' not in os.environ
        assert 'priority' not in os.environ
        assert 'require_confirmation' not in os.environ
        assert 'no_colors' not in os.environ
        assert 'debug' not in os.environ
        assert 'alter_history' not in os.environ
        assert 'wait_command' not in os.environ
        assert 'slow_commands' not in os.environ
        assert 'exclude_rules' not in os.environ
        assert 'repeat' not in os.environ
        assert 'history_limit' not in os.environ


# Generated at 2022-06-24 05:00:16.026132
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert (settings.__setattr__('key', 'value') ==
            settings.__getattr__('key') == 'value')

# Generated at 2022-06-24 05:00:27.853378
# Unit test for method init of class Settings
def test_Settings_init():
    """
    test_Settings_init
    settings.init() should update existing settings and add new key/value pairs
    from settings.py, env and args
    """
    settings.init(args=None)
    assert settings.alias == const.DEFAULT_ALIAS
    assert settings.priority == const.DEFAULT_PRIORITY
    assert settings.no_colors == const.DEFAULT_NO_COLORS
    assert settings.wait_command == const.DEFAULT_WAIT_COMMAND
    assert settings.require_confirmation == const.DEFAULT_REQUIRE_CONFIRMATION
    assert settings.exclude_rules == const.DEFAULT_EXCLUDE_RULES
    assert settings.alter_history == const.DEFAULT_ALTER_HISTORY
    assert settings.user_dir == const.DEFAULT_USER_DIR


# Generated at 2022-06-24 05:00:38.357811
# Unit test for method init of class Settings
def test_Settings_init():
    """Test that Settings class has been correctly initialized"""
    assert settings['require_confirmation'] is True
    assert settings['env'] is None
    assert settings['exclude_rules'] == []
    assert settings['history_limit'] == 10
    assert settings['wait_command'] == 3
    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['priority'] == {}
    assert settings['wait_slow_command'] == 10
    assert settings['slow_commands'] == [
        'mvn', 'lein', 'gradle']
    assert settings['no_colors'] is False
    assert settings['debug'] is False
    assert settings['alter_history'] is True

# Generated at 2022-06-24 05:00:44.242871
# Unit test for method init of class Settings
def test_Settings_init():
    from tests.tools import assert_equal, Mock

    settings.update(Mock(history_limit=None, wait_command=None,
                         require_confirmation=None, alter_history=None,
                         wait_slow_command=None, debug=None,
                         num_close_matches=None))
    settings.init()
    assert_equal(settings['history_limit'], None)
    assert_equal(settings['debug'], None)

# Generated at 2022-06-24 05:00:50.683631
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert Path.home().joinpath('.config/thefuck/settings.py') == settings.user_dir.joinpath('settings.py')
    assert 'priority' in const.DEFAULT_SETTINGS.keys()
    assert 'require_confirmation' in const.DEFAULT_SETTINGS.keys()
    assert 'no_colors' in const.DEFAULT_SETTINGS.keys()

# Generated at 2022-06-24 05:00:52.242321
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test_settings = True
    assert settings['test_settings']

# Generated at 2022-06-24 05:00:59.180062
# Unit test for constructor of class Settings
def test_Settings():
    class _Settings(Settings):
        def _setup_user_dir(self):
            self.user_dir = Path()

        def _settings_from_file(self):
            return {}

        def _settings_from_env(self):
            return {}

        def _settings_from_args(self, args):
            return {}

    settings = _Settings()
    assert settings._get_user_dir_path() == Path('~/.config/thefuck')
    settings.init()



# Generated at 2022-06-24 05:01:03.655215
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    """unit test for `Settings`"""
    assert not hasattr(settings, 'test')
    settings.test = 1
    assert settings['test'] == 1
    assert settings.test == 1

# Generated at 2022-06-24 05:01:11.444918
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    from .logs import clear_logger
    from .utils import get_all_commands
    from .system import get_all_paths


# Generated at 2022-06-24 05:01:15.699449
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == True
    assert settings.rules == None
    assert settings.alter_history == None


# Generated at 2022-06-24 05:01:18.200417
# Unit test for constructor of class Settings
def test_Settings():
    from .logs import exception

    try:
        settings.init(None)
    except Exception:
        exception("Can't load settings from file", sys.exc_info())

test_Settings()

# Generated at 2022-06-24 05:01:29.011397
# Unit test for method init of class Settings
def test_Settings_init():
    import sys
    from .logs import exception

    settings._init_settings_file()

    assert settings.history_limit == 5
    assert settings.no_colors == False
    assert settings.require_confirmation == False
    assert settings.instant_mode == False
    assert settings.alter_history == False
    assert settings.wait_command == 0
    assert settings.wait_slow_command == 5
    assert settings.rules == ['git_add_no_commit', 'git_amend', 'git_branch_delete', 'git_checkout', 'git_cherry_pick', 'git_commit', 'git_diff', 'git_forget_new', 'git_mv', 'git_no_such_cmd', 'git_reset', 'git_rm', 'sudo']
    assert settings.exclude_rules == []
   

# Generated at 2022-06-24 05:01:31.127903
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.A = 'a'
    assert settings.A == 'a'
    assert settings.get('A') == 'a'


# Generated at 2022-06-24 05:01:33.950820
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    assert getattr(s, 'a') is None
    s.a = 1
    assert hasattr(s, 'a')
    assert s.a == 1


# Generated at 2022-06-24 05:01:39.111551
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch
    from tempfile import mkdtemp
    from shutil import rmtree
    from six import text_type

    args = type('', (), {'yes': None, 'repeat': None, 'debug': False})()


# Generated at 2022-06-24 05:01:40.949476
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class Foo(Settings):
        pass
    foo = Foo()
    foo.something = 'test_value'
    assert foo.something == 'test_value'
    assert foo['something'] == 'test_value'

# Generated at 2022-06-24 05:01:44.451678
# Unit test for constructor of class Settings
def test_Settings():
    # init
    settings_1 = Settings(const.DEFAULT_SETTINGS)
    assert all(settings_1.get(key) == value for key, value in const.DEFAULT_SETTINGS.items())

    # getattr & setattr
    settings_2 = Settings()
    settings_2.require_confirmation = True
    assert settings_2.require_confirmation

# Generated at 2022-06-24 05:01:52.040271
# Unit test for method init of class Settings
def test_Settings_init():
    user_dir = '/user-dir'
    user_dir_file = '/user-dir/user-dir-file'

# Generated at 2022-06-24 05:01:53.932863
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings(a=1)
    assert settings.a == 1
    settings.b = 2
    assert settings.b == 2
    assert settings['b'] == 2

# Generated at 2022-06-24 05:01:57.498999
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings['hello'] = 'world'
    assert settings['hello'] == 'world'

# Unit tests for method __getattr__ of class Settings

# Generated at 2022-06-24 05:02:04.977938
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from .tests.utils import suppress_stdout, FakeArgs

    settings.init()

    try:
        with suppress_stdout():
            settings.require_confirmation = False
            assert settings.require_confirmation == False

            settings.init(FakeArgs(yes=True))
            assert settings.require_confirmation == True

            settings.init(FakeArgs(debug=True))
            assert settings.debug == True

            settings.init(FakeArgs(repeat=True))
            assert settings.repeat == True

    finally:
        settings.init()


# Generated at 2022-06-24 05:02:12.355432
# Unit test for constructor of class Settings
def test_Settings():
    class Settings(dict):
        def __init__(self, settings):
            super(Settings, self).__init__(settings)
            self.user_dir = None
            self.rules = self['rules']
            self.priority = self['priority']
            self.exclude_rules = self['exclude_rules']
            self.no_colors = self['no_colors']
            self.wait_command = self['wait_command']
            self.history_limit = self['history_limit']
            self.slow_commands = self['slow_commands']
            self.wait_slo

# Generated at 2022-06-24 05:02:15.151348
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert isinstance(settings, Settings)
    assert settings.user_dir.joinpath('settings.py')
    assert settings.get('rules') == const.DEFAULT_RULES


# Generated at 2022-06-24 05:02:17.375379
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    global settings
    assert settings.rules
    assert not settings.no_such_attr


# Generated at 2022-06-24 05:02:27.928688
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'),
                                     'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.alter_history == True
    assert settings.require_confirmation == True
    assert settings.wait_command == 0
    assert settings.wait_slow_command == 3
    assert settings.slow_commands == ['lein', 'react-native', 'gradle',
                                      './gradlew', 'vagrant']
    assert settings.no_colors == False
    assert settings.debug == False


# Generated at 2022-06-24 05:02:34.677851
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.hist_limit == 10
    assert settings.slow_commands == ['lein', 'gradle', 'rebar', 'rake', 'python',
                                      'python2', 'python3', 'ruby', 'node']


# Generated at 2022-06-24 05:02:37.034062
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules == const.DEFAULT_RULES


# Generated at 2022-06-24 05:02:38.430495
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.__setattr__('test_Settings', True)
    assert settings.__getattr__('test_Settings') == True

# Generated at 2022-06-24 05:02:40.002619
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert isinstance(settings.rules, list)
    assert 'cd_parent' in settings.rules

# Generated at 2022-06-24 05:02:41.758282
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    s.hello = 'world'
    assert s == {'hello': 'world'}

# Generated at 2022-06-24 05:02:49.408209
# Unit test for constructor of class Settings
def test_Settings():
    # test item assignment
    settings.a = 1
    assert settings.a == 1
    settings.b = 2
    assert settings.b == 2
    assert 'a' in settings
    assert 'b' in settings
    # test item deletion
    del settings.a
    del settings.b
    assert 'a' not in settings
    assert 'b' not in settings
    # test __str__
    settings.a = 1
    assert str(settings) == "{'a': 1}"
    settings.clear()
    assert str(settings) == '{}'

# Generated at 2022-06-24 05:02:51.677902
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.get('require_confirmation')
    assert settings.get('wait_slow_command')


# Generated at 2022-06-24 05:03:00.149291
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    import shutil

    class Args:
        def __init__(self, debug, yes, repeat):
            self.debug = debug
            self.yes = yes
            self.repeat = repeat

    settings.init(Args(False, True, False))
    assert 'require_confirmation' in settings.keys()

    settings.init(Args(True, True, True))
    assert 'debug' in settings.keys()
    assert 'repeat' in settings.keys()

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-24 05:03:05.342489
# Unit test for constructor of class Settings
def test_Settings():
    from .system import Path

    user_dir = Path('~/.config/thefuck').expanduser()
    if user_dir.joinpath('settings.py').is_file():
        raise Exception('settings.py already exists at {}'.format(user_dir))

    settings = Settings(const.DEFAULT_SETTINGS)
    settings._init_settings_file()

    if not user_dir.joinpath('settings.py').is_file():
        raise Exception('settings.py does not exist at {}'.format(user_dir))

# Generated at 2022-06-24 05:03:07.240004
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.new_setting = 'value of new setting'
    assert settings.new_setting == 'value of new setting'


# Generated at 2022-06-24 05:03:09.251890
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.user_dir
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation
    assert settings.priority == const.DEFAULT_PRIORITY

# Generated at 2022-06-24 05:03:11.669588
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    obj = Settings({'a': 1})
    assert obj['a'] == 1
    assert obj.a == 1


# Generated at 2022-06-24 05:03:13.021415
# Unit test for method init of class Settings
def test_Settings_init():
    settings.clear()
    assert settings == const.DEFAULT_SETTINGS
    settings.init()
    assert settings != const.DEFAULT_SETTINGS

# Generated at 2022-06-24 05:03:14.767448
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == True
    assert settings.rules == ('fuck', 'cd_parent', 'ls', 'rm_dir', 'python')
    assert settings.priority == {"fuck": 100, "cd_parent": 10}


# Generated at 2022-06-24 05:03:16.602291
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    s = Settings({"a":1})
    assert s.__getattr__("a") == 1


# Generated at 2022-06-24 05:03:21.983761
# Unit test for constructor of class Settings
def test_Settings():
    def test_getattr():
        assert settings.require_confirmation == False
    def test_setattr():
        settings.require_confirmation = True
        assert settings.require_confirmation == True
    def test_init():
        settings.init()
    test_getattr()
    test_setattr()
    test_init()


if __name__ == '__main__':
    test_Settings()

# Generated at 2022-06-24 05:03:31.512873
# Unit test for method init of class Settings
def test_Settings_init():
    user_dir = settings._get_user_dir_path()
    settings.init()
    assert settings['debug'] is False
    assert settings['require_confirmation'] is True
    assert settings['wait_command'] == 0
    assert settings['history_limit'] == None
    assert settings['repeat'] == False
    assert settings['wait_slow_command'] == 15
    assert settings['no_colors'] is False
    assert settings['instant_mode'] is False
    assert settings['slow_commands'] == []
    assert settings['num_close_matches'] == 3
    assert settings['exclude_rules'] == []
    assert settings['excluded_search_path_prefixes'] == []
    assert settings['alter_history'] is False
    assert settings['priority'] == {}
    assert settings.user_dir == user_dir




# Generated at 2022-06-24 05:03:33.339631
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings({'key': 'value'})
    assert settings.key == 'value'



# Generated at 2022-06-24 05:03:41.859345
# Unit test for method init of class Settings
def test_Settings_init():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    test_settings.init()
    assert test_settings.user_dir == settings.user_dir
    assert test_settings.rules == settings.rules
    assert test_settings.require_confirmation == settings.require_confirmation
    assert test_settings.no_colors == settings.no_colors
    assert test_settings.debug == settings.debug
    assert test_settings.wait_command == settings.wait_command
    assert test_settings.slow_commands == settings.slow_commands
    assert test_settings.history_limit == settings.history_limit
    assert test_settings.alter_history == settings.alter_history
    assert test_settings.exclude_rules == settings.exclude_rules
    assert test_settings.priority == settings.priority

# Generated at 2022-06-24 05:03:46.249656
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.command_not_found == 'zsh: command not found: {script_name}'
    assert not hasattr(settings, '__abrakadabra__')


# Generated at 2022-06-24 05:03:53.023014
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

    assert settings.rules == const.DEFAULT_RULES
    assert settings.wait_command == const.DEFAULT_WAIT_COMMAND
    assert settings.slow_commands == const.DEFAULT_SLOW_COMMANDS
    assert settings.exclude_rules == []
    assert settings.require_confirmation == const.DEFAULT_REQUIRE_CONFIRMATION
    assert settings.no_colors == const.DEFAULT_NO_COLORS
    assert settings.wait_slow_command == const.DEFAULT_WAIT_SLOW_COMMAND
    assert settings.alter_history == const.DEFAULT_ALTER_HISTORY
    assert settings.priority == {}
    assert settings.history_limit == const.DEFAULT_HISTORY_LIMIT

# Generated at 2022-06-24 05:04:01.591256
# Unit test for constructor of class Settings
def test_Settings():
    import unittest
    from tempfile import TemporaryDirectory
    from types import ModuleType
    from thefuck.settings import Settings

    class SettingsTestCase(unittest.TestCase):
        def setUp(self):
            self.settings = Settings()
            self.settings.init()

        def test_load_settings(self):
            self.assertEqual(self.settings.python3, False)
            self.assertEqual(self.settings.require_confirmation, True)

        def test_settings_from_file(self):
            self.assertIsInstance(self.settings._settings_from_file(), dict)


# Generated at 2022-06-24 05:04:05.209163
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    """Should just work"""
    class A(object):
        def __init__(self):
            self.var = 123

    a = A()
    a.__dict__['var'] = 123
    assert a.__dict__['var'] == 123
    assert a.var == 123


# Generated at 2022-06-24 05:04:09.095760
# Unit test for constructor of class Settings
def test_Settings():
    expected_dict = const.DEFAULT_SETTINGS
    #expecting the initial settings dictionary should be the expected dictionary
    assert settings.__dict__ == expected_dict

# Generated at 2022-06-24 05:04:10.180734
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.a = 1
    del settings.a
    assert True

# Generated at 2022-06-24 05:04:18.526241
# Unit test for constructor of class Settings
def test_Settings():
    const.DEFAULT_SETTINGS['test2'] = 'test2'
    const.DEFAULT_SETTINGS['test3'] = 'test3'
    const.DEFAULT_SETTINGS['test4'] = 'test4'
    const.DEFAULT_SETTINGS['test5'] = 'test5'
    const.DEFAULT_SETTINGS['test7'] = 'test7'
    const.DEFAULT_SETTINGS['test8'] = 'test8'
    const.DEFAULT_SETTINGS['test9'] = 'test9'
    const.DEFAULT_SETTINGS['test10'] = 'test10'
    const.DEFAULT_SETTINGS['test11'] = 'test11'
    const.DEFAULT_SETTINGS['test13'] = 'test13'
    const.DEFAULT_SETTINGS

# Generated at 2022-06-24 05:04:23.568642
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings['TEST'] = 'test'
    assert settings['TEST'] == 'test'


# Generated at 2022-06-24 05:04:27.791239
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.key = 'value'

    assert settings.get('key') == 'value'


# Generated at 2022-06-24 05:04:31.568410
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)


# Generated at 2022-06-24 05:04:32.635251
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.repeat = True
    assert settings['repeat'] == True


# Generated at 2022-06-24 05:04:33.839817
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings()
    settings.a = 1
    assert settings.a == 1



# Generated at 2022-06-24 05:04:36.818372
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class TestSettings(Settings):
        def __setattr__(self, key, value):
            super(TestSettings, self).__setattr__(key, value)

    settings = TestSettings(foo=1)
    settings.bar = 'baz'
    assert settings.bar == 'baz'
    assert settings.foo == 1
    assert settings['foo'] == 1


# Generated at 2022-06-24 05:04:39.163226
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    '''
    def __setattr__(self, key, value):
        self[key] = value

    '''
    a = Settings()
    a.__setattr__('a', 1)
    assert a['a'] == 1


# Generated at 2022-06-24 05:04:47.672270
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import sys

    from .system import Path

    from thefuck.conf import settings
    from thefuck.scripts import main
    from thefuck.tests.utils import ensure_called_once, ensure_called_with_arg

    old_environ = dict(os.environ)

# Generated at 2022-06-24 05:04:56.165374
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']
    assert settings.rules == const.DEFAULT_SETTINGS['rules']
    assert settings.priority == const.DEFAULT_SETTINGS['priority']
    assert settings.history_limit == const.DEFAULT_SETTINGS['history_limit']
    assert settings.slow_commands == const.DEFAULT_SETTINGS['slow_commands']
    assert settings.wait_command == const.DEFAULT_SETTINGS['wait_command']
    assert settings.wait_slow_command == const.DEFAULT_SETTINGS['wait_slow_command']
    assert settings.no_colors == const.DEFAULT_SETTINGS['no_colors']
    assert settings.alter_history == const.DEFAULT_SETTINGS['alter_history']

# Generated at 2022-06-24 05:04:57.611547
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = 'test'
    assert settings.get('test') == 'test'



# Generated at 2022-06-24 05:05:01.575717
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules



# Generated at 2022-06-24 05:05:03.528854
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == True

#Unit test for method __setattr__ of class Settings

# Generated at 2022-06-24 05:05:07.512244
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    a = Settings()
    a.attr = 'attr'
    assert a.attr == 'attr'
    assert a['attr'] == 'attr'


# Generated at 2022-06-24 05:05:08.654546
# Unit test for constructor of class Settings
def test_Settings():
    assert settings == const.DEFAULT_SETTINGS



# Generated at 2022-06-24 05:05:12.698437
# Unit test for method init of class Settings
def test_Settings_init():
    from .tests.utils import with_environ

    args = type('Namespace', (), {
        'repeat': None,
        'yes': True,
        'debug': None})

# Generated at 2022-06-24 05:05:14.279525
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class Test(dict):
        pass

    test = Test()
    settings = Settings(test)
    settings.foo = 42
    assert settings.get('foo') == 42
    assert test.get('foo') == 42

# Generated at 2022-06-24 05:05:16.474369
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings_ = Settings({'x': 1})

    assert settings_.x == 1
    assert settings_.y is None



# Generated at 2022-06-24 05:05:17.590459
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert not settings.no_colors


# Generated at 2022-06-24 05:05:19.002045
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.new = 'value'
    assert settings['new'] == 'value'



# Generated at 2022-06-24 05:05:26.559005
# Unit test for method init of class Settings
def test_Settings_init():
    import mock

    settings = Settings(const.DEFAULT_SETTINGS)
    # just set default settings
    settings.init()
    assert const.DEFAULT_SETTINGS == settings
    # set default settings and settings from file
    file_settings = {'key': 'value'}
    with mock.patch('thefuck.conf.settings._settings_from_file', return_value=file_settings):
        assert const.DEFAULT_SETTINGS != settings
        settings.init()
        assert const.DEFAULT_SETTINGS != settings
        assert file_settings == settings
    # set default settings, settings from file and settings from env
    env_settings = {'key1': 'value1', 'key2': 'value2'}

# Generated at 2022-06-24 05:05:28.847924
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings({"one" : 1})
    assert settings.one == 1


# Generated at 2022-06-24 05:05:30.961264
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    value = settings.__setattr__('key', "value")
    assert settings.get('key') == value

# Generated at 2022-06-24 05:05:39.805206
# Unit test for method init of class Settings
def test_Settings_init():
    def assert_settings_correct(settings):
        assert settings.key == 'value'
        assert settings.rules == ['ls', 'cd']
        assert settings.exclude_rules == ['git']
        assert settings.prioritize_matches == False
        assert settings.history_limit == None
        assert settings.no_colors == False
        assert settings.wait_command == 1
        assert settings.alter_history == False


# Generated at 2022-06-24 05:05:41.670069
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings_dict = dict(A='B')
    assert Settings(settings_dict).__getattr__('A') == 'B'


# Generated at 2022-06-24 05:05:43.501799
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings()
    settings['hellow'] = 'Hello World'
    assert settings.hellow == 'Hello World'


# Generated at 2022-06-24 05:05:44.745261
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = "test"
    assert settings.test == "test"



# Generated at 2022-06-24 05:05:55.252569
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import log_to_file
    from os import environ
    from . import const

    mocks = const.DEFAULT_SETTINGS.keys()
    mocks.extend(const.ENV_TO_ATTR.values())
    mocks.extend(['sys.exc_info', '__builtins__.open'])

    environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'true'
    environ['THEFUCK_BEFORE_INVOKE'] = 'before_invoke'
    environ['THEFUCK_AFTER_INVOKE'] = 'after_invoke'
    environ['THEFUCK_WAIT_COMMAND'] = '0.1'
    environ['THEFUCK_SLOW_COMMANDS'] = 'slow_cmd'

# Generated at 2022-06-24 05:05:57.777572
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test_value = 'test_value'
    assert(settings['test_value'] == 'test_value')

# Generated at 2022-06-24 05:06:00.934288
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    TestSettings = type('TestSettings', (Settings,), {})
    TestSettings.__setattr__('a', 'b')
    assert TestSettings['a'] == 'b'
    assert not TestSettings.a


# Generated at 2022-06-24 05:06:05.533368
# Unit test for constructor of class Settings
def test_Settings():
    def getattr(self, item):
        return self.get(item)

    def setattr(self, key, value):
        self[key] = value

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.__getattr__ = getattr
    settings.__setattr__ = setattr
    assert settings.__getattr__("require_confirmation") == False
    assert settings.__getattr__("wait_slow_command") == 1



# Generated at 2022-06-24 05:06:15.552670
# Unit test for method init of class Settings
def test_Settings_init():
    """Unit test for method init of class Settings"""
    os.environ['TF_REQUIRE_CONFIRMATION'] = 'True'
    os.environ['TF_RULES'] = 'DEFAULT_RULES:thefuck.rules.has_been_aliased:thefuck.rules.git_svn_moved_file:thefuck.rules.git_push_was_rejected:thefuck.rules.git_rebase_isnt_rebase'

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()

    assert settings.require_confirmation == True

# Generated at 2022-06-24 05:06:22.649838
# Unit test for method init of class Settings
def test_Settings_init():
    import mock
    import tempfile
    from thefuck import const

    class Args(object):
        def __init__(self):
            self.yes = True
            self.debug = True
            self.repeat = 2

    _settings = Settings(const.DEFAULT_SETTINGS)
    _settings.init(Args())

    assert _settings.get('require_confirmation') == False
    assert _settings.get('debug') == True
    assert _settings.get('repeat') == 2

    _settings = Settings(const.DEFAULT_SETTINGS)
    args = Args()
    args.yes = False
    _settings.init(args)
    assert _settings.get('require_confirmation') == True

    args = Args()
    args.debug = False
    _settings.init(args)
    assert _settings

# Generated at 2022-06-24 05:06:30.782457
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch, MagicMock
    from thefuck.shells import Bash

    class DummyOptparse(object):
        def __init__(self, **keywords):
            for attr, val in keywords.items():
                setattr(self, attr, val)

    with patch('thefuck.settings.load_source') as load_source_mock:
        load_source_mock.return_value = MagicMock()


# Generated at 2022-06-24 05:06:39.350571
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    from .logs import arguments
    from six import StringIO
    from unittest import TestCase
    from click.testing import CliRunner

    class Test(TestCase):
        def setUp(self):
            self.output = StringIO()
            arguments.output = self.output

        def tearDown(self):
            arguments.output = sys.stdout

        def test_settings_from_args(self):
            runner = CliRunner()
            result = runner.invoke(arguments, ['thefuck'], env={'TF_NO_COLORS': '1'})
            self.assertFalse(settings.require_confirmation)
            self.assertTrue(settings.no_colors)

        def test_settings_from_file(self):
            self.assertTrue(settings.require_confirmation)

# Generated at 2022-06-24 05:06:40.722409
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.testing = '123'
    assert settings.testing == '123'


# Generated at 2022-06-24 05:06:44.665790
# Unit test for method init of class Settings
def test_Settings_init():
    import sys
    import os

    class _Settings(Settings):
        def _settings_from_file(self):
            return {'foo': 1}

        def _settings_from_env(self):
            return {'bar': 2}

        def _settings_from_args(self, args):
            return {'baz': 3}

        def _init_settings_file(self):
            pass

    settings = _Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.foo == 1
    assert settings.bar == 2
    assert settings.baz == 3
    assert settings.no_system_rc is False

    settings.reset()
    sys.argv = ['binary.exe', '--yes', '--debug', '--repeat=2']
    settings.init()
    assert settings.require

# Generated at 2022-06-24 05:06:50.946234
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.__getattr__('require_confirmation')
    assert settings.__getattr__('no_colors') is False
    assert settings.__getattr__('use_notify') is True

    settings.init()
    assert settings.__getattr__('require_confirmation')
    assert settings.__getattr__('no_colors') is False
    assert settings.__getattr__('use_notify') is True



# Generated at 2022-06-24 05:06:53.115207
# Unit test for constructor of class Settings
def test_Settings():
    settings_ = Settings(const.DEFAULT_SETTINGS)
    assert settings_ == const.DEFAULT_SETTINGS



# Generated at 2022-06-24 05:07:01.967239
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    import os

    def _remove_dir(dir):
        if os.path.isdir(dir):
            import shutil

            shutil.rmtree(dir)

    path = tempfile.mkdtemp()
    file_path = os.path.join(path, 'settings.py')

# Generated at 2022-06-24 05:07:03.638158
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings['require_confirmation'] == True
    assert settings['repeat'] == False



# Generated at 2022-06-24 05:07:14.844480
# Unit test for constructor of class Settings
def test_Settings():
    # test default Settings
    assert settings.get('require_confirmation') == True
    assert settings.get('repeat') == False
    assert settings.get('rules') == ['git_push', 'git_add', 'ls', 'mvn', 'brew', 'apt_get', 'pip', 'docker']
    assert settings.get('priority') == {}
    assert settings.get('wait_command') == 3
    assert settings.get('history_limit') == 10
    assert settings.get('wait_slow_command') == 10
    assert settings.get('slow_commands') == ['lein', 'react-native', 'gradle', './gradlew', '.\\gradlew.bat']

    # test init method
    settings.init()
    assert settings.get('user_dir').endswith('/.config/thefuck')

   

# Generated at 2022-06-24 05:07:15.934086
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings_ = Settings()

    settings_.test = 1

    assert settings_.test == 1



# Generated at 2022-06-24 05:07:21.134894
# Unit test for constructor of class Settings
def test_Settings():
    args = None
    settings = Settings()
    settings._setup_user_dir()
    settings._init_settings_file()
    settings.update(settings._settings_from_file())
    settings.update(settings._settings_from_env())
    settings.update(settings._settings_from_args(args))

test_Settings()

# Generated at 2022-06-24 05:07:22.468970
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = 'test'
    assert settings['test'] == 'test'

# Generated at 2022-06-24 05:07:24.474060
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)

# Generated at 2022-06-24 05:07:29.591909
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.enable_experimental_instant_mode is True
    assert settings.require_confirmation is True
    assert settings.rules == const.DEFAULT_RULES

# Generated at 2022-06-24 05:07:31.368406
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings['test_key'] = 'test_val'
    assert settings.test_key == 'test_val'


# Generated at 2022-06-24 05:07:35.528819
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    from unittest import TestCase
    class TestSettings(TestCase):
        def test_Settings___getattr__(self):
            test_settings = Settings({'a': 1})
            self.assertEquals(test_settings.a, 1)
    TestSettings().test_Settings___getattr__()


# Generated at 2022-06-24 05:07:38.090169
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.test_Settings___getattr___value = "OK"
    assert settings["test_Settings___getattr___value"] == "OK", (
        "Attribute setting failed")



# Generated at 2022-06-24 05:07:39.948656
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('require_confirmation') == True
    assert settings.get('repeat') == False

# Generated at 2022-06-24 05:07:43.489766
# Unit test for constructor of class Settings
def test_Settings():
    default_settings = const.DEFAULT_SETTINGS
    settings = Settings(default_settings)
    for key, value in default_settings.items():
        assert settings.get(key) == value



# Generated at 2022-06-24 05:07:48.956788
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings({'TRUE_ENV_VAR': True,
                         'TEST_KEY_SEARCH_PATH': '/var/log'})
    assert settings.TEST_KEY_SEARCH_PATH == '/var/log'
    assert settings.TRUE_ENV_VAR is True
    assert settings.NOT_EXIST_KEY is None


# Generated at 2022-06-24 05:07:53.517429
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from .logs import capture_logging
    settings = Settings()
    settings.test = False
    assert settings['test'] is False
    with capture_logging() as logger:
        settings.update({'test': True})
        assert logger.has_warning(u'Setting `update` doesn\'t exist.')



# Generated at 2022-06-24 05:07:58.425454
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    class DummyArgs():
        debug = True
        yes = False
        repeat = "echo"

    settings = Settings()
    settings.init(DummyArgs())

    assert settings.require_confirmation == False
    assert settings.debug == True
    assert settings.repeat == "echo"
    assert settings.help == None

# Generated at 2022-06-24 05:07:59.454504
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, dict)



# Generated at 2022-06-24 05:08:01.166079
# Unit test for method init of class Settings
def test_Settings_init():
    settings_ = Settings()
    settings_.init()
    assert settings_ == const.DEFAULT_SETTINGS

# Generated at 2022-06-24 05:08:07.313155
# Unit test for constructor of class Settings
def test_Settings():
    from .logs import exception
    from .system import get_aliases
    from .utils import get_all_executables

    settings.init()

    alias_dict= get_aliases()
    for i in settings['alias']:
        if i not in alias_dict:
            exception(u"There is no alias '{}' in settings".format(i))

    if not settings['exclude_rules']:
        exception(u"There is no exclude rules in settings")

    if not settings['rules'] and not settings['exclude_rules']:
        exception(u"There is no any rule in settings")

# Generated at 2022-06-24 05:08:16.772416
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import Logger

    logger = Logger('all')
    settings._init_settings_file()
    settings.init()

    assert(settings.user_dir == Path(os.environ['XDG_CONFIG_HOME'], 'thefuck'))
    settings_file = settings.user_dir.joinpath('settings.py')
    with settings_file.open() as file:
        contents = file.read()
        assert(contents.startswith(const.SETTINGS_HEADER))
        assert(contents.endswith('\n'))
    assert(settings.debug == logger.level == 30)
    assert(settings.require_confirmation)
    assert(settings.exclude_rules == const.DEFAULT_RULES)

# Generated at 2022-06-24 05:08:18.489372
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings({"key": "value"})
    assert settings.key == "value"



# Generated at 2022-06-24 05:08:20.081496
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test_key = 'test_value'
    assert settings['test_key'] == 'test_value'


# Generated at 2022-06-24 05:08:22.545418
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.a = 1
    assert settings['a'] == 1


# Generated at 2022-06-24 05:08:25.620663
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings(const.DEFAULT_SETTINGS)
    assert s == const.DEFAULT_SETTINGS



# Generated at 2022-06-24 05:08:26.662394
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = 1
    assert settings["test"] == 1


# Generated at 2022-06-24 05:08:37.203816
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(settings._get_user_dir_path())
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == ()
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ('lein', 'react-native', 'gradle', './gradlew', 'vagrant')
    assert settings.excluded_search_path_prefixes == ('/usr', '/home')
   

# Generated at 2022-06-24 05:08:47.167758
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import captured_logging
    from .system import TemporaryDirectory

    class SettingsTest(object):
        def __init__(self, *args, **kwargs):
            super(SettingsTest, self).__init__(*args, **kwargs)
            self.user_dir = None
            self._settings_from_file = lambda: {'test': True}
            self._settings_from_env = lambda: {'test': True}
            self._settings_from_args = lambda x: {'test': True}

    with captured_logging(level='ERROR') as logs:
        with TemporaryDirectory() as tmp_dir:
            # Test case: exception
            settings = SettingsTest()
            settings.user_dir = tmp_dir
            settings.init()


# Generated at 2022-06-24 05:08:49.668519
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    """
    Settings class should support set attribute directly
    """
    from .logs import log

    settings.log = log
    assert settings.log is log



# Generated at 2022-06-24 05:08:53.405179
# Unit test for method init of class Settings
def test_Settings_init():
    settings_ = Settings(const.DEFAULT_SETTINGS)
    settings_.debug = True
    settings_.require_confirmation = False
    settings_.repeat = 3
    settings_.init()
    assert settings.debug == True
    assert settings.require_confirmation == False
    assert settings.repeat == 3


# Generated at 2022-06-24 05:08:58.177179
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class A():
        settings = {}

    a = A()
    a.settings['key'] = 'value'
    assert 'key' in a.settings
    assert a.settings.get('key') == 'value'

# Generated at 2022-06-24 05:09:00.962963
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.settings_path == const.DEFAULT_SETTINGS
test_Settings()

# Generated at 2022-06-24 05:09:02.870466
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert hasattr(settings, 'default_matcher')



# Generated at 2022-06-24 05:09:13.466006
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    import imp
    import os
    import sys

    def _init_settings_file():
        settings_path = settings._get_user_dir_path().joinpath('settings.py')

        # Set up test settings.py that is loaded in test
        with settings_path.open(mode='w') as settings_file:
            settings_file.write(const.SETTINGS_HEADER)
            setting_content = '# {} = {}\n'
            for setting in const.DEFAULT_SETTINGS.items():
                settings_file.write(setting_content.format(*setting))
            settings_file.write('test = 10')

    def _setup_user_dir():
        # Set up the user directory
        user_dir = settings._get_user_dir_path()

# Generated at 2022-06-24 05:09:14.570967
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    def _():
        return Settings(a='b').a
    assert _() == 'b'



# Generated at 2022-06-24 05:09:20.303709
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('require_confirmation') == True
    assert settings.get('use_notify') == True
    assert settings.get('notify_timeout') == 3
    assert settings.get('wait_command') == 3
    assert settings.get('wait_slow_command') == 8



# Generated at 2022-06-24 05:09:25.189626
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.test_key = 'test_value'
    assert(settings.test_key == 'test_value')
    assert(settings['test_key'] == 'test_value')


# Generated at 2022-06-24 05:09:26.199877
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.vcs_settings == 'git'


# Generated at 2022-06-24 05:09:27.248250
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.command_not_found == 'echo'



# Generated at 2022-06-24 05:09:29.718077
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    from thefuck.settings import Settings
    settings = Settings({'a': 1, 'b': 2})
    assert settings.a == 1
    assert settings.b == 2


# Generated at 2022-06-24 05:09:33.509746
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    s = Settings()
    s.test = 'test'
    assert s['test'] == 'test'
    assert s.test == 'test'


# Generated at 2022-06-24 05:09:37.493390
# Unit test for constructor of class Settings
def test_Settings():
    from .logs import log_to_stderr
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.require_confirmation
    assert settings.repeat == 1
    log_to_stderr()


# Generated at 2022-06-24 05:09:42.785397
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import init_log
    from .logs import exception
    from .config import clear

    settings.init(None)
    assert 'require_confirmation' in settings
    assert settings.require_confirmation is True

    # Change log level to error
    init_log('ERROR', config=settings)
    # if the keys of `_settings_from_env` were not check in `_settings_from_args`,
    # it will throw an exception.
    settings._settings_from_args(None)
    settings.init()

    # According to the comments of `_settings_from_file`, it should print an exception when
    # calling `load_source` in `_settings_from_file`.
    settings.init()



# Generated at 2022-06-24 05:09:45.514401
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    global settings

    settings = Settings({'key': 'value'})
    assert settings.key == 'value'
    assert 'no_exists' not in settings.__dict__
    assert 'no_exists' not in settings
    assert settings.no_exists is None



# Generated at 2022-06-24 05:09:46.712990
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation is True


# Generated at 2022-06-24 05:09:48.670668
# Unit test for constructor of class Settings
def test_Settings():
    temp_settings = Settings(const.DEFAULT_SETTINGS)
    assert temp_settings == const.DEFAULT_SETTINGS

# Generated at 2022-06-24 05:09:52.696646
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.settings = 'settings'
    assert settings.settings == 'settings'


# Generated at 2022-06-24 05:09:55.367513
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings._get_user_dir_path() == Path('~/.config/thefuck').expanduser()



# Generated at 2022-06-24 05:09:56.890152
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = 1
    assert settings['test'] == 1


# Generated at 2022-06-24 05:09:58.713568
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test_attr = 'test'
    assert settings['test_attr'] == 'test'

