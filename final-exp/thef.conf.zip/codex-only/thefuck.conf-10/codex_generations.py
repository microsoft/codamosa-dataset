

# Generated at 2022-06-24 05:00:01.677985
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.test_attr = "test_attr"
    assert settings.test_attr == "test_attr"
    assert settings.get("test_attr") == "test_attr"


# Generated at 2022-06-24 05:00:04.381205
# Unit test for constructor of class Settings
def test_Settings():
    from test.pytest_thefuck.utils import AbstractSettingsTest

    class SettingsTest(AbstractSettingsTest):
        settings_cls = Settings

    return SettingsTest

# Generated at 2022-06-24 05:00:07.429586
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # the "Settings(dict)" is not to introduce a side effect
    settings = Settings(dict())
    settings.a = 1
    assert settings.a == 1
    assert settings['a'] == 1

# Generated at 2022-06-24 05:00:08.802239
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.__class__.__name__ == 'Settings'

test_Settings()

# Generated at 2022-06-24 05:00:16.540750
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import Logger

    settings.init()
    assert type(settings.require_confirmation) == bool
    assert type(settings.wait_command) == int
    assert type(settings.history_limit) == int
    assert type(settings.wait_slow_command) == int
    assert type(settings.slow_commands) == list
    assert type(settings.excluded_search_path_prefixes) == list
    assert type(settings.num_close_matches) == int
    assert type(settings.priority) == dict
    assert type(settings.rules) == list
    assert type(settings.exclude_rules) == list
    assert type(settings.no_colors) == bool
    assert type(settings.debug) == bool
    assert type(settings.alter_history) == bool

# Generated at 2022-06-24 05:00:21.510002
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.user_dir == Settings._get_user_dir_path()
    assert settings._get_user_dir_path() == Path('~/.config/thefuck').expanduser()
    assert settings is not Settings()  # singleton



# Generated at 2022-06-24 05:00:22.529893
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['exclude_rules'] == []

# Generated at 2022-06-24 05:00:28.909533
# Unit test for constructor of class Settings
def test_Settings():
    settings.init()
    assert settings.adapter
    assert settings.wait_command
    assert settings.require_confirmation
    assert settings.priority
    assert settings.history_limit
    assert settings.wait_slow_command
    assert settings.slow_commands
    assert settings.rules
    assert settings.exclude_rules
    assert settings.excluded_search_path_prefixes
    assert settings.num_close_matches
    assert settings.alter_history
    assert settings.instant_mode
    assert settings.no_colors

# Generated at 2022-06-24 05:00:37.334482
# Unit test for constructor of class Settings
def test_Settings():
    assert 'python' in settings.rules
    assert settings.require_confirmation
    assert settings.wait_command == 0
    assert settings.priority['python'] == 25
    assert settings.history_limit == 0
    assert not settings.no_colors
    assert not settings.debug
    assert not settings.alter_history
    assert not settings.instant_mode
    assert settings.wait_slow_command == 15
    assert not settings.slow_commands
    assert settings.num_close_matches == 3
    assert not settings.excluded_search_path_prefixes


# Unit tests for some methods

# Generated at 2022-06-24 05:00:46.564554
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import screen_logger
    from .tempdir import TempDir

    # cleans up settings
    def _init_settings():
        for var in const.DEFAULT_SETTINGS:
            delattr(settings, var)

    # asserts whether or not the setting has changed
    def _assert_settings_changed(expected, actual):
        assert expected != actual

    # asserts whether or not the setting has not changed
    def _assert_settings_not_changed(expected, actual):
        assert expected == actual

    class _MockClass(object):
        def __init__(self):
            self.debug = True
            self.repeat = 2
            self.yes = True

    _MockClass.__name__ = 'Args'
    args = _MockClass()


# Generated at 2022-06-24 05:00:49.565660
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.name = 'The Fuck'
    assert settings.get("name") == 'The Fuck'
    settings.name = "The Fuck"
    assert settings.get("name") == "The Fuck"

# Generated at 2022-06-24 05:00:51.193750
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert settings.rules == const.DEFAULT_RULES

# Generated at 2022-06-24 05:00:55.672761
# Unit test for constructor of class Settings
def test_Settings():
    settings.init()
    assert settings.require_confirmation
    assert settings.rules == const.DEFAULT_RULES

# Generated at 2022-06-24 05:01:00.908529
# Unit test for method init of class Settings
def test_Settings_init():
    settings.update(settings._settings_from_file())
    assert settings.rules == const.DEFAULT_RULES
    settings.init('rules=fuck')
    assert settings.rules == 'fuck'
    assert settings.require_confirmation == True
    settings.init('--yes')
    assert settings.require_confirmation == False
    assert settings.repeat == False
    settings.init('-r')
    assert settings.repeat == True

# Generated at 2022-06-24 05:01:02.640607
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings._settings_from_env() == {}


# Generated at 2022-06-24 05:01:06.343309
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.__setattr__('require_confirmation', False)
    settings.__setattr__('wait_command', 0)
    assert settings['require_confirmation'] == False
    assert settings['wait_command'] == 0

# Generated at 2022-06-24 05:01:12.176736
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    global settings
    temp_settings = Settings()
    temp_settings.custom_setting = 'custom'
    assert temp_settings['custom_setting'] == 'custom'
    settings = temp_settings

# Generated at 2022-06-24 05:01:16.118853
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    d = Settings()
    d.attr = 'attr'
    assert d['attr'] == 'attr'
    assert d.attr == 'attr'



# Generated at 2022-06-24 05:01:18.573655
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.confirm == True
    assert settings.python_path == 'python'
    assert settings.alias == 'fuck'
    assert settings.require_confirmation == True


# Generated at 2022-06-24 05:01:26.152902
# Unit test for constructor of class Settings
def test_Settings():
  settings.init()
  assert settings.get('require_confirmation') == True
  assert settings.get('history_limit') == 0
  assert settings.get('wait_command') == 1
  assert settings.get('wait_slow_command') == 15
  assert settings.get('rules') == ['git_push', 'man', 'pip', 'brew', 'apt_get', 'emerge', 'pacman', 'pkg_add']
  assert settings.get('exclude_rules') == []
  assert settings.get('priority') == {'git_push': 1000, 'emerge': 900, 'pacman': 900, 'pkg_add': 900, 'pip': 900, 'apt_get': 850, 'brew': 800, 'man': 100}
  assert settings.get('no_colors') == False

# Generated at 2022-06-24 05:01:30.512492
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test_int = 100
    assert settings['test_int'] == 100
    settings.test_string = 'settings'
    assert settings['test_string'] == 'settings'
    settings.test_list = ['settings', 'test']
    assert settings['test_list'] == ['settings', 'test']

# Generated at 2022-06-24 05:01:33.881964
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert settings['require_confirmation']
    settings.update({'a_setting': 'a_value'})
    assert settings.a_setting == 'a_value'


# Generated at 2022-06-24 05:01:35.447137
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import settings as _settings

    assert(settings.init().user_dir == _settings.Settings._get_user_dir_path())

# Generated at 2022-06-24 05:01:36.597152
# Unit test for constructor of class Settings
def test_Settings():
    settings_ = Settings(debug = True)
    assert settings_["debug"] == True


# Generated at 2022-06-24 05:01:37.942571
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings()
    settings.key = "value"
    assert settings.key == "value", "Settings and dict is not equal"



# Generated at 2022-06-24 05:01:44.261970
# Unit test for method init of class Settings
def test_Settings_init():
    import mock

    # No settings file, args, os.environ
    with mock.patch('thefuck.settings.os.environ', {}):
        with mock.patch('thefuck.settings.Settings._get_user_dir_path'):
            with mock.patch('thefuck.settings.Settings._settings_from_file') as mock_settings_from_file:
                with mock.patch('thefuck.settings.Settings._settings_from_env') as mock_settings_from_env:
                    with mock.patch('thefuck.settings.Settings._settings_from_args') as mock_settings_from_args:
                        settings.init()
                        assert mock_settings_from_args.call_count == 1
                        assert mock_settings_from_file.call_count == 1
                        assert mock_settings_from_env.call_count == 1

# Generated at 2022-06-24 05:01:48.531053
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.command  == const.DEFAULT_SETTINGS["command"]
    assert settings.settings_path == const.DEFAULT_SETTINGS["settings_path"]


# Generated at 2022-06-24 05:01:52.274629
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.init()
    assert settings.require_confirmation
    assert settings.confirm_exit == 1


# Generated at 2022-06-24 05:01:53.871626
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    settings.init()
    assert exception.called is False



# Generated at 2022-06-24 05:01:57.499451
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.no_colors = 'True'
    assert settings['no_colors'] == 'True'



# Generated at 2022-06-24 05:02:07.598961
# Unit test for method init of class Settings
def test_Settings_init():
    """Test for method init of class Settings"""
    from .logs import exception
    from .utils import transcode
    import sys
    import mock
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    def check_settings_from_file(settings_file):
        """
        Return true if 'settings.py' and 'settings_file' have the same content,
        except comments and empty lines.
        """
        def ignore_comment(line):
            """Return line without comments"""
            return line.split('#')[0]
        with open(settings.user_dir.joinpath('settings.py')) as f:
            file1 = map(ignore_comment, f.readlines())

# Generated at 2022-06-24 05:02:08.776334
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.a = 1
    assert settings['a'] == 1


# Generated at 2022-06-24 05:02:17.748154
# Unit test for constructor of class Settings
def test_Settings():
  from .logs import exception
  from . import rules
  from .tools import get_all_executables

  def _get_all_rules(settings):
    for rule in get_all_executables(rules.__path__[0], 'rule'):
      rule = load_source('', text_type(rule))
      if hasattr(rule, 'enabled_by_default'):
        enabled_by_default = getattr(rule, 'enabled_by_default')
        if enabled_by_default:
          yield rule.__name__[:-len('_rule')]
      else:
        yield rule.__name__[:-len('_rule')]


# Generated at 2022-06-24 05:02:28.045206
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.user_dir == Path('/home/dma/.config/thefuck')
    assert settings.alter_history == False
    assert settings.history_limit == None
    assert settings.no_colors == False
    assert settings.require_confirmation == True

# Generated at 2022-06-24 05:02:39.962038
# Unit test for constructor of class Settings
def test_Settings():
    from .logs import clear_logger
    from .logs import log_to_file
    from .logs import get_logger
    from six import StringIO
    from io import open
    from .system import TemporaryDirectory
    from .logs import exception
    import os
    import sys

    with TemporaryDirectory() as temp_path:
        clear_logger()
        log_to_file(temp_path)
        with open(os.path.join(temp_path, 'settings.py'), mode='w', encoding='utf-8') as user_config:
            user_config.write(const.SETTINGS_HEADER)
            user_config.write(u'DEBUG = True')
        settings = Settings(const.DEFAULT_SETTINGS)
        try:
            settings.init()
        except Exception:
            exception

# Generated at 2022-06-24 05:02:43.054282
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    global settings
    settings.test_attr = 'test_attr'
    assert settings.test_attr == 'test_attr'
    assert settings['test_attr'] == 'test_attr'


# Generated at 2022-06-24 05:02:52.778132
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.user_dir == Path('~', '.config', 'thefuck')
    assert settings.exclude_rules == ()
    assert settings.require_confirmation == True
    assert settings.num_close_matches == 3
    assert settings.priority == {}
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.history_limit == None
    assert settings.instant_mode == False
    assert settings.alter_history == False
    assert settings.excluded_search_path_prefixes == ()
    assert settings.slow_commands == ('lein', 'react-native', 'gradle', './manage.py', 'vagrant')
    assert settings.debug == False
    assert settings.repeat == False


# Generated at 2022-06-24 05:02:55.690302
# Unit test for method init of class Settings
def test_Settings_init():
    """Test method init of class Settings.

    Test that no error occurs during the execution of method init.
    """
    settings = Settings()
    settings.init()

# Generated at 2022-06-24 05:02:57.293184
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.foo = 'bar'
    assert settings.foo == 'bar'


# Generated at 2022-06-24 05:03:03.292159
# Unit test for method init of class Settings
def test_Settings_init():
    args = argparse.Namespace(yes=True, debug=False, repeat=None)
    settings.init(args)
    assert settings.require_confirmation is False, 'no'
    assert settings.debug is False, 'no'
    assert settings.repeat is None, None



# Generated at 2022-06-24 05:03:05.070025
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.test = "test"
    assert settings.test == "test"


# Generated at 2022-06-24 05:03:07.561092
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    assert settings.init() == None
    assert settings.user_dir.is_dir()
    assert settings.user_dir.joinpath('settings.py').is_file()


# Generated at 2022-06-24 05:03:19.150291
# Unit test for method init of class Settings
def test_Settings_init():
    import subprocess
    from tempfile import TemporaryDirectory

    settings = Settings()
    subprocess.call(['pip install thefuck'], shell=True)

    with TemporaryDirectory() as tempdir:
        os.chdir(tempdir)
        with open('settings.py', 'w') as settings_file:
            settings_file.write(const.SETTINGS_HEADER)
            settings_file.write('require_confirmation = True')

        settings.init()
        assert settings['require_confirmation']

        os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'false'
        settings.init()
        assert settings['require_confirmation']

        del os.environ['THEFUCK_REQUIRE_CONFIRMATION']

# Generated at 2022-06-24 05:03:21.091799
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings

# Generated at 2022-06-24 05:03:23.422703
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['require_confirmation'] == True
    assert settings['repeat'] == False
    assert settings.get('repeat') == False
    settings.init(None)

# Generated at 2022-06-24 05:03:30.419958
# Unit test for method init of class Settings
def test_Settings_init():
    user_dir = '/tmp/thefuck/'
    settings.user_dir = lambda: user_dir
    settings.update({k: 1 for k in const.DEFAULT_SETTINGS.keys()})
    settings.init()
    assert settings['wait_command'] == 1
    settings.user_dir = lambda: user_dir
    settings.init()
    assert settings['wait_command'] == 1
    settings.update({k: 2 for k in const.DEFAULT_SETTINGS.keys()})
    settings.init()
    assert settings['wait_command'] == 2


# Generated at 2022-06-24 05:03:37.192266
# Unit test for constructor of class Settings
def test_Settings():
    import argparse

    s = Settings(const.DEFAULT_SETTINGS)
    s.init()
    assert s == const.DEFAULT_SETTINGS
    parser = argparse.ArgumentParser()
    parser.add_argument('--debug')
    parser.add_argument('--yes')
    s.init(parser.parse_args(['--yes', '--debug', 'True']))
    assert s['require_confirmation'] == False
    assert s['debug'] == True
    s.init(parser.parse_args(['--yes']))
    assert s['repeat'] == 1
    s.init(parser.parse_args(['--yes', '--repeat', '2']))
    assert s['repeat'] == 2

# Generated at 2022-06-24 05:03:39.408069
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings({'test': 1})
    s.test = 2
    assert s['test'] == 2

    s.test2 = 3
    assert s['test2'] == 3


# Generated at 2022-06-24 05:03:41.055845
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.version == '3.1'
    assert settings.require_confirmation is True
    assert settings.no_colors is False



# Generated at 2022-06-24 05:03:44.671598
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.__setattr__('aaa', 'aaa')
    assert settings['aaa'] == 'aaa'


# Generated at 2022-06-24 05:03:52.262419
# Unit test for method init of class Settings
def test_Settings_init():
    settings_py = settings.user_dir.joinpath('settings.py')
    env_to_attr = const.ENV_TO_ATTR
    default_settings = const.DEFAULT_SETTINGS

    # Test settings_from_file()
    # Initialize test settings.py
    with settings_py.open(mode='w') as settings_file:
        settings_file.write(const.SETTINGS_HEADER)
        for setting in const.DEFAULT_SETTINGS.items():
            settings_file.write(u'{} = {}\n'.format(*setting))

    # Testing if the from_file() really is reading from the settings.py
    assert settings._settings_from_file() == default_settings

    # Test settings_from_env()

# Generated at 2022-06-24 05:03:56.752473
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.settings_version == const.DEFAULT_SETTINGS['settings_version'], \
        'Failed __getattr__ method'


# Generated at 2022-06-24 05:03:59.126143
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert const.DEFAULT_SETTINGS['require_confirmation'] == settings.require_confirmation


# Generated at 2022-06-24 05:04:02.241165
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir == Path(u'~/.config/thefuck').expanduser()

# Generated at 2022-06-24 05:04:03.349760
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.user_dir.joinpath('settings.py').is_file()

# Generated at 2022-06-24 05:04:12.905083
# Unit test for method init of class Settings
def test_Settings_init():
    from collections import namedtuple
    import tempfile

    Args = namedtuple('Args', 'yes repeat debug')

    with tempfile.TemporaryDirectory() as config_dir:
        settings.user_dir = Path(config_dir, 'thefuck')

        settings.init(Args(True, False, False))
        assert not settings.require_confirmation

        settings.init(Args(False, True, False))
        assert settings.repeat

        settings.init(Args(False, False, True))
        assert settings.debug

        settings_path = settings.user_dir.joinpath('settings.py')
        with settings_path.open() as settings_file:
            assert settings_file.read().startswith(const.SETTINGS_HEADER)

# Generated at 2022-06-24 05:04:23.796867
# Unit test for method init of class Settings
def test_Settings_init():

    import os
    from .logs import exception

    class FakeSysModule(object):

        def __init__(self):
            self.platform = 'linux'
            self.version = '2.7.11'

        def exit(self, n):
            pass

    class FakeArgParser(object):

        def __init__(self):
            self.yes = False

    class FakePath(object):

        def __init__(self):
            self.dirs = []

        def joinpath(self, name):
            return self.dirs.append(name)

        def is_file(self):
            return False

        def open(self, mode):
            return FakeFile()

    class FakeFile(object):

        def __init__(self):
            self.content = ''

        def write(self, data):
            self

# Generated at 2022-06-24 05:04:25.513929
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    setattr(settings, 'key', 'value')
    assert settings.key == 'value'


# Generated at 2022-06-24 05:04:27.448576
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = True
    assert settings['test'] == True
    settings['test'] = False
    assert settings.test == False

# Generated at 2022-06-24 05:04:32.085159
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings({'test': 'test'})
    assert settings.__getattr__('test') == 'test'


# Generated at 2022-06-24 05:04:33.184623
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = 'Test'
    assert settings['test'] == 'Test'

# Generated at 2022-06-24 05:04:34.236014
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['require_confirmation']
    assert not settings['debug']

# Generated at 2022-06-24 05:04:35.298342
# Unit test for constructor of class Settings
def test_Settings():
    assert settings == const.DEFAULT_SETTINGS


# Generated at 2022-06-24 05:04:42.380151
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings({'require_confirmation': True, 'settings_dir': '/dir'})
    settings.init({'yes': True})
    assert settings == {'require_confirmation': False, 'settings_dir': '/dir'}

    settings = Settings({'require_confirmation': True, 'settings_dir': '/dir'})
    settings.init({'debug': True})
    assert settings == {'require_confirmation': True, 'debug': True,
                        'settings_dir': '/dir'}

    settings = Settings({'require_confirmation': True, 'settings_dir': '/dir',
                         'repeat': True})
    settings.init({'repeat': False})
    assert settings == {'require_confirmation': True, 'settings_dir': '/dir',
                        'repeat': False}


# Generated at 2022-06-24 05:04:44.062479
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings['a'] = 'b'
    assert settings.a == 'b'


# Generated at 2022-06-24 05:04:51.204166
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert isinstance(settings, Settings)
    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['exclude_rules'] == []
    assert settings['priority'] == {}
    assert settings['history_limit'] == 100
    assert settings['wait_command'] == 5
    assert settings['wait_slow_command'] == 15
    assert settings['alter_history'] is False
    assert settings['wait_slow_command'] == 15
    assert settings['require_confirmation'] is True
    assert settings['no_colors'] is False
    assert settings['debug'] is False
    assert settings['require_confirmation'] is True
    assert settings['instant_mode'] is False
    assert settings['num_close_matches'] == 3

# Generated at 2022-06-24 05:04:52.305772
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    assert test_settings['rules'] == const.DEFAULT_RULES

# Generated at 2022-06-24 05:04:55.644022
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()

    settings.update(const.TEST_SETTINGS)
    assert settings.rules == const.TEST_SETTINGS['rules']
    assert settings.debug == const.TEST_SETTINGS['debug']



# Generated at 2022-06-24 05:04:56.745291
# Unit test for constructor of class Settings
def test_Settings():
    assert settings == const.DEFAULT_SETTINGS



# Generated at 2022-06-24 05:04:58.491211
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class Cls(Settings):
        pass
    a = Cls()
    a.abc = 123
    assert a.get('abc') == 123



# Generated at 2022-06-24 05:05:03.447444
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class TestClass(object):
        def __init__(self):
            self.x = 1

        @property
        def x(self):
            return self._x

        @x.setter
        def x(self, value):
            self._x = value

        @x.deleter
        def x(self):
            del self._x

    test_obj = TestClass()
    def test(key, value):
        test_obj.key = value
        return test_obj.key == value

    assert test('x', 2)
    assert test('y', 1)
    del test_obj.x
    assert 'x' in dir(test_obj)

# Generated at 2022-06-24 05:05:10.537496
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    # Test for getting a key whose value is not None
    settings['test_key_name'] = 'test_key_value'
    assert settings.test_key_name == 'test_key_value'
    # Test for getting a key whose value is None
    settings['test_key_name'] = None
    assert settings.test_key_name is None
    # Test for getting a non-existent key
    assert settings.test_non_existent_key is None


# Generated at 2022-06-24 05:05:16.392775
# Unit test for method init of class Settings
def test_Settings_init():
    # when: settings is initialized
    settings.init()
    assert settings == const.DEFAULT_SETTINGS
    settings.init(args='')
    assert settings == const.DEFAULT_SETTINGS
    settings.init(args='--yes')
    assert settings['require_confirmation'] == False
    settings.init(args='--debug')
    assert settings['debug'] == True
    settings.init(args='--repeat')
    assert settings['repeat'] == True

settings.init()

# Generated at 2022-06-24 05:05:18.756218
# Unit test for method init of class Settings
def test_Settings_init():
    settings_before = settings.copy()
    settings.init()
    settings_before.update(settings_before)
    for key, val in settings_before.items():
        assert settings[key] == val

# Generated at 2022-06-24 05:05:20.455640
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.foo = 'bar'
    assert settings.get('foo') == 'bar'



# Generated at 2022-06-24 05:05:31.058164
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.user_dir.endswith('.thefuck')
    assert settings.alter_history
    assert settings.wait_command
    assert settings.history_limit
    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['wait_slow_command']
    assert settings['slow_commands'] == const.DEFAULT_SLOW_COMMANDS
    assert settings['priority'] == const.DEFAULT_PRIORITY
    assert settings['exclude_rules'] == []
    assert settings['no_colors'] is False
    assert settings['instant_mode'] is False
    assert settings['debug'] is False
    assert settings['excluded_search_path_prefixes'] == []
    assert settings['require_confirmation'] is True
    assert settings['alter_history'] is True

# Generated at 2022-06-24 05:05:32.563248
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.attr = 'attr'
    assert settings['attr'] == settings.attr

# Generated at 2022-06-24 05:05:34.217680
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings({'a': 1})
    assert settings.a == 1


# Generated at 2022-06-24 05:05:35.250707
# Unit test for constructor of class Settings
def test_Settings():
    assert const.DEFAULT_SETTINGS == settings


# Generated at 2022-06-24 05:05:41.230538
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    """Unit test for method __setattr__ of class Settings"""
    s = Settings(dict(a=1, b=2))
    assert(s.a == 1)
    assert(s.b == 2)
    s.a = 3
    assert(s.a == 3)
    assert(s.b == 2)


# Generated at 2022-06-24 05:05:45.487300
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

    assert(settings.user_dir == Path('~/.config/thefuck').expanduser())
    assert(settings.wait_command == 3)

    os.environ['TF_WAIT_COMMAND'] = '5'
    settings.init()
    assert(settings.wait_command == 5)

    del os.environ['TF_WAIT_COMMAND']

# Generated at 2022-06-24 05:05:55.837240
# Unit test for method init of class Settings
def test_Settings_init():
    import collections
    import unittest
    from .logs import _log
    from .logs import exception

    # Mock _log method of 'logs' module
    _log.debug = lambda msg: None
    _log.info = lambda msg: None

    # Mock exception method of 'logs' module
    def exception(msg, err):
        pass

    # Mock methods of OS module
    class OSMock(collections.namedtuple('os', 'path setattr environ getenv putenv')):
        def __new__(cls, path, environ, getenv, putenv):
            return super(OSMock, cls).__new__(cls, path, setattr, environ, getenv, putenv)


# Generated at 2022-06-24 05:06:00.612658
# Unit test for method init of class Settings
def test_Settings_init():
    settings_path = settings.user_dir.joinpath('settings.py')
    assert settings_path.is_file()
    assert settings_path.read_text() == const.SETTINGS_HEADER + u'\n# {} = {}\n'.format(*const.DEFAULT_SETTINGS.items()[0])

# Generated at 2022-06-24 05:06:02.671093
# Unit test for constructor of class Settings
def test_Settings():
    for key in const.DEFAULT_SETTINGS.keys():
        assert settings[key] == const.DEFAULT_SETTINGS[key]


# Generated at 2022-06-24 05:06:04.584501
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.foo = 'bar'
    assert settings.foo == 'bar'
    assert settings['foo'] == 'bar'


# Generated at 2022-06-24 05:06:10.676219
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.require_confirmation
    assert not settings.debug
    settings.require_confirmation = False
    settings.debug = True
    assert not settings.require_confirmation
    assert settings.debug


# Generated at 2022-06-24 05:06:13.603298
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    """Test method __setattr__ of class Settings"""
    s = Settings()
    s.name = 'Tony'
    assert s['name'] == 'Tony'


# Generated at 2022-06-24 05:06:16.999751
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.__setattr__('test_attr', 'foo')
    settings.__setattr__('test_attr2', 'foo2')
    assert settings['test_attr'] == 'foo'
    assert settings.test_attr == settings['test_attr']



# Generated at 2022-06-24 05:06:18.512981
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()


# Generated at 2022-06-24 05:06:20.057830
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert settings["require_confirmation"] == True
    assert settings["repeat"] == False

# Generated at 2022-06-24 05:06:29.442009
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.priority == const.DEFAULT_SETTINGS['priority']
    assert settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']
    assert settings.history_limit == const.DEFAULT_SETTINGS['history_limit']
    assert settings.rules == const.DEFAULT_SETTINGS['rules']
    assert settings.exclude_rules == const.DEFAULT_SETTINGS['exclude_rules']
    assert settings.wait_command == const.DEFAULT_SETTINGS['wait_command']
    assert settings.wait_slow_command == const.DEFAULT_SETTINGS['wait_slow_command']
    assert settings.slow_commands == const.DEFAULT_SETTINGS['slow_commands']
    assert settings.alter_history == const.DEFAULT_SETTINGS['alter_history']

# Generated at 2022-06-24 05:06:32.857820
# Unit test for method init of class Settings
def test_Settings_init():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    test_settings.init()
    assert(test_settings.user_dir.joinpath('rules').is_dir())
    assert(test_settings.user_dir.joinpath('settings.py').is_file())


# Generated at 2022-06-24 05:06:35.778333
# Unit test for constructor of class Settings
def test_Settings():
    settings.init()

    assert settings.user_dir.is_dir()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.user_dir.joinpath('rules').is_dir()

# Generated at 2022-06-24 05:06:38.326311
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    class TestSettings(Settings):
        pass

    settings = TestSettings({"foo": "bar"})
    assert settings.foo == "bar"
    assert settings["foo"] == "bar"


# Generated at 2022-06-24 05:06:45.449610
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    import os

    s = Settings()
    s.a = 1
    assert os.environ.get('THEFUCK_ALTERNATIVE_DIR') is None
    s.alternative_dir = Path('~/.foo/bar').expanduser()
    assert s['alternative_dir'] == Path('~/.foo/bar').expanduser()
    assert os.environ.get('THEFUCK_ALTERNATIVE_DIR') == '~/.foo/bar'

    # Unsetting a setting should unset the corresponding environment variable.
    del os.environ['THEFUCK_ALTERNATIVE_DIR']
    assert os.environ.get('THEFUCK_ALTERNATIVE_DIR') is None
    s.alternative_dir = Path('~/.foo/bar').expanduser()

# Generated at 2022-06-24 05:06:56.533083
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.alias
    assert settings.confirm_exit
    assert settings.default_to_shell
    assert settings.env_size
    assert settings.exclude_rules
    assert settings.help_message
    assert settings.mandatory_envs
    assert settings.no_colors
    assert settings.priority
    assert settings.require_confirmation
    assert settings.rules
    assert settings.slow_commands
    assert settings.wait_command
    assert settings.wait_slow_command
    assert settings.history_limit
    assert settings.no_colors
    assert settings.debug
    assert settings.alter_history
    assert settings.instant_mode
    assert settings.num_close_matches
    assert settings.excluded_search_path_prefixes


# Generated at 2022-06-24 05:07:03.772170
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings['rules'] == ['git_push', 'git_commit', 'git_add', 'sudo', 'python_pip', 'python_mvn', 'brew', 'pip', 'apt_get', 'yarn', 'npm', 'composer', 'rustup', 'stack', 'xcode-select', 'php', 'pip3', 'gh', 'jenv', 'rvm', 'gvm', 'n', 'sdk']
    assert settings['require_confirmation'] == True
    assert settings['wait_slow_command'] == 15
    assert settings['wait_command'] == 10
    assert settings['no_colors'] == True
    assert settings['debug'] == False
    assert settings['repeat'] == False
    assert settings['history_limit'] == 1000


# Generated at 2022-06-24 05:07:05.372555
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.__setattr__('test', 'test')
    assert settings['test'] == 'test'

# Generated at 2022-06-24 05:07:15.243487
# Unit test for method init of class Settings
def test_Settings_init():
    import random
    random_items = {k: random.sample(v) for k, v in const.DEFAULT_SETTINGS.items()}
    settings_path = settings.user_dir.joinpath('settings.py')
    original_settings = []
    settings_data = None

# Generated at 2022-06-24 05:07:24.896925
# Unit test for constructor of class Settings
def test_Settings():
    from .utils import wrap_settings
    from .system import Seq

    def test_empty_settings():
        fake_settings = {}
        with wrap_settings(fake_settings):
            assert settings == const.DEFAULT_SETTINGS
    test_empty_settings()

    def test_default_settings():
        fake_settings = const.DEFAULT_SETTINGS

# Generated at 2022-06-24 05:07:28.249491
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings()
    test_settings.test = True
    assert test_settings['test'] == True

# Generated at 2022-06-24 05:07:37.459532
# Unit test for method init of class Settings
def test_Settings_init():
    import imp
    import inspect
    import mock
    import os
    import sys
    from thefuck.settings import const

    # Warning: this is a fragile test, could be broken by changes in settings.py.
    # We are looking for the settings variable.
    # TODO: replace settings.py with settings.pyc, easier to get settings from
    settings_file = inspect.getsource(imp.load_source('settings',
                                      os.path.abspath('thefuck/settings.py')))
    settings_var = settings_file.partition(const.SETTINGS_HEADER)[2].split('\n')[1]


# Generated at 2022-06-24 05:07:47.364651
# Unit test for method init of class Settings
def test_Settings_init():
    """Unit test for method init of class Settings."""
    from unittest import mock
    from .logs import exception

    args = mock.Mock()
    args.yes = True
    args.debug = True
    args.repeat = 'always'

    class TestSettings(Settings):
        def _settings_from_file(self):
            return {'key': 'value', 'rules': ['ls']}

        def _settings_from_env(self):
            return {'key': 'old_value', 'rules': ['rm']}

        def _settings_from_args(self, args):
            return {'key': 'new_value', 'rules': ['pwd']}

    settings = TestSettings(const.DEFAULT_SETTINGS)
    settings.init(args)
    assert settings.key == 'new_value'


# Generated at 2022-06-24 05:07:50.906548
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    """Test Settings.__setattr__()"""
    tmp_settings = Settings()

    tmp_settings.test_attr = "test_attr"
    assert tmp_settings["test_attr"] == "test_attr"


# Generated at 2022-06-24 05:07:52.303145
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert Settings({"a" : "b"}).a == "b"


# Generated at 2022-06-24 05:07:54.457193
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    test_settings = Settings(a='1')
    assert test_settings.a == '1'


# Generated at 2022-06-24 05:07:56.945685
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.test = 'test'
    assert settings['test'] == 'test'



# Generated at 2022-06-24 05:08:06.242166
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import set_logger
    from .logs import logger
    from .logs import ERROR

    set_logger(logger(lang='en'))

    os.environ['THEFUCK_NO_COLORS'] = 'True'

    settings.init()
    assert settings['no_colors'] == True
    assert settings['require_confirmation'] == True
    assert settings['rules'] == const.DEFAULT_RULES

    settings.init('--yes'.split())
    assert settings['require_confirmation'] == False

    settings.init('--debug'.split())
    assert settings['debug'] == True

    settings.init('--repeat=3'.split())
    assert settings['repeat'] == 3

    del os.environ['THEFUCK_NO_COLORS']
    settings.init()

    assert logger

# Generated at 2022-06-24 05:08:15.791052
# Unit test for method init of class Settings
def test_Settings_init():
    # Given we have a fresh settings object
    test_settings = Settings(const.DEFAULT_SETTINGS)
    # And we have a list of arguments
    args = "--yes"
    # When we call init
    test_settings.init(args)
    # Then we have a user directory
    assert test_settings.user_dir is not None
    # And we have a file 'settings.py' with default settings
    assert Path(test_settings.user_dir, "settings.py") is not None
    # And we have new settings
    assert test_settings.require_confirmation == False
    # And we have settings from arguments
    assert test_settings.require_confirmation == False



# Generated at 2022-06-24 05:08:16.624933
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert hasattr(settings, 'rules')

# Generated at 2022-06-24 05:08:18.429845
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    test_settings = Settings()
    test_settings.a = 10
    assert test_settings.a == 10
    test_settings.b = 'test_string'
    assert test_settings.b == 'test_string'


# Generated at 2022-06-24 05:08:28.638828
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.user_dir == Path(os.path.expanduser('~/.config/thefuck'))
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.wait_command == const.DEFAULT_WAIT_COMMAND
    assert settings.history_limit == const.DEFAULT_HISTORY_LIMIT
    assert settings.priority == const.DEFAULT_PRIORITY
    assert settings.require_confirmation == const.DEFAULT_REQUIRE_CONFIRMATION
    assert settings.no_colors == const.DEFAULT_NO_COLORS
    assert settings.debug == const.DEFAULT_DEBUG
    assert settings.alter_history == const.DEFAULT_ALTER_HISTORY
    assert settings.instant_mode == const.DEFAULT_INSTANT_MODE

# Generated at 2022-06-24 05:08:33.171925
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings = Settings(const.DEFAULT_SETTINGS)
    args = type('args', (object,), {'debug':True,'yes':True,'repeat':True})
    settings.init(args)
    assert settings.debug
    assert not settings.require_confirmation
    assert settings.repeat

# Generated at 2022-06-24 05:08:42.946914
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['DEBUG'] == False
    assert settings['REQUIRE_CONFIRMATION'] == True
    assert settings['ALTER_HISTORY'] == False
    assert settings['WAIT_COMMAND'] == 1
    assert settings['HISTORY_LIMIT'] == None
    assert settings['NO_COLORS'] == False
    assert settings['WAIT_SLOW_COMMAND'] == 15
    assert settings['SLOW_COMMANDS'] == ['lein', 'react-native', 'gradle', './gradlew', './gradlew.bat', 'flutter']
    assert settings['EXCLUDED_SEARCH_PATH_PREFIXES'] == []
    assert settings['REPEAT'] == False
    assert settings['RULES'] == []
    assert settings['EXCLUDE_RULES'] == []
    assert settings

# Generated at 2022-06-24 05:08:48.420556
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # test original one
    settings.__setattr__('test', 'test')
    assert settings['test'] == 'test'
    # test __getattr__ and __setattr__
    settings.test = 'test2'
    assert settings['test'] == 'test2'



# Generated at 2022-06-24 05:08:49.626036
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.test = 1
    assert settings['test'] == 1


# Generated at 2022-06-24 05:08:51.038074
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings
    settings.__setattr__('foo', 'bar')

# Generated at 2022-06-24 05:08:58.745344
# Unit test for method init of class Settings
def test_Settings_init():
    s = Settings()
    s._settings_from_file = lambda: {
        "require_confirmation": True, "fuck_interpolation_depth": 100
    }
    s._settings_from_env = lambda: {
        "eval_expression": "fuck", "history_limit": 1000
    }
    s._settings_from_args = lambda x: {}
    s.user_dir = 'user_dir'
    s.init()
    assert s.fuck_interpolation_depth == 100
    assert s.require_confirmation
    assert s.eval_expression == 'fuck'
    assert s.history_limit == 1000

# Generated at 2022-06-24 05:09:00.219164
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.abc = 1
    assert settings['abc'] == 1

# Generated at 2022-06-24 05:09:04.083341
# Unit test for constructor of class Settings
def test_Settings():

    # Initialise the settings class
    settings.init()

    # Check that the user_dir is correctly set.
    assert settings['user_dir'] == '~/.config/thefuck'

    # Check that the settings_path is correctly set.
    assert settings['settings_path'] == '~/.config/thefuck/settings.py'

# Generated at 2022-06-24 05:09:05.589812
# Unit test for constructor of class Settings
def test_Settings():
    """Dummy function for the unit test of class Settings"""
    assert settings.rules == const.DEFAULT_RULES

# Generated at 2022-06-24 05:09:07.030500
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == True
    assert settings.get('require_confirmation') == True


# Generated at 2022-06-24 05:09:08.534491
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings1 = Settings()
    settings1.key = 1
    assert settings1 == {'key': 1}

# Generated at 2022-06-24 05:09:10.025120
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.test = 'test'
    assert settings.test == 'test'


# Generated at 2022-06-24 05:09:12.480625
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # Given
    key = 'test_key'
    value = 'test_value'

    # When
    settings.__setattr__(key, value)

    # Then
    assert settings.get(key) == value


# Generated at 2022-06-24 05:09:18.915073
# Unit test for constructor of class Settings
def test_Settings():
    """
    Try to set two variables by .init()
    """
    class Args(object):
        pass

    args = Args()
    args.yes = True
    args.debug = True
    settings.init(args)
    assert settings['require_confirmation'] == False
    assert settings['debug'] == True
    assert settings['repeat'] == None

# Generated at 2022-06-24 05:09:25.949716
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(u'~/.config/thefuck').expanduser()
    assert settings.require_confirmation is True
    assert settings.wait_command == const.DEFAULT_SETTINGS['wait_command']
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == const.DEFAULT_SETTINGS['exclude_rules']
    assert settings.history_limit == const.DEFAULT_SETTINGS['history_limit']
    assert settings.wait_slow_command == const.DEFAULT_SETTINGS['wait_slow_command']
    assert settings.slow_commands == const.DEFAULT_SETTINGS['slow_commands']
    assert settings.no_colors is False
    assert settings.num_close_matches == const.DE

# Generated at 2022-06-24 05:09:26.932048
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules == const.DEFAULT_RULES


# Generated at 2022-06-24 05:09:27.640587
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.prefix == 'fuck'

# Generated at 2022-06-24 05:09:29.511559
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation is True
    assert settings.priority is {}
    assert settings.alias is None

# Generated at 2022-06-24 05:09:31.866544
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.wait_command == 2


# Generated at 2022-06-24 05:09:41.556046
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['alter_history'] == True
    assert settings['rules'] == ['git_push', 'git_add']
    assert settings['exclude_rules'] == []
    assert settings['wait_command'] == 2
    assert settings['history_limit'] == 10
    assert settings['require_confirmation'] == True
    assert settings['wait_slow_command'] == 15
    assert settings['slow_commands'] == [
        'lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings['no_colors'] == False
    assert settings['num_close_matches'] == 3
    assert settings['prioritize_match'] == 'first'

# Generated at 2022-06-24 05:09:44.354182
# Unit test for constructor of class Settings
def test_Settings():
    settings_init = Settings({'key': 'value'})
    assert settings_init.get('key') == 'value'
    settings_init.init()
    assert settings_init.get('history_limit') == 0


# Generated at 2022-06-24 05:09:48.744093
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    test_settings = Settings({"key_1": "value_1", "key_2": "value_2"})
    assert test_settings.key_1 == "value_1"



# Generated at 2022-06-24 05:09:58.590298
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import shutil
    import tempfile
    from pathlib import Path

    # Create temporary dir and add support of env vars to tests
    tmpdir = tempfile.mkdtemp()
    os.environ['XDG_CONFIG_HOME'] = tmpdir

    user_dir = Path(tmpdir, 'thefuck')
    settings_path = user_dir.joinpath('settings.py')
    rules_dir = user_dir.joinpath('rules')
