

# Generated at 2022-06-24 05:00:00.680124
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings['test'] = 'test'
    assert settings.test == 'test'



# Generated at 2022-06-24 05:00:02.610144
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.tmp = "test"
    assert settings["tmp"] == "test"


# Generated at 2022-06-24 05:00:04.099731
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()



# Generated at 2022-06-24 05:00:08.475007
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.name = 'name'
    assert settings['name'] == 'name'

# Generated at 2022-06-24 05:00:10.024996
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.a = 1
    assert settings.a == 1



# Generated at 2022-06-24 05:00:15.272997
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.user_dir == Path(const.DEFAULT_SETTINGS['user_dir'])
    settings.init()
    settings.user_dir = 'test_user_dir'
    assert settings.user_dir == 'test_user_dir'

# Generated at 2022-06-24 05:00:27.425504
# Unit test for method init of class Settings
def test_Settings_init():
    p = Path
    settings.init(None)
    assert settings.user_dir == p('~/.config/thefuck').expanduser()
    assert settings.wait_command == 3
    assert settings.slow_commands == [
        'lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.no_colors
    assert not settings.require_confirmation
    assert settings.exclude_rules == ['git_push', 'python_ipython']
    assert settings.excluded_search_path_prefixes == ['/usr', '/bin', '/sbin']
    assert (settings.priority ==
            {'brew_install': -2, 'brew_cask_install': -2, 'pip_install': -1})
    assert settings.wait_slow_command == 15

# Generated at 2022-06-24 05:00:29.609391
# Unit test for method __setattr__ of class Settings

# Generated at 2022-06-24 05:00:31.543845
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    val = 'Value'
    settings['key'] = val
    assert settings.key == val



# Generated at 2022-06-24 05:00:32.515130
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation


# Generated at 2022-06-24 05:00:34.412025
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.__setattr__('a', 1)
    assert settings['a'] == 1



# Generated at 2022-06-24 05:00:44.753911
# Unit test for method init of class Settings
def test_Settings_init():
    """To test Settings class,a test_settings module is created.
    """
    import inspect
    import shutil
    import tempfile
    import unittest

    from . import settings as test_settings

    class TestSettings(unittest.TestCase):
        """TestSettings is the unittest class for Settings class.
        """
        def setUp(self):
            self.test_dir = Path(tempfile.mkdtemp())

        def tearDown(self):
            shutil.rmtree(self.test_dir)

        def test_init_settings(self):
            test_settings.init()
            self.assertTrue(self.test_dir.joinpath('settings.py').is_file())

# Generated at 2022-06-24 05:00:49.058654
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings({'key1': 1, 'key2': 2, 'key3': 3})
    assert settings.key1 == 1
    assert settings.key2 == 2
    assert settings.key3 == 3


# Generated at 2022-06-24 05:00:50.591262
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.testing = 'testing'
    assert settings.testing == 'testing'


# Generated at 2022-06-24 05:01:01.469051
# Unit test for method init of class Settings
def test_Settings_init():
    
    from .logs import LoggerManager
    from .logs import logger
    from .logs import logger
    from .logs import log
    from .logs import debug
    from .logs import exception
    from .logs import warning
    from .logs import require_confirmation
    from .logs import print_result
    
    class Test_method_init(unittest.TestCase):
        """test init(self, args=None)"""
        
        def setUp(self):
            self.test = Settings()
        
        def test_init_settings_file(self):
            """test init_settings_file(self)"""
            
            class Test_init_settings_file(unittest.TestCase):
                """test init_settings_file(self)"""
                

# Generated at 2022-06-24 05:01:08.369351
# Unit test for constructor of class Settings
def test_Settings():
    assert type(settings) is Settings
    assert settings['require_confirmation'] is True
    assert settings['no_colors'] is False
    assert settings['wait_slow_command'] is 15
    assert settings['alter_history'] is False
    assert settings['priority'] == {}
    assert len(settings['exclude_rules']) == 0
    assert settings['history_limit'] is None
    assert settings['instant_mode'] is False
    assert len(settings['slow_commands']) == 0
    assert len(settings['excluded_search_path_prefixes']) == 0



# Generated at 2022-06-24 05:01:14.428806
# Unit test for method init of class Settings
def test_Settings_init():
    SETTINGS = {
        'wait_command': 1,
        'wait_slow_command': 3,
        'history_limit': 5,
        'require_confirmation': False,
        'rules': ['cd', 'cp'],
        'exclude_rules': ['ls', 'pwd'],
        'priority': {'cd': 2, 'cp': 1},
        'no_colors': True,
        'alter_history': False,
        'exclude_rules': ['ls', 'pwd'],
        'slow_commands': ['python -m SimpleHTTPServer'],
        'excluded_search_path_prefixes': ['pyenv', 'virtualenv'],
        'num_close_matches': 3,
        'instant_mode': False,
    }
    from mock import patch

# Generated at 2022-06-24 05:01:15.991231
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # given
    settings.test = 'value'
    #then
    assert settings.test == 'value'

# Generated at 2022-06-24 05:01:19.398281
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    # Given a new instance of Settings
    x = Settings(const.DEFAULT_SETTINGS)
    # When the value of some key is accessed by attribute notation
    # Then it should return the same value as using the dictionary notation
    assert x.get('key') == x['key']


# Generated at 2022-06-24 05:01:20.864570
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules == ['git_push', 'git_commit', 'sudo']


# Generated at 2022-06-24 05:01:27.721827
# Unit test for method init of class Settings
def test_Settings_init():
    import sys

    def _reload_settings():
        """Reloads module settings"""
        reload(sys.modules[__name__])

    _reload_settings()

    assert settings.require_confirmation
    assert settings.wait_command == 0.3
    assert settings.history_limit == 0
    assert not settings.debug
    assert not settings.alter_history
    assert settings.python3_path is None
    assert settings.sudo_command == 'sudo'
    assert settings.wait_slow_command == 5
    assert not settings.no_colors
    assert not settings.instant_mode
    assert settings.alter_history
    assert settings.repeat == 1
    assert not settings.rules
    assert not settings.exclude_rules
    assert not settings.slow_commands
    assert not settings.excluded_search_path_

# Generated at 2022-06-24 05:01:30.600701
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.leet = 1337
    assert settings.leet == 1337
    assert hasattr(settings, 'leet')
    assert hasattr(settings, '__getattr__')


# Generated at 2022-06-24 05:01:35.408409
# Unit test for method init of class Settings
def test_Settings_init():
    import mock
    import sys
    import os
    from collections import namedtuple

    Arg = namedtuple('Arg', ['yes', 'repeat', 'debug'])
    arg = Arg(yes=True, repeat=2, debug=True)


# Generated at 2022-06-24 05:01:36.606229
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.a = 1
    assert settings.get('a') == 1



# Generated at 2022-06-24 05:01:39.723059
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.no_colors == False
    assert settings.require_confirmation == True
    assert settings.history_limit == None
    assert settings._not_exists is None


# Generated at 2022-06-24 05:01:44.332155
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    test_settings.test_key1 = "test_value1"
    test_settings.test_key2 = "test_value2"
    assert test_settings['test_key1'] == "test_value1"
    assert test_settings['test_key2'] == "test_value2"
    assert test_settings.test_key1 == "test_value1"
    assert test_settings.test_key2 == "test_value2"


# Generated at 2022-06-24 05:01:54.618878
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    empty_settings = Settings()
    assert empty_settings.__getattr__('test_key') == None

    const_settings = Settings(const.DEFAULT_SETTINGS)
    assert const_settings.__getattr__('rules') == ['cd_parent', 'git_push',
            'git_add', 'git_rm', 'git_commit', 'git_branch', 'git_checkout',
            'svn_revert', 'svn_commit', 'svn_add', 'svn_rm', 'svn_switch',
            'svn_update', 'svn_cleanup', 'npm_install', 'pip_install',
            'stack_install']

    const_settings.__setattr__('test_key', 123)
    assert const_settings.__getattr__('test_key') == 123

# Generated at 2022-06-24 05:01:57.145212
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    setattr(settings, 'replace', True)
    assert settings.replace


# Generated at 2022-06-24 05:02:00.036339
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.__setattr__('enable', 'true')
    assert settings.get('enable') == 'true'


# Generated at 2022-06-24 05:02:04.228368
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    assert test_settings.__getattr__('history_limit') == 15
    test_settings.__setattr__('history_limit', 20)
    assert test_settings.__getattr__('history_limit') == 20


# Generated at 2022-06-24 05:02:12.159887
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    from .logs import exception
    from .logs import debug
    import os
    import sys

    debug_output = []


# Generated at 2022-06-24 05:02:14.123246
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['rules'] == ['git_add', 'git_bisect']
    assert settings['require_confirmation']


# Generated at 2022-06-24 05:02:24.826526
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert isinstance(settings.wait_command, int)
    assert isinstance(settings.history_limit, int)
    assert isinstance(settings.require_confirmation, bool)
    assert isinstance(settings.no_colors, bool)
    assert isinstance(settings.debug, bool)
    assert isinstance(settings.repeat, int)
    assert isinstance(settings.slow_commands, list)
    assert isinstance(settings.exclude_rules, list)
    assert isinstance(settings.excluded_search_path_prefixes, list)
    assert isinstance(settings.priority, dict)
    assert isinstance(settings.alter_history, bool)
    assert isinstance(settings.instant_mode, bool)


# Generated at 2022-06-24 05:02:32.924175
# Unit test for method init of class Settings
def test_Settings_init():
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'True'
    os.environ['THEFUCK_PRIORITY'] = 'slow=1:confusing=10'
    os.environ['THEFUCK_RULES'] = 'slow:DEFAULT_RULES'
    os.environ['THEFUCK_EXCLUDE_RULES'] = 'confusing'
    os.environ['THEFUCK_WAIT_COMMAND'] = '10'
    os.environ['THEFUCK_NO_COLORS'] = 'True'
    os.environ['THEFUCK_HISTORY_LIMIT'] = '10'
    os.environ['THEFUCK_ALTER_HISTORY'] = 'False'

# Generated at 2022-06-24 05:02:36.049721
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings = Settings(const.DEFAULT_SETTINGS)
    import argparse
    args = argparse.Namespace()
    args.yes = True
    settings.init(args)
    assert not settings.require_confirmation
    args.debug = True
    settings.init(args)
    assert settings.debug

# Generated at 2022-06-24 05:02:38.322976
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings({"a": "b"})
    s.a = "c"
    assert s.a == "c"
    assert s.get("a") == "c"



# Generated at 2022-06-24 05:02:39.631708
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    f = Settings()
    f.foo = 'bar'
    assert f['foo'] == 'bar'

# Generated at 2022-06-24 05:02:50.785852
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from . import const
    from .system import Path

    settings.user_dir = Path('test')
    assert settings.user_dir == Path('test')
    # Check for tuple
    settings.slow_commands = ('slow_commands 1', 'slow_commands 2')
    assert settings.slow_commands == ('slow_commands 1', 'slow_commands 2')
    # Check for double quotes
    settings.wait_command = "test \"test\""
    assert settings.wait_command == "test \"test\""
    # Check for single quotes
    settings.wait_command = 'test \'test\''
    assert settings.wait_command == "test 'test'"
    # Check for mixed quotes
    settings.wait_command = 'test "test"'
    assert settings.wait_command == 'test "test"'

# Generated at 2022-06-24 05:02:56.536971
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings({
        'key': 'value',
        'key2': 'value2'
    })
    settings.test_key = 'test_value'
    assert settings.test_key == 'test_value'
    assert settings.key == 'value'
    assert settings.key2 == 'value2'


# Generated at 2022-06-24 05:02:58.688995
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    # given
    settings['key'] = 'value'

    # when
    ret = settings.key

    # then
    assert 'value' == ret


# Generated at 2022-06-24 05:03:00.181940
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert not settings.debug
    assert settings.get('require_confirmation')
    assert not settings.get('debug')

# Generated at 2022-06-24 05:03:09.030466
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    from .system import TemporaryDirectory
    from .logs import logger

    with TemporaryDirectory() as tmp_dir:
        settings_file = Path(tmp_dir, 'settings.py')
        settings_file.write_text(u'RULES = ["ls"]')
        settings_file.write_text(u'EXCLUDE_RULES = ["ls"]')
        settings_file.write_text(u'PRIORITY = {"ls": 1}')
        settings_file.write_text(u'WAIT_COMMAND = 5')

        with tempfile.NamedTemporaryFile() as f:
            old_stdout = sys.stdout
            sys.stdout = f
            try:
                settings.init()
            finally:
                sys.stdout = old_stdout

            assert settings

# Generated at 2022-06-24 05:03:09.841347
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation

# Generated at 2022-06-24 05:03:11.065133
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.python is None


# Generated at 2022-06-24 05:03:12.890347
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.__setattr__("a", 1)
    assert settings["a"] == 1



# Generated at 2022-06-24 05:03:23.459909
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']
    assert settings.rules == const.DEFAULT_SETTINGS['rules']
    assert settings.wait_command == const.DEFAULT_SETTINGS['wait_command']
    assert settings.no_colors == const.DEFAULT_SETTINGS['no_colors']
    assert settings.alter_history == const.DEFAULT_SETTINGS['alter_history']
    assert settings.priority == const.DEFAULT_SETTINGS['priority']
    assert settings.exclude_rules == const.DEFAULT_SETTINGS['exclude_rules']
    assert settings.wait_slow_command == const.DEFAULT_SETTINGS['wait_slow_command']

# Generated at 2022-06-24 05:03:26.739286
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    some_dict = dict()
    settings_test = Settings(some_dict)
    settings_test.some_attr = 5
    assert some_dict == {'some_attr':5}



# Generated at 2022-06-24 05:03:29.744706
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():

    class Settings(dict):
        def __getattr__(self, item):
            return self.get(item)

    s = Settings()
    s['foo'] = 'bar'
    assert s.foo == 'bar'


# Generated at 2022-06-24 05:03:34.662624
# Unit test for constructor of class Settings
def test_Settings():
    import unittest

    class TestSettings(unittest.TestCase):

        def test_getattr(self):
            settings = Settings()
            settings.test = True
            self.assertTrue(settings.test)

        def test_setattr(self):
            settings = Settings()
            settings.test = True
            self.assertEqual(settings['test'], True)

    unittest.main()

if __name__ == '__main__':
    test_Settings()

# Generated at 2022-06-24 05:03:40.240660
# Unit test for constructor of class Settings
def test_Settings():
    with pytest.raises(Exception):
        settings = Settings()
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.user_dir.endswith('\config\\')
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.user_dir.endswith('\config\\')
    settings = Settings(const.DEFAULT_SETTINGS, user_dir='test')
    assert settings.user_dir.endswith('\test')


# Generated at 2022-06-24 05:03:42.367704
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.a = 1
    assert settings.a == 1


# Generated at 2022-06-24 05:03:51.759098
# Unit test for method init of class Settings
def test_Settings_init():
    import unittest
    import sys

    class TestSettings(unittest.TestCase):
        def test_init_user_dir(self):
            settings.init()
            self.assertTrue(settings.user_dir.is_dir())

        def test_update(self):
            user_dir = settings.user_dir
            settings.init()
            self.assertEqual(settings.user_dir, user_dir)

        def test_init_settings_file(self):
            settings.init()
            self.assertTrue(settings.user_dir.joinpath('settings.py').is_file())

        def test_init_settings_file_if_not_exists_with_default(self):
            with settings.user_dir.joinpath('settings.py').open() as f:
                default_content = f.read

# Generated at 2022-06-24 05:03:56.230780
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings(name = "cxl")
    assert settings.name == "cxl"


# Generated at 2022-06-24 05:03:58.873564
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings(
        {
            'require_confirmation': True,
            'wait_command': 3
        }
    )
    assert settings.require_confirmation is True
    assert settings.wait_command == 3

# Generated at 2022-06-24 05:04:00.506380
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.script == settings['script']


# Generated at 2022-06-24 05:04:03.157846
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.attr = "attr"
    assert settings['attr'] == 'attr'

# Generated at 2022-06-24 05:04:07.170839
# Unit test for method init of class Settings
def test_Settings_init():
    import mock
    import thefuck.main as main
    from thefuck.settings import Settings
    args = mock.MagicMock()
    args.yes = False
    args.debug = None
    args.repeat = None
    settings.__init__(Settings(const.DEFAULT_SETTINGS))
    settings.init(args)
    assert settings.require_confirmation == True
    assert settings.debug == None
    assert settings.repeat == None


# Generated at 2022-06-24 05:04:11.300793
# Unit test for constructor of class Settings
def test_Settings():
    empty_settings = Settings()
    assert empty_settings == {}

    settings_with_default_val = Settings(name="value")
    assert settings_with_default_val == {"name": "value"}

    settings_with_default_val.update(age=123)
    assert settings_with_default_val == {"name": "value", "age": 123}


settings.init()

# Generated at 2022-06-24 05:04:13.835923
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation is True
    assert settings.not_exists is None


# Generated at 2022-06-24 05:04:18.278129
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings(const.DEFAULT_SETTINGS)
    assert s['wait_command'] == 1
    assert s.rules == const.DEFAULT_RULES
    assert s.priority == const.DEFAULT_PRIORITY
    assert s.require_confirmation is False

# Generated at 2022-06-24 05:04:22.761750
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
	settings.__setattr__("name","rayk")
	assert settings["name"] == "rayk"



# Generated at 2022-06-24 05:04:24.364646
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.key = 'value'
    assert settings.key == 'value'
    assert settings['key'] == 'value'



# Generated at 2022-06-24 05:04:26.116902
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert(settings['require_confirmation'] == True)


# Generated at 2022-06-24 05:04:30.918561
# Unit test for method init of class Settings
def test_Settings_init():
    from .system import TemporaryDirectory
    from .logs import LogCaptureTestCase

    with TemporaryDirectory() as temp, LogCaptureTestCase() as testcase:
        settings.user_dir = Path(temp)
        settings.init()
        exception = testcase.exceptions[0][1]
        assert repr(exception) == "Can't load settings from env (NameError('name 'THEFUCK_TRUE_VAL' is not defined',), None)"

# Generated at 2022-06-24 05:04:37.177819
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.init(args=None) == {
        'alter_history': True,
        'debug': False,
        'exclude_rules': ['sudo', 'cd'],
        'excluded_search_path_prefixes': ['/anaconda', '/home/user/.pyenv'],
        'no_colors': False,
        'require_confirmation': True,
        'rules': ['cp_p', 'ls', 'fuck', 'git_push', 'hg', 'rm', 'vim',
                  'brew_install', 'mvn', 'apt_install', 'git_commit']
    }



# Generated at 2022-06-24 05:04:45.782068
# Unit test for constructor of class Settings
def test_Settings():
    assert settings._get_user_dir_path() == Path('~/.config/thefuck').expanduser()

    settings.init()

    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert len(settings.rules) != 0
    assert all(
        [isinstance(rule, (type, text_type)) for rule in settings.rules])
    assert all(
        [rule in sys.modules for rule in settings.rules])
    assert settings.priority == {}
    assert settings.require_confirmation
    assert not settings.no_colors
    assert not settings.debug
    assert not settings.alter_history
    assert not settings.instant_mode
    assert settings.wait_command == 3
    assert settings.wait_slow_command == 10
    assert settings.slow_commands == []

# Generated at 2022-06-24 05:04:48.160583
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert const.DEFAULT_SETTINGS['rules'] == settings.rules


# Generated at 2022-06-24 05:04:56.425342
# Unit test for method init of class Settings
def test_Settings_init():
    '''Test for method init of class Settings'''
    # Test if the default value is equal to the value in const.DEFAULT_SETTINGS
    settings.init()
    print(settings)
    for key, value in const.DEFAULT_SETTINGS.items():
        assert settings.get(key) == value
    # Test if the value in const.DEFAULT_SETTINGS is replaced by the value in 'settings.py'
    settings.update(const.TEST_SETTINGS)
    settings.init()
    for key, value in const.TEST_SETTINGS.items():
        assert settings.get(key) == value
    # Test if the value in 'settings.py' is replaced by the value in env
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'True'

# Generated at 2022-06-24 05:04:58.231743
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert not settings.no_colors
    assert_raises(AttributeError, lambda: settings.undefined_attribute)


# Generated at 2022-06-24 05:05:02.722471
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.testing_dict = {'a': 'b'}
    assert settings.testing_dict == {'a': 'b'}



# Generated at 2022-06-24 05:05:06.198003
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = 3
    assert settings["test"] == 3



# Generated at 2022-06-24 05:05:07.669946
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings = Settings(const.DEFAULT_SETTINGS)

# Generated at 2022-06-24 05:05:08.366778
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.command
    assert not settings.a


# Generated at 2022-06-24 05:05:12.054658
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings({'xxx': 'xxx'})
    assert settings['xxx'] == 'xxx'
    assert settings.xxx == 'xxx'
    settings.yyy = 'yyy'
    assert settings['yyy'] == 'yyy'
    assert settings.yyy == 'yyy'



# Generated at 2022-06-24 05:05:13.717444
# Unit test for constructor of class Settings
def test_Settings():
    import pytest

    with pytest.raises(AttributeError):
        settings.unexisting_attribute



# Generated at 2022-06-24 05:05:15.927940
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    s.__setattr__("key", "value")
    assert s['key'] == 'value'


# Generated at 2022-06-24 05:05:17.016397
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    settings.init()
    assert settings['require_confirmation'] == True
    assert settings['rules'] == const.DEFAULT_RULES

# Generated at 2022-06-24 05:05:18.157088
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.require_confirmation == True



# Generated at 2022-06-24 05:05:18.973775
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.wait_command == 3


# Generated at 2022-06-24 05:05:25.503566
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    """Test method __getattr__ of class Settings

    Function that tests the method __getattr__
    of the class Settings and returns a list of
    strings with the testing results.

    Returns:
        list of str: list with the testing results
    """
    from .logs import init_log
    test_results = []
    init_log(False)

    settings.init()
    test_results.append(
        "thefuck.settings.__getattr__ of class Settings: " +
        ("OK" if settings._get_user_dir_path() == ".thefuck" else "Fail"))

    return test_results


# Generated at 2022-06-24 05:05:27.780013
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    _settings = Settings({'val': 1})
    assert(_settings.val == 1)


# Generated at 2022-06-24 05:05:31.107976
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.attr1 = 1
    assert settings['attr1'] == 1
    settings.attr2 = 2
    assert settings['attr2'] == 2

# Generated at 2022-06-24 05:05:32.920221
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.test = 'test'
    assert settings.test == 'test'



# Generated at 2022-06-24 05:05:41.866455
# Unit test for method init of class Settings
def test_Settings_init():
    os.environ.update({
        'TF_REQUIRE_CONFIRMATION': 'FALSE',
        'TF_PRIORITY': 'cd=0:ls=1:mv=2',
        'TF_SLOW_COMMANDS': 'vagrant',
        'TF_WAIT_COMMAND': '3',
        'TF_WAIT_SLOW_COMMAND': '6',
        'TF_HISTORY_LIMIT': '100',
        'TF_DEBUG': 'TRUE',
        'TF_RULES': 'DEFAULT_RULES:ls',
        'TF_EXCLUDE_RULES': 'pwd',
        'TF_EXCLUDED_SEARCH_PATH_PREFIXES': '/usr/local'
    })

    settings.init()

# Generated at 2022-06-24 05:05:43.020219
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.test_key = 'test'
    assert settings.test_key == 'test'

# Generated at 2022-06-24 05:05:45.412216
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.require_confirmation = False
    assert settings.get('require_confirmation') is False
    assert settings.require_confirmation is False


# Generated at 2022-06-24 05:05:54.371706
# Unit test for method init of class Settings
def test_Settings_init():
    import argparse

    settings.init(argparse.Namespace())
    assert not settings.require_confirmation
    assert not settings.debug
    assert settings.repeat is None

    settings.init(argparse.Namespace(yes=True))
    assert not settings.require_confirmation
    assert not settings.debug
    assert settings.repeat is None

    settings.init(argparse.Namespace(debug=True))
    assert settings.require_confirmation
    assert settings.debug
    assert settings.repeat is None

    settings.init(argparse.Namespace(repeat=2))
    assert settings.require_confirmation
    assert not settings.debug
    assert settings.repeat == 2

# Generated at 2022-06-24 05:05:57.213030
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings()
    test_settings.test = "test"
    assert test_settings['test'] == "test"

# Generated at 2022-06-24 05:06:05.505425
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import shutil
    import tempfile

    base_dir = tempfile.mkdtemp()

    settings_dir = os.path.join(base_dir, '.thefuck')
    os.makedirs(settings_dir)

    with open(os.path.join(settings_dir, 'settings.py'), 'w') as settings_file:
        settings_file.write('#!/usr/bin/env python\n')
        settings_file.write('# -*- coding: utf-8 -*-\n\n')
        settings_file.write('require_confirmation=True\n')
        settings_file.write('wait_command=2\n')
        settings_file.write('history_limit=123\n')


# Generated at 2022-06-24 05:06:13.452124
# Unit test for constructor of class Settings
def test_Settings():
    for env, attr in const.ENV_TO_ATTR.items():
        os.environ[env] = 'val'
    args = type('args', (object, ),
                {'yes': False, 'debug': False, 'repeat': None})()

    try:
        settings = Settings(const.DEFAULT_SETTINGS)
        settings.init(args)
        assert settings['val']
    finally:
        del os.environ['TF_VAL']

# Generated at 2022-06-24 05:06:15.170901
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():

    settings.hello = 'world'
    assert settings['hello'] == 'world'
    assert settings.hello == 'world'
    assert settings.get('hello') == 'world'


# Generated at 2022-06-24 05:06:17.721286
# Unit test for constructor of class Settings
def test_Settings():
    assert type(Settings(const.DEFAULT_SETTINGS)['no_colors']) == bool

# Generated at 2022-06-24 05:06:27.448336
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import log
    from .tests.utils import support_file
    _logs = []

    def _exception(msg, exc_info):
        _logs.append(msg)

    log.exception = _exception
    settings.init()
    assert settings['require_confirmation'] is True
    settings.init(args=type("FakeArgs", (), {'yes':True, 'debug':True}))
    assert settings['require_confirmation'] is False
    settings.init(args=type("FakeArgs", (), {'yes':True, 'debug':True}))
    assert settings['debug'] is True
    assert 'Can\'t load settings from file' in _logs[0]
    assert 'Can\'t load settings from env' in _logs[1]


# Generated at 2022-06-24 05:06:28.655020
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()



# Generated at 2022-06-24 05:06:31.965221
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.__setattr__('test_key', 'test_value')
    assert 'test_key' in settings.keys()
    assert settings['test_key'] == 'test_value'



# Generated at 2022-06-24 05:06:35.857702
# Unit test for method init of class Settings
def test_Settings_init():
    user_dir = settings._get_user_dir_path()
    assert user_dir.exists() is True
    assert user_dir.is_dir() is True

    settings_file = user_dir.joinpath('settings.py')
    assert settings_file.exists() is True
    assert settings_file.is_file() is True



# Generated at 2022-06-24 05:06:39.664394
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from pytest import raises
    from thefuck.settings import Settings
    settings = Settings()

    assert getattr(settings, 'slow_command', False) == False

    with raises(AttributeError):
        getattr(settings, 'fake_attribute')

    settings.slow_command = True
    assert getattr(settings, 'slow_command') == True

# Generated at 2022-06-24 05:06:42.626105
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.get('debug') == False
    settings.debug = True
    assert settings.get('debug') == True

# Generated at 2022-06-24 05:06:52.906819
# Unit test for method init of class Settings
def test_Settings_init():
    # Creates a temporary folder
    import shutil
    import tempfile
    import os
    import os.path
    import sys

    # Creates temporary folder to store The Fuck configuration
    tf = tempfile.mkdtemp(prefix='thefuck-')
    user_dir = os.path.join(tf, '.thefuck')
    os.mkdir(user_dir)

    # Changes the environment variable XDG_CONFIG_HOME to the temporary folder
    os.environ.update(XDG_CONFIG_HOME=tf)

    # Creates settings.py file
    with open(os.path.join(user_dir, 'settings.py'), 'w') as settings:
        settings.write(u'# test\n')

# Generated at 2022-06-24 05:06:54.380349
# Unit test for constructor of class Settings
def test_Settings():
    assert settings == const.DEFAULT_SETTINGS

# Generated at 2022-06-24 05:06:57.306299
# Unit test for constructor of class Settings
def test_Settings():
    m = list(const.DEFAULT_SETTINGS.keys())
    m.sort()

    s = Settings(const.DEFAULT_SETTINGS)
    assert [i for i in s] == m



# Generated at 2022-06-24 05:07:08.050307
# Unit test for method init of class Settings
def test_Settings_init():
    # test 1
    settings.user_dir = Path('~', '.thefuck').expanduser()
    settings.init()
    assert settings.require_confirmation == False
    assert settings.wait_command == 0
    assert settings.repeat == 1
    assert settings.priority == {}
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.no_colors == False
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == [
        'lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.excluded_search_path_prefixes == [
        '/usr', '/bin', '/sbin', '/opt', '/snap', '/home']
    assert settings.history_limit == None


# Generated at 2022-06-24 05:07:09.401013
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == True


# Generated at 2022-06-24 05:07:11.068588
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.a = 'b'
    assert settings.a == 'b'


# Generated at 2022-06-24 05:07:17.385740
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    for attr in const.DEFAULT_SETTINGS.keys():
        assert settings.__getattr__(attr) == const.DEFAULT_SETTINGS[attr]
    settings.new_attr = 123
    assert settings.new_attr == 123
    del settings.new_attr
    assert not settings.new_attr

# testing _settings_from_file

# Generated at 2022-06-24 05:07:18.636171
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from thefuck.conf import settings

    settings.init()
    settings.wait_command = 3

# Generated at 2022-06-24 05:07:19.636782
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation



# Generated at 2022-06-24 05:07:20.240356
# Unit test for constructor of class Settings
def test_Settings():
    pass

# Generated at 2022-06-24 05:07:27.282782
# Unit test for constructor of class Settings
def test_Settings():
    from .logs import exception
    from .logs import logger
    from .logs import set_loggers
    from .logs import set_log_level
    from .const import DEFAULT_SETTINGS
    from .const import ENV_TO_ATTR
    from .const import SETTINGS_HEADER
    from .path import get_all_settings_paths
    from .platform import get_profile_path
    from .utils import get_command_output
    from .utils import get_script_path
    from os import remove
    from os import unsetenv
    from shutil import rmtree
    from sys import version_info
    from thefuck.logs import clear_debug_logs
    from thefuck.logs import clear_history_logs
    from thefuck.logs import debug_logger

# Generated at 2022-06-24 05:07:29.562913
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    import os

    assert settings.user_dir == os.path.expanduser('~/.config/thefuck')
    assert 'rules_folder' in settings

# Generated at 2022-06-24 05:07:33.391482
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    test_settings.__setattr__("test_key", True)
    assert test_settings["test_key"] == True
    assert test_settings.test_key == True


# Generated at 2022-06-24 05:07:34.104414
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.no_colors is True


# Generated at 2022-06-24 05:07:35.360329
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert not settings.debug


# Generated at 2022-06-24 05:07:36.510197
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.rules == const.DEFAULT_RULES



# Generated at 2022-06-24 05:07:38.948982
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert settings.no_colors is False
    assert settings.wait_command == 0
    assert settings.python_bin == settings['python_bin']



# Generated at 2022-06-24 05:07:40.221108
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings == const.DEFAULT_SETTINGS


# Generated at 2022-06-24 05:07:43.034892
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.new_key = 'new_value'
    assert settings['new_key'] == 'new_value'


# Generated at 2022-06-24 05:07:43.908090
# Unit test for constructor of class Settings
def test_Settings():
    assert type(settings) == Settings


# Generated at 2022-06-24 05:07:45.828185
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.test = 'test'
    assert settings['test'] == 'test'

# Generated at 2022-06-24 05:07:47.549830
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.require_confirmation
    assert settings.no_colors


# Generated at 2022-06-24 05:07:56.763593
# Unit test for constructor of class Settings
def test_Settings():
    # Assert function
    def _assert(a, b):
        assert a == b

    # Configure object
    settings.init()

    # Test const.DEFAULT_SETTINGS
    _assert(settings.get('wait_command'), const.DEFAULT_SETTINGS.get('wait_command'))
    _assert(settings.get('wait_slow_command'), const.DEFAULT_SETTINGS.get('wait_slow_command'))
    _assert(settings.get('history_limit'), const.DEFAULT_SETTINGS.get('history_limit'))
    _assert(settings.get('require_confirmation'), const.DEFAULT_SETTINGS.get('require_confirmation'))
    _assert(settings.get('alter_history'), const.DEFAULT_SETTINGS.get('alter_history'))
    _

# Generated at 2022-06-24 05:07:59.064242
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir
    assert settings.history_limit == const.DEFAULT_SETTINGS['history_limit']

# Generated at 2022-06-24 05:08:04.987150
# Unit test for method init of class Settings
def test_Settings_init():
    settings_from_file = load_source(
        'settings', 'tests/settings.py')
    settings_from_args = load_source(
        'settings', 'tests/settings_from_args.py')
    os.environ['THEFUCK_RULE'] = 'env_rule'
    settings_from_env = load_source(
        'settings', 'tests/settings_from_env.py')
    del os.environ['THEFUCK_RULE']

# Generated at 2022-06-24 05:08:08.116292
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.init() == const.DEFAULT_SETTINGS


# Generated at 2022-06-24 05:08:15.645582
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('require_confirmation')
    assert settings.get('history_limit') == 20
    assert settings.get('wait_command') == 10
    assert settings.get('enabled_plugins') is not None
    assert settings.get('exclude_rules') == ['git_push']
    assert settings.get('slow_commands') == ['git']
    assert settings.get('excluded_search_path_prefixes') == []
    assert settings.get('priority') == {}

if __name__ == '__main__':
    test_Settings()

# Generated at 2022-06-24 05:08:19.589522
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.history_limit == None
    assert settings.alter_history == True
    assert settings.require_confirmation == True


# Generated at 2022-06-24 05:08:23.217908
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('require_confirmation', 'false') == 'false'
    assert settings.get('use_standard_error') == True
    assert settings.get('no_colors') == False



# Generated at 2022-06-24 05:08:34.976238
# Unit test for method init of class Settings
def test_Settings_init():
    # TODO: It would be better to use @patch to keep mock.patch
    sys.modules['__main__'] = None
    old_user_dir = settings.user_dir
    settings.init()
    assert settings.user_dir == old_user_dir
    # TODO: doesn't work with mock.patch
    #user_dir = settings._get_user_dir_path()
    user_dir = settings.user_dir
    try:
        Path(user_dir).rmtree()
    except:
        pass
    settings.init()
    assert Path(user_dir).exists()
    assert 'require_confirmation' in settings
    assert 'debug' in settings
    assert 'repeat' in settings


# Unit tests for method _settings_from_env of class Settings

# Generated at 2022-06-24 05:08:36.362637
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation is True
    assert settings.not_existing_key is None

# Generated at 2022-06-24 05:08:37.363870
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.alias == 'fuck'


# Generated at 2022-06-24 05:08:38.925034
# Unit test for constructor of class Settings
def test_Settings():
    assert 'MATCH' in settings
    assert 'NO_COLORS' in settings


# Generated at 2022-06-24 05:08:49.169155
# Unit test for method init of class Settings
def test_Settings_init():
    def _get_sys_path():
        return sys.path

    def _have_this_born_monday():
        return sys.version_info[0] == 3

    def _raise_exception():
        raise Exception

    from mock import patch, MagicMock
    sys.path = _get_sys_path()[:]
    sys.path.append('/usr/fuck')
    with patch.object(sys, 'exc_info', return_value='exc_info'), \
            patch.object(Settings, '_settings_from_env', return_value='{}'), \
            patch.object(Settings, '_settings_from_file',
                         side_effect=_raise_exception):
        settings.init(MagicMock())
        assert sys.path == _get_sys_path()[:]
        assert settings == Settings

# Generated at 2022-06-24 05:08:51.958889
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings__setattr__ = Settings(const.DEFAULT_SETTINGS)
    settings__setattr__.test = 'test'
    assert settings__setattr__.get('test') == 'test'



# Generated at 2022-06-24 05:08:53.989275
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.init() == settings == settings.init(args = None)
    assert settings.update() == settings
    assert settings.update(settings = None) == settings

# Generated at 2022-06-24 05:09:03.649458
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.__getattr__('wait_slow_command') == 3
    assert settings.__getattr__('require_confirmation') == True
    assert settings.__getattr__('no_colors') == False
    assert settings.__getattr__('priority') == {}
    assert settings.__getattr__('history_limit') == None
    assert settings.__getattr__('debug') == False
    assert settings.__getattr__('slow_commands') == []
    assert settings.__getattr__('exclude_rules') == []
    assert settings.__getattr__('excluded_search_path_prefixes') == []
    assert settings.__getattr__('repeat') == False

    settings.__setattr__('a', 1)
    assert settings.__getattr__('a') == 1, settings.__getattr__

# Generated at 2022-06-24 05:09:09.804803
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from mock import MagicMock
    from .logs import print_async

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.debug = True
    settings.require_confirmation = False
    settings.repeat = 3
    settings.print_async = MagicMock()
    settings.print_async.side_effect = print_async
    assert settings['debug'] is True
    assert settings['require_confirmation'] is False
    assert settings['repeat'] is 3
    assert settings.debug is True
    assert settings.require_confirmation is False
    assert settings.repeat is 3

# Generated at 2022-06-24 05:09:20.266074
# Unit test for constructor of class Settings
def test_Settings():
    # Test user's home dir and user's dir for config file
    settings = Settings(const.DEFAULT_SETTINGS)
    from os.path import expanduser
    home = expanduser("~")
    assert settings['user_dir'] == Path(home, ".config", "thefuck")
    assert settings['user_path'] == Path(home, ".config", "thefuck", "settings.py")
    assert settings['rules_dir'] == Path(home, ".config", "thefuck", "rules")
    assert settings['history_file'] == Path(home, ".config", "thefuck", "history")
    assert settings['log_file'] == Path(home, ".config", "thefuck", "thefuck.log")

    # Test Settings from Environment
    settings = Settings(const.DEFAULT_SETTINGS)

# Generated at 2022-06-24 05:09:30.735352
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch
    from .logs import log_exception
    from . import const

    fake_args = {'yes': True, 'debug': False, 'repeat': 3}
    fake_env = {'THEFUCK_RULES': "DEFAULT_RULES:helloworld",
                'THEFUCK_PRIORITY': "helloworld=1:fuck=2",
                'THEFUCK_WAIT_COMMAND': "2",
                'THEFUCK_WAIT_SLOW_COMMAND': "1",
                'THEFUCK_EXCLUDED_SEARCH_PATH_PREFIXES': "/dev:/proc"
                }

# Generated at 2022-06-24 05:09:38.979040
# Unit test for method init of class Settings
def test_Settings_init():
    from collections import namedtuple
    from test.compat import unittest, mock

    class TestSettings(unittest.TestCase):
        @mock.patch('os.environ', {'THEFUCK_WAIT_COMMAND': '1',
                       'THEFUCK_DEBUG': 'true',
                       'THEFUCK_PRIORITY': 'fiz=0',
                       'THEFUCK_RULES': 'bash',
                       'XDG_CONFIG_HOME': '~/.config',
                       'HOME': '~'})
        def test_init_should_return_correct_Settings(self):
            settings.init()

# Generated at 2022-06-24 05:09:39.788197
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.alias == 'fuck'


# Generated at 2022-06-24 05:09:43.056207
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('wait_command') == settings.wait_command
    assert settings.get('require_confirmation') == settings.require_confirmation
    settings.wait_command = 5
    assert settings['wait_command'] == 5
    assert settings['wait_command'] == settings.wait_command

# Generated at 2022-06-24 05:09:45.456753
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    s = Settings(const.DEFAULT_SETTINGS)
    if not isinstance(s.require_confirmation, bool):
        raise RuntimeError('_test_Settings___getattr__ failed')
test_Settings___getattr__()


# Generated at 2022-06-24 05:09:53.629197
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch
    from six import StringIO
    from thefuck.main import main
    from thefuck.logs import exception
    with patch('sys.stderr',
               new_callable=StringIO) as stderr, \
            patch('sys.version_info', (3, 5)), \
            patch('os.environ', {'XDG_CONFIG_HOME': '~/.config'}):
        settings.init()
    assert exception in stderr.getvalue()


# Generated at 2022-06-24 05:09:56.889762
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings['key'] = 'value'
    assert 'value' == settings.key
    try:
        settings.no_such_attribute
    except AttributeError:
        pass


# Generated at 2022-06-24 05:09:58.712555
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = 'test'
    assert settings['test'] == 'test'

