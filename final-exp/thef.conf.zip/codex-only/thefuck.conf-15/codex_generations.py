

# Generated at 2022-06-24 05:00:00.793238
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.update()
    assert settings['wait_command'] == 0.8
    assert settings['require_confirmation'] == True



# Generated at 2022-06-24 05:00:04.334827
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.priority == {'fuck': 4, 'cd': 3, 'ls': 2, 'man': 1}
    settings.priority = {}
    assert settings.priority == {}


# Generated at 2022-06-24 05:00:11.404229
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert settings.rules
    assert settings.no_colors is False
    assert settings.slow_commands
    assert settings.exclude_rules
    assert settings.history_limit
    assert settings.wait_command
    assert settings.wait_slow_command
    assert settings.priority
    assert settings.debug is False
    assert settings.num_close_matches
    assert settings.alter_history is False
    assert settings.instant_mode is False
    assert settings.excluded_search_path_prefixes
    assert settings.repeat


# Generated at 2022-06-24 05:00:13.726455
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert isinstance(s, Settings)
    s.init()
    for k, v in const.DEFAULT_SETTINGS.items():
        assert s[k] == v


# Generated at 2022-06-24 05:00:14.763224
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.x = 1
    assert settings['x'] == 1

# Generated at 2022-06-24 05:00:17.994411
# Unit test for method init of class Settings
def test_Settings_init():
    settings['history_limit'] = 10
    settings.init()
    assert not settings.user_dir.joinpath('rules').is_dir()

    settings.user_dir.joinpath('rules').mkdir()
    settings['history_limit'] = 100
    settings.init()
    assert settings['history_limit'] == 100



# Generated at 2022-06-24 05:00:20.172224
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings({'a': 'b'})
    assert settings.a == 'b'



# Generated at 2022-06-24 05:00:24.775571
# Unit test for method init of class Settings
def test_Settings_init():
    s = Settings()
    s.init()
    assert s.require_confirmation is True
    assert s.wait_command is 1
    assert s.history_limit is None
    assert s.wait_slow_command is 15
    assert s.rules == const.DEFAULT_RULES

# Generated at 2022-06-24 05:00:25.821000
# Unit test for constructor of class Settings
def test_Settings():
    assert settings == const.DEFAULT_SETTINGS

# Generated at 2022-06-24 05:00:29.774625
# Unit test for constructor of class Settings
def test_Settings():
    assert len(settings) == len(const.DEFAULT_SETTINGS)
    for key, value in const.DEFAULT_SETTINGS.items():
        assert settings[key] == value



# Generated at 2022-06-24 05:00:32.074531
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    assert settings.user_dir.name == '.thefuck'
    # TODO how to test `_setup_user_dir()` function

# Generated at 2022-06-24 05:00:37.934188
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings['test_key'] = 'test_value'
    assert settings['test_key'] == 'test_value'

    settings['test_key2'] = 'test_value2'
    assert settings['test_key2'] == 'test_value2'

    settings.test_key3 = 'test_value3'
    assert settings.test_key3 == 'test_value3'



# Generated at 2022-06-24 05:00:46.701267
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import clear_exceptions

    settings.init(args=None)
    assert bool(settings)
    assert settings['history_limit'] == 500
    assert hasattr(settings, 'log_file')
    assert settings.log_file.is_file()
    assert settings.user_dir.is_dir()

    class Args:
        def __init__(self, repeat, yes, debug):
            self.repeat = repeat
            self.yes = yes
            self.debug = debug
    args = Args(repeat=30, yes=True, debug=True)
    settings.init(args=args)
    assert settings['repeat'] == 30
    assert settings['require_confirmation'] is False
    assert settings['debug'] is True

    del os.environ['TF_REPEAT']
    del os.environ

# Generated at 2022-06-24 05:00:48.683743
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.test = True
    assert settings['test'] == True



# Generated at 2022-06-24 05:00:50.374759
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert hasattr(settings, 'help') == True
    assert settings.help == True


# Generated at 2022-06-24 05:01:01.326007
# Unit test for method init of class Settings
def test_Settings_init():
    import sys
    from unittest.mock import patch, mock_open
    from thefuck.settings import Settings, const
    from thefuck.logs import exception
    from thefuck.types import Settings as SettingsType

    class Args(object):
        def __init__(self, yes=False, debug=False, repeat=False):
            self.yes = yes
            self.debug = debug
            self.repeat = repeat

    args = Args()
    settings = Settings()
    user_dir = settings._get_user_dir_path()

# Generated at 2022-06-24 05:01:02.741893
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.fuck = 999
    assert settings.fuck == 999


# Generated at 2022-06-24 05:01:07.422310
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # mock
    class Mock(object):
        pass
    mock = Mock()

    # Exercise
    settings.__setattr__('key', 'value')
    # Verify
    assert settings['key'] == 'value'

    # Exercise and verify again
    settings.__setattr__('MOCK', mock)
    assert settings['MOCK'] == mock



# Generated at 2022-06-24 05:01:13.583010
# Unit test for method init of class Settings
def test_Settings_init():
    import sys
    import os

    args = FakeArgs()
    args.yes = True
    args.debug = True
    args.repeat = False

    settings_path = Path('~', '.thefuck', 'settings.py').expanduser()
    with settings_path.open(mode='r') as settings_file:
        settings_file_contents = settings_file.read()
    if os.path.exists(settings_path):
        os.remove(settings_path)
    if os.environ.get('XDG_CONFIG_HOME') is None:
        os.environ['XDG_CONFIG_HOME'] = '/tmp'

# Generated at 2022-06-24 05:01:14.860627
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.sudo_safe == const.DEFAULT_SETTINGS['sudo_safe']

# Generated at 2022-06-24 05:01:16.616724
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.init()
    settings.hello = 'world'
    assert settings['hello'] == 'world'



# Generated at 2022-06-24 05:01:18.376266
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.wait_command == 5
    assert settings.time_format == '%m/%d/%Y'

# Generated at 2022-06-24 05:01:23.980359
# Unit test for method init of class Settings
def test_Settings_init():
    settings.update(const.DEFAULT_SETTINGS)
    args = mock.Mock(yes=True, debug=True, repeat=1)
    settings.init(args)

    assert not settings.require_confirmation
    assert settings.debug
    assert settings.repeat == 1
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.wait_command == 3
    assert settings.wait_slow_command == 15
    assert settings.num_close_matches == 3
    assert settings.alter_history == True

# Generated at 2022-06-24 05:01:26.230834
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules
    assert not settings.not_exists


# Generated at 2022-06-24 05:01:28.966367
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class Const(object):
        A = 1
        B = 2
    const = Const()
    settings = Settings()
    settings.A = const.A
    assert settings.get('A') == const.A
    settings.A = const.B
    assert settings.get('A') == const.B
    settings.B = const.A
    assert settings.get('B') == const.A

# Generated at 2022-06-24 05:01:31.685609
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['require_confirmation'] == True

# Generated at 2022-06-24 05:01:43.243081
# Unit test for method init of class Settings
def test_Settings_init():
    """
    Test for method init at class Settings
    """
    from unittest import TestCase
    import sys
    import os
    import shutil
    from mock import Mock
    from six import StringIO
    # mock object
    file_mock = Mock()
    file_mock.readline = Mock(return_value="")
    sys.stdin = StringIO()
    sys_argv = ["thefuck", "git", "commit", "--amend", "--no-edit"]
    # get the mock attr
    Settings.user_dir = Mock()
    Settings._settings_from_file = Mock(side_effect=ValueError)
    Settings._settings_from_file.return_value = {"priority": {"git":1, "cp":2},
                                                 "require_confirmation": True}
    Settings._settings

# Generated at 2022-06-24 05:01:51.957993
# Unit test for method init of class Settings
def test_Settings_init():
    """
    Makes sure that the settings file is created and settings
    initialized properly.
    """
    from settings import Settings
    import tempfile
    import shutil
    import sys

    class TemporarySettings(Settings):
        """
        A stub for the settings class. Provides a temporary directory
        and in-memory file for the settings file.
        """

        def __init__(self):
            super(TemporarySettings, self).__init__()
            self._settings_file = None
            self.user_dir = None
            temp_dir = tempfile.mkdtemp(prefix='thefuck')
            self.user_dir = Path(temp_dir)

        def _get_user_dir_path(self):
            return self.user_dir

        def _init_settings_file(self):
            self._settings_file = self.user

# Generated at 2022-06-24 05:01:57.473141
# Unit test for constructor of class Settings
def test_Settings():
    from .logs import capture_logger
    from .exceptions import ConfigError

    with capture_logger('thefuck.shells') as logged_warnings:
        settings = Settings({'shells': ['bash', 'no-shell']})

    assert 'no-shell' not in settings['shells']
    assert len(logged_warnings) == 1
    assert 'no-shell' in logged_warnings[0]

    with capture_logger('thefuck.rules') as logged_warnings:
        settings = Settings({'rules': ['no-rule']})

    assert 'no-rule' not in settings['rules']
    assert len(logged_warnings) == 1
    assert 'no-rule' in logged_warnings[0]
    assert u'python2' in settings['python_path']


# Generated at 2022-06-24 05:02:03.057619
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['require_confirmation'] == True
    assert settings.require_confirmation == True
    settings.require_confirmation = False
    assert settings.require_confirmation == False
    assert settings['require_confirmation'] == False
    settings['require_confirmation'] = True
    assert settings['require_confirmation'] == True
    assert settings.require_confirmation == True

# Generated at 2022-06-24 05:02:04.803182
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.hello = 'world'
    assert settings.hello == 'world'


# Generated at 2022-06-24 05:02:12.510037
# Unit test for method init of class Settings
def test_Settings_init():
    """Unit test for method init of class Settings"""
    from mock import patch, sentinel

    args = sentinel.args
    os_environ = {'test1': 'test', 'test2': 'test'}
    args_return = {'test3': 'test'}

    with patch('%s._settings_from_args' % __name__, return_value=args_return) as mock_from_args, \
            patch.dict(os.environ, os_environ), \
            patch('%s._settings_from_env' % __name__) as mock_from_env, \
            patch('%s.const.ENV_TO_ATTR' % __name__):
        settings.init(args)

        mock_from_env.assert_called_once_with()

# Generated at 2022-06-24 05:02:14.963741
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    for key,value in const.DEFAULT_SETTINGS.items():
        assert settings[key] == value

# Generated at 2022-06-24 05:02:17.568711
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = True
    assert settings['test'] is True
    settings.test = False
    assert settings['test'] is False



# Generated at 2022-06-24 05:02:21.056696
# Unit test for constructor of class Settings
def test_Settings():
    settings_old = Settings(const.DEFAULT_SETTINGS)
    assert settings_old.user_dir == settings.user_dir

    settings_new = Settings()
    assert settings_new.user_dir == settings.user_dir

# Generated at 2022-06-24 05:02:26.812619
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # Create a new instance of class Settings
    settings = Settings()

    # Call __setattr__ of class Settings
    settings.__setattr__('key', 'value')

    # Check the key 'key' exists in class Settings
    assert settings.get('key') == 'value'


# Generated at 2022-06-24 05:02:29.911454
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings(
        {'a': 1,
         'b': 2})
    assert s.a == 1
    assert s.b == 2
    assert s['b'] == 2
    s.a = 'apple'
    assert s['a'] == 'apple'


# Generated at 2022-06-24 05:02:33.241606
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.key = 'value'
    assert (settings.key == 'value')

# Generated at 2022-06-24 05:02:34.256709
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.__setattr__("key","value") == None


# Generated at 2022-06-24 05:02:39.041015
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings({'hello': 'world'})
    assert settings.hello == 'world'

    settings.hello = 'world2'
    assert settings.hello == 'world2'

    settings['hello'] = 'world3'
    assert settings.hello == 'world3'

    assert settings['hello'] == 'world3'

# Generated at 2022-06-24 05:02:48.799949
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.repeat == 1
    assert settings.require_confirmation == True
    assert settings.history_limit == None
    assert settings.instant_mode == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.alter_history == True
    assert settings.num_close_matches == 3
    assert settings.slow_commands == ['lein', 'react-native-cli']
    assert settings.exclude_rules == []
    assert settings.exclude_commands == []
    assert settings.priority == {}
    assert settings.excluded_search_path_prefixes == []



# Generated at 2022-06-24 05:02:58.342140
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(temp_dir)

# Generated at 2022-06-24 05:03:00.928707
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
	assert settings.require_confirmation == True


# Generated at 2022-06-24 05:03:02.737232
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.name = 'Fuck'
    assert settings.name == 'Fuck'


# Generated at 2022-06-24 05:03:06.516768
# Unit test for method init of class Settings
def test_Settings_init():
    """Test the function init of class Settings."""
    sys_args = ['thefuck', '--yes', '--repeat', '2']
    settings.init(args=type('', (),
                            {'yes': True, 'debug': False, 'repeat': 2})())
    assert settings.require_confirmation is False
    assert settings.repeat == 2

# Generated at 2022-06-24 05:03:08.045112
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.repeat = 10
    assert settings['repeat'] == 10
    assert settings.repeat == 10


# Generated at 2022-06-24 05:03:11.014731
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.command_not_found == None
    assert settings.excluded_search_path_prefixes == None
    assert settings.require_confirmation == None


# Generated at 2022-06-24 05:03:12.889918
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert not settings.not_existing_key
    assert settings.no_colors


# Generated at 2022-06-24 05:03:18.981330
# Unit test for constructor of class Settings
def test_Settings():
    new_settings = Settings()
    assert new_settings == {}
    new_settings = Settings({'key': 'value'})
    assert new_settings == {'key': 'value'}
    assert new_settings.key == 'value'
    new_settings.key = 'new_value'
    assert new_settings.key == 'new_value'
    assert new_settings == {'key': 'new_value'}

# Generated at 2022-06-24 05:03:19.921064
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = 1



# Generated at 2022-06-24 05:03:22.564366
# Unit test for method init of class Settings
def test_Settings_init():
    import mock
    with mock.patch('thefuck.settings.Settings.update') as update:
        Settings().init()
        assert update.call_count == 3


# Generated at 2022-06-24 05:03:24.897475
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings['key'] = 'value'
    assert settings.key == 'value'


# Generated at 2022-06-24 05:03:31.344578
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    # Check that settings with all DEFAULT_SETTINGS exist in settings
    settings_lst = [settings.__getattr__(name) for name in const.DEFAULT_SETTINGS.keys()]
    assert len(settings_lst) == len(const.DEFAULT_SETTINGS)

    settings.test_key = 'val'
    assert settings.test_key == 'val'
    assert settings['test_key'] == 'val'
    del settings.test_key
    settings.test_key = None
    assert settings.test_key is None
    assert settings['test_key'] is None



# Generated at 2022-06-24 05:03:40.425616
# Unit test for constructor of class Settings
def test_Settings():
    import os

    os.environ['TF_CONFIRMATION'] = 'False'
    assert 'require_confirmation' in settings
    assert not settings['require_confirmation']

    os.environ['TF_COLOR'] = 'FALSE'
    assert 'no_colors' in settings
    assert not settings['no_colors']

    os.environ['TF_SHELL_INTEGRATION'] = 'FOO:BAR'
    assert settings['shell_integration'] == 'FOO:BAR'

    os.environ['TF_REPEAT'] = 'true'
    assert settings['repeat']

    os.environ['TF_RULES'] = 'DEFAULT_RULES:foo'
    assert settings['rules'] == const.DEFAULT_RULES + ['foo']


# Generated at 2022-06-24 05:03:51.079896
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    os.environ["THEFUCK_RULES"] = "bash_history:sudo:your_rule"
    os.environ["THEFUCK_EXCLUDE_RULES"] = "test"
    os.environ["THEFUCK_NO_COLORS"] = "True"
    os.environ["THEFUCK_PRIORITY"] = "bash_history=1:sudo=2:alter_history=0"
    os.environ["THEFUCK_WAIT_COMMAND"] = "1"
    os.environ["THEFUCK_REQUIRE_CONFIRMATION"] = "False"
    os.environ["THEFUCK_WAIT_SLOW_COMMAND"] = "1"
    os.environ["THEFUCK_SLOW_COMMANDS"] = "test"

# Generated at 2022-06-24 05:03:58.824153
# Unit test for constructor of class Settings
def test_Settings():
    import unittest

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.settings = Settings({"new": "setting"})

        def test_settings_attr(self):
            self.assertEqual(self.settings.new, "setting")

        def test_settings_getattr(self):
            self.assertIsNone(self.settings.not_exists)

    unittest.main(module=__name__, buffer=True, exit=False)


if __name__ == "__main__":
    test_Settings()

# Generated at 2022-06-24 05:04:07.676915
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    args = type('', (), {'yes': True, 'repeat': 13})()
    settings.init(args)
    for key, value in const.DEFAULT_SETTINGS.items():
        if key == 'require_confirmation':
            assert settings[key] == False
        elif key == 'repeat':
            assert settings[key] == 13
        else:
            assert settings[key] == value

    os.environ['THEFUCK_RULES'] = 'DEFAULT_RULES'
    os.environ['THEFUCK_PRIORITY'] = 'example=3:ls=7'
    os.environ['THEFUCK_WAIT_COMMAND'] = '1'
    os.environ['THEFUCK_HISTORY_LIMIT'] = '2'
   

# Generated at 2022-06-24 05:04:08.497458
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('require_confirmation') == True


# Generated at 2022-06-24 05:04:09.607603
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    s.fuck = 'it'
    assert s['fuck'] == 'it'

# Generated at 2022-06-24 05:04:13.439900
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation is True


# Generated at 2022-06-24 05:04:17.059181
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.password = '123'
    assert settings.password == '123'
    assert settings['password'] == '123'
    assert settings.get('password') == '123'


# Generated at 2022-06-24 05:04:18.116858
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
   settings.newsettings = "newsettings"
   assert settings["newsettings"] == "newsettings"

# Generated at 2022-06-24 05:04:22.365270
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings({"a": 1})
    assert settings.a == 1
    assert settings["a"] == 1


# Generated at 2022-06-24 05:04:25.034892
# Unit test for method init of class Settings
def test_Settings_init():
    """Settings.init test case."""
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init(args=None)
    assert settings.user_dir.joinpath('settings.py').is_file()

# Generated at 2022-06-24 05:04:26.691290
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules
    settings['rules'] = None
    assert settings.rules is None


# Generated at 2022-06-24 05:04:34.355710
# Unit test for constructor of class Settings
def test_Settings():
    from . import history, logs
    from .logs import DEBUG, ERROR, INFO

    setting_source = const.DEFAULT_SETTINGS
    for key, value in setting_source.items():
        assert settings[key] == value, \
            u"Default setting {} doesn't match expected value `{}`. Got `{}`.".format(
                    key, value, settings[key])

    assert settings['history_limit'] == 0, \
        u"History has to be disabled by default"
    assert not settings['debug'], "Debug is not disabled by default"
    assert settings['wait_command'] == 3, \
        u"Wait command has to be equal 3 seconds by default"

    setting_source = {'history_limit': 2, 'debug': True}
    settings.update(setting_source)

# Generated at 2022-06-24 05:04:42.276874
# Unit test for constructor of class Settings
def test_Settings():
    from .logs import exception

    try:
        assert settings._get_user_dir_path() == Path('~/.config/thefuck').expanduser()
        assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    except Exception:
        exception("Can't create user dir", sys.exc_info())
    try:
        assert settings.get('require_confirmation') == True
        assert settings.get('repeat') == False
    except Exception:
        exception("Can't get default settings", sys.exc_info())


if __name__ == '__main__':
    test_Settings()

# Generated at 2022-06-24 05:04:49.573438
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init(args=None)
    assert settings == const.DEFAULT_SETTINGS
    assert settings.user_dir.is_dir()
    assert not settings.user_dir.joinpath('settings.py').is_file()

    os.environ['XDG_CONFIG_HOME'] = '~/test/'
    settings.init(args=None)
    assert settings.user_dir.is_dir()
    assert settings.user_dir.joinpath('settings.py').is_file()

    os.environ['TF_REQUIRE_CONFIRMATION'] = 'false'
    settings.init(args=None)
    assert settings.require_confi

# Generated at 2022-06-24 05:04:56.958831
# Unit test for constructor of class Settings
def test_Settings():
    assert dict(settings) == const.DEFAULT_SETTINGS
    assert settings.require_confirmation == True
    assert settings.wait_command == 4
    assert settings.history_limit == None
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert dict(settings.priority) == const.DEFAULT_RULE_PRIORITY
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.num_close_matches == 3
    assert settings.alter_history == True
    assert settings.instant_mode == False

# Generated at 2022-06-24 05:05:06.566595
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.user_dir.name == '.thefuck'
    assert settings.get('user_dir').name == '.thefuck'
    assert settings.get('user_dir').name == '.thefuck'
    settings.user_dir = 'test_user_dir'
    assert settings.user_dir == 'test_user_dir'
    assert settings.repeat == 3
    assert settings.alt_enter == True
    assert settings.history_limit == 5
    assert settings.priority == {'man': 1, 'brew': 2}
    assert settings.debug == False
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.rules == ['brew', 'ls_a']
    assert settings.exclude_rules == ['test']
    assert settings.alter_history == False
    assert settings.inst

# Generated at 2022-06-24 05:05:16.055731
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    from .system import Path

    test_settings_path = Path('.thefuck/settings.py')
    assert not test_settings_path.exists()
    settings.init()
    assert test_settings_path.read_text() == const.SETTINGS_HEADER
    test_settings_path.unlink()

    test_settings_path.write_text('RULES = ["test_rule"]\n')
    os.environ['THEFUCK_RULES'] = 'DEFAULT_RULES'
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'True'
    os.environ['THEFUCK_DEBUG'] = 'True'
    os.environ['THEFUCK_PRIORITY'] = 'git_push=10:git_add=20'
   

# Generated at 2022-06-24 05:05:20.682878
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    from .logs import test_settings as logs_settings
    from .how_to import test_settings as how_to_settings

    settings.init()
    assert settings.default_search_function(1, 2, a=3) == logs_settings.default_search_function(1, 2, a=3)
    assert settings.default_search_function(a=3) == how_to_settings.default_search_function(a=3)

# Generated at 2022-06-24 05:05:29.933354
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.require_confirmation
    assert settings.no_colors == False
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'gradle']
    assert settings.excluded_search_path_prefixes == []
    assert settings.debug == False
    assert settings.alter_history == False
    assert settings.instant_mode == False
    assert settings.num_close_matches == 3
    assert settings.repeat == 1
    assert settings.history_limit == None

# Generated at 2022-06-24 05:05:34.257019
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings(a=3, b=4)
    assert settings.a == 3 and settings.b == 4


# Generated at 2022-06-24 05:05:38.295846
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings(const.DEFAULT_SETTINGS)

    assert settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']
    assert settings.cmd_format == const.DEFAULT_SETTINGS['cmd_format']

    settings.new_key = True
    assert settings.new_key == True



# Generated at 2022-06-24 05:05:39.853802
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert not settings.history_limit


# Generated at 2022-06-24 05:05:47.271477
# Unit test for method init of class Settings
def test_Settings_init():
    import os

    from thefuck.shells import shells
    from thefuck.logs import log
    from thefuck.conf import _settings_from_args as settings_from_args

    __import__('thefuck.logs').log = lambda x: x
    __import__('thefuck.conf').settings = settings
    __import__('thefuck.shells').shells.get_shell = lambda: 'bash'
    settings._setup_user_dir = lambda: None
    settings._settings_from_file = lambda: {'rules': ['fuck1', 'fuck2']}
    settings._settings_from_env = lambda: {'exclude_rules': ['fuck3']}

    settings.init(settings_from_args(None))
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules

# Generated at 2022-06-24 05:05:50.485885
# Unit test for method init of class Settings
def test_Settings_init():
    import types

    settings.init(types.SimpleNamespace(
        yes=True, debug=True, repeat=3
        ))
    assert not settings.require_confirmation
    assert settings.debug
    assert settings.repeat == 3

# Generated at 2022-06-24 05:05:54.601547
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    test_settings.__setattr__("test_key", "test_value")
    if test_settings['test_key'] is not "test_value" :
        return 1
    else:
        return 0

# Generated at 2022-06-24 05:05:55.558155
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.alias == 'fuck'



# Generated at 2022-06-24 05:05:59.973025
# Unit test for method init of class Settings
def test_Settings_init():
    settings.update(const.DEFAULT_SETTINGS)
    settings.init(args=None)
    assert settings == const.DEFAULT_SETTINGS
    settings.init(args=dict())
    assert settings == const.DEFAULT_SETTINGS


# Generated at 2022-06-24 05:06:07.048687
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()


if __name__ == '__main__':
    # Unit test for method _settings_from_args of class Settings
    settings.init(args='args')

    # Unit test for method _settings_from_env of class Settings
    os.environ['THEFUCK_WAIT_COMMAND'] = '1000'
    settings.init()

    # Unit test for method _val_from_env of class Settings
    def test_rules_from_env():
        assert settings._rules_from_env('') == []
        assert settings._rules_from_env('DEFAULT_RULES') == const.DEFAULT_RULES
        assert settings._rules_from_env(':DEFAULT_RULES') == const.DEFAULT_RULES

# Generated at 2022-06-24 05:06:10.902418
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class TestClass(Settings):
        def __init__(self):
            self.__dict__ = {}
    test = TestClass()
    test.foo = 1
    assert test['foo'] == 1

test_Settings___setattr__()

# Generated at 2022-06-24 05:06:13.084775
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings_ = Settings({'a': 'foo'})
    assert settings_['a'] == settings_.a


# Generated at 2022-06-24 05:06:15.233581
# Unit test for constructor of class Settings
def test_Settings():
    class Foo(Settings):
        def __init__(self):
            pass
    foo = Foo()
    assert foo == {}


# Generated at 2022-06-24 05:06:18.705994
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    print(settings)


if __name__ == '__main__':
    test_Settings_init()

# Generated at 2022-06-24 05:06:21.436967
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    s = Settings({"a": "b"})
    assert s.get("a") == "b"
    assert s.__getattr__("a") == "b"


# Generated at 2022-06-24 05:06:23.915958
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.test_attr = 'test_attr'
    assert settings['test_attr'] == 'test_attr'

# Generated at 2022-06-24 05:06:31.510288
# Unit test for constructor of class Settings
def test_Settings():
    from nose.tools import assert_equals
    assert_equals(settings.user_dir.joinpath('settings.py').expanduser().is_file(), True)
    assert_equals(settings.user_dir.joinpath('rules').expanduser().is_dir(), True)
    #assert_equals(settings._get_user_dir_path(), '~/.config/thefuck')
    assert_equals(settings._settings_from_env(), {})
    assert_equals(settings._settings_from_args(), {})
    assert_equals(settings._rules_from_env('DEFAULT_RULES:man'), const.DEFAULT_RULES + ['man'])

# Generated at 2022-06-24 05:06:32.830380
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.new_value = 'value'
    assert settings['new_value'] == 'value'

# Generated at 2022-06-24 05:06:34.422354
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, dict)
    assert isinstance(settings.get("require_confirmation"), bool)


# Generated at 2022-06-24 05:06:35.615856
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == True



# Generated at 2022-06-24 05:06:37.121299
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings_test = Settings()
    settings_test.test = 1
    assert settings_test['test'] == 1

# Generated at 2022-06-24 05:06:39.358913
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    example1 = settings.require_confirmation
    example2 = settings.no_default_rules
    assert example1 == True
    assert example2 == False


# Generated at 2022-06-24 05:06:43.449099
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.__setattr__('key1', 'value1')
    assert settings['key1'] == 'value1'
    settings.key2 = 'value2'
    assert settings['key2'] == 'value2'


# Generated at 2022-06-24 05:06:45.348306
# Unit test for constructor of class Settings
def test_Settings():
    result = Settings(const.DEFAULT_SETTINGS)
    assert result == const.DEFAULT_SETTINGS

# Generated at 2022-06-24 05:06:52.688535
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    for key, value in const.DEFAULT_SETTINGS.items():
        assert settings[key] == value
        assert settings.get(key) == value
        assert getattr(settings, key) == value
    # Set an attribute in Settings
    settings.new_key = 'new_value'
    assert settings.get('new_key') == 'new_value'
    assert getattr(settings, 'new_key') == 'new_value'
    assert settings['new_key'] == 'new_value'


# Generated at 2022-06-24 05:06:57.259165
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert settings.wait_slow_command == 3
    assert settings.get('require_confirmation')
    assert settings.get('wait_slow_command') == 3
    assert settings.get('nonexistent_setting', 'default_value') == 'default_value'


# Generated at 2022-06-24 05:07:08.050976
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.wait_command == 1
    assert settings.priority == {'fuck': 1, '*': 2}
    assert settings.rules == ['git_push', 'git_add', 'git_commit', 'hg_push', 'svn_revert']
    assert settings.exclude_rules == ['lisp_calls']
    assert settings.require_confirmation is True
    assert settings.no_colors is False
    assert settings.wait_slow_command == 15
    assert settings.history_limit == 0
    assert settings.debug is False
    assert settings.alter_history is True
    assert settings.instant_mode is False
    assert settings.slow_commands == ['lein', 'rebar', 'gradle']
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_mat

# Generated at 2022-06-24 05:07:09.034381
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.wait_command == 3


# Generated at 2022-06-24 05:07:11.375180
# Unit test for constructor of class Settings
def test_Settings():
    _settings = Settings(const.DEFAULT_SETTINGS)
    for key, value in const.DEFAULT_SETTINGS.items():
        assert(_settings[key] == value)

# Generated at 2022-06-24 05:07:17.513389
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.rules == const.DEFAULT_RULES
    assert settings.alter_history == True
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.priority == {}
    assert settings.wait_command == const.DEFAULT_WAIT_COMMAND
    assert settings.slow_commands == []
    assert settings.history_limit == const.DEFAULT_HISTORY_LIMIT
    assert settings.env == {}
    assert settings.exclude_rules == []
    assert settings.wait_slow_command == 0
    assert settings.num_close_matches == const.DEFAULT_CLOSE_MATCHES
    assert settings.excluded_search_path_prefixes == const.DEFAULT_EXCLUDE_PATHS

# Generated at 2022-06-24 05:07:23.021675
# Unit test for method init of class Settings
def test_Settings_init():
    """Tests Init method in Settings"""
    from .logs import capture_logs, disable_logger


# Generated at 2022-06-24 05:07:34.277731
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert isinstance(settings, dict)
    assert isinstance(settings, Settings)

# Generated at 2022-06-24 05:07:38.911812
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    settings.init()
    assert settings.user_dir == Path('~', '.config', 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False

# Generated at 2022-06-24 05:07:46.557485
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init(args=None)
    assert settings['require_confirmation'] == const.DEFAULT_SETTINGS['require_confirmation']
    assert settings['DEBUG'] == const.DEFAULT_SETTINGS['DEBUG']
    assert settings['repeat'] == const.DEFAULT_SETTINGS['repeat']
    assert settings['wait_command'] == const.DEFAULT_SETTINGS['wait_command']
    assert settings['wait_slow_command'] == const.DEFAULT_SETTINGS['wait_slow_command']
    assert settings['history_limit'] == const.DEFAULT_SETTINGS['history_limit']


if __name__ == '__main__':
    test_Settings_init()

# Generated at 2022-06-24 05:07:49.353640
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    assert settings.get("test") == None
    settings.test = 1
    assert settings.get("test") == 1


# Generated at 2022-06-24 05:07:50.670781
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.init()
    assert settings.require_confirmation
    assert settings.command_not_found == u'fuck'
    assert settings.history_limit == 100


# Generated at 2022-06-24 05:07:52.121969
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert 'require_confirmation' in settings

# Generated at 2022-06-24 05:07:53.773145
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.test = 'test'
    assert settings.test == 'test'


# Generated at 2022-06-24 05:07:55.208597
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()

# Generated at 2022-06-24 05:07:57.209617
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    s = Settings({"a":1})
    assert s.a == 1

# Generated at 2022-06-24 05:08:03.498942
# Unit test for method init of class Settings
def test_Settings_init():
    class SettingsTester(Settings):
        def __init__(self, args=None):
            self.user_dir = None
            self.received_args = args
            self._settings_from_file = MagicMock(return_value={'LOG_FILE': 'file'})
            self._settings_from_env = MagicMock(return_value={'LOG_FILE': 'env'})
            self._settings_from_args = MagicMock(return_value={'REQUIRE_CONFIRMATION': False, 'LOG_FILE': 'args'})
            self._setup_user_dir = MagicMock(return_value='config')
            self.init(args)

# Generated at 2022-06-24 05:08:06.729973
# Unit test for constructor of class Settings
def test_Settings():
    settings.init()
    for (key, value) in const.DEFAULT_SETTINGS.items():
        assert settings[key] == value

# Generated at 2022-06-24 05:08:11.725109
# Unit test for method init of class Settings
def test_Settings_init():
    """Test properties if settings have been loaded as expected
    """
    settings.init()
    assert os.path.isdir(os.path.join(os.path.expanduser('~'),'.thefuck'))
    assert settings.get('require_confirmation')
    assert settings.get('rules')
    assert settings.get('priority')
    assert settings.get('wait_command')
    assert settings.get('wait_slow_command')

# Generated at 2022-06-24 05:08:18.137360
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import logs

    settings.init()
    assert settings.user_dir == user_dir

    settings.init(args=None)
    assert logs == []

    settings.init(args=FakeArgs())
    assert logs == []

    settings.init(args=FakeArgs(debug=True, repeat=10, yes=True))
    assert settings.debug is True
    assert settings.repeat == 10
    assert settings.require_confirmation is False
    assert logs == []

user_dir = '~/.thefuck'


# Generated at 2022-06-24 05:08:19.516021
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.__class__.__name__ == 'Settings'
    assert settings.__str__() == "{}"

# Generated at 2022-06-24 05:08:22.056071
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['history_limit'] == 100
    assert settings['exclude_rules'] == []

# Generated at 2022-06-24 05:08:24.947822
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.test_attr = 42
    assert settings.test_attr == 42

# Generated at 2022-06-24 05:08:26.059741
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(Settings(), Settings)



# Generated at 2022-06-24 05:08:27.619061
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings()
    test_settings.test_key = "test"
    assert test_settings['test_key'] == "test"

# Generated at 2022-06-24 05:08:29.005786
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.__setattr__('test_attr', 'test_value')
    assert settings['test_attr'] == 'test_value'


# Generated at 2022-06-24 05:08:31.616090
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test_attribute = 'test'
    assert settings['test_attribute'] == 'test'

# Generated at 2022-06-24 05:08:36.125715
# Unit test for method init of class Settings
def test_Settings_init():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    args = Namespace(yes=True, debug=False, repeat=None)
    settings.user_dir = settings._get_user_dir_path()
    settings.init(args)
    settings.user_dir = settings._get_user_dir_path()
    settings.init()



# Generated at 2022-06-24 05:08:37.768374
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    global settings
    settings = Settings()
    settings.test = 1
    assert settings['test'] == 1



# Generated at 2022-06-24 05:08:38.992073
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['require_confirmation']
    assert settings['history_limit'] == None

# Generated at 2022-06-24 05:08:39.708970
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.no_colors is False


# Generated at 2022-06-24 05:08:41.015588
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = 'test'
    assert settings['test'] == 'test'


# Generated at 2022-06-24 05:08:43.966342
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert a == const.DEFAULT_SETTINGS
    assert a.alter_history == False
    a.alter_history = True
    assert a.alter_history == True


# Generated at 2022-06-24 05:08:46.667066
# Unit test for constructor of class Settings
def test_Settings():
    a = Settings()
    assert(const.DEFAULT_SETTINGS == a)

# Generated at 2022-06-24 05:08:48.211257
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings({'ok': True})
    assert settings.ok == True

# Generated at 2022-06-24 05:08:51.877222
# Unit test for constructor of class Settings
def test_Settings():
    global settings
    settings = Settings(const.DEFAULT_SETTINGS)

# Generated at 2022-06-24 05:08:53.365227
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']



# Generated at 2022-06-24 05:08:56.942493
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.a = 1
    assert settings['a'] == 1


# Generated at 2022-06-24 05:08:59.927118
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    _settings = Settings(const.DEFAULT_SETTINGS)
    _settings.require_confirmation = False

    assert not _settings.require_confirmation


# Generated at 2022-06-24 05:09:01.666393
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    assert settings == {}

    settings.a = 1
    assert settings['a'] == 1

# Generated at 2022-06-24 05:09:06.188451
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.__setattr__('key', 'value')
    assert settings.key == 'value'

# Generated at 2022-06-24 05:09:13.553327
# Unit test for constructor of class Settings
def test_Settings():
    settings['key1'] = 'value1'
    settings['key2'] = 'value2'
    assert settings.get('key1') == 'value1'
    assert settings.key2 == 'value2'
    assert settings['key2'] == 'value2'
    settings.key3 = 'value3'
    assert settings.get('key3') == 'value3'
    settings['key4'] = 'value4'
    try:
        settings.get('key5')
        raise Exception()
    except KeyError:
        pass
    try:
        settings.key6
        raise Exception()
    except KeyError:
        pass
    try:
        settings['key7']
        raise Exception()
    except KeyError:
        pass
    settings.update({'key8':'value8'})

# Generated at 2022-06-24 05:09:15.243159
# Unit test for constructor of class Settings
def test_Settings():
    result = Settings()
    assert result.user_dir.joinpath('settings.py').is_file()


# Generated at 2022-06-24 05:09:18.625732
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.default_rule == 'fuck'
    assert settings.rules == ['fuck']
    assert settings.exclude_rules == ['cd', 'git_push']
    assert settings.num_close_matches == 3
    assert settings.hist_file == '~/.thefuck_history'

# Generated at 2022-06-24 05:09:20.898159
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.wait_slow_command == 3
    assert settings.require_confirmation == True


# Generated at 2022-06-24 05:09:25.324149
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    # check if object created and __getattr__ work
    assert settings.vim, 'object settings created'
    print('TEST SUCCESSFUL: object created and __getattr__ work')


# Generated at 2022-06-24 05:09:29.795861
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.alter_history == True
    assert settings.not_exists_attr == None

if __name__ == '__main__':
    test_Settings___getattr__()

# Generated at 2022-06-24 05:09:31.558705
# Unit test for method init of class Settings
def test_Settings_init():
    #TODO: add tests for this method
    pass


# Generated at 2022-06-24 05:09:34.813884
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings({'first': 'python'})
    settings.update({'second': 2})

    assert settings.first == settings['first']
    assert settings.second == settings['second']



# Generated at 2022-06-24 05:09:41.824892
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()

    assert settings.user_dir.endswith('/.config/thefuck')

    assert settings.user_dir.joinpath('rules').is_dir()
    assert settings.user_dir.joinpath('settings.py').is_file()

    import imp
    import functools
    dummy_loader = functools.partial(imp.load_source, 'settings', text_type(settings.user_dir.joinpath('settings.py')))
    dummy_loader()

    # assert settings.debug == const.ENV_TO_ATTR['debug']

# Generated at 2022-06-24 05:09:43.769005
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.hello = "world"
    assert settings["hello"] == "world"

# Generated at 2022-06-24 05:09:53.523241
# Unit test for constructor of class Settings

# Generated at 2022-06-24 05:09:55.555932
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert const.DEFAULT_SETTINGS['require_confirmation'] == settings.require_confirmation

# Generated at 2022-06-24 05:10:01.090203
# Unit test for constructor of class Settings
def test_Settings():
    origin = const.DEFAULT_SETTINGS.copy()
    origin['rules'] = origin['rules'] + ['fuck']
    origin['priority'] = {'fuck': 2, 'ls': 1}
    settings = Settings(origin)

    assert settings.priority == {'fuck': 2, 'ls': 1}
    assert settings.rules == origin['rules']
    assert settings.rules == ['fuck'] + const.DEFAULT_SETTINGS['rules']