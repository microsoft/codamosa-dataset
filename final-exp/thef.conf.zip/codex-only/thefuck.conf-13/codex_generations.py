

# Generated at 2022-06-24 05:00:02.101503
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

    assert settings['require_confirmation'] == True
    assert settings.require_confirmation == True

    assert settings['repeat'] == False
    assert settings.repeat == False

#### Last test


# Generated at 2022-06-24 05:00:12.212746
# Unit test for constructor of class Settings
def test_Settings():
    from nose.tools import assert_equal, assert_dict_contains_subset
    from thefuck.conf.settings import Settings

    settings = Settings()
    assert_equal('/etc/thefuck', settings['conf_file'])
    assert_equal(2, settings['slow_commands_limit'])
    assert_equal(3, settings['priority_limit'])
    assert_equal(5, settings['history_limit'])
    assert_equal(2, settings['wait_slow_command'])
    assert_dict_contains_subset(
        {'fuck': 7, 'lucky': 1, 'fuckit': 3, 'first': 1}, settings['priority'])

# Generated at 2022-06-24 05:00:16.573927
# Unit test for method init of class Settings
def test_Settings_init():
    d = dict(const.DEFAULT_SETTINGS)
    d.update({
        'require_confirmation': False,
        'repeat': 10,
        'debug': True,
        'no_colors': True
    })
    settings.init({'require_confirmation': False, 'repeat': 10, 'debug': True, 'no_colors': True})
    assert settings == d

# Generated at 2022-06-24 05:00:25.334334
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    from .utils import get_all_executables
    from .logs import debug

    debug('Test Settings.__getattr__')
    s = Settings({'a': 1, 'slow_commands': []})
    assert s.a == 1
    assert s['a'] == 1
    s.slow_commands = get_all_executables()
    assert s.slow_commands == get_all_executables()
    assert s['slow_commands'] == get_all_executables()



# Generated at 2022-06-24 05:00:26.977737
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    assert test_settings['require_confirmation'] == True

# Generated at 2022-06-24 05:00:30.085851
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init(args = None)

    assert settings == const.DEFAULT_SETTINGS

    settings.init(args = 1)

    assert settings == const.DEFAULT_SETTINGS


# Generated at 2022-06-24 05:00:37.391015
# Unit test for method init of class Settings
def test_Settings_init():
    # When settings is filled by `init`
    # Then user_dir is equal to `Path('~/.config/thefuck')`
    settings.init()
    expected_user_dir = Path('~/.config/thefuck').expanduser()
    assert settings.user_dir == expected_user_dir

    # And `settings.py` is created
    # And it contains all the settings
    expected_settings_file = const.SETTINGS_HEADER
    for setting in const.DEFAULT_SETTINGS.items():
        expected_settings_file += u'# {} = {}\n'.format(*setting)

    settings_path = settings.user_dir.joinpath('settings.py')
    with settings_path.open(mode='r') as settings_file:
        assert settings_file.read() == expected_settings_file

   

# Generated at 2022-06-24 05:00:46.595444
# Unit test for constructor of class Settings
def test_Settings():
    from mock import patch, PropertyMock
    original_settings = settings

    mock_path = patch('thefuck.settings.Path', autospec=True)
    mock_path.start()
    settings._setup_user_dir()

    settings.init()
    with patch.object(settings, '_settings_from_file',
                      return_value={'rules': ['not_default']},
                      autospec=True):
        assert settings['rules'] == ['not_default']

    with patch.object(settings, '_settings_from_env',
                      return_value={'rules': ['not_default']},
                      autospec=True):
        assert settings['rules'] == ['not_default']


# Generated at 2022-06-24 05:00:55.852195
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from mock import patch
    from .system import subprocess
    from .utils import wrap_streams


# Generated at 2022-06-24 05:01:00.317214
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.__setattr__('name', 'value')
    assert settings.name == 'value'
    assert settings.__getattr__('name') == 'value'


# Generated at 2022-06-24 05:01:02.648891
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.priority == const.DEFAULT_SETTINGS['priority']



# Generated at 2022-06-24 05:01:04.476323
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    s = Settings()
    s.test = 'test'
    assert s.test == 'test'


# Generated at 2022-06-24 05:01:07.881577
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    global settings
    settings = Settings()

    try:
        settings.init()
    except Exception:
        exception("Can't load settings", sys.exc_info())

    return settings


# Generated at 2022-06-24 05:01:11.993532
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.new_attr = "new attr"
    assert settings.new_attr == "new attr"


# Generated at 2022-06-24 05:01:15.390649
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()

# Generated at 2022-06-24 05:01:19.554683
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.no_colors == settings['no_colors']


# Generated at 2022-06-24 05:01:21.385970
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    sys.argv = ['thefuck']
    settings.init()
    assert settings.require_confirmation is True

# Generated at 2022-06-24 05:01:32.198729
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import Logger
    from .utils import memoize

    class FakeArgs(object):
        def __init__(self, debug=False, repeat=None):
            self.debug = debug
            self.repeat = repeat

    class FakeEnv(object):
        def __init__(self, val):
            self.rules = 'DEFAULT_RULES:' + val

        def __contains__(self, attr):
            return True

    def fake_load_source(name, path):
        if hasattr(path, 'is_file'):
            assert path == Path('thefuck', 'settings.py').expanduser()
        else:
            assert path == 'thefuck/settings.py'

        assert name == 'settings'
        return FakeSettings()


# Generated at 2022-06-24 05:01:34.397089
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    assert settings.abc == None
    settings.abc = 'abc'
    assert settings.abc == 'abc'


# Generated at 2022-06-24 05:01:38.521675
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings_dict = {}
    settings_dict["test_key"] = "test_value"

    settings_obj = Settings(settings_dict)

    assert settings_obj.test_key == "test_value"

# Generated at 2022-06-24 05:01:40.746188
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.require_confirmation
    assert settings.history_limit == 0
    assert settings.wait_command == 0
    assert settings.wait_slow_command == 1

    settings = Settings({'history_limit': 10})
    assert settings.history_limit == 10

# Generated at 2022-06-24 05:01:47.241180
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import sys

    def do_init():
        settings.init()

    saved_sys_modules = sys.modules.copy()
    saved_os_environ = os.environ.copy()

    # Test with all env-variables set

# Generated at 2022-06-24 05:01:48.019544
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == True


# Generated at 2022-06-24 05:01:54.078352
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.exclude_rules == ['man', 'ls', 'bg']
    assert settings.exclude_commands == ['sudo']
    assert settings.require_confirmation
    assert settings.no_colors
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.history_limit == 1000
    assert settings.alter_history
    assert settings.num_close_matches == 3
    assert settings.instant_mode

# Generated at 2022-06-24 05:01:56.833125
# Unit test for constructor of class Settings
def test_Settings():
    # Test initalizer of Settings class.
    settings['require_confirmation'] = True
    assert settings.require_confirmation is True
    settings.require_confirmation = False
    assert settings['require_confirmation'] is False
    settings.init()
    assert settings.require_confirmation is True

    # Test initalizer of Settings class.
    settings.init(args=True)
    settings.init(args=False)
    assert settings.require_confirmation is False
    assert settings.repeat == 1
    assert settings.debug is False

# Generated at 2022-06-24 05:02:00.748918
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    dic = {}
    settings = Settings(dic)
    settings.foo = 'bar'
    assert dic['foo'] == 'bar'
    assert settings['foo'] == 'bar'
    assert settings.foo == 'bar'


# Generated at 2022-06-24 05:02:03.812314
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)

    settings.init()

    assert settings['require_confirmation'] is True
    assert settings['rules'] == const.DEFAULT_RULES

# Generated at 2022-06-24 05:02:05.154577
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.settings == const.DEFAULT_SETTINGS



# Generated at 2022-06-24 05:02:12.718630
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    settings = Settings()
    assert not settings.user_dir.is_dir()

    settings.init()

    assert settings.user_dir.is_dir()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.user_dir.joinpath('rules').is_dir()

    assert settings.require_confirmation
    assert not settings.no_colors
    assert not settings.debug

    with settings.user_dir.joinpath('settings.py').open('w') as settings_file:
        settings_file.write('require_confirmation = False')

    settings.init()
    assert not settings.require_confirmation


# Generated at 2022-06-24 05:02:14.535928
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.a = 'b'
    assert settings.a == settings['a']


# Generated at 2022-06-24 05:02:16.509412
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert not settings.no_colors


# Generated at 2022-06-24 05:02:18.717546
# Unit test for constructor of class Settings
def test_Settings():
    """Unit test for constructor of class Settings"""
    assert settings.get("slow_commands") == []

# Generated at 2022-06-24 05:02:20.099015
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert not settings.alter_history



# Generated at 2022-06-24 05:02:27.040430
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.require_confirmation == True
    assert settings.history_limit == 10
    assert settings.wait_command == 15
    assert settings.require_confirmation == True
    assert settings.python_path == sys.executable
    assert settings.alter_history == False
    assert settings.no_colors == False
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_slow_command == 15

# Generated at 2022-06-24 05:02:34.558137
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.get('require_confirmation') == True
    assert settings.get('repeat') == False
    assert settings.get('repeat_info') == None
    assert settings.get('wait_command') == 3
    assert settings.get('clear_on_exit') == True
    assert settings.get('no_colors') == False
    assert settings.get('debug') == False
    assert settings.get('priority') == {}
    assert settings.get('rules') == const.DEFAULT_RULES
    assert settings.get('exclude_rules') == []
    assert settings.get('wait_slow_command') == 15

# Generated at 2022-06-24 05:02:36.755169
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['require_confirmation'] == True

# Generated at 2022-06-24 05:02:44.157310
# Unit test for constructor of class Settings

# Generated at 2022-06-24 05:02:45.689584
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.command is None
    assert settings.no_colors == False


# Generated at 2022-06-24 05:02:55.510614
# Unit test for method init of class Settings
def test_Settings_init():
    from .system import Path
    from .logs import exception

    def _exception(err, exc_info):
        assert err == "Can't load settings from file"
        assert exc_info

    def _settings_from_file():
        raise RuntimeError

    def _settings_from_env():
        raise RuntimeError

    def _settings_from_args(args):
        raise RuntimeError


# Generated at 2022-06-24 05:02:57.085906
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    a = Settings()
    a.test = 123
    assert a == {'test': 123}



# Generated at 2022-06-24 05:03:07.744297
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .main import main
    from . import logs
    import sys
    import os

    def test_exceptions_in_log(expected_log):
        assert logs.log == expected_log

    def updat_test_settings_from_env():
        settings.update({attr: '1' for attr in const.DEFAULT_SETTINGS.keys()})
        settings.update({attr: '1' for attr in const.EXTRA_SETTINGS.keys()})


# Generated at 2022-06-24 05:03:12.587450
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    assert settings == {}
    settings.a = 1
    assert settings == {'a': 1}
    settings.b = 2
    assert settings == {'a': 1, 'b': 2}
    del settings.a
    assert settings == {'b': 2}


# Generated at 2022-06-24 05:03:23.212479
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings.init()
    assert settings.user_dir == Path.home().joinpath(".config/thefuck")
    assert settings.user_dir.joinpath("rules").is_dir()
    assert not settings.get("fuck")
    assert settings.get("rules") == const.DEFAULT_RULES
    assert settings.get("require_confirmation")
    assert not settings.get("debug")
    assert settings.get("repeat") == False
    assert settings.get("priority") == {}
    assert settings.get("history_limit") == None
    assert settings.get("no_colors") == False
    assert settings.get("wait_command") == 15
    assert settings.get("alter_history") == True
    assert settings.get("wait_slow_command") == 3

# Generated at 2022-06-24 05:03:26.275639
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    attr = 'attr'
    assert settings.__getattr__(attr) == settings[attr] == settings.__dict__.get(attr)


# Generated at 2022-06-24 05:03:29.050173
# Unit test for method init of class Settings
def test_Settings_init():
    args = type('', (object,), {'yes': True, 'repeat': 0})
    settings.init(args)
    assert not settings.require_confirmation
    assert settings.repeat == 0

# Generated at 2022-06-24 05:03:39.676733
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    from .logs import log_to_stderr
    from .utils import cached_property
    settings._get_user_dir_path = cached_property(lambda x: 'test')
    settings._rules_from_env = lambda x: x
    settings._priority_from_env = lambda x: x
    settings._val_from_env = lambda *a: a[1]
    settings.init()
    settings.log = log_to_stderr
    settings.require_confirmation = True
    assert settings.require_confirmation
    assert settings.history_limit == 100
    assert settings['history_limit'] == 100
    settings.history_limit = 200
    assert settings.history_limit == 200
    assert settings['history_limit'] == 200
    settings['history_limit'] = 300
    assert settings.history_limit == 300

# Generated at 2022-06-24 05:03:43.997224
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    assert (test_settings.get('wait_command') == 0.3)


# Generated at 2022-06-24 05:03:45.658215
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings(ADMIN_NAME='admin', ADMIN_PASSWORD='admin')
    assert settings.ADMIN_NAME == 'admin'
    assert settings.ADMIN_PASSWORD == 'admin'


# Generated at 2022-06-24 05:03:46.891842
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('require_confirmation') == True



# Generated at 2022-06-24 05:03:50.210454
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings['priority'] == const.DEFAULT_PRIORITY
    assert settings['help_message'] == const.DEFAULT_HELP_MESSAGE


# Generated at 2022-06-24 05:03:51.958294
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == True
    assert settings.rules == ['ls_a', 'fuck', 'git_push', 'sudo_fuck']

# Generated at 2022-06-24 05:03:55.930377
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.user_dir.isdir() and settings.user_dir.islink()
    assert not settings.require_confirmation
    assert settings.history_limit == 10
    assert not settings.alter_history
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'tsc', 'carthage']
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.no_colors
    assert not settings.instant_mode
    assert not settings.debug
    assert settings.wait_command == 1
    assert settings.excluded_search_path_prefixes == []

# Generated at 2022-06-24 05:03:59.432022
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    sett = Settings(const.DEFAULT_SETTINGS)
    sett.set = 1
    assert sett.get('set') == 1
    assert sett['set'] == 1



# Generated at 2022-06-24 05:04:03.277539
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']
    assert settings.get('require_confirmation') == const.DEFAULT_SETTINGS['require_confirmation']


# Generated at 2022-06-24 05:04:10.284275
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.init()

    assert settings.slow_commands
    assert settings.no_colors
    assert settings.require_confirmation
    assert settings.wait_command
    assert settings.wait_slow_command
    assert settings.require_confirmation
    assert settings.alter_history
    assert settings.instant_mode
    assert settings.debug
    assert settings.exclude_rules
    assert settings.history_limit
    assert settings.excluded_search_path_prefixes
    assert settings.rules
    assert settings.priority
    assert settings.repeat
    assert settings.num_close_matches
    assert settings.user_dir



# Generated at 2022-06-24 05:04:11.254460
# Unit test for constructor of class Settings
def test_Settings():
    print(settings)

if __name__ == '__main__':
    test_Settings()

# Generated at 2022-06-24 05:04:18.586055
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()

    # settings.py is not exist, create it
    from shutil import rmtree
    settings.user_dir.joinpath('settings.py').unlink()
    settings.init()
    with open(settings.user_dir.joinpath('settings.py'), 'r') as settings_file:
        assert  settings_file.read() == const.SETTINGS_HEADER
        for setting in const.DEFAULT_SETTINGS.items():
            assert settings_file.read().find('# {} = {}'.format(*setting)) != -1
    settings.user_dir.joinpath('settings.py').unlink()

    # test settings_from_file method

# Generated at 2022-06-24 05:04:19.227733
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == False


# Generated at 2022-06-24 05:04:21.006557
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    s = Settings()
    s['a'] = 1
    assert s.a == 1



# Generated at 2022-06-24 05:04:29.810207
# Unit test for method init of class Settings
def test_Settings_init():
    with settings.user_dir.joinpath('settings.py').open() as settings_file:
        settings_file.write('rules = ["test_rule_1", "test_rule_2"]')

    os.environ['THEFUCK_RULES'] = 'DEFAULT_RULES:test_rule_3'
    os.environ['THEFUCK_PRIORITY'] = 'test_rule_3=7'
    os.environ['THEFUCK_DEBUG'] = 'True'
    os.environ['THEFUCK_REPEAT'] = '2'
    os.environ['THEFUCK_YES'] = 'True'


# Generated at 2022-06-24 05:04:40.930301
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert 'colors' in settings and 'wait_command' in settings
    # TODO: Fix test to work with other configurations
    assert settings['colors'] == {
        'green': '\x1b[1;32m', 'red': '\x1b[1;31m', 'purple': '\x1b[1;35m',
        'blue': '\x1b[1;34m', 'yellow': '\x1b[1;33m', 'bold': '\x1b[1m',
        'reset': '\x1b[0m'}
    assert settings['wait_command'] == 15

# Generated at 2022-06-24 05:04:44.185599
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    """Test for method __setattr__ of class Settings"""
    settings = Settings()
    settings.test = True
    assert settings['test'] is True



# Generated at 2022-06-24 05:04:54.312218
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['exclude_rules'] == const.DEFAULT_EXCLUDE_RULES
    assert settings['slow_commands'] == const.DEFAULT_SLOW_COMMANDS
    assert settings['excluded_search_path_prefixes'] == const.DEFAULT_EXCLUDE_SEARCH_PATH_PREFIXES
    assert settings['wait_command'] == const.DEFAULT_WAIT_COMMAND
    assert settings['history_limit'] == const.DEFAULT_HISTORY_LIMIT
    assert settings['priority'] == const.DEFAULT_PRIORITY
    assert settings['no_colors'] == const.DEFAULT_NO_COLORS
    assert settings['require_confirmation'] == const.DEFAULT_REQUIRE_CONFIRMATION
   

# Generated at 2022-06-24 05:05:05.013261
# Unit test for constructor of class Settings
def test_Settings():
    env = {}

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir == settings._get_user_dir_path()

    settings.user_dir.joinpath('settings.py').unlink()

    settings.init()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert not settings.require_confirmation

    settings.init()
    assert settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']
    assert settings.rules == const.DEFAULT_SETTINGS['rules']


# Generated at 2022-06-24 05:05:07.669111
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from .tests.utils import AssertIn
    assert AssertIn(settings.__setattr__('name', 'value'), {'name': 'value'})


# Generated at 2022-06-24 05:05:16.886772
# Unit test for method init of class Settings
def test_Settings_init():
    """
    Test that fragment of environment variable is interpreted correctly
    while adding it to the settings.
    """
    import os
    import sys

    from .settings import Settings

    mock_args = type("mock_args", (), {})()
    mock_args.debug = False
    mock_args.repeat = 0


# Generated at 2022-06-24 05:05:20.822028
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init(args=None)
    assert settings.require_confirmation == True
    assert settings.repeat == False
    assert settings.history_limit == None
    assert settings.slow_commands == [
        'lein', 'react-native', 'react-native-cli', 'cargo',
        'composer', 'gradle']
    assert settings.exclude_rules == ['man']
    assert settings.alter_history == True
    assert settings.wait_command == 3
    assert settings.wait_slow_command == 10
    assert settings.env['LANGUAGE'] == os.environ['LANGUAGE']
    assert settings.excluded_search_path_prefixes == ['.']
    assert settings.user_dir == u'~/.config/thefuck'
    assert settings.alter_history == True
    assert settings

# Generated at 2022-06-24 05:05:31.206414
# Unit test for constructor of class Settings
def test_Settings():
    init_dict = {
        'rules': [],
        'exclude_rules': [],
        'priority': {},
        'require_confirmation': True,
        'wait_command': 10,
        'history_limit': None,
        'wait_slow_command': 15,
        'slow_commands': [],
        'excluded_search_path_prefixes': [],
        'no_colors': False,
        'debug': False,
        'alter_history': True,
        'repeat': False,
        'num_close_matches': 0,
        'instant_mode': False
    }

    settings = Settings(init_dict)
    for key, val in init_dict.items():
        assert settings[key] == val


# Generated at 2022-06-24 05:05:34.026388
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation



# Generated at 2022-06-24 05:05:40.490847
# Unit test for method init of class Settings
def test_Settings_init():
    # Attributes settings and user_dir are None
    settings = Settings()
    assert settings == const.DEFAULT_SETTINGS
    # Attributes settings and user_dir are not None
    import tempfile
    from .logs import enable_debug, disable_debug
    enable_debug()
    settings.user_dir = tempfile.mkdtemp()
    settings.DEBUG = False
    settings.init()
    assert settings['DEBUG'] == True
    disable_debug()


# Generated at 2022-06-24 05:05:41.880316
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.new_attr = 'new_value'
    assert settings.new_attr == 'new_value'



# Generated at 2022-06-24 05:05:49.254543
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    import mock
    import sys
    import six

    six.assertCountEqual(test_Settings_init, settings, const.DEFAULT_SETTINGS)

    # Test init from file.
    with mock.patch('thefuck.settings.load_source') as load_source:
        settings._settings_from_file = mock.Mock(return_value={'key': 'value'})
        settings._settings_from_env = mock.Mock(return_value={})
        settings._settings_from_args = mock.Mock(return_value={})
        settings.init()
        settings._settings_from_file.assert_called_once_with()
        settings._settings_from_env.assert_called_once_with()
        settings._settings_from_args.assert_called_once_with

# Generated at 2022-06-24 05:05:55.559340
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.__class__.__name__ == 'Settings'
    expected = ['require_confirmation', 'history_limit', 'no_colors', 'debug',
                'rules', 'exclude_rules', 'wait_slow_command',
                'slow_commands', 'wait_command', 'alter_history',
                'instant_mode', 'num_close_matches',
                'excluded_search_path_prefixes']
    assert sorted(settings.keys()) == sorted(expected)

# Generated at 2022-06-24 05:05:59.652898
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # Test set a key,value pair in the settings
    # should equal to the value
    settings.clear()
    settings.__setattr__('key','value')
    assert settings.__getattr__('key') is 'value'


# Generated at 2022-06-24 05:06:03.058813
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == True
    assert settings.priority == {'noop': 10}


# Generated at 2022-06-24 05:06:06.179324
# Unit test for method init of class Settings
def test_Settings_init():
    test_args = argparse.Namespace()
    test_args.yes = True
    test_args.debug = False
    test_args.repeat = 2

    settings.init(test_args)
    assert settings.require_confirmation == False
    assert settings.debug == False
    assert settings.repeat == 2


# Generated at 2022-06-24 05:06:11.865576
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from .exceptions import SettingsError
    from .tests.utils import assert_equal

    settings = Settings()
    settings.exclude_rules = ['some_rule']
    assert_equal(settings['exclude_rules'], ['some_rule'])
    assert_equal(settings.exclude_rules, ['some_rule'])



# Generated at 2022-06-24 05:06:14.381014
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    s = Settings({'a': 1})
    assert s.a == 1
    assert s.get('a') == 1


# Generated at 2022-06-24 05:06:24.895471
# Unit test for method init of class Settings
def test_Settings_init():
    if os.environ.get('CI', None) == 'true':
        return
    import pytest

    from thefuck.settings import Settings, const

    test_args = type('args', (object,), {'yes': None, 'debug': None, 'repeat': None})
    settings = Settings()
    settings.init(args=test_args)
    assert settings.get_all() == const.DEFAULT_SETTINGS
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'),
                                     'thefuck').expanduser()

    # Add enviroment variable THEFUCK_REQUIRE_CONFIRMATION for test
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'false'

# Generated at 2022-06-24 05:06:31.058800
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('alter_history') == False
    assert settings.get('debug') == False
    assert settings.get('no_colors') == False
    assert settings.get('require_confirmation') == True
    assert settings.get('repeat') == False

# Generated at 2022-06-24 05:06:39.551093
# Unit test for method init of class Settings
def test_Settings_init():
    import mock
    from thefuck.main import TheFuckArgumentParser
    test_arg = mock.Mock(yes = False, debug = False, repeat = None)
    test_set = Settings(const.DEFAULT_SETTINGS)

    test_set.init(test_arg)

# Generated at 2022-06-24 05:06:42.780785
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    settings.init({'yes': True})
    assert settings['require_confirmation'] is False
    settings.init({'debug': True})
    assert settings['debug'] is True
    settings.init({'repeat': True})
    assert settings['repeat'] is True



# Generated at 2022-06-24 05:06:49.721452
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    class A(object):
        settings = {'a': '1', 'b': '2'}

    class B(object):
        settings = {'a': '3', 'c': '4'}

    assert A().settings.a == '1'
    assert B().settings.b == '2'
    assert A().settings.c == '4'
    assert A().settings.d == None


if __name__ == '__main__':
    test_Settings___getattr__()

# Generated at 2022-06-24 05:06:53.885111
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    """
    verify method __setattr__ of class Settings
    """
    s = Settings()
    s.init()
    assert s.does_not_exist is None
    s.does_not_exist = 42
    assert s.does_not_exist == 42
    del s.does_not_exist
    assert s.does_not_exist is None

# Generated at 2022-06-24 05:06:57.259943
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('require_confirmation', True)
    assert settings.get('priority', {})
    assert settings.get('slow_commands') == ['((gnome|kde)-?session|startx|ksmserver)']
    settings.init()

# Generated at 2022-06-24 05:07:08.050757
# Unit test for constructor of class Settings
def test_Settings():
    import os
    xdg_config_home = os.environ.get('XDG_CONFIG_HOME', '~/.config')
    user_dir = Path(xdg_config_home, 'thefuck').expanduser()
    legacy_user_dir = Path('~', '.thefuck').expanduser()

    assert settings._get_user_dir_path() == legacy_user_dir

    os.environ.pop('XDG_CONFIG_HOME')
    assert settings._get_user_dir_path() == legacy_user_dir

    os.environ['XDG_CONFIG_HOME'] = '/tmp/.config'
    assert settings._get_user_dir_path() == user_dir

    os.environ.pop('XDG_CONFIG_HOME')
    assert settings._get_user_

# Generated at 2022-06-24 05:07:14.255298
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings()
    test_settings['key'] = 'value'
    assert test_settings['key'] == 'value'
    assert test_settings.key == 'value'
    assert test_settings.get('key') == 'value'
    assert test_settings.get('wrong_key') == None
    assert test_settings.get('wrong_key', 'test_value') == 'test_value'

# Generated at 2022-06-24 05:07:17.072998
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    test_settings.hello = "world"
    assert(test_settings['hello'] == 'world')



# Generated at 2022-06-24 05:07:25.858329
# Unit test for method init of class Settings
def test_Settings_init():
    from unittest.mock import patch, Mock
    import tempfile

    settings_file_content = const.SETTINGS_HEADER + '\n' +\
                            const.DEFAULT_SETTINGS_STR
    with tempfile.TemporaryDirectory() as temp_dir:
        settings_path = Path(temp_dir, 'settings.py')
        settings_path.write_text(settings_file_content)

        settings = Settings()
        settings.init()
        assert settings['require_confirmation']
        assert not settings['repeat']

        settings = Settings()
        settings._settings_from_file = Mock()
        settings._settings_from_env = Mock()
        settings._settings_from_args = Mock()
        settings.init()
        assert settings._settings_from_file.called
        assert settings._settings_from

# Generated at 2022-06-24 05:07:35.170238
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import logger

    settings.init()
    assert settings.rules
    for key, val in const.DEFAULT_SETTINGS.items():
        assert getattr(settings, key) == val

    for key, val in {'slow_commands': 'mvn'}.items():
        os.environ['THEFUCK_' + key.upper()] = val
        settings = Settings(const.DEFAULT_SETTINGS)
        settings.init()
        assert getattr(settings, key) == val
    os.environ.pop('THEFUCK_SLOW_COMMANDS')

    os.environ['THEFUCK_DEBUG'] = 'YES'
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.debug

# Generated at 2022-06-24 05:07:37.376282
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['require_confirmation']
    settings.init()
    assert settings['require_confirmation']

# Generated at 2022-06-24 05:07:39.057438
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.a = 1
    assert settings['a'] == 1



# Generated at 2022-06-24 05:07:41.959370
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings({'a': 1})
    assert settings.a == 1
    assert settings.b is None



# Generated at 2022-06-24 05:07:43.568344
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings()
    settings.foo = 1
    assert settings.foo == 1



# Generated at 2022-06-24 05:07:46.486011
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings()
    assert settings.__getattr__('key1') == None
    assert settings.__getattr__('key2') == None



# Generated at 2022-06-24 05:07:52.171623
# Unit test for constructor of class Settings
def test_Settings():
    class Test(Settings):
        def __init__(self, args):
            self.args = args
    a = Test({'yes': True, 'debug': True, 'repeat': True})
    a.init()
    assert a.args.yes == a['require_confirmation'] == False
    assert a.args.debug == a['debug'] == True
    assert a.args.repeat == a['repeat'] == True

# Generated at 2022-06-24 05:07:56.290000
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # There is no need to test this method in Python 2.
    from .utils import which
    if which('python2'):
        return
    from .logs import Log

    settings = Settings()
    setattr(settings, 's', 2)
    assert settings['s'] == 2
    setattr(settings, 'log', Log())
    assert isinstance(settings['log'], Log)

# Generated at 2022-06-24 05:08:00.464040
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)
    # Each value in settings should equal the default value
    for key, val in const.DEFAULT_SETTINGS.items():
        assert settings.get(key) == val

# Unit tests for _settings_from_file

# Generated at 2022-06-24 05:08:02.674779
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == True
    assert settings.no_colors == False

# Generated at 2022-06-24 05:08:05.912784
# Unit test for method init of class Settings
def test_Settings_init():
    args = mock.Mock(yes=True, debug=True, repeat=True)
    settings.init(args)
    assert settings.require_confirmation is False
    assert settings.debug is True
    assert settings.repeat is True



# Generated at 2022-06-24 05:08:08.299790
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    """Unit test for method __getattr__ of class Settings."""
    test_settings = Settings(a=1)
    assert Settings.__getattr__(test_settings, 'a') == 1


# Generated at 2022-06-24 05:08:10.829202
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.user_dir.endswith('.config/thefuck')

# Generated at 2022-06-24 05:08:12.592216
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init(args=None)
    assert settings.require_confirmation == True
    assert settings.repeat == False

# Generated at 2022-06-24 05:08:14.383951
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.test = 'test'
    assert settings.test == 'test'


# Generated at 2022-06-24 05:08:16.666473
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings({'foo': 'bar'})
    assert settings.__getattribute__('foo') == 'bar'



# Generated at 2022-06-24 05:08:17.696712
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.testing = 'test'
    assert settings['testing'] == 'test'


# Generated at 2022-06-24 05:08:19.015626
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.python_script == const.DEFAULT_SETTINGS['python_script']



# Generated at 2022-06-24 05:08:20.768398
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    class TestSettings(Settings):
        def init(self, args=None):
            self.update({'test': 'test'})

    s = TestSettings()
    s.init()
    assert s.test == 'test'


# Generated at 2022-06-24 05:08:30.427852
# Unit test for method init of class Settings
def test_Settings_init():
    from .system import check_output

    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME',
                                                    '~/.config')).joinpath(
                                                        'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation

    os.environ['THEFUCK_NO_COLORS'] = 'true'
    os.environ['THEFUCK_ALIAS'] = 'fuck'
    os.environ['THEFUCK_WAIT_COMMAND'] = '5'
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'false'
    os.environ['THEFUCK_PRIORITY'] = 'man_pages=100'
    os

# Generated at 2022-06-24 05:08:32.080644
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.foo = 'bar'
    assert settings['foo'] == 'bar'

# Generated at 2022-06-24 05:08:34.823087
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.init()

    assert settings['require_confirmation'] == True

    settings['require_confirmation'] = False
    assert settings['require_confirmation'] == False

# Generated at 2022-06-24 05:08:42.131481
# Unit test for method init of class Settings
def test_Settings_init():
    overrided_settings = {'priority': {'spam': 1}}
    env_settings = {'debug': True, 'require_confirmation': False}
    arg_settings = {'repeat': True, 'require_confirmation': False}

    settings.init(args=argparse.Namespace(repeat=True, yes=True))
    assert settings == const.DEFAULT_SETTINGS

    settings.update(overrided_settings)
    settings.init(args=argparse.Namespace(repeat=True, yes=True))
    assert settings == overrided_settings

    settings = Settings()
    for env, attr in const.ENV_TO_ATTR.items():
        os.environ[env] = str(env_settings[attr])

# Generated at 2022-06-24 05:08:45.858075
# Unit test for constructor of class Settings
def test_Settings():
    valid_settings = const.DEFAULT_SETTINGS.keys()
    assert all(setting in settings for setting in valid_settings), valid_settings



# Generated at 2022-06-24 05:08:48.621572
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('require_confirmation') == True
    settings.init()
    assert settings.require_confirmation == settings.get('require_confirmation')

# Generated at 2022-06-24 05:08:49.848706
# Unit test for constructor of class Settings
def test_Settings():
    assert dict(settings) == const.DEFAULT_SETTINGS

# Generated at 2022-06-24 05:08:51.722209
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.no_colors
    assert settings.wait_command == 1


# Generated at 2022-06-24 05:08:53.510938
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    global settings
    settings = Settings({'key': 'value'})

    assert settings.key == 'value'


# Generated at 2022-06-24 05:09:01.101473
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    for val in ['require_confirmation', 'rules', 'priority', 'wait_command',
                'history_limit', 'no_colors', 'slow_commands', 'wait_slow_command',
                'exclude_rules', 'excluded_search_path_prefixes', 'alter_history',
                'instant_mode', 'num_close_matches']:
        assert hasattr(settings, val)

# Generated at 2022-06-24 05:09:09.138442
# Unit test for method init of class Settings
def test_Settings_init():
    from .config import load_config
    from .logs import enable_log
    from .helpers import get_all_executables

    args = load_config(['--require-confirmation', 'no'], [])
    settings.init(args)
    assert settings.require_confirmation == False

    args = load_config(['--rules'], ['DEFAULT_RULES'])
    settings.init(args)
    assert settings.rules == const.DEFAULT_RULES

    args = load_config(['--rules'], ['DEFAULT_RULES', 'cd_parent'])
    settings.init(args)
    assert 'cd_parent' in settings.rules

    args = load_config(['--exclude-rules'], ['DEFAULT_RULES'])
    settings.init(args)
   

# Generated at 2022-06-24 05:09:11.666766
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.require_confirmation is True
    assert settings.rules == const.DEFAULT_RULES
    assert settings.no_colors is False


# Generated at 2022-06-24 05:09:17.939188
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    """
    Test method Settings.__getattr__
    """
    assert settings.command_not_found == 'zsh: command not found: '
    assert settings.require_confirmation
    assert not settings.debug



# Generated at 2022-06-24 05:09:19.219429
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.additional_env = {'PATH': '/some/path'}
    assert settings.get('additional_env') == {'PATH': '/some/path'}

# Generated at 2022-06-24 05:09:26.099668
# Unit test for method init of class Settings
def test_Settings_init():
    user_dir = Path('~').expanduser()
    def user_dir_path_side_effect(*args, **kwargs):
        return user_dir

    with mock.patch(
            'thefuck.settings.Settings._get_user_dir_path',
            side_effect=user_dir_path_side_effect):
        with mock.patch.object(settings, '_settings_from_file', return_value={}):
            with mock.patch.object(settings, '_settings_from_env', return_value={}):
                with mock.patch.object(settings, '_settings_from_args', return_value={}):
                    settings.init()

    assert user_dir == settings.user_dir
    assert user_dir.joinpath('settings.py').is_file()



# Generated at 2022-06-24 05:09:29.921219
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings(a = 1, b = "abcd")
    assert s == {"a":1, "b":"abcd"}
    assert s.a == 1
    s.a = 2
    assert s.a == 2
    del s.a
    try:
        s.a
        assert False
    except:
        assert True

# Generated at 2022-06-24 05:09:35.588043
# Unit test for method init of class Settings
def test_Settings_init():
    args = lambda **kwargs: type('Args', (), kwargs)()
    settings.init(args(
        yes=True,
        debug=True,
        repeat=222))
    assert settings['require_confirmation'] == False
    assert settings['debug'] == True
    assert settings['repeat'] == 222

# Generated at 2022-06-24 05:09:44.324506
# Unit test for method init of class Settings
def test_Settings_init():
    """
    Make sure Settings.init() works as expected.
    """
    from mock import patch

    def _load_source(name, path):
        return type('MockedModule', (), {
            'slow_commands': ['slow_command'],
            'require_confirmation': False
        })

    # test_init_settings & test_load_settings_from_file
    with patch('thefuck.settings._init_settings_file', lambda x: None), \
         patch('thefuck.settings.const.DEFAULT_SETTINGS', {'require_confirmation': False,
                                                           'slow_commands': ['slow_command']}), \
         patch('thefuck.settings.load_source', _load_source):
        settings.init()

# Generated at 2022-06-24 05:09:48.450010
# Unit test for constructor of class Settings
def test_Settings():
    _settings = Settings(const.DEFAULT_SETTINGS)
    for setting in const.DEFAULT_SETTINGS.items():
        assert _settings[setting[0]] == _settings.get(setting[0]) == setting[1]
        assert getattr(_settings, setting[0]) == setting[1]
        setattr(_settings, setting[0], 'changed')
        assert _settings[setting[0]] == _settings.get(setting[0]) == 'changed'
        assert getattr(_settings, setting[0]) == 'changed'

# Generated at 2022-06-24 05:09:52.128343
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings['foo'] = 'bar'
    assert settings.foo == 'bar'
    assert settings['foo'] == 'bar'
    assert settings.bar == None
    assert settings['bar'] == None


# Generated at 2022-06-24 05:09:53.510526
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules == const.DEFAULT_SETTINGS['rules']

# Generated at 2022-06-24 05:09:56.222234
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test1 = 'test1'
    assert settings.test1 == 'test1'
    assert settings['test1'] == 'test1'



# Generated at 2022-06-24 05:09:58.250273
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.new_attr = 12345
    assert settings.new_attr == 12345
