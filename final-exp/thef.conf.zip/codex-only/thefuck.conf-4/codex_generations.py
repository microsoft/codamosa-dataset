

# Generated at 2022-06-24 04:59:59.892228
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.rules
    assert settings.only_match

# Generated at 2022-06-24 05:00:10.626466
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import _logger
    from .utils import memoize

    @memoize
    def _get_user_dir():
        return settings._get_user_dir_path()

    # Clear loggers
    _logger.disabled = True

    # Fake `user_dir`
    settings.user_dir = _get_user_dir()
    assert settings.user_dir == _get_user_dir()
    fake_settings_file = settings.user_dir.joinpath('settings.py')
    fake_settings_file.open(mode='w').write('')

    # Fake `XDG_CONFIG_HOME`
    os.environ['XDG_CONFIG_HOME'] = '/tmp/.config'

# Generated at 2022-06-24 05:00:13.157134
# Unit test for method init of class Settings
def test_Settings_init():
    pass

# Generated at 2022-06-24 05:00:14.592036
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init(None)
    assert settings.get('require_confirmation') is True


# Generated at 2022-06-24 05:00:16.505823
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.aaa = 'aaa'
    assert settings['aaa'] == 'aaa'


# Generated at 2022-06-24 05:00:21.501114
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.__setattr__("a", 1)
    assert settings["a"] == 1
    settings.__setattr__("b", 1)
    assert settings["a"] == 1
    assert settings["b"] == 1
    assert settings["c"] is None

# Generated at 2022-06-24 05:00:25.539126
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # Set value
    settings.a = 1
    assert settings.a == 1

    # Overwrite existing value
    settings.a = 2
    assert settings.a == 2

    # Add new value
    settings.b = 3
    assert settings.b == 3


# Generated at 2022-06-24 05:00:33.273860
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import call, patch
    from thefuck.settings import Settings

    mock_user_dir = 'thefuck-test-files'
    mock_settings_file = 'thefuck-test-files/settings.py'

    with patch('thefuck.settings.Path') as mock_path:
        mock_path.side_effect = lambda *args: args
        mock_path.return_value.joinpath.return_value = mock_settings_file
        mock_path.return_value.is_file.return_value = True
        mock_path.return_value.expanduser.return_value = mock_user_dir
        mock_path.return_value.open.return_value.__enter__.return_value = mock_settings_file

# Generated at 2022-06-24 05:00:35.904074
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    obj = Settings()
    obj.key = 'value'
    assert obj['key'] == 'value'

# Generated at 2022-06-24 05:00:46.232706
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.require_confirmation
    assert settings.rules == ['fuck', 'sudo', 'python3', 'python2', 'pip3', 'pip2']
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 3
    assert settings.wait_slow_command == 5
    assert settings.alter_history
    assert settings.no_colors == False
    assert settings.repeat == False
    assert settings.history_limit == 25
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert not settings.instant_mode
    assert settings.num_close_matches == 3

if __name__ == '__main__':
    test_Settings()

# Generated at 2022-06-24 05:00:50.553220
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import shutil
    from thefuck.settings import _get_user_dir_path

    settings.user_dir = _get_user_dir_path()
    settings.init()

    assert settings.user_dir == _get_user_dir_path()
    shutil.rmtree(settings.user_dir)

# Generated at 2022-06-24 05:00:53.439284
# Unit test for constructor of class Settings
def test_Settings():
    assert text_type(settings.user_dir) == '~/.config/thefuck'
    assert settings.user_dir.joinpath('settings.py') == settings.user_dir.joinpath('settings.py')

# Generated at 2022-06-24 05:00:55.237955
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    """Test for method __setattr__ of class Settings"""
    settings = Settings()
    settings.attr = "attr"
    assert settings.attr == "attr"

# Generated at 2022-06-24 05:01:05.236401
# Unit test for constructor of class Settings
def test_Settings():
    settings1 = Settings.__new__(Settings) #settings1 = Settings()
    settings1.init()


# Generated at 2022-06-24 05:01:07.947888
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.alter_history is True
    assert settings.require_confirmation is True
    assert settings.wait_slow_command is 0
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation



# Generated at 2022-06-24 05:01:16.240994
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # Test assertion that __setattr__ is not recursive
    settings.__setattr__('foo', {'bar': 'baz'})
    assert "'bar': 'baz'" not in str(settings)

    # Test assertion that __setattr__ correctly write to the dictionary
    settings.__setattr__('foo', 'baz')
    assert settings['foo'] == 'baz'

    # Test assertion that __setattr__ correctly write to the dictionary
    settings.__setattr__('foo', 'bar')
    assert settings['foo'] == 'bar'



# Generated at 2022-06-24 05:01:17.276666
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules == settings['rules']


# Generated at 2022-06-24 05:01:18.993757
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings['PATH'] = 'some_path'
    assert settings.PATH == 'some_path'


# Generated at 2022-06-24 05:01:21.836101
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.clear() # clear all variables
    settings.a = None
    assert(settings.get('a') == None)
    assert(settings.a == None)
    settings.a = 1
    assert(settings.get('a') == 1)
    assert(settings.a == 1)


# Generated at 2022-06-24 05:01:23.289716
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings()
    settings.foo = 'bar'
    assert settings.foo == 'bar'


# Generated at 2022-06-24 05:01:27.430052
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    result = {}
    settings = Settings()
    settings.__setattr__('key', 'value')
    result['key']='value'
    assert settings == result


# Generated at 2022-06-24 05:01:33.847573
# Unit test for method init of class Settings
def test_Settings_init():
    test_settings = Settings({'rules': ['test'], 'debug': True})
    test_settings._init_settings_file()
    test_settings.init()
    assert test_settings['rules'] == ['test']
    assert test_settings['debug']
    assert test_settings.user_dir.joinpath('settings.py').is_file()



# Generated at 2022-06-24 05:01:43.379386
# Unit test for method init of class Settings
def test_Settings_init():
    from types import ModuleType

    class TestArgs:
        def __init__(self, yes, debug, repeat):
            self.yes = yes
            self.debug = debug
            self.repeat = repeat

    class TestSettings(Settings):
        def __init__(self, user_dir, user_settings):
            self.user_dir = user_dir
            self.user_settings = user_settings
            self.settings = {}

        def _settings_from_env(self):
            return {}

        def _settings_from_file(self):
            return self.user_settings

    import tempfile
    from textwrap import dedent
    from .system import TemporaryDirectory

    with TemporaryDirectory() as temp_dir:
        user_settings = {'rules': ['ls', 'cd']}

# Generated at 2022-06-24 05:01:44.704732
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.enable_experimental_instant_mode


# Generated at 2022-06-24 05:01:46.125539
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.key = 'value'
    assert settings.key == 'value'



# Generated at 2022-06-24 05:01:50.170730
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings['name'] = 'Jim'
    assert settings.name == 'Jim'



# Generated at 2022-06-24 05:01:51.539305
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.foo = 42
    assert settings['foo'] == 42
    assert settings.foo == 42

# Generated at 2022-06-24 05:01:54.313630
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.key = 'value'
    assert settings['key'] == 'value'
    assert settings.key == 'value'

# Generated at 2022-06-24 05:01:57.889108
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    class MockSettings(Settings):
        def __init__(self):
            self.some_key = 'some_value'

    assert MockSettings()['some_key'] == 'some_value'


# Generated at 2022-06-24 05:02:01.425522
# Unit test for method init of class Settings
def test_Settings_init():
    """Unit test for init"""
    # Test without args
    settings.clear()
    settings.init()
    assert settings['require_confirmation'] == True
    assert settings['no_colors'] == False
    assert settings['priority'] == {}

    # Test with args
    settings.clear()
    settings.init(args=type('', (object,), {'debug': 'true', 'yes': True, 'repeat': 'all'}))
    assert settings['debug'] == True
    assert settings['require_confirmation'] == False
    assert settings['repeat'] == 'all'

# Generated at 2022-06-24 05:02:10.029148
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert settings.no_colors
    assert not settings.debug
    assert settings.alter_history
    assert settings.repeat == 1
    assert settings.exclude_rules == ['git_push_current_branch_to_master',
                                      'git_add_and_commit',
                                      'git_checkout_master_and_merge',
                                      'git_checkout_to_master']
    assert settings.wait_command == 0
    assert settings.wait_slow_command == 5
    assert settings.history_limit == 100
    assert settings.priority == {'mvn': 80, 'git': 90}
    assert settings.num_close_matches == 3
    assert settings.instant_mode

# Generated at 2022-06-24 05:02:13.782145
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    class Setting(Settings): pass
    setting = Setting()
    setting.key = 'value'
    assert setting.key == 'value'



#test_Settings___setattr__()

# Generated at 2022-06-24 05:02:18.465913
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import MagicMock, patch
    args = MagicMock()
    args.yes = True
    with patch.object(Settings,'update') as mock_update:
        settings.init(args)
        mock_update.assert_called_once_with({'require_confirmation': False})


# Generated at 2022-06-24 05:02:20.223735
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    s.a = 'a'
    assert s['a'] == 'a'


# Generated at 2022-06-24 05:02:30.024404
# Unit test for constructor of class Settings
def test_Settings():
    from .utils import wrap_streams
    from .logs import log_to_file
    import sys
    from thefuck.settings import Settings
    global settings
    settings = Settings()
    settings.init()
    assert settings['debug'] == False
    assert settings['history_limit'] == None
    assert settings['require_confirmation'] == True
    assert settings['wait_slow_command'] == 3
    assert settings['priority'] == {}
    assert settings['instant_mode'] == False
    assert settings['no_colors'] == False
    assert settings['alter_history'] == True
    assert settings['wait_command'] == 0
    assert settings['exclude_rules'] == []
    assert settings['excluded_search_path_prefixes'] == []
    assert settings['num_close_matches'] == 3

# Generated at 2022-06-24 05:02:34.777171
# Unit test for method init of class Settings
def test_Settings_init():
    from thefuck.conf.settings import Settings
    from mock import patch
    from StringIO import StringIO

    def _real_get_user_dir_path(self):
        return '/config'

    def _real_settings_from_file(self):
        return {'require_confirmation': True, 'wait_command': 1000}

    def _real_settings_from_env(self):
        return {'require_confirmation': False, 'wait_command': 2000}

    def _real_settings_from_args(self, args):
        return {'instant_mode': True}

    with patch('sys.stdout', new=StringIO()) as out:
        Settings.__dict__['_get_user_dir_path'] = _real_get_user_dir_path

# Generated at 2022-06-24 05:02:43.541707
# Unit test for constructor of class Settings
def test_Settings():
    # To test __init__ method of class Settings
    settings = Settings()

    # To test __getattr__ method of class Settings
    settings.__getattr__('slow_commands')
    settings.__getattr__(None)

    # To test __setattr__ method of class Settings
    settings.__setattr__('slow_commands', None)
    settings.__setattr__('slow_commands', ['ls', 'find', 'grep'])

    # To test _get_user_dir_path method of class Settings
    settings._get_user_dir_path()

    # To test _setup_user_dir method of class Settings
    settings._setup_user_dir()

    # To test  _settings_from_file method of class Settings
    settings._settings_from_file()

    # To test _rules_from_

# Generated at 2022-06-24 05:02:53.056086
# Unit test for method init of class Settings
def test_Settings_init():
    from .system import (
        ExecutedCommand,
        ParsedCommand,
        PlaceHolder
    )
    from .utils import (
        datetime_from_timestamp,
        get_all_executables,
        get_closest
    )
    from .logs import (
        debug,
        exception,
        log_to_file,
        log_to_stdout,
        print_debug,
        print_error,
        print_result,
        print_rule,
        print_rewrite
    )

    user_dir = Path('~/.config/thefuck').expanduser()
    # Note: following test is not Windows compatible

    class TestSettings(Settings):
        def __init__(self):
            super(TestSettings, self).__init__()
            self._test_user_dir_

# Generated at 2022-06-24 05:03:01.238803
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.rules == ['cd_parent', 'git_push', 'git_add', 'ls_t', 'python_command', 'sudo']
    assert settings.require_confirmation is True
    assert settings.exclude_rules == []
    assert settings.no_colors is False
    assert settings.debug is False
    assert settings.priority == {'cd_parent': 100, 'git_push': 90, 'git_add': 80, 'ls_t': 70, 'python_command': 60, 'sudo': 50}
    assert settings.wait_command == 1
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', 'mvn']
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15

# Generated at 2022-06-24 05:03:02.997327
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = 'test'
    assert settings.test == 'test'
    assert settings['test'] == 'test'

# Generated at 2022-06-24 05:03:07.352637
# Unit test for method init of class Settings
def test_Settings_init():
    _settings = Settings({'require_confirmation': False})
    _settings.init({'yes':True, 'debug': True})
    assert _settings
    assert _settings.require_confirmation == False
    assert _settings.debug == True
    assert _settings.repeat is None

# Generated at 2022-06-24 05:03:08.215355
# Unit test for constructor of class Settings
def test_Settings():
	s = Settings(const.DEFAULT_SETTINGS)

# Generated at 2022-06-24 05:03:09.592919
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.foo = 'bar'
    assert settings['foo'] == 'bar'


# Generated at 2022-06-24 05:03:10.926106
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.__getattr__('debug') == settings.get('debug')



# Generated at 2022-06-24 05:03:12.787983
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.a = 1
    settings['a'] = 1


# Generated at 2022-06-24 05:03:23.373262
# Unit test for constructor of class Settings
def test_Settings():
    from .logs import _exception
    import sys
    import types
    from .tests.tools import MockPath


# Generated at 2022-06-24 05:03:32.318347
# Unit test for method init of class Settings
def test_Settings_init():
    # With empty args
    settings.init()
    assert settings.user_dir.endswith('.config/thefuck')
    assert settings.user_dir.is_dir()
    assert not settings.debug
    assert settings.repeat == 3
    assert settings.require_confirmation
    assert not settings.no_colors
    assert not settings.alter_history
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.history_limit == 10
    assert settings.num_close_matches == 3

    # With args
    settings.init(args=argparse.Namespace(yes=True,
                                          debug=True,
                                          repeat=2))
    assert settings.debug
    assert settings.repeat == 2
    assert not settings.require_confirmation

    # With env

# Generated at 2022-06-24 05:03:33.588614
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.yes = True
    assert settings['yes']

# Generated at 2022-06-24 05:03:35.396754
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.rules

# Generated at 2022-06-24 05:03:40.570580
# Unit test for constructor of class Settings
def test_Settings():
    import json
    import os

    from . import logs

    from .logs import log
    from .utils import wrap_streams

    settings.init()
    assert settings == const.DEFAULT_SETTINGS

    with wrap_streams(
            stderr=os.devnull, stdout=os.devnull, logger=logs.log):
        with open('settings_json.json', 'w') as f:
            json.dump(settings, f)

    log(settings)

# Generated at 2022-06-24 05:03:51.199058
# Unit test for method init of class Settings
def test_Settings_init():
    class SettingsMock(Settings):
        def _settings_from_file(self):
            return {'rules': ['foo = 1'],
                    'exclude_rules': ['bar = 1']}

        def _settings_from_env(self):
            return {'slow_commands': 'foo',
                    'priority': {'foo': 1},
                    'exclude_rules': ['foo = 1']}

        def _settings_from_args(self, args):
            return {'require_confirmation': False,
                    'debug': True}

    args = type('Args', (object,), {'repeat': 2})()

    settings = SettingsMock()
    settings.init(args)
    assert settings['require_confirmation'] == False
    assert settings['debug'] == True
    assert settings['repeat'] == 2
    assert settings

# Generated at 2022-06-24 05:04:01.502308
# Unit test for constructor of class Settings
def test_Settings():
    settings.init()
    assert settings.get('debug') == False
    assert settings.get('require_confirmation') == True
    assert settings.get('repeat') == False
    assert settings.get('show_in_stdout') == True
    assert settings.get('wait_command') == 1
    assert settings.get('wait_slow_command') == 15
    assert settings.get('rules') == ['git_rebase', 'git_add_patch']
    assert settings.get('exclude_rules') == []
    assert settings.get('history_limit') == None
    assert settings.get('num_close_matches') == 3
    assert settings.get('slow_commands') == ['lein', 'react-native', 'gradle']
    assert settings.get('alter_history') == False

# Generated at 2022-06-24 05:04:02.483460
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.user_dir

# Generated at 2022-06-24 05:04:04.966290
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    """
    Test if get the value of a key that doesn't exist

    Returns:
        True if key doesn't exist and return None
    """
    if settings.key != None:
        return False
    else:
        return True

# Generated at 2022-06-24 05:04:08.039361
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert None == Settings().get('no such attr')



# Generated at 2022-06-24 05:04:09.757130
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.thefuck_alias='thefuck'
    assert settings['thefuck_alias'] == 'thefuck'


# Generated at 2022-06-24 05:04:18.117221
# Unit test for method init of class Settings
def test_Settings_init():
    """Test init method of class Settings"""
    settings = Settings({})
    settings._get_user_dir_path = lambda: Path('user_dir')
    settings._init_settings_file = lambda: None
    settings._settings_from_file = lambda: {
        'require_confirmation': True,
        'slow_commands': ['foo', 'bar'],
        'rules': ['ls']}
    settings._settings_from_env = lambda: {
        'require_confirmation': False,
        'slow_commands': ['baz'],
        'priority': {'ls': 100}}
    settings._settings_from_args = lambda arg: {
        'slow_commands': ['baw'], 'require_confirmation': True}
    settings.init(True)

# Generated at 2022-06-24 05:04:27.449927
# Unit test for method init of class Settings
def test_Settings_init():
    from os import environ
    from shutil import rmtree
    from tempfile import mkdtemp
    from unittest import TestCase
    class TestSettings(TestCase):
        def setUp(self):
            self.config_dir = mkdtemp()
            self.old_XDG_CONFIG_HOME = environ.get('XDG_CONFIG_HOME')
            environ['XDG_CONFIG_HOME'] = self.config_dir

        def tearDown(self):
            rmtree(self.config_dir)
            if self.old_XDG_CONFIG_HOME:
                environ['XDG_CONFIG_HOME'] = self.old_XDG_CONFIG_HOME
            else:
                del environ['XDG_CONFIG_HOME']


# Generated at 2022-06-24 05:04:28.971878
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.wait_command == 3



# Generated at 2022-06-24 05:04:30.765897
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings({'test': 1})
    assert s['test'] == 1
    s.test = 2
    assert s['test'] == 2

# Generated at 2022-06-24 05:04:35.650170
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import log

    settings.init(args=argparse.Namespace(yes=True, debug=True, repeat=1))
    assert not settings.require_confirmation
    assert settings.debug
    assert settings.repeat == 1

    # In case of an error calling the function log with the right parameters
    try:
        settings.init(args=argparse.Namespace(yes=True, debug=True))
    except Exception:
        assert log.call_args_list == [(('Can\'t load settings from env',), {})]
    else:
        assert False

# Generated at 2022-06-24 05:04:39.275357
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.command == 'python'
    assert settings.get_new_command_timing is True
    assert settings.debug is False
    assert settings.require_confirmation is True


# Generated at 2022-06-24 05:04:41.019680
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert(os.path.isfile(os.path.join(settings.user_dir, 'settings.py')))


test_Settings_init()

# Generated at 2022-06-24 05:04:52.395453
# Unit test for constructor of class Settings
def test_Settings():
    user_dir = '~/.config/thefuck'
    settings = Settings(const.DEFAULT_SETTINGS)
    settings._setup_user_dir()
    settings._init_settings_file()
    #setattr(settings, "user_dir", user_dir)

    #test for settings from file
    assert settings._settings_from_file() == {'alter_history': True, 'slow_commands': ['.*'], 'wait_slow_command': 3, 'rules': [], 'debug': False, 'require_confirmation': True, 'priority': {}, 'no_colors': False, 'exclude_rules': [], 'instant_mode': False, 'history_limit': None}

    #test for settings_from_env

# Generated at 2022-06-24 05:04:54.604043
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.require_confirmation
    if not sys.platform.startswith('win'):
        assert settings.alias



# Generated at 2022-06-24 05:04:56.535107
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class_for_test = Settings()
    class_for_test.test_attr = 'test'
    assert class_for_test['test_attr'] == 'test'

# Generated at 2022-06-24 05:05:06.142497
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, dict)

    settings.init()
    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['exclude_rules'] == []
    assert settings['require_confirmation'] is True
    assert settings['wait_command'] == 0
    assert settings['history_limit'] == 10000
    assert settings['wait_slow_command'] == 9
    assert settings['slow_commands'] == ['(?i)^.*(vi|vim|man).*$']
    assert settings['no_colors'] is False
    assert settings.user_dir == settings._get_user_dir_path()
    assert settings['priority'] == {}
    assert settings['alter_history'] is True
    assert settings['instant_mode'] is False
    assert settings['debug'] is False
    assert settings['repeat'] is None

# Generated at 2022-06-24 05:05:08.850171
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.rules == const.DEFAULT_SETTINGS['rules']
    settings.rules = 'changed'
    assert settings.rules == 'changed'



# Generated at 2022-06-24 05:05:10.533209
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('require_confirmation') == True
    assert settings.get('debug') == False

# Generated at 2022-06-24 05:05:19.474691
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    import mock
    from . import rules

    with mock.patch.object(settings, '_settings_from_env', return_value={}):
        with mock.patch.object(settings, '_settings_from_file', return_value={}):
            with mock.patch.object(settings, '_settings_from_args', return_value={'require_confirmation': False}):
                settings.init()
                assert settings.get('require_confirmation') is False


# Generated at 2022-06-24 05:05:24.634532
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    import sys
    class FakeSettings(Settings):
        def __init__(self, items=None, **kwargs):
            if items is None:
                items = {}
            items.update(**kwargs)
            super(FakeSettings, self).__init__(items)
    settings = FakeSettings(user_dir=Path(sys.prefix, 'fake_dir'))
    assert settings.user_dir == Path(sys.prefix, 'fake_dir')
    assert settings.not_exist_key is None


# Generated at 2022-06-24 05:05:32.409700
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    """Unit test for Settings.__setattr__"""
    _settings = Settings()
    _settings['test_key'] = 'test_value'
    assert _settings['test_key'] == 'test_value'
    assert _settings.test_key == 'test_value'
    _settings.test_key = 'test_value_2'
    assert _settings['test_key'] == 'test_value_2'
    assert _settings.test_key == 'test_value_2'

# Generated at 2022-06-24 05:05:41.623057
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import logger
    from .utils import wrap_streams

    with wrap_streams():
        settings.init()
        for msg in [logger.exception.call_args, logger.warn.call_args]:
            assert "Can't load settings from file" in msg[0][0]
        assert settings.debug == False
        assert settings.require_confirmation == True
        assert settings.alter_history == False
        assert settings.slow_commands == []
        assert settings.history_limit == None
        assert settings.exclude_rules == []
        assert settings.excluded_search_path_prefixes == []
        assert settings.wait_command == 0
        assert settings.wait_slow_command == 1.0
        assert settings.no_colors == False
        # No sudo rules without real sudo

# Generated at 2022-06-24 05:05:49.056242
# Unit test for method init of class Settings
def test_Settings_init():
    import os

    environ = os.environ

# Generated at 2022-06-24 05:05:49.692006
# Unit test for constructor of class Settings
def test_Settings():
    assert Settings()

# Generated at 2022-06-24 05:05:51.954514
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.script == 'fuck'
    settings.script = 'test'
    assert settings['script'] == 'test'



# Generated at 2022-06-24 05:05:58.678983
# Unit test for method init of class Settings
def test_Settings_init():
    args = type('TestArgs', (object,), {
        'debug': True,
        'repeat': True,
        'yes': True,
    })
    settings.init(args)

    assert settings.get('debug') == True
    assert settings.get('repeat') == True
    assert settings.get('require_confirmation') == False



# Generated at 2022-06-24 05:06:08.876709
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch, call
    from thefuck import const
    from thefuck.settings import Settings
    from thefuck.types import Rule

    def _init_settings_file():
        settings_file.write(const.SETTINGS_HEADER)
        for setting in const.DEFAULT_SETTINGS.items():
            settings_file.write(u'# {} = {}\n'.format(*setting))

    mock_settings_path = Mock(spec_set=Path)
    mock_settings_path.is_file.return_value = False

# Generated at 2022-06-24 05:06:15.517762
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    """
    Test to check if the __setattr__ method of Settings class is
    setting the value in settings dictionary.
    """
    test_setting = 'is_setting_value_in_dictionary'
    test_value = 'value_set'
    setattr(settings, test_setting, test_value)
    assert settings.get(test_setting) == test_value
    del settings[test_setting]



# Generated at 2022-06-24 05:06:19.226318
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.is_a_setting == const.DEFAULT_SETTINGS['is_a_setting']
    assert settings.not_a_setting is None
    assert settings['not_a_setting'] is None



# Generated at 2022-06-24 05:06:28.826575
# Unit test for method init of class Settings
def test_Settings_init():
    settings_from_file = Settings(const.DEFAULT_SETTINGS)
    settings_from_file._init_settings_file()

# Generated at 2022-06-24 05:06:31.422709
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    '''
    Test the method __setattr__ of class Settings
    '''
    assert settings.get("require_confirmation") == True


# Generated at 2022-06-24 05:06:41.533449
# Unit test for constructor of class Settings
def test_Settings():
    import pytest
    from .system import Popen, CommandNotFound, Path
    from .logs import Logger
    from .levels import Config
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-y", "--yes", action="store_true", help="Don't ask before run")
    parser.add_argument(
        "-d", "--debug", action="store_true", help="Enable debug logging")
    parser.add_argument(
        "-r", "--repeat", action="store_true", help="Repeat last command")
    args = parser.parse_args()
    Popen.which = lambda *args, **kwargs: [Path('/some/path')]
    Logger.log_to_stdout = lambda *args, **kwargs: None
    Config.get

# Generated at 2022-06-24 05:06:42.963271
# Unit test for constructor of class Settings
def test_Settings():
    assert const.DEFAULT_SETTINGS['require_confirmation'] == settings['require_confirmation']

# Generated at 2022-06-24 05:06:44.544606
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules == const.DEFAULT_RULES



# Generated at 2022-06-24 05:06:48.412838
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings_test = Settings(const.DEFAULT_SETTINGS)
    settings_test.__setattr__("_settings_from_args", None)
    assert settings_test.__getattr__("_settings_from_args") == None


# Generated at 2022-06-24 05:06:58.778956
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.init() == {}

# Generated at 2022-06-24 05:07:02.857507
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('require_confirmation') == True
    assert settings.get('history_limit') == 10

if __name__ == '__main__':
    test_Settings()

# Generated at 2022-06-24 05:07:07.305017
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    for key in const.DEFAULT_SETTINGS:
        assert settings.get(key) == const.DEFAULT_SETTINGS[key]

# Generated at 2022-06-24 05:07:12.026191
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings(debug=False, require_confirmation=True, rules=[])
    assert s.debug == False
    assert s.require_confirmation == True
    assert s.rules == []


# Generated at 2022-06-24 05:07:14.777695
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings.clear()
    settings.init()
    assert settings == const.DEFAULT_SETTINGS

# Generated at 2022-06-24 05:07:17.322546
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.test = 'test'
    assert settings['test'] == 'test'
    assert settings.test == 'test'

# Generated at 2022-06-24 05:07:19.197772
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():

    settings.init({})

    assert settings.require_confirmation


# Generated at 2022-06-24 05:07:20.637445
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules == const.DEFAULT_RULES


# Generated at 2022-06-24 05:07:22.974013
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    """Test docstring for method `__setattr__` of class `Settings`"""
    obj = Settings()
    obj.field = 1
    assert obj['field'] == obj.field

# Generated at 2022-06-24 05:07:34.278079
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

    assert settings.user_dir is not None
    settings_file = settings.user_dir + '/settings.py'
    assert settings_file is not None
    settings = load_source('settings', settings_file)
    assert settings
    assert settings.rules is not None
    assert settings.require_confirmation is not None
    assert settings.no_colors is not None
    assert settings.priority is not None
    assert settings.wait_command is not None
    assert settings.history_limit is not None
    assert settings.wait_slow_command is not None
    assert settings.slow_commands is not None
    assert settings.exclude_rules is not None
    assert settings.excluded_search_path_prefixes is not None
    settings4 = Settings(const.DEFAULT_SETTINGS)

# Generated at 2022-06-24 05:07:36.433349
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    """Unit test for __getattr__ method of Settings class."""
    assert settings.wait_slow_command == settings['wait_slow_command']


# Generated at 2022-06-24 05:07:38.621230
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.wait_command == 3
    assert settings.history_limit == None
    assert settings.repeat == None

# Generated at 2022-06-24 05:07:41.317786
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    """
    If a settings is found in settings, then return settings value
    """
    settings = Settings({'key': 'value'})
    assert settings.key == 'value'



# Generated at 2022-06-24 05:07:49.006833
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    def test_func(attr_name):
        # should return value when calling settings.attr_name
        settings.__setattr__(attr_name, 'test_value')
        return settings.__getattr__(attr_name)
    assert 'test_value' == test_func('test_attr')
    assert 'test_value' == test_func('test_attr')
    # should return None when calling settings.other_attr
    assert None == test_func('other_attr')

# Generated at 2022-06-24 05:07:50.182910
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.a = 1
    assert settings.a == 1
    assert settings['a'] == 1


# Generated at 2022-06-24 05:07:53.816405
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class testSettings(dict):
        def __init__(self, settings):
            super(testSettings, self).__init__(settings)

    test_settings= testSettings(const.DEFAULT_SETTINGS)
    test_settings.debug = True
    assert test_settings['debug']

# Generated at 2022-06-24 05:07:55.263821
# Unit test for constructor of class Settings
def test_Settings():
    assert const.DEFAULT_SETTINGS == settings



# Generated at 2022-06-24 05:07:59.496645
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == True
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein']
    assert settings.excluded_search_path_prefixes == []
    assert settings.priority == {}
    assert settings.history_limit == None
    assert settings.repeat

# Generated at 2022-06-24 05:08:02.849516
# Unit test for method init of class Settings
def test_Settings_init():
    class A:
        pass
    a = A()
    a.args = A()
    a.args.yes = True
    a.args.repeat = True
    Settings(const.DEFAULT_SETTINGS).init(a.args)
    print(settings)

# Generated at 2022-06-24 05:08:05.734514
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings1 = Settings()
    settings1.key = 'value'
    assert settings1['key'] == 'value'

# Generated at 2022-06-24 05:08:12.282879
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from datetime import date
    from datetime import time

    settings.test_date = date(2011, 1, 2)
    assert settings.test_date.__class__.__name__ == "date"

    settings.test_time = time(10, 10, 10)
    assert settings.test_time.__class__.__name__ == "time"

    settings.test_int = 123
    assert settings.test_int.__class__.__name__ == "int"

    settings.test_float = 123.456
    assert settings.test_float.__class__.__name__ == "float"

# Generated at 2022-06-24 05:08:21.896455
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    class Args():
        debug = True
        repeat = 10
        yes = True

    settings.init(Args)
    assert settings.repeat == 10
    assert settings.debug is True
    assert settings.require_confirmation is False

    try:
        from unittest.mock import patch
        with patch('thefuck.settings.logs.exception') as log_exception:
            settings.init()
            assert log_exception.call_count == 2
    except ImportError:
        # Python 2.7 compatibility
        from mock import patch
        with patch('thefuck.settings.logs.exception') as log_exception:
            settings.init()
            assert log_exception.call_count == 2

# Generated at 2022-06-24 05:08:26.166372
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    s.a = 1
    assert s == {'a': 1}
    s.a = 2
    assert s == {'a': 2}


# Generated at 2022-06-24 05:08:27.199330
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.testattr = 1
    assert settings.testattr == 1



# Generated at 2022-06-24 05:08:30.716157
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings()
    test_settings.test_attr = 'test_attr'
    assert test_settings['test_attr'] == 'test_attr'


# Generated at 2022-06-24 05:08:40.070397
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import shutil
    import tempfile
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-24 05:08:41.162884
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert settings.get('require_confirmation')

# Generated at 2022-06-24 05:08:42.471177
# Unit test for constructor of class Settings
def test_Settings():
    settings.init({})
    assert settings.require_confirmation
    assert not settings.debug
    assert not settings.repeat

# Generated at 2022-06-24 05:08:53.616721
# Unit test for method init of class Settings
def test_Settings_init():
    # Create temp dir for test
    import tempfile
    import shutil
    from .logs import exception
    from .system import get_aliases, get_history
    from .rules.base import BaseRule

# Generated at 2022-06-24 05:09:00.008772
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    import mock
    from .const import DEFAULT_SETTINGS
    settings = Settings(DEFAULT_SETTINGS)
    settings.update = mock.MagicMock()
    settings.regenerate_command = 'fuck'
    settings.update.assert_called_once_with({'regenerate_command': 'fuck'})

# Generated at 2022-06-24 05:09:01.354215
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init(args=None)
    settings.init(args=None)

# Generated at 2022-06-24 05:09:06.661704
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test_Settings___setattr__ = True
    assert settings['test_Settings___setattr__']
    del settings.test_Settings___setattr__


# Generated at 2022-06-24 05:09:12.988683
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert settings.rules == const.DEFAULT_RULES
    assert settings.priority == {}
    assert settings.history_limit == 0
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['sudo']
    assert settings.exclude_rules == []
    assert settings.num_close_matches == 3
    assert settings.alter_history
    assert settings.instant_mode
    assert not settings.debug
    assert not settings.no_colors
    assert settings.excluded_search_path_prefixes == ['/usr/local', '/usr']


# Generated at 2022-06-24 05:09:17.739281
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class TestSettings(Settings):
        pass

    settings = TestSettings()
    settings.hello = 'world'
    assert settings['hello'] == 'world'
    assert settings.hello == 'world'

# Generated at 2022-06-24 05:09:25.177188
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    import mock
    from random import shuffle

    class Args:
        debug = False
        yes = True
        repeat = None

    settings = Settings(const.DEFAULT_SETTINGS)
    with tempfile.TemporaryDirectory() as tmpdir:
        user_dir = Path(tmpdir)
        rules_dir = user_dir.joinpath('rules')
        rules_dir.mkdir()
        settings_path = user_dir.joinpath('settings.py')
        with settings_path.open(mode='w') as settings_file:
            settings_file.write(const.SETTINGS_HEADER)
            for setting in const.DEFAULT_SETTINGS.items():
                settings_file.write(u'# {} = {}\n'.format(*setting))

# Generated at 2022-06-24 05:09:28.418860
# Unit test for constructor of class Settings
def test_Settings():
    settings.init()

# Generated at 2022-06-24 05:09:30.882757
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    # should return None if value is not set
    assert settings.helloworld == None

    settings.helloworld = 'test'
    assert settings.helloworld == 'test'

# Generated at 2022-06-24 05:09:31.655043
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = 1
    assert settings['test'] == 1


# Generated at 2022-06-24 05:09:32.777838
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings()
    test_settings.foo = "bar"
    assert test_settings.foo == "bar"


# Generated at 2022-06-24 05:09:35.056818
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    setting = Settings()
    setting.test = "test"
    assert setting["test"] == "test"


# Generated at 2022-06-24 05:09:42.879495
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('rules') == const.DEFAULT_RULES + ['perl_command_not_found']
    assert settings.get('require_confirmation') is True
    assert settings.get('prioritize_match') == 1
    assert settings.get('no_colors') == False
    assert settings.get('debug') == False
    assert settings.get('repeat') == 1
    assert settings.get('wait_slow_command') == 3
    assert settings.get('wait_command') == 1
    assert settings.get('alter_history') == True
    assert settings.get('exclude_rules') == []
    assert settings.get('slow_commands') == ['lein', 'react-native', 'gradle', ]
    assert settings.get('history_limit') == None

# Generated at 2022-06-24 05:09:49.133257
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['rules'][0].name == 'git_push_name_with_remote'
    assert settings['rules'][1].name == 'git_push_failed'
    assert settings['priority']['git_push_failed'] == 100
    assert settings['priority']['git_push_name_with_remote'] == 110
    assert settings['require_confirmation'] is True
    assert settings['alter_history'] is True
    assert settings['wait_command'] == 1
    assert settings['history_limit'] == 1000
    assert settings['no_colors'] is False
    assert settings['debug'] is False
    assert settings['slow_commands'] == ['lein', 'react-native', 'gradle']
    assert settings['wait_slow_command'] == 15
    assert settings['exclude_rules'] == ['cd_parent']
   

# Generated at 2022-06-24 05:09:52.445869
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.user_dir == '/home/user/.config/thefuck'

# Generated at 2022-06-24 05:09:55.213465
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.get('require_confirmation')
    settings.__setattr__('require_confirmation', False)
    assert settings.get('require_confirmation') == False

# Generated at 2022-06-24 05:09:56.897582
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    for attr in const.DEFAULT_SETTINGS:
        assert getattr(test_settings, attr) == const.DEFAULT_SETTINGS[attr]

# Generated at 2022-06-24 05:10:06.184291
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['use_best_match_only'] == True 
    assert settings['use_not_command'] == True
    assert settings['reverse_match'] == False
    assert settings['include_rules'] == []
    assert settings['exclude_rules'] == []
    assert settings['priority'] == {}
    assert settings['history_limit'] == 500
    assert settings['wait_slow_command'] == 15
    assert settings['wait_command'] == 1
    assert settings['num_close_matches'] == 3
    assert settings['require_confirmation'] == True
    assert settings['no_colors'] == False
    assert settings['wait_slow_command'] == 15
    assert settings['debug'] == False
    assert settings['alter_history'] == True
    assert settings['slow_commands'] == ['lein', 'activator', 'gradle']