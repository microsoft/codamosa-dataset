

# Generated at 2022-06-24 05:00:00.514759
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert isinstance(settings, Settings)


# Generated at 2022-06-24 05:00:04.099115
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.priority == {}

# Generated at 2022-06-24 05:00:06.761765
# Unit test for method init of class Settings
def test_Settings_init():
    # TODO: please, correct my test
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init(None)
    assert settings['require_confirmation'] == False

# Generated at 2022-06-24 05:00:10.507064
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    from .logs import capture_log
    settings.test = 100
    if settings.test != 100:
        return False
    # Test for not existing key
    with capture_log() as captured:
        settings.not_exist = 1
    if not captured:
        return False
    return True

# Generated at 2022-06-24 05:00:14.078280
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.__setattr__('a', 1) == {'a': 1}


# Generated at 2022-06-24 05:00:15.457344
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    _dict = {}
    _dict['a'] = 1
    assert _dict['a'] == 1


# Generated at 2022-06-24 05:00:22.042465
# Unit test for method init of class Settings
def test_Settings_init():
    # 1. Given
    args = ['--yes']
    user_dir = Path(os.path.dirname(__file__), 'resources/rules')

    # 2. When
    settings.init(args)

    # 3. Then
    assert settings.user_dir == user_dir
    assert not settings.require_confirmation



# Generated at 2022-06-24 05:00:31.328192
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)

    # unit test for method init of class Settings

    # two decorators for unit test for method init of class Settings
    def dec_init_confirmation(init):
        def wrapper(self, *args, **kwargs):
            import sys
            if sys.version_info[0] == 3:
                import builtins
            else:
                import __builtin__ as builtins

            args_yes = args[0] if args else None
            if args_yes:
                args_yes.yes = True
                builtins.input = lambda x: 'y'

            ret = init(self, *args, **kwargs)
            args_yes.yes = False
            builtins.input = input
            return ret
        return wrapper


# Generated at 2022-06-24 05:00:33.888259
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings({'key': 'value'})
    args = Mock(repeat=1)
    settings.init(args)
    assert settings['repeat'] == 1

# Generated at 2022-06-24 05:00:36.443134
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.hello = 'world'
    assert settings.hello == settings['hello']



# Generated at 2022-06-24 05:00:39.090613
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.priority == const.DEFAULT_RULES
    assert settings.require_confirmation is True


# Generated at 2022-06-24 05:00:41.512974
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    a = Settings()
    a['foo'] = 'bar'
    assert a.foo == 'bar'


# Generated at 2022-06-24 05:00:48.728381
# Unit test for method init of class Settings
def test_Settings_init():
    args = Mock(yes=False, debug=None, repeat=None)
    env_path = 'src/thefuck/settings.py'
    with patch('thefuck.conf.settings.user_dir',
               'thefuck/tests/fixtures') as user_dir_mock:
        with mock.patch('thefuck.conf.settings.environ',
                        {'TF_RULES': 'bash_history:alt_bash_history'}):
            with mock.patch.object(sys, 'argv', ['fuck', 'ls']):
                with mock.patch.object(sys, 'path', [env_path]):
                    settings_mock = Mock()
                    settings.init(args)
                    assert settings_mock.user_dir == user_dir_mock

# Generated at 2022-06-24 05:00:50.376813
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    setattr(settings, 'key', 'value')
    assert settings['key'] == 'value'

# Generated at 2022-06-24 05:01:01.322046
# Unit test for method init of class Settings
def test_Settings_init():
    from unittest.mock import patch

    with patch('thefuck.settings.Settings._init_settings_file') \
            as mock_init_settings_file:
        with patch('thefuck.settings.Settings._settings_from_file') \
                as mock_settings_from_file:
            with patch('thefuck.settings.Settings._settings_from_env') \
                    as mock_settings_from_env:
                with patch('thefuck.settings.Settings._settings_from_args') \
                        as mock_settings_from_args:
                    settings.init()
                    mock_init_settings_file.assert_called_once_with()
                    mock_settings_from_file.assert_called_once_with()
                    mock_settings_from_env.assert_called_once_with()
                    mock_settings_from_args

# Generated at 2022-06-24 05:01:04.970088
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings({"foo": "bar"})
    assert settings.foo == settings["foo"]
    assert settings.foo == "bar"

# Generated at 2022-06-24 05:01:08.174429
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings['require_confirmation'] == True
    settings['require_confirmation'] = False
    assert settings.require_confirmation == False


# Generated at 2022-06-24 05:01:14.286276
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir is not None
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['exclude_rules'] == []
    assert settings['priority'] == {}
    assert settings['require_confirmation'] == True
    assert settings['no_colors'] == False
    assert settings['wait_command'] == 2
    assert settings['wait_slow_command'] == 15
    assert settings['slow_commands'] == []
    assert settings['history_limit'] == None
    assert settings['alter_history'] == False
    assert settings['excluded_search_path_prefixes'] == []
    assert settings['num_close_matches'] == 3
    assert settings['debug'] == False
    assert settings

# Generated at 2022-06-24 05:01:15.560685
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.help == settings.get('help')


# Generated at 2022-06-24 05:01:24.082243
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from .logs import exception
    from tests.utils import support_get_all_logging_records

    # check default value
    assert settings.require_confirmation is True

    # check override
    settings.require_confirmation = False
    assert settings.require_confirmation is False

    # check unknown assigment is ignored
    settings.not_assigned = True
    assert settings.not_assigned is None

    with support_get_all_logging_records() as logs:
        # check exception is logged but not thrown
        settings.not_assigned = Exception('test')
        assert len(logs) == 1
        assert logs[0].msg == "Can't load settings from file"
        assert str(logs[0].exc_info[1]) == "test"



# Generated at 2022-06-24 05:01:33.916272
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .types import Settings as settings_type
    from .utils import get_all_executables

    # excluir archivos ejecutables en carpetas que no estan en PATH de manera recursiva

# Generated at 2022-06-24 05:01:34.934897
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = 1
    assert settings['test'] == 1

# Generated at 2022-06-24 05:01:36.319332
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.wait_command == 3


# Generated at 2022-06-24 05:01:40.996367
# Unit test for constructor of class Settings
def test_Settings():
    #Test the creation of class Settings by giving some parameters

    #Test the creation of class Settings without any parameter
    settings_empty = Settings()
    assert len(settings_empty) == 0

    #Test the creation of class Settings with parameters
    settings_filled = Settings({'a': 1, 'b': 2, 'c': 3})
    assert len(settings_filled) == 3



# Generated at 2022-06-24 05:01:43.722439
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    global settings
    settings = Settings({'a':'A'})
    settings.a = 'b'
    settings.b = 'c'
    assert settings == {'a':'b', 'b':'c'}


# Generated at 2022-06-24 05:01:46.693092
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.init()._settings_from_env() == {}
    assert settings.init()._settings_from_file() == const.DEFAULT_SETTINGS



# Generated at 2022-06-24 05:01:55.825363
# Unit test for method init of class Settings
def test_Settings_init():
    # create temporary directory for tests
    import tempfile
    tmpdir = tempfile.mkdtemp()

    test_settings = Settings(const.DEFAULT_SETTINGS)
    # set tmpdir as thefuck directory
    test_settings._set_user_dir(Path(tmpdir))
    # init settings
    test_settings.init()

    # check if path to config file exists
    assert Path(tmpdir, 'settings.py').is_file()
    # check if path to rules exists
    assert Path(tmpdir, 'rules').is_dir()

    # create temporary environment variables
    import random
    import string
    env_vars = {}

# Generated at 2022-06-24 05:01:57.921293
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert not hasattr(settings, 'attr')
    settings.attr = 'attr_value'
    assert settings.attr == 'attr_value'

# Generated at 2022-06-24 05:01:58.861571
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.new_key = 123
    assert settings.new_key == 123


# Generated at 2022-06-24 05:02:01.279339
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings1 = Settings(const.DEFAULT_SETTINGS)
    setattr(settings1,"language","fuck")
    assert settings1["language"] == "fuck"

# Generated at 2022-06-24 05:02:04.358459
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('rules').is_dir() is True


# Generated at 2022-06-24 05:02:12.242712
# Unit test for constructor of class Settings
def test_Settings():
    from .utils import wrap_streams
    from .utils import read_output
    from .intersection import merge_coroutines
    from .rules import get_rules
    from .logs import log_to_file
    assert settings.settings_file == const.DEFAULT_SETTINGS['settings_file']
    assert settings.rules == const.DEFAULT_SETTINGS['rules']
    assert settings.wait_command == const.DEFAULT_SETTINGS['wait_command']
    assert settings.wait_slow_command == const.DEFAULT_SETTINGS['wait_slow_command']
    assert settings.history_limit == const.DEFAULT_SETTINGS['history_limit']
    assert settings.prioritize_match == const.DEFAULT_SETTINGS['prioritize_match']
    assert settings.priority == const.DE

# Generated at 2022-06-24 05:02:15.902467
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    a=Settings(const.DEFAULT_SETTINGS)
    a.a=1
    assert a['a']==1


if __name__ == '__main__':
    a=Settings(const.DEFAULT_SETTINGS)
    a.a=1
    print(a)

# Generated at 2022-06-24 05:02:18.869387
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings()
    test_settings.test_attr = "test_attr_value"
    assert test_settings['test_attr'] == "test_attr_value"

# Generated at 2022-06-24 05:02:21.057923
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    for key in settings.keys():
        assert getattr(settings, key) == settings[key]

# Generated at 2022-06-24 05:02:22.835217
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.verbose == True
    assert settings.wait_command == 10


# Generated at 2022-06-24 05:02:27.205818
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.get('priority') == {'fuckyou': 100, 'fuck': 100, 'reuse': 10, 'man': 0}

# Generated at 2022-06-24 05:02:29.300925
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.test_attr = 'test_value'
    assert settings['test_attr'] == 'test_value'

# Generated at 2022-06-24 05:02:36.339985
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['require_confirmation']
    assert settings['sudo_command'] == 'sudo'
    assert settings['exclude_rules'] == ['git_push']
    assert settings['priority'] == {}
    assert settings['history_limit'] == 100
    assert settings['slow_commands'] == ['lein', 'react-native', 'gradle', './gradlew',
                                         'vagrant']
    assert settings['wait_command'] == 10
    assert settings['no_colors'] == False
    assert settings['alter_history'] == True
    assert settings['repeat'] == False
    assert settings['wait_slow_command'] == 15
    assert settings['excluded_search_path_prefixes'] == \
           ['/usr', '/bin', '/opt/bin']
    assert settings['num_close_matches'] == 3

# Generated at 2022-06-24 05:02:43.828391
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.__setattr__('new_attr','new_value') == None
    assert settings['new_attr'] == 'new_value'
    assert settings.__setattr__('new_attr','new_new_value') == None
    assert settings['new_attr'] == 'new_new_value'
    assert settings.new_attr == 'new_new_value'
    assert settings.__setattr__('debug',True) == None
    assert settings['debug'] == True
    assert settings.__setattr__('debug',False) == None
    assert settings['debug'] == False
    assert settings.__setattr__('num_close_matches',10) == None
    assert settings['num_close_matches'] == 10



# Generated at 2022-06-24 05:02:44.568720
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings()
    assert settings.__getattr__('fuck') is None



# Generated at 2022-06-24 05:02:53.228582
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.rules == [u'git_push', u'git_add', u'cd']
    assert settings.priority == {u'git_push': 100, u'cd': 1}
    assert settings.exclude_rules == []
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == False
    assert settings.wait_command == 1
    assert settings.slow_commands == []
    assert settings.wait_slow_command == 15
    assert settings.history_limit == 100
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.instant_mode == False
    assert settings.repeat == None

# Generated at 2022-06-24 05:02:55.429477
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation is True
    assert settings.rules == const.DEFAULT_RULES



# Generated at 2022-06-24 05:03:04.590727
# Unit test for method init of class Settings
def test_Settings_init():
    import unittest
    import tempfile
    from os import environ
    from textwrap import dedent

    class SettingsTestCase(unittest.TestCase):
        def setUp(self):
            self.settings = Settings(const.DEFAULT_SETTINGS)
            self.settings.init()
            self.orig_user_dir = self.settings.user_dir
            self.settings.user_dir = Path(tempfile.mkdtemp())

        def tearDown(self):
            self.settings.user_dir.rmtree()
            self.settings.user_dir = self.orig_user_dir


# Generated at 2022-06-24 05:03:06.169979
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert(settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation'])

# Generated at 2022-06-24 05:03:07.756821
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.key = 'value'
    assert settings['key'] == 'value'


# Generated at 2022-06-24 05:03:19.234610
# Unit test for constructor of class Settings
def test_Settings():
    from hypothesis import assume
    from hypothesis.strategies import sampled_from

    assume(not settings.get('slow_commands') and \
            not settings.get('require_confirmation'))

    settings_test = Settings(slow_commands=['vi'], require_confirmation=True)
    assert settings_test.get('slow_commands') and \
            settings_test.get('require_confirmation') is True

    settings_test = Settings(slow_commands=[], require_confirmation=False)
    assert not settings_test.get('slow_commands') and \
            settings_test.get('require_confirmation') is False

    settings_test = Settings()
    settings_test.update(slow_commands=['vi'])
    assert settings_test.get('slow_commands')


# Generated at 2022-06-24 05:03:29.312468
# Unit test for method init of class Settings
def test_Settings_init():
    """
    `test_settings.test_Settings_init` returns `None` if `settings.init`
    creates correct `settings` config.
    """

    # Example of init settings from env
    os.environ.update({
        'THEFUCK_REQUIRE_CONFIRMATION': 'False',
        'THEFUCK_PRIORITY': 'yes=2:fuck=3:man=4:what=1:another=0',
    })

    # Example of init settings from file
    settings_path = settings.user_dir.joinpath('settings.py')

    if settings_path.exists():
        os.remove(settings_path)

    settings_path.touch()

    with open(settings_path, 'w') as settings_file:
        settings_file.write(const.SETTINGS_HEADER)


# Generated at 2022-06-24 05:03:32.019464
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings['debug'] == False
    settings.debug = True
    assert settings['debug'] == True

# Generated at 2022-06-24 05:03:34.897231
# Unit test for constructor of class Settings
def test_Settings():
    new_settings = Settings()
    assert new_settings is not settings
    for key, val in const.DEFAULT_SETTINGS.iteritems():
        assert new_settings[key] == val

# Generated at 2022-06-24 05:03:36.463338
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, dict)

if __name__ == "__main__":
    test_Settings()

# Generated at 2022-06-24 05:03:47.051332
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['require_confirmation'] == True
    assert settings['debug'] == False
    assert settings['history_limit'] == None
    assert settings['wait_command'] == 3
    assert settings['wait_slow_command'] == 15
    assert settings['repeat'] == False
    assert settings['alter_history'] == True
    assert settings['no_colors'] == False
    assert settings['instant_mode'] == False
    assert settings['priority'] == {}
    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['exclude_rules'] == []
    assert settings['excluded_search_path_prefixes'] == []
    assert settings['slow_commands'] == []
    assert settings['num_close_matches'] == 3
    assert settings['require_confirmation'] == True

# Generated at 2022-06-24 05:03:49.385618
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings()
    settings['FOO'] = 'BAR'
    settings.__getattr__('FOO') == 'BAR'


# Generated at 2022-06-24 05:03:53.223319
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings({'a':'a', 'b':'b'})
    assert s == {'a':'a', 'b':'b'}
    s.a = 'c'
    s.c = 'd'
    assert s == {'a':'c', 'b':'b', 'c':'d'}


# Generated at 2022-06-24 05:04:00.279042
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)
    assert isinstance(settings['rules'], list)
    assert isinstance(settings.exclude_rules, list)
    assert isinstance(settings.priority, dict)
    assert isinstance(settings.wait_command, int)
    assert isinstance(settings.no_colors, bool)
    assert isinstance(settings.require_confirmation, bool)
    assert isinstance(settings.slow_commands, list)
    assert isinstance(settings.excluded_search_path_prefixes, list)
    assert settings.debug is False

# Generated at 2022-06-24 05:04:03.426932
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings()
    assert settings.__getattr__('settings') == None


# Generated at 2022-06-24 05:04:04.497214
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()

    s.test = 1
    assert s['test'] == 1

# Generated at 2022-06-24 05:04:09.601056
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.foo = "bar"
    assert settings.foo == "bar"
    assert settings['foo'] == "bar"
    assert settings.get('foo') == "bar"


# Generated at 2022-06-24 05:04:13.933563
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = 1
    assert settings['test'] == 1
    settings.test = 2
    assert settings['test'] == 2


# Generated at 2022-06-24 05:04:17.109172
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.test1 = u'test1'
    assert settings['test1'] == u'test1'


# Generated at 2022-06-24 05:04:19.017868
# Unit test for method init of class Settings
def test_Settings_init():
    _settings = Settings(const.DEFAULT_SETTINGS)
    _settings.init(args=None)

# Generated at 2022-06-24 05:04:25.768070
# Unit test for constructor of class Settings
def test_Settings():
	assert settings['require_confirmation']==False
	assert settings['no_colors']==False
	assert settings['debug']==False
	assert settings['alter_history']==True
	assert settings['wait_command']==1
	assert settings['wait_slow_command']==15
	assert settings['history_limit']==None
	assert settings['repeat']==False

if __name__ == '__main__':
	test_Settings()

# Generated at 2022-06-24 05:04:27.364755
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings({'a': 1})
    assert settings.a == 1



# Generated at 2022-06-24 05:04:28.906984
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.__setattr__('test', 'True')
    assert settings['test'] == 'True'

# Generated at 2022-06-24 05:04:33.323254
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # Given that I created a Settings object
    # When I set a setting
    settings.new_setting = 1
    # Then the setting should be stored in the object
    settings.new_setting == 1

# Generated at 2022-06-24 05:04:40.788937
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings(const.DEFAULT_SETTINGS)
    s.thefuck_alias = "fuck-this"
    s.thefuck_slow_commands = "fuck-that"
    s.thefuck_wait_command = "fuck-me"
    s.thefuck_alter_history = "fuck-yes"
    s.thefuck_no_colors = "fuck-no"
    s.thefuck_wait_slow_command = "fuck-it"
    s.thefuck_history_limit = "fuck-long"
    s.thefuck_priority = "fuck-first"
    s.thefuck_instant_mode = "fuck-instant"
    s.thefuck_exclude_rules = "fuck-none"
    s.thefuck_rules = "fuck-all"
    s.thefuck_ex

# Generated at 2022-06-24 05:04:45.163948
# Unit test for constructor of class Settings
def test_Settings():
    t = const.DEFAULT_SETTINGS
    t['aliases'] = t['aliases'] + (('gst', 'git status'),)
    s = Settings(t)
    assert s.aliases[-1] == ('gst', 'git status')

# Generated at 2022-06-24 05:04:49.585742
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    from .tests.utils import replace_attr

    assert settings.require_confirmation
    with replace_attr(settings, 'get'):
        assert settings.require_confirmation == settings.get('require_confirmation')


# Generated at 2022-06-24 05:04:57.182074
# Unit test for method init of class Settings
def test_Settings_init():
    """Test method init of class Settings"""
    settings._setup_user_dir = lambda: Path('/tmp')

# Generated at 2022-06-24 05:05:02.324855
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from .tests.utils import expect

    test_settings = Settings()
    test_settings.test_attr = 'test'
    expect(test_settings['test_attr']) == 'test'

# Generated at 2022-06-24 05:05:14.064986
# Unit test for constructor of class Settings
def test_Settings():
    from .logs import exception

    class MockException(Exception): pass

    def mock_init_settings_file():
        raise MockException()
    def mock_settings_from_file():
        raise MockException()
    def mock_settings_from_env():
        raise MockException()
    def mock_settings_from_args():
        raise MockException()

    class MockSettings():
        def __getattr__(self, item):
            return self.get(item)
        def __setattr__(self, key, value):
            self[key] = value
        def __init__(self, dic):
            self.update(dic)
        def init(self):
            mock_init_settings_file()
            mock_settings_from_file()
            mock_settings_from_env()
            mock_settings_from_

# Generated at 2022-06-24 05:05:16.267866
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.wait_command is None
    assert settings['rules'] is None

# Generated at 2022-06-24 05:05:18.383865
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['rules'] == ['fuck_alias']
    assert settings.repeat is False
    assert settings.require_confirmation is True
    assert settings.alter_history is True



# Generated at 2022-06-24 05:05:26.093841
# Unit test for method init of class Settings
def test_Settings_init():
    class Args(object):
        def __init__(self, yes=None, debug=None, repeat=None):
            self.yes = yes
            self.debug = debug
            self.repeat = repeat

    class TempDir(Path):
        def __init__(self, **kwargs):
            kwargs.setdefault('prefix', 'thefuck-test')
            super(TempDir, self).__init__(mkdtemp(**kwargs))

        def __exit__(self, exc_type, exc_value, traceback):
            shutil.rmtree(text_type(self))

        def __enter__(self):
            return self

    from .system import Popen, TemporaryDirectory, NamedTemporaryFile
    from .logs import log_to
    from .terminal import is_a_tty

# Generated at 2022-06-24 05:05:31.306569
# Unit test for method init of class Settings
def test_Settings_init():
    settings.update(const.DEFAULT_SETTINGS)
    settings.update({
        'require_confirmation': True,
        'priority': {},
        'exclude_rules': [],
        'alias': {},
        'debug': False
    })

    assert settings.init() == None


# Generated at 2022-06-24 05:05:41.111626
# Unit test for constructor of class Settings
def test_Settings():
    from tests.utils import Command

    assert settings.init() == {
        'alter_history': True,
        'instant_mode': True,
        'require_confirmation': True,
        'no_colors': False,
        'wait_command': 3,
        'history_limit': 10,
        'wait_slow_command': 15,
        'rules': [],
        'priority': {},
        'exclude_rules': [],
        'slow_commands': ['(?i)vagrant'],
        'excluded_search_path_prefixes': [],
        'debug': False,
        'num_close_matches': 3,
        'user_dir': settings._get_user_dir_path(),
        'repeat': False,
    }


# Generated at 2022-06-24 05:05:42.157141
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    s.correct = 1
    assert s['correct'] == 1

# Generated at 2022-06-24 05:05:43.113736
# Unit test for constructor of class Settings
def test_Settings():
    assert type(settings) is Settings
    assert settings.get('debug') == False


# Generated at 2022-06-24 05:05:44.820779
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init(args=3)
    assert settings.require_confirmation == False
    assert settings.debug == True
    assert settings.repeat == 3

settings.init()

# Generated at 2022-06-24 05:05:46.900857
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.__setattr__('attr', 'val')
    assert settings.attr == 'val'


# Generated at 2022-06-24 05:05:51.422108
# Unit test for constructor of class Settings
def test_Settings():
    settings2 = Settings(const.DEFAULT_SETTINGS)
    settings2.init()

    assert settings.get('priority') == settings2.get('priority')
    assert settings.get('require_confirmation') == settings2.get('require_confirmation')
    assert settings.get('rules') == settings2.get('rules')


# Generated at 2022-06-24 05:05:57.731022
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    global settings
    settings = Settings({'test_attr': 'test_attr_init_value'})
    settings.test_attr = 'test_attr_new_value'
    settings.test_attr_new = 'test_attr_new_new_value'
    assert settings['test_attr'] == 'test_attr_new_value'
    assert hasattr(settings, 'test_attr_new')

# Generated at 2022-06-24 05:05:59.853298
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.foo = {'bar': 'baz'}
    assert settings == {'foo': {'bar': 'baz'}}

# Generated at 2022-06-24 05:06:01.245313
# Unit test for constructor of class Settings
def test_Settings():
    import pytest
    test_settings = Settings(const.DEFAULT_SETTINGS)
    assert test_settings.key == 'value'


# Generated at 2022-06-24 05:06:04.311741
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']
    assert settings['require_confirmation'] == const.DEFAULT_SETTINGS['require_confirmation']



# Generated at 2022-06-24 05:06:10.023419
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    from .logs import log_exception
    from .rules import (get_normalized_rules_names, get_rules,
                        get_enabled_rules_names)
    from .utils import get_all_commands
    from .history import get_history

    s = Settings()
    # Create temp directory as user config
    tmp_conf = tempfile.TemporaryDirectory()
    os.environ['XDG_CONFIG_HOME'] = tmp_conf.name

    # Create settings.py file with some changes
    user_conf = os.path.join(os.environ['XDG_CONFIG_HOME'],
                             'thefuck/settings.py')
    with open(user_conf, 'w') as f:
        f.write('rules = [\'fuck\']\n')
        f

# Generated at 2022-06-24 05:06:14.236132
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class A:
        def __init__(self, settings):
            self.settings = settings

    a = A(settings)
    a.settings.update({"test_a": "1"})
    assert a.settings.get("test_a") == "1"


# Generated at 2022-06-24 05:06:21.253612
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.alias == 'fuck'
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation
    assert settings.priority == {}
    assert settings.exclude_rules == []
    assert settings.wait_command == 0.8
    assert settings.no_colors
    assert settings.alter_history
    assert settings.history_limit == 0
    assert settings.slow_commands == []
    assert settings.wait_slow_command == 3.0
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.repeat == 3
    assert settings.instant_mode



# Generated at 2022-06-24 05:06:23.736725
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings._settings_from_args = lambda *x: {'attr1': 1, 'attr2': 2}
    assert 2 == settings.attr2


# Generated at 2022-06-24 05:06:31.404068
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import log
    from .utils import wrap_streams


# Generated at 2022-06-24 05:06:32.636304
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.test = 999
    assert settings['test'] == 999

# Generated at 2022-06-24 05:06:39.780279
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.require_confirmation is True
    assert settings.history_limit == 0
    assert settings.rules == const.DEFAULT_RULES
    assert settings.alter_history is True
    assert settings.wait_command == 1
    assert settings.priority == {}
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.no_colors is False
    assert settings.instant_mode is False
    assert settings['debug'] is False
    assert settings.num_close_matches == 3
    assert settings.excluded_search_path_prefixes == []



# Generated at 2022-06-24 05:06:44.295360
# Unit test for constructor of class Settings
def test_Settings():
    result = 0
    for key in const.DEFAULT_SETTINGS.keys():
        if not settings.get(key):
            result = 1
    return result

# Generated at 2022-06-24 05:06:46.734828
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.a = 'b'
    assert settings.get('a') == 'b'


# Generated at 2022-06-24 05:06:50.767792
# Unit test for constructor of class Settings
def test_Settings():
    assert 'settings.py' in str(settings.user_dir.joinpath('settings.py'))
    assert settings['require_confirmation'] == False
    assert settings['rules'] == ['git_push', 'git_add_symbolic_ref', 'git_add']

# Generated at 2022-06-24 05:06:54.724226
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings_instance = Settings({'test_key': 'test_value'})
    assert settings_instance.test_key == 'test_value'

    settings_instance = Settings()
    assert settings_instance.test_key is None



# Generated at 2022-06-24 05:06:57.306863
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings(dict(app_version=u'0.0.1'))
    assert s.app_version == u'0.0.1'


# Generated at 2022-06-24 05:07:02.622229
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    test_settings.val = True
    assert test_settings.val == True


# Generated at 2022-06-24 05:07:06.992818
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.echo = 'hello world!'
    assert settings['echo'] == 'hello world!'

if __name__ == '__main__':
    test_Settings___setattr__()

# Generated at 2022-06-24 05:07:11.049405
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.test = 'test'
    assert settings['test'] == 'test'



# Generated at 2022-06-24 05:07:19.960984
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import mock

    with mock.patch.object(Settings, '_settings_from_file', return_value={'a': 1}):
        with mock.patch.object(Settings, '_settings_from_env', return_value={'b': 2}):
            mock_args = mock.Mock()
            mock_args.yes = True
            mock_args.debug = False
            mock_args.repeat = 2
            with mock.patch.dict(os.environ, {'THEFUCK_SETTINGS': ''}):
                settings.init(args=mock_args)

    assert settings.get('a') == 1
    assert settings.get('b') == 2
    assert settings.get('require_confirmation') == False
    assert settings.get('debug') == False
    assert settings.get('repeat')

# Generated at 2022-06-24 05:07:27.165163
# Unit test for method init of class Settings
def test_Settings_init():

    def del_settings_from_file(user_dir):
        """Deletes settings from file."""
        os.remove(Path(user_dir, 'settings.py'))

    def del_settings_from_env(user_dir, settings_from_env):
        """Deletes settings from env."""
        for env in settings_from_env:
            del os.environ[env]

    def get_settings_from_file(user_dir):
        """Gets settings from file"""
        return load_source('settings',
                           text_type(Path(user_dir, 'settings.py')))

    def get_settings_from_env(settings_from_env):
        """Gets settings from env"""

# Generated at 2022-06-24 05:07:31.961034
# Unit test for method init of class Settings
def test_Settings_init():
    settings_init = Settings(const.DEFAULT_SETTINGS)
    settings_init.init()
    assert settings_init._get_user_dir_path() is not None
    assert settings_init._settings_from_env() is not None
    assert settings_init._settings_from_file() is not None
    assert settings_init._settings_from_args(None) is not None

# Generated at 2022-06-24 05:07:34.667911
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(debug=True)
    settings.init()
    assert hasattr(settings, 'debug'), "Settings not have debug"
    assert settings['debug'] == True, "Debug not have True"

# Generated at 2022-06-24 05:07:36.916063
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.get('require_confirmation')
    settings.require_confirmation = False
    assert not settings.get('require_confirmation')



# Generated at 2022-06-24 05:07:39.015839
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    test_settings = Settings({'a': 1, 'b': 2})
    assert test_settings.a == 1
    assert test_settings.b == 2


# Generated at 2022-06-24 05:07:42.637277
# Unit test for constructor of class Settings
def test_Settings():
    assert settings == const.DEFAULT_SETTINGS

    settings = Settings({})
    assert settings == {}

    settings = Settings({'require_confirmation': True})
    assert settings == {'require_confirmation': True}

# Generated at 2022-06-24 05:07:46.649319
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings(a=1, b=2)
    assert s.a == 1
    assert s.b == 2
    assert s.get('c') is None
    s.c = 3
    assert s.c == 3
    assert isinstance(s, dict)

# Generated at 2022-06-24 05:07:48.598568
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.use_notify == True
    assert settings.no_colors == False



# Generated at 2022-06-24 05:07:55.424369
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['debug'] == False
    settings_config = Settings(debug = True)
    settings_config['debug'] = False
    assert settings_config['debug'] == False
    assert settings_config.debug == False
    settings_config.debug = True
    assert settings_config.debug == True
    assert settings_config['debug'] == True
    settings_config['debug'] = False
    assert settings_config['debug'] == False
    settings_config.debug = False
    assert settings_config.debug == False
    assert settings_config['debug'] == False


# Generated at 2022-06-24 05:07:57.665716
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    a = Settings()
    a.b = 1
    assert a['b'] == 1


# Generated at 2022-06-24 05:08:00.670305
# Unit test for method init of class Settings
def test_Settings_init():
    instance = Settings(const.DEFAULT_SETTINGS)
    instance.init({'yes': True})
    assert instance['require_confirmation'] == 'false'
    assert instance['repeat'] == ''

# Generated at 2022-06-24 05:08:03.305320
# Unit test for constructor of class Settings
def test_Settings():
    assert settings._get_user_dir_path() == Path('~/.config/thefuck').expanduser()
    assert settings.wait_command == 3

# Generated at 2022-06-24 05:08:09.585518
# Unit test for method init of class Settings
def test_Settings_init():
    args = type('args', (object,), {'yes': True, 'debug': True,
                                    'repeat': True, 'quiet': False})()
    settings_test = Settings(const.DEFAULT_SETTINGS)
    settings_test.init(args)
    assert settings_test.require_confirmation == False
    assert settings_test.debug == True
    assert settings_test.repeat == True

# Generated at 2022-06-24 05:08:14.665034
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path.home().joinpath('.config', 'thefuck')
    assert settings.rules == ['fuck', 'man', 'advice', 'lucky', 'cd']
    assert settings.require_confirmation is True

    settings.init(args=Namespace(debug=True, repeat=5))
    assert settings.debug is True
    assert settings.repeat == 5

# Generated at 2022-06-24 05:08:22.362602
# Unit test for constructor of class Settings

# Generated at 2022-06-24 05:08:28.764752
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings._setup_user_dir()
    assert settings.user_dir == Path(
        '~/.config/thefuck').expanduser()
    settings._init_settings_file()
    settings_file = settings.user_dir.joinpath('settings.py')
    assert settings_file.is_file()
    settings_file.remove()
    settings.user_dir.rmdir()
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()



# Generated at 2022-06-24 05:08:38.859397
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import _logger
    from .system import platform
    from .platform import _cache
    from .utils import _script_from_command
    from .utils import _script_from_history
    from .utils import _script_from_rule
    import sys
    from six.moves import reload_module

    # Backup original setings
    backup_settings = settings.copy()

    # Mock platform
    mocked_platform = {
        'get_shell_type': lambda: 'python',
        '_script_from_command': lambda *args, **kwargs: None,
        '_script_from_history': lambda *args, **kwargs: None,
        '_script_from_rule': lambda *args, **kwargs: None
    }

# Generated at 2022-06-24 05:08:42.110050
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.__setattr__('test', 'value')
    assert settings.test == 'value'

# Generated at 2022-06-24 05:08:43.965770
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.key = 'value'
    assert settings['key'] == 'value'

# Generated at 2022-06-24 05:08:46.007075
# Unit test for method init of class Settings
def test_Settings_init():
    settings = S

# Generated at 2022-06-24 05:08:48.808354
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings()
    test_settings.new_settings = 'new_settings'
    assert test_settings['new_settings'] == 'new_settings'



# Generated at 2022-06-24 05:08:51.917352
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    class Settings(dict):
        def __getattr__(self, item):
            return item

    settings = Settings({'foo': 'bar'})
    assert settings.foo == 'foo'
    assert settings.bar == 'bar'

# Generated at 2022-06-24 05:09:01.628293
# Unit test for method init of class Settings
def test_Settings_init():
    """
    Settings.init() updates self to settings from settings.py and env.
    It creates settings.py with default values if it doesn't exist.
    """
    # Replace default settings with a 'settings' module that is the same as
    # 'thefuck.settings'
    # And replace `user_dir` with a tempdir.
    from tempfile import mkdtemp
    import thefuck.settings
    reload(thefuck.settings)
    old_default_settings = thefuck.settings.const.DEFAULT_SETTINGS
    thefuck.settings.const.DEFAULT_SETTINGS = const.DEFAULT_SETTINGS
    old_xc = os.environ.get('XDG_CONFIG_HOME')


# Generated at 2022-06-24 05:09:07.209841
# Unit test for constructor of class Settings
def test_Settings():
    # Init with None
    settings = Settings(None)
    assert settings == {}

    # Init with a dict
    settings = Settings({'test': 'test'})
    assert settings == {'test': 'test'}



# Generated at 2022-06-24 05:09:09.904173
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.some_attr = '123'
    assert settings.some_attr == '123'


# Generated at 2022-06-24 05:09:11.414970
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.test = 'test'
    assert settings['test'] == 'test'


# Generated at 2022-06-24 05:09:16.360557
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings['foo'] = 'bar'
    assert 'bar' == settings.foo



# Generated at 2022-06-24 05:09:20.276967
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    global settings
    settings = Settings()
    settings.test = '123'
    assert settings['test'] == '123'

# Generated at 2022-06-24 05:09:30.735075
# Unit test for method init of class Settings
def test_Settings_init():
    args = type('args', (object,), {'yes': False, 'debug': False, 'repeat': False})
    initial_settings = {'exclude_rules': [], 'wait_command': 1,
                        'rules': ['print_fuck', 'git_fuck'],
                        'wait_slow_command': 15, 'priority': {},
                        'require_confirmation': True,
                        'excluded_search_path_prefixes': [],
                        'no_colors': False, 'debug': False,
                        'slow_commands': [], 'alter_history': True,
                        'history_limit': None, 'repeat': False,
                        'num_close_matches': 3, 'instant_mode': False}
    settings.init(args)
    for setting in initial_settings.items():
        assert setting in settings.items

# Generated at 2022-06-24 05:09:35.261038
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.__class__ == Settings
    assert settings.rules == const.DEFAULT_SETTINGS['rules']
    assert settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']
    assert settings.history_limit == const.DEFAULT_SETTINGS['history_limit']
    assert settings.alter_history == const.DEFAULT_SETTINGS['alter_history']
    assert settings.wait_command == const.DEFAULT_SETTINGS['wait_command']
    assert settings.no_colors == const.DEFAULT_SETTINGS['no_colors']
    assert settings.exclude_rules == const.DEFAULT_SETTINGS['exclude_rules']
    assert settings.wait_slow_command == const.DEFAULT_SETTINGS['wait_slow_command']
    assert settings.slow_comm

# Generated at 2022-06-24 05:09:37.255862
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.__setattr__('a', 1)
    assert settings.a == 1


# Generated at 2022-06-24 05:09:42.297971
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from .const import DEFAULT_SETTINGS
    settings = Settings(DEFAULT_SETTINGS)
    assert hasattr(settings, 'require_confirmation')
    assert not settings.has_key('require_confirmation')
    settings.require_confirmation = False
    assert settings.has_key('require_confirmation')
    assert settings['require_confirmation'] == False

if __name__ == '__main__':
    test_Settings___setattr__()

# Generated at 2022-06-24 05:09:43.950936
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.item1 = 'item1'
    assert settings.item1 == 'item1'


# Generated at 2022-06-24 05:09:47.370422
# Unit test for constructor of class Settings
def test_Settings():
    assert Settings(const.DEFAULT_SETTINGS) == const.DEFAULT_SETTINGS

# Generated at 2022-06-24 05:09:48.476838
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    a = Settings()
    b = "foo"
    a.b = b
    assert a['b'] is b

# Generated at 2022-06-24 05:09:57.452920
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    if 'DEBUG' in os.environ:
        del os.environ['DEBUG']

    settings_path = settings['user_dir'].joinpath('settings.py')
    if settings_path.is_file():
        settings_path.remove()
    from_file = settings._settings_from_file()
    assert from_file == {}

    try:
        settings.update(settings._settings_from_env())
    except Exception:
        exception("Can't load settings from env", sys.exc_info())

    settings.init()
    assert settings._get_user_dir_path() == settings['user_dir']

# Generated at 2022-06-24 05:10:06.355354
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.rules == const.DEFAULT_RULES
    assert settings.priority == const.DEFAULT_PRIORITY
    assert settings.alter_history == True
    assert settings.no_colors == False
    assert settings.wait_command == const.DEFAULT_WAIT_COMMAND
    assert settings.require_confirmation == True
    assert settings.slow_commands == const.DEFAULT_SLOW_COMMANDS
    assert settings.history_limit == const.DEFAULT_HISTORY_LIMIT
    assert settings.exclude_rules == const.DEFAULT_EXCLUDE_RULES
    assert settings.excluded_search_path_prefixes == const.DEFAULT_EXCLUDED_SEARCH_PATH_PREFIXES
    assert settings.wait_slow_command == const.DEFAULT_WAIT_SLOW