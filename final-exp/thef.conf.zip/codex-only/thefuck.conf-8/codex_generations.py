

# Generated at 2022-06-24 05:00:02.091847
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import log_to_stderr
    from tempfile import mkdtemp
    from shutil import rmtree
    from .utils import wrap_settings
    from .tests.utils import get_mocked_settings

    settings.clear()
    settings['require_confirmation'] = False
    settings['debug'] = False

    class Args(object):
        yes = False
        debug = False
        repeat = False

    def log(msg):
        assert "Can't load settings from file" in msg
        raise EnvironmentError()

    log_to_stderr(log)
    settings.init(args=Args())

    log_to_stderr(log)
    settings.init()

    settings.clear()
    settings['require_confirmation'] = False
    settings['debug'] = False

    args = Args

# Generated at 2022-06-24 05:00:03.633973
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert 'require_confirmation' == settings.require_confirmation


# Generated at 2022-06-24 05:00:08.436954
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    s.a = 1
    assert s.a == 1



# Generated at 2022-06-24 05:00:11.218313
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    """Check if method __setattr__ of class Settings works correctly"""
    settings = Settings({'foo': 'bar'})
    settings.foo = 'foobar'
    assert settings['foo'] == 'foobar'

# Generated at 2022-06-24 05:00:13.857665
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation is True


# Generated at 2022-06-24 05:00:15.272871
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']


# Generated at 2022-06-24 05:00:16.301385
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.new_attr = 123
    assert settings['new_attr'] == 123

# Generated at 2022-06-24 05:00:17.867312
# Unit test for constructor of class Settings
def test_Settings():
    assert Settings({}) == {}



# Generated at 2022-06-24 05:00:21.551887
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.no_colors == False
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True


# Generated at 2022-06-24 05:00:24.362502
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['no_colors'] == True
    assert settings['wait_slow_command'] == 5
    assert settings['history_limit'] == 10


# Generated at 2022-06-24 05:00:33.927166
# Unit test for method init of class Settings
def test_Settings_init():
    _settings = Settings(const.DEFAULT_SETTINGS)
    _settings.init(args=None)
    assert _settings['exclude_rules'] == ['root']
    assert _settings['rules'] == ['git_push', 'git_add', 'pip', 'brew_install_formula', 'apt_get', 'make', 'git_branch_delete']
    assert _settings['python3'] == True
    assert _settings['require_confirmation'] == True
    assert _settings['alter_history'] == False
    assert _settings['wait_command'] == 0.08
    assert _settings['wait_slow_command'] == 1
    assert _settings['history_limit'] == 1000
    assert _settings['instant_mode'] == False

# Generated at 2022-06-24 05:00:36.443133
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings({'key': 'val'})
    assert settings.key == settings['key']


# Generated at 2022-06-24 05:00:40.790804
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['require_confirmation']
    assert settings['history_limit'] == 100
    assert settings['slow_commands'] == ['(?i)vagrant']


# Generated at 2022-06-24 05:00:43.717924
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    assert test_settings.__getattr__('require_confirmation') == const.DEFAULT_SETTINGS['require_confirmation']
    test_settings.__setattr__('require_confirmation', False)
    assert test_settings.__getattr__('require_confirmation') == False


# Generated at 2022-06-24 05:00:46.813603
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == True


# Generated at 2022-06-24 05:00:48.473777
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules is settings['rules']


# Generated at 2022-06-24 05:00:58.878863
# Unit test for method init of class Settings
def test_Settings_init():
    from unittest.mock import patch
    from thefuck.rules.git_merge_conflict import match, get_new_command

    # set mock values for settings from file
    xdg_config_home = '~/.config'
    user_settings_path = Path(xdg_config_home, 'thefuck', 'settings.py')
    user_settings_py = """
        rules = [
            "git_merge_conflict",
        ]
        exclude_rules = [
            "git_push_current_branch",
        ]
        priority = {
            "echo": 100,
            "git_merge_conflict": 1,
        }
    """

# Generated at 2022-06-24 05:01:02.199752
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings._unknown is None



# Generated at 2022-06-24 05:01:08.797771
# Unit test for constructor of class Settings
def test_Settings():
    def get_settings():
        return {key: value for key, value in settings.items()}

    assert get_settings() == const.DEFAULT_SETTINGS
    settings.update({'test': 'test'})
    assert get_settings() == dict(list(const.DEFAULT_SETTINGS.items()) + [('test', 'test')])
    del settings['test']
    assert get_settings() == const.DEFAULT_SETTINGS



# Generated at 2022-06-24 05:01:11.106839
# Unit test for constructor of class Settings
def test_Settings():
    assert settings == const.DEFAULT_SETTINGS


# Generated at 2022-06-24 05:01:16.674590
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.require_confirmation == True
    assert settings.require_confirmation_visible_in_history == False
    assert settings.history_limit == None



# Generated at 2022-06-24 05:01:19.290221
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings()
    settings.key = "value"
    assert settings.key == "value"
    assert settings["key"] == "value"
    assert settings.key1 is None



# Generated at 2022-06-24 05:01:21.141388
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.has_attr = True
    assert settings.has_attr is True
    assert settings['has_attr'] is True


# Generated at 2022-06-24 05:01:25.116049
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    """
    Settings.__setattr__ should put argument value to the dict.
    """
    from .logs import log_to_stderr

    s = Settings({"default": 1})
    s.log_to_stderr = log_to_stderr
    assert s["log_to_stderr"] == log_to_stderr

test_Settings___setattr__()

# Generated at 2022-06-24 05:01:27.163710
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.a = 1
    assert settings['a'] == 1

# Generated at 2022-06-24 05:01:29.347442
# Unit test for constructor of class Settings
def test_Settings():
    """Test Settings"""
    import types

    assert isinstance(settings, types.DictType)
    assert settings['history_limit'] == 100

# Generated at 2022-06-24 05:01:37.413205
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    s = Settings(const.DEFAULT_SETTINGS)
    li_a = [settings.user_dir, s.user_dir]
    for k in const.DEFAULT_SETTINGS.keys():
        li_a.append(getattr(settings, k))
        li_a.append(getattr(s, k))
    s.init()
    li_b = [settings.user_dir, s.user_dir]
    for k in const.DEFAULT_SETTINGS.keys():
        li_b.append(getattr(settings, k))
        li_b.append(getattr(s, k))
    assert li_a == li_b

# Generated at 2022-06-24 05:01:45.832230
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import tempfile

    settings = Settings()
    temp_dir = tempfile.mkdtemp()
    user_dir = os.path.join(temp_dir, '.thefuck')
    settings_file = os.path.join(user_dir, 'settings.py')

# Generated at 2022-06-24 05:01:55.704366
# Unit test for method init of class Settings
def test_Settings_init():
    class Args(object):
        pass

    args = Args()

    with Path('/tmp/.thefuck').as_cwd():
        settings.init()
        assert settings.require_confirmation
        assert settings.repeat == 1

    with Path('/tmp/.thefuck').as_cwd():
        os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'False'
        settings.init()
        assert not settings.require_confirmation

    with Path('/tmp/.thefuck').as_cwd():
        os.environ['THEFUCK_REPEAT'] = '2'
        settings.init()
        assert settings.repeat == 2

    with Path('/tmp/.thefuck').as_cwd():
        del os.environ['THEFUCK_REPEAT']
        args.repeat = 2

# Generated at 2022-06-24 05:01:56.983389
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.alias == const.DEFAULT_SETTINGS['alias']



# Generated at 2022-06-24 05:01:59.850604
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.test_key = True
    assert settings.test_key
    assert not settings.unexist_key



# Generated at 2022-06-24 05:02:01.525657
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.test = 123
    assert settings['test'] == 123


# Generated at 2022-06-24 05:02:04.626403
# Unit test for constructor of class Settings
def test_Settings():
    default_settings = Settings(const.DEFAULT_SETTINGS)
    assert default_settings['wait_command'] == 1
    assert default_settings['require_confirmation'] == True


# Generated at 2022-06-24 05:02:08.973277
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test_attr = 1
    assert settings['test_attr'] == 1
    assert settings.test_attr == 1
    settings.test_attr += 1
    assert settings['test_attr'] == 2
    assert settings.test_attr == 2
    del settings.test_attr
    assert 'test_attr' not in settings
    with pytest.raises(AttributeError):
        settings.test_attr



# Generated at 2022-06-24 05:02:16.526504
# Unit test for constructor of class Settings
def test_Settings():
    settings_test = Settings(const.DEFAULT_SETTINGS)
    settings_test.init()
    assert settings_test.rules == ['git_push', 'git_merge', 'git_rebase', 'git_checkout', 'git_pull', 'svn_revert', 'apt_get_update', 'make', 'sudo', 'pip_install']
    assert settings_test.history_limit == None
    assert settings_test.wait_slow_command == 3
    assert settings_test.require_confirmation == True
    assert settings_test.no_colors == False

# Generated at 2022-06-24 05:02:18.719697
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.__setattr__('test', 'test')
    assert settings['test'] == 'test'


# Generated at 2022-06-24 05:02:20.098000
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.testing = True
    assert settings['testing']



# Generated at 2022-06-24 05:02:21.526415
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.a = 1
    assert settings['a'] == 1


# Generated at 2022-06-24 05:02:30.986428
# Unit test for method init of class Settings
def test_Settings_init():
    settings_from_file = {'key1': 'value1', 'key2': 'value2'}
    settings_from_env = {'key3': 'value3'}
    settings_from_args = {'key4': 'value4', 'key5': 'value5'}
    user_dir = Settings._get_user_dir_path()
    # mock
    settings.user_dir = user_dir
    settings._settings_from_file = lambda: settings_from_file
    settings._settings_from_env = lambda: settings_from_env
    settings._settings_from_args = lambda: settings_from_args
    settings.init()
    assert settings == dict(const.DEFAULT_SETTINGS, **settings_from_file, **settings_from_env, **settings_from_args)

# Generated at 2022-06-24 05:02:38.246170
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    from os.path import join
    from thefuck.rules import get_all_rules

    assert settings._get_user_dir_path().as_posix() == join(
        '~', '.config', 'thefuck').expanduser()
    assert settings.settings_path.as_posix() == join(
        '~', '.config', 'thefuck', 'settings.py').expanduser()
    assert settings.rules_dir.as_posix() == join('~', '.config',
                                                 'thefuck', 'rules').expanduser()
    assert settings.history_limit == 1000
    assert settings.require_confirmation is True
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew']
    assert settings.no_colors is False
    assert settings.exclude

# Generated at 2022-06-24 05:02:43.860240
# Unit test for method init of class Settings
def test_Settings_init():
    class TestedSettings(Settings):
        def __init__(self):
            self._settings_from_file = lambda: {'key': 'val'}
            self._settings_from_env = lambda: {'key1': 'val1'}
            self._settings_from_args = lambda args: {'key2': 'val2'}
            self.user_dir = Path('user_dir')
            super(TestedSettings, self).__init__(const.DEFAULT_SETTINGS)

    t = TestedSettings()
    t.init(Namespace(yes=True, debug=True, repeat=3))
    assert t['key'] == 'val'
    assert t['key1'] == 'val1'
    assert t['key2'] == 'val2'
    assert t['require_confirmation'] == False
   

# Generated at 2022-06-24 05:02:53.120174
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    import shutil
    import sys
    import os
    from os import path

    def _join(d, *parts):
        return path.join(d, *parts)

    def _exists(d, *parts):
        return path.exists(_join(d, *parts))

    def _writer(d, *parts):
        with open(_join(d, *parts), 'w') as f:
            f.write(const.SETTINGS_HEADER)
            for setting in const.DEFAULT_SETTINGS.items():
                f.write('# {} = {}\n'.format(*setting))

    def _env(**kwargs):
        old_env = os.environ.copy()
        os.environ.update(kwargs)
        yield
        os.environ = old_env



# Generated at 2022-06-24 05:03:00.271499
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.user_dir.endswith('/thefuck')
    assert settings['wait_command'] == const.DEFAULT_SETTINGS['wait_command']
    assert settings['no_colors'] == False
    assert settings['require_confirmation'] == True
    assert settings['history_limit'] == const.DEFAULT_SETTINGS['history_limit']
    assert settings['alter_history'] == const.DEFAULT_SETTINGS['alter_history']
    assert settings['rules'] == const.DEFAULT_RULES

# Generated at 2022-06-24 05:03:01.181724
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    return settings.user_dir


# Generated at 2022-06-24 05:03:03.487080
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings({})
    test_settings.test_key = "test_value"
    assert test_settings["test_key"] == "test_value"

# Generated at 2022-06-24 05:03:05.738852
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings({'a': 1})
    assert settings.a == 1


# Generated at 2022-06-24 05:03:13.021330
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings(
        {'require_confirmation': False, 'rules': ['ls', 'cd'],
         'priority': {'ls': 1000, 'cd': 2000}, 'wait_command': 2000,
         'history_limit': None, 'wait_slow_command': 0, 'slow_commands': ['git'],
         'num_close_matches': 0, 'exclude_rules': [],
         'excluded_search_path_prefixes': [], 'no_colors': False, 'debug': False,
         'alter_history': True, 'instant_mode': False, 'repeat': None})
    assert test_settings.get('require_confirmation') == False, \
        'require_confirmation should be False!'

# Generated at 2022-06-24 05:03:16.787302
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    """
    >>> settings = Settings(const.DEFAULT_SETTINGS)
    >>> settings.foo = 'bar'
    >>> settings['foo']
    'bar'
    """



# Generated at 2022-06-24 05:03:19.655152
# Unit test for constructor of class Settings
def test_Settings():
    settings.init()
    assert os.path.isdir(settings.user_dir)
    settings.user_dir.joinpath('settings.py').unlink()
    settings.user_dir.rmdir()

# Generated at 2022-06-24 05:03:23.295323
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    instance_settings = Settings()
    instance_settings.foo = 'bar'
    instance_settings.foo_bar = 'bar foo'
    assert 'bar' == instance_settings['foo']
    assert 'bar foo' == instance_settings['foo_bar']



# Generated at 2022-06-24 05:03:26.016435
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.attr = 'attr value'
    assert(settings.get('attr') == 'attr value')



# Generated at 2022-06-24 05:03:29.042378
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    class Empty(Settings):
        """Empty class"""
    empty = Empty({})
    assert empty.prop is None

# Generated at 2022-06-24 05:03:32.278530
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings({"tests_enabled": True})
    assert settings["tests_enabled"] is True
    assert settings.tests_enabled is True

# Generated at 2022-06-24 05:03:34.484076
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings['foo'] = 'bar'
    assert settings.foo == 'bar'
    assert settings['foo'] == 'bar'

# Generated at 2022-06-24 05:03:37.062513
# Unit test for method init of class Settings
def test_Settings_init():
    env = os.environ
    try:
        os.environ = {}
        s = Settings()
        assert s.init() == None
    finally:
        os.environ = env


# Generated at 2022-06-24 05:03:38.646224
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    s.test_item = 'value'
    assert s['test_item'] == 'value'

# Generated at 2022-06-24 05:03:40.714075
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings['wait_command'] == const.DEFAULT_SETTINGS['wait_command']

# Generated at 2022-06-24 05:03:43.178379
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    settings.init(object())


# Generated at 2022-06-24 05:03:47.206250
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    test_dict = {'attr1': 1, 'attr2': 2}
    test_settings = Settings(test_dict)
    assert test_settings.attr1 == 1
    assert test_settings.attr2 == 2



# Generated at 2022-06-24 05:03:48.326869
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.get('require_confirmation', False) == True

# Generated at 2022-06-24 05:03:58.333530
# Unit test for constructor of class Settings
def test_Settings():
    # Test plain settings
    test_settings = Settings()
    test_settings.update(const.DEFAULT_SETTINGS)
    assert test_settings == settings

    # Test settings from file
    test_settings = Settings()
    test_settings.init()
    assert test_settings == settings

    # Test settings from env
    test_settings = Settings()
    test_settings.update(const.DEFAULT_SETTINGS)
    test_settings.update(settings._settings_from_env())
    assert test_settings == settings

    # Test settings from args
    test_settings = Settings()
    test_settings.update(const.DEFAULT_SETTINGS)
    test_settings.update(settings._settings_from_args(
            namespace(require_confirmation=False, debug=True, repeat=True)))

# Generated at 2022-06-24 05:04:07.405159
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    settings = Settings(const.DEFAULT_SETTINGS)
    # mock setting file with a string
    with Path('/etc/thefuck/settings.py').open(mode='w') as settings_file:
        settings_file.write(const.SETTINGS_HEADER)
        for setting in const.DEFAULT_SETTINGS.items():
            settings_file.write(u'# {} = {}\n'.format(*setting))

    try:
        os.remove('~/.config/thefuck/settings.py'.replace('~', os.environ.get('HOME')))
    except Exception:
        exception("Can't remove ~/.config/thefuck/settings.py", sys.exc_info())

# Generated at 2022-06-24 05:04:12.357081
# Unit test for method init of class Settings
def test_Settings_init():
    import mock
    import sys

    from .logs import clear_exception_handler
    # pylint: disable=W0603
    global settings

    def new_settings():
        return settings

    def settings_exception_handler(exc_type, exc_value, tb):
        settings_exception_handler.raised = [exc_type, exc_value, tb]
    settings_exception_handler.raised = []
    sys.excepthook = settings_exception_handler

    class FakeArgs(object):
        """Fake args object for unit tests."""
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)


# Generated at 2022-06-24 05:04:16.482229
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings({})
    test_settings.__setattr__('a', 'b')
    assert test_settings.get('a') == 'b'

# Generated at 2022-06-24 05:04:23.920967
# Unit test for constructor of class Settings
def test_Settings():
    default_settings = dict(const.DEFAULT_SETTINGS)
    for key, value in default_settings.items(): 
        got_value = settings.get(key)
        assert got_value == value

    settings.init()
    # The same testcase as test_rule_dir_created, but we also do the test here 
    #  so that we can omit the import statement
    assert settings.user_dir.joinpath('rules').is_dir()
    default_settings['user_dir'] = settings.user_dir
    default_settings['require_confirmation'] = True
    assert settings == default_settings

# Generated at 2022-06-24 05:04:25.990533
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert not settings.DEBUG
    assert settings.rule_search_limit == settings.rules_count_limit


# Generated at 2022-06-24 05:04:27.577825
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.python == 'python'
    assert settings.settings_file == ''



# Generated at 2022-06-24 05:04:33.961153
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.debug == const.DEFAULT_SETTINGS.debug
    assert settings.get("debug") == const.DEFAULT_SETTINGS.debug
    settings.debug = True
    assert settings.get("debug") == True
    assert settings["debug"] == True
    settings.init()

# Generated at 2022-06-24 05:04:35.297970
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings['attr'] = 'value'
    assert settings.attr == 'value'



# Generated at 2022-06-24 05:04:38.723242
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings(a=1)
    assert settings.a == settings['a']
    settings.b = 2
    assert settings.b == settings['b']


# Generated at 2022-06-24 05:04:41.400677
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    test_settings.update({'test': 'test'})
    assert test_settings['test'] == 'test'
    assert test_settings.get('test') == 'test'



# Generated at 2022-06-24 05:04:52.445592
# Unit test for method init of class Settings
def test_Settings_init():
    import pytest
    from .logs import exception

    args = type("args", (object, ), {'yes': True, 'debug': True, 'repeat': True})
    settings.init(args)
    assert settings['require_confirmation'] == False
    assert settings['debug'] == True
    assert settings['repeat'] == True
    assert settings['alter_history'] == True
    assert settings['instant_mode'] == False
    assert settings['no_colors'] == False
    assert settings['num_close_matches'] == 3
    assert settings['wait_command'] == 1
    assert settings['wait_slow_command'] == 15
    assert settings['exclude_rules'] == []
    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['slow_commands'] == ['lein']

# Generated at 2022-06-24 05:04:54.964433
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class Test(object):
        pass

    settings = Test()
    settings.foo = 'bar'
    assert hasattr(settings, 'foo') and getattr(settings, 'foo') == 'bar'

# Generated at 2022-06-24 05:04:59.101758
# Unit test for constructor of class Settings
def test_Settings():
    settings.init()
    assert isinstance(settings, Settings)
    assert isinstance(settings['require_confirmation'], bool)
    assert isinstance(settings['history_limit'], int)
    assert isinstance(settings['alter_history'], bool)
    assert isinstance(settings['wait_command'], int)
    assert isinstance(settings['wait_slow_command'], int)
    assert isinstance(settings['rules'], list)
    assert isinstance(settings['exclude_rules'], list)
    assert isinstance(settings['priority'], dict)
    assert isinstance(settings['no_colors'], bool)
    assert isinstance(settings['debug'], bool)


# Generated at 2022-06-24 05:05:02.869704
# Unit test for constructor of class Settings
def test_Settings():
    from tests.utils import assert_equal

    assert_equal(Settings(a=1), {'a': 1})


# Generated at 2022-06-24 05:05:14.105448
# Unit test for constructor of class Settings
def test_Settings():
    import sys
    import os
    import os.path
    from clicks.testing import CliRunner
    from .__main__ import main
    import shutil
    from .logs import initialize_logger

    usersettingsdir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    usersettingsdir = os.path.join(usersettingsdir, 'tests', 'usersettings')
    user_dir = settings._get_user_dir_path()

    def _run(args):
        args = args if isinstance(args, (list, tuple)) else [args]
        runner = CliRunner()

# Generated at 2022-06-24 05:05:22.188542
# Unit test for constructor of class Settings
def test_Settings():
    with settings.user_dir.joinpath('settings.py').open(mode='w') as settings_file:
        settings_file.write(const.SETTINGS_HEADER)
        for setting in const.DEFAULT_SETTINGS.items():
            settings_file.write(u'# {} = {}\n'.format(*setting))
    settings.init()
    assert(settings.get('require_confirmation') == True)
    assert(settings.get('wait_command') == 3)
    assert(settings.get('rules') == const.DEFAULT_RULES)
    assert(settings.get('enabled_plugins_cache_expiration_time') == 60)
    assert(settings.get('slow_commands') == ['long_running_command'])
    assert(settings.get('history_limit') == None)

# Generated at 2022-06-24 05:05:23.267141
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation is True


# Generated at 2022-06-24 05:05:24.844487
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert settings.correct_all


# Generated at 2022-06-24 05:05:28.958473
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    assert test_settings.no_colors == const.DEFAULT_SETTINGS['no_colors']


# Generated at 2022-06-24 05:05:31.449525
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test_attr = 'test_value'
    assert settings['test_attr'] == 'test_value'


# Generated at 2022-06-24 05:05:41.191071
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .const import SETTINGS_HEADER
    import os, sys
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err
    
    def _get_user_dir_path(self):
        """Returns Path object representing the user config resource"""

# Generated at 2022-06-24 05:05:48.686047
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    from .system import make_temp_directory
    from .logs import init as init_log
    import sys
    import textwrap
    from .const import DEFAULT_RULES, SETTINGS_HEADER
    from imp import load_source

    with make_temp_directory() as temp_dir:
        settings_file = temp_dir.joinpath('settings.py')
        args = '--yes'
        os.environ['THEFUCK_SETTINGS_PATH'] = text_type(settings_file)
        os.environ['THEFUCK_RULES'] = ':'.join(DEFAULT_RULES)
        os.environ['THEFUCK_EXCLUDE_RULES'] = ':'.join(DEFAULT_RULES)

# Generated at 2022-06-24 05:05:50.034541
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert settings.repeat


# Generated at 2022-06-24 05:06:00.857245
# Unit test for constructor of class Settings
def test_Settings():
    # settings = {'require_confirmation': True}
    assert settings.require_confirmation
    assert settings.rules == const.DEFAULT_RULES
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 3
    assert not settings.no_colors
    assert settings.exclude_rules == []
    assert not settings.debug
    assert settings.alter_history
    assert settings.slow_commands == []
    assert settings.num_close_matches == 3
    assert settings.excluded_search_path_prefixes == []
    assert not settings.instant_mode
    assert settings['exclude_rules'] == []
    assert 'exclude_rules' in settings
    settings.exclude_rules = ['foo']


# Generated at 2022-06-24 05:06:07.589445
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch
    from .logs import exception

    args = type('args', (object,), {'yes': True, 'repeat': 2, 'debug': True})


# Generated at 2022-06-24 05:06:10.567001
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings({'id': 42})
    assert settings.id == 42
    assert settings.no_such_key is None


# Generated at 2022-06-24 05:06:12.840570
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.__setattr__('key', 'value')
    assert settings.get('key') is 'value'

# Generated at 2022-06-24 05:06:15.004871
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test_attr = 'test_value'
    assert settings['test_attr'] == 'test_value'


# Generated at 2022-06-24 05:06:23.690048
# Unit test for constructor of class Settings
def test_Settings():
    from .logs import Log, logger as default_logger
    from .utils import get_logger

    log = Log()
    settings = Settings()
    assert settings.logger == default_logger, "logger is default logger"
    assert settings['logger'] == default_logger, "logger is default logger"

    settings.logger = log
    assert settings.logger == log, "logger is log object"
    assert settings['logger'] == log, "logger is log object"

    get_logger.cache_clear()
    assert get_logger() == default_logger, "logger is default logger"


# Generated at 2022-06-24 05:06:31.378283
# Unit test for constructor of class Settings
def test_Settings():
    def get_all_settings():
        return {attr: getattr(settings, attr) for attr in const.DEFAULT_SETTINGS.keys()}

    # os.environ must be not changed
    environ = {}
    environ.update(os.environ)
    # Settings from file must be the same as the default ones
    settings.init()
    assert get_all_settings() == const.DEFAULT_SETTINGS
    # os.environ must be the same as at the beginning
    assert os.environ == environ

    # os.environ must be not changed
    environ = {}
    environ.update(os.environ)
    # Settings from env must be the same as the default ones
    settings.init()
    assert get_all_settings() == const.DEFAULT_SETTINGS
   

# Generated at 2022-06-24 05:06:32.199994
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.DEBUG = True



# Generated at 2022-06-24 05:06:36.106415
# Unit test for constructor of class Settings
def test_Settings():
    import tempfile
    default_settings = const.DEFAULT_SETTINGS.copy()
    default_settings['user_dir'] = tempfile.mkdtemp(prefix='thefuck_')
    settings = Settings(default_settings)
    assert settings.init() == None
    assert settings['user_dir'] == default_settings['user_dir']

# Generated at 2022-06-24 05:06:37.598730
# Unit test for constructor of class Settings
def test_Settings():
    assert 'require_confirmation' in settings.keys()
    assert settings.require_confirmation is True


# Generated at 2022-06-24 05:06:40.653655
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    """ Should be {'__name__': '__main__', 'foo': 42} """
    settings = Settings({'__name__': '__main__', 'foo': 42})
    assert settings.__name__ == '__main__'
    assert settings.foo == 42


# Generated at 2022-06-24 05:06:43.785790
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings(a='A', b='B', c='C')
    assert settings.a == 'A'
    assert settings.b == 'B'
    assert settings.c == 'C'
    assert settings.d is None


# Generated at 2022-06-24 05:06:55.084828
# Unit test for method init of class Settings
def test_Settings_init():
    import sys
    import os
    from .logs import exception

    def user_dir_test():
        os.environ['XDG_CONFIG_HOME'] = '/test_XDG_CONFIG_HOME'
        try:
            settings._setup_user_dir()
            assert settings.user_dir == '/test_XDG_CONFIG_HOME/thefuck'
        finally:
            os.environ.pop('XDG_CONFIG_HOME')

    def init_settings_file_test():
        settings.user_dir = 'tests/test_init_settings_file_test'

# Generated at 2022-06-24 05:07:03.036804
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.user_dir == None
    assert settings.rules == list(const.DEFAULT_RULES)
    assert settings.require_confirmation == True
    assert settings.no_colors == True if sys.platform == 'win32' else False
    assert settings.priority == {}
    assert settings.wait_command == 0
    assert settings.slow_commands == const.DEFAULT_SLOW_COMMANDS
    assert settings.alter_history == True
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.instant_mode == False
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 0
    assert settings.debug == False
    assert settings.num_

# Generated at 2022-06-24 05:07:09.035533
# Unit test for constructor of class Settings
def test_Settings():
    env = {'THEFUCK_WAIT_COMMAND': '1', 'THEFUCK_REQUIRE_CONFIRMATION': 'True'}

    with patch.dict('os.environ', env):
        settings = Settings(const.DEFAULT_SETTINGS)
        assert settings.get('wait_command') == 1
        assert settings.get('require_confirmation') is True

# Generated at 2022-06-24 05:07:11.022050
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    set_ = Settings({"a" : "A"})
    assert set_.a == "A"
    assert set_.b == None


# Generated at 2022-06-24 05:07:12.785260
# Unit test for constructor of class Settings
def test_Settings():
    from . import settings
    from . import __main__

    settings.init(__main__.get_args())


# Generated at 2022-06-24 05:07:14.768859
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    s = settings.copy()
    assert s['require_confirmation'] == True
    assert s.require_confirmation == True


# Generated at 2022-06-24 05:07:24.733595
# Unit test for method init of class Settings
def test_Settings_init():
    """Initialization test"""
    from .logs import exception

    def check(settings_dict, settings_from_file=None, settings_from_env=None,
              settings_from_args=None):
        settings_from_file = settings_from_file if settings_from_file is not None else {}
        settings_from_env = settings_from_env if settings_from_env is not None else {}
        settings_from_args = settings_from_args if settings_from_args is not None else {}

        settings._init_settings_file = _fake_init_settings_file
        settings._settings_from_file = _fake_settings_from_file(settings_from_file)
        settings._settings_from_env = _fake_settings_from_env(settings_from_env)

# Generated at 2022-06-24 05:07:29.732304
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings({"a": 1,"b": 2,"c": 3})
    assert settings["a"] == 1
    assert settings["b"] == 2
    assert settings["c"] == 3
    settings = Settings()
    assert settings == {}

# Generated at 2022-06-24 05:07:38.950430
# Unit test for constructor of class Settings
def test_Settings():
    SETTINGS = {
        'require_confirmation': True,
        'rules': ['fuck'],
        'alias': 'f',
        'priority': {'fuck': 10000},
        'exclude_rules': ['git_push'],
        'wait_command': 1,
        'num_close_matches': 3,
        'history_limit': None,
        'wait_slow_command': 15,
        'slow_commands': ['lein', 'react-native'],
        'excluded_search_path_prefixes': ['.'],
        'no_colors': False,
        'debug': False,
        'alter_history': True,
        'instant_mode': False,
        'repeat': False
    }
    

# Generated at 2022-06-24 05:07:40.221089
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    """Test for method __getattr__ of class Settings"""
    assert settings.require_confirmation == True



# Generated at 2022-06-24 05:07:42.735069
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings(const.DEFAULT_SETTINGS)
    assert s == const.DEFAULT_SETTINGS

# Generated at 2022-06-24 05:07:48.853838
# Unit test for method init of class Settings
def test_Settings_init():
    # Arrange
    import mock
    args = mock.Mock(
        yes=False,
        debug=False,
        repeat=None)
    settings = Settings(const.DEFAULT_SETTINGS)
    # Act
    settings.init(args)
    # Assert
    assert settings.get('require_confirmation') == True
    assert settings.get('debug') == False
    assert settings.get('repeat') == None

# Generated at 2022-06-24 05:07:50.282752
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.script == "thefuck"


# Generated at 2022-06-24 05:07:54.251225
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from test.unit.system import DummyPath
    from test.unit.utils import Mock

    settings = Settings({})
    settings.user_dir = DummyPath('/user/dir')
    settings._init_settings_file = Mock()
    settings._settings_from_file = Mock()
    settings._settings_from_env = Mock()
    settings._settings_from_args = Mock()

    assert settings.user_dir == '/user/dir'
    assert settings._init_settings_file.called
    assert settings._settings_from_file.called
    assert settings._settings_from_env.called
    assert settings._settings_from_args.called

# Generated at 2022-06-24 05:07:56.326566
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings(const.DEFAULT_SETTINGS)
    assert isinstance(s, dict)


# Generated at 2022-06-24 05:07:57.347540
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == True


# Generated at 2022-06-24 05:07:58.527699
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    a = Settings()
    a.foo = 'bar'
    assert a['foo'] == 'bar'


# Generated at 2022-06-24 05:08:01.369218
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.timestamp_format == '%Y-%m-%d %H:%M:%S'
    assert settings.alter_history
    assert settings.fast_mode


# Generated at 2022-06-24 05:08:08.368749
# Unit test for constructor of class Settings
def test_Settings():
    from .system import Path
    from .logs import exception
    from . import const
    from . import utils
    from .const import DEFAULT_SETTINGS
    from .settings import Settings
    from .system import system
    from unittest.mock import patch
    import os
    import tempfile
    import sys

    # add _get_user_dir_path to test the method of getting user config file
    def test_get_user_dir_path(settings):
        assert (settings._get_user_dir_path() == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser())


# Generated at 2022-06-24 05:08:10.479952
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.value == None


# Generated at 2022-06-24 05:08:12.592272
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    two = settings.confirmation_timeout
    assert two == const.DEFAULT_SETTINGS['confirmation_timeout']


# Generated at 2022-06-24 05:08:22.719398
# Unit test for method init of class Settings
def test_Settings_init():
    import os

    from unittest import TestCase
    from unittest.mock import patch

    from imp import find_module, load_module

    from thefuck import const, settings

    class SettingsTest(TestCase):
        def setUp(self):
            self.settings = settings

        @patch('thefuck.settings._settings_from_file')
        @patch('thefuck.settings._settings_from_env')
        @patch('thefuck.settings._settings_from_args')
        def test_init(self, _settings_from_args, _settings_from_env, _settings_from_file):
            _settings_from_args.return_value = {'test_from_args': 'test_from_args'}

# Generated at 2022-06-24 05:08:25.015683
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.temp = 10
    assert settings["temp"] == 10


# Generated at 2022-06-24 05:08:30.269271
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class FakeSettings(Settings):
        def __init__(self):
            self.foo = 'bar'
    fake_settings = FakeSettings()
    assert fake_settings['foo'] == 'bar'

# Generated at 2022-06-24 05:08:35.702765
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.user_dir == settings._get_user_dir_path(
    ), '`user_dir` should be set to the value returned from `_get_user_dir_path`'

# Generated at 2022-06-24 05:08:38.294084
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # Returns result of method __setattr__ of class Settings
    # with different parameters
    _settings = Settings()
    _settings.__setattr__('a', 'b')
    return _settings['a'] == 'b'

# Generated at 2022-06-24 05:08:41.299318
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    settings.init()
    assert settings.wait_slow_command == 5
    assert settings.log_file == '~/.local/share/thefuck/thefuck.log'
    settings.init({'yes': True})
    assert settings.require_confirmation == False
    settings.init({'debug': True})
    assert settings.debug


# Generated at 2022-06-24 05:08:46.277021
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    import sys
    if sys.version_info[0] == 2:
        s = Settings()
        s.a = 1
        assert(s['a'] == 1)
    else:
        s = Settings()
        s.b = 1
        assert(s['b'] == 1)

# Generated at 2022-06-24 05:08:48.379273
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.foo = 'bar'
    assert settings.get("foo") == 'bar'


# Generated at 2022-06-24 05:08:51.871343
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.priority == const.DEFAULT_SETTINGS['priority']


# Generated at 2022-06-24 05:08:54.657942
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init(args=None)

    assert settings.user_dir.as_posix() == '~/.config/thefuck'
    assert settings.include_rules == ['fuckit']
    assert settings.exclude_rules == ['test']
    assert settings['correct_everywhere'] is True
    assert settings.alter_history is False

# Generated at 2022-06-24 05:08:57.639223
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings["test_Settings___setattr__"] = "value"
    assert settings.test_Settings___setattr__ == "value"

# Generated at 2022-06-24 05:08:59.836886
# Unit test for constructor of class Settings
def test_Settings():
    new_settings = Settings(const.DEFAULT_SETTINGS)
    assert new_settings == settings

# Generated at 2022-06-24 05:09:05.009858
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import init_log
    from . import logs
    import types

    init_log = types.MethodType(init_log, None)

    def exception_handler(*args):
        print('exception')

    sys.exc_info = types.MethodType(lambda: (None, None, None), None)
    logs.exception = exception_handler
    settings.init()
    sys.exc_info = sys.exc_info
    logs.exception = logs.exception

# Generated at 2022-06-24 05:09:06.112504
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.priority == const.DEFAULT_SETTINGS['priority']


# Generated at 2022-06-24 05:09:13.497645
# Unit test for method init of class Settings
def test_Settings_init():
    from pytest import raises
    from mock import patch
    from thefuck.settings import Settings
    from thefuck.config import const
    def test_load_file(self):
        with patch('{}.load_source'.format(__name__)) as mock_load_source:
            mock_load_source.side_effect = Exception()
            new_settings = Settings()
            new_settings._init_settings_file()
            new_settings.user_dir = 'dir'
            with raises(SystemExit):
                new_settings._settings_from_file()

    def test_load_env(self):
        with patch('{}.os.environ'.format(__name__)) as mock_environ:
            mock_environ.get.return_value = 'a:b'
            new_settings = Settings()

# Generated at 2022-06-24 05:09:14.821313
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    s = Settings(root='/')
    assert s.get('root') == '/'
    assert s.root == '/'



# Generated at 2022-06-24 05:09:16.460086
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    for key in const.DEFAULT_SETTINGS:
        assert key in settings.keys()
        assert settings[key] == const.DEFAULT_SETTINGS[key]

# Generated at 2022-06-24 05:09:20.269510
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings(answer=42)
    assert settings.answer == 42



# Generated at 2022-06-24 05:09:24.852251
# Unit test for method init of class Settings
def test_Settings_init():
    # create test object
    test_settings = Settings()
    # fill test object with values from settings.py and env
    test_settings.init()
    assert test_settings == settings

# Generated at 2022-06-24 05:09:27.940218
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings._settings_from_args(None) == {}
    assert settings._settings_from_args(('yes', )) == {'require_confirmation': False}
    assert settings._settings_from_args(('debug', )) == {'debug': True}
    assert settings._settings_from_args(('repeat', )) == {'repeat': True}

# Generated at 2022-06-24 05:09:28.640678
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.wait_command == 5



# Generated at 2022-06-24 05:09:33.132487
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    """Test method __getattr__ of class Settings."""
    assert isinstance(settings.require_confirmation, bool)
    assert isinstance(settings.alias, list)
    assert settings.require_confirmation is not None
    assert settings.alias is not None



# Generated at 2022-06-24 05:09:39.893184
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    from .logs import exception

    # test init() raises Exception when cannot load settings from file
    def _exception():
        raise Exception

    original_log_exception = exception
    exception = _exception

    user_dir = tempfile.mkdtemp()
    settings.user_dir = Path(user_dir)

    settings._init_settings_file()

    try:
        settings.init()
    except Exception:
        exception = original_log_exception
        return

    raise Exception('Should have raised exception')



# Generated at 2022-06-24 05:09:41.627133
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.hello = 'world'
    assert settings['hello'] == 'world'

# Generated at 2022-06-24 05:09:43.913752
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']
    # return None for inexistent key
    assert settings.foo is None


# Generated at 2022-06-24 05:09:53.525952
# Unit test for method init of class Settings
def test_Settings_init():
    # test default settings
    assert settings.require_confirmation
    assert not settings.debug
    assert settings.repeat == 3

    test_settings_path = Path(settings.user_dir.joinpath('test_settings.py'))
