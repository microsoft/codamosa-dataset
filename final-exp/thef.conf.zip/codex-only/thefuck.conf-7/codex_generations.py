

# Generated at 2022-06-24 05:00:00.955777
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']


# Generated at 2022-06-24 05:00:02.883491
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    s = Settings({'foo': 'bar'})
    assert s.foo == 'bar'


# Generated at 2022-06-24 05:00:04.996699
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    s.test = 'test'
    assert s['test'] == 'test'


# Generated at 2022-06-24 05:00:09.768001
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(a=1, b=2)
    assert settings['a'] == 1
    assert settings.a == 1

    settings.c = 3
    assert settings['c'] == 3
    assert settings.d == None

    settings.update(d=4, e=5)
    assert settings['d'] == 4
    assert settings['e'] == 5

# Generated at 2022-06-24 05:00:13.999387
# Unit test for constructor of class Settings
def test_Settings():
    settings.init()
    assert settings.exclude_rules == []
    assert settings.history_limit == None

# Generated at 2022-06-24 05:00:14.818276
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert(settings.debug == True)


# Generated at 2022-06-24 05:00:21.099047
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch, Mock
    from .logs import exception


# Generated at 2022-06-24 05:00:22.311230
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings1 = Settings(const.DEFAULT_SETTINGS)
    settings1.test = 'test'
    assert settings1.test == 'test'

# Generated at 2022-06-24 05:00:23.526763
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == True



# Generated at 2022-06-24 05:00:25.385009
# Unit test for constructor of class Settings
def test_Settings():
    settings['require_confirmation'] = False
    assert settings.get('require_confirmation') == False

# Generated at 2022-06-24 05:00:27.496778
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = 'hello world'
    assert settings['test'] == 'hello world'

# Generated at 2022-06-24 05:00:28.546251
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert "rule" == settings.rule


# Generated at 2022-06-24 05:00:38.281416
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.rules == ['fuck']
    assert settings.exclude_rules == []
    assert settings.wait_command == 0
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle',
                                      './gradlew', 'vagrant']
    assert settings.require_confirmation
    assert settings.alter_history
    assert settings.no_colors
    assert settings.excluded_search_path_prefixes == []
    assert settings.priority == dict()
    assert settings.env == dict()
    assert settings.num_close_matches == 3
    assert settings.instant_mode
    assert settings.repeat == 0



# Generated at 2022-06-24 05:00:42.877535
# Unit test for method init of class Settings
def test_Settings_init():
    global settings  # pylint: disable=global-statement,invalid-name

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()

    assert settings == const.DEFAULT_SETTINGS
    assert settings.user_dir == settings._get_user_dir_path()



# Generated at 2022-06-24 05:00:51.929295
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import _logger
    from .logs import disable_stderr, enable_stderr

    def _load_env(**environ):
        return_value = settings
        settings['user_dir'] = 'test_user_dir'
        mock_load_source = Mock()
        with patch.object(__builtins__, 'open', mock_open()):
            with patch.object(builtins, 'open', mock_open()):
                with patch.object(sys, 'stderr', StringIO()):
                    with patch.object(load_source, '__call__', mock_load_source):
                        with patch.dict('os.environ', environ.copy()):
                            return_value.init()
        return return_value, mock_load_source


# Generated at 2022-06-24 05:01:02.334074
# Unit test for method init of class Settings
def test_Settings_init():
    no_args = lambda: None
    setattr(no_args, 'debug', False)
    setattr(no_args, 'repeat', False)
    setattr(no_args, 'yes', False)
    setattr(no_args, 'no-wait', False)
    settings.update({'user_dir': './', 'require_confirmation': True, 'repeat': False, 'debug': False})
    assert settings.require_confirmation is True
    assert settings.repeat is False
    assert settings.debug is False
    settings.init(no_args)
    assert settings.require_confirmation is True
    assert settings.repeat is False
    assert settings.debug is False
    setattr(no_args, 'yes', True)
    settings.init(no_args)
    assert settings.require_confirmation is False
   

# Generated at 2022-06-24 05:01:05.435197
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    _test_settings = Settings()
    _test_settings.set_key = "set_value"
    assert _test_settings['set_key'] == "set_value"



# Generated at 2022-06-24 05:01:07.886433
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings['name'] = 'test_settings'
    assert settings.name == 'test_settings'
    assert settings['name'] == 'test_settings'

# Generated at 2022-06-24 05:01:12.349589
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    global settings
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.set_me = 'really'
    assert settings.set_me == 'really'

# Generated at 2022-06-24 05:01:13.799057
# Unit test for constructor of class Settings
def test_Settings():
    setting_temp = Settings()
    assert setting_temp.user_dir is None


# Generated at 2022-06-24 05:01:16.291414
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # When use `settings.test = True`
    # Then `settings['test']` is True
    settings.test = True
    assert settings['test'] == True



# Generated at 2022-06-24 05:01:17.076593
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation


# Generated at 2022-06-24 05:01:19.871718
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings.user_dir, type(Path()))
    assert settings.user_dir.is_dir()
    assert settings.user_dir.joinpath('rules').is_dir()

# Generated at 2022-06-24 05:01:21.064518
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert TextSettings()["slow_commands"] == ["lein"]


# Generated at 2022-06-24 05:01:26.727294
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.get('require_confirmation') == True
    assert settings.get('history_limit') == None
    assert settings.get('wait_command') == 0
    assert settings.get('reply') == '{}'
    assert settings.get('alter_history') == True
    assert settings.get('no_colors') == False
    assert settings.get('repeat') == False
    assert settings.get('wait_slow_command') == 3
    assert settings.get('num_close_matches') == 3
    assert settings.get('exclude_rules') == []


# Generated at 2022-06-24 05:01:27.756317
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.require_confirmation is True

# Generated at 2022-06-24 05:01:37.890037
# Unit test for method init of class Settings
def test_Settings_init():
    from unittest.mock import patch
    import builtins

    with patch.object(builtins, 'open', create=True) as mock_open:
        mock_open.return_value.__enter__ = lambda s: s
        mock_open.return_value.__exit__ = lambda s, *args, **kwargs: None
        mock_open.return_value.read.return_value = 'require_confirmation = False'

        with patch.object(Settings, '_settings_from_env') as mock_from_env:
            mock_from_env.return_value = {'require_confirmation': False}

            with patch.object(Settings, '_settings_from_args') as mock_from_args:
                mock_from_args.return_value = {}

                settings.init()

# Generated at 2022-06-24 05:01:41.736245
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    key = 'key'
    value = 'value'
    settings.__setattr__(key, value)
    assert settings.get(key) == value


# Generated at 2022-06-24 05:01:45.489199
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings._getattr__('a') is None


# Generated at 2022-06-24 05:01:47.014929
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    s = Settings()
    s['a'] = 'b'
    assert s.a == 'b'


# Generated at 2022-06-24 05:01:50.257423
# Unit test for constructor of class Settings
def test_Settings():
    actual_settings = Settings()
    actual_settings.init()
    assert actual_settings == settings

# Generated at 2022-06-24 05:01:53.415186
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings({})
    settings.attr = "attr"
    assert settings.attr == 'attr'


# Generated at 2022-06-24 05:01:55.846257
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    s.a = 1
    assert s['a'] == 1
    assert s.a == 1


# Generated at 2022-06-24 05:01:56.599704
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()


# Generated at 2022-06-24 05:02:00.657230
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.require_confirmation
    assert not settings.repeat
    assert settings.rules == const.DEFAULT_RULES
    assert settings.history_limit == 500
    assert settings.wait_command == 3
    assert settings.wait_slow_command == 15

# Generated at 2022-06-24 05:02:09.982387
# Unit test for constructor of class Settings
def test_Settings():
    from pytest import raises
    from .logs import get_logger
    from .temp import Temp

    with Temp() as temp:
        temp.path.joinpath('rule.py').write_text(u'rule = True', 'utf-8')

        settings = Settings({'rules': [temp.path.joinpath('rule.py')]})
        with raises(AttributeError):
            settings.not_existed_var
        assert settings.get('not_existed_var') is None
        assert settings.not_existed_var is None

        settings.init()
        assert get_logger('settings').exception.called
        assert get_logger('settings').exception.call_args_list[0][0][0] == \
            "Can't load settings from file"
        assert get_logger('settings').exception

# Generated at 2022-06-24 05:02:14.444364
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.init()
    assert settings.no_colors == False
    assert settings.no_colors == False
    assert settings.no_colors == False
    assert settings.no_colors == False
    assert settings.num_close_matches == 3
    assert settings.num_close_matches == 3
    assert settings.num_close_matches == 3
    assert settings.num_close_matches == 3

# Generated at 2022-06-24 05:02:17.423598
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings({u'TEST': u'testval'})
    assert settings['TEST'] == u'testval'
    assert settings.TEST == u'testval'

# Generated at 2022-06-24 05:02:20.183346
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings({'key': 'value'})
    assert settings.key == settings['key']
    assert settings.another == settings.get('another')



# Generated at 2022-06-24 05:02:22.020949
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings()
    test_settings.a = 1
    assert test_settings.a == 1

# Generated at 2022-06-24 05:02:25.861305
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    for k, v in const.DEFAULT_SETTINGS.items():
        assert s[k] == v
    assert s.require_confirmation is True
    assert s.repeat is False


# Generated at 2022-06-24 05:02:33.708527
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    with open('test_settings.py', 'w') as f:
        f.write(const.SETTINGS_HEADER)
        f.write('rules = [\'git*\']')
        f.write('priority = {\'git*\': 100}')
        f.write('require_confirmation = False')
        f.write('wait_command = 10')
        f.write('history_limit = 10')
        f.write('wait_slow_command = 10')
        f.write('extra_env = {\'key\': \'value\'}')
        f.write('num_close_matches = 10')
        f.write('require_slow_exit_codes = [143]')
        f.write('exclude_rules = [\'git*\']')

# Generated at 2022-06-24 05:02:37.849986
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']
    settings.new = 'new'
    assert settings['new'] == 'new'

# Generated at 2022-06-24 05:02:40.628865
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings({'key': 'value'})
    assert settings['key'] == 'value'
    assert settings.key == 'value'
    settings.key = 'new_value'
    assert settings['key'] == 'new_value'
    assert settings.key == 'new_value'

# Generated at 2022-06-24 05:02:42.016793
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings()
    settings.test = 'test'
    assert settings.test == 'test'

# Generated at 2022-06-24 05:02:47.001321
# Unit test for constructor of class Settings
def test_Settings():
    test_settings = Settings(test_setting = "test")
    assert test_settings['test_setting'] == "test"
    assert test_settings.test_setting == "test"
    assert test_settings.get('test_setting') == "test"

# Generated at 2022-06-24 05:02:49.159717
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == False
    assert settings.slow_commands == ()


# Generated at 2022-06-24 05:02:58.480966
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    from io import open

    module_name = 'settings'
    setting_name = 'test_setting'
    test_setting_value = 'test_value'

    def get_test_value(func):
        func = getattr(settings, func)
        return func(module_name, setting_name)

    def _create_sys_module(test_value):
        class FakeModule(object):
            '''A fake module to be returned by __import__'''

        sys.modules[module_name] = FakeModule()
        setattr(sys.modules[module_name], setting_name, test_value)


# Generated at 2022-06-24 05:03:02.566778
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['python'] == '/usr/bin/python'
    assert settings['history_limit'] == None
    assert settings['require_confirmation'] == True
    assert settings['no_colors'] == False



# Generated at 2022-06-24 05:03:10.959387
# Unit test for method init of class Settings
def test_Settings_init():
    def _check_settings_dict(settings, d):
        assert settings == d

    settings.init(args=None)
    _check_settings_dict(settings, const.DEFAULT_SETTINGS)

    settings.init(args=type('args', (object, ), {'yes': True}))
    _check_settings_dict(settings, const.DEFAULT_SETTINGS)

    settings.init(args=type('args', (object, ), {'debug': True}))
    _check_settings_dict(settings, const.DEFAULT_SETTINGS)

    settings.init(args=type('args', (object, ), {'repeat': 1}))
    _check_settings_dict(settings, const.DEFAULT_SETTINGS)

# Generated at 2022-06-24 05:03:12.445358
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.var = 1
    assert dict(settings).pop('var') == 1


# Generated at 2022-06-24 05:03:23.132026
# Unit test for method init of class Settings
def test_Settings_init():
    from unittest import mock
    from thefuck import logs

    with mock.patch('thefuck.settings.settings._init_settings_file') as m_init_settings_file, \
            mock.patch('thefuck.settings.settings._settings_from_file') as m_settings_from_file, \
            mock.patch('thefuck.settings.settings._settings_from_env') as m_settings_from_env, \
            mock.patch('thefuck.settings.settings._settings_from_args') as m_settings_from_args, \
            mock.patch('thefuck.settings.settings._setup_user_dir') as m_setup_user_dir:
        settings.init()
        m_init_settings_file.assert_called_once_with()
        m_settings_from_file.assert_called_once_

# Generated at 2022-06-24 05:03:32.205021
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    settings.init()

    # Test user_dir
    user_dir = settings._get_user_dir_path()
    assert settings.user_dir == user_dir

    rules_dir = user_dir.joinpath('rules')
    assert rules_dir.is_dir()

    # Test _settings_from_file
    settings_file = user_dir.joinpath('settings.py')
    with settings_file.open() as f:
        header = f.readline()
        assert header == const.SETTINGS_HEADER

    # Test _settings_from_env
    os.environ['THEFUCK_RULES'] = 'git:svn:find:DEFAULT_RULES'
    assert settings._rules_from_env(os.environ['THEFUCK_RULES'])

# Generated at 2022-06-24 05:03:34.768199
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings['require_confirmation'] == True
    assert settings['repeat'] == False

# Generated at 2022-06-24 05:03:42.666306
# Unit test for method init of class Settings
def test_Settings_init():
    import sys
    import os
    import tempfile

    with tempfile.TemporaryDirectory() as temp_dir:
        user_dir = Path(temp_dir, '.thefuck').expanduser()
        os.mkdir(user_dir)
        user_settings = user_dir.joinpath('settings.py')
        user_settings.write_text('rules = [\'bash\', \'python3\']')
        from_file = {'rules': ['bash', 'python3']}

        env = {key: 'true' for key in const.DEFAULT_SETTINGS}
        env['TF_DEBUG'] = 'true'
        env['TF_REQUIRE_CONFIRMATION'] = 'false'
        env['TF_HISTORY_LIMIT'] = '1'

# Generated at 2022-06-24 05:03:51.920803
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.user_dir == None

    # Test the dict constructor
    d = dict(a=1, b=2, c=3)
    settings = Settings(d)
    assert settings.a == 1 and settings.b == 2 and settings.c == 3

    # Test the keyword constructor
    settings = Settings(a=1, b=2, c=3)
    assert settings.a == 1 and settings.b == 2 and settings.c == 3

    # Test the dict update() method
    settings = Settings(a=1, b=2, c=3)
    d = dict(a=10, b=20, c=30, d=40)
    settings.update(d)
    assert settings.a == 1 and settings.b == 2 and settings.c == 3

# Generated at 2022-06-24 05:03:56.219836
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings(key='value')
    assert settings.key == 'value'



# Generated at 2022-06-24 05:03:58.210647
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_dict = Settings()
    test_dict.foo = 'bar'
    test_dict['foo'] == 'bar'

# Generated at 2022-06-24 05:04:00.988395
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings['foo'] = 'bar'
    assert settings.foo == 'bar'
    assert settings['foo'] == 'bar'


# Generated at 2022-06-24 05:04:08.522757
# Unit test for method init of class Settings
def test_Settings_init():
    # Create temporary directory with settings file
    import tempfile
    import shutil
    import os
    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-24 05:04:09.638706
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert settings.priority['cd_parent'] == 50


# Generated at 2022-06-24 05:04:13.716777
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.__setattr__('test', 'test')
    assert settings['test'] == 'test'

# Generated at 2022-06-24 05:04:16.059282
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings()
    settings.foo = 'bar'
    assert settings.foo == 'bar'

# Generated at 2022-06-24 05:04:25.773910
# Unit test for method init of class Settings
def test_Settings_init():
    # When settings is empty.
    settings.clear()
    settings.init()
    assert settings == const.DEFAULT_SETTINGS
    assert settings.user_dir == settings._get_user_dir_path()
    assert settings.user_dir.joinpath('settings.py').is_file()

    # When settings contains some keys.
    settings.clear()
    for key in const.DEFAULT_SETTINGS:
        settings[key] = '123'
    settings.init()
    for key, value in const.DEFAULT_SETTINGS.items():
        if key in settings:
            assert settings[key] == '123'
        else:
            assert settings[key] == value
    assert settings.user_dir == settings._get_user_dir_path()

# Generated at 2022-06-24 05:04:27.280679
# Unit test for method init of class Settings
def test_Settings_init():
    settings_to_test = Settings(const.DEFAULT_SETTINGS)

    settings_to_test.init()
    assert settings_to_test == const.DEFAULT_SETTINGS

# Generated at 2022-06-24 05:04:30.727729
# Unit test for method init of class Settings
def test_Settings_init():
    print(settings_path)
    print(settings_path.is_file())
    if settings_path.is_file():
        os.remove(settings_path)
    settings.init()
    print(settings_path.is_file())
    pprint.pprint(settings)



# Generated at 2022-06-24 05:04:37.203537
# Unit test for method init of class Settings
def test_Settings_init():
    """Check that init method of class Settings behaves as expected."""
    from .logs import exception
    from .utils import get_closest

    from mock import patch
    from pytest import raises
    from os.path import expanduser
    from shutil import rmtree

    # Args object
    args = lambda: None
    args.yes = False
    args.debug = False
    args.repeat = None

    # Args with debug
    argsDebug = lambda: None
    argsDebug.yes = False
    argsDebug.debug = True
    argsDebug.repeat = None

    # Args with yes
    argsYes = lambda: None
    argsYes.yes = True
    argsYes.debug = False
    argsYes.repeat = None

    # Args with repeat
    argsRepeat = lambda: None
    argsRepeat.yes = False

# Generated at 2022-06-24 05:04:41.172872
# Unit test for constructor of class Settings
def test_Settings():
    import random
    import string
    random_str = lambda: ''.join(random.choice(string.ascii_uppercase) for _ in range(10))
    env_var_list = [random_str() for i in range(50)]
    settings_var_list = [random_str() for i in range(50)]
    settings_var_list.sort(key=lambda x: len(x))
    var_dict = dict(zip(env_var_list, settings_var_list))
    for var in var_dict:
        os.environ[var] = random_str()
    settings.init()
    for key in settings:
        assert settings[key] == const.DEFAULT_SETTINGS[key]

# Generated at 2022-06-24 05:04:43.567895
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.history_limit == 100
    assert settings.require_confirmation



# Generated at 2022-06-24 05:04:48.481244
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # Given that `settings` is a `Settings` object
    assert isinstance(settings, Settings)
    # When I set a key as an attribute
    settings.foo = 'bar'
    # Then key `foo` is setted in `settings`
    assert settings['foo'] == 'bar'



# Generated at 2022-06-24 05:04:49.517866
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['alter_history'] == True
    assert settings['wait_command'] == 1


# Generated at 2022-06-24 05:04:50.091353
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.x == settings['x']

# Generated at 2022-06-24 05:04:51.093776
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = 'test'
    assert settings['test'] == 'test'

# Generated at 2022-06-24 05:04:53.528629
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.init().get('debug') == False
    assert settings.init({'debug': True}).get('debug') == True
    assert settings.init({'debug': True}).get('debug') == True

test_Settings()

# Generated at 2022-06-24 05:04:56.464563
# Unit test for constructor of class Settings
def test_Settings():
    from thefuck import settings

    assert set(settings.keys()) == set(const.DEFAULT_SETTINGS)

    for key in const.DEFAULT_SETTINGS.keys():
        assert settings[key] == const.DEFAULT_SETTINGS[key]



# Generated at 2022-06-24 05:05:02.099766
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.user_dir.endswith('.config/thefuck')
    assert settings.rules == ['git_rebase', 'git_push', 'git_add', 'git_commit',
                              'pip_install', 'sudo', 'apt_install', 'systemctl']

# Generated at 2022-06-24 05:05:04.610722
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    obj = Settings()
    obj.test = 'test'
    assert obj.test == 'test'
    obj['test'] = 'test'
    assert obj['test'] == 'test'

# Generated at 2022-06-24 05:05:08.574158
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    """Test for settings.py
    Test method __getattr__ of class Settings.
    """

    settings.fuck = "Hello, Fuck You!"
    assert settings.fuck == 'Hello, Fuck You!', \
        "method __getattr__ of class Settings doesn't work"

# Generated at 2022-06-24 05:05:11.215935
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    global settings

    obj = Settings()
    obj.name = 'xiaoming'
    assert obj['name'] == 'xiaoming'

    settings.name = 'xiaohong'
    assert settings.name == 'xiaohong'

# Generated at 2022-06-24 05:05:13.360983
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    new_settings = Settings({"foo": "bar"})
    assert new_settings.foo == "bar"


# Generated at 2022-06-24 05:05:14.949610
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = "Changed"
    assert settings["test"] == "Changed"


# Generated at 2022-06-24 05:05:19.186420
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class Test(object):
        def __init__(self):
            self.settings = Settings()

        def test_setattr(self):
            self.settings.key = 'test'

        def test_getattr(self):
            self.assertTrue(self.settings.key == 'test')

    import unittest
    unittest.main(module='__main__', exit=False)

# Generated at 2022-06-24 05:05:21.135019
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.__setattr__("a", "b")
    assert "b" == settings.__getattr__("a")



# Generated at 2022-06-24 05:05:22.890778
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings['a'] = 10
    print(settings['a'])
    print(settings.a)
    assert settings['a'] == settings.a

# Generated at 2022-06-24 05:05:24.720278
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    s = Settings()
    s['key'] = 'value'
    assert s.key == 'value'



# Generated at 2022-06-24 05:05:36.268253
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert isinstance(settings, object)

    assert settings.__getitem__('require_confirmation') == True
    assert settings.__getitem__('history_limit') == None
    assert settings.__getitem__('wait_command') == 15
    assert settings.__getitem__('wait_slow_command') == 3
    assert settings.__getitem__('alter_history') == False
    assert settings.__getitem__('priority') == {}
    assert settings.__getitem__('rules') == const.DEFAULT_RULES
    assert settings.__getitem__('exclude_rules') == []
    assert settings.__getitem__('no_colors') == False
    assert settings.__getitem__('instant_mode') == False
    assert settings.__

# Generated at 2022-06-24 05:05:39.131559
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.testkey = 'testval'
    assert settings['testkey'] == 'testval'



# Generated at 2022-06-24 05:05:44.716747
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert 'rules' in settings
    assert 'exclude_rules' in settings
    assert 'wait_command' in settings
    assert 'require_confirmation' in settings
    assert 'slow_commands' in settings
    assert 'alter_history' in settings
    assert 'no_colors' in settings
    assert 'exclude_search_path_prefixes' in settings
    assert 'history_limit' in settings
    assert 'instant_mode' in settings
    assert 'wait_slow_command' in settings

# Generated at 2022-06-24 05:05:52.584656
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings({})
    settings._get_user_dir_path = lambda: Path('/test/')
    settings._settings_from_env = lambda: {'rules': 'rules'}
    settings._settings_from_args = lambda args: {'debug': True}
    settings._settings_from_file = lambda: {'require_confirmation': False, 'no_colors': True}
    settings.init()
    assert settings['debug']
    assert settings['rules'] == 'rules'
    assert settings['require_confirmation']
    assert settings['no_colors']

# Generated at 2022-06-24 05:05:55.370723
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings['key'] = 'value'
    assert settings.key == 'value'



# Generated at 2022-06-24 05:05:57.544692
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert( settings.settings_path == "settings.py" )

# Generated at 2022-06-24 05:06:03.070937
# Unit test for method init of class Settings
def test_Settings_init():
    """Unit test for method init of class Settings

    Tests data:
        _settings_from_file:
        1. settings.py doesn't exist
        2. settings.py exists, but has errors
        3. settings.py exists, but some settings aren't listed there
        4. settings.py exists and valid

        _settings_from_env:
        1. No environment variables are set
        2. All environment variables are set to invalid values
        3. All environment variables are set to valid values

        _settings_from_args:
        1. No arguments are passed
        2. --yes flag is set
        3. --debug is set
        4. --repeat is set
    """
    import os
    from argparse import ArgumentParser
    from mock import patch, mock_open, Mock
    from textwrap import dedent
    from shutil import rmt

# Generated at 2022-06-24 05:06:04.066935
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.foo = 'bar'
    assert settings.foo == 'bar'


# Generated at 2022-06-24 05:06:07.221681
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings()
    assert settings.nonexistent is None
    assert settings['nonexistent'] is None
    settings.foo = 'bar'
    assert settings.foo == 'bar'
    assert settings['foo'] == 'bar'


# Generated at 2022-06-24 05:06:09.008341
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.no_colors == const.DEFAULT_SETTINGS['no_colors']


# Generated at 2022-06-24 05:06:14.090327
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    global settings
    settings = Settings({'string':'string object','int':123,'float':1.23})
    assert settings.__getattr__('string') == 'string object'
    assert settings.__getattr__('int') == 123
    assert settings.__getattr__('float') == 1.23


# Generated at 2022-06-24 05:06:15.738528
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()

# Generated at 2022-06-24 05:06:22.730651
# Unit test for method init of class Settings
def test_Settings_init():
    def _test_settings_from_file():
        # For testing we use `linecache` to read lines from string-file
        # to make it working we need to write file to disk
        settings_path = settings.user_dir.joinpath('settings.py')
        assert settings_path.is_file()
        settings_path.write_text("foo = 'bar'")
        assert settings.init() == {'foo': 'bar'}
        assert settings.foo == 'bar'

# Generated at 2022-06-24 05:06:24.796502
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.user_dir == settings._get_user_dir_path()
    assert settings.alter_history == False

# Generated at 2022-06-24 05:06:28.696035
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['wait_command'] == 0.3


# Generated at 2022-06-24 05:06:37.877855
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception, reset_log

    def _test_settings_from_env(value, expected, attr):
        reset_log()
        os.environ['thefuck_{}'.format(attr)] = value
        settings.init()
        assert settings.get(attr) == expected
        assert len(exception.log) == 0, 'Unexpected exception'

    _test_settings_from_env('', const.DEFAULT_SETTINGS['rules'], 'rules')
    _test_settings_from_env('DEFAULT_RULES', const.DEFAULT_SETTINGS['rules'],
                            'rules')
    _test_settings_from_env(':', const.DEFAULT_SETTINGS['rules'], 'rules')

# Generated at 2022-06-24 05:06:39.741465
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings({'a': 1})
    assert s.a == 1
    assert s['a'] == 1
    assert s.b == None



# Generated at 2022-06-24 05:06:47.727108
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.require_confirmation == True
    assert settings.repeat == True
    assert settings.wait_command == 0
    assert settings.no_colors == False
    assert settings.alter_history == False
    assert settings.wait_slow_command == 15
    assert settings.instant_mode == False
    assert settings.history_limit == None
    assert settings.debug == False
    assert settings.exclude_rules == []
    assert settings.rules ==['fuck', 'git_fuck', 'man', 'apt_get', 'brew', 'brew_cask', 'composer', 'docker', 'emacs', 'gem', 'gulp', 'javac', 'lein', 'npm', 'pip', 'puppet', 'python', 'rbenv', 'rvm', 'stack', 'vagrant', 'yarn']
    assert settings

# Generated at 2022-06-24 05:06:58.453570
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from unittest.mock import patch, Mock
    from thefuck.settings import Settings
    from thefuck.system import Path
    from thefuck import const

    args = Mock()
    _settings_from_file = Mock()
    _settings_from_env = Mock()
    _settings_from_args = Mock()


# Generated at 2022-06-24 05:07:03.187318
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    setting = Settings(const.DEFAULT_SETTINGS)
    assert setting.__setattr__('key', 'value') == None
    assert setting.get('key') == 'value'


# Generated at 2022-06-24 05:07:07.643139
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    for key in const.DEFAULT_SETTINGS.keys():
        assert(settings[key] == const.DEFAULT_SETTINGS[key])


# Generated at 2022-06-24 05:07:11.131161
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    """Unit test for method __getattr__ of class Settings"""
    assert settings.require_confirmation == True


# Generated at 2022-06-24 05:07:15.210156
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    s = Settings()
    assert(s.user_dir is None)
    assert(s.rules is None)
    s.rules = ['ls', 'cd']
    assert(s.rules == ['ls', 'cd'])


# Generated at 2022-06-24 05:07:24.863404
# Unit test for method init of class Settings
def test_Settings_init():
    # Change default settings
    const.DEFAULT_SETTINGS['require_confirmation'] = True
    const.DEFAULT_SETTINGS['alter_history'] = False

    # Set up environment
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'False'
    os.environ['THEFUCK_ALTER_HISTORY'] = 'True'

    # Set up arguments
    from . import shell

    args = shell.FuckArguments(yes=True, repeat=True, debug=True)

    # Set up user dir
    user_dir = Path(__file__).abspath().dirname()

    settings = Settings(const.DEFAULT_SETTINGS)

    # First initialization
    settings.init(args)
    assert settings['require_confirmation'] == False
    assert settings['alter_history']

# Generated at 2022-06-24 05:07:34.970808
# Unit test for method init of class Settings
def test_Settings_init():
    backup = dict(sys.modules)
    sys.modules['thefuck.logs'] = __import__('thefuck.logs')
    # mocks
    sys.modules['thefuck.const'] = __import__('mock')
    sys.modules['thefuck.logs'].exception = lambda s, e: None
    sys.modules['mock'].const = __import__('mock')
    sys.modules['mock'].const.DEFAULT_SETTINGS = {'key': 'value'}
    sys.modules['mock'].const.ENV_TO_ATTR = {'env': 'key'}
    sys.modules['mock'].const.SETTINGS_HEADER = 'header#'
    # end mocks

    # mocks
    sys.modules['thefuck.system'] = __

# Generated at 2022-06-24 05:07:37.471510
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings['require_confirmation'] is True


# Generated at 2022-06-24 05:07:41.816903
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    import pytest
    test_dict = {'foo': 'bar'}
    x = Settings(test_dict)
    assert x.foo == 'bar'
    with pytest.raises(AttributeError):
        x.baz


# Generated at 2022-06-24 05:07:52.983548
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.init()
    print('settings.require_confirmation = ' + str(settings.require_confirmation))
    print('settings.repeat = ' + str(settings.repeat))
    print('settings.no_colors = ' + str(settings.no_colors))
    print('settings.slow_commands = ' + str(settings.slow_commands))
    print('settings.exclude_rules = ' + str(settings.exclude_rules))
    print('settings.excluded_search_path_prefixes = ' + str(settings.excluded_search_path_prefixes))
    print('settings.wait_slow_command = ' + str(settings.wait_slow_command))
    print('settings.wait_command = ' + str(settings.wait_command))

# Generated at 2022-06-24 05:08:03.333317
# Unit test for method init of class Settings
def test_Settings_init():
    from .system import get_aliases

    settings.clear()
    settings.init(args=None)

    assert settings.priority == {rule.name: idx for idx, rule in enumerate([])}
    assert settings.rules == []
    assert settings.no_colors is False
    assert settings.require_confirmation is True
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.exclude_rules == []
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'gradle']
    assert settings.num_close_matches == 3
    assert settings.alter_history is True
    assert settings.instant_mode is False
    assert settings.excluded_search_path_prefixes == []

# Generated at 2022-06-24 05:08:06.198500
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.__setattr__('size', 12) == settings.update({'size': 12})

# Generated at 2022-06-24 05:08:10.613526
# Unit test for constructor of class Settings
def test_Settings():
    knownvalues = dict(const.DEFAULT_SETTINGS)
    knownvalues.update(const.ENV_TO_ATTR)
    settings = Settings(knownvalues)
    assert settings == knownvalues

# Generated at 2022-06-24 05:08:12.216130
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings_ = Settings(const.DEFAULT_SETTINGS)
    settings_.test = 1
    assert settings_['test'] == 1

# Generated at 2022-06-24 05:08:14.382461
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings()
    test_settings.test_key = 1
    assert test_settings.get('test_key') == 1


# Generated at 2022-06-24 05:08:16.625747
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.__setattr__('name', 'kc')
    assert settings['name'] == 'kc'



# Generated at 2022-06-24 05:08:24.824695
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    import sys

    from mock import mock_open, patch
    from thefuck.settings import const, Settings
    from thefuck.settings import _init_settings_file, _setup_user_dir, \
                                 _settings_from_args, _settings_from_env, \
                                 _settings_from_file, _get_user_dir_path

    # Test case init()

# Generated at 2022-06-24 05:08:26.528429
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.test_attr = 'value'
    assert settings.test_attr == 'value'



# Generated at 2022-06-24 05:08:29.887813
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules == const.DEFAULT_RULES
    assert settings._not_exist is None


# Generated at 2022-06-24 05:08:36.540214
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.var = 'abc'
    assert settings.var == 'abc'
    assert settings.get('var') == 'abc'
    assert settings.var == settings['var']
    assert settings.non_existent_attribute == None
    assert settings.non_existent_attribute == settings.get('non_existent_attribute')
    assert not hasattr(settings, 'non_existent_attribute')


# Generated at 2022-06-24 05:08:38.544160
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test_attr = 'test_attr'
    assert settings['test_attr'] == 'test_attr'


# Generated at 2022-06-24 05:08:42.061139
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('require_confirmation') == True
    assert settings.get('slow_commands') == []
    assert settings.get('excluded_search_path_prefixes') == []
    assert settings.get('history_limit') == 0
    assert settings.get('wait_command') == 0
    assert settings.get('repeat') == False
    assert settings.get('alter_history') == True
    assert settings.get('num_close_matches') == 3

test_Settings()

# Generated at 2022-06-24 05:08:46.434636
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation
    assert not settings.wait_slow_command
    assert settings.history_limit == 0
    assert settings.priority == {}

# Generated at 2022-06-24 05:08:48.796107
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    s = Settings()
    s.update({'test': 'success'})
    assert s.test == s['test']



# Generated at 2022-06-24 05:08:57.908476
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile

    tmp_dir = tempfile.mkdtemp()
    tmp_user_dir = Path(tmp_dir).joinpath('user_dir')
    tmp_settings = tmp_user_dir.joinpath('settings.py')
    tmp_settings.parent.mkdir()

    with tmp_settings.open(mode='w') as tmp_settings_file:
        tmp_settings_file.write('require_confirmation = False')

    os.environ['TF_DEBUG'] = 'True'
    os.environ['TF_HISTORY_LIMIT'] = '3'
    os.environ['TF_RULES'] = 'DEFAULT_RULES:TestRule:'
    os.environ['TF_PRIORITY'] = 'DEFAULT_RULES=2:TestRule=1'
    os.en

# Generated at 2022-06-24 05:09:00.123821
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == True
    assert settings.something_not_exists == None

# Generated at 2022-06-24 05:09:02.185578
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings.wait_command, int)
    assert isinstance(settings.priority, dict)
    assert isinstance(settings.rules, list)

# Generated at 2022-06-24 05:09:09.337869
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.__getattr__('priority') == const.DEFAULT_SETTINGS['priority']
    assert settings.get('priority') == const.DEFAULT_SETTINGS['priority']
    settings.__setattr__('priority', 4)
    assert settings.priority == 4
    assert settings.get('priority') == 4

# Generated at 2022-06-24 05:09:10.852008
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']


# Generated at 2022-06-24 05:09:21.185516
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

#
# # tests for method _init_settings_file of class Settings
# def test_Settings__init_settings_file():
#     settings._init_settings_file()
#
# # tests for method _setup_user_dir of class Settings
# def test__setup_user_dir():
#     settings._setup_user_dir()
#
# # tests for method _settings_from_file of class Settings
# def test__settings_from_file():
#     settings._settings_from_file()
#
# # tests for method _rules_from_env of class Settings
# def test__rules_from_env():
#     settings._rules_from_env()
#
# # tests for method _priority_from_env of class Settings
# def test__priority_from_env():
#     settings._priority_

# Generated at 2022-06-24 05:09:22.661197
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation



# Generated at 2022-06-24 05:09:23.339247
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules == const.DEFAULT_SETTINGS['rules']


# Generated at 2022-06-24 05:09:24.135543
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    setattr(settings, 'rules', [])
    assert settings['rules'] == []

# Generated at 2022-06-24 05:09:26.148567
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['slow_commands'] == const.DEFAULT_SETTINGS['slow_commands']
    assert settings['require_confirmation'] == const.DEFAULT_SETTINGS['require_confirmation']


# Generated at 2022-06-24 05:09:35.105148
# Unit test for constructor of class Settings
def test_Settings():
    assert settings == const.DEFAULT_SETTINGS

    assert settings.require_confirmation == True
    assert settings.wait_command == 10
    assert settings.history_limit == None
    assert settings.rules == ()
    assert settings.exclude_rules == ()
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.num_close_matches == 3
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.priority == {}
    assert settings.excluded_search_path_prefixes == ()
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.repeat == False
    assert settings.user_dir

# Generated at 2022-06-24 05:09:40.111468
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    global settings
    settings = Settings({"exist_key": "exist_value"})
    assert settings.exist_key == 'exist_value'

    # test that not exist key will raise AttributeError exception
    try:
        settings.not_exist_key == 'exist_value'
    except AttributeError:
        return True
    else:
        return False


# Generated at 2022-06-24 05:09:47.328639
# Unit test for method init of class Settings
def test_Settings_init():
    import pytest
    from subprocess import Popen, PIPE
    from .logs import set_logger

    # test if _settings_from_file() works correctly
    set_logger(None)
    process = Popen(['thefuck', '--alias', 'fuck', 'pwd'],
                    stdout=PIPE, stderr=PIPE, env=os.environ)
    output, errput = process.communicate()
    assert errput == ''
    assert process.returncode == 0
    assert settings.alter_history == False
    assert settings.require_confirmation == True
    assert 'fuck' in settings.aliases

    # test if _settings_from_env() works correctly
    set_logger(None)
    env = dict(os.environ)

# Generated at 2022-06-24 05:09:48.420476
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.fake_name = 'Fake Value'
    assert settings['fake_name'] == 'Fake Value'

# Generated at 2022-06-24 05:09:58.560438
# Unit test for method init of class Settings
def test_Settings_init():
    """
    Checks that constructor:
    1. creates config directory and settings.py if they don't exist
    2. loads config from settings.py
    3. loads config from env
    4. loads config from args
    5. updates default config with loaded config
    """

    import tempfile

    # create temporary config directory and config file
    test_dir = tempfile.TemporaryDirectory().name
    user_dir = Path(test_dir, 'thefuck')
    settings_file = user_dir.joinpath('settings.py')
    user_dir.mkdir()
    with settings_file.open(mode='w') as settings_file_handler:
        settings_file_handler.write(const.SETTINGS_HEADER)