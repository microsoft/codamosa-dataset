

# Generated at 2022-06-12 10:01:06.756468
# Unit test for method init of class Settings
def test_Settings_init():
    """
    @type args: None
    @rtype: None
    """

    def open(path, mode):
        return StringIO()

    settings.init()
    assert settings.user_dir.joinpath(
        'settings.py').is_file()

    path = settings.user_dir.joinpath('settings.py')
    with patch('six.moves.builtins.open', open):
        with patch('os.environ', {}):
            settings.init()
    with open(text_type(path)) as settings_file:
        assert settings_file.read() == const.SETTINGS_HEADER

    patched_load_source = patch('thefuck.conf.load_source')
    with patched_load_source:
        settings.init()

# Generated at 2022-06-12 10:01:17.389001
# Unit test for method init of class Settings
def test_Settings_init():
    import mock
    import sys
    
    a = mock.Mock()
    a.yes = True
    a.debug = True
    a.repeat = True
    with mock.patch.object(const, 'ENV_TO_ATTR') as c_mock:
        with mock.patch.object(sys, 'exc_info') as s_mock:
            with mock.patch.object(os, 'environ') as o_mock:
                o_mock.get.return_value = '~/.config'
                o_mock.__contains__.return_value = True
                s_mock.return_value = '123'
                c_mock.items.return_value = [('ENV1', 'ATTR1'), ('ENV2', 'ATTR2')]

# Generated at 2022-06-12 10:01:26.196069
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings == const.DEFAULT_SETTINGS
    assert settings.user_dir == Path('~/.thefuck').expanduser()

    os.environ['THEFUCK_NO_COLOR'] = 'TRUE'
    os.environ['THEFUCK_RULES'] = ':another_rules:OLD_env_rule:'
    os.environ['THEFUCK_RULES_EXCLUDE'] = 'OLD_env_excluded_rule'
    os.environ['THEFUCK_PRIORITY'] = 'tf:7:another_rule:10:OLD_env_rule:0'
    os.environ['THEFUCK_SETTINGS'] = '/path/to/settings'

# Generated at 2022-06-12 10:01:37.809001
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['exclude_rules'] == const.DEFAULT_EXCLUDE_RULES
    assert settings['priority'] == const.DEFAULT_PRIORITY
    assert settings['wait_command'] == const.DEFAULT_WAIT_COMMAND
    assert settings['history_limit'] == const.DEFAULT_HISTORY_LIMIT
    assert settings['slow_commands'] == const.DEFAULT_SLOW_COMMANDS
    assert settings['wait_slow_command'] == const.DEFAULT_WAIT_SLOW_COMMAND
    assert settings['excluded_search_path_prefixes'] == const.DEFAULT_EXCLUDED_SEARCH_PATH_PREFIXES
    assert settings['require_confirmation'] == const.DE

# Generated at 2022-06-12 10:01:47.656016
# Unit test for method init of class Settings
def test_Settings_init():
    shell_history = ['echo hello', 'echo test', 'echo fuck']
    settings.init()
    assert settings.require_confirmation
    assert isinstance(settings.rules, list)
    assert isinstance(settings.rules[0].match, list)
    assert settings.rules[0].match[0] == 'echo hello && echo test'
    assert settings.rules[0].get_new_command('echo hello', shell_history) == 'echo test'
    assert isinstance(settings.exclude_rules, list)
    assert isinstance(settings.exclude_rules[0].match, list)
    assert settings.exclude_rules[0].match[0] == 'echo hello && echo hello'
    assert settings.exclude_rules[0].get_new_command('echo hello 3', shell_history) == 'echo hello 3'


# Generated at 2022-06-12 10:01:55.526362
# Unit test for method init of class Settings
def test_Settings_init():
    import unittest
    import tempfile
    import shutil

    class SettingsInitTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_when_settings_file_does_not_exist_create_it(self):
            settings.init()

            settings_file_path = settings.user_dir.joinpath('settings.py')
            self.assertTrue(settings_file_path.is_file())

        def test_if_settings_file_exists_do_not_overwrite_it(self):
            settings_file_path = settings.user_dir.joinpath('settings.py')

# Generated at 2022-06-12 10:01:56.811220
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.key == 'value'



# Generated at 2022-06-12 10:02:06.121209
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import log_to_stderr, log_to_file, log_to_syslog, log_to_journal
    from .main import get_default_settings
    from .utils import wrap_streams
    from .system import is_mac, is_windows
    from .utils import wrap_streams
    from .const import ENABLE_JOURNAL
    from thefuck.utils import wrap_streams
    from thefuck.system import is_mac, is_windows
    from thefuck.const import ENABLE_JOURNAL
    from thefuck import const
    from thefuck import logs
    from thefuck import main
    from thefuck import system
    from thefuck import utils
    import thefuck.const
    import thefuck.logs
    import thefuck.main
    import thefuck.system


# Generated at 2022-06-12 10:02:09.012031
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import check_log_contains

    check_log_contains(u'DeprecationWarning')
    check_log_contains(u'Config path ~/.thefuck is deprecated')

# Generated at 2022-06-12 10:02:18.116058
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import LOGS_DIR

    settings_path = Path(__file__).parent.joinpath('settings.py')
    settings_path_init = Path(__file__).parent.joinpath('settings_init.py')

# Generated at 2022-06-12 10:02:43.820552
# Unit test for method init of class Settings
def test_Settings_init():
    # init from file
    settings.update({'require_confirmation': False,
                     'alter_history': False,
                     'wait_command': 10,
                     'wait_slow_command': 0,
                     'exclude_rules': ['git'],
                     'rules': []})
    settings.init()
    assert settings.require_confirmation
    assert settings.alter_history
    assert settings.wait_command == 5
    assert settings.wait_slow_command == 15
    assert settings.exclude_rules == ['git', 'fuck']
    assert settings.rules != []

    # init from env

# Generated at 2022-06-12 10:02:47.641138
# Unit test for method init of class Settings
def test_Settings_init():
    """When none of the settings is given in env,
    then default settings should be loaded."""

    # Arrange
    settings.Clear()
    env_vars = os.environ.keys()
    for key in env_vars:
        del os.environ[key]

    # Act
    settings.init()

    # Assert
    assert settings == const.DEFAULT_SETTINGS



# Generated at 2022-06-12 10:02:54.241675
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import clear_exceptions
    from .tests.utils import replace_object
    from .system import create_file
    from .utils import create_executable_script
    import contextlib
    import os
    from six import StringIO
    from .logs import exception

    old_exception = exception
    old_load_source = load_source
    old_user_dir = settings.user_dir
    clear_exceptions()

# Generated at 2022-06-12 10:03:03.778035
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch

    with patch.multiple(const, __package__=False,
                        DEFAULT_SETTINGS={'first_attr': 'default',
                                          'second_attr': 'default',
                                          'third_attr': 'default'},
                        ENV_TO_ATTR={'env_first_attr': 'first_attr',
                                     'env_second_attr': 'second_attr',
                                     'env_third_attr': 'third_attr'}):
        settings = Settings()


# Generated at 2022-06-12 10:03:04.760944
# Unit test for method init of class Settings
def test_Settings_init():
    s = Settings(const.DEFAULT_SETTINGS)
    s.init()
    assert s.user_dir != ""

# Generated at 2022-06-12 10:03:09.629578
# Unit test for method init of class Settings
def test_Settings_init():
    _settings = Settings(const.DEFAULT_SETTINGS)
    _settings._get_user_dir_path = lambda: Path('/', 'tmp', '.thefuck')
    _settings.init()

    assert _settings.get('wait_command') == 3
    assert _settings.get('exclude_rules') == []



# Generated at 2022-06-12 10:03:19.713964
# Unit test for method init of class Settings
def test_Settings_init():
    # Settings.init([])
    from .logs import _logger, logger_loaded
    if not logger_loaded:
        _logger()

    settings.init()
    assert settings['dir_name'] == 'rules.d'
    assert settings['exclude_rules'] == ['*']
    assert settings['wait_command'] == 3
    assert settings['history_limit'] == 10
    assert settings['require_confirmation'] == True
    assert settings['no_colors'] == False
    assert settings['debug'] == False
    assert settings['alter_history'] == True
    assert settings['wait_slow_command'] == 9
    assert settings['num_close_matches'] == 5
    assert settings['instant_mode'] == False
    assert settings['repeat'] is None
    assert settings['slow_commands'] == []

# Generated at 2022-06-12 10:03:28.826094
# Unit test for method init of class Settings
def test_Settings_init():
    # method init will overwrite the dict with values from settings.py and
    # environment variables
    const.DEFAULT_SETTINGS["wait_command"]=1
    const.DEFAULT_SETTINGS["require_confirmation"]=True
    const.DEFAULT_SETTINGS["priority"]={}
    const.DEFAULT_SETTINGS["exclude_rules"]=[""]
    const.DEFAULT_SETTINGS["excluded_search_path_prefixes"]=[""]
    const.DEFAULT_SETTINGS["history_limit"]=1
    const.DEFAULT_SETTINGS["rules"]=[""]
    const.DEFAULT_SETTINGS["no_colors"]=False
    const.DEFAULT_SETTINGS["slow_commands"]=[""]

# Generated at 2022-06-12 10:03:32.204496
# Unit test for method init of class Settings
def test_Settings_init():
    args = type('Args', (), {})()
    args.yes = True
    args.debug = True
    args.repeat = 2

    settings.init(args=args)

    assert settings.repeat == 2
    assert settings.require_confirmation == False
    assert settings.debug == True


# Generated at 2022-06-12 10:03:39.996839
# Unit test for method init of class Settings
def test_Settings_init():
    settings.update(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir == Path(os.environ['XDG_CONFIG_HOME']).joinpath('thefuck')
    assert settings.require_confirmation == True
    assert settings.exclude_rules == []
    assert settings.alternative_executables == {}
    assert settings.python_bin == 'python'
    assert settings.wait_command == 2
    assert settings.require_confirmation == True
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew']
    assert settings.no_colors == False
    assert settings.priority == {}
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.excluded_search_path

# Generated at 2022-06-12 10:04:33.756544
# Unit test for method init of class Settings
def test_Settings_init():
    from tests.utils import assert_equal, assert_true, assert_false, assert_in

    settings.init()

    settings_file_path = settings.user_dir.joinpath('settings.py')
    assert_true(settings_file_path.is_file())

    with settings_file_path.open('r') as opened_file:
        assert_equal(const.SETTINGS_HEADER, opened_file.read())

    assert_equal('', settings.sudo_command)
    assert_equal(
        'fuck', settings.alias if settings.alias else 'thefuck')
    assert_equal(2, settings.history_limit)
    assert_equal(3, settings.wait_command)
    assert_equal(15, settings.wait_slow_command)
    assert_equal(True, settings.require_confirmation)


# Generated at 2022-06-12 10:04:43.558671
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import enable_debug
    from .utils import get_all_executables, wrap_settings

    def check_settings(settings):
        initial_settings = {attr: getattr(settings, attr)
                            for attr in const.DEFAULT_SETTINGS.keys()}
        assert initial_settings == {}

    def check_env_settings(settings):
        for env, attr in const.ENV_TO_ATTR.items():
            if env in os.environ:
                assert getattr(settings, attr) == os.environ.get(env)

    def check_file_settings(settings):
        for attr in const.DEFAULT_SETTINGS.keys():
            if attr in dir(settings._settings_from_file()):
                assert getattr(settings, attr) == get

# Generated at 2022-06-12 10:04:51.681849
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    import shutil

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create a real settings file in temporary directory
    user_dir = Path(temp_dir, 'thefuck')
    user_dir.mkdir()
    settings_dest = user_dir.joinpath('settings.py')
    settings_dest.write_text(const.SETTINGS_HEADER)
    for setting in const.DEFAULT_SETTINGS.items():
        settings_dest.write_text(u'# {} = {}\n'.format(*setting))

    # Create fake environment variables
    os.environ['THEFUCK_DEBUG'] = 'True'
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'False'

# Generated at 2022-06-12 10:04:53.377559
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

    return settings.user_dir.is_dir() and settings.user_dir.joinpath('settings.py').is_file()

# Generated at 2022-06-12 10:05:02.732829
# Unit test for method init of class Settings
def test_Settings_init():
    # settings should contain all settings from file
    # when execution is okay
    settings.init()
    settings.update(**const.DEFAULT_SETTINGS)
    settings.update({'user_dir': settings._get_user_dir_path()})
    settings.user_dir.joinpath("settings.py").write_text("")
    assert settings['user_dir'] == settings._get_user_dir_path()
    assert settings['rules'] == settings._rules_from_env("DEFAULT_RULES")
    assert settings['priority'] == dict(settings._priority_from_env(""))
    settings.user_dir.joinpath("settings.py").write_text("a = 1")
    assert settings['a'] == 1
    assert settings['slow_commands'] == []
    assert settings['exclude_rules'] == []


# Generated at 2022-06-12 10:05:09.910531
# Unit test for method init of class Settings
def test_Settings_init():
    from .system import create_spy, create_stub

    settings_from_file = create_spy(lambda: {'require_confirmation': False})
    settings_from_env = create_spy(lambda: {'require_confirmation': True})
    settings_from_args = create_spy(lambda _: {})
    user_dir = create_stub(Path)
    user_dir.joinpath.return_value = 'thefuck/settings.py'
    _init_settings_file = create_spy()
    _setup_user_dir = create_spy(lambda: user_dir)

    class Settings_(Settings):
        _init_settings_file = _init_settings_file
        _setup_user_dir = _setup_user_dir
        _settings_from_file = settings_from_file

# Generated at 2022-06-12 10:05:10.972102
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.rules != []

# Generated at 2022-06-12 10:05:11.923185
# Unit test for method init of class Settings
def test_Settings_init():
        settings.init()
        assert settings.user_dir

# Generated at 2022-06-12 10:05:21.803517
# Unit test for method init of class Settings
def test_Settings_init():
    # Case 1: Settings correctly init
    # Given
    def _init_settings_file():
        settings_path = settings.user_dir.joinpath('settings.py')
        with settings_path.open(mode='w') as settings_file:
            settings_file.write('')
    settings._init_settings_file = _init_settings_file

    def _settings_from_file():
        settings = load_source('settings', settings.user_dir.joinpath('settings.py'))
        return {key: getattr(settings, key) for key in settings.keys() if hasattr(settings, key)}
    settings._settings_from_file = _settings_from_file


# Generated at 2022-06-12 10:05:28.250352
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert(settings.get('require_confirmation'))
    assert(settings.get('wait_command') == 3)
    assert(settings.get('wait_slow_command') == 3)
    assert(settings.get('history_limit') == 10)
    assert(settings.get('alter_history') is True)
    assert(settings.get('exclude_rules') == [])
    assert(settings.get('no_colors') is False)
    assert(settings.get('prioirty') == {})
    assert(settings.get('slow_commands') == [])

# Generated at 2022-06-12 10:07:07.197251
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.init() is None # pylint: disable=E1101
    assert settings.init(['--yes']) is None # pylint: disable=E1101


# Generated at 2022-06-12 10:07:15.446649
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .__main__ import get_settings_from_args
    import imp
    import sys

    settings = Settings(const.DEFAULT_SETTINGS)
    fake_Settings = type(
        'fake_Settings',
        (Settings,),
        {'_setup_user_dir': lambda self: None,
         '_settings_from_file': lambda self: None})
    fake_Settings.update(const.DEFAULT_SETTINGS)

    settings = fake_Settings(const.DEFAULT_SETTINGS)
    settings.init('args')
    assert settings.require_confirmation == False
    assert settings.debug == True
    assert settings.repeat == 0

    settings = fake_Settings(const.DEFAULT_SETTINGS)

# Generated at 2022-06-12 10:07:16.499769
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    settings.init()


# Generated at 2022-06-12 10:07:18.252225
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

    assert settings.user_dir is not None

    assert settings.rules is not None

    assert settings.priority is not None

# Generated at 2022-06-12 10:07:22.825146
# Unit test for method init of class Settings
def test_Settings_init():
    if not hasattr(settings, 'init'):
        return 'No init() method defined'
    settings.init({
        'yes': True,
        'debug': True,
        'repeat': 1
    })
    if settings.get('require_confirmation') != False:
        return "require_confirmation != False"
    if settings.get('debug') != True:
        return "debug != True"
    if settings.get('repeat') != 1:
        return "repeat != 1"


# Generated at 2022-06-12 10:07:28.848949
# Unit test for method init of class Settings
def test_Settings_init():
    import pytest
    settings._settings_from_file = lambda: {'DEBUG': True, 'TIMEOUT': 5}
    settings._settings_from_env = lambda: {'NO_COLORS': True}
    settings._settings_from_args = lambda args: {'REQUIRE_CONFIRMATION': False}
    settings.init()
    assert settings['DEBUG'] == True
    assert settings['TIMEOUT'] == 5
    assert settings['NO_COLORS'] == True
    assert settings['REQUIRE_CONFIRMATION'] == False

# Generated at 2022-06-12 10:07:37.951213
# Unit test for method init of class Settings
def test_Settings_init():
    # Test setup_user_dir
    import tempfile
    old_user_dir = settings.user_dir
    settings.user_dir = tempfile.mkdtemp(prefix="thefuck_test_")
    from shutil import rmtree
    try:
        rules_dir = Path(settings.user_dir).joinpath('rules')
        assert not rules_dir.is_dir()
        settings.init()
        assert rules_dir.is_dir()
    finally:
        rmtree(settings.user_dir)
        settings.user_dir = old_user_dir
    # Test _init_settings_file
    settings.user_dir = tempfile.mkdtemp(prefix="thefuck_test_")

# Generated at 2022-06-12 10:07:44.761093
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import sys

    class Args(object):
        pass

    args = Args()
    args.yes = True
    args.debug = False
    args.repeat = 10

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init(args)

    sys.stdout.write(str(settings) + "\n")
    assert settings.require_confirmation == False
    assert settings.debug == False
    assert settings.repeat == 10

if __name__ == '__main__':
    test_Settings_init()

# Generated at 2022-06-12 10:07:47.238726
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import log_to_stderr
    from .system import get_aliases, get_history, get_shell

    log_to_stderr()
    settings.init(args=None)

# Generated at 2022-06-12 10:07:50.873051
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    settings.user_dir = Path('~/.thefuck').expanduser()
    assert settings.user_dir.is_dir()

