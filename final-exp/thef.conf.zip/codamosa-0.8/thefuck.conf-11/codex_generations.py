

# Generated at 2022-06-12 10:01:01.716812
# Unit test for method init of class Settings
def test_Settings_init():
    import sys
    sys.argv.append("--yes")
    settings.init(args=None)
    if const.DEFAULT_SETTINGS['require_confirmation'] == settings['require_confirmation']:
        return True
    else:
        return False

# Generated at 2022-06-12 10:01:11.721244
# Unit test for method init of class Settings
def test_Settings_init():
    import os

    args = type('args', (object,), {'yes': True, 'debug': True, 'repeat': '3'})()
    env = {'THEFUCK_WAIT_COMMAND': '1',
           'THEFUCK_PRIORITY': 'python=10:python3=10',
           'THEFUCK_RULES': 'DEFAULT_RULES:bash_history'}
    val = os.environ['THEFUCK_SLOW_COMMANDS'] = 'git:svn'
    sett = Settings(const.DEFAULT_SETTINGS)
    sett.init(args)
    assert sett.wait_command == 1
    assert sett.priority == {'python': 10, 'python3': 10}

# Generated at 2022-06-12 10:01:21.647558
# Unit test for method init of class Settings
def test_Settings_init():
    import unittest
    import tempfile
    import os

    class TestSettings(unittest.TestCase):
        def setUp(self):
            self.temp_file = tempfile.NamedTemporaryFile(suffix='py')
            self.temp_file.write(const.SETTINGS_HEADER)
            self.old_user_dir = settings.user_dir

        def tearDown(self):
            self.temp_file.close()
            settings.user_dir = self.old_user_dir

        def test_init_create_settings_file(self):
            settings.user_dir = '~'
            settings.init()
            settings_path = settings.user_dir.joinpath('settings.py').expanduser()
            self.assertTrue(settings_path.is_file())
            settings_path

# Generated at 2022-06-12 10:01:31.030504
# Unit test for method init of class Settings
def test_Settings_init():
    test_settings = Settings()
    test_settings.init()

    assert test_settings.user_dir == settings.user_dir
    assert test_settings.rules == settings.rules
    assert test_settings.verbose == settings.verbose
    assert test_settings.wait_command == settings.wait_command
    assert test_settings.slow_commands == settings.slow_commands
    assert test_settings.exclude_rules == settings.exclude_rules
    assert test_settings.require_confirmation == settings.require_confirmation
    assert test_settings.no_colors == settings.no_colors
    assert test_settings.debug == settings.debug
    assert test_settings.alter_history == settings.alter_history
    assert test_settings.env == settings.env

# Generated at 2022-06-12 10:01:40.475387
# Unit test for method init of class Settings
def test_Settings_init():
    import sys
    import os
    from mock import patch

    args = type('', (object,), {
        'yes': True,
        'repeat': True,
        'debug': True})
    args = args()

    with patch.multiple(Settings, update=lambda *args, **kwargs: None) as mocks:
        settings.init(args)
        mocks['update'].assert_called_with(
            {'require_confirmation': False,
             'repeat': True,
             'debug': True})
        assert hasattr(settings, 'user_dir')

    with patch.multiple(Settings, update=lambda *args, **kwargs: None) as mocks:
        del sys.modules['settings']
        os.environ['TF_RULES'] = 'Foo'

# Generated at 2022-06-12 10:01:45.246407
# Unit test for method init of class Settings
def test_Settings_init():
    _settings = Settings(const.DEFAULT_SETTINGS)
    _settings.init()
    assert _settings['require_confirmation'] == const.DEFAULT_SETTINGS['require_confirmation']
    os.environ['THEFUCK_REPEAT'] = 'True'
    _settings.init()
    assert _settings['repeat'] == True

# Generated at 2022-06-12 10:01:50.149874
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    settings.init(args=object)
    assert settings.user_dir.joinpath('settings.py').is_file()
    settings.init(args=object)
    assert settings.user_dir.joinpath('settings.py').is_file()

# Generated at 2022-06-12 10:01:59.600417
# Unit test for method init of class Settings
def test_Settings_init():
    # Prepare test setting
    import tempfile
    user_dir = tempfile.mkdtemp()
    settings_file = os.path.join(user_dir, 'settings.py')
    with open(settings_file, 'w') as f:
        f.write("require_confirmation = False\n")
    os.environ["TF_INSTANT_MODE"] = 'False'

    default_settings = dict(const.DEFAULT_SETTINGS)
    default_settings.update({'require_confirmation': False})
    default_settings.update({'instant_mode': False})

    # Execute test method
    settings.user_dir = user_dir
    settings.init()

    # Check results
    assert(settings == default_settings)

    # Clear test environment
    import shutil
    shutil.rmtree

# Generated at 2022-06-12 10:02:07.042791
# Unit test for method init of class Settings
def test_Settings_init():
    from tempfile import mkdtemp
    from shutil import rmtree
    from .config import which

    cwd = os.getcwd()
    temp_dir = mkdtemp()
    try:
        temp_path = Path(temp_dir)
        os.chdir(temp_dir)

        settings = Settings(const.DEFAULT_SETTINGS)
        settings.init()
        assert settings.user_dir == temp_path.joinpath('.config', 'thefuck')
        assert settings.user_dir.is_dir()
        assert settings.user_dir.joinpath('settings.py').is_file()
        assert settings.user_dir.joinpath('rules').is_dir()
        assert which('less') == 'less'
    finally:
        os.chdir(cwd)

# Generated at 2022-06-12 10:02:16.455268
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings['require_confirmation'] is True
    assert settings['rules'] == const.DEFAULT_RULES


# Generated at 2022-06-12 10:02:53.139017
# Unit test for method init of class Settings
def test_Settings_init():
    test = Settings()
    test.init()
    assert test['rules'] == const.DEFAULT_RULES

# Generated at 2022-06-12 10:03:02.135843
# Unit test for method init of class Settings
def test_Settings_init():
    """Unit test for method init of class Settings."""
    os.environ['THEFUCK_WAIT_COMMAND'] = '5'
    os.environ['THEFUCK_PRIORITY'] = 'history=5'
    os.environ['THEFUCK_EXCLUDE_RULES'] = 'history:DEFAULT_RULES'
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'True'
    os.environ['THEFUCK_NO_COLORS'] = 'False'
    os.environ['THEFUCK_ALTER_HISTORY'] = 'true'
    os.environ['THEFUCK_REPEAT'] = '4'

    settings.init(['--yes', '--debug', '--repeat=3'])


# Generated at 2022-06-12 10:03:03.816784
# Unit test for method init of class Settings
def test_Settings_init():
    # Test init all settings
    settings.init()
    pass


# Generated at 2022-06-12 10:03:07.804493
# Unit test for method init of class Settings
def test_Settings_init():
    # method init of class Settings could well run with default settings
    settings.init()
    assert settings == const.DEFAULT_SETTINGS
    # method init of class Settings could well run with other settings from the file
    os.environ["THEFUCK_WAIT_COMMAND"] = "1"
    settings.init()
    assert settings["wait_command"] == 1

# Generated at 2022-06-12 10:03:13.554048
# Unit test for method init of class Settings
def test_Settings_init():
    import mock
    import imp
    import builtins

    os.getenv = mock.MagicMock(return_value='')
    ModuleType = imp.new_module('settings')
    sys.modules['settings'] = ModuleType
    ModuleType.__dict__.update({'require_confirmation': False})
    open_mock = mock.mock_open(read_data=const.SETTINGS_HEADER)

# Generated at 2022-06-12 10:03:22.991196
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import log
    import sys
    from mock import patch
    from .tests.utils import CustomObject

    # First case: no args

# Generated at 2022-06-12 10:03:32.195959
# Unit test for method init of class Settings
def test_Settings_init():
    assert const.DEFAULT_SETTINGS['require_confirmation'] == True
    assert const.DEFAULT_SETTINGS['priority'] == {
        'cd_parent': 1,
        'cd_mkdir': 0,
        'git_push': 0,
        'git_push_current_branch': 0,
        'python_command': -1,
        'sudo': 100,
        'man': 10,
    }

# Generated at 2022-06-12 10:03:39.997255
# Unit test for method init of class Settings
def test_Settings_init():
    TEST_SETTINGS = {'require_confirmation': True,
                     'rules': ['thefuck.rules.titular'],
                     'history_limit': None,
                     'wait_slow_command': 15,
                     'wait_command': 5,
                     'alter_history': True,
                     'debug': False,
                     'no_colors': False,
                     'priority': {'titular': 200},
                     'exclude_rules': [],
                     'num_close_matches': 3,
                     'instant_mode': False,
                     'slow_commands': ['(?<!\.egg-info)/bin/pip'],
                     'excluded_search_path_prefixes': ['/usr/local/lib/python']}

    import tempfile
    tmpdir = tempfile.mkdtemp()
   

# Generated at 2022-06-12 10:03:49.379473
# Unit test for method init of class Settings
def test_Settings_init():
    def test_settings_init_backward_comp(monkeypatch):
        world = {'thefuck_dir': '~/.thefuck',
                 'settings_file': '~/.thefuck/settings.py'}
        monkeypatch.setattr('os.environ', world)
        world['user_dir'] = '~/.config/thefuck'
        get_user_dir_path = Settings._get_user_dir_path
        monkeypatch.setattr(Settings, '_get_user_dir_path',
                            lambda x: world[get_user_dir_path.__name__])
        setup_user_dir = Settings._setup_user_dir
        monkeypatch.setattr(Settings, '_setup_user_dir',
                            lambda x: world[setup_user_dir.__name__])

# Generated at 2022-06-12 10:03:52.779027
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    # Ensure that settings contains default settings and `home_and_config_paths`
    expected_keys = list(const.DEFAULT_SETTINGS.keys()) + ['home_and_config_paths']
    assert set(settings.keys()) == set(expected_keys)

# Generated at 2022-06-12 10:04:21.117788
# Unit test for method init of class Settings
def test_Settings_init():
    s = Settings()
    s.init()
    r = Settings(const.DEFAULT_SETTINGS)
    assert s == r

# Generated at 2022-06-12 10:04:30.510906
# Unit test for method init of class Settings
def test_Settings_init():
    args = lambda **kwargs: type('args', (), kwargs)
    sys.modules['settings'] = type('settings', (), {
        'require_confirmation': False,
        'wait_command': 1,
        'wait_slow_commands': 0,
        'num_close_matches': 3,
        'slow_commands': [],
        'exclude_rules': ['test'],
        'alter_history': True,
        'priority': {}
    })()

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()

    assert settings == const.DEFAULT_SETTINGS
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()



# Generated at 2022-06-12 10:04:33.613974
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    arg = argparse.Namespace(
        yes = False,
        debug = False,
        repeat = 0
    )
    settings.init(args = arg)
    assert settings['require_confirmation'] == True
    assert settings['repeat'] == 0

# Generated at 2022-06-12 10:04:43.394953
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import LOGGER
    LOGGER.clear()
    with settings.user_dir.joinpath('settings.py').open() as settings_file:
        settings_file.write(u'# fuck_settings = DEFAULT_RULES:python:git\n')

    os.environ['THEFUCK_RULES'] = 'python:git:php:!'
    os.environ['THEFUCK_PRIORITY'] = 'python=1:php=2'
    os.environ['THEFUCK_ALTER_HISTORY'] = 'True'
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'False'
    os.environ['THEFUCK_SLOW_COMMANDS'] = 'fuck:f'

# Generated at 2022-06-12 10:04:47.905890
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    settings.init()
    assert settings._get_user_dir_path() == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.user_dir.joinpath('rules').is_dir()


# Generated at 2022-06-12 10:04:54.812563
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import log

    def print_exception():
        pass

    def _settings_from_file():
        return {'wait_command': 4}

    def _settings_from_env():
        return {'require_confirmation': True}

    def _settings_from_args():
        return {'repeat': 2}

    def test():
        exception_mock = Mock(wraps=print_exception)
        _settings_from_file_mock = Mock(wraps=_settings_from_file)
        _settings_from_env_mock = Mock(wraps=_settings_from_env)
        _settings_from_args_mock = Mock(wraps=_settings_from_args)


# Generated at 2022-06-12 10:05:00.083455
# Unit test for method init of class Settings
def test_Settings_init():
    args = type('', (), {'yes': False, 'debug': False})()
    _settings = Settings(const.DEFAULT_SETTINGS)
    _settings.init(args)

    assert _settings.user_dir == os.path.expanduser('~/.config/thefuck')
    assert _settings.get('require_confirmation') is True
    assert _settings.get('repeat') is False

# Generated at 2022-06-12 10:05:07.914276
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.init() is None
    assert settings.get('alter_history') == True
    assert settings.get('exclude_rules') == []
    assert settings.get('excluded_search_path_prefixes') == []
    assert settings.get('history_limit') == None
    assert settings.get('instant_mode') == False
    assert settings.get('num_close_matches') == 3
    assert settings.get('priority') == {}
    assert settings.get('require_confirmation') == True

# Generated at 2022-06-12 10:05:17.175133
# Unit test for method init of class Settings
def test_Settings_init():
    """Test init method of class Settings
    """
    import tempfile
    import shutil
    import os
    from pathlib2 import Path

    def execute (command):
        os.system(command)
    try:
        tmp_path = Path(tempfile.mkdtemp())
        execute("echo 'RULES = [\"echo 1\"]' >> " + tmp_path + "/settings.py")

        with open("/tmp/test_Settings_init.py",'w') as out:
            out.write("settings.init()")
        os.system("python /tmp/test_Settings_init.py")

    except:
        assert False
    finally:
        shutil.rmtree(tmp_path)

# Generated at 2022-06-12 10:05:24.122809
# Unit test for method init of class Settings
def test_Settings_init():
    settings_obj = Settings()
    settings_obj.init()
    settings_obj._init_settings_file()
    settings_obj._setup_user_dir()
    assert settings_obj.get('require_confirmation') == True
    assert settings_obj.get('wait_command') == 0.5
    assert settings_obj.get('no_colors') == False
    assert settings_obj.get('repeat') == 1
    settings_obj.update(settings_obj._settings_from_env())
    assert settings_obj.get('require_confirmation') == False
    settings_obj.init()

# Generated at 2022-06-12 10:06:34.840962
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    import sys
    import imp
    import os
    from os.path import isfile
    from six import StringIO
    from warnings import filterwarnings
    from six.moves import reload_module
    filterwarnings('ignore', 'imp.load_source.*deprecated',
                   DeprecationWarning)

    # unit-test for method _init_settings_file:
    settings_path = settings._get_user_dir_path().joinpath('settings.py')
    if isfile(settings_path):
        os.remove(settings_path)
    settings._init_settings_file()
    assert isfile(settings_path)

    # unit-test for method _settings_from_file:
    with StringIO() as f:
        sys.stderr = f

# Generated at 2022-06-12 10:06:40.119494
# Unit test for method init of class Settings
def test_Settings_init():
    # validate _setup_user_dir method
    settings._setup_user_dir()
    assert settings.user_dir.name == '.config/thefuck'

    # validate _init_settings_file method
    settings._init_settings_file()
    assert settings.user_dir.joinpath('settings.py').is_file()

    # validate _settings_from_file method
    settings._settings_from_file()
    assert len(settings) == len(const.DEFAULT_SETTINGS)

# Generated at 2022-06-12 10:06:43.233996
# Unit test for method init of class Settings
def test_Settings_init():
    class Args(object):
        def __init__(self, yes, debug, repeat):
            self.yes = yes
            self.debug = debug
            self.repeat = repeat

    args = Args(True, True, 2)
    settings.init(args)
    assert settings['require_confirmation'] is False
    assert settings['debug'] is True
    assert settings['repeat'] == 2
    # reset settings
    settings.init()

# Generated at 2022-06-12 10:06:48.381443
# Unit test for method init of class Settings
def test_Settings_init():
    from .history import History
    from .logs import exception
    from .profile import Profile
    from .rule import RulesFinder
    from .utils import memoize

    user_dir = Path('/fuck')
    settings = Settings({
        'user_dir': user_dir,
        'e': 'r',
        'q': 'w',
    })
    args = type('Args', (object,), {'debug': True, 'repeat': 2})

    class MockExists:
        def __init__(self, val, exist=True):
            self.val = val
            self.exist = exist

        def __eq__(self, other):
            return other == self.val

        def is_dir(self):
            return self.exist

    class MockOpen:
        def __init__(self, func):
            self._

# Generated at 2022-06-12 10:06:56.614414
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch, call
    from thefuck.settings import Settings, const

    with patch('thefuck.settings.Settings._settings_from_file') as \
            settings_from_file, \
            patch('thefuck.settings.Settings._settings_from_env') as \
            settings_from_env, \
            patch('thefuck.settings.Settings._settings_from_args') as \
            settings_from_args, \
            patch('thefuck.settings.logs.exception') as exception:

        settings_from_file.return_value = {'key': 'value'}
        settings_from_env.return_value = {'key1': 'value1'}
        settings_from_args.return_value = {'key2': 'value2'}

        settings._init_settings_file = lambda: None


# Generated at 2022-06-12 10:07:05.479220
# Unit test for method init of class Settings
def test_Settings_init():
    import argparse
    args = argparse.Namespace(yes=None, debug=None, repeat=None)

    from .logs import exception
    def test_exception(*args):
        raise Exception('Expected exception')
    exception.side_effect = test_exception

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.user_dir.exists = lambda:False
    settings._get_user_dir_path().joinpath('settings.py').open = lambda x, y: None
    with settings._get_user_dir_path().joinpath('settings.py').open(mode='w') as f:
        f.write('test=test')
    settings.init(args)
    assert exception.call_count == 2
    assert settings['test'] == 'test'
    assert settings['require_confirmation']

# Generated at 2022-06-12 10:07:09.973681
# Unit test for method init of class Settings
def test_Settings_init():
    """Unit test for method init of class Settings.

    The method init should initialize attribute user_dir and update settings
    with values from settings.py, environment and arguments.
    """
    from .logs import log_exception

    settings = Settings()

    # Mock value for user_dir
    user_dir = Path('~/.thefuck')
    settings._get_user_dir_path = lambda: user_dir

    # Mock method
    class NullClass:
        pass

    settings._settings_from_file = NullClass
    settings._settings_from_file.return_value = {'test_file': 'test_file'}

    settings._settings_from_env = NullClass
    settings._settings_from_env.return_value = {'test_env': 'test_env'}

    settings._settings_from_args = NullClass

# Generated at 2022-06-12 10:07:12.008019
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings['require_confirmation']
    assert settings['debug'] == False
    assert settings['repeat'] is None
    assert settings['priority'] == {}



# Generated at 2022-06-12 10:07:19.586100
# Unit test for method init of class Settings
def test_Settings_init():
    import types
    import os

    settings_py_path = settings.user_dir.joinpath('settings.py')
    assert settings_py_path.is_file()

    assert settings.user_dir.isdir()

    assert 'require_confirmation' not in os.environ
    assert 'require_confirmation' not in settings

    os.environ['REQUIRE_CONFIRMATION'] = 'false'
    settings.init()
    assert settings.require_confirmation == False
    assert 'require_confirmation' not in settings

    assert 'ALTER_HISTORY' not in os.environ
    assert 'alter_history' not in settings

    os.environ['alter_history'] = 'true'
    settings.init()
    assert settings.alter_history == True
    assert 'alter_history' not in settings

   

# Generated at 2022-06-12 10:07:25.418136
# Unit test for method init of class Settings

# Generated at 2022-06-12 10:10:41.907213
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import TemporaryDirectory
    from .conf import settings

    with TemporaryDirectory() as tmpdir:
        xdg_config_home = os.environ.get('XDG_CONFIG_HOME', '~/.config')
        user_dir = Path(xdg_config_home, 'thefuck').expanduser()
        user_dir.mkdir(parents=True)

        settings.init()

        assert settings.get('require_confirmation') == True
        assert settings.get('repeat') == False

        if not user_dir.joinpath('rules').is_dir():
            user_dir.joinpath('rules').mkdir(parents=True)
