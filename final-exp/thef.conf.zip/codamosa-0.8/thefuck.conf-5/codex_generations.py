

# Generated at 2022-06-12 10:01:27.945805
# Unit test for method init of class Settings
def test_Settings_init():
    import pytest
    from mock import patch
    from pkg_resources import resource_filename
    from shutil import rmtree

    from .system import Path

    @pytest.fixture
    def settings_path(request):
        settings_path = Path(resource_filename('thefuck', 'settings.py'))
        request.addfinalizer(lambda: rmtree(settings_path))
        return settings_path

    @pytest.fixture
    def args():
        import argparse
        parser = argparse.ArgumentParser()
        parser.add_argument('--yes', action='store_true')
        return parser.parse_args(['--yes'])


# Generated at 2022-06-12 10:01:32.170371
# Unit test for method init of class Settings
def test_Settings_init():
    """
    Unit test of Settings.init method
    """
    local_settings=Settings({'require_confirmation': True})
    local_settings.init()
    assert local_settings['require_confirmation'] is True


# Generated at 2022-06-12 10:01:40.963544
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)

    import tempfile
    tmpdir = tempfile.TemporaryDirectory()

    config_path = Path(tmpdir.name)
    settings_file_path = config_path.joinpath('settings.py')
    rules_path = Path(config_path.joinpath('rules'))

    os.environ['THEFUCK_RULES'] = 'bash'
    os.environ['THEFUCK_WAIT_SLOW_COMMAND'] = '2'
    os.environ['THEFUCK_NO_COLORS'] = 'false'
    os.environ['THEFUCK_PRIORITY'] = 'bash=10:python=10'

# Generated at 2022-06-12 10:01:41.951163
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.init() == None

# Generated at 2022-06-12 10:01:52.141726
# Unit test for method init of class Settings
def test_Settings_init():
    from thefuck.shells import Bash
    from thefuck.settings import cache
    from thefuck.types import Command

    args = lambda **kwargs: type('Args', (), kwargs)
    bash = Bash()
    cache.clear()

    settings.init()
    assert settings == const.DEFAULT_SETTINGS
    assert settings.user_dir == settings._get_user_dir_path()

    settings.init(args(yes=True))
    assert settings.require_confirmation == False
    assert bash.cmd_requires_confirmation(Command(
        script='echo test',
        stderr='', stdout='',
        env={'LANG': 'C', 'LC_ALL': 'C'})) == False

    settings.init(args(repeat='sudo'))
    assert settings.repeat == 'sudo'

# Generated at 2022-06-12 10:02:02.002357
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings.init()
    assert settings.exclude_rules == tuple(const.DEFAULT_RULES)
    assert settings.rules == tuple(const.DEFAULT_RULES)
    assert settings.priority == {}
    assert settings.wait_command == 3
    assert settings.history_limit == 10
    assert settings.require_confirmation
    assert settings.slow_commands is None
    assert settings.exclude_rules is not None
    assert settings.excluded_search_path_prefixes is None
    assert settings.no_colors is False
    assert settings.debug is False
    assert settings.wait_slow_command == 10
    assert settings.alter_history is False
    assert settings.instant_mode is False
    assert settings.num_close_matches == 5

# Generated at 2022-06-12 10:02:12.893793
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings({})
    args = type('Args', (object,), {'yes': False, 'debug': False, 'repeat': None})
    settings.init(args=args)
    assert settings.require_confirmation

    settings = Settings({})
    args = type('Args', (object,), {'yes': True, 'debug': False, 'repeat': None})
    settings.init(args=args)
    assert not settings.require_confirmation

    settings = Settings({})
    args = type('Args', (object,), {'yes': True, 'debug': True, 'repeat': None})
    settings.init(args=args)
    assert settings.debug
    assert not settings.require_confirmation

    settings = Settings({})

# Generated at 2022-06-12 10:02:21.027533
# Unit test for method init of class Settings
def test_Settings_init():
    from . import logs, paths
    from .logs import exception
    from .paths import Path

    logs.exception = lambda err, ex: None
    paths.Path = Path

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()

    settings.init(args=type('args', (object,), {'yes': True}))
    assert settings.require_confirmation == False
    settings.init(args=type('args', (object,), {'yes': False}))
    assert settings.require_confirmation == True

    settings.init(args=type('args', (object,), {'debug': 'test'}))
    assert settings.debug == 'test'
    settings.init(args=type('args', (object,), {'debug': None}))
    assert settings.debug == False



# Generated at 2022-06-12 10:02:22.720759
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    for key, val in const.DEFAULT_SETTINGS.items():
        assert settings[key] == val
    assert settings['user_dir'].is_dir()

# Generated at 2022-06-12 10:02:27.758900
# Unit test for method init of class Settings
def test_Settings_init():
    # Build mocks
    def _init_settings_file(): pass
    def _settings_from_file(): return {'rules': ['mock_rule']}
    def _settings_from_env(): return {'priority': {'mock_rule': 42}}
    def _settings_from_args(_): return {'require_confirmation': False}
    mock_instance = {
        '_init_settings_file': _init_settings_file,
        '_settings_from_file': _settings_from_file,
        '_settings_from_env': _settings_from_env,
        '_settings_from_args': _settings_from_args
    }

    import thefuck
    thefuck.settings.__class__.init(mock_instance)

# Generated at 2022-06-12 10:03:20.349152
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    user_dir = Path('~/.thefuck').expanduser()

    if user_dir.is_dir():
        user_dir.rmdir()


# Generated at 2022-06-12 10:03:24.098616
# Unit test for method init of class Settings
def test_Settings_init():
    import argparse
    from .config import settings

    args = argparse.Namespace(yes=True, debug=True, repeat=3)

    settings.init(args)
    assert settings.get('require_confirmation') == False
    assert settings.get('debug') == True
    assert settings.get('repeat') == 3


# Generated at 2022-06-12 10:03:30.625303
# Unit test for method init of class Settings
def test_Settings_init():
    os.environ["TF_DEBUG"] = 'true'
    os.environ["TF_RULES"] = 'DEFAULT_RULES:bash_history'
    os.environ["TF_PRIORITY"] = 'bash_history=50'
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.get('debug')
    assert settings.get('rules') == const.DEFAULT_RULES+['bash_history']
    assert settings.get('priority').get('bash_history') == 50

# Generated at 2022-06-12 10:03:36.474105
# Unit test for method init of class Settings
def test_Settings_init():

    import subprocess
    import unittest.mock

    class SubProcess(object):

        def __init__(self, returncode, stdout='', stderr=''):
            self.returncode = returncode
            self.stdout = stdout
            self.stderr = stderr

    args = const.DEFAULT_SETTINGS

# Generated at 2022-06-12 10:03:45.066014
# Unit test for method init of class Settings
def test_Settings_init():
    # prepare for test
    mocked_args = mock.Mock()
    mocked_args.yes = False
    mocked_args.debug = False
    mocked_args.repeat = False

    user_dir = Path(tempfile.gettempdir(), 'thefuck-tests')
    user_dir.mkdir()
    settings_file_path = user_dir.joinpath('settings.py')

    with settings_file_path.open(mode='w') as settings_file:
        settings_file.write('DEBUG = True\n')
        settings_file.write('REQUIRE_CONFIRMATION = False\n')
        settings_file.write('PRIORITY = {\'bash\': 100}\n')
        settings_file.write('RULES = [\'bash\']\n')

    # run test

# Generated at 2022-06-12 10:03:46.825643
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.get('rules') == const.DEFAULT_RULES


# Generated at 2022-06-12 10:03:54.213292
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

    assert 'require_confirmation' in settings
    assert 'alter_history' in settings
    assert 'rules' in settings
    assert 'priority' in settings

    file_settings = {
        'require_confirmation': False,
        'alter_history': True,
        'rules': ['pip', 'git'],
        'priority': {
            'brew': 100
        }
    }

    user_dir = settings._get_user_dir_path()
    with user_dir.joinpath('settings.py').open(mode='w') as settings_file:
        for setting, value in file_settings.items():
            settings_file.write(u'{} = {}\n'.format(setting, value))

    settings.init()

    for setting, value in file_settings.items():
        assert settings

# Generated at 2022-06-12 10:03:56.451719
# Unit test for method init of class Settings
def test_Settings_init():
    settings_dict = {'require_confirmation': False, 'repeat': 5}
    settings.init(args=settings_dict)
    assert settings == settings_dict

# Generated at 2022-06-12 10:04:04.877458
# Unit test for method init of class Settings
def test_Settings_init():
    import mock
    import sys

    # make sure that the user_dir is created
    user_dir = settings._get_user_dir_path()
    user_dir.mkdir(parents=True, exist_ok=True)

    # make sure the settings file is created
    settings_path = user_dir.joinpath('settings.py')
    if not settings_path.is_file():
        with settings_path.open(mode='w') as settings_file:
            settings_file.write(const.SETTINGS_HEADER)
            for setting in const.DEFAULT_SETTINGS.items():
                settings_file.write(u'# {} = {}\n'.format(*setting))

    # create a copy of the global settings object because we need to modify it
    global settings
    _settings = settings.copy()

    # mock

# Generated at 2022-06-12 10:04:14.536145
# Unit test for method init of class Settings
def test_Settings_init():
    """Test for method init of class Settings"""
    from .logs import exception

    def _fake_exception_call(self, message, exc_info):
        raise ValueError(message)

    def _fake_settings_from_file():
        raise ValueError('Can\'t load settings from file')

    def _fake_settings_from_env():
        raise ValueError('Can\'t load settings from env')

    constructor_settings = Settings()
    constructor_settings.init()
    assert constructor_settings['alter_history']

    exception_settings = Settings()
    exception_settings.init()
    exception.__call__ = _fake_exception_call
    exception_settings['user_dir'] = Path('~/.config/thefuck')
    exception_settings['_settings_from_env'] = _fake_settings_from_env
   

# Generated at 2022-06-12 10:05:58.989753
# Unit test for method init of class Settings
def test_Settings_init():
    """
    If init method is executed with no arguments it will set up user's directory.
    Also it will create settings file in that directory.
    Then it will load settings from file and environment.
    """
    from mock import Mock, mock_open, patch, sentinel
    from thefuck.shells import get_history

    class Args(object):
        def __init__(self, yes=False, debug=False, repeat=False):
            self.yes = yes
            self.debug = debug
            self.repeat = repeat

    args = Args()

    with patch('builtins.open', mock_open(read_data=u'')) as mock_settings_file:
        with patch('os.environ', {}):
            with patch.object(Path, 'mkdir') as mock_mkdir:
                settings.init()

    mock

# Generated at 2022-06-12 10:05:59.961118
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.get('require_confirmation')


# Generated at 2022-06-12 10:06:07.696146
# Unit test for method init of class Settings
def test_Settings_init():
    from .utils import wrap_streams
    import sys
    import os
    from .logs import _print, exception

    # Initial initial settings
    s = Settings()

    # Test for settings from file
    fake_settings_file = '''
settings = object()
rules = ['ls_a']
'''
    with wrap_streams(sys.stdout, sys.stderr, '''Can't load settings from file
Traceback (most recent call last):
  File "<string>", line 1, in <module>
NameError: name 'settings' is not defined
'''):
        with settings.user_dir.joinpath('settings.py').open(mode='w') as fake_settings:
            fake_settings.write(fake_settings_file)
        s.init()
    assert 'settings' not in s

# Generated at 2022-06-12 10:06:10.453756
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir == Path(os.environ.get(
        'XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()

# Generated at 2022-06-12 10:06:15.746385
# Unit test for method init of class Settings
def test_Settings_init():
    '''
    Run the test for method init of class Settings
    :return:
    '''
    from . import main

    # Load environment settings for testing
    os.environ['THEFUCK_RULES'] = 'bash:man:python:git:sysadmin'
    os.environ['THEFUCK_PRIORITY'] = 'bash=10:python=1'
    os.environ['THEFUCK_EXCLUDE_RULES'] = 'python:git'
    os.environ['THEFUCK_WAIT_COMMAND'] = '1'
    os.environ['THEFUCK_WAIT_SLOW_COMMAND'] = '1'
    os.environ['THEFUCK_NO_COLORS'] = 'True'

# Generated at 2022-06-12 10:06:17.456439
# Unit test for method init of class Settings
def test_Settings_init():
    args = None
    settings.init(args)
    expected_settings = const.DEFAULT_SETTINGS
    assert settings == expected_settings


# Generated at 2022-06-12 10:06:20.627509
# Unit test for method init of class Settings
def test_Settings_init():
    args = type('', (object,), {'yes': True, 'debug': True, 'repeat': 4})()
    settings.init(args)
    assert settings.require_confirmation == False
    assert settings.debug == True
    assert settings.repeat == 4


# Generated at 2022-06-12 10:06:22.436476
# Unit test for method init of class Settings
def test_Settings_init():
    """Unit test for method init of class Settings"""
    current_settings = settings.init()
    assert current_settings == {'_skip_confirm': True}

# Generated at 2022-06-12 10:06:30.774605
# Unit test for method init of class Settings
def test_Settings_init():

    current_settings = settings.copy()

    args_1 = argparse.Namespace(yes=None, repeat=None, debug=None)

    settings.init(args_1)
    for key, value in current_settings.items():
        assert settings[key] == value


    args_2 = argparse.Namespace(yes=True, repeat=None, debug=None)

    settings.init(args_2)
    for key, value in current_settings.items():
        if key != 'require_confirmation':
            assert settings[key] == value

# Generated at 2022-06-12 10:06:38.978709
# Unit test for method init of class Settings
def test_Settings_init():
    # Given
    import types
    import mock

    # When
    s = Settings(const.DEFAULT_SETTINGS)
    s.init()

    # Then
    assert isinstance(s, types.DictType)
    assert hasattr(s, '_init_settings_file')
    assert hasattr(s, '_setup_user_dir')
    assert isinstance(s.user_dir, mock.Mock)
    assert isinstance(s['rules'], types.ListType)
    assert isinstance(s['priority'], types.DictType)
    assert isinstance(s['require_confirmation'], types.BooleanType)
    assert isinstance(s['no_colors'], types.BooleanType)
    assert isinstance(s['debug'], types.BooleanType)