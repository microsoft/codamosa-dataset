

# Generated at 2022-06-12 10:01:11.046200
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch, Mock
    from thefuck.settings import Settings

    default_settings = const.DEFAULT_SETTINGS.copy()
    # Remove attributes user_dir and commands_history
    # because we want to test only other attributes.
    del default_settings['user_dir']
    del default_settings['commands_history']

    def get(self, item):
        return self.get(item)
    # Copy this method because it will be modified in class Settings.
    default_settings['_init_settings_file'] = Settings._init_settings_file
    default_settings['__getattr__'] = get

    settings = Settings()

# Generated at 2022-06-12 10:01:21.288794
# Unit test for method init of class Settings
def test_Settings_init():
    import sys
    from io import StringIO
    from .logs import exception

    args = Object()
    args.yes = True
    args.debug = True
    args.repeat = True
    const.DEFAULT_SETTINGS['exclude_rules'] = ['a', 'b', 'c']
    const.ENV_TO_ATTR = {'LANG': 'lang'}
    os.environ['LANG'] = 'en'

    def _warn(message, category, stacklevel):
        assert u'Please move to' in message
        assert category == DeprecationWarning
        assert stacklevel == 2

    def _get_user_dir_path(self):
        return Path('~/.config/thefuck')


# Generated at 2022-06-12 10:01:30.748361
# Unit test for method init of class Settings
def test_Settings_init():
    import os, sys
    import shutil
    from thefuck.logs import exception
    from thefuck.system import Path
    from .logs import log
    
    work_dir = os.path.dirname(os.path.realpath(__file__))
    log_file = os.path.join(work_dir, 'test.log')
    
    s = Settings(const.DEFAULT_SETTINGS)
    # test _init_settings_file
    shutil.rmtree(os.path.join(work_dir, 'thefuck'))
    s._setup_user_dir()
    with open(log_file, 'w') as f:
        sys.stderr = f
        s._init_settings_file()
    

# Generated at 2022-06-12 10:01:38.902316
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    # create mocked call to function _settings_from_file
    settings._settings_from_file = lambda: {'alternative_script':'echo hi'}
    # create mocked call to function _settings_from_env
    settings._settings_from_env = lambda: {'no_colors':True}
    # create mocked call to function _settings_from_args
    settings._settings_from_args = lambda args: {'repeat':True}

    settings.init()
    assert settings.alternative_script == 'echo hi'
    assert settings.no_colors == True
    assert settings.repeat == True

# Generated at 2022-06-12 10:01:41.270104
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.steam_link_exec == "steam steam://rungameid/"

# Generated at 2022-06-12 10:01:51.628284
# Unit test for method init of class Settings
def test_Settings_init():
    import sys

    from thefuck.logs import exception
    from .logs import logger
    from .utils import wrap_streams
    from .config import SETTINGS_HEADER, DEFAULT_SETTINGS, ENV_TO_ATTR
    from .types import SettingsDict
    from .system import Path

    with wrap_streams():
        os.environ.clear()
        settings.__init__(dict())

        assert (settings.user_dir.joinpath('settings.py')).is_file() is True

        current_path = Path(__file__)
        settings_path = Path(__file__).parent.joinpath('settings.py')


# Generated at 2022-06-12 10:01:52.772074
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init(args=None)
    assert settings['require_confirmation'] == False

# Generated at 2022-06-12 10:02:02.969442
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .utils import get_all_rules_names_from_paths

    def reset_settings():
        settings.__init__(const.DEFAULT_SETTINGS)

    args = Mock()
    args.debug = True
    user_dir = Path('/tmp', '.thefuck')
    reset_settings()
    settings.user_dir = user_dir
    settings.init(args)
    assert settings.debug == args.debug
    settings.exclude_rules = ['slow_command']
    settings.init(args)
    assert settings.rules == get_all_rules_names_from_paths(settings.rules_dir)
    settings.exclude_rules = []
    settings.init(args)
    assert settings.slow_commands == ['sudo']

# Generated at 2022-06-12 10:02:13.431348
# Unit test for method init of class Settings
def test_Settings_init():
    """Mock for testing init method."""

    class MockFile(object):
        def write(self, text):
            pass

        def close(self):
            pass
    import __builtin__
    __builtin__.__dict__['open'] = MockFile

    args = type('', (), {'yes': True, 'debug': False, 'repeat': True})
    settings.update({'require_confirmation': False,
                     'debug': False})
    settings.init(args)
    assert settings == {'require_confirmation': False,
                        'debug': True,
                        'repeat': True,
                        'user_dir': Path('~/.config/thefuck').expanduser(),
                        'rules_dir': Path('~/.config/thefuck/rules').expanduser()}


# Generated at 2022-06-12 10:02:14.305474
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings['rules']

# Generated at 2022-06-12 10:02:43.479001
# Unit test for method init of class Settings
def test_Settings_init():
    import sys
    from .logs import exception
    from .system import Path

    settings = Settings(const.DEFAULT_SETTINGS)

    if os.name == 'nt':
        xdg_config_home = os.environ.get('XDG_CONFIG_HOME', '~/.config')
        settings_path = Path(xdg_config_home, 'thefuck').expanduser()
    else:
        settings_path = Path('~', '.thefuck').expanduser()

    def _get_user_dir_path(self):
        return settings_path

    settings._get_user_dir_path = types.MethodType(_get_user_dir_path, settings)

    def _setup_user_dir(self):
        user_dir = self._get_user_dir_path()

        rules_dir

# Generated at 2022-06-12 10:02:44.754211
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    args = None
    settings.init(args)
    assert settings['require_confirmation'] == True

# Generated at 2022-06-12 10:02:49.740271
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch

    def _load_source(name, path):
        return {'rules': ['fuck'], 'require_confirmation': True}


# Generated at 2022-06-12 10:02:53.441334
# Unit test for method init of class Settings
def test_Settings_init():
    import pytest
    from mock import mock_open

    with pytest.raises(Exception):
        Settings().init()

    with mock_open() as m:
        m.side_effect = Exception()
        Settings().init()

    with mock_open() as m:
        m.side_effect = ValueError()
        Settings().init()

# Generated at 2022-06-12 10:03:02.588226
# Unit test for method init of class Settings
def test_Settings_init():
    #create temporary directory
    from tempfile import mkdtemp
    from shutil import rmtree
    from random import choice, randint
    from string import ascii_letters

    def random_string(stringLength=10):
        """Generate a random string of fixed length """
        letters = ascii_letters
        return ''.join(choice(letters) for i in range(stringLength))

    d = mkdtemp()
    print(d)
    s = Settings()
    s.init()

    config_file = 'settings.py'
    config_file_path = d + '/' + config_file
    with open(config_file_path, 'w+') as f:
        f.write(const.SETTINGS_HEADER)

# Generated at 2022-06-12 10:03:06.524621
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init(args_=Namespace(yes=True, debug=False, repeat=0))
    assert settings.require_confirmation == False
    settings.init(args_=Namespace(yes=False, debug=True, repeat=1))
    assert settings.debug == True
    assert settings.repeat == 1

# Generated at 2022-06-12 10:03:17.313358
# Unit test for method init of class Settings
def test_Settings_init():

    def settings_from_file():
        return {'require_confirmation': False,
                'rules': ['git_push', 'git_add'],
                'no_colors': True}

    def settings_from_env():
        return {'rules': ['hg_commit'], 'priority': {'hg_commit': 1000}}

    def settings_from_args(yes=False, debug=None, repeat=None):
        return {'require_confirmation': yes, 'debug': debug, 'repeat': repeat}

    settings = Settings(const.DEFAULT_SETTINGS)

# Generated at 2022-06-12 10:03:25.759887
# Unit test for method init of class Settings
def test_Settings_init():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    test_settings.init()
    assert os.path.isdir(test_settings.user_dir)
    assert os.path.isdir(test_settings.user_dir + '/rules')
    if sys.version_info.major == 2:
        assert isinstance(test_settings['require_confirmation'], bool)
        assert isinstance(test_settings['no_colors'], bool)
        assert isinstance(test_settings['debug'], bool)
        assert isinstance(test_settings['alter_history'], bool)
        assert isinstance(test_settings['repeat'], int)
        assert isinstance(test_settings['wait_command'], int)
        assert isinstance(test_settings['wait_slow_command'], int)

# Generated at 2022-06-12 10:03:27.062576
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings == const.DEFAULT_SETTINGS

# Generated at 2022-06-12 10:03:35.131137
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    user_dir_path = settings._get_user_dir_path()
    settings.init()
    assert settings.user_dir == user_dir_path

    xdg_config_home = os.environ.get('XDG_CONFIG_HOME', '~/.config')
    user_dir = Path(xdg_config_home, 'thefuck').expanduser()
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.user_dir == user_dir

    os.environ['XDG_CONFIG_HOME'] = ''
    user_dir = Path('~', '.config', 'thefuck').expanduser()
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.user_dir == user_dir


# Generated at 2022-06-12 10:04:01.886268
# Unit test for method init of class Settings
def test_Settings_init():
    import sys

    settings.init(None)
    assert settings.debug == False
    assert settings.repeat == None

    sys.argv.append('-d')
    settings.init(None)
    assert settings.debug == True

    sys.argv.append('--no-require-confirm')
    settings.init(None)
    assert settings.require_confirmation == False

    sys.argv.append('--repeat')
    sys.argv.append('3')
    settings.init(None)
    assert settings.repeat == 3

# Generated at 2022-06-12 10:04:11.379547
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .exceptions import AppError
    
    with Path(__file__).dirname().joinpath('settings_test.py').open(mode='w') as settings_file:
        settings_file.write(const.SETTINGS_HEADER)
        for setting in const.DEFAULT_SETTINGS.items():
            settings_file.write(u'# {} = {}\n'.format(*setting))
    
    settings.init()
    assert settings['use_notify'] == const.DEFAULT_SETTINGS['use_notify']
    
    Path(__file__).dirname().joinpath('settings_test.py').remove()
    
    with Path(__file__).dirname().joinpath('settings_test.py').open(mode='w') as settings_file:
        settings_

# Generated at 2022-06-12 10:04:13.715337
# Unit test for method init of class Settings
def test_Settings_init():
    test_args = None
    test_settings = Settings(const.DEFAULT_SETTINGS)
    test_settings.init(test_args)

    assert test_settings is not None

# Generated at 2022-06-12 10:04:21.913816
# Unit test for method init of class Settings
def test_Settings_init():

    from shutil import rmtree

    import tempfile
    import os

    from thefuck import settings as _settings

    tmp_user_dir = Path(tempfile.mkdtemp())
    os.environ['THEFUCK_CONFIG_PATH'] = tmp_user_dir
    os.environ['THEFUCK_RULES'] = 'echo'
    os.environ['THEFUCK_EXCLUDE_RULES'] = 'echo'
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'False'
    os.environ['THEFUCK_NO_COLOR'] = 'False'
    os.environ['THEFUCK_ALIAS'] = 'fuck'
    os.environ['THEFUCK_WAIT_COMMAND'] = '1'

# Generated at 2022-06-12 10:04:31.370903
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    import shutil
    import os
    import json

    args=None
    settings_path = '.thefuck'
    rules_path = settings_path + '/rules'
    settings_file_path = settings_path + '/settings.py'
    os.environ['TF_ALTER_HISTORY'] = 'true'
    os.environ['TF_RULES'] = './fuck/you'
    os.environ['TF_PRIORITY'] = './fuck/you=4:./fuck/that=6'


    config_path = tempfile.mkdtemp()
    to_create = [config_path + '/' + i
                 for i in [settings_path, rules_path, settings_file_path]]
    for i in to_create:
        os.makedirs(i)


# Generated at 2022-06-12 10:04:34.655050
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    settings.init(args=True)
    settings_user_dir = settings._get_user_dir_path()
    assert settings.user_dir == settings_user_dir
    assert settings._init_settings_file() == None


# Generated at 2022-06-12 10:04:44.590903
# Unit test for method init of class Settings
def test_Settings_init():

    settings = Settings()
    settings.init()

    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['require_confirmation'] == True
    assert settings['alter_history'] == False
    assert settings['no_colors'] == False
    assert settings['debug'] == False
    assert settings['prioritize_alias'] == False
    assert settings['wait_command'] == 1
    assert settings['wait_slow_command'] == 15
    assert settings['history_limit'] == None
    assert settings['exclude_rules'] == []
    assert settings['repeat'] == False
    assert settings['num_close_matches'] == 3
    assert settings['slow_commands'] == []
    assert settings['excluded_search_path_prefixes'] == []

# Generated at 2022-06-12 10:04:52.345898
# Unit test for method init of class Settings
def test_Settings_init():
    import sys, os

    args = type('', (), {'yes': False, 'debug': False})
    settings.init(args)
    assert settings.rules == const.DEFAULT_RULES

    args.yes = True
    settings.init(args)
    assert settings.require_confirmation == False

    args.debug = True
    settings.init(args)
    assert settings.debug == True

    os.environ['THEFUCK_RULES'] = 'man'
    settings.init(args)
    assert settings.rules == const.DEFAULT_RULES + ['man']

    os.environ['THEFUCK_RULES_DEFAULT'] = 'true'
    settings.init(args)
    assert settings.rules == const.DEFAULT_RULES


# Generated at 2022-06-12 10:05:01.565826
# Unit test for method init of class Settings
def test_Settings_init():
    """set env for test function: Settings.init()."""
    os.environ['WAIT_COMMAND'] = '10'
    os.environ['RULES'] = 'DEFAULT_RULES'
    os.environ['PRIORITY'] = 'fuck:10'
    os.environ['EXCLUDE_RULES'] = 'fuck'
    os.environ['HISTORY_LIMIT'] = '10'
    os.environ['WAIT_SLOW_COMMAND'] = '10'
    os.environ['SLOW_COMMANDS'] = 'fuck'
    os.environ['REQUIRE_CONFIRMATION'] = 'True'
    os.environ['NO_COLOR'] = 'True'
    os.environ['ALTER_HISTORY'] = 'True'
   

# Generated at 2022-06-12 10:05:04.252180
# Unit test for method init of class Settings
def test_Settings_init():
    args = type('', (), {'yes': True, 'debug': True, 'repeat': True})
    settings.init(args)
    assert settings['require_confirmation'] == False
    assert settings['debug'] == True
    assert settings['repeat'] == True

# Generated at 2022-06-12 10:06:04.608227
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import get_logger
    from .logs import DEBUG

    settings.init()
    assert settings.keys() == const.DEFAULT_SETTINGS.keys()
    assert settings.priority == const.DEFAULT_SETTINGS['priority'].copy()
    assert settings.rules == const.DEFAULT_SETTINGS['rules'][:]
    assert settings.exclude_rules == const.DEFAULT_SETTINGS['exclude_rules'][:]
    assert settings.no_colors is False
    assert settings.require_confirmation is True
    assert settings.alter_history is False
    assert settings.repeat is None
    assert settings.history_limit == const.DEFAULT_SETTINGS['history_limit']
    assert settings.wait_command == const.DEFAULT_SETTINGS['wait_command']

# Generated at 2022-06-12 10:06:08.226268
# Unit test for method init of class Settings
def test_Settings_init():
    settings_test = Settings()
    settings_test.init()
    settings_test.init("-y")
    settings_test.init("-y -D debug")
    settings_test.init("-y -D debug -R 10")
    settings_test.init("-y -D debug -R 10 --no-colors")

# Generated at 2022-06-12 10:06:17.645303
# Unit test for method init of class Settings
def test_Settings_init():
    from unittest.mock import patch
    from thefuck.config import Settings
    m_path = "thefuck.config.Settings"
    with patch(m_path + "._setup_user_dir") as m_setup_user_dir,     \
            patch(m_path + "._init_settings_file") as m_init_settings_file, \
            patch(m_path + "._settings_from_file") as m_settings_from_file, \
            patch(m_path + "._settings_from_env") as m_settings_from_env, \
            patch(m_path + "._settings_from_args") as m_settings_from_args:
        settings = Settings()
        settings.init()
        m_setup_user_dir.assert_called_once()
        m_init_settings

# Generated at 2022-06-12 10:06:18.409217
# Unit test for method init of class Settings
def test_Settings_init():
    #test init() with no exception
    settings.init()

# Generated at 2022-06-12 10:06:23.155989
# Unit test for method init of class Settings
def test_Settings_init():
    """Unit test for method init of class Settings"""
    from .tests.utils import Mock, patch

    args = Mock(**{'yes': True, 'debug': None, 'repeat': None})

    from .logs import exception


# Generated at 2022-06-12 10:06:31.440194
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    from thefuck.utils import for_app

    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = Path(tmp_dir)
        settings_path = tmp_dir.joinpath('settings.py')

# Generated at 2022-06-12 10:06:39.832624
# Unit test for method init of class Settings
def test_Settings_init():
    """Test of method init of class Settings"""
    import os
    import shutil
    from .logs import exception

    def test(function):
        """Test function"""
        try:
            function()
        except Exception:
            exception("Test of method init of class Settings failed")

    test_settings_path = 'settings.py'
    user_dir = '.config/thefuck'
    rules = user_dir + '/rules'

    def _del_user_dir():
        """Delete user dir"""
        if os.path.exists(user_dir):
            shutil.rmtree(user_dir)

    def _del_settings():
        """Delete file settings"""
        if os.path.exists(test_settings_path):
            os.remove(test_settings_path)


# Generated at 2022-06-12 10:06:45.821560
# Unit test for method init of class Settings
def test_Settings_init():
    settings_path = settings.user_dir.joinpath('settings.py')
    if not settings_path.is_file():
        with settings_path.open(mode='w') as settings_file:
            settings_file.write(const.SETTINGS_HEADER)
            for setting in const.DEFAULT_SETTINGS.items():
                settings_file.write(u'# {} = {}\n'.format(*setting))
    settings.init()
    assert settings['wait_command'] == 0
    assert settings['require_confirmation'] == False
    assert settings['rules'] == ('git add',)


# Generated at 2022-06-12 10:06:54.116651
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import _log_levels, exception

    test_settings = Settings()
    test_settings.init()

    assert test_settings.user_dir == settings.user_dir
    assert test_settings.rules == settings.rules
    assert test_settings.log_file == settings.log_file
    assert test_settings.priorities == settings.priorities
    assert test_settings.exclude_rules == settings.exclude_rules
    assert test_settings.log_file == settings.log_file
    assert test_settings.log_level == _log_levels[settings.log_level]
    assert test_settings.alter_history == settings.alter_history
    assert test_settings.wait_command == settings.wait_command
    assert test_settings.history_limit == settings.history_limit

# Generated at 2022-06-12 10:07:03.217259
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings({})
    settings.init()
    assert settings['require_confirmation'] == True
    assert settings['no_colors'] == False
    assert settings['alter_history'] == False
    assert settings['instant_mode'] == False
    assert settings['history_limit'] == None
    assert settings['wait_command'] == 1
    assert settings['wait_slow_command'] == 5
    assert settings['prioritize_aliases'] == True
    assert settings['priority'] == {}
    assert settings['exclude_rules'] == []
    assert settings['rules'] == []
    assert settings['rules_dir'] == '$XDG_CONFIG_HOME/thefuck/rules'
    assert settings['excluded_search_path_prefixes'] == []
    assert settings['slow_commands'] == []

# Generated at 2022-06-12 10:08:16.004958
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import shutil
    from tempfile import mkdtemp
    import tempfile
    import sys
    import six
    import re
    import yaml
    # mock some functions
    file_path = 'thefuck.conf'

    def mock_init_settings_file(settings_path):
        with open(settings_path, 'w') as test_file:
            test_file.write(const.SETTINGS_HEADER)

    def mock_setup_user_dir():
        print('mock_setup_user_dir')

    def mock_settings_from_file():
        print('mock_settings_from_file')
        return {'rules': ['mock_rules']}

    def mock_settings_from_env():
        print('mock_settings_from_env')

# Generated at 2022-06-12 10:08:17.354954
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    try:
        settings.init()
    except Exception:
        assert False, 'Settings cannot be initialized'

# Generated at 2022-06-12 10:08:23.739319
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import log_exception

    def _log_exception(message, exc_info):
        assert exc_info == (ValueError, ValueError('smth'), None)
        raise exc_info[1]

    log_exception.side_effect = _log_exception

    try:
        _settings = Settings({})
        _settings.init(args=None)
        assert False
    except ValueError:
        pass

    _settings = Settings({})
    _settings.init(args=argparse.Namespace(**{'yes': True}))
    assert _settings.get('require_confirmation') is False

    _settings = Settings({})
    _settings.init(args=argparse.Namespace(**{'debug': True}))
    assert _settings.get('debug') is True


# Generated at 2022-06-12 10:08:30.378213
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .utils import memoized
    import argparse
    allowed_in_args = ['debug', 'repeat', 'yes']
    allowed_in_env = ['RULES', 'REQUIRE_CONFIRMATION', 'DEBUG',
                      'EXCLUDE_RULES', 'SLOW_COMMANDS',
                      'NO_COLORS', 'HISTORY_LIMIT',
                      'WAIT_SLOW_COMMAND', 'PRIORITY',
                      'ALTER_HISTORY', 'INSTANT_MODE',
                      'EXCLUDE_SEARCH_PATH_PREFIXES',
                      'WAIT_COMMAND', 'NUM_CLOSE_MATCHES']

# Generated at 2022-06-12 10:08:31.872956
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init(['fuck'])
    assert settings['history_limit'] == 1000


# Generated at 2022-06-12 10:08:32.638674
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init(None)

# Generated at 2022-06-12 10:08:40.995134
# Unit test for method init of class Settings
def test_Settings_init():
    from .config import settings
    from .logs import log, clear_logs
    from .utils import wrap_settings
    from .exceptions import InvalidConfiguration

    clear_logs()
    with wrap_settings(dict(accept_env=False)):
        settings.init()
        assert log.call_args_list[-1][0][0] == 'Can\'t load settings from env'
        assert settings['rules'] == const.DEFAULT_RULES
        assert settings['rules_dirs'] == ['~']

    clear_logs()
    with wrap_settings(dict(accept_env=False, user_dir='/non-existent'),):
        settings.init()
        assert settings['rules'] == []

# Generated at 2022-06-12 10:08:45.508114
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import CapturedLogging
    from .utils import get_all_executors

    test_args = Settings({"debug": False})
    test_args.init(Args(yes=True))
    assert not test_args.debug
    assert test_args.require_confirmation
    test_args.init(Args(debug=True))
    assert test_args.debug

    test_settings = Settings({"debug": False})
    old_dir = test_settings.user_dir

    test_settings.init()
    assert test_settings.user_dir == old_dir
    assert not test_settings.debug

    os.environ["DEBUG"] = "true"
    os.environ["RULES"] = "DEFAULT_RULES"
    test_settings.init()
    assert test_settings.debug


# Generated at 2022-06-12 10:08:52.751667
# Unit test for method init of class Settings
def test_Settings_init():
    class FakeArgs(object):
        def __init__(self, yes=None, repeat=None, debug=None):
            self.yes = yes
            self.repeat = repeat
            self.debug = debug

    def test_init_with_empty_args():
        global settings
        settings.init()
        assert settings['rules'] == const.DEFAULT_RULES
        assert settings['history_limit'] == const.DEFAULT_HISTORY_LIMIT
        assert settings['require_confirmation'] == const.DEFAULT_REQUIRE_CONFIRMATION

    def test_init_with_nonempty_args():
        global settings
        settings.init(FakeArgs(yes=True, debug=False, repeat=False))
        assert settings['require_confirmation'] == False
        assert settings['debug'] == False
        assert settings['repeat']

# Generated at 2022-06-12 10:09:00.979136
# Unit test for method init of class Settings
def test_Settings_init():
    """
    Unit test for Settings.init()

    The following files are created in the test:
    'settings.py'
    """
    class FakeArgs(object):
        yes = True
        repeat = None
        debug = False
        files = None
        help = None
        history = None
        print_explanations = False
        seconds = None
        test = None
        version = None
    from .system import TemporaryDirectory

    with TemporaryDirectory() as tmp_dir:
        cwd = os.path.realpath(os.path.curdir)
        os.chdir(tmp_dir)
        settings.init(args=FakeArgs())
        with open('settings.py') as settings_file:
            settings_content = settings_file.read()