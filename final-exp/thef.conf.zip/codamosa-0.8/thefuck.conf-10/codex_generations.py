

# Generated at 2022-06-12 10:01:06.881192
# Unit test for method init of class Settings
def test_Settings_init():
    # Testing init() method of class Settings without args
    settings.init()
    assert settings.wait_command == 3
    assert settings.history_limit == None
    assert settings.require_confirmation is True
    assert settings.no_colors is False
    assert settings.debug is False
    assert settings.repeat is None
    assert settings.slow_commands == []
    assert settings.wait_slow_command is 15
    assert settings.alter_history is False
    assert settings.exclude_rules == []
    assert settings.rules == ['fuck']
    assert settings.num_close_matches == 3
    assert settings.excluded_search_path_prefixes == []
    assert settings.instant_mode is False
    assert settings.priority == {}

    # Testing init() method of class Settings with args

# Generated at 2022-06-12 10:01:17.540955
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import Mock
    def _get_user_dir_path():
        return Path('/tmp/thefuck')
    def _settings_from_file():
        return {'key_file': 'value_file'}
    def _settings_from_env():
        return {'key_env': 'value_env'}
    def _settings_from_args(args):
        return {'key_args': 'value_args'}

    settings = Settings()
    settings._get_user_dir_path = _get_user_dir_path
    settings._settings_from_file = _settings_from_file
    settings._settings_from_env = _settings_from_env
    settings._settings_from_args = _settings_from_args

# Generated at 2022-06-12 10:01:26.333522
# Unit test for method init of class Settings
def test_Settings_init():
    args = object()
    settings = Settings()
    settings.init(args)
    assert settings.debug is False
    assert settings.require_confirmation is True
    assert settings.repeat is 1
    assert settings.no_colors is False
    assert settings.alter_history is False
    assert settings.wait_command is 3
    assert settings.wait_slow_command is 15
    assert set(settings.exclude_rules) == set()
    assert set(settings.rules) == const.DEFAULT_RULES
    assert settings.priority == {}
    assert settings.instant_mode is False
    assert set(settings.excluded_search_path_prefixes) == set()
    assert set(settings.slow_commands) == set()
    assert settings.history_limit is 1000


# Generated at 2022-06-12 10:01:35.834327
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.questions_path.name == 'questions.json'
    assert settings.no_colors == False
    assert settings.require_confirmation == True
    assert settings.priority == {}
    assert settings.wait_command == 0
    assert settings.wait_slow_command == 3
    assert settings.debug == False
    assert settings.instant_mode == False
    assert settings.history_limit == None
    assert settings.num_close_matches == 3
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []

# Generated at 2022-06-12 10:01:42.224126
# Unit test for method init of class Settings
def test_Settings_init():
    # Also test deprecated '~/.thefuck' path
    global settings
    settings = Settings(const.DEFAULT_SETTINGS)
    legacy_user_dir = Path('~', '.thefuck').expanduser()
    user_dir = Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'),
                    'thefuck').expanduser()
    settings.init()
    assert settings.user_dir == legacy_user_dir
    settings.init()
    assert settings.user_dir == user_dir
    settings.init(argparse.Namespace(yes=True, debug=True, repeat=2))
    assert settings.user_dir == user_dir
    assert settings.require_confirmation == False
    assert settings.debug == True
    assert settings.repeat == 2



# Generated at 2022-06-12 10:01:52.247974
# Unit test for method init of class Settings
def test_Settings_init():
    from thefuck.rules.git_branch_merged_into_master import match, get_new_command
    from thefuck.rules.git_repo_clean import match, get_new_command
    from thefuck.rules.git_not_pushed import match, get_new_command
    from thefuck.rules.git_not_pulled import match, get_new_command
    from thefuck.rules.git_branch_exists import match, get_new_command

    test_settings = Settings(const.DEFAULT_SETTINGS)
    test_settings.init({'settings_file':['/home/jojo/.thefuck/settings.py']})

    # Test defaults

# Generated at 2022-06-12 10:01:59.284972
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import reverse

    args = type(u'test', (), {u'yes': True, u'debug': True, u'repeat': True})()
    settings.init(args)
    assert settings.require_confirmation == False
    assert settings.debug == True
    assert settings.repeat == True
    assert settings.alter_history == False
    assert settings.wait_slow_command == 10
    # Here we replace the log by a mockup to avoid printing to stdout
    settings.log = reverse
    settings.init()

# Generated at 2022-06-12 10:02:02.280161
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.get('rules') == ['sudo_rm_rf', 'git_push_current_branch',
                                     'python_command', 'man', 'brew_install']


# Generated at 2022-06-12 10:02:09.958080
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings._get_user_dir_path = lambda: Path('.')
    settings.rules = ['test1']
    settings._init_settings_file()
    settings.init()
    assert settings.rules == ['test1']
    text = open('settings.py').read()
    assert text.startswith('# -*- coding: utf-8 -*-\n')
    assert text.endswith(
        '# require_confirmation = True\n')


# Generated at 2022-06-12 10:02:18.846870
# Unit test for method init of class Settings
def test_Settings_init():
    from .utils import CaptureOutput
    from .system import TemporaryDirectory
    from .main import no_colors
    from .logs import debug

    def call_TheFuck_with(**kwargs):
        class Args(object):
            pass
        args = Args()
        for key, value in kwargs.items():
            setattr(args, key, value)

# Generated at 2022-06-12 10:03:06.060641
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import get_aliases, reset_all_commands, get_history
    from .utils import get_closest, filter_wait_commands
    from .cmds import run

    settings.init(args=True)
    assert settings.verbose
    assert settings.correct_usage
    assert settings.instant_mode
    assert settings.no_colors
    assert settings.require_confirmation
    assert settings.wait_command
    assert settings.wait_slow_command
    assert settings.debug
    assert settings.cache_size
    assert settings.priority
    assert settings.rules
    assert settings.exclude_rules
    assert settings.slow_commands
    assert settings.excluded_search_path_prefixes
    assert settings.sudo_command
    assert settings.history_limit


# Generated at 2022-06-12 10:03:10.988834
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init(args=None)
    assert settings._get_user_dir_path() == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir == settings._get_user_dir_path()
    settings.init(args=None)
    assert settings == const.DEFAULT_SETTINGS


# Generated at 2022-06-12 10:03:16.101598
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings['settings_path'] == Path('~/.config/thefuck/settings.py').expanduser()
    assert settings['wait_command'] == 3
    assert settings['rules_dir'] == [Path('~/.config/thefuck/rules').expanduser().as_posix()]
    assert settings['wait_slow_command'] == 7
    assert settings['no_colors'] == False
    assert settings['require_confirmation'] == True
    assert settings['debug'] == False
    assert settings['rules'] == ['~/.config/thefuck/rules/git.py', '~/.config/thefuck/rules/pip.py', '~/.config/thefuck/rules/python.py']
    assert settings['exclude_rules'] == []

# Generated at 2022-06-12 10:03:24.265610
# Unit test for method init of class Settings
def test_Settings_init():
    import mock

    user_dir = mock.MagicMock()

    args = mock.MagicMock()
    args.yes = False
    args.debug = False
    args.repeat = None

    settings_module = mock.MagicMock()
    settings_module.RULES = ['cat', 'cd']
    settings_module.EXCLUDE_RULES = []
    settings_module.WAIT_COMMAND = True
    settings_module.HISTORY_LIMIT = True
    settings_module.PRIORITY = {}
    settings_module.SUDO_COMMAND = 'sudo -A'
    settings_module.REQUIRE_CONFIRMATION = True
    settings_module.NO_COLORS = True
    settings_module.DEBUG = False
    settings_module.ALTER_HISTORY = True
   

# Generated at 2022-06-12 10:03:33.192713
# Unit test for method init of class Settings
def test_Settings_init():
    # Given we have a fake settings file
    settings = _fake_settings_file()
    # And we have a fake args
    args = _fake_args()

    output = settings.init(args)

    # Then we're able to read all settings from settings.py
    assert output['priority'] == {'echo': 50, 'cd': 63}
    assert output['require_confirmation'] == False
    assert output['no_colors'] == False
    assert output['wait_command'] == 1
    assert output['wait_slow_command'] == 15
    assert output['history_limit'] == 100
    assert output['exclude_rules'] == ['cd_parent', 'git_push', 'sudo']
    assert output['alter_history'] == False
    assert output['instant_mode'] == False

# Generated at 2022-06-12 10:03:39.254895
# Unit test for method init of class Settings
def test_Settings_init():
    import mock
    from six import StringIO

    settings = Settings()
    with mock.patch.object(settings, '_settings_from_env') as mock_from_env:
        with mock.patch.object(settings, '_settings_from_file') as mock_from_file:
            with mock.patch.object(settings, '_settings_from_args') as mock_from_args:
                settings.init()
                assert mock_from_env.call_count == 1
                assert mock_from_file.call_count == 1
                assert mock_from_args.call_count == 1
                assert mock_from_args.call_args[0][0] is None
                assert mock_from_args.call_args[1] == {}

    settings = Settings()

# Generated at 2022-06-12 10:03:45.690132
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.get("require_confirmation") == True
    assert settings.get("repeat") == False
    assert settings.get("history_limit") == None
    assert settings.get("wait_command") == 0
    assert settings.get("wait_slow_command") == 3
    assert settings.get("rules") == const.DEFAULT_RULES
    assert settings.get("debug") == False
    assert settings.get("no_colors") == False
    assert settings.get("use_notify") == True
    assert settings.get("help_command") == 'fuck'
    assert settings.get("exclude_rules") == []
    assert settings.get("priority") == {}
    assert settings.get("alter_history") == False

# Generated at 2022-06-12 10:03:53.759061
# Unit test for method init of class Settings
def test_Settings_init():
    args = object()
    s = Settings
    s._setup_user_dir = lambda x: None
    s._init_settings_file = lambda x: None
    s._settings_from_file = lambda: {'rules': [], 'exclude_rules': []}
    s._settings_from_env = lambda: {'rules': [], 'exclude_rules': []}
    s._settings_from_args = lambda x: {'rules': [], 'exclude_rules': []}

    s.init(args)
    assert s._settings_from_args.call_args == (args,)
    assert s._settings_from_file.call_args == ()
    assert s._settings_from_env.call_args == ()
    assert s._init_settings_file.call_args == ()
    assert s._setup_user

# Generated at 2022-06-12 10:04:00.936867
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    args = {'yes': True}
    settings.init(args)
    assert not settings.get('require_confirmation')
    assert not settings.get('debug')
    args = {'debug': True}
    settings.init(args)
    assert settings.get('debug')
    assert not settings.get('repeat')
    args = {'repeat': 'hi'}
    settings.init(args)
    assert settings.get('repeat') == 'hi'


settings.init()
settings.rules = [os.path.join(settings.user_dir, 'rules', rule)
                  for rule in settings.rules]



# Generated at 2022-06-12 10:04:10.359634
# Unit test for method init of class Settings
def test_Settings_init():
    import pytest
    from .logs import exception

    tmp_user_dir = Path(__file__).parent.joinpath('test_init_user_dir')
    tmp_settings_path = tmp_user_dir.joinpath('settings.py')
    env = os.environ
    args = set()

    def _test_init():
        settings.init(args)

    # test if user_dir is created and settings file is created
    def test_user_dir(monkeypatch):
        def mock_get_user_dir_path():
            return tmp_user_dir
        monkeypatch.setattr(settings, '_get_user_dir_path', mock_get_user_dir_path)
        
        _test_init()
        assert tmp_user_dir.is_dir()

# Generated at 2022-06-12 10:05:06.508185
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir
    assert settings.rules


# Generated at 2022-06-12 10:05:12.533683
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    from .logs import exception
    from .logs import warning

    settings.init()

# Generated at 2022-06-12 10:05:21.484997
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    from .logs import capture_logs
    from .system import create_file

    user_dir = Path('test_settings')
    if not user_dir.exists():
        user_dir.mkdir()

    create_file(user_dir.joinpath('settings.py'),
                const.SETTINGS_HEADER + 'require_confirmation = False')

    os.environ['THEFUCK_REPEAT'] = 'True'

    settings.init(args=settings)
    assert not settings.require_confirmation
    assert settings.repeat

    with capture_logs() as logs:
        settings.init(args=None)
        assert not logs


# Generated at 2022-06-12 10:05:29.987163
# Unit test for method init of class Settings
def test_Settings_init():
    global settings

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()

    assert settings.user_dir == Path(
        os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 0
    assert settings.history_limit == None
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.instant_mode == False

# Generated at 2022-06-12 10:05:36.163837
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.get("rules") == ['git_push', 'git_commit', 'git_amend',
                                     'sudo', 'cd', 'ls', 'cp', 'mkdir',
                                     'rm', 'venv', 'virtualenv', 'pip', 'git_rebase_local']
    assert settings.get("require_confirmation") is False
    assert settings.get("no_colors") is True
    assert settings.get("debug") is False
    assert settings.get("alter_history") is True
    assert settings.get("wait_command") == 1
    assert settings.get("wait_slow_command") == 15
    assert settings.get("env") == {}
    assert settings.get("instant_mode") is False

# Generated at 2022-06-12 10:05:42.776153
# Unit test for method init of class Settings
def test_Settings_init():
    import sys
    import os
    import shutil

    config_dir = Path('./config_dir')
    sys.modules['settings'] = None
    _settings = Settings(const.DEFAULT_SETTINGS)
    _settings.user_dir = config_dir

    if not config_dir.is_dir():
        config_dir.mkdir()

    try:
        _settings.init()
        assert _settings['require_confirmation'] == True
    finally:
        # Clean up
        if config_dir.is_dir():
            shutil.rmtree(config_dir)

# Generated at 2022-06-12 10:05:50.535510
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch
    from thefuck.settings import DEFAULT_SETTINGS, ENV_TO_ATTR

    settings_init = Settings().init
    with patch('thefuck.settings.Settings._settings_from_file',
               return_value={'rules': ['fuck'], 'priority': {'fuck': 1000}}):
        with patch('thefuck.settings.Settings._settings_from_env',
                   return_value={'verbose': True, 'wait_command': 1000}):
            with patch('thefuck.settings.Settings._settings_from_args',
                       return_value={'yes': False, 'repeat': 'foo'}):
                settings_init()

# Generated at 2022-06-12 10:05:59.123103
# Unit test for method init of class Settings
def test_Settings_init():
    sys.argv = ['thefuck']
    settings.init()
    assert settings['require_confirmation']
    assert settings['priority'] == const.DEFAULT_PRIORITY
    assert settings['rules'] == const.DEFAULT_RULES

    os.environ['THEFUCK_WAIT_COMMAND'] = '0'
    os.environ['THEFUCK_RULES_FROM_ENV'] = ':'.join(['DEFAULT_RULES', 'use_sudo'])
    os.environ['THEFUCK_PRIORITY_FROM_ENV'] = 'use_sudo=1'
    settings.init()
    assert not settings['wait_command']
    assert settings['rules'] == ['use_sudo'] + const.DEFAULT_RULES

# Generated at 2022-06-12 10:06:00.596904
# Unit test for method init of class Settings
def test_Settings_init():
    def init_test():
        new_settings = Settings()
        new_settings.init()
        return new_settings
    init_test()

# Generated at 2022-06-12 10:06:08.375744
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .const import SETTINGS_HEADER
    from .system import Path
    from imp import load_source
    from mock import patch
    from os import environ
    from unittest import TestCase
    import sys
    import warnings

    warnings.simplefilter("ignore", ResourceWarning)

    class TestCase(TestCase):
        def test_settings_file(self):
            user_dir_path = Path('~/.config/thefuck').expanduser()
            settings_file_path = user_dir_path.joinpath('settings.py')
            user_dir_path.mkdir(parents=True)
            self.addCleanup(user_dir_path.rmtree)

            assert not settings_file_path.is_file()
            settings.init()
            assert settings_file_path

# Generated at 2022-06-12 10:08:43.885089
# Unit test for method init of class Settings

# Generated at 2022-06-12 10:08:49.118838
# Unit test for method init of class Settings
def test_Settings_init():
    class ArgParser():
        def __init__(self, repeat=None, debug=None, yes=None):
            self.repeat = repeat
            self.debug = debug
            self.yes = yes

    import tempfile
    import shutil
    from .logs import disable_log_to_file
    from .logs import enable_log_to_file
    from .logs import _log_file_path

    settings.init()
    assert settings['repeat'] == 1
    assert settings['debug'] == False
    assert settings['require_confirmation'] == True
    assert settings['alter_history'] == False
    assert settings['instant_mode'] == False
    assert settings['wait_command'] == 1
    assert settings['wait_slow_command'] == 15
    assert settings['history_limit'] == 10

# Generated at 2022-06-12 10:08:50.202130
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    settings.init()



# Generated at 2022-06-12 10:08:58.182252
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    settings.init(args=None)
    assert settings.user_dir, Path('~/.config/thefuck').expanduser()
    assert settings.require_confirmation, True
    assert settings.debug, False
    assert settings.wait_command, 0
    assert settings.rules, []
    assert settings.wait_slow_command, 2
    assert settings.slow_commands, []
    assert settings.exclude_rules, []
    assert settings.alter_history, True
    assert settings.no_colors, False
    assert settings.repeat, False
    assert settings.history_limit, None
    assert settings.instant_mode, False
    assert settings.priority, {}
    assert settings.excluded_search_path_prefixes, const.DEFAULT_EXCLUDED_SEARCH_PATH_PREFIXES

# Generated at 2022-06-12 10:09:05.053047
# Unit test for method init of class Settings
def test_Settings_init():
    _user_dir = settings.user_dir
    _settings_from_env = settings._settings_from_env
    _settings_from_file = settings._settings_from_file
    _settings_from_args = settings._settings_from_args

    settings.init()
    assert settings.user_dir == _user_dir
    assert settings._settings_from_env == _settings_from_env
    assert settings._settings_from_file == _settings_from_file
    assert settings._settings_from_args == _settings_from_args
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.history_limit == 0
    assert settings.require_confirmation is True



# Generated at 2022-06-12 10:09:06.669291
# Unit test for method init of class Settings
def test_Settings_init():
    settings.clear()
    settings.init()
    assert settings == const.DEFAULT_SETTINGS


# Generated at 2022-06-12 10:09:14.840684
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch


# Generated at 2022-06-12 10:09:18.406958
# Unit test for method init of class Settings
def test_Settings_init():
    def test_func():
        pass
    sys.argv = [test_func.__name__]
    settings.init()
    assert settings['require_confirmation'] == True
    assert settings['rules'] == const.DEFAULT_RULES


# Generated at 2022-06-12 10:09:22.290322
# Unit test for method init of class Settings
def test_Settings_init():
    """ Unit test for method init of class Settings """
    from .logs import exception
    from .system import get_aliases
    settings.init()
    settings._init_settings_file()
    try:
        settings.update(settings._settings_from_file())
    except Exception:
        exception("Can't load settings from file", sys.exc_info())
    settings.update(settings._settings_from_env())
    settings.update(settings._settings_from_args(get_aliases()))


# Generated at 2022-06-12 10:09:24.554447
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.user_dir == settings._get_user_dir_path()
    settings.update(settings._settings_from_args())

    os.environ['THEFUCK_RULES'] = 'bash'
    assert settings._rules_from_env('bash') == ['bash']

