

# Generated at 2022-06-12 10:01:23.031006
# Unit test for method init of class Settings
def test_Settings_init():
    """
    Checks if the environment variables are correctly parsed.
    """
    import tempfile
    import os
    from thefuck.types import Setting, PriorityMap


# Generated at 2022-06-12 10:01:33.835064
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import sys

    test_args = ['thefuck', 'wrong_command', '--yes']
    test_env = {'THEFUCK_DEBUG': 'true', 'PATH': ''}

# Generated at 2022-06-12 10:01:38.112278
# Unit test for method init of class Settings
def test_Settings_init():
    fake_args = type('', (), {})
    fake_args.yes = False
    fake_args.debug = False
    fake_args.repeat = None
    fake_args.settings_file = None

    settings.init(fake_args)


# Generated at 2022-06-12 10:01:48.110474
# Unit test for method init of class Settings
def test_Settings_init():
    global settings

    settings.init()
    assert settings.log_file == '/tmp/thefuck.log'
    assert settings.rules == ['fuck_simple']
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.wait_command == 3
    assert settings.alter_history == True
    assert settings.no_colors == False
    assert settings.wait_slow_command == 20
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew']
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == None
    assert settings.instant_mode == False
    assert settings.num_close_matches == 3

# Generated at 2022-06-12 10:01:55.268406
# Unit test for method init of class Settings
def test_Settings_init():
    settings_py = 'user_dir = \'abc\''
    user_dir = 'test_user_dir'
    os.environ['THEFUCK_WAIT_SLOW_COMMAND'] = '101'

    with settings.user_dir.joinpath('settings.py').open(mode='w') as settings_file:
        settings_file.write(settings_py)

    args = type('', (object,), {'yes': True, 'repeat': False})
    settings.init(args)

    assert(settings['user_dir'] == 'abc')
    assert(settings['require_confirmation'] == False)
    assert(settings['wait_slow_command'] == 101)
    assert(settings['repeat'] == False)

# Generated at 2022-06-12 10:02:05.056236
# Unit test for method init of class Settings
def test_Settings_init():
    # Args
    import argparse
    args = argparse.Namespace()
    args.yes = True
    args.debug = True
    # User config dir
    settings.user_dir = Path('/home/sophia/config-thefuck')
    settings.user_dir.joinpath('settings.py').touch()
    # Env
    os.environ['TF_COLOR_OUTPUT'] = 'True'
    os.environ['TF_RULE_SEARCH_PREFIX'] = 'mypy'
    # Expected settings
    expected_settings = {
        'DEBUG': True,
        'COLOR_OUTPUT': True,
        'REQUIRE_CONFIRMATION': False,
        'RULE_SEARCH_PREFIX': ['mypy']
    }
    # Test method init of class Settings

# Generated at 2022-06-12 10:02:15.079124
# Unit test for method init of class Settings
def test_Settings_init():
    """
    Settings.init(args=None) should update the settings in const.DEFAULT_SETTINGS
    with values from const.ENV_TO_ATTR if there are environment variables for them
    """
    from .logs import exception


# Generated at 2022-06-12 10:02:22.534877
# Unit test for method init of class Settings
def test_Settings_init():
  from .rules import RulesCollection
  from .history import History
  from .logs import ColoredFormatter, Logger
  from .utils import wait_output
  from .notify import Notify

  sys.modules['thefuck.settings'] = Settings(const.DEFAULT_SETTINGS)
  sys.modules['thefuck.rules'] = RulesCollection()
  sys.modules['thefuck.history'] = History()
  sys.modules['thefuck.logs'] = Logger(formatter=ColoredFormatter())
  sys.modules['thefuck.utils'] = wait_output
  sys.modules['thefuck.notify'] = Notify()

  test_settings = sys.modules['thefuck.settings']
  test_settings.init(None)


# Generated at 2022-06-12 10:02:31.983903
# Unit test for method init of class Settings
def test_Settings_init():
    """
    Tests that Settings() works correctly with the environment
    """
    from .logs import _exception_handler

    # Make a new test-settings object
    class TestSettings(Settings):
        def __init__(self):
            Settings.__init__(self, const.DEFAULT_SETTINGS)
            self.update({
                'history_limit': 9999,
                'require_confirmation': True,
                'no_colors': True,
                'alter_history': True,
                'debug': False,
                'instant_mode': False,
                'wait_command': 3,
                'wait_slow_command': 7,
                'num_close_matches': 2,
                'repeat': False
                })
    settings = TestSettings()

    # Mock the user_dir variable
    settings.user_

# Generated at 2022-06-12 10:02:41.270679
# Unit test for method init of class Settings
def test_Settings_init():
    # Mock sys.argv
    from unittest.mock import patch
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--yes', action='store_true')
    parser.add_argument('--repeat', type=int)
    parser.add_argument('--debug', action='store_true')
    args = parser.parse_args(['--yes', '--debug'])

    # Create a temp dir for settings
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from . import const
    with TemporaryDirectory() as temp_dir:
        temp_user_dir = Path(temp_dir).joinpath('.thefuck')
        temp_user_dir.mkdir()
        settings_file = temp_user_dir.joinpath('settings.py')

# Generated at 2022-06-12 10:03:08.536352
# Unit test for method init of class Settings
def test_Settings_init():
    s = Settings(const.DEFAULT_SETTINGS)
    s.init()
    assert s.get('require_confirmation')

    from .logs import test as test_logs
    test_logs.patch_for_test()
    s = Settings(const.DEFAULT_SETTINGS)
    del s.user_dir
    s.init()
    assert s.user_dir



# Generated at 2022-06-12 10:03:19.177373
# Unit test for method init of class Settings
def test_Settings_init():
    """Testing method init of class Settings."""
    import tempfile
    from .logs import exception

    # Setup
    settings._settings_from_env = lambda: {'require_confirmation': True}
    rules_dir = tempfile.TemporaryDirectory()
    settings_path = os.path.join(rules_dir.name, 'settings.py')
    settings.user_dir = Path(rules_dir.name)

    # Exception in _init_settings_file
    exception.called = False
    with open(settings_path, mode='w') as settings_file:
        settings_file.write(const.SETTINGS_HEADER)
        for setting in const.DEFAULT_SETTINGS.items():
            settings_file.write(u'# {} = {}\n'.format(*setting))

# Generated at 2022-06-12 10:03:21.794147
# Unit test for method init of class Settings
def test_Settings_init():
    test_args = type('', (), {'debug': True, 'repeat': 4})

    settings.init(test_args)
    assert settings['debug'] is True
    assert settings['repeat'] == 4

# Generated at 2022-06-12 10:03:24.327540
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.init()
    assert settings.init(args = ['--yes'])
    assert settings.init(args = ['--debug'])
    assert settings.init(args = ['--repeat'])

# Generated at 2022-06-12 10:03:26.926402
# Unit test for method init of class Settings
def test_Settings_init():
    import six

    if six.PY2:
        assert isinstance(settings.init(), dict)
    else:
        assert isinstance(settings.init(), Settings)

# Generated at 2022-06-12 10:03:35.066907
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert isinstance(settings.user_dir, Path)
    assert settings.user_dir.is_dir()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.user_dir in settings.rules_dir
    assert settings.rules_dir.joinpath('thefuck').is_dir()
    assert settings.rules_dir.joinpath('custom').is_dir()
    assert settings.rules_dir.joinpath('python').is_dir()
    assert isinstance(settings.rules, list)
    assert isinstance(settings.priority, dict)
    assert isinstance(settings.require_confirmation, bool)
    assert isinstance(settings.slow_commands, list)
    assert isinstance(settings.no_colors, bool)

# Generated at 2022-06-12 10:03:42.045395
# Unit test for method init of class Settings
def test_Settings_init():
    from unittest.mock import patch

    with patch('thefuck.conf.load_source') as load_source_mock, \
            patch('thefuck.conf.warn'), \
            patch('thefuck.conf.Path') as PathMock, \
            patch('thefuck.conf.os'), \
            patch('builtins.open', create=True) as open_mock:

        # mock Path constructor to return mocked Path object
        PathMock.return_value = PathMock

        # mock Path.is_dir
        PathMock.is_dir.return_value = False

        os.environ.get.return_value = '.config/thefuck'

        # mock settings.py file
        open_mock.side_effect = ['settings', 'settings_content']

        PathMock().joinpath.return_value

# Generated at 2022-06-12 10:03:51.250479
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    import shutil

    loaded_settings = Settings(const.DEFAULT_SETTINGS)

    with tempfile.TemporaryDirectory() as tmp:
        xdg_config_home = Path(tmp)
        user_dir = xdg_config_home.joinpath('thefuck')
        user_dir.mkdir()
        settings_path = user_dir.joinpath('settings.py')
        with settings_path.open('w') as f:
            f.write(const.SETTINGS_HEADER)
            # Add custom settings to settings file
            for key in const.DEFAULT_SETTINGS.keys():
                if key == 'require_confirmation':
                    f.write('require_confirmation = False\n')

# Generated at 2022-06-12 10:03:55.066902
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init({'yes':True, 'debug':True, 'repeat':'abc'})

    assert settings['require_confirmation'] == False
    assert settings['debug'] == True
    assert settings['repeat'] == 'abc'


# Unit tests for method _get_user_dir_path of class Settings

# Generated at 2022-06-12 10:04:03.554229
# Unit test for method init of class Settings
def test_Settings_init():
    def _test_settings_from_env():
        s = Settings()
        os.environ['THEFUCK_RULES'] = ':'.join(['test_rule1', 'test_rule2'])
        os.environ['THEFUCK_PRIORITY'] = 'test_rule2=666'
        s.init()
        assert s.rules == ['test_rule1', 'test_rule2']
        assert s.priority['test_rule2'] == 666

    _test_settings_from_env()
    if 'THEFUCK_RULES' in os.environ:
        del os.environ['THEFUCK_RULES']
    if 'THEFUCK_PRIORITY' in os.environ:
        del os.environ['THEFUCK_PRIORITY']

# Generated at 2022-06-12 10:04:34.173619
# Unit test for method init of class Settings
def test_Settings_init():
    """Check class Settings"""
    const.DEFAULT_SETTINGS['rules'] = 'default_rules'
    const.DEFAULT_SETTINGS['alias'] = 'fuck'
    const.DEFAULT_SETTINGS['no_colors'] = True
    const.DEFAULT_SETTINGS['priority'] = {'wrong_command': 1000}
    const.DEFAULT_SETTINGS['wait_slow_command'] = 5
    const.DEFAULT_SETTINGS['require_confirmation'] = False
    const.DEFAULT_SETTINGS['slow_commands'] = ['ls']

    const.ENV_TO_ATTR['THEFUCK_RULES'] = 'rules'
    const.ENV_TO_ATTR['THEFUCK_ALIAS'] = 'alias'

# Generated at 2022-06-12 10:04:43.974481
# Unit test for method init of class Settings
def test_Settings_init():
    from tempfile import TemporaryDirectory
    from shutil import copyfile
    from os import environ


    original_environment = environ.copy()


# Generated at 2022-06-12 10:04:50.321633
# Unit test for method init of class Settings
def test_Settings_init():
    s = Settings(const.DEFAULT_SETTINGS)
    s._val_from_env = lambda x, y: x
    s._settings_from_env = lambda: {'RULES': 'RULE_PATH'}
    s._settings_from_file = lambda: {'RULES': 'FILE_PATH'}
    s._settings_from_args = lambda y=None: {'RULES': 'ARGS_PATH'}
    s.init()
    assert s['RULES'] == 'ARGS_PATH'

if __name__ == '__main__':
    test_Settings_init()

# Generated at 2022-06-12 10:04:55.746664
# Unit test for method init of class Settings
def test_Settings_init():
    from .pycompat import StringIO
    from .logs import exception

    stderr = StringIO()
    stdout = StringIO()
    settings = Settings({'user_dir': 'test_dir'})
    settings.update(const.DEFAULT_SETTINGS)
    settings.init()

    stdout_text = stdout.getvalue()
    stderr_text = stderr.getvalue()
    assert stdout_text == ''
    assert stderr_text == ''



# Generated at 2022-06-12 10:04:56.901951
# Unit test for method init of class Settings
def test_Settings_init():
    if not settings.init():
        assert True

# Generated at 2022-06-12 10:04:58.689280
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.init() == 'default_settings'


# Generated at 2022-06-12 10:05:06.701640
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import print_command
    from .logs import print_exception
    from .logs import print_result
    from .logs import print_rewrite

    import sys
    import six
    import mock

    def get_out(function):
        out = six.StringIO()
        sys.stdout = out
        function()
        return out.getvalue().strip()

    def get_err(function):
        err = six.StringIO()
        sys.stderr = err
        function()
        return err.getvalue().strip()

    rules_dir = settings.user_dir.joinpath('rules')

    empty_file = rules_dir.joinpath('settings.py')
    empty_file.touch()
    rules_dir.rmdir()

    settings.init()

    # We are using mock

# Generated at 2022-06-12 10:05:08.921486
# Unit test for method init of class Settings
def test_Settings_init():
    pass

    # Unit test for method _init_settings_file of class Settings
    def test__init_settings_file(monkeypatch):
        monkeypatch.setattr(Settings, 'user_dir', None)
        settings = Settings()
        assert len(settings.init()) == 0



# Generated at 2022-06-12 10:05:19.650997
# Unit test for method init of class Settings
def test_Settings_init():
    """
    unittest for method `__init__` of class `Settings`

    """

    from tests.test_rules import MockPattern, MockRule

    # Initialize a Settings object to test, and clear the environment variables
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()

    # Test settings from `settings.py`, the settings from env and args are empty
    settings = Settings(const.DEFAULT_SETTINGS)
    settings_from_file = settings._settings_from_file()
    settings.init()
    assert settings == settings_from_file

    # Test settings from environment variables
    settings = Settings(const.DEFAULT_SETTINGS)
    os_environ_backup = dict(os.environ)

# Generated at 2022-06-12 10:05:22.071791
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.user_dir.is_dir()

    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['slow_command_time'] == 3


# Generated at 2022-06-12 10:05:52.598434
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings['history_limit'] == const.DEFAULT_SETTINGS['history_limit']
    assert settings['use_notify2'] == const.DEFAULT_SETTINGS['use_notify2']
    settings.init(['--yes'])

# Generated at 2022-06-12 10:05:54.639266
# Unit test for method init of class Settings
def test_Settings_init():
    _settings = Settings()
    assert _settings.update(const.DEFAULT_SETTINGS) == None

# Generated at 2022-06-12 10:06:01.123579
# Unit test for method init of class Settings
def test_Settings_init():
    """Test for method init of class Settings."""
    import os
    import shutil
    from .logs import LOG_FORMAT
    from .system import Path

    settings = Settings(const.DEFAULT_SETTINGS)

# Generated at 2022-06-12 10:06:04.058731
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import _log as log
    from mock import Mock

    settings.init(Mock(yes=True, debug=True, repeat=True))
    assert settings['require_confirmation'] == False
    assert settings['debug'] == True
    assert settings['repeat'] == True

# Generated at 2022-06-12 10:06:06.746043
# Unit test for method init of class Settings
def test_Settings_init():
    result = Settings(const.DEFAULT_SETTINGS)
    result.init("args")
    assert result.get("require_confirmation") == False
    assert result.get("debug") == "args"
    assert result.get("repeat") == "args"

# Generated at 2022-06-12 10:06:13.307063
# Unit test for method init of class Settings
def test_Settings_init():
    import sys
    import tempfile

    tempdir = tempfile.mkdtemp()
    user_dir = Path(tempdir, 'thefuck')
    os.makedirs(user_dir)
    settings_file = user_dir.joinpath('settings.py')
    with settings_file.open(mode='w') as f:
        f.write('# require_confirmation = True')

    os.environ['TF_REPEAT'] = 'True'
    os.environ['TF_DEBUG'] = 'True'
    os.environ['TF_REQUIRE_VERIFICATION'] = 'False'

    sys.argv = ['thefuck', '--yes', '--debug', '--repeat']
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()

# Generated at 2022-06-12 10:06:21.915547
# Unit test for method init of class Settings
def test_Settings_init():
    # Create a mock .thefuck directory
    user_dir = Path('/tmp/.thefuck')
    rules_dir = user_dir.joinpath('rules')
    if not user_dir.is_dir():
        user_dir.mkdir()
    if not rules_dir.is_dir():
        rules_dir.mkdir()

    # Create a mock settings file
    settings_file = user_dir.joinpath('settings.py')
    with settings_file.open(mode='w') as f:
        f.write(const.SETTINGS_HEADER)
        f.write('rules = DEFAULT_RULES\n')
        f.write('require_confirmation = False')

    # Create a mock environment
    import os
    os.environ['LANG'] = 'en_US.UTF-8'
   

# Generated at 2022-06-12 10:06:30.300260
# Unit test for method init of class Settings
def test_Settings_init():
    from . import __version__
    from .logs import exception

    settings.update({'require_confirmation': False,
                     'wait_command': 1,
                     'history_limit': 1,
                     'wait_slow_command': 1,
                     'num_close_matches': 1,
                     'require_confirmation': True,
                     'no_colors': True,
                     'debug': True,
                     'alter_history': True,
                     'instant_mode': True,
                     'slow_commands': ['ls'],
                     'excluded_search_path_prefixes': ['/usr/local'],
                     'rules': ['echo<space><text>'],
                     'exclude_rules': ['echo<text>'],
                     'priority': {'echo<text>': 2},
                     'repeat': 1})


# Generated at 2022-06-12 10:06:33.480406
# Unit test for method init of class Settings
def test_Settings_init():
    # This is not a full unit test, just a test of init method
    settings.clear()
    # mock.patch the default settings
    with mock.patch.dict(const.DEFAULT_SETTINGS, {'key': 'value'}):
        settings.init()
    assert settings == {'key': 'value'}

# Generated at 2022-06-12 10:06:34.675874
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    settings.init()

    assert exception.called

# Generated at 2022-06-12 10:07:31.298228
# Unit test for method init of class Settings
def test_Settings_init():
    # Setup
    args = type('', (), {'yes': True, 'debug': True, 'repeat': 3})
    os.environ.update(const.ENV_TO_ATTR)

    # Test
    settings.init(args)

    # Assert
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == const.DEFAULT_EXCLUDE_RULES
    assert settings.require_confirmation == False
    assert settings.no_colors == True
    assert settings.debug == True
    assert settings.alter_history == False
    assert settings.history_limit == 50
    assert settings.prioritize_match == False

# Generated at 2022-06-12 10:07:39.795891
# Unit test for method init of class Settings
def test_Settings_init():
    instance = Settings(const.DEFAULT_SETTINGS)
    instance.init()
    assert isinstance(instance, Settings)
    assert settings.user_dir == settings._get_user_dir_path()
    settings_path = settings.user_dir.joinpath('settings.py')
    assert settings_path.is_file()
    with settings_path.open() as settings_file:
        assert const.SETTINGS_HEADER == settings_file.readline()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation is True
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.no_colors is False
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10

# Generated at 2022-06-12 10:07:45.658202
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    settings._init_settings_file()
    settings._setup_user_dir()
    assert settings._get_user_dir_path().exists()

    settings.init()
    assert settings['require_confirmation']

    # TODO: Fix this test
    # with pytest.raises(exception):
        # settings.init(args=['--rule', 'test'])



# Generated at 2022-06-12 10:07:49.805104
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()

    assert settings.user_dir is not None
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()

    settings = Settings(const.DEFAULT_SETTINGS)
    settings._get_user_dir_path = lambda: Path('/foo/bar')
    settings.init()
    assert settings.user_dir == Path('/foo/bar')



# Generated at 2022-06-12 10:07:56.906335
# Unit test for method init of class Settings
def test_Settings_init():
    args = type('', (), {'yes': False, 'debug': False, 'repeat': None})()
    settings.init(args)

    assert settings.verbose == False
    assert settings.require_confirmation == True
    assert settings.rules == ['git_push', 'git_add', 'pip_install', 'ls_command', 'brew_install', 'apt_get_install']
    assert settings.priority == {'git_push': 100, 'git_add': 100, 'pip_install': 90, 'ls_command': 90, 'brew_install': 80, 'apt_get_install': 80}
    assert settings.exclude_rules == []
    assert settings.wait_command == 3

# Generated at 2022-06-12 10:08:04.419712
# Unit test for method init of class Settings
def test_Settings_init():
    class Args(object):
        def __init__(self, values):
            self.__dict__.update(values)
    settings._init_settings_file()
    settings._setup_user_dir()
    settings.init(Args({'yes': True, 'debug': True, 'repeat': 1}))
    assert settings['require_confirmation'] == False
    assert settings['debug'] == True
    assert settings['repeat'] == 1
    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['history_limit'] == 10
    assert settings['wait_command'] == 0.5
    assert settings['wait_slow_command'] == 3

    # Unit test for method _get_user_dir_path
    assert settings._get_user_dir_path() == settings.user_dir

# Generated at 2022-06-12 10:08:05.680388
# Unit test for method init of class Settings
def test_Settings_init():
    global settings

    settings.update(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings == const.DEFAULT_SETTINGS

# Generated at 2022-06-12 10:08:10.278562
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['require_confirmation'] == True
    assert settings['history_limit'] == None
    assert settings['wait_command'] == 1
    assert settings['wait_slow_command'] == 15
    assert settings['no_colors'] == False
    assert settings['alter_history'] == True
    assert settings['repeat'] == False
    assert settings['debug'] == False
    assert settings['exclude_rules'] == []
    assert settings['priority'] == {}
    assert settings['instant_mode'] == False
    assert settings['num_close_matches'] == 3
    assert settings['slow_commands'] == []


# Generated at 2022-06-12 10:08:11.764411
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings._get_user_dir_path().suffix == '.config/thefuck'

# Generated at 2022-06-12 10:08:18.154821
# Unit test for method init of class Settings
def test_Settings_init():
    import sys
    import unittest

    class TestSettings(unittest.TestCase):
        def test_settings_from_file_and_env(self):
            args = ['--yes', '--debug', 'ls']
            os.environ.update({'THEFUCK_WAIT_COMMAND': '10',
                               'THEFUCK_REQUIRE_CONFIRMATION': 'False',
                               'THEFUCK_RULES': 'test_rules:DEFAULT_RULES',
                               'THEFUCK_PRIORITY': 'test_rules1=5:test_rules2=10'})
            settings.init(args)
            self.assertEqual(settings.wait_command, 10)
            self.assertEqual(settings.require_confirmation, False)

# Generated at 2022-06-12 10:10:24.552516
# Unit test for method init of class Settings
def test_Settings_init():
    def _reset_environ():
        os.environ = {}

    _reset_environ()
    settings.init()


# Generated at 2022-06-12 10:10:33.758866
# Unit test for method init of class Settings
def test_Settings_init():
    #
    # Test with legacy `.thefuck` directory.
    #

    # Prepare legacy `.thefuck` directory.
    thefuck_dir = Path('~/.thefuck').expanduser()
    if thefuck_dir.is_dir():
        shutil.rmtree(thefuck_dir)
    Path('~/.thefuck/settings.py').expanduser().write_text(u'a = bar')

    # Call init() with ".thefuck" directory.
    settings.init()

    # Check that settings have been updated with ".thefuck".
    assert settings.a == u'bar'
    assert settings.debug == False
    assert settings.require_confirmation == True
    assert settings.wait_command == 1