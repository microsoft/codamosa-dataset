

# Generated at 2022-06-12 10:01:26.030745
# Unit test for method init of class Settings
def test_Settings_init():
    # test with xdg dir
    xdg_config_home = os.environ.get('XDG_CONFIG_HOME', '~/.config')
    user_dir = Path(xdg_config_home, 'thefuck').expanduser()
    if user_dir.is_dir():
        user_dir.rmtree()
    user_dir.mkdir(parents=True)

    settings.init()
    assert settings.get('rules') == const.DEFAULT_RULES
    assert settings.get('require_confirmation') == True
    assert settings.get('no_colors') == False
    assert settings.get('wait_command') == 1
    assert settings.get('history_limit') == 0
    assert settings.get('wait_slow_command') == 15

# Generated at 2022-06-12 10:01:37.650396
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import tempfile
    from six import StringIO
    stdout = sys.stdout
    try:
        user_dir = tempfile.mkdtemp()
        settings_path = os.path.join(user_dir, 'settings.py')
        with open(settings_path, 'w') as settings_file:
            settings_file.write(const.SETTINGS_HEADER)
            settings_file.write('# rules = DEFAULT_RULES\n')
        settings.user_dir = Path(user_dir)

        sys.stdout = StringIO()
        settings.init()
        assert 'settings.py' in sys.stdout.getvalue()
    finally:
        sys.stdout = stdout
        os.chdir(settings.user_dir.parent)

# Generated at 2022-06-12 10:01:47.431831
# Unit test for method init of class Settings
def test_Settings_init():
    """Test when init runs ok"""
    # When
    settings.init()

    # Then
    assert settings.require_confirmation is not None
    assert settings.rules is not None
    assert settings.priority is not None
    assert settings.no_colors is not None
    assert settings.wait_command is not None
    assert settings.history_limit is not None
    assert settings.repeat is not None
    assert settings.wait_slow_command is not None
    assert settings.debug is not None
    assert settings.alter_history is not None
    assert settings.slow_commands is not None
    assert settings.exclude_rules is not None
    assert settings.excluded_search_path_prefixes is not None
    assert settings.num_close_matches is not None
    assert settings.instant_mode is not None

# Generated at 2022-06-12 10:01:54.111483
# Unit test for method init of class Settings
def test_Settings_init():
    assert {'require_confirmation': True,
            'history_limit': None,
            'no_colors': False,
            'wait_command': 0,
            'rules': [],
            'exclude_rules': [],
            'alternative_cd': True,
            'wait_slow_command': 15,
            'slow_commands': ['lein', 'gradle', './gradlew', 'rake', 'sbt', './activator'],
            'priority': {},
            'excluded_search_path_prefixes': ['.git', 'node_modules', '.bower_components', '.tox'],
            'debug': False,
            'alter_history': False,
            'num_close_matches': 3,
            'instant_mode': False,
            'repeat': False} == settings

# Generated at 2022-06-12 10:02:04.125317
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import enable_debug, disable_debug
    enable_debug('load')

# Generated at 2022-06-12 10:02:14.739846
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

    assert settings._get_user_dir_path() == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.history_limit == 10
    assert settings.require_confirmation
    assert settings.rules == \
        ['fuck', 'git_add', 'git_commit', 'git_push', 'git_pull', 'svn_revert']
    assert settings.exclude_rules == []
    assert settings.wait_command == 0
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew']
    assert settings.wait_slow_command == 15
    assert settings.alter_history == True
    assert settings.no_colors == False
    assert settings

# Generated at 2022-06-12 10:02:16.008715
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings['history_limit'] == 100


# Generated at 2022-06-12 10:02:23.029923
# Unit test for method init of class Settings
def test_Settings_init():
    import mock
    import thefuck.shells.zsh
    mock_Args = mock.Mock()
    mock_Args.yes = 'True'
    mock_Args.debug = 'True'
    mock_Args.repeat = 'False'
    settings.init(mock_Args)

# Generated at 2022-06-12 10:02:29.459601
# Unit test for method init of class Settings
def test_Settings_init():
    import pytest

    args = type("obj", (object,), {"debug": False, "yes": False, "repeat": False})

    settings = Settings()
    settings.init(args)

    assert settings.get("require_confirmation") == const.DEFAULT_SETTINGS.get("require_confirmation")
    assert settings.get("debug") == const.DEFAULT_SETTINGS.get("debug")
    assert settings.get("repeat") == const.DEFAULT_SETTINGS.get("repeat")

# Generated at 2022-06-12 10:02:36.339372
# Unit test for method init of class Settings
def test_Settings_init():
    args = '--yes --debug --repeat'.split()
    settings.init(args=args)

    assert settings.rules == const.DEFAULT_RULES
    assert settings.priority == const.DEFAULT_PRIORITY
    assert settings.require_confirmation is False
    assert settings.no_colors is False
    assert settings.debug is True
    assert settings.alter_history is True
    assert settings.wait_command == 2
    assert settings.slow_commands == [
        'lein', 'gradle', './gradlew', 'rebar', './rebar', 'rake', 'jekyll',
        'bundle', 'composer', 'npm', 'vagrant', 'cap']
    assert settings.instant_mode is False
    assert settings.exclude_rules == []
    assert settings.excluded_search

# Generated at 2022-06-12 10:03:15.170367
# Unit test for method init of class Settings
def test_Settings_init():
    args = argparse.Namespace(yes=True)
    settings = Settings()
    settings.init(args)

    assert settings['require_confirmation'] is False

# Generated at 2022-06-12 10:03:23.824722
# Unit test for method init of class Settings
def test_Settings_init():
    """Method init of class Settings loads settings from file, env and args.
    """
    from StringIO import StringIO
    import sys

    s = Settings()
    s.user_dir = Path('/tmp')

# Generated at 2022-06-12 10:03:32.881673
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings["require_confirmation"] == True
    assert settings["debug"] == False
    assert settings["repeat"] == True
    assert settings["wait_command"] == 3
    assert settings["history_limit"] == None
    assert settings["wait_slow_command"] == 1
    assert settings["rules"] == []
    assert settings["exclude_rules"] == []
    assert settings["slow_commands"] == [
        'vagrant', 'hg', 'cd', 'bundle', 'rake', 'man', 'ls', 'copy',
        'copyrecursive', 'ftp', 'docker']
    assert settings["excluded_search_path_prefixes"] == [
        '/usr/share/npm/lib/node_modules', '/usr/share/npm/bin']
    assert settings["priority"] == {}


# Generated at 2022-06-12 10:03:35.805320
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init(args={'yes': True, 'repeat': True, 'debug': True})
    assert settings.debug
    assert settings.repeat
    assert not settings.require_confirmation
    assert settings.priority['fuck'] == 10
    settings.init()
    assert settings.require_confirmation



# Generated at 2022-06-12 10:03:36.927817
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.require_confirmation == True
    assert settings.repeat == False

# Generated at 2022-06-12 10:03:43.653755
# Unit test for method init of class Settings
def test_Settings_init():
    settings.user_dir = Path('./tests/unit')
    settings.init()
    assert settings == {'rules': ['correct_cd_path', 'git_push', 'git_stash', 
                                  'pip_install'],
                         'instant_mode': False, 'alter_history': False, 
                         'history_limit': None, 'wait_command': 5, 
                         'priority': {'cd_parent': 200}, 
                         'require_confirmation': True, 'wait_slow_command': 15, 
                         'no_colors': False}

# Generated at 2022-06-12 10:03:52.368628
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    import os
    mock_args = lambda x: lambda: x
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'true'
    os.environ['THEFUCK_YES'] = 'false'
    os.environ['THEFUCK_DEBUG'] = 'true'
    os.environ['THEFUCK_WAIT_COMMAND'] = '0'
    os.environ['THEFUCK_RULES'] = 'DEFAULT_RULES'
    os.environ['THEFUCK_EXCLUDE_RULES'] = ':'.join(['', 'man'])
    os.environ['THEFUCK_ALTER_HISTORY'] = 'false'
    os.environ['THEFUCK_HISTORY_LIMIT'] = '1'


# Generated at 2022-06-12 10:04:00.790747
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import stdout
    from .logs import exception
    from .system import get_aliases
    from .system import clear_cache

    for method in (stdout, exception, get_aliases, clear_cache):
        method.cache_clear()

    test_dir = Path(__file__).dirname().joinpath('test_settings').expanduser()
    orig_user_dir = settings.user_dir
    orig_settings_path = test_dir.joinpath('settings.py')
    settings_path = test_dir.joinpath('settings.py')
    old_settings_path = test_dir.joinpath('old_settings.py')

    settings_path.write_text('')
    old_settings_path.write_text('')
    settings.user_dir = test_dir


# Generated at 2022-06-12 10:04:09.344000
# Unit test for method init of class Settings
def test_Settings_init():
    """
    Test case for method init of class Settings
    """
    from . import settings

    class FakeArgs(object):
        def __init__(self, repeat, debug, yes):
            self.repeat = repeat
            self.debug = debug
            self.yes = yes

    args_1 = FakeArgs(repeat=10, debug=True, yes=True)

    settings.init(args_1)
    assert settings.repeat == 10
    assert settings.debug == True
    assert settings.require_confirmation == False

    class X(dict):
        def __getattr__(self, item):
            return self.get(item)

        def __setattr__(self, key, value):
            self[key] = value



# Generated at 2022-06-12 10:04:11.975434
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS.copy())
    settings.init()
    assert settings.get('rules') == const.DEFAULT_SETTINGS['rules']

# Generated at 2022-06-12 10:05:39.809929
# Unit test for method init of class Settings
def test_Settings_init():
    for rule in rules.default:
        assert rule in settings.rules
    for excluded_rule in rules.default_excluded:
        assert excluded_rule in settings.exclude_rules
    assert len(settings.exclude_rules) == len(rules.default_excluded)
    assert settings.require_confirmation
    assert settings.num_close_matches == 3
    assert settings.slow_commands == [
        'lein', 'react-native', 'cargo', 'gradle', './gradlew', 'vagrant']
    assert settings.history_limit == None
    assert settings.wait_command == 3
    assert settings.wait_slow_command == 15
    assert settings.priority == {}

# Generated at 2022-06-12 10:05:47.647424
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import Mock
    import inspect

    import thefuck
    thefuck.settings = Settings(const.DEFAULT_SETTINGS)

    settings_mock = Mock()
    settings_mock.configure_mock(**const.DEFAULT_SETTINGS)
    settings_mock.update.side_effect = lambda x: settings_mock.__dict__.update(x)
    thefuck.settings._setup_user_dir = Mock()
    thefuck.settings._init_settings_file = Mock()
    thefuck.settings._settings_from_file = Mock(return_value={})
    thefuck.settings._settings_from_env = Mock(return_value={})
    thefuck.settings._settings_from_args = Mock(return_value={})

    thefuck.settings.init(None)

    settings_m

# Generated at 2022-06-12 10:05:49.359291
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.init()


if __name__ == '__main__':
    test_Settings_init()

# Generated at 2022-06-12 10:05:52.964350
# Unit test for method init of class Settings
def test_Settings_init():
    # FIXME: Unknown variable 'user_dir'
    # settings.user_dir = Path('/')
    settings.init()
    # FIXME: Unknown variable 'user_dir'
    # assert settings.user_dir == Path('/'), settings.user_dir

# Generated at 2022-06-12 10:06:00.958677
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

    assert settings.user_dir.is_dir()
    assert settings.user_dir.joinpath('rules').is_dir()
    assert settings.user_dir.joinpath('settings.py').is_file()

    assert settings.require_confirmation is False
    assert settings.wait_command == 0
    assert settings.history_limit == 0
    assert settings.wait_slow_command == 3
    assert settings.num_close_matches == 3
    assert settings.rules == []
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.no_colors is True
    assert settings.slow_commands == []
    assert settings.debug is False
    assert settings.alter_history is False
    assert settings.excluded_search_path_prefixes == []
    assert settings

# Generated at 2022-06-12 10:06:08.762738
# Unit test for method init of class Settings
def test_Settings_init():
    _settings_from_file = '_settings_from_file'
    _settings_from_env = '_settings_from_env'
    _settings_from_args = '_settings_from_args'

    class MockedSettings(Settings):
        def __init__(self):
            self._init_settings_file = lambda: None
            self._settings_from_file = lambda: {_settings_from_file: True}
            self._settings_from_env = lambda: {_settings_from_env: True}
            self._settings_from_args = lambda arg: {_settings_from_args: arg}

            self.rules = const.DEFAULT_RULES
            self.priority = {}
            self.no_colors = True
            self.require_confirmation = True

# Generated at 2022-06-12 10:06:11.123848
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings
    assert 'DEFAULT_RULES' in settings['rules']
    for key, value in const.DEFAULT_SETTINGS.items():
        assert value == settings[key]



# Generated at 2022-06-12 10:06:20.401532
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['wait_command'] == const.DEFAULT_WAIT_COMMAND
    assert settings['require_confirmation'] == const.DEFAULT_REQUIRE_CONFIRMATION
    assert settings['no_colors'] == const.DEFAULT_NO_COLORS
    assert settings['debug'] == const.DEFAULT_DEBUG
    assert settings['history_limit'] == const.DEFAULT_HISTORY_LIMIT
    assert settings['wait_slow_command'] == const.DEFAULT_WAIT_SLOW_COMMAND
    assert settings['slow_commands'] == const.DEFAULT_SLOW_COMMANDS
    assert settings['alter_history'] == const.DEFAULT_ALTER_HISTORY

# Generated at 2022-06-12 10:06:28.880666
# Unit test for method init of class Settings
def test_Settings_init():
    import pytest
    import os
    import tempfile

    class Args(object):
        yes = False
        debug = False
        repeat = False

    settings.init(Args())

    settings.init({})

    old_user_dir = settings._get_user_dir_path()
    try:
        os.environ['XDG_CONFIG_HOME'] = tempfile.mkdtemp()
        settings.init({})
    finally:
        os.environ.pop('XDG_CONFIG_HOME')

    with pytest.raises(AttributeError):
        settings.nonexistent

    with pytest.raises(AttributeError):
        settings.non_existent = 'value'

    settings.correct = 'value'
    assert settings.correct == 'value'

    assert settings.default_priority == 1

# Generated at 2022-06-12 10:06:33.479703
# Unit test for method init of class Settings
def test_Settings_init():
    """Test of method init of class Settings"""
    import os
    from .logs import enable_debug, exception

    enable_debug()

    try:
        # test init() without arguments
        settings.init()

        # test init() with arguments
        args = type('', (object,), {'yes': True, 'debug': True, 'repeat': 1})()
        settings.init(args)
    except:
        exception(sys.exc_info())

# Generated at 2022-06-12 10:10:20.035826
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    settings.init()
    assert settings.user_dir

# Generated at 2022-06-12 10:10:28.231991
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings = Settings({})

    # Unit test for method _init_settings_file
    def test_Settings__init_settings_file():
        assert settings.get('user_dir') is None
        settings._init_settings_file()
        assert settings.get('user_dir').joinpath('settings.py').is_file()
        settings.user_dir.joinpath('settings.py').unlink()
        settings.user_dir.rmdir()

    # Unit test for method _setup_user_dir
    def test_Settings__setup_user_dir():
        assert settings.get('user_dir') is None
        settings._setup_user_dir()
        assert settings.get('user_dir').is_dir()
        settings.user_dir.rmdir()

    # Unit test for method _settings_from_

# Generated at 2022-06-12 10:10:36.579487
# Unit test for method init of class Settings
def test_Settings_init():
    # Test if _setup_user_dir works
    settings.init()
    assert isinstance(settings, Settings)
    assert isinstance(settings.user_dir, Path)
    assert settings.user_dir.joinpath('rules').is_dir() is True

    # Test if _settings_from_file works
    with settings.user_dir.joinpath('settings.py').open(mode='w') as settings_file:
        settings_file.write(const.SETTINGS_HEADER)
        settings_file.write('slow_commands = ["ls"]\n')
        settings_file.write('exclude_rules = ["git_push_current_branch"]\n')
        settings_file.write('excluded_search_path_prefixes = ["/home/user/prefix/"]\n')
        settings_file.write