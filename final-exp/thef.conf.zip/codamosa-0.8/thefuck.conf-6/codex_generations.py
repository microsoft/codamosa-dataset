

# Generated at 2022-06-12 10:01:15.027564
# Unit test for method init of class Settings
def test_Settings_init():
    del sys.modules['thefuck.settings']
    import thefuck.settings
    settings = thefuck.settings.settings
    settings.init()
    assert settings.rules == ['git_push', 'git_commit', 'git_add',
                              'git_pull', 'brew_install', 'pip_install',
                              'java_import', 'npm_install', 'cargo_install',
                              'stack_install', 'apt_install']

# Generated at 2022-06-12 10:01:16.415669
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()

# Generated at 2022-06-12 10:01:25.522485
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import Mock, patch
    from textwrap import dedent
    from six import u

    def init_argparse(args=None):
        import argparse
        parser = argparse.ArgumentParser()
        parser.add_argument('--yes', '-y', action='store_true')
        parser.add_argument('--debug', '-d', action='store_true')
        parser.add_argument('--repeat', '-r', action='store_true')
        return parser.parse_args(['--yes', '--debug', '--repeat']) if args else parser

    def init_settings_with_args(args):
        from .settings import settings
        settings.init(args)
        return settings


# Generated at 2022-06-12 10:01:28.046951
# Unit test for method init of class Settings
def test_Settings_init():
    """
    >>> settings.init()
    >>> settings.require_confirmation
    True
    >>> settings.no_colors
    False
    """
    pass

# Generated at 2022-06-12 10:01:39.102563
# Unit test for method init of class Settings
def test_Settings_init():
    test_args1 = None
    test_settings1 = Settings(const.DEFAULT_SETTINGS)
    test_settings1.init(test_args1)
    assert test_settings1.get('repeat') == 1
    assert test_settings1.get('require_confirmation') == True
    assert test_settings1.get('no_colors') == False
    assert test_settings1.get('slow_commands') == []
    assert test_settings1.get('exclude_rules') == []
    assert test_settings1.get('alter_history') == True
    assert test_settings1.get('wait_command') == 10
    assert test_settings1.get('wait_slow_command') == 3
    assert test_settings1.get('debug') == False
    assert test_settings1.get('history_limit')

# Generated at 2022-06-12 10:01:41.125292
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert 'confirm_exit' in settings
    assert settings.get('confirm_exit') is True


# Generated at 2022-06-12 10:01:45.117578
# Unit test for method init of class Settings
def test_Settings_init():
    args = type('FakeArgs', (), {
        'yes': True,
        'debug': True,
        'repeat': 5})()
    settings.init(args)
    assert settings.require_confirmation == False
    assert settings.debug == True
    assert settings.repeat == 5

# Generated at 2022-06-12 10:01:48.110329
# Unit test for method init of class Settings
def test_Settings_init():
    s = Settings()
    s.init()
    assert s['history_limit'] is 20
    s.init({'yes': True})
    assert s['require_confirmation'] is False



# Generated at 2022-06-12 10:01:55.675399
# Unit test for method init of class Settings
def test_Settings_init():
    class TestSettings(Settings):
        def __init__(self):
            super(TestSettings, self).__init__()
            self.user_dir = Path('/user/dir')
            self.original_environ = os.environ

# Generated at 2022-06-12 10:02:05.380080
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import Log
    from .logs import LogCapture
    import thefuck

    old_log = thefuck.logs.log

    class TestSettings(Settings):
        def _init_settings_file(self):
            pass


# Generated at 2022-06-12 10:02:33.173002
# Unit test for method init of class Settings
def test_Settings_init():
    """
    Test for method init of class Settings

    It is possible to create object of class Settings with other settings
    """
    from thefuck.main import Command

    settings['require_confirmation'] = False
    settings['repeat'] = "no_repeat"
    settings['history_limit'] = 5

    settings.init({"repeat": 1,
                   "debug": True,
                   "yes": True})

    assert settings['require_confirmation'] is True
    assert settings['repeat'] == "yes_repeat"
    assert settings['history_limit'] == 5
    assert settings['debug'] is True

# Generated at 2022-06-12 10:02:42.038032
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert type(settings.require_confirmation) == bool
    assert type(settings.wait_command) == int
    assert type(settings.wait_slow_command) == int
    assert type(settings.rules) == list
    assert type(settings.exclude_rules) == list
    assert type(settings.history_limit) == int
    assert type(settings.priority) == dict
    assert type(settings.no_colors) == bool
    assert type(settings.alter_history) == bool
    assert type(settings.instant_mode) == bool
    assert type(settings.debug) == bool
    assert type(settings.num_close_matches) == int
    assert type(settings.slow_commands) == list
    assert type(settings.excluded_search_path_prefixes) == list

# Generated at 2022-06-12 10:02:43.922917
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings['require_confirmation'] is True
    assert settings['repeat'] is False

# Generated at 2022-06-12 10:02:44.544297
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()


# Generated at 2022-06-12 10:02:50.427350
# Unit test for method init of class Settings
def test_Settings_init():
    def settings_from_file():
        return {'require_confirmation': True}

    def settings_from_env():
        return {'require_confirmation': True}

    def settings_from_args(args):
        return {'require_confirmation': True}

    settings._init_settings_file = lambda: None  # pylint: disable=protected-access
    settings._settings_from_file = settings_from_file
    settings._settings_from_env = settings_from_env
    settings._settings_from_args = settings_from_args

    settings.init({'yes': True})

    assert settings.require_confirmation == True

# Generated at 2022-06-12 10:02:52.883191
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    for key in const.DEFAULT_SETTINGS.keys():
        assert settings[key] == const.DEFAULT_SETTINGS[key]

# Generated at 2022-06-12 10:03:01.804035
# Unit test for method init of class Settings
def test_Settings_init():
    old_settings_file = Path('~', '.thefuck', 'settings.py')
    old_settings_file.remove()
    if const.SETTINGS_FILE.is_file():
        const.SETTINGS_FILE.remove()
    const.SETTINGS_FILE.touch()

    original_user_dir = settings.user_dir
    old_user_dir = settings.user_dir
    old_user_dir.remove()

    # Check that new settings file is created in new place,
    # when deprecated file does not exist
    settings.init()
    assert settings.user_dir == original_user_dir
    assert settings.user_dir.joinpath('settings.py').is_file()

    # Check that new settings file is not created in new place,
    # when deprecated file exists
    settings.init()

# Generated at 2022-06-12 10:03:04.937050
# Unit test for method init of class Settings
def test_Settings_init():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    test_settings.init(None)
    assert test_settings.get('commands') == const.DEFAULT_COMMANDS



# Generated at 2022-06-12 10:03:07.920086
# Unit test for method init of class Settings
def test_Settings_init():
    # Args:
    #     args - Namespace
    # Returns:
    #     None
    args = Namespace(yes=None, debug=None, repeat=None)
    settings.init(args=args)


# Generated at 2022-06-12 10:03:18.864198
# Unit test for method init of class Settings
def test_Settings_init():
    from tempfile import mkdtemp
    from shutil import rmtree
    from six import StringIO
    from .system import get_aliases

    settings = Settings(const.DEFAULT_SETTINGS)
    old_aliases = get_aliases()

# Generated at 2022-06-12 10:04:13.756974
# Unit test for method init of class Settings
def test_Settings_init():
    '''
    Create settings.py file in user_dir and set environment variables
    '''
    import tempfile
    from . import log
    import sys
    from .log_manager import LogManager

    def mock_print(message):
        pass

    def mock_exception(message, exc_info):
        pass

    def mock_get_logger(name):
        return log

    log.print = mock_print
    log.exception = mock_exception

    temp_dir = tempfile.TemporaryDirectory()

# Generated at 2022-06-12 10:04:21.943258
# Unit test for method init of class Settings
def test_Settings_init():
    # Clear all settings before run tests
    settings.clear()
    from .logs import exception

    # Test init method with default settings and without args
    settings.init()
    for key, val in const.DEFAULT_SETTINGS.items():
        assert(settings[key] == val)

    # Test init method with env values with args repeat
    key = 'require_confirmation'
    val = True
    os.environ[const.ENV_TO_ATTR[key]] = 'False'
    settings.init(args=argparse.Namespace(repeat=1))
    assert(settings[key] == val)
    os.environ.pop(const.ENV_TO_ATTR[key])

    # Test init method with file values without args
    key = 'wait_slow_command'
    val = 5
    filename

# Generated at 2022-06-12 10:04:24.366451
# Unit test for method init of class Settings
def test_Settings_init():
    sys.argv = ["thefuck"]
    settings.init()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation


# Generated at 2022-06-12 10:04:30.792749
# Unit test for method init of class Settings
def test_Settings_init():
    import inspect
    import sys
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--yes', action='store_true')
    parser.add_argument('--debug', action='store_true')
    parser.add_argument('--repeat', action='store_true')

    args = parser.parse_args()
    settings.init(args)

    assert settings.get('require_confirmation') == True
    assert settings.get('debug') == True
    assert settings.get('repeat') == True

# Generated at 2022-06-12 10:04:34.387088
# Unit test for method init of class Settings
def test_Settings_init():
    import argparse
    args = argparse.Namespace(yes=True, debug=True, repeat=1)
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init(args)
    assert settings.require_confirmation == False
    assert settings.debug == True
    assert settings.repeat == 1


# Generated at 2022-06-12 10:04:44.310530
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import shutil
    import tempfile
    # Import to initialize `settings`
    import thefuck.settings
    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-12 10:04:50.239659
# Unit test for method init of class Settings
def test_Settings_init():
    class Args:
        yes = None
        debug = None
        repeat = None

    test_args = Args()

    settings.init(test_args)
    
    assert settings['require_confirmation']
    assert settings['debug']
    assert settings['repeat'] is None

    test_args.yes = True
    test_args.debug = True
    test_args.repeat = 2
    
    settings.init(test_args)

    assert settings['require_confirmation'] is False
    assert settings['debug'] is True
    assert settings['repeat'] == 2

# Generated at 2022-06-12 10:04:59.504523
# Unit test for method init of class Settings
def test_Settings_init():
    test_settings = Settings()
    test_settings.init()
    assert test_settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']
    assert test_settings.rules == const.DEFAULT_SETTINGS['rules']
    assert test_settings.exclude_rules == const.DEFAULT_SETTINGS['exclude_rules']
    assert test_settings.no_colors == const.DEFAULT_SETTINGS['no_colors']
    assert test_settings.priority == const.DEFAULT_SETTINGS['priority']
    assert test_settings.wait_command == const.DEFAULT_SETTINGS['wait_command']
    assert test_settings.slow_commands == [x for x in const.DEFAULT_SETTINGS['slow_commands']]
    assert test_settings.wait_slow

# Generated at 2022-06-12 10:05:07.348815
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import get_logger
    from .system import History, get_aliases, get_shell_command
    from .utils import memoize, wrap_with_history_and_exit

    settings.clear()
    settings.init()

    # Set environment variable and check if settings.py can be loaded.
    os.environ['THEFUCK_HISTORY_LIMIT'] = '2'
    settings.init()
    assert settings['history_limit'] == 2

    # Set alias and check if it can be loaded.
    os.path.exists = lambda path: True
    os.listdir = lambda path: ['git', 'git.py']
    const.CONFIG_FILES = ['~/.gitconfig']
    assert 'git' in get_aliases()

    # Set history and check if it can be saved.


# Generated at 2022-06-12 10:05:09.701402
# Unit test for method init of class Settings
def test_Settings_init():

    os.environ['XDG_CONFIG_HOME'] = '~/.config'
    cleanup()

    assert settings.init()
    assert settings.user_dir == os.path.expanduser(os.environ['XDG_CONFIG_HOME'] + '/thefuck')

    assert os.path.isfile(settings.user_dir + '/settings.py')



# Generated at 2022-06-12 10:06:43.994433
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()


# Generated at 2022-06-12 10:06:52.437257
# Unit test for method init of class Settings
def test_Settings_init():
    from pytest import raises
    from mock import patch, MagicMock

    # Fills `settings` with values from `settings.py`
    with patch('thefuck.settings.Settings._settings_from_file',
               return_value={'key': 'value'}):
        settings.init()
        assert settings == {'key': 'value'}

    # Fills `settings` with values from env
    with patch('thefuck.settings.Settings._settings_from_env',
               return_value={'other_key': 'other_value'}):
        settings.init()
        assert settings == {'other_key': 'other_value'}

    # Fills `settings` with values from args

# Generated at 2022-06-12 10:06:59.091631
# Unit test for method init of class Settings
def test_Settings_init():
    args_test = type('test', (object,), {'yes': True, 'debug': False, 'repeat': 1})
    from mock import patch
    from thefuck.settings import const
    from thefuck.settings import Settings
    settings_test = Settings(const.DEFAULT_SETTINGS)
    settings_test.user_dir = 'test/test/test'
    settings_test.init(args_test)
    assert(settings_test.repeat == 1)
    assert(settings_test.require_confirmation == False)
    assert(settings_test.debug == False)



# Generated at 2022-06-12 10:07:07.898375
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings._get_user_dir_path() == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.require_confirmation == True
    assert settings.alter_history == True
    assert settings.history_limit == None
    assert settings.instant_mode == False
    assert settings.no_colors == False
    assert settings.wait_command == None
    assert settings.wait_slow_command == 15
    assert settings.python3 == False
    assert settings.slow_commands == [
        'lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.excluded_search_path_prefixes == ['/usr', '/private/var']

# Generated at 2022-06-12 10:07:13.872015
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import _logs

    settings.clear()
    settings.init(args="""
        --debug
        --repeat 10
        --yes
        """)
    assert settings == {'require_confirmation': False,
                        'debug': True,
                        'repeat': 10}
    assert _logs == [
        'Config path {} is deprecated. Please move to {}',
        "Can't load settings from file [Errno 2] No such file or directory: 'settings.py'",
        "Can't load settings from env [Errno 2] No such file or directory: 'settings.py'"]

# Generated at 2022-06-12 10:07:16.358975
# Unit test for method init of class Settings
def test_Settings_init():
    try:
        settings.init()
        assert(type(settings.user_dir) == type(Path()))
        assert(type(settings.rules) == list)
    except:
        assert(False)


# Generated at 2022-06-12 10:07:23.393599
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()

    settings.init()
    assert settings['require_confirmation'] == True
    assert settings['priority'] == [-2, -1, 0, 1, 2]

    settings = Settings()
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'FALSE'
    settings.init()
    assert settings['require_confirmation'] == False

    settings = Settings()
    os.environ['THEFUCK_PRIORITY'] = 'git=86:brew=99'
    settings.init()
    assert settings['priority'] == {'brew': 99, 'git': 86}

    settings = Settings()
    os.environ['THEFUCK_RULES'] = 'DEFAULT_RULES:brew:git'
    settings.init()

# Generated at 2022-06-12 10:07:31.818714
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import _exception
    from .cache import _use_cache
    from .utils import _PATH
    from .utils import _ALIASES
    from .utils import _SUDO_MODE


# Generated at 2022-06-12 10:07:40.027727
# Unit test for method init of class Settings
def test_Settings_init():
    settings.update({
        'require_confirmation': True,
        'wait_command': 2,
        'no_colors': True,
        'rules': ['test', 'test1'],
        'exclude_rules': ['test1']})

    environ = {'TF_RULES': 'test2',
               'TF_EXCLUDE_RULES': 'test',
               'TF_NO_COLORS': 'false',
               'TF_WAIT_COMMAND': '3',
               'TF_REQUIRE_CONFIRMATION': 'false'}

    settings.init(args=None)

# Generated at 2022-06-12 10:07:41.178186
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert len(settings) == 20
