

# Generated at 2022-06-12 10:01:05.100477
# Unit test for method init of class Settings
def test_Settings_init():
    """
    This function tests the settings init method
    """
    # When a class is imported it runs the init method
    # so lets test that the init method runs the proper functions
    # and doesn't error
    settings_copy = settings
    os.environ['TF_DEBUG'] = 'True'
    settings_copy.init('args')
    del os.environ['TF_DEBUG']
    assert(settings_copy.debug == True)

# Generated at 2022-06-12 10:01:15.591800
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    args = type('', (), {'yes': True, 'debug': True, 'repeat': 3})()
    settings.init(args)
    assert settings.require_confirmation == False
    assert settings.debug == True
    assert settings.repeat == 3

    settings = Settings(const.DEFAULT_SETTINGS)
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'false'
    os.environ['THEFUCK_DEBUG'] = 'true'
    settings.init()
    assert settings.require_confirmation == False
    assert settings.debug == True

    settings = Settings(const.DEFAULT_SETTINGS)
    os.environ['THEFUCK_RULES'] = ':'.join(['DEFAULT_RULES', 'git_push_force_with_lease'])

# Generated at 2022-06-12 10:01:24.870662
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import Mock, patch
    from .system import Path
    from . import const

    args = Mock()
    settings.init(args)

    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME',
                                                    '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.wait_command == 1
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew']
    assert settings.prioritize_match == ['fuck']

# Generated at 2022-06-12 10:01:32.741598
# Unit test for method init of class Settings
def test_Settings_init():
    """Test Settings.init method
    """
    # init settings dict
    settings._settings_from_args = lambda args: {'require_confirmation':False}
    settings._settings_from_env = lambda: {'require_confirmation':False,
                                           'rules':['fuck']}
    settings._settings_from_file = lambda: {'require_confirmation':False,
                                            'rules':['fuck']}
    settings.init()
    assert settings['rules'] == ['fuck']
    assert settings['require_confirmation'] == False

# Generated at 2022-06-12 10:01:33.737140
# Unit test for method init of class Settings
def test_Settings_init():
    print(settings.init())

# Generated at 2022-06-12 10:01:38.586398
# Unit test for method init of class Settings
def test_Settings_init():
    import mock
    settings = Settings(dict(a=1, b=2))
    settings.update = mock.MagicMock()
    settings.init()
    settings._settings_from_file.assert_called_with()
    settings._settings_from_env.assert_called_with()
    settings._settings_from_args.assert_called_with()

# Generated at 2022-06-12 10:01:42.971850
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.require_confirmation is True
    assert settings.repeat is None
    assert settings.history_limit is None
    assert settings.no_colors is False
    assert settings.wait_command is 3
    assert settings.wait_slow_command is 10

# Generated at 2022-06-12 10:01:46.793223
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.priority == {}

# Generated at 2022-06-12 10:01:47.798252
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.init() == {}

# Generated at 2022-06-12 10:01:52.520280
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    for k, v in const.DEFAULT_SETTINGS.items():
        assert settings[k] == v
    assert settings['require_confirmation'] is True
    assert settings['no_colors'] is False
    assert settings.debug is False
    assert settings.repeat is 1
    assert settings.get('repeat_modifier', None) is None

# Generated at 2022-06-12 10:02:15.368169
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()



# Generated at 2022-06-12 10:02:22.668441
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import devnull
    from .utils import wrap_streams
    from six import StringIO
    from unittest import TestCase

    class TestCase(TestCase):
        def setUp(self):
            self._stdout = sys.stdout
            self._stderr = sys.stderr
            sys.stdout = devnull
            sys.stderr = devnull

        def tearDown(self):
            sys.stdout = self._stdout
            sys.stderr = self._stderr

    class TestSettings(Settings):
        def _get_user_dir_path(self):
            return Path('')

        def __init__(self):
            super(TestSettings, self).__init__()
            self.user_dir = Path('')


# Generated at 2022-06-12 10:02:29.153733
# Unit test for method init of class Settings
def test_Settings_init():
    args = type('FakeArgs', (object,), {})
    for attr in const.ATTR_TO_ENV:
        setattr(args, attr, False)
        settings._settings_from_args = lambda s: {}
        settings.init(args)
        assert settings[attr] is False

    args.yes = True
    settings._settings_from_args = lambda s: {}
    settings.init(args)
    assert settings['require_confirmation'] is False



# Generated at 2022-06-12 10:02:36.197721
# Unit test for method init of class Settings
def test_Settings_init():
    """
    Test Settings init method
    """
    import pytest
    import os
    import thefuck.utils.settings as st

    test_settings = st.Settings(const.DEFAULT_SETTINGS)
    test_env = os.environ.copy()
    test_env['TF_COLOR_MODE'] = 'always'
    test_env['TF_RULES'] = 'DEFAULT_RULES:some_rule:some_other_rule'
    test_env['PATH'] = 'some_path:some_other_path'
    test_env['TF_PRIORITY'] = 'some_rule=4:some_other_rule=8'
    test_env['TF_SLOW_COMMANDS'] = 'some_slow_command:some_other_slow_command'

# Generated at 2022-06-12 10:02:41.900896
# Unit test for method init of class Settings
def test_Settings_init():
    # Tested method, _setup_user_dir, uses os.environ, which isn't available
    # in all environments. Below we create a dummy os.environ object.
    from thefuck.utils import import_os_environ

    os_environ_module = import_os_environ()
    os_environ_module.environ = {
        'xdg_config_home': '.thefuck'
    }

    settings.init()
    assert settings._get_user_dir_path() == os.path.join('.thefuck')

# Generated at 2022-06-12 10:02:44.556376
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import logger
    _logger_info = logger.info
    logger.info = lambda *a, **kw: None
    try:
        settings.init(args=None)
    except Exception as e:
        logger.info = _logger_info
        raise e

# Generated at 2022-06-12 10:02:49.008143
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch

    # Python 2 and Python 3 compatibility:
    if sys.version_info >= (3, 0):
        getattr = getattr(set, '__getattr__')
        setattr = getattr(set, '__setattr__')
    else:
        getattr = getattr

    set_user_dir = patch.object(Settings, '_setup_user_dir').start() # noqa
    set_init_settings_file = patch.object(Settings, '_init_settings_file').start()  # noqa
    set_settings_from_file = patch.object(Settings, '_settings_from_file').start()  # noqa
    set_settings_from_env = patch.object(Settings, '_settings_from_env').start()  # noqa

# Generated at 2022-06-12 10:02:51.086713
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    settings.init()
    settings.init(args = {'yes': True, 'debug': True, 'repeat': 1})
    settings.init(args = {'yes': True, 'debug': True, 'repeat': 0})



# Generated at 2022-06-12 10:03:00.354823
# Unit test for method init of class Settings
def test_Settings_init():
    import mock
    import os
    import tempfile
    import shutil
    import sys

    temp_dir = tempfile.mkdtemp()


# Generated at 2022-06-12 10:03:09.096839
# Unit test for method init of class Settings
def test_Settings_init():
    # Current is sys.stderr and sys.stdout, so we need to mock them.
    sys.stderr = StringIO()
    sys.stdout = StringIO()
    # Create a new instance of the Settings class
    settings = Settings(const.DEFAULT_SETTINGS)
    # Call the init method with a random argument
    try:
        settings.init(args=None)
    except AttributeError:
        assert 0
    # Check if the instance has the same keys and values
    # as the default_settings dictionary
    assert settings == const.DEFAULT_SETTINGS
    # Check if the user_dir attribute exists
    assert hasattr(settings, 'user_dir')
    # Check if the user config file was created
    assert settings.user_dir.joinpath('settings.py').is_file()
    # Check

# Generated at 2022-06-12 10:03:35.140642
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings['rules'] == ['bash', 'debian']
    assert settings['priority'] == {'bash': 100, 'debian': 90}
    assert settings['exclude_rules'] == []
    assert settings['require_confirmation'] == False
    assert settings['no_colors'] == False
    assert settings['slow_commands'] == ['lein', 'react-native', 'gradle']
    assert settings['history_limit'] == None
    assert settings['wait_command'] == 3
    assert settings['wait_slow_command'] == 10
    assert settings['alter_history'] == True
    assert settings['excluded_search_path_prefixes'] == ['$PYTHONPATH']
    assert settings['debug'] == False
    assert settings['num_close_matches'] == 3
    assert settings['repeat'] == True

# Generated at 2022-06-12 10:03:42.447181
# Unit test for method init of class Settings
def test_Settings_init():
    from unittest import mock
    from .logs import exception
    from .utils import get_all_executables

    old_path = os.environ['PATH']
    xdg_config_home = os.environ.get('XDG_CONFIG_HOME', '~/.config')
    user_home = os.path.expanduser('~')
    user_dir = os.path.join(xdg_config_home, 'thefuck')
    legacy_user_dir = os.path.join(user_home, '.thefuck')
    os.environ['PATH'] = '/bin:/usr/bin'
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'True'
    os.environ['THEFUCK_WAIT_COMMAND'] = '10'

# Generated at 2022-06-12 10:03:49.887661
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    tempdir = tempfile.mkdtemp()
    old_env = dict(os.environ)
    os.environ.clear()
    os.environ['XDG_CONFIG_HOME'] = tempdir
    try:
        settings = Settings(const.DEFAULT_SETTINGS)
        settings.init()
        assert settings['require_confirmation']
        assert settings['rules'] == const.DEFAULT_RULES
    finally:
        os.environ.clear()
        os.environ.update(old_env)
        import shutil
        shutil.rmtree(tempdir)



# Generated at 2022-06-12 10:03:55.872042
# Unit test for method init of class Settings
def test_Settings_init():
    args = type('', (), {'yes':False, 'repeat':False, 'debug':False})()
    settings.init(args)

# Generated at 2022-06-12 10:04:04.306990
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    import shutil
    import os
    import pytest

    class FakeArgs(object):
        def __init__(self, repeat=None, yes=None, debug=None):
            self.repeat = repeat
            self.yes = yes
            self.debug = debug

    settings = Settings(const.DEFAULT_SETTINGS)
    # create temporary directory
    path = tempfile.mkdtemp()
    # create temporary file and write settings
    os.mkdir(path + '/.thefuck')
    with open(path + '/.thefuck/settings.py', 'wb') as settings_file:
        settings_file.write(const.SETTINGS_HEADER)
        settings_file.write(u'alias = "fuck"\n')

# Generated at 2022-06-12 10:04:05.203308
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.init() == True

# Generated at 2022-06-12 10:04:14.895758
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)

    with settings.user_dir.joinpath('settings.py').open(mode='w') as f:
        f.write(const.SETTINGS_HEADER)

    os.environ['TF_REQUIRE_CONFIRMATION'] = 'FALSE'
    os.environ['TF_RULES'] = ':DEFAULT_RULES:bash:ls'
    os.environ['TF_PRIORITY'] = 'fs=100'
    os.environ['TF_WAIT_COMMAND'] = '2'
    os.environ['TF_HISTORY_LIMIT'] = '3'
    os.environ['TF_WAIT_SLOW_COMMAND'] = '4'

# Generated at 2022-06-12 10:04:22.651422
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch
    from .logs import exception

    with patch('thefuck.settings._settings_from_file'), \
         patch('thefuck.settings._settings_from_env'), \
         patch('thefuck.settings._settings_from_args'), \
         patch('thefuck.settings.Settings.update'), \
         patch('logging.exception') as mock_exception:
        settings.init()
        settings._settings_from_file.assert_called_with()
        settings._settings_from_env.assert_called_with()
        settings._settings_from_args.assert_called_with(None)
        settings.update.assert_called_with(
            settings._settings_from_file.return_value)

# Generated at 2022-06-12 10:04:26.309088
# Unit test for method init of class Settings
def test_Settings_init():
    args = lambda **kwargs: type('object', (object,), kwargs)()
    settings.init(args(yes=True, debug=True, repeat=7))
    assert settings.require_confirmation is False
    assert settings.debug is True
    assert settings.repeat == 7


# Generated at 2022-06-12 10:04:34.917125
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    from .logs import exception
    from .logs import log
    from .logs import print_to_stderr
    from .logs import get_logger

    logger = get_logger('thefuck')
    original_exception = exception
    original_log = log
    original_print_to_stderr = print_to_stderr
    original_get_logger = get_logger

    def mocked_exception(*args, **kwargs):
        pass

    def mocked_log(*args, **kwargs):
        pass

    def mocked_print_to_stderr(*args, **kwargs):
        pass

    def mocked_get_logger(*args, **kwargs):
        pass

    exception = mocked_exception
    log

# Generated at 2022-06-12 10:05:27.603540
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .rules import load_rules
    from mock import patch

    args = None
    settings_file = {}

# Generated at 2022-06-12 10:05:34.788936
# Unit test for method init of class Settings
def test_Settings_init():
    import unittest
    import random
    class DummyArgs(object):
        def __init__(self, yes=False, debug=False, repeat=False):
            self.yes = yes
            self.debug = debug
            self.repeat = repeat

    class TestSettings(unittest.TestCase):
        def setUp(self):
            self.settings = Settings(const.DEFAULT_SETTINGS)
            self.old_env = {}
            self.old_args = None
            self.old_settings = {}

            self.old_env = os.environ.copy()
            os.environ = {}

            self.old_args = self.settings.args
            self.settings.args = None

            self.old_settings = {key: value
                                 for key, value in self.settings.items()}

           

# Generated at 2022-06-12 10:05:42.076282
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init(None)
    assert settings['require_confirmation'] == True
    assert settings['history_limit'] == None
    assert settings['alter_history'] == False

    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'True'
    os.environ['THEFUCK_HISTORY_LIMIT'] = '10'
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init(None)
    assert settings['require_confirmation'] == True
    assert settings['history_limit'] == 10

# Generated at 2022-06-12 10:05:49.871059
# Unit test for method init of class Settings
def test_Settings_init():  # export
    from .logs import log_to_stderr, log_to_file
    import tempfile
    import re

    temp_log = tempfile.NamedTemporaryFile()

    log_to_stderr()
    # test default settings
    assert settings.require_confirmation is True
    assert settings.priority == {}
    assert settings.wait_command == 2
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', 'rebar3']
    assert settings.history_limit == 10
    assert settings.no_colors is False
    assert settings.debug is False
    assert settings.alter_history is True
    assert settings.exclude_rules == []

    # test settings from file (this file doesn't exist)

# Generated at 2022-06-12 10:05:56.347331
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import Logger
    from thefuck.config import settings

    class FakeArgs(object):
        yes = False
        debug = False
        repeat = 0

    logger = Logger()
    fake_args = FakeArgs()
    settings.init(fake_args)

    assert settings['require_confirmation'] == True
    assert settings['repeat'] == 0
    assert settings['debug'] == False
    assert settings['history_limit'] == None
    assert settings['no_colors'] == False
    assert settings['instant_mode'] == False

# Generated at 2022-06-12 10:06:03.755956
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import logger
    from .logs import exception
    from .logs import debug
    import sys
    import os

    # reset settings to defaults
    settings.clear()
    settings.update(const.DEFAULT_SETTINGS)

    # suppress all output
    logger.disabled = 1
    exception.disabled = 1
    debug.disabled = 1

    # remove user config dir and create it again
    user_dir = settings._get_user_dir_path()
    if user_dir.is_dir():
        import shutil

        shutil.rmtree(text_type(user_dir))
    settings._setup_user_dir()

    # remove settings from env

# Generated at 2022-06-12 10:06:09.889953
# Unit test for method init of class Settings
def test_Settings_init():
    """
    Test if `init` method set `settings` in file and env.

    # If `settings.py` file does not exist, then create it with default values.
    # Load `settings` from `settings.py`.
    # Load `settings` from env.
    # Load `settings` from args.
    # NOTE: This test also checks user config dir: `user_dir.joinpath('settings.py')`

    """
    from unittest.mock import patch
    import tempfile
    from thefuck.types import Settings as MockSettings

    # Prepare
    tmp_dir = tempfile.TemporaryDirectory()

# Generated at 2022-06-12 10:06:19.592831
# Unit test for method init of class Settings
def test_Settings_init():
    """Unit test for method init of class Settings"""
    from .logs import captured_logger
    import tempfile

    with tempfile.NamedTemporaryFile() as temp_file:
        temp_file.write('DEV_MODE=True'.encode('utf-8'))
        temp_file.flush()
        os.environ['THEFUCK_SETTINGS_FILE'] = temp_file.name
        os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'False'
        os.environ['THEFUCK_DEBUG'] = 'True'
        os.environ['THEFUCK_REPEAT'] = '5'

        settings.init(argparse.Namespace(debug=True, yes=True, repeat=5))


# Generated at 2022-06-12 10:06:28.064689
# Unit test for method init of class Settings
def test_Settings_init():
    from .system import TemporaryDirectory
    from six.moves import reload_module
    import os

    with TemporaryDirectory() as tmp_dir:
        debug = True
        env_updates = {'XDG_CONFIG_HOME': tmp_dir}
        user_dir = Path(tmp_dir, 'thefuck')
        user_dir.mkdir()
        user_settings = user_dir.joinpath('settings.py')

        user_settings.write_text('import os\n'
                                 'DEBUG = os.environ["DEBUG"]\n')

        env_updates['DEBUG'] = str(debug)
        reload_module(sys.modules[__name__])
        with os.environ.updates(env_updates):
            settings.init()

        assert settings['debug'] == debug

# Generated at 2022-06-12 10:06:35.971923
# Unit test for method init of class Settings
def test_Settings_init():
    import sys
    from future.builtins import input
    from contextlib import contextmanager
    from io import StringIO

    @contextmanager
    def captured_stderr():
        old_stderr = sys.stderr
        sys.stderr = StringIO()
        try:
            yield sys.stderr
        finally:
            sys.stderr = old_stderr

    @contextmanager
    def mock_input(mock):
        old_input = input
        input = lambda _: mock
        try:
            yield
        finally:
            input = old_input


# Generated at 2022-06-12 10:08:36.929986
# Unit test for method init of class Settings
def test_Settings_init():
    test_dir = '.tests'
    test_file = 'settings.py'
    test_settings = {'rules': ['test_1', 'test_2']}
    test_settings_header = const.SETTINGS_HEADER + 'test = None\n'
    test_settings_key = 'test'
    test_settings_value = 'None'

    def assert_settings_file(user_dir, settings_file):
        assert settings_file == {test_settings_key: test_settings_value}

    def assert_settings_dir(user_dir):
        assert user_dir.joinpath('rules').is_dir()

    # Test create_settings_file and create_empty_dir
    os.mkdir(test_dir)
    settings._get_user_dir_path = lambda: test_dir

# Generated at 2022-06-12 10:08:45.070613
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .utils import get_all_executables, replace_argument
    from .const import DEFAULT_SETTINGS
    from .system import Path

    # setup
    settings['wait_command'] = 3
    settings['wait_slow_command'] = 5
    settings['num_close_matches'] = 7
    settings['history_limit'] = 9
    settings['require_confirmation'] = True
    settings['no_colors'] = True
    settings['rules'] = ['echo']
    settings['priority'] = {'echo': 3}
    settings['exclude_rules'] = ['test']
    settings['debug'] = True
    settings['slow_commands'] = ['ls']
    settings['excluded_search_path_prefixes'] = ['echo']
    settings['alter_history'] = True

# Generated at 2022-06-12 10:08:48.119283
# Unit test for method init of class Settings
def test_Settings_init():
    args = type('args', (object,), {'yes': True, 'repeat': None})()
    _settings = Settings(const.DEFAULT_SETTINGS)
    _settings.init(args)
    assert not _settings.require_confirmation
    assert not _settings.debug
    assert not _settings.repeat
    assert _settings.no_colors

# Generated at 2022-06-12 10:08:49.654813
# Unit test for method init of class Settings
def test_Settings_init():
    _settings = Settings(const.DEFAULT_SETTINGS)
    _settings.init()

    assert _settings == settings



# Generated at 2022-06-12 10:08:56.529263
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()

    # test settings_from_file
    settings.init()
    assert settings.rules == const.DEFAULT_RULES

    # test settings_from_env
    os.environ.update({"THEFUCK_RULES": "bash:fish:test1:test2:test3"})
    settings.init()
    assert settings.rules == const.DEFAULT_RULES + ["test1", "test2", "test3"]

    # test settings_from_args
    from tests.utils import MockArgs
    args = MockArgs()
    args.yes = True
    settings.init(args)
    assert settings.require_confirmation is False

    os.environ.clear()

# Generated at 2022-06-12 10:09:00.788993
# Unit test for method init of class Settings
def test_Settings_init():
    args = type('args', (object,), {'yes': True, 'debug': True, 'repeat':3})
    os_environ = {'TF_COLOR_MODE': 'true', 'TF_REQUIRE_CONFIRMATION': 'false'}
    settings.init(args=args)

    assert settings.require_confirmation == False
    assert settings.no_colors == True



# Generated at 2022-06-12 10:09:07.328176
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    from thefuck.utils import wrap_settings

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-12 10:09:15.685451
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings({})
    settings.init()
    assert isinstance(settings, dict)
    assert hasattr(settings, 'priority')
    assert hasattr(settings, 'require_confirmation')
    assert hasattr(settings, 'no_colors')
    assert hasattr(settings, 'history_limit')
    assert hasattr(settings, 'wait_command')
    assert hasattr(settings, 'wait_slow_command')
    assert hasattr(settings, 'alter_history')
    assert hasattr(settings, 'debug')
    assert hasattr(settings, 'exclude_rules')
    assert hasattr(settings, 'slow_commands')
    assert hasattr(settings, 'excluded_search_path_prefixes')
    assert hasattr(settings, 'instant_mode')

# Generated at 2022-06-12 10:09:17.858573
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir.is_dir()

# Generated at 2022-06-12 10:09:19.405959
# Unit test for method init of class Settings
def test_Settings_init():
    from argparse import Namespace

    settings.init(Namespace(yes=True))

    assert 'require_confirmation' in settings and not settings.require_confirmation