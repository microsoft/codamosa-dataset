

# Generated at 2022-06-12 10:01:24.518533
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init(args=object)
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation
    assert settings.alternative_script == 'fuck'
    assert settings.repeat == 1
    assert settings.priority == {}
    assert settings.exclude_rules == []
    assert settings.wait_command == 15
    assert settings.history_limit == None
    assert settings.wait_slow_command == 3
    assert settings.slow_commands == ['lein', 'gradle', 'rebar3']
    assert settings.num_close_matches == 3
    assert settings.alter_history
    assert settings.no_colors
    assert not settings.debug



# Generated at 2022-06-12 10:01:36.282982
# Unit test for method init of class Settings
def test_Settings_init():
    tempdir = tempfile.mkdtemp()
    user_dir = os.path.join(tempdir, '.config/thefuck')
    user_settings = os.path.join(user_dir, 'settings.py')
    user_rules_dir = os.path.join(user_dir, 'rules')
    os.makedirs(user_rules_dir)

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.user_dir = os.path.join(tempdir, '.thefuck')
    settings.init()
    assert not os.path.exists(os.path.join(tempdir, '.thefuck'))
    assert os.path.exists(user_settings)
    assert open(user_settings).read() == const.SETTINGS_HEADER

# Generated at 2022-06-12 10:01:38.730665
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings['history_limit'] == const.DEFAULT_SETTINGS['history_limit']

# Generated at 2022-06-12 10:01:49.096258
# Unit test for method init of class Settings
def test_Settings_init():
    import sys
    from .logs import exception

    args = object()
    os.environ['DEBUG'] = 'false'
    os.environ['COMMAND_NOT_FOUND_SUGGESTION'] = 'true'
    os.environ['RULES'] = 'DEFAULT_RULES:bash_history'
    os.environ['COMMENT_ONLY'] = 'true'
    os.environ['PRIORITY'] = 'bash_history=-1'
    os.environ['WAIT_COMMAND'] = '46'
    os.environ['SLOW_COMMANDS'] = 'foo:bar'
    os.environ['HISTORY_LIMIT'] = '46'
    os.environ['WAIT_SLOW_COMMAND'] = '46'
    os.environ

# Generated at 2022-06-12 10:01:55.999475
# Unit test for method init of class Settings
def test_Settings_init():
    args = Mock()
    args.yes = True
    args.debug = False
    args.repeat = None

# Generated at 2022-06-12 10:02:05.613857
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import capture_log
    from .logs import logger
    from .logs import reset_logger
    from .logs import set_logger

    settings['require_confirmation'] = False
    settings._setup_user_dir = lambda: Path('.', '.thefuck')
    settings._settings_from_file = lambda: {}
    settings._settings_from_env = lambda: {'priority': {'foo': 10}}
    settings._settings_from_args = lambda x: {}

    init_logger = set_logger(capture_log(reset_logger()))
    settings.init()

    assert settings['priority'] == {'foo': 10}
    assert settings['require_confirmation'] == False
    assert (settings.user_dir.joinpath('settings.py')
                             .read_text())

# Generated at 2022-06-12 10:02:15.414941
# Unit test for method init of class Settings
def test_Settings_init():
    import sys
    import os
    from argparse import ArgumentParser
    from .logs import _logger
    from tempfile import gettempdir
    from six import text_type
    from .system import Path

    def _clean_settings():
        settings.clear()
        settings.update(const.DEFAULT_SETTINGS)

    class Command(object):
        def __init__(self, yes=False, debug=False, repeat=None):
            self.yes = yes
            self.debug = debug
            self.repeat = repeat

    # reset settings
    _clean_settings()

    # init with empty args
    settings.init()

    # when repeat is empty, then repeat should be None
    assert settings.repeat is None

    # init with args
    settings.init(Command(yes=True, debug=True, repeat=1))

# Generated at 2022-06-12 10:02:22.714612
# Unit test for method init of class Settings
def test_Settings_init():
    import mock
    import os
    from .system import Path

    user_dir = Path('~/.config/thefuck/')
    settings = Settings()
    settings._settings_from_args = mock.Mock(return_value={})
    settings._settings_from_env = mock.Mock(return_value={})
    settings.update = mock.Mock()
    settings._init_settings_file = mock.Mock()
    settings._setup_user_dir = mock.Mock(return_value=user_dir)
    settings._settings_from_file = mock.Mock(return_value={})
    settings.init()
    settings._settings_from_args.assert_called_once_with()
    settings._settings_from_env.assert_called_once_with()
    settings.update.assert_called_once_

# Generated at 2022-06-12 10:02:32.126168
# Unit test for method init of class Settings
def test_Settings_init():
    import os

    xdg_config_home = os.environ.get('XDG_CONFIG_HOME', '~/.config')

    settings = Settings({'alter_history': True})
    assert settings.init() == None
    assert settings['alter_history'] == True

    settings = Settings({'alter_history': False})
    assert settings.init(args=['-y']) == None
    assert settings['alter_history'] == True

    settings = Settings({'alter_history': True})
    assert settings.init(args=['-y']) == None
    assert settings['alter_history'] == False

    settings = Settings({'alter_history': True})
    assert settings.init(args=['--debug']) == None
    assert settings['alter_history'] == True
    assert settings['debug'] == True

    settings

# Generated at 2022-06-12 10:02:41.332583
# Unit test for method init of class Settings
def test_Settings_init():
    from os import environ
    import pytest

    settings.init()
    assert settings.get('require_confirmation')
    assert not settings.get('debug')
    settings.init(args=object)
    assert settings.get('require_confirmation')
    settings.init(args=object())
    assert settings.get('require_confirmation')
    settings.init(args=object(require_confirmation=False))
    assert not settings.get('require_confirmation')
    settings.init(args=object(debug=True))
    assert settings.get('debug')
    environ['THEFUCK_DEBUG'] = '1'
    settings.init()
    assert settings.get('debug')
    del environ['THEFUCK_DEBUG']
    settings.init()
    assert not settings.get('debug')

# Generated at 2022-06-12 10:03:22.716599
# Unit test for method init of class Settings
def test_Settings_init():
    import mock

    def assert_settings(args, expected, warn=None):
        args = [u'--{}'.format(args)] if args else []

# Generated at 2022-06-12 10:03:31.945462
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import capture_logs, LogCapture
    from .history import History

    with capture_logs(logger_name='thefuck') as logs:
        settings = Settings(const.DEFAULT_SETTINGS)
        settings.init()
        assert not logs.records

    # Test reading from settings file
    settings_path = settings.user_dir.joinpath('settings.py')
    with settings_path.open(mode='w') as settings_file:
        settings_file.write('slow_commands = ["vim"]')
    settings.init()
    assert settings['slow_commands'] == ['vim']

    # Test reading from environment variables

# Generated at 2022-06-12 10:03:39.752958
# Unit test for method init of class Settings
def test_Settings_init():
    import imp
    import os
    import tempfile
    import shutil

    sys.modules['settings'] = imp.new_module('settings')

    class Args(object):
        pass

    args = Args()
    args.yes = True

    # create the fuck dir
    temp_dir = tempfile.mkdtemp(prefix='thefuck-')

    # create mock settings.py file
    settings_file = temp_dir + '/settings.py'
    f = open(settings_file, 'w')
    f.write('#! /usr/bin/python')
    f.write('\nalter_history = true')
    f.write('\ndebug = false')
    f.write('\nexclude_rules = []')
    f.write('\nexcluded_search_path_prefixes = []')
   

# Generated at 2022-06-12 10:03:49.031326
# Unit test for method init of class Settings
def test_Settings_init():
    from contextlib import contextmanager

    from .logs import _is_debug
    from .system import Path
    from .utils import get_all_executables

    class FakeFile(object):
        def __init__(self, content=u''):
            self._content = content
            self._idx = 0

        def readline(self):
            if self._idx >= len(self._content):
                return u''
            res = self._content[self._idx]
            self._idx += 1
            return res

        def __enter__(self):
            return self

        def __exit__(self, *args):
            pass

    @contextmanager
    def mock_open_file(data=u''):
        with FakeFile(data) as fakefile:
            yield fakefile


# Generated at 2022-06-12 10:03:55.419988
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init(args=None)
    assert isinstance(getattr(settings, "require_confirmation"), bool)
    assert isinstance(getattr(settings, "priority"), dict)
    assert isinstance(getattr(settings, "user_dir"), Path)
    assert isinstance(getattr(settings, "rules"), list)
    assert isinstance(getattr(settings, "no_colors"), bool)
    assert isinstance(getattr(settings, "debug"), bool)
    assert isinstance(getattr(settings, "repeat"), int)
    assert isinstance(getattr(settings, "wait_command"), int)
    assert isinstance(getattr(settings, "slow_commands"), list)
    assert isinstance(getattr(settings, "exclude_rules"), list)

# Generated at 2022-06-12 10:04:01.640468
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.init()

    class FakeArgs(object):
        def __init__(self, settings):
            self.settings = settings

        @property
        def yes(self):
            return self.settings

        @property
        def debug(self):
            return self.settings

        @property
        def repeat(self):
            return self.settings

    for value in [True, False]:
        settings.init(FakeArgs(value))

# Generated at 2022-06-12 10:04:11.248836
# Unit test for method init of class Settings
def test_Settings_init():
    # init first
    # cur_settings = Settings(const.DEFAULT_SETTINGS)
    # cur_settings.init()
    # new_settings = Settings(const.DEFAULT_SETTINGS)
    # new_settings.update(cur_settings._settings_from_file())
    # new_settings.update(cur_settings._settings_from_env())
    # new_settings.update(cur_settings._settings_from_args(None))
    # print new_settings

    # init second
    cur_settings = Settings(const.DEFAULT_SETTINGS)
    cur_settings.init()
    new_settings = Settings(const.DEFAULT_SETTINGS)
    new_settings.update(cur_settings._settings_from_file())
    new_settings.update(cur_settings._settings_from_env())


# Generated at 2022-06-12 10:04:20.098830
# Unit test for method init of class Settings
def test_Settings_init():
    args = Mock(yes=None, debug=None, repeat=None)
    _settings = Settings(const.DEFAULT_SETTINGS)
    _settings.user_dir = Mock(joinpath=Mock(return_value=Mock(
        is_file=Mock(return_value=False))))
    _settings.init(args)
    _settings.init(args)
    _settings.user_dir = Mock(joinpath=Mock(return_value=Mock(
        is_file=Mock(return_value=True))))
    _settings.init(args)
    _settings._set_user_dir = Mock(side_effect=OSError)
    _settings.init(args)

# Generated at 2022-06-12 10:04:24.193176
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    settings = Settings({})
    log_spy = espy(exception)

    settings.init()
    assert settings.get('require_confirmation')
    assert settings.get('wait_command')

    settings.init(['--yes'])
    assert not settings.require_confirmation

    # If you don't have an environment variable, you get an exception
    del os.environ['THEFUCK_REQUIRE_CONFIRMATION']
    settings.init()
    assert 'Can\'t load settings from env' in str(log_spy)

# Generated at 2022-06-12 10:04:32.381667
# Unit test for method init of class Settings
def test_Settings_init():
    def setup_args(yes=False, debug=False, repeat=1):
        class Args:
            def __init__(self):
                self.yes = yes
                self.debug = debug
                self.repeat = repeat

        return Args()

    assert settings == const.DEFAULT_SETTINGS

    settings.init()
    assert settings == const.DEFAULT_SETTINGS

    settings.init(setup_args(yes=True))
    assert settings['require_confirmation'] == False
    assert settings['debug'] == False

    settings.init(setup_args(debug=True))
    assert settings['debug'] == True

    settings.init(setup_args(repeat=2))
    assert settings['repeat'] == 2

# Generated at 2022-06-12 10:05:09.883408
# Unit test for method init of class Settings
def test_Settings_init():
    def _settings_from_file():
        return {'slow_commands': ['foo', 'bar']}
    def _settings_from_env():
        return {
            'slow_commands': ['baz'],
            'exclude_rules': ['bar', 'baz'],
            'wait_slow_command': 1,
            'require_confirmation': False,
            'no_colors': True,
            'debug': True,
            'history_limit': 5,
            'alter_history': True,
            'exclude_search_path_prefixes': ['spam'],
            'num_close_matches': 3,
            'instant_mode': True,
            'priority': {'foo': 5, 'bar': 10},
            'rules': ['foo', 'bar']
        }

# Generated at 2022-06-12 10:05:12.767211
# Unit test for method init of class Settings
def test_Settings_init():
    #GIVEN
    args = lambda: None
    args.yes = False
    args.repeat = None
    args.debug = None
    #WHEN
    settings.init(args)
    #THEN
    assert settings
    assert settings.get('require_confirmation') == True
    assert settings.get('repeat') == None
    assert settings.get('debug') == False


# Generated at 2022-06-12 10:05:16.324293
# Unit test for method init of class Settings
def test_Settings_init():
    args = '--yes --debug --repeat 10'.split()
    settings = Settings()
    settings.init(args)
    assert not settings.require_confirmation
    assert settings.debug
    assert settings.repeat == 10


# Generated at 2022-06-12 10:05:22.829612
# Unit test for method init of class Settings
def test_Settings_init():
    os.environ['TF_DEBUG'] = 'True'
    os.environ['THEFUCK_RULES'] = 'test'
    os.environ['THEFUCK_RULE_TEST_PRIORITY'] = '1'
    os.environ['XDG_CONFIG_HOME'] = '/tmp/.config'

    settings.init()
    assert settings.debug == True
    assert settings.rules == ['test']
    assert settings.priority == {'test': 1}
    assert settings.user_dir == '/tmp/.config/thefuck'

# Generated at 2022-06-12 10:05:31.152537
# Unit test for method init of class Settings
def test_Settings_init():
    from . import logs
    from .logs import exception

    logs.init = lambda *args: None
    exception.return_value = (None, None, None)

    args = lambda x: type('', (), {'yes': x, 'debug': x})

    user_dir = 'tests/test-settings'

# Generated at 2022-06-12 10:05:34.868413
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import shutil
    import tempfile

    if os.path.exists('.thefuck'):
        shutil.rmtree('.thefuck')

    settings.user_dir = tempfile.mkdtemp(prefix=u'test_thefuck_')
    settings.init()

    assert os.path.exists('.thefuck/settings.py')
    assert os.path.exists('.thefuck/rules')

# Generated at 2022-06-12 10:05:41.019777
# Unit test for method init of class Settings
def test_Settings_init():
    # Initialize Settings
    result = Settings()
    result.init()

    # Check if user directory has been created
    assert os.path.exists(result.user_dir)

    # Check if user directory contains settings.py file
    assert os.path.exists(result.user_dir.joinpath('settings.py'))

    # Check if user directory contains rules directory
    assert os.path.exists(result.user_dir.joinpath('rules'))

# Generated at 2022-06-12 10:05:48.570721
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    settings.init()

    assert isinstance(settings['replace_command'], bool)
    assert isinstance(settings['no_colors'], bool)
    assert isinstance(settings['wait_command'], int)
    assert isinstance(settings['history_limit'], int)
    assert isinstance(settings['wait_slow_command'], int)
    assert isinstance(settings['num_close_matches'], int)
    assert isinstance(settings['priority'], dict)
    assert isinstance(settings['instant_mode'], bool)
    assert isinstance(settings['alter_history'], bool)
    assert isinstance(settings['slow_commands'], list)
    assert isinstance(settings['exclude_rules'], list)

# Generated at 2022-06-12 10:05:56.236978
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init(args=None)
    assert settings.user_dir == Path('~', '.config', 'thefuck').expanduser()
    assert set(settings.keys()) == set([
        'rules',
        'exclude_rules',
        'priority',
        'wait_command',
        'alter_history',
        'require_confirmation',
        'no_colors',
        'wait_slow_command',
        'slow_commands',
        'exclude_search_path_prefixes',
        'debug',
        'history_limit',
        'num_close_matches',
        'instant_mode'])

# Generated at 2022-06-12 10:06:03.646232
# Unit test for method init of class Settings
def test_Settings_init():
    from tempfile import mkdtemp
    from shutil import rmtree
    from .logs import _log_dir
    from .utils import get_closest

    args = type("args", (object,), {})


# Generated at 2022-06-12 10:06:43.351837
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.require_confirmation
    assert settings.wait_command == 2
    assert settings.rules == const.DEFAULT_RULES + ['sudo']
    assert settings.priority == {'sudo': 100}
    assert settings.exclude_rules == ['noop']
    assert settings.no_colors
    assert settings.history_limit == None
    assert settings.alter_history
    assert not settings.wait_slow_command
    assert not settings.slow_commands
    assert settings.instant_mode
    assert Path(settings.user_dir).joinpath('settings.py').isfile()
    assert settings.num_close_matches == 3

# Generated at 2022-06-12 10:06:45.452985
# Unit test for method init of class Settings
def test_Settings_init():
    args = Namespace(yes=True, debug=True, repeat=1)
    settings.init(args)
    assert settings.require_confirmation == False
    assert settings.debug == True
    assert settings.repeat == 1

# Generated at 2022-06-12 10:06:47.820239
# Unit test for method init of class Settings
def test_Settings_init():
    """
        Calling init must set up the settings dict with the default values
    """
    settings = Settings()
    settings.init()
    assert settings == const.DEFAULT_SETTINGS


# Generated at 2022-06-12 10:06:49.323229
# Unit test for method init of class Settings
def test_Settings_init():
    # init method should set user_dir attribute
    settings.init()
    assert isinstance(settings.user_dir, Path)

# Generated at 2022-06-12 10:06:57.854943
# Unit test for method init of class Settings
def test_Settings_init():
    from .system import Path
    from .logs import WARNING
    from .logs import debug as _debug
    from .logs import exception as _exception
    from .logs import logging
    import warnings

    settings = Settings()

    # Mock settings.py
    settings.user_dir = Path('/home/user/.config/thefuck')
    settings.user_dir.joinpath('settings.py').write_text(
        'exclude_rules = [\n    "root",\n    "sudo",\n]')

    # Mock os.environ
    os.environ['THEFUCK_EXCLUDE_RULES'] = 'ls:ps'

    with warnings.catch_warnings(record=True) as w:
        settings.init()

    assert len(w) == 1

# Generated at 2022-06-12 10:07:06.330029
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .utils import user_dir

    # Initial settings.
    settings.init(args=None)
    assert settings.user_dir == user_dir
    assert settings.slow_commands == settings["slow_commands"]
    assert settings.require_confirmation == settings["require_confirmation"]
    assert settings.wait_command == settings["wait_command"]

    # settings.py
    path_settings_py = user_dir.joinpath('settings.py')
    path_settings_py.open(mode='w').write('\n'.join([
        const.SETTINGS_HEADER,
        'slow_commands = ["git", "ls", "git status", "git push", "git pull"]',
        'require_confirmation = True',
        'wait_command = 2']))
   

# Generated at 2022-06-12 10:07:14.758908
# Unit test for method init of class Settings
def test_Settings_init():
   from six.moves import configparser
   from unittest import mock
   from os import environ
   from os.path import join
   from tempfile import mkdtemp
   from .logs import exception

   settings.user_dir = "./exemplo"

   try:
      from .settings import load_source
      from .settings import Path
      from .settings import const
      from .settings import Settings
      from .settings import test_Settings_init
      import os
      import sys
      import thefuck
   except:
      pass

   environ["HOME"] = mkdtemp()
   settings.user_dir = os.path.join(os.environ["HOME"], ".thefuck")


# Generated at 2022-06-12 10:07:22.120564
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch
    from unittest import TestCase

    class SettingsInitTestCase(TestCase):
        @patch('thefuck.settings.Settings')
        @patch('thefuck.settings.Path')
        def test_should_pass_user_dir_to_init_settings_file(self, path, settings):
            settings.user_dir = path
            settings.init()
            path.joinpath.assert_called_once_with('settings.py')

        @patch('thefuck.settings.Settings')
        def test_should_pass_settings_path_to_load_source(self, settings):
            path = 'thefuck.settings.Path'
            from os import path as os_path
            path.open.return_value = os_path.join('settings', 'settings.py')
            settings.user_dir = path

# Generated at 2022-06-12 10:07:30.855129
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

    assert isinstance(settings.user_dir, Path)
    assert isinstance(settings.require_confirmation, bool)
    assert isinstance(settings.wait_command, int)
    assert isinstance(settings.history_limit, int)
    assert isinstance(settings.slow_commands, list)
    assert isinstance(settings.wait_slow_command, int)
    assert isinstance(settings.alter_history, bool)
    assert isinstance(settings.exclude_rules, list)
    assert isinstance(settings.rules, list)
    assert isinstance(settings.priorities, list)
    assert isinstance(settings.priority, dict)

# Unit tests for method _get_user_dir_path of class Settings
# Unit tests for method _setup_user_dir of class Settings

# Generated at 2022-06-12 10:07:39.462190
# Unit test for method init of class Settings
def test_Settings_init():
    test_args = type('args_type', (object,), {
        'yes': False,
        'repeat': None,
        'debug': False
    })

    test_settings = Settings(const.DEFAULT_SETTINGS)
    test_settings['_settings_from_file'] = lambda: {'rules': ['a', 'b', 'c']}
    test_settings['_settings_from_env'] = lambda: {'exclude_rules': ['d', 'e']}
    test_settings['_settings_from_args'] = lambda _: {'wait_command': 2}
    test_settings['user_dir'] = '~/.thefuck-test'
    test_settings['_setup_user_dir'] = lambda: None
    test_settings['_get_user_dir_path'] = lambda: None
    test

# Generated at 2022-06-12 10:09:25.290228
# Unit test for method init of class Settings
def test_Settings_init():
    import mock
    import thefuck.settings
    from thefuck.settings import const

    with mock.patch('thefuck.settings.Settings._settings_from_file',
                    return_value={'foo': 'bar'}), \
            mock.patch('thefuck.settings.Settings._settings_from_env',
                       return_value={'baz': 'qux'}), \
            mock.patch('thefuck.settings.Settings._settings_from_args',
                       return_value={'a': 'b'}), \
            mock.patch('thefuck.settings.Path.mkdir', return_value=None), \
            mock.patch('thefuck.settings.Path.joinpath', return_value=None), \
            mock.patch('thefuck.settings.Path.is_dir', return_value=True):
        thefuck.settings

# Generated at 2022-06-12 10:09:33.139705
# Unit test for method init of class Settings
def test_Settings_init():
    user_dir = Path('~/.config/thefuck').expanduser()
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir == user_dir
    assert settings.require_confirmation
    assert not settings.no_colors
    assert not settings.debug
    assert not settings.alter_history
    assert not settings.instant_mode
    assert settings.repeat == 1
    assert settings.history_limit == 1
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == const.DEFAULT_SLOW_COMMANDS
    assert settings.excluded_search_path_prefixes == ['/usr']
    assert len(settings.rules) == 45

# Generated at 2022-06-12 10:09:40.650847
# Unit test for method init of class Settings
def test_Settings_init():
    path = settings.user_dir.joinpath('settings.py')
    path.chmod(0o600)
    with path.open('a') as settings_file:
        settings_file.write("""
require_confirmation = False
history_limit = 10
wait_command = 10
wait_slow_commands = 2
no_colors = True
numeric_priority = 100
rules = DEFAULT_RULES + [r'^git stat$']
priority = {'git status': 100, 'git reset': -100, 'git st': 0}
alter_history = True
rules_dir = '/tmp/myrules'
slow_commands = ['sleep 1']
exclude_rules = ['numpy_upgrade']
excluded_search_path_prefixes = ['/home/vagrant/virtualenvs']
""")


# Generated at 2022-06-12 10:09:50.538118
# Unit test for method init of class Settings
def test_Settings_init():
    old_env = dict(os.environ)
    old_argv = sys.argv


# Generated at 2022-06-12 10:09:55.310017
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    settings = Settings()
    # "init" function can't be accessed directly from "settings" because it's
    # already been invoked.
    settings.update = lambda args=None: {'repeat': 3}
    settings.init()
    assert settings['repeat'] == 3
    settings['debug'] = True
    settings['user_dir'] = 'test'
    settings._init_settings_file = lambda: None
    settings._settings_from_file = lambda: {'require_confirmation': False,
                                            'rules': ['test_rule'],
                                            'exclude_rules': ['test_rule2']}
    settings._settings_from_env = lambda: {'priority': {'test_rule': 1},
                                           'slow_commands': ['test_rule']}
    settings._

# Generated at 2022-06-12 10:09:59.860595
# Unit test for method init of class Settings
def test_Settings_init():
    import mock
    args = mock.Mock()
    args.yes = True
    args.debug = True
    args.repeat = 1
    args.no_wait = False
    args.no_colors = True
    args.wait_slow_command = 2
    args.slow_commands = 'rm:rm -rf'
    args.require_confirmation = True
    args.exclude_rules = 'slow_command'
    args.num_close_matches = 2
    args.history_limit = 20
    args.change_history = True
    args.alter_history = False
    args.exclude_rules = 'slow_command:no_colors'
    args.rules = 'slow_command:no_colors'

# Generated at 2022-06-12 10:10:01.373844
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == settings._get_user_dir_path()


# Generated at 2022-06-12 10:10:08.930811
# Unit test for method init of class Settings

# Generated at 2022-06-12 10:10:15.945886
# Unit test for method init of class Settings
def test_Settings_init():
    """Unit test for method init of class Settings."""

    # create directory and settings file
    user_dir = Path('/tmp/thefuck')
    user_dir.mkdir()
    settings_path = user_dir.joinpath('settings.py')
    with settings_path.open(mode='w') as settings_file:
        settings_file.write(const.SETTINGS_HEADER)
        for setting in const.DEFAULT_SETTINGS.items():
            settings_file.write(u'# {} = {}\n'.format(*setting))
    settings_path.chmod(0o777)

    # create settings in env
    os.environ['THEFUCK_WAIT_COMMAND'] = '10'
    os.environ['THEFUCK_PRIORITY'] = 'python=10:system=2'

# Generated at 2022-06-12 10:10:21.265924
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.get('require_confirmation') == True
    assert settings.get('repeat') == False
    assert settings.get('debug') == False
    assert settings.get('alter_history') == True
    assert settings.get('history_limit') == 0
    assert settings.get('instant_mode') == False
    assert settings.get('exclude_rules') == []
    assert settings.get('excluded_search_path_prefixes') == []