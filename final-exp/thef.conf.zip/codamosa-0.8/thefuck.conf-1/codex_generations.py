

# Generated at 2022-06-12 10:01:08.987990
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir.name == '.thefuck'
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init(None)
    assert settings.user_dir.name == '.thefuck'

# Generated at 2022-06-12 10:01:19.796295
# Unit test for method init of class Settings
def test_Settings_init():
    args = lambda: None
    args.history_limit = 7
    args.require_confirmation = True
    args.no_colors = True
    args.wait_command = 4
    args.wait_slow_command = 2
    args.alter_history = True
    args.repeat = False
    args.exclude_rules = ['long_sed_command']
    args.debug = False
    args.priority = {'long_sed_command': 10, 'no_command': 20}
    args.slow_commands = ['ls', 'll']
    args.excluded_search_path_prefixes = ['/usr/local']
    args.rules = ['ls', 'rm']
    args.num_close_matches = 2
    args.instant_mode = False
    settings.init(args)

# Generated at 2022-06-12 10:01:27.538118
# Unit test for method init of class Settings
def test_Settings_init():
    os.environ['XDG_CONFIG_HOME'] = '/home/user/.config'
    settings.update(const.DEFAULT_SETTINGS)
    settings.init(args=None)

    # check if it is possible to get/set an attribute
    assert(settings.XDG_CONFIG_HOME == '/home/user/.config')
    settings.XDG_CONFIG_HOME = '/home/user/.config'

    # check if default values are loaded
    assert('DEBUG' not in settings.keys())
    assert('REPEAT' not in settings.keys())

    # check if a file created
    assert(os.path.exists('/home/user/.config/thefuck/settings.py'))
    # check if the file contains comments

# Generated at 2022-06-12 10:01:38.801737
# Unit test for method init of class Settings
def test_Settings_init():
    args = mock.Mock(
        yes=False,
        debug=False,
        repeat=None)

    # os.environ.update({
    #     'THEFUCK_REQUIRE_CONFIRMATION': None,
    #     'XDG_CONFIG_HOME': tempfile.gettempdir()
    # })
    # mock.patch.dict(os.environ, {
    #     'THEFUCK_REQUIRE_CONFIRMATION': None,
    #     'XDG_CONFIG_HOME': tempfile.gettempdir()
    # })


# Generated at 2022-06-12 10:01:49.193228
# Unit test for method init of class Settings
def test_Settings_init():
    import mock
    import sys
    import tempfile

    with mock.patch.object(Path, 'is_file', return_value=False), \
            mock.patch.object(Path, 'mkdir', return_value=None), \
            mock.patch.object(tempfile, '_RandomNameSequence'), \
            mock.patch.object(tempfile, 'mkdtemp') as mkdtemp, \
            mock.patch.dict('os.environ', {'HOME': '/home',
                                           'XDG_RUNTIME_DIR': '/run',
                                           'USER': 'user',
                                           'XDG_CONFIG_HOME': '/config'}):
        settings.init()
        assert settings['user_dir'] == '/config/thefuck'
        assert settings['require_confirmation'] is True


# Generated at 2022-06-12 10:01:53.702658
# Unit test for method init of class Settings
def test_Settings_init():
    settings_env = {'XDG_CONFIG_HOME': '/'}
    settings_env.update(const.ENV_TO_ATTR)
    with mock.patch.dict(os.environ, settings_env):
        with mock.patch('sys.argv', [sys.argv[0], '--yes']):
            settings.init()
            assert settings['require_confirmation'] == False



# Generated at 2022-06-12 10:02:03.793243
# Unit test for method init of class Settings
def test_Settings_init():
    args = object()
    settings = Settings(const.DEFAULT_SETTINGS)
    with mock.patch.object(Settings, '__init__', return_value=None):
        with mock.patch.object(Settings, '_setup_user_dir') as setup_user_dir:
            with mock.patch.object(Settings, '_init_settings_file') as init_settings_file:
                with mock.patch.object(Settings, '_settings_from_file') as settings_from_file:
                    with mock.patch.object(Settings, '_settings_from_env') as settings_from_env:
                        with mock.patch.object(Settings, '_settings_from_args') as settings_from_args:
                            settings.init(args=args)
                            init_settings_file.assert_called_once_with

# Generated at 2022-06-12 10:02:04.427036
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.init()

# Generated at 2022-06-12 10:02:13.347518
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init(args=None)
    assert settings['require_confirmation'] is True
    assert settings['no_colors'] is False
    assert settings['debug'] is False
    assert settings['history_limit'] is None
    assert settings['wait_command'] is 3
    assert settings['alter_history'] is False
    assert settings['slow_commands'] == []
    assert settings['exclude_rules'] == []
    assert settings['priority'] == {}
    assert settings['wait_slow_command'] is 9
    assert settings['instant_mode'] is False
    assert settings['excluded_search_path_prefixes'] == [
        '/usr']

# Generated at 2022-06-12 10:02:14.912791
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.rules == list(const.DEFAULT_SETTINGS['rules'])

# Generated at 2022-06-12 10:02:50.070552
# Unit test for method init of class Settings
def test_Settings_init():
    def fake_settings_from_file():
        return {'require_confirmation': False,
                'alternative_script': '$PYTHON',
                'alter_history': True,
                'history_limit': 10,
                'priority': {'brew': 100},
                'slow_commands': ['lein', 'react-native'],
                'wait_slow_command': 10,
                'exclude_rules': ['cat_is_awsome'],
                'excluded_search_path_prefixes': ['/home/user/work'],
                'num_close_matches': 3}


# Generated at 2022-06-12 10:02:50.540587
# Unit test for method init of class Settings

# Generated at 2022-06-12 10:02:59.556482
# Unit test for method init of class Settings
def test_Settings_init():
    _settings_from_file_mock = MagicMock(return_value={'jira_token':'abcde'})
    _settings_from_env_mock = MagicMock(return_value={'jira_url':'https://jira.com'})
    _settings_from_args_mock = MagicMock(return_value={'git_add':'True'})
    _get_user_dir_path_mock = MagicMock(return_value=Path('/tmp/test'))
    _setup_user_dir_mock = MagicMock()

# Generated at 2022-06-12 10:03:08.468881
# Unit test for method init of class Settings
def test_Settings_init():

    # Case: no exception raised
    def no_exception(settings):
        try:
            settings.init()
        except Exception:
            return False
        return True

    assert no_exception(settings), "Can't load settings."

    # Case: load settings from file
    path = settings.user_dir.joinpath('settings.py')
    with path.open(mode='w') as settings_file:
        settings_file.write(u'wait_slow_command = 10\n')
    settings.init()
    assert settings.get('wait_slow_command') == 10, "Can't load settings from file."

    # Case: load settings from env
    os.environ['THEFUCK_WAIT_SLOW_COMMAND'] = u'20'
    settings.init()

# Generated at 2022-06-12 10:03:09.187845
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.init() == None

# Generated at 2022-06-12 10:03:10.541860
# Unit test for method init of class Settings
def test_Settings_init():
    settings.__dict__.clear()
    settings.init()
    assert settings == Settings(const.DEFAULT_SETTINGS)

# Generated at 2022-06-12 10:03:20.150947
# Unit test for method init of class Settings
def test_Settings_init():
    def init_and_check(keys):
        settings.init()
        for key in keys:
            assert key in settings
            assert isinstance(settings[key], type(const.DEFAULT_SETTINGS[key]))
    # check one key
    os.environ['TF_INSTANT_MODE'] = "1"
    init_and_check(['instant_mode'])

    # check two keys
    os.environ['TF_INSTANT_MODE'] = '0'
    os.environ['TF_SHOW_REASON'] = '1'
    init_and_check(['instant_mode', 'show_reason'])

    # check three keys
    os.environ['TF_INSTANT_MODE'] = '0'
    os.environ['TF_SHOW_REASON'] = '0'


# Generated at 2022-06-12 10:03:23.167458
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()

    # Check if settings file exists
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.repeat == 1



# Generated at 2022-06-12 10:03:31.377261
# Unit test for method init of class Settings
def test_Settings_init():
    #test settings_from_file
    settings_path = settings._get_user_dir_path().joinpath('settings.py')
    settings_path.write_text("{}\nhistory_limit = 2000\n".format(const.SETTINGS_HEADER))
    settings.init()
    settings_path.unlink()
    assert settings["history_limit"] == 2000

    #test settings_from_args
    settings.init(argparse.Namespace(yes=False))
    assert settings["require_confirmation"] == False

    #test settings_from_env
    os.environ['THEFUCK_DEBUG'] = 'False'
    settings.init()
    assert settings["debug"] == False

# Generated at 2022-06-12 10:03:38.104838
# Unit test for method init of class Settings
def test_Settings_init():
    """Test cases for method init of class Settings"""
    global const, Settings

    const.ENV_TO_ATTR = {'TF_TIMEOUT': 'timeout'}
    const.DEFAULT_SETTINGS = {'timeout': 5}

    class Settings(object):
        _settings_from_env_called = False
        _settings_from_args_called = False


        def __init__(self):
            pass

        def update(self, *args, **kwargs):
            pass

        def _settings_from_env(self):
            self._settings_from_env_called = True
            return {'timeout': 42}

        def _settings_from_args(self, args):
            self._settings_from_args_called = True
            return {'timeout': 1337}

    settings = Settings()
    test_

# Generated at 2022-06-12 10:04:18.078116
# Unit test for method init of class Settings
def test_Settings_init():
    import shutil
    from time import time
    from .logs import log_to_file
    from .utils import get_all_executables

    # Run one time
    settings.init()
    assert settings.user_dir.is_dir()
    # Run two times
    settings.init()
    assert settings.user_dir.is_dir()

    # Create new settings.py
    user_dir = settings.user_dir
    settings_new_content = u'rules = [\'echo\']\n'
    shutil.copyfile(unicode(user_dir.joinpath('settings.py')),
                    unicode(user_dir.joinpath(u'settings.py.backup')))
    with user_dir.joinpath('settings.py').open(mode='w') as settings_file:
        settings_file

# Generated at 2022-06-12 10:04:19.497015
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == '~/.config/thefuck'
    assert__settings_match_default(settings)



# Generated at 2022-06-12 10:04:25.126271
# Unit test for method init of class Settings
def test_Settings_init():
    from .system import get_alias
    # with empty env
    settings.init()
    assert settings['wait_command'] == 3
    assert settings['require_confirmation'] is True
    # with env
    os.environ['THEFUCK_WAIT_COMMAND'] = "5"
    os.environ['THEFUCK_PRIORITY'] = \
        'fuck:100:fuckit:100:fuckyou:100:fuckoff:100'
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = "False"
    os.environ['THEFUCK_ALIAS'] = 'f'
    os.environ['THEFUCK_HISTORY_LIMIT'] = "100"
    os.environ['THEFUCK_EXCLUDE_RULES'] = "fuck"
   

# Generated at 2022-06-12 10:04:26.946111
# Unit test for method init of class Settings
def test_Settings_init():
    args = []
    settings.init(args)
    assert settings.user_dir is None
    assert settings.require_confirmation


# Generated at 2022-06-12 10:04:29.060147
# Unit test for method init of class Settings
def test_Settings_init():
    _settings = Settings(const.DEFAULT_SETTINGS)
    _settings.init()
    if _settings.user_dir.joinpath("thefuck").is_dir():
        return True
    if _settings.user_dir.joinpath("rules").is_dir():
        return True
    else:
        return False


# Generated at 2022-06-12 10:04:32.108312
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert len(settings.rules) == 2

# Generated at 2022-06-12 10:04:36.305709
# Unit test for method init of class Settings
def test_Settings_init():
    test_settings = Settings(const.DEFAULT_SETTINGS)

    # init should do nothing if no args
    test_settings.init()
    assert test_settings == const.DEFAULT_SETTINGS

    # init should take settings from args
    test_settings.init(Namespace(yes=True))
    assert test_settings['require_confirmation'] is False

    # init should take settings from args
    test_settings.init(Namespace(repeat=True))
    assert test_settings['repeat'] is True


# Generated at 2022-06-12 10:04:37.963182
# Unit test for method init of class Settings

# Generated at 2022-06-12 10:04:47.050822
# Unit test for method init of class Settings
def test_Settings_init():
    settings_file = settings.user_dir.joinpath('settings.py')
    with settings.user_dir.joinpath('settings.py').open() as old_settings_file:
        old_settings = old_settings_file.read()


# Generated at 2022-06-12 10:04:54.206748
# Unit test for method init of class Settings
def test_Settings_init():
    """
    This test shows the behaviour of the method init of class Settings.
    """
    import tempfile
    import os
    import shutil
    import argparse
    from thefuck.utils import memoize


    @memoize
    def get_default_settings():
        """
        This method returns the default value of the settings.
        """
        return Settings(const.DEFAULT_SETTINGS)


    def clear_environment():
        """
        This method clear the environment variables.
        """
        for var in os.environ.keys():
            if any(substring in var for substring in
                   const.ENV_TO_ATTR.keys()):
                del os.environ[var]


    def clear_settings(settings):
        """
        This method clear the settings attributes.
        """
        default_

# Generated at 2022-06-12 10:06:11.854025
# Unit test for method init of class Settings
def test_Settings_init():
    from unittest import TestCase
    import mock
    import os

    class SettingsTest(TestCase):
        def setUp(self):
            self.settings = Settings(const.DEFAULT_SETTINGS)
            self.settings.user_dir = Path('/test-user-dir')

            self.path_mock = mock.patch('thefuck.conf.settings.Path').start()
            self.path_mock.expanduser.return_value = self.path_mock
            self.path_mock.joinpath.return_value = self.path_mock
            self.path_mock.mkdir.return_value = self.path_mock

            self.environ_mock = mock.patch('thefuck.conf.settings.os.environ').start()
            self.environ_mock.get

# Generated at 2022-06-12 10:06:20.927317
# Unit test for method init of class Settings
def test_Settings_init():
    # When settings.py doesn't exist, create and init it
    user_dir = settings._get_user_dir_path()
    settings_path = user_dir.joinpath('settings.py')
    if settings_path.is_file():
        os.remove(settings_path)
    assert not settings_path.is_file()
    settings.init()
    assert settings_path.is_file()


# Generated at 2022-06-12 10:06:29.385133
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from unittest import patch
    from io import StringIO
    from contextlib import contextmanager

    def is_settings():
        return settings.__dict__.keys() == const.DEFAULT_SETTINGS.keys()

    marshal = StringIO()
    with mock_user_dir() as user_dir, patch('sys.stdout', marshal):
        with pytest.raises(Exception):
            with patched_sys_exc_info() as (type_, value, traceback):
                settings.init()
                assert is_settings() and not user_dir.is_dir()
                assert type_ == Exception
                assert value.args == ('Can\'t load settings from file',)

# Generated at 2022-06-12 10:06:37.327186
# Unit test for method init of class Settings
def test_Settings_init():
    """
    Test `Settings.init()` loads settings from file and env.
    """
    s = Settings()

    with tempfile.NamedTemporaryFile(delete=False) as tf:
        tf.write("slow_commands = ('git rebase', 'git am')\n"
                 "wait_slow_command = 2\n"
                 "instant_mode = True\n")

    os.environ['THEFUCK_SLOW_COMMANDS'] = 'git commit'
    os.environ['THEFUCK_INSTANT_MODE'] = 'False'
    os.environ['THEFUCK_WAIT_SLOW_COMMAND'] = '0'
    s.init()
    assert s['slow_commands'] == (u'git rebase', u'git am', u'git commit')

# Generated at 2022-06-12 10:06:45.569331
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import tempfile
    from shutil import rmtree
    from mock import patch

    test_dir = Path(tempfile.mkdtemp(prefix='thefuck-'))
    settings_file = test_dir.joinpath('settings.py')

    def create_test_settings():
        settings_file.open('w').close()
        with settings_file.open('a') as f:
            f.write('require_confirmation = True')

    # Test method init without args and test settings
    with patch('thefuck.settings._get_user_dir_path', return_value=test_dir):
        create_test_settings()
        settings.init()
        assert settings.user_dir == test_dir
        assert settings['require_confirmation']
        rmtree(settings.user_dir)

    # Test method

# Generated at 2022-06-12 10:06:47.357666
# Unit test for method init of class Settings
def test_Settings_init():
    test_args = type('', (), {})
    setattr(test_args, 'yes', True)
    settings.init(test_args)



# Generated at 2022-06-12 10:06:55.569941
# Unit test for method init of class Settings
def test_Settings_init():
    from thefuck import const
    from thefuck.config import _get_user_dir_path
    from thefuck.config import _init_settings_file
    from thefuck.config import _setup_user_dir
    from thefuck.config import _settings_from_env
    from thefuck.config import _settings_from_file
    from thefuck.config import _settings_from_args
    from thefuck.logs import exception
    from thefuck.conf import settings
    import os

    # unit test for method _get_user_dir_path of class Settings
    xdg_config_home = os.environ.get('XDG_CONFIG_HOME', '~/.config')
    user_dir = Path(xdg_config_home, 'thefuck').expanduser()

# Generated at 2022-06-12 10:06:57.927772
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.get('require_confirmation') == True
    assert settings.get('repeat') == False
    assert isinstance(settings.get('history_limit'), int)

# Generated at 2022-06-12 10:07:00.735920
# Unit test for method init of class Settings
def test_Settings_init():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    import sys
    test_settings.init(sys.argv)
    assert test_settings.get('user_dir') is not None

# Generated at 2022-06-12 10:07:09.423608
# Unit test for method init of class Settings
def test_Settings_init():
    class Args(object):
        def __init__(self, **kwargs):
            for key, val in kwargs.items():
                setattr(self, key, val)

    class FileSettings(object):
        script = 'echo fuck; echo 1'
        priority = {'echo': 50, 'fuck': 1000}
        rules = ['echo', 'correct_shit']
        no_colors = True
        history_limit = 0
        wait_command = 10
        wait_slow_command = 11
        exclude_rules = ['not_correct_shit']
        num_close_matches = 20
        slow_commands = ['slow_command']
        require_confirmation = True
        alter_history = True
        excluded_search_path_prefixes = ['fuck']
        instant_mode = True
        debug = True
       

# Generated at 2022-06-12 10:10:17.060879
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    with settings.user_dir.joinpath('settings.py').open(mode='w') as settings_file:
        settings_file.write(const.SETTINGS_HEADER)
        for setting in const.DEFAULT_SETTINGS.items():
            settings_file.write(u'# {} = {}\n'.format(*setting))

    os.environ["THEFUCK_DEBUG"] = 'true'
    os.environ["THEFUCK_REQUIRE_CONFIRMATION"] = 'true'
    os.environ["THEFUCK_WAIT_COMMAND"] = '1'
    os.environ["THEFUCK_RULES"] = 'DEFAULT_RULES:ls'

# Generated at 2022-06-12 10:10:18.502146
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir
    assert settings.rules
    assert settings.history_limit

# Generated at 2022-06-12 10:10:19.410074
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings = Settings()
    settings.init()

# Generated at 2022-06-12 10:10:27.767852
# Unit test for method init of class Settings

# Generated at 2022-06-12 10:10:36.219392
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings({
        'wait_command': 10,
        'priority': {'brew': 1, 'fuck': 1}
    })

    settings.init()

    assert settings.require_confirmation
    assert settings.history_limit == 1000
    assert settings.wait_command == 10
    assert settings.wait_slow_command == 15