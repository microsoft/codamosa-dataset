

# Generated at 2022-06-12 10:01:10.370032
# Unit test for method init of class Settings
def test_Settings_init():
    import os

    settings.init()
    assert os.path.exists(settings.user_dir.joinpath('settings.py'))
    assert hasattr(settings, 'rules')
    assert hasattr(settings, 'priority')
    assert hasattr(settings, 'exclude_rules')
    assert hasattr(settings, 'no_colors')
    assert hasattr(settings, 'wait_command')
    assert hasattr(settings, 'history_limit')
    assert hasattr(settings, 'require_confirmation')
    assert hasattr(settings, 'slow_commands')
    assert hasattr(settings, 'wait_slow_command')
    assert hasattr(settings, 'alter_history')
    assert hasattr(settings, 'excluded_search_path_prefixes')

# Generated at 2022-06-12 10:01:20.444820
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()

    settings_path = settings.user_dir.joinpath('settings.py')
    with settings_path.open(mode='w') as settings_file:
        settings_file.write(u'# {} = {}'.format('require_confirmation', not const.DEFAULT_SETTINGS['require_confirmation']))
    settings.init()
    assert not settings.require_confirmation

    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'false'
    settings.init()
    assert not settings.require_confirmation

    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'true'
    settings.init()
    assert settings.require_confirmation


# Generated at 2022-06-12 10:01:23.784958
# Unit test for method init of class Settings
def test_Settings_init():
    # kwargs
    settings.init(args={'yes': True})
    assert settings['require_confirmation'] == False
    assert settings['debug'] == None
    assert settings['repeat'] == None

    # env
    settings.init()
    assert settings['require_confirmation'] == True
    assert settings['debug'] == False
    assert settings['repeat'] == None

    # settings.py
    settings.init()

# Generated at 2022-06-12 10:01:35.738045
# Unit test for method init of class Settings

# Generated at 2022-06-12 10:01:42.182012
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

    assert settings['require_confirmation'] is True
    assert settings['wait_command'] == 3
    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['exclude_rules'] == []
    assert settings['no_colors'] is False
    assert settings['debug'] is False
    assert settings['history_limit'] == 1000
    assert settings['alter_history'] is False
    assert settings['priority'] == {}
    assert settings['wait_slow_command'] == 3
    assert settings['slow_commands'] == ['lein', 'react-native', 'gradle']
    assert settings['num_close_matches'] == 3
    assert settings['instant_mode'] is False
    assert settings['excluded_search_path_prefixes'] == []

    assert settings['repeat'] == 1

# Generated at 2022-06-12 10:01:52.249854
# Unit test for method init of class Settings
def test_Settings_init():
    # For method _get_user_dir_path().
    os.environ['XDG_CONFIG_HOME'] = '/home/s/.config'
    assert settings._get_user_dir_path() == Path('/home/s/.config/thefuck')

    # For method _setup_user_dir().
    settings.user_dir = None
    settings._setup_user_dir()
    assert settings.user_dir == Path('/home/s/.config/thefuck')

    # For method _settings_from_env().
    os.environ['TF_NO_COLORS'] = 'True'
    assert settings._settings_from_env() == {'no_colors': True}

    # For method _settings_from_args().

# Generated at 2022-06-12 10:01:57.102552
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    old_settings = settings
    settings = Settings(const.DEFAULT_SETTINGS)

    def restore():
        global settings
        settings = old_settings
    import atexit
    atexit.register(restore)

    settings.init(args=None)

    assert settings['require_confirmation'] == True
    assert settings['repeat'] == False
    assert settings['wait_command'] == 15


# Generated at 2022-06-12 10:02:06.303434
# Unit test for method init of class Settings
def test_Settings_init():
    #test case with all options
    settings.init(args = argparse.Namespace(
        yes=False,
        debug=False,
        repeat=0))
    assert(settings.get('require_confirmation') == False and settings.get('debug') == False and settings.get('repeat') == 0)

    #test case without options and without env
    settings.init(args = None)
    assert(settings.get('require_confirmation') and settings.get('debug') == False and settings.get('repeat') == 1)

    #test case with some options
    settings.init(args = argparse.Namespace(
        yes=True,
        debug=False,
        repeat=1))
    assert(settings.get('require_confirmation') == True and settings.get('debug') == False and settings.get('repeat') == 1)

# Generated at 2022-06-12 10:02:09.557917
# Unit test for method init of class Settings
def test_Settings_init():
    args = ['--yes', '--debug', '--repeat', '1']
    settings.init(args)
    assert settings['require_confirmation'] is False
    assert settings['debug'] is True
    assert settings['repeat'] == 1

# Generated at 2022-06-12 10:02:14.553030
# Unit test for method init of class Settings
def test_Settings_init():
    """Test init"""
    settings = Settings()

    class Args(object):
        pass

    args = Args()
    args.yes = True
    args.debug = True
    args.repeat = 3
    expected_settings = {'require_confirmation': False,
                         'repeat': 3,
                         'debug': True}
    settings.init(args)
    assert settings == expected_settings



# Generated at 2022-06-12 10:02:34.931815
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings = Settings(const.DEFAULT_SETTINGS)

    test_settings = const.DEFAULT_SETTINGS.copy()
    test_settings.update(settings._settings_from_env())

    assert settings.init() == test_settings

# Generated at 2022-06-12 10:02:43.255804
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile

    temp_dir = tempfile.mkdtemp()
    user_dir = Path(temp_dir, 'thefuck')
    user_dir.joinpath('settings.py').touch()
    _settings = Settings(const.DEFAULT_SETTINGS)

    _settings._get_user_dir_path = lambda: user_dir
    _settings.init()
    assert(user_dir.joinpath('settings.py').is_file())
    assert(_settings['debug'])
    assert(_settings['rules'])

    rules = ['TestRule']
    os.environ['THEFUCK_DEBUG'] = 'false'
    os.environ['THEFUCK_RULES'] = ':'.join(rules)
    _settings.init()
    assert(not _settings['debug'])

# Generated at 2022-06-12 10:02:47.357842
# Unit test for method init of class Settings
def test_Settings_init():
    args = type('', (object, ), {'yes': True, 'debug': True, 'repeat': 0})()
    test_settings = Settings(const.DEFAULT_SETTINGS)
    test_settings.init(args)
    assert test_settings.get('require_confirmation') is False
    assert test_settings.get('debug') is True
    assert test_settings.get('repeat') == 0

test_Settings_init()

# Generated at 2022-06-12 10:02:52.729791
# Unit test for method init of class Settings
def test_Settings_init():
    # given
    test_settings = Settings(const.DEFAULT_SETTINGS)
    import tempfile
    import shutil
    import os
    config_home = tempfile.mkdtemp()
    os.environ['XDG_CONFIG_HOME'] = config_home
    # when
    test_settings.init()
    # then
    assert test_settings['require_confirmation']
    assert test_settings['history_limit'] == 8
    assert test_settings['repeat'] == 1
    assert test_settings['no_colors'] == False
    shutil.rmtree(config_home)

# Generated at 2022-06-12 10:03:01.613271
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch
    from .rules import get_all_rules

    mock_get_all_rules = get_all_rules(include_deprecated=None, include_core=None, user_dir=None)
    mock_get_all_rules.return_value = []

    expected_settings = const.DEFAULT_SETTINGS
    expected_settings['conf.default'] = None
    expected_settings['rules'] = []

    with patch('thefuck.settings.get_all_rules', mock_get_all_rules):
        settings.init()

    import pprint
    pprint.pprint(settings)

    mock_get_all_rules.assert_called_once_with(include_deprecated=None, include_core=None, user_dir=None)
    assert settings == expected_settings


# Generated at 2022-06-12 10:03:05.102295
# Unit test for method init of class Settings
def test_Settings_init():
    class Args(object):
        yes = True
        debug = True
        repeat = True
    settings.init(Args())
    assert settings['require_confirmation'] == False
    assert settings['debug'] == True
    assert settings['repeat'] == True

# Generated at 2022-06-12 10:03:11.737609
# Unit test for method init of class Settings
def test_Settings_init():
    s = Settings()
    assert s.user_dir == Path('~', '.config', 'thefuck').expanduser()
    # For backward compatibility use legacy '~/.thefuck' if it exists:
    if Path('~', '.thefuck').expanduser().is_dir():
        assert s.user_dir == Path('~', '.thefuck').expanduser()

    # TODO: make the test less fragile
    sys.argv = ['thefuck']
    s.init()
    assert s.user_dir == Path('~', '.config', 'thefuck').expanduser()
    # For backward compatibility use legacy '~/.thefuck' if it exists:
    if Path('~', '.thefuck').expanduser().is_dir():
        assert s.user_dir == Path('~', '.thefuck').expanduser()

   

# Generated at 2022-06-12 10:03:15.171079
# Unit test for method init of class Settings
def test_Settings_init():
    # Set `os.environ` to `{}` to prevent unpredictable side-effects
    # (env variables)
    os.environ = dict()

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()



# Generated at 2022-06-12 10:03:23.822623
# Unit test for method init of class Settings
def test_Settings_init():
    args = Mock(spec=['yes', 'debug', 'repeat'])
    args.yes = False
    args.debug = False
    args.repeat = False
    settings_copy = settings.copy()
    settings.init(args)
    assert settings_copy == settings
    assert not settings['require_confirmation']
    assert settings['debug']
    assert settings['repeat']

    args.yes = True
    args.debug = False
    args.repeat = False
    settings.init(args)
    assert not settings['require_confirmation']

    args.yes = False
    args.debug = True
    args.repeat = False
    settings.init(args)
    assert settings['debug']

    args.yes = False
    args.debug = False
    args.repeat = 123
    settings.init(args)

# Generated at 2022-06-12 10:03:32.882031
# Unit test for method init of class Settings
def test_Settings_init():
    import mock
    import tempfile

    user_dir = tempfile.TemporaryDirectory()
    mock_settings = tempfile.NamedTemporaryFile('w', suffix='.py', dir=user_dir.name)
    mock_settings.write(const.SETTINGS_HEADER)
    mock_settings.write('RULES = ["test_rule"]\n')
    mock_settings.write('WAIT_COMMAND = 2\n')
    mock_settings.write('WAIT_SLOW_COMMAND = 1\n')
    mock_settings.write('ALTER_HISTORY = False')
    mock_settings.flush()
    mock_args = mock.Mock()
    mock_args.yes = True
    mock_args.repeat = 10
    mock_args.debug = True

# Generated at 2022-06-12 10:04:20.031144
# Unit test for method init of class Settings
def test_Settings_init():
    from .system import create_file, clear_directory
    from .logs import exception

    with clear_directory(settings.user_dir) as reset_user_dir:
        create_file('settings.py', "", settings.user_dir)
        settings.init()
        assert settings.require_confirmation is False
        assert settings.repeat is True

        with create_file('settings.py', const.SETTINGS_HEADER +
                         'require_confirmation = True\n'
                         'python = "python2"',
                         settings.user_dir) as replace_settings:
            settings.init()
            assert settings.require_confirmation is True


# Generated at 2022-06-12 10:04:25.474693
# Unit test for method init of class Settings
def test_Settings_init():
    global settings

    settings.init()
    assert settings == const.DEFAULT_SETTINGS
    settings['require_confirmation'] = True
    settings['rules'] = ['git_add', 'git_push']
    settings['exclude_rules'] = ['git_push']

    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'false'
    os.environ['THEFUCK_RULES'] = 'git_commit:git_commit_amend'
    os.environ['THEFUCK_EXCLUDE_RULES'] = 'DEFAULT_RULES'

    settings.init()
    assert settings['require_confirmation'] == False
    assert settings['rules'] == ['git_commit', 'git_commit_amend']
    assert settings['exclude_rules'] == const.DEFAULT

# Generated at 2022-06-12 10:04:33.214050
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.priority == {}
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.alter_history == False
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.num_close_matches == 3
    assert settings.repeat == False
    assert settings.debug == False
    assert settings.instant_mode == False

# Generated at 2022-06-12 10:04:34.236998
# Unit test for method init of class Settings
def test_Settings_init():
    """Unit test for method init of class Settings"""
    assert settings.init() == 0

# Generated at 2022-06-12 10:04:44.165915
# Unit test for method init of class Settings
def test_Settings_init():
    """Test init method of class Settings"""
    def _settings_from_file():
        """Mock method `_settings_from_file`"""
        return {}

    def _settings_from_env():
        """Mock method `_settings_from_env`"""
        return {}

    def _settings_from_args(args):
        """Mock method `_settings_from_args`"""
        return {}

    def _get_user_dir_path():
        """Mock method `_get_user_dir_path`"""
        return '/home/user/.config/thefuck'

    def _init_settings_file():
        """Mock method `_init_settings_file`"""
        pass

    settings._get_user_dir_path = _get_user_dir_path
    settings._init_settings_file = _

# Generated at 2022-06-12 10:04:45.442391
# Unit test for method init of class Settings
def test_Settings_init():
    load_source('settings', const.SETTINGS_HEADER)


# Generated at 2022-06-12 10:04:48.163715
# Unit test for method init of class Settings
def test_Settings_init():
    import thefuck.main as main
    args = main.parse_arguments(['-d'])
    settings.init(args)
    assert settings.get('debug')==True
    settings.init()
    assert settings.get('debug')==False

# Generated at 2022-06-12 10:04:49.719039
# Unit test for method init of class Settings
def test_Settings_init():
    args = '--yes'
    settings.init(args)
    assert settings['require_confirmation'] == False



# Generated at 2022-06-12 10:04:55.891339
# Unit test for method init of class Settings
def test_Settings_init():
    def settings_file_exists_function_exists(s):
        assert os.path.isfile(os.path.join(settings.user_dir, 'settings.py'))

    def test_return_value_settings_from_file(s):
        assert s._settings_from_file() == {'wait_slow_command': 5}

    def test_return_value_settings_from_env(s):
        assert s._settings_from_env() == {'wait_slow_command': 4}

    def test_return_value_settings_from_args(s):
        assert s._settings_from_args('args') == {'require_confirmation': True}

    settings_file_exists_function_exists(settings)
    settings.init()

# Generated at 2022-06-12 10:05:03.704292
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .logs import log
    from .which import which

    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.repeat == False
    assert exception._logger == log._logger
    assert which._cache == {}

# Generated at 2022-06-12 10:05:57.824252
# Unit test for method init of class Settings
def test_Settings_init():
    args = lambda **kwargs: type('Args', (object,), kwargs)

    assert 'require_confirmation' not in settings
    assert 'debug' not in settings
    assert 'repeat' not in settings
    settings.init(args())
    assert settings['require_confirmation'] is True
    assert settings['debug'] is False
    assert settings['repeat'] is 1

    for key in ('require_confirmation', 'debug', 'repeat'):
        assert key not in settings

    settings.init(args(yes=True))
    assert settings['require_confirmation'] is False
    settings.init(args(debug=True))
    assert settings['debug'] is True
    settings.init(args(repeat=2))
    assert settings['repeat'] is 2

# Generated at 2022-06-12 10:06:04.882494
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    args = type('args', (object,), {'debug': True, 'yes': False, 'repeat': True})()
    settings.init(args)
    assert settings['require_confirmation'] == False
    assert settings['debug'] == True
    assert settings['repeat'] == True
    assert settings['history_limit'] == 100
    assert settings['wait_command'] == 3
    assert settings['wait_slow_command'] == 10
    assert settings['require_confirmation'] == False
    assert settings['no_colors'] == False
    assert settings['debug'] == True
    assert settings['alter_history'] == True
    assert settings['instant_mode'] == True
    assert settings['slow_commands'] == ['.*']
    assert settings['num_close_matches'] == 3

# Generated at 2022-06-12 10:06:12.134948
# Unit test for method init of class Settings
def test_Settings_init():
    class Args():
        def __init__(self, **kwargs):
            for key, val in kwargs.items():
                setattr(self, key, val)

    from .logs.exceptions import MoreThanOneCommandFound
    from .logs import exception
    from . import rules
    import sys

    settings.init()
    assert settings.user_dir.endswith('thefuck')
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES

    settings = Settings()
    try:
        # raise exception to test exception handler
        settings.init()
        assert False
    except MoreThanOneCommandFound:
        pass
    assert settings.user_dir.endswith('thefuck')
    assert settings.user_dir

# Generated at 2022-06-12 10:06:16.068819
# Unit test for method init of class Settings
def test_Settings_init():
    args = type("test_args", (object, ), {'yes': True, 'debug': False, 'repeat': 0})
    settings.init(args)
    assert settings.require_confirmation == False
    assert settings.debug == False
    assert settings.repeat == 0

# Generated at 2022-06-12 10:06:24.576471
# Unit test for method init of class Settings
def test_Settings_init():
    class Args(object):
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)

    class FakeEnv(object):
        def __init__(self, env):
            self._env = env

        def __getitem__(self, item):
            return self._env[item]

        def __contains__(self, item):
            return item in self._env

        def get(self, item, default=None):
            return self._env.get(item, default)

    # With empty env and args
    os.environ = {}
    args = Args()
    settings.init(args)
    assert not settings['require_confirmation']
    assert not settings['repeat']
    assert not settings['debug']

    #

# Generated at 2022-06-12 10:06:32.458748
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch
    from .logs import exception

    args = lambda: None
    args.repeat = None
    args.debug = None
    args.yes = None

# Generated at 2022-06-12 10:06:41.406615
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import _logs_dir

    args = lambda **kwargs: type('Args', (), kwargs)()
    original_environ = dict(os.environ)

    # default settings
    try:
        del settings['DEBUG']
    except KeyError:
        pass
    settings.init()
    assert settings['DEBUG'] == False

    settings.init(args=args(debug=True))
    assert settings['DEBUG'] == True
    settings.init(args=args(yes=True))
    assert settings['require_confirmation'] == False

    # settings from `settings.py`
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'False'
    settings.init()
    assert settings['require_confirmation'] == False

    # settings from env

# Generated at 2022-06-12 10:06:46.483456
# Unit test for method init of class Settings
def test_Settings_init():
    # Fill settings with custom YES-value if argument required it
    assert settings.require_confirmation == True
    settings.init(args=MockArgs(yes=True))
    assert settings.require_confirmation == False
    # Fill settings with custom DEBUG-value if argument required it
    assert settings.debug == False
    settings.init(args=MockArgs(debug=True))
    assert settings.debug == True
    # Fill settings with custom REPEAT-value if argument required it
    assert settings.repeat == None
    settings.init(args=MockArgs(repeat=2))
    assert settings.repeat == 2



# Generated at 2022-06-12 10:06:49.972432
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert 'PYTHONPATH' not in settings
    assert settings.wait_command == const.DEFAULT_SETTINGS['wait_command']
    assert settings.no_colors is False



# Generated at 2022-06-12 10:06:55.488123
# Unit test for method init of class Settings
def test_Settings_init():
    test_args = []
    # a function
    assert _test_settings_init_exe(settings, test_args)
    test_args = ['-y']
    # a function
    assert _test_settings_init_exe(settings, test_args)
    test_args = ['--debug']
    # a function
    assert _test_settings_init_exe(settings, test_args)
    test_args = ['--repeat']
    # a function
    assert _test_settings_init_exe(settings, test_args)


# Generated at 2022-06-12 10:09:02.646114
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.user_dir.is_dir()
    assert not settings.require_confirmation
    assert settings.rules == const.DEFAULT_RULES
    assert settings.priority == {}
    assert settings.wait_command == 0

# Generated at 2022-06-12 10:09:04.030011
# Unit test for method init of class Settings
def test_Settings_init():
    if not settings.init():
        import Test.test_thefuck_settings
        Test.test_thefuck_settings.test_Settings_init()

# Generated at 2022-06-12 10:09:11.602391
# Unit test for method init of class Settings
def test_Settings_init():
    # Given settings
    class _TestSettings(Settings):
        _settings = {'require_confirmation': False,
                     'rules': ['ls_command']}

        def _init_settings_file(self):
            pass

        def _setup_user_dir(self):
            pass

        def _settings_from_file(self):
            return self._settings


# Generated at 2022-06-12 10:09:16.993322
# Unit test for method init of class Settings
def test_Settings_init():
    # Ensures that it will return default config when it can't load
    # settings from file or env
    settings._init_settings_file = lambda: None
    settings._settings_from_file = lambda: {}
    settings._settings_from_env = lambda: {}
    settings._settings_from_args = lambda x: {}
    settings.init()

    for key, val in const.DEFAULT_SETTINGS.items():
        assert settings[key] == val



# Generated at 2022-06-12 10:09:22.466496
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.priority == {}
    assert settings.no_colors == False
    assert settings.require_confirmation == True
    assert settings.alter_history == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.exclude_rules == []
    assert settings.num_close_matches == 3
    assert settings.slow_commands == []
    assert settings.instant_mode == False
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == None
    assert settings.debug == False



# Generated at 2022-06-12 10:09:30.831831
# Unit test for method init of class Settings
def test_Settings_init():
    import mock
    with mock.patch('thefuck.settings.Settings._settings_from_file') as settings_from_file, \
            mock.patch('thefuck.settings.Settings._settings_from_env') as settings_from_env, \
            mock.patch('thefuck.settings.Settings._settings_from_args') as settings_from_args, \
            mock.patch('thefuck.settings.Settings._setup_user_dir'), \
            mock.patch('thefuck.settings.Settings._init_settings_file') as init_settings_file:
        settings_from_file.return_value = {'rules': ['some-rule']}
        settings_from_args.return_value = {'repeat': True}
        settings_from_env.return_value = {'require_confirmation': False}

# Generated at 2022-06-12 10:09:31.336712
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

# Generated at 2022-06-12 10:09:32.910063
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init(args={'yes':True, 'debug':True})
    assert settings.yes == False
    assert settings.debug == True

# Generated at 2022-06-12 10:09:36.336805
# Unit test for method init of class Settings
def test_Settings_init():
    argv = ['--repeat', '2', '--debug', 'True']
    settings = Settings()
    settings.init(args=argv)
    assert settings.require_confirmation is True
    assert settings.debug is True
    assert settings.repeat is 2


# Generated at 2022-06-12 10:09:39.700355
# Unit test for method init of class Settings
def test_Settings_init():
    settings._setup_user_dir()
    settings._init_settings_file()
    settings.update(settings._settings_from_file())
    settings.update(settings._settings_from_env())
    settings.update(settings._settings_from_args(None))

    assert os.path.isfile(os.path.expanduser("~/.config/thefuck/settings.py")) == True