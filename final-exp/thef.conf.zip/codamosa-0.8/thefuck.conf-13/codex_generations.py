

# Generated at 2022-06-12 10:01:15.915980
# Unit test for method init of class Settings
def test_Settings_init():
    env = {'TF_ALTER_HISTORY': 'true', 'TF_CUSTOM': 'true'}
    args = None
    with mock.patch.object(settings, '_settings_from_file', return_value={'alter_history': True}),\
        mock.patch.object(settings, '_settings_from_env', return_value=env),\
        mock.patch.object(settings, '_settings_from_args', return_value=args):
        settings.init()
        assert settings.get('custom')
        assert settings.get('alter_history')
        assert settings.get('TF_CUSTOM')


# Generated at 2022-06-12 10:01:18.396849
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init(args=None)
    assert settings.get('require_confirmation') == True
    assert settings.get('no_colors') == False

# Generated at 2022-06-12 10:01:26.855738
# Unit test for method init of class Settings
def test_Settings_init():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    test_settings._setup_user_dir = lambda: None
    test_settings._init_settings_file = lambda: None
    test_settings._settings_from_file = lambda: {'a': 1, 'b': 2, 'c': 3}
    test_settings._settings_from_env = lambda: {'b': 3, 'd': 4}
    test_settings._settings_from_args = lambda: {'b': 4, 'e': 5}
    test_settings.init()
    assert test_settings['a'] == 1
    assert test_settings['b'] == 4
    assert test_settings['c'] == 3
    assert test_settings['d'] == 4
    assert test_settings['e'] == 5

# Generated at 2022-06-12 10:01:38.296549
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import log_exception
    from functools import partial

    # Test with exception
    # FIXME __init__ of Settings not working properly if Settings.init raises an exception
    # (the line `self.update(self._settings_from_file())` is not working right)
    # log_exception = partial(log_exception, exit=False)
    # settings = Settings(const.DEFAULT_SETTINGS)
    # settings.update = lambda *_: 42
    # settings.init()
    # assert settings == const.DEFAULT_SETTINGS

    # Test with args
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.update = lambda *_: 42

# Generated at 2022-06-12 10:01:40.648236
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir.joinpath('settings.py').is_file()

# Generated at 2022-06-12 10:01:51.152793
# Unit test for method init of class Settings
def test_Settings_init():
    from . import logs
    from .logs import capture_logs
    from .settings import const, settings
    from six import StringIO
    import os
    import pytest

    with capture_logs(logs.DEBUG) as captured_logs:
        settings.init()
    assert not captured_logs

    with capture_logs(logs.DEBUG) as captured_logs:
        settings.init()
    assert not captured_logs

    assert settings.user_dir
    assert settings.user_dir.endswith('.thefuck') or\
        settings.user_dir.endswith('.config/thefuck')


# Generated at 2022-06-12 10:02:01.180391
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    test_settings = Settings(const.DEFAULT_SETTINGS)

    test_settings.init()
    assert test_settings == settings

    test_settings.init(args=Namespace(yes=True))
    assert test_settings['require_confirmation'] == False
    assert test_settings == settings

    test_settings.init(args=Namespace(debug=True))
    assert test_settings['debug'] == True
    assert test_settings == settings

    test_settings.init(args=Namespace(repeat=2))
    assert test_settings['repeat'] == 2
    assert test_settings == settings

    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'True'
    test_settings.init()
    assert test_settings['require_confirmation'] == True

# Generated at 2022-06-12 10:02:04.160218
# Unit test for method init of class Settings
def test_Settings_init():
    args = type('', (), {'yes': 'abc'})()
    settings_ = Settings(const.DEFAULT_SETTINGS)
    settings_.init(args)

    assert 'yes' not in settings_
    assert settings_['require_confirmation'] is False

# Generated at 2022-06-12 10:02:14.790164
# Unit test for method init of class Settings
def test_Settings_init():
    """Test settings init"""
    configuration = Settings()
    configuration.init()
    assert configuration['require_confirmation'] is True
    assert configuration['wait_command'] == 0.5
    assert configuration['wait_slow_command'] == 0.5
    assert configuration['history_limit'] == None
    assert configuration['rules'] == [
        'echo', 'git', 'mercurial', 'noop', 'npm', 'pip', 'poetry', 'sudo', 'yarn']
    assert configuration['priority'] == {'noop': 9000}
    assert configuration['exclude_rules'] == []
    assert configuration['repeat'] == False
    assert configuration['slow_commands'] == [
        'lein', 'reboot', 'vagrant']
    assert configuration['no_colors'] is False
    assert configuration['debug'] is False

# Generated at 2022-06-12 10:02:19.171131
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir.is_dir()
    user_settings_path = settings.user_dir.joinpath('settings.py')
    assert user_settings_path.is_file()
    assert user_settings_path.read_text().startswith(const.SETTINGS_HEADER)


# Unit tests for method _get_user_dir_path of class Settings

# Generated at 2022-06-12 10:02:49.947736
# Unit test for method init of class Settings
def test_Settings_init():
    import sys
    from os import environ, path
    from tempfile import mkdtemp
    from shutil import rmtree

    def make_settings_path():
        return '{0}/test-settings.py'.format(settings.user_dir)

    def make_temp_dir():
        return mkdtemp()

    def cleanup_temp_dir(temp_dir):
        rmtree(temp_dir)


# Generated at 2022-06-12 10:02:56.512799
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    # For testing purpose we need to use the same dir
    settings._get_user_dir_path = lambda: Path('~/.thefuck')
    settings.init()
    assert settings.user_dir == Path('~/.thefuck').expanduser()

    settings = Settings(const.DEFAULT_SETTINGS)
    settings._get_user_dir_path = lambda: Path('~/.config/thefuck')
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()



# Generated at 2022-06-12 10:03:06.024871
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import mock
    import sys

    def fake_exception(message, exc_info):
        fake_exception.message = message
        fake_exception.exc_info = exc_info

    sys.modules['thefuck.logs'].exception = fake_exception

    with mock.patch('thefuck.settings.const.DEFAULT_SETTINGS', {'key': 'def'}):
        with mock.patch('os.environ', {'TF_KEY': 'env'}):
            settings = Settings()
            settings.init(mock.Mock(key='args'))

# Generated at 2022-06-12 10:03:16.597730
# Unit test for method init of class Settings
def test_Settings_init():

    # Set up the testing environment
    const.DEFAULT_SETTINGS['require_confirmation'] = False
    const.DEFAULT_SETTINGS['repeat'] = False
    const.DEFAULT_SETTINGS['debug'] = False
    const.DEFAULT_SETTINGS['no_colors'] = False
    const.DEFAULT_SETTINGS['history_limit'] = 1000
    const.DEFAULT_SETTINGS['rules'] = ['some']
    const.DEFAULT_SETTINGS['exclude_rules'] = []
    const.DEFAULT_SETTINGS['slow_commands'] = []
    const.DEFAULT_SETTINGS['wait_command'] = 10
    const.DEFAULT_SETTINGS['wait_slow_command'] = 10
    const.DEFAULT_SETTINGS['alter_history'] = False
    const

# Generated at 2022-06-12 10:03:19.322178
# Unit test for method init of class Settings
def test_Settings_init():
    """Settings should store default settings from const.py at startup."""
    assert settings.init()
    for key, value in const.DEFAULT_SETTINGS.items():
        assert settings[key] == value

# Generated at 2022-06-12 10:03:28.573005
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings['aliases'] == const.DEFAULT_ALIASES
    assert settings['verbose'] == const.DEFAULT_VERBOSE
    assert settings['wait_command'] == const.DEFAULT_WAIT_COMMAND
    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['priority'] == const.DEFAULT_PRIORITY
    assert settings['exclude_rules'] == const.DEFAULT_EXCLUDE_RULES
    assert settings['history_limit'] == const.DEFAULT_HISTORY_LIMIT
    assert settings['wait_slow_command'] == const.DEFAULT_WAIT_SLOW_COMMAND
    assert settings['slow_commands'] == const.DEFAULT_SLOW_COMMANDS

# Generated at 2022-06-12 10:03:34.475782
# Unit test for method init of class Settings
def test_Settings_init():
    class Args(object):
        def __init__(self, yes=False, debug=False, repeat=None):
            self.yes = yes
            self.debug = debug
            self.repeat = repeat

    args = Args()
    settings.init(args)
    assert settings['no_colors'] == False

    args = Args(yes=True)
    settings.init(args)
    assert settings['require_confirmation'] == False

    args = Args(debug=True)
    settings.init(args)
    assert settings['debug']

    args = Args(repeat=1)
    settings.init(args)
    assert settings['repeat'] == 1

# Generated at 2022-06-12 10:03:41.557757
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import LogCapture

    def test_settings_from_file(Settings):
        assert Settings.require_confirmation is False
        assert Settings.rules == const.DEFAULT_RULES

    def test_settings_from_env(Settings):
        assert Settings.require_confirmation is True
        assert Settings.rules == ['test']

    def test_settings_from_args(Settings):
        assert Settings.repeat is 123
        assert Settings.rules == ['echo']

    def patched_import(name, globals=None, locals=None, fromlist=(), level=0):
        if name == 'settings':
            return lambda: test_settings_from_file(Settings)
        raise ImportError

    def patched_get(self, item, default=None):
        if item == 'XDG_CONFIG_HOME':
            return

# Generated at 2022-06-12 10:03:51.016318
# Unit test for method init of class Settings
def test_Settings_init():
    # reset value
    settings = Settings(const.DEFAULT_SETTINGS)
    from . import __version__
    from .logs import logger
    from .logs import ColoredFormatter

    # output colored logs
    logger.setLevel(10)
    handler = logging.StreamHandler()
    formatter = ColoredFormatter(
        '%(log_color)s%(levelname)-5s %(name)-3s %(asctime)s: %(message)s',
        datefmt='%H:%M:%S')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # construct args
    args = lambda **kwargs: type('', (), kwargs)
    args_yes = args(yes=True)
    args_debug = args(debug=True)


# Generated at 2022-06-12 10:04:00.142979
# Unit test for method init of class Settings
def test_Settings_init():
    import sys
    import os
    import tempfile
    from contextlib import contextmanager
    from six import StringIO
    from tests.runner import runner

    os.environ['TF_REQUIRE_CONFIRMATION'] = "FALSE"
    os.environ['TF_DEBUG'] = "TRUE"

    @contextmanager
    def capture_sys_output():
        capture_out, capture_err = StringIO(), StringIO()
        current_out, current_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = capture_out, capture_err
            yield capture_out, capture_err
        finally:
            sys.stdout, sys.stderr = current_out, current_err


# Generated at 2022-06-12 10:04:34.445019
# Unit test for method init of class Settings
def test_Settings_init():
    """Unit test for Settings.init"""
    import os
    os.environ['XDG_CONFIG_HOME'] = '~/config'
    os.environ['TF_NO_COLORS'] = 'TRUE'
    os.environ['TF_DEBUG'] = 'TRUE'
    os.environ['TF_REQUIRE_CONFIRMATION'] = 'FALSE'
    os.environ['TF_EXCLUDE_RULES'] = ':DEFAULT_RULES:'
    os.environ['TF_EXCLUDE_SEARCH_PATH_PREFIXES'] = ':echo:echo2'
    os.environ['TF_PRIORITY'] = 'regex=1:echo=2'
    os.environ['TF_SLOW_COMMANDS'] = 'echo:echo2'

# Generated at 2022-06-12 10:04:36.307603
# Unit test for method init of class Settings
def test_Settings_init():
    _settings = Settings(const.DEFAULT_SETTINGS)
    _settings.init()
    assert _settings == settings

# Generated at 2022-06-12 10:04:45.929063
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

    assert settings['debug'] == False
    assert settings['require_confirmation'] == True
    assert settings['wait_command'] == 2
    assert settings['wait_slow_command'] == 15
    assert settings['history_limit'] == 1000
    assert settings['rules'] == ['git_push', 'git_add', 'brew_install',
                                 'pip_install', 'cabal_install',
                                 'long_option', 'sudo', 'apt_get',
                                 'yum', 'pacman', 'emerge', 'macports',
                                 'npm', 'composer', 'rvm', 'vagrant',
                                 'dotnet', 'stack', 'nuget',
                                 'stack_install', 'npm_install',
                                 'gvm']

# Generated at 2022-06-12 10:04:50.197964
# Unit test for method init of class Settings
def test_Settings_init():
    testargs = {
        'require_confirmation': True,
        'repeat': True,
        'debug': True
    }

    settings.init(testargs)

    assert 'require_confirmation' in settings
    assert not settings['require_confirmation']

    assert 'repeat' in settings
    assert settings['repeat']

    assert 'debug' in settings
    assert settings['debug']



# Generated at 2022-06-12 10:04:59.425466
# Unit test for method init of class Settings
def test_Settings_init():
    settings_dict = const.DEFAULT_SETTINGS
    settings_dict['user_dir'] = 'tmp'
    settings_dict['instant_mode'] = False
    settings_dict['require_confirmation'] = True
    settings_dict['wait_command'] = 10
    settings_dict['wait_slow_command'] = 3
    settings_dict['no_colors'] = False
    settings_dict['alter_history'] = True
    settings_dict['rules_dir'] = []
    settings_dict['priority'] = {}
    settings_dict['repeat'] = False
    settings_dict['debug'] = False
    settings_dict['exclude_rules'] = []
    settings_dict['history_limit'] = 50
    settings_dict['slow_commands'] = []

# Generated at 2022-06-12 10:05:07.278921
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .__main__ import main_args
    from .main import main

    argv = sys.argv
    settings.init(main_args)

    # Exceptions are captured in the method init of class Settings
    # Here we check if the `exception` method was called
    exception.assert_called_once()
    try:
        settings.init(main_args)
    except Exception as e:
        assert(e.message == "Can't load settings from file")
    else:
        assert(False)

    with open(settings.user_dir + '/settings.py', 'w') as f:
        f.write(const.SETTINGS_HEADER)
        f.write('rules = [\'fuck\', \'ls\']')

# Generated at 2022-06-12 10:05:17.454621
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.user_dir = Path('~/.config/thefuck').expanduser()
    settings.init()
    assert settings['rules'] == ['git_commit', 'git_push', 'git_rebase',
                                 'git_add', 'hg_commit', 'hg_push',
                                 'svn_revert', 'svn_ci', 'hg_update']
    assert settings['history_limit'] == 5
    assert settings['alter_history'] == True
    assert settings['wait_slow_command'] == 5
    assert settings['no_colors'] == False
    assert settings['debug'] == False
    assert settings['wait_command'] == 0
    assert settings['exclude_rules'] == []
    assert settings['require_confirmation'] == True


# Generated at 2022-06-12 10:05:26.409516
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

    assert settings['history_limit'] == const.DEFAULT_SETTINGS['history_limit']
    assert settings['wait_command'] == const.DEFAULT_SETTINGS['wait_command']
    assert settings['alter_history'] == const.DEFAULT_SETTINGS['alter_history']
    assert settings['priority'] == const.DEFAULT_SETTINGS['priority']
    assert settings['rules'] == const.DEFAULT_SETTINGS['rules']
    assert settings['require_confirmation'] == const.DEFAULT_SETTINGS['require_confirmation']
    assert settings['no_colors'] == const.DEFAULT_SETTINGS['no_colors']
    assert settings['debug'] == const.DEFAULT_SETTINGS['debug']
    assert settings['wait_slow_command'] == const.DEFAULT_SET

# Generated at 2022-06-12 10:05:33.932009
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import Mock
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile(prefix='thefuck-test_rule') as tmp_rule:
        tmp_rule.write(const.PYTHON_RULE_HEADER)
        tmp_rule.file.flush()

    settings = Settings()
    settings.update = Mock()
    settings.init()
    assert settings['rules_dir'] == '~/.config/thefuck/rules'
    assert settings['require_confirmation']
    assert settings['alter_history']
    assert settings['wait_command'] == 3
    assert settings['history_limit'] == 10
    assert settings['rules'] == [tmp_rule.name]

    settings.init(args=Mock(yes=True, repeat=False))
    assert settings['require_confirmation'] is False
    assert settings

# Generated at 2022-06-12 10:05:42.942233
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    settings._setup_user_dir = lambda: None

    exception = mock.Mock()

# Generated at 2022-06-12 10:06:35.402486
# Unit test for method init of class Settings
def test_Settings_init():
    from .system import TemporaryDirectory
    from .utils import get_all_settings

    args = ['thefuck', 'ls', '--yes']
    with TemporaryDirectory() as user_dir:
        settings = Settings(const.DEFAULT_SETTINGS)
        settings.init(args)

        all_settings = get_all_settings(args)
        assert settings == all_settings

# Generated at 2022-06-12 10:06:44.054874
# Unit test for method init of class Settings
def test_Settings_init():
    class Args():
        def __init__(self, yes=False, debug=False, repeat=False):
            self.yes = yes
            self.debug = debug
            self.repeat = repeat


# Generated at 2022-06-12 10:06:48.173019
# Unit test for method init of class Settings
def test_Settings_init():
    argv = ['thefuck', '--yes', '--repeat', '2', 'ls']
    from .test.py_test import parse_args

    args = parse_args(argv)
    settings.init(args=args)
    assert settings.require_confirmation is False
    assert settings.repeat is 2
    assert settings.rules == const.DEFAULT_RULES

# Generated at 2022-06-12 10:06:56.370249
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['exclude_rules'] == []
    assert settings['require_confirmation'] is True
    assert settings['wait_command'] == 0
    assert settings['slow_commands'] == []
    assert settings['wait_slow_command'] == 5
    assert settings['alter_history'] is False
    assert settings['excluded_search_path_prefixes'] == []
    assert settings['no_colors'] is False
    assert settings['debug'] is False
    assert settings['rule_priority'] == {}
    assert settings['history_limit'] == None
    assert settings['instant_mode'] is False
    assert settings['repeat'] == False
    assert settings['num_close_matches'] == 1

# Generated at 2022-06-12 10:07:05.277968
# Unit test for method init of class Settings
def test_Settings_init():
    import unittest
    import mock

    # Settings inheritance, mock
    set_up = mock.MagicMock()
    set_up.user_dir = '/path/to/user_dir'

    # Settings from file
    set_up._init_settings_file = mock.MagicMock()
    set_up._settings_from_file = mock.MagicMock(return_value={'value': 'from_file'})

    # Settings from env
    os.environ['TF_VALUE'] = 'from_env'
    set_up._settings_from_env = mock.MagicMock(return_value={'value': 'from_env'})

    # Settings from args
    set_up._settings_from_args = mock.MagicMock(return_value={'value': 'from_args'})

    # Except Exception


# Generated at 2022-06-12 10:07:09.874079
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)

    # return {} when args are none
    assert settings._settings_from_args(None) == {}

    # load option args
    args = type('args', (object,), {'yes': True, 'debug': True, 'repeat': True})()
    assert settings._settings_from_args(args) == {
        'require_confirmation': False,
        'debug': True,
        'repeat': True}

    # load dict from env
    os.environ['TF_PRIORITY'] = 'foo=1:bar=2'
    os.environ['TF_WAIT_COMMAND'] = '10'
    os.environ['TF_INSTANT_MODE'] = 'true'

# Generated at 2022-06-12 10:07:13.074694
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings._get_user_dir_path() == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()

# Test for method _settings_from_env of class Settings

# Generated at 2022-06-12 10:07:16.466676
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile

    settings.init()
    assert settings.user_dir == Path(tempfile.gettempdir()).joinpath('.config', 'thefuck')
    assert settings.user_dir.joinpath('rules').is_dir()
    assert settings.user_dir.joinpath('settings.py').is_file()

# Generated at 2022-06-12 10:07:19.655545
# Unit test for method init of class Settings
def test_Settings_init():
    s = Settings(const.DEFAULT_SETTINGS)
    settings_path = settings._get_user_dir_path().joinpath('settings.py')
    print(settings_path)
    print(settings)
    if settings_path.is_file():
        os.remove(settings_path)

# Generated at 2022-06-12 10:07:26.071338
# Unit test for method init of class Settings
def test_Settings_init():
    # Init settings with args
    settings.init(Namespace(yes=True, debug=True, repeat=3))
    assert not settings.require_confirmation
    assert settings.debug
    assert settings.repeat == 3
    assert settings.rules == const.DEFAULT_RULES

    # Init settings with env
    settings.init()
    assert settings.require_confirmation
    assert not settings.debug
    assert settings.repeat == 1
    assert settings.rules == const.DEFAULT_RULES

    # Init settings with file
    settings.init()
    assert settings.require_confirmation
    assert not settings.debug
    assert settings.repeat == 1
    assert settings.rules == const.DEFAULT_RULES


# NOTE: recommended to be moved to separate file?

# Generated at 2022-06-12 10:10:05.947368
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init({'yes': True, 'debug': True, 'repeat': True})
    assert settings.require_confirmation is False
    assert settings.debug is True
    assert settings.repeat == '*'



# Generated at 2022-06-12 10:10:13.226331
# Unit test for method init of class Settings
def test_Settings_init():
    # mock setup_user_dir method
    def user_dir(self):
        self.user_dir = True
    Settings._setup_user_dir = user_dir

    # mock init_settings_file method
    def save_settings(self):
        self.settings_file = True
    Settings._init_settings_file = save_settings

    # mock settings_from_file method
    def settings_file(self):
        return {'log_file': 'log.txt'}
    Settings._settings_from_file = settings_file

    # mock settings_from_env method
    def settings_env(self):
        return {'require_confirmation': False}
    Settings._settings_from_env = settings_env

    # mock settings_from_args method

# Generated at 2022-06-12 10:10:14.284448
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.init().get('require_confirmation') == True

# Generated at 2022-06-12 10:10:19.960133
# Unit test for method init of class Settings
def test_Settings_init():
    import os

    settings.init()

    # test inheritance
    assert isinstance(settings, dict)

    # test attribute member
    assert settings.require_confirmation == True
    assert settings.history_limit == None

    # test value from settings.py
    # test value from env
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'False'
    env_value = os.environ['THEFUCK_REQUIRE_CONFIRMATION']
    settings.init()
    assert settings['require_confirmation'] == False
    os.environ.pop('THEFUCK_REQUIRE_CONFIRMATION')

    # test value from args
    arg_value = True
    settings.init(arg_value)
    assert settings['require_confirmation'] == arg_value

# Generated at 2022-06-12 10:10:28.155743
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception, log
    import mock
    import settings as s
    with mock.patch('sys.exc_info') as info:
        with mock.patch.object(s.Settings, '_init_settings_file'):
            with mock.patch.object(s.Settings, '_settings_from_file') as from_file:
                with mock.patch.object(s.Settings, '_settings_from_env') as from_env:
                    with mock.patch.object(s.Settings, '_settings_from_args') as from_args:
                        with mock.patch.object(s.Settings, '_setup_user_dir'):
                            settings.init()
                            assert from_file.called
                            assert from_env.called
                            assert from_args.called

# Generated at 2022-06-12 10:10:36.503572
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .test_utils import FakeHomeDir

    import sys
    import os

    with FakeHomeDir() as fake_home_dir:
        user_dir = Path(fake_home_dir.path).joinpath('.config', 'thefuck')
        original_user_dir = settings.user_dir
