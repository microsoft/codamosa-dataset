

# Generated at 2022-06-12 10:01:23.932795
# Unit test for method init of class Settings
def test_Settings_init():
    # Make sure that error while loading custom settings won't break things
    # (see #687)
    os.environ['THEFUCK_CUSTOM_SETTINGS'] = '/etc/nonexistent-file'
    os.environ['THEFUCK_NO_COLORS'] = 'True'
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'True'
    os.environ['THEFUCK_EXCLUDE_RULES'] = 'some-rule'
    os.environ['THEFUCK_RULES'] = 'another-rule'
    os.environ['THEFUCK_PRIORITY'] = 'some-rule=1:another-rule=2'
    os.environ['THEFUCK_DEBUG'] = 'True'

# Generated at 2022-06-12 10:01:35.882339
# Unit test for method init of class Settings
def test_Settings_init():
    import unittest
    import unittest.mock

    from . import logs

    class SettingsTestCase(unittest.TestCase):
        def setUp(self):
            self.settings = Settings(const.DEFAULT_SETTINGS)
            self.settings._get_user_dir_path = unittest.mock.Mock()
            self.settings.user_dir = unittest.mock.MagicMock()
            self.settings._setup_user_dir = unittest.mock.Mock()
            self.settings._init_settings_file = unittest.mock.Mock()
            self.settings._settings_from_file = unittest.mock.Mock()
            self.settings._settings_from_env = unittest.mock.Mock()
            self.settings._settings

# Generated at 2022-06-12 10:01:38.969465
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert isinstance(settings, dict)
    assert isinstance(settings, Settings)
    assert settings.user_dir == Path(settings._get_user_dir_path())
    assert settings['require_confirmation'] == True


# Generated at 2022-06-12 10:01:49.383757
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile

    args = lambda **kwargs: type('', (), kwargs)()
    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-12 10:01:53.608698
# Unit test for method init of class Settings
def test_Settings_init():
    """Check if Settings(dict).init() works"""
    env = {}
    args = ['thefuck', 'cd', '--yes', '--debug', '--repeat', '2']
    args = parse_args(args)
    settings.init(args)

    assert(settings['require_confirmation'] == False)
    assert(settings['debug'] == True)
    assert(settings['repeat'] == 2)

# Generated at 2022-06-12 10:02:03.719174
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    import os
    from six import StringIO
    from thefuck.logs import logs
    from thefuck.logs.logs import _logs_path

    args = type('', (), {})()
    args.yes = False
    args.repeat = False
    args.debug = False

    tmp_dir = tempfile.mkdtemp()
    user_dir = Path(tmp_dir, 'thefuck')
    rules_dir = user_dir.joinpath('rules')
    settings_file = user_dir.joinpath('settings.py')

    env = os.environ.copy()
    env['XDG_CONFIG_HOME'] = tmp_dir

    logs_file = StringIO()

    settings.init(args)

# Generated at 2022-06-12 10:02:08.460511
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir.expanduser().is_dir()
    assert settings.user_dir.joinpath('rules').is_dir()
    assert settings.user_dir.joinpath('settings.py').is_file()



# Generated at 2022-06-12 10:02:12.473816
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    args = []
    settings.init(args)
    assert settings.user_dir == settings._get_user_dir_path()
    assert settings.require_confirmation is True
    assert settings.no_colors is False
    assert settings.debug is False

# Generated at 2022-06-12 10:02:15.885832
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    args = type('', (object,), dict(yes=True, debug=True, repeat=2))()
    settings.init(args)

    assert not settings['require_confirmation']
    assert settings['debug']
    assert settings['repeat'] == 2

# Generated at 2022-06-12 10:02:18.324708
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings._get_user_dir_path() == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()

# Generated at 2022-06-12 10:02:42.402016
# Unit test for method init of class Settings
def test_Settings_init():
    args = type('TestArgs', (object,), {'yes': True, 'repeat': 3, 'debug': True})
    settings.init(args=args)
    assert not settings.require_confirmation
    assert settings.repeat == 3
    assert settings.debug
    assert settings.user_dir.name == '.thefuck'



# Generated at 2022-06-12 10:02:44.523159
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings.init()
    assert settings._settings_from_file()['require_confirmation']
    assert settings._settings_from_env()['require_confirmation']


# Generated at 2022-06-12 10:02:49.383376
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    args = mock.Mock()
    settings_dir = settings.user_dir.joinpath('settings.py')
    try:
        with mock.patch('thefuck.settings.Settings._settings_from_file',
                        side_effect=RuntimeError):
            settings.init()
    except RuntimeError:
        exception.assert_called_once_with(
            'Can\'t load settings from file', sys.exc_info())
    else:
        assert False

    try:
        with mock.patch('thefuck.settings.Settings._settings_from_env',
                        side_effect=RuntimeError):
            settings.init()
    except RuntimeError:
        exception.assert_called_with(
            'Can\'t load settings from env', sys.exc_info())
    else:
        assert False

   

# Generated at 2022-06-12 10:02:50.733384
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir.is_dir()

# Generated at 2022-06-12 10:02:52.980067
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.get('rules') == const.DEFAULT_RULES

# Generated at 2022-06-12 10:03:01.949353
# Unit test for method init of class Settings
def test_Settings_init():
    args = type('', (), {})()
    args.yes = True
    args.debug = False
    args.repeat = ''
    _settings = Settings(const.DEFAULT_SETTINGS)
    _settings.init(args)

    assert _settings["rules"] == const.DEFAULT_RULES
    assert _settings["require_confirmation"] is False
    assert _settings["debug"] is False
    assert _settings["repeat"] == ''
    assert _settings["wait_command"] == 0.8
    assert _settings["history_limit"] == None
    assert _settings["wait_slow_command"] == 3
    assert _settings["exclude_rules"] == []
    assert _settings["priority"] == {}
    assert _settings["no_colors"] is False

# Generated at 2022-06-12 10:03:10.100214
# Unit test for method init of class Settings
def test_Settings_init():
    '''Unit test for method init of class Settings'''
    import tempfile
    import shutil
    import os
    import sys
    from subprocess import call
    #from thefuck import const, Settings
    import thefuck as tf
    #from thefuck.logs import debug

    thefuck_home_test_dir = tempfile.mkdtemp(prefix='thefuck_test')
    #debug('thefuck_home_test_dir: ' + thefuck_home_test_dir)

    # Create a fake settings.py
    user_dir_path = os.path.join(thefuck_home_test_dir, 'user_settings')
    os.mkdir(user_dir_path)
    settings_file_path = os.path.join(user_dir_path, 'settings.py')

# Generated at 2022-06-12 10:03:15.343086
# Unit test for method init of class Settings
def test_Settings_init():
    import six

    def _check(config_file, env, args, expected):
        test_settings = Settings()
        if config_file:
            test_settings.user_dir = six.moves.UserDirs().home
            with open(os.path.join(test_settings.user_dir, 'settings.py'), 'w') as f:
                f.write('\n'.join(config_file) + '\n')
        for k, v in env.items():
            os.environ[k] = v

        class Args(object):
            pass
        args = Args()
        for k, v in args.items():
            setattr(args, k, v)

        test_settings.init(args)
        assert test_settings == expected

    # skip Windows root-cause: https://github.com/

# Generated at 2022-06-12 10:03:19.032880
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.user_dir.joinpath('rules').is_dir()

# Unit tests for method _get_user_dir_path of class Settings

# Generated at 2022-06-12 10:03:28.247087
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch
    from tempfile import NamedTemporaryFile

    with patch('thefuck.settings.os.environ.get') as environ_get:
        environ_get.return_value = None
        with patch('thefuck.settings.load_source') as load_source:
            load_source.return_value = ''
            with NamedTemporaryFile('r+') as settings_file:
                settings_file.write(const.SETTINGS_HEADER)
                for setting in const.DEFAULT_SETTINGS.items():
                    settings_file.write(u'# {} = {}\n'.format(*setting))
                settings_file.seek(0)
                with patch('thefuck.settings.Path.expanduser') as expanduser:
                    expanduser.return_value = settings_file.name
                    settings.init

# Generated at 2022-06-12 10:04:16.987088
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings == const.DEFAULT_SETTINGS
    assert settings.user_dir == \
        settings._get_user_dir_path()

    settings.update(exclude_rules=['.*'])
    settings.init()
    assert settings['exclude_rules'] == ['.*']

    settings.init(argparse.Namespace(yes=True))
    assert settings['require_confirmation'] is False
    settings.init(argparse.Namespace(debug=True))
    assert settings['debug'] is True
    settings.init(argparse.Namespace(repeat=2))
    assert settings['repeat'] == 2

# Generated at 2022-06-12 10:04:23.683847
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    user_dir = const.DEFAULT_SETTINGS['user_dir']
    settings.init()
    assert settings.user_dir == user_dir
    from .logs import exception
    try:
        settings.init('args')
    except Exception:
        exception("Can't init settings from args", sys.exc_info())
    try:
        settings['rules'] = settings._rules_from_env('DEFAULT_RULES')
    except Exception:
        exception("Can't load rules from env", sys.exc_info())
    try:
        settings['priority'] = dict(settings._priority_from_env('DEFAULT_RULES'))
    except Exception:
        exception("Can't get priority pairs from env", sys.exc_info())

# Generated at 2022-06-12 10:04:32.954782
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)

    class Args:
        def __init__(self, repeat=None, debug=None, yes=False):
            self.repeat = repeat
            self.debug = debug
            self.yes = yes

    confirm_default = const.DEFAULT_SETTINGS['require_confirmation']
    repeat_default = const.DEFAULT_SETTINGS['repeat']
    debug_default = const.DEFAULT_SETTINGS['debug']

    # When all args are None
    args = Args()
    settings.init(args)
    assert settings['require_confirmation'] == confirm_default
    assert settings['repeat'] == repeat_default
    assert settings['debug'] == debug_default

    # When args are given + true

# Generated at 2022-06-12 10:04:39.794396
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import capture_logs

    settings.init()
    # Assert settings['rules'] == const.DEFAULT_RULES
    assert settings.rules == const.DEFAULT_RULES
    settings.init({'yes': True})
    assert settings.require_confirmation is False

    with capture_logs() as logs:
        settings.init({'debug': True})
        assert settings.debug
        assert u'Debug mode: on' in logs.logs[0]


# Generated at 2022-06-12 10:04:46.083905
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings({})
    settings['user_dir'] = 'user_dir'
    settings['log_file'] = 'log_file'
    settings.init()
    assert settings.get('user_dir') == 'user_dir'
    assert settings.get('log_file') == 'log_file'
    assert settings.get('slow_commands') == ['(?i)^((git|hg|bzr) diff|svn st)$']
    assert settings.get('confirm_exit') == True


# Generated at 2022-06-12 10:04:50.641329
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    # Test for when the user_dir doesn't exist (creating it)
    # The `settings.py` file should be created with the default settings.
    settings.init()
    user_dir_path = settings._get_user_dir_path()
    assert user_dir_path.is_dir()
    settings_path = user_dir_path.joinpath('settings.py')
    assert settings_path.is_file()
    with settings_path.open() as settings_file:
        assert settings_file.read() == const.SETTINGS_HEADER

    # Test for when the `settings.py` file contains some more settings.

# Generated at 2022-06-12 10:04:59.815621
# Unit test for method init of class Settings
def test_Settings_init():
    """Settings.init(args=None)

    - sets user_dir to new `XDG_CONFIG_HOME/thefuck` by default
    - updates settings by file
    - updates settings by env
    - updates settings by args
    """
    import pytest
    from mock import patch
    from itertools import chain

    args = type('', (object,), {'yes': None, 'debug': None, 'repeat': None})


# Generated at 2022-06-12 10:05:07.644747
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    from .system import Path
    from .settings import settings
    os.environ['THEFUCK_SUDO_COMMAND'] = 'pkexec'
    os.environ['THEFUCK_RULES'] = 'default_rules:sudo'
    os.environ['THEFUCK_PRIORITY'] = 'default_rules=10:sudo=0'
    os.environ['THEFUCK_WAIT_COMMAND'] = '1'
    os.environ['THEFUCK_WAIT_SLOW_COMMAND'] = '2'
    os.environ['THEFUCK_HISTORY_LIMIT'] = '3'
    os.environ['THEFUCK_NO_COLORS'] = 'True'

# Generated at 2022-06-12 10:05:17.949890
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    import mock
    import pytest

    with mock.patch("thefuck.settings._settings_from_file", return_value={}), \
            mock.patch("thefuck.settings._settings_from_env", return_value={}), \
            mock.patch("thefuck.settings._settings_from_args", return_value={}), \
            mock.patch("thefuck.settings.warn") as mock_warn, \
            mock.patch("thefuck.settings.load_source",
                       return_value=mock.Mock(**{"get_setting.return_value": "setting"})), \
            mock.patch("thefuck.settings.Path") as mock_path, \
            mock.patch("thefuck.settings.os.environ.get", return_value="~/.config"):
        settings

# Generated at 2022-06-12 10:05:19.993838
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings == Settings(const.DEFAULT_SETTINGS)

# Generated at 2022-06-12 10:06:59.279597
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    from copy import copy
    from .logs import exception

    settings.clear()
    assert len(settings) == 0

    def _get_user_dir_path(self):
        return 'path/to/user/dir'

    tmp_init = Settings.init
    tmp_get_user_dir_path = Settings._get_user_dir_path

    Settings._get_user_dir_path = _get_user_dir_path
    result = {}

    def _settings_from_file():
        return {
            'key1': 'value1',
            'key2': 'value2'
        }

    def _settings_from_env():
        return {
            'key3': 'value3',
            'key4': 'value4'
        }


# Generated at 2022-06-12 10:07:05.174238
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

    assert settings.user_dir != ''
    assert settings.user_dir.is_dir()

    settings_file = settings.user_dir.joinpath('settings.py')
    assert settings_file.is_file()

    settings_contents = settings_file.read_text()
    assert settings_contents.startswith(const.SETTINGS_HEADER)

    for setting in const.DEFAULT_SETTINGS.items():
        assert '# {} = {}'.format(*setting) in settings_contents


# Generated at 2022-06-12 10:07:08.923450
# Unit test for method init of class Settings
def test_Settings_init():
    """Test init method of class Settings."""
    class Args(object):
        pass

    args = Args()
    args.yes = True
    args.debug = True
    args.repeat = 3
    settings_test = Settings(const.DEFAULT_SETTINGS)
    settings_test.init(args)
    assert settings_test.require_confirmation == False
    assert settings_test.debug == True
    assert settings_test.repeat == 3
    settings_test.init()
    assert settings_test.require_confirmation == True
    assert settings_test.debug == True
    assert settings_test.repeat == 3

# Generated at 2022-06-12 10:07:16.535920
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import test_exception
    os.environ['TF_WAIT_COMMAND'] = '2'
    os.environ['TF_PRIORITY'] = u'fuck=100:ls=50:ps=100:rm=0'
    os.environ['TF_SLOW_COMMANDS'] = 'git:vagrant'
    os.environ['TF_RULES'] = 'confused:ls:DEFAULT_RULES:fuck:ps:rm'
    os.environ['TF_EXCLUDE_RULES'] = 'fuck:ls:ps:rm'
    os.environ['TF_EXCLUDED_SEARCH_PATH_PREFIXES'] = '/usr/bin'
    os.environ['TF_HISTORY_LIMIT'] = '50'

# Generated at 2022-06-12 10:07:23.520454
# Unit test for method init of class Settings
def test_Settings_init():
    class FakeArgs(object):
        yes = False
        debug = False
        repeat = False

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init(args=FakeArgs())

    assert settings.get('require_confirmation') == const.DEFAULT_SETTINGS.get('require_confirmation')
    assert settings.get('debug') == const.DEFAULT_SETTINGS.get('debug')
    assert settings.get('repeat') == const.DEFAULT_SETTINGS.get('repeat')

    class FakeArgs(object):
        yes = True
        debug = True
        repeat = True

    settings.init(args=FakeArgs())

    assert settings.get('require_confirmation') == False
    assert settings.get('debug') == True
    assert settings.get('repeat') == True

# Generated at 2022-06-12 10:07:29.657798
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()

    for value in ('require_confirmation', 'repeat', 'no_colors', 'wait_command',
                  'wait_slow_command', 'history_limit', 'priority', 'rules',
                  'exclude_rules', 'env', 'exclude_search_path_prefixes',
                  'slow_commands', 'no_colors', 'debug', 'alter_history',
                  'instant_mode', 'num_close_matches'):
        assert value in settings

    assert settings.user_dir.joinpath('settings.py').isfile()



# Generated at 2022-06-12 10:07:36.475835
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    temp = tempfile.mkdtemp()
    user_dir = Path(temp, 'thefuck').expanduser()
    file_path = user_dir.joinpath('settings.py')
    user_dir.mkdir(parents=True)
    with file_path.open(mode='w') as f:
        f.write(const.SETTINGS_HEADER)
        for setting in const.DEFAULT_SETTINGS.items():
            f.write(u'# {} = {}\n'.format(*setting))
    st = Settings(const.DEFAULT_SETTINGS)
    st._setup_user_dir()
    st.init()
    assert st.require_confirmation == True
    assert st.wait_command == 3
    assert st.rules == const.DEFAULT_RULES

# Generated at 2022-06-12 10:07:41.813621
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import _exception
    import sys

    class Args(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    def test_Settings_init_raise_exception():
        settings._init_settings_file = lambda: settings.user_dir.joinpath('settings.py').remove()
        settings.init()
        assert settings.get('require_confirmation')
        sys.excepthook = _exception

    def test_Settings_init_no_default_rules():
        settings._settings_from_file = lambda: {'rules': []}
        settings.init()
        assert settings.get('rules') == const.DEFAULT_RULES

    def test_Settings_init_settings_from_file():
        settings._settings_from_

# Generated at 2022-06-12 10:07:50.139252
# Unit test for method init of class Settings
def test_Settings_init():
    from textwrap import dedent

    mock_args = {
        'yes': True,
        'debug': True,
        'repeat': 2
    }
    test_file = dedent("""
    rules = ['test', 'rule']
    require_confirmation = True
    no_colors = False
    history_limit = None
    alter_history = True
    repeat = 3
    wait_command = 3
    wait_slow_command = 10
    instant_mode = True
    slow_commands = ['.*']
    exclude_rules = ['exclude', 'rule']
    debug = True
    num_close_matches = 3
    priority = { 'mv': 1, 'ln': 2 }
    excluded_search_path_prefixes = ['exclude', 'path']
    """)


# Generated at 2022-06-12 10:07:51.218519
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.rules == const.DEFAULT_RULES