

# Generated at 2022-06-12 10:01:39.318592
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    from tests.utils import restore_settings
    from tempfile import mkdtemp
    from thefuck.settings import Settings
    from thefuck.utils import get_all_executables
    from thefuck.utils import get_all_rules
    from thefuck.utils import get_all_scripts

    with restore_settings(settings):
        settings.init()
        assert settings.user_dir == settings._get_user_dir_path()
        assert os.path.isfile(os.path.join(settings.user_dir, 'settings.py'))
        assert settings.require_confirmation == True
        assert settings.history_limit == None
        assert settings.wait_command == 1
        assert settings.rules['python'] == get_all_rules()
        assert settings.exclude_rules == []
        assert settings.no_

# Generated at 2022-06-12 10:01:48.379202
# Unit test for method init of class Settings
def test_Settings_init():
    def mock_update(dct):
        settings.update(dct)

    def mock__settings_from_file():
        return {'rules': ['test']}

    def mock__settings_from_env():
        return {'rules': ['test']}

    def mock__settings_from_args():
        return {'rules': ['test']}

    settings.init = Settings.init
    settings.update = mock_update
    settings.update = mock__settings_from_file
    settings.update = mock__settings_from_env
    settings.update = mock__settings_from_args
    settings.init()
    assert settings.get('rules') == ['test']

test_Settings_init()

# Generated at 2022-06-12 10:01:55.793797
# Unit test for method init of class Settings
def test_Settings_init():
    import sys
    class Args(object):
        """Simple stub for argparse.Namespace"""
        def __init__(self, yes=False, debug=False, repeat=0):
            self.yes = yes
            self.debug = debug
            self.repeat = repeat

    def get_settings():
        settings = Settings(const.DEFAULT_SETTINGS)
        settings.init(Args())
        return settings

    def get_settings_with_args(yes=False, debug=False, repeat=0):
        settings = Settings(const.DEFAULT_SETTINGS)
        settings.init(Args(yes, debug, repeat))
        return settings

    # Test: settings from file - settings.py
    settings.init()
    assert settings.require_confirmation is True
    settings.init()
    assert settings.require_confirmation

# Generated at 2022-06-12 10:02:05.469598
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

    assert(settings.get('require_confirmation') == True)
    assert(settings.get('history_limit') == 5)
    assert(settings.get('repeat') == 0)
    assert(settings.get('wait_slow_command') == 15)
    assert(settings.get('require_confirmation') == True)
    assert(settings.get('rules') == const.DEFAULT_RULES)
    assert(settings.get('slow_commands') == [])
    assert(settings.get('exclude_rules') == [])
    assert(settings.get('excluded_search_path_prefixes') == ['/dev', '/proc', '='])
    assert(settings.get('history_file') == '~/.local/share/history')
    assert(settings.get('priority') == {})


# Generated at 2022-06-12 10:02:15.294987
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import Log
    from .utils import memoize
    from os import environ
    from os.path import expanduser
    from six import StringIO
    from thefuck import const

    def set_xdg_config_home(path):
        environ['XDG_CONFIG_HOME'] = path

    def set_user_dir_file(setting, val):
        user_dir_file = Path(expanduser('~/.thefuck/settings.py')).open(mode='w')
        user_dir_file.write(const.SETTINGS_HEADER)
        user_dir_file.write('{} = {}\n'.format(setting, val))
        user_dir_file.flush()
        return user_dir_file


# Generated at 2022-06-12 10:02:22.642759
# Unit test for method init of class Settings
def test_Settings_init():
    """Unit test for method init of class Settings"""
    import mock

    class Args:
        yes = False
        debug = False
        repeat = None

    settings.init()
    assert settings.require_confirmation == True
    assert settings.debug == False
    assert settings.repeat == 1

    args = Args()
    settings.init(args)
    assert settings.require_confirmation == True
    assert settings.debug == False
    assert settings.repeat == 1

    args = Args()
    args.yes = True
    settings.init(args)
    assert settings.require_confirmation == False
    assert settings.debug == False
    assert settings.repeat == 1

    args = Args()
    args.debug = True
    settings.init(args)
    assert settings.require_confirmation == True
    assert settings.debug

# Generated at 2022-06-12 10:02:27.448569
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()

    os.environ['TF_DEBUG'] = 'True'
    os.environ['TF_REQUIRE_CONFIRMATION'] = 'False'
    settings.init()
    assert settings.debug
    assert not settings.require_confirmation



# Generated at 2022-06-12 10:02:30.493311
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings['require_confirmation']
    settings.init(args)

    assert settings['require_confirmation'] == False
    assert settings['debug'] == True
    assert settings['repeat'] == 1

# Generated at 2022-06-12 10:02:39.509460
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    settings.init()
    settings_file = settings.user_dir.joinpath('settings.py')
    assert settings_file.open().read() == const.SETTINGS_HEADER + '''# rules = ['echo', 'ls', 'rm']
# exclude_rules = []
# priority = {}
# wait_command = 3
# wait_slow_command = 15
# history_limit = None
# no_colors = False
# require_confirmation = True
# debug = False
# alter_history = True
# repeat = True
# instant_mode = False
# num_close_matches = 0
# slow_commands = ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
# excluded_search_path_prefixes = ['.']
'''

# Generated at 2022-06-12 10:02:46.400866
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import MagicMock
    from types import ModuleType

    def reset():
        settings.clear()
        settings.update(const.DEFAULT_SETTINGS)

    settings.init()
    assert settings.get('require_confirmation') is True
    assert settings.get('history_limit') == 0
    assert settings.get('no_colors') is False

    user_dir = settings.user_dir
    settings.user_dir = MagicMock()
    settings.user_dir.joinpath.return_value.expanduser.return_value = user_dir
    settings.user_dir.joinpath.return_value.open.return_value = MagicMock()
    settings.user_dir.joinpath.return_value.is_file.return_value = True
    settings._init_settings_file()
    assert settings

# Generated at 2022-06-12 10:03:26.926687
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings._get_user_dir_path() == Path('~', '.config', 'thefuck').expanduser()
    assert settings.user_dir == Path('~', '.config', 'thefuck').expanduser()

# Generated at 2022-06-12 10:03:35.032351
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import log_to_stderr

    # Test init without arguments
    settings.update(DEFAULT_SETTINGS)
    settings.init()
    assert settings.get('require_confirmation')

    # Test when require_confirmation is set to False
    settings.update(DEFAULT_SETTINGS)
    settings.init(args=argparse.Namespace(yes=True))
    assert not settings.get('require_confirmation')

    # Test when debug is set to True
    settings.update(DEFAULT_SETTINGS)
    settings.init(args=argparse.Namespace(debug=True))
    assert settings.get('debug')

    # Test when repeat is set to 5
    settings.update(DEFAULT_SETTINGS)
    settings.init(args=argparse.Namespace(repeat=5))

# Generated at 2022-06-12 10:03:41.062547
# Unit test for method init of class Settings
def test_Settings_init():
    from unittest.mock import patch, MagicMock
    settings = Settings(const.DEFAULT_SETTINGS)
    settings._get_user_dir_path = MagicMock(return_value='')
    settings._setup_user_dir = MagicMock()
    settings._init_settings_file = MagicMock()

    with patch.dict('os.environ', {'THEFUCK_WAIT_COMMAND': '2'}):
        settings.init()

    settings._setup_user_dir.assert_called_once_with()
    settings._init_settings_file.assert_called_once_with()

    assert settings['wait_command'] == 2



# Generated at 2022-06-12 10:03:50.429843
# Unit test for method init of class Settings
def test_Settings_init():
    """Settings.init() should init settings with values
    from file, env and args."""
    # pylint: disable=protected-access
    assert settings.init() is None
    # it should call _setup_user_dir for init user_dir
    assert settings._setup_user_dir.called
    # it should call _init_settings_file for creating file
    assert settings._init_settings_file.called
    # it should call _settings_from_file for setting
    # from file
    assert settings._settings_from_file.called
    # it should call _settings_from_env for setting
    # from env
    assert settings._settings_from_env.called
    # it should call _settings_from_args for setting
    # from args
    assert settings._settings_from_args.called


# Generated at 2022-06-12 10:03:54.343875
# Unit test for method init of class Settings
def test_Settings_init():
    # arrange
    import tempfile
    temp_dir = tempfile.mkdtemp()
    temp_settings_file = temp_dir + '/settings.py'
    temp_settings_file_content = u'\n'.join(
        [const.SETTINGS_HEADER,
        u'alter_history = True',
        u'no_colors = False',
        u'priority = fuck:1000:git:500'])
    with open(temp_settings_file, mode='w') as f:
        f.write(temp_settings_file_content)

    import os
    os.environ['THEFUCK_ALTER_HISTORY'] = 'False'
    os.environ['THEFUCK_NO_COLORS'] = 'True'

# Generated at 2022-06-12 10:03:57.215984
# Unit test for method init of class Settings
def test_Settings_init():
    """In settings should be updated settings from file, env and args
    """
    import argparse
    arg = argparse.Namespace()
    arg.yes = True
    settings.init(arg)
    assert settings['require_confirmation'] == False

# Generated at 2022-06-12 10:03:59.370276
# Unit test for method init of class Settings
def test_Settings_init():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    assert isinstance(test_settings, dict)
    test_settings.init()

# Generated at 2022-06-12 10:04:08.086601
# Unit test for method init of class Settings
def test_Settings_init():
    #  Check default settings
    default_settings = {'require_confirmation': True,
                        'rules': [],
                        'exclude_rules': [],
                        'priority': {},
                        'wait_command': 1,
                        'history_limit': None,
                        'slow_commands': [],
                        'wait_slow_command': 15,
                        'no_colors': False,
                        'debug': False,
                        'alter_history': True,
                        'excluded_search_path_prefixes': [],
                        'num_close_matches': 3,
                        'instant_mode': False,
                        'repeat': None}
    s = Settings()
    assert (s == default_settings)

    #  Check settings from file

# Generated at 2022-06-12 10:04:11.249151
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings['priority'] == const.DEFAULT_PRIORITY
    assert settings['history_limit'] == 0

# Generated at 2022-06-12 10:04:20.100103
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)

    class Args(object):
        yes = True
        debug = False
        repeat = 'repeat'
        wait_slow_command = 1
        wait_command = 2
        history_limit = 3
        require_confirmation = False
        slow_commands = 'command1:command2'
        exclude_rules = 'rule1:rule2'
        rules = 'rule3:rule4'

    args = Args()

    settings.init(args)
    assert settings['rules'] == 'rule3:rule4'
    assert settings['exclude_rules'] == 'rule1:rule2'
    assert settings['priority'] == {}
    assert settings['wait_command'] == 2
    assert settings['wait_slow_command'] == 1

# Generated at 2022-06-12 10:05:33.545540
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()



# Generated at 2022-06-12 10:05:42.575094
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile

    settings = Settings(const.DEFAULT_SETTINGS)

    with tempfile.TemporaryDirectory() as tmpdir:
        settings.user_dir = Path(tmpdir)
        settings.init()

        assert settings.user_dir.joinpath('settings.py').is_file()
        assert settings.rules == const.DEFAULT_RULES

    settings = Settings(const.DEFAULT_SETTINGS)

    with tempfile.TemporaryDirectory() as tmpdir:
        user_dir = Path(tmpdir)
        settings.user_dir = user_dir
        with open(user_dir.joinpath('settings.py'), 'w') as f:
            f.write('rules = ["cd_parent"]')
        settings.init()

        assert settings.rules == ["cd_parent"]


# Generated at 2022-06-12 10:05:45.075031
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings['wait_command'] == 1
    assert settings['rules'] == const.DEFAULT_RULES
    assert not settings.get('no_colors')
    assert not settings.get('require_confirmation')
    assert not settings.get('repeat')



# Generated at 2022-06-12 10:05:51.422247
# Unit test for method init of class Settings
def test_Settings_init():
    import sys
    import tempfile

    old_environ = dict(os.environ)
    old_argv = sys.argv
    old_path = sys.path
    old_user_dir = settings.user_dir


# Generated at 2022-06-12 10:05:59.791043
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.require_confirmation == False
    assert settings.wait_command == 1
    assert settings.history_limit == 100
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['(?i)vagrant']
    assert settings.alter_history == True
    assert settings.priority == {}
    assert settings.rules == ['git_rebase', 'git_amend']
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.env == {}
    assert settings.command_not_found == 'zsh: command not found: {command}'
    assert settings.no_colors == False
    assert settings.instant_mode == False
    assert settings.num_close_matches == 3

# Generated at 2022-06-12 10:06:04.011119
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import _exception as exception
    from .tests.utils import wrap_stderr

    def _exception(text):
        exception(text, sys.exc_info())

    settings = Settings(const.DEFAULT_SETTINGS)
    # `_get_user_dir_path` is tested in test_settings.py
    settings._get_user_dir_path = lambda: Path('~', '.thefuck').expanduser()

    # Test init when file `settings.py` doesn't exist
    settings._init_settings_file = lambda: None
    settings.user_dir = None
    with wrap_stderr() as stderr:
        settings.init()
    assert u'Can\'t load settings from file' in stderr.getvalue()

# Generated at 2022-06-12 10:06:06.063786
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.user_dir == settings._get_user_dir_path()
    assert settings.instant_mode == True
    assert settings.alter_history == False

# Generated at 2022-06-12 10:06:09.249542
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    settings.init({'yes': True, 'repeat': 10, 'debug': True})
    assert(settings['rules'] == const.DEFAULT_RULES and \
           settings['require_confirmation'] == False and \
           settings['repeat'] == 10 and \
           settings['debug'] == True)

# Generated at 2022-06-12 10:06:18.850182
# Unit test for method init of class Settings
def test_Settings_init():
    class Args(object):
        def __init__(self, repeat=False, yes=False, debug=False):
            self.repeat = repeat
            self.yes = yes
            self.debug = debug

    args = Args()
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init(args)
    assert settings['require_confirmation'] == False
    assert settings['repeat'] == 0

    args = Args(repeat=1)
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init(args)
    assert settings['repeat'] == 1

    args = Args(yes=True)
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init(args)
    assert settings['require_confirmation'] == True


# Generated at 2022-06-12 10:06:27.304965
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings['require_confirmation'] == True
    assert settings['slow_commands'] == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings['rules'] == ['python_command', 'git_push', 'sudo']
    assert settings['priority'] == {'python_command': 100, 'git_push': 90, 'sudo': 200}
    assert settings['exclude_rules'] == []
    assert settings['excluded_search_path_prefixes'] == []
    assert settings['history_limit'] == None
    assert settings['wait_command'] == 1
    assert settings['wait_slow_command'] == 15
    assert settings['alter_history'] == True
    assert settings['no_colors'] == False
    assert settings['debug'] == False
    assert settings

# Generated at 2022-06-12 10:09:52.008080
# Unit test for method init of class Settings
def test_Settings_init():
    # Create user dir with not existing settings file
    user_dir = Path(os.curdir).joinpath('user-dir')
    user_dir.mkdir(exist_ok=True)

    # Put env vars
    os.environ['THEFUCK_WAIT_COMMAND'] = '1'
    os.environ['THEFUCK_RULES'] = 'DEFAULT_RULES'
    os.environ['THEFUCK_EXCLUDE_RULES'] = ':'.join(['slow', 'sudoers'])
    os.environ['THEFUCK_PRIORITY'] = 'python=10'
    os.environ['THEFUCK_WAIT_SLOW_COMMAND'] = '0'

# Generated at 2022-06-12 10:10:01.264006
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert isinstance(settings.user_dir, Path) # Settings creates new user dir, if it doesn't exist
    assert settings.user_dir == Path.home().joinpath(".config/thefuck")
    assert settings.rules == ['bash', 'man', 'brew', 'pip', 'pep8', 'git', 'apt-get', 'vagrant', 'docker']
    assert settings.require_confirmation == True
    assert settings.history_limit == None
    assert settings.exclude_rules == []
    assert settings.wait_command == 1
    assert settings.no_colors == False
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']

# Generated at 2022-06-12 10:10:03.921202
# Unit test for method init of class Settings
def test_Settings_init():
    test_settings = Settings()
    test_settings.init()
    assert test_settings.get('sudo_command') == 'sudo'
    assert test_settings.get('repeat') == False
    assert len(test_settings.get('exclude_rules')) == 0
    assert test_settings.get('require_confirmation') == False

# Generated at 2022-06-12 10:10:11.027526
# Unit test for method init of class Settings
def test_Settings_init():
    """
    test for settings.init
    """

    settings_ = Settings(
        {'nt': '1', 'require_confirmation': '2', 'priority': '3',
         'alias': '4', 'wait_command': '5', 'env': '6',
         'history_limit': '7', 'no_colors': '8',
         'wait_slow_command': '9', 'exclude_rules': '10',
         'rules_dir': '11', 'slow_commands': '12', 'debug': '13',
         'exclude_commands': '14', 'extras': '15', 'alter_history': '16',
         'num_close_matches': '17'})

    settings_.init()

    assert settings_.get("nt") == '1'

# Generated at 2022-06-12 10:10:12.187698
# Unit test for method init of class Settings
def test_Settings_init():
    s = Settings()
    s.init()
    assert s.user_dir.exists()
    assert s.verbose is False

# Generated at 2022-06-12 10:10:18.692905
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import Log
    from .system import Path
    from . import const

    class SettingsMock(Settings):
        def __init__(self):
            super(SettingsMock, self).__init__()
            self._user_dir = Path('~')
            self.settings.py = 'test'
            self._settings_from_file = lambda: {'test_key': 'test_val'}
            self._settings_from_env = lambda: {'test_key_env': 'test_val_env'}
            self._settings_from_args = lambda x: {'test_key_args': 'test_val_args'}
            self.log = Log()

    settings = SettingsMock()
    settings.init()
    assert settings['test_key'] == 'test_val'

# Generated at 2022-06-12 10:10:23.509099
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME',
                                                    '~/.config'),
                                     'thefuck').expanduser()
    assert os.path.exists(settings.user_dir.joinpath('settings.py'))
    assert os.path.exists(settings.user_dir.joinpath('rules'))
    assert settings['python3'] == settings.python3

# Generated at 2022-06-12 10:10:25.095398
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.user_dir.is_dir()
    assert settings.rules
    assert settings.alter_history


# Generated at 2022-06-12 10:10:26.653770
# Unit test for method init of class Settings
def test_Settings_init():
    settings.update(const.DEFAULT_SETTINGS)
    settings.init()

# Generated at 2022-06-12 10:10:35.483377
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    import shutil
    import os

    tmp_dir = tempfile.mkdtemp()
    user_dir = os.path.join(tmp_dir, '.thefuck')
    os.mkdir(user_dir)
    settings_path = os.path.join(user_dir, 'settings.py')
    with open(settings_path, 'w') as settings_file:
        settings_file.write("rules = ['foo', 'bar']")

    settings.init()
    assert settings.user_dir == Path(user_dir)
    assert settings.rules == ['foo', 'bar']
    assert settings.require_confirmation is True
    assert settings.wait_command == 1
    assert settings.slow_commands == set()
    assert settings.exclude_rules == []
    assert settings.excluded_search