

# Generated at 2022-06-26 04:30:08.052940
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

# Generated at 2022-06-26 04:30:12.594105
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0._init_settings_file()
    assert settings_0._settings_from_env() == {}
    assert settings_0._settings_from_args(args=None) == {}



# Generated at 2022-06-26 04:30:21.685294
# Unit test for method init of class Settings
def test_Settings_init():
    import unittest

    class TestSettings(unittest.TestCase):
        def test_init(self):
            settings_1 = Settings(const.DEFAULT_SETTINGS)
            settings_1.init()
            self.assertEqual(settings_1['py3_path'], '/usr/bin/python3')
            self.assertEqual(settings_1['DEBUG'], False)

    unittest.main()



# Generated at 2022-06-26 04:30:23.430621
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    # Call method init of settings_0
    settings_0.init()


# Generated at 2022-06-26 04:30:36.369795
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1.init()

    if not settings_1.user_dir == Path('~/.config/thefuck').expanduser():
        print ("Error: Settings.user_dir is not correct")
        return


# Generated at 2022-06-26 04:30:38.353431
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()


# Generated at 2022-06-26 04:30:41.618010
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert isinstance(settings_0.user_dir,Path)
    settings_0.init("args")

# Generated at 2022-06-26 04:30:50.343527
# Unit test for method init of class Settings
def test_Settings_init():

    settings_1 = Settings()
    assert settings_1

    settings_2 = Settings()
    assert settings_2

    settings_2.init()
    print (settings_2)
    print (settings_2['require_confirmation'])
    assert settings_2['require_confirmation'] == True


if __name__ == '__main__':
    test_case_0()
    test_Settings_init()

# Generated at 2022-06-26 04:30:52.730929
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    assert settings_0.init() is True


# Generated at 2022-06-26 04:30:53.869631
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1.init()


# Generated at 2022-06-26 04:31:45.690720
# Unit test for method init of class Settings
def test_Settings_init():
    # Initialize Settings object
    settings_1 = Settings()
    assert settings_1 is not None
    # Check if Settings variable is a dict
    assert isinstance(settings_1, dict)

# Generated at 2022-06-26 04:31:49.373017
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()

    settings_1 = Settings()
    settings_1.init()
    assert settings.update(settings_0) == settings.update(settings_1)



# Generated at 2022-06-26 04:32:00.078416
# Unit test for method init of class Settings
def test_Settings_init():

    from .logs import exception
    from .history import History

    settings_0 = Settings(const.DEFAULT_SETTINGS)
    args_1 = None
    try:
        settings_0.init(args=args_1)
    except:
        exception("Cannot initialize settings file", sys.exc_info())
    # if `settings` file is not present raise TypeError
    # this error is usually, due to missing user config file
    # test whether method init works in absence of settings.py
    try:
        settings_0.init(args=args_1)
    except TypeError:
        print ('TypeError exception raised')
    else:
        print ('TypeError not raised')

    # test whether method init works in presence of settings.py

# Generated at 2022-06-26 04:32:01.200409
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()

# Generated at 2022-06-26 04:32:07.074296
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0._setup_user_dir()
    settings_0._init_settings_file()
    settings_0['user_dir'] = Path('~/.config/thefuck/')
    settings_0['user_dir'].expanduser() == Path('~/.config/thefuck/')
    settings_0.update(settings_0._settings_from_file())
    settings_0.update(settings_0._settings_from_env())
    settings_0.update(settings_0._settings_from_args(args=None))
    settings_0.__class__.__name__ == 'Settings'
    settings_0.update({})
    settings_0.__getattr__('get')
    settings_0.__setattr__('key', 'value')
    settings_0._settings_

# Generated at 2022-06-26 04:32:17.518378
# Unit test for method init of class Settings
def test_Settings_init():
    tmp = object()
    pos = object()
    path = object()
    f = object()
    val = object()
    args = object()
    def test_case_1():
        settings_1 = Settings({})
        settings_1.user_dir = path
        def test_case_1_1():
            settings_1.user_dir.joinpath = lambda *args: tmp
            settings_1._get_user_dir_path = lambda : pos
            settings_1._settings_from_file = lambda : val
            settings_1._settings_from_env = lambda : val
            settings_1._settings_from_args = lambda : val
            def test_case_1_1_1():
                tmp.is_file = lambda : False
                def test_case_1_1_1_1():
                    tmp.open

# Generated at 2022-06-26 04:32:30.076290
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()

    assert settings_0["require_confirmation"] == True
    assert settings_0["history_limit"] == None
    assert settings_0["wait_command"] == 3
    assert settings_0["rules"] == ["sudo !!", "fc -s {}"]
    assert settings_0["sudo_command"] == "sudo"
    assert settings_0["alter_history"] == False
    assert settings_0["exclude_rules"] == ["git push"]
    assert settings_0["priority"] == None
    assert settings_0["wait_slow_command"] == 15
    assert settings_0["slow_commands"] == ["lein", "react-native", "gradle", "./gradlew"]
    assert settings_0["no_colors"] == False
    assert settings_0["debug"] == False
    assert settings_

# Generated at 2022-06-26 04:32:39.550516
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1.init()

    if settings_1['rules'] != const.DEFAULT_RULES:
        raise AssertionError("settings_1['rules'] != const.DEFAULT_RULES")
    if settings_1['require_confirmation'] != True:
        raise AssertionError("settings_1['require_confirmation'] != True")
    if settings_1['priority'] != {}:
        raise AssertionError("settings_1['priority'] != {}")
    if settings_1['no_colors'] != False:
        raise AssertionError("settings_1['no_colors'] != False")
    if settings_1['wait_command'] != 0.5:
        raise AssertionError("settings_1['wait_command'] != 0.5")

# Generated at 2022-06-26 04:32:42.020662
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.get('rules') == "DEFAULT_RULES"
    assert settings.get('verbose') == False

# Generated at 2022-06-26 04:32:52.209921
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    try:
        settings_0._setup_user_dir()
    except Exception:
        assert False
    else:
        assert True
    try:
        settings_0._init_settings_file()
    except Exception:
        assert False
    else:
        assert True
    try:
        settings_0._settings_from_file()
    except Exception:
        assert False
    else:
        assert True
    try:
        settings_0._settings_from_env()
    except Exception:
        assert False
    else:
        assert True
    try:
        settings_0._settings_from_args(['true'])
    except Exception:
        assert False
    else:
        assert True

# Generated at 2022-06-26 04:34:37.556626
# Unit test for method init of class Settings
def test_Settings_init():

    init = settings.init()
    assert init == None


# Generated at 2022-06-26 04:34:38.645929
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()


# Generated at 2022-06-26 04:34:49.023038
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ['HOME'],'.config/thefuck')
    assert settings.require_confirmation == True
    assert settings.priority == {}
    assert settings.exclude_rules == ('sudo', )
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15

# Generated at 2022-06-26 04:34:50.966882
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()



# Generated at 2022-06-26 04:34:56.111597
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    print('User config path: ' + str(settings_0.get('user_dir')))
    assert isinstance(settings_0.get('user_dir'), Path)



# Generated at 2022-06-26 04:35:01.545262
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init(args=None)


# Generated at 2022-06-26 04:35:03.749574
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()



# Generated at 2022-06-26 04:35:11.810817
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    args_1 = argparse.Namespace()
    settings_1.init(args_1)
    assert settings_1._get_user_dir_path() == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings_1.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert len(settings_1) == 10
    assert settings_1.get('rules') == ['git_add_command', 'git_commit_command']
    assert settings_1.get('exclude_rules') == []
    assert settings_1.get('priority') == {}
    assert settings_1.get('wait_command')

# Generated at 2022-06-26 04:35:18.587661
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0.get('user_dir').endswith('.config/thefuck')
    settings_0_2 = Settings()
    settings_0_2.init()
    assert settings_0_2.get('user_dir').endswith('.config/thefuck')
    # assert settings_0.get('user_dir') == settings_0_2.get('user_dir')


# Generated at 2022-06-26 04:35:21.982698
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    assert isinstance(settings_0, Settings)
