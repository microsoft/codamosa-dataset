

# Generated at 2022-06-26 04:30:06.866048
# Unit test for method init of class Settings
def test_Settings_init():
	settings_0.init()
	assert settings_0.user_dir.joinpath('settings.py') == type(object)


# Generated at 2022-06-26 04:30:07.660620
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1.init()


# Generated at 2022-06-26 04:30:08.500688
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

# Generated at 2022-06-26 04:30:10.720480
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()



# Generated at 2022-06-26 04:30:16.594768
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert(settings_0['require_confirmation'] == True)
    assert(settings_0['no_colors'] == False)
    assert(settings_0['debug'] == False)
    assert(settings_0['history_limit'] == 10)
    assert(settings_0['alter_history'] == False)
    assert(settings_0['repeat'] == False)
    assert(settings_0['wait_command'] == 3)
    assert(settings_0['env'] == {})
    assert(settings_0['wait_slow_command'] == 5)
    assert(settings_0['exclude_rules'] == [])
    assert(settings_0['priority'] == {})
    assert(settings_0['exclude_commands'] == [])

# Generated at 2022-06-26 04:30:20.577805
# Unit test for method init of class Settings
def test_Settings_init():
    # Expect that settings_0 has been changed,
    #   by the method init of class Settings
    settings_0.init()
    assert settings == settings_0



# Generated at 2022-06-26 04:30:25.104412
# Unit test for method init of class Settings
def test_Settings_init():
    """
    Unit test for method init of class Settings
    """
    import StringIO
    saved_stdout = sys.stdout
    try:
        out = StringIO.StringIO()
        sys.stdout = out
        test_case_0()
    finally:
        sys.stdout = saved_stdout
    output = out.getvalue().strip()
    assert output == ""


# Generated at 2022-06-26 04:30:30.330445
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1.init()
    assert(settings_1.user_dir==os.path.expanduser(os.path.join('~', '.config', 'thefuck')))
    

# Generated at 2022-06-26 04:30:37.134151
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    # Here we check that the user configuration directory is created
    # and contains the default configuration files
    assert settings_0['user_dir'] == Path('~', '.thefuck').expanduser()
    assert Path(settings_0['user_dir'], 'settings.py').is_file()
    assert Path(settings_0['user_dir'], 'rules').is_dir()
    assert len(os.listdir(settings_0['user_dir'].joinpath('rules'))) > 0

# Generated at 2022-06-26 04:30:42.638679
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0._setup_user_dir()
    settings_0._init_settings_file()
    settings_0.update(settings_0._settings_from_file())
    settings_0.update(settings_0._settings_from_env())
    settings_0.update(settings_0._settings_from_args(args=None))


# Generated at 2022-06-26 04:31:07.961371
# Unit test for method init of class Settings
def test_Settings_init():
    from tests.utils import captured_output
    from .command import Command
    from .logs import _logger, DEBUG

    sys.argv = ["thefuck"]
    settings_0 = Settings(const.DEFAULT_SETTINGS)
    settings_1 = Settings()
    assert settings_0 == settings_1
    
    #Should load from settings.py if exists
    settings_0.init()
    user_dir = settings_0._get_user_dir_path()
    user_dir.joinpath('settings.py').touch()
    settings_1.init()
    assert settings_0 == settings_1
    
    #Should load from environment variable XDG_CONFIG_HOME
    sys.argv = ["thefuck","-y","-d"]

# Generated at 2022-06-26 04:31:11.249847
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0.get('debug') == False


# Generated at 2022-06-26 04:31:13.787404
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init(args=None)


# Generated at 2022-06-26 04:31:16.735091
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init('settings.py')


# Generated at 2022-06-26 04:31:17.493301
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

# Generated at 2022-06-26 04:31:28.647010
# Unit test for method init of class Settings
def test_Settings_init():
    """
    Test the method init of class Settings

    :return: nothing
    """
    settings_1 = Settings()
    settings_1.init()

# Generated at 2022-06-26 04:31:40.221665
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import _exception
    from .logs import _warn
    from .logs import exception
    from .system import _Path
    from .system import _Path_is_dir
    from .system import _Path_is_file
    from .system import _Path_mkdir
    from .system import _Path_open
    from .system import _Path_joinpath
    from .system import _Path_expanduser
    from .system import _write

    def _Path_joinpath(self, *args):
        return _Path()

    with patch('thefuck.settings.Path.joinpath', _Path_joinpath):
        settings_1 = Settings()
        settings_1._setup_user_dir()

    def _Path_expanduser(self):
        return _Path()


# Generated at 2022-06-26 04:31:44.042791
# Unit test for method init of class Settings
def test_Settings_init():
    settings_init = Settings()
    settings_init.init()

__all__ = ['settings']

# Generated at 2022-06-26 04:31:56.136922
# Unit test for method init of class Settings
def test_Settings_init():
    settings_init = Settings()
    settings_init.init()
    assert settings_init['require_confirmation'] is False
    assert settings_init['repeat'] is False
    assert settings_init['history_limit'] is None
    assert settings_init['wait_command'] is 3
    assert settings_init['alter_history'] is True
    assert settings_init['rules'] is not None
    assert settings_init['exclude_rules'] is not None
    assert settings_init['priorities'] is None
    assert settings_init['no_colors'] is None
    assert settings_init['debug'] is False
    assert settings_init['slow_commands'] is None
    assert settings_init['wait_slow_command'] is 10
    assert settings_init['exclude_search_path_prefixes'] is None

# Generated at 2022-06-26 04:32:01.339496
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

# Generated at 2022-06-26 04:32:23.563184
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

# Unit tests for method SETTINGS_FROM_ENV of class Settings

# Generated at 2022-06-26 04:32:37.144453
# Unit test for method init of class Settings
def test_Settings_init():
    temp_dir = tempfile.mkdtemp()
    xdg_config_home = os.environ.get('XDG_CONFIG_HOME', '~/.config')
    user_dir = Path(xdg_config_home, 'thefuck').expanduser()
    legacy_user_dir = Path('~', '.thefuck').expanduser()
    # test user_dir
    os.environ['XDG_CONFIG_HOME'] = temp_dir
    settings_1 = Settings()
    assert settings_1.user_dir == user_dir
    os.environ['XDG_CONFIG_HOME'] = legacy_user_dir
    settings_2 = Settings()
    assert settings_2.user_dir == Path(temp_dir, 'thefuck')
    # test `settings.py`
    settings_

# Generated at 2022-06-26 04:32:39.398423
# Unit test for method init of class Settings
def test_Settings_init():
    # Create the object
    settings_0 = Settings()

    # Unit test for method init of class Settings
    # TODO !
    pass


# Generated at 2022-06-26 04:32:41.871409
# Unit test for method init of class Settings
def test_Settings_init():
    # test 1
    settings_1 = Settings()
    settings_1.init()
    assert settings_1.user_dir == Path('~/.config/thefuck').expanduser()


# Generated at 2022-06-26 04:32:52.115128
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1.init()
    if settings_1.rules != const.DEFAULT_RULES:
        raise AssertionError('rules is not correctly initialised')
    if settings_1.exclude_rules != []:
        raise AssertionError('exclude_rules is not correctly initialised')
    if settings_1.priority != {}:
        raise AssertionError('priority is not correctly initialised')
    if settings_1.wait_command != 3:
        raise AssertionError('wait_command is not correctly initialised')
    if settings_1.history_limit != 10:
        raise AssertionError('history_limit is not correctly initialised')
    if settings_1.require_confirmation != True:
        raise AssertionError('require_confirmation is not correctly initialised')


# Generated at 2022-06-26 04:32:55.926966
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0.user_dir == Path('~', '.thefuck').expanduser()



# Generated at 2022-06-26 04:32:57.686813
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert isinstance(settings_0, Settings)
    assert settings_0.user_dir

# Generated at 2022-06-26 04:33:09.105053
# Unit test for method init of class Settings
def test_Settings_init():
    from .tests.utils import replace_attr
    from .tests.utils import reset_attr
    from .logs import on_exception
    from .logs import on_exception_args
    from unittest import TestCase
    from io import StringIO
    from mock import patch
    from mock import MagicMock
    import sys
    import os
    import shutil
    import time
    import random

    class TestSettingsInit(TestCase):
        def setUp(self):
            self.test_dir = Path('test')
            self.test_dir.mkdir(exist_ok=True)
            os.environ['XDG_CONFIG_HOME'] = self.test_dir.as_posix()
            shutil.rmtree(self.test_dir.joinpath('thefuck').as_posix())
           

# Generated at 2022-06-26 04:33:11.785350
# Unit test for method init of class Settings
def test_Settings_init():
    # Test case 0
    try:
        settings_0 = Settings()
        # Settings._setup_user_dir()
    except NameError:
        settings_0._setup_user_dir()

    settings_0.init()
    settings_0.user_dir


# Generated at 2022-06-26 04:33:15.088277
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.get_user_dir_path()
    settings_0.init()


# Generated at 2022-06-26 04:33:35.430220
# Unit test for method init of class Settings
def test_Settings_init():
    instance = Settings()
    instance.init()


# Generated at 2022-06-26 04:33:38.230458
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()
    

# Generated at 2022-06-26 04:33:40.185356
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()

# Generated at 2022-06-26 04:33:42.451363
# Unit test for method init of class Settings
def test_Settings_init():

    settings_0 = Settings()
    settings_0.init()


# Generated at 2022-06-26 04:33:43.828708
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()


# Generated at 2022-06-26 04:33:48.370874
# Unit test for method init of class Settings
def test_Settings_init():
    # Arrange
    settings_0 = Settings()
    # Act
    var_0 = settings_0.init()
    # Assert
    assert var_0 == None


# Generated at 2022-06-26 04:33:49.659217
# Unit test for method init of class Settings
def test_Settings_init():
    assert test_case_0() == None

settings.init()

# Generated at 2022-06-26 04:33:54.197949
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()
    settings_0 = Settings()
    settings_0.init(args=None)


# Generated at 2022-06-26 04:33:56.706977
# Unit test for method init of class Settings
def test_Settings_init():
    # Test without param
    test_case_0()


# Generated at 2022-06-26 04:33:59.361789
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init


# Generated at 2022-06-26 04:34:52.443029
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    value = settings_0.init()
    assert not value


# Generated at 2022-06-26 04:34:57.432379
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    var_1 = settings_1.init()
    try:
        assert settings_1 == settings
    except AssertionError:
        raise Exception(
            'Mismatch between {} and {}'.format(settings_1, settings))


# Generated at 2022-06-26 04:35:00.680913
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()


# Generated at 2022-06-26 04:35:07.625304
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    settings_1 = Settings()
    settings_1.user_dir = Path('/usr/bin/thefuck')
    settings_1._init_settings_file()
    var_1 = settings_1.init()
    assert str(var_1.get('_get_user_dir_path')) == 'Path(\'/usr/bin/thefuck\')'
    assert str(var_1.get('_init_settings_file')) == 'None'

# Generated at 2022-06-26 04:35:08.660488
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()



# Generated at 2022-06-26 04:35:10.587589
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

# Generated at 2022-06-26 04:35:20.149173
# Unit test for method init of class Settings
def test_Settings_init():
  var_0 = Settings()
  var_1 = os.environ
  os.environ = {'XDG_CONFIG_HOME':'~/.config', 'THEFUCK_DEBUG':'True', 'THEFUCK_WAIT_COMMAND':'2', 'THEFUCK_SLOW_COMMANDS':'.*', 'THEFUCK_EXCLUDE_RULES':'DEFAULT_RULES:rm', 'THEFUCK_ALTER_HISTORY':'True', 'THEFUCK_REQUIRE_CONFIRMATION':'False', 'THEFUCK_INSTANT_MODE':'True', 'THEFUCK_HISTORY_LIMIT':'42', 'THEFUCK_NO_COLORS':'True'}
  var_1 = settings.init()
  os.environ = var_1

# Generated at 2022-06-26 04:35:24.006220
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()
    assert True


# Generated at 2022-06-26 04:35:27.054991
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    var_1 = settings_1.init()


# Generated at 2022-06-26 04:35:31.633840
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()
    assert var_0 == None



# Generated at 2022-06-26 04:37:37.431860
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.user_dir = Path('/usr/local', '.thefuck')
    settings_0.user_dir.expanduser = mock.Mock()
    settings_0._setup_user_dir = mock.Mock()
    settings_0._init_settings_file = mock.Mock()
    settings_0._settings_from_file = mock.Mock(return_value={'a': 0})
    settings_0._settings_from_args = mock.Mock(return_value={'b': 1})
    settings_0._settings_from_env = mock.Mock(return_value={'c': 2})
    var_0 = settings_0.init()
    assert var_0 == {'a': 0, 'b': 1, 'c': 2}
    assert settings_

# Generated at 2022-06-26 04:37:44.069718
# Unit test for method init of class Settings
def test_Settings_init():
    input_0 = Settings()
    var_0 = input_0.init()
    assert var_0 == None


# Generated at 2022-06-26 04:37:45.219426
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()


# Generated at 2022-06-26 04:37:52.203048
# Unit test for method init of class Settings
def test_Settings_init():
    # Create context
    settings_0 = Settings()

    # Invoke method
    var_0 = settings_0.init()

    # Check the results
    assert var_0 is None
    assert settings_0._get_user_dir_path() == Path("/home/vagrant/.config/thefuck")
    assert settings_0.user_dir.is_dir()
    assert settings_0.user_dir == Path("/home/vagrant/.config/thefuck")
    assert settings_0._settings_from_file() == {}
    assert settings_0._rules_from_env("DEFAULT_RULES:sed:cd:pwd") == ["wrong_command", "sed", "cd", "pwd"]
    assert settings_0._priority_from_env("sed=1") == [("sed", 1)]
    assert settings_

# Generated at 2022-06-26 04:38:01.975179
# Unit test for method init of class Settings
def test_Settings_init():
    from functools import partial
    from unittest import mock

    settings_0 = Settings()
    # Func for patching
    def _func():
        return None


# Generated at 2022-06-26 04:38:02.872992
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

# Generated at 2022-06-26 04:38:04.742381
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()
    assert var_0 is None


# Generated at 2022-06-26 04:38:07.316748
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()


if __name__ == '__main__':
    import pytest
    pytest.main(['-x', 'test_Settings.py'])

# Generated at 2022-06-26 04:38:16.461850
# Unit test for method init of class Settings
def test_Settings_init():
    from .helper import assert_equal
    settings_0 = Settings()
    var_0 = settings_0.init()
    settings_1 = settings_0._init_settings_file()
    settings_2 = settings_0._settings_from_file()
    var_1 = settings_0.update(settings_2)
    settings_3 = settings_0._settings_from_env()
    settings_4 = settings_0.update(settings_3)
    settings_5 = settings_0._settings_from_args()
    var_2 = settings_0.update(settings_5)
    settings_6 = settings_0.user_dir
    var_3 = assert_equal(settings_6, Path('~/.config/thefuck').expanduser())
    settings_7 = settings_0._get_user_dir_path()

# Generated at 2022-06-26 04:38:18.334443
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
