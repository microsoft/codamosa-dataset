

# Generated at 2022-06-26 04:30:18.617778
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()

# Generated at 2022-06-26 04:30:22.055427
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1.init()
    settings_2 = Settings()
    settings_2.init(args=None)


# Generated at 2022-06-26 04:30:23.434190
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()


# Generated at 2022-06-26 04:30:36.370181
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()

    settings_0.init()
    assert settings_0['debug'] == False
    assert settings_0['require_confirmation'] == True
    assert settings_0['no_colors'] == False
    assert settings_0['history_limit'] == None
    assert settings_0['wait_command'] == 3
    assert settings_0['wait_slow_command'] == 10
    assert settings_0['alter_history'] == True
    assert settings_0['env'] == {}
    assert settings_0['exclude_rules'] == []
    assert settings_0['priority'] == {}
    assert settings_0['repeat'] == False
    assert settings_0['rules'] == [
        '<shell>', '<alias>', '<command>', '<lookup>']

# Generated at 2022-06-26 04:30:39.534296
# Unit test for method init of class Settings
def test_Settings_init():
    # Create a new instance of Settings
    settings_0 = Settings()
    # Call method init of settings_0
    settings_0.init(args=None)
    assert settings_0.require_confirmation == True


# Generated at 2022-06-26 04:30:52.464548
# Unit test for method init of class Settings
def test_Settings_init():
    # Unit test for test case 0
    settings_0 = Settings()
    from .logs import exception
    from .const import DEFAULT_SETTINGS

    assert settings_0._setup_user_dir() is None
    assert settings_0._init_settings_file() is None
    assert settings_0.update(settings_0._settings_from_file()) is None
    assert settings_0.update(settings_0._settings_from_env()) is None
    assert settings_0.update(settings_0._settings_from_args(args=None)) is None
    assert settings_0.get(settings_0) is not None
    assert settings_0.get(settings_0) is None
    assert settings_0.get(settings_0) is not None

# Generated at 2022-06-26 04:30:54.161249
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings(const.DEFAULT_SETTINGS)
    settings_0.init()
    assert settings_0 == settings


# Generated at 2022-06-26 04:30:56.912261
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()

    settings_0.init()
    pass


# Generated at 2022-06-26 04:30:59.080076
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()


# Generated at 2022-06-26 04:31:01.095709
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init(args = None)


# Generated at 2022-06-26 04:32:00.334038
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()

    from thefuck.settings import const

    assert settings_0.get('priority') == const.DEFAULT_SETTINGS['priority']
    assert settings_0.get('require_confirmation') == const.DEFAULT_SETTINGS['require_confirmation']
    assert settings_0.get('wait_command') == const.DEFAULT_SETTINGS['wait_command']
    assert settings_0.get('slow_commands') == const.DEFAULT_SETTINGS['slow_commands']
    assert settings_0.get('history_limit') == const.DEFAULT_SETTINGS['history_limit']
    assert settings_0.get('no_colors') == const.DEFAULT_SETTINGS['no_colors']
    assert settings_0.get('alter_history') == const.DEFAULT_

# Generated at 2022-06-26 04:32:01.163860
# Unit test for method init of class Settings
def test_Settings_init():

    test_case_0()

# Generated at 2022-06-26 04:32:07.057710
# Unit test for method init of class Settings
def test_Settings_init():
    # case 0
    fp = open(const.DEFAULT_SETTINGS_PATH, 'w')
    fp.write(const.SETTINGS_HEADER)
    fp.close()
    settings_1 = Settings()
    settings_1.init()
    assert settings_1.script == const.DEFAULT_SETTINGS.get('script')

    # case 1
    fp = open(const.DEFAULT_SETTINGS_PATH, 'a')
    fp.write('script = "echo \"Fuck\""\n')
    fp.close()
    settings_1.init()
    assert settings_1.script == "echo \"Fuck\""

    # case 2
    os.environ['THEFUCK_SCRIPT'] = 'ls && ls'
    settings_2 = Settings()

# Generated at 2022-06-26 04:32:09.080778
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1.init()
    assert isinstance(settings_1, Settings)


# Generated at 2022-06-26 04:32:15.817240
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0.keys() == {'priority', 'require_confirmation',
        'history_limit', 'no_colors', 'debug', 'exclude_rules', 'exclude_dirs',
        'wait_slow_command', 'alter_history', 'rules', 'exclude_commands',
        'slow_commands', 'wait_command', 'num_close_matches', 'instant_mode',
        'excluded_search_path_prefixes'}



# Generated at 2022-06-26 04:32:26.138531
# Unit test for method init of class Settings
def test_Settings_init():
    # Defined variables
    # name = None(String)

    # Test case 0
    try:
        test_case_0()
    except Exception as e:
        print(e)
        print("=> Failed test_case_0()")

    # Test case 1

    # Test case 2

    # Test case 3

    # Test case 4

    # Test case 5

    # Test case 6

    # Test case 7

    # Test case 8

    # Test case 9


# Generated at 2022-06-26 04:32:30.043349
# Unit test for method init of class Settings
def test_Settings_init():
    #Check if user_dir has been created
    assert settings.user_dir
    #Check if 'rules' dir has been created
    assert settings.user_dir.joinpath('rules').is_dir()
    #Check if 'settings.py' has been created
    assert settings.user_dir.joinpath('settings.py').is_file()


# Generated at 2022-06-26 04:32:39.548712
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings({})
    settings_1.init()
    assert settings_1.rules == settings_0.rules


# Generated at 2022-06-26 04:32:45.781373
# Unit test for method init of class Settings
def test_Settings_init():
    from .system import Path
    from .logs import exception
    from .logs import clear_output
    import mock
    import sys
    import os

    settings_0 = Settings()
    settings_0._setup_user_dir = mock.Mock(return_value=Path('/home/user/.config/thefuck'))
    settings_0._init_settings_file = mock.Mock()
    settings_0._settings_from_file = mock.Mock()
    settings_0._settings_from_env = mock.Mock()
    settings_0._settings_from_args = mock.Mock()

    settings_0.init()

    settings_0._setup_user_dir.assert_called_once_with()
    settings_0._init_settings_file.assert_called_once_with()
    settings_0

# Generated at 2022-06-26 04:32:52.710714
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    args = None
    settings._settings_from_args(args)
    settings._settings_from_env()
    settings._setup_user_dir()
    settings._init_settings_file()
    try:
        settings.update(settings._settings_from_file())
    except Exception:
        exception("Can't load settings from file", sys.exc_info())

    try:
        settings.update(settings._settings_from_env())
    except Exception:
        exception("Can't load settings from env", sys.exc_info())

    settings.update(settings._settings_from_args(args))


# Generated at 2022-06-26 04:33:52.074318
# Unit test for method init of class Settings
def test_Settings_init():
    def _test_settings_from_args(args, from_args):
        settings_1 = Settings()
        settings_1.init(args)

# Generated at 2022-06-26 04:34:03.320100
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0.get("require_confirmation") == True

# Generated at 2022-06-26 04:34:09.585361
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    func_1 = lambda: settings_1.init(None)
    func_1()
    assert settings_1._get_user_dir_path() == Path('/home/mj/.config/thefuck')


# Generated at 2022-06-26 04:34:20.886281
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings(const.DEFAULT_SETTINGS)
    settings_1.init(['ls', '-l'])
    assert settings_1.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings_1.rules == ':\n'
    assert settings_1.exclude_rules == const.DEFAULT_RULES
    assert settings_1.priority == {}
    assert settings_1.wait_command == 0
    assert settings_1.history_limit == 0
    assert settings_1.wait_slow_command == 10
    assert settings_1.no_colors == False
    assert settings_1.require_confirmation == True
    assert settings_1.slow_commands == ['(?i)^rvm use [^\s]{1,}$', 'vagrant']

# Generated at 2022-06-26 04:34:24.886336
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings.init()
    assert settings.get('require_confirmation') == False
    assert settings.get('wait_slow_command') == 15


# Generated at 2022-06-26 04:34:32.494143
# Unit test for method init of class Settings
def test_Settings_init():
    "Check that the method init behave as expected"
    from unittest import TestCase, main
    from thefuck.settings import Settings
    from thefuck.logs import exception
    from thefuck.system import Path
    from tempfile import mkdtemp
    from shutil import rmtree

    def fake_user_dir_path():
        return Path('~', 'user_dir').expanduser()

    def fake_init_settings_file(self):
        settings_path = fake_user_dir_path().joinpath('settings.py')
        with settings_path.open(mode='w') as settings_file:
            settings_file.write(u'var = 1\n')

    def fake_settings_from_file(self):
        return {'var': 2}

    def fake_update(self, other):
        self

# Generated at 2022-06-26 04:34:33.395870
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

# Generated at 2022-06-26 04:34:37.731345
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    settings.init()
    assert Path(settings['user_dir']) == Path(os.path.expanduser('~/.config/thefuck'))

# Generated at 2022-06-26 04:34:43.614737
# Unit test for method init of class Settings
def test_Settings_init():
    # Test case 1:
    settings_1 = Settings()
    settings_1.init()

# Generated at 2022-06-26 04:34:47.648788
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.update({'user_dir': 'value'})
    settings_0.spec_set = True
    settings_0.spec_set = None
    settings_0.init()



# Generated at 2022-06-26 04:35:47.724648
# Unit test for method init of class Settings
def test_Settings_init():
    """Tests the init method of the Settings class"""
    assert_equal(None, settings.init())
    assert_equal(False, settings.get("require_confirmation"))



# Generated at 2022-06-26 04:35:50.448500
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    settings_0 = Settings()
    settings_0.init()



# Generated at 2022-06-26 04:35:51.032612
# Unit test for method init of class Settings
def test_Settings_init():
    pass

# Generated at 2022-06-26 04:35:52.601960
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

# Unit tests for method _settings_from_env of class Settings

# Generated at 2022-06-26 04:35:53.966015
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init() # Assertion

# Generated at 2022-06-26 04:35:56.719101
# Unit test for method init of class Settings
def test_Settings_init():
    from unittest import TestCase, main
    from .settings import Settings
    settings = Settings()
    settings.init()
    test = TestCase()
    test_settings = Settings({'require_confirmation': True, 'no_colors': False})
    test.assertEqual(settings, test_settings)


# Generated at 2022-06-26 04:35:57.983175
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()

# Generated at 2022-06-26 04:35:59.488030
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.init() == None


# Generated at 2022-06-26 04:36:08.400452
# Unit test for method init of class Settings
def test_Settings_init():
    var_0 = Settings.init(Settings())
    var_1 = Settings.get_user_dir_path(Settings())
    var_2 = Settings.init_settings_file(Settings())
    var_3 = Settings.settings_from_file(Settings())
    var_4 = Settings.settings_from_env(Settings())
    var_5 = Settings.impl(Settings(), '', '')
    var_6 = Settings.val_from_env(Settings(), '', '')
    var_7 = Settings.rules_from_env(Settings(), '')
    var_8 = Settings.priority_from_env(Settings(), '')
    var_9 = Settings.settings_from_args(Settings(), '')



# Generated at 2022-06-26 04:36:18.892261
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .thefuck.utils import memoize

    for key in settings:
        val = getattr(settings, key)
        if key == 'exclude_rules':
            # For testing, include all available rules
            setattr(settings, key, const.DEFAULT_RULES)
        elif key == 'exclude_rules':
            # Remove excluded rules for testing
            setattr(settings, key, [])
        elif key == 'history_limit':
            # Prevent loading of all history
            setattr(settings, key, 0)
        elif key == 'memoize_timeout':
            setattr(settings, key, -1)



# Generated at 2022-06-26 04:38:58.645585
# Unit test for method init of class Settings
def test_Settings_init():
    initial_data = Settings()
    assert initial_data == Settings(const.DEFAULT_SETTINGS)
    assert len(initial_data) == 12
    assert initial_data.user_dir is not None
    assert len(initial_data.user_dir) > 0


# Generated at 2022-06-26 04:39:00.159449
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    var_1 = settings_1.init()
    assert True


# Generated at 2022-06-26 04:39:10.870249
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .logs import print_debug
    from .logs import print_error
    from .logs import print_exception
    from .logs import print_system
    from .logs import print_warning
    from .system import Path
    from .utils import get_closest
    from .utils import get_closest_match
    from .utils import get_historical_command
    from .utils import get_historical_commands
    from .utils import get_history_file_path
    from .utils import get_slow_command
    from .utils import is_enabled
    from .utils import memoize
    from .utils import print_result
    from .utils import prefix_match
    from .utils import run_script
    from .utils import search_in_history

# Generated at 2022-06-26 04:39:12.876621
# Unit test for method init of class Settings
def test_Settings_init():
    Settings_0 = Settings(const.DEFAULT_SETTINGS)
    Settings_0.init()
    assert(True)


# Generated at 2022-06-26 04:39:18.322033
# Unit test for method init of class Settings
def test_Settings_init():
    with patch('thefuck.conf.settings.Settings._setup_user_dir') as mock_settings__setup_user_dir:
        with patch('thefuck.conf.settings.Settings._init_settings_file') as mock_settings__init_settings_file:
            with patch('thefuck.conf.settings.Settings._settings_from_file') as mock_settings__settings_from_file:
                with patch('thefuck.conf.settings.Settings._settings_from_env') as mock_settings__settings_from_env:
                    with patch('thefuck.conf.settings.Settings._settings_from_args') as mock_settings__settings_from_args:
                        settings_1 = Settings()
                        var_1 = settings_1.init({})
                        assert mock_settings__setup_user_dir.call_count == 1
                        assert mock_settings

# Generated at 2022-06-26 04:39:29.460067
# Unit test for method init of class Settings
def test_Settings_init():
    from ddt import ddt, data, unpack
    class settings_init_args:
        settings_0 = settings_init_args.settings_0 = Settings()
        settings_0.init()
        settings_0 = settings_init_args.settings_0 = Settings()
        settings_0.init()
        settings_0 = settings_init_args.settings_0 = Settings()
        settings_0.init()
    settings_init_args_0 = settings_init_args()
    settings_init_args_0 = settings_init_args()
    settings_init_args_0 = settings_init_args()
    settings_init_args_0 = settings_init_args()
    settings_init_args_0 = settings_init_args()
    settings_init_args_0 = settings_init_args(
    )


# Generated at 2022-06-26 04:39:33.538263
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()



# Generated at 2022-06-26 04:39:34.703589
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()


# Generated at 2022-06-26 04:39:36.404944
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()



# Generated at 2022-06-26 04:39:38.434615
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

if __name__ == '__main__':
    test_Settings_init()