

# Generated at 2022-06-26 04:30:03.286374
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    if settings_0.user_dir == '~/.config/thefuck':
        print('test_case_1: Pass')
    else:
        print('test_case_1: Fail')

if __name__ == "__main__":
    test_case_0()
    test_Settings_init()

# Generated at 2022-06-26 04:30:07.091844
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import DEBUG, has_logs

    settings_0 = Settings()
    settings_0.init()
    assert settings_0.user_dir is not None
    assert settings_0._settings_from_file() is not None
    assert settings_0._settings_from_env() is not None
    assert settings_0._settings_from_args() is not None
    assert settings_0.log.level == DEBUG
    assert has_logs(settings_0.log.debug)


# Generated at 2022-06-26 04:30:15.212040
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0['require_confirmation'] == True
    assert settings_0['slow_commands'] == ['lein', 'gradle', './gradlew', 'sbt', './sbt']
    assert settings_0['exclude_rules'] == ['git_push', 'hg_push']
    assert settings_0['rules'] == ['sed', 'cd_parent']
    assert settings_0['wait_command'] == 3
    assert settings_0['priority'] == {}
    assert settings_0['sudo_command'] == u'sudo'
    assert settings_0['num_close_matches'] == 3
    assert settings_0['alter_history'] == True

# Generated at 2022-06-26 04:30:18.772292
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    try:
        settings_0.init()
    except:
        assert False


# Generated at 2022-06-26 04:30:20.243047
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

# Generated at 2022-06-26 04:30:26.121050
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0._setup_user_dir()
    settings_0.user_dir = settings_0._get_user_dir_path()
    settings_0._init_settings_file()
    settings_0._settings_from_file()
    settings_0._settings_from_env()
    settings_0._settings_from_args(test_case_0)
    settings_0.init()


# Generated at 2022-06-26 04:30:37.316724
# Unit test for method init of class Settings
def test_Settings_init():
    from thefuck.main import TheFuckArgumentParser
    from thefuck.utils import mem
    from thefuck.settings import settings
    from thefuck.settings import const

    argparser = TheFuckArgumentParser(argv=['t'])
    args = argparser.parse_args()

# Generated at 2022-06-26 04:30:42.448024
# Unit test for method init of class Settings
def test_Settings_init():
    import imp
    import pytest
    from .logs import exception

    settings_1 = Settings()
    settings_1.init()
    assert imp.reload(settings_1) is not None

    settings_2 = Settings()
    try:
        settings_2.init(1)
    except TypeError:
        True



# Generated at 2022-06-26 04:30:55.489869
# Unit test for method init of class Settings
def test_Settings_init():
    """Settings.init should work correctly"""
    settings_0 = Settings()
    settings_0.init()
    assert settings_0.get('require_confirmation') == True
    assert settings_0.get('no_colors') == False
    assert settings_0.get('history_limit') == 10
    assert settings_0.get('alter_history') == True
    assert settings_0.get('instant_mode') == False
    assert settings_0.get('wait_command') == 15
    assert settings_0.get('slow_commands') == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings_0.get('excluded_search_path_prefixes') == ['/usr', '/var', '/bin', '__pycache__', '.']
    assert settings_

# Generated at 2022-06-26 04:31:06.461653
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings = Settings()
    settings.init()
    assert settings.require_confirmation == True
    assert settings.slow_commands is None
    assert settings.priority == {'rule_x': 1}
    assert settings.rules == ['rule_x', 'rule_y']
    assert settings.exclude_rules == ['rule_a']
    assert settings.wait_command == 3
    assert settings.history_limit == 9
    assert settings.wait_slow_command == 9
    assert settings.no_colors == False
    assert settings.num_close_matches == 3
    assert settings.instant_mode == True
    assert settings.excluded_search_path_prefixes == []
    assert settings.alter_history == True
    assert settings.debug == False
    assert settings.repeat == False
    assert settings.user

# Generated at 2022-06-26 04:31:39.553749
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings.init(args=None)
    assert (settings['alter_history'] == False)
    assert (settings['no_colors'] == False)
    assert (settings['repeat'] == None)
    assert (settings['rules'] ==['fzf', 'fzf_fasd_mru_last', 'fzf_fasd_mru_first', 'fasd', 'fasd_mru_first', 'fasd_mru_last', 'fuzzy_with_backup', 'fuzzy', 'ghq', 'git_show', 'history', 'longest', 'longest_match', 'man', 'man_pages', 'most_likely', 'nearest', 'repo', 'shortest', 'z'])


# Generated at 2022-06-26 04:31:43.538447
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()

# Generated at 2022-06-26 04:31:47.218001
# Unit test for method init of class Settings
def test_Settings_init():
    try:
        settings_0 = Settings()
        settings_0.init()
        return True
    except Exception as e:
        print(e)
        return False


# Generated at 2022-06-26 04:31:48.180672
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

# Generated at 2022-06-26 04:31:49.249982
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

# Generated at 2022-06-26 04:31:59.970386
# Unit test for method init of class Settings
def test_Settings_init():
    # Return the user config resource, create it when it doesn't exist.
    user_dir_0 = Path('~', '.thefuck').expanduser()
    if not user_dir_0.is_dir():
        os.mkdir(user_dir_0)
    # Return the user config dir, create it when it doesn't exist.
    user_dir_1 = Path('~', '.thefuck').expanduser()
    if not user_dir_1.is_dir():
        os.mkdir(user_dir_1)
    # Return user config dir, create it when it doesn't exist.
    user_dir_2 = Path('~/.config/thefuck').expanduser()
    if not user_dir_2.is_dir():
        os.mkdir(user_dir_2)
    # Returns settings from args.

# Generated at 2022-06-26 04:32:01.432718
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

if __name__ == '__main__':
    test_Settings_init()

# Generated at 2022-06-26 04:32:03.575250
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings['history_limit'] == 10
    assert settings['require_confirmation']
    assert not settings['instant_mode']
    assert settings['debug']



# Generated at 2022-06-26 04:32:17.157559
# Unit test for method init of class Settings
def test_Settings_init():
    import random
    import string
    import os
    import doctest

    settings = Settings(const.DEFAULT_SETTINGS)
    pwd = os.getcwd()
    os.chdir('/tmp')
    # Generate a random directory name
    directoryName = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(10))
    # Create the directory in /tmp
    os.mkdir(directoryName)
    os.chdir(directoryName)
    # Create the settings.py file for The Fuck
    f = open('settings.py', 'w')
    # Copy the test case for settings.py
    f.write(const.SETTINGS_HEADER)
    f.close()
    # Set the XDG_CONFIG_HOME to the directory
   

# Generated at 2022-06-26 04:32:29.861828
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    import shutil
    import os, sys
    import imp
    import pytest
    try:
        import thefuck.main
        main_module_imported = True
    except (ImportError, ModuleNotFoundError):
        main_module_imported = False

    script_path = os.path.realpath(__file__)
    this_directory = os.path.dirname(script_path)
    thefuck_directory = os.path.dirname(this_directory)
    sys.path.append(thefuck_directory)

    test_dir = tempfile.mkdtemp()

# Generated at 2022-06-26 04:32:52.063419
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

# Generated at 2022-06-26 04:32:54.013547
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1.init()

# Generated at 2022-06-26 04:32:57.289464
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    var_1 = settings_1.init()

if __name__ == '__main__':
    test_case_0()
    test_Settings_init()

# Generated at 2022-06-26 04:33:01.280814
# Unit test for method init of class Settings
def test_Settings_init():
    xdg_config_home = os.environ.get('XDG_CONFIG_HOME', '~/.config')
    user_dir = Path(xdg_config_home, 'thefuck').expanduser()
    legacy_user_dir = Path('~', '.thefuck').expanduser()

    # For backward compatibility use legacy '~/.thefuck' if it exists:
    if legacy_user_dir.is_dir():
        warn(u'Config path {} is deprecated. Please move to {}'.format(
            legacy_user_dir, user_dir))
        return legacy_user_dir
    else:
        return user_dir



# Generated at 2022-06-26 04:33:08.979539
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    def user_dir_path_mock(self):
        return Path('sample_path')
    settings_user_dir_path_backup = Settings._get_user_dir_path
    Settings._get_user_dir_path = user_dir_path_mock
    settings_0 = Settings()
    settings_0._init_settings_file()
    settings_0.update = dict
    settings_0.user_dir = Path('sample_path')
    settings_0._settings_from_file = lambda: {'key': 'value'}
    settings_0._settings_from_env = dict
    settings_0._settings_from_args = dict
    var_0 = settings_0.init()
    Settings._get_user_dir_path = settings_user_dir_path_backup

# Generated at 2022-06-26 04:33:11.172579
# Unit test for method init of class Settings
def test_Settings_init():
    # Case 0: unit test for method init of class Settings
    test_case_0()

if __name__ == '__main__':
    test_Settings_init()

# Generated at 2022-06-26 04:33:16.838646
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0['debug'] = True
    settings_0['script_mode'] = True
    settings_0['wait_slow_command'] = 0.1
    settings_0['confirm_exit'] = True
    settings_0.init()


# Generated at 2022-06-26 04:33:21.639405
# Unit test for method init of class Settings
def test_Settings_init():
    try:
        settings_0 = Settings()
        settings_0.init()

    except SystemExit:
        pass
    except Exception:
        print ('Test failed!')
        raise

# Generated at 2022-06-26 04:33:32.105801
# Unit test for method init of class Settings
def test_Settings_init():
    """Test that the Settings.init() creates following:
        1. a directory pointed by default XDG path
        2. a settings.py file
    """
    # Generate test config path with random name
    test_conf_path = Path(tempfile.mkdtemp())
    os.environ['XDG_CONFIG_HOME'] = test_conf_path.as_posix()
    settings_1 = Settings()
    var_1 = settings_1.init()
    # Test if the directory with config and settings.py file are created
    assert test_conf_path.joinpath('thefuck').is_dir()
    assert test_conf_path.joinpath('thefuck', 'settings.py').is_file()
    # Test if the directory with the name "rules" is created

# Generated at 2022-06-26 04:33:34.277816
# Unit test for method init of class Settings
def test_Settings_init():
    test_0 = Settings()
    test_0.init()

# Generated at 2022-06-26 04:33:59.571317
# Unit test for method init of class Settings
def test_Settings_init():
    # Test with argument "args" with value None
    test_case_0()
    # Test with argument "args" with value None
    test_case_0()
    # Test with argument "args" with value None
    test_case_0()

# Generated at 2022-06-26 04:34:04.156839
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.user_dir_path = Path('/tmp')
    settings_0.user_dir = settings_0.user_dir_path
    settings_0.init()
    assert(settings_0.user_dir.joinpath('settings.py').read_text() == const.SETTINGS_HEADER)
    assert(settings_0.user_dir.joinpath('settings.py').read_text() != '\n')
    assert(settings_0.user_dir.joinpath('settings.py').read_text() != '')


# Generated at 2022-06-26 04:34:06.216788
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    var = settings.init()


# Generated at 2022-06-26 04:34:07.642581
# Unit test for method init of class Settings
def test_Settings_init():

    assert(var_0 == None)


# Generated at 2022-06-26 04:34:10.257429
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()

# Generated at 2022-06-26 04:34:11.426258
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()


# Generated at 2022-06-26 04:34:12.998958
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()

    test_case_0()

# Generated at 2022-06-26 04:34:14.682993
# Unit test for method init of class Settings
def test_Settings_init():
    
    print(settings.user_dir)


settings.init()

# Generated at 2022-06-26 04:34:16.175269
# Unit test for method init of class Settings
def test_Settings_init():
    # Verify for function call sort

    # Verify for function call str.split

    # Test for class Settings

    test_case_0()

# Generated at 2022-06-26 04:34:18.216776
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.init() == None


# Generated at 2022-06-26 04:34:48.903700
# Unit test for method init of class Settings

# Generated at 2022-06-26 04:34:51.380248
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    print('Unit test passed')


# Generated at 2022-06-26 04:34:54.775555
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()
    print(var_0)



# Generated at 2022-06-26 04:34:58.014496
# Unit test for method init of class Settings
def test_Settings_init():
    var_1 = Settings()
    # var_1.init(args=None)
    assert var_1['require_confirmation'] == True
    # assert_equal(var_1['require_confirmation'], True)


# Generated at 2022-06-26 04:35:01.981551
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    # In case of no exception.
    assert True


# Generated at 2022-06-26 04:35:04.815979
# Unit test for method init of class Settings
def test_Settings_init():
    assert const.DEFAULT_SETTINGS[0] in settings.keys()


# Generated at 2022-06-26 04:35:12.085962
# Unit test for method init of class Settings
def test_Settings_init():

    ####
    # Test 0
    # Tests correct input

    # Set up
    settings_0 = Settings()

    # Test
    var_0 = settings_0.init()

    # Assertions
    assert var_0 == None

    ####
    # Test 1
    # Tests correct input

    # Set up
    settings_1 = Settings()
    args_1 = None

    # Test
    var_0 = settings_1.init(args_1)

    # Assertions
    assert var_0 == None

    ####
    # Test 2
    # Tests incorrect input

    # Set up
    settings_2 = Settings()
    args_2 = None

    # Test
    try:
        var_0 = settings_2.init(args_2)
    except Exception as e:
        var_0 = e

# Generated at 2022-06-26 04:35:19.280539
# Unit test for method init of class Settings
def test_Settings_init():
    var_1 = Settings()
    var_2 = Settings()
    var_3 = Settings()
    var_4 = Settings()
    var_5 = Settings()
    var_6 = Settings()
    var_7 = Settings()
    var_8 = Settings()
    var_9 = Settings()
    var_10 = Settings()
    var_11 = Settings()
    var_12 = Settings()
    var_13 = Settings()
    var_14 = Settings()
    var_15 = Settings()
    var_16 = Settings()
    var_17 = Settings()



# Generated at 2022-06-26 04:35:21.286993
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()


# Generated at 2022-06-26 04:35:23.790187
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()

# Generated at 2022-06-26 04:36:26.287069
# Unit test for method init of class Settings
def test_Settings_init():
    temp_tests = [
        (
            False,
        ),
    ]

    for test in temp_tests:
        temp_result = test_case_0()

    assert temp_result


# Generated at 2022-06-26 04:36:27.116289
# Unit test for method init of class Settings
def test_Settings_init():
    pass

# Generated at 2022-06-26 04:36:31.392809
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings
    var_0 = settings_0.init(settings_0, 1.19)


if __name__ == '__main__':
    import sys
    import nose2
    sys.argv.append('--verbose')
    sys.argv.append('--nologcapture')
    nose2.main()

# Generated at 2022-06-26 04:36:36.835068
# Unit test for method init of class Settings
def test_Settings_init():
    # Test case 0
    #
    # Try to load settings from file
    test_case_0()

# Generated at 2022-06-26 04:36:39.484940
# Unit test for method init of class Settings
def test_Settings_init():
    assert isinstance(settings.init(), None)


# Generated at 2022-06-26 04:36:42.899104
# Unit test for method init of class Settings
def test_Settings_init():
    # Uncomment following code to show execution results
    #test_case_0()
    print("TestCase 0 finished")
    return

settings.init()
if __name__ == '__main__':
    test_Settings_init()

# Generated at 2022-06-26 04:36:54.016044
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    with patch('thefuck.settings.Settings', return_value=settings_0) as settings_constructor_call:
        try:
            with patch('thefuck.settings.os', autospec=True) as mock_os:
                mock_os.environ = {'TF_ANSI_COLORS': 'true', 'TF_NO_COLORS': 'false'}
                var_0 = settings.init()
        except Exception as ex:
            print('init() raised an exception: {}'.format(ex))
        assert settings_constructor_call.called
        args, kwargs = settings_constructor_call.call_args
        if kwargs:
            print('called with kwargs:')

# Generated at 2022-06-26 04:36:56.263960
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()
    assert False


# Generated at 2022-06-26 04:36:57.594072
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()



# Generated at 2022-06-26 04:36:58.882429
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()


# Generated at 2022-06-26 04:39:12.115042
# Unit test for method init of class Settings
def test_Settings_init():
    invocation_0 = Settings()
    invocation_0.init()
    invocation_1 = Settings()
    invocation_1.init()


# Generated at 2022-06-26 04:39:13.739085
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings(const.DEFAULT_SETTINGS)
    var_0 = settings_0.init()
    assert var_0 is None

# Generated at 2022-06-26 04:39:17.849385
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    var_1 = settings_1._get_user_dir_path()
    var_2 = settings_1._setup_user_dir()
    var_3 = settings_1._init_settings_file()
    var_4 = settings_1._settings_from_file()
    var_5 = settings_1._settings_from_env()
    var_6 = settings_1._settings_from_args(args=None)


# Generated at 2022-06-26 04:39:22.742782
# Unit test for method init of class Settings
def test_Settings_init():
    # init function should set correct values to correct variables
    settings_1 = Settings()
    settings_1.init()
    assert settings_1['slow_commands'] == ['lein', '. /usr/local/etc/bash_completion']


# Generated at 2022-06-26 04:39:23.701688
# Unit test for method init of class Settings
def test_Settings_init():
    var_0 = test_case_0()

# Generated at 2022-06-26 04:39:26.023534
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()
    assert var_0 == None


# Generated at 2022-06-26 04:39:28.195856
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    return settings_0.__getattr__('debug')


# Generated at 2022-06-26 04:39:30.288699
# Unit test for method init of class Settings
def test_Settings_init():
    # Note: This unit test is for the method init of class Settings.

    settings.init(args=None)


# Generated at 2022-06-26 04:39:33.941743
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()


# Generated at 2022-06-26 04:39:35.024148
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()
