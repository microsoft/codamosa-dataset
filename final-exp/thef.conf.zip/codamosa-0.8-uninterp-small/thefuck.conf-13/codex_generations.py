

# Generated at 2022-06-26 04:30:04.283120
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()


# Generated at 2022-06-26 04:30:08.077454
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    settings_1 = Settings()
    settings_1.init()
    try:
        settings_2 = Settings()
        settings_2.init()
    except Exception as e:
        return True
    else:
        return False
    return True


# Generated at 2022-06-26 04:30:09.390997
# Unit test for method init of class Settings
def test_Settings_init():
    # Test cases
    test_case_0()


# Generated at 2022-06-26 04:30:12.802354
# Unit test for method init of class Settings
def test_Settings_init():
    # Test normal use
    str_0 = '~/.cache'
    settings_0 = Settings()
    settings_0.init()


# Generated at 2022-06-26 04:30:19.114802
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1.init()
    assert settings_1.user_dir.endswith(".cache/thefuck")
    assert settings_1.settings_path.endswith(".cache/thefuck/settings.py")


# Generated at 2022-06-26 04:30:29.071130
# Unit test for method init of class Settings
def test_Settings_init():
    str_0 = const.DEFAULT_SETTINGS['require_confirmation']
    str_1 = const.DEFAULT_SETTINGS['wait_command']
    str_2 = const.DEFAULT_SETTINGS['env']
    str_3 = const.DEFAULT_SETTINGS['alter_history']
    str_4 = const.DEFAULT_SETTINGS['wait_slow_command']
    str_5 = const.DEFAULT_SETTINGS['rules']
    str_6 = const.DEFAULT_SETTINGS['no_colors']
    str_7 = const.DEFAULT_SETTINGS['priority']
    str_8 = const.DEFAULT_SETTINGS['debug']
    str_9 = const.DEFAULT_SETTINGS['instant_mode']
    str_10 = const.DEFAULT_SETT

# Generated at 2022-06-26 04:30:40.634749
# Unit test for method init of class Settings
def test_Settings_init():
    str_0 = '~/.cache/.config/thefuck'
    str_1 = '~/.config/thefuck/settings.py'
    str_2 = '~/.config/thefuck'
    str_3 = '~/.thefuck'
    str_4 = '~/.thefuck/settings.py'
    str_5 = '~/.thefuck'
    tie_0 = '~/.cache/.config/thefuck/settings.py'
    tie_1 = '~/.cache/.config/thefuck/rules'
    str_7 = "Can't load settings from file"
    str_8 = "Can't load settings from env"
    str_9 = '~/.cache/thefuck'
    str_10 = '~/.thefuck'
    str_11 = '~/.thefuck/settings.py'
    str_

# Generated at 2022-06-26 04:30:50.042742
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()

    #    Check settings
    #    .
    settings_0.init(args)

    # The following line is needed to remove the user_home and user_dir directories
    # The line is commented to make the unit test faster.
    # os.system("rmdir -r ~/.config/thefuck")

# Generated at 2022-06-26 04:30:52.092228
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()



# Generated at 2022-06-26 04:30:54.232874
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    exception("Can't load settings from file", sys.exc_info())

    exception("Can't load settings from env", sys.exc_info())



# Generated at 2022-06-26 04:31:17.012241
# Unit test for method init of class Settings
def test_Settings_init():
    settings_init = Settings()
    settings_init.init()
    assert isinstance(settings_init, dict)


# Generated at 2022-06-26 04:31:19.476714
# Unit test for method init of class Settings
def test_Settings_init():
    init = settings.init(args=None)
    assert init == None

# Generated at 2022-06-26 04:31:29.155592
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()

    xdg_config_home = os.environ.get('XDG_CONFIG_HOME', '~/.config')
    user_dir = Path(xdg_config_home, 'thefuck').expanduser()
    rules_dir = user_dir.joinpath('rules')
    if not rules_dir.is_dir():
        rules_dir.mkdir(parents=True)
        settings_0.user_dir = user_dir

    settings_path = settings_0.user_dir.joinpath('settings.py')
    if not settings_path.is_file():
        with settings_path.open(mode='w') as settings_file:
            settings_file.write(const.SETTINGS_HEADER)

# Generated at 2022-06-26 04:31:40.417797
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0.user_dir == '/home/thefuck/.config/thefuck'
    assert settings_0.rules == 'DEFAULT_RULES'
    assert settings_0.exclude_rules == ''
    assert settings_0.alter_history == True
    assert settings_0.wait_command == 3
    assert settings_0.require_confirmation == True
    assert settings_0.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', 'scala', 'tsc', 'npm']
    assert settings_0.no_colors == False
    assert settings_0.debug == False
    assert settings_0.priority == {}
    assert settings_0.history_limit == None
    assert settings_0.wait_

# Generated at 2022-06-26 04:31:53.475237
# Unit test for method init of class Settings
def test_Settings_init():
    # create object settings_1 of class Settings
    settings_1 = Settings(const.DEFAULT_SETTINGS)
    user_dir = settings_1._get_user_dir_path()
    temp_dir = user_dir.parent.joinpath(user_dir.name + '_temp')
    settings_1.user_dir = temp_dir
    # invoke method init
    settings_1.init()
    # test result
    assert os.path.exists(settings_1.user_dir)
    assert os.path.exists(settings_1.user_dir.joinpath('rules'))
    assert os.path.exists(settings_1.user_dir.joinpath('settings.py'))
    temp_dir.rmdir()

# Generated at 2022-06-26 04:31:54.466910
# Unit test for method init of class Settings
def test_Settings_init():
    pass


# Generated at 2022-06-26 04:31:55.898107
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()



# Generated at 2022-06-26 04:32:04.077775
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .logs.logger import logger as log
    from . import utils

    # Testing method init of class Settings and testing log function exception

# Generated at 2022-06-26 04:32:14.186244
# Unit test for method init of class Settings

# Generated at 2022-06-26 04:32:15.315143
# Unit test for method init of class Settings
def test_Settings_init():
    settings_2 = Settings()
    settings_2.init()


# Generated at 2022-06-26 04:32:36.576401
# Unit test for method init of class Settings
def test_Settings_init():
    assert False



# Generated at 2022-06-26 04:32:37.412103
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()



# Generated at 2022-06-26 04:32:44.239193
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1.init()
    assert Path(Path('~', '.config', 'thefuck', 'settings.py')).isfile()
    assert settings_1['rules'] == ['git_push_current_branch', 'git_add_pushed_file', 'git_not_pushed_commit', 'git_not_pushed_file', 'git_remove_branch', 'git_remove_file', 'git_checkout_file', 'git_branch_doesnt_exists', 'git_nothing_to_commit', 'git_untracked_files', 'git_not_pushed']
    assert settings_1['alter_history']


# Generated at 2022-06-26 04:32:46.766578
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    var_1 = settings_1.init()
    assert var_1 == None


# Generated at 2022-06-26 04:32:47.562264
# Unit test for method init of class Settings
def test_Settings_init():
    pass

# Generated at 2022-06-26 04:32:51.281601
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1.init(args=None)


# Generated at 2022-06-26 04:32:57.687891
# Unit test for method init of class Settings
def test_Settings_init():
    print("Testing init...")
    settings_0 = Settings()
    var_0 = settings_0.init()
    assert var_0 is None, "var_0 = " + str(var_0)
    print("Finished test_Settings_init")

if __name__ == "__main__":
    print("Running unit test")
    test_Settings_init()
    print("Unit test complete")

# Generated at 2022-06-26 04:33:00.221364
# Unit test for method init of class Settings
def test_Settings_init():
    # Declarations
    settings_0 = Settings()
    var_0 = settings_0.init()


# Generated at 2022-06-26 04:33:03.828224
# Unit test for method init of class Settings
def test_Settings_init():
    # Create test objects
    settings_0 = Settings()

    # Call tested method
    settings_0.init()


# Generated at 2022-06-26 04:33:06.643096
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings = Settings()
    test_0 = type(settings) == Settings

    var_0 = True
    if not test_0:
        var_0 = False
    assert var_0


# Generated at 2022-06-26 04:33:48.293817
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()


# Generated at 2022-06-26 04:33:54.870825
# Unit test for method init of class Settings
def test_Settings_init():
    from .test import TestCase
    from .test import suppresses_logger, mocking
    from .utils import wrapped_input
    from .system import Path

    class TestSettingsInit(TestCase):
        @mocking('builtins.open')
        def test_settings_file_does_not_exist(self):
            settings = Settings()
            settings._get_user_dir_path = lambda: Path('mocked_settings_path')
            settings.init()
            open.assert_called_once_with('mocked_settings_path/settings.py', 'w')

        @suppresses_logger('thefuck.logs')  # Remove once pytest stops printing
        @mocking('thefuck.settings.Settings._settings_from_file')
        def test_settings_file_is_broken(self):
            settings = Settings()


# Generated at 2022-06-26 04:33:55.521833
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()


# Generated at 2022-06-26 04:34:04.072582
# Unit test for method init of class Settings
def test_Settings_init():
    from .system import Path
    from .logs import exception
    from . import const

    settings_0 = Settings()
    var_0 = settings_0.init()

    settings_1 = Settings()
    settings_1._get_user_dir_path()
    settings_2 = Settings()
    settings_2._setup_user_dir()
    settings_3 = Settings()
    settings_3._init_settings_file()
    settings_4 = Settings()
    settings_4._settings_from_file()
    settings_5 = Settings()
    settings_5._settings_from_env()
    settings_6 = Settings()
    settings_6._rules_from_env()
    settings_7 = Settings()
    settings_7._priority_from_env()
    settings_8 = Settings()
    settings_8._val_from

# Generated at 2022-06-26 04:34:07.283188
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init(args = None)
    assert var_0 == None


# Generated at 2022-06-26 04:34:20.845474
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    import unittest
    from .logs import LoggerTestCase
    from thefuck.settings import Settings
    from thefuck.settings import const
    from thefuck.settings import os
    from thefuck.settings import sys
    from thefuck.settings import text_type
    from thefuck.settings import warn
    from thefuck.system import Path

    class Test_init_0(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.tempsettings = Path(self.tempdir, 'settings.py')
            self.oldenv = os.environ
            self.oldcwd = os.getcwd()
            os.chdir(self.tempdir)
            sys.modules['settings'] = Settings()


# Generated at 2022-06-26 04:34:22.560346
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init(args)
    settings.init()

# Generated at 2022-06-26 04:34:26.374493
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    var_1 = settings_1.init()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 04:34:29.114597
# Unit test for method init of class Settings
def test_Settings_init():

    settings_1 = Settings()
    settings_1.init()
    assert settings == settings_1


# Generated at 2022-06-26 04:34:32.103708
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.init() == None


# Generated at 2022-06-26 04:36:29.824570
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    var_0 = Settings()
    var_1 = var_0._setup_user_dir()
    var_2 = var_0._init_settings_file()
    var_3 = var_0._get_user_dir_path()
    var_4 = var_0._settings_from_file()
    var_5 = var_0._rules_from_env()
    var_6 = var_0._priority_from_env()
    var_7 = var_0._val_from_env()
    var_8 = var_0._settings_from_env()
    var_9 = var_0._settings_from_args()


# Generated at 2022-06-26 04:36:31.008828
# Unit test for method init of class Settings
def test_Settings_init():
    #test_case_0()
    #raise Exception("test case 0 failed")
    pass

# Generated at 2022-06-26 04:36:32.072423
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

# Generated at 2022-06-26 04:36:45.047123
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    if (not (settings_0.get('user_dir').is_dir())):
        raise ValueError('user_dir')
    if not (settings_0.get('user_dir').joinpath('rules').is_dir()):
        raise ValueError('user_dir.rules')
    if (not (settings_0.get('user_dir').joinpath('settings.py').is_file())):
        raise ValueError('user_dir.settings.py')
    if (not (settings_0.get('user_dir').joinpath('settings.py').open().read().startswith(const.SETTINGS_HEADER))):
        raise ValueError('user_dir.settings.py')


# Generated at 2022-06-26 04:36:46.195586
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()


# Generated at 2022-06-26 04:36:50.302224
# Unit test for method init of class Settings
def test_Settings_init():
    # Init all mock objects
    test_case_0_settings_path = Path('mock_object')

    # Call function to test
    var_0 = test_case_0()

    # Test assert
    # assert var_0 == var_0_expected_value

# Generated at 2022-06-26 04:36:52.893078
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    assert not settings_0.init()


# Generated at 2022-06-26 04:36:55.497593
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()



# Generated at 2022-06-26 04:36:58.839700
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()


if __name__ == '__main__':
    settings_0 = Settings()
    settings_0.init()

# Generated at 2022-06-26 04:37:02.020838
# Unit test for method init of class Settings
def test_Settings_init():
    var_1 = Settings()
    var_2 = var_1.init()
    assert var_1 is settings, "Expected result is not equal"

