

# Generated at 2022-06-26 04:30:24.712561
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    # Test 1
    settings_0.init()
    assert settings_0.exclude_rules == ['man', 'ls']
    assert settings_0.excluded_search_path_prefixes == ['/usr'] #for 3.8
    #assert settings_0.rules == ['git', 'python', 'system', 'custom']
    assert settings_0.slow_commands == ['lein', 'react-native', 'gradle', './gradlew']
    assert settings_0.history_limit == None
    assert settings_0.no_colors == False
    assert settings_0.require_confirmation == True
    assert settings_0.wait_command == 0
    assert settings_0.wait_slow_command == 15
    assert settings_0.alter_history == False

# Generated at 2022-06-26 04:30:27.833261
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings(const.DEFAULT_SETTINGS)
    settings_1.init()


# Generated at 2022-06-26 04:30:38.099956
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert len(settings) == 17
    assert settings['require_confirmation'] is True
    assert settings['rules'] == tuple(const.DEFAULT_RULES)
    assert settings['exclude_rules'] == tuple()
    assert settings['alter_history'] is True
    assert settings['wait_command'] == 0
    assert settings['slow_commands'] == tuple()
    assert settings['wait_slow_command'] == 3
    assert settings['no_colors'] == False
    assert settings['debug'] == False
    assert settings['priority'] == dict()
    assert settings['history_limit'] == None
    assert settings['excluded_search_path_prefixes'] == tuple()
    assert settings['num_close_matches'] == 3
    assert settings['instant_mode'] == False
    assert settings['repeat']

# Generated at 2022-06-26 04:30:45.506661
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    settings.init()
    if not(hasattr(settings, 'user_dir')):
        raise Exception("Error")
    if not(hasattr(settings.user_dir, 'joinpath')):
        raise Exception("Error")
    if not(hasattr(settings, 'log_file')):
        raise Exception("Error")
    if not(hasattr(settings, 'use_log_file')):
        raise Exception("Error")
    if not(hasattr(settings, 'log_command')):
        raise Exception("Error")
    if not(hasattr(settings, 'log_buffer')):
        raise Exception("Error")
    if not(hasattr(settings, 'log_syslog')):
        raise Exception("Error")
    if not(hasattr(settings, 'log_root_errors')):
        raise

# Generated at 2022-06-26 04:30:48.511692
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()



# Generated at 2022-06-26 04:30:49.438003
# Unit test for method init of class Settings
def test_Settings_init():
    return None

# Generated at 2022-06-26 04:30:52.028331
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init('/home/pierre/thefuck')


# Generated at 2022-06-26 04:31:02.925828
# Unit test for method init of class Settings
def test_Settings_init():
    # do not change the original settings
    settings_0 = settings.copy()

# Generated at 2022-06-26 04:31:05.137324
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1.init()
    settings_2 = Settings()
    settings_2.init(['test'])
    settings_2.get('repeat', 2)


# Generated at 2022-06-26 04:31:17.008063
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch

    settings_1 = Settings({'key': 'value'})
    settings_2 = settings_1
    settings_1.update({'key_2': 'value_2'})
    assert settings_1 == settings_2
    assert settings_1 == {'key': 'value', 'key_2': 'value_2'}

    with patch('thefuck.settings.logs.exception') as exception:
        settings_3 = Settings()
        settings_3.update({'key': 'value_3'})
        settings_3.update({'key_2': 'value_4'})

# Generated at 2022-06-26 04:31:56.689236
# Unit test for method init of class Settings
def test_Settings_init():
    # Create testing instance
    settings = Settings()

    # Create testing path
    import tempfile
    import shutil
    test_path = tempfile.mkdtemp()

    # Create testing settings file
    settings_file = open(test_path + '/settings.py', 'w')
    settings_file.write("# Fuck off, I don't want to use 'sudo' to fix fuckups.\nsudo_command = ''")
    settings_file.close()

    # Testing instance
    import argparse
    args = argparse.Namespace()
    settings.init(args)

    # Check the result
    assert settings_file.closed
    assert settings.sudo_command == ''

    shutil.rmtree(test_path)


# Generated at 2022-06-26 04:32:04.616378
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import sys
    from thefuck.conf import settings
    settings._setup_user_dir()
    settings.init()
    settings.instant_mode
    settings.debug
    settings.require_confirmation
    settings.wait_command
    settings.slow_commands
    settings.exclude_rules
    settings.wait_slow_command
    settings.priority
    settings.history_limit
    settings.hist_file
    settings.no_colors
    settings.alter_history
    settings.num_close_matches
    settings.rules
    settings.excluded_search_path_prefixes
    settings.debug = True
    settings._settings_from_env()
    settings.init(args=None)
    settings.init(args=test_case_0())
    settings._settings_from_env()

# Generated at 2022-06-26 04:32:08.637186
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0.user_dir == '.thefuck' or settings_0.user_dir == '~/.thefuck'

# Generated at 2022-06-26 04:32:18.211300
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings({'require_confirmation': False, 'rules': 'C:python3 C:python C:ruby C:php C:perl C:nodejs C:java C:go'})
    assert settings_0 == Settings({'require_confirmation': False, 'rules': 'C:python3 C:python C:ruby C:php C:perl C:nodejs C:java C:go'})
    settings_0.init()
    assert settings_0 == Settings({'require_confirmation': False, 'rules': 'C:python3 C:python C:ruby C:php C:perl C:nodejs C:java C:go'})
    # No validations
    pass


# Generated at 2022-06-26 04:32:19.746630
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()

if __name__ == '__main__':
    import nose
    nose.main()

# Generated at 2022-06-26 04:32:31.122778
# Unit test for method init of class Settings
def test_Settings_init():
    """This function tests the method init of class Settings.
    """
    settings_0 = Settings(const.DEFAULT_SETTINGS)
    settings_0.init()
    print(settings_0)
    assert settings_0.history_limit == 50
    assert settings_0.wait_slow_command == 15
    assert settings_0.debug == False
    assert settings_0.require_confirmation == True
    assert settings_0.wait_command == 1
    assert settings_0.no_colors == False
    assert settings_0.priority == {}
    assert settings_0.rules == ['fuck_alias', 'cd_parent', 'cd_mkdir', 'emacs', 'git_push', 'hg', 'pip', 'python', 'ssh', 'sudo']
    assert settings_0.exclude_rules == []

# Generated at 2022-06-26 04:32:36.143823
# Unit test for method init of class Settings
def test_Settings_init():
	warnings.simplefilter("error", ResourceWarning) 
	settings_0 = Settings(const.DEFAULT_SETTINGS)
	settings_0.init()
	#assert settings_0.user_dir.expanduser() == user_dir_0.expanduser()

# Generated at 2022-06-26 04:32:41.236636
# Unit test for method init of class Settings
def test_Settings_init():
    # Empty settings
    settings_init_test = Settings(test_case_0)
    settings_init_test._setup_user_dir()
    settings_init_test._init_settings_file()
    settings_init_test.update(settings_init_test._settings_from_env())
    assert settings_init_test.update(settings_init_test._settings_from_args)



# Generated at 2022-06-26 04:32:51.937399
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings = Settings()
    env = os.environ
    classes = [Path, load_source]

# Generated at 2022-06-26 04:32:52.725189
# Unit test for method init of class Settings
def test_Settings_init():
    Settings.init()

# Generated at 2022-06-26 04:33:23.536870
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()


# Generated at 2022-06-26 04:33:32.791693
# Unit test for method init of class Settings
def test_Settings_init():
    import os

    # Unit test for method init of class Settings.
    # This method has no return value, but it will initialize the settings dict.
    # We test whether the dict is initialized with only one element.
    # Since the init method will call the inner method _setup_user_dir after
    # calling method _init_settings_file, we also test whether file settings.py
    # is created and whether the user_dir is set up properly.

    #create a new directory for testing
    os.mkdir(os.path.expanduser('~/.config/thefuck'))
    os.environ['XDG_CONFIG_HOME'] = os.path.expanduser('~/.config')
    #create an arguments object
    class args:
        def __init__(self):
            self.yes = False
            self.debug = False

# Generated at 2022-06-26 04:33:42.540532
# Unit test for method init of class Settings
def test_Settings_init():
    # Initialization of class Settings
    settings_1 = Settings()
    assert settings_1 is not None

    # Initialization of class Settings
    settings_2 = Settings()
    assert settings_2 is not None

    # Initialization of class Settings
    settings_3 = Settings()
    assert settings_3 is not None

    # Initialization of class Settings
    settings_4 = Settings()
    assert settings_4 is not None

    # Initialization of class Settings
    settings_5 = Settings()
    assert settings_5 is not None

    # Initialization of class Settings
    settings_6 = Settings()
    assert settings_6 is not None

    # Initialization of class Settings
    settings_7 = Settings()
    assert settings_7 is not None

    # Initialization of class Settings
    settings_8 = Settings()
    assert settings_8 is not None

# Generated at 2022-06-26 04:33:46.822942
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings
    assert settings['require_confirmation'] == True


# Generated at 2022-06-26 04:33:49.842343
# Unit test for method init of class Settings
def test_Settings_init():
    try:
        settings_0.init()
        assert True
    except Exception as e:
        assert False, "Unexpected exception occured: {}".format(e)


# Generated at 2022-06-26 04:33:52.535947
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    ref_0 = [
        None,
        None
    ]
    settings_0.init(ref_0)
    assert settings_0.__getattr__('explicit_command') == True
    

# Generated at 2022-06-26 04:33:55.251427
# Unit test for method init of class Settings
def test_Settings_init():
    print('Settings.init')
    test_case_0()



# Generated at 2022-06-26 04:34:02.209468
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings(const.DEFAULT_SETTINGS)

    assert settings_0._get_user_dir_path() == const.DEFAULT_SETTINGS['user_dir']
    assert settings_0._setup_user_dir() == const.DEFAULT_SETTINGS['user_dir']
    assert settings_0._settings_from_file() == const.DEFAULT_SETTINGS


if __name__ == '__main__':
    test_case_0()
    test_Settings_init()

# Generated at 2022-06-26 04:34:12.216115
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()

    # Check that the config folder has been created
    assert settings_0.user_dir.is_dir()

    # Check that the config file has been created
    assert settings_0.user_dir.joinpath('settings.py').is_file()

    # Check that Xdg path is used instead of old config path
    old_settings_path = Path('~', '.thefuck').expanduser()
    assert not old_settings_path.is_dir()
    assert settings_0.user_dir != old_settings_path



# Generated at 2022-06-26 04:34:14.474679
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()


# Generated at 2022-06-26 04:35:36.226323
# Unit test for method init of class Settings
def test_Settings_init():
    import unittest
    import collections
    import os
    class MyTestCase(unittest.TestCase):
        def test_init_0(self):
            settings_0 = Settings()

            settings_0['user_dir'] = 'C:\\Users\\acer\\.config\\thefuck'
            settings_0['require_confirmation'] = True
            settings_0['history_limit'] = None
            settings_0['priority'] = {}
            settings_0['no_colors'] = False
            settings_0['wait_command'] = 10
            settings_0['env'] = {}
            settings_0['rules'] = ['git_push', 'git_add', 'git_commit', 'git_amend', 'sudo', 'pip_requirements', 'brew_install']
            settings_0['exclude_rules'] = []

# Generated at 2022-06-26 04:35:40.059800
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_0 = Settings()
    settings_1.init()
    diff = settings_1.viewitems() - settings_0.viewitems()
    assert not diff

# Generated at 2022-06-26 04:35:45.139614
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings.get("rules") == const.DEFAULT_RULES


# Generated at 2022-06-26 04:35:47.223000
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()



# Generated at 2022-06-26 04:35:48.532189
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

# Generated at 2022-06-26 04:35:50.828290
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()
    print("Test successful")

# Run a test on setting init
test_Settings_init()

# Generated at 2022-06-26 04:35:57.427877
# Unit test for method init of class Settings
def test_Settings_init():
    # Test case 0
    settings_0 = Settings()
    settings_0.init()
    assert settings_0.rules == [
        'brew_test',
        'bundle_test',
        'composer_test',
        'gem_test',
        'man_test',
        'npm_test',
        'pip_test',
        'vagrant_test',
        'sudo_test',
        'git_test'
    ]
    assert settings_0.require_confirmation is True
    assert settings_0.alter_history is False
    assert settings_0.no_colors is False
    assert settings_0.repeat is False
    assert settings_0.priority == {}
    assert settings_0.exclude_rules == []


# Generated at 2022-06-26 04:36:06.359520
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0._setup_user_dir()

    user_dir_path = settings_0._get_user_dir_path()
    assert user_dir_path.exists() == True

    settings_file_path = user_dir_path.joinpath('settings.py')
    assert settings_file_path.exists() == True
    f = open(settings_file_path, 'r')
    assert f.readline() == const.SETTINGS_HEADER

    settings_0._init_settings_file()
    assert settings_file_path.exists() == True


# Generated at 2022-06-26 04:36:10.096475
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    args = None
    settings_0.init(args)
    assert settings_0._get_user_dir_path() == Path('~/.config/thefuck').expanduser()
    assert settings_0.user_dir == Path('~/.config/thefuck').expanduser()

# Generated at 2022-06-26 04:36:11.841748
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0 == {}



# Generated at 2022-06-26 04:37:45.259813
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings_0.init() == {}

# Generated at 2022-06-26 04:37:46.291757
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.init()


# Generated at 2022-06-26 04:37:59.132961
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.rules == const.DEFAULT_RULES, 'Test 1'
    assert settings.exclude_rules == [], 'Test 2'
    assert settings.priority == {}, 'Test 3'
    assert settings.require_confirmation, 'Test 4'
    assert settings.no_colors is False, 'Test 5'
    assert settings.wait_command == 1, 'Test 6'
    assert settings.history_limit == 0, 'Test 7'
    assert settings.slow_commands == [], 'Test 8'
    assert settings.wait_slow_command == 15, 'Test 9'
    assert settings.alter_history is False, 'Test 10'
    assert settings.excluded_search_path_prefixes == [], 'Test 11'
    assert settings.instant_mode is False, 'Test 12'

# Generated at 2022-06-26 04:38:08.050381
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1._settings_from_file = mock.MagicMock()
    settings_1._settings_from_env = mock.MagicMock()
    settings_1._settings_from_args = mock.MagicMock()
    settings_1.update = mock.MagicMock()
    settings_1.init()
    assert settings_1.init() == settings_1.update(settings_1._settings_from_file(),settings_1._settings_from_env(),settings_1._settings_from_args())
    print('settings_1._settings_from_file() is', settings_1._settings_from_file(), type(settings_1._settings_from_file))

# Generated at 2022-06-26 04:38:16.869351
# Unit test for method init of class Settings
def test_Settings_init():
    settings_init = Settings()
    settings_init.init(args=None)
    assert settings_init._setup_user_dir() is not None
    assert settings_init._init_settings_file() is None
    assert settings_init._get_user_dir_path() is not None
    assert settings_init._settings_from_file() is not None
    assert settings_init._rules_from_env('DEFAULT_RULES:echo:echo:echo:echo:echo:echo') == ['echo', 'echo', 'echo', 'echo', 'echo', 'echo']
    assert settings_init._priority_from_env('DEFAULT_RULES=2:echo=2').__next__() == ('DEFAULT_RULES', 2)
    assert settings_init._settings_from_env() is not None
    assert settings_init._

# Generated at 2022-06-26 04:38:29.868354
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

    user_dir = settings._get_user_dir_path()
    settings_path = user_dir.joinpath('settings.py')
    if not settings_path.is_file():
        with settings_path.open(mode='w') as settings_file:
            settings_file.write(const.SETTINGS_HEADER)
            for setting in const.DEFAULT_SETTINGS.items():
                settings_file.write(u'# {} = {}\n'.format(*setting))

    try:
        settings._settings_from_file()
    except Exception:
        settings.exception("Can't load settings from file", settings.sys.exc_info())


# Generated at 2022-06-26 04:38:35.833922
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init(args=None)
    # assert settings_0.user_dir._get_user_dir_path() is equivalent to '~/.config/thefuck'

    # assert settings_0.user_dir.joinpath('settings.py') is equivalent to '~/.config/thefuck/settings.py'


# Generated at 2022-06-26 04:38:39.176434
# Unit test for method init of class Settings
def test_Settings_init():
    # Test 0
    settings_0 = Settings(const.DEFAULT_SETTINGS)
    settings_0.init()



# Generated at 2022-06-26 04:38:42.000835
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    # No arguments are provided. Test will not pass
    try:
        settings_0.init()
    except TypeError:
        pass
    settings_1 = Settings()
    settings_1.init()


# Generated at 2022-06-26 04:38:43.999448
# Unit test for method init of class Settings
def test_Settings_init():
    settings_init = Settings()
    settings_init.init()
