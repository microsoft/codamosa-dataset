

# Generated at 2022-06-26 04:30:19.490893
# Unit test for method init of class Settings
def test_Settings_init():
    # Set up
    settings_init = Settings()
    settings_init.init()
    # AssertEqual
    assert settings_init.user_dir == const.DEFAULT_SETTINGS['user_dir']

# Generated at 2022-06-26 04:30:29.096222
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0['user_dir'] = const.DEFAULT_SETTINGS['user_dir']
    settings_0['rules'] = const.DEFAULT_SETTINGS['rules']
    settings_0['exclude_rules'] = const.DEFAULT_SETTINGS['exclude_rules']
    settings_0['priority'] = const.DEFAULT_SETTINGS['priority']
    settings_0['wait_command'] = const.DEFAULT_SETTINGS['wait_command']
    settings_0['no_colors'] = const.DEFAULT_SETTINGS['no_colors']
    settings_0['require_confirmation'] = const.DEFAULT_SETTINGS['require_confirmation']
    settings_0['history_limit'] = const.DEFAULT_SETTINGS['history_limit']
   

# Generated at 2022-06-26 04:30:31.451472
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0["history_limit"] == 10

# Generated at 2022-06-26 04:30:37.145766
# Unit test for method init of class Settings
def test_Settings_init():
    print("Begin test_Settings_init")
    settings_0 = Settings()
    settings_0.init()
    print("End test_Settings_init")


test_case_0()
test_Settings_init()
print(settings)
# settings.init()
# print(settings)
# print(settings.user_dir)

# Generated at 2022-06-26 04:30:44.471438
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1.init()
    test0 = (settings_1.get("ALIAS") == settings["ALIAS"])
    test1 = (settings_1.get("DEBUG") == settings["DEBUG"])
    test2 = (settings_1.get("WAIT_COMMAND") == settings["WAIT_COMMAND"])
    test3 = (settings_1.get("WAIT_SLOW_COMMAND") == settings["WAIT_SLOW_COMMAND"])
    test4 = (settings_1.get("REQUIRE_CONFIRMATION") == settings["REQUIRE_CONFIRMATION"])
    test5 = (settings_1.get("REPEAT") == settings["REPEAT"])

# Generated at 2022-06-26 04:30:49.813873
# Unit test for method init of class Settings
def test_Settings_init():
    import thefuck.settings
    settings_0 = Settings()
    thefuck.settings.settings = settings_0
    settings_0.init()
    pass


if __name__ == '__main__':
    test_case_0()
    test_Settings_init()

# Generated at 2022-06-26 04:31:00.959827
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

    assert(settings['rules'] == test_case_0_result['rules'])
    assert(settings['priority'] == test_case_0_result['priority'])
    assert(settings['exclude_rules'] == test_case_0_result['exclude_rules'])
    assert(settings['no_colors'] == test_case_0_result['no_colors'])
    assert(settings['require_confirmation'] == test_case_0_result['require_confirmation'])
    assert(settings['wait_command'] == test_case_0_result['wait_command'])
    assert(settings['slow_commands'] == test_case_0_result['slow_commands'])
    assert(settings['history_limit'] == test_case_0_result['history_limit'])
   

# Generated at 2022-06-26 04:31:03.978886
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    assert settings_0.require_confirmation == True
    settings_0.init()
    assert settings_0.require_confirmation == True

# Generated at 2022-06-26 04:31:16.239590
# Unit test for method init of class Settings
def test_Settings_init():
    with mock.patch.object(Settings, "_init_settings_file") as mocked_method:
        with mock.patch.object(Settings, "_setup_user_dir") as mocked_method2:
            with mock.patch.object(Settings, "_settings_from_file") as mocked_method3:
                with mock.patch.object(Settings, "_settings_from_env") as mocked_method4:
                    with mock.patch.object(Settings, "_settings_from_args") as mocked_method5:
                        test_case_0()
                        mocked_method.assert_called()
                        mocked_method2.assert_called()
                        mocked_method3.assert_called()
                        mocked_method4.assert_called()
                        mocked_method5.assert_called()

##

# Generated at 2022-06-26 04:31:28.236133
# Unit test for method init of class Settings
def test_Settings_init():
    settings_obj = Settings()
    settings_obj.init()
    user_dir_path = os.path.join(os.path.expanduser('~'), '.config', 'thefuck')
    assert settings_obj.user_dir == user_dir_path
    assert settings_obj['enable_doa'] == True
    assert settings_obj['wait_command'] == 2
    assert settings_obj['require_confirmation'] == True
    assert settings_obj['history_limit'] == None
    assert settings_obj['rules'] == ['fuck', 'faster_fuck']
    assert settings_obj['exclude_rules'] == []
    assert settings_obj['priority'] == {}
    assert settings_obj['no_colors'] == False
    assert settings_obj['debug'] == False
    assert settings_obj['alter_history'] == True


# Generated at 2022-06-26 04:32:31.770769
# Unit test for method init of class Settings
def test_Settings_init():
    # unit test for empty setting file
    settings_0 = Settings()
    settings_0.init()
    assert settings_0 == const.DEFAULT_SETTINGS
    settings_0.user_dir.joinpath('settings.py').unlink()
    settings_0.user_dir.rmdir()

    # unit test for not empty setting file
    settings_1 = Settings()
    settings_1.init()
    settings_1.user_dir.joinpath('settings.py').write_text(
        "# -*- coding: UTF-8 -*-\n#comment 1\n# comment 2\nlog_file = '/home/user/log.py'\n")
    settings_1.init()
    assert settings_1 == const.DEFAULT_SETTINGS

# Generated at 2022-06-26 04:32:39.139913
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings({'dir': '../rules'})
    settings_1.init()
    assert const.SETTINGS_HEADER in settings_1['dir'].read_text()
    assert settings_1['rules'] == ['git_push', 'man', 'sudo']
    # assert settings_1['num_close_matches'] == 25
    # assert settings_1['require_confirmation'] == True



# Generated at 2022-06-26 04:32:41.400280
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    try:
        settings_0.init()
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-26 04:32:43.063161
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init(None)


# Generated at 2022-06-26 04:32:52.737814
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    import os
    from .system import Path
    from . import const

    # __init__
    # Define a Settings object
    settings_1 = Settings()
    settings_1.init()

    # Setup User dir
    # Check if the user dir is a directory
    assert Path("/home/travis/.config/thefuck").is_dir()
    # Check if the user dir is a directory
    assert Path("/home/travis/.config/thefuck/settings.py").is_file()

    # Load Settings from file
    settings_1._init_settings_file()
    settings_1.update(settings_1._settings_from_file())

    # Load Settings from env
    settings_1.update(settings_1._settings_from_env())

    # Load Settings from args
    settings_

# Generated at 2022-06-26 04:32:57.059792
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    x_1 = settings_0.__getattr__('rules')
    assert x_1 == ['fuck_alias', 'history', 'everything'], 'Assertion Failed'


# Generated at 2022-06-26 04:33:08.024707
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1.init()
    assert 'require_confirmation' in settings_1
    assert settings_1.get('require_confirmation')
    assert 'history_limit' in settings_1
    assert settings_1.get('history_limit') == 10
    assert 'wait_slow_command' in settings_1
    assert settings_1.get('wait_slow_command') == 15
    assert 'no_colors' in settings_1
    assert not settings_1.get('no_colors')
    assert 'alter_history' in settings_1
    assert settings_1.get('alter_history')
    assert 'exclude_rules' in settings_1
    assert not settings_1.get('exclude_rules')
    assert 'rules' in settings_1

# Generated at 2022-06-26 04:33:09.724332
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1.init()



# Generated at 2022-06-26 04:33:10.722977
# Unit test for method init of class Settings
def test_Settings_init():
    assert not settings_0


# Generated at 2022-06-26 04:33:20.519770
# Unit test for method init of class Settings
def test_Settings_init():

    # test case 1:
    settings_1 = Settings()
    settings_1._setup_user_dir()
    settings_1.user_dir.joinpath = Path = f_Path
    settings_1.joinpath = Path = f_Path

    settings_1.is_dir = True
    settings_1.is_file = True
    settings_1.init()
    settings_1.update = dict.update
    assert settings_1._get_user_dir_path() == Path()

    # test case 2:
    settings_2 = Settings()
    settings_2._setup_user_dir()
    settings_2.user_dir.joinpath = Path = f_Path
    settings_2.joinpath = Path = f_Path

    settings_2.is_dir = True
    settings_2.is_file = False


# Generated at 2022-06-26 04:34:18.538248
# Unit test for method init of class Settings
def test_Settings_init():
    try:
        settings.init()
    except:
        fail("settings.init() raised Exception")


# Generated at 2022-06-26 04:34:23.787250
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    global const
    settings = Settings(const.DEFAULT_SETTINGS)
    global Path
    Path = Path

    global os
    os = os

    global sys
    sys = sys

    global warn
    warn = warn

    global text_type
    text_type = text_type

    global load_source
    load_source = load_source

    global warn
    warn = warn

    print("Testing init of class Settings")
    try:
        test_case_0()
        print("tests pass")
    except:
        print("test fail")

# Generated at 2022-06-26 04:34:25.895967
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()


# Generated at 2022-06-26 04:34:29.707966
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    print("Checking: init of Settings")
    print("Expected: %s" % ('',))
    print("Received: %s" % (settings_1.init(),))

# Generated at 2022-06-26 04:34:32.608895
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    assert settings == settings_0


# Generated at 2022-06-26 04:34:34.242180
# Unit test for method init of class Settings
def test_Settings_init():
    # Initialize settings.
    settings.init()

    print('settings done')

if __name__ == "__main__":
    test_case_0()
    test_Settings_init()

# Generated at 2022-06-26 04:34:37.680824
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings(const.DEFAULT_SETTINGS)
    var_1 = settings_1.init()



# Generated at 2022-06-26 04:34:43.585460
# Unit test for method init of class Settings
def test_Settings_init():
    # Given: settings
    settings = Settings(const.DEFAULT_SETTINGS)

# Generated at 2022-06-26 04:34:45.470280
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()



# Generated at 2022-06-26 04:34:47.175472
# Unit test for method init of class Settings
def test_Settings_init():
    print('Testing class Settings, method init')
    test_case_0()


# Generated at 2022-06-26 04:37:19.027716
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()
    print(settings_0.get("require_confirmation"))


# Generated at 2022-06-26 04:37:20.310772
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()

# Generated at 2022-06-26 04:37:22.993180
# Unit test for method init of class Settings
def test_Settings_init():
    # assert_type_match(settings.init())
    settings_0 = Settings()
    var_0 = settings_0.init()
    # assert_equal(settings.init(), var_0)



# Generated at 2022-06-26 04:37:30.161520
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import log
    from .utils import wrap

    def test():
        # Check if settings.py is created
        settings_path = settings._get_user_dir_path().joinpath('settings.py')
        assert(settings_path.is_file())
        with open(settings_path) as settings_file:
            assert(settings_file.read() == const.SETTINGS_HEADER)

        # Check if log has been called
        assert(log.warning.call_count == 1)
        assert(wrap.called)

    # Mock _get_user_dir_path
    wrapper = mock.patch('thefuck.settings._get_user_dir_path', lambda: '/tmp')
    # Mock log
    wrapper.start()
    log = mock.MagicMock()
    wrapper.stop()
    # Mock Path

# Generated at 2022-06-26 04:37:31.931322
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    var_0 = settings_1.init()
    

# Testing for Class Settings

# Generated at 2022-06-26 04:37:36.354367
# Unit test for method init of class Settings
def test_Settings_init():
    global settings # So that we can modify it inside the test case
    settings_0 = Settings()
    settings_1 = settings_0.init()
    settings_2 = settings_0.init()

    assert settings_2 == settings_1 == settings_0, "The method init of class Settings failed"

test_case_0()

# Generated at 2022-06-26 04:37:39.149000
# Unit test for method init of class Settings
def test_Settings_init():
    var_0 = Settings()
    try:
        var_0.init()
    except Exception:
        assert False

# Generated at 2022-06-26 04:37:41.745275
# Unit test for method init of class Settings
def test_Settings_init():
    var_0 = Settings.init()


# Generated at 2022-06-26 04:37:44.764069
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()


# Generated at 2022-06-26 04:37:52.052037
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    # xfail: reason
    user_dir_path_0 = settings_0._get_user_dir_path()
    # assert user_dir_path_0._path == os.path.expanduser(os.environ.get('XDG_CONFIG_HOME', '~/.config/')) + 'thefuck'
    assert user_dir_path_0._path == os.path.expanduser('~/.config/thefuck')

    user_dir_0 = user_dir_path_0.joinpath('settings.py')
    # xfail: reason
    # assert user_dir_0._path == os.path.expanduser(os.environ.get('XDG_CONFIG_HOME', '~/.config/')) + 'thefuck