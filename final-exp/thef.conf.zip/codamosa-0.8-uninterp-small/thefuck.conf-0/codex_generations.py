

# Generated at 2022-06-26 04:30:22.905542
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import init as logs_init

    args = argparse.Namespace(yes=True)

    for env in const.ENV_TO_ATTR.keys():
        if env in os.environ:
            del os.environ[env]

    logs_init()

    settings_0 = Settings()
    settings_0.init(args=args)

    for key in const.DEFAULT_SETTINGS.keys():
        assert getattr(settings_0, key) == const.DEFAULT_SETTINGS[key]


# Generated at 2022-06-26 04:30:27.457205
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings['rules'] == const.DEFAULT_RULES
    settings.init()
    assert settings['rules'] == const.DEFAULT_RULES


# Generated at 2022-06-26 04:30:29.442224
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()


# Generated at 2022-06-26 04:30:40.821266
# Unit test for method init of class Settings
def test_Settings_init():
    """
    Unit test for method init of class Settings
    """
    settings_1 = Settings()
    settings_1.init()
    # Test case 1: checks if the default settings are loaded
    assert settings_1["require_confirmation"] == True
    assert settings_1["alter_history"] == True
    assert settings_1["wait_command"] == 3
    assert settings_1["history_limit"] == None
    assert settings_1["require_confirmation"] == True
    assert settings_1["repeat"] == False
    assert settings_1["instant_mode"] == False
    assert settings_1["rules"] == []
    assert settings_1["exclude_rules"] == []
    assert settings_1["priority"] == {}
    assert settings_1["no_colors"] == False
    assert settings_1["debug"] == False


# Generated at 2022-06-26 04:30:42.177486
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    settings.init()
    assert settings.user_dir == settings._get_user_dir_path()
    

# Generated at 2022-06-26 04:30:45.159423
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()

# Generated at 2022-06-26 04:30:48.049917
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    assert settings_1.init()


# Generated at 2022-06-26 04:30:49.507996
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()


# Generated at 2022-06-26 04:30:50.521041
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings() 
    settings_0.init()



# Generated at 2022-06-26 04:30:56.997964
# Unit test for method init of class Settings
def test_Settings_init():
    # Arrange
    settings_0 = Settings()
    settings_0._init_settings_file = MagicMock()
    settings_0.user_dir = Path('~', '.thefuck').expanduser()
    settings_0._settings_from_file = MagicMock(return_value={})
    settings_0._settings_from_env = MagicMock(return_value={})
    settings_0._settings_from_args = MagicMock(return_value={})
    args = None

    # Act
    settings_0.init(args)

    # Assert
    assert(settings_0 == {})



# Generated at 2022-06-26 04:31:29.476746
# Unit test for method init of class Settings

# Generated at 2022-06-26 04:31:31.591594
# Unit test for method init of class Settings
def test_Settings_init():
    # Test Case 0
    assert settings.init() != None

# Generated at 2022-06-26 04:31:34.994746
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0.user_dir == Path('~/.config/thefuck').expanduser()


# Generated at 2022-06-26 04:31:37.399530
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    test_1_result = settings_0
    assert test_1_result == settings



# Generated at 2022-06-26 04:31:39.257686
# Unit test for method init of class Settings
def test_Settings_init():
    function_name = 'init'
    method = getattr(settings_0, function_name, lambda: "nothing")
    method()


# Generated at 2022-06-26 04:31:45.986210
# Unit test for method init of class Settings
def test_Settings_init():
    # test init of default settings
    assert settings['alias'] == 'fuck'
    assert settings['require_confirmation'] is True
    assert settings['wait_command'] == 10
    assert settings['wait_slow_command'] == 3
    assert settings['alter_history'] is False
    assert settings['no_colors'] is False
    assert settings['slow_commands'] == ['sudo']
    assert settings['exclude_rules'] == ['sudo']
    assert settings['excluded_search_path_prefixes'] == ['/dev', '/sys']
    assert settings['priority'] == {}
    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['num_close_matches'] == 3
    assert settings['history_limit'] == 0
    assert settings['instant_mode'] is False

    # test init of settings in settings

# Generated at 2022-06-26 04:31:50.235922
# Unit test for method init of class Settings
def test_Settings_init():
    os.environ['THEFUCK_HISTORY_LIMIT'] = '42'
    settings_0 = Settings()
    settings_0.init()
    assert settings_0['history_limit'] == 42
    del os.environ['THEFUCK_HISTORY_LIMIT']


# Generated at 2022-06-26 04:31:51.807048
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()


# Generated at 2022-06-26 04:31:56.462587
# Unit test for method init of class Settings
def test_Settings_init():
    # Test Case 0
    settings_0 = Settings()
    settings_0.init(args = None)
    assert settings_0

    # Test Case 1
    settings_1 = Settings()
    settings_1.init(args = 1)
    assert settings_1


# Generated at 2022-06-26 04:31:59.405368
# Unit test for method init of class Settings
def test_Settings_init():
    # unit test for method init of class Settings
    settings_1 = Settings({})
    settings_1.init()
    assert settings_1.get('alias') == 'fuck'


# Generated at 2022-06-26 04:32:25.419765
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings(key)
    var_1 = settings_1.init(args)

test_case_0()
test_Settings_init()

# Generated at 2022-06-26 04:32:29.381793
# Unit test for method init of class Settings
def test_Settings_init():
    test_cases = [
        (0,0,0)
    ]
    test_results = []
    for test_case_nr, result in test_cases:
        test_result = test_case_0()
        test_results.append(test_result)
    check(test_results,test_cases)

# Generated at 2022-06-26 04:32:30.430098
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()


# Generated at 2022-06-26 04:32:42.012708
# Unit test for method init of class Settings
def test_Settings_init():
    import inspect
    import sys
    import os
    import pdb

    # Initializing of settings

    var_0 = ''

    # Settings from file and env

    var_0 = ''

    # Initializing of settings

    var_0 = ''

    # Settings from file
    import settings as lu
    lu.settings.DICT = lu.const.DEFAULT_SETTINGS
    var_0 = lu.settings
    try:

        # Settings from env
        assert ('10' == (lambda: var_0.DICT.update(lu.settings._settings_from_env()))())
    except AssertionError:
        pdb.set_trace()
        print(inspect.stack()[0][3])

# Generated at 2022-06-26 04:32:43.958984
# Unit test for method init of class Settings
def test_Settings_init():
    # Test case 0
    settings_0 = Settings()
    var_0 = settings_0.init()

# Generated at 2022-06-26 04:32:46.212335
# Unit test for method init of class Settings
def test_Settings_init():
    var_0 = test_case_0()


# Generated at 2022-06-26 04:32:47.629854
# Unit test for method init of class Settings
def test_Settings_init():
    assert True == True


# Generated at 2022-06-26 04:32:50.719972
# Unit test for method init of class Settings
def test_Settings_init():
    assert test_case_0() == None

test_Settings_init()

# Generated at 2022-06-26 04:32:52.125525
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()


# Generated at 2022-06-26 04:32:52.903363
# Unit test for method init of class Settings
def test_Settings_init():
    assert True



# Generated at 2022-06-26 04:33:20.333221
# Unit test for method init of class Settings
def test_Settings_init():
    # Test cases
    test_case_0()



# Generated at 2022-06-26 04:33:31.741361
# Unit test for method init of class Settings
def test_Settings_init():
    # Assign
    var_0 = 'SETTINGS_HEADER'
    settings_0 = Settings()
    settings_0.init()
    var_1 = 'thefuck.settings'
    var_2 = var_1.rsplit('.', 1)[0]
    var_3 = var_1.rsplit('.', 1)[1]
    settings_0.init()
    settings_0.init()
    settings_0.init()
    settings_0.init()
    var_4 = 'thefuck.settings'
    var_5 = settings_0._val_from_env('TF_NO_COLORS', 'no_colors')
    var_6 = '~'
    settings_0.init()
    settings_0.init()
    settings_0.init()
    settings_0.init

# Generated at 2022-06-26 04:33:35.726576
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    try:
        settings_0.init()
        assert False
    except KeyError:
        assert True
    except Exception:
        assert False


# Generated at 2022-06-26 04:33:38.826431
# Unit test for method init of class Settings
def test_Settings_init():
    # Case 0
    # Input
    temp_settings = Settings()
    temp_settings.init()

    # Output
    assert True


# Generated at 2022-06-26 04:33:52.072975
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    # Way 1 of getting a Path object
    var_0 = Path('.')
    # Way 2 of getting a Path object
    var_1 = Path(['.'])
    # Way 3 of getting a Path object
    var_2 = Path(Path('.'))
    # Way 4 of getting a Path object
    var_3 = Path(os.path.join('.'))
    var_3.exists()
    var_3.is_dir()
    # Way 5 of getting a Path object
    var_4 = Path(var_0)
    var_4.exists()
    var_4.is_dir()
    # Way 6 of getting a Path object
    var_5 = Path('.', '..')
    # Way 7 of getting a Path object

# Generated at 2022-06-26 04:33:57.600857
# Unit test for method init of class Settings
def test_Settings_init():
    from test_thefuck.utils import test_dir

    settings_1 = Settings()
    settings_1.user_dir = test_dir
    var_1 = settings_1.init()


# Generated at 2022-06-26 04:34:00.622521
# Unit test for method init of class Settings
def test_Settings_init():
    import inspect
    import datetime as dt
    global settings_0
    try:
        test_case_0()
    except:
        print('Test case 0 failed')



# Generated at 2022-06-26 04:34:02.895571
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.init() is None


# Generated at 2022-06-26 04:34:06.758200
# Unit test for method init of class Settings
def test_Settings_init():
    # Test for method init of class Settings
    # This method test whether the initialize method of class Settings
    # works properly
    assert test_case_0() == None


# Generated at 2022-06-26 04:34:09.992144
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()


# Generated at 2022-06-26 04:34:51.530983
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()
    assert var_0 == None


# Generated at 2022-06-26 04:34:57.058265
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .settings import const
    from .settings import settings
    from .system import Path
    from .settings import test_case_0

    settings_0 = settings
    var_0 = settings_0.init()



# Generated at 2022-06-26 04:35:01.597160
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings(const.DEFAULT_SETTINGS)
    assert settings_1


# Generated at 2022-06-26 04:35:08.190744
# Unit test for method init of class Settings
def test_Settings_init():
    def test_init_0():
        """Constructor test: default value"""
        settings_0 = Settings()
        var_0 = settings_0.init()
        assert settings_0.user_dir.basename() == '.config/thefuck', "settings.init() does not work"

    test_init_0()


# Generated at 2022-06-26 04:35:10.082426
# Unit test for method init of class Settings
def test_Settings_init():
    # Test case 0
    try:
        test_case_0()
    except:
        print("Exception in test case 0")

if __name__ == '__main__':
    main()

# Generated at 2022-06-26 04:35:11.762240
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

# Generated at 2022-06-26 04:35:13.723788
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()

# Generated at 2022-06-26 04:35:15.640340
# Unit test for method init of class Settings

# Generated at 2022-06-26 04:35:21.367881
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    var_0 = settings_0.init()
    def test_case_1():
        class Dummy_Class_0(object):
            def __init__(self):
                pass
            @staticmethod
            def joinpath(path):
                """docstring for joinpath"""
                return path

        settings_0 = Settings()
        settings_0.init()
        var_0 = settings_0.init()
    @staticmethod
    def test_case_2():
        settings_0 = Settings()
        settings_0.init()
        var_0 = settings_0.init()
    @staticmethod
    def test_case_3():
        settings_1 = Settings(const.DEFAULT_SETTINGS)

# Generated at 2022-06-26 04:35:25.035593
# Unit test for method init of class Settings
def test_Settings_init():
    var_0 = Settings()
    assert var_0.init()
    var_1 = Settings()
    assert not var_1.init()

# Generated at 2022-06-26 04:36:01.340984
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    settings_0.init()
    settings_0.init()

# Generated at 2022-06-26 04:36:07.135365
# Unit test for method init of class Settings
def test_Settings_init():
    if os.environ.has_key("THEFUCK_SETTINGS_PYTHON"):
        del os.environ["THEFUCK_SETTINGS_PYTHON"]
    settings_0 = Settings()
    settings_0.init()
    settings_1 = Settings()
    settings_1.init()
    assert settings_1.get("debug")== settings_0.get("debug")

# Generated at 2022-06-26 04:36:08.680881
# Unit test for method init of class Settings
def test_Settings_init():
    # var_0 = Settings()
    # assert var_0.init() == None

    assert True


# Generated at 2022-06-26 04:36:20.327970
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings._setup_user_dir.__dict__.__setitem__('stypy_call_defaults', defaults)
    settings._setup_user_dir.__dict__.__setitem__('stypy_call_varargs', varargs)
    settings._setup_user_dir.__dict__.__setitem__('stypy_call_kwargs', kwargs)
    settings._setup_user_dir.__dict__.__setitem__('stypy_declared_arg_number', 1)
    arguments = process_argument_values(localization, type_of_self, module_type_store, 'Settings._setup_user_dir', [], None, None, defaults, varargs, kwargs)

    if is_error_type(arguments):
        # Destroy the current context
        module

# Generated at 2022-06-26 04:36:21.565475
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

# Generated at 2022-06-26 04:36:29.024002
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.user_dir = settings_0._get_user_dir_path()
    settings_0._init_settings_file()
    settings_1 = settings_0._settings_from_file()
    settings_1 = settings_0._settings_from_env()
    settings_1 = settings_0._settings_from_args()
    settings_0.init()

# main
if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 04:36:34.805851
# Unit test for method init of class Settings

# Generated at 2022-06-26 04:36:36.944703
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()


# Generated at 2022-06-26 04:36:41.883445
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0['history_limit'] == 10
    assert settings_0['require_confirmation'] == True


# Generated at 2022-06-26 04:36:43.737392
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()


# Generated at 2022-06-26 04:38:04.351790
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    var_1 = settings_1.init()



# Generated at 2022-06-26 04:38:12.482178
# Unit test for method init of class Settings
def test_Settings_init():
    warnings = ['Config path %s is deprecated. Please move to %s' % (os.path.expanduser('~/.thefuck'), os.path.expanduser('~/.config/thefuck')), 'Can\'t load settings from file', 'Can\'t load settings from env']
    res = 0
    try:
        test_case_0()
    except:
        pass
    else:
        if warnings:
            warnings.reverse()
            warnings.append('--- FAILED: test_Settings_init')
            warnings.reverse()
            res = 1
        else:
            print('+++ OK: test_Settings_init')
    return res

if __name__ == "__main__":
    res = test_Settings_init()
    if res: sys.exit(res)

# Generated at 2022-06-26 04:38:18.814757
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    var_1 = settings_1.init()
    if var_1 == True:
        print("Pass")
    else:
        print("False")


# Generated at 2022-06-26 04:38:22.707620
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()


# Generated at 2022-06-26 04:38:24.075132
# Unit test for method init of class Settings
def test_Settings_init():
    # Case1:
    test_case_0()

# Generated at 2022-06-26 04:38:31.356934
# Unit test for method init of class Settings
def test_Settings_init():
    # Create class instance for method init
    settings_1 = Settings()
    var_1 = settings_1.init()
    # Check instance attribute user_dir
    var_1 = settings_1.user_dir
    # Check class attribute DEFAULT_SETTINGS
    var_2 = Settings.DEFAULT_SETTINGS
    # Check instance attribute user_dir
    var_3 = settings_1.user_dir
    # Check class attribute DEFAULT_SETTINGS
    var_4 = Settings.DEFAULT_SETTINGS



# Generated at 2022-06-26 04:38:36.586054
# Unit test for method init of class Settings
def test_Settings_init():
    settings0 = Settings()
    settings0.init()


# Generated at 2022-06-26 04:38:39.347713
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert_equal(True, True)

# Generated at 2022-06-26 04:38:40.615982
# Unit test for method init of class Settings
def test_Settings_init():
    # var_0 = Settings()
    # var_0.init()
    pass

# Generated at 2022-06-26 04:38:50.632936
# Unit test for method init of class Settings
def test_Settings_init():
  from .logs import exception
  from . import const
  from . import settings
  from .api import settings_from_env, rules_from_env, settings_from_args, priority_from_env
  from .system import Path
  from .logs import debug, exception
  settings_1 = settings()
  settings_1._settings_from_file = settings_from_file
  settings_1._setup_user_dir = setup_user_dir
  settings_1._settings_from_env = settings_from_env
  settings_2 = settings()
  settings_2._settings_from_file = settings_from_file
  settings_2._setup_user_dir = setup_user_dir
  settings_2._settings_from_env = settings_from_env
  settings_2._settings_from_args = settings_from_