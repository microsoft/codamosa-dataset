

# Generated at 2022-06-26 04:30:29.186087
# Unit test for method init of class Settings
def test_Settings_init():
    import StringIO
    import sys
    import os
    import tempfile

    # Call function init
    # Prepare parameters
    # module settings, line number 1
    # module settings, line number 2
    # module settings, line number 3
    # module settings, line number 4
    # module settings, line number 5
    # module settings, line number 6
    # module settings, line number 7
    # module settings, line number 8
    # module settings, line number 9
    # module settings, line number 10
    # module settings, line number 11
    # module settings, line number 12
    # module settings, line number 13
    # module settings, line number 14
    # module settings, line number 15
    # module settings, line number 16
    # module settings, line number 17
    # module settings, line number 18
    # module settings, line number 19

# Generated at 2022-06-26 04:30:31.221432
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()

# Unit 

# Generated at 2022-06-26 04:30:34.982662
# Unit test for method init of class Settings
def test_Settings_init():
    # Preparation
    test_Settings_init.settings = Settings()

    # Execution
    test_Settings_init.settings.init()

    # Verification
    assert len(test_Settings_init.settings) != 0


# Generated at 2022-06-26 04:30:36.915185
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()



# Generated at 2022-06-26 04:30:45.143853
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import init
    settings_1 = Settings()
    # creating user config directory
    user_dir = settings_1._get_user_dir_path()
    user_dir.mkdir(parents=True)
    settings_1.init()

    # checking created files and dirs
    path = user_dir.joinpath('settings.py')
    assert (settings_1.user_dir.joinpath('settings.py')).is_file
    assert open(path, 'r').read() == const.SETTINGS_HEADER
    rules_dir = settings_1.user_dir.joinpath('rules')
    assert rules_dir.is_dir

    # checking created logs
    assert open(user_dir.joinpath('logs', 'application.log'), 'r').read() == ''


# Generated at 2022-06-26 04:30:56.438848
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()

    settings.init() # initializes settings with default values

    if settings.get('debug') != False:
        raise Exception("Initialization fails because debug is not set")
    elif settings.get('require_confirmation') != True:
        raise Exception("Initialization fails because require_confirmation is not set")
    elif settings.get('history_limit') != None:
        raise Exception("Initialization fails because history_limit is not set")
    elif settings.get('rules') != []:
        raise Exception("Initialization fails because rules is not set")
    elif settings.get('wait_command') != 3:
        raise Exception("Initialization fails because wait_command is not set")

# Generated at 2022-06-26 04:30:59.152313
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1.init()



# Generated at 2022-06-26 04:31:07.236123
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()

# Generated at 2022-06-26 04:31:09.053427
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

# Generated at 2022-06-26 04:31:18.197454
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1.init()
    assert settings_1._settings_from_file() == load_source('settings', text_type(Path('~/.config/thefuck/settings.py').expanduser())).__dict__
    assert settings_1._get_user_dir_path() == Path('~/.config/thefuck').expanduser()
    assert settings_1._settings_from_env() == {'rules': [u'echo', u'fuck', u'man'], 'alter_history': True, 'no_colors': False, 'debug': False}
    assert settings_1._rules_from_env('DEFAULT_RULES:echo:fuck:man') == ['echo', 'fuck', 'man']

# Generated at 2022-06-26 04:31:58.785404
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()
    assert var_0 == None


# Generated at 2022-06-26 04:31:59.637208
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.init() == None


# Generated at 2022-06-26 04:32:06.234963
# Unit test for method init of class Settings
def test_Settings_init():
    from imp import load_source
    from .system import Path
    from .const import SETTINGS_HEADER, DEFAULT_SETTINGS
    from .logs import exception
    from .const import ENV_TO_ATTR, DEFAULT_RULES
    from .utils import get_closest
    import os
    import sys

    settings_0 = Settings()
    # Method init does the following:

    #   Fills `settings` with values from `settings.py` and env.
    #   `settings.py` needs to be a valid Python file with
    #   attribute assignments.
    #
    #   Does not override values from env by default, which can be
    #   set by settings.conf or settings.py
    var_0 = settings_0.init()
    user_dir = self._get_user_dir_

# Generated at 2022-06-26 04:32:07.497358
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    global var_0
    settings_0 = Settings()
    var_0 = settings_0.init()


# Generated at 2022-06-26 04:32:09.752342
# Unit test for method init of class Settings
def test_Settings_init():
    cwd = os.getcwd()
    os.chdir("/home/user1/.config/thefuck/")
    test_case_0()
    os.chdir(cwd)


# Generated at 2022-06-26 04:32:12.009458
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()


# Generated at 2022-06-26 04:32:14.383798
# Unit test for method init of class Settings
def test_Settings_init():
    var_0 = Settings()
    var_1 = var_0.init()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 04:32:15.537842
# Unit test for method init of class Settings
def test_Settings_init():
    print('testing method init of class Settings')
    test_case_0()


# Generated at 2022-06-26 04:32:16.724390
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()


# Generated at 2022-06-26 04:32:18.437638
# Unit test for method init of class Settings
def test_Settings_init():
    # Test case 0
    test_case_0()

# Generated at 2022-06-26 04:33:28.555809
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()



# Generated at 2022-06-26 04:33:31.371081
# Unit test for method init of class Settings
def test_Settings_init():
    settings_var = Settings()
    settings_var.init()


# Generated at 2022-06-26 04:33:34.728852
# Unit test for method init of class Settings
def test_Settings_init():
    # 1. init
    f0 = Settings()
    assert f0.init() == None, "init failed"



# Generated at 2022-06-26 04:33:41.679694
# Unit test for method init of class Settings
def test_Settings_init():
    import inspect, copy

    settings_1 = Settings(const.DEFAULT_SETTINGS)
    args_1 = None
    var_1 = settings_1.init(args_1)
    assert settings_1.log_file == Path(settings_1.user_dir, 'thefuck.log')
    assert settings_1['repeat'] == True
    assert settings_1.exclude_rules == ['session_socket']
    assert settings_1.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']


# Generated at 2022-06-26 04:33:44.289215
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()


# Generated at 2022-06-26 04:33:47.664760
# Unit test for method init of class Settings
def test_Settings_init():
    settings_test_init = Settings()
    settings_test_init.init()


# Generated at 2022-06-26 04:33:50.844590
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()

    # Unit test for method init of class Settings
    def test_Settings_init():
        settings_0 = Settings()
        var_0 = settings_0.init()



# Generated at 2022-06-26 04:33:56.292556
# Unit test for method init of class Settings
def test_Settings_init():
    _settings_addition_dict = {}
    _settings_addition_dict['user_dir'] = _user_dir_path()
    assert Settings.init(_settings_addition_dict) == None


# Generated at 2022-06-26 04:34:01.118144
# Unit test for method init of class Settings
def test_Settings_init():
    # Create a settings instance
    settings = Settings()
    # Init settings with settings from file
    settings_0 = settings.init()
    # Check if settings file is created, as it does not exist
    assert os.path.isfile( settings.user_dir.joinpath('settings.py'))



# Generated at 2022-06-26 04:34:06.282780
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

settings_0 = Settings()
var_0 = settings_0.init()
# Checking if the method works properly
assert var_0 == None
print("Success!")

# Generated at 2022-06-26 04:37:17.772347
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()

# Generated at 2022-06-26 04:37:18.797803
# Unit test for method init of class Settings
def test_Settings_init():
    pass



# Generated at 2022-06-26 04:37:19.643055
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()



# Generated at 2022-06-26 04:37:26.171149
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .main import load_config
    from .main import main
    from .settings import Settings
    from .utils import get_closest
    from .utils import get_history_without_current
    from .utils import get_script
    from .utils import get_valid_history_without_current
    from .utils import replace_argument
    from .utils import run
    var_0 = Settings()
    var_1 = var_0.init()
    var_2 = var_0.init()
    var_3 = var_0.init()
    var_4 = var_0.init()
    var_5 = var_0.init()
    var_6 = var_0.init()
    var_7 = var_0.init()
    var_8 = var_0.init()


# Generated at 2022-06-26 04:37:31.807004
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()
    # Default settings
    # - 0: user_dir
    assert settings_0.user_dir.is_dir()
    # - 1: wait_command
    assert settings_0.wait_command == 1

    # Test patching
    settings_1 = Settings({
        'user_dir': '.',
        'wait_command': 1,
        'require_confirmation': True
    })
    settings_1.init(argparse.Namespace(yes=True, debug=True))
    assert not settings_1.require_confirmation
    assert settings_1.debug

    settings_2 = Settings({
        'user_dir': '.',
        'wait_command': 1,
        'require_confirmation': True
    })
    settings_

# Generated at 2022-06-26 04:37:33.373490
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()


# Generated at 2022-06-26 04:37:35.853292
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()
    assert(var_0 == None)

# Generated at 2022-06-26 04:37:43.545514
# Unit test for method init of class Settings
def test_Settings_init():
    # Create a fake sys.argv for unit testing
    sys.argv = ['thefuck', '--yes', '--debug', '--repeat', '9']

    settings.init()

    assert os.path.isabs(settings.require_confirmation) == False

    assert settings.slow_commands == ["lein", "rebar3", "gradle"]

    assert settings.debug == True

    assert settings.repeat == 9

    assert os.path.isabs(settings.wait_command) == False

    assert settings.exclude_rules == ['git_push', 'sudo']

    assert settings.require_confirmation == False

    assert os.path.isabs(settings.priority) == False

    assert settings.no_colors == False

    assert os.path.isabs(settings.excluded_search_path_prefixes) == False

# Generated at 2022-06-26 04:37:44.721416
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

# Generated at 2022-06-26 04:37:45.614279
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()