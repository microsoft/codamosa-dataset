

# Generated at 2022-06-26 04:30:37.102435
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0['debug'] == settings['debug']
    assert settings_0['require_confirmation'] == settings['require_confirmation']
    assert settings_0['slow_commands'] == settings['slow_commands']
    assert settings_0['exclude_rules'] == settings['exclude_rules']
    assert settings_0['excluded_search_path_prefixes'] == settings['excluded_search_path_prefixes']
    assert settings_0['history_limit'] == settings['history_limit']
    assert settings_0['wait_command'] == settings['wait_command']
    assert settings_0['wait_slow_command'] == settings['wait_slow_command']
    assert settings_0['alter_history'] == settings['alter_history']
    assert settings

# Generated at 2022-06-26 04:30:40.858967
# Unit test for method init of class Settings
def test_Settings_init():
    init_args = "settings.py"
    settings_0 = Settings()
    settings_0.init(init_args)
    assert len(settings_0) > 0

# Generated at 2022-06-26 04:30:42.203803
# Unit test for method init of class Settings
def test_Settings_init():
    
    # Test first init of Settings object
    test_case_0()

    # Test next init of Settings object
    settings.init()

# Generated at 2022-06-26 04:30:55.329069
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings._get_user_dir_path() == Path('~/.config/thefuck').expanduser()
    assert settings['rules'] == ['git_push', 'git_add', 'npm', 'man', 'brew_install', 'pep8', 'vagrant', 'system', 'pip', 'git_commit', 'git_stash', 'git_pull', 'long_commands', 'cd_parent', 'sudo', 'git_amend', 'git_checkout', 'git_clean', 'cargo', 'ls_command', 'docker', 'node', 'python_cmd', 'safe_sudo', 'nvm', 'apt_get', 'brew', 'ruby', 'php', 'django_manage', 'git_branch', 'git', 'apt']

# Generated at 2022-06-26 04:30:59.220982
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    assert settings.require_confirmation, \
        "require_confirmation should be True initially"


# Generated at 2022-06-26 04:31:06.856321
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    settings_1 = Settings()
    settings_1._setup_user_dir()
    settings_1._init_settings_file()
    try:
        settings_1.update(settings_1._settings_from_file())
    except Exception:
        exception("Can't load settings from file", sys.exc_info())
    try:
        settings_1.update(settings_1._settings_from_env())
    except Exception:
        exception("Can't load settings from env", sys.exc_info())
    settings_1.update(settings_1._settings_from_args([]))

# Generated at 2022-06-26 04:31:12.550625
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0.require_confirmation == True
    assert settings_0.repeat == 1
    assert settings_0.history_limit == None


# Generated at 2022-06-26 04:31:16.693380
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    # assert False # TODO: implement your test here
    assert True


# Generated at 2022-06-26 04:31:21.065208
# Unit test for method init of class Settings
def test_Settings_init():
   x = Settings()
   x.init()
   assert x.get('sudo_mode') == True, "The test for method init of class Settings is failed."


# Generated at 2022-06-26 04:31:29.578206
# Unit test for method init of class Settings
def test_Settings_init():
    # Saving original attributes of settings
    original_attributes = {}
    attributes_to_save = ['user_dir', 'settings_file']
    for attr in attributes_to_save:
        if attr in settings.__dict__:
            original_attributes[attr] = settings.__dict__[attr]
    if len(original_attributes.keys()) != len(attributes_to_save):
        raise AssertionError()

    # Saving original environment variables
    original_environ = {}
    for key, val in const.ENV_TO_ATTR.items():
        if key in os.environ:
            original_environ[key] = os.environ[key]

    # Saving original content of user settings.py
    original_user_settings = {}

# Generated at 2022-06-26 04:31:55.859566
# Unit test for method init of class Settings
def test_Settings_init():
    # No exception was raised, test passed.
    pass



# Generated at 2022-06-26 04:32:00.679119
# Unit test for method init of class Settings
def test_Settings_init():

    var_0 = Settings()
    assert len(var_0.keys()) == 17
    var_0.update(var_0._settings_from_file())
    assert len(var_0.keys()) == 17
    var_0.update({'rules': ('test_test',), 'command_not_found': 'command_not_found'})
    assert len(var_0.keys()) == 19


# Generated at 2022-06-26 04:32:01.841295
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()


# Generated at 2022-06-26 04:32:07.066076
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings({'num_close_matches': 1})
    settings_0._setup_user_dir()
    settings_0._init_settings_file()
    settings_0.update(settings_0._settings_from_file())
    settings_0.update(settings_0._settings_from_env())
    settings_0.update(settings_0._settings_from_args())


# Generated at 2022-06-26 04:32:07.664489
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

# Generated at 2022-06-26 04:32:12.542835
# Unit test for method init of class Settings
def test_Settings_init():
    os.environ['XDG_CONFIG_HOME'] = '/home/dima/.config'
    settings_0 = Settings()
    var_0 = settings_0.init()

    assert (var_0 == None)
if __name__ == '__main__':
    test_Settings_init()

# Generated at 2022-06-26 04:32:15.671822
# Unit test for method init of class Settings
def test_Settings_init():
    pass



# Generated at 2022-06-26 04:32:17.440342
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()


# Generated at 2022-06-26 04:32:19.452124
# Unit test for method init of class Settings
def test_Settings_init():
	settings = Settings()
	settings.init()
	pass



# Generated at 2022-06-26 04:32:23.144748
# Unit test for method init of class Settings
def test_Settings_init():
    print("Testing init...")

    var_0 = Settings()
    var_0.init()
    assert var_0 == settings
    return

# Generated at 2022-06-26 04:33:20.686558
# Unit test for method init of class Settings
def test_Settings_init():
    from sys import argv, exc_info
    from . import logs
    from .logs import exception
    from imp import load_source
    from os import environ
    from six import text_type
    from . import const
    from .system import Path
    import os
    import sys
    from warnings import warn


# Generated at 2022-06-26 04:33:21.242693
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

# Generated at 2022-06-26 04:33:23.330704
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    var_1 = settings_1.init()

# Generated at 2022-06-26 04:33:24.900014
# Unit test for method init of class Settings
def test_Settings_init():
    assert True

# Generated at 2022-06-26 04:33:27.183189
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init( sys)



# Generated at 2022-06-26 04:33:28.852723
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()
    assert(var_0 == None)


# Generated at 2022-06-26 04:33:32.698419
# Unit test for method init of class Settings
def test_Settings_init():
    # Test 1:
    # var_0 = None
    # case_0 = test_case_0()

    pass


# Generated at 2022-06-26 04:33:36.019109
# Unit test for method init of class Settings
def test_Settings_init():
    cases = [
        test_case_0,
    ]
    for case in cases:
        case()


# Generated at 2022-06-26 04:33:43.541898
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path

    settings_0 = Settings()
    settings_0._setup_user_dir()
    settings_0.user_dir = Path(settings_0.user_dir.joinpath('settings.py'))
    settings_0.update(settings_0._settings_from_file())

    env_0 = {}
    env_0['FUCK_WAIT_COMMAND'] = '8'
    env_0['FUCK_SLOW_COMMANDS'] = 'gradle build'
    env_0['FUCK_HISTORY_LIMIT'] = '9'
    env_0['FUCK_PRIORITY'] = 'fasd=3:brew=1'
    env_0['FUCK_WAIT_SLOW_COMMAND'] = '4'
   

# Generated at 2022-06-26 04:33:53.691775
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()

# Init settings with empty args
settings.init()
assert(settings.require_confirmation == True)
assert(settings.history_limit == None)
assert(settings.rules == (
        'git_add_command',
        'git_bisect_bad_command',
        'git_bisect_good_command',
        'git_bisect_reset_command',
        'git_checkout_command',
        'git_commit_command',
        'git_diff_command',
        'git_merge_command',
        'git_push_command',
        'git_rebase_command',
        'git_reset_command',
        'git_stash_command',
        'git_tag_command',
    ))

# Test method _val

# Generated at 2022-06-26 04:36:11.487016
# Unit test for method init of class Settings
def test_Settings_init():
    print('Testing init of the class Settings ...')
    import tempfile
    test_case_0()
    #
    td = tempfile.mkdtemp()
    user_dir_old = const.DEFAULT_SETTINGS['user_dir']
    const.DEFAULT_SETTINGS['user_dir'] = td + '/.config/thefuck'
    settings_1 = Settings()
    settings_1.init()
    const.DEFAULT_SETTINGS['user_dir'] = user_dir_old
    print('... Testing init of the class Settings passed.')


# Generated at 2022-06-26 04:36:15.081404
# Unit test for method init of class Settings
def test_Settings_init():
    var_0 = Settings({"rules": ["fuck", "sudo"], "priority": {"none": 0, "low": 1, "normal": 2, "high": 3}})
    var_1 = var_0.init()


# Generated at 2022-06-26 04:36:22.988760
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    from thefuck.rules.git_branch import match
    from thefuck.rules.git_branch import get_new_command
    from thefuck.rules.git_commit import match
    from thefuck.rules.git_commit import get_new_command
    from thefuck.rules.git_checkout import match
    from thefuck.rules.git_checkout import get_new_command
    from thefuck.rules.git_rerere import match
    from thefuck.rules.git_rerere import get_new_command
    from thefuck.rules.git_push import match
    from thefuck.rules.git_push import get_new_command
    from thefuck.rules.git_merge import match
    from thefuck.rules.git_merge import get_new_command

# Generated at 2022-06-26 04:36:30.901918
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0._init_settings_file()
    var_0 = settings_0._get_user_dir_path()
    settings_0._setup_user_dir()
    var_2 = settings_0._val_from_env("THEFUCK_SHOW_ALIASES", "show_aliases")
    var_3 = settings_0._rules_from_env("THEFUCK_RULES_DEFAULT")
    settings_0.update(settings_0._settings_from_file())
    settings_0.update(settings_0._settings_from_env())


# Generated at 2022-06-26 04:36:36.105394
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()

# Generated at 2022-06-26 04:36:39.377579
# Unit test for method init of class Settings
def test_Settings_init():
    var_0 = Settings().init()


# Generated at 2022-06-26 04:36:41.273827
# Unit test for method init of class Settings
def test_Settings_init():
    # test case 0
    test_case_0()
    return True

# Generated at 2022-06-26 04:36:49.224595
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    settings.init()
    # assert settings.user_dir == '/home/dz0ny/.config/thefuck'
    assert settings.debug == False
    assert settings.require_confirmation == True
    assert settings.history_limit == None
    assert settings.alter_history == False
    assert settings.wait_slow_command == 7
    assert settings.wait_command == 3
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.no_colors == False
    assert settings.excluded_search_path_prefixes == ['sudo']
    assert settings.repeat == False


# Generated at 2022-06-26 04:36:52.585402
# Unit test for method init of class Settings
def test_Settings_init():
    import inspect
    lines = inspect.getsource(test_case_0)
    assert 'settings_0.init()' in lines


# Generated at 2022-06-26 04:36:57.593217
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    # the test doesn't work if the path to user's config dir doesn't exist
    # mkdir(settings_0._get_user_dir_path())
    settings_0.init()

# Generated at 2022-06-26 04:39:41.794557
# Unit test for method init of class Settings
def test_Settings_init():
    print("Test of init method of Settings")
    #arrange
    settings_0 = Settings()
    var_0 = settings_0.init(args=None)

    #assert
    assert(var_0 == None)