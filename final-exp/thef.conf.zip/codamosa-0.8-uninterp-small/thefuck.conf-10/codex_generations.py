

# Generated at 2022-06-26 04:30:04.807007
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    for key in settings_0.keys():
        assert 'settings_0.'+key in dir(settings_0)

# Generated at 2022-06-26 04:30:05.714980
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

# Generated at 2022-06-26 04:30:14.219859
# Unit test for method init of class Settings
def test_Settings_init():
    print('Start to test method init of class Settings')
    # @unittest.skip("demonstrating skipping")
    settings_1 = Settings()
    settings_1.init()
    assert settings_1.user_dir != None
    assert settings_1.user_dir != ''
    assert settings_1.user_dir != None
    assert settings_1.user_dir != ''
    assert settings_1.user_dir != None
    assert settings_1.user_dir != ''
    assert settings_1.user_dir != None
    assert settings_1.user_dir != ''
    assert settings_1.user_dir != None
    assert settings_1.user_dir != ''
    assert settings_1.user_dir != None
    assert settings_1.user_dir != ''
    assert settings_1.user_dir != None

# Generated at 2022-06-26 04:30:21.553220
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    try:
        settings.init('1')
    except Exception:
        exception("Can't load settings from file", sys.exc_info())

    try:
        settings.init('1')
    except Exception:
        exception("Can't load settings from env", sys.exc_info())

    settings.init('1')

# Generated at 2022-06-26 04:30:23.430915
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    key = 'rules'
    assert key in settings_0

# Generated at 2022-06-26 04:30:28.394725
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert(settings_0['history_limit'] == 10)
    assert(settings_0['alter_history'] == False)


# Generated at 2022-06-26 04:30:39.424148
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    if settings_0._get_user_dir_path() == '~/.config/thefuck':
        print("Passed unit test 1 of method init of class Settings")
    else:
        print("Failed unit test 1 of method init of class Settings")
    if settings_0['command_not_found'] == 'fuck' and settings_0['rules'] == [
        'sudo_command'
    ] and settings_0['require_confirmation'] == True and settings_0[
            'repeat_command'] == True and settings_0[
                'wait_command'] == 5 and settings_0['repeat_delay'] == 3:
        print("Passed unit test 2 of method init of class Settings")
    else:
        print("Failed unit test 2 of method init of class Settings")


#test_case_0

# Generated at 2022-06-26 04:30:40.671011
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

# Generated at 2022-06-26 04:30:44.566095
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

# Generated at 2022-06-26 04:30:53.290008
# Unit test for method init of class Settings
def test_Settings_init():
    # before getattr()
    assert 'user_dir' not in dir(settings_0)

    # before _setup_user_dir()
    assert not ('user_dir' in dir(settings_0) and settings_0.user_dir is None)

    # before _init_settings_file()
    assert 'settings_path' in dir(settings_0) and settings_0.settings_path is not None
    assert (settings_0.settings_path.is_file() == False)

    # before _settings_from_file()
    assert 'val' in dir(settings_0) and settings_0.val is None

    # before _settings_from_env()
    assert ('attr' in dir(settings_0) and settings_0.attr is None) or ('attr' not in dir(settings_0))

    # before _settings

# Generated at 2022-06-26 04:31:27.885386
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0['require_confirmation'] == True
    assert settings_0['history_limit'] == None
    assert settings_0['alter_history'] == True
    assert settings_0['wait_command'] == 3
    assert settings_0['num_close_matches'] == 3
    assert settings_0['rules'] == ['git_push', 'git_add', 'pip_install', 'brew_install', 'apt_install', 'npm_install', 'vagrant', 'supervisord_restart', 'systemd_restart', 'systemctl_restart', 'lxc_start', 'rm', 'cp', 'mv', 'sudo_rm_rf', 'cd', 'mkdir', 'chown', 'chmod']

# Generated at 2022-06-26 04:31:39.389492
# Unit test for method init of class Settings
def test_Settings_init():
    from thefuck.runner import Runner
    from thefuck.rules.alias import match, get_new_command
    from thefuck.rules.git_support import match, get_new_command
    from thefuck.rules.git_support import git_support
    from thefuck.rules.python_support import match, get_new_command
    from thefuck.rules.python_support import python_support
    from thefuck.rules.man import match, get_new_command
    from thefuck.rules.man import man_support
    from thefuck.rules.no_command import match, get_new_command
    from thefuck.rules.no_command_found import match, get_new_command
    from thefuck.rules.no_command_found import no_command_found
    from thefuck.rules.no_command_match import match, get

# Generated at 2022-06-26 04:31:41.892784
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    settings_0 = Settings()
    settings_0.init()

# Generated at 2022-06-26 04:31:43.829375
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    test_case_0()



# Generated at 2022-06-26 04:31:55.898464
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1.init()
    assert settings_1['require_confirmation'] == True
    assert settings_1['no_colors'] == False
    assert settings_1['debug'] == False
    assert settings_1['alter_history'] == True
    assert settings_1['wait_command'] == 3
    assert settings_1['history_limit'] == None
    assert settings_1['wait_slow_command'] == 30
    assert settings_1['num_close_matches'] == 3
    assert settings_1['slow_commands'] == ['lein', 'gradle', 'rebuild', './build.sh', 'bundle', 'vagrant']
    assert settings_1['excluded_search_path_prefixes'] == []

# Generated at 2022-06-26 04:31:57.375725
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()


# Generated at 2022-06-26 04:31:59.084259
# Unit test for method init of class Settings
def test_Settings_init():
    settings_init = Settings()
    settings_init._init_settings_file()


# Generated at 2022-06-26 04:32:05.903217
# Unit test for method init of class Settings
def test_Settings_init():
    import unittest
    import sys
    import os
    sys.path.append('/home/igarashi/src/thefuck3')
    class MockPath(object):
        def __init__(self, path):
            self._path = path

        def joinpath(self, path):
            self._path = os.path.join(self._path, path)
            return self

        def is_file(self):
            if self._path == 'is_file_true':
                return True
            else:
                return False

        def open(self, mode):
            self._mode = mode
            return None

        def is_dir(self):
            if self._path == 'is_dir_true':
                return True
            else:
                return False

        def mkdir(self, parents):
            self._parent = parents

# Generated at 2022-06-26 04:32:07.091838
# Unit test for method init of class Settings
def test_Settings_init():
    settings_2 = Settings(dict(a=True, b=True))
    settings_3 = Settings()



# Generated at 2022-06-26 04:32:09.380026
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()


# Generated at 2022-06-26 04:32:36.623800
# Unit test for method init of class Settings
def test_Settings_init():
    # Setup test data
    settings_0 = Settings()
    var_0 = settings_0.init()
    assert var_0 == None


# Generated at 2022-06-26 04:32:38.060973
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0 == settings

# Generated at 2022-06-26 04:32:42.131592
# Unit test for method init of class Settings
def test_Settings_init():
    print("test_Settings_init")

    settings_0 = Settings()
    var_0 = settings_0.init()
    #assert settings_0.user_dir == '/home/jerry/.config/thefuck', \
    #    'Incorrect value for settings_0.user_dir'
    #assert var_0 is None, 'Incorrect return value'

# Generated at 2022-06-26 04:32:44.064315
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-26 04:32:46.263988
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0.var_0


# Generated at 2022-06-26 04:32:48.001844
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()


# Generated at 2022-06-26 04:32:51.345726
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()
    assert None == var_0

# Generated at 2022-06-26 04:32:58.161835
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    settings_1 = Settings()
    settings_1.user_dir = text_type(Path())
    settings_1.init()

    try:
        var_0 = settings_1.init()
    except Exception:
        exception("Can't load settings from file", sys.exc_info())

    try:
        var_1 = settings_1.init()
    except Exception:
        exception("Can't load settings from env", sys.exc_info())

# Generated at 2022-06-26 04:33:03.320603
# Unit test for method init of class Settings
def test_Settings_init():
    settings_obj = settings
    var_0 = settings_obj.init()
    assert settings['repeat'] == 1

# Generated at 2022-06-26 04:33:05.624823
# Unit test for method init of class Settings
def test_Settings_init():
    settings_init_0 = Settings()
    var_init_0 = settings_init_0.init()


# Generated at 2022-06-26 04:33:56.967559
# Unit test for method init of class Settings
def test_Settings_init():
    # Test for method init of class Settings
    # Test for method init of class Settings
    assert(True)


# Generated at 2022-06-26 04:34:02.580299
# Unit test for method init of class Settings
def test_Settings_init():
    if True:
        path_1 = os.getcwd()
        path_2 = os.path.join(path_1, "test")
        os.chdir(path_2)
        var_0 = settings.init()

# Generated at 2022-06-26 04:34:04.098909
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

# Generated at 2022-06-26 04:34:08.398097
# Unit test for method init of class Settings
def test_Settings_init():
    s = Settings()
    s.init()
    assert s.instant_mode == False
    assert s.alter_history == False
    assert s.exclude_rules == []
    assert s.debug == False

# Generated at 2022-06-26 04:34:13.921425
# Unit test for method init of class Settings
def test_Settings_init():
	settings_0 = Settings()
	var_0 = settings_0.init()


# Generated at 2022-06-26 04:34:15.054572
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()

# Generated at 2022-06-26 04:34:16.260178
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()
    assert(var_0 == None)

# Generated at 2022-06-26 04:34:24.785809
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init(None)
    settings_0['repeat'] = None
    assert settings_0['repeat'] == None

# Generated at 2022-06-26 04:34:26.241538
# Unit test for method init of class Settings
def test_Settings_init():
    assert True


# Generated at 2022-06-26 04:34:30.062246
# Unit test for method init of class Settings
def test_Settings_init():
    expected_res = "dictionnary"
    var_0 = Settings()
    var_1 = var_0.init()
    var_2 = type(var_1)
    assert var_2 == expected_res


# Generated at 2022-06-26 04:35:33.680351
# Unit test for method init of class Settings
def test_Settings_init():
    try:
        for setting in const.DEFAULT_SETTINGS.items():
            settings_file.write(u'# {} = {}\n'.format(*setting))
        settings_0 = Settings()
        var_0 = settings_0.init()
    except Exception as e:
        print("An error occurred")
        print(e)
        raise e

# Generated at 2022-06-26 04:35:37.901369
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()
    assert 'user_dir' in var_0


# Generated at 2022-06-26 04:35:40.502322
# Unit test for method init of class Settings
def test_Settings_init():
    default_settings = Settings()
    default_settings.init()
    # print(default_settings.get('alias'))
    assert default_settings.get('alias') == 'fuck'

# Generated at 2022-06-26 04:35:44.981066
# Unit test for method init of class Settings
def test_Settings_init():

    # Validate state of variables after function call:
    assert settings.user_dir.is_dir()


# Generated at 2022-06-26 04:35:51.484248
# Unit test for method init of class Settings
def test_Settings_init():
    import sys
    import os
    import tempfile
    import shutil

    testdir = tempfile.mkdtemp()
    os.environ['XDG_CONFIG_HOME'] = testdir
    os.mkdir(os.path.join(testdir, 'thefuck'))
    settings_0 = Settings()
    var_1 = settings_0.init()


    shutil.rmtree(testdir)

# Generated at 2022-06-26 04:35:52.715137
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()


# Generated at 2022-06-26 04:35:58.249879
# Unit test for method init of class Settings
def test_Settings_init():

    class Args(object):
        inst_mode = True
        wait_command = 11
        wait_slow_command = 15
        require_confirmation = False
        alter_history = True
        history_limit = 10
        no_colors = True
        debug = False
        repeat = 3
        wait_slow_command = 55

    settings_1 = Settings()
    var_1 = settings_1.init(Args())
    assert var_1 == {'wait_command': 11, 'wait_slow_command': 55,
                     'require_confirmation': False, 'alter_history': True,
                     'history_limit': 10, 'no_colors': True, 'debug': False,
                     'repeat': 3, 'instant_mode': True}


# Generated at 2022-06-26 04:36:00.068028
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    assert type(settings_1) == Settings

# Generated at 2022-06-26 04:36:01.609841
# Unit test for method init of class Settings
def test_Settings_init():
    
    settings_0 = Settings()
    assert_equals(settings_0.init(), None)


# Generated at 2022-06-26 04:36:03.924823
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    settings.init()


# Generated at 2022-06-26 04:38:37.820892
# Unit test for method init of class Settings
def test_Settings_init():
    instance_0 = Settings()
    instance_0.init()


# Generated at 2022-06-26 04:38:49.258360
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0.get('require_confirmation') == True
    assert settings_0.get('no_colors') == False
    assert settings_0.get('debug') == False
    assert settings_0.get('alter_history') == True
    assert settings_0.get('instant_mode') == False
    assert settings_0.get('exe') == 'fuck'
    assert settings_0.get('wait_command') == 3
    assert settings_0.get('wait_slow_command') == 5
    assert bool(settings_0.get('rules')) == bool(list)
    assert bool(settings_0.get('priority')) == bool(dict)
    assert bool(settings_0.get('history_limit')) == bool(int)
   

# Generated at 2022-06-26 04:39:00.256791
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1._setup_user_dir()
    var_1 = settings_1._init_settings_file()
    settings_1.update(settings_1._settings_from_file())
    settings_1.update(settings_1._settings_from_env())
    settings_1.update(settings_1._settings_from_args())
    settings_1.__getattr__()
    settings_1.__setattr__()

# Generated at 2022-06-26 04:39:02.819420
# Unit test for method init of class Settings
def test_Settings_init():
    # test for case 0
    test_case_0()

if __name__ == '__main__':
    test_Settings_init()

# Generated at 2022-06-26 04:39:07.790401
# Unit test for method init of class Settings
def test_Settings_init():
    test_error = None
    try:
        test_case_0()
    except Exception as e:
        test_error = e
    if test_error:
        print('FAIL {}'.format(test_error))
    else:
        print('PASS')

if __name__ == '__main__':
    test_Settings_init()

# Generated at 2022-06-26 04:39:09.794843
# Unit test for method init of class Settings
def test_Settings_init():
    # Initialize the object of class Settings
    settings_0 = Settings()
    # Call the method init of class Settings
    var_0 = settings_0.init()


# Generated at 2022-06-26 04:39:12.547012
# Unit test for method init of class Settings
def test_Settings_init():
    print("\n\tTest case 0:")
    test_case_0()

# Python code to create 
# a class dynamically 

# Generated at 2022-06-26 04:39:14.082340
# Unit test for method init of class Settings
def test_Settings_init():
    u = Settings(const.DEFAULT_SETTINGS)
    u.init()
    assert u == const.DEFAULT_SETTINGS


# Generated at 2022-06-26 04:39:26.684240
# Unit test for method init of class Settings
def test_Settings_init():
    # self._settings_from_args(args)
    settings_0 = Settings()
    settings_0.init()
    assert None is settings_0._settings_from_args()
    # self._settings_from_env()
    settings_1 = Settings()
    settings_1.init()
    assert None is settings_1._settings_from_env()
    # self._settings_from_file()
    settings_2 = Settings()
    settings_2.init()
    assert None is settings_2._settings_from_file()
    # self.update(self._settings_from_args(args))
    settings_3 = Settings()
    settings_3.update({})
    assert None is settings_3.init()
    # self.update(self._settings_from_env())
    settings_4 = Settings()
    settings_

# Generated at 2022-06-26 04:39:33.147324
# Unit test for method init of class Settings
def test_Settings_init():
    # Set up test environment
    settings_0 = Settings()
    var_0 = settings_0.init()

    from .logs import exception

    settings_0._setup_user_dir()
    settings_0._init_settings_file()

    try:
        var_0 = settings_0.update(settings_0._settings_from_file())
    except Exception as var_1:
        exception("Can't load settings from file", sys.exc_info())

    try:
        var_0 = settings_0.update(settings_0._settings_from_env())
    except Exception as var_2:
        exception("Can't load settings from env", sys.exc_info())

    var_0 = settings_0.update(settings_0._settings_from_args(None))

