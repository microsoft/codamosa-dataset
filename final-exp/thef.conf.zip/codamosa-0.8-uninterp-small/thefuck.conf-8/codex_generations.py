

# Generated at 2022-06-26 04:30:30.550325
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()

if __name__ == '__main__':
    test_case_0()
    test_Settings_init()

    print(settings)

# Generated at 2022-06-26 04:30:34.981496
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.update(settings_0._settings_from_env())
    assert settings_0 == {'require_confirmation': True, 'debug': False, 'rules': ['match_changed', 'match_group_changed']}



# Generated at 2022-06-26 04:30:43.334786
# Unit test for method init of class Settings
def test_Settings_init():
    os.environ['XDG_CONFIG_HOME'] = '~./config'
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'true'
    os.environ['THEFUCK_RULES'] = 'DEFAULT_RULES'
    os.environ['THEFUCK_ALTER_HISTORY'] = 'true'
    os.environ['THEFUCK_WAIT_COMMAND'] = '1'
    os.environ['THEFUCK_TIMEOUT'] = '1'
    os.environ['THEFUCK_HISTORY_LIMIT'] = '1'
    os.environ['THEFUCK_WAIT_SLOW_COMMAND'] = '1'
    os.environ['THEFUCK_SLOW_COMMANDS'] = '[]'


# Generated at 2022-06-26 04:30:45.454797
# Unit test for method init of class Settings
def test_Settings_init():
    # Test case 0
    test_case_0()


# Generated at 2022-06-26 04:30:56.579906
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    args_1 = None
    settings_1.init(args_1)
    test_case_1 = []
    test_case_1.append(settings_1.get('require_confirmation'))
    test_case_1.append(settings_1.get('rules'))
    test_case_1.append(settings_1.get('exclude_rules'))
    test_case_1.append(settings_1.get('no_colors'))
    test_case_1.append(settings_1.get('wait_command'))
    test_case_1.append(settings_1.get('slow_commands'))
    test_case_1.append(settings_1.get('wait_slow_command'))

# Generated at 2022-06-26 04:31:01.557065
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0.get('require_confirmation') == const.DEFAULT_SETTINGS['require_confirmation']


# Generated at 2022-06-26 04:31:13.921433
# Unit test for method init of class Settings
def test_Settings_init():
    print('testing')
    settings_0 = Settings()
    default_settings_0 = {'require_confirmation': True, 'use_notify': True, 'priority': {'pip': 100, 'git': 100, 'svn': 100, 'cargo': 100, 'stack': 100, 'bower': 100, 'vagrant': 100, 'emacs': 100, 'setuptools': 100, 'hg': 100, 'systemctl': 100, 'cabal': 100, 'apt-get': 100, 'emerge': 100, 'lua': 100, 'php': 100, 'aptitude': 100, 'brew': 100, 'perl': 100, 'snap': 100, 'chocolatey': 100, 'default': 100}}
    if settings_0.items() == default_settings_0.items():
        return True
    else:
        return

# Generated at 2022-06-26 04:31:16.750292
# Unit test for method init of class Settings
def test_Settings_init():
    # test case, when args is None
    test_case_0()


# Generated at 2022-06-26 04:31:17.521963
# Unit test for method init of class Settings
def test_Settings_init():
    # process of method init
    settings.init(None)

# Generated at 2022-06-26 04:31:21.798218
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()

    print('\nUnit test result of method init of class Settings')
    print(settings_0 == settings)



# Generated at 2022-06-26 04:31:56.346208
# Unit test for method init of class Settings
def test_Settings_init():
    from .system import Path
    from .logs import exception
    import sys
    import os

    settings_1 = Settings()
    settings_1.user_dir = Path('/home/thefuck/.config/thefuck')
    settings_1._init_settings_file()
    assert settings_1.user_dir.joinpath('settings.py').is_file()

    try:
        settings_1.update(settings_1._settings_from_file())
    except Exception:
        exception("Can't load settings from file", sys.exc_info())

    try:
        settings_1.update(settings_1._settings_from_env())
    except Exception:
        exception("Can't load settings from env", sys.exc_info())

    settings_1.update(settings_1._settings_from_args(args=None))

   

# Generated at 2022-06-26 04:31:57.852551
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings() 
    settings_0.init()



# Generated at 2022-06-26 04:31:59.172657
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()


# Generated at 2022-06-26 04:32:00.258681
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()



# Generated at 2022-06-26 04:32:05.682883
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0._get_user_dir_path()
    settings_0._setup_user_dir()
    settings_0._init_settings_file()
    settings_0._settings_from_file()
    settings_0._rules_from_env("")
    settings_0._priority_from_env("")
    settings_0._val_from_env("", "")
    settings_0._settings_from_env()
    settings_0.update({})

if __name__ == '__main__':
    """
    main function
    """
    # Unit test
    test_case_0()

# Generated at 2022-06-26 04:32:07.166393
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    # Unfortunately, this method requires an argument
    # settings_0.init()


# Generated at 2022-06-26 04:32:14.668976
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    user_dir_path = settings_1._get_user_dir_path()
    # This method must lead to successful return in 2 two cases
    # Case 1 : The settings path is the settings.py file which is the default path
    # Case 2 : The settings path is the settings.py file in a specified directory
    settings_1.init()
    settings_1.init(['/home/navarjun/thefuck/thefuck/tests'])
    user_dir_path.joinpath('settings.py').unlink()
    user_dir_path.unlink()
    assert 1



# Generated at 2022-06-26 04:32:16.494577
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()

    arg_0 = None
    settings_1.init(arg_0)


# Generated at 2022-06-26 04:32:29.769000
# Unit test for method init of class Settings
def test_Settings_init():
    args = None
    settings_1 = Settings()
    settings_1.init(args)
    assert settings_1.require_confirmation == True
    assert settings_1.alter_history == True
    assert settings_1.rules == ['ls_la']
    assert settings_1.priority == {'ls_la': 1}
    assert settings_1.exclude_rules == []
    assert settings_1.no_colors == False
    assert settings_1.debug == False
    assert settings_1.wait_command == 1
    assert settings_1.history_limit == None
    assert settings_1.slow_commands == ['lein', 'react-native-cli']
    assert settings_1.wait_slow_command == 15
    assert settings_1.num_close_matches == 3
    assert settings_1.instant_

# Generated at 2022-06-26 04:32:39.265770
# Unit test for method init of class Settings
def test_Settings_init():
    from .tests.utils import replace_attr
    settings_0 = Settings()
    settings_0._settings_from_file = lambda: {}
    settings_0._settings_from_env = lambda: {"RULES": "default_rules"}
    with replace_attr(settings_0, '_rules_from_env', lambda x: x):
        settings_0._settings_from_args = lambda x: {"require_confirmation": True}
        settings_0.init()
        assert settings_0["require_confirmation"]
        assert settings_0["RULES"] == "default_rules"
    settings_0._settings_from_file = lambda: {"RULES": "rules_from_settings"}
    settings_0._settings_from_env = lambda: {"require_confirmation": False}
    settings_0._settings_from_

# Generated at 2022-06-26 04:33:09.281317
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1.init()



# Generated at 2022-06-26 04:33:11.086078
# Unit test for method init of class Settings
def test_Settings_init():
    Settings(settings).update(settings)
    for s in settings :
        assert const.DEFAULT_SETTINGS[s] == settings[s]

# Generated at 2022-06-26 04:33:13.299026
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()


# Generated at 2022-06-26 04:33:17.476239
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1.init(args=None)
    """
    settings_1.update(settings_1._settings_from_env())
    settings_1.update(settings_1._settings_from_file())
    """



# Generated at 2022-06-26 04:33:30.379555
# Unit test for method init of class Settings
def test_Settings_init():
    dict_1 = {u'rules': [u'~/test_rules.py'], u'exclude_rules': [u'WhatevzField'],
    u'no_colors': True, u'wait_command': 5, u'history_limit': 4, u'wait_slow_command': 9,
    u'priority': {u'WhatevzField': 1, u'HelloField': 2, u'AlohaField': 3}}


# Generated at 2022-06-26 04:33:32.340838
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0["require_confirmation"]
    assert settings_0["wait_command"] == 3



# Generated at 2022-06-26 04:33:35.678696
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0._init_settings_file() == None



# Generated at 2022-06-26 04:33:40.661834
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import log, logger
    from .logs import set_logger
    set_logger(log, logger)
    from .logs import exception
    temp_settings = Settings()
    try:
        temp_settings.init()
    except Exception as e:
        exception("Can't init settings in test_case_0", sys.exc_info())


# Generated at 2022-06-26 04:33:42.387692
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()


# Generated at 2022-06-26 04:33:48.708234
# Unit test for method init of class Settings
def test_Settings_init():
    # Calling init without parameters
    settings.init()
    # Testing user_dir
    assert isinstance(settings.user_dir, Path)
    assert settings.user_dir.endswith('.thefuck')
    assert settings.user_dir.exists()



# Generated at 2022-06-26 04:34:22.804726
# Unit test for method init of class Settings
def test_Settings_init():
    # test first
    settings_0 = Settings()
    settings_0.init()
    assert settings_0.get('rules') == const.DEFAULT_RULES
    assert settings_0.get('exclude_rules') == []
    assert settings_0.get('priority') == {}
    assert settings_0.get('history_limit') == 10
    assert settings_0.get('wait_command') == 5
    assert settings_0.get('slow_commands') == []
    assert settings_0.get('excluded_search_path_prefixes') == []
    assert settings_0.get('no_colors') == False
    assert settings_0.get('require_confirmation') == True
    assert settings_0.get('instant_mode') == False
    assert settings_0.get('wait_slow_command')

# Generated at 2022-06-26 04:34:28.743591
# Unit test for method init of class Settings
def test_Settings_init():
    """
    To test init method of class Settings
    """
    settings_1 = Settings()
    settings_1.init()
    assert len(settings_1) == 13
    assert settings_1['rules'] is not None
    assert settings_1['require_confirmation'] is True

# Generated at 2022-06-26 04:34:40.288762
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0._settings_from_file() == {'alias': None, 'priority': {}, 'exclude_rules': [], 'history_limit': None, 'no_colors': False, 'rules': [], 'wait_slow_command': 1, 'require_confirmation': False, 'alter_history': False, 'debug': False, 'exclude_commands': [], 'num_close_matches': 3}

# Generated at 2022-06-26 04:34:46.880987
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = copy.deepcopy(settings)
    settings_2 = Settings()
    assert settings_1 == settings_2


# Generated at 2022-06-26 04:34:48.757875
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init(args=None)
    settings_0['user_dir'] = Path('.', 'thefuck')


# Generated at 2022-06-26 04:34:59.406290
# Unit test for method init of class Settings
def test_Settings_init():
    # Populate settings0
    settings_0 = Settings(const.DEFAULT_SETTINGS)
    settings_0.init("")
    assert settings_0['require_confirmation'] == True
    assert settings_0['no_colors'] == False
    assert settings_0['debug'] == False
    assert settings_0['rules'] == ['man_clear', 'apt_remove', 'brew_upgrade']
    assert settings_0['exclude_rules'] == []
    assert settings_0['wait_command'] == 3
    assert settings_0['slow_commands'] == ['git', 'vagrant']
    assert settings_0['wait_slow_command'] == 5
    assert settings_0['priority'] == {}
    assert settings_0['excluded_search_path_prefixes'] == []

# Generated at 2022-06-26 04:35:03.749317
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()

    assert(settings_0.user_dir.is_dir())
    assert("user_dir" in settings_0)


# Generated at 2022-06-26 04:35:05.850148
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()


# Generated at 2022-06-26 04:35:07.518178
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()



# Generated at 2022-06-26 04:35:10.413696
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0.update(settings_0._settings_from_file()) is None
    assert settings_0.update(settings_0._settings_from_env()) is None
    assert settings_0.update(settings_0._settings_from_args(test_case_0)) is None

# Generated at 2022-06-26 04:35:44.667510
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1.init()


# Generated at 2022-06-26 04:35:46.802687
# Unit test for method init of class Settings
def test_Settings_init():
    # when calling method init with a instance of settings
    settings_0 = Settings()
    settings_0.init(args=None)
    # then method init should return None
    assert settings_0 == settings


# Generated at 2022-06-26 04:35:50.515453
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    # Test is passed because the project doesn't have any errors while executing this method.


# Generated at 2022-06-26 04:35:51.716611
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()



# Generated at 2022-06-26 04:35:54.195496
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()

if __name__ == '__main__':
    test_case_0()
    test_Settings_init()

# Generated at 2022-06-26 04:35:55.540272
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings(const.DEFAULT_SETTINGS)
    settings_0.init()


# Generated at 2022-06-26 04:36:01.236862
# Unit test for method init of class Settings
def test_Settings_init():
    settings_init = Settings(const.DEFAULT_SETTINGS)
    settings_init.init()
    settings_init.user_dir = Path('~/.config/thefuck').expanduser()
    assert Path('~/.config/thefuck/settings.py').expanduser().exists()
    assert settings_init == settings
    settings_init.init()
    assert settings_init == settings


# Generated at 2022-06-26 04:36:10.529225
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from mock import patch, MagicMock
    from sys import exc_info
    from thefuck.conf import settings, Settings

    # Test case 1:
    # Test when a user's config dir is created.
    args = MagicMock(yes=None, debug=None, repeat=None)
    with patch.object(Settings, '_get_user_dir_path') as mock_user_dir:
        mock_user_dir.return_value = '~/.config/thefuck'
        with patch.object(Path, 'is_dir') as mock_is_dir:
            mock_is_dir.return_value = False

# Generated at 2022-06-26 04:36:21.175124
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .logs import _log
    from .system import _env

    args = None

    # Mock for method load_source can be called with any arguments
    def load_source_mock(name, source):
        if name == 'settings':
            return const.MockedSettings
        else:
            return None
    settings_0 = Settings()
    settings_0.load_source = load_source_mock

    # Mock for method update can be called with any arguments

# Generated at 2022-06-26 04:36:28.039113
# Unit test for method init of class Settings
def test_Settings_init():

    # Set up args with some values
    args = []
    args.require_confirmation = False
    args.debug = True
    args.repeat = 2

    # Set up expected dict
    expected = dict()
    expected['user_dir'] = ""
    expected['require_confirmation'] = False
    expected['debug'] = True
    expected['repeat'] = 2

    # Call init and check whether the returned dict is expected
    returned = settings.init(args)
    assert returned == expected



# Generated at 2022-06-26 04:37:06.717124
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    # Test exceptions
    settings_0.init()


# Test case 1: Call the method Settings.__getattr__

# Generated at 2022-06-26 04:37:08.653022
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings == settings_0

# Generated at 2022-06-26 04:37:09.821173
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()



# Generated at 2022-06-26 04:37:11.147195
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()


# Generated at 2022-06-26 04:37:14.460848
# Unit test for method init of class Settings
def test_Settings_init():
   settings_0 = Settings()
   args_0 = None
   settings_0.init(args_0)


# Generated at 2022-06-26 04:37:16.392398
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()

# Generated at 2022-06-26 04:37:23.650038
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .logs import args
    settings['test_0'] = 'test_0'
    settings.init(args)
    exception('test', '1')
    assert settings['test_0'] == 'test_0'
    settings['test_0'] = 'test_1'
    settings['test_1'] = 'test_2'
    settings.init(args)
    assert settings['test_1'] == 'test_2'
    assert settings['test_0'] == 'test_1'


# Generated at 2022-06-26 04:37:24.326969
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1.init()

# Generated at 2022-06-26 04:37:30.806642
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1.init()
    assert settings_1.user_dir == Path('/home/user/.config/thefuck')
    assert settings_1.rules == ['git_push', 'git_commit']
    assert settings_1.exclude_rules == []
    assert settings_1.wait_command == 3
    assert settings_1.require_confirmation == True
    assert settings_1.alter_history == False
    assert settings_1.no_colors == False
    assert settings_1.priority == {}
    assert settings_1.wait_slow_command == 15
    assert settings_1.slow_commands == ['lein', 'react-native', 'gradle', './gradlew']
    assert settings_1.history_limit == None
    assert settings_1.num_close_matches

# Generated at 2022-06-26 04:37:41.533180
# Unit test for method init of class Settings
def test_Settings_init():
    # Test case 0
    settings_0 = Settings({'exclude_rules': 'ls', 'wait_command': 1, 'num_close_matches': 1, 'excluded_search_path_prefixes': '', 'alter_history': True, 'rules': ['test', 'ls', 'cp'], 'slow_commands': '', 'history_limit': 0, 'debug': False, 'priority': {'cp': 0}, 'require_confirmation': False, 'instant_mode': False, 'wait_slow_command': 3, 'no_colors': False})
    settings_0.init()
    assert settings_0.debug == False
    assert settings_0.history_limit == 0
    assert settings_0.instant_mode == False
    assert settings_0.num_close_matches == 1

# Generated at 2022-06-26 04:39:11.428808
# Unit test for method init of class Settings
def test_Settings_init():
    from thefuck.utils import get_closest
    settings_0 = Settings()
    settings_0.init()
    assert settings_0.rules == [
    'sudo',
    'man',
    'alias',
    'cd',
    'cp',
    'git',
    'hg',
    'lf',
    'ls',
    'mkdir',
    'pip',
    'vagrant',
    'virtualenv',
    'unzip',
    'which'
    ]
    assert settings_0.require_confirmation
    assert settings_0.no_colors
    assert not settings_0.alter_history
    assert settings_0.wait_command == 3
    assert settings_0.history_limit == 1000
    assert settings_0.wait_slow_command == 10
    assert settings_0

# Generated at 2022-06-26 04:39:13.299881
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    sys.argv.append('--yes')

    settings_0.init()


# Generated at 2022-06-26 04:39:18.490214
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()

    class TestArgs(object):
        def __init__(self, yes=False, debug=False, repeat=False):
            self.yes = yes
            self.debug = debug
            self.repeat = repeat

    args_0 = TestArgs(True, True, True)
    settings_0['user_dir'] = '/home/ubuntu/.config/thefuck'

# Generated at 2022-06-26 04:39:22.405793
# Unit test for method init of class Settings
def test_Settings_init():
    print('test_Settings_init')
    settings_0 = Settings()
    settings_0.init()
    assert settings_0.user_dir == '/home/remy/.config/thefuck'

test_Settings_init()

# Generated at 2022-06-26 04:39:26.062053
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings(const.DEFAULT_SETTINGS)
    settings_0.init()
    assert settings_0.user_dir.name == 'thefuck'
    assert settings_0.user_dir.parent.name == '.config'


# Generated at 2022-06-26 04:39:32.943529
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert len(settings_0) == 9
    assert settings_0['require_confirmation']
    assert settings_0['priority'] == {'fuck': 1}
    assert settings_0['exclude_rules'] == ['git_push']
    assert settings_0['rules'] == ['fuck']
    assert settings_0['no_colors']
    assert settings_0['wait_command'] == 1
    assert settings_0['slow_commands'] == []
    assert settings_0['wait_slow_command'] == 15
    assert settings_0['alter_history']
    assert settings_0['instant_mode'] == False
    assert settings_0['history_limit'] == None
    assert settings_0['num_close_matches'] == 3
    assert settings_0

# Generated at 2022-06-26 04:39:37.087443
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings.user_dir.is_dir()




# Generated at 2022-06-26 04:39:38.288037
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()



# Generated at 2022-06-26 04:39:40.457772
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0.get('confirmation_method') == 'confirm'
