

# Generated at 2022-06-26 04:30:25.563447
# Unit test for method init of class Settings
def test_Settings_init():
    # Just in case
    settings.init()

    # Initiate from DEFAULT_SETTINGS and default settings file
    settings_0 = Settings()
    settings_0.init()
    assert settings_0.get('rules') == const.DEFAULT_SETTINGS['rules']

    # Initiate from file and overwrite the rules by args
    settings_0 = Settings()
    settings_0.init(argparse.Namespace(yes=True))
    assert settings_0.get('rules') == const.DEFAULT_SETTINGS['rules']
    assert settings_0.get('require_confirmation') == True

    # Initiate from file and args, without settings file
    settings_0 = Settings()
    settings_0.user_dir = Path('/tmp')
    settings_0.init(argparse.Namespace(yes=True))


# Generated at 2022-06-26 04:30:30.480553
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1.init()
    assert settings_1 == settings
    settings_2 = Settings()
    settings_2.init(args=None)
    assert settings_2 == settings



# Generated at 2022-06-26 04:30:32.039233
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()


# Generated at 2022-06-26 04:30:43.594807
# Unit test for method init of class Settings
def test_Settings_init():
    before_init = settings.__dict__.get('_initialized')
    before_user_dir = settings.__dict__.get('user_dir')
    before_settings_from_file = settings._settings_from_file()
    before_settings_from_env = settings._settings_from_env()
    before_settings_from_args = settings._settings_from_args(True)

    settings.init(True)
    after_init = settings.__dict__.get('_initialized')
    after_user_dir = settings.__dict__.get('user_dir')
    after_settings_from_file = settings._settings_from_file()
    after_settings_from_env = settings._settings_from_env()
    after_settings_from_args = settings._settings_from_args(True)

    assert before_init

# Generated at 2022-06-26 04:30:44.873974
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.init()


# Generated at 2022-06-26 04:30:47.181449
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1.init(None)


# Generated at 2022-06-26 04:30:48.625689
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1.init()



# Generated at 2022-06-26 04:30:57.734786
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init(None)
    assert settings_0.get('user_dir') == Path('~/.config/thefuck').expanduser()
    assert settings_0.get('history_limit') == const.DEFAULT_SETTINGS.get('history_limit')
    assert settings_0.get('num_close_matches') == const.DEFAULT_SETTINGS.get('num_close_matches')
    assert settings_0.get('priority') == const.DEFAULT_SETTINGS.get('priority')
    assert settings_0.get('rules') == const.DEFAULT_SETTINGS.get('rules')
    assert settings_0.get('exclude_rules') == const.DEFAULT_SETTINGS.get('exclude_rules')

# Generated at 2022-06-26 04:31:01.029540
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0.user_dir == settings.user_dir


# Generated at 2022-06-26 04:31:02.925020
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()

# Generated at 2022-06-26 04:31:39.344452
# Unit test for method init of class Settings
def test_Settings_init():
    if not sys.warnoptions:
        import warnings
        warnings.simplefilter("ignore")
    # Init settings by default
    settings_0 = Settings()
    settings_0.init()
    assert settings_0.get('require_confirmation') == const.DEFAULT_SETTINGS['require_confirmation']
    assert settings_0.get('rules') == const.DEFAULT_SETTINGS['rules']

    settings_1 = Settings()
    settings_1.init([])
    assert settings_1.get('require_confirmation') == const.DEFAULT_SETTINGS['require_confirmation']
    assert settings_1.get('rules') == const.DEFAULT_SETTINGS['rules']

    settings_2 = Settings()
    settings_2.init('require_confirmation')

# Generated at 2022-06-26 04:31:42.170492
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0 == settings


# Generated at 2022-06-26 04:31:49.528679
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    # Try to init Settings with no user_dir
    # This might raise an Exception
    try:
        settings_0.init()
    except Exception:
        pass
    # Setup user_dir 
    settings_0._setup_user_dir()
    # Try to init Settings with user_dir
    try:
        settings_0.init()
    except Exception:
        pass


# Generated at 2022-06-26 04:31:50.725311
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

# Generated at 2022-06-26 04:31:53.024459
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0


# Generated at 2022-06-26 04:32:02.208924
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.keys() == const.DEFAULT_SETTINGS.keys() + \
                             ['user_dir']
    # Assert settings.user_dir is correct
    assert settings.user_dir.is_dir() == True
    assert (settings.user_dir == Path('~/.config/thefuck').expanduser()).is_dir() or \
           (settings.user_dir == Path('~/.thefuck').expanduser()).is_dir()
    assert Path(str(settings.user_dir) + '/rules').is_dir() == True
    assert Path(str(settings.user_dir) + '/settings.py').is_file() == True

    # Assert settings.rules is correct
    assert settings.rules == settings.rules

    # Assert settings.exclude_rules is correct
   

# Generated at 2022-06-26 04:32:07.373642
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1.init()

# Generated at 2022-06-26 04:32:09.466419
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init(args)  # settings from file must be overwritten by settings from env
    assert settings_0.user_dir



# Generated at 2022-06-26 04:32:18.090589
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    
    settings_0 = Settings()
    settings_0.init()

    assert settings_0.get('priority') == const.DEFAULT_SETTINGS.get('priority')
    assert settings_0.get('rules') == const.DEFAULT_SETTINGS.get('rules')
    assert settings_0.get('exclude_rules') == const.DEFAULT_SETTINGS.get('exclude_rules')
    assert settings_0.get('require_confirmation') == const.DEFAULT_SETTINGS.get('require_confirmation')
    assert settings_0.get('no_colors') == const.DEFAULT_SETTINGS.get('no_colors')
    assert settings_0.get('debug') == const.DEFAULT_SETTINGS.get('debug')

# Generated at 2022-06-26 04:32:22.661200
# Unit test for method init of class Settings
def test_Settings_init():
    from .system import Path
    from .logs import exception

    # normal case
    settings_1 = Settings()
    settings_1._setup_user_dir = lambda: Path('~/.config/thefuck').expanduser()
    settings_1._init_settings_file = lambda: None
    settings_1._settings_from_file = lambda: {'key': 'value'}
    settings_1._settings_from_env = lambda: {'env': 'env'}
    settings_1._settings_from_args = lambda arg: arg
    settings_1.init('args')
    assert settings_1 == {'key': 'value', 'env': 'env'}

    # abnormal case
    settings_2 = Settings()
    settings_2._setup_user_dir = lambda: Path('~/.config/thefuck').expanduser

# Generated at 2022-06-26 04:33:16.804984
# Unit test for method init of class Settings
def test_Settings_init():
    # Call method init
    settings.init()
    # Check that attribute user_dir is set
    assert settings.user_dir, "Error: attribute user_dir was not set"


# Generated at 2022-06-26 04:33:20.129913
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0['require_confirmation'] == True

# Generated at 2022-06-26 04:33:27.791017
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    settings_1.init(['-y'])
    assert settings_1['require_confirmation'] is False
    settings_1.init(['--debug'])
    assert settings_1['debug'] is True
    settings_1.init(['--repeat'])
    assert settings_1['repeat'] is True


# Generated at 2022-06-26 04:33:31.907791
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()

    settings_1 = Settings()
    settings_1.init({})


# Generated at 2022-06-26 04:33:42.227064
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0.user_dir == '/home/shubham/.config/thefuck'
    assert settings_0.wait_command == 3
    assert settings_0.require_confirmation == True
    assert settings_0.no_colors == False
    assert settings_0.repeat == False
    assert settings_0.wait_slow_command == 15

# Generated at 2022-06-26 04:33:44.289082
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()


# Generated at 2022-06-26 04:33:47.666147
# Unit test for method init of class Settings
def test_Settings_init():
    settings_init = Settings()
    assert settings_init == const.DEFAULT_SETTINGS
  

# Generated at 2022-06-26 04:33:51.354601
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init(None)
    # test whether settings_0 has the correct user_dir
    user_dir = settings_0._get_user_dir_path()
    assert settings_0.user_dir == user_dir


# Generated at 2022-06-26 04:33:55.524120
# Unit test for method init of class Settings
def test_Settings_init():

    # define instance
    settings_0 = Settings()

    # test for method init of class Settings
    settings_0.init()


# Generated at 2022-06-26 04:34:02.768395
# Unit test for method init of class Settings
def test_Settings_init():
    from .system import subprocess
    from . import config
    import os
    # Initialize settings to default values
    settings_0 = Settings()
    settings_0.init()
    settings_1 = settings_0

    # Check that settings values are equal to corresponding settings values in default settings
    for attr, value in const.DEFAULT_SETTINGS.items():
        if attr in settings_1.keys():
            if settings_1.get(attr) != const.DEFAULT_SETTINGS.get(attr):
                return(False)
    return(True)


# Generated at 2022-06-26 04:36:00.489125
# Unit test for method init of class Settings
def test_Settings_init():
    # Init varibales
    settings_0 = Settings()
    if(settings.init() == None):
        print("pass the test")
    else:
        print("fail the test")



# Generated at 2022-06-26 04:36:10.068748
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from unittest import TestCase
    from io import StringIO
    import sys
    import importlib
    import os
    import tempfile

    class SettingsUnitTest(TestCase):
        def setUp(self):
            self.settings = Settings(const.DEFAULT_SETTINGS)
            self.setUp_temp_user_dir()

        def setUp_temp_user_dir(self):
            self.temp_user_dir = Path(
                tempfile.mkdtemp()
            )

            self.settings.user_dir = self.temp_user_dir

            rules_dir = self.temp_user_dir.joinpath('rules')

# Generated at 2022-06-26 04:36:17.467682
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from mock import patch
    with patch('thefuck.settings.exception') as exception_patch:
        settings_0 = Settings()
        settings_0.user_dir = 'user_dir'
        settings_0.init()
        assert exception_patch.called

# Generated at 2022-06-26 04:36:21.033459
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

# Generated at 2022-06-26 04:36:22.370176
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()


# Generated at 2022-06-26 04:36:24.975985
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0['require_confirmation'] == True


# Generated at 2022-06-26 04:36:33.255668
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_1 = Settings()
    settings_0.init(args=None)
    settings_1.init(args=None)
    assert settings_0.require_confirmation == settings_1.require_confirmation
    assert settings_0.slow_commands == settings_1.slow_commands
    assert settings_0.exclude_rules == settings_1.exclude_rules
    assert settings_0.alter_history == settings_1.alter_history
    assert settings_0.debug == settings_1.debug
    assert settings_0.repeat == settings_1.repeat
    assert settings_0.no_colors == settings_1.no_colors
    assert settings_0.history_limit == settings_1.history_limit
    assert settings_0.wait_slow_command == settings_1

# Generated at 2022-06-26 04:36:40.925796
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()
    assert settings_0['use_alternative_tokens'] == True
    assert settings_0['require_confirmation'] == True
    assert settings_0['no_colors'] == False
    assert settings_0['debug'] == False
    assert settings_0['wait_command'] == 3
    assert settings_0['history_limit'] == 99999
    assert settings_0['alter_history'] == True
    assert settings_0['repeat'] == 1
    assert settings_0['instant_mode'] == False
    assert settings_0['wait_slow_command'] == 15

# Generated at 2022-06-26 04:36:45.492459
# Unit test for method init of class Settings
def test_Settings_init():
    settings_init = Settings()
    settings_init._setup_user_dir()
    settings_init._init_settings_file()
    settings_init.update(settings_init._settings_from_file())
    settings_init.update(settings_init._settings_from_env())
    settings_init.update(settings_init._settings_from_args())


# Generated at 2022-06-26 04:36:47.114859
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    settings_0.init()

# Generated at 2022-06-26 04:39:08.481633
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

# Generated at 2022-06-26 04:39:13.107465
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    assert isinstance(settings_1, Settings)
    assert_equals(settings_1.__class__, dict)
    assert_equals(settings_1, {})
    var_1 = settings_1.init()
    assert_equals(var_1, None)


# Generated at 2022-06-26 04:39:14.607445
# Unit test for method init of class Settings
def test_Settings_init():
    var = Settings()
    var.init()
    assert var.user_dir == Path('~', '.config', 'thefuck')


# Generated at 2022-06-26 04:39:24.268775
# Unit test for method init of class Settings
def test_Settings_init():
    try:
        assert settings._settings_from_env() == {}
    except:
        warn("Method '_settings_from_env' of class 'Settings' doesn't pass tests.")
    try:
        assert settings._settings_from_file() == {}
    except:
        warn("Method '_settings_from_file' of class 'Settings' doesn't pass tests.")
    try:
        assert settings._settings_from_args() == {}
    except:
        warn("Method '_settings_from_args' of class 'Settings' doesn't pass tests.")


# Generated at 2022-06-26 04:39:25.908425
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.init(args=None) is None


# Generated at 2022-06-26 04:39:29.649927
# Unit test for method init of class Settings
def test_Settings_init():
    settings_1 = Settings()
    var_1 = settings_1.init()


if __name__ == '__main__':
    test_case_0()
    test_Settings_init()
    print('test finished')

# Generated at 2022-06-26 04:39:30.778173
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()

# vim: tabstop=8 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-26 04:39:33.241564
# Unit test for method init of class Settings
def test_Settings_init():
    test_case_0()


# Generated at 2022-06-26 04:39:36.750151
# Unit test for method init of class Settings
def test_Settings_init():
    settings_0 = Settings()
    var_0 = settings_0.init()
    assert var_0 == None


# Generated at 2022-06-26 04:39:43.741813
# Unit test for method init of class Settings
def test_Settings_init():
    settings_init = Settings().init

    # import os.environ
    # save_environ = os.environ
    # os.environ = {}

    # import sys.stderr as stderr
    # stderr.write = lambda *args: None
    # import sys.stdout as stdout
    # stdout.write = lambda *args: None
    # import sys.stdin as stdin
    # stdin.read = lambda *args: None

    settings_init()