

# Generated at 2022-06-22 00:06:23.735911
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.__class__.__base__ == dict
    assert settings['require_confirmation'] == True
    assert settings.require_confirmation == True
    assert settings.get('require_confirmation') == True
    assert settings == Settings(const.DEFAULT_SETTINGS)
    assert settings != const.DEFAULT_SETTINGS



# Generated at 2022-06-22 00:06:25.271569
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.__setattr__("test", 123)
    assert settings["test"] == 123


# Generated at 2022-06-22 00:06:33.900046
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    # give a undefined key
    assert isinstance(settings.__getattr__('undefined'), type(None))

    # give a empty string
    assert isinstance(settings.__getattr__(''), type(None))

    # give a None
    assert isinstance(settings.__getattr__(None), type(None))

    # give a dict
    assert isinstance(settings.__getattr__({}), type(None))

    # give a list
    assert isinstance(settings.__getattr__([]), type(None))


# Generated at 2022-06-22 00:06:35.333897
# Unit test for constructor of class Settings
def test_Settings():
    assert settings == const.DEFAULT_SETTINGS



# Generated at 2022-06-22 00:06:46.401242
# Unit test for method init of class Settings
def test_Settings_init():
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'False'
    os.environ['THEFUCK_RULES'] = 'DEFAULT_RULES:bash_history'
    os.environ['THEFUCK_EXCLUDE_RULES'] = 'git_commit'
    os.environ['THEFUCK_PRIORITY'] = 'bash_history=100:bash_alias=200'
    os.environ['THEFUCK_NO_COLORS'] = 'True'
    os.environ['THEFUCK_DEBUG'] = 'True'
    os.environ['THEFUCK_ALTER_HISTORY'] = 'False'
    os.environ['THEFUCK_WAIT_COMMAND'] = '50'

# Generated at 2022-06-22 00:06:47.194054
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.__setattr__('real_time_output', False)



# Generated at 2022-06-22 00:06:56.774509
# Unit test for method init of class Settings
def test_Settings_init():
    old_user_dir = settings.user_dir
    old_settings = settings.copy()
    try:
        settings.init()
    except ImportError as e:
        assert str(e) == 'No module named settings'

    try:
        settings.init(args=object())
    except AssertionError as e:
        assert str(e) == "'args' must be Namespace, not object"

    settings._setup_user_dir()

    class Args(object):
        pass
    args = Args()
    args.repeat = 2
    args.yes = True
    args.debug = True
    settings.init(args=args)
    assert settings.repeat == 2
    assert not settings.require_confirmation
    assert settings.debug

    settings.init()
    assert settings.repeat is None

# Generated at 2022-06-22 00:06:59.622260
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings == const.DEFAULT_SETTINGS
    settings.foo = 'bar'
    assert settings['foo'] == 'bar'


# Generated at 2022-06-22 00:07:02.986990
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init({'yes': True, 'debug': True, 'repeat': False})
    assert settings['require_confirmation'] == False
    assert settings['debug'] == True
    assert settings['repeat'] == False

# Generated at 2022-06-22 00:07:04.997958
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.hello = 'world'
    assert settings['hello'] == 'world'


# Generated at 2022-06-22 00:07:46.071329
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    if 'eggs' in settings:
        del settings['eggs']
    settings.eggs = 'spam'
    assert settings['eggs'] == 'spam'
    settings.eggs = 'ham'
    assert settings['eggs'] == 'ham'

# Generated at 2022-06-22 00:07:47.921659
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.wait_command == const.DEFAULT_SETTINGS['wait_command']


# Generated at 2022-06-22 00:07:57.313612
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.get('require_confirmation') == True
    assert settings.__setattr__('require_confirmation', False)
    assert settings.get('require_confirmation') == False
    assert settings.get('debug') == False
    assert settings.__setattr__('debug', True)
    assert settings.get('debug') == True
    assert settings.get('rules') == ('fuck', 'lazy', 'lol', 'man')
    settings.__setattr__('rules', ('fuck', 'lol'))
    assert settings.get('rules') == ('fuck', 'lol')
    assert settings.get('history_limit') == 500
    settings.__setattr__('history_limit', 1000)
    assert settings.get('history_limit') == 1000

# Generated at 2022-06-22 00:08:09.710749
# Unit test for method init of class Settings
def test_Settings_init():
    # pylint: disable=protected-access
    test_filename = __name__ + '.test_settings'
    test_settings_path = settings._get_user_dir_path().joinpath(test_filename)

    with test_settings_path.open(mode='w') as settings_file:
        settings_file.write(const.SETTINGS_HEADER)
        settings_file.write('require_confirmation = False')
    settings.init()
    assert not settings['require_confirmation']

    with test_settings_path.open(mode='w') as settings_file:
        settings_file.write(const.SETTINGS_HEADER)
        settings_file.write('require_confirmation = True')
    settings.init()
    assert settings['require_confirmation']

    test_settings_path.unlink()

# Generated at 2022-06-22 00:08:12.685130
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == False


# Generated at 2022-06-22 00:08:15.604098
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    # This is a test for method __getattr__ of class Settings
    has_attr = hasattr(settings, 'rules')
    assert has_attr



# Generated at 2022-06-22 00:08:20.006295
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('require_confirmation') == True
    settings['new_attr'] = 'new_attr'
    assert settings['new_attr'] == 'new_attr'
    assert settings.new_attr == 'new_attr'
    assert settings.get('not_existed_attr') == None

# Generated at 2022-06-22 00:08:22.149581
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings(const.DEFAULT_SETTINGS)
    assert isinstance(s, dict)
    assert s.get('wait_command') == 1


# Generated at 2022-06-22 00:08:24.210889
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings['priority']['fuck'] == 110
    assert settings['require_confirmation'] == True

# Generated at 2022-06-22 00:08:27.202332
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.get('require_confirmation') == \
        const.DEFAULT_SETTINGS['require_confirmation']
    settings.require_confirmation = False
    assert settings.get('require_confirmation') == False

# Generated at 2022-06-22 00:09:40.041104
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('require_confirmation') == True
    assert settings.get('num_close_matches') == 3
    assert settings.get('priority') == {'git': 100, '*': 0}
    assert settings.get('no_colors') == False
    assert settings.get('debug') == False
    assert settings.get('alter_history') == True

# Generated at 2022-06-22 00:09:52.071100
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules == const.DEFAULT_RULES
    assert settings.priority == const.DEFAULT_PRIORITY
    assert settings.wait_command == const.DEFAULT_WAIT_COMMAND
    assert settings.alter_history == const.DEFAULT_ALTER_HISTORY
    assert settings.wait_slow_command == const.DEFAULT_WAIT_SLOW_COMMAND
    assert settings.slow_commands == const.DEFAULT_SLOW_COMMANDS
    assert settings.history_limit == const.DEFAULT_HISTORY_LIMIT
    assert settings.no_colors == const.DEFAULT_NO_COLORS
    assert settings.require_confirmation == const.DEFAULT_REQUIRE_CONFIRMATION
    assert settings.num_close_matches == const.DEFAULT_NUM_CLOSE_MATCHES

# Generated at 2022-06-22 00:09:57.019474
# Unit test for constructor of class Settings
def test_Settings():
    local_settings = Settings(const.DEFAULT_SETTINGS)
    assert local_settings._get_user_dir_path() == Path("/home/tilatat/.config/thefuck")
    t = Settings(local_settings)
    assert t._get_user_dir_path() == Path("/home/tilatat/.config/thefuck")



# Generated at 2022-06-22 00:10:03.940373
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    """test_Settings___setattr__"""
    # __setattr__() should behave like a dictionary
    settings = Settings()
    settings.foo = 'bar'
    assert settings['foo'] == 'bar'
    assert settings.foo == 'bar'
    # del should work
    del settings.foo
    assert settings.get('foo', 'foo') == 'foo'
    assert settings.get('foo', None) is None



# Generated at 2022-06-22 00:10:12.132887
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from . import system
    from .logs import exception

    def check_exception(obj):
        with system.mock_sys_exc_info():
            exception("Can't load settings from file", sys.exc_info())
            assert not obj.exception

    obj = Settings()
    obj.exception = True
    obj.exception = False
    assert not obj.exception
    try:
        obj.exception
    except AttributeError:
        pass
    else:
        assert False, '"exception" exists in obj'

    obj.init()
    check_exception(obj)

# Generated at 2022-06-22 00:10:21.624793
# Unit test for constructor of class Settings
def test_Settings():
    assert const.DEFAULT_SETTINGS == {
        'alter_history': False,
        'no_colors': False,
        'exclude_rules': [],
        'rules': const.DEFAULT_RULES,
        'priority': {},
        'history_limit': None,
        'wait_slow_command': 15,
        'require_confirmation': True,
        'wait_command': 0,
        'debug': False,
        'repeat': False,
        'slow_commands': [],
        'num_close_matches': 3,
        'excluded_search_path_prefixes': [os.path.expanduser('~')]
    }



# Generated at 2022-06-22 00:10:24.766506
# Unit test for method init of class Settings
def test_Settings_init():
    """
    Тест для метода init класса Settings
    :return:
    """
    global settings
    settings.init()

# Generated at 2022-06-22 00:10:34.998449
# Unit test for constructor of class Settings
def test_Settings():
    # Test for Default Settings Value
    assert settings['require_confirmation'] == True
    assert settings['wait_command'] == 0.08
    assert settings['slow_commands'] == []
    assert settings['history_limit'] == 500
    assert settings['rules'] == []
    assert settings['exclude_rules'] == []
    assert settings['wait_slow_command'] == 15
    assert settings['priority'] == {}
    assert settings['alternative_cd'] == 'sudo !!'
    assert settings['no_colors'] == False
    assert settings['debug'] == False
    assert settings['excluded_search_path_prefixes'] == []
    assert settings['alter_history'] == True
    assert settings['instant_mode'] == False
    assert settings['num_close_matches'] == 3
    assert settings['repeat'] == 1
   

# Generated at 2022-06-22 00:10:44.549703
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import Log

    set_settings = Settings(const.DEFAULT_SETTINGS)
    set_settings.user_dir = Path(__file__).dirname().joinpath('..', 'test',
                                                              'test_settings')
    set_settings.init()
    assert set_settings['require_confirmation'] and \
           set_settings['wait_slow_command'] and \
           set_settings['wait_command'] and \
           set_settings['slow_commands'] and \
           set_settings['priority'] and \
           set_settings['history_limit'] and \
           set_settings['no_colors'] and \
           set_settings['alter_history'] and \
           set_settings['instant_mode'] and \
           set_settings['exclude_rules'] and \
           set_

# Generated at 2022-06-22 00:10:45.593482
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()


# Generated at 2022-06-22 00:12:22.149440
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import _exception

    class MockLogs(object):
        def __init__(self):
            self.exception_msg = ''

        def exception(self, msg, exc_info=None):
            self.exception_msg = msg

    logs = MockLogs()
    settings = Settings()
    settings._init_settings_file = lambda: None
    settings._settings_from_file = lambda: {'a': 1, 'b': 2}
    settings._settings_from_env = lambda: {'c': 3, 'd': 4}
    settings._settings_from_args = lambda *args: {'e': 5}
    settings._setup_user_dir = lambda: None

    with patch.object(_exception, 'exception', logs.exception):
        settings.init()

# Generated at 2022-06-22 00:12:25.044915
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    s.foo = 'bar'
    assert s['foo'] == 'bar'
    assert s.foo == 'bar'

# Generated at 2022-06-22 00:12:27.453827
# Unit test for constructor of class Settings
def test_Settings():
    from .system import Path
    from .logs import exception

    try:
        test = Settings()
        test.init()
    except Exception as e:
        exception("Settings constructor failed")
        return False
    return True

# Generated at 2022-06-22 00:12:29.946855
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.foo = 'bar'
    assert settings.get('foo') == 'bar'


# Generated at 2022-06-22 00:12:32.279521
# Unit test for constructor of class Settings
def test_Settings():
    load_settings = Settings(const.DEFAULT_SETTINGS)
    assert load_settings.require_confirmation
    assert load_settings.rules
    assert load_settings.slow_commands


# Generated at 2022-06-22 00:12:35.450837
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from thefuck.settings import Settings
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.test = 'test'
    assert(settings['test'] == 'test')


# Generated at 2022-06-22 00:12:36.716908
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    # assert settings is an empty dictionary
    assert settings == {}


# Generated at 2022-06-22 00:12:44.281785
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert(settings.get('require_confirmation'))
    settings.init(args=argparse.Namespace(yes=True))
    assert(settings.get('require_confirmation') == False)
    assert(settings.get('debug') == False)
    settings.init(args=argparse.Namespace(debug=True))
    assert(settings.get('debug') == True)
    settings.init(args=argparse.Namespace(repeat=1))
    assert(settings.get('repeat') == 1)

# Generated at 2022-06-22 00:12:46.052084
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings_ = Settings(const.DEFAULT_SETTINGS)
    settings_.key = 'value'
    assert settings_['key'] == 'value'


# Generated at 2022-06-22 00:12:47.754127
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.history_limit == 20
    settings.my_value = "my value"
    assert settings.my_value == "my value"

