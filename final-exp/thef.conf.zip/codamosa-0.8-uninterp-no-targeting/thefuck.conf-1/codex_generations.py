

# Generated at 2022-06-22 00:06:09.999053
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, dict)
    assert settings['require_confirmation'] == True

# Generated at 2022-06-22 00:06:13.602488
# Unit test for method init of class Settings
def test_Settings_init():
    args = MagicMock()
    settings.user_dir = None
    settings.__setitem__ = MagicMock()

    settings.init(args)

    settings.user_dir = None
    settings.__setitem__ = MagicMock()
    settings._init_settings_file = MagicMock(side_effect=Exception('Exception'))

    settings.init(args)

# Generated at 2022-06-22 00:06:15.355757
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.python == '/usr/bin/python'



# Generated at 2022-06-22 00:06:21.367848
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('repeat', False) == False
    assert settings.get('debug', False) == False
    assert settings.get('require_confirmation') == True
    assert settings.get('slow_commands') == ['sudo']
    assert settings.get('wait_slow_command') == 3
    assert settings.get('history_limit') == 5
    assert Settin

# Generated at 2022-06-22 00:06:33.140400
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import ERROR, exception
    from .system import get_all_exe_paths

    # when: init settings from thefuck/settings.py and env

# Generated at 2022-06-22 00:06:39.343379
# Unit test for method init of class Settings
def test_Settings_init():
    os.environ['THEFUCK_RULES'] = 'bash_history'
    os.environ['THEFUCK_WAIT_COMMAND'] = '5'
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'false'
    os.environ['THEFUCK_PRIORITY'] = 'bash_history=100'
    settings.init()
    assert 'require_confirmation' in settings
    assert not settings['require_confirmation']

# Generated at 2022-06-22 00:06:41.281721
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.attr = True
    assert settings['attr'] == True
    del settings.attr


# Generated at 2022-06-22 00:06:44.683599
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings({'foo': 'bar'})
    assert settings['foo'] == settings.foo
    assert not hasattr(settings, 'bar')


# Generated at 2022-06-22 00:06:46.939992
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings['rules'] == const.DEFAULT_SETTINGS['rules']
    settings.rules = []
    assert settings['rules'] == []



# Generated at 2022-06-22 00:06:54.634346
# Unit test for method init of class Settings
def test_Settings_init():
    args = type('_', (), {})()
    args.yes = False
    args.debug = False
    args.repeat = 1
    settings.init(args)
    assert settings['require_confirmation'] == const.REQUIRE_CONFIRMATION
    assert settings['require_slow_command'] == const.REQUIRE_SLOW_COMMAND
    assert settings['wait_command'] == const.WAIT_COMMAND
    assert settings['wait_slow_command'] == const.WAIT_SLOW_COMMAND
    assert settings['history_limit'] == const.HISTORY_LIMIT
    assert settings['priority'] == const.PRIORITY
    assert settings['exclude_rules'] == const.EXCLUDE_RULES
    assert settings['rules'] == const.RULES
    assert settings['no_colors']

# Generated at 2022-06-22 00:07:28.140570
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings({'a': 1})
    assert s.a == 1
    assert s['a'] == 1
    s.b = 2
    assert s.b == 2
    assert s['b'] == 2
    assert len(s) == 2
    assert [key for key in s] == ['a', 'b']
    s['b'] = 3
    assert s.b == 3
    assert s['b'] == 3
    del s.a
    assert len(s) == 1
    assert s.b == 3
    del s['b']
    assert len(s) == 0

# Generated at 2022-06-22 00:07:32.948821
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test_attr = 'test_attr_value'
    settings['test_attr2'] = 'test_attr_value2'

    assert settings['test_attr'] == settings.test_attr == 'test_attr_value'
    assert settings['test_attr2'] == 'test_attr_value2'


# Generated at 2022-06-22 00:07:44.602827
# Unit test for method init of class Settings
def test_Settings_init():
    # Load settings from file:
    assert settings.init()['require_confirmation'] is True
    settings.update({'require_confirmation': False})
    assert settings.init()['require_confirmation'] is False

    # Load settings from env:
    assert settings.init()['require_confirmation'] is False
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'True'
    assert settings.init()['require_confirmation'] is True
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'False'
    assert settings.init()['require_confirmation'] is False

    # Load settings from args:
    assert settings.init()['require_confirmation'] is False
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'True'

# Generated at 2022-06-22 00:07:47.359596
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    class Test(object):
        def __init__(self):
            self.settings = settings
    t = Test()
    assert t.settings.python == 'python'


# Generated at 2022-06-22 00:07:53.970424
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings['verbose'] == False
    assert settings['wait_command'] == 0
    assert settings['alias'] == 'fuck'
    assert settings['priority'] == {}
    assert settings['exclude_rules'] == []

    settings.init(args='--yes --repeat=2 --debug=2'.split(' '))
    assert settings['require_confirmation'] == False
    assert settings['repeat'] == '2'
    assert settings['debug'] == '2'


# Generated at 2022-06-22 00:08:00.295370
# Unit test for constructor of class Settings
def test_Settings():
    import json
    import os

    env_vars = {
        'thefuck_require_confirmation': 'False',
        'thefuck_alias': 'fuck',
        'thefuck_priority': 'f_script=5',
        'thefuck_rules': 'f_script:fuck',
        'thefuck_slow_commands': 'tox',
        'thefuck_wait_command': '10',
        'thefuck_no_colors': 'True',
        'thefuck_wait_slow_command': '5'
    }

    settings = Settings(const.DEFAULT_SETTINGS)
    for key, value in env_vars.items():
        os.environ[key] = value

    settings.init()
    assert settings.get('require_confirmation') == False
    assert settings.get('alias')

# Generated at 2022-06-22 00:08:10.777537
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import tempfile
    from shutil import rmtree
    from thefuck.settings import const as c
    from thefuck.settings import Settings

    tmp_dir = tempfile.mkdtemp()
    config_path = os.path.join(tmp_dir, 'thefuck')

    os.environ['XDG_CONFIG_HOME'] = tmp_dir
    settings = Settings()

    assert not os.path.exists(config_path)
    settings.init()
    assert not os.path.exists(os.path.join(config_path, 'settings.py'))
    settings._init_settings_file()
    assert os.path.exists(os.path.join(config_path, 'settings.py'))

# Generated at 2022-06-22 00:08:12.814270
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.z = 5
    assert settings['z'] == 5



# Generated at 2022-06-22 00:08:23.351060
# Unit test for method init of class Settings
def test_Settings_init():
    from .utils import import_module
    from .logs import exception as logs_exception
    from .system import Path
    import mock

    with mock.patch('__builtin__.open', mock.mock_open(), create=True) as m:
        mock_file = m.return_value.__enter__.return_value
        mock_file.read.return_value = const.SETTINGS_HEADER

        with mock.patch('os.environ') as env:
            env.get.return_value = '~/.config'
            args = import_module('argparse').Namespace(yes=True, debug=True, repeat=3)

            def side_effect(path):
                return path.startswith(Path('~/.config/thefuck/rules').expanduser())


# Generated at 2022-06-22 00:08:30.268137
# Unit test for method init of class Settings
def test_Settings_init():
    class Args:
        # pylint: disable=attribute-defined-outside-init
        def __init__(self, yes, repeat, debug):
            self.yes = yes
            self.repeat = repeat
            self.debug = debug

    # Pylint can't find __file__ in test methods
    # pylint: disable=invalid-name
    user_dir = Path(__file__).parent.joinpath('test').joinpath('config')

    # pylint: disable=no-member
    # pylint: disable=attribute-defined-outside-init
    with user_dir.joinpath('settings.py').open(mode='w') as settings_file:
        settings_file.write(const.SETTINGS_HEADER)
        for setting in const.DEFAULT_SETTINGS.items():
            settings_

# Generated at 2022-06-22 00:09:25.208626
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_data_dict = {
        'key': 'value',
        'key2': 'value2'
    }
    test_data_str = "str"
    test_data_int = 100
    test_data_list = ['a', 'b', 'c']
    test_data_tuple = (1, 2, 3)
    test_data_class = Settings
    Settings.test_dict = test_data_dict
    Settings.test_str = test_data_str
    Settings.test_int = test_data_int
    Settings.test_list = test_data_list
    Settings.test_tuple = test_data_tuple
    Settings.test_class = test_data_class
    assert Settings.get('test_dict') == test_data_dict
    assert Settings.get('test_str')

# Generated at 2022-06-22 00:09:26.157720
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation


# Generated at 2022-06-22 00:09:27.911965
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    s.name = 'The Fuck'
    assert s['name'] == 'The Fuck'



# Generated at 2022-06-22 00:09:30.529493
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    setting = Settings()
    setting.foo = 'bar'
    assert setting['foo'] == 'bar'



# Generated at 2022-06-22 00:09:41.448923
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import capture_exception
    from test.utils import CustomSettings

    settings = CustomSettings({'init': 'is called', 'a': 'b'})
    settings.update({'foo': 'bar'})
    settings.init()
    assert settings.init == 'is called'
    assert settings.user_dir
    assert settings.user_dir.endswith('/test')
    assert settings.a == 'b'
    assert settings.foo == 'bar'
    assert 'settings' in sys.modules
    assert sys.modules['settings']
    assert settings._settings_from_file() == {'a': 'b'}
    assert settings._settings_from_env() == {'foo': 'bar'}
    assert settings._settings_from_args(object) == {'init': 'is called'}


# Generated at 2022-06-22 00:09:50.784737
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('require_confirmation') == True
    assert settings.get('history_limit') == 10
    assert settings.get('wait_slow_command') == 15
    assert settings.get('slow_commands') == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant', 'docker']
    assert settings.get('excluded_search_path_prefixes') == ['/usr', '/Users/paul/', '/home/paul/']
    assert settings.get('num_close_matches') == 3


# Generated at 2022-06-22 00:09:58.087247
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.user_dir.startswith('~/.config/thefuck')
    assert settings.require_confirmation == True

    min_similarity = const.DEFAULT_SETTINGS['min_similarity']
    assert settings.min_similarity == min_similarity

    alter_history = const.DEFAULT_SETTINGS['alter_history']
    assert settings.alter_history == alter_history

    priority = const.DEFAULT_SETTINGS['priority']
    assert settings.priority == priority

    rules = const.DEFAULT_SETTINGS['rules']
    assert settings.rules == rules



# Generated at 2022-06-22 00:10:08.559726
# Unit test for constructor of class Settings
def test_Settings():
    class Settings(dict):
        def __init__(self):
            self.update(const.DEFAULT_SETTINGS)

        def __getattr__(self, item):
            return self.get(item)

        def __setattr__(self, key, value):
            self[key] = value

    class Args(object):
        def __init__(self, yes=False, debug=False, repeat='0'):
            self.yes = yes
            self.debug = debug
            self.repeat = repeat

    settings.init()
    assert settings.get_priority('cd') == 1
    assert settings.require_confirmation
    assert settings.rules == const.DEFAULT_RULES
    assert settings.repeat == 0
    assert not settings.debug
    assert not settings.alter_history


# Generated at 2022-06-22 00:10:09.994489
# Unit test for constructor of class Settings
def test_Settings():
    assert settings == const.DEFAULT_SETTINGS



# Generated at 2022-06-22 00:10:11.980310
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.test = 1
    assert settings['test'] == 1

# Generated at 2022-06-22 00:12:27.316161
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.init()
    settings.username = 'test'
    assert settings['username'] == 'test'



# Generated at 2022-06-22 00:12:30.961352
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings({"foo": "bar"})
    settings.foo = "spam"
    assert settings.foo == 'spam'
    settings.ham = "eggs"
    assert settings.ham == 'eggs'


# Generated at 2022-06-22 00:12:37.161141
# Unit test for method init of class Settings
def test_Settings_init():
    try:
        args = argparse.ArgumentParser()
        args.add_argument('--yes', action='store_true')
        args.add_argument('--debug', action='store_true')
        args.add_argument('--repeat', type=int)
        args = args.parse_args()

        settings.init(args)
        assert settings.require_confirmation == True
        assert settings.debug == True
        assert settings.repeat == 1
    finally:
        settings.require_confirmation = False
        settings.debug = False
        settings.repeat = None

# Generated at 2022-06-22 00:12:42.774643
# Unit test for constructor of class Settings
def test_Settings():
    from .logs import log_transport
    assert log_transport.get_queued_logs() == []
    settings_test = Settings(const.DEFAULT_SETTINGS)
    assert log_transport.get_queued_logs() == []
    assert settings_test.get('priority') == {'fuck': 100}
    assert settings_test.get('debug') == False

# Generated at 2022-06-22 00:12:44.132857
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation


# Generated at 2022-06-22 00:12:50.049470
# Unit test for method init of class Settings
def test_Settings_init():
    # When the directory does not exist
    no_dir = '/tmp/thefuck/'
    # When the settings file does not exist
    no_file = '/tmp/thefuck/settings.py'
    # When the settings file exist
    file = '/tmp/thefuck/settings.py'

    def _init_settings_file():
        settings_path = Path(file).expanduser()
        if not settings_path.is_file():
            with settings_path.open(mode='w') as settings_file:
                settings_file.write(const.SETTINGS_HEADER)
                for setting in const.DEFAULT_SETTINGS.items():
                    settings_file.write(u'# {} = {}\n'.format(*setting))

    # 1. When the directory does not exist, then create the directory.
    settings.init

# Generated at 2022-06-22 00:12:54.626277
# Unit test for method init of class Settings
def test_Settings_init():
    from argparse import Namespace

    settings.init(None)
    assert 'require_confirmation' in settings
    assert 'history_limit' in settings

    assert settings['require_confirmation'] == const.DEFAULT_SETTINGS['require_confirmation']
    assert settings['history_limit'] == const.DEFAULT_SETTINGS['history_limit']



# Generated at 2022-06-22 00:12:55.795168
# Unit test for constructor of class Settings
def test_Settings():
    assert settings == const.DEFAULT_SETTINGS


# Generated at 2022-06-22 00:13:05.121605
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import _log_exception
    from mock import patch, MagicMock
    from pytest import raises
    from six.moves import reload_module
    import thefuck.settings

    def reload_thefuck():
        reload_module(thefuck.settings)
        return thefuck.settings.settings

    def set_os_environ(**kwargs):
        os.environ.clear()
        os.environ.update(kwargs)

    def set_arg_parser_args(**kwargs):
        mocked_parser = MagicMock()
        mocked_parser.configure_mock(**kwargs)
        return mocked_parser

    def create_settings():
        return Settings(
            {key: 'DEFAULT' for key in const.DEFAULT_SETTINGS})


# Generated at 2022-06-22 00:13:06.190128
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = 42
    assert settings.get('test') == 42