

# Generated at 2022-06-22 00:06:27.300667
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_var = Settings()
    test_var.__setattr__('test', 'test')
    assert test_var['test'] == 'test'


# Generated at 2022-06-22 00:06:30.295006
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.get('no_colors') is True

    settings.no_colors = False
    assert settings.get('no_colors') is False

# Generated at 2022-06-22 00:06:32.142765
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.init()
    assert settings.prefix == 'fuck'
    assert settings.require_confirmation

# Generated at 2022-06-22 00:06:37.056116
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['require_confirmation'] is True
    assert settings['repeat'] is False
    assert settings['history_limit'] == None
    assert settings['exclude_rules'] == []
    assert settings['alias'] == 'fuck'
    assert settings['priority'] == {}
    assert settings['wait_command'] == 3
    assert settings['wait_slow_command'] == 1
    assert settings['num_close_matches'] == 3
    assert settings['alter_history'] is True
    assert settings['instant_mode'] is False
    assert settings['slow_commands'] == ['lein', 'react-native', 'gradle', './gradlew', 'android', 'flutter']
    assert settings['excluded_search_path_prefixes'] == []
    assert settings['no_colors'] is False
    assert settings['debug'] is False

# Generated at 2022-06-22 00:06:38.504714
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test_attr = True
    assert settings.test_attr

# Generated at 2022-06-22 00:06:49.314592
# Unit test for method init of class Settings
def test_Settings_init():
    import sys
    import os
    import thefuck

    os.environ['THEFUCK_DEBUG'] = 'True'
    os.environ['THEFUCK_EXCLUDE_RULES'] = 'DEFAULT_RULES:git_push_current_branch'
    os.environ['THEFUCK_PRIORITY'] = 'git_push_current_branch=20:git_add_and_push=40:git_new_branch=10'
    args = thefuck.config.get_argparser().parse_args(['--yes'])
    settings.init(args)

# Generated at 2022-06-22 00:06:51.517698
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir.joinpath('settings.py').is_file()
    settings.user_dir.rmtree()


# Generated at 2022-06-22 00:06:54.107769
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    '''
    Test for method getattr of class Settings
    :return:
    '''
    # Test getattr with wrong key
    assert settings.wrong_key is None

    # Test getattr with right key
    assert settings.confirm_command == True


# Generated at 2022-06-22 00:06:56.080400
# Unit test for constructor of class Settings
def test_Settings():
    assert settings == const.DEFAULT_SETTINGS

###
# User config section
###



# Generated at 2022-06-22 00:06:57.469023
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings(fail=True)
    assert settings.fail

# Generated at 2022-06-22 00:07:32.174569
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert settings._raw_prefix == 'sudo !!'
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.repeat == 1
    assert settings.wait_command == 15
    assert settings.wait_slow_command == 1
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.priority == {}
    assert settings.history_limit == 1000
    assert settings.rules == []
    assert settings.num_close_matches == 3
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.rules_path == ['~/.config/thefuck/rules']



# Generated at 2022-06-22 00:07:43.143851
# Unit test for constructor of class Settings
def test_Settings():
	settings.init()
	assert settings['require_confirmation'] == True
	assert settings['no_colors'] == False
	assert settings['debug'] == False
	assert settings['alter_history'] == True
	assert settings['instant_mode'] == False
	assert settings['wait_command'] == 3
	assert settings['history_limit'] == 10
	assert settings['wait_slow_command'] == 3
	assert settings['priority'] == {}
	assert settings['num_close_matches'] == 3
	assert settings['slow_commands'] == ['lein', 'gradle', 'rake', 'eslint', 'gradlew', 'tsc', 'ionic', 'react-scripts', 'emacs', 'jekyll', 'watch', 'subl', 'bundle']
	assert settings['exclude_rules'] == []

# Generated at 2022-06-22 00:07:45.595872
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.key = 'value'
    assert settings['key'] == 'value'


# Generated at 2022-06-22 00:07:53.487598
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.alter_history == True
    assert settings.priority == {}
    assert settings.no_colors == False
    assert settings.slow_commands == []
    assert settings.wait_command == 0
    assert settings.wait_slow_command == 3
    assert settings.rules == []
    assert settings.require_confirmation == True
    assert settings.history_limit == None
    assert settings.num_close_matches == 3
    assert settings.instant_mode == False
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []



# Generated at 2022-06-22 00:07:55.409012
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert getattr(settings,'require_confirmation') == True

# Generated at 2022-06-22 00:08:05.209209
# Unit test for constructor of class Settings
def test_Settings():
    from .config import Settings
    from .logs import enable_log, set_log_level
    from .const import DEFAULT_SETTINGS, DEFAULT_PRIORITY

    settings = Settings(DEFAULT_SETTINGS)
    # settings.init()
    enable_log('/tmp/t.log')
    set_log_level('DEBUG')
    settings.init()
    assert settings.user_dir == settings._get_user_dir_path()
    assert settings.priority == DEFAULT_PRIORITY
    assert settings.priority == settings.get('priority')

# Generated at 2022-06-22 00:08:06.829615
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.key = 'value'
    assert settings['key'] == 'value'


# Generated at 2022-06-22 00:08:08.265735
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings()
    settings.a = 1
    assert settings.a == 1



# Generated at 2022-06-22 00:08:14.740801
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings['require_confirmation'] == True
    assert settings['aliases'] == {}

# Generated at 2022-06-22 00:08:17.395799
# Unit test for constructor of class Settings
def test_Settings():
    c = Settings()
    assert c.get('alter_history') == False
    assert c.get('require_confirmation') == True
    assert c.get('slow_commands') == []

# Generated at 2022-06-22 00:09:25.777327
# Unit test for constructor of class Settings
def test_Settings():

    quit_type = type(quit)  # pylint: disable=undefined-variable
    builtin_quit = quit  # pylint: disable=undefined-variable
    settings = Settings(const.DEFAULT_SETTINGS)

    assert settings['wait_command'] == 3
    assert settings['wait_slow_command'] == 5
    assert settings['require_confirmation'] is True
    assert settings['no_colors'] is False
    assert settings['priority'] == {}
    assert settings['history_limit'] == None
    assert settings['debug'] is False
    assert settings['alter_history'] is False
    assert settings['repeat'] is False
    assert settings['exclude_rules'] == []
    assert settings['exclude_commands'] == []
    assert settings['instant_mode'] is False

# Generated at 2022-06-22 00:09:27.260201
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings({"a": 1})
    assert settings.a == 1


# Generated at 2022-06-22 00:09:30.248951
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test_a = 1
    assert settings['test_a'] == 1
    settings['test_b'] = 2
    assert settings.get('test_b') == 2
    assert hasattr(settings, 'test_b')
    delattr(settings, 'test_b')
    assert not hasattr(settings, 'test_b')


# Generated at 2022-06-22 00:09:41.198389
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    from .system import TemporaryDirectory

    settings = Settings(const.DEFAULT_SETTINGS)
    args = type('', (object, ), {'debug': True, 'yes': True})()

    with TemporaryDirectory() as tmp_dir:
        user_dir_path = tmp_dir.joinpath('thefuck')
        os.makedirs(user_dir_path)
        settings_file = user_dir_path.joinpath('settings.py')

        with settings_file.open(mode='w') as settings_file_opened:
            settings_file_opened.write(const.SETTINGS_HEADER)
            settings_file_opened.write('# require_confirmation = True\n')
            settings_file_opened.write('# alter_history = False\n')

# Generated at 2022-06-22 00:09:42.858055
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.key = 'value'
    assert settings.get('key') == 'value'

# Generated at 2022-06-22 00:09:54.315110
# Unit test for method init of class Settings
def test_Settings_init():
    args = ['arg1', 'arg2']
    settings = Settings(const.DEFAULT_SETTINGS)
    settings._get_user_dir_path = lambda: Path('/home/user')
    settings._init_settings_file = lambda: None
    settings._settings_from_file = lambda: {'key1': 'value1'}
    settings._settings_from_env = lambda: {'key2': 'value2'}
    settings._settings_from_args = lambda: {'key3': 'value3'}
    settings.init()
    assert settings.get('key1') == 'value1'
    assert settings.get('key2') == 'value2'
    assert settings.get('key3') == 'value3'

# Generated at 2022-06-22 00:09:57.304905
# Unit test for method init of class Settings
def test_Settings_init():
    args = Mock()
    settings.init(args)


# Generated at 2022-06-22 00:10:01.247362
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class A(object):
        pass
    a = A()
    settings.__setattr__('a', a)
    assert settings.get('a') == a

# Generated at 2022-06-22 00:10:03.420111
# Unit test for constructor of class Settings
def test_Settings():
    settings['awesome_factory'] = 'awesome'
    settings.init()

    assert settings['awesome_factory'] == 'awesome'

# Generated at 2022-06-22 00:10:04.916643
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.test_attr = 42
    assert(settings.test_attr == 42)


# Generated at 2022-06-22 00:12:37.193432
# Unit test for constructor of class Settings
def test_Settings():
    settings.init()

    assert(settings['history_limit'] == 100)
    assert(settings['no_colors'] == False)
    assert(settings['require_confirmation'] == True)
    assert(settings['instant_mode'] == False)
    assert(settings['slow_commands'] == [u'sudo', u'git'])
    assert(settings['alter_history'] == False)
    assert(settings['sudo_safe'] == False)

# Generated at 2022-06-22 00:12:39.985637
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert not settings.no_colors



# Generated at 2022-06-22 00:12:41.804946
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.verbose == True
    settings.verbose = False
    assert settings.verbose == False


# Generated at 2022-06-22 00:12:44.350150
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']


# Generated at 2022-06-22 00:12:47.126290
# Unit test for constructor of class Settings
def test_Settings():
    # Settings's constructor is deprecated(in Python3), so it'll not have
    # attributes that can be passed by parameters.
    settings = Settings()
    keys = settings.keys()
    assert 'require_confirmation' in keys
    assert 'history_limit' in keys
    assert 'alter_history' in keys

# Generated at 2022-06-22 00:12:51.586964
# Unit test for constructor of class Settings
def test_Settings():
    def init_settings(args):
        settings.init(args)
        return settings

    from itertools import chain
    from .logs import _captured_logs

    assert init_settings(None) == const.DEFAULT_SETTINGS
    assert init_settings({'require_confirmation': False})\
        == dict(chain(const.DEFAULT_SETTINGS.items(),
                      [('require_confirmation', False)]))


# Generated at 2022-06-22 00:12:53.390290
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings()
    settings.foo = 'bar'
    assert settings.foo == 'bar'


# Generated at 2022-06-22 00:13:02.317857
# Unit test for method init of class Settings
def test_Settings_init():
    import sys
    from mock import patch, Mock
    from pytest import raises
    import thefuck.settings
    from thefuck.settings import Settings
    from thefuck.settings import const


    _sys_argv = sys.argv
    sys.argv = []

    thefuck.settings.settings = Settings(const.DEFAULT_SETTINGS)

    check = thefuck.settings.settings.init

    with patch('os.environ', {'TF_REQUIRE_CONFIRMATION': 'True'}):
        check()
        assert 'require_confirmation' in thefuck.settings.settings
        assert thefuck.settings.settings['require_confirmation']
        assert 'repeat' not in thefuck.settings.settings


# Generated at 2022-06-22 00:13:13.225227
# Unit test for method init of class Settings
def test_Settings_init():
    from .test import reset_settings
    reset_settings()
    settings.init()

    from .logs import debug
    from .logs import warning
    from .logs import error
    from .logs import exception
    from .logs import log_file

    assert settings.__getattr__('use_standard_logging') == True

    assert settings.__getattr__('require_confirmation') == False
    assert settings.__getattr__('no_colors') == False
    assert settings.__getattr__('alter_history') == True
    assert settings.__getattr__('wait_slow_command') == 10
    assert settings.__getattr__('wait_command') == 1
    assert settings.__getattr__('history_limit') == None
    assert settings.__getattr__('repeat') == None
    assert settings

# Generated at 2022-06-22 00:13:15.453469
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    d = Settings()
    d.foo = 'bar'
    assert d['foo'] == 'bar'
