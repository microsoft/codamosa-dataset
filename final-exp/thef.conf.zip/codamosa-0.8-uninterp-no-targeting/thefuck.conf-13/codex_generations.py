

# Generated at 2022-06-22 00:06:15.064063
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('require_confirmation') == True
    assert settings.get('rules') == const.DEFAULT_RULES
    assert settings.get('exclude_rules') == []
    assert settings.get('priority') == {}
    assert settings.get('wait_command') == 3
    assert settings.get('history_limit') == 10
    assert settings.get('wait_slow_command') == 10
    assert settings.get('no_colors') == False
    assert settings.get('alter_history') == False
    assert settings.get('debug') == False
    assert settings.get('slow_commands') == ['lein', 'gradle', './gradlew']
    assert settings.get('excluded_search_path_prefixes') == []
    assert settings.get('repeat') == False

# Generated at 2022-06-22 00:06:26.151533
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    user_dir = settings._get_user_dir_path()
    settings.init()
    assert settings['require_confirmation'] is True
    assert settings['history_limit'] is None
    assert settings['wait_command'] == 0
    assert settings['repeat'] is False
    assert settings['wait_slow_command'] == 1
    assert settings['no_colors'] is False
    assert settings['alter_history'] is True
    assert settings['instant_mode'] is False
    assert settings['num_close_matches'] == 3
    assert settings['slow_commands'] == ['lol', 'sss']
    assert settings['exclude_rules'] == ['git_push']
    assert settings['excluded_search_path_prefixes'] == []

# Generated at 2022-06-22 00:06:38.053206
# Unit test for method init of class Settings
def test_Settings_init():
    import platform
    from .system import Path

    if platform.system() == 'Darwin':
        home = '~'
    else:
        home = '~root'

# Generated at 2022-06-22 00:06:39.772114
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.banana = 42
    assert settings["banana"] == 42
    assert settings.banana == 42

# Generated at 2022-06-22 00:06:40.785674
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings.require_confirmation, bool)

# Generated at 2022-06-22 00:06:51.322901
# Unit test for constructor of class Settings
def test_Settings():
    from .logs import log

    if not settings.user_dir.joinpath('settings.py').is_file():
        raise Exception('Can not find settings.py')

    settings.debug = True
    log('debug = {}', settings.debug)
    assert settings.debug

    settings.debug = False
    assert not settings.debug
    log('debug = {}', settings.debug)

    settings.rules = ['fuck3', 'fuck4']
    log('rules = {}', settings.rules)
    assert settings.rules == ['fuck3', 'fuck4']

    settings.rules = ['fuck1', 'fuck2']
    log('rules = {}', settings.rules)
    assert settings.rules == ['fuck1', 'fuck2']

    settings.history_limit = 10
    log('history_limit = {}', settings.history_limit)


# Generated at 2022-06-22 00:06:52.856904
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings["test"] = "test"
    assert settings["test"] == "test"


# Generated at 2022-06-22 00:06:56.176114
# Unit test for constructor of class Settings
def test_Settings():
    default_settings = dict(const.DEFAULT_SETTINGS)
    test_settings = Settings(default_settings)
    assert test_settings is not None

# Generated at 2022-06-22 00:06:57.937199
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = 'setattr'
    assert settings['test'] == 'setattr'


# Generated at 2022-06-22 00:07:08.378043
# Unit test for method init of class Settings
def test_Settings_init():
    argv = ['thefuck', '--yes', '--debug', '--repeat', '5']
    settings.init(args=argparse.Namespace(yes=True, debug=True, repeat=5))
    assert not settings.require_confirmation
    assert settings.debug
    assert settings.repeat == 5
    argv = ['thefuck', '--yes', '--repeat', '5']
    settings.init(args=argparse.Namespace(yes=True, repeat=5))
    assert not settings.require_confirmation
    assert not settings.debug
    assert settings.repeat == 5
    argv = ['thefuck', '--repeat', '5']
    settings.init(args=argparse.Namespace(repeat=5))
    assert settings.require_confirmation
    assert not settings.debug
    assert settings.repeat == 5

# Generated at 2022-06-22 00:07:38.395229
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['require_confirmation']
    assert settings['alter_history']
    assert settings['no_colors']
    assert settings['history_limit'] == 0
    assert settings['num_close_matches'] == 3
    assert settings['wait_command'] == 1
    assert settings['wait_slow_command'] == 15
    assert settings['rules'] == ['git_push', 'git_add_and_commit', 'pip_install']
    assert settings['exclude_rules'] == []
    assert settings['priority'] == {}



# Generated at 2022-06-22 00:07:40.129953
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.alias == 'fuck'


# Generated at 2022-06-22 00:07:42.984614
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings(const.DEFAULT_SETTINGS)
    assert(s == const.DEFAULT_SETTINGS)
    assert(s.history_limit == 10)

# Generated at 2022-06-22 00:07:46.287408
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.keys() == const.DEFAULT_SETTINGS.keys()



# Generated at 2022-06-22 00:07:52.174632
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get_all_executables == []
    assert settings.require_confirmation

    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.get_all_executables == []
    assert settings.require_confirmation

    settings = Settings({'get_all_executables': ['ls']})
    assert settings.get_all_executables == ['ls']
    assert settings.require_confirmation


# Generated at 2022-06-22 00:07:56.050504
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    from .logs import exception

    assert settings.no_colors
    assert not settings.alter_history
    assert settings.debug
    assert settings.alter_history is False
    assert settings.foo is None

    settings.foo = 'bar'
    assert settings.foo == 'bar'



# Generated at 2022-06-22 00:08:08.121773
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['exclude_rules'] == const.DEFAULT_EXCLUDE_RULES
    assert settings['priority'] == {}
    assert settings['require_confirmation'] == True
    assert settings['wait_command'] == 0
    assert settings['slow_commands'] == []
    assert settings['history_limit'] == None
    assert settings['wait_slow_command'] == 15
    assert settings['no_colors'] == False
    assert settings['debug'] == False
    assert settings['excluded_search_path_prefixes'] == []
    assert settings['alter_history'] == False
    assert settings['instant_mode'] == False
    assert settings['num_close_matches'] == 3

    from mock import patch

# Generated at 2022-06-22 00:08:10.913524
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert settings.no_colors
    assert settings.wait_command == 5
    assert settings.rules == const.DEFAULT_RULES

# Generated at 2022-06-22 00:08:13.578749
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.require_confirmation == True
    settings.require_confirmation = False
    assert settings.require_confirmation == False

# Generated at 2022-06-22 00:08:14.565086
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation



# Generated at 2022-06-22 00:08:45.617708
# Unit test for method init of class Settings
def test_Settings_init():
    class MockArgs:
        def __init__(self, yes, debug, repeat):
            self.yes, self.debug, self.repeat = yes, debug, repeat

    # Without any settings
    settings.init()
    assert settings['require_confirmation'] == True
    assert settings['debug'] == False
    assert settings['repeat'] == False

    # Override settings
    settings.init(MockArgs(yes=True, debug=True, repeat=True))
    assert settings['require_confirmation'] == False
    assert settings['debug'] == True
    assert settings['repeat'] == True

# Generated at 2022-06-22 00:08:53.749979
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == False
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.instant_mode == False
    assert settings.alter_history == False
    assert settings.wait_command == 3
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.excluded_search_path_prefixes == []
    assert settings.no_colors == False
    assert settings.num_close_matches == 3


# Generated at 2022-06-22 00:08:57.200497
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 3
    assert settings.num_close_matches == 3
    assert settings.rules == ['fuck']
    assert settings.priority == {'ls': 1, 'cd': 1, 'mkdir': 1}


# Generated at 2022-06-22 00:08:59.229797
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.exclude_rules == ['git', 'ls', 'cd']


# Generated at 2022-06-22 00:09:11.282799
# Unit test for constructor of class Settings
def test_Settings():
    from .logs import log

    # an artificial exception
    class ArtificalError(Exception):
        pass

    import sys
    sys.path.append('.')

    settings = Settings()
    settings.init()
    settings.update({'require_confirmation':None, 'git_log':None})
    log(settings.get('require_confirmation'))
    log(settings.get('git_log'))

    settings.update({'require_confirmation':None, 'git_log':None})
    log(settings.get('require_confirmation'))
    log(settings.get('git_log'))

    settings.update({'require_confirmation':None, 'git_log':None})
    log(settings.get('require_confirmation'))
    log(settings.get('git_log'))

    settings

# Generated at 2022-06-22 00:09:13.997592
# Unit test for method init of class Settings
def test_Settings_init():  # noqa
    from .logs import debug, reset_logging
    reset_logging()
    settings.init()
    assert 'require_confirmation' in settings
    assert 'no_colors' in settings
    debug("Settings loaded from %s", settings.user_dir)

# Generated at 2022-06-22 00:09:19.005438
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    """
    Test case for method __setattr__ of class Settings.
    """
    import json
    import copy
    settings_origin = copy.deepcopy(settings)
    settings.foo = 'bar'
    assert settings == json.loads(json.dumps(settings_origin))
    assert settings.foo == 'bar'



# Generated at 2022-06-22 00:09:21.294165
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    args = type('', (), {})
    settings.user_dir = Path('~/.thefuck')

    settings.init(args)
    assert settings['rules'] == const.DEFAULT_RULES

# Generated at 2022-06-22 00:09:22.394247
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings["key"] = "value"
    assert settings["key"] == "value"
    assert settings.key == "value"

# Generated at 2022-06-22 00:09:30.537259
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch

    args = type('args', (object,), {'yes': False, 'debug': False, 'repeat': False})()

    with patch('thefuck.settings.Settings._settings_from_file') as \
            mock_settings_from_file, \
            patch('thefuck.settings.Settings._settings_from_env') as \
            mock_settings_from_env, \
            patch('thefuck.settings.Settings._settings_from_args') as \
            mock_settings_from_args:
        mock_settings_from_file.return_value = {'key': 'value'}
        mock_settings_from_env.return_value = {'key1': 'value1'}
        mock_settings_from_args.return_value = {'key2': 'value2'}

        settings.init

# Generated at 2022-06-22 00:09:59.252536
# Unit test for constructor of class Settings
def test_Settings():
    for attr in const.DEFAULT_SETTINGS.keys():
        assert getattr(settings, attr, None) == const.DEFAULT_SETTINGS[attr]


# Generated at 2022-06-22 00:10:01.628420
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    obj=Settings()
    obj.testAttr=5
    assert obj['testAttr']==5


# Generated at 2022-06-22 00:10:03.729195
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings['require_confirmation'] == True
    settings.require_confirmation = False
    assert settings['require_confirmation'] == False


# Generated at 2022-06-22 00:10:07.881686
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    """Unit test for method __setattr__ of class Settings"""
    try:
        setattr(settings, 'key', 5)
    except Exception:
        assert False
    if settings['key'] != 5:
        assert False
    if settings.key != 5:
        assert False



# Generated at 2022-06-22 00:10:09.735394
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.no_colors
    assert settings.require_confirmation
    assert settings.priority == const.DEFAULT_PRIORITY


# Generated at 2022-06-22 00:10:15.106896
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.rules == ['git_push', 'git_commit', 'git_merge',
                              'git_checkout', 'git_reset', 'heroku_run',
                              'sudo', 'command', 'python_command']
    settings.init(ArgumentParser().parse_args(['--yes']))
    assert not settings.require_confirmation

# Generated at 2022-06-22 00:10:22.263565
# Unit test for method init of class Settings
def test_Settings_init():
    global settings

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init(Namespace(yes=True, debug=True, repeat=1))
    assert settings['require_confirmation'] == False
    assert settings['debug'] == True
    assert settings['repeat'] == 1



# Generated at 2022-06-22 00:10:33.216949
# Unit test for method init of class Settings
def test_Settings_init():
    """Unit test for method init of class Settings"""

    from .logs import exception

    def mock_exception(msg, exc_info):
        exception.called = True
        exception.msg = msg
        exception.exc_info = exc_info

    def mock_init_settings_file():
        settings._init_settings_file.called = True

    def mock_get_user_dir_path():
        settings._get_user_dir_path.called = True
        return 'mock user dir path'

    def mock_setup_user_dir():
        settings._setup_user_dir.called = True

    def mock_settings_from_file():
        settings._settings_from_file.called = True
        return {'test1': 1, 'test2': 2}

    def mock_settings_from_env():
        settings._

# Generated at 2022-06-22 00:10:34.636431
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    foo = Settings()
    foo.hello = 'world'
    assert foo['hello'] == 'world'



# Generated at 2022-06-22 00:10:36.017870
# Unit test for constructor of class Settings
def test_Settings():
    """Unit test for constructor of class Settings"""
    s = Settings()
    assert s == const.DEFAULT_SETTINGS

# Generated at 2022-06-22 00:11:33.717498
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()



# Generated at 2022-06-22 00:11:35.075117
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    s.test = 'test'
    assert s['test'] == 'test'

# Generated at 2022-06-22 00:11:37.151134
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.test_a = 'A'
    assert settings.test_a == 'A'
    assert settings['test_a'] == 'A'


# Generated at 2022-06-22 00:11:48.700875
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import setup_log
    from .system import Path

    settings._setup_user_dir = lambda : Path('debug_dir')
    try:
        settings.init()
    except Exception as e:
        assert False, "Threw an exception"
    assert settings.wait_command == 3, \
        'Default settings.wait_command should be 3. Is %s' % settings.wait_command
    assert settings.alter_history == True, \
        'Default settings.alter_history should be True. Is %s' % settings.alter_history
    assert settings.wait_slow_command == 9, \
        'Default settings.wait_slow_command should be 9. Is %s' % settings.wait_slow_command
    settings.init(argparse.Namespace(debug=3))

# Generated at 2022-06-22 00:11:50.005023
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.test = 'test'
    assert settings['test'] == 'test'


# Generated at 2022-06-22 00:11:52.458696
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = 'test'
    assert settings.test == 'test'


# Generated at 2022-06-22 00:11:53.500796
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir is not None

# Generated at 2022-06-22 00:12:03.263137
# Unit test for method init of class Settings
def test_Settings_init():
    def _load_settings(val):
        settings_file = Path(val)
        settings_file.open('w').close()
        settings.init()
        settings_file.unlink()

    _load_settings('settings.py')
    _load_settings('settings.pyc')
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'True'
    settings.init()
    entry = settings.get('require_confirmation')
    assert entry == True

    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'False'
    settings.init()
    entry = settings.get('require_confirmation')
    assert entry == False

    os.environ['THEFUCK_PRIORITY'] = 'fasd_cd=1:fasd=2'
    settings

# Generated at 2022-06-22 00:12:04.672820
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    _settings = Settings(a=1)
    assert _settings.a == 1


# Generated at 2022-06-22 00:12:09.153084
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings['require_confirmation'] == True
    assert settings['slow_commands'] == ['lein', 'gradle', './gradlew', 'rebar3', 'go', 'gb']
    assert settings['instant_mode'] == False
    assert settings['history_limit'] == None


# Generated at 2022-06-22 00:14:43.907313
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.require_confirmation
    settings.require_confirmation = False
    assert settings.require_confirmation == False



# Generated at 2022-06-22 00:14:45.255596
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.test_1 = 1
    assert settings.test_1 == 1



# Generated at 2022-06-22 00:14:48.246238
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.test = 'test'
    assert settings['test'] == settings.test
    assert settings['test'] == 'test'


# Generated at 2022-06-22 00:14:54.600517
# Unit test for method init of class Settings
def test_Settings_init():
    """
    # Settings class should fill settings variable with values from file
    """
    global settings
    settings = Settings()
    settings.init()
    assert settings.__attrs__ == const.DEFAULT_SETTINGS.keys()
    assert settings.__getattr__('history_limit') == 500
    assert settings.__getattr__('rules') == const.DEFAULT_RULES
    from thefuck.logs import LOGS
    assert settings.__getattr__('logs') == LOGS
test_Settings_init()

# Generated at 2022-06-22 00:15:01.514522
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .match import get_closest
    from .rule import get_all_rules as get_all
    from .types import Settings
    from .notify import notify

    settings.init()

    assert type(settings.user_dir) == Path
    assert settings.user_dir.is_dir()
    assert type(settings.get_all_rules()) == list
    assert settings.get_all_rules() is get_all()
    assert settings.is_debug() is True
    assert settings.alter_history() is False
    assert settings.get_priority() == {}
    assert settings.require_confirmation() is False
    assert settings.exclude_rules() == []
    assert settings.no_colors() is False

# Generated at 2022-06-22 00:15:03.891925
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == True
    assert settings.wait_command == 5


# Generated at 2022-06-22 00:15:05.767080
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.init()
    assert settings.init(args=None)


# Generated at 2022-06-22 00:15:11.837203
# Unit test for method __setattr__ of class Settings

# Generated at 2022-06-22 00:15:17.242580
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.user_dir.endswith(u'~/.config/thefuck')
    assert settings.user_dir.is_dir()
    assert settings.settings_path.endswith('.config/thefuck/settings.py')
    settings.init()
    assert settings.rules

# Generated at 2022-06-22 00:15:29.394422
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.require_confirmation is True
    assert settings.wait_slow_command == 3
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == const.DEFAULT_EXCLUDED_SEARCH_PATH_PREFIXES
    assert settings.no_colors is False
    assert settings.debug is False
    assert settings.alter_history is True
    assert settings.instant_mode is False
    assert settings.num_close_matches is 3