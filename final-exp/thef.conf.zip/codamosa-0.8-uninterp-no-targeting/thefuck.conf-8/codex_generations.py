

# Generated at 2022-06-22 00:06:09.949522
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.init()
    assert settings.require_confirmation is True

# Generated at 2022-06-22 00:06:11.744481
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = 'test'
    assert settings.test == 'test'


# Generated at 2022-06-22 00:06:14.458079
# Unit test for method init of class Settings
def test_Settings_init():
    print('Started')
    from .logs import capture_logs, log_to_stderr

    with log_to_stderr(), capture_logs() as logs:
        settings.init(args=None)
    print('FINISHED')

# Generated at 2022-06-22 00:06:25.815035
# Unit test for method init of class Settings
def test_Settings_init():
    import time
    settings.init(args=None)
    assert settings.no_colors is True
    assert settings.require_confirmation is True
    assert settings.history_limit == 8
    assert settings.wait_slow_command == 3
    assert len(settings.rules) > 0
    assert len(settings.exclude_rules) == 0
    assert settings.repeat == 1
    assert settings.num_close_matches == 3
    assert settings.user_dir == Path(settings._get_user_dir_path())
    assert settings.alter_history is True
    assert settings.instant_mode is False
    assert settings.wait_command == 1
    settings.init(args=None)
    assert time.time() - settings.start_time < 0.1
    assert len(settings.priority) == 0

# Generated at 2022-06-22 00:06:30.452843
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings_ = Settings()
    settings_.a = 1
    assert settings_ == {'a': 1}
    settings_.a = 2
    assert settings_ == {'a': 2}
    settings_.b = 3
    assert settings_ == {'a': 2, 'b': 3}

# Generated at 2022-06-22 00:06:34.259926
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    class Object(object):
        pass
    o = Object()
    o.attr = 'attr'
    s = Settings(attr='attr')
    assert o.attr == s.attr


# Generated at 2022-06-22 00:06:42.837066
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['require_confirmation'] == True
    assert settings['wait_command'] == 1
    assert settings['no_colors'] == False
    assert settings['history_limit'] == 1000
    assert settings['wait_slow_command'] == 3
    assert settings['debug'] == False
    assert settings['alter_history'] == True
    assert settings['priority'] == {}
    assert settings['instant_mode'] == False
    assert settings['repeat'] == False
    assert settings['num_close_matches'] == 3
    assert settings['slow_commands'] == []
    assert settings['exclude_rules'] == []
    assert settings['excluded_search_path_prefixes'] == []

# Generated at 2022-06-22 00:06:45.095434
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    settings.init()
    assert settings.init
    return True

# Generated at 2022-06-22 00:06:53.735077
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch
    from os import environ
    from tempfile import mkdtemp

    environ['TF_IGNORE_DOTFILES'] = '1'
    environ['TF_DISABLE_COLORS'] = '1'
    environ['TF_REQUIRE_CONFIRMATION'] = 'True'
    environ['TF_HISTORY_LIMIT'] = '10'
    environ['TF_RULES'] = ':'
    environ['TF_PRIORITY'] = 'git-rebase=2'
    environ['TF_WAIT_SLOW_COMMAND'] = '3'
    environ['TF_SLOW_COMMANDS'] = 'echo:very_slow_command'
    environ['TF_NUM_CLOSE_MATCHES'] = '4'

# Generated at 2022-06-22 00:07:05.817181
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception_log
    from .command import Command

    with settings.user_dir.joinpath('settings.py').open() as f:
        assert f.read() == const.SETTINGS_HEADER
        for setting in const.DEFAULT_SETTINGS.items():
            assert u'# {} = {}\n'.format(*setting) in f.readlines()

    normal = Command('echo hi', 'hi\n')
    slow = Command('sleep 1 && echo hi', 'hi\n')
    assert settings.require_confirmation(normal)
    assert not settings.require_confirmation(slow)
    assert settings.wait_command(slow) == 1
    assert not settings.wait_command(normal)
    assert settings.priority(normal) == 1

# Generated at 2022-06-22 00:07:31.966782
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.abc = 123

    assert settings['abc'] == 123
    assert settings.abc == 123

# Generated at 2022-06-22 00:07:37.302922
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.require_confirmation
    assert not settings.no_colors
    assert settings.rules == ()
    assert settings.exts == ()
    assert settings.priority == {}

    settings.no_colors = True
    settings.exts = ('py',)

    assert not settings.require_confirmation
    assert settings.no_colors
    assert settings.exts == ('py',)



# Generated at 2022-06-22 00:07:49.142931
# Unit test for method init of class Settings
def test_Settings_init():
    from .system import get_alias
    from .date import datetime
    from .logs import naive_logger
    import os
    import warnings

    os.environ = {
        'TF_ALIAS': 'fuck',
        'TF_WAIT_COMMAND': '3',
        'TF_RULES': 'bash_history:ls:git_push',
        'TF_PRIORITY': 'bash_history=50:ls=30',
        'TF_REQUIRE_CONFIRMATION': 'false',
        'TF_NO_COLOR': 'true',
        'TF_DEBUG': 'true',
        'TF_ALT_HISTORY': 'false',
    }

    settings.init()

    assert settings.alias == 'fuck'
    assert settings.wait_command == 3

# Generated at 2022-06-22 00:07:55.863959
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from .utils import wrap_streams
    from .logs import log

    stdout, stderr = sys.stdout, sys.stderr

    with wrap_streams() as out:
        settings.__setattr__("test_key", "test_value")
        assert settings.test_key == "test_value"
        assert len(out.getvalue()) == 0

    with wrap_streams(stdout, stderr) as out:
        settings.__setattr__("log", log)
        assert len(out.getvalue()) > 0

# Generated at 2022-06-22 00:07:57.742773
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules == const.DEFAULT_RULES


# Generated at 2022-06-22 00:08:01.564497
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.require_confirmation
    assert settings.rules == const.DEFAULT_RULES

# Generated at 2022-06-22 00:08:04.860639
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    s = Settings()
    s.a = 1
    assert s.a == 1
    assert s['a'] == 1
    assert s.get('b') is None


# Generated at 2022-06-22 00:08:12.910846
# Unit test for method init of class Settings
def test_Settings_init():
    # Reset settings object to default values
    settings.clear()
    settings.update(const.DEFAULT_SETTINGS)

    # Initialise dummy arguments
    args = type('', (), dict(yes=False, debug=False, repeat=False))()

    # Get a copy of the settings before initialisation
    old_settings = dict(settings)

    # Perform initialisation with dummy arguments
    settings.init(args)

    # Ensure the user directory was initialised
    user_dir = settings._get_user_dir_path()
    assert user_dir, "No user directory was initialised"
    assert user_dir.is_dir(), "{} is not a directory".format(user_dir)
    assert user_dir.joinpath('rules').is_dir(), "{} is not a directory".format(user_dir.joinpath('rules'))



# Generated at 2022-06-22 00:08:15.470928
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    global settings
    settings = Settings({})
    settings.test_key = 123
    assert settings.get('test_key') == 123


# Generated at 2022-06-22 00:08:17.391553
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.a = 'A'
    assert settings.a == 'A'
    assert settings['a'] == 'A'


# Generated at 2022-06-22 00:09:15.914930
# Unit test for method init of class Settings
def test_Settings_init():
    def empty_settings_file(settings_file):
        settings_file.write(' ')

    def empty_settings_file_with_comment(settings_file):
        settings_file.write(' #')

    def wait_command_settings_file(settings_file):
        settings_file.write('wait_command = 0')

    def wait_command_settings_file_with_comment(settings_file):
        settings_file.write('# wait_command = 0')

    def get_settings_file_path(settings_folder, settings_file_name,
                               settings_file_content):
        settings_file_path = settings_folder.joinpath(settings_file_name)
        with settings_file_path.open(mode='w') as settings_file:
            settings_file_content(settings_file)


# Generated at 2022-06-22 00:09:19.902525
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.no_colors is False
    assert settings.require_confirmation is True
    assert settings.wait_command == 3
    assert settings.rules == const.DEFAULT_RULES


# Generated at 2022-06-22 00:09:28.995726
# Unit test for constructor of class Settings
def test_Settings():
    current_dir = os.path.dirname(os.path.realpath(__file__))
    sys.path.insert(0, current_dir)
    settings.init()
    assert settings.alter_history
    assert settings.require_confirmation
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.no_colors
    assert settings.env['LANG'] == 'en_US.UTF-8'
    assert settings.wait_slow_command == 3
    assert settings.wait_command == 1
    assert settings.priority == {}
    assert settings.history_limit == 10
    assert settings.slow_commands == const.DEFAULT_SLOW_COMMANDS
    assert settings.excluded_search_path_prefixes == []
    assert not settings.inst

# Generated at 2022-06-22 00:09:36.077241
# Unit test for method init of class Settings
def test_Settings_init():
    settings["require_confirmation"] = True
    settings.init()
    assert settings["require_confirmation"] == True

    settings["require_confirmation"] = False
    settings.init(args=argparse.Namespace(yes=True))
    assert settings["require_confirmation"] == False

    os.environ['THEFUCK_CONFIRM'] = 'False'
    settings.init()
    assert settings["require_confirmation"] == False

# Generated at 2022-06-22 00:09:46.885773
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings._get_user_dir_path() == Path(
        '~/.config/thefuck').expanduser()
    assert settings.require_confirmation == True
    assert settings.priority == {}
    assert settings.rules == ['fuck_alias', 'fuck_git_rebase',
                              'fuck_git_amend', 'fuck_git_push',
                              'fuck_autofix', 'fuck_sudo',
                              'fuck_pip_forget_args',
                              'fuck_brew_forget_args',
                              'fuck_apt_get_forget_args']

    assert settings.exclude_rules == ['fuck_python_venv']
    assert settings.history_limit == None
    assert settings.wait_command == 5
    assert settings.slow_commands == []


# Generated at 2022-06-22 00:09:50.581401
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings_test = Settings()
    setattr(settings_test, 'test', 'test')
    assert 'test' in settings_test
    assert settings_test.test == 'test'

# Generated at 2022-06-22 00:09:55.920568
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # Normal Case:
    settings.fuck = 'world'
    assert settings['fuck'] == 'world'
    assert settings.fuck == 'world'

    # Exceptional Case:

# Generated at 2022-06-22 00:09:59.932899
# Unit test for method init of class Settings
def test_Settings_init():
    """Test for method Settings.init."""
    tmp = settings.init()
    assert type(tmp) is dict
    assert tmp['history_limit'] ==  os.environ['THEFUCK_HISTORY_LIMIT']

# Generated at 2022-06-22 00:10:02.155311
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    s.a = 1
    assert s.a == 1
    assert s['a'] == 1

# Generated at 2022-06-22 00:10:03.575591
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.require_confirmation = False
    assert not settings.require_confirmation

# Generated at 2022-06-22 00:11:08.631626
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings = Settings()
    settings.init()
    assert settings['require_confirmation'] == True
    assert settings['debug'] == False
    assert settings['repeat'] == False

# Generated at 2022-06-22 00:11:15.557714
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    # Create new instance of class Settings
    settings = Settings(init=False)

    # Check if default attributes have default values
    for attr_default, value_default in const.DEFAULT_SETTINGS.items():
        assert settings.__getattr__(attr_default) == value_default

    # Check if not existing attribute raise KeyError
    try:
        settings.__getattr__('not_existing')
        assert False
    except KeyError:
        assert True



# Generated at 2022-06-22 00:11:17.320369
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.init()
    assert settings.init(args=True)

# Generated at 2022-06-22 00:11:27.790790
# Unit test for constructor of class Settings
def test_Settings():
    from .logs import exception
    from thefuck import utils
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck')
    settings_path = settings.user_dir.joinpath('settings.py')
    assert settings_path.is_file()
    settings_file = settings_path.open()
    settings_file_content = settings_file.read()
    settings_file.close()
    settings_file_content_list = settings_file_content.split('\n')
    assert settings_file_content_list[0] == const.SETTINGS_HEADER

# Generated at 2022-06-22 00:11:29.270773
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.foo = 'bar'
    assert settings['foo'] == 'bar'



# Generated at 2022-06-22 00:11:33.392750
# Unit test for method init of class Settings
def test_Settings_init():
    import mock

    args = mock.MagicMock()
    args.yes = True
    args.debug = True
    args.repeat = True
    settings.init(args)
    assert settings.require_confirmation == False
    assert settings.debug == True
    assert settings.repeat == True

# Generated at 2022-06-22 00:11:43.142999
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules == const.DEFAULT_SETTINGS['rules']
    assert settings.priority == const.DEFAULT_SETTINGS['priority']
    assert settings.history_limit == const.DEFAULT_SETTINGS['history_limit']
    assert settings.require_confirmation == \
        const.DEFAULT_SETTINGS['require_confirmation']
    assert settings.no_colors == const.DEFAULT_SETTINGS['no_colors']
    assert settings.wait_command == const.DEFAULT_SETTINGS['wait_command']
    assert settings.wait_slow_command == \
        const.DEFAULT_SETTINGS['wait_slow_command']
    assert settings.exclude_rules == const.DEFAULT_SETTINGS['exclude_rules']

# Generated at 2022-06-22 00:11:46.659580
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    """
    >>> s = Settings({'a': 1})
    >>> type(s.a)
    <type 'int'>
    >>> s.a
    1
    >>> s.b
    """



# Generated at 2022-06-22 00:11:48.776065
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    a = Settings()
    a.test = 1
    assert a['test'] == 1, '__setattr__ does not work'

# Generated at 2022-06-22 00:11:52.600994
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.get('rules') == const.DEFAULT_RULES
    assert settings.get('history_limit') == 10
    assert settings.get('exclude_rules') == ['exclude']


# Generated at 2022-06-22 00:13:14.375515
# Unit test for method init of class Settings
def test_Settings_init():
    def _settings_from_file(settings_file_content):
        settings_mock = Mock()
        settings_mock.slow_commands = 42
        with patch('thefuck.settings.load_source',
                   return_value=settings_mock):
            settings.init()
            assert settings['slow_commands'] == 42

    yield _settings_from_file, ''
    yield _settings_from_file, const.SETTINGS_HEADER

# Generated at 2022-06-22 00:13:15.516428
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules == const.DEFAULT_RULES



# Generated at 2022-06-22 00:13:17.727106
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings()
    test_settings.test_attr = "test_attr_val"
    assert test_settings.test_attr == "test_attr_val"



# Generated at 2022-06-22 00:13:20.635557
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings['require_confirmation'] is True
    settings.require_confirmation = False
    assert settings['require_confirmation'] is False


# Generated at 2022-06-22 00:13:23.249613
# Unit test for constructor of class Settings
def test_Settings():
    assert dict == type(settings)
    assert dict == type(settings.__dict__)
    assert settings.get('require_confirmation') is True
    assert settings.repeat is None


# Generated at 2022-06-22 00:13:25.230118
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    STATUS = 'test status'
    settings.status = STATUS
    assert settings['status'] == STATUS



# Generated at 2022-06-22 00:13:26.720231
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.test = 1
    assert settings['test'] == 1



# Generated at 2022-06-22 00:13:28.651522
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.test = 'test'
    assert settings.test == 'test'



# Generated at 2022-06-22 00:13:29.951258
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.python_path == '/usr/bin/python'


# Generated at 2022-06-22 00:13:33.242425
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings({'script': 'foo.py', 'slow_commands': ['ls']})
    assert settings.script == 'foo.py'
    assert settings.slow_commands == ['ls']


# Generated at 2022-06-22 00:14:56.523888
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules == const.DEFAULT_RULES


# Generated at 2022-06-22 00:15:08.688398
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch
    from .system import Path

    class FakeSettings(dict):
        user_dir = Path('mock_dir')


# Generated at 2022-06-22 00:15:12.178020
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('require_confirmation') is True
    assert settings.get('alter_history') is True



# Generated at 2022-06-22 00:15:21.591345
# Unit test for method init of class Settings
def test_Settings_init():
    settings.user_dir = None
    settings.init()
    assert settings.user_dir._path == '/home/vladimirpc/.config/thefuck'
    assert settings.rules == ['git_push', 'git_push_current_branch', 'git_add_and_commit', 'git_amend', 'git_rebase_interactive', 'git_rebase_squash', 'git_checkout', 'git_merge', 'hg_commit', 'svn_revert', 'svn_commit', 'svn_switch']
    assert settings.wait_command == 1
    assert settings.require_confirmation == True
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.slow_

# Generated at 2022-06-22 00:15:22.977773
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation



# Generated at 2022-06-22 00:15:26.192777
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation is True
    settings.require_confirmation = False
    assert settings.require_confirmation is False



# Generated at 2022-06-22 00:15:28.202438
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.test = True
    assert(settings['test'])


# Generated at 2022-06-22 00:15:39.637937
# Unit test for constructor of class Settings
def test_Settings():
	assert settings.rules == ['git_recent', 'git_add', 'git_amend', 'git_push', 'git_pull', 'svn', 'sudo']
	assert settings.wait_command == 1
	assert settings.history_limit == 10
	assert settings.no_colors
	assert not settings.debug
	assert settings.require_confirmation
	assert settings.priority == {'git_recent': 100, 'git_add': 99, 'git_amend': 99, 'git_push': 98, 'git_pull': 90, 'svn': 50, 'sudo': 100}
	assert settings.alter_history
	assert settings.exclude_rules == []
	assert settings.exclude_commands == []
	assert settings.wait_slow_command == 15