

# Generated at 2022-06-22 00:06:05.968415
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception, warn
    from .system import Path

    def mock_warning(msg):
        pass

    def mock_exception(msg, exc_info):
        pass
    warn = mock_warning
    exception = mock_exception

    settings = Settings({})
    settings.init()
    assert settings.require_confirmation is True
    assert settings.wait_command is 1
    assert settings.rules == const.DEFAULT_RULES
    assert settings.priority == {}
    assert settings.exclude_rules == []
    assert settings.no_colors is False
    assert settings.wait_slow_command is 3

# Generated at 2022-06-22 00:06:14.954506
# Unit test for method init of class Settings
def test_Settings_init():
    test_settings = Settings({})
    with mock.patch('thefuck.settings.Settings._settings_from_file',
                    return_value={'slow_commands': ['test']}):
        with mock.patch('thefuck.settings.Settings._settings_from_env',
                        return_value={'rules': ['test']}):
            with mock.patch('thefuck.settings.Settings._settings_from_args',
                            return_value={'require_confirmation': True}):
                 test_settings.init()
            assert test_settings.slow_commands == ['test']
            assert test_settings.rules == ['test']
            assert test_settings.require_confirmation is True

# Generated at 2022-06-22 00:06:26.055292
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch
    from _pytest.monkeypatch import MonkeyPatch
    from thefuck.main import Command

    monkeypatch = MonkeyPatch()

    with patch('thefuck.settings._init_settings_file') as init_settings_file, \
            patch('thefuck.settings._settings_from_file') as settings_from_file, \
            patch('thefuck.settings._settings_from_env') as settings_from_env, \
            patch('thefuck.settings._settings_from_args') as settings_from_args:
        monkeypatch.setattr(settings, '_get_user_dir_path',
                            lambda: Path('/opt/thefuck'))

# Generated at 2022-06-22 00:06:29.008754
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    s.attr = '123'
    assert(s['attr'] == '123')
    assert(s.attr == '123')


# Generated at 2022-06-22 00:06:31.644463
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('priorty') == {}
    assert settings.get('require_confirmation') == True


# Generated at 2022-06-22 00:06:35.435762
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    """
    Verify that Settings overrides __setattr__ to behave like `__setitem__`
    """
    settings = Settings()
    settings.attr = 'value'
    assert settings['attr'] == 'value'

# Generated at 2022-06-22 00:06:37.738558
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test_key = True
    assert 'test_key' in settings
    assert settings['test_key'] is True



# Generated at 2022-06-22 00:06:38.741714
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules != None


# Generated at 2022-06-22 00:06:40.558008
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.python_path == '/usr/bin/python3'
    assert settings.require_confirmation



# Generated at 2022-06-22 00:06:51.125021
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert settings.rules == ['cd_parent',
                              'git_push',
                              'git_push_current_branch',
                              'python_command',
                              'sudo']
    assert settings.exclude_rules == ['man',
                                      'ls',
                                      'l',
                                      'bg',
                                      'fg']
    assert settings.history_limit == None
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alias == None
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 10
    assert settings.slow_commands == ['lein',
                                      'react-native',
                                      'gradle',
                                      './gradlew',
                                      '.\\gradlew.bat']

# Generated at 2022-06-22 00:07:10.740375
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.__setattr__('test', 'test')
    assert settings ['test'] == 'test'


# Generated at 2022-06-22 00:07:16.766509
# Unit test for constructor of class Settings
def test_Settings():
    from_env = settings._settings_from_env()
    from_file = settings._settings_from_file()
    '''
    for key, val in from_file.items():
        if key in from_env.keys():
            assert False
    '''
    for key in from_env.keys():
        assert key in from_file.keys()
        assert from_env[key] == from_file[key]



# Generated at 2022-06-22 00:07:18.414311
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    global settings
    settings = Settings()
    settings.some_key = 'some_value'
    assert settings['some_key'] == 'some_value'

# Generated at 2022-06-22 00:07:21.217323
# Unit test for method __setattr__ of class Settings

# Generated at 2022-06-22 00:07:23.658813
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.init()
    settings.new_setting_added = "new-setting-added"
    assert settings["new_setting_added"] == "new-setting-added"



# Generated at 2022-06-22 00:07:35.601675
# Unit test for method init of class Settings
def test_Settings_init():
    """This is a unit test for method init of class Settings."""
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'true'
    os.environ['THEFUCK_DEBUG'] = 'true'
    os.environ['THEFUCK_PRIORITY'] = ''
    os.environ['THEFUCK_WAIT_COMMAND'] = '5'
    os.environ['THEFUCK_WAIT_SLOW_COMMAND'] = '5'
    os.environ['THEFUCK_HISTORY_LIMIT'] = '5'
    os.environ['THEFUCK_ALTER_HISTORY'] = 'true'
    os.environ['THEFUCK_NO_COLORS'] = 'true'

# Generated at 2022-06-22 00:07:37.168522
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert settings.rules == const.DEFAULT_RULES



# Generated at 2022-06-22 00:07:38.431016
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    global settings
    assert settings.debug
    assert settings['debug']


settings.init()

# Generated at 2022-06-22 00:07:41.495219
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init(args=None)
    assert settings.user_dir
    assert settings.rules
    assert settings.priority
    assert settings.require_confirmation

# Generated at 2022-06-22 00:07:42.202638
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

# Generated at 2022-06-22 00:08:40.613230
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    test_settings = Settings({"var_name":"value"})
    assert test_settings.__getattr__("var_name") == "value"
    assert test_settings.__getattr__("var_not_exist") == None



# Generated at 2022-06-22 00:08:42.195095
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings(test='test')
    assert settings.test == 'test'


# Generated at 2022-06-22 00:08:45.280142
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings._get_user_dir_path() == Path('~/.config', 'thefuck').expanduser()



# Generated at 2022-06-22 00:08:49.647366
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    new_settings = Settings(const.DEFAULT_SETTINGS)
    new_settings.test_attr = 'test value'
    assert new_settings['test_attr'] == 'test value'

# Generated at 2022-06-22 00:08:51.506595
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    a = Settings({1: 'one'})
    assert a.__getattr__(1) == 'one'


# Generated at 2022-06-22 00:08:54.479957
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.require_confirmation
    assert not settings.alter_history
    assert settings.rules == const.DEFAULT_RULES
    assert settings.priority == {}



# Generated at 2022-06-22 00:08:56.039665
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    s.test = 'test'
    assert s['test'] == 'test'


# Generated at 2022-06-22 00:08:58.973062
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    attr = 'attr'
    value = 'value'
    settings = Settings()
    settings.__setattr__(attr, value)
    assert settings[attr] == value
    assert settings.attr == value

# Generated at 2022-06-22 00:09:02.919959
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    assert not settings.keys()
    settings.test = 123
    assert settings['test'] == 123
    settings.test = 456
    assert settings['test'] == 456

# Generated at 2022-06-22 00:09:04.909446
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings()
    settings.asd = 1
    assert(settings.asd == 1)



# Generated at 2022-06-22 00:11:14.738184
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.test = 1
    assert settings["test"] == 1



# Generated at 2022-06-22 00:11:15.829046
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings is not None

# Generated at 2022-06-22 00:11:17.349201
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert Settings({"a": "b"}).a == "b"

# Generated at 2022-06-22 00:11:23.036493
# Unit test for constructor of class Settings
def test_Settings():
    d = {'key1':'value1'}
    settings = Settings(d)
    assert settings['key1'] == 'value1'
    assert settings.key1 == 'value1'
    settings.key2 = 'value2'
    assert settings['key2'] == 'value2'
    assert settings.key2 == 'value2'

# Generated at 2022-06-22 00:11:24.769322
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    s.hogehoge = 100
    assert s == {"hogehoge": 100}


# Generated at 2022-06-22 00:11:34.319545
# Unit test for constructor of class Settings
def test_Settings():
    assert settings == const.DEFAULT_SETTINGS
    assert settings.user_dir == Path(u'~/.config/thefuck').expanduser()
    assert settings.alias == 'fuck'
    assert settings.priority == {}
    assert settings.wait_command == 0
    assert settings.wait_slow_command == 3
    assert settings.require_confirmation is False
    assert settings.no_colors is False
    assert settings.repeat is False
    assert settings.instant_mode is False
    assert settings.debug is False
    assert settings.alter_history is False
    assert settings.num_close_matches == 3
    assert settings.history_limit == 1000
    assert settings.slow_commands == ['lein', './gradlew']
    assert settings.exclude_rules == []
    assert len(settings.rules) == 4

# Generated at 2022-06-22 00:11:35.706066
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.log_file = 'a'
    assert settings['log_file'] == 'a'

# Generated at 2022-06-22 00:11:36.859001
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = 1
    assert settings['test'] == 1


# Generated at 2022-06-22 00:11:38.995494
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.test = True
    assert settings.get('test')


# Generated at 2022-06-22 00:11:42.104049
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test_value = 'test_value'
    assert settings.test_value == 'test_value'
