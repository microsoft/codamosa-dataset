

# Generated at 2022-06-22 00:06:03.231211
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = 1
    assert settings["test"] == 1


# Generated at 2022-06-22 00:06:07.134312
# Unit test for constructor of class Settings
def test_Settings():
    # default_settings is a dict of default settings
    default_settings = const.DEFAULT_SETTINGS
    # settings is a dict of all settings
    for key in default_settings.keys():
        assert hasattr(settings, key)


# Generated at 2022-06-22 00:06:08.213067
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings()
    test_settings.test_attr = 'test_attr'
    assert settings.test_attr == 'test_attr'


# Generated at 2022-06-22 00:06:10.231202
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class Test(object):
        def __init__(self):
            self.settings = Settings(const.DEFAULT_SETTINGS)

    test = Test()
    assert test.settings['require_confirmation'] == True
    test.settings['require_confirmation'] = False
    assert test.settings['require_confirmation'] == False

# Generated at 2022-06-22 00:06:11.990835
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings()
    settings.name = 'value'
    assert settings.name == 'value'



# Generated at 2022-06-22 00:06:24.402337
# Unit test for method init of class Settings

# Generated at 2022-06-22 00:06:26.295012
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.name = "value"
    assert settings['name'] == "value"

# Generated at 2022-06-22 00:06:32.411990
# Unit test for method init of class Settings
def test_Settings_init():
    # Load settings.json
    old_user_dir = settings.user_dir
    try:
        settings.user_dir = old_user_dir.parent
        settings.init()
        assert settings.require_confirmation
        assert settings.rules == const.DEFAULT_RULES
    finally:
        settings.user_dir = old_user_dir


# Generated at 2022-06-22 00:06:35.941696
# Unit test for method init of class Settings
def test_Settings_init():
    import types
    reload(sys)
    sys.setdefaultencoding('UTF8')
    args = types.SimpleNamespace(yes=False, debug=False, repeat=False)
    settings.init(args)

# Generated at 2022-06-22 00:06:47.037429
# Unit test for constructor of class Settings
def test_Settings():
    # test for private method '_setup_user_dir'
    def test_setup_user_dir():
        user_dir = settings._get_user_dir_path()
        # delete user_dir
        if user_dir.exists():
            for child in user_dir.iterdir():
                child.unlink()
            user_dir.rmdir()
        # initialize user_dir
        settings._setup_user_dir()
        assert user_dir.exists()
        assert user_dir.joinpath('rules').is_dir()
        # delete user_dir
        if user_dir.exists():
            for child in user_dir.iterdir():
                child.unlink()
            user_dir.rmdir()
    test_setup_user_dir()

    # test for private method '_init_settings_

# Generated at 2022-06-22 00:07:23.611815
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.get('rules') == const.DEFAULT_RULES.split(':')
    assert isinstance(settings, Settings)


# Generated at 2022-06-22 00:07:29.538405
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class Foo(object):
        def __init__(self):
            self.settings = Settings()

    foo = Foo()
    foo.settings.foo = 'bar'
    assert foo.settings['foo'] == 'bar'
    assert foo.settings.foo == 'bar'

    del foo.settings['foo']
    assert foo.settings.foo is None



# Generated at 2022-06-22 00:07:32.010176
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert const.DEFAULT_SETTINGS["require_confirmation"] == settings.require_confirmation

# Generated at 2022-06-22 00:07:34.222124
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation is True
    assert settings.rules == const.DEFAULT_RULES
    assert settings.priority == {}
    assert settings.env == {}



# Generated at 2022-06-22 00:07:34.985992
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.test_key = 'test'
    assert settings.test_key == 'test'


# Generated at 2022-06-22 00:07:36.298291
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings(const.DEFAULT_SETTINGS)
    assert s.user_dir is None
    assert isinstance(const.DEFAULT_SETTINGS, dict)
    assert isinstance(s, dict)

# Generated at 2022-06-22 00:07:47.922596
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings['require_confirmation'] is True
    assert settings['history_limit'] == 0
    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['priority'] == {}
    assert settings['no_colors'] is False
    assert settings['exclude_rules'] == []
    assert settings['wait_command'] == 0
    assert settings['debug'] is False
    assert settings['slow_commands'] == []
    assert settings['wait_slow_command'] == 1
    assert settings['repeat'] is False
    assert settings['alter_history'] is False
    assert settings['excluded_search_path_prefixes'] == []
    assert settings['num_close_matches'] == 3
    assert settings['instant_mode'] is False

# Generated at 2022-06-22 00:07:49.392482
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.foo = 'bar'
    assert settings['foo'] == 'bar'

# Generated at 2022-06-22 00:07:51.629569
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert isinstance(s,Settings)

# Generated at 2022-06-22 00:07:55.640810
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from .logs import log
    from .utils import get_closest_match
    settings._set_log_methods(log, get_closest_match)
    settings.init()
    settings.fuck = True
    assert settings.fuck == True
    settings.fuck = False
    assert settings.fuck == False

# Generated at 2022-06-22 00:08:36.446076
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(one=1, two=2)
    assert settings.one == 1
    assert settings.two == 2
    settings['three'] = 3
    assert settings.three == 3
    settings.four = 4
    assert settings['four'] == 4
    assert settings.__class__.__name__ == 'Settings'

# Generated at 2022-06-22 00:08:40.490575
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings({'key': 'value'})
    assert settings.key == 'value'
    assert settings['key'] == 'value'
    settings.key2 = 'value2'
    assert settings['key2'] == 'value2'

# Generated at 2022-06-22 00:08:47.358293
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    s = Settings()
    s.init()

    assert s.require_confirmation == True
    assert s.repeat == False
    assert s.wait_slow_command == 15
    assert s.wait_command == 1
    assert s.no_colors == False
    assert s.use_notify == False
    assert s.priority == {}
    assert s.history_limit == None
    assert s.exclude_rules == []
    assert s.excluded_search_path_prefixes == []
    assert s.require_confirmation == True
    assert s.show_in_linux == True
    assert s.show_in_mac == True
    assert s.show_in_bsd == True
    assert s.show_in_cygwin == True
    assert s.show_in_w

# Generated at 2022-06-22 00:08:56.560653
# Unit test for method init of class Settings
def test_Settings_init():
    """
    The test checks the correctness of working method init
    of class Settings
    """
    from .logs import exception
    def _get_user_dir_path():
        return Path(__file__).dirname().joinpath('..')
    settings._get_user_dir_path = _get_user_dir_path
    settings._settings_from_file = lambda: {'key': 'value'}
    settings._settings_from_env = lambda: {'key2': 'value2'}
    settings._settings_from_args = lambda: {'key3': 'value3'}
    settings.init()
    assert settings.user_dir == Path(__file__).dirname().joinpath('..')
    assert settings.get('key') == 'value'
    assert settings.get('key2') == 'value2'

# Generated at 2022-06-22 00:09:07.764155
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    args = Mock()
    args.yes = True
    args.debug = False
    args.repeat = 5

    settings._get_user_dir_path = Mock(return_value=Path('~/.thefuck'))
    settings._init_settings_file = Mock()
    settings._settings_from_file = Mock(return_value={'rules': ['rule1'],
                                                      'require_confirmation': False})
    settings._settings_from_env = Mock(return_value={'rules': ['rule2'],
                                                     'debug': True})
    settings._settings_from_args = Mock(return_value={'repeat': 99})
    settings.update = Mock()

    settings.init(args)

    settings._get_user_dir_path.assert_called_once_with()


# Generated at 2022-06-22 00:09:15.796882
# Unit test for constructor of class Settings
def test_Settings():
    # Settings is a dict class
    assert issubclass(Settings, dict)
    # test __getattr__ method
    test_dict = {'test_key': 'test_val'}
    test_settings = Settings(test_dict)
    assert test_settings.get('test_key') == 'test_val'
    # test __setattr__ method
    test_settings.test_key = 'test_val2'
    assert test_settings.get('test_key') == 'test_val2'
    # test init method
    # test _setup_user_dir method
    test_settings.user_dir = None
    test_settings.init({'test_arg': 'test_val'})
    assert test_settings.get('test_arg') == 'test_val'

# Generated at 2022-06-22 00:09:17.813460
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings['DEBUG'] == False
    settings['DEBUG'] = True
    assert settings['DEBUG'] == True


# Generated at 2022-06-22 00:09:20.698936
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.wait_command == 3
    assert settings.require_confirmation is True
    assert settings.totally_invalid_setting is None

# Generated at 2022-06-22 00:09:22.337508
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.__setattr__('key', 'value')
    assert settings.get('key') == 'value'

# Generated at 2022-06-22 00:09:26.031365
# Unit test for method init of class Settings
def test_Settings_init():
    config_path = '~/.config/thefuck'
    settings.init()
    assert settings.user_dir.expanduser() == Path(config_path).expanduser()
    assert settings.user_dir == Path(config_path)

# Generated at 2022-06-22 00:10:52.652313
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    with open(settings.user_dir.joinpath('settings.py'), 'w') as settings_file:
        settings_file.write(const.SETTINGS_HEADER)
        settings_file.write("require_confirmation = True")
    settings.init()
    assert settings.require_confirmation == True


# Generated at 2022-06-22 00:11:03.792953
# Unit test for method init of class Settings
def test_Settings_init():
    from unittest.mock import patch

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()

    expected_user_dir = Path().expanduser().joinpath('~/.config/thefuck')

    assert settings.user_dir == expected_user_dir

    with patch('thefuck.settings.Settings._settings_from_file') as _settings_from_file, \
            patch('thefuck.settings.Settings._settings_from_env', return_value={'key': 'env'}), \
            patch('thefuck.settings.Settings._settings_from_args', return_value={'key': 'args'}):
        settings.init()
        assert settings.key == 'args'
        _settings_from_file.assert_called_once()

# Generated at 2022-06-22 00:11:07.064727
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    from . import settings as mod_settings
    settings.test_attr = 'test_attr'
    assert(mod_settings.test_attr == 'test_attr')


# Generated at 2022-06-22 00:11:10.179136
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation is True


# Generated at 2022-06-22 00:11:18.349898
# Unit test for constructor of class Settings
def test_Settings():
    from mock import patch
    from thefuck.settings import Settings

    with patch.object(Settings, '_get_user_dir_path',
                      return_value='test_path') as mocked_user_dir_path,\
            patch.object(Settings, '_settings_from_file',
                         return_value='settings_from_file'),\
            patch.object(Settings, '_settings_from_env',
                         return_value='settings_from_env'),\
            patch.object(Settings, '_settings_from_args',
                         return_value='settings_from_args'):
        settings = Settings()
        settings.init()
        assert settings.user_dir == 'test_path'
        assert settings._settings_from_file.called
        assert settings._settings_from_env.called
        assert settings._settings_from_

# Generated at 2022-06-22 00:11:28.735749
# Unit test for method init of class Settings
def test_Settings_init():
    """Test `init` method of class `Settings`.

    This method should recreate default settings file, if not found.

    """
    import shutil
    from .logs import exception

    with settings.user_dir.joinpath('settings.py').open() as settings_file:
        default_settings = settings_file.read()

    shutil.rmtree(settings.user_dir)
    assert not settings.user_dir.is_dir()

    settings.init()
    with settings.user_dir.joinpath('settings.py').open() as settings_file:
        recovered_settings = settings_file.read()
    assert recovered_settings == default_settings

    settings.user_dir.joinpath('settings.py').remove()
    assert not settings.user_dir.joinpath('settings.py').is_file()


# Generated at 2022-06-22 00:11:37.651547
# Unit test for constructor of class Settings
def test_Settings():
    """Test function for class Settings"""
    import pytest
    def test_main(monkeypatch, capsys):
        """Main test function to test Settings class"""
        # Checks default settings when no config files or environment variables are set.
        from subprocess import Popen
        from time import time, sleep
        # Create config directories
        if not os.path.isdir(os.path.expanduser('~/.config/thefuck')):
            os.makedirs(os.path.expanduser('~/.config/thefuck'))
        if not os.path.isdir(os.path.expanduser('~/.config/thefuck/rules')):
            os.makedirs(os.path.expanduser('~/.config/thefuck/rules'))

# Generated at 2022-06-22 00:11:41.607038
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings()
    test_settings.test_attr = 'test_attr'
    test_attr = test_settings.get('test_attr')
    assert test_attr == 'test_attr'

# Generated at 2022-06-22 00:11:43.257652
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']



# Generated at 2022-06-22 00:11:53.536868
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings(
        {
            'require_confirmation': False,
            'no_colors': False,
            'history_limit': 10,
        }
    )
    assert s['require_confirmation'] is False
    assert s['require_confirmation'] == s.require_confirmation
    assert s['no_colors'] is False
    assert s['no_colors'] == s.no_colors
    assert s['history_limit'] == 10
    assert s['history_limit'] == s.history_limit

    s.foo = 42
    assert s['foo'] == 42
    assert getattr(s, 'foo') == s.foo

    assert s['missing'] is None
    assert s.missing is None
    assert getattr(s, 'missing') is None
    assert s.get('missing') is None