

# Generated at 2022-06-22 00:06:00.978470
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.__class__ is Settings, 'settings.__class__ should be Settings'
    settings.attribute_name1 = 'my test value'
    assert settings.attribute_name1 == 'my test value', 'settings.attribute_name1 should be "my test value"'

    return True

# Generated at 2022-06-22 00:06:09.570247
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import mock_log

    class MockArgs(object):
        def __init__(self, **kwargs):
            for attr, val in kwargs.items():
                setattr(self, attr, val)

    with mock_log() as logs:
        settings = Settings()
        settings.init(MockArgs(yes=True, debug=True, repeat=1))
        assert not logs.error
        assert settings.require_confirmation is False
        assert settings.debug is True
        assert settings.repeat == 1

# Generated at 2022-06-22 00:06:11.511702
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
	settings.test_attr = "test"
	assert settings["test_attr"] == "test"

# Generated at 2022-06-22 00:06:13.475787
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from .tests.utils import mock
    settings.__setattr__('attr', 'value')
    assert settings['attr'] == 'value'



# Generated at 2022-06-22 00:06:15.609107
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings({'a': 'b'})
    assert settings.a == 'b'


# Generated at 2022-06-22 00:06:19.625068
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from unittest import mock

    temp_settings = Settings()
    temp_settings.__setattr__('test_key', 'test_value')
    assert temp_settings['test_key'] == 'test_value'

# Generated at 2022-06-22 00:06:21.020140
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules == const.DEFAULT_SETTINGS['rules']



# Generated at 2022-06-22 00:06:31.993659
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    from .logs import exception
    from .system import Path

    def _get_env(args):
        return {attr: val for attr, val in args.items()
                if attr in const.ENV_TO_ATTR}

    def _get_args(args):
        return {attr: val for attr, val in args.items()
                if attr in const.SETTINGS_FROM_ARGS.keys()}

    args = ['--exclude-rules', 'some_rule',
            '--no-require-confirmation',
            '--debug',
            '--repeat', '2']

# Generated at 2022-06-22 00:06:36.579705
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings._setup_user_dir()
    path = settings._get_user_dir_path()
    assert path.is_dir()

    settings = Settings(const.DEFAULT_SETTINGS)


# Generated at 2022-06-22 00:06:42.791576
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # Example for usage in settings.py
    class Settings(object):
        def __init__(self, *args, **kwargs):
            pass

    settings = Settings()
    settings.__class__ = Settings
    settings.__setattr__('test', '123')
    assert settings.test == '123'
    # Example for usage in any other code
    settings = Settings()
    settings.__setattr__('test', '123')
    assert settings.get('test') == '123'

# Generated at 2022-06-22 00:07:12.511968
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings(dict(foo = 'bar'))
    settings.__getattr__('foo') == 'bar'


# Generated at 2022-06-22 00:07:16.180105
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    # when item is in settings dictionary
    settings['a'] = 'b'
    assert settings.a == 'b'

    # when item is not in settings dictionary
    settings.a = 'b'
    assert settings.a == 'b'



# Generated at 2022-06-22 00:07:17.523392
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.no_colors == False
    assert settings.require_confirmation == True


# Generated at 2022-06-22 00:07:20.377051
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.foo = 'bar'
    assert settings['foo'] == 'bar'
    assert settings['baz'] == 'qux'



# Generated at 2022-06-22 00:07:31.966276
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import Logger
    from .config import Config, _get_environ_var, _get_environ_vars

    from mock import patch
    import sys

    settings = Settings(const.DEFAULT_SETTINGS)

    def reset_env_vars():
        for var in _get_environ_vars():
            del os.environ[var]

    def test_load_default_settings():
        settings.init()

        for key, value in const.DEFAULT_SETTINGS.items():
            assert settings[key] == value

    def test_load_settings_from_file():
        settings_path = settings.user_dir.joinpath('settings.py')

# Generated at 2022-06-22 00:07:33.864327
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.hello = 'world'
    assert settings.get('hello') == 'world'
    assert settings.hello == 'world'

# Generated at 2022-06-22 00:07:35.477058
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.wait_slow_command


# Generated at 2022-06-22 00:07:46.903594
# Unit test for constructor of class Settings
def test_Settings():
    _settings = Settings(const.DEFAULT_SETTINGS)
    assert _settings.get('alter_history') == True
    assert _settings.get('wait_command') == 3
    assert _settings.get('exclude_rules') == []
    assert _settings.get('priority') == {}
    assert _settings.get('history_limit') == None
    assert _settings.get('wait_slow_command') == 15
    assert _settings.get('no_colors') == False
    assert _settings.get('num_close_matches') == 3
    assert _settings.get('slow_commands') == ['lein', 'react-native-cli']
    assert _settings.get('excluded_search_path_prefixes') == []
    assert _settings.get('require_confirmation') == True

# Generated at 2022-06-22 00:07:49.192410
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.new_var = 'new_var'
    assert settings.new_var == settings['new_var']


# Generated at 2022-06-22 00:07:57.550787
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.require_confirmation == True
    assert settings.repeat == False
    assert settings.erase_history == False
    assert settings.debug == False
    assert settings.wait_command == 1
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', './sbt']
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.no_colors == False
    assert settings.num_close_matches == 3
    assert settings.priority == {}

# Generated at 2022-06-22 00:08:20.120325
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = 'test'
    assert settings['test'] == 'test'



# Generated at 2022-06-22 00:08:28.399857
# Unit test for method init of class Settings
def test_Settings_init():
    from thefuck.main import Command

    settings.init(args=None)
    assert isinstance(settings.user_dir, Path)
    assert settings.user_dir.is_dir()
    assert isinstance(settings.rules, list)
    assert isinstance(settings.exclude_rules, list)
    assert isinstance(settings.priority, dict)
    assert isinstance(settings.wait_command, int)
    assert isinstance(settings.history_limit, int)
    assert isinstance(settings.wait_slow_command, int)
    assert isinstance(settings.no_colors, bool)
    assert isinstance(settings.require_confirmation, bool)
    assert isinstance(settings.alter_history, bool)
    assert isinstance(settings.slow_commands, list)

# Generated at 2022-06-22 00:08:39.652581
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    def _init_settings_file_impl(self):
        return

    def _setup_user_dir_impl(self):
        return

    def _settings_from_file_impl(self):
        return {'require_confirmation': True}

    def _settings_from_env_impl(self):
        return {'require_confirmation': False}

    def _settings_from_args_impl(self, args):
        return {'require_confirmation': True}

    s = Settings(const.DEFAULT_SETTINGS)
    s._init_settings_file = _init_settings_file_impl
    s._setup_user_dir = _setup_user_dir_impl
    s._settings_from_file = _settings_from_file_impl
    s._settings_from_env

# Generated at 2022-06-22 00:08:47.153058
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from thefuck.utils import Namespace
    class Mock(object):
        settings = Settings(const.DEFAULT_SETTINGS)
        def __init__(self):
            self.MockSettings = type('MockSettings', (), self.settings)
    # tested attribute will be set as a new attr of MockSettings
    Mock().MockSettings.new_attr = 'new_attr'
    # tested attribute will be set as a new item of MockSettings
    Mock().MockSettings['new_item'] = 'new_item'
    assert hasattr(Mock().MockSettings, 'new_attr')
    assert Mock().MockSettings.new_attr == 'new_attr'
    assert 'new_item' in Mock().MockSettings
    assert Mock().MockSettings['new_item'] == 'new_item'

# Unit test

# Generated at 2022-06-22 00:08:51.151385
# Unit test for constructor of class Settings
def test_Settings():
    settings_new = Settings(const.DEFAULT_SETTINGS)
    for key in const.DEFAULT_SETTINGS.keys():
        assert settings_new[key] == const.DEFAULT_SETTINGS[key]


# Generated at 2022-06-22 00:08:52.699871
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.require_confirmation = False
    assert settings.require_confirmation == False

# Generated at 2022-06-22 00:08:54.181351
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.foo == None


# Generated at 2022-06-22 00:09:05.141992
# Unit test for method init of class Settings
def test_Settings_init():
    from .shells import Shell
    from .logs import get_logger
    logger = get_logger()
    s = Settings()
    s.init()
    assert isinstance(s.shell, Shell)
    assert isinstance(s.history_limit, int)
    assert isinstance(s.require_confirmation, bool)
    assert isinstance(s.rules, list)
    assert isinstance(s.priority, dict)
    assert isinstance(s.no_colors, bool)
    assert isinstance(s.debug, bool)
    assert isinstance(s.wait_command, int)
    assert isinstance(s.repeat, int)
    assert isinstance(s.alter_history, bool)
    assert isinstance(s.instant_mode, bool)

# Generated at 2022-06-22 00:09:07.213620
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    """Method __getattr__() of class Settings should return None if the
    attribute is not found in the instance."""
    assert settings.nonExistentAttribute == None

# Generated at 2022-06-22 00:09:15.533227
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from unittest.mock import patch, Mock
    mock_user_dir = Mock()
    mock_user_dir.joinpath = Mock()
    mock_user_dir.is_file = Mock()
    mock_user_dir.is_dir = Mock()
    mock_user_dir.mkdir = Mock()
    mock_user_dir.expanduser = Mock()
    mock_user_dir.joinpath().open = Mock()
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.get_user_dir_path = Mock(return_value=mock_user_dir)
    with patch.dict('os.environ', {'XDG_CONFIG_HOME': '~/.config'}):
        settings.init()
        settings.get_user_dir_

# Generated at 2022-06-22 00:09:38.826862
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    from .logs import Logger

    settings = Settings(LOG=Logger())
    assert settings.LOG

    settings = Settings()
    assert not settings.LOG



# Generated at 2022-06-22 00:09:40.183282
# Unit test for method init of class Settings
def test_Settings_init():
    s = Settings(const.DEFAULT_SETTINGS)
    s.init()

# Generated at 2022-06-22 00:09:42.152833
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    instance = Settings()
    instance.__setattr__('k', 1)
    assert instance['k'] == 1


# Generated at 2022-06-22 00:09:49.423351
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    assert s.user_dir is None
    s.init()
    assert s.user_dir
    assert s.user_dir.name == '.config'
    assert s.user_dir.parent.name == 'thefuck'
    assert s.user_dir.parent.parent.name == 'config'
    assert s.user_dir.parent.parent.parent.name == 'home'

# Generated at 2022-06-22 00:09:52.262804
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    _settings = Settings(const.DEFAULT_SETTINGS)
    _settings.not_in_dict = 'test'
    assert _settings.get_in_dict == 'test'

# Generated at 2022-06-22 00:09:53.695335
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['require_confirmation']
    assert settings.require_confirmation

# Generated at 2022-06-22 00:10:00.873010
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.correct_cd == 'cd'
    assert settings.correct_mkdir == 'mkdir'
    assert settings.alter_history == True
    assert settings.require_confirmation == False
    assert settings.no_colors == False
    assert settings.wait_slow_command == 5
    assert settings.wait_command == 1
    assert settings.repeat == 1
    assert settings.history_limit == 10
    assert settings.instant_mode == False

# Generated at 2022-06-22 00:10:04.636426
# Unit test for method init of class Settings
def test_Settings_init():
    class MockArgs:
        pass

    args = MockArgs()
    args.yes = True
    args.repeat = 3
    args.debug = True
    settings.init(args)
    assert settings.require_confirmation == False
    assert settings.repeat == 3
    assert settings.debug == True



# Generated at 2022-06-22 00:10:06.767112
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    new_settings = Settings()
    assert new_settings.require_confirmation == True


# Generated at 2022-06-22 00:10:17.036014
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    from thefuck.tests.utils import cwd

    def load_source(name, path):
        return {'rules': ['bash']}

    def _settings_from_args(args):
        return {'require_confirmation': False}

    with cwd(tempfile.mkdtemp()):
        with open('settings.py', 'w') as settings_file:
            settings_file.write("# -*- coding: utf-8 -*-\n")
            settings_file.write("# The Fuck settings file\n")
            settings_file.write("#\n")
            settings_file.write("# The rules are defined as in the example bellow:\n")
            settings_file.write("#\n")

# Generated at 2022-06-22 00:11:19.964197
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)
    assert settings.user_dir is not None
    assert settings.user_dir != ''
    assert settings.repeat == 1
    assert settings.history_limit == 5
    assert 'python' in settings.rules
    assert 'python3' in settings.rules
    assert settings.require_confirmation
    assert not settings.alter_history
    assert not settings.no_colors
    assert not settings.debug
    assert not settings.wait_command
    assert settings.wait_slow_command == 15

# Generated at 2022-06-22 00:11:29.346999
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

    assert settings.user_dir.is_dir()
    assert settings.user_dir.joinpath('settings.py').is_file()

    assert const.DEFAULT_SETTINGS.keys() == settings.keys()

    env = {'repo_alias': 'origin', 'repo_group': 'my_group'}
    with pytest.raises(Exception):
        settings.init(env)

    with pytest.raises(Exception):
        settings.init({'no_colors': 'true'})

    with pytest.raises(Exception):
        settings.init({'require_confirmation': 'true'})

    with pytest.raises(Exception):
        settings.init({'rules': 'DEFAULT_RULES'})

    with pytest.raises(Exception):
        settings

# Generated at 2022-06-22 00:11:38.471090
# Unit test for method init of class Settings
def test_Settings_init():
    import sys
    import os
    from shutil import rmtree
    from tempfile import mkdtemp
    from six import text_type
    from .logs import exception

    class Struct:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    def get_exc_info():
        exc_type, exc_val, exc_tb = sys.exc_info()
        error_path = Path(exc_tb.tb_frame.f_code.co_filename)
        return exc_type, error_path, text_type(exc_val)

    user_dir = Path(mkdtemp(suffix='-thefuck'))
    settings_path = user_dir.joinpath('settings.py')

# Generated at 2022-06-22 00:11:41.560844
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings(const.DEFAULT_SETTINGS)
    assert s != None
    print("test_Settings() passed")

test_Settings()

# Generated at 2022-06-22 00:11:42.501088
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation


# Generated at 2022-06-22 00:11:44.438408
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    dict = {'key': 'value'}
    settings = Settings(dict)
    assert settings.key == 'value'


# Generated at 2022-06-22 00:11:48.739776
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings()
    test_settings.test_key = 'test_value'
    assert test_settings['test_key'] is 'test_value'
    assert test_settings.test_key is 'test_value'

# Generated at 2022-06-22 00:11:52.613227
# Unit test for constructor of class Settings
def test_Settings():
    assert 'python3' in settings.aliases['python']
    assert 'python' in settings.aliases['py']
    assert 'PYTHONIOENCODING' in settings.env
    with pytest.raises(Exception):
        settings.update(settings.aliases['python'])

# Generated at 2022-06-22 00:11:53.899507
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings()
    settings.set('hello', 1234)
    assert settings.hello == 1234


# Generated at 2022-06-22 00:11:55.150235
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.history_limit == const.DEFAULT_SETTINGS.history_limit



# Generated at 2022-06-22 00:14:17.473602
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    random_name = "xiaoo66"
    old_settings_value = settings.get(random_name)
    settings[random_name] = "zzz"
    from_dict = settings.__getattr__(random_name)
    assert from_dict == "zzz"

    settings[random_name] = old_settings_value
    del settings[random_name]
    assert settings.__getattr__(random_name) == None


# Generated at 2022-06-22 00:14:18.880948
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.debug == True
    assert settings.alter_history == True


# Generated at 2022-06-22 00:14:28.115978
# Unit test for constructor of class Settings
def test_Settings():
    # testing settings.update()
    settings.update({'require_confirmation': False})
    settings.update({'enable_experimental': True})

    assert settings['require_confirmation'] == False
    assert settings['enable_experimental'] == True

    # testing settings.__getattr__()
    assert settings.require_confirmation == False
    assert settings.enable_experimental == True
    # the value doesn't exist
    assert settings.no_such_value == None

    # testing settings.__setattr__()
    settings.require_confirmation = True
    settings.no_such_value = "I'm here"

    assert settings['require_confirmation'] == True
    assert settings['no_such_value'] == "I'm here"

    assert settings.require_confirmation == True

# Generated at 2022-06-22 00:14:38.009786
# Unit test for constructor of class Settings
def test_Settings():
    _settings = Settings(const.DEFAULT_SETTINGS)
    _settings.init()
    assert _settings.require_confirmation == False
    assert _settings.no_colors == False
    assert _settings.rules == []
    assert _settings.exclude_rules == []
    assert _settings.wait_command == 0
    assert _settings.wait_slow_command == 1
    assert _settings.alter_history == True
    assert _settings.priority == {}
    assert _settings.history_limit == None
    assert _settings.slow_commands == []
    assert _settings.repeat == False
    assert _settings.excluded_search_path_prefixes == []
    assert _settings.instant_mode == False
    assert _settings.num_close_matches == 3

# Generated at 2022-06-22 00:14:40.320329
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    # set up
    settings['test'] = True
    # test
    assert settings.test
    # tear down
    del settings['test']


# Generated at 2022-06-22 00:14:43.420354
# Unit test for constructor of class Settings
def test_Settings():
    new_settings = Settings()
    assert new_settings == const.DEFAULT_SETTINGS
    assert isinstance(new_settings['rules'], list)

# Generated at 2022-06-22 00:14:47.721542
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import shutil
    from .logs import exception
    from .system import Path
    from . import const

    test_settings = Settings(const.DEFAULT_SETTINGS)

    temp_dir = Path(u'./tempuserdir')
    os.mkdir(temp_dir)
    temp_path = temp_dir.joinpath(u'settings.py')

# Generated at 2022-06-22 00:14:50.463882
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class TempClass(Settings):
        pass
    test_settings = TempClass()
    test_settings.temp = 'value'
    assert test_settings['temp'] == 'value'



# Generated at 2022-06-22 00:14:53.992212
# Unit test for method init of class Settings
def test_Settings_init():
    # assert not equal for method init
    assert settings.init() != settings.init(args=True)
    assert settings.init() != settings.init(args=False)



settings.init()

# Generated at 2022-06-22 00:14:55.195143
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.require_confirmation
    assert settings.repeat == 1

