

# Generated at 2022-06-22 00:06:37.018826
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.app_version == const.APP_VERSION
    assert settings.help_message == const.HELP_MESSAGE
    assert settings.no_colors
    assert settings.alter_history
    assert not settings.debug
    assert settings.instant_mode
    assert len(settings.rules) == 2
    assert len(settings.exclude_rules) == 0
    assert settings.priority == {}

# Generated at 2022-06-22 00:06:42.444339
# Unit test for method init of class Settings
def test_Settings_init():
    import mock
    from thefuck.settings import Settings
    args = mock.Mock()
    args.debug = False
    args.yes = True
    args.repeat = False
    s = Settings()
    s.init(args)
    assert s.get('require_confirmation') == False
    assert s.get('debug') == False
    assert s.get('repeat') == False


# Generated at 2022-06-22 00:06:46.014563
# Unit test for constructor of class Settings
def test_Settings():
    assert settings["require_confirmation"] == True
    assert settings["repeat"] == False
    assert settings["wait_slow_command"] == 15
test_Settings.settings = settings

# Generated at 2022-06-22 00:06:47.808457
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    s.key = 'value'
    assert s['key'] == 'value'


# Generated at 2022-06-22 00:06:50.097104
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings()
    test_settings.new_value = 42
    assert test_settings == Settings({'new_value': 42})



# Generated at 2022-06-22 00:06:51.650892
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.fuck = 'shit'
    assert settings['fuck'] == 'shit'
    assert settings.fuck == 'shit'

# Generated at 2022-06-22 00:06:55.517378
# Unit test for constructor of class Settings
def test_Settings():
    import unittest
    import doctest
    suite = unittest.TestSuite()
    suite.addTest(doctest.DocTestSuite(settings))
    return suite

# Generated at 2022-06-22 00:06:58.041552
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir
    assert settings.require_confirmation

# Generated at 2022-06-22 00:07:00.619043
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.wait_command == 6
    settings.wait_command = 5
    assert settings.wait_command == 5

# Generated at 2022-06-22 00:07:01.706860
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.rules == c

# Generated at 2022-06-22 00:07:36.526521
# Unit test for constructor of class Settings
def test_Settings():
    pass

# Generated at 2022-06-22 00:07:38.132904
# Unit test for method init of class Settings
def test_Settings_init():
    res = Settings()
    res.init()
    # print(res)



# Generated at 2022-06-22 00:07:50.063555
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert not settings.no_colors
    assert settings.debug
    assert settings.alter_history
    assert settings.wait_command == 1
    assert not settings.instant_mode
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 3
    assert settings.slow_commands == ['sudo']
    assert settings.excluded_search_path_prefixes == ['/usr', '/bin']
    assert settings.exclude_rules == ['git_push', 'vagrant']
    assert settings.rules == ['git_commit', 'firefox_bookmarks',
                              'pip']
    assert settings.priority == {'git_commit': 20, 'firefox_bookmarks': 10}
    assert settings.num_close_matches == 3
    assert settings.no_rules

# Generated at 2022-06-22 00:07:52.320093
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.verbose == False



# Generated at 2022-06-22 00:07:58.971079
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation
    assert settings.no_colors is False
    assert settings.debug is False
    assert settings.alter_history is False
    assert settings.wait_command == 3
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 9
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.priority == {}
    assert settings.instant_mode == False
    assert settings.num_close_matches == 3
    assert settings.repeat == 1



# Generated at 2022-06-22 00:08:00.967429
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules == const.DEFAULT_RULES


# Generated at 2022-06-22 00:08:10.959803
# Unit test for method init of class Settings
def test_Settings_init():
    def init(*arg, **karg):
        settings.init(*arg, **karg)

    # 1. test init without args
    # 1.1 test init without settings.py
    # os.environ.clear()
    # assert init() == const.DEFAULT_SETTINGS

    # 1.2 test init with settings.py
    # print("start test with settings.py")
    # os.chdir("tests")
    # for k, v in os.environ.items():
    #     print(k, v)
    # print("cwd", os.getcwd())
    # init()
    # for k, v in settings.items():
    #     print(k, v)
    # assert settings.items() == const.SETTINGS_FROM_FILE.items()

# Generated at 2022-06-22 00:08:12.555333
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation


# Generated at 2022-06-22 00:08:14.192190
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    s.a = 'a'
    assert s.a == 'a'


# Generated at 2022-06-22 00:08:17.716517
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings['require_confirmation']
    assert settings['no_colors']
    assert settings['debug']
    assert settings['repeat'] is None

test_Settings()

# Generated at 2022-06-22 00:09:31.358209
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    test_Settings = Settings({'test': 'test'})
    assert test_Settings.test == 'test'



# Generated at 2022-06-22 00:09:42.345816
# Unit test for constructor of class Settings
def test_Settings():
    assert hasattr(settings,'require_confirmation')
    assert settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']
    assert hasattr(settings,'alter_history')
    assert settings.alter_history == const.DEFAULT_SETTINGS['alter_history']
    assert hasattr(settings,'no_colors')
    assert settings.no_colors == const.DEFAULT_SETTINGS['no_colors']
    assert hasattr(settings, 'env_vars')
    assert settings.env_vars == const.DEFAULT_SETTINGS['env_vars']
    assert hasattr(settings, 'priority')
    assert settings.priority == const.DEFAULT_SETTINGS['priority']
    assert hasattr(settings, 'exclude_rules')
    assert settings.exclude_rules == const

# Generated at 2022-06-22 00:09:45.986609
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    expected = dict(const.DEFAULT_SETTINGS)
    expected.update(const.DEFAULT_SETTINGS_FILE)
    assert settings == expected


# Generated at 2022-06-22 00:09:47.428363
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.a = 2
    assert settings.a == 2



# Generated at 2022-06-22 00:09:50.001387
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    foo = Settings()
    foo['test'] = 'test'
    assert foo.test == 'test'


# Generated at 2022-06-22 00:09:59.057464
# Unit test for constructor of class Settings
def test_Settings():
    import os
    import sys
    import shutil
    from six.moves import StringIO
    from thefuck.utils import settings as thefuck_settings
    from thefuck.settings import Settings
    from thefuck.logs import log
    from thefuck.logs import set_log_level
    from thefuck.exceptions import FailedCommand

    set_log_level('ERROR')

    # When settings.Settings() is called
    settings = Settings()
    # Then settings is instance of settings.Settings
    assert isinstance(settings, Settings)
    # And settings is filled with const.DEFAULT_SETTINGS
    assert settings == const.DEFAULT_SETTINGS
    # And $XDG_CONFIG_HOME/thefuck and $XDG_CONFIG_HOME/thefuck/rules
    # directories are created in user home directory
   

# Generated at 2022-06-22 00:10:09.318950
# Unit test for method init of class Settings
def test_Settings_init():
    import os

    sys.modules.pop('settings', None)
    settings.user_dir = None
    settings.update(const.DEFAULT_SETTINGS)

    # Test init when no settings.py
    settings.user_dir = Path('/')
    settings.init()
    assert settings.user_dir.joinpath('settings.py').is_file()

    # Test init when no env
    user_dir = settings.user_dir
    settings.user_dir = None
    settings.init()
    assert settings.user_dir == user_dir

    # Test init when has env
    env = os.environ
    os.environ = {}
    settings.user_dir = None
    settings.init()
    assert settings.user_dir == Path('/')
    os.environ = env

    # Test init when

# Generated at 2022-06-22 00:10:11.939263
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test_key = 'test_value'
    assert settings['test_key'] == 'test_value'

# Generated at 2022-06-22 00:10:14.022224
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings({"test":"test"})
    #test for "test" in settings
    assert settings.test == "test"


# Generated at 2022-06-22 00:10:17.300112
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings()

    test_settings.key = 'value'
    assert test_settings['key'] == 'value'

    test_settings['key2'] = 'value2'
    assert test_settings.key2 == 'value2'

# Generated at 2022-06-22 00:13:32.644265
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('require_confirmation') == True
    assert settings.get('no_colors') == False
    assert settings.get('priority') == {}
    assert settings.get('wait_command') == 3
    assert settings.get('wait_slow_command') == 10
    assert settings.get('history_limit') == 10
    assert settings.get('rules') == const.DEFAULT_RULES
    assert settings.get('exclude_rules') == []
    assert settings.get('alter_history') == True
    assert settings.get('instant_mode') == False
    assert settings.get('history_db_path') == None
    assert settings.get('num_close_matches') == 3
    assert settings.get('slow_commands') == []

# Generated at 2022-06-22 00:13:34.977085
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert hasattr(settings, 'require_confirmation')
    settings.require_confirmation = False
    assert hasattr(settings, 'require_confirmation')
    assert settings.require_confirmation == False



# Generated at 2022-06-22 00:13:37.413665
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.new_attribute = 'value'
    assert settings['new_attribute'] == 'value'


# Generated at 2022-06-22 00:13:39.306346
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_setting = Settings()
    test_setting.__setattr__('key', 'value')
    assert test_setting == {'key': 'value'}


# Generated at 2022-06-22 00:13:42.256287
# Unit test for method init of class Settings
def test_Settings_init():
    s = Settings()
    s.init()
    assert s._get_user_dir_path() == Path('~/.config/thefuck').expanduser()
    assert s.require_confirmation
    assert s.slow_commands == ['lein', 'react-native', 'gradle']
    assert s.repeat is None


# Generated at 2022-06-22 00:13:43.704301
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.correct_cd == const.DEFAULT_SETTINGS['correct_cd']
    assert settings.correct_cd == True

# Generated at 2022-06-22 00:13:45.928799
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert not hasattr(settings, 'nothing')
    settings.nothing = 'yyyy'
    assert settings['nothing'] == 'yyyy'
    settings.nothing = 'zzzz'
    assert settings['nothing'] == 'zzzz'

# Generated at 2022-06-22 00:13:48.544066
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    from unittest import TestCase

    class TestSettings(TestCase):
        def test_get_existing_attribute(self):
            self.assertFalse(settings.require_confirmation)

        def test_get_notexisting_attribute(self):
            self.assertIsNone(settings.notexistingattribute)

    TestSettings().test_get_existing_attribute()
    TestSettings().test_get_notexisting_attribute()


# Generated at 2022-06-22 00:13:54.288770
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import SameRule, SameRule
    from .utils import get_closest

    class Args:
        yes = False
        debug = False
        repeat = 1

    settings = Settings()
    settings.init()

    assert settings.require_confirmation
    assert settings.change_times == 3
    assert settings.confirm_message == u'Would you like to correct {}?'
    assert settings.instant_mode
    assert settings.alter_history
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 1
    assert settings.expect_slow_command == ['sudo', 'git']
    assert settings.exclude_rules == ['same', 'noop', 'system']

# Generated at 2022-06-22 00:13:55.357483
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    test = 'test'
    s.test = test
    assert s[test] == test

