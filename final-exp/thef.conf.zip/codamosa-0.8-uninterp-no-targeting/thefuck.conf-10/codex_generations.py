

# Generated at 2022-06-22 00:06:02.200252
# Unit test for method init of class Settings
def test_Settings_init():
    # Given settings
    test_settings = Settings(const.DEFAULT_SETTINGS)

    # When init user settings
    test_settings.init()

    # Then all settings are loaded
    for key, value in const.DEFAULT_SETTINGS.items():
        assert test_settings[key] == value



# Generated at 2022-06-22 00:06:03.537350
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.init()
    assert settings.require_confirmation == True


# Generated at 2022-06-22 00:06:04.991985
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('wait_command') == 0.08


# Generated at 2022-06-22 00:06:08.634065
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    s = Settings()
    s.foo = 'bar'
    assert s.__getattr__('foo') == 'bar'


# Generated at 2022-06-22 00:06:15.812930
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    
    # _get_user_dir_path
    settings._get_user_dir_path = lambda: '~/.thefuck'
    settings.init()
    settings.user_dir = '~/.thefuck'
    
    settings._get_user_dir_path = lambda: '~/.config/thefuck'
    settings.init()
    settings.user_dir = '~/.config/thefuck'

    # _setup_user_dir
    # copy from _get_user_dir_path
    settings._get_user_dir_path = lambda: '~/.thefuck'
    settings.init()
    settings.user_dir = '~/.thefuck'
    
    settings._get_

# Generated at 2022-06-22 00:06:21.896379
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = 12345
    assert settings.get('test') == 12345
    assert settings['test'] == 12345
    assert settings.test == 12345
    assert settings == {key: getattr(settings, key) for key in const.DEFAULT_SETTINGS.keys()}
    assert settings == dict(const.DEFAULT_SETTINGS)


# Generated at 2022-06-22 00:06:24.401321
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    """
    Unit test for method __getattr__ of class Settings.
    """
    assert settings.rules == ['git_push', 'sudo']



# Generated at 2022-06-22 00:06:26.294774
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.init() == Settings()

# Unit test to check if a dictionary is returned

# Generated at 2022-06-22 00:06:34.974121
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation
    assert not settings.no_colors
    assert settings.history_limit == 100
    assert settings.wait_slow_command == 15
    assert settings.wait_command == 0
    assert settings.sudo_command == 'sudo'
    assert settings.alter_history == False
    assert settings.priority == {}
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.debug == False
    assert not hasattr(settings, 'unknow_attr')



# Generated at 2022-06-22 00:06:46.057890
# Unit test for method init of class Settings
def test_Settings_init():
    os.environ['THEFUCK_RULES'] = 'bash_history'
    os.environ['THEFUCK_PRIORITY'] = 'bash_history=1000'
    os.environ['THEFUCK_NO_COLORS'] = 'true'
    os.environ['THEFUCK_SLOW_COMMANDS'] = 'git:bower'
    os.environ['THEFUCK_EXCLUDED_SEARCH_PATH_PREFIXES'] = '/usr/local/bin'
    os.environ['THEFUCK_WAIT_COMMAND'] = '20'
    os.environ['THEFUCK_WAIT_SLOW_COMMAND'] = '30'
    os.environ['THEFUCK_NUM_CLOSE_MATCHES'] = '99'

# Generated at 2022-06-22 00:07:11.984371
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.python3 == const.DEFAULT_SETTINGS['python3']


# Generated at 2022-06-22 00:07:16.102709
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['require_confirmation'] is True
    assert settings['wait_command'] == 0
    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['priority'] == {}
    assert settings['history_limit'] == None



# Generated at 2022-06-22 00:07:17.711004
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get("require_confirmation")
    assert settings.get("debug") == False
    assert settings.get("repeat") == None

# Generated at 2022-06-22 00:07:18.599191
# Unit test for constructor of class Settings
def test_Settings():
    assert type(settings) == Settings


# Generated at 2022-06-22 00:07:21.884531
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings['some_settings'] = 1
    assert settings.some_settings == 1
    assert settings['some_settings'] == 1



# Generated at 2022-06-22 00:07:26.897887
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['rules'][0] == 'fuck'
    assert settings['priority'] == {'fuck': 1000}
    assert settings['require_confirmation'] == True
    assert settings['no_colors'] == False
    assert settings['debug'] == False
    assert settings['repeat'] == False


# Generated at 2022-06-22 00:07:28.183292
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == False


# Generated at 2022-06-22 00:07:32.651920
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    # method __getattr__ should return value of settings when the value matched
    assert settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']
    # method __getattr__ should return None if the value not matched
    assert settings.unknown == None


# Generated at 2022-06-22 00:07:35.258394
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.command_not_found == u"zsh: command not found: "
    assert settings.sudo_command == u"sudo"


# Generated at 2022-06-22 00:07:41.385931
# Unit test for method init of class Settings
def test_Settings_init():
    """Unit test for method init of class Settings."""
    from mock import patch, Mock
    from tests.utils import suppress_stdout

    with suppress_stdout(), patch.object(Settings, 'update') as update:
        settings.init(Mock(debug=True, yes=True, repeat=2))
        update.assert_called_once_with({'require_confirmation': False,
                                        'debug': True, 'repeat': 2})

# Generated at 2022-06-22 00:08:08.536438
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from .logs import log

    settings.log_file = ''
    assert log.handlers[0].baseFilename == ''
    settings.log_file = '/tmp/test_log'
    assert log.handlers[0].baseFilename == '/tmp/test_log'

# Generated at 2022-06-22 00:08:12.507111
# Unit test for method init of class Settings
def test_Settings_init():
    """This function tests Settings init
    by asserting the initialised settings should be exactly equal to
    the default settings in the file const.py
    """
    # test initialisation
    settings.init()
    # compare result with default settings
    assert settings == const.DEFAULT_SETTINGS

# Unit tests for method _get_user_dir_path of class Settings

# Generated at 2022-06-22 00:08:14.145585
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.attr = 'attr'
    assert settings.attr == 'attr'



# Generated at 2022-06-22 00:08:24.512560
# Unit test for method init of class Settings
def test_Settings_init():
    from .tests.utils import Rule, RuleMock

    settings.init()

    assert settings.user_dir.endswith('.config/thefuck/')
    rules_dir = settings.user_dir.joinpath('rules/')
    assert rules_dir.is_dir()

    path = settings.user_dir.joinpath('settings.py')
    assert path.is_file()
    assert path.read_text() == const.SETTINGS_HEADER

    assert settings.rules == [RuleMock(Rule)]
    assert settings.exclude_rules == []
    assert settings.priority == {'': 1}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.wait_command == 1
    assert settings.history_limit == 10


# Generated at 2022-06-22 00:08:30.991211
# Unit test for method init of class Settings
def test_Settings_init():
    """
    Ensures that Settings is initialized correctly for the first time.

    1. Settings is initialized with default settings
    2. User home directory is created if it doesn't exist
    3. Settings file is created if it doesn't exist
    4. Settings file is filled with correct content
    """
    from mock import patch, call

    def side_effect_path_joinpath(path, *paths):
        path_mock = path
        for path in paths:
            path_mock += '/' + path
        return path_mock

    with patch('thefuck.settings.Path.joinpath') as joinpath_mock:
        joinpath_mock.side_effect = side_effect_path_joinpath


# Generated at 2022-06-22 00:08:33.290576
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert dict.__getattr__({'foo': 'bar'}, 'keys') == [u'foo']



# Generated at 2022-06-22 00:08:41.091828
# Unit test for constructor of class Settings
def test_Settings():
    # Test no argument
    settings_no_arg = Settings()
    settings_no_arg.init()
    assert settings_no_arg.__dict__ == const.DEFAULT_SETTINGS

    # Test with argument
    settings_arg = Settings()
    settings_arg.init(argparse.Namespace(yes=True, debug=True, repeat=True))
    assert settings_arg.require_confirmation == False
    assert settings_arg.debug == True
    assert settings_arg.repeat == True



# Generated at 2022-06-22 00:08:44.467787
# Unit test for method init of class Settings
def test_Settings_init():
    args = lambda x: argparse.Namespace(yes=x)

    settings.init(args(False))
    assert settings['require_confirmation']

    settings.init(args(True))
    assert not settings['require_confirmation']

    settings.init()
    assert settings['require_confirmation']

# Generated at 2022-06-22 00:08:49.373265
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    class Element(object):
        pass
    settings = Settings({'element': Element()})
    assert settings.element.__class__.__name__ == 'Element'

# Generated at 2022-06-22 00:08:58.209121
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    from .system import Path
    from . import const

    settings.init()

    settings.update(
        const.DEFAULT_SETTINGS)
    settings._init_settings_file()
    settings.update(settings._settings_from_file())
    f = open('/tmp/settings.py', 'w')
    f.write(u'settings.py')
    f.close()
    settings.update({'user_dir': Path('/tmp')})
    settings.update(settings._settings_from_file())
    f = open('/tmp/settings.py', 'w')
    f.write(const.SETTINGS_HEADER)
    for setting in const.DEFAULT_SETTINGS.items():
        f.write(u'# {} = {}\n'.format(*setting))


# Generated at 2022-06-22 00:09:53.550176
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    newsettings = Settings()
    newsettings.__setattr__('test', 'success')
    assert newsettings.__getattr__('test') == 'success'

    try:
        newsettings.__setattr__(1, 'error')
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-22 00:10:00.793845
# Unit test for method init of class Settings

# Generated at 2022-06-22 00:10:11.265283
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import tempfile
    import shutil
    from thefuck import const
    from thefuck.utils import get_all_executables

    # create tempory directory to work with config files
    working_path = tempfile.mkdtemp()
    # create tmp config
    settings_file = os.path.join(working_path, 'settings.py')
    with open(settings_file, "w") as f:
        f.write(const.SETTINGS_HEADER)
        f.write("rules = ['fuu', 'bar']\n")
        f.write("rules = ['fuu', 'bar']\n")
        f.write("require_confirmation = False\n")
        f.write("debug = False\n")
    # create tmp env

# Generated at 2022-06-22 00:10:12.677268
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.wait_command == const.DEFAULT_WAIT_COMMAND

# Generated at 2022-06-22 00:10:18.244969
# Unit test for constructor of class Settings
def test_Settings():
    init_settings = Settings(const.DEFAULT_SETTINGS)
    assert init_settings == const.DEFAULT_SETTINGS
    init_settings.update({'test': 'test'})
    assert const.DEFAULT_SETTINGS == init_settings
    assert init_settings.test == 'test'
    init_settings.update({'test': 'test1'})
    assert init_settings.test == 'test1'

# Generated at 2022-06-22 00:10:19.478062
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    result = settings.help
    assert 'Show how to use' in result



# Generated at 2022-06-22 00:10:21.538301
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings['exclude_rules'] == []



# Generated at 2022-06-22 00:10:23.677161
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings['foo'] = 'bar'
    assert settings.foo == 'bar'


# Generated at 2022-06-22 00:10:25.519719
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation is True
    assert settings.__getattr__(u'require_confirmation') is True



# Generated at 2022-06-22 00:10:30.905821
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(
            {'rules': const.DEFAULT_RULES,
             'priorities': {rule: i for i, rule in
                enumerate(const.DEFAULT_RULES)}
            }
    )
    assert (settings['rules'] == const.DEFAULT_RULES)
    assert (settings['priorities'] == {rule: i for i, rule in
                enumerate(const.DEFAULT_RULES)})

# Generated at 2022-06-22 00:12:36.260001
# Unit test for constructor of class Settings
def test_Settings():
    for attr, value in const.DEFAULT_SETTINGS.items():
        assert getattr(settings, attr) == value
    assert settings['priority'] == const.DEFAULT_SETTINGS['priority']

# Generated at 2022-06-22 00:12:37.475250
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation is True
    assert settings.not_existing is None



# Generated at 2022-06-22 00:12:40.386620
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert const.DEFAULT_SETTINGS['require_confirmation'] == settings.require_confirmation



# Generated at 2022-06-22 00:12:43.919916
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test__setattr__ = 42
    assert settings['test__setattr__'] == 42
    assert settings.test__setattr__ == 42
    del settings.test__setattr__
    assert 'test__setattr__' not in settings

# Generated at 2022-06-22 00:12:49.936055
# Unit test for method init of class Settings
def test_Settings_init():
    import pkg_resources

    class Args(object):
        def __init__(self, yes=False, debug=False, repeat=False):
            self.yes = yes
            self.debug = debug
            self.repeat = repeat

    def get_output(yes=False, debug=False, repeat=False, return_code=0):
        from .logs import log_command
        from .utils import get_closest, get_history

        settings.init(Args(yes, debug, repeat))
        settings.exclude_rules = ['echo']

        command_script = text_type(
            pkg_resources.resource_filename(
                'thefuck', 'resources/bash_history.sh')) + u' && echo None'
        command = u'fuck'

        closest = get_closest(command)
        commands

# Generated at 2022-06-22 00:12:51.076323
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.no_colors == const.DEFAULT_SETTINGS['no_colors']



# Generated at 2022-06-22 00:12:51.899019
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.user_dir



# Generated at 2022-06-22 00:12:52.893449
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.init() == None

# Generated at 2022-06-22 00:13:02.211129
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.slow_commands == const.DEFAULT_SETTINGS['slow_commands']
    assert settings.excluded_search_path_prefixes == const.DEFAULT_SETTINGS['excluded_search_path_prefixes']
    assert settings.alter_history == const.DEFAULT_SETTINGS['alter_history']
    assert settings.no_colors == const.DEFAULT_SETTINGS['no_colors']
    assert settings.repeat == const.DEFAULT_SETTINGS['repeat']
    assert settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']
    assert settings.history_limit == const.DEFAULT_SETTINGS['history_limit']
    assert settings.rules == const.DEFAULT_SETTINGS['rules']
    assert settings.exclude_rules == const.DEFAULT

# Generated at 2022-06-22 00:13:08.106834
# Unit test for method init of class Settings
def test_Settings_init():
    settings.update(const.DEFAULT_SETTINGS)
    args = None
    settings.init(args)
    assert settings.get("rules") == [
        'fuck_mercurial', 'fuck_git_push', 'fuck_git_amend', 'fuck_git_pull',
        'fuck_git_checkout', 'fuck_git_diff', 'fuck_git_reset', 'fuck_sudo',
        'fuck_python_command'
    ]