

# Generated at 2022-06-22 00:06:08.710368
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings({'foo': 'bar'})

    # settings.init()



# Generated at 2022-06-22 00:06:16.340202
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings['require_confirmation'] == True
    assert settings['no_colors'] == False
    assert settings['repeat'] == False
    assert settings['use_scream'] == False
    assert settings['wait_command'] == 3
    assert settings['slow_commands'] == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings['exclude_rules'] == []
    assert settings['history_limit'] == None
    assert settings['alter_history'] == True
    assert settings['instant_mode'] == False
    assert settings['wait_slow_command'] == 10
    assert settings['num_close_matches'] == 3

# Generated at 2022-06-22 00:06:19.727165
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.__setattr__('key', 'value')
    assert settings['key'] == 'value'



# Generated at 2022-06-22 00:06:30.713194
# Unit test for constructor of class Settings
def test_Settings():
    from thefuck.settings import Settings
    test = Settings(const.DEFAULT_SETTINGS)

    assert test['require_confirmation'] == True
    assert test['slow_commands'] == []
    assert test['num_close_matches'] == 3
    assert test['priority'] == {}
    assert test['exclude_rules'] == []
    assert test['excluded_search_path_prefixes'] == []
    assert test['alter_history'] == False
    assert test['history_limit'] == None
    assert test['wait_command'] == 3
    assert test['wait_slow_command'] == 15
    assert test['rules'] == ['fuck_alias', 'git_push', 'python_command', 'sudo', 'pip_command']
    assert test['instant_mode'] == False
    assert test['no_colors']

# Generated at 2022-06-22 00:06:35.334184
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    # Test if the attribute not exists
    assert settings.__getattr__('test_attr') == None
    # Test if the attribute exists
    settings.update({"test_attr": "test"})
    assert settings.__getattr__('test_attr') == 'test'


# Generated at 2022-06-22 00:06:38.348247
# Unit test for method init of class Settings
def test_Settings_init():
    from .types import Settings as SettingsT

    class Args:
        yes = False
        debug = None
        repeat = None

    settings.clear()
    settings.init()
    assert(isinstance(settings, SettingsT))

# Generated at 2022-06-22 00:06:47.373328
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import log

    def _test(args, expected_exception):
        from .logs import exception

        settings._setup_user_dir()
        settings._init_settings_file()

        if expected_exception:
            try:
                settings.init(args)
            except Exception:
                exception("Can't load settings from file", sys.exc_info())
        else:
            settings.init(args)

    import pytest
    test_args = [('settings', None), ('env', TypeError)]
    for args, expected_exception in test_args:
        yield _test, args, expected_exception



# Generated at 2022-06-22 00:06:51.394209
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import reset_logger
    reset_logger()
    import argparse
    args = argparse.Namespace(yes=False, debug=False, repeat=False)

    settings.init(args)
    assert settings.get('require_confirmation') == True
    assert settings.get('debug') == False
    assert settings.get('repeat') == False

settings.init()

# Generated at 2022-06-22 00:06:52.895516
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    d = {'foo': 'bar'}
    settings = Settings(d)
    assert settings.foo == d['foo']

# Generated at 2022-06-22 00:06:55.853430
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    Settings().__setattr__('key', 'value') == \
        {'key': 'value'}

# Generated at 2022-06-22 00:07:42.399483
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.slow_commands == [
        "sudo", "apt-get", "wine", "pip", "pacman", "ruby"]



# Generated at 2022-06-22 00:07:45.705488
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert str(settings.user_dir) == str(Path('~/.config/thefuck').expanduser())
    assert settings.wait_command == 1

# Generated at 2022-06-22 00:07:47.972259
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings(test1=1)
    assert settings.test1 == 1
    assert settings.test2 is None


# Generated at 2022-06-22 00:07:56.219890
# Unit test for method init of class Settings
def test_Settings_init():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    test_settings._get_user_dir_path = lambda: Path('test')
    test_settings._init_settings_file = lambda: True
    test_settings._settings_from_file = lambda: {'key': 'value'}
    test_settings._settings_from_env = lambda: {'key1': 'value'}
    test_settings._settings_from_args = lambda: {'key2': 'value'}
    test_settings.init()
    assert test_settings == {'key': 'value', 'key1': 'value', 'key2': 'value'}


# Generated at 2022-06-22 00:08:00.561999
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    # Arrange
    settings = Settings()

    # Act
    settings.key = "value"

    # Assert
    assert settings.key == "value"



# Generated at 2022-06-22 00:08:02.304772
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['alter_history'] is True



# Generated at 2022-06-22 00:08:04.909106
# Unit test for constructor of class Settings
def test_Settings():
    assert isinstance(settings, Settings)
    assert isinstance(settings, dict)


# Generated at 2022-06-22 00:08:07.840795
# Unit test for constructor of class Settings
def test_Settings():
    '''
    >>> test_Settings()
    default settings
    '''
    import json
    import inspect

# Generated at 2022-06-22 00:08:14.531822
# Unit test for constructor of class Settings
def test_Settings():
    import pytest
    if 'DEBUG' in os.environ:
        del os.environ['DEBUG']
    if 'REPEAT' in os.environ:
        del os.environ['REPEAT']
    if 'RULES' in os.environ:
        del os.environ['RULES']
    if 'PRIORITY' in os.environ:
        del os.environ['PRIORITY']
    if 'EXCLUDED_SEARCH_PATH_PREFIXES' in os.environ:
        del os.environ['EXCLUDED_SEARCH_PATH_PREFIXES']
    if 'ALTER_HISTORY' in os.environ:
        del os.environ['ALTER_HISTORY']
    if 'INSTANT_MODE' in os.environ:
        del os

# Generated at 2022-06-22 00:08:16.696280
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.test = 'test'
    assert settings['test'] == 'test'


# Generated at 2022-06-22 00:09:15.644369
# Unit test for constructor of class Settings
def test_Settings():
    settings.init(None)
    assert settings.user_dir == '/home/user/.config/thefuck'
    assert settings.rules == ['bash_history', 'git_commit']
    assert settings.exclude_rules == []
    assert settings.require_confirmation == True
    assert settings.priority == {'bash_history': 100, 'git_commit': 50}
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant', 'bundle', 'composer']
    assert settings.num_close_matches == 3
    assert settings.alter_history == True

# Generated at 2022-06-22 00:09:20.743035
# Unit test for method init of class Settings
def test_Settings_init():
    args = type('', (), {})()
    args.yes = True
    args.debug = True
    args.repeat = True
    settings.init(args)
    assert settings.get('require_confirmation') == False
    assert settings.get('debug') == True
    assert settings.get('repeat') == True

# Generated at 2022-06-22 00:09:22.034615
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.user_dir == settings._get_user_dir_path()

# Generated at 2022-06-22 00:09:23.765897
# Unit test for constructor of class Settings
def test_Settings():
    print(settings.alter_history)
    settings.alter_history = False
    print(settings.alter_history)

# Generated at 2022-06-22 00:09:25.383958
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.a = 'b'
    assert settings['a'] == 'b'

# Generated at 2022-06-22 00:09:27.556412
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.command == const.DEFAULT_SETTINGS['command']
    settings.command = '!!'
    assert settings.command == '!!'


# Generated at 2022-06-22 00:09:30.843748
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    obj = Settings({"key": "value"})
    assert obj.__getattr__("key") == obj.get("key")



# Generated at 2022-06-22 00:09:31.773983
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation


# Generated at 2022-06-22 00:09:39.468303
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.get('user_dir') == Path(
        os.environ.get('XDG_CONFIG_HOME', '~/.config')) \
        .joinpath('thefuck')
    assert settings.require_confirmation
    assert not settings.no_colors
    assert not settings.debug
    assert settings.repeat == 1
    assert settings.alter_history
    assert not settings.instant_mode



# Generated at 2022-06-22 00:09:41.152862
# Unit test for method init of class Settings
def test_Settings_init():
    import json

    # os.environ.update(JSON_SETTINGS)
    Settings.init()


# Generated at 2022-06-22 00:11:36.572546
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings['key'] = 'value'
    assert settings.key == 'value'


# Generated at 2022-06-22 00:11:38.561674
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert(list(settings.keys()) == list(const.DEFAULT_SETTINGS.keys()))


# Generated at 2022-06-22 00:11:41.301285
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings['a'] = 1
    assert settings.a == 1
    assert settings.get('a') == 1



# Generated at 2022-06-22 00:11:44.049701
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # Backup
    backup = settings.copy()

    # Mock of setting
    settings.test = True
    assert settings.test

    # Reset
    settings.clear()
    settings.update(backup)

# Generated at 2022-06-22 00:11:46.249902
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.test_key = 2
    assert settings.test_key == 2


# Generated at 2022-06-22 00:11:49.316822
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings.get('require_confirmation') == settings['require_confirmation']
    assert settings['require_confirmation'] == True


# Generated at 2022-06-22 00:11:52.851685
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.attribute1 = 'value1'
    settings.attribute2 = 'value2'
    assert settings['attribute1'] == 'value1'
    assert settings['attribute2'] == 'value2'


# Generated at 2022-06-22 00:11:57.501292
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings({'key1': 'value1', 'key2': 'value2'})
    assert settings.get('key1') == 'value1'
    settings.__setattr__('key1', 'new_value1')
    assert settings.get('key1') == 'new_value1'
    settings.__setattr__('key3', 'value3')
    assert settings.get('key3') == 'value3'

# Generated at 2022-06-22 00:12:06.122461
# Unit test for method init of class Settings
def test_Settings_init():
    temp_settings = Settings()
    temp_settings.init()
    settings_file = settings.user_dir.joinpath('settings.py')
    assert settings_file.is_file()
    settings_file_content = open(settings_file, 'r').read()
    assert settings_file_content.startswith(const.SETTINGS_HEADER)
    assert settings_file_content.startswith('# ')
    assert settings_file_content.startswith('# This file is created by The Fuck')
    assert settings_file_content.endswith('# alter_history = True\n')
    assert settings_file_content.endswith('# wait_slow_command = 15\n')

# Generated at 2022-06-22 00:12:16.606837
# Unit test for method init of class Settings
def test_Settings_init():
    args = mock.Mock(yes=None, debug=False, repeat=None)
    with mock.patch('subprocess.Popen') as Popen,\
            mock.patch('thefuck.conf.settings._init_settings_file',
                       return_value=None),\
            mock.patch('thefuck.conf.settings._settings_from_file',
                       return_value={'settings': 'values'}),\
            mock.patch('thefuck.conf.settings._settings_from_env',
                       return_value={'settings': 'env_values'}),\
            mock.patch('thefuck.conf.settings._settings_from_args',
                       return_value={'settings': 'args_values'}):
        settings.init(args)
        assert settings['settings'] == 'args_values'