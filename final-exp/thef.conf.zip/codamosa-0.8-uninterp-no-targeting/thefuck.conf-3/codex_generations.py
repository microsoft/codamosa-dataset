

# Generated at 2022-06-22 00:06:10.985990
# Unit test for constructor of class Settings
def test_Settings():
    settings.update(const.DEFAULT_SETTINGS)
    settings.init()

    # Test the output of `python -m thefuck --help`
    for item in const.DEFAULT_SETTINGS.items():
        print(str(item))

# Generated at 2022-06-22 00:06:13.064136
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    def get():
        settings.foo = 'bar'

    get()
    assert settings['foo'] == 'bar'


# Generated at 2022-06-22 00:06:15.609120
# Unit test for method init of class Settings
def test_Settings_init():
    test_settings = Settings(const.DEFAULT_SETTINGS)
    test_settings.init()
    assert test_settings['require_confirmation'] == True

# Generated at 2022-06-22 00:06:18.264298
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.require_confirmation
    del settings.require_confirmation
    settings.require_confirmation = False
    assert not settings.require_confirmation

# Generated at 2022-06-22 00:06:24.541532
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()

    # Test user config
    assert settings.user_dir.is_dir()
    assert settings.user_dir.joinpath('settings.py').is_file()

    # Test default_settings
    assert settings.require_confirmation is True
    assert settings.rules == ['cd_parent', 'git_push', 'git_add', 'git_reset',
                              'pip_install', 'python_command', 'sudo']

# Generated at 2022-06-22 00:06:30.452640
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class Mod:
        def __init__(self):
            self.settings = Settings(
                dict(a=1, b=2))

    obj = Mod()
    assert obj.settings['a'] == 1
    assert obj.settings.a == 1

    obj.settings.a = 9
    assert obj.settings['a'] == 9
    assert obj.settings.a == 9

# Generated at 2022-06-22 00:06:38.694679
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('require_confirmation',False) == True
    assert settings.get('no_colors', True) == False
    assert settings.get('rules', 'default') == 'default'
    assert settings.get('priority', 'default') == 'default'
    assert settings.get('alter_history', False) == False
    assert settings.get('wait_command', 1) == 1
    assert settings.get('history_limit', 1000) == 1000
    assert settings.get('wait_slow_command', 15) == 15
    assert settings.get('debug', False) == False

# Generated at 2022-06-22 00:06:40.923092
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.test = {1,2,3}

    assert settings == {"test": {1,2,3}}


# Generated at 2022-06-22 00:06:44.100624
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class Dummy(object):
        pass
    obj = Dummy()
    settings = Settings()
    settings.obj = obj
    assert settings['obj'] == obj


# Generated at 2022-06-22 00:06:44.929672
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings()
    s.init()
    assert s.require_confirmation == True
    assert s.alter_history == True

# Generated at 2022-06-22 00:07:23.008383
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    temp_settings = Settings(const.DEFAULT_SETTINGS)
    temp_settings.app_name = 'test_app_name'
    assert temp_settings.app_name == 'test_app_name'


# Generated at 2022-06-22 00:07:28.694640
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class FakeSettings(object):
        def __init__(self):
            self.test_attr = 'test_attr_value'

    settings = FakeSettings()
    assert settings.test_attr == 'test_attr_value'

    settings.test_attr = 'new_test_attr_value'
    assert settings.test_attr == 'new_test_attr_value'



# Generated at 2022-06-22 00:07:30.875208
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    # Returns default value from const.DEFAULT_SETTINGS
    assert settings.require_confirmation == False

    # Returns value from const.ENV_TO_ATTR
    assert settings.rules == const.DEFAULT_RULES

    # Returns value that was set using __setattr__
    settings.something = 'something'
    assert settings.something == 'something'


# Generated at 2022-06-22 00:07:32.946896
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings['test_key'] = 'test_value'
    assert settings.test_key == settings['test_key']


# Generated at 2022-06-22 00:07:35.211539
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.test = '1234'
    assert settings.test == '1234'


# Generated at 2022-06-22 00:07:46.594462
# Unit test for constructor of class Settings
def test_Settings():

    # test for __getattr__()
    assert settings.wait_command == 3

    # test for __setattr__()
    into_settings = 'test_Settings'
    settings.test_Settings = into_settings
    assert settings.test_Settings == into_settings
    assert 'test_Settings' in settings

    # test for _get_user_dir_path()
    # 1 -- use default value (XDG_CONFIG_HOME)
    os.environ.pop('XDG_CONFIG_HOME', None)
    expected_user_dir = os.path.expanduser('~/.config/thefuck')
    user_dir = settings._get_user_dir_path()
    assert expected_user_dir == user_dir
    # 2 -- use assigned value

# Generated at 2022-06-22 00:07:47.614374
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.history_limit == 20


# Generated at 2022-06-22 00:07:52.282331
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.rules == const.DEFAULT_SETTINGS['rules']
    assert settings.nocolor == const.DEFAULT_SETTINGS['no_colors']
    assert settings.help_command == const.DEFAULT_SETTINGS['help_command']
    assert not settings.alter_history
    assert not settings.instant_mode

# Generated at 2022-06-22 00:07:54.062800
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.history_limit == 500
    settings['history_limit'] = 600
    assert settings.history_limit == 600

# Generated at 2022-06-22 00:07:56.278681
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == True
    assert settings.debug == False


# Generated at 2022-06-22 00:08:36.400543
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['require_confirmation'] == True
    assert settings['repeat'] == False

# Generated at 2022-06-22 00:08:38.033577
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.fuck = True
    assert settings['fuck']

# Generated at 2022-06-22 00:08:39.217015
# Unit test for constructor of class Settings
def test_Settings():
    assert settings == const.DEFAULT_SETTINGS


# Generated at 2022-06-22 00:08:41.212787
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == const.DEFAULT_SETTINGS.get('require_confirmation')


# Generated at 2022-06-22 00:08:47.696878
# Unit test for method init of class Settings
def test_Settings_init():
    """
    Test for method init of class Settings
    Author: @glouk
    """
    import unittest
    import six
    import subprocess
    from six import text_type
    from mock import patch
    from .logs import exception


# Generated at 2022-06-22 00:08:49.861068
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings.get('require_confirmation')
    assert settings.get('colors') == colors

# Generated at 2022-06-22 00:08:58.602789
# Unit test for method init of class Settings
def test_Settings_init():
    from unittest import mock
    from io import StringIO

    settings.init()
    expected_settings = const.DEFAULT_SETTINGS.copy()
    expected_settings['user_dir'] = settings._get_user_dir_path()
    assert settings == expected_settings

    settings = Settings()
    path = settings._get_user_dir_path().joinpath('settings.py')
    with mock.patch(__name__ + '.open', mock.mock_open(
            read_data=u'require_confirmation = False\n')) as mock_open:
        settings.init()
    assert settings['require_confirmation'] == False
    mock_open.assert_called_once_with(str(path))

    settings = Settings()

# Generated at 2022-06-22 00:09:00.333178
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # Test for __setattr__ method
    settings.a = 'b'
    assert settings['a'] == 'b'


# Generated at 2022-06-22 00:09:03.889438
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings['require_confirmation'] == True
    assert settings.require_confirmation == True


# Generated at 2022-06-22 00:09:05.857782
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.rules == const.DEFAULT_RULES
    settings.rules = ['foo']
    assert settings.rules == ['foo']

# Generated at 2022-06-22 00:10:40.692512
# Unit test for constructor of class Settings
def test_Settings():
    assert len(settings) == len(const.DEFAULT_SETTINGS)
    assert settings.rules == const.DEFAULT_RULES
    assert settings.priority == {rule: 0 for rule in settings.rules}
    assert settings.wait_command == 2
    assert settings.history_limit == 1000
    assert settings.require_confirmation
    assert settings.wait_slow_command == 15
    assert settings.exclude_rules == []
    assert settings.slow_commands == []
    assert settings.num_close_matches == 3
    assert settings.alter_history
    assert settings.excluded_search_path_prefixes == ['/usr']

# Generated at 2022-06-22 00:10:43.767221
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    s.test_Settings___setattr__ = 'test_Settings___setattr__'
    assert s['test_Settings___setattr__'] == 'test_Settings___setattr__'
    assert s.test_Settings___setattr__ == 'test_Settings___setattr__'


# Generated at 2022-06-22 00:10:45.361816
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation is True


# Generated at 2022-06-22 00:10:47.394047
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings({"a":"aa"})
    assert s["a"] == "aa"
    s.b = "bb"
    assert s["b"] == "bb"


# Generated at 2022-06-22 00:10:48.489182
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.a = 1
    assert settings['a'] == 1

# Generated at 2022-06-22 00:10:58.187471
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.slow_commands == (
        'sudo', 'ember', 'rails', 'npm',)
    assert settings.rules == (
        'brew_update', 'brew_reinstall', 'brew_install', 'brew_uninstall',
        'brew_missing', 'gem_install', 'npm_install', 'npm_uninstall',
        'npm_missing', 'npm_reinstall', 'npm_update', 'man_pages',
        'locate_file',)
    assert settings.exclude_rules == ()
    assert settings.require_confirmation == False
    assert settings.no_colors == False
    assert settings.wait_command == 3
    assert settings.slow_commands == ('sudo', 'ember', 'rails', 'npm',)

# Generated at 2022-06-22 00:11:06.963318
# Unit test for method init of class Settings
def test_Settings_init():
    import sys
    import os
    import tempfile
    from .system import Path
    from .logs import CapturedLogger
    from .utils import wrap, restore
    from .settings import Settings

    # Create user dir
    user_dir = Path(tempfile.mkdtemp())

    # Set user dir
    wrap(Settings, '_get_user_dir_path', lambda self: user_dir)

    # Write settings.py
    with user_dir.joinpath('settings.py').open(mode='w') as settings_file:
        settings_file.write(const.SETTINGS_HEADER)
        settings_file.write('require_confirmation = False\n')
        settings_file.write('slow_commands = "fuck:shit"\n')
        settings_file.write('response_timeout = 666\n')

# Generated at 2022-06-22 00:11:17.626583
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    from tempfile import mkdtemp
    from shutil import rmtree
    from .logs import config_log
    from .system import TemporaryDirectory

    class TestSettings(Settings):
        def _setup_user_dir(self):
            self.user_dir = Path(mkdtemp())
        def _init_settings_file(self):
            pass
        def _settings_from_file(self):
            return {}
        def _settings_from_env(self):
            return {}
        def _settings_from_args(self, args):
            return {}

    settings = TestSettings()

    # Test _init_settings_file and _settings_from_file

# Generated at 2022-06-22 00:11:20.577732
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings()
    settings.var = 'value'
    assert settings.var == 'value'


# Generated at 2022-06-22 00:11:29.555253
# Unit test for method init of class Settings
def test_Settings_init():
    DEFAULT_SETTINGS = const.DEFAULT_SETTINGS
    from .logs import exception
    from .logs import capture_exception
    import thefuck
    from .logs import init_log
    args = thefuck.Arguments()
    settings = Settings(DEFAULT_SETTINGS)
    args.yes = True
    args.debug = False
    args.repeat = None
    settings.init(args)
    assert settings.require_confirmation == DEFAULT_SETTINGS['require_confirmation']
    assert settings.debug == DEFAULT_SETTINGS['debug']
    assert settings.repeat == DEFAULT_SETTINGS['repeat']
    init_log()
    args.repeat = DEFAULT_SETTINGS['repeat']
    from .logs import capture_exception
    with capture_exception():
        settings

# Generated at 2022-06-22 00:15:26.785148
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.update({"a": "b"})
    assert settings["a"] == "b"


# Generated at 2022-06-22 00:15:32.702595
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import capture_logging
    from .logs import exception
    import tempfile

    def from_env(val):
        settings.update(settings._settings_from_env())

    def from_args(val):
        settings.update(settings._settings_from_args(val))

    with tempfile.TemporaryDirectory() as tmp_dir:
        settings.user_dir = Path(tmp_dir)

# Generated at 2022-06-22 00:15:38.297292
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['require_confirmation']
    assert not settings['instant_mode']
    assert settings['use_notify']
    assert settings['use_temporary_history']
    assert settings['repeat'] == 1
    assert settings['history_limit'] == 500


if __name__ == '__main__':
    test_Settings()