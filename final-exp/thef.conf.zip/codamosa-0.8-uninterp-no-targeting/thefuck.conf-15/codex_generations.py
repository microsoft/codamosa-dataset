

# Generated at 2022-06-22 00:06:30.811114
# Unit test for method init of class Settings
def test_Settings_init():
    # Check init() initialize default settings correctly
    init_settings = Settings()
    init_settings.init()
    assert init_settings == const.DEFAULT_SETTINGS
    # Check init() overwrite settings from file
    from .system import Path
    fake_settings_path = Path(__file__, '..', 'test_settings.py')
    init_settings = Settings()
    init_settings.user_dir = Path(__file__, '..', 'test_settings')
    init_settings.init()

# Generated at 2022-06-22 00:06:32.465026
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test = 1
    assert settings['test'] == 1



# Generated at 2022-06-22 00:06:33.571999
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.test_attr = 'qwerty'
    assert settings['test_attr'] == 'qwerty'



# Generated at 2022-06-22 00:06:35.840761
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_class = Settings()
    test_class.key = 'value'
    assert test_class['key'] == 'value'

# Generated at 2022-06-22 00:06:38.835817
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings(a=0)
    s.__setattr__('b', 1)
    assert s['b'] == 1
    s.__setattr__('a', 2)
    assert s['a'] == 2

# Generated at 2022-06-22 00:06:41.517111
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert(settings.history_limit == 10)
    assert(settings.require_confirmation == True)



# Generated at 2022-06-22 00:06:46.987981
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.init() == None
    assert settings.init(args = ['--yes'])['require_confirmation'] == False
    assert settings.init(args = ['--debug'])['debug'] == True
    assert settings.init(args = ['--repeat', '4'])['repeat'] == 4
    import pdb; pdb.set_trace()

# Generated at 2022-06-22 00:06:47.894312
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation

# Generated at 2022-06-22 00:06:51.525769
# Unit test for method init of class Settings
def test_Settings_init():
    _default = const.DEFAULT_SETTINGS
    if sys.version_info.major == 2:
        _default = dict(map(lambda x: (x[0], unicode(x[1])), _default.items()))
    assert settings.init(None) is None
    assert settings == _default

# Generated at 2022-06-22 00:06:56.503348
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    class Settings(dict):
        dict.__getattr__ = Settings.__getattr__
        dict.__setattr__ = Settings.__setattr__

    settings = Settings({'rules': ['test']})
    assert settings.rules == ['test']


# Get attribute from the class

# Generated at 2022-06-22 00:07:38.175195
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test_value = 'test'
    assert settings['test_value'] == 'test'


# Generated at 2022-06-22 00:07:50.102393
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['require_confirmation'] == True
    assert settings['rules'] == list(const.DEFAULT_RULES)
    assert settings['priority'] == dict(const.DEFAULT_PRIORITY)
    assert settings['wait_command'] == 1
    assert settings['wait_slow_command'] == 15
    assert settings['history_limit'] == None
    assert settings['no_colors'] == False
    assert settings['alter_history'] == True
    assert settings['exclude_rules'] == []
    assert settings['instant_mode'] == False
    assert settings['debug'] == False
    assert settings['num_close_matches'] == 3
    assert settings['slow_commands'] == []
    assert settings['excluded_search_path_prefixes'] == []
    assert settings['repeat'] == True


# Generated at 2022-06-22 00:07:51.290487
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    for key in const.DEFAULT_SETTINGS:
        assert settings[key] == settings.get(key)

# Generated at 2022-06-22 00:07:59.067483
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('require_confirmation') == True
    assert settings.get('wait_command') == 3
    assert settings.get('rules') == const.DEFAULT_RULES
    assert settings.get('priority') == {}
    assert settings.get('history_limit') == None
    assert settings.get('exclude_rules') == []
    assert settings.get('repeat') == False
    assert settings.get('wait_slow_command') == 15
    assert settings.get('slow_commands') == ['sudo']
    assert settings.get('num_close_matches') == 3
    assert settings.get('alter_history') == False
    assert settings.get('excluded_search_path_prefixes') == []
    assert settings.get('no_colors') == False
    assert settings.get('debug') == False
   

# Generated at 2022-06-22 00:08:01.513556
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.foo = 'bar'
    assert settings.foo == 'bar'


# Generated at 2022-06-22 00:08:11.511461
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings_ = Settings(
        {"profile": True,
         "wait_slow_command": 4,
         "require_confirmation": True,
         "num_close_matches": 2,
         "slow_commands": ["npm install", "brew upgrade"],
         "exclude_rules": ["git_push", "sudo"],
         "wait_command": 2,
         "alter_history": True,
         "history_limit": 100,
         "debug": True,
         "rules": ["bash_cd_parent"],
         "instant_mode": True,
         "priority": {"git_push": 100, "sudo": 100},
         "excluded_search_path_prefixes": ["/usr"]})
    assert settings_["profile"] == True
    assert settings_["wait_slow_command"] == 4
    assert settings_

# Generated at 2022-06-22 00:08:13.072237
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['require_confirmation']
    assert settings.require_confirmation

# Generated at 2022-06-22 00:08:16.695464
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings()
    assert settings == const.DEFAULT_SETTINGS
    settings = Settings(const.DEFAULT_SETTINGS)
    assert settings == const.DEFAULT_SETTINGS
    assert settings.require_confirmation is True


# Generated at 2022-06-22 00:08:19.712489
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(const.DEFAULT_SETTINGS)
    assert type(settings) == Settings
    assert settings == const.DEFAULT_SETTINGS


# Generated at 2022-06-22 00:08:26.558446
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    import shutil
    import os

    tempdir = tempfile.mkdtemp()
    os.environ['XDG_CONFIG_HOME'] = tempdir

    settings.init()
    assert settings.user_dir == Path(tempdir, 'thefuck')
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert os.path.abspath(os.path.expanduser('~/.thefuck')) not in settings.user_dir.as_posix()

    shutil.rmtree(tempdir)



# Generated at 2022-06-22 00:09:59.820584
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.user_dir == Path('.thefuck')
    assert settings.debug == False
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.alter_history == False
    assert settings.instant_mode == False
    assert settings.exclude_rules == []
    assert settings.rules == ['git_dirty_workdir']
    assert settings.excluded_search_path_prefixes == []
    assert settings.repeat == False
    assert settings.history_limit == None
    assert settings.slow_commands == []
    assert settings.num_close_matches == 3

# Generated at 2022-06-22 00:10:01.126098
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings is not None

# Generated at 2022-06-22 00:10:02.932955
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.test = 1
    assert(settings.get('test') == 1)

# Generated at 2022-06-22 00:10:04.437678
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    """Unit test for method __getattr__ of class Settings"""
    assert settings.require_confirmation



# Generated at 2022-06-22 00:10:07.595620
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['require_confirmation'] == True
    assert settings['wait_command'] == 0.5
    assert settings['slow_commands'] == ['lein', 'gradle', './gradlew']


# Generated at 2022-06-22 00:10:09.180072
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings.new_key = 'value'
    assert settings.new_key == 'value'



# Generated at 2022-06-22 00:10:11.784348
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation == True
    assert settings.no_colors == False



# Generated at 2022-06-22 00:10:14.497347
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
	settings = Settings(const.DEFAULT_SETTINGS)
	settings['test_item'] = 'test_value'
	assert settings['test_item'] == 'test_value'


# Generated at 2022-06-22 00:10:16.893436
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.key is None
    settings.key = 'value'
    assert settings['key'] == 'value'



# Generated at 2022-06-22 00:10:22.196926
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    from .const import DEFAULT_SETTINGS
    from .types import Settings
    s = Settings(DEFAULT_SETTINGS)
    assert s['require_confirmation'] == DEFAULT_SETTINGS['require_confirmation']
    assert s.require_confirmation == DEFAULT_SETTINGS['require_confirmation']


# Generated at 2022-06-22 00:14:24.892964
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    settings.init()
    assert settings['use_gpu'] == False
    assert settings['require_confirmation'] == True
    if sys.version_info > (3,0):
        assert settings['wait_command'] == 0.5
        assert settings['wait_slow_command'] == 2
    else:
        assert settings['wait_command']  == 2
        assert settings['wait_slow_command'] == 3
    assert settings['debug'] == False
    assert settings['rules'] == 'git:bash:python:perl:ruby:default'
    assert settings['exclude_rules'] == 'sudo:ls:man:cd:bg:fg:mount'
    assert settings['slow_commands'] == 'sudo,source'

# Generated at 2022-06-22 00:14:28.441732
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings(dict(a=1, b=2))
    assert(settings.get('a') == 1)
    assert(settings.get('b') == 2)
    settings.update({'c': 3})
    assert(settings.get('c') == 3)

# Generated at 2022-06-22 00:14:38.048047
# Unit test for method init of class Settings
def test_Settings_init():

    const.DEFAULT_SETTINGS.update({"settings_dir": "~/.config/thefuck"})
    settings.init()

    # It should load settings from user config settings.py file
    assert 'require_confirmation' in settings
    assert settings.require_confirmation is True

    # It should load settings from environ variables
    os.environ["THEFUCK_EXCLUDE_RULES"] = "cd_mkdir"
    settings.init()
    assert 'exclude_rules' in settings
    assert settings.exclude_rules == ["cd_mkdir"]

    # It should load settings from arguments
    assert (settings.init(args=argparse.Namespace(yes=True))
            == {'require_confirmation': False})

# Generated at 2022-06-22 00:14:40.104744
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.test = 'value'
    assert settings.test == 'value'



# Generated at 2022-06-22 00:14:50.121285
# Unit test for method init of class Settings
def test_Settings_init():
    global settings
    settings = Settings()
    settings.init()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.priority == dict()
    assert settings.require_confirmation
    assert settings.no_colors
    assert not settings.debug
    assert settings.alter_history
    assert not settings.instant_mode
    assert settings.wait_command == 3
    assert settings.wait_slow_command == 10
    assert settings.history_limit == 100
    assert settings.slow_commands == const.DEFAULT_SLOW_COMMANDS
    assert settings.search_prefixes == const.DEFAULT_SEARCH_PREFIXES
    assert settings.exclude_rules == ()
    assert settings.num_close_matches == 3
    assert settings.excluded_search_path_prefixes == []

# Generated at 2022-06-22 00:14:58.821939
# Unit test for constructor of class Settings
def test_Settings():
    settings.init()
    assert isinstance(settings['history_limit'], int)
    assert isinstance(settings['alter_history'], bool)
    assert isinstance(settings['rules'], list)
    assert isinstance(settings['priority'], dict)
    assert isinstance(settings['no_colors'], bool)
    assert isinstance(settings['require_confirmation'], bool)
    assert isinstance(settings['exclude_rules'], list)
    assert isinstance(settings['wait_command'], int)
    assert isinstance(settings['wait_slow_command'], int)
    assert isinstance(settings['slow_commands'], list)
    assert isinstance(settings['num_close_matches'], int)
    assert isinstance(settings['excluded_search_path_prefixes'], list)

#

# Generated at 2022-06-22 00:15:07.442423
# Unit test for method init of class Settings
def test_Settings_init():
    try:
        from six import StringIO
    except ImportError:
        from io import StringIO

    from .logs import exception
    import sys
    old_stdout, old_stderr = sys.stdout, sys.stderr
    sys.stdout, sys.stderr = StringIO(), StringIO()
    settings.init()
    sys.stdout = old_stdout
    sys.stderr = old_stderr
    assert exception.called == True

    settings.init({})
    assert settings['require_confirmation'] == False

# Generated at 2022-06-22 00:15:13.873948
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.someNewAttr = 'foo'
    assert 'someNewAttr' in settings.keys()
    assert settings['someNewAttr'] == 'foo'


# Generated at 2022-06-22 00:15:22.094343
# Unit test for method init of class Settings
def test_Settings_init():
    os.environ['TF_REQUIRE_CONFIRMATION'] = 'False'
    os.environ['TF_NO_COLORS'] = 'True'
    os.environ['TF_DEBUG'] = 'False'
    os.environ['TF_ALTER_HISTORY'] = 'True'
    os.environ['TF_INSTANT_MODE'] = 'False'
    os.environ['TF_WAIT_COMMAND'] = '1'
    os.environ['TF_WAIT_SLOW_COMMAND'] = '2'
    os.environ['TF_HISTORY_LIMIT'] = '3'
    os.environ['TF_RULES'] = 'DEFAULT_RULES:bash_history:brew_install'

# Generated at 2022-06-22 00:15:31.477093
# Unit test for method init of class Settings
def test_Settings_init():
    """Unit-test for method init of class Settings."""
    # backup old settings
    old_settings = settings.copy()

    # backup the old values of environment variables
    old_env = os.environ.copy()
    # set new values of environment variables
    os.environ['THEFUCK_REQUIRE_CONFIRMATION'] = 'false'
    os.environ['THEFUCK_WAIT_COMMAND'] = '1'
    os.environ['THEFUCK_WAIT_SLOW_COMMAND'] = '2'
    os.environ['THEFUCK_HISTORY_LIMIT'] = '3'
    os.environ['THEFUCK_ALTER_HISTORY'] = 'true'