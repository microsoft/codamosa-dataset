

# Generated at 2022-06-22 00:05:58.521737
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.command_not_found == 'fuck'
    assert settings.wait_command == 3
    assert 'git' in settings.exclude_rules
    assert settings.wait_slow_command == 10

# Generated at 2022-06-22 00:06:00.094663
# Unit test for method init of class Settings
def test_Settings_init():
    settings.reset()
    settings.init()
    assert settings.rules == const.DEFAULT_RULES



# Generated at 2022-06-22 00:06:03.141829
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.no_colors == const.DEFAULT_SETTINGS['no_colors']
    assert settings.history_limit == const.DEFAULT_SETTINGS['history_limit']


# Generated at 2022-06-22 00:06:05.720060
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_attr = 'test_attr'
    test_val = 1
    settings.__setattr__(test_attr, test_val)
    assert settings.test_attr == test_val

# Generated at 2022-06-22 00:06:09.380535
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings_obj = Settings({"KEY": "VALUE"})
    assert settings_obj.KEY == "VALUE"



# Generated at 2022-06-22 00:06:16.635028
# Unit test for method init of class Settings
def test_Settings_init():
    from thefuck import scripts

    def _init(args=None):
        settings.init(args)

    assert_raises(Exception, _init)
    assert_raises(Exception, _init, scripts.parse_args(['--repeat', '3']))

    settings.init(scripts.parse_args(['--yes']))
    assert settings._settings_from_args(scripts.parse_args(['--yes'])) == {'require_confirmation': False}

    settings.init(scripts.parse_args(['--debug']))
    assert settings._settings_from_args(scripts.parse_args(['--debug'])) == {'debug': True}

    settings.init(scripts.parse_args(['--repeat', '3']))

# Generated at 2022-06-22 00:06:21.221394
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class Dummy(object):
        pass
    dummy = Dummy()
    dummy.foo = 'foo'
    dummy.bar = 'bar'
    assert dummy.foo == 'foo'
    assert dummy.bar == 'bar'

# Generated at 2022-06-22 00:06:23.734829
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.sudo_command == '/usr/bin/sudo'
    assert settings.alias == 'f'
    assert settings.history_limit == None



# Generated at 2022-06-22 00:06:25.612431
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.test = 'value'
    assert settings['test'] == 'value'



# Generated at 2022-06-22 00:06:35.840576
# Unit test for method init of class Settings
def test_Settings_init():
    """Unit test of method init of class Settings."""
    # Testing the initialisation of settings

    def get_settings_object():
        """ Returns a settings.Settings object. """
        return Settings(const.DEFAULT_SETTINGS)

    # Testing the initialisation of settings object
    get_settings_object()

    # Testing the initialisation of Settings object with settings from file
    get_settings_object()._settings_from_file()

    # Testing the initialisation of settings with settings from env
    get_settings_object()._settings_from_env()

    # Testing the initialisation of settings with settings from args
    get_settings_object()._settings_from_args(args=None)

# Generated at 2022-06-22 00:06:55.613937
# Unit test for constructor of class Settings
def test_Settings():
    assert settings == const.DEFAULT_SETTINGS


# Generated at 2022-06-22 00:06:57.752791
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    s.__setattr__('x', 1)
    assert s == {'x': 1}


# Generated at 2022-06-22 00:06:59.435096
# Unit test for constructor of class Settings
def test_Settings():
    assert settings == const.DEFAULT_SETTINGS

# Generated at 2022-06-22 00:07:00.978820
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.foo = 'bar'
    assert settings['foo'] == 'bar'

# Generated at 2022-06-22 00:07:01.613541
# Unit test for constructor of class Settings
def test_Settings():
    pass

# Generated at 2022-06-22 00:07:09.825829
# Unit test for constructor of class Settings
def test_Settings():
    settings = Settings({
        'rules': ['base', 'brew', 'gem', 'git', 'hg', 'npm', 'pip', 'svn', 'system'],
        'require_confirmation': True,
        'no_colors': True,
        'wait_command': 3,
        'history_limit': None,
        'repeat': False,
        'wait_slow_command': 15,
        'alter_history': True,
        'instant_mode': False,
        'slow_commands': [],
        'exclude_rules': [],
        'excluded_search_path_prefixes': [],
        'num_close_matches': 3,
        'priority': {},
        'debug': False
    })
    assert settings.user_dir is None
    assert settings.debug == False


# Generated at 2022-06-22 00:07:19.343461
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import set_log_level
    set_log_level('critical')

    import sys
    from textwrap import dedent
    from tempfile import mkdtemp
    from six import text_type

    rmdir = lambda: sys.modules['shutil'].rmtree(settings.user_dir)
    sys.modules['shutil'].rmtree = rmdir


    def load_source():
        return sys.modules['thefuck.settings']


    sys.modules['thefuck.settings'] = load_source

    tmpdir = text_type(Path(mkdtemp()))
    settings.user_dir = Path(tmpdir)
    assert not settings.user_dir.joinpath('settings.py').is_file()

    settings.init()


# Generated at 2022-06-22 00:07:22.235911
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    from .config import settings
    settings.update({"a": "b"})
    assert settings.a == "b"


# Generated at 2022-06-22 00:07:33.558557
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    settings = Settings()
    settings._setup_user_dir = lambda: None
    settings.init()
    assert settings.require_confirmation == True

    settings = Settings()
    settings._setup_user_dir = lambda: None
    settings._init_settings_file = lambda: None
    settings._settings_from_file = lambda: {'require_confirmation': False}
    settings.init()
    assert settings.require_confirmation == False

    settings = Settings()
    settings._setup_user_dir = lambda: None
    settings._init_settings_file = lambda: None
    settings._settings_from_file = lambda: {'require_confirmation': False}
    settings._settings_from_env = lambda: {'require_confirmation': False}
    settings.init()
    assert settings.require

# Generated at 2022-06-22 00:07:41.856276
# Unit test for constructor of class Settings
def test_Settings():
    assert getattr(settings, 'wait_slow_command') == settings.get('wait_slow_command')
    assert getattr(settings, 'alter_history') == settings.get('alter_history')
    assert getattr(settings, 'history_limit') == settings.get('history_limit')
    settings.init()
    assert getattr(settings, 'rules') == settings.get('rules')
    assert getattr(settings, 'require_confirmation') == settings.get('require_confirmation')
    assert getattr(settings, 'exclude_rules') == settings.get('exclude_rules')

# Generated at 2022-06-22 00:08:42.479322
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    test_settings = Settings()
    test_settings.test_key = 'test_value'
    assert test_settings['test_key'] == 'test_value'


# Generated at 2022-06-22 00:08:45.532534
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init(None)
    assert settings['require_confirmation'] == const.DEFAULT_SETTINGS['require_confirmation']


# Generated at 2022-06-22 00:08:48.775900
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.python == '/usr/bin/python'



# Generated at 2022-06-22 00:08:57.129244
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.priority == {}
    assert settings.require_confirmation is True
    assert settings.wait_command is 1
    assert settings.history_limit is 10
    assert settings.no_colors is False
    assert settings.debug is False
    assert settings.exclude_rules == []
    assert settings.extend_sudo is False
    assert settings.slow_commands == []
    assert settings.wait_slow_command is 15
    assert settings.alter_history is True
    assert settings.instant_mode is False

# Generated at 2022-06-22 00:08:59.741376
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    class A(object):
        foo = 'bar'
    a = A()
    settings.a = a
    assert settings.a.foo == 'bar'


# Generated at 2022-06-22 00:09:02.226069
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    settings['test_value'] = 1
    assert settings.test_value == 1
    assert settings['test_value'] == 1

# Generated at 2022-06-22 00:09:07.377376
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings({'a':1, 'b':2})
    settings.init({'yes':True, 'repeat':True})
    assert settings.require_confirmation == False
    assert settings['repeat'] == True
    settings['d'] = 4
    settings.init()
    assert settings.require_confirmation == True
    assert settings['d'] == 4

# Generated at 2022-06-22 00:09:15.622786
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    import shutil
    import os
    import sys

    args = argparse.Namespace()
    args.yes = True
    args.debug = True
    args.repeat = 3

    # Create a temporary directory
    user_dir = tempfile.mkdtemp()
    with open(os.path.join(user_dir, 'settings.py'), 'w') as settings_file:
        settings_file.write('# This is a test settings file\n')
    os.chdir(user_dir)

    settings_orig = Settings({})
    settings_orig.init(args)

    # Verify that user_dir and user_dir/rules directories have been created
    user_dir = os.path.join(user_dir, '.config', 'thefuck')
    assert os.path.isdir(user_dir)

# Generated at 2022-06-22 00:09:26.653898
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.user_dir.name == '.config' + os.sep + 'thefuck'
    assert settings.require_confirmation == const.DEFAULT_SETTINGS['require_confirmation']
    assert settings.wait_command == const.DEFAULT_SETTINGS['wait_command']
    assert settings.wait_slow_command == const.DEFAULT_SETTINGS['wait_slow_command']
    assert settings.env == const.DEFAULT_SETTINGS['env']
    assert settings.priority == const.DEFAULT_SETTINGS['priority']
    assert settings.rules == const.DEFAULT_SETTINGS['rules']
    assert settings.exclude_rules == const.DEFAULT_SETTINGS['exclude_rules']
    assert settings.no_colors == const.DEFAULT_SETTINGS['no_colors']
   

# Generated at 2022-06-22 00:09:30.618034
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class Test(object):
        pass
    test = Test()
    test = Settings()
    test.a = 10
    test.b = 20
    assert test['a'] == 10
    assert test.b == 20

# Generated at 2022-06-22 00:10:30.866702
# Unit test for method init of class Settings
def test_Settings_init():
    import os, sys
    from thefuck.main import CommandNotFound, get_aliases
    from ordereddict import OrderedDict
    from six import text_type
    from thefuck.settings import Settings

    settings_init = Settings(const.DEFAULT_SETTINGS)
    settings_init._setup_user_dir()

    settings_dir = settings_init._get_user_dir_path()
    if not settings_init._settings_from_file():
        settings_init._init_settings_file()
    settings_init.update(settings_init._settings_from_file())

    assert isinstance(settings_init.require_confirmation, bool)
    assert isinstance(settings_init.no_colors, bool)
    assert isinstance(settings_init.debug, bool)

# Generated at 2022-06-22 00:10:42.600109
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import capture_logs
    from .rules import get_all_rules
    from .utils import get_all_executables
    from six import string_types

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()

    assert settings.user_dir == settings._get_user_dir_path()
    assert isinstance(settings.get('rules'), list)
    assert set(settings.get('rules')) == set(r.name for r in get_all_rules())
    assert settings.get('history_limit') > 0
    assert isinstance(settings.get('exclude_rules'), list)
    assert settings.get('wait_slow_command') >= 0
    assert settings.get('num_close_matches') >= 1

# Generated at 2022-06-22 00:10:46.181971
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    # For example:
    # settings['test'] = 'test'
    # settings.test = 'test'
    settings.test = 'test'
    assert settings['test'] == 'test'

# Generated at 2022-06-22 00:10:47.617021
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.python = 'python'
    assert settings['python'] == 'python'


# Generated at 2022-06-22 00:10:50.331721
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class A(object):
        pass
    a = A()
    a.x = 10

    setting = Settings()
    setting.x = 10
    assert setting['x'] == 10

# Generated at 2022-06-22 00:10:57.349255
# Unit test for constructor of class Settings
def test_Settings():
    const_default_settings = {
        'require_confirmation': True, 'no_colors': False, 'alter_history': False, 'repeat': False, 'instant_mode': False,
        'wait_slow_command': 10,'rules': [], 'priority': {}, 'exclude_rules': [], 'wait_command': 3, 'slow_commands': [],
        'debug': False, 'history_limit': None, 'excluded_search_path_prefixes': [], 'num_close_matches': 3
    }
    s = Settings(const_default_settings)
    assert s == const_default_settings


# Generated at 2022-06-22 00:11:01.145117
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test_key = 'test_val'
    assert settings.test_key == 'test_val'


# Generated at 2022-06-22 00:11:07.757258
# Unit test for constructor of class Settings
def test_Settings():
    from .logs import logger

    assert settings.rules == ['git_rebase', 'git_push', 'git_commit', 'git_add',
                              'svn_revert', 'svn_ci', 'svn_co', 'svn_mkdir',
                              'svn_mkdir_p', 'svn_rm', 'svn_st', 'svn_switch',
                              'svn_update']

# Generated at 2022-06-22 00:11:17.899518
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    # skip the following test for manual testing
    # It's for testing the initialization of settings' values
    from .system import get_all_executables
    executables = get_all_executables()
    if 'fuck' in executables or 'thefuck' in executables:
        return
    # end

    import os
    import shutil
    from tempfile import mkdtemp

    tempdir = mkdtemp()
    os.environ['XDG_CONFIG_HOME'] = tempdir
    os.makedirs(os.path.join(tempdir, 'thefuck', 'rules'))
    with open(os.path.join(tempdir, 'thefuck', 'settings.py'), 'w') as f:
        f.write(const.SETTINGS_HEADER)
        f

# Generated at 2022-06-22 00:11:23.812718
# Unit test for method init of class Settings
def test_Settings_init():
    old_user_dir = settings.user_dir
    settings.update(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir == old_user_dir
    assert settings.require_confirmation == True
    settings.init(args=Namespace(yes=True))
    assert settings.require_confirmation == False



# Generated at 2022-06-22 00:13:45.898654
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    settings.init()
    assert settings.require_confirmation

    settings.init(args=lambda: None)
    assert settings.require_confirmation

    settings_path = settings._get_user_dir_path().joinpath('settings.py')
    with settings_path.open(mode='w') as settings_file:
        settings_file.write(const.SETTINGS_HEADER)
        settings_file.write('require_confirmation = False')

    settings.init()
    assert not settings.require_confirmation

    # os.environ['TF_REQUIRE_CONFIRMATION'] = 'TRUE'
    # settings.init()
    # assert settings.require_confirmation

    os.environ['TF_REQUIRE_CONFIRMATION'] = 'False'
    settings.init()

# Generated at 2022-06-22 00:13:47.050482
# Unit test for constructor of class Settings
def test_Settings():
    settings.init()
    for key in const.DEFAULT_SETTINGS.keys():
        assert key in settings

# Generated at 2022-06-22 00:13:53.015951
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from mock import patch

    exception.enabled = False

    with patch('sys.exit') as exit, \
            patch.object(Settings, '_settings_from_file',
                         return_value={'require_confirmation': True}), \
            patch.object(Settings, '_settings_from_env', return_value={}), \
            patch.object(Settings, '_settings_from_args', return_value={}), \
            patch('thefuck.settings.logging'):
        settings.init()
        exit.assert_called_with(1)
        assert settings['require_confirmation']

    exception.enabled = True


# Generated at 2022-06-22 00:13:53.708114
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.abc = 123
    assert settings['abc'] == 123


# Generated at 2022-06-22 00:13:54.983292
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.wait_command == 1


# Generated at 2022-06-22 00:13:56.540740
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    from .logs import Color

    assert settings.require_confirmation
    assert settings.no_colors == Color.enabled()
    assert settings.debug is False



# Generated at 2022-06-22 00:13:57.840095
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings({'a': 1})
    settings.b = 1
    assert settings == {'a': 1, 'b': 1}



# Generated at 2022-06-22 00:13:59.310274
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    from .tests.utils import suppress_stderr

    assert settings.require_confirmation

    with suppress_stderr(settings):
        assert settings.no_exist is None

# Generated at 2022-06-22 00:14:01.933849
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('require_confirmation') == True
    settings.init()
    assert settings.get('require_confirmation') == False
    assert settings.get('repeat') == None

# Generated at 2022-06-22 00:14:08.555916
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('require_confirmation') == True
    assert settings.get('repeat') == 1
    assert settings.get('alias') == 'fuck'
    assert settings.get('rules') == ['git_push', 'git_add_upstream']
    assert settings.get('priority') == {'git_add_upstream': 100}
    assert settings.get('wait_command') == 1
    assert settings.get('history_limit') == None
    assert settings.get('wait_slow_command') == 15
    assert settings.get('no_colors') == False
    assert settings.get('debug') == False
    assert settings.get('alter_history') == True
    assert settings.get('exclude_rules') == []
    assert settings.get('instant_mode') == False