

# Generated at 2022-06-22 00:06:06.558740
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .logs import log

    class TmpSettings(Settings):

        def __init__(self, *args):
            self._settings_from_args = lambda x: None
            self._rules_from_env = lambda x: None
            self._settings_from_env = lambda: None
            self._get_user_dir_path = lambda: None
            self._update = lambda x: None
            self._init_settings_file = lambda: None
            self._setup_user_dir = lambda: None
            super(TmpSettings, self).__init__(*args)

        def _settings_from_file(self):
            return {}

    settings = TmpSettings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings['repeat'] == 1

# Generated at 2022-06-22 00:06:10.551799
# Unit test for constructor of class Settings
def test_Settings():
    assert Settings(a=1) == {'a': 1}
    assert Settings().init() is None
    assert settings.user_dir.endswith('config/thefuck')

# Generated at 2022-06-22 00:06:12.265543
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert isinstance(settings, dict)
    settings.init()
    assert settings.get('require_confirmation')

# Generated at 2022-06-22 00:06:13.958268
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.alias == 'fuck'



# Generated at 2022-06-22 00:06:15.732065
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.rules
    assert not settings.not_exist_settings

# Generated at 2022-06-22 00:06:19.369643
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert 'require_confirmation' == settings.require_confirmation
    assert 'THEFUCK_REQUIRE_CONFIRMATION' == settings['require_confirmation']


# Generated at 2022-06-22 00:06:21.992178
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings['sudo_command'] == 'sudo {command}'
    settings.sudo_command = 'remount'
    assert settings['sudo_command'] == 'remount'



# Generated at 2022-06-22 00:06:24.495037
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    assert settings.get("require_confirmation") == True
    settings.__setattr__("require_confirmation", False)
    assert settings.get("require_confirmation") == False

# Generated at 2022-06-22 00:06:27.163874
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.get('require_confirmation') == True
    settings.update({'require_confirmation': False})
    assert settings.get('require_confirmation') == False

# Generated at 2022-06-22 00:06:30.610037
# Unit test for constructor of class Settings
def test_Settings():
    result = Settings({'a': 1})
    assert result['a'] == 1
    assert result.a == 1
    result.b = 2
    assert result.b == 2



# Generated at 2022-06-22 00:07:09.347858
# Unit test for constructor of class Settings
def test_Settings():
    from .system import get_aliases

    alias_command = get_aliases().split('\n')[0].split('=')[0].strip()
    assert isinstance(settings, dict)
    assert settings.get('alias', '') == alias_command
    assert settings.get('wait_command', 0) == 1
    assert settings.get('history_limit', 0) == 10
    assert settings.get('require_confirmation', True) == True
    assert isinstance(settings.get('alter_history', True), bool)



# Generated at 2022-06-22 00:07:12.417791
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.key == settings['key']
    assert settings.non_existent_key == settings.get('non_existent_key')


# Generated at 2022-06-22 00:07:16.780064
# Unit test for method init of class Settings
def test_Settings_init():
    assert settings.user_dir == Path(os.environ['HOME'], '.thefuck')
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation is True
    assert settings.history_limit == 10
    assert settings.wait_command == 1


# Generated at 2022-06-22 00:07:18.414743
# Unit test for constructor of class Settings
def test_Settings():
    temp_settings = Settings(const.DEFAULT_SETTINGS)
    assert temp_settings == const.DEFAULT_SETTINGS


# Generated at 2022-06-22 00:07:22.011662
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    from .config import settings
    settings.new_attr = 5
    assert settings.new_attr == 5
    assert settings.get('new_attr') == 5



# Generated at 2022-06-22 00:07:24.115465
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings(const.DEFAULT_SETTINGS)
    assert s['wait_command'] == 0
    assert s['rules'] is not None

# Generated at 2022-06-22 00:07:27.375860
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.debug = True
    assert settings.debug == True
    settings.debug = False
    assert settings.debug == False


# Generated at 2022-06-22 00:07:38.008639
# Unit test for method init of class Settings
def test_Settings_init():
    def _settings_from_file(file_name):
        load_source = load_source
        from .logs import exception

        settings_path = '/tmp/' + file_name
        settings_file = open(settings_path, 'w')
        settings_file.write(const.SETTINGS_HEADER)
        for setting in const.DEFAULT_SETTINGS.items():
            settings_file.write('# {} = {}\n'.format(*setting))
        settings_file.close()

        try:
            return load_source('settings', settings_path)
        except Exception:
            exception("Can't load settings from file", sys.exc_info())
            return None

    def _settings_from_args(args):
        if not args:
            return {}

        from_args = {}

# Generated at 2022-06-22 00:07:40.952808
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings.test_Settings___setattr__ = 1
    assert settings['test_Settings___setattr__'] == 1


# Generated at 2022-06-22 00:07:52.124350
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .logs import log

    exception_logs = []

    def exception(*args):
        exception_logs.append(args)

    def load_source(*args):
        return args[1]

    def update(self, settings):
        self.update(settings)

    def _settings_from_file(self):
        return {
            'require_confirmation': True,
            'history_limit': 1000
        }

    def _settings_from_env(self):
        return {
            'rules': ['DEFAULT_RULES', 'test_rule'],
            'exclude_rules': ['test_exclude_rule'],
            'priority': {'pwd': 10},
            'no_colors': True,
            'wait_slow_command': 100
        }



# Generated at 2022-06-22 00:09:00.132518
# Unit test for constructor of class Settings
def test_Settings():
    """
    >>> isinstance(new_settings, Settings)
    True
    >>> new_settings.get('require_confirmation')
    True
    >>> new_settings['require_confirmation'] = False
    >>> 'require_confirmation' in new_settings
    True
    """
    new_settings = Settings(require_confirmation=True)
    assert new_settings.get('require_confirmation')
    new_settings['require_confirmation'] = False
    assert 'require_confirmation' in new_settings


# Generated at 2022-06-22 00:09:04.382994
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.require_confirmation is True, 'should return attr'
    assert settings.not_exists is None, 'should return None'


# Generated at 2022-06-22 00:09:13.912988
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert settings.is_ok == True
    assert settings.require_confirmation == True
    assert settings.priority == const.DEFAULT_SETTINGS['priority']
    assert settings.script_mode == False
    assert settings.wait_command == const.DEFAULT_SETTINGS['wait_command']
    assert settings.slow_commands == const.DEFAULT_SETTINGS['slow_commands']
    assert settings.exclude_rules == const.DEFAULT_SETTINGS['exclude_rules']
    assert settings.excluded_search_path_prefixes == const.DEFAULT_SETTINGS['excluded_search_path_prefixes']
    assert settings.wait_slow_command == const.DEFAULT_SETTINGS['wait_slow_command']

# Generated at 2022-06-22 00:09:16.968180
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    from .logs import Log
    Log.log_file = 'test_log_file'
    assert settings.log_file == 'test_log_file'


# Generated at 2022-06-22 00:09:27.489786
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.user_dir == Path('~/.config', 'thefuck')
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation is True
    assert settings.wait_command == 1
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.priority == {}
    assert settings.no_colors is False
    assert settings.slow_commands == ['lein', 'react-native',
                                      'gradle', './gradlew', './gradlew.bat',
                                      'cargo', 'composer',
                                      'ionic', 'gulp']
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.debug is False
    assert settings.alter_history

# Generated at 2022-06-22 00:09:38.591287
# Unit test for constructor of class Settings
def test_Settings():
    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['exclude_rules'] == []
    assert settings['wait_command'] == 10
    assert settings['require_confirmation'] == True
    assert settings['no_colors'] == False
    assert settings['priority'] == {}
    assert settings['wait_slow_command'] == 3
    assert settings['debug'] == False
    assert settings['repeat'] == False
    assert settings['history_limit'] == None
    assert settings['slow_commands'] == []
    assert settings['excluded_search_path_prefixes'] == []
    assert settings['alter_history'] == True
    assert settings['num_close_matches'] == 3


# Generated at 2022-06-22 00:09:40.360857
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
        settings.LOL = "42"
        assert settings.LOL == "42"


# Generated at 2022-06-22 00:09:41.958283
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    s = Settings()
    s.key = 'value'
    assert s['key'] == 'value'

# Generated at 2022-06-22 00:09:46.742774
# Unit test for constructor of class Settings
def test_Settings():
    s = Settings(const.DEFAULT_SETTINGS)
    assert s.get('require_confirmation') == True
    s.init()
    assert s.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck')

# Generated at 2022-06-22 00:09:48.360597
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.user_dir.expanduser() != '.'

# Generated at 2022-06-22 00:12:27.453223
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    settings = Settings()
    settings.a = 1
    assert settings['a'] == 1
    settings.a = 2
    assert settings['a'] == 2

# Generated at 2022-06-22 00:12:36.845800
# Unit test for constructor of class Settings
def test_Settings():
    from .logs import exception
    settings.init()
    assert settings.user_dir.as_posix().endswith('.config/thefuck')
    settings.user_dir = Path('~/.thefuck').expanduser()
    assert settings.user_dir.is_dir()
    assert settings.require_confirmation is True
    assert settings.alter_history is True
    assert settings.instant_mode is False
    assert settings.num_close_matches == 3
    assert settings.history_limit == 10
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 9
    assert settings.env == {}
    assert settings.rules == []
    assert settings.exclude_rules == []
    assert settings.slow_commands == ["(git|hg|bzr|svn) log"]

# Generated at 2022-06-22 00:12:39.905806
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    assert (dict.__getattr__(settings, 'require_confirmation') ==
            settings.require_confirmation)



# Generated at 2022-06-22 00:12:47.941024
# Unit test for constructor of class Settings
def test_Settings():
    from .logs import log_to_file

    def _check(message):
        raise AssertionError(message)

    log_to_file()

    settings = Settings(const.DEFAULT_SETTINGS)
    try:
        assert settings.get('require_confirmation')
    except AssertionError:
        _check("settings get 'require_confirmation' error ")
    try:
        assert settings.rule == 'DEFAULT_RULES'
    except AssertionError:
        _check("settings.rule == DEFAULT_RULES error")

    try:
        assert settings.rules == const.DEFAULT_RULES
    except AssertionError:
        _check("settings.rule == const.DEFAULT_RULES error")


# Generated at 2022-06-22 00:12:52.720943
# Unit test for method __getattr__ of class Settings
def test_Settings___getattr__():
    from .tests.utils import SuppressStdoutAndStderr

    assert settings.require_confirmation is True

    env_vars = {'THEFUCK_REQUIRE_CONFIRMATION': 'false'}
    with (SuppressStdoutAndStderr()):
        settings.init(None)
    assert settings.require_confirmation is False



# Generated at 2022-06-22 00:12:57.514228
# Unit test for method init of class Settings
def test_Settings_init():
    instance = settings
    import thefuck.settings
    thefuck.settings.DEFAULT_RULES = ['bash', 'git']
    assert len(instance) > 0
    instance.init()
    assert instance.get('history_limit') == 1000
    assert instance.get('exclude_rules') == []
    assert instance.get('rules') == ['bash', 'git']
    assert instance.get('priority') == {}

# Generated at 2022-06-22 00:13:00.429526
# Unit test for constructor of class Settings
def test_Settings():
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.user_dir.joinpath('rules').is_dir()


# Generated at 2022-06-22 00:13:04.257647
# Unit test for method __setattr__ of class Settings
def test_Settings___setattr__():
    class Dummy(object):
        pass
    dummy = Dummy()
    dummy.settings = Settings(const.DEFAULT_SETTINGS)
    dummy.settings.dummy_attr = 'dummy_value'
    assert dummy.settings['dummy_attr'] == 'dummy_value'

# Generated at 2022-06-22 00:13:14.661426
# Unit test for constructor of class Settings
def test_Settings():
    setting = Settings(const.DEFAULT_SETTINGS)
    assert setting.get('require_confirmation') == False
    assert setting.get('no_colors') == False
    assert setting.get('debug') == False
    assert setting.get('change_current_dir') == False
    assert setting.get('alter_history') == False
    assert setting.get('instant_mode') == False
    assert setting.get('wait_slow_command') == 3
    assert setting.get('wait_command') == 1
    assert setting.get('history_limit') == 10
    assert setting.get('num_close_matches') == 3
    assert setting.get('repeat') == 1

# Generated at 2022-06-22 00:13:23.393541
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import shutil
    from .logs import exception
    from thefuck.conf.settings import settings
