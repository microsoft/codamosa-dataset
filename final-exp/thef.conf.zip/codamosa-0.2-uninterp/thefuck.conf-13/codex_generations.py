

# Generated at 2022-06-18 06:36:05.255183
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.repeat == False

# Generated at 2022-06-18 06:36:11.444019
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from mock import patch, MagicMock

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.user_dir = Path('/home/user/.config/thefuck')
    settings.init()
    assert settings.require_confirmation == True

# Generated at 2022-06-18 06:36:23.033405
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from . import settings
    from . import logs
    from . import system
    from . import utils
    from . import rules
    from . import history
    from . import shells
    from . import __main__
    from . import __init__
    from . import __version__
    from . import __author__
    from . import __license__
    from . import __copyright__
    from . import __email__
    from . import __status__
    from . import __url__
    from . import __doc__
    from . import __all__
    from . import __file__
    from . import __builtins__
    from . import __name__
    from . import __package__
    from . import __path__
    from . import __

# Generated at 2022-06-18 06:36:30.434435
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.require_confirmation == True
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew']
    assert settings.no_colors == False
    assert settings.alter_history == True
    assert settings.priority == {}
    assert settings.excluded_search_path_prefixes == []
    assert settings.debug == False
   

# Generated at 2022-06-18 06:36:41.850878
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from .settings import settings
    from .settings import _settings_from_args
    from .settings import _settings_from_env
    from .settings import _settings_from_file
    from .settings import _setup_user_dir
    from .settings import _init_settings_file
    from .settings import _get_user_dir_path
    from .settings import _rules_from_env
    from .settings import _priority_from_env
    from .settings import _val_from_env
    from .settings import test_Settings_init

    # Test for method _settings_from_args of class Settings
    def test_Settings__settings_from_args():
        from .settings import _settings_from_args

# Generated at 2022-06-18 06:36:53.206643
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.history_limit == None
    assert settings.priority == {}
    assert settings.exclude_rules == []

# Generated at 2022-06-18 06:37:02.528189
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 0
    assert settings.history_limit == 0
    assert settings.wait_slow_command == 0
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == False
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_mat

# Generated at 2022-06-18 06:37:12.573800
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    import os
    import sys
    from six import text_type
    from imp import load_source
    from warnings import warn

    settings = Settings(const.DEFAULT_SETTINGS)
    settings._setup_user_dir()
    settings._init_settings_file()

    try:
        settings.update(settings._settings_from_file())
    except Exception:
        exception("Can't load settings from file", sys.exc_info())

    try:
        settings.update(settings._settings_from_env())
    except Exception:
        exception("Can't load settings from env", sys.exc_info())

    settings.update(settings._settings_from_args(None))

    assert settings['require_confirmation'] == True

# Generated at 2022-06-18 06:37:24.292041
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3

# Generated at 2022-06-18 06:37:32.859990
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from .utils import get_all_executables
    from .utils import get_all_scripts
    from .utils import get_all_commands
    from .utils import get_all_alias
    from .utils import get_all_functions
    from .utils import get_all_builtins
    from .utils import get_all_keywords
    from .utils import get_all_paths
    from .utils import get_all_man_pages
    from .utils import get_all_man_sections
    from .utils import get_all_man_paths
    from .utils import get_all_man_section_paths
    from .utils import get_all_man_section_files
    from .utils import get_all_man_section_files_paths


# Generated at 2022-06-18 06:38:07.346606
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from mock import patch, Mock

    def _get_user_dir_path():
        return Path('~/.thefuck').expanduser()

    def _settings_from_file():
        return {'require_confirmation': False}

    def _settings_from_env():
        return {'wait_command': 10}

    def _settings_from_args(args):
        return {'repeat': 3}


# Generated at 2022-06-18 06:38:17.833595
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.alter_history == True
    assert settings.priority == {}
    assert settings.exclude_rules == []
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == None
    assert settings.num_close_matches == 3
    assert settings.instant_mode == False
    assert settings.repeat == False


# Generated at 2022-06-18 06:38:30.429057
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()

    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native-cli']
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.no_colors
    assert settings.debug
    assert settings.alter_history
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:38:32.305153
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir.is_dir()
    assert settings.user_dir.joinpath('settings.py').is_file()

# Generated at 2022-06-18 06:38:42.810319
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.alter_history == True
    assert settings.priority == {}
    assert settings.history_limit == None
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.instant_mode == False

# Generated at 2022-06-18 06:38:52.638562
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 0
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.repeat == 1



# Generated at 2022-06-18 06:38:59.639386
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    import shutil
    import os
    from .logs import exception

    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-18 06:39:10.338883
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', './sbt']
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.priority == {}
    assert settings.alter_history == False
    assert settings.instant_

# Generated at 2022-06-18 06:39:17.394545
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 0
    assert settings.history_limit == 0
    assert settings.wait_slow_command == 0
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_mat

# Generated at 2022-06-18 06:39:27.109916
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.alter_history == True
    assert settings.priority == {}
    assert settings.history_limit == None
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.instant_mode == False

# Generated at 2022-06-18 06:40:20.499741
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from .settings import settings
    from .settings import test_Settings_init
    from .settings import _settings_from_args
    from .settings import _settings_from_env
    from .settings import _settings_from_file
    from .settings import _setup_user_dir
    from .settings import _val_from_env
    from .settings import _get_user_dir_path
    from .settings import _init_settings_file
    from .settings import _rules_from_env
    from .settings import _priority_from_env
    from .utils import wrap_streams
    from .utils import wrap_streams_context
    from .utils import wrap_streams_context_manager
    from .utils import wrap_

# Generated at 2022-06-18 06:40:30.578860
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == settings._get_user_dir_path()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 0
    assert settings.history_limit == 0
    assert settings.wait_slow_command == 0
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.num_close_matches

# Generated at 2022-06-18 06:40:35.583292
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.repeat == False
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []

# Generated at 2022-06-18 06:40:39.975087
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()

    settings.init(args=object())
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()

    settings.init(args=object())
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()

# Generated at 2022-06-18 06:40:48.936600
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native-cli']
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.instant_mode == False


# Generated at 2022-06-18 06:40:58.331331
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 0
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.repeat == False
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == None
   

# Generated at 2022-06-18 06:41:02.688090
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation
    assert settings.no_colors
    assert not settings.debug
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.alter_history
    assert settings.history_limit == None
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.instant_mode
    assert settings.num_close_matches == 3


# Generated at 2022-06-18 06:41:11.752086
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:41:22.941442
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', './sbt']

# Generated at 2022-06-18 06:41:33.377624
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation is True
    assert settings.no_colors is False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.history_limit == None
    assert settings.alter_history is False
    assert settings.instant_mode is False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.debug is False
    assert settings.repeat is None


# Generated at 2022-06-18 06:43:23.720768
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path

    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation is True
    assert settings.no_colors is False
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == None
    assert settings.alter_history is False
    assert settings.instant_mode is False
    assert settings.num_close_matches == 3
    assert settings.repeat is None

# Generated at 2022-06-18 06:43:33.782371
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.repeat == 1


# Generated at 2022-06-18 06:43:42.192965
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from .settings import settings
    from .settings import test_Settings_init
    from .settings import _settings_from_args
    from .settings import _settings_from_env
    from .settings import _settings_from_file
    from .settings import _setup_user_dir
    from .settings import _val_from_env
    from .settings import _get_user_dir_path
    from .settings import _init_settings_file
    from .settings import _rules_from_env
    from .settings import _priority_from_env
    from .settings import Settings
    from .settings import settings
    from .settings import test_Settings_init
    from .settings import _settings_from_args
    from .settings import _

# Generated at 2022-06-18 06:43:50.212627
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.alter_history == True
    assert settings.priority == {}
    assert settings.exclude_rules == []
    assert settings.history_limit == None
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:43:59.077482
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == False
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.excluded_search_path_prefixes == []

# Generated at 2022-06-18 06:44:06.018218
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir.is_dir()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation
    assert settings.no_colors
    assert settings.priority == {}
    assert settings.wait_command == 0
    assert settings.history_limit == 0
    assert settings.wait_slow_command == 0
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.alter_history
    assert not settings.debug
    assert not settings.repeat
    assert not settings.instant_mode

    settings.init

# Generated at 2022-06-18 06:44:14.659428
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew']
    assert settings.excluded_search_path_prefixes == []
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.num_close_matches

# Generated at 2022-06-18 06:44:23.437500
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch
    from thefuck.settings import Settings
    from thefuck.settings import const

    with patch('thefuck.settings.Settings._settings_from_file') as \
            mock_settings_from_file, \
            patch('thefuck.settings.Settings._settings_from_env') as \
            mock_settings_from_env, \
            patch('thefuck.settings.Settings._settings_from_args') as \
            mock_settings_from_args:
        mock_settings_from_file.return_value = {'key1': 'value1'}
        mock_settings_from_env.return_value = {'key2': 'value2'}
        mock_settings_from_args.return_value = {'key3': 'value3'}

# Generated at 2022-06-18 06:44:31.178375
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == None
    assert settings.num_close_matches == 3
    assert settings.repeat == False


# Generated at 2022-06-18 06:44:38.864240
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close