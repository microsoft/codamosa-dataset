

# Generated at 2022-06-18 06:36:04.165988
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch
    from thefuck.settings import Settings
    from thefuck.settings import const
    from thefuck.settings import os
    from thefuck.settings import sys
    from thefuck.settings import warn

    settings = Settings()

# Generated at 2022-06-18 06:36:10.958565
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:36:22.642821
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.excluded_search_path_prefixes == []
    assert settings.debug == False
    assert settings.alter_history == True

# Generated at 2022-06-18 06:36:30.219259
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    import os
    import sys
    from mock import patch
    from six import text_type
    from thefuck.settings import Settings

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15

# Generated at 2022-06-18 06:36:41.648297
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from .settings import settings
    from .settings import _settings_from_file
    from .settings import _settings_from_env
    from .settings import _settings_from_args
    from .settings import _get_user_dir_path
    from .settings import _setup_user_dir
    from .settings import _rules_from_env
    from .settings import _priority_from_env
    from .settings import _val_from_env
    from .settings import test_Settings_init
    from .settings import test_Settings_getattr
    from .settings import test_Settings_setattr
    from .settings import test_Settings_get
    from .settings import test_Settings_update
    from .settings import test_Settings_

# Generated at 2022-06-18 06:36:49.869501
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from mock import patch, Mock
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import environ

    def _test_settings_from_file(settings_file):
        settings = Settings(const.DEFAULT_SETTINGS)
        settings.user_dir = Path(mkdtemp())
        settings.user_dir.joinpath('settings.py').write_text(settings_file)
        settings.init()
        return settings

    def _test_settings_from_env(settings_env):
        settings = Settings(const.DEFAULT_SETTINGS)
        settings.user_dir = Path(mkdtemp())
        settings.user_dir.joinpath('settings.py').write_text(const.SETTINGS_HEADER)

# Generated at 2022-06-18 06:37:00.600206
# Unit test for method init of class Settings
def test_Settings_init():
    import mock
    from thefuck.settings import Settings
    from thefuck.settings import const
    from thefuck.settings import os

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()

    assert settings.user_dir == os.path.expanduser('~/.config/thefuck')
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 3
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_

# Generated at 2022-06-18 06:37:11.046413
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:37:22.181185
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.alter_history == False

# Generated at 2022-06-18 06:37:31.568644
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation
    assert settings.no_colors
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.alter_history
    assert settings.instant_mode
    assert settings.num_close_matches == 3
    assert settings.excluded_search_path_prefixes == []
    assert settings.repeat == 1

# Generated at 2022-06-18 06:38:02.740079
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', './sbt']

# Generated at 2022-06-18 06:38:13.402372
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    import os
    import sys
    from six import text_type
    from . import const
    from .logs import exception
    from .system import Path
    import os
    import sys
    from six import text_type
    from . import const
    from .logs import exception
    from .system import Path
    import os
    import sys
    from six import text_type
    from . import const
    from .logs import exception
    from .system import Path
    import os
    import sys
    from six import text_type
    from . import const
    from .logs import exception
    from .system import Path
    import os
    import sys
    from six import text_type
    from . import const
    from .logs import exception
    from .system import Path

# Generated at 2022-06-18 06:38:21.517394
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.repeat == 1


# Generated at 2022-06-18 06:38:31.635753
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.instant_mode == False
    assert settings.num_close_matches == 3



# Generated at 2022-06-18 06:38:41.045593
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3


# Generated at 2022-06-18 06:38:51.182300
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation
    assert not settings.no_colors
    assert not settings.debug
    assert settings.wait_command == 1
    assert not settings.alter_history
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert not settings.instant_mode


# Generated at 2022-06-18 06:38:58.716187
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from mock import patch
    from .system import Path
    from . import const
    from .settings import Settings
    from .settings import settings
    from .settings import _settings_from_file
    from .settings import _settings_from_env
    from .settings import _settings_from_args
    from .settings import _setup_user_dir
    from .settings import _init_settings_file
    from .settings import _get_user_dir_path
    from .settings import _rules_from_env
    from .settings import _priority_from_env
    from .settings import _val_from_env

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules

# Generated at 2022-06-18 06:39:09.417787
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.user_dir.joinpath('rules').is_dir()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.no_colors == False
    assert settings.priority == {}
    assert settings.history_limit == None
    assert settings.alter_history == True
    assert settings.exclude_rules == []
    assert settings.repeat == False
    assert settings.debug == False

# Generated at 2022-06-18 06:39:16.920433
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch
    from thefuck.settings import Settings
    from thefuck.settings import const
    from thefuck.settings import os
    from thefuck.settings import sys


# Generated at 2022-06-18 06:39:26.928237
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.require_confirmation == True
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.alter_history == True
    assert settings.no_colors == False
    assert settings.priority == {}
    assert settings.history_limit == None
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.instant_mode == False
    assert settings.debug == False
    assert settings.repeat == False


# Generated at 2022-06-18 06:39:57.983242
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path

    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.repeat == False

# Generated at 2022-06-18 06:40:06.329805
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from . import settings

    settings.init()

    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15

# Generated at 2022-06-18 06:40:16.417475
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.repeat == 1


# Generated at 2022-06-18 06:40:26.185881
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', './sbt']
    assert settings.excluded_

# Generated at 2022-06-18 06:40:36.465121
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings['require_confirmation'] == True
    assert settings['rules'] == ['git_push', 'git_add', 'git_commit', 'sudo']
    assert settings['exclude_rules'] == []
    assert settings['wait_command'] == 3
    assert settings['wait_slow_command'] == 10
    assert settings['alter_history'] == True
    assert settings['history_limit'] == None
    assert settings['no_colors'] == False
    assert settings['debug'] == False
    assert settings['priority'] == {}
    assert settings['slow_commands'] == []
    assert settings['excluded_search_path_prefixes'] == []
    assert settings['num_close_matches'] == 3
    assert settings['instant_mode'] == False
    assert settings['repeat'] == False
    assert settings

# Generated at 2022-06-18 06:40:45.726025
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import shutil
    import tempfile
    from .logs import exception

    def _test_settings_from_file(settings_file_content, expected_settings):
        with tempfile.NamedTemporaryFile(mode='w', delete=False) as settings_file:
            settings_file.write(settings_file_content)
        try:
            settings.user_dir = Path(settings_file.name).parent
            settings.init()
            assert settings == expected_settings
        finally:
            os.remove(settings_file.name)

    def _test_settings_from_env(env_vars, expected_settings):
        for env_var, value in env_vars.items():
            os.environ[env_var] = value

# Generated at 2022-06-18 06:40:55.042922
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', './sbt']

# Generated at 2022-06-18 06:41:04.928438
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 0
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_mat

# Generated at 2022-06-18 06:41:12.996784
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 3
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 10
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.repeat == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.instant_mode == False


# Generated at 2022-06-18 06:41:24.387500
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from unittest import mock
    import sys
    import os

    # Mock the method _get_user_dir_path
    with mock.patch.object(Settings, '_get_user_dir_path') as mock_get_user_dir_path:
        mock_get_user_dir_path.return_value = Path('/home/user/.config/thefuck')

        # Mock the method _settings_from_file
        with mock.patch.object(Settings, '_settings_from_file') as mock_settings_from_file:
            mock_settings_from_file.return_value = {'require_confirmation': True, 'repeat': True}

            # Mock the method _settings_from_env
           

# Generated at 2022-06-18 06:41:56.246231
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == None
    assert settings.num_close_mat

# Generated at 2022-06-18 06:42:05.635525
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.repeat == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.instant_mode == False

# Generated at 2022-06-18 06:42:15.599600
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:42:23.960687
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3


# Generated at 2022-06-18 06:42:32.852720
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.repeat == False


# Generated at 2022-06-18 06:42:40.169712
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew']
    assert settings.excluded_search_path_prefixes == []
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.num_close_matches

# Generated at 2022-06-18 06:42:48.424339
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 0
    assert settings.history_limit == 0
    assert settings.wait_slow_command == 0
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3



# Generated at 2022-06-18 06:42:59.377084
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 0
    assert settings.wait_slow_command == 3
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.priority == {}
    assert settings.history_limit == None
    assert settings.exclude_rules == []
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3

# Generated at 2022-06-18 06:43:07.326228
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import shutil
    import tempfile
    from .logs import exception

    def _test_settings_from_file(settings_file):
        settings_dir = tempfile.mkdtemp()
        settings_path = os.path.join(settings_dir, 'settings.py')
        with open(settings_path, 'w') as f:
            f.write(settings_file)
        settings.user_dir = settings_dir
        try:
            return settings._settings_from_file()
        finally:
            shutil.rmtree(settings_dir)

    def _test_settings_from_env(env):
        os.environ.update(env)

# Generated at 2022-06-18 06:43:18.491702
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path

    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.excluded_search_path_prefixes == []

# Generated at 2022-06-18 06:44:29.295836
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_mat

# Generated at 2022-06-18 06:44:36.858457
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', './sbt']

# Generated at 2022-06-18 06:44:45.738125
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.require_confirmation == True
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.no_colors == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.num_close_matches == 3
    assert settings.excluded_search_path_prefixes == []
    assert settings.debug == False
    assert settings.repeat == False


# Generated at 2022-06-18 06:44:54.660271
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.priority == {}
    assert settings.no_colors
    assert not settings.debug
    assert not settings.alter_history
    assert settings.instant_mode
    assert settings.num_close_matches == 3


# Generated at 2022-06-18 06:45:02.708874
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import shutil
    from .logs import exception
    from .system import Path

    def _get_user_dir_path():
        xdg_config_home = os.environ.get('XDG_CONFIG_HOME', '~/.config')
        user_dir = Path(xdg_config_home, 'thefuck').expanduser()
        legacy_user_dir = Path('~', '.thefuck').expanduser()

        if legacy_user_dir.is_dir():
            warn(u'Config path {} is deprecated. Please move to {}'.format(
                legacy_user_dir, user_dir))
            return legacy_user_dir
        else:
            return user_dir


# Generated at 2022-06-18 06:45:11.087564
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.alter_history
    assert settings.priority == {}
    assert settings.no_colors
    assert not settings.debug

# Generated at 2022-06-18 06:45:15.595446
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from mock import patch, Mock
    from six import text_type
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import environ
    from os.path import join
    from sys import exc_info

    def _mock_exception(*args, **kwargs):
        raise Exception('test')

    def _mock_settings_from_file(*args, **kwargs):
        return {'rules': ['test_rule']}

    def _mock_settings_from_env(*args, **kwargs):
        return {'rules': ['test_rule']}

    def _mock_settings_from_args(*args, **kwargs):
        return {'rules': ['test_rule']}


# Generated at 2022-06-18 06:45:24.949275
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == None
    assert settings.alter_history == False
    assert settings.instant_mode == False
    assert settings.num_close_matches == 3
    assert settings.debug == False
    assert settings.repeat == False