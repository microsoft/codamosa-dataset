

# Generated at 2022-06-18 06:36:26.893182
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from mock import patch, Mock
    from six import text_type
    from io import StringIO
    import sys
    import os

    def _get_user_dir_path(self):
        """Returns Path object representing the user config resource"""
        xdg_config_home = os.environ.get('XDG_CONFIG_HOME', '~/.config')
        user_dir = Path(xdg_config_home, 'thefuck').expanduser()
        legacy_user_dir = Path('~', '.thefuck').expanduser()

        # For backward compatibility use legacy '~/.thefuck' if it exists:

# Generated at 2022-06-18 06:36:36.964592
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', './sbt']

# Generated at 2022-06-18 06:36:47.475682
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 0
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.repeat == False
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', './sbt']
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_mat

# Generated at 2022-06-18 06:36:58.365187
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path

    settings.init()

    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 0
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.repeat == False
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []

# Generated at 2022-06-18 06:37:05.777834
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from .settings import settings
    from .settings import _settings_from_env
    from .settings import _settings_from_args
    from .settings import _settings_from_file
    from .settings import _setup_user_dir
    from .settings import _init_settings_file
    from .settings import _get_user_dir_path
    from .settings import _rules_from_env
    from .settings import _priority_from_env
    from .settings import _val_from_env

    # test _get_user_dir_path
    os.environ['XDG_CONFIG_HOME'] = '/home/user/.config'

# Generated at 2022-06-18 06:37:17.007436
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 0
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.history_limit == None
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.excluded_search_path_prefixes == []
   

# Generated at 2022-06-18 06:37:27.134319
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from . import settings
    from . import utils
    from .utils import wrap_streams
    from .utils import wrap_streams
    from .utils import wrap_streams
    from .utils import wrap_streams
    from .utils import wrap_streams
    from .utils import wrap_streams
    from .utils import wrap_streams
    from .utils import wrap_streams
    from .utils import wrap_streams
    from .utils import wrap_streams
    from .utils import wrap_streams
    from .utils import wrap_streams
    from .utils import wrap_streams
    from .utils import wrap_streams
    from .utils import wrap_streams
    from .utils import wrap_streams

# Generated at 2022-06-18 06:37:35.014663
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    settings.init()
    assert settings.user_dir.is_dir()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.get('require_confirmation') == True
    assert settings.get('rules') == const.DEFAULT_RULES
    assert settings.get('priority') == {}
    assert settings.get('wait_command') == 3
    assert settings.get('history_limit') == None
    assert settings.get('wait_slow_command') == 15
    assert settings.get('slow_commands') == []
    assert settings.get('exclude_rules') == []
    assert settings.get('excluded_search_path_prefixes') == []
    assert settings.get('no_colors') == False

# Generated at 2022-06-18 06:37:44.393499
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', './sbt']

# Generated at 2022-06-18 06:37:52.907891
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.priority == {}
    assert settings.require_confirmation
    assert settings.no_colors
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == None
    assert settings.alter_history
    assert settings.num_close_matches == 3
    assert settings.instant_mode
    assert settings.repeat == 1

    os.environ['THEFUCK_RULES'] = 'bash_history:ls'

# Generated at 2022-06-18 06:38:31.055876
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    import os
    import sys
    from six import text_type
    from imp import load_source
    from warnings import warn

    settings = Settings(const.DEFAULT_SETTINGS)

    # test _get_user_dir_path
    xdg_config_home = os.environ.get('XDG_CONFIG_HOME', '~/.config')
    user_dir = Path(xdg_config_home, 'thefuck').expanduser()
    legacy_user_dir = Path('~', '.thefuck').expanduser()
    assert settings._get_user_dir_path() == user_dir

    # test _setup_user_dir
    settings._setup_user_dir()
    assert settings.user_dir == user_

# Generated at 2022-06-18 06:38:38.361102
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.num_close_matches == 3
    assert settings.repeat == False


# Generated at 2022-06-18 06:38:49.378315
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path

    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.require_confirmation == True
    assert settings.wait_command == 1
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.history_limit == None
    assert settings.no_colors == False
    assert settings.wait_slow_command == 15
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.num_close_matches == 3
    assert settings.excluded_search_path_prefixes == []
   

# Generated at 2022-06-18 06:38:55.382762
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation
    assert settings.no_colors
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.alter_history
    assert settings.instant_mode
    assert settings.history_limit == 0
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3


# Generated at 2022-06-18 06:39:05.396328
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation is True
    assert settings.no_colors is False
    assert settings.wait_command is 3
    assert settings.wait_slow_command is 15
    assert settings.history_limit is None
    assert settings.alter_history is False
    assert settings.instant_mode is False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3

# Generated at 2022-06-18 06:39:14.869201
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from .settings import settings
    from .settings import _settings_from_file
    from .settings import _settings_from_env
    from .settings import _settings_from_args
    from .settings import _setup_user_dir
    from .settings import _get_user_dir_path
    from .settings import _init_settings_file

    # Test _init_settings_file
    settings_path = Path('~/.config/thefuck/settings.py').expanduser()
    if settings_path.is_file():
        settings_path.unlink()
    _init_settings_file()
    with settings_path.open(mode='r') as settings_file:
        assert settings_file.read() == const

# Generated at 2022-06-18 06:39:19.974046
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from mock import patch, Mock
    from six import text_type
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import environ

    def _mock_exception(msg, exc_info):
        raise exc_info[1]


# Generated at 2022-06-18 06:39:30.769689
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from mock import patch, Mock

    args = Mock()
    args.yes = True
    args.debug = True
    args.repeat = True

    with patch.object(settings, '_setup_user_dir') as mock_setup_user_dir, \
            patch.object(settings, '_init_settings_file') as mock_init_settings_file, \
            patch.object(settings, '_settings_from_file') as mock_settings_from_file, \
            patch.object(settings, '_settings_from_env') as mock_settings_from_env, \
            patch.object(settings, '_settings_from_args') as mock_settings_from_args, \
            patch('thefuck.settings.exception') as mock_exception:
        mock_settings_from_

# Generated at 2022-06-18 06:39:40.434160
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir.is_dir()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.user_dir.joinpath('rules').is_dir()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation
    assert settings.no_colors
    assert not settings.debug
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.alter_history
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == None
    assert settings.num_close_matches == 3
    assert settings

# Generated at 2022-06-18 06:39:49.907287
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False

# Generated at 2022-06-18 06:40:53.861181
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.priority == {}
    assert settings.history_limit == None
    assert settings.alter_history == True
    assert settings.exclude_rules == []
    assert settings.debug == False
    assert settings.repeat == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.instant_mode == False
    assert settings.num_close_matches == 3


# Generated at 2022-06-18 06:41:03.078332
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation
    assert settings.no_colors
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.alter_history
    assert settings.instant_mode
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == None
    assert settings.num_close_matches == 3
    assert settings.debug == False
    assert settings.repeat == 1


# Generated at 2022-06-18 06:41:12.039513
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings['require_confirmation'] == True
    assert settings['history_limit'] == None
    assert settings['wait_command'] == 3
    assert settings['wait_slow_command'] == 15

# Generated at 2022-06-18 06:41:23.229531
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.alter_history == True
    assert settings.history_limit == None
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.instant_mode == False
   

# Generated at 2022-06-18 06:41:33.635836
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    import shutil
    import os
    from .logs import exception

    def _test_settings_from_file(settings_file_content):
        with tempfile.NamedTemporaryFile(mode='w', delete=False) as settings_file:
            settings_file.write(settings_file_content)
        try:
            settings.user_dir = Path(settings_file.name).parent
            settings.init()
            return settings
        finally:
            os.remove(settings_file.name)

    def _test_settings_from_env(env_vars):
        old_env = os.environ.copy()
        try:
            os.environ.update(env_vars)
            settings.init()
            return settings
        finally:
            os.environ.clear()
            os

# Generated at 2022-06-18 06:41:42.157845
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3

# Generated at 2022-06-18 06:41:53.770808
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.repeat == False
    assert settings.wait_command == 1
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.alter_history == False
    assert settings.instant_mode == False
    assert settings.priority == {}
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3


# Generated at 2022-06-18 06:42:03.167045
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.debug == False
    assert settings.alter_history

# Generated at 2022-06-18 06:42:12.509527
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from .const import SETTINGS_HEADER, DEFAULT_SETTINGS, ENV_TO_ATTR
    from mock import patch, mock_open, MagicMock
    from six import StringIO
    from sys import exc_info

    settings = Settings(DEFAULT_SETTINGS)
    settings.user_dir = Path('/user_dir')

    with patch('thefuck.settings.Settings._settings_from_file',
               return_value={'wait_command': 10}):
        with patch('thefuck.settings.Settings._settings_from_env',
                   return_value={'wait_command': 20}):
            with patch('thefuck.settings.Settings._settings_from_args',
                       return_value={'wait_command': 30}):
                settings.init

# Generated at 2022-06-18 06:42:21.694057
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.repeat == False
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []

# Generated at 2022-06-18 06:44:50.973369
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    import os
    import sys
    from six import text_type
    from warnings import warn

    # Mock the method _setup_user_dir
    def _setup_user_dir(self):
        self.user_dir = Path('/home/user/.config/thefuck')
        self.user_dir.joinpath('rules').mkdir(parents=True)

    # Mock the method _init_settings_file
    def _init_settings_file(self):
        settings_path = self.user_dir.joinpath('settings.py')

# Generated at 2022-06-18 06:44:59.104149
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 0
    assert settings.require_confirmation
    assert settings.no_colors
    assert settings.debug
    assert settings.alter_history
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == 0
    assert settings.wait_slow_command == 0
    assert settings.num_close_matches == 3
    assert settings.instant_mode == False

# Generated at 2022-06-18 06:45:08.545064
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:45:20.819235
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings['require_confirmation'] == True

# Generated at 2022-06-18 06:45:29.768024
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from . import settings
    from . import __main__
    from . import __version__
    from . import __file__
    from . import __doc__
    from . import __author__
    from . import __author_email__
    from . import __license__
    from . import __url__
    from . import __copyright__
    from . import __all__
    from . import __title__
    from . import __summary__
    from . import __uri__
    from . import __requires__
    from . import __install_requires__
    from . import __keywords__
    from . import __classifiers__
    from . import __entry_points__
    from . import __project_urls__
    from . import __python_requires