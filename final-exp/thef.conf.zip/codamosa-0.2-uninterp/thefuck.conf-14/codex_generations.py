

# Generated at 2022-06-18 06:36:17.419737
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from .settings import settings
    from .settings import test_Settings_init
    from .settings import _get_user_dir_path
    from .settings import _setup_user_dir
    from .settings import _settings_from_file
    from .settings import _rules_from_env
    from .settings import _priority_from_env
    from .settings import _val_from_env
    from .settings import _settings_from_env
    from .settings import _settings_from_args
    from .utils import wrap_streams
    from .utils import wrap_stream
    from .utils import get_all_executables
    from .utils import get_all_scripts
    from .utils import get_all_alias
   

# Generated at 2022-06-18 06:36:26.664743
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from mock import patch
    from .system import Path

    # Test for method _init_settings_file
    with patch('thefuck.settings.Path') as mock_path:
        mock_path.return_value.is_file.return_value = False
        mock_path.return_value.open.return_value = 'settings_file'
        settings._init_settings_file()
        mock_path.return_value.open.assert_called_with(mode='w')
        assert 'settings_file' in sys.modules

    # Test for method _setup_user_dir
    with patch('thefuck.settings.Path') as mock_path:
        mock_path.return_value.expanduser.return_value = 'user_dir'

# Generated at 2022-06-18 06:36:36.563173
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 0
    assert settings.require_confirmation
    assert settings.no_colors
    assert not settings.debug
    assert settings.alter_history
    assert not settings.instant_mode
    assert settings.wait_slow_command == 3
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew']
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == None
    assert settings.num_close_matches == 3
    assert settings.repeat

# Generated at 2022-06-18 06:36:47.203411
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.repeat == 1


# Generated at 2022-06-18 06:36:58.069822
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:37:05.586886
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation
    assert settings.no_colors
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.alter_history
    assert settings.instant_mode
    assert settings.num_close_matches == 3
    assert settings.excluded_search_path_prefixes == []
    assert settings.debug is False

# Generated at 2022-06-18 06:37:16.971923
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_mat

# Generated at 2022-06-18 06:37:22.299262
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    from .logs import exception
    from .system import Path
    from . import const

    settings.init()

    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 3
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 10
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.repeat == False

# Generated at 2022-06-18 06:37:28.929656
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings

    def _init_settings_file(self):
        settings_path = self.user_dir.joinpath('settings.py')
        if not settings_path.is_file():
            with settings_path.open(mode='w') as settings_file:
                settings_file.write(const.SETTINGS_HEADER)
                for setting in const.DEFAULT_SETTINGS.items():
                    settings_file.write(u'# {} = {}\n'.format(*setting))

    def _get_user_dir_path(self):
        """Returns Path object representing the user config resource"""

# Generated at 2022-06-18 06:37:36.310004
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.no_colors is False
    assert settings.require_confirmation is True
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native-cli']
    assert settings.excluded_search_path_prefixes == []
    assert settings.debug is False
    assert settings.alter_history is False
    assert settings.instant_mode is False
    assert settings.num_close_matches == 3
    assert settings.repeat

# Generated at 2022-06-18 06:38:19.395979
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_mat

# Generated at 2022-06-18 06:38:30.974276
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from mock import patch, Mock
    from six import text_type
    from six.moves import reload_module

    reload_module(const)
    reload_module(exception)
    reload_module(Path)

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()

    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.user_dir.joinpath('rules').is_dir()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}

# Generated at 2022-06-18 06:38:38.310821
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.alter_history == True
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.instant_mode == False
    assert settings.repeat == None

# Generated at 2022-06-18 06:38:49.330945
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.excluded_search_path_prefixes == []
    assert settings.debug == False
    assert settings.alter_history == True

# Generated at 2022-06-18 06:38:57.425341
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == False
    assert settings.repeat == False
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
   

# Generated at 2022-06-18 06:39:08.044498
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from mock import patch, mock_open, MagicMock
    from six import StringIO

    def _mock_exception(msg, exc_info):
        raise exc_info[1]


# Generated at 2022-06-18 06:39:16.219205
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import shutil
    import tempfile
    from .logs import exception

    def _settings_from_file(settings_path):
        settings = load_source(
            'settings', text_type(settings_path))
        return {key: getattr(settings, key)
                for key in const.DEFAULT_SETTINGS.keys()
                if hasattr(settings, key)}

    def _settings_from_env():
        return {attr: settings._val_from_env(env, attr)
                for env, attr in const.ENV_TO_ATTR.items()
                if env in os.environ}

    def _settings_from_args(args):
        from_args = {}
        if args.yes:
            from_args['require_confirmation'] = not args.yes

# Generated at 2022-06-18 06:39:26.566783
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.alter_history == True
    assert settings.history_limit == None
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.excluded_search_path_prefixes == []
    assert settings.num

# Generated at 2022-06-18 06:39:37.137424
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 0
    assert settings.require_confirmation
    assert settings.no_colors
    assert settings.debug
    assert settings.alter_history
    assert settings.wait_slow_command == 3
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == 0
    assert settings.num_close_matches == 3
    assert settings.instant_mode
    assert settings.repeat == 1



# Generated at 2022-06-18 06:39:46.226644
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.priority == {}
    assert settings.require_confirmation
    assert settings.no_colors
    assert not settings.debug
    assert settings.wait_command == 1
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert not settings.alter_history
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert not settings.instant_mode
    assert not settings.repeat

    settings.init(args=object())

# Generated at 2022-06-18 06:40:57.283670
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation is True
    assert settings.no_colors is False
    assert settings.debug is False
    assert settings.alter_history is True
    assert settings.instant_mode is False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:41:02.128830
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    settings.init()
    assert settings.user_dir.is_dir()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.require_confirmation
    assert settings.history_limit == 10
    assert settings.wait_command == 0
    assert settings.wait_slow_command == 3
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.no_colors
    assert not settings.debug
    assert not settings.alter_history
    assert not settings.instant_mode
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3

    settings

# Generated at 2022-06-18 06:41:11.493997
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from .utils import get_all_executables
    from .const import DEFAULT_SETTINGS, ENV_TO_ATTR, SETTINGS_HEADER
    from .settings import Settings
    from .config import Config
    from .utils import get_all_executables
    from .utils import get_all_executables
    from .utils import get_all_executables
    from .utils import get_all_executables
    from .utils import get_all_executables
    from .utils import get_all_executables
    from .utils import get_all_executables
    from .utils import get_all_executables
    from .utils import get_all_executables
    from .utils import get_all_executables


# Generated at 2022-06-18 06:41:21.244005
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3


# Generated at 2022-06-18 06:41:32.554364
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path

    settings.clear()
    settings.init()

    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation is True
    assert settings.no_colors is False
    assert settings.wait_command is 3
    assert settings.history_limit is None
    assert settings.wait_slow_command is 15
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.debug is False
    assert settings.alter_history

# Generated at 2022-06-18 06:41:39.856333
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', './sbt']

# Generated at 2022-06-18 06:41:52.114576
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.num_close_matches == 3
    assert settings.repeat == False


# Generated at 2022-06-18 06:41:59.649806
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:42:09.380343
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from .settings import settings
    from .settings import test_Settings_init
    from .settings import _settings_from_args
    from .settings import _settings_from_env
    from .settings import _settings_from_file
    from .settings import _setup_user_dir
    from .settings import _get_user_dir_path
    from .settings import _init_settings_file
    from .settings import _rules_from_env
    from .settings import _priority_from_env
    from .settings import _val_from_env
    from .settings import _settings_from_args
    from .settings import _settings_from_env
    from .settings import _settings_from_file
    from .settings import _setup

# Generated at 2022-06-18 06:42:16.218599
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path

    settings = Settings(const.DEFAULT_SETTINGS)
    settings._setup_user_dir = lambda: None
    settings._init_settings_file = lambda: None
    settings._settings_from_file = lambda: {'require_confirmation': False}
    settings._settings_from_env = lambda: {'require_confirmation': True}
    settings._settings_from_args = lambda args: {'require_confirmation': False}
    settings.init()
    assert settings['require_confirmation'] == False

# Generated at 2022-06-18 06:45:10.988612
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', './sbt']

# Generated at 2022-06-18 06:45:15.512093
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == False
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.repeat == 1


# Generated at 2022-06-18 06:45:24.864727
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.excluded_search_path_prefixes == []
    assert settings.priority == {}
    assert settings.debug == False
    assert settings.alter_history

# Generated at 2022-06-18 06:45:32.774091
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew']
    assert settings.excluded_search_path_prefixes == []
    assert settings.debug == False
    assert settings.alter_history == False
    assert settings.repeat == False
    assert settings.num_close_matches == 3
