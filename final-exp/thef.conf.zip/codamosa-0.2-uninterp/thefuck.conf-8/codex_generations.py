

# Generated at 2022-06-18 06:35:57.568397
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    import sys
    import os
    from .system import Path
    from . import const
    from .settings import Settings
    from .settings import settings
    from .settings import test_Settings_init
    from .logs import exception
    from .logs import test_exception
    from .logs import test_log
    from .logs import test_warning
    from .logs import warning
    from .logs import log
    from .logs import test_log_to_file
    from .logs import log_to_file
    from .logs import test_log_to_output
    from .logs import log_to_output
    from .logs import test_log_exception
    from .logs import log_exception
    from .logs import test_log_to_stder

# Generated at 2022-06-18 06:36:06.833895
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from mock import patch, Mock
    from six import text_type

    settings = Settings(const.DEFAULT_SETTINGS)
    settings._setup_user_dir = Mock()
    settings._init_settings_file = Mock()
    settings._settings_from_file = Mock()
    settings._settings_from_env = Mock()
    settings._settings_from_args = Mock()

    settings.init()

    settings._setup_user_dir.assert_called_once_with()
    settings._init_settings_file.assert_called_once_with()
    settings._settings_from_file.assert_called_once_with()
    settings._settings_from_env.assert_called_once_with()
    settings

# Generated at 2022-06-18 06:36:17.792738
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.history_limit == None
    assert settings.priority == {}

# Generated at 2022-06-18 06:36:26.964656
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from mock import patch

    with patch.object(Settings, '_init_settings_file') as mock_init_settings_file:
        with patch.object(Settings, '_settings_from_file') as mock_settings_from_file:
            with patch.object(Settings, '_settings_from_env') as mock_settings_from_env:
                with patch.object(Settings, '_settings_from_args') as mock_settings_from_args:
                    with patch.object(exception, 'exception') as mock_exception:
                        settings.init()
                        mock_init_settings_file.assert_called_once_with()
                        mock_settings_from_file.assert_called_once_with()
                        mock_settings_from_env.assert_called_once_with()
                       

# Generated at 2022-06-18 06:36:37.057121
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.alter_history == True
    assert settings.repeat == False
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.excluded_

# Generated at 2022-06-18 06:36:47.468063
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path

    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == None
    assert settings.alter_history == False
    assert settings.instant_mode == False

# Generated at 2022-06-18 06:36:58.377193
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.alter_history == True
    assert settings.history_limit == None
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:37:05.795536
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path

    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == None
    assert settings.alter_history == False
    assert settings.instant_mode == False
    assert settings.num_close_matches == 3


# Generated at 2022-06-18 06:37:17.047876
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path

    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.alter_history == True
    assert settings.history_limit == None
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches

# Generated at 2022-06-18 06:37:27.120243
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.excluded_search_path_prefixes == []
    assert settings.debug == False
    assert settings.alter_history == True

# Generated at 2022-06-18 06:37:53.809269
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path

    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 0
    assert settings.history_limit == 0
    assert settings.wait_slow_command == 0
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == False
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3

# Generated at 2022-06-18 06:38:02.212362
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    import shutil
    import os
    import sys
    from six import text_type
    from .logs import exception

    def _settings_from_file():
        settings = load_source(
            'settings', text_type(user_dir.joinpath('settings.py')))
        return {key: getattr(settings, key)
                for key in const.DEFAULT_SETTINGS.keys()
                if hasattr(settings, key)}

    def _settings_from_env():
        return {attr: _val_from_env(env, attr)
                for env, attr in const.ENV_TO_ATTR.items()
                if env in os.environ}

    def _val_from_env(env, attr):
        val = os.environ[env]

# Generated at 2022-06-18 06:38:12.898212
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation is True
    assert settings.no_colors is False
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.alter_history is False
    assert settings.instant_mode is False
    assert settings.num_close_matches == 3

# Generated at 2022-06-18 06:38:21.218656
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:38:31.758612
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.require_confirmation is True
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.no_colors is False
    assert settings.alter_history is True
    assert settings.priority == {}
    assert settings.history_limit == None
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.instant_mode is False

# Generated at 2022-06-18 06:38:41.703999
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.repeat == False


# Generated at 2022-06-18 06:38:51.841515
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from mock import patch
    from six import text_type
    from .settings import Settings
    from .settings import settings
    from .settings import _settings_from_file
    from .settings import _settings_from_env
    from .settings import _settings_from_args
    from .settings import _get_user_dir_path
    from .settings import _setup_user_dir
    from .settings import _init_settings_file
    from .settings import _rules_from_env
    from .settings import _priority_from_env
    from .settings import _val_from_env
    from .settings import test_Settings_init
    from .settings import test_Settings_init_with_args


# Generated at 2022-06-18 06:38:59.133116
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation
    assert settings.no_colors
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.debug is False
    assert settings.alter_history is False
    assert settings.instant_mode is False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == 0

# Generated at 2022-06-18 06:39:09.882647
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    import shutil
    import os
    from .logs import exception

    def _test_init(args, expected_settings):
        settings.init(args)
        assert settings == expected_settings

    def _test_init_with_settings_file(settings_file_content, expected_settings):
        with tempfile.NamedTemporaryFile(mode='w', delete=False) as settings_file:
            settings_file.write(settings_file_content)
        settings.user_dir = Path(settings_file.name).parent
        _test_init(None, expected_settings)
        os.remove(settings_file.name)


# Generated at 2022-06-18 06:39:17.142697
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir.is_dir()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.history_limit == None
    assert settings.priority == {}
    assert settings.exclude_rules == []
    assert settings.repeat == False
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_

# Generated at 2022-06-18 06:40:05.181090
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 0
    assert settings.wait_slow_command == 3
    assert settings.alter_history == True
    assert settings.priority == {}
    assert settings.exclude_rules == []
    assert settings.history_limit == None
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.instant_mode == False
    assert settings.repeat == False
    assert settings.debug == False

# Generated at 2022-06-18 06:40:15.308572
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from .utils import get_all_executables
    from .utils import get_all_scripts

    # Test for method _init_settings_file
    def test_init_settings_file():
        # Create a temporary directory
        import tempfile
        temp_dir = tempfile.mkdtemp()
        settings.user_dir = Path(temp_dir)

        # Test for method _init_settings_file
        settings._init_settings_file()
        settings_path = settings.user_dir.joinpath('settings.py')
        assert settings_path.is_file()

        # Test for method _init_settings_file
        # If the settings file exists, it should not be overwritten
        settings._init_settings_file()
        assert settings_path.is_file

# Generated at 2022-06-18 06:40:25.172372
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3

# Generated at 2022-06-18 06:40:35.495813
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:40:44.804695
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3

    os.environ['THEFUCK_RULES']

# Generated at 2022-06-18 06:40:54.170277
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.history_limit == None
    assert settings.repeat == False
    assert settings.instant_mode == False
    assert settings.slow_commands

# Generated at 2022-06-18 06:41:03.461593
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch
    from thefuck.settings import Settings
    from thefuck.settings import const
    from thefuck.settings import os
    from thefuck.settings import sys


# Generated at 2022-06-18 06:41:12.309747
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:41:23.718123
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', './sbt']
    assert settings.excluded_search_path_prefixes

# Generated at 2022-06-18 06:41:34.012114
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from mock import patch

    with patch('thefuck.settings.Settings._settings_from_file',
               return_value={'key': 'value'}):
        with patch('thefuck.settings.Settings._settings_from_env',
                   return_value={'key2': 'value2'}):
            with patch('thefuck.settings.Settings._settings_from_args',
                       return_value={'key3': 'value3'}):
                with patch('thefuck.settings.Settings._setup_user_dir'):
                    settings.init()
                    assert settings == {'key': 'value',
                                        'key2': 'value2',
                                        'key3': 'value3'}


# Generated at 2022-06-18 06:43:01.617653
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:43:11.091267
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == None
    assert settings.num_close

# Generated at 2022-06-18 06:43:21.213477
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.slow_commands == []
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.inst

# Generated at 2022-06-18 06:43:30.940266
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.alter_history == True
    assert settings.priority == {}
    assert settings.exclude_rules == []
    assert settings.history_limit == None
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:43:39.798890
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    import shutil
    import os
    from .logs import exception

    def _get_user_dir_path():
        return Path(tempfile.mkdtemp())

    def _init_settings_file():
        settings_path = Path(tempfile.mkdtemp())
        with settings_path.open(mode='w') as settings_file:
            settings_file.write(const.SETTINGS_HEADER)
            for setting in const.DEFAULT_SETTINGS.items():
                settings_file.write(u'# {} = {}\n'.format(*setting))
        return settings_path

    def _settings_from_file():
        settings = load_source(
            'settings', text_type(settings_path))

# Generated at 2022-06-18 06:43:47.968560
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.history_limit == None
    assert settings.alter_history == False
    assert settings.excluded_search_path_prefixes == []


# Generated at 2022-06-18 06:43:56.686503
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.alter_history == True
    assert settings.history_limit == None
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.instant

# Generated at 2022-06-18 06:44:04.103255
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from mock import patch, MagicMock
    from six import StringIO
    from sys import exc_info

    def _get_user_dir_path():
        return Path('/user/dir')

    def _settings_from_file():
        return {'require_confirmation': False}

    def _settings_from_env():
        return {'require_confirmation': True}

    def _settings_from_args(args):
        return {'require_confirmation': False}

    def _init_settings_file():
        pass

    def _setup_user_dir():
        pass


# Generated at 2022-06-18 06:44:12.464511
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3

    os.environ['THEFUCK_RULES']

# Generated at 2022-06-18 06:44:21.035091
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.repeat == False
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', './sbt']
    assert settings.excluded_