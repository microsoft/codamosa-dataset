

# Generated at 2022-06-18 06:36:19.335173
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation
    assert not settings.no_colors
    assert not settings.debug
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.alter_history
    assert not settings.instant_mode
    assert settings.history_limit == None
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3

    settings.init(args=None)
    assert settings

# Generated at 2022-06-18 06:36:28.067425
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation
    assert settings.no_colors
    assert not settings.debug
    assert not settings.alter_history
    assert not settings.instant_mode
    assert settings.wait_command == 0
    assert settings.wait_slow_command == 3
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == 0
    assert settings.num_

# Generated at 2022-06-18 06:36:39.103161
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from .settings import settings
    from .settings import _settings_from_args
    from .settings import _settings_from_env
    from .settings import _settings_from_file
    from .settings import _setup_user_dir
    from .settings import _get_user_dir_path
    from .settings import _init_settings_file
    from .settings import _rules_from_env
    from .settings import _priority_from_env
    from .settings import _val_from_env
    from mock import patch
    import os
    import sys
    import tempfile
    import shutil

    def _mock_exception(msg, exc_info):
        pass


# Generated at 2022-06-18 06:36:48.417666
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    import os
    import sys
    import mock
    import pytest

    # Test for method _init_settings_file
    def test_Settings_init_settings_file():
        settings_path = Path('~/.config/thefuck/settings.py').expanduser()
        if settings_path.is_file():
            settings_path.unlink()
        settings = Settings(const.DEFAULT_SETTINGS)
        settings.user_dir = Path('~/.config/thefuck').expanduser()
        settings._init_settings_file()
        assert settings_path.is_file()
        settings_path.unlink()

    # Test for method _get_user_dir_path

# Generated at 2022-06-18 06:36:59.535310
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from .const import SETTINGS_HEADER, DEFAULT_SETTINGS, ENV_TO_ATTR
    from .settings import Settings
    from .utils import get_all_executables
    from .utils import get_all_search_paths
    from .utils import get_all_rules
    from .utils import get_all_exclude_rules
    from .utils import get_all_slow_commands
    from .utils import get_all_excluded_search_path_prefixes
    from .utils import get_all_priority
    from .utils import get_all_history_limit
    from .utils import get_all_wait_command
    from .utils import get_all_wait_slow_command
    from .utils import get_all_num_close_

# Generated at 2022-06-18 06:37:10.220087
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == None
    assert settings.alter_history == False
    assert settings.debug == False

# Generated at 2022-06-18 06:37:21.290725
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.history_limit == None
    assert settings.repeat == False
    assert settings.instant_mode == False
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', './sbt']

# Generated at 2022-06-18 06:37:30.777019
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path

    settings.init()

    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.excluded_search_path_prefixes == []
    assert settings.debug == False
    assert settings.alter_history == True

# Generated at 2022-06-18 06:37:39.021533
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from .utils import get_all_executables
    from mock import patch, mock_open, MagicMock
    from six import StringIO
    from contextlib import contextmanager
    import sys
    import os

    @contextmanager
    def mock_open_file(content):
        mock_file = MagicMock(spec=file)
        mock_file.__enter__.return_value = StringIO(content)
        with patch('thefuck.settings.open', mock_open(read_data=content), create=True):
            yield mock_file

    def get_settings_from_file(content):
        with mock_open_file(content) as mock_file:
            return Settings()._settings_from_file()

# Generated at 2022-06-18 06:37:48.721438
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.wait_command == 0
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.no_colors == False
    assert settings.priority == {}
    assert settings.exclude_rules == []
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.debug == False
    assert settings.alter_history == True


# Generated at 2022-06-18 06:38:35.543942
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import shutil
    from tempfile import mkdtemp
    from .logs import exception

    def _test_settings_from_file(settings_file_content, expected_settings):
        settings_file_path = Path(temp_dir, 'settings.py')
        with settings_file_path.open(mode='w') as settings_file:
            settings_file.write(settings_file_content)

        settings.init()
        assert settings == expected_settings

    def _test_settings_from_env(env_vars, expected_settings):
        for key, value in env_vars.items():
            os.environ[key] = value

        settings.init()
        assert settings == expected_settings


# Generated at 2022-06-18 06:38:47.247130
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.repeat == False
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []

# Generated at 2022-06-18 06:38:56.076175
# Unit test for method init of class Settings
def test_Settings_init():
    import mock
    from thefuck.settings import Settings
    from thefuck.settings import const
    from thefuck.settings import os
    from thefuck.settings import sys
    from thefuck.settings import warn
    from thefuck.settings import load_source
    from thefuck.settings import Path
    from thefuck.settings import text_type
    from thefuck.settings import open

    settings = Settings()
    settings.user_dir = mock.Mock()
    settings.user_dir.joinpath.return_value = 'settings.py'
    settings.user_dir.joinpath().is_file.return_value = True
    settings._init_settings_file = mock.Mock()
    settings._settings_from_file = mock.Mock()
    settings._settings_from_env = mock.Mock()
    settings._settings_from

# Generated at 2022-06-18 06:39:06.722068
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.alter_history == False
    assert settings.debug == False
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.instant_mode == False

# Generated at 2022-06-18 06:39:15.574321
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation
    assert settings.no_colors
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.alter_history
    assert settings.instant_mode
    assert settings.num_close_matches == 3
    assert settings.excluded_search_path_prefixes == []
    assert settings.repeat == 1

# Generated at 2022-06-18 06:39:26.265634
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.slow_commands == []
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.excluded_search_path_prefixes == []


# Generated at 2022-06-18 06:39:37.258660
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.alter_history == True
    assert settings.priority == {}
    assert settings.history_limit == None
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:39:46.339218
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from .settings import settings
    from .settings import _settings_from_args
    from .settings import _settings_from_env
    from .settings import _settings_from_file
    from .settings import _setup_user_dir
    from .settings import _get_user_dir_path
    from .settings import _init_settings_file
    from .settings import _rules_from_env
    from .settings import _priority_from_env
    from .settings import _val_from_env
    from . import utils
    from . import logs
    from . import system
    from . import const
    from . import settings
    from . import rules
    from . import history
    from . import shell
    from . import types

# Generated at 2022-06-18 06:39:55.938843
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_mat

# Generated at 2022-06-18 06:40:04.674638
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir.endswith('thefuck')
    assert settings.user_dir.is_dir()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.priority == {}
    assert settings.alter_history == False
    assert settings.instant_mode == False
    assert settings.num_close

# Generated at 2022-06-18 06:41:33.077089
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.excluded_search_path_prefixes == []
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.num_

# Generated at 2022-06-18 06:41:40.126432
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from mock import patch, Mock
    from six import text_type
    from tempfile import mkdtemp
    from shutil import rmtree
    from os import environ

    def _init_settings_file(self):
        settings_path = self.user_dir.joinpath('settings.py')
        if not settings_path.is_file():
            with settings_path.open(mode='w') as settings_file:
                settings_file.write(const.SETTINGS_HEADER)
                for setting in const.DEFAULT_SETTINGS.items():
                    settings_file.write(u'# {} = {}\n'.format(*setting))


# Generated at 2022-06-18 06:41:52.114475
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.excluded_search_path_prefixes == []
    assert settings.debug == False
    assert settings.alter_history == False
    assert settings.instant_mode == False
    assert settings.num_

# Generated at 2022-06-18 06:41:59.993950
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_mat

# Generated at 2022-06-18 06:42:09.736771
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3


# Generated at 2022-06-18 06:42:19.009163
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False

# Generated at 2022-06-18 06:42:27.482613
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    import sys
    import os
    import shutil
    import tempfile
    import unittest
    from mock import patch
    from thefuck.settings import Settings

    class SettingsInitTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.settings_path = os.path.join(self.temp_dir, 'settings.py')
            self.settings = Settings()

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_init_settings_file(self):
            self.settings._init_settings_file()
            self.assertTrue(os.path.isfile(self.settings_path))


# Generated at 2022-06-18 06:42:36.273361
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', './sbt']

# Generated at 2022-06-18 06:42:43.249329
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:42:54.442994
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from .settings import settings
    from .settings import test_Settings_init
    from .settings import _settings_from_args
    from .settings import _settings_from_env
    from .settings import _settings_from_file
    from .settings import _setup_user_dir
    from .settings import _get_user_dir_path
    from .settings import _init_settings_file
    from .settings import _rules_from_env
    from .settings import _priority_from_env
    from .settings import _val_from_env
    from .settings import _settings_from_args
    from .settings import _settings_from_env
    from .settings import _settings_from_file
    from .settings import _setup