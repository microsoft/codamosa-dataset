

# Generated at 2022-06-18 06:36:19.724516
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from unittest.mock import patch

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir.is_dir()
    assert settings.user_dir.joinpath('settings.py').is_file()

    with patch('thefuck.settings.Settings._settings_from_file') as mock_settings_from_file:
        mock_settings_from_file.side_effect = Exception('test')
        with patch('thefuck.settings.exception') as mock_exception:
            settings.init()
            mock_exception.assert_called_once_with("Can't load settings from file", mock_settings_from_file.side_effect)


# Generated at 2022-06-18 06:36:28.337137
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch
    from thefuck.settings import Settings
    from thefuck.settings import const

    with patch('thefuck.settings.Settings._settings_from_file') as mock_settings_from_file, \
         patch('thefuck.settings.Settings._settings_from_env') as mock_settings_from_env, \
         patch('thefuck.settings.Settings._settings_from_args') as mock_settings_from_args:
        mock_settings_from_file.return_value = {'key1': 'value1'}
        mock_settings_from_env.return_value = {'key2': 'value2'}
        mock_settings_from_args.return_value = {'key3': 'value3'}
        settings = Settings(const.DEFAULT_SETTINGS)
        settings.init()
       

# Generated at 2022-06-18 06:36:39.486390
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.user_dir.joinpath('rules').is_dir()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.history_limit == None
    assert settings.priority == {}
    assert settings.exclude_rules == []
    assert settings.slow_commands == []
    assert settings.ex

# Generated at 2022-06-18 06:36:48.655148
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir.is_dir()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.user_dir.joinpath('rules').is_dir()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation
    assert settings.no_colors
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.alter_history
    assert settings.instant_mode
    assert settings.num_close_matches == 3



# Generated at 2022-06-18 06:36:59.798316
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == False
    assert settings.instant_mode == False
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', './sbt']
    assert settings.excluded_search_path_prefix

# Generated at 2022-06-18 06:37:06.594349
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from mock import patch, Mock

    settings = Settings()
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.user_dir.joinpath('rules').is_dir()

    with patch('thefuck.settings.Settings._settings_from_file') as _settings_from_file:
        _settings_from_file.return_value = {'key': 'value'}
        settings.init()
        assert settings['key'] == 'value'


# Generated at 2022-06-18 06:37:17.826011
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    import os
    import sys
    import mock
    import six
    from six import text_type


# Generated at 2022-06-18 06:37:27.615999
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False

# Generated at 2022-06-18 06:37:35.346858
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.priority == {}
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew']
    assert settings.excluded_search_path_prefixes == []
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.num_close_matches

# Generated at 2022-06-18 06:37:45.365630
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.repeat == False
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.instant_mode == False
    assert settings.num_close_matches == 3


# Generated at 2022-06-18 06:38:20.661566
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation is True
    assert settings.no_colors is False
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.alter_history is False
    assert settings.instant_mode is False
    assert settings.debug is False
    assert settings.repeat is False


# Generated at 2022-06-18 06:38:31.429301
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from mock import patch
    from .system import Path

    with patch('thefuck.settings.Settings._settings_from_file') as \
            mock_settings_from_file, \
            patch('thefuck.settings.Settings._settings_from_env') as \
            mock_settings_from_env, \
            patch('thefuck.settings.Settings._settings_from_args') as \
            mock_settings_from_args, \
            patch('thefuck.settings.Path') as mock_path, \
            patch('thefuck.settings.exception') as mock_exception:
        mock_settings_from_file.return_value = {'key1': 'value1'}
        mock_settings_from_env.return_value = {'key2': 'value2'}
        mock_settings

# Generated at 2022-06-18 06:38:40.853121
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.priority == {}
    assert settings.history_limit == None
    assert settings.alter_history == True
    assert settings.exclude_rules == []
    assert settings.debug == False
    assert settings.repeat == False
    assert settings.num_close_matches == 3
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.instant_mode == False



# Generated at 2022-06-18 06:38:51.017875
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.priority == {}
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.excluded_search_path_prefixes == []
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.num_

# Generated at 2022-06-18 06:38:58.600009
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:39:09.319538
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings['require_confirmation'] == True
    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['exclude_rules'] == []
    assert settings['priority'] == {}
    assert settings['wait_command'] == 3
    assert settings['history_limit'] == 10
    assert settings['wait_slow_command'] == 10
    assert settings['slow_commands'] == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings['excluded_search_path_prefixes'] == []
    assert settings['num_close_matches'] == 3
    assert settings['alter_history'] == True
    assert settings['instant_mode'] == False
    assert settings['no_colors'] == False
    assert settings['debug'] == False
   

# Generated at 2022-06-18 06:39:16.868265
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()

    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.user_dir.joinpath('rules').is_dir()

    settings.init(args=None)
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.user_dir.join

# Generated at 2022-06-18 06:39:26.896924
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:39:37.655718
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir.is_dir()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.user_dir.joinpath('rules').is_dir()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 0
    assert settings.history_limit == 0
    assert settings.wait_slow_command == 0
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.require_confirmation is True
    assert settings.no_colors is False
    assert settings.debug is False
    assert settings.alter_history is False

# Generated at 2022-06-18 06:39:46.887984
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.history_limit == None
    assert settings.alter_history == False
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:40:54.774763
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_mat

# Generated at 2022-06-18 06:41:04.604915
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    from thefuck.utils import get_closest
    from thefuck.settings import Settings
    from thefuck.types import Settings as SettingsType
    from thefuck.types import Rules as RulesType
    from thefuck.types import Priority as PriorityType
    from thefuck.types import Env as EnvType
    from thefuck.types import Args as ArgsType
    from thefuck.types import Command as CommandType
    from thefuck.types import CorrectedCommand as CorrectedCommandType
    from thefuck.types import History as HistoryType
    from thefuck.types import NoRuleMatched as NoRuleMatchedType
    from thefuck.types import NoRuleMatched as NoRuleMatchedType
    from thefuck.types import NoRuleMatched as NoRuleMatchedType
    from thefuck.types import NoRuleMatched as NoRuleM

# Generated at 2022-06-18 06:41:12.795605
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.repeat == False
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []

# Generated at 2022-06-18 06:41:24.186680
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation is True
    assert settings.no_colors is False
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == None
    assert settings.alter_history is True
    assert settings.debug is False
    assert settings.num_close_matches == 3
    assert settings.instant_mode is False
    assert settings.repeat is None


# Generated at 2022-06-18 06:41:34.216602
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_mat

# Generated at 2022-06-18 06:41:40.772376
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation is True
    assert settings.no_colors is False
    assert settings.debug is False
    assert settings.alter_history is False
    assert settings.repeat is False
    assert settings.instant_mode is False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3


# Generated at 2022-06-18 06:41:52.527507
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from mock import patch, mock_open, MagicMock
    import os
    import sys

    # Mock the user_dir
    user_dir = MagicMock(spec=Path)
    user_dir.joinpath.return_value = 'settings.py'
    user_dir.is_dir.return_value = True
    user_dir.expanduser.return_value = user_dir
    user_dir.is_file.return_value = False

    # Mock the user_dir.joinpath('settings.py')
    settings_path = MagicMock(spec=Path)
    settings_path.open.return_value = mock_open(read_data=const.SETTINGS_HEADER)

    # Mock

# Generated at 2022-06-18 06:42:00.602046
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.repeat == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3


# Generated at 2022-06-18 06:42:10.230171
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.excluded_search_path_prefixes == []
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.num_

# Generated at 2022-06-18 06:42:19.520965
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:45:20.821962
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from .utils import get_all_executables
    from .utils import get_all_scripts
    from .utils import get_all_suffixes
    from .utils import get_all_paths
    from .utils import get_all_path_extensions
    from .utils import get_all_search_paths
    from .utils import get_all_search_path_extensions
    from .utils import get_all_search_prefixes
    from .utils import get_all_search_prefix_extensions
    from .utils import get_all_search_suffixes
    from .utils import get_all_search_suffix_extensions
    from .utils import get_all_search_extensions
    from .utils import get_all_search_extension_ext

# Generated at 2022-06-18 06:45:29.769200
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close