

# Generated at 2022-06-18 06:36:24.254472
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:36:31.482804
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch
    from thefuck.settings import Settings

    settings = Settings()
    with patch.object(settings, '_settings_from_file',
                      return_value={'key1': 'value1'}):
        with patch.object(settings, '_settings_from_env',
                          return_value={'key2': 'value2'}):
            with patch.object(settings, '_settings_from_args',
                              return_value={'key3': 'value3'}):
                settings.init()
                assert settings == {'key1': 'value1', 'key2': 'value2',
                                    'key3': 'value3'}


# Generated at 2022-06-18 06:36:43.378933
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.repeat == 1



# Generated at 2022-06-18 06:36:50.472418
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()

    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.repeat == False
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.ex

# Generated at 2022-06-18 06:37:01.138763
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.require_confirmation == True
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.alter_history == True
    assert settings.no_colors == False
    assert settings.priority == {}
    assert settings.history_limit == None
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.instant_mode == False
    assert settings.debug == False
    assert settings.repeat == False

# Generated at 2022-06-18 06:37:11.164774
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path

    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == None
    assert settings.alter_history == False
    assert settings.instant_mode == False
    assert settings.num_close_matches == 3
    assert settings.debug == False

# Generated at 2022-06-18 06:37:22.310407
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation is True
    assert settings.no_colors is False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.history_limit == None
    assert settings.alter_history is True
    assert settings.instant_mode is False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes

# Generated at 2022-06-18 06:37:28.929744
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    import shutil
    import os

    def _test_init(settings_file_content, env_vars, args, expected):
        tmp_dir = tempfile.mkdtemp()
        settings_file = os.path.join(tmp_dir, 'settings.py')
        with open(settings_file, 'w') as f:
            f.write(settings_file_content)

        for env_var, env_val in env_vars.items():
            os.environ[env_var] = env_val

        settings.init(args)

        shutil.rmtree(tmp_dir)
        for env_var in env_vars:
            del os.environ[env_var]

        assert settings == expected


# Generated at 2022-06-18 06:37:36.057869
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.num_close_matches == 3

# Generated at 2022-06-18 06:37:46.096054
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch
    from thefuck.settings import Settings
    from thefuck.utils import wrap_settings

    with patch('thefuck.settings.Settings._settings_from_file') as \
            mock_settings_from_file, \
            patch('thefuck.settings.Settings._settings_from_env') as \
            mock_settings_from_env, \
            patch('thefuck.settings.Settings._settings_from_args') as \
            mock_settings_from_args:
        mock_settings_from_file.return_value = {'key1': 'value1'}
        mock_settings_from_env.return_value = {'key2': 'value2'}
        mock_settings_from_args.return_value = {'key3': 'value3'}

        settings = Settings()
        settings.init()

# Generated at 2022-06-18 06:38:31.399276
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.require_confirmation
    assert settings.no_colors
    assert settings.debug
    assert settings.alter_history
    assert settings.repeat == 1
    assert settings.history_limit == 0
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.inst

# Generated at 2022-06-18 06:38:38.579021
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == False
    assert settings.repeat == False
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_mat

# Generated at 2022-06-18 06:38:49.378663
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.repeat == 1


# Generated at 2022-06-18 06:38:55.383235
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 3
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 10
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3

# Generated at 2022-06-18 06:39:05.336434
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from mock import patch, Mock
    import os
    import sys

    def _get_user_dir_path():
        return Path('/tmp/thefuck')

    def _settings_from_file():
        return {'rules': ['test_rule']}

    def _settings_from_env():
        return {'rules': ['test_rule_env']}

    def _settings_from_args(args):
        return {'rules': ['test_rule_args']}

    def _init_settings_file():
        pass

    def _setup_user_dir():
        pass

    def _val_from_env(env, attr):
        return 'test_rule_env'


# Generated at 2022-06-18 06:39:14.837841
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const

    settings = Settings(const.DEFAULT_SETTINGS)
    settings._setup_user_dir = lambda: None
    settings._init_settings_file = lambda: None
    settings._settings_from_file = lambda: {'require_confirmation': False}
    settings._settings_from_env = lambda: {'require_confirmation': True}
    settings._settings_from_args = lambda args: {'require_confirmation': False}

    settings.init()
    assert settings.require_confirmation == False

    settings._settings_from_file = lambda: {'require_confirmation': True}
    settings._settings_from_env = lambda: {'require_confirmation': False}

# Generated at 2022-06-18 06:39:25.896216
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == None
    assert settings.num_close_mat

# Generated at 2022-06-18 06:39:37.013970
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_mat

# Generated at 2022-06-18 06:39:45.775287
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation
    assert settings.no_colors
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.alter_history
    assert settings.instant_mode
    assert settings.num_close_matches == 3
    assert settings.excluded_search_path_prefixes == []
    assert settings.repeat == 1
    assert settings.debug == False

# Generated at 2022-06-18 06:39:55.330834
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from mock import patch, Mock, call
    from six import text_type

    settings = Settings(const.DEFAULT_SETTINGS)

# Generated at 2022-06-18 06:41:10.820627
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path

    settings = Settings(const.DEFAULT_SETTINGS)
    settings._setup_user_dir = lambda: None
    settings._init_settings_file = lambda: None
    settings._settings_from_file = lambda: {'require_confirmation': False}
    settings._settings_from_env = lambda: {'require_confirmation': True}
    settings._settings_from_args = lambda args: {'require_confirmation': False}

    settings.init()
    assert settings['require_confirmation'] is False

    settings._settings_from_file = lambda: {'require_confirmation': True}
    settings._settings_from_env = lambda: {'require_confirmation': False}

# Generated at 2022-06-18 06:41:20.620912
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from . import settings
    from . import rules
    from . import history
    from . import logs
    from . import utils
    from . import __main__
    from . import __version__
    from . import __doc__
    from . import __author__
    from . import __license__
    from . import __copyright__
    from . import __title__
    from . import __url__
    from . import __description__
    from . import __email__
    from . import __keywords__
    from . import __classifiers__
    from . import __requires__
    from . import __provides__
    from . import __with_pluggable_rules__
    from . import __with_pluggable_history__

# Generated at 2022-06-18 06:41:31.809931
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation
    assert settings.no_colors
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.priority == {}
    assert settings.alter_history
    assert settings.instant_mode

# Generated at 2022-06-18 06:41:39.466293
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.repeat == False
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []

# Generated at 2022-06-18 06:41:51.733374
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == settings._get_user_dir_path()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', './sbt']
    assert settings.ex

# Generated at 2022-06-18 06:41:59.754979
# Unit test for method init of class Settings

# Generated at 2022-06-18 06:42:09.461744
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 0
    assert settings.history_limit == 0
    assert settings.wait_slow_command == 0
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_mat

# Generated at 2022-06-18 06:42:18.733800
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.repeat == False
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', './sbt']
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_mat

# Generated at 2022-06-18 06:42:27.134550
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir.is_dir()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.user_dir.joinpath('rules').is_dir()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.priority == {}
    assert settings.num_close_mat

# Generated at 2022-06-18 06:42:36.000169
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.priority == {}
    assert settings.alter_history == False
    assert settings.repeat == False
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.excluded_

# Generated at 2022-06-18 06:45:31.110156
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.num_close_matches == 3
    assert settings.excluded_search_path_prefixes == []
   