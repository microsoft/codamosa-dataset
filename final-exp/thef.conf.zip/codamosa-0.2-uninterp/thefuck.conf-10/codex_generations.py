

# Generated at 2022-06-18 06:36:10.168303
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.repeat == None



# Generated at 2022-06-18 06:36:22.286277
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.history_limit == None
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.debug == False
    assert settings.repeat == False


# Generated at 2022-06-18 06:36:29.788004
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.history_limit == None
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3



# Generated at 2022-06-18 06:36:40.779395
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3


# Generated at 2022-06-18 06:36:49.372239
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:37:00.232780
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.excluded_search_path_prefixes == []
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.num_close_matches == 3

# Generated at 2022-06-18 06:37:11.005125
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    from .system import Path
    from .logs import exception

    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.user_dir.joinpath('rules').is_dir()
    assert settings.require_confirmation == True
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.exclude_rules == []

# Generated at 2022-06-18 06:37:21.763472
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.instant_mode == False
    assert settings.num_close_matches == 3

# Generated at 2022-06-18 06:37:31.176385
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.repeat == False
    assert settings.history_limit == None
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.instant_mode == False
   

# Generated at 2022-06-18 06:37:39.514932
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.alter_history == False
    assert settings.instant_mode == False
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
   

# Generated at 2022-06-18 06:38:20.194332
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew']
    assert settings.excluded_search_path_prefixes == []
    assert settings.debug == False
    assert settings.alter_history == True
   

# Generated at 2022-06-18 06:38:31.138752
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.repeat == False


# Generated at 2022-06-18 06:38:38.408575
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation
    assert settings.no_colors
    assert not settings.debug
    assert not settings.alter_history
    assert not settings.instant_mode
    assert settings.wait_command == 0
    assert settings.wait_slow_command == 3
    assert settings.history_limit == 0
    assert settings.priority == {}
    assert settings.exclude_rules == []
    assert settings.num_close_matches == 3
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
   

# Generated at 2022-06-18 06:38:49.378171
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit

# Generated at 2022-06-18 06:38:55.384089
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.history_limit == None
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.debug == False
    assert settings.repeat == False


# Generated at 2022-06-18 06:39:05.384852
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.history_limit == None
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', './sbt']

# Generated at 2022-06-18 06:39:14.869556
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()

    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.alter_history == True
    assert settings.priority == {}
    assert settings.exclude_rules == []
    assert settings.history_limit == None
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.excluded_search_path_

# Generated at 2022-06-18 06:39:19.937414
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.alter_history == False
    assert settings.instant_mode == False
    assert settings.repeat == False


# Generated at 2022-06-18 06:39:28.029961
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.repeat == False


# Generated at 2022-06-18 06:39:38.217829
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from .utils import get_all_executables

    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.require_confirmation
    assert settings.no_colors
    assert settings.alter_history
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle',
                                      './gradlew', 'vagrant']
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == None


# Generated at 2022-06-18 06:40:45.766763
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from mock import patch, Mock
    from six import StringIO
    import sys

    settings = Settings(const.DEFAULT_SETTINGS)
    settings._setup_user_dir = Mock()
    settings._init_settings_file = Mock()
    settings._settings_from_file = Mock()
    settings._settings_from_env = Mock()
    settings._settings_from_args = Mock()

    settings.init()

    settings._setup_user_dir.assert_called_once_with()
    settings._init_settings_file.assert_called_once_with()
    settings._settings_from_file.assert_called_once_with()
    settings._settings_from_env.assert_called_once_with()

# Generated at 2022-06-18 06:40:55.083512
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.alter_history == False
    assert settings.repeat == False
    assert settings.wait_slow_command == 15

# Generated at 2022-06-18 06:41:04.977661
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation
    assert settings.no_colors
    assert settings.priority == {}
    assert settings.wait_command == 0
    assert settings.history_limit == 0
    assert settings.wait_slow_command == 0
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.alter_history
    assert not settings.debug
    assert not settings.repeat
    assert not settings.instant_mode


# Generated at 2022-06-18 06:41:09.269189
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', './sbt']
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.no_colors
    assert not settings.debug
    assert settings.alter_history
    assert not settings.instant_mode
    assert settings.num_close_matches == 3

# Generated at 2022-06-18 06:41:15.345005
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.instant_mode == False
    assert settings.num_close_matches == 3


# Generated at 2022-06-18 06:41:26.801409
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception

    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.require_confirmation == True
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15

# Generated at 2022-06-18 06:41:36.104167
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .utils import get_all_executables
    from .utils import get_all_scripts
    from .utils import get_all_files
    from .utils import get_all_commands
    from .utils import get_all_rules
    from .utils import get_all_exclude_rules
    from .utils import get_all_priority
    from .utils import get_all_slow_commands
    from .utils import get_all_excluded_search_path_prefixes
    from .utils import get_all_require_confirmation
    from .utils import get_all_no_colors
    from .utils import get_all_debug
    from .utils import get_all_alter_history
    from .utils import get_all_inst

# Generated at 2022-06-18 06:41:47.025390
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from mock import patch, Mock
    import sys
    import os

    # mock the user_dir
    user_dir = Mock(spec=Path)
    user_dir.joinpath.return_value = 'settings.py'
    user_dir.is_dir.return_value = False
    user_dir.expanduser.return_value = user_dir
    user_dir.is_file.return_value = False

    # mock the settings_path
    settings_path = Mock(spec=Path)
    settings_path.open.return_value = 'settings_file'
    settings_path.is_file.return_value = False

    # mock the settings_file
    settings_file = Mock()
    settings

# Generated at 2022-06-18 06:41:56.992670
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.alter_history == False
    assert settings.instant_mode == False
    assert settings.debug == False


# Generated at 2022-06-18 06:42:05.778519
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 0
    assert settings.history_limit == 0
    assert settings.wait_slow_command == 0
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == False
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.ex

# Generated at 2022-06-18 06:43:25.328120
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings()
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings

# Generated at 2022-06-18 06:43:35.305641
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    from .logs import exception
    from .system import Path
    from . import const

    # Mock the method _get_user_dir_path
    def _get_user_dir_path(self):
        return Path('~/.thefuck').expanduser()

    # Mock the method _settings_from_file
    def _settings_from_file(self):
        return {'rules': ['test_rule']}

    # Mock the method _settings_from_env
    def _settings_from_env(self):
        return {'rules': ['test_rule_2']}

    # Mock the method _settings_from_args
    def _settings_from_args(self, args):
        return {'rules': ['test_rule_3']}

    # Mock the method _init_settings_file

# Generated at 2022-06-18 06:43:44.057877
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.priority == {}
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.alter_history == True
    assert settings.instant_mode == False
   

# Generated at 2022-06-18 06:43:51.532159
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.alter_history == True
    assert settings.repeat == False
    assert settings.wait_slow_command == 15

# Generated at 2022-06-18 06:44:00.327571
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 0
    assert settings.history_limit == 0
    assert settings.wait_slow_command == 0
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:44:07.611083
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path

    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation is True
    assert settings.no_colors is False
    assert settings.priority == {}
    assert settings.wait_command == 0
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == None
    assert settings.alter_history is False
    assert settings.instant_mode is False
    assert settings.num_close_matches == 3
    assert settings.repeat == 1

# Generated at 2022-06-18 06:44:15.862438
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:44:24.873999
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', './sbt']

# Generated at 2022-06-18 06:44:32.577184
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation
    assert settings.no_colors
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew']
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == None
    assert settings.alter_history
    assert settings.instant_mode
    assert settings.num_

# Generated at 2022-06-18 06:44:41.110082
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch
    from .logs import exception

    settings.init()
    assert settings.user_dir.joinpath('settings.py').is_file()

    with patch('thefuck.settings.Settings._settings_from_file',
               side_effect=Exception):
        with patch('thefuck.settings.exception') as exception_mock:
            settings.init()
            exception_mock.assert_called_with(
                "Can't load settings from file",
                (Exception, Exception(), None))

    with patch('thefuck.settings.Settings._settings_from_env',
               side_effect=Exception):
        with patch('thefuck.settings.exception') as exception_mock:
            settings.init()