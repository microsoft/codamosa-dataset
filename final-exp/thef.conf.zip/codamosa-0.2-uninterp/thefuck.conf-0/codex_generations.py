

# Generated at 2022-06-18 06:35:55.524409
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    from mock import patch
    from thefuck.settings import Settings
    from thefuck.settings import const
    from thefuck.settings import os

    settings = Settings()
    with patch.object(settings, '_settings_from_file', return_value={'rules': ['test_rule']}):
        with patch.object(settings, '_settings_from_env', return_value={'rules': ['test_rule_env']}):
            with patch.object(settings, '_settings_from_args', return_value={'rules': ['test_rule_args']}):
                settings.init()
                assert settings['rules'] == ['test_rule_args']


# Generated at 2022-06-18 06:35:59.716572
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.require_confirmation == True
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.alter_history == True
    assert settings.history_limit == None
    assert settings.no_colors == False
    assert settings.priority == {}
    assert settings.exclude_rules == []

# Generated at 2022-06-18 06:36:08.507733
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.alter_history == False
    assert settings.debug == False
    assert settings.num_close_matches == 3
    assert settings.instant_

# Generated at 2022-06-18 06:36:20.470702
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.history_limit == None
    assert settings.alter_history == False
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', './sbt']
    assert settings.num_close_matches == 3
    assert settings.instant_mode == False
   

# Generated at 2022-06-18 06:36:28.850356
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.require_confirmation == True
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15

# Generated at 2022-06-18 06:36:40.174003
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch
    from thefuck.settings import Settings, const

    with patch('thefuck.settings.Settings._settings_from_file') as \
            mock_settings_from_file, \
            patch('thefuck.settings.Settings._settings_from_env') as \
            mock_settings_from_env, \
            patch('thefuck.settings.Settings._settings_from_args') as \
            mock_settings_from_args, \
            patch('thefuck.settings.Settings._setup_user_dir') as \
            mock_setup_user_dir, \
            patch('thefuck.settings.Settings._init_settings_file') as \
            mock_init_settings_file:
        mock_settings_from_file.return_value = {'key': 'value'}

# Generated at 2022-06-18 06:36:49.047866
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings['require_confirmation'] == True
    assert settings['history_limit'] == None
    assert settings['wait_command'] == 3
    assert settings['wait_slow_command'] == 15

# Generated at 2022-06-18 06:37:00.107225
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.history_limit == None
    assert settings.alter_history == False
    assert settings.debug == False
    assert settings.excluded_search_path_prefixes

# Generated at 2022-06-18 06:37:10.923796
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.alter_history == True
    assert settings.debug == False
    assert settings.num_close_matches == 3

# Generated at 2022-06-18 06:37:22.059199
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir.is_dir()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.user_dir.joinpath('rules').is_dir()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.alter_history == False

# Generated at 2022-06-18 06:37:46.577140
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('rules').is_dir()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.exclude_rules == []
    assert settings

# Generated at 2022-06-18 06:37:55.023103
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3

# Generated at 2022-06-18 06:38:03.757661
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from .utils import wrap_streams
    from mock import patch, mock_open, call
    from six import StringIO


# Generated at 2022-06-18 06:38:13.874871
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3

    os.environ['THEFUCK_RULES']

# Generated at 2022-06-18 06:38:21.753145
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings['require_confirmation'] == True
    assert settings['rules'] == const.DEFAULT_RULES
    assert settings['priority'] == {}
    assert settings['exclude_rules'] == []
    assert settings['wait_command'] == 0
    assert settings['history_limit'] == None
    assert settings['wait_slow_command'] == 15
    assert settings['slow_commands'] == ['lein', 'gradle', './gradlew', 'sbt', './sbt']
    assert settings['no_colors'] == False
    assert settings['debug'] == False
    assert settings['alter_history'] == True
    assert settings['excluded_search_path_prefixes'] == []
    assert settings['num_close_matches'] == 3
    assert settings['instant_mode'] == False
   

# Generated at 2022-06-18 06:38:32.144846
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import shutil
    import tempfile
    from six import text_type

    def get_settings_from_file(settings_file):
        settings = load_source(
            'settings', text_type(settings_file))
        return {key: getattr(settings, key)
                for key in const.DEFAULT_SETTINGS.keys()
                if hasattr(settings, key)}

    def get_settings_from_env():
        return {attr: settings._val_from_env(env, attr)
                for env, attr in const.ENV_TO_ATTR.items()
                if env in os.environ}

    def get_settings_from_args(args):
        from_args = {}
        if args.yes:
            from_args['require_confirmation'] = not args.yes

# Generated at 2022-06-18 06:38:42.598504
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', './sbt']

# Generated at 2022-06-18 06:38:52.441388
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from .utils import wrap_streams

    with wrap_streams():
        settings.init()
        assert settings.user_dir == Path('~/.config/thefuck').expanduser()
        assert settings.user_dir.joinpath('settings.py').is_file()
        assert settings.user_dir.joinpath('rules').is_dir()
        assert settings.rules == const.DEFAULT_RULES
        assert settings.exclude_rules == []
        assert settings.priority == {}
        assert settings.require_confirmation is True
        assert settings.no_colors is False
        assert settings.wait_command is 3
        assert settings.wait_slow_command is 15
        assert settings.slow_commands == []
        assert settings.excluded_search_path_

# Generated at 2022-06-18 06:38:59.514422
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.alter_history
    assert settings.history_limit == None
    assert settings.no_colors
    assert settings.priority == {}
    assert settings.exclude_rules == []
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.instant_mode == False
    assert settings.debug == False
    assert settings.repeat == False


# Generated at 2022-06-18 06:39:10.293007
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 0
    assert settings.history_limit == 0
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == False
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.inst

# Generated at 2022-06-18 06:39:40.365817
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:39:49.865444
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path

    settings.init()

    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.require_confirmation == True
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15

# Generated at 2022-06-18 06:39:58.706087
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:40:06.824282
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import shutil
    import tempfile
    import unittest
    from thefuck.settings import Settings
    from thefuck.logs import exception

    class SettingsTest(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            os.environ['XDG_CONFIG_HOME'] = self.temp_dir
            self.settings = Settings()

        def tearDown(self):
            shutil.rmtree(self.temp_dir)

        def test_init_settings_file(self):
            self.settings.init()
            self.assertTrue(os.path.isfile(os.path.join(self.temp_dir,
                                                        'thefuck',
                                                        'settings.py')))


# Generated at 2022-06-18 06:40:17.774682
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:40:27.209752
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path

    def _init_settings_file(self):
        pass

    def _settings_from_file(self):
        return {'require_confirmation': False}

    def _settings_from_env(self):
        return {'require_confirmation': True}

    def _settings_from_args(self, args):
        return {'require_confirmation': False}

    def _get_user_dir_path(self):
        return Path('~/.thefuck').expanduser()

    def _setup_user_dir(self):
        pass

    def _get_user_dir_path(self):
        return Path('~/.thefuck').expanduser()

    def _setup_user_dir(self):
        pass


# Generated at 2022-06-18 06:40:36.953917
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew']
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.alter_

# Generated at 2022-06-18 06:40:46.274935
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir
    assert settings.user_dir.is_dir()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.user_dir.joinpath('rules').is_dir()
    assert settings.rules
    assert settings.priority
    assert settings.require_confirmation
    assert settings.no_colors
    assert settings.wait_command
    assert settings.wait_slow_command
    assert settings.history_limit
    assert settings.num_close_matches
    assert settings.alter_history
    assert settings.instant_mode
    assert settings.slow_commands
    assert settings.excluded_search_path_prefixes
    assert settings.exclude_rules
    assert settings.debug
    assert settings.repeat



# Generated at 2022-06-18 06:40:55.638876
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from .settings import settings
    from .settings import test_Settings_init
    from .settings import _settings_from_args
    from .settings import _settings_from_env
    from .settings import _settings_from_file
    from .settings import _setup_user_dir
    from .settings import _val_from_env
    from .settings import _priority_from_env
    from .settings import _rules_from_env
    from .settings import _get_user_dir_path
    from .settings import _init_settings_file
    from .settings import _setup_user_dir
    from .settings import _settings_from_file
    from .settings import _settings_from_env
    from .settings import _settings

# Generated at 2022-06-18 06:41:05.639168
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.repeat == 1


# Generated at 2022-06-18 06:41:56.247962
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    import sys
    import os
    from mock import patch, mock_open, call
    from six import StringIO

    args = type('', (), {'yes': True, 'debug': True, 'repeat': True})()


# Generated at 2022-06-18 06:42:05.634347
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation
    assert settings.no_colors is False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.alter_history is False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == None
    assert settings.num_close_matches == 3
    assert settings.instant_mode is False
    assert settings.debug is False
    assert settings.repeat is None


# Generated at 2022-06-18 06:42:15.599751
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import shutil
    import tempfile
    from .logs import exception

    def _test_settings_from_file(settings_path):
        with settings_path.open(mode='w') as settings_file:
            settings_file.write(const.SETTINGS_HEADER)
            for setting in const.DEFAULT_SETTINGS.items():
                settings_file.write(u'# {} = {}\n'.format(*setting))

    def _test_settings_from_env(env_to_attr):
        for env, attr in env_to_attr.items():
            os.environ[env] = attr

    def _test_settings_from_args(args):
        args.yes = True
        args.debug = True
        args.repeat = True


# Generated at 2022-06-18 06:42:23.962330
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3



# Generated at 2022-06-18 06:42:32.852535
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.num_close_matches == 3
    assert settings.instant_mode == False
    assert settings.excluded_search_

# Generated at 2022-06-18 06:42:40.170587
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import sys
    import shutil
    import tempfile
    from .logs import exception

    def _init_settings_file(settings_path):
        with settings_path.open(mode='w') as settings_file:
            settings_file.write(const.SETTINGS_HEADER)
            for setting in const.DEFAULT_SETTINGS.items():
                settings_file.write(u'# {} = {}\n'.format(*setting))

    def _settings_from_file(settings_path):
        settings = load_source(
            'settings', text_type(settings_path))
        return {key: getattr(settings, key)
                for key in const.DEFAULT_SETTINGS.keys()
                if hasattr(settings, key)}


# Generated at 2022-06-18 06:42:48.709686
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.repeat == False
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []

# Generated at 2022-06-18 06:42:59.674036
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    from .logs import exception
    from .system import Path

    def _get_user_dir_path():
        xdg_config_home = os.environ.get('XDG_CONFIG_HOME', '~/.config')
        user_dir = Path(xdg_config_home, 'thefuck').expanduser()
        legacy_user_dir = Path('~', '.thefuck').expanduser()

        if legacy_user_dir.is_dir():
            warn(u'Config path {} is deprecated. Please move to {}'.format(
                legacy_user_dir, user_dir))
            return legacy_user_dir
        else:
            return user_dir

    def _init_settings_file():
        settings_path = _get_user_dir_path().joinpath('settings.py')


# Generated at 2022-06-18 06:43:07.569487
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.repeat == False
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', './sbt']
    assert settings.excluded_

# Generated at 2022-06-18 06:43:18.780308
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:45:10.792589
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from .settings import settings
    from .settings import test_Settings_init
    from .settings import _settings_from_args
    from .settings import _settings_from_env
    from .settings import _settings_from_file
    from .settings import _setup_user_dir
    from .settings import _val_from_env
    from .settings import _get_user_dir_path
    from .settings import _init_settings_file
    from .settings import _rules_from_env
    from .settings import _priority_from_env
    from .utils import memoize
    from .utils import wrap_settings
    from .utils import get_all_executables
    from .utils import get_all_rules

# Generated at 2022-06-18 06:45:21.421532
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False

# Generated at 2022-06-18 06:45:30.070622
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
