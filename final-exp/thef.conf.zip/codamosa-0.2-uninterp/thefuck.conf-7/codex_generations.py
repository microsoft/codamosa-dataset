

# Generated at 2022-06-18 06:36:06.998683
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:36:18.086952
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_mat

# Generated at 2022-06-18 06:36:22.784066
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation is True
    assert settings.no_colors is False
    assert settings.debug is False
    assert settings.alter_history is True
    assert settings.instant_mode is False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:36:30.285923
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from mock import patch, Mock, call

    # Test init with default args

# Generated at 2022-06-18 06:36:41.696610
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'gradle', './gradlew', 'sbt', './sbt']
    assert settings.excluded_search_path_prefixes == []
    assert settings.debug == False
    assert settings.alter_history == True

# Generated at 2022-06-18 06:36:52.610081
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.priority == {}
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.debug == False


# Generated at 2022-06-18 06:37:02.181505
# Unit test for method init of class Settings
def test_Settings_init():
    import os
    import tempfile
    from .logs import exception
    from .system import Path

    def _get_user_dir_path():
        return Path(tempfile.gettempdir(), 'thefuck')

    def _setup_user_dir():
        user_dir = _get_user_dir_path()
        user_dir.mkdir()
        return user_dir

    def _init_settings_file():
        settings_path = _get_user_dir_path().joinpath('settings.py')
        with settings_path.open(mode='w') as settings_file:
            settings_file.write(const.SETTINGS_HEADER)
            for setting in const.DEFAULT_SETTINGS.items():
                settings_file.write(u'# {} = {}\n'.format(*setting))


# Generated at 2022-06-18 06:37:12.239582
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch
    from thefuck.settings import Settings

    with patch('thefuck.settings.Settings._settings_from_file') as \
            settings_from_file, \
            patch('thefuck.settings.Settings._settings_from_env') as \
            settings_from_env, \
            patch('thefuck.settings.Settings._settings_from_args') as \
            settings_from_args:
        settings_from_file.return_value = {'key1': 'val1'}
        settings_from_env.return_value = {'key2': 'val2'}
        settings_from_args.return_value = {'key3': 'val3'}
        settings = Settings()
        settings.init(args=None)

# Generated at 2022-06-18 06:37:23.254146
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const

    settings = Settings(const.DEFAULT_SETTINGS)
    settings._setup_user_dir = lambda: Path('/tmp/thefuck')
    settings._init_settings_file = lambda: None
    settings._settings_from_file = lambda: {'key': 'value'}
    settings._settings_from_env = lambda: {'key2': 'value2'}
    settings._settings_from_args = lambda args: {'key3': 'value3'}

    settings.init()

    assert settings['key'] == 'value'
    assert settings['key2'] == 'value2'
    assert settings['key3'] == 'value3'



# Generated at 2022-06-18 06:37:31.980994
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch
    from thefuck.settings import Settings
    from thefuck.settings import const
    from thefuck.settings import os
    from thefuck.settings import sys
    from thefuck.settings import warn
    from thefuck.settings import Path
    from thefuck.settings import load_source
    from thefuck.settings import text_type

    with patch('thefuck.settings.os.environ', {'XDG_CONFIG_HOME': '~/.config'}):
        with patch('thefuck.settings.Path.expanduser') as mock_expanduser:
            mock_expanduser.return_value = '~/.config/thefuck'
            with patch('thefuck.settings.Path.is_dir') as mock_is_dir:
                mock_is_dir.return_value = False

# Generated at 2022-06-18 06:37:59.515145
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir.is_dir()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation
    assert settings.no_colors
    assert settings.priority == {}
    assert settings.wait_command == 0
    assert settings.history_limit == 0
    assert settings.wait_slow_command == 0
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.alter_history
    assert settings.instant_mode
    assert settings.repeat == 1


# Generated at 2022-06-18 06:38:09.096634
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const

    settings = Settings(const.DEFAULT_SETTINGS)
    settings._setup_user_dir = lambda: Path('/home/user/.config/thefuck')
    settings._init_settings_file = lambda: None
    settings._settings_from_file = lambda: {'rules': ['test']}
    settings._settings_from_env = lambda: {'rules': ['test']}
    settings._settings_from_args = lambda: {'rules': ['test']}
    settings.init()
    assert settings['rules'] == ['test']

    settings = Settings(const.DEFAULT_SETTINGS)
    settings._setup_user_dir = lambda: Path('/home/user/.config/thefuck')

# Generated at 2022-06-18 06:38:19.261583
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch
    from thefuck.settings import Settings

    with patch('thefuck.settings.Settings._settings_from_file') as \
            settings_from_file, \
            patch('thefuck.settings.Settings._settings_from_env') as \
            settings_from_env, \
            patch('thefuck.settings.Settings._settings_from_args') as \
            settings_from_args:
        settings_from_file.return_value = {'key1': 'value1'}
        settings_from_env.return_value = {'key2': 'value2'}
        settings_from_args.return_value = {'key3': 'value3'}
        settings = Settings()
        settings.init(args='args')

# Generated at 2022-06-18 06:38:25.635245
# Unit test for method init of class Settings
def test_Settings_init():
    # Arrange
    args = type('', (), {'yes': True, 'debug': True, 'repeat': True})()
    settings = Settings(const.DEFAULT_SETTINGS)

    # Act
    settings.init(args)

    # Assert
    assert settings['require_confirmation'] == False
    assert settings['debug'] == True
    assert settings['repeat'] == True

# Generated at 2022-06-18 06:38:34.851292
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from mock import patch, Mock
    from six import text_type
    from six.moves import reload_module
    from unittest import TestCase

    class TestSettings(TestCase):
        def setUp(self):
            reload_module(const)
            reload_module(sys)
            reload_module(os)
            reload_module(exception)
            reload_module(Path)
            reload_module(Settings)
            self.settings = Settings(const.DEFAULT_SETTINGS)


# Generated at 2022-06-18 06:38:46.234866
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.ex

# Generated at 2022-06-18 06:38:55.211270
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from .utils import get_all_executables
    from .const import DEFAULT_SETTINGS
    from .const import SETTINGS_HEADER
    from .const import ENV_TO_ATTR
    from .const import DEFAULT_RULES
    from .const import DEFAULT_EXCLUDE_RULES
    from .const import DEFAULT_PRIORITY
    from .const import DEFAULT_WAIT_COMMAND
    from .const import DEFAULT_HISTORY_LIMIT
    from .const import DEFAULT_WAIT_SLOW_COMMAND
    from .const import DEFAULT_SLOW_COMMANDS
    from .const import DEFAULT_EXCLUDED_SEARCH_PATH_PREFIXES
    from .const import DEFAULT_

# Generated at 2022-06-18 06:39:04.915099
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch
    from thefuck.settings import Settings
    from thefuck.settings import const

    settings = Settings()
    settings.init()

    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.no_colors is False
    assert settings.require_confirmation is True
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
    assert settings.history_limit == None
    assert settings

# Generated at 2022-06-18 06:39:14.573443
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.repeat == False


# Generated at 2022-06-18 06:39:25.755692
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == False
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.inst

# Generated at 2022-06-18 06:40:16.335413
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    import os
    import sys

    def _init_settings_file(self):
        settings_path = self.user_dir.joinpath('settings.py')
        if not settings_path.is_file():
            with settings_path.open(mode='w') as settings_file:
                settings_file.write(const.SETTINGS_HEADER)
                for setting in const.DEFAULT_SETTINGS.items():
                    settings_file.write(u'# {} = {}\n'.format(*setting))

    def _get_user_dir_path(self):
        """Returns Path object representing the user config resource"""

# Generated at 2022-06-18 06:40:26.097723
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from .settings import settings
    from .settings import test_Settings_init
    from .settings import _settings_from_args
    from .settings import _settings_from_env
    from .settings import _settings_from_file
    from .settings import _init_settings_file
    from .settings import _setup_user_dir
    from .settings import _get_user_dir_path
    from .settings import _rules_from_env
    from .settings import _priority_from_env
    from .settings import _val_from_env
    from .settings import _settings_from_args
    from .settings import _settings_from_env
    from .settings import _settings_from_file
    from .settings import _init

# Generated at 2022-06-18 06:40:36.385508
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.alter_history == True
    assert settings.repeat == False
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew']
   

# Generated at 2022-06-18 06:40:45.648788
# Unit test for method init of class Settings
def test_Settings_init():
    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.wait_command == 1
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.alter_history == False
    assert settings.excluded_search_path_prefixes == []
    assert settings.inst

# Generated at 2022-06-18 06:40:50.737163
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew']
    assert settings.excluded_search_path_prefixes == []
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.num_close_matches

# Generated at 2022-06-18 06:40:59.773927
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from . import settings
    from . import rules
    from . import history
    from . import logs
    from . import utils
    from . import __main__
    from . import __version__
    from . import __doc__
    from . import __author__
    from . import __license__
    from . import __copyright__
    from . import __email__
    from . import __status__
    from . import __url__
    from . import __title__
    from . import __summary__
    from . import __uri__
    from . import __keywords__
    from . import __requires__
    from . import __provides__
    from . import __classifiers__
    from . import __description__
    from . import __platforms

# Generated at 2022-06-18 06:41:09.484001
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew']
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == None
    assert settings.alter_history == False

# Generated at 2022-06-18 06:41:15.427711
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3



# Generated at 2022-06-18 06:41:26.902904
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir.is_dir()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation
    assert settings.history_limit == const.DEFAULT_HISTORY_LIMIT
    assert settings.wait_command == const.DEFAULT_WAIT_COMMAND
    assert settings.wait_slow_command == const.DEFAULT_WAIT_SLOW_COMMAND
    assert settings.slow_commands == const.DEFAULT_SLOW_COMMANDS
    assert settings.exclude_rules == const.DEFAULT_EXCLUDE_RULES
    assert settings.excluded_search_path_prefixes == const.DEFAULT_EXCLUDED_SEARCH_PATH

# Generated at 2022-06-18 06:41:36.140847
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close

# Generated at 2022-06-18 06:43:04.176502
# Unit test for method init of class Settings
def test_Settings_init():
    from mock import patch
    from thefuck.settings import Settings, const
    from thefuck.logs import exception


# Generated at 2022-06-18 06:43:13.217549
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == ['lein', 'react-native', 'gradle', './gradlew']
    assert settings.excluded_search_path_prefixes == []
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.num_close_matches

# Generated at 2022-06-18 06:43:23.076999
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == None
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.alter_history == False
    assert settings.instant_mode == False
    assert settings.repeat == None
    assert settings.debug == False


# Generated at 2022-06-18 06:43:33.318105
# Unit test for method init of class Settings
def test_Settings_init():
    import tempfile
    import shutil
    import os

    temp_dir = tempfile.mkdtemp()
    user_dir = os.path.join(temp_dir, '.config', 'thefuck')
    os.makedirs(user_dir)
    settings_file = os.path.join(user_dir, 'settings.py')
    with open(settings_file, 'w') as f:
        f.write('require_confirmation = False\n')
        f.write('rules = [\'fuck\']\n')
        f.write('exclude_rules = [\'fuck\']\n')
        f.write('priority = {\'fuck\': 1}\n')
        f.write('wait_command = 1\n')
        f.write('history_limit = 1\n')

# Generated at 2022-06-18 06:43:41.718270
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.wait_slow_command == 15
    assert settings.slow_commands == []
    assert settings.exclude_rules == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.history_limit == None
    assert settings.alter_history == False
    assert settings.instant_mode == False
    assert settings.num_close_matches == 3
    assert settings.repeat == None

    os.environ['THEFUCK_RULES']

# Generated at 2022-06-18 06:43:49.688979
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 1
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 15
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True
    assert settings.instant_mode == False
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_mat

# Generated at 2022-06-18 06:43:58.479178
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from .utils import wrap_streams
    from .const import SETTINGS_HEADER, DEFAULT_SETTINGS, ENV_TO_ATTR
    from .settings import Settings
    from . import logs
    from . import system
    from . import utils
    from . import const
    from . import settings as s
    from . import logs as l
    from . import system as sy
    from . import utils as u
    from . import const as c

    # Mock
    logs = l
    system = sy
    utils = u
    const = c
    settings = s
    SETTINGS_HEADER = 'SETTINGS_HEADER'
    DEFAULT_SETTINGS = {'require_confirmation': True}

# Generated at 2022-06-18 06:44:05.376281
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path(os.environ.get('XDG_CONFIG_HOME', '~/.config'), 'thefuck').expanduser()
    assert settings.user_dir.joinpath('rules').is_dir()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.exclude_rules == []
    assert settings.priority == {}
    assert settings.wait_command == 0
    assert settings.history_limit == 10
    assert settings.wait_slow_command == 3
    assert settings.require_confirmation == True
    assert settings.no_colors == False
    assert settings.debug == False
    assert settings.alter_history == True

# Generated at 2022-06-18 06:44:14.058134
# Unit test for method init of class Settings
def test_Settings_init():
    from .logs import exception
    from .system import Path
    from . import const
    from .settings import Settings
    from .settings import settings
    from .settings import _settings_from_args
    from .settings import _settings_from_env
    from .settings import _settings_from_file
    from .settings import _setup_user_dir
    from .settings import _get_user_dir_path
    from .settings import _init_settings_file
    from .settings import _rules_from_env
    from .settings import _priority_from_env
    from .settings import _val_from_env

    settings = Settings(const.DEFAULT_SETTINGS)
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.require_confirmation == True


# Generated at 2022-06-18 06:44:22.761775
# Unit test for method init of class Settings
def test_Settings_init():
    settings.init()
    assert settings.user_dir == Path('~/.config/thefuck').expanduser()
    assert settings.user_dir.joinpath('settings.py').is_file()
    assert settings.rules == const.DEFAULT_RULES
    assert settings.require_confirmation
    assert settings.no_colors
    assert settings.wait_command == 0
    assert settings.wait_slow_command == 3
    assert settings.alter_history
    assert settings.priority == {}
    assert settings.exclude_rules == []
    assert settings.history_limit == 0
    assert settings.slow_commands == []
    assert settings.excluded_search_path_prefixes == []
    assert settings.num_close_matches == 3
    assert settings.instant_mode
    assert settings.repeat == 1


#