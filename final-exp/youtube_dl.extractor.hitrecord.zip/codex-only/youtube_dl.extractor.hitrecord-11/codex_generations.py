

# Generated at 2022-06-24 12:37:17.672978
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._URL_TEMPLATE == 'https://record.hitrecord.org/records/%s'
    assert HitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert HitRecordIE._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert HitRecordIE._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert HitRecordIE._TEST['info_dict']['id'] == '2954362'
    assert HitRecordIE._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 12:37:18.094049
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:37:19.575314
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:37:20.084724
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE()

# Generated at 2022-06-24 12:37:21.548827
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL
    assert HitRecordIE._TEST
    assert HitRecordIE.__doc__

# Generated at 2022-06-24 12:37:23.026514
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:37:24.470029
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Constructor of class HitRecordIE
    HitRecordIE("")

# Generated at 2022-06-24 12:37:25.486876
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert(HitRecordIE())

# Generated at 2022-06-24 12:37:33.051413
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:37:35.357897
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')
    assert ie.test_test()

# Generated at 2022-06-24 12:37:37.604622
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(HitRecordIE._VALID_URL, HitRecordIE._TEST)
    ie.download('2954362')

# Generated at 2022-06-24 12:37:38.263449
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()
    print(obj)


# Generated at 2022-06-24 12:37:45.576149
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie=HitRecordIE()
    ie.suitable('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:37:47.971877
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('HitRecord')
    assert ie is not None
    assert ie.get_info_extractor is not None

# Generated at 2022-06-24 12:37:52.375673
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    url = 'https://hitrecord.org/records/2954362'
    video_id = '2954362'
    hitRecordIE._real_extract(url)

    return hitRecordIE._VALID_URL


# Generated at 2022-06-24 12:37:54.311601
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie2 = HitRecordIE()
    ie3 = HitRecordIE()

# Generated at 2022-06-24 12:37:55.943700
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # ie_test.test_handle_error_format_id(ie)
    ie_test.test_correct_format_id(ie)

# Generated at 2022-06-24 12:38:02.803407
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:38:04.420502
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    raise NotImplementedError

if __name__ == "__main__":
    test_HitRecordIE()

# Generated at 2022-06-24 12:38:07.790612
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Creation of an Instance of HitRecordIE
    ie = HitRecordIE()
    assert ie.__class__.__name__ == 'HitRecordIE'


# Generated at 2022-06-24 12:38:08.758510
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:09.352617
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:11.402884
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'

# Generated at 2022-06-24 12:38:12.630864
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	hitrecord = HitRecordIE()
	assert(hitrecord)

# Generated at 2022-06-24 12:38:24.368741
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:26.614425
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:38:27.204441
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:33.579044
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'hitrecord'
    assert ie.http_headers() is None
    assert ie.__class__.__name__ == 'HitRecordIE'
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_download_webpage')
    assert hasattr(ie, '_WORKING')
    assert hasattr(ie, '_download_json')
    assert hasattr(ie, '_real_extract')
    assert ie._WORKING is True


# Generated at 2022-06-24 12:38:39.670767
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert('https://hitrecord.org/records/2954362' == ie._VALID_URL)
    assert('https://hitrecord.org/records/2954362' == ie.url)
    assert('2954362' == ie.video_id)
    assert('2954362' == ie._VALID_URL)
    assert('HitRecordIE' == ie.IE_NAME)


# Generated at 2022-06-24 12:38:40.051333
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-24 12:38:46.677998
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    #Constructor
    hr = HitRecordIE()

    # Test _VALID_URL
    assert hr._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

    # Test _TEST
    hr._TEST
    hr._TEST['info_dict']['view_count'] = int
    hr._TEST['info_dict']['like_count'] = int
    hr._TEST['info_dict']['comment_count'] = int
    hr._TEST['info_dict']['tags'] = list

# Generated at 2022-06-24 12:38:47.743066
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()
    assert obj

# Generated at 2022-06-24 12:38:57.164303
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    url = 'https://hitrecord.org/records/2954362'
    assert ie._VALID_URL == ie._TEST.get('url')
    assert ie._TEST['info_dict']['id'] == ie._match_id(url)
    assert ie._TEST['info_dict']['title'] == ie._real_extract(url).get('title')
    assert ie._TEST['info_dict']['description'] == ie._real_extract(url).get('description')
    assert ie._TEST['info_dict']['duration'] == ie._real_extract(url).get('duration')

# Generated at 2022-06-24 12:38:58.401106
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.url
    ie.match_id

# Generated at 2022-06-24 12:39:05.080539
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test the constructor of class HitRecordIE by creating an instance of the class
    hitRecordIE = HitRecordIE()
    # Test the validity of this URL
    assert hitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    # Test the extraction of an URL from YouTube
    assert hitRecordIE._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:39:11.609459
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL is not None # pylint: disable=protected-access
    assert ie.__name__ == 'hitrecord.org'
    assert ie.IE_DESC == 'hitrecord.org'
    assert ie.age_limit == 0
    assert ie.report_video_unavailable == 'We can\'t find this video.'
    assert ie.report_age_confirmation == 'age-verification'

# Generated at 2022-06-24 12:39:18.726159
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/(?:records/)?(?P<id>\d+)'

# Generated at 2022-06-24 12:39:27.186301
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video_id = '2954362'
    video_url = 'https://hitrecord.org/records/%s' % video_id

# Generated at 2022-06-24 12:39:28.557937
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()
    return

# Generated at 2022-06-24 12:39:30.025135
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE("http://hitrecord.org/records/2954362")
    hitRecordIE.extract("http://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:39:31.242347
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert(HitRecordIE)



# Generated at 2022-06-24 12:39:38.331854
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print(HitRecordIE._TEST)
    print(HitRecordIE._TEST['url'])
    print(HitRecordIE._TEST['url'])
    print(HitRecordIE._TEST['info_dict'])
    video_id = HitRecordIE._match_id(HitRecordIE._TEST['url'])
    video = HitRecordIE._download_json(
        'https://hitrecord.org/api/web/records/%s' % video_id, video_id)
    print(video)

# Generated at 2022-06-24 12:39:47.421674
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test a few functions
    # The test should pass if the function runs without error
    extractor = HitRecordIE("https://www.hitrecord.org/records/2954362")
    extractor._match_id("https://www.hitrecord.org/records/2954362")
    extractor._real_extract("https://www.hitrecord.org/records/2954362")
    extractor._download_json("https://hitrecord.org/api/web/records/2954362", "2954362")
    # Test with a non-existing video
    extractor = HitRecordIE("https://www.hitrecord.org/records/00000000")
    # The test should pass if an error is caught

# Generated at 2022-06-24 12:39:50.802277
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    # Unit test for extractor
    hitrecord.extract('https://hitrecord.org/records/2954362')    
    

# Generated at 2022-06-24 12:40:00.060045
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from re import compile as re_compile

    # Constructor shouldn't throw any exception when called with good parameters
    HitRecordIE('https://hitrecord.org/records/2954362')

    # Constructor should throw an exception when called with bad parameters
    # the exception should be an instance of class ValueError
    exception = None
    try:
        HitRecordIE('https://google.com')
    except Exception as e:
        exception = e
    assert type(exception) == ValueError

    # The constructor shouldn't match invalid URLs
    regex = re_compile(HitRecordIE._VALID_URL)
    assert not regex.match('https://hitrecord.org')
    assert regex.match('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:40:01.024744
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ie = HitRecordIE()
	assert ie is not None

# Generated at 2022-06-24 12:40:04.166886
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.suitable(ie.ie_key(), 'https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:40:06.712641
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_url = 'https://hitrecord.org/records/2954362'
    HitRecordIE()._real_extract(test_url)

# Generated at 2022-06-24 12:40:08.753814
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE._VALID_URL
    HitRecordIE._download_json
    HitRecordIE._match_id
    HitRecordIE._real_extract
    HitRecordIE.suitable
    HitRecordIE.__name__
    HitRecordIE.test
    HitRecordIE.__doc__

# Generated at 2022-06-24 12:40:12.010436
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    video_id = ie._match_id(ie._VALID_URL)
    assert video_id == '2954362'


# Generated at 2022-06-24 12:40:13.435622
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('http://hitrecord.org/records/2954362');

# Generated at 2022-06-24 12:40:17.374273
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    urls_to_test = [
        'https://hitrecord.org/records/2954362',
        'https://www.hitrecord.org/records/2954362',
    ]

    for url in urls_to_test:
        _test_HitRecordIE(url)


# Generated at 2022-06-24 12:40:18.566542
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    h = HitRecordIE()

# Generated at 2022-06-24 12:40:19.724368
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info = HitRecordIE()
    assert 1 == 1

# Generated at 2022-06-24 12:40:22.516191
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')



# Generated at 2022-06-24 12:40:25.096464
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from ..constructor import _create_ie_instance as create_ie_instance
    ie = create_ie_instance(HitRecordIE)
    assert ie.__name__ == 'HitRecord'



# Generated at 2022-06-24 12:40:28.488632
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # URL for video from hitrecord.org
    video_url = 'https://hitrecord.org/records/2954362'
    # create an instance of InfoExtractor
    ie = HitRecordIE()
    # check if video URL matches the pattern
    assert ie._match_id('url', video_url) == '2954362'

# Generated at 2022-06-24 12:40:34.205177
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Test that a HitRecord instance initializes correctly.
    """

    ieInstance = HitRecordIE('<url>')
    assert(ieInstance.SUFFIX == 'records/')
    assert(ieInstance._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')
    assert(ieInstance._TEST['url'] == 'https://hitrecord.org/records/2954362')
    assert(ieInstance._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71')
    assert(ieInstance._TEST['info_dict']['id'] == '2954362')

# Generated at 2022-06-24 12:40:36.866484
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE({})._download_json('http://api.hitrecord.org/records/2954362', '2954362')

# Generated at 2022-06-24 12:40:43.004022
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    assert hitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:43.597376
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:40:51.972459
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Create an object of class HitRecordIE
    obj = HitRecordIE()

    # Create a test url for the object
    url = "https://hitrecord.org/records/2954362"

    # Get the actual content from the url
    result = obj._real_extract(url)

    # Compare with the test values
    assert result["id"] == "2954362"
    assert result["title"] == "A Very Different World (HITRECORD x ACLU)"

# Generated at 2022-06-24 12:40:59.031964
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Unit test for constructor of class HitRecordIE.
    """
    ie = HitRecordIE()
    if ie._VALID_URL != ie.VALID_URL:
        raise AssertionError('%s != %s' % (ie._VALID_URL, ie.VALID_URL))
    _TEST = ie._TEST
    if _TEST != ie.TEST:
        raise AssertionError('%s != %s' % (_TEST, ie.TEST))

# Generated at 2022-06-24 12:41:10.454591
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:41:11.339669
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  ie = HitRecordIE()

# Generated at 2022-06-24 12:41:12.352689
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:19.183474
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.HEADERS['User-Agent'] == 'Mozilla/5.0 (iPad; U; CPU OS 3_2 like Mac OS X; en-us) AppleWebKit/531.21.10 (KHTML, like Gecko) Version/4.0.4 Mobile/7B334b Safari/531.21.102011-10-16 20:23:10'


# Generated at 2022-06-24 12:41:19.721633
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:20.291320
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:25.006280
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']

# Generated at 2022-06-24 12:41:26.227338
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-24 12:41:26.842100
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:28.784332
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    a = HitRecordIE()
    print(a._VALID_URL)
    print(a._TEST)

# Generated at 2022-06-24 12:41:32.937814
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert not ie.is_suitable("http://hitrecord.org/records/2954362/?q=c++")
    assert ie.is_suitable("http://hitrecord.org/records/2954362/")

# Generated at 2022-06-24 12:41:41.685408
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('www.hitrecord.org/records/2954362')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:41:42.857999
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE().extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:41:44.921998
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print("Testing HitRecordIE constructor")
    HitRecordIE()



# Generated at 2022-06-24 12:41:52.204772
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        import HTMLParser
    except ImportError:
        import html.parser as HTMLParser
    from .common import InfoExtractor
    from .common import SearchInfoExtractor
    from ..compat import compat_str
    from ..compat import compat_urlparse
    from ..utils import (
        clean_html,
        float_or_none,
        int_or_none,
        try_get,
    )
    hitRecord = HitRecordIE()
    assert isinstance(hitRecord, InfoExtractor)
    assert isinstance(hitRecord, SearchInfoExtractor)
    assert isinstance(hitRecord, HitRecordIE)


# Generated at 2022-06-24 12:41:54.249527
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:55.302653
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert isinstance(HitRecordIE,InfoExtractor)

# Generated at 2022-06-24 12:41:57.570120
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract("https://hitrecord.org/records/2954362")
# That's all!

# Generated at 2022-06-24 12:42:00.239047
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.extract('https://www.hitrecord.org/records/2954362') is not None

# Generated at 2022-06-24 12:42:01.956339
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(HitRecordIE._VALID_URL, HitRecordIE._TEST['url'])

# Generated at 2022-06-24 12:42:04.523907
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Constants
    target_url = "https://hitrecord.org/records/2954362"
    target_id = "2954362"

    HitRecordIE(target_url)

# Generated at 2022-06-24 12:42:05.246490
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:06.454627
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # init an object of HitRecordIE class
    HitRecordIE()

# Generated at 2022-06-24 12:42:08.233963
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(HitRecordIE._VALID_URL, HitRecordIE._TEST)


# Generated at 2022-06-24 12:42:09.240868
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-24 12:42:14.180168
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE('https://hitrecord.org/records/2954362');
    assert(hitRecord._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)');

# Generated at 2022-06-24 12:42:15.311281
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE(InfoExtractor())

# Generated at 2022-06-24 12:42:16.558310
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')
    

# Generated at 2022-06-24 12:42:20.013727
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    [TestHitRecordIE]
    class TestHitRecordIE(object):
        # Test case 1
        def _test_extract_id():
            ie = HitRecordIE({}, [], '', {})
            assert ie._match_id('https://hitrecord.org/records/2954362') == 2954362

# Generated at 2022-06-24 12:42:31.083784
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE(None)
    assert hitRecord._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert hitRecord._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert hitRecord._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert hitRecord._TEST['info_dict']['id'] == '2954362'
    assert hitRecord._TEST['info_dict']['ext'] == 'mp4'
    assert hitRecord._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:42:32.114137
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(HitRecordIE._VALID_URL)

# Generated at 2022-06-24 12:42:38.956857
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    test_cases = [
        {
            'url': 'https://hitrecord.org/records/2954362',
            'id': '2954362',
        },
        {
            'url': 'http://hitrecord.org/records/2954362',
            'id': '2954362',
        },
    ]
    for test_case in test_cases:
        url = ie._match_id(test_case['url'])
        assert url == test_case['id']


# Generated at 2022-06-24 12:42:40.541208
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print("Test HitRecordIE")
    HitRecordIE()

# Generated at 2022-06-24 12:42:41.134140
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:41.714304
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:42.691281
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('')

# Generated at 2022-06-24 12:42:44.073138
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

test_HitRecordIE.unit_test = True

# Generated at 2022-06-24 12:42:48.218610
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('http://hitrecord.org/records/2954362')
    info = ie._real_extract(
            'http://hitrecord.org/records/2954362')
    print(info)
    #assert ie.extract('http://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:42:50.537483
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    HitRecordIE._real_extract(HitRecordIE(), url)

# Generated at 2022-06-24 12:42:52.989375
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert hasattr(HitRecordIE, '_VALID_URL')
    assert hasattr(HitRecordIE, '_TEST')

# Generated at 2022-06-24 12:42:59.158332
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie_id = ie.ie_key()
    ie_name = ie.ie_key()
    ie_description = ie.ie_key()

    good_test = dict()
    good_test['ie_key'] = ie_id
    good_test['ie_key'] = ie_name
    good_test['ie_key'] = ie_description
    assert (ie_id, ie_name, ie_description) == ('HitRecord', 'HitRecord', 'HitRecord')

# Generated at 2022-06-24 12:42:59.669690
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:00.149133
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:02.236568
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:43:03.256099
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:43:03.823447
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:05.399486
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE(InfoExtractor)

    assert hitRecord is not None

# Generated at 2022-06-24 12:43:07.388534
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL
    assert ie._TEST

# Generated at 2022-06-24 12:43:08.379835
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:08.935132
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:09.866728
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert ie

# Generated at 2022-06-24 12:43:15.520354
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"
    assert HitRecordIE._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert HitRecordIE._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-24 12:43:23.762607
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record = HitRecordIE
    hit_record._download_json = lambda x: None
    hit_record_video = hit_record._real_extract('http://hitrecord.org/records/2954362')
    assert hit_record_video['id'] == '2954362'
    assert hit_record_video['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert hit_record_video['description'] == '<p>Collaboration with the ACLU to create a song/music video that reflects a desire to live in a very different world.</p>\n'
    assert hit_record_video['uploader_id'] == '362811'

# Generated at 2022-06-24 12:43:26.083538
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ie = HitRecordIE()
	assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-24 12:43:31.438189
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.name == 'hitrecord:record'
    assert ie._VALID_URL == HitRecordIE._VALID_URL

    assert ie._TEST['url'] == HitRecordIE._TEST['url']
    assert ie._TEST['md5'] == HitRecordIE._TEST['md5']
    assert ie._TEST['info_dict'] == HitRecordIE._TEST['info_dict']

# Generated at 2022-06-24 12:43:41.301147
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    import unittest
    test_class = unittest.TestCase()

    video_info_extractor = HitRecordIE()

    test_class.assertEqual(video_info_extractor._VALID_URL, r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-24 12:43:42.197082
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None, None, None)

# Generated at 2022-06-24 12:43:44.524508
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ydl = HitRecordIE()
    assert ydl.ie_key() == 'hitrecord'

# Generated at 2022-06-24 12:43:47.797114
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('http://hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org')

# Generated at 2022-06-24 12:43:50.229213
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """ Tests HitRecordIE constructor """
    ie = HitRecordIE()
    assert ie._VALID_URL == ie._TEST['url']
    assert ie._TEST['md5'] == ie._TEST['info_dict']['md5']



# Generated at 2022-06-24 12:43:51.450203
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# Unit test code
	h = HitRecordIE()
	h.test()

# Generated at 2022-06-24 12:43:52.103285
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)



# Generated at 2022-06-24 12:43:52.568485
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:53.377605
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('', {})

# Generated at 2022-06-24 12:43:55.374921
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE("https://hitrecord.org/records/2954362")


# Generated at 2022-06-24 12:44:04.626461
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:05.160558
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:44:05.688054
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:44:15.593232
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Unit test for constructor of class HitRecordIE.
    """
    URL = 'https://hitrecord.org/records/2965599'
    res = HitRecordIE()
    info_dict = res.extract(URL)

    assert info_dict['id'] == '2965599'
    assert info_dict['url'] == 'https://d1rtylhfu7l5zn.cloudfront.net/record/2016/09/25/123018/production_mp4.mp4'
    assert info_dict['title'] == '100 Days in Office (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:44:17.387737
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    assert isinstance(instance, HitRecordIE)


# Generated at 2022-06-24 12:44:20.385738
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie.url == 'https://hitrecord.org/records/2954362'
    assert ie.video_id == '2954362'


# Generated at 2022-06-24 12:44:23.487777
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecordIE = HitRecordIE()
    print(hitrecordIE)
if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:44:26.702700
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # This following line raises an exception since HitRecordIE's __init__
    # calls an unimplemented abstract method
    try:
        HitRecordIE()
    except:
        pass
    # The assert statement verifies that we have reached this point
    assert True

# Generated at 2022-06-24 12:44:27.318090
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-24 12:44:29.714777
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.suitable('https://hitrecord.org/records/2954362')

test_HitRecordIE()

# Generated at 2022-06-24 12:44:30.351854
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:44:31.821237
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:33.301907
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362");

# Generated at 2022-06-24 12:44:33.859553
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    assert HitRecordIE()

# Generated at 2022-06-24 12:44:36.119835
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._TEST == ie.get_test()

# Generated at 2022-06-24 12:44:38.068646
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE("https://hitrecord.org/records/2954362")
    except Exception as e:
        assert False
    assert True

# Generated at 2022-06-24 12:44:48.566762
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ins = HitRecordIE()

    assert ins._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ins._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ins._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ins._TEST['info_dict']['id'] == '2954362'
    assert ins._TEST['info_dict']['ext'] == 'mp4'
    assert ins._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:44:52.058035
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Test data for HitRecordIE
test_HitRecordIE.data = [
    'https://hitrecord.org/records/2954362'
]

# Generated at 2022-06-24 12:44:55.651606
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    u = 'https://hitrecord.org/records/2954362'
    i = ie._real_extract(u)
    print(i['id'])

# Generated at 2022-06-24 12:45:00.474230
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie_instance = HitRecordIE()
    assert ie_instance._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)', "VALID_URL mismatch"

# Generated at 2022-06-24 12:45:01.115281
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:45:02.867825
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract(test_HitRecordIE._TEST['url'])

# Generated at 2022-06-24 12:45:06.058400
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')


# Generated at 2022-06-24 12:45:08.621248
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except NameError as e:
        assert 'run time' in str(e)
    else:
        assert False

# Generated at 2022-06-24 12:45:18.885772
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie

    assert ie.IE_NAME == 'hitrecord:record'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:30.327446
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:38.900009
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)'

# Generated at 2022-06-24 12:45:40.452470
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("HitRecordIE", "hitrecord.org", "mp4")

# Generated at 2022-06-24 12:45:41.005654
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:45:42.405949
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:45:46.752989
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    unit_test_HitRecordIE = HitRecordIE.UnitTest("https://hitrecord.org/records/2954362")
    print("unit_test_HitRecordIE = ", unit_test_HitRecordIE)


# Generated at 2022-06-24 12:45:48.624606
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Create an instance of HitRecordIE
    hrie = HitRecordIE()
    # Download a video
    hrie._real_extract("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:45:50.261199
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'test'
    hitrecordIE = HitRecordIE(url)
    assert hitrecordIE is not None

# Generated at 2022-06-24 12:45:58.998544
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('http://https://hitrecord.org/records/2954362')
    assert ie.VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:46:09.105454
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Initialize test origin URL
    url = 'https://hitrecord.org/records/2954362'

    # Initialize test record id
    record_id = '2954362'

    # Initialize test instance
    info = HitRecordIE()

    # Run _VALID_URL test to check regex match
    matched = info._VALID_URL_RE.match(url)
    assert matched, 'Failed to match url by _VALID_URL_RE, url: ' + url

    # Run _real_extract to extract record info
    record_info = info._real_extract(url)

    # Check whether return value is None
    assert record_info, 'Failed to extract url: ' + url

    # Check record id
    assert record_info['id'] == record_id

# Generated at 2022-06-24 12:46:12.655943
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    constructor = HitRecordIE._constructor_test()
    assert_equals(constructor.ie_key(), 'HitRecord')
    assert_equals(constructor.ie_name(), 'hitrecord')
    assert_equals(constructor.supported_domains(), ['hitrecord.org'])

# Generated at 2022-06-24 12:46:13.213784
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:14.451388
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert isinstance(ie, HitRecordIE)

# Generated at 2022-06-24 12:46:17.746240
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(True)
    url = 'https://hitrecord.org/records/2954362'
    video_id = ie.extract_id(url)
    assert video_id == "2954362"

# Generated at 2022-06-24 12:46:19.505122
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # this is a new test for a new class
    HitRecordIE('hitrecord', 'hitrecord.org')

# Generated at 2022-06-24 12:46:21.487345
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  
  hit_record = HitRecordIE()

  assert hit_record.ie_key() == 'hitrecord'


# Generated at 2022-06-24 12:46:24.682000
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	try:
		HitRecordIE()
	except Exception as e:
		print('Unexpected exception raised: ' + e.__str__())
		return False
	return True


# Generated at 2022-06-24 12:46:26.654512
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(HitRecordIE._VALID_URL)
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:46:28.330885
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE("")
    assert hitRecordIE.name == "hitrecord.org"

# Generated at 2022-06-24 12:46:34.497553
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-24 12:46:35.912164
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract(HitRecordIE._TEST['url'])

# Generated at 2022-06-24 12:46:37.185561
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE("http://foo.bar/records/123")

# Generated at 2022-06-24 12:46:38.278776
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(HitRecordIE._downloader, HitRecordIE._VALID_URL)

# Generated at 2022-06-24 12:46:39.452334
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._TEST['url'] == HitRecordIE._VALID_URL

# Generated at 2022-06-24 12:46:41.970130
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_instance = HitRecordIE()
    assert test_instance._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:46:48.491007
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.suitable('https://hitrecord.org/records/2954362')
    assert HitRecordIE.suitable('http://hitrecord.org/records/2954362')

    assert HitRecordIE.suitable('https://hitrecord.org/records/2954362') == True
    assert HitRecordIE.suitable('https://hitrecord.org/records/2954362') != False

    assert HitRecordIE.suitable('http://hitrecord.org/records/2954362') == True
    assert HitRecordIE.suitable('http://hitrecord.org/records/2954362') != False


# Generated at 2022-06-24 12:46:59.525529
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'HitRecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:47:10.277491
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('hitrecord', 'hitrecord.org')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'