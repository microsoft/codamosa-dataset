

# Generated at 2022-06-24 12:37:04.288027
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test the HitRecordIE constructor
    HitRecordIE(True)

# Generated at 2022-06-24 12:37:06.060367
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    global hitRecordIE
    hitRecordIE = HitRecordIE()



# Generated at 2022-06-24 12:37:07.215687
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hr = HitRecordIE()
    assert hr is not None

# Generated at 2022-06-24 12:37:07.799113
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:37:11.727307
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Constructor unit test for class HitRecordIE
    instance = HitRecordIE(HitRecordIE.ie_key())
    print(instance.ie_key())
    assert (HitRecordIE.ie_key() == 'hitrecord')

# Generated at 2022-06-24 12:37:12.297453
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:37:14.066088
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecordIE = HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:37:16.537335
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:37:20.004157
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)

    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.NAME == 'HitRecord'
    assert ie.DASH_FLAVORS == [
        'main', 'high', 'medium', 'low'
    ]

# Generated at 2022-06-24 12:37:22.033140
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('test_HitRecordIE', 'https://hitrecord.org/records/2954362')
    assert isinstance(ie, HitRecordIE)

# Generated at 2022-06-24 12:37:22.588400
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:37:31.763360
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordTest = HitRecordIE()
    url = 'https://hitrecord.org/records/2954362'

# Generated at 2022-06-24 12:37:33.036477
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == "hitrecord"

# Generated at 2022-06-24 12:37:40.136966
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test = HitRecordIE()
    test_HitRecordIE = test._TEST
    #print(test_HitRecordIE['url'])
    test_url = test_HitRecordIE[u'url']
    test_id = test._match_id(test_url)
    test_id = int(test_id)
    #print(test_id)
    #print(test_HitRecordIE[u'info_dict'][u'id'])
    if test_id == int(test_HitRecordIE[u'info_dict'][u'id']):
        print('OK')

# Generated at 2022-06-24 12:37:40.956690
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:37:42.278660
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == HitRecordIE.VALID_URL

# Generated at 2022-06-24 12:37:45.095268
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-24 12:37:49.150295
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hits = 0
    for index in range(1, 5):
        url = 'https://hitrecord.org/records/%d' % index
        hits += HitRecordIE().suitable(url) and HitRecordIE().extract(url) is not None
    assert hits == 2

# Generated at 2022-06-24 12:37:53.102031
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('HitRecordIE', 'https://www.hitrecord.org/records/2954362')
    assert ie.url == 'https://www.hitrecord.org/records/2954362'



# Generated at 2022-06-24 12:37:54.166170
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ret = HitRecordIE()
    assert ret!=None

# Generated at 2022-06-24 12:38:04.126138
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:38:06.765602
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_obj = HitRecordIE()


# unit test for function _real_extract of class HitRecordIE

# Generated at 2022-06-24 12:38:07.391453
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:09.441323
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	instance = HitRecordIE('https://hitrecord.org/records/2954362')
	print("Test Passed")


# Generated at 2022-06-24 12:38:09.963894
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.initialize()

# Generated at 2022-06-24 12:38:10.940736
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:38:12.202857
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.title() == "HitRecord"

# Generated at 2022-06-24 12:38:13.606913
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('url', 'download')


if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:38:19.515489
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('https://hitrecord.org/records/2954362', {}).extract_info({})
    assert HitRecordIE('https://hitrecord.org/records/2954362', {})._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:20.571004
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()
    assert obj.url

# Generated at 2022-06-24 12:38:23.182978
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:38:25.543487
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._download_json.__name__ == 'HitRecordIE._download_json'

# Generated at 2022-06-24 12:38:26.563409
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:38:31.072239
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    ie = HitRecordIE(None, None)
    match = ie._VALID_URL % {'id': '2954362'}
    if not match in url:
        raise "Not correct input (url)"
    return {'id': '2954362'}


# Generated at 2022-06-24 12:38:41.306694
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert HitRecordIE._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert HitRecordIE._TEST['info_dict']['id'] == '2954362'
    assert HitRecordIE._TEST['info_dict']['ext'] == 'mp4'
    assert HitRecordIE._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert HitRecordIE._TEST['info_dict']['description'] == 'md5:e62defaffab5075a5277736bead95a3d'

# Generated at 2022-06-24 12:38:42.897116
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:38:43.359662
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:45.205205
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Test constructor of class HitRecordIE"""
    x = HitRecordIE(None)
    assert isinstance(x, HitRecordIE)

# Generated at 2022-06-24 12:38:48.649865
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')
    ie.extract('https://www.hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:38:50.225727
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ie = HitRecordIE()
	assert isinstance(ie, HitRecordIE)

# Generated at 2022-06-24 12:38:59.128813
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Constructor
    HitRecordIE()
    # test_parameter
    assert HitRecordIE._VALID_URL == (r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')
    assert HitRecordIE._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert HitRecordIE._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    # test_info_dict
    video = HitRecordIE()._real_extract(HitRecordIE._TEST['url'])
    assert video['upload_date'] == '20160818'
    assert video['view_count'] == int
    # test_tags
    tags = video['tags']

# Generated at 2022-06-24 12:39:03.744459
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    u= 'https://hitrecord.org/records/2954362'
    temp = HitRecordIE()
    print(temp.GetVideoID())
    #assert (temp.GetVideoID() == '2954362')
    return

test_HitRecordIE()

# Generated at 2022-06-24 12:39:11.058901
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  # Test on a non-existing video
  # It is really difficult to find a non-existing video, so I just found a youtube video
  # Hopefully, this option would never happen in the future
  ie = HitRecordIE()
  assert ie.suitable('https://www.youtube.com/watch?v=ErEa7I-1Xc8') == False

  # Test on a real thisamericanlife video
  ie = HitRecordIE()
  assert ie.suitable('https://hitrecord.org/records/2954362') == True


# Generated at 2022-06-24 12:39:13.570608
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert(HitRecordIE._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)")


# Generated at 2022-06-24 12:39:16.966953
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj_1 = HitRecordIE()
    obj_2 = InfoExtractor()

    assert obj_1 is not obj_2
    assert type(obj_1) == type(obj_2)

# Generated at 2022-06-24 12:39:25.793680
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE()._VALID_URL ==  r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:39:27.384886
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test = HitRecordIE()
    test._real_extract('https://hitrecord.org/records/2954362')
    test.suite()

# Generated at 2022-06-24 12:39:28.588391
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()


# Generated at 2022-06-24 12:39:29.820299
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('https://hitrecord.org/records/2954362')

# Assert type of HitRecordIE object

# Generated at 2022-06-24 12:39:30.492288
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:31.246549
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:35.464934
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # Check that HitRecordIE.constructor works
    ie.constructor('HitRecord', 'https://hitrecord.org/records/2954362', '1234')
    # Check that constructor without arguments result in an exception
    try:
        ie.constructor()
    except:
        pass

# Generated at 2022-06-24 12:39:39.841680
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_url = 'https://hitrecord.org/records/2954362'
    HitRecordIE._download_json(
        'https://hitrecord.org/api/web/records/%s' % video_id, video_id)

# Generated at 2022-06-24 12:39:48.344097
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    class_ = HitRecordIE
    assert class_._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert 'md5' in class_._TEST['info_dict']
    assert class_._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert class_._TEST['info_dict']['id'] == '2954362'
    assert class_._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert 'tags' in class_._TEST['info_dict']

# Generated at 2022-06-24 12:39:55.566881
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362') == True
    assert ie.suitable('https://hitrecord.org/records/2954362') == True
    assert ie.suitable('http://www.hitrecord.org/records/2954362') == True
    assert ie.suitable('https://www.hitrecord.org/records/2954362') == True
    assert ie.suitable('https://hitrecord.org/records/') == False

# Generated at 2022-06-24 12:40:03.313687
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    #Input from '_TEST'
    test_url = 'https://hitrecord.org/records/2954362'
    test_ext = 'mp4'
    test_id = '2954362'
    test_title = 'A Very Different World (HITRECORD x ACLU)'
    test_description = 'md5:e62defaffab5075a5277736bead95a3d'
    test_duration = 139.327
    test_timestamp = 1471557582
    test_upload_date = '20160818'
    test_uploader = 'Zuzi.C12'
    test_uploader_id = '362811'
    test_view_count = int
    test_like_count = int
    test_comment_count = int
    test_tags = list


# Generated at 2022-06-24 12:40:14.042574
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)'

# Generated at 2022-06-24 12:40:20.555505
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from .common import TestCase
    from .test_hitrecord import HitRecordIE
    test = TestCase()
    result = HitRecordIE()
    test.assertEqual(result._VALID_URL, r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-24 12:40:21.476654
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:40:23.063664
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(HitRecordIE._VALID_URL)

# Generated at 2022-06-24 12:40:24.128196
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert(HitRecordIE._TEST) # This should assert True

# Generated at 2022-06-24 12:40:25.814845
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    i = HitRecordIE()
    assert i.ie_key() == 'HitRecord'
    assert i.ie_name() == 'HitRecord'

# Generated at 2022-06-24 12:40:33.423976
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_cases = [
        {
            "input_url": "https://hitrecord.org/records/2954362",
            "expected_output": {
                "endpoint_url": "https://hitrecord.org/api/web/records/%s",
                "id": "HitRecord_2954362"
            }
        },
        {
            "input_url": "https://hitrecord.org/records/678910",
            "expected_output": {
                "endpoint_url": "https://hitrecord.org/api/web/records/%s",
                "id": "HitRecord_678910"
            }
        }
    ]
    for case in test_cases:
        ie = HitRecordIE(case["input_url"])

# Generated at 2022-06-24 12:40:35.064724
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Just get result of constructor."""
    HitRecordIE()

# Generated at 2022-06-24 12:40:36.015823
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-24 12:40:37.426301
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Constructor of HitRecordIE class should not raise any error
    HitRecordIE()

# Generated at 2022-06-24 12:40:47.665498
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    temp = HitRecordIE()
    assert temp._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert temp._TEST['url'] =='https://hitrecord.org/records/2954362'
    assert temp._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert temp._TEST['info_dict']['id'] == '2954362'
    assert temp._TEST['info_dict']['ext'] == 'mp4'
    assert temp._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:40:48.994997
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert(HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL)

# Generated at 2022-06-24 12:40:57.850747
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Constructor without module name raises ImportError
    try:
        ie = HitRecordIE(None, None, {}, None)
    except ImportError:
        assert True
    else:
        assert False

    # Constructor with empty module name raises ImportError
    try:
        ie = HitRecordIE('', None, {}, None)
    except ImportError:
        assert True
    else:
        assert False

    # Constructor with invalid module name raises ImportError
    try:
        ie = HitRecordIE('foo', None, {}, None)
    except ImportError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 12:41:04.903277
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    module = HitRecordIE('')
    assert module._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:41:08.558679
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    unit_test = ie._TEST
    assert ie._VALID_URL == HitRecordIE._VALID_URL
    assert ie._download_json(unit_test['url']) == HitRecordIE._download_json(
        unit_test['url'])
    assert ie._match_id(unit_test['url']) == HitRecordIE._match_id(
        unit_test['url'])
    assert ie._real_extract(unit_test['url'])['view_count'] == ie._real_extract(
        unit_test['url'])['view_count']

# Generated at 2022-06-24 12:41:09.155424
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-24 12:41:10.410679
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    x = HitRecordIE()
    assert x.ie_key() == 'hitrecord'

# Generated at 2022-06-24 12:41:17.152277
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test title and id extraction
    ie = HitRecordIE();
    title = ie._download_json(
        'https://hitrecord.org/api/web/records/2954362', '2954362');
    assert title['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert title['id'] == '2954362'
    # Test description extraction
    description = title['body']
    # assert description == 'HITRECORD x ACLU: A Very Different World<br><br><a href="https://www.aclu.org/feature/collaborative-project-a-very-different-world">https://www.aclu.org/feature/collaborative-project-a-very-different-world</a><br><br><strong>Story by HITRECORD Founder and Director, Joseph Gordon-Levitt</strong

# Generated at 2022-06-24 12:41:18.617896
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert(ie.construct_url("https://hitrecord.org/records/2954362") == "https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:41:22.196516
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'

# Generated at 2022-06-24 12:41:24.755385
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL
    assert HitRecordIE()._TEST == HitRecordIE._TEST


# Generated at 2022-06-24 12:41:36.042188
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ie = HitRecordIE()
	assert ie.SUFFIX == 'imdb'
	assert ie.age_limit == 0

	assert ie.IE_NAME == 'imdb'
	assert ie._VALID_URL == 'https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)'


# Generated at 2022-06-24 12:41:36.631693
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:39.132154
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"

# Generated at 2022-06-24 12:41:47.444732
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    ie = HitRecordIE()
    assert ie.constructor == HitRecordIE
    assert ie.suitable(url) == True
    assert ie.IE_NAME == 'hitrecord:record'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-24 12:41:48.607436
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:41:49.452055
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie

# Generated at 2022-06-24 12:41:49.964702
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:59.747423
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:42:00.312852
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("Email Protector")

# Generated at 2022-06-24 12:42:04.347558
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  # Invalid URL
  h = HitRecordIE(HitRecordIE._VALID_URL[:-1])
  assert not h._real_initialize()

  # Valid URL
  h = HitRecordIE("https://hitrecord.org/records/2954362")
  assert h._real_initialize()

# Generated at 2022-06-24 12:42:05.429009
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('', {})

# Generated at 2022-06-24 12:42:06.789910
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HitRecordIE()

# Generated at 2022-06-24 12:42:08.431049
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # I'm not sure if this url has the right format, but it always works so I guess...
    HitRecordIE()

# Generated at 2022-06-24 12:42:09.435409
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(InfoExtractor)

# Generated at 2022-06-24 12:42:20.181375
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:42:21.901487
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE != None

# Generated at 2022-06-24 12:42:23.298074
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test constructor of class HitRecordIE
    HitRecordIE()

# Generated at 2022-06-24 12:42:24.698200
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    print(hitRecordIE)

# Generated at 2022-06-24 12:42:34.230990
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:42:34.753660
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:36.395889
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-24 12:42:37.396145
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:42:41.239890
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable("https://hitrecord.org/records/2954362")
    assert ie.get_video_id("https://hitrecord.org/records/2954362") == "2954362"

# Generated at 2022-06-24 12:42:41.851677
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:51.556563
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE();
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:42:52.138107
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:01.318131
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecordie = HitRecordIE(None)
    assert hitrecordie.IE_NAME in 'HitRecordIE'
    assert hitrecordie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:43:11.892261
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.IE_NAME == 'hitrecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:43:14.893842
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Create a HitRecordIE object.
    ie = HitRecordIE('https://hitrecord.org/records/2954362')

    # Call the `test_HitRecordIE` function.
    test_HitRecordIE()

# Generated at 2022-06-24 12:43:19.746422
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Unit test function for HitRecordIE class
    """
    # Constructor test
    ie = HitRecordIE('http://www.hitrecord.org/records/123456')
    assert ie.name == 'hitrecord'
    assert ie.validate()

    # assert_raises test
    assert_raises(ExtractorError, HitRecordIE, 'http://www.hitrecord.org/')
    assert_raises(ExtractorError, ie.extract, 'http://www.hitrecord.org/')

# Generated at 2022-06-24 12:43:21.203073
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test basic initialization
    HitRecordIE(test=True)

# Generated at 2022-06-24 12:43:23.564853
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    test = ie.suitable('https://hitrecord.org/records/2954362')
    assert test

# Generated at 2022-06-24 12:43:28.040796
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    

# Generated at 2022-06-24 12:43:28.637196
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-24 12:43:33.830165
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert ie.IE_NAME == 'hitrecord'
    assert ie.valid_url(
        'https://hitrecord.org/records/2954362',
        pattern=ie.VALID_URL) == '2954362'
    assert ie.valid_url(
        'https://hitrecord.org/records/2954362312',
        pattern=ie.VALID_URL) is None


# Generated at 2022-06-24 12:43:35.552683
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # This test should create an object of class HitRecordIE
    assert HitRecordIE != None

# Generated at 2022-06-24 12:43:36.768722
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_ie = HitRecordIE()
    assert bool(hit_record_ie)

# Generated at 2022-06-24 12:43:41.837158
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362") 
    assert ie.url == "https://hitrecord.org/records/2954362", "URL should be the well-formatted url string passed to the constructor"
    assert ie.video_id == "2954362", "video_id must be the passed integer"
    

# Generated at 2022-06-24 12:43:43.524363
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Test YouTube constructor for HitRecordIE class
    """
    HitRecordIE(True, {'info_dict': {'id': '2954362'}})

# Generated at 2022-06-24 12:43:50.153761
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie.is_suitable(r'https://hitrecord.org/records/2954362')
    assert ie.is_suitable(r'https://www.hitrecord.org/records/2954362')
    assert ie.is_suitable(r'https://www.hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:43:51.183917
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Constructor test
    """
    ie = HitRecordIE()

# Generated at 2022-06-24 12:43:55.677737
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    ext = 'mp4'
    title = 'A Very Different World (HITRECORD x ACLU)'
    description = 'md5:e62defaffab5075a5277736bead95a3d'
    duration = 139.327
    timestamp = 1471557582
    upload_date = '20160818'
    uploader = 'Zuzi.C12'
    uploader_id = '362811'
    view_count = int
    like_count = int
    comment_count = int
    tags = list


# Generated at 2022-06-24 12:43:56.930835
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()



# Generated at 2022-06-24 12:43:58.020857
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    print(ie)

# Generated at 2022-06-24 12:44:00.376821
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:00.739171
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-24 12:44:01.661638
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:44:11.073961
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:19.233048
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    if 'hitrecord.org' not in InfoExtractor._downloader_cache.cache:
        InfoExtractor._downloader_cache.cache['hitrecord.org'] = {}
    if HitRecordIE.__name__ not in InfoExtractor._downloader_cache.cache['hitrecord.org']:
        InfoExtractor._downloader_cache.cache['hitrecord.org'][HitRecordIE.__name__] = {}
    # Initialize a HitRecordIE instance with the test url
    ie = HitRecordIE('http://www.hitrecord.org/records/2954362')
    # Check that the key-value pair 'id': '2954362' exists in the dictionary returned by _real_extract()
    assert 'id' in ie._real_extract('http://www.hitrecord.org/records/2954362')
   

# Generated at 2022-06-24 12:44:24.973701
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie.IE_NAME, compat_str)
    assert ie.IE_NAME == 'hitrecord'
    assert isinstance(ie.IE_DESC, compat_str)
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:29.190266
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    # test if the name of the class is correct
    assert hitRecordIE.IE_NAME == 'HitRecordIE'
    # test if the class is an instance of InfoExtractor
    assert isinstance(hitRecordIE, InfoExtractor)

# Generated at 2022-06-24 12:44:31.179032
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.ie_key = 'HitRecord'
    ie.ie_name = 'HitRecord'
    ie.ie_id = 'hitrecord'
    ie.webpage_url = ''
    ie.ad_free = True

# Generated at 2022-06-24 12:44:31.805919
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:44:40.647731
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:50.430909
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.url = ie._VALID_URL
    ie.video = ie.download(ie.url)
    assert ie.video is not None
    assert ie.video.url is not None
    assert ie.video.title is not None
    assert ie.video.description is not None
    assert ie.video.id is not None
    assert ie.video.uploader is not None
    assert ie.video.uploader_id is not None
    assert ie.video.timestamp is not None
    assert ie.video.duration is not None
    assert ie.video.view_count is not None
    assert ie.video.like_count is not None
    assert ie.video.comment_count is not None
    assert ie.video.tags is not None

# Generated at 2022-06-24 12:44:51.637589
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-24 12:44:53.737745
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Simple test case to see a construction of HitRecordIE class.
    """
    ie = HitRecordIE()

# Generated at 2022-06-24 12:44:57.518049
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    inst = HitRecordIE()
    assert inst._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"


# Generated at 2022-06-24 12:45:01.923453
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    assert hitrecord._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert hitrecord._TEST['url'] == 'https://hitrecord.org/records/2954362'

# Generated at 2022-06-24 12:45:10.719011
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    extracted = HitRecordIE()._real_extract(url)

    assert extracted['id'] == '2954362'
    assert extracted['url'] == 'https://cdn-images-1.medium.com/max/1600/1*MH5y5U5z6CKpG72YZbfMfA.mp4'
    assert extracted['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert extracted['description'] == 'md5:e62defaffab5075a5277736bead95a3d'
    assert extracted['duration'] == 139.327
    assert extracted['timestamp'] == 1471557582
    assert extracted['upload_date'] == '20160818'

# Generated at 2022-06-24 12:45:13.764470
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE(None)
    assert hitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:23.245541
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HITRECORD'
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:25.282242
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:26.500963
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract('https://www.hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:45:27.614893
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'

# Generated at 2022-06-24 12:45:32.230057
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    constructors = [
        lambda url: HitRecordIE().suitable(url),
        lambda url: HitRecordIE.suitable(url),
        lambda url: HitRecordIE.suitable(url)
    ]
    for constructor in constructors:
        yield check_suitable, constructor, HitRecordIE._VALID_URL



# Generated at 2022-06-24 12:45:37.843403
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.IE_NAME == 'hitrecord:record'
    assert ie.IE_DESC == 'hitrecord.org (record)'

    ie = HitRecordIE()
    assert ie.suitable('http://hitrecord.org/records/2954362')
    assert ie.IE_NAME == 'hitrecord:record'
    assert ie.IE_DESC == 'hitrecord.org (record)'

# Generated at 2022-06-24 12:45:41.179138
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
        assert(True)
    except Exception as e:
        print('Error: ' + str(e))
        assert(False)

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:45:44.065872
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    test_HitRecordIE.assertIsInstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:45:49.544155
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert HitRecordIE.suitable(HitRecordIE._VALID_URL)
    assert ie._VALID_URL == HitRecordIE._VALID_URL
    valid_url = 'https://hitrecord.org/records/2954362'
    assert ie._real_extract(valid_url)['id'] == '2954362'



# Generated at 2022-06-24 12:45:50.130048
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:45:52.227335
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert True

# Generated at 2022-06-24 12:45:53.803116
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
   hitrecord = HitRecordIE(HitRecordIE._VALID_URL)
   assert hitrecord != None

# Generated at 2022-06-24 12:45:58.928968
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    # initialize an object of class HitRecordIE by passing the url of 
    # the video to be extracted, then the class object is returned
    # In our test case, the url is:
    # 'https://hitrecord.org/records/2954362'
    hitrecord_ie = HitRecordIE._build_ie(url='https://hitrecord.org/records/2954362')

    # assert equal whether the type of the object is HitRecordIE
    assert type(hitrecord_ie) == HitRecordIE

# Generated at 2022-06-24 12:45:59.515435
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:02.588446
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	expected = HitRecordIE('HitRecord')
	actual = HitRecordIE('HitRecord')
	assert(expected.__str__() == actual.__str__())
	assert(expected == actual)

# Generated at 2022-06-24 12:46:05.607734
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	url = "https://hitrecord.org/records/2954362"
	HRIE =  HitRecordIE(url)
	assert HRIE._VALID_URL == url


# Generated at 2022-06-24 12:46:13.872938
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert repr(ie) == '<HitRecord>'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:46:14.763801
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-24 12:46:15.606324
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:46:25.227845
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print('test_HitRecordIE')

# Generated at 2022-06-24 12:46:26.879402
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie,InfoExtractor)


# Generated at 2022-06-24 12:46:28.374428
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    TestClass = HitRecordIE
    # Constructor of HitRecordIE
    HitRecordIE("unit test")

# Generated at 2022-06-24 12:46:30.546739
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-24 12:46:31.091392
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:46:32.004397
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:33.503405
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE()._get_info_extractor

# Generated at 2022-06-24 12:46:35.265715
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """ Test construction of HitRecordIE module """
    hie = HitRecordIE()
    assert hie is not None

# Generated at 2022-06-24 12:46:37.711638
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE({})
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'hitrecord'
    assert ie.SUCCESS

# Generated at 2022-06-24 12:46:40.164606
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_HitRecordIE = HitRecordIE()
    assert test_HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:46:41.135131
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie is not None


# Generated at 2022-06-24 12:46:43.723954
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:46:46.553241
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('hitrecord.org')
    assert ie.IE_NAME in ('hitrecord:video')
    assert ie.ie_key() == None
    assert ie.ie_info()


# Generated at 2022-06-24 12:46:47.334048
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL

# Generated at 2022-06-24 12:46:48.133538
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()


# Generated at 2022-06-24 12:46:50.340745
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    assert isinstance(hitrecord._download_json,
                      FunctionType)

# Generated at 2022-06-24 12:46:52.704613
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE('https://hitrecord.org/records/2954362')
    print(hitRecord)

# Generated at 2022-06-24 12:46:56.404160
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.suitable('https://hitrecord.org/records/2954362')
    ie.suitable('https://www.hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:46:57.494509
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('HitRecordIE', 'https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:47:02.360463
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# Import function HitRecordIE from extractor class hitrecord
	from .hitrecord import HitRecordIE
	# Create instance
	ie = HitRecordIE()
	# Test _VALID_URL attribute
	assert ie._VALID_URL == HitRecordIE._VALID_URL
	# Test _TEST attribute
	assert ie._TEST == HitRecordIE._TEST

# Generated at 2022-06-24 12:47:05.426440
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r"https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"