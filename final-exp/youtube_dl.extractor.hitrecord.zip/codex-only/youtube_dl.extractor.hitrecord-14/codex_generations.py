

# Generated at 2022-06-24 12:37:04.833588
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None, None)

# Generated at 2022-06-24 12:37:07.596263
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/')
    assert ie._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-24 12:37:10.150416
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:37:11.547217
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HI = HitRecordIE()

# Unit test condition: url

# Generated at 2022-06-24 12:37:13.325803
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print("start testing HitRecordIE")
    assert 1, HitRecordIE()
    print("end testing HitRecordIE")

# Generated at 2022-06-24 12:37:15.057938
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')


# Generated at 2022-06-24 12:37:19.038055
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()

    # Example Url
    video_url = "https://hitrecord.org/records/2954362"
    _, ie_key, _ = hitrecord._extract_url(video_url)
    assert ie_key == 'HitRecord'

# Generated at 2022-06-24 12:37:25.358529
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST.get('url') == 'https://hitrecord.org/records/2954362'
    assert ie._TEST.get('md5') == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-24 12:37:27.938655
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test HitRecordIE.__init__()
    # Initialize HitRecordIE object
    HitRecordIE(None)

# Generated at 2022-06-24 12:37:28.628707
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:37:31.765925
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except:
        print('Fail')
        return False
    else:
        print('Success')
        return True


# Generated at 2022-06-24 12:37:32.356605
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE();

# Generated at 2022-06-24 12:37:33.260016
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)

# Generated at 2022-06-24 12:37:35.227154
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE is not None

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:37:35.798395
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE

# Generated at 2022-06-24 12:37:36.739989
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('')

# Generated at 2022-06-24 12:37:40.603790
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.IE_NAME == 'hitrecord'
    assert ie.SUITABLE_COMBINATIONS == [('no_country', 'http'), ('no_country', 'https')]



# Generated at 2022-06-24 12:37:46.186479
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.extract_info("https://hitrecord.org/records/2954362") == {"id":"2954362","url":"https://hitrecord.org/records/2954362","title":"A Very Different World (HITRECORD x ACLU)","description":"md5:e62defaffab5075a5277736bead95a3d","duration":139.327,"timestamp":1471557582,"upload_date":"20160818","uploader":"Zuzi.C12","uploader_id":"362811","view_count":int,"like_count":int,"comment_count":int,"tags":list}

# Generated at 2022-06-24 12:37:47.037086
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:37:47.675872
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE()

# Generated at 2022-06-24 12:37:48.255080
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:37:52.764982
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert not ie.suitable('https://www.youtube.com/watch?v=mYFaghHyMKc') 


# Generated at 2022-06-24 12:38:01.121641
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"
    assert HitRecordIE._TEST['url'] == "https://hitrecord.org/records/2954362"
    assert HitRecordIE._TEST['md5'] == "fe1cdc2023bce0bbb95c39c57426aa71"
    assert HitRecordIE._TEST['info_dict']['id'] == "2954362"
    assert HitRecordIE._TEST['info_dict']['ext'] == "mp4"
    assert HitRecordIE._TEST['info_dict']['title'] == "A Very Different World (HITRECORD x ACLU)"

# Generated at 2022-06-24 12:38:03.173965
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    raise NotImplementedError('TODO: Write an unit test for HitRecordIE')

# Generated at 2022-06-24 12:38:07.049756
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Works for HitRecord
    test_url = (u'https://hitrecord.org/records/2954362')
    ie = HitRecordIE()
    ie.extract(test_url)


# Generated at 2022-06-24 12:38:09.078955
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Tests HitRecordIE class constructor
    """
    ie = HitRecordIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:38:16.589902
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE()
    assert info_extractor.get_url() == 'https://hitrecord.org/records/2954362'
    assert info_extractor.get_id() == '2954362'
    assert info_extractor.get_title() == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:38:19.807811
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Test for constructor of HitRecordIE."""
    hitrecord_instance = HitRecordIE()
    assert hitrecord_instance.ie_key() == 'HitRecord'



# Generated at 2022-06-24 12:38:21.224443
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:38:23.806843
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    print(ie)
    print(ie._real_extract('https://hitrecord.org/records/2954362'))

# Generated at 2022-06-24 12:38:27.395982
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    TestBase = dict(_TEST)
    TestBase.update({'id': TestBase['info_dict']['id']})
    ie.initialize(TestBase)
    return True

# Generated at 2022-06-24 12:38:29.399120
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # init method
    HitRecordIE._real_extract(self,'https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:38:35.151305
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

	# Test valid url
	try:
		HitRecordIE("http://hitrecord.org/records/2954362")
	except ValueError:
		assert False, "Valid url not accepted"
	
	# Test invalid url
	try:
		HitRecordIE("https://hitrecord.org")
		assert False, "Invalid url accepted"
	except ValueError:
		assert True, "Invalid url not accepted"


# Generated at 2022-06-24 12:38:37.462506
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+'

# Generated at 2022-06-24 12:38:41.691332
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit = HitRecordIE()
    test = hit._download_json('https://hitrecord.org/api/web/records/2954362', '2954362')
    print("The title is:" + test['title'])
    print("The video ID is:" + str(test['id']))


# Generated at 2022-06-24 12:38:42.245237
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:38:42.730917
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:51.757317
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    websites = [
        {
            'url': 'https://hitrecord.org/records/2954362',
            'expected_id': '2954362'
        },
        {
            'url': 'https://hitrecord.org/records/2954362',
            'expected_id': '2954362'
        },
        {
            'url': 'https://hitrecord.org/records/2954362',
            'expected_id': '2954362'
        }
    ]

    for website in websites:
        url = website['url']
        expected_id = website['expected_id']
        hitRecordIE = HitRecordIE(url)
        assert hitRecordIE._match_id(url) == expected_id

# Generated at 2022-06-24 12:38:57.039240
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Video link is valid
    assert(HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')
    # Initialize HitRecordIE instance with valid video link
    instance = HitRecordIE()._real_initialize(HitRecordIE._VALID_URL)
    # Check if instance is instance of HitRecordIE class
    assert(isinstance(instance, HitRecordIE))

# Generated at 2022-06-24 12:38:57.568071
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:00.357084
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("Test", "https://hitrecord.org/records/2954362", "Test", "Test")
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:39:00.980449
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)


# Generated at 2022-06-24 12:39:03.001137
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract_url("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:39:04.266018
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'HitRecord'

# Generated at 2022-06-24 12:39:06.338673
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE('hitrecord.org/records/2954362')
    except Exception as err:
        print(err)

# Generated at 2022-06-24 12:39:06.969634
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:07.964370
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    constructor_test(HitRecordIE)


# Generated at 2022-06-24 12:39:11.144655
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except TypeError as e:
        assert False, "constructor of class HitRecordIE raises exception: " + str(e)

# Generated at 2022-06-24 12:39:14.712962
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie.VALID_URL == HitRecordIE._VALID_URL
    assert ie.TEST == HitRecordIE._TEST

# Generated at 2022-06-24 12:39:23.866598
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:39:36.163417
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	import unittest

	class TestHitRecordIE(unittest.TestCase):
		def setUp(self):
			self.ie = HitRecordIE()
			self.ie._login = lambda: None
			self.ie._downloader._cache.clear()
		def test_match_id(self):
			self.assertEqual(self.ie._match_id('https://hitrecord.org/records/2954362'), '2954362')
		def test_extract(self):
			self.assertTrue(self.ie.suitable('https://hitrecord.org/records/2954362'))

	suite = unittest.TestLoader().loadTestsFromTestCase(TestHitRecordIE)

# Generated at 2022-06-24 12:39:40.370720
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    result = ie.extract('https://hitrecord.org/records/2954362')
    assert result['url'] == 'https://hitrecord.org/api/web/records/2954362.mp4'


# Generated at 2022-06-24 12:39:48.219856
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    video_id = ie._match_id(r'https://hitrecord.org/records/2954362')
    assert video_id == '2954362'
    video_id = ie._match_id(r'http://hitrecord.org/records/2954362')
    assert video_id == '2954362'
    video_id = ie._match_id(r'https://www.hitrecord.org/records/2954362')
    assert video_id == '2954362'
    video_id = ie._match_id(r'http://www.hitrecord.org/records/2954362')
    assert video_id == '2954362'



# Generated at 2022-06-24 12:39:58.217222
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:39:59.984804
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://www.hitrecord.org/records/2950892')

# Generated at 2022-06-24 12:40:01.172856
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    hitrecord.extract('hitrecord.org')

# Generated at 2022-06-24 12:40:11.873952
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord:record'
    assert ie.IE_DESC == 'HitRecord Record'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:15.889216
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    class_members = [attr for attr in dir(HitRecordIE) if inspect.ismethod(attr) or inspect.isfunction(attr)]

    assert "_VALID_URL" in class_members
    assert "_TEST" in class_members
    assert "_real_extract" in class_members



# Generated at 2022-06-24 12:40:17.600764
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    testInstance = HitRecordIE()
    assert testInstance.get_info_extractor_name() == 'HitRecord'

# Generated at 2022-06-24 12:40:22.649656
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    a = HitRecordIE()
    assert hasattr(a, '_VALID_URL')
    assert hasattr(a, '_TEST')
    assert hasattr(a, '_real_extract')
    assert hasattr(a, '_match_id')
    assert hasattr(a, '_download_json')
    assert hasattr(a, '_api_request')

# Generated at 2022-06-24 12:40:23.137544
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:40:25.091782
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    video_id = ie._match_id('https://hitrecord.org/records/2954362')
    assert video_id == '2954362'

# Generated at 2022-06-24 12:40:27.548097
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# arranges
	url = 'https://hitrecord.org/records/2954362'
	# acts
	extractor = HitRecordIE.suitable(url)
	# asserts
	assert extractor is not None

# Generated at 2022-06-24 12:40:28.997113
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')


# Generated at 2022-06-24 12:40:29.773956
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass


# Generated at 2022-06-24 12:40:33.114888
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie._match_id("https://hitrecord.org/records/2954362") == "2954362"

# Generated at 2022-06-24 12:40:34.437570
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()



# Generated at 2022-06-24 12:40:37.097272
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE("http://hitrecord.org/records/2954362")
    assert hitrecord.constructor == "HitRecordIE"

# Generated at 2022-06-24 12:40:39.448184
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE("HitRecordIE")
    assert isinstance(instance, HitRecordIE)

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:40:48.943853
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.get_metadata_moz('https://hitrecord.org/records/2954362') == {
        'id': '2954362',
        'ext': 'mp4',
        'title': 'A Very Different World (HITRECORD x ACLU)',
        'description': 136,
        'duration': 139.327,
        'timestamp': 1471557582,
        'upload_date': '20160818',
        'uploader': 'Zuzi.C12',
        'uploader_id': '362811',
        'view_count': int,
        'like_count': int,
        'comment_count': int,
        'tags': list,
    }

# Generated at 2022-06-24 12:40:52.717372
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_url = 'https://hitrecord.org/records/2954362'
    hitrecord_ie = HitRecordIE()
    assert hitrecord_ie._match_id(hitrecord_url) == '2954362'

# Generated at 2022-06-24 12:41:02.624449
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = "https://hitrecord.org/records/2954362"
    ie = HitRecordIE(url)
    assert ie is not None
    # Test if VideoID is parsed correctly
    assert ie._match_id(url) == '2954362'
    # Test if _real_extract method is capable of downloading a video correctly
    for _, info in ie._TEST['info_dict'].items():
        if isinstance(info, int):
            # Test if the numbers are integers
            assert isinstance(ie._real_extract(url)[str(_)], int)
        elif isinstance(info, list):
            # Test if the list of tags is made correctly
            assert isinstance(ie._real_extract(url)[str(_)], list)

# Generated at 2022-06-24 12:41:03.895814
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-24 12:41:04.650384
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE

# Generated at 2022-06-24 12:41:10.829277
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# Initializing HitRecordIE
	ie_hitrecord = HitRecordIE() 
	# Testing URL regex
	assert ie_hitrecord._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
	# Testing if instance of class InfoExtractor
	assert isinstance(ie_hitrecord, InfoExtractor)


# Generated at 2022-06-24 12:41:11.385179
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:22.281768
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.SUITABLE == 'universal'
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:41:25.236468
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:41:26.888205
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/3043290")

# Generated at 2022-06-24 12:41:27.949055
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()


# Generated at 2022-06-24 12:41:28.672787
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:32.259542
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'hitrecord.org'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:41:39.421679
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._match_id('https://hitrecord.org/records/2954362') == '2954362'

# Generated at 2022-06-24 12:41:40.521478
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie



# Generated at 2022-06-24 12:41:41.296715
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print("Testing HitRecordIE")
    HitRecordIE()

# Generated at 2022-06-24 12:41:42.777348
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://www.hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:41:46.028936
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	obj = HitRecordIE()
	assert obj._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"

# Generated at 2022-06-24 12:41:47.643732
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Verify that constructor of HitRecordIE class does not fail
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:41:57.969805
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Test constructor of class HitRecordIE"""

    # Test creation of HitRecordIE instance
    instance = HitRecordIE('HitRecord')

    assert instance._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert instance._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert instance._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

    video_id = instance._match_id('https://hitrecord.org/records/2954362')

    video = instance._download_json(
        'https://hitrecord.org/api/web/records/%s' % video_id, video_id)


# Generated at 2022-06-24 12:42:02.589601
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://www.hitrecord.org/records/2954362", {}, None)
    assert ie.initialize()
    assert ie.ie_key() == 'HitRecord'
    assert ie.extract("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:42:03.869136
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:42:04.437119
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:07.657771
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	u = "https://hitrecord.org/records/2954362"
	vIE = HitRecordIE()
	assert vIE._match_id(u) == "2954362"
	assert vIE.suitable(u) == True


# Generated at 2022-06-24 12:42:09.089810
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:42:12.300239
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract("https://hitrecord.org/records/2954362")


# Generated at 2022-06-24 12:42:13.439791
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:14.411602
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:42:19.252056
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print('Testing the constructor of the HitRecordIE')
    ie = HitRecordIE()

    assert ie.ie_key() == 'HitRecord'
    assert ie.ie_id() == 'hitrecord'
    assert ie._VALID_URL == ie.url_result(ie._VALID_URL)['url']
    assert ie._TEST == ie.extract(ie._TEST['url'])

# Generated at 2022-06-24 12:42:20.026807
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:23.843612
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE(downloader=None)
    print("Unit test for constructor of class HitRecordIE")
    assert (hitRecordIE.ie_key() == 'hitrecord')
    print("passed\n")

# Generated at 2022-06-24 12:42:33.545346
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("http://hitrecord.org/records/2954362")
    info = ie._real_extract("http://hitrecord.org/records/2954362")
    assert info['id'] == '2954362'
    assert info['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert info['url'] == 'https://hitrecord-assets.s3.amazonaws.com/uploads/record/source_url/' \
                          '150186/we_the_people.mp4'
    assert info['description'] == '<p>A film that takes Trump’s use of the phrase "- the American way' \
                                  '" during the debate and asks, "What is the American way?"</p>'

# Generated at 2022-06-24 12:42:35.989403
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hie = HitRecordIE()
    expect = 'HitRecordIE'
    actual = hie.IE_NAME
    assert expect == actual

# Generated at 2022-06-24 12:42:37.529753
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    myIE = HitRecordIE()
    assert myIE is not None


# Generated at 2022-06-24 12:42:48.004404
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')
    assert(ie._TEST['url'] == 'https://hitrecord.org/records/2954362')
    assert(ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71')
    assert(ie._TEST['info_dict']['id'] == '2954362')
    assert(ie._TEST['info_dict']['ext'] == 'mp4')
    assert(ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)')

# Generated at 2022-06-24 12:42:50.098621
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(InfoExtractor())._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:42:59.902028
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    h = HitRecordIE()
    h.ie_key = 'HitRecord'
    h.ie_name = 'HitRecord'
    h.ie_desc = 'An open online community for creative collaboration.'
    h.homepage = 'http://www.hitrecord.org/'
    h.url_re = r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

    assert h.ie_key == 'HitRecord'
    assert h.ie_name == 'HitRecord'
    assert h.ie_desc == 'An open online community for creative collaboration.'
    assert h.homepage == 'http://www.hitrecord.org/'

# Generated at 2022-06-24 12:43:09.643634
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._VALID_URL = r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:43:11.789818
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Class tests"""
    unit_test = HitRecordIE()
    assert unit_test is not None

# Generated at 2022-06-24 12:43:18.009093
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    sample_url = 'https://hitrecord.org/records/2954362'
    unit_test = HitRecordIE()
    unit_test._VALID_URL = (
        r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')
    unit_test._download_json = (
        'https://hitrecord.org/api/web/records/%s' % unit_test._match_id(sample_url))
    unit_test._real_extract(sample_url)

# Generated at 2022-06-24 12:43:28.896202
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.IE_NAME == 'hitrecord'
    assert ie.VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    ie.workingURL('https://hitrecord.org/records/2954362')
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'

# Generated at 2022-06-24 12:43:36.806811
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-24 12:43:43.402030
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.url = 'https://hitrecord.org/records/2954362'
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    # Added this to define variable 'id' in order to make sure that test passes
    ie.id = '2954362'
    # Added this to define variable '_download_webpage' in order to make sure that test passes

# Generated at 2022-06-24 12:43:45.723555
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('http://hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/')

# Generated at 2022-06-24 12:43:51.881317
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    class_ = HitRecordIE
    url = 'https://hitrecord.org/records/2954362'
    assert class_._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:43:52.770362
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # constructs object of the class
    HitRecordIE()



# Generated at 2022-06-24 12:44:02.563662
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    extracted_info = HitRecordIE().extract('https://hitrecord.org/records/2954362')
    assert extracted_info['id'] == '2954362'
    assert extracted_info['url'] == 'https://s3.amazonaws.com/hr-record-production/record/mp4s/302097/2YaoLfU6_avryd5784_ad8c3429f0ad7d4e3e4d8a38a0896a5e3649.mp4'
    assert extracted_info['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:44:08.208063
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# ex, the first argument for all classes

	# the second argument, the url
	# the url should be in the format: example: https://hitrecord.org/records/2954362
	url = "https://hitrecord.org/records/2954362"

	# the third argument, the ie is a tuple of (class, ie_name)
	# the class is the class_name of the class that you want to test
	# the ie_name is the name of the class, not the file name

	assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)' 
	assert HitRecordIE.__name__ == 'HitRecord'

# Generated at 2022-06-24 12:44:10.851225
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('test')
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:12.371037
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except:
        assert False

# Generated at 2022-06-24 12:44:16.308092
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'

# Test function to check if the function works

# Generated at 2022-06-24 12:44:26.580612
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_info = HitRecordIE()
    test_item = hitrecord_info._TEST
    download_data = hitrecord_info._download_json(
        'https://hitrecord.org/api/web/records/%s' % hitrecord_info._match_id(test_item['url']), '2954362')

# Generated at 2022-06-24 12:44:32.778570
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.suitable("http://hitrecord.org/records/2954362") == True
    assert HitRecordIE.suitable("http://www.hitrecord.org/records/2954362") == True
    assert HitRecordIE.suitable("https://hitrecord.org/records/2954362") == True
    assert HitRecordIE.suitable("https://www.hitrecord.org/records/2954362") == True
    assert HitRecordIE.suitable("https://www.hitrecord.org/records/2954362?foo=bar") == True
    assert HitRecordIE.suitable("http://www.hitrecord.org/records/1") == True
    assert HitRecordIE.suitable("http://www.hitrecord.org/records/4294967296") == True
    assert HitRecord

# Generated at 2022-06-24 12:44:36.166927
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE({})
    assert ie.ie_key() == 'Hitrecord'
    assert ie.ie_key() in ie.json_ld(
        'https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:44:39.063587
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord_ie = HitRecordIE()
    assert hitRecord_ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'



# Generated at 2022-06-24 12:44:42.214289
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._match_id('https://hitrecord.org/records/2954362')
    ie._real_extract('https://hitrecord.org/records/2954362')

test_HitRecordIE()

# Generated at 2022-06-24 12:44:45.525692
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:47.972394
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    print('Test HitRecordIE.__init__')
    print('Test HitRecordIE._real_extract')

# Generated at 2022-06-24 12:44:49.953608
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'

# Generated at 2022-06-24 12:44:53.737620
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'
    aie = ie.get_info_extractor(HitRecordIE._VALID_URL)
    assert isinstance(aie, HitRecordIE)

# Generated at 2022-06-24 12:44:54.829216
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:44:56.303719
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE is not None

# Generated at 2022-06-24 12:44:57.050875
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:45:00.321019
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE("test")
    assert hitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:09.397805
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test for proper instantiation of class HitRecordIE
    ie = HitRecordIE('http://www.hitrecord.org/records/2954362')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:19.393703
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    video_info = HitRecordIE()._real_extract(url)

# Generated at 2022-06-24 12:45:21.378559
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('www.hitrecord.org')
    assert ie.name == 'hitrecord'

# Generated at 2022-06-24 12:45:23.359610
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.HitRecordIE.suite()

# Generated at 2022-06-24 12:45:24.132387
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL

# Generated at 2022-06-24 12:45:26.005527
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:45:27.400187
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	obj = HitRecordIE(object)
	assert obj.valid_url(HitRecordIE._TEST['url'])

# Generated at 2022-06-24 12:45:32.550694
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:45:34.290265
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Test the constructor of class HitRecordIE"""
    HR = HitRecordIE()
    assert type(HR) == HitRecordIE

# Generated at 2022-06-24 12:45:35.986464
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:45:38.053700
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    unit_test = HitRecordIE()
    unit_test._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:45:43.031174
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.token == "a8d9a3c9fa3f27be0507e538ea93e7baa1f1b1a7"
    assert ie.base_url == "https://hitrecord.org/api/web/records/"


# Generated at 2022-06-24 12:45:45.146425
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Exercise HitRecordIE constructor
    HitRecordIE()


# Generated at 2022-06-24 12:45:55.141990
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    url = 'https://hitrecord.org/records/2954362'
    video_id = '2954362'
    assert HitRecordIE._match_id(url) == video_id
    video_id_invalid = '12345678'
    assert HitRecordIE._match_id(video_id_invalid) == None
    assert HitRecordIE._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert HitRecordIE._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-24 12:45:56.600634
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:45:57.971979
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info = HitRecordIE()._get_info_extractor()
    assert info is not None


# Generated at 2022-06-24 12:45:59.509866
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:46:00.769957
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    #Constructor for class HitRecordIE
    HitRecordIE()

# Generated at 2022-06-24 12:46:06.538041
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE().suitable('https://hitrecord.org/records/2954362')
    assert not HitRecordIE().suitable('https://www.hitrecord.org/records/2954362')
    assert not HitRecordIE().suitable('https://hitrecord.org/records')
    assert not HitRecordIE().suitable('https://hitrecord.org')

# Generated at 2022-06-24 12:46:14.346079
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("HitRecordIE", {"url": "https://hitrecord.org/records/2954362"})
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST["url"] == "https://hitrecord.org/records/2954362"
    assert ie._TEST["md5"] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST["info_dict"]["id"] == "2954362"
    assert ie._TEST["info_dict"]["ext"] == "mp4"

# Generated at 2022-06-24 12:46:22.339874
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:46:24.458914
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('hitrecord.org', 'https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:46:25.330684
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:46:34.873498
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    hit_record_ie = HitRecordIE()

    assert hit_record_ie is not None
    assert hit_record_ie.ie_key() == 'HitRecord'
    assert hit_record_ie.ie_name() == 'HitRecord'
    assert hit_record_ie.ie_description() == 'HitRecord'
    assert hit_record_ie.ie_version() != ''
    assert hit_record_ie.is_suitable(None)
    assert hit_record_ie.is_suitable('https://hitrecord.org/records/2954362')
    assert not hit_record_ie.is_suitable('https://hitrecord.org/records/2954362', 'test_video')

# Generated at 2022-06-24 12:46:36.115328
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    h = HitRecordIE()
    assert h.ie_key() == 'hitrecord'
    assert h.ie_name() == 'Hitrecord'

# Generated at 2022-06-24 12:46:38.781752
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """ Tests for constructor of HitRecordIE """
    url = 'https://hitrecord.org/records/2954362'
    assert HitRecordIE._match_id(HitRecordIE._VALID_URL, url) == "2954362"


# Generated at 2022-06-24 12:46:42.299202
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert (ie.IE_NAME == 'hitrecord')
    assert (ie.IE_DESC == 'HITRECORD')
    assert (ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-24 12:46:45.193724
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE("https://hitrecord.org/records/2954362")
    assert instance.urls == ["https://hitrecord.org/records/2954362"]
    assert instance.video_id == "2954362"

# Generated at 2022-06-24 12:46:47.260282
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("http://hitrecord.org")._download_json("https://hitrecord.org/api/web/records/2954362", "2954362")

# Generated at 2022-06-24 12:46:58.294800
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:46:59.626473
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE()


# Generated at 2022-06-24 12:47:01.465515
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:47:11.467311
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie.IE_NAME == 'hitrecord'
    
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'