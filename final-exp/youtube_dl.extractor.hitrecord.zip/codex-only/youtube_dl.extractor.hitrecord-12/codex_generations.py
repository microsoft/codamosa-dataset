

# Generated at 2022-06-24 12:37:06.812046
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE()

# Generated at 2022-06-24 12:37:07.338646
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-24 12:37:09.811095
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(0)
    assert ie.test == False

# Generated at 2022-06-24 12:37:16.806877
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    TestHitRecordIE = HitRecordIE()
    assert TestHitRecordIE.IE_NAME == "hitrecord"
    assert TestHitRecordIE.VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"
    # Check if the class that called this constructor is equal to 
    # the class of which constructed the object, 
    # to check if the object is an instance of the class
    assert type(TestHitRecordIE) == HitRecordIE

# Generated at 2022-06-24 12:37:24.157201
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie.url == 'https://hitrecord.org/records/2954362'
    assert ie.vali_url == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:37:25.900126
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie is not None



# Generated at 2022-06-24 12:37:26.650496
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:37:27.402489
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE()

# Generated at 2022-06-24 12:37:31.279299
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test URL
    url = 'https://hitrecord.org/records/2954362'
    ext = HitRecordIE(HitRecordIE._create_get_url(url))
    assert url == ext.url

# Generated at 2022-06-24 12:37:33.260680
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video_url = 'https://hitrecord.org/records/2954362'
    HitRecordIE().extract(video_url)

# Generated at 2022-06-24 12:37:42.432010
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-24 12:37:42.925500
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE

# Generated at 2022-06-24 12:37:43.447900
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:37:44.902959
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from .HitRecordIE import HitRecordIE;
    assert HitRecordIE("")

# Generated at 2022-06-24 12:37:46.197566
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    print(ie.working())

# Generated at 2022-06-24 12:37:47.036460
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:37:48.448676
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Test the HitRecordIE constructor
    """
    assert HitRecordIE

# Generated at 2022-06-24 12:37:50.813714
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Unit test for constructor of class HitRecordIE
    # Instantiate HitRecordIE
    HitRecordIE()

# Generated at 2022-06-24 12:37:52.263549
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # This should work with or without video_id
    ie.extract("https://hitrecord.org/records/2954362")
    ie.extract("https://hitrecord.org/records/")

# Generated at 2022-06-24 12:37:57.802564
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE();
    assert ie.suitable('https://hitrecord.org/records/2954362') == True
    assert ie.suitable('https://hitrecord.org/records/295436') == False
    assert ie.suitable('https://hitrecord.org/records/295436234234') == True
    assert ie.suitable('https://hitrecord.org/records/29543623423') == False

# Generated at 2022-06-24 12:38:02.737813
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    IE = HitRecordIE('https://www.hitrecord.org/records/2954362')
    assert IE is not None
    assert IE.__class__ == HitRecordIE
    assert IE.valide_url == 'https://www.hitrecord.org/records/2954362'

# Generated at 2022-06-24 12:38:06.662280
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Unit test for constructor of class HitRecordIE
    """
    ie = HitRecordIE()
    ie = HitRecordIE('http://www.hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:38:08.712265
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:10.412505
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Test instantiation of class HitRecordIE.
    """
    ie = HitRecordIE()
    ie_info = ie.IE_NAME + " " + ie.IE_DESC

    # If you don't pass in argument in instantiation, it is

# Generated at 2022-06-24 12:38:14.610038
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        import pytest
    except:
        pass

    url = 'https://hitrecord.org/records/2954362'
    module_name = 'hitrecord'
    mod1 = __import__(module_name)  # import module
    all_the_modules = mod1.getmodules(module_name)

    # Get the module object
    mod2 = getattr(mod1, module_name)

    # Get the class
    mod3 = getattr(mod2, 'HitRecordIE')

    # Create instance
    instance = mod3()

    # Test it
    assert instance._match_id(url) == "2954362"
    assert 'https://hitrecord.org/api/web/records/' in instance._download_json(url, "2954362")

# Generated at 2022-06-24 12:38:17.422744
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL is not None
    assert ie._TEST is not None

# Generated at 2022-06-24 12:38:19.121660
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:38:20.971928
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:38:31.187248
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert HitRecordIE()._TEST['id'] == '2954362'
    assert HitRecordIE()._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert HitRecordIE()._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-24 12:38:34.296964
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert (HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')


# Generated at 2022-06-24 12:38:35.191712
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:36.426947
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._download_json
    ie._real_extract

# Generated at 2022-06-24 12:38:40.983550
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	obj = HitRecordIE()
	obj.id = '1'
	obj.url = 'http://www.hitrecord.org/records/123'
	obj._match_id('http://www.hitrecord.org/records/123')
	obj._real_extract('http://www.hitrecord.org/records/123')

# Generated at 2022-06-24 12:38:42.282602
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    constructor = HitRecordIE(null_out())
    assert constructor != None


# Generated at 2022-06-24 12:38:49.081325
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # First make sure the unit test is working
    assert(3 == 3)
    # Now run the constructor (hopefully)
    ie = HitRecordIE()
    # Now compare the two strings to make sure they have been set
    assert(ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')
    # Now test the md5 of the test that has been run
    assert(ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71')

# Generated at 2022-06-24 12:38:58.454954
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    IE = HitRecordIE()
    assert IE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:39:08.488778
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # `from . import` is used to force test to fail if one of the modules is not available.
    from . import common, utils  # pylint: disable=redefined-outer-name
    # It is necessary to instantiate classes with parameters before using them.
    common_instance = common.InfoExtractor()
    utils_instance = utils.ExtractorError()
    common_instance = None
    utils_instance = None
    # test for HitRecordIE class
    HitRecordIE._download_json(None, None)  # pylint: disable=protected-access
    HitRecordIE._real_extract(None, None)  # pylint: disable=protected-access
    HitRecordIE._match_id(None, None)  # pylint: disable=protected-access

# Generated at 2022-06-24 12:39:14.354016
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    class_ = HitRecordIE()
    assert_equal(class_.SUFFIXES, () )
    assert_true(class_.IE_NAME, 'HitRecord')
    assert_true(class_.IE_DESC, 'HitRecord')
    assert_equal(class_.VALID_URL, HitRecordIE._VALID_URL)
    assert_equal(class_._TEST, HitRecordIE._TEST)

# Generated at 2022-06-24 12:39:16.045563
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    global htRecordIE

    htRecordIE = HitRecordIE()

# Generated at 2022-06-24 12:39:17.934818
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert re.search(ie._VALID_URL,
                     "https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:39:19.558348
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:39:21.122335
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    '''
    Unit test for constructor of class HitRecordIE.
    '''
    url = 'https://hitrecord.org/records/2954362'
    ie = HitRecordIE()
    return ie(url)

# Generated at 2022-06-24 12:39:21.734652
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:22.979886
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_obj = HitRecordIE()
    assert test_obj != None


# Generated at 2022-06-24 12:39:24.183996
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ies = HitRecordIE()
    assert ies.extractor == HitRecordIE

# Generated at 2022-06-24 12:39:25.313746
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	hitrecordIE = HitRecordIE()
	assert(hitrecordIE != None)

# Generated at 2022-06-24 12:39:29.513894
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(HitRecordIE._VALID_URL)
    assert ie._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-24 12:39:31.513596
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:39:33.444167
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    tester = HitRecordIE()
    assert tester is not None


# Generated at 2022-06-24 12:39:33.811928
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE()

# Generated at 2022-06-24 12:39:34.346721
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:35.640217
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	#The following line is an example
	print(HitRecordIE._VALID_URL)
test_HitRecordIE()

# Generated at 2022-06-24 12:39:37.712264
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'

# Generated at 2022-06-24 12:39:39.562157
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.match_url('http://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:39:48.195616
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    #test _VALID_URL properties
    assert ie._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"

    #test _TEST properties

# Generated at 2022-06-24 12:39:51.039257
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    d = HitRecordIE()
    assert d._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:39:52.001872
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert isinstance( HitRecordIE, object )

# Generated at 2022-06-24 12:39:56.618301
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"
    assert ie.ie_key() == "HitRecord"
    assert ie.video_id == "2954362"

# Generated at 2022-06-24 12:40:04.007442
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ie = HitRecordIE()
	url = 'https://hitrecord.org/records/1581597'
	mobj = ie._url_re.match(url)
	assert(mobj.group('id') == '1581597')
	assert(ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-24 12:40:04.562495
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:40:05.245209
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:40:06.555638
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-24 12:40:07.606109
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hrIE = HitRecordIE()

# Generated at 2022-06-24 12:40:09.028431
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:40:10.366973
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:40:12.974869
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_HitRecordIE = HitRecordIE()
    # test_HitRecordIE.test()
    test_HitRecordIE.download('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:40:22.829572
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"
    assert HitRecordIE._TEST['url'] == "https://hitrecord.org/records/2954362"
    assert HitRecordIE._TEST['md5'] == "fe1cdc2023bce0bbb95c39c57426aa71"
    assert HitRecordIE._TEST['info_dict']['id'] == "2954362"
    assert HitRecordIE._TEST['info_dict']['ext'] == "mp4"
    assert HitRecordIE._TEST['info_dict']['title'] == "A Very Different World (HITRECORD x ACLU)"

# Generated at 2022-06-24 12:40:30.651417
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:40:32.221221
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:40:34.741318
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HRIE = HitRecordIE()
    assert HRIE.get_url_re() == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert HRIE.get_url_re() == HitRecordIE._VALID_URL


# Generated at 2022-06-24 12:40:37.950078
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-24 12:40:43.923085
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    from .common import InfoExtractor
    from .generic import GenericIE

    info_extractor = InfoExtractor()
    generic_ie = GenericIE(info_extractor)
    hitrecord_ie = HitRecordIE(info_extractor)

    assert isinstance(hitrecord_ie, HitRecordIE)
    assert isinstance(hitrecord_ie, GenericIE)
    assert isinstance(hitrecord_ie, InfoExtractor)

# Generated at 2022-06-24 12:40:52.142429
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    x = HitRecordIE()
    assert x._VALID_URL == 'https://hitrecord.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:54.364634
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Unit test for constructor of class HitRecordIE
    """

    test_instance = HitRecordIE()
    assert test_instance is not None

# Generated at 2022-06-24 12:40:57.364339
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE.HitRecordIE(HitRecordIE.HitRecordIE.supported_ie)
    assert ie.succeeded() == True

# Generated at 2022-06-24 12:40:59.908676
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:41:06.255053
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Parameters which should be provided to the constructor of HitRecordIE
    url = "https://hitrecord.org/records/2954362"
    ie = HitRecordIE(url)
    # Test if url was correctly provided as a parameter to the constructor of HitRecordIE
    assert ie._VALID_URL == url

    # Test if video_id was not incorrectly initialized
    assert ie._video_id is None

    # Test if _TEST dictionary was correctly initialized
    url = ie._TEST['url']
    ie = HitRecordIE(url)
    assert ie._TEST['url'] == url
    # Test if other fields of _TEST dictionary were correctly initialized
    assert ie._TEST['md5'] is not None
    assert ie._TEST['info_dict'] is not None

# Generated at 2022-06-24 12:41:08.107998
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE("https://www.hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:41:09.124411
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert "HitRecordIE" in globals()

# Generated at 2022-06-24 12:41:19.183959
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie_test = ie._TEST
    url = ie_test['url']
    # Create a dictionary to save information of a video

# Generated at 2022-06-24 12:41:19.769024
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:20.383508
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE is not None

# Generated at 2022-06-24 12:41:26.198062
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit = HitRecordIE()
    assert hit._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:41:27.640185
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE == HitRecordIE(HitRecordIE.ie_key())

# Generated at 2022-06-24 12:41:35.585877
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    x = HitRecordIE()
    # Test for video URL
    video_url = 'https://hitrecord.org/records/2954362'
    x.assertTrue(x._VALID_URL in video_url)

    # Test for video ID
    video_id = x._match_id(video_url)
    x.assertEqual (video_id, '2954362')

    # Test for URL
    url = x._real_extract(video_url)
    x.assertTrue(isinstance(url, dict))

# Generated at 2022-06-24 12:41:37.916535
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:41:38.924054
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE()
    assert hitRecord != None

# Generated at 2022-06-24 12:41:41.814367
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Function to test the HitRecordIE class.
    """

    # Creating an instance of class HitRecordIE to test.
    ie = HitRecordIE()

    # Performing a download by calling the appropriate method.
    ie.extract()

# Generated at 2022-06-24 12:41:48.376458
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('http://www.hitrecord.org/records/2954362')
    assert ie.suitable == True
    assert ie.try_extract == True

# Generated at 2022-06-24 12:41:58.040797
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test the above unit tests if they are correctly coded
    import unittest
    import urllib.request
    import urllib
    class TestIE(unittest.TestCase):
        def test_HitRecordIE(self):
            url = 'https://hitrecord.org/records/2954362'
            self.assertEqual(urllib.parse.urlparse(url)[0:2], ('https', 'hitrecord.org'))

            url = 'http://www.hitrecord.org/records/2954362'
            self.assertEqual(urllib.parse.urlparse(url)[0:2], ('http', 'www.hitrecord.org'))
            print("HitRecordIE test finished")

    unittest.main()

# Generated at 2022-06-24 12:41:59.797547
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:42:03.181451
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:42:04.820694
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except NameError:
        print("HitRecordIE not found")
    else:
        print("HitRecordIE found")


# Generated at 2022-06-24 12:42:05.431893
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:09.392101
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # pylint: disable=function-redefined
    def HitRecordIE_constructor_test(self):
        """Call constructor of HitRecordIE"""
        return HitRecordIE(self)
    return HitRecordIE_constructor_test


# Generated at 2022-06-24 12:42:10.582977
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:10.928792
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:16.436415
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    e = HitRecordIE()
    assert e.suitable('https://hitrecord.org/records/2954362')
    assert e.IE_NAME == 'hitrecord:record'
    assert e._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:42:17.779730
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE("", "")
    assert obj is not None

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:42:18.333911
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:18.807767
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:21.239485
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:42:21.657351
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:31.754905
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:42:34.561025
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert ie.IE_NAME == 'hitrecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:42:45.511050
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test 1
    ie = HitRecordIE('http://fake.url1')
    assert ie.url_result[0] == 'http://fake.url1'
    assert ie.valid_url == True
    assert ie.url == 'http://fake.url1'
    assert ie.url_result[1] == 'http://fake.url1'
    assert ie._match_id('http://fake.url1') == 'http://fake.url1'

    # Test 2
    ie = HitRecordIE('http://fake.url2')
    assert ie.valid_url == False
    assert ie.url == 'http://fake.url2'

# Test 1
# ie = IE_Base('http://fake.url1')
# oe = HitRecordIE(ie)
# oe.valid_url == True
# oe

# Generated at 2022-06-24 12:42:53.610140
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    # First, check that the url is matched by the HitRecordIE regex
    url = "https://hitrecord.org/records/2954362"
    ie = HitRecordIE(HitRecordIE.ie_key())
    assert ie.suitable(url)

    # Second, extract info from the url, and check that the returned fields
    # are not empty
    info = ie.extract(url)
    assert info['id']
    assert info['url']
    assert info['title']
    assert info['description']
    assert info['duration']
    assert info['timestamp']
    assert info['uploader']
    assert info['uploader_id']
    assert info['view_count']
    assert info['like_count']
    assert info['comment_count']
    assert info['tags']

# Generated at 2022-06-24 12:43:02.093588
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_object = HitRecordIE()

    assert test_object._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:43:03.561482
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-24 12:43:04.545394
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrec_ie = HitRecordIE()

# Generated at 2022-06-24 12:43:05.928977
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:43:08.099298
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'hitrecord'

# Generated at 2022-06-24 12:43:09.417688
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:43:10.674665
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    
    HitRecordIE()

# Generated at 2022-06-24 12:43:19.395300
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    # test for the id match function
    assert(ie._match_id('https://hitrecord.org/records/2954362') == '2954362')
    assert(ie._match_id('https://hitrecord.org/records/2954362') != '12345')
    assert(ie._match_id('https://hitrecord.org/records/2954362') != '295436')
    assert(ie._match_id('https://hitrecord.org/records/2954362') != '29543620')

    # test for the test data with real data
    assert(ie._TEST['info_dict']['view_count'] != 2)

    # test for the real_extract function

# Generated at 2022-06-24 12:43:20.206627
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:23.663783
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE(HitRecordIE._VALID_URL)
    except Exception:  # pylint:disable=broad-except
        assert False, 'Object of class HitRecordIE could not be instantiated. Is unit test failing?'

# Generated at 2022-06-24 12:43:25.271728
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert type(HitRecordIE()) is HitRecordIE

# Generated at 2022-06-24 12:43:28.359196
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = "https://hitrecord.org/records/2954362"
    ie = HitRecordIE(url)
    expect = "HitRecordIE"
    assert ie.get_IE_Name() == expect

# Generated at 2022-06-24 12:43:36.412705
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

	# Instantiation of class HitRecordIE
	# success case
	try:
		hit = HitRecordIE('https://hitrecord.org/records/2954362')
	except Exception as e:
		hit = None
		print(e)
	assert hit is not None

	# failure case. url should be of pattern "http(s)://(www.)?hitrecord.org/records/<id>"
	try:
		hit = HitRecordIE('https://hitrecord.org/records/295436288')
	except Exception as e:
		hit = None
		print(e)
	assert hit is None

	# failure case. url should be of pattern "http(s)://(www.)?hitrecord.org/records/<id>"

# Generated at 2022-06-24 12:43:38.300988
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:43:40.366336
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test for the constructor of HitRecordIE
    hitrecordIE = HitRecordIE()
    assert hitrecordIE != None


# Generated at 2022-06-24 12:43:43.152358
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    exampleUrl = 'https://hitrecord.org/records/2954362'
    url = HitRecordIE.ie_key_id(exampleUrl)
    assert(url)
    assert(url == '2954362')

# Generated at 2022-06-24 12:43:44.312011
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:45.225642
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE.test()

# Generated at 2022-06-24 12:43:53.074925
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    expected = {
            'id': '2954362',
            'url': 'https://hitrecord.org/api/web/record_files/video/2954362/2954362_848.mp4',
            'title': 'A Very Different World',
            'description': 'We live in a very different world.',
            'duration': 139.327,
            'timestamp': 1471557582,
            'upload_date': '20160818',
            'uploader': 'Zuzi.C12',
            'uploader_id': '362811',
            'view_count': 2,
            'like_count': 2,
            'comment_count': 0,
            'tags': ['test'],
            }
    test = HitRecordIE()
    test.to_screen("Testing constructor")
    actual = test

# Generated at 2022-06-24 12:43:54.647345
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('http://www.hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:44:02.472574
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    '''
    This is just a sanity check, to see if the constructor is working.
    '''
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert(isinstance(ie, HitRecordIE))

    # Unit tests for youtube-dl
    # Executing this file while in the youtube-dl root directory, i.e.
    # \youtube-dl-master, will run this unit test.
    # See https://github.com/rg3/youtube-dl/blob/master/README.md#running-unit-tests
    # for more information.

###############################################################################

# Generated at 2022-06-24 12:44:03.959116
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract(HitRecordIE._TEST['url'])

# Generated at 2022-06-24 12:44:13.749105
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL.findall('https://hitrecord.org/records/2954362')
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:44:14.307954
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:44:20.692460
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# Start test
	print("Testing starting, plesase wait...")

	# Create test for the constructor
	print("Create test for the constructor >>>")
	assert HitRecordIE._VALID_URL ==r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
	print("DONE")

	# Create test for the main function
	print("Create test for the main function >>>")
	assert HitRecordIE._TEST['url'] == 'https://hitrecord.org/records/2954362'
	assert HitRecordIE._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
	print("DONE")

	# Create test for the _real_extract function

# Generated at 2022-06-24 12:44:24.454959
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    _testurl = 'http://hitrecord.org/records/2954362'

    HitRecordIE().suitable(_testurl)

    HitRecordIE()._real_extract(_testurl)

# Generated at 2022-06-24 12:44:28.646316
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # url = 'https://hitrecord.org/records/2954362'
    # id = HitRecordIE._match_id(url)
    # assert id == '2954362'
    pass

# Generated at 2022-06-24 12:44:30.497664
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._match_id('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:44:39.970541
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hie = HitRecordIE()
    assert hie.ie_key() == 'hitrecord'
    assert hie.ie_name() == 'HitRecord'
    assert hie.ie_dir() is None
    assert hie._VALID_URL == 'https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)'
    # Test _info_extract
    print('Testing method info_extract in HitRecordIE')
    hie = HitRecordIE()
    url = 'https://hitrecord.org/records/2954362'
    info_dict = hie._real_extract(url)

# Generated at 2022-06-24 12:44:50.157039
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:01.825167
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, HitRecordIE)
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:02.775552
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HitRecordIE(hitrecordOrg())

# Generated at 2022-06-24 12:45:03.549236
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:45:11.753329
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:21.392327
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:23.245010
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
        assert True
    except BaseException:
        assert False


# Generated at 2022-06-24 12:45:24.031552
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:45:26.730430
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:28.562777
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test if HitRecordIE can be instantiated
    HitRecordIE()
    
    
if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:45:31.656971
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hie = HitRecordIE();
    return hie._download_json('https://hitrecord.org/api/web/records/2954362', '2954362')


# Generated at 2022-06-24 12:45:35.569033
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    ie = HitRecordIE('https://hitrecord.org/records/2954362')

    assert ie.IE_NAME == 'HitRecord'

    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:36.844863
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:45:38.487623
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('HitRecordIE', 'HitRecord', 'HitRecord')
    assert ie

# Generated at 2022-06-24 12:45:42.090769
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:45:43.697479
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:45:45.375244
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-24 12:45:49.548972
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    vid = HitRecordIE('http://www.hitrecord.org/records/2954362')
    assert vid.name == 'hitrecord'
    assert vid._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:51.215049
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract(HitRecordIE._TEST['url'])

# Generated at 2022-06-24 12:45:52.962643
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE({})
    assert isinstance(ie, HitRecordIE)

# Generated at 2022-06-24 12:45:53.903902
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Unit test: instantiate HitRecordIE
    HitRecordIE()

# Generated at 2022-06-24 12:45:55.484467
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:45:55.988233
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:45:56.475505
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:45:56.960353
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE

# Generated at 2022-06-24 12:46:07.380556
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
   ie = HitRecordIE()
   ie.suitable('http://www.hitrecord.org/records/2954362')
   ie.get_urls('http://www.hitrecord.org/records/2954362')
   ie.extract({'url': 'http://www.hitrecord.org/records/2954362'})
   ie.get_video_info({'url': 'http://www.hitrecord.org/records/2954362'})
   ie.get_video_info_url('http://www.hitrecord.org/records/2954362')
   ie.get_video_url({'url': 'http://www.hitrecord.org/records/2954362'})
   ie.get_video_id('http://www.hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:46:08.709980
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-24 12:46:09.982304
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # test instantiation
    assert HitRecordIE is not None


# Generated at 2022-06-24 12:46:10.709005
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:12.818583
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    _HitRecordIE = HitRecordIE()
    HitRecordIE._VALID_URL
    HitRecordIE._TEST

# Generated at 2022-06-24 12:46:14.770121
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    
    IE_name = 'hitrecord'
    ie = HitRecordIE(IE_name)

    assert ie.ie_key() == IE_name

# Generated at 2022-06-24 12:46:16.676554
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:46:19.459614
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hri = HitRecordIE("https://hitrecord.org/records/2954362")
    assert isinstance(hri, HitRecordIE), "Constructor of class HitRecordIE isn't working"


# Generated at 2022-06-24 12:46:20.029197
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:46:29.277250
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE()
    # real_extract method will be tested in next test function
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:46:29.819969
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:30.393112
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE();

# Generated at 2022-06-24 12:46:31.697121
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIEObject = HitRecordIE()
    assert isinstance(HitRecordIEObject, HitRecordIE)

# Generated at 2022-06-24 12:46:40.955468
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\. org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:46:41.483010
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-24 12:46:43.383311
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, InfoExtractor) and ie.ie_key() == 'HitRecord'

# Generated at 2022-06-24 12:46:46.214594
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.suitable('https://hitrecord.org/records/2954362') == True
    assert HitRecordIE.suitable('https://hitrecord.org/movies/2954362') == False


# Generated at 2022-06-24 12:46:47.297211
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_case = HitRecordIE()
    print(test_case)


# Generated at 2022-06-24 12:46:48.935146
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:46:51.530014
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE()
    assert info_extractor is not None
    print('Unit test for HitRecordIE is successful!')

# Generated at 2022-06-24 12:46:53.492191
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(display_id=None, url=None, params=None)

# Generated at 2022-06-24 12:46:57.490448
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._VALID_URL = HitRecordIE._VALID_URL
    ie.url = HitRecordIE._TEST.get('url')
    ie.info_dict = HitRecordIE._TEST.get('info_dict')


# Generated at 2022-06-24 12:47:00.101754
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:47:01.745531
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:47:02.365487
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:47:05.029963
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	print("in test HitRecordIE")
	assert HitRecordIE(HitRecordIE._VALID_URL) is not None

# Generated at 2022-06-24 12:47:05.997933
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(HitRecordIE.ie_key())