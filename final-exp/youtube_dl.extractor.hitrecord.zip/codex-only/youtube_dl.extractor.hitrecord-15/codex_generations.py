

# Generated at 2022-06-24 12:37:02.229620
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    d = HitRecordIE()
    pass

# Generated at 2022-06-24 12:37:02.780459
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None, {})

# Generated at 2022-06-24 12:37:03.383685
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-24 12:37:04.706491
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:37:06.775685
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HitRecordIE("https://hitrecord.org/records/2954362");

# Generated at 2022-06-24 12:37:08.749939
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert hasattr(ie, "HitRecordIE")

# Generated at 2022-06-24 12:37:10.196559
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    p = HitRecordIE()
    assert p

# Generated at 2022-06-24 12:37:11.634532
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:37:13.418067
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None, None)
    assert ie.ie_key() == "HitRecordIE"

# Generated at 2022-06-24 12:37:15.144438
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """constructor of class HitRecordIE
    """
    result = HitRecordIE()
    assert result

# Generated at 2022-06-24 12:37:15.818082
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:37:17.461144
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:37:18.956674
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

if __name__ == "__main__":
    test_HitRecordIE()

# Generated at 2022-06-24 12:37:19.459140
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE

# Generated at 2022-06-24 12:37:21.021094
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hirrecord.org/records/2954362')

# Generated at 2022-06-24 12:37:22.372880
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-24 12:37:23.993594
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  assert HitRecordIE._VALID_URL.find('hitrecord') != -1

# Generated at 2022-06-24 12:37:32.373000
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-24 12:37:33.260636
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:37:34.866903
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video_id = '2954362'
    HitRecordIE(video_id)

# Generated at 2022-06-24 12:37:43.447964
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    assert instance._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:37:54.487557
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert_equal(ie.IE_NAME, 'hitrecord')
    assert_equal(ie.IE_DESC, 'HitRecord.org')
    assert_equal(ie._VALID_URL, r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-24 12:37:55.166303
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    res = HitRecordIE()
    assert res

# Generated at 2022-06-24 12:37:57.224917
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    print(instance.extract('https://hitrecord.org/records/2954362'))


# Generated at 2022-06-24 12:37:58.480901
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Constructor of HitRecordIE class
    assert HitRecordIE is not None

# Generated at 2022-06-24 12:38:00.976281
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try_get(None, lambda x: x['user.username'])


# Generated at 2022-06-24 12:38:11.819812
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    expectedIE = HitRecordIE('hitrecord', 'https://www.hitrecord.org/records/2954362')
    assert expectedIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert expectedIE._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert expectedIE._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-24 12:38:12.345950
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:14.445465
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'


# Generated at 2022-06-24 12:38:17.198128
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Constructor without any arguments
    HitRecordIE()
    # Constructor with argument
    HitRecordIE(info_dict)

# Generated at 2022-06-24 12:38:19.366040
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE();
    print(hitRecord._VALID_URL)
    print(hitRecord._TEST)

# Generated at 2022-06-24 12:38:21.984877
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Basic test to check that the constructor of HitRecordIE class
    doesn't throw any exceptions
    """
    ie = HitRecordIE()



# Generated at 2022-06-24 12:38:22.599954
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:32.421021
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-24 12:38:34.168951
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:38:36.795997
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    v = HitRecordIE()
    assert v._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:39.414546
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:47.905713
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # check constructor of class HitRecordIE
    ie = HitRecordIE('http://hitrecord.org/records/2954362')
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:49.124614
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    aa = HitRecordIE()

# Generated at 2022-06-24 12:38:50.722713
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Unit test for HitRecordIE"""
    ie = HitRecordIE
    print(ie)

# Generated at 2022-06-24 12:38:51.311127
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:53.697734
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord_ie = HitRecordIE()
    assert hasattr(hitRecord_ie, '_VALID_URL')
    assert hasattr(hitRecord_ie, '_TEST')

# Generated at 2022-06-24 12:38:54.700200
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:38:57.606770
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test regular constructor
    ie = HitRecordIE('hitrecord', False)
    # Test with regexp
    ie = HitRecordIE(HitRecordIE._VALID_URL, False)
    assert ie.IE_NAME == 'hitrecord'

# Generated at 2022-06-24 12:38:58.557265
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('id1')

# Generated at 2022-06-24 12:39:02.153927
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	test_class = HitRecordIE("test")
	assert test_class.extractor_key == "hitrecord"
	assert test_class.ie_key =="Youtube"

# Generated at 2022-06-24 12:39:03.133689
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie

# Generated at 2022-06-24 12:39:05.164822
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_case = HitRecordIE()
    test_case.test('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:39:06.155195
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:07.919747
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	Video = HitRecordIE()
	assert Video.__class__.__name__ == "HitRecordIE"

# Generated at 2022-06-24 12:39:10.327279
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hrie = HitRecordIE(hitrecordIE,HitRecordIE.ie_key())
    return hrie

# Generated at 2022-06-24 12:39:17.977630
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # If the test fails, the assert line will be outputted
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-24 12:39:20.673047
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('www.hitrecord.org')
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:39:28.508738
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    x = HitRecordIE()
    assert x._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:39:32.194131
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie.VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:39:33.341679
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_ie = HitRecordIE()
    assert hit_record_ie.test_url('', 'test_HitRecordIE')

# Generated at 2022-06-24 12:39:33.883546
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:35.940994
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE({})
    except Exception as e:
        raise AssertionError("Unexpected error in HitRecordIE constructor: " + str(e))



# Generated at 2022-06-24 12:39:36.616442
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:38.893475
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:39:40.942723
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # create an instance of HitRecordIE
    ie = HitRecordIE()
    # test for using constructor to get HitRecordIE
    assert isinstance(ie, HitRecordIE)

# Generated at 2022-06-24 12:39:48.878906
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	video_id = '2954362'
	video = HitRecordIE()._download_json(
			   'https://hitrecord.org/api/web/records/%s' % video_id, video_id)

# Generated at 2022-06-24 12:39:50.393309
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie


# Generated at 2022-06-24 12:39:50.996668
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:52.677103
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE().extract('http://hitrecord.org/records/2954362')


# Generated at 2022-06-24 12:40:00.426185
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE("HitRecordIE")
    print("hitRecordIE: {}".format(hitRecordIE))

    assert hitRecordIE.getUrl() == "https://www.hitrecord.org/records/2954362"
    assert hitRecordIE.getId() == "2954362"
    assert hitRecordIE.getExt() == "mp4"
    assert hitRecordIE.getTitle() == "A Very Different World (HITRECORD x ACLU)"
    assert hitRecordIE.getDuration() == 139.327
    assert hitRecordIE.getUploader() == "Zuzi.C12"
    assert hitRecordIE.getUploaderId() == "362811"

# Generated at 2022-06-24 12:40:04.769849
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:05.400460
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-24 12:40:06.713653
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_HitRecordIE = HitRecordIE()

# Generated at 2022-06-24 12:40:08.179229
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://www.hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:40:09.167275
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)


# Generated at 2022-06-24 12:40:10.136427
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('1')

# Generated at 2022-06-24 12:40:20.196111
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:28.498323
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('http://hitrecord.org/records/2954362')
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:30.177125
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')


# Generated at 2022-06-24 12:40:31.482285
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    assert hitrecord.__class__.__name__ == 'HitRecordIE'

# Generated at 2022-06-24 12:40:33.057572
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL
    assert HitRecordIE()._TEST == HitRecordIE._TEST

# Generated at 2022-06-24 12:40:36.722326
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    h = HitRecordIE()
    assert h._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-24 12:40:40.631220
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    test_url = HitRecordIE._TEST['url']
    test_id = HitRecordIE._TEST['info_dict']['id']
    test_video = ie.url_result(test_url)
    assert test_video.video_id == test_id

# Generated at 2022-06-24 12:40:50.437595
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_dict = HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')
    assert info_dict['id'] == '2954362'
    assert info_dict['url'] == 'https://hitrecord.org/source_data/2954362/mp4/2954362.mp4'
    assert info_dict['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert info_dict['description'] == '<p><span>You are in a very different world.</span></p>\n'
    assert info_dict['uploads'] == 1471557582
    assert info_dict['view_count'] == int
    assert info_dict['like_count'] == int
    assert info_dict['comment_count'] == int
    assert info_dict['tags'] == list

# Generated at 2022-06-24 12:40:52.061653
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-24 12:41:02.266324
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie.SUFFIX == '.org'
    assert ie.IE_NAME == 'hitrecord:record'

# Generated at 2022-06-24 12:41:03.197553
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:41:09.289106
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_video = HitRecordIE()._extract_info('https://hitrecord.org/records/2954362')
    assert isinstance(test_video, dict)
    assert test_video.get('id') == '2954362'
    assert 'A Very Different World (HITRECORD x ACLU)' in test_video.get('title')

# Generated at 2022-06-24 12:41:14.760448
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Check https://hitrecord.org/records/83152, but there are no video tags.
    t = HitRecordIE('https://hitrecord.org/records/2954362')
    assert t.get_entry_by_id('2954362') is not None

    assert t.get_entry_by_id('83152') is not None

    # Check for non-existing video
    assert t.get_entry_by_id('abcdefg') is None

    assert t.get_entry_by_id('900000000') is None

# Generated at 2022-06-24 12:41:24.444537
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	hit = HitRecordIE()
	assert hit._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:41:25.016714
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:36.311618
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_dict = HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')
    assert info_dict['id'] == '2954362'
    assert info_dict['url'] == 'https://s3.amazonaws.com/s3.hitrecord.org/video/production/2954362.mp4'
    assert info_dict['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:41:39.439446
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Unit test for constructor of class HitRecordIE
    # test_HitRecordIE(HitRecordIE)
    # Unit test for HitRecordIE._real_extract(url) method
    HitRecordIE._real_extract(HitRecordIE(), 'https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:41:42.284983
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")

    assert ie.url == 'https://hitrecord.org/records/2954362'
    assert ie.id == '2954362'



# Generated at 2022-06-24 12:41:43.502143
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()


# Generated at 2022-06-24 12:41:45.609001
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._match_id('https://hitrecord.org/records/2954362') == '2954362'

# Generated at 2022-06-24 12:41:47.898719
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE({})
    assert isinstance(hitrecord, HitRecordIE)
    assert hitrecord.ie_key() == 'hitrecord'
    assert hitrecord.ie_name() == 'hitrecord'

# Generated at 2022-06-24 12:41:54.331015
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert hasattr(ie, '_VALID_URL')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert hasattr(ie, '_TEST')
    test = ie._TEST
    assert type(test) is dict
    assert 'url' in test
    assert test['url'] == 'https://hitrecord.org/records/2954362'
    assert 'md5' in test
    assert test['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert 'info_dict' in test
    info_dict = test['info_dict']
    assert 'id' in info_dict

# Generated at 2022-06-24 12:41:55.007238
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("hitrecord.org")

# Generated at 2022-06-24 12:41:55.426354
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:56.256837
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)


# Generated at 2022-06-24 12:41:58.143474
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, HitRecordIE)

# Generated at 2022-06-24 12:42:01.138474
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:42:02.133042
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:05.435459
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE(): 
    username = '3sharps'
    hitRecordIE = HitRecordIE._download_json(
            'https://hitrecord.org/users/%s' % username, username)
    assert hitRecordIE['username'] == '3sharps'

# Generated at 2022-06-24 12:42:07.447880
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	hitrecordIE = HitRecordIE()
	assert hitrecordIE != None

# Generated at 2022-06-24 12:42:07.991130
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:09.887891
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
     hitrecord_ie = HitRecordIE()
     assert isinstance(hitrecord_ie, HitRecordIE)

# Generated at 2022-06-24 12:42:20.368314
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    test_video_url = 'https://hitrecord.org/records/2954362'
    test_video_id = '2954362'

    HitRecordIE(test_video_url)

    HitRecordIE(test_video_url + '#something_else')

    test_class = HitRecordIE(test_video_url)

    test_class_matchID = test_class._match_id(test_video_url)

    assert test_class_matchID == test_video_id

    test_info = test_class._real_extract(test_video_url)

    assert test_info['id'] == test_video_id


# Generated at 2022-06-24 12:42:23.518122
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362', 'HitRecordIE')
    assert ie.name() == 'HitRecordIE'

# Generated at 2022-06-24 12:42:24.921874
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:42:34.374360
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# To run doctest unittests:
#
#     sudo apt-get install -qq python3-doctest
#     python3 -m doctest -v youtube_dl/extractor/hitrecord.py
#
# or
#
#     python3 -m doctest -v $(which youtube-dl)
#
# For verbose output:
#
#     python3 -m doctest -v -o ELLIPSIS -o NORMALIZE_WHITESPACE \
#         youtube_dl/extractor/hitrecord.py
#
# For Emacs users:
#
#     M-x doctest-mode  RET  youtube_dl/extractor/hitrecord.py  RET
#
# To run all doctest unittests:
#
#     sudo apt-get install -qq python3-do

# Generated at 2022-06-24 12:42:37.484795
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test case
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Test case for missing id in url

# Generated at 2022-06-24 12:42:38.080172
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:42:38.643699
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:41.381757
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:42:43.877621
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Test for constructor of class HitRecordIE"""
    test1 = HitRecordIE('')
    assert isinstance(test1, HitRecordIE)



# Generated at 2022-06-24 12:42:48.046226
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    i = HitRecordIE()
    assert(i.IE_NAME == 'hitrecord')
    assert(i.IE_DESC == 'HitRecord')
    assert(i._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-24 12:42:49.276252
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    print("Done")


# Generated at 2022-06-24 12:42:51.828602
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_ie = HitRecordIE()
    s = 'https://www.hitrecord.org/records/2954362'
    assert hitrecord_ie.suitable(s)

# Generated at 2022-06-24 12:42:52.627746
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:54.338969
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    record = HitRecordIE()
    assert record._VALID_URL

# Generated at 2022-06-24 12:43:01.248323
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(HitRecordIE.ie_key())
    assert ie.ie_key() == 'HitRecord'
    assert ie.SUFFIX == 'hitrecord:video'
    assert ie.name == 'HitRecord'
    assert ie._VALID_URL == 'https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-24 12:43:01.892427
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:02.668201
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:04.322980
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:43:07.241581
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.__name__=='HitRecordIE'
    instance = HitRecordIE()
    assert instance.__class__.__name__=='HitRecordIE'

# Generated at 2022-06-24 12:43:07.817788
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:17.532848
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert hitrecord_ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:43:18.617882
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:21.522198
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE(None)

    # Verify that the HitRecordIE constructor was able to successfully
    # create an object
    assert info_extractor is not None


# Generated at 2022-06-24 12:43:24.535232
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    inst = HitRecordIE()
    assert inst._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:43:27.196802
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL is not None
    hitrecord = HitRecordIE()
    assert hitrecord._VALID_URL is not None

# Generated at 2022-06-24 12:43:30.590179
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == "hitrecord"
    assert ie.ie_name() == "HitRecord"
    assert ie.valid_url('https://hitrecord.org/records/2954362') == 1


# Generated at 2022-06-24 12:43:32.148117
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_video = HitRecordIE()
    assert test_video is not None



# Generated at 2022-06-24 12:43:33.945800
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    A constructor of class HitRecordIE

    """
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'

# Generated at 2022-06-24 12:43:35.206391
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-24 12:43:41.666829
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except:
        print('Test is failed')
# Tests for class HitRecordIE
test = HitRecordIE()
print(test._download_json(
    'https://hitrecord.org/api/web/records/%s' % test._match_id('https://hitrecord.org/records/2954362'),
    '2954362'))
print(test._real_extract(test._VALID_URL))
print(test._TEST)

# Generated at 2022-06-24 12:43:50.837193
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie.VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:43:55.484898
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Unit test for constructor of class HitRecordIE"""
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:43:57.108013
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except:
        assert False


# Generated at 2022-06-24 12:44:04.626101
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.info_extractors == [HitRecordIE]
    assert ie.IE_NAME == ie.__class__.__name__
    assert ie.VALID_URL == HitRecordIE._VALID_URL
    assert ie.TEST == HitRecordIE._TEST
    assert ie.TEST['info_dict'] == HitRecordIE._TEST['info_dict']
    assert ie.TEST['url'] == HitRecordIE._TEST['url']
    assert ie.TEST['md5'] == HitRecordIE._TEST['md5']

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:44:05.808229
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    '''Test for constructor class HitRecordIE'''
    HitRecordIE()

# Generated at 2022-06-24 12:44:07.380514
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
   hit_record = HitRecordIE(InfoExtractor) 
   assert hit_record != null

# Generated at 2022-06-24 12:44:08.308123
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HitRecordIE(InfoExtractor)

# Generated at 2022-06-24 12:44:09.524353
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE != None

# Generated at 2022-06-24 12:44:10.111561
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:44:10.711946
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:44:14.681687
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    my_ie = HitRecordIE("http://hitrecord.org/records/2954362")
    my_ie.suitable("https://hitrecord.org/records/2954362")
    my_ie.extract("https://hitrecord.org/records/2954362", True)

# Generated at 2022-06-24 12:44:24.750442
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    input_url = 'https://hitrecord.org/records/2954362'
    assert ie.suitable(input_url) == True
    assert ie.IE_NAME == 'hitrecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:27.314736
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('hitrecord', 'hitrecord.org')

# Generated at 2022-06-24 12:44:29.305948
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie.KEEP_VIDEO_FRAGMENT == False)

# Generated at 2022-06-24 12:44:30.348164
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(None)

# Generated at 2022-06-24 12:44:36.583244
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = r'https://hitrecord.org/records/2954362'
    hitRecordIE = HitRecordIE()
    hitRecordIE._match_id(url)
    hitRecordIE.suitable(url)
    hitRecordIE.url_result()
    hitRecordIE.extract()


if __name__ == "__main__":
    import sys
    import inspect
    import json

    if len(sys.argv) < 2:
        print("usage: %s <method name>" % sys.argv[0])
        sys.exit(1)

    test_functions = filter(
        lambda x: x[0].startswith("test")
        and not x[0] == "test_HitRecordIE",
        inspect.getmembers(sys.modules[__name__], inspect.ismethod))
   

# Generated at 2022-06-24 12:44:37.330108
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:44:47.817881
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:54.455402
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Unit test for HitRecordIE"""
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:44:57.822717
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    instance._match_id("https://hitrecord.org/records/2954362")
    instance._test_suite()


# Generated at 2022-06-24 12:45:07.625270
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_ie = HitRecordIE()
    assert hit_record_ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert hit_record_ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert hit_record_ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert hit_record_ie._TEST['info_dict']['id'] == '2954362'
    assert hit_record_ie._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 12:45:14.338546
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST[0] == 'url'
    assert ie._TEST[1] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST[2] == 'md5:fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST[3]['id'] == '2954362'
    assert ie._TEST[3]['ext'] == 'mp4'
    assert ie._TEST[3]['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:45:20.349988
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from pytube import YouTube
    from .common import InfoExtractor
    from .common import SearchInfoExtractor
    from .hitrecord import HitRecordIE
    from .youtube import YoutubeIE
    from .youtube import YoutubeSearchIE
    from .youtube import YoutubeShowIE
    from ..utils import get_element_by_attribute
    ie = HitRecordIE
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_key() == 'HitRecord'
    assert ie.ie_key() == 'hitRecord'
    assert ie.ie_key() == 'Hitrecord'
    assert ie.ie_key() == 'HitRecord'
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie

# Generated at 2022-06-24 12:45:24.669089
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == "hitrecord"
    assert ie.ie_name() == "HitRecord"
    assert ie._VALID_URL is not None
    assert ie._TEST is not None

# Generated at 2022-06-24 12:45:26.686601
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        assert HitRecordIE
    except:
        raise Exception("Constructor of class HitRecordIE is not defined, "
                        "check if all the required modules are installed")


# Generated at 2022-06-24 12:45:27.756580
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:45:28.829921
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None, None)

# Generated at 2022-06-24 12:45:29.467254
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-24 12:45:31.896359
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie.url == 'https://hitrecord.org/records/2954362'

# Generated at 2022-06-24 12:45:39.961451
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:43.287269
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == HitRecordIE._VALID_URL
    assert ie._TEST == HitRecordIE._TEST

# Generated at 2022-06-24 12:45:45.422217
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Instantiate and verify class HitRecordIE
    HitRecordIE()


# Generated at 2022-06-24 12:45:46.828134
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:45:48.635380
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('test.com', 'https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:45:49.946216
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('http://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:45:51.258323
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except:
        assert False

# Generated at 2022-06-24 12:45:59.647423
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("HitRecordIE",
                [("HitRecordIE", "https://hitrecord.org/records/2954362",
                  {"id": "2954362",
                   "ext": "mp4",
                   "title": "A Very Different World (HITRECORD x ACLU)",
                   "description": "md5:e62defaffab5075a5277736bead95a3d",
                   "duration": 139.327,
                   "timestamp": 1471557582,
                   "upload_date": "20160818",
                   "uploader": "Zuzi.C12",
                   "uploader_id": "362811",
                   "view_count": int,
                   "like_count": int,
                   "comment_count": int,
                   "tags": list})
                 ])

# Generated at 2022-06-24 12:46:06.061666
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    class_ = HitRecordIE(FakeYDL())
    class_.http.headers.update({'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36'})
    assert class_.extract('https://hitrecord.org/records/2954362') is not None

# Generated at 2022-06-24 12:46:07.612239
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # pylint: disable=W0212
    html = "<html><head></head><body></body></html>"
    ie = HitRecordIE([])
    assert ie.suitable(html)
    assert ie.IE_NAME == "hitrecord:video"

# Generated at 2022-06-24 12:46:13.765157
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    #Creating instance of HitRecordIE
    hr_ie = HitRecordIE('http://www.hitrecord.org/records/2988477')
    assert hr_ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    expected_result_of_url_match = {'id': '2988477'}
    assert hr_ie._match_id(hr_ie.ie_key()) == expected_result_of_url_match["id"]

# Generated at 2022-06-24 12:46:14.684332
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-24 12:46:16.585792
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('http://www.hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:46:24.459604
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	
	# Test case 1: A working URL
	hitrecord = HitRecordIE("https://hitrecord.org/records/2954362")
	assert isinstance(hitrecord, HitRecordIE)

	# Test case 2: An URL that consists of a different domain
	try:
		hitrecord = HitRecordIE("https://www.youtube.com/watch?v=dQw4w9WgXcQ")
	except ValueError:
		assert True

	# Test case 3: A string instead of a valid URL
	try:
		hitrecord = HitRecordIE("hello")
	except ValueError:
		assert True


# Generated at 2022-06-24 12:46:26.094893
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:46:29.766443
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test constructor of HitRecordIE
    urlTest = 'https://hitrecord.org/records/2954362'
    hitrecord_ie = HitRecordIE(urlTest)

    assert hitrecord_ie is not None
    assert hitrecord_ie._TEST is not None
    assert hitrecord_ie._VALID_URL is not None

# Generated at 2022-06-24 12:46:31.009046
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-24 12:46:32.595501
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:46:34.729499
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:46:36.970979
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable("http://hitrecord.org/records/2954362")
    assert not ie.suitable("http://hitrecord.org/")
    assert ie._VALID_URL == ie.VALID_URL

# Generated at 2022-06-24 12:46:45.315060
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie.REAL_VIDEO_URL == ie.VALID_URL, 'REAL_VIDEO_URL and VALID_URL should be equal'
    assert ie.REAL_VIDEO_URL == ie.VALID_URL, 'REAL_VIDEO_URL and VALID_URL should be equal'

    # test if the video_id is correctly extracted
    video_url = 'https://hitrecord.org/records/2954362'
    video_id = ie.video_id(video_url)
    assert video_id == '2954362', 'video_id is not correct'

    # test if _real_extract is working properly
    result = ie._real_extract(video_url)

# Generated at 2022-06-24 12:46:47.653318
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    a = HitRecordIE('HitRecordIE')
    assert a._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)', 'Unit test failed'

# Generated at 2022-06-24 12:46:50.982320
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE(None)
    assert obj.suitable('bla bla bla') == False
    assert obj.suitable('https://hitrecord.org/records/2954362') == True

# Generated at 2022-06-24 12:46:51.583975
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HitRecordIE()

# Generated at 2022-06-24 12:47:01.417428
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    #print(ie._TEST['info_dict'])
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:47:11.432429
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    import youtube_dl

    def test_factory(test):
        class FakeYoutubeDL(object):
            def __init__(self):
                self.params = {}
                self.to_screen = self.to_stderr = lambda *args: None
                self.cache = None
                self.age_limit = None

            def report_warning(self, message):
                pass

        ie = HitRecordIE()
        ie.ydl = FakeYoutubeDL()
        ie.report_warning = ie.ydl.report_warning
        ie.suitable(test['url'])
        info = ie.extract(test['url'])
        # info should be downloaded
        assert info['id'] is not None

