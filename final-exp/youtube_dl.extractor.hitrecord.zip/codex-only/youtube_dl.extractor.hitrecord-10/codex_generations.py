

# Generated at 2022-06-24 12:37:05.632117
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:37:07.118259
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == "HitRecord"

# Generated at 2022-06-24 12:37:07.719228
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE

# Generated at 2022-06-24 12:37:10.196327
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie = HitRecordIE()

# Generated at 2022-06-24 12:37:17.057046
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    # Arrange:
    # import requests
    import requests
    from ..utils import parse_query
    from ..compat import compat_str
    video_id = '2954362'
    url = 'https://hitrecord.org/api/web/records/' + video_id

    # Act:
    # download the information of the video
    response = requests.get(url).json()

    # Assert:
    # get the seven important information of the video
    assert response['id'] == int(compat_str(video_id))
    response_url = response['source_url']
    assert parse_query(video_url)['v'] == int(video_id)
    assert response['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:37:21.712959
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.suitable('http://hitrecord.org/records/2954362') == True
    assert ie.suitable('http://hitrecord.org') == False
    assert ie.suitable('https://hitrecord.org/records/2954362') == True
    assert ie.suitable('https://hitrecord.org') == False

# Generated at 2022-06-24 12:37:30.570942
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.name == 'hitrecord'
    assert ie.ie_key() == 'hitrecord:record'
    assert ie.host == 'hitrecord.org'
    assert ie.description == "hitRECord is an online collaborative production company founded by actor and director Joseph Gordon-Levitt in 2005"
    assert ie.age_limit == 0
    assert ie.geo_countries == [ 'US' ]
    assert ie.report_url == 'https://hitrecord.org/report'
    assert ie.IE_NAME == 'hitrecord:record'
    assert ie.audio_codec() == 'mp4a'
    assert ie.video_codec() == 'h264'

# Generated at 2022-06-24 12:37:35.182417
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie.name == "Hit Record"
    assert ie.validate("https://hitrecord.org/records/2954362")
    #assert ie.validate("https://hitrecord.org/records/2954362") == True



# Generated at 2022-06-24 12:37:36.483884
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:37:37.046696
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-24 12:37:37.838132
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:37:38.184780
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:37:45.878414
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    infoExtractor = HitRecordIE()
    # Test normal video
    testResult = infoExtractor.extract(infoExtractor._TEST['url'])

# Generated at 2022-06-24 12:37:47.526275
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-24 12:37:49.046415
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    ie = HitRecordIE()
    ie._match_id(None)

# Generated at 2022-06-24 12:37:50.867554
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert_true(ie is not None)

# Generated at 2022-06-24 12:37:53.048038
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE("http://www.hitrecord.org/records/2954362")
    except:
        raise AssertionError("HitRecordIE constructor do not work")

# Generated at 2022-06-24 12:37:54.485830
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE();
    assert ie == HitRecordIE()

# Generated at 2022-06-24 12:37:57.921816
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'

# Generated at 2022-06-24 12:38:00.532375
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    return ie

# Generated at 2022-06-24 12:38:02.137992
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print(HitRecordIE(None)._VALID_URL)


# Generated at 2022-06-24 12:38:03.706487
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie
    assert ie._TEST

# Generated at 2022-06-24 12:38:05.821514
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(unittest.TestCase())
    assert isinstance(ie, HitRecordIE)

# Generated at 2022-06-24 12:38:09.170877
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_ie = HitRecordIE()
    assert hit_record_ie._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"

# Generated at 2022-06-24 12:38:11.572864
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.IE_NAME == 'hitrecord'

# Generated at 2022-06-24 12:38:14.127966
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    HitRecordIE constructor should return an object of type HitRecordIE
    """
    ie = HitRecordIE(None)

    assert isinstance(ie, HitRecordIE)

# Generated at 2022-06-24 12:38:15.014691
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:26.718381
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # type: () -> None
    # test if title string contains 'Unable' raises ValueError
    class DummyIE(HitRecordIE):
        def _real_extract(self, url):
            title = 'Unable to do something'
            raise ValueError(title)

    class DummyInfoExtractor(InfoExtractor):
        IE_NAME = 'hitrecord'
        _VALID_URL = r'https://hitrecord.org/records/2954362'
        ie_key = 'DummyIE'

# Generated at 2022-06-24 12:38:28.434679
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(2954362)
    ie.download(2954362)

# Generated at 2022-06-24 12:38:37.422415
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()
    assert obj.IE_NAME == 'hitrecord:record'
    assert obj._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:39.670024
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE('https://hitrecord.org/records/2')
    except:
        assert False

# Generated at 2022-06-24 12:38:42.236689
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == HitRecordIE._VALID_URL
    assert ie.IE_NAME == HitRecordIE.IE_NAME
    assert ie.IE_DESC == HitRecordIE.IE_DESC


# Generated at 2022-06-24 12:38:43.961943
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('http://example.com', {})._real_extract({'id': '2954362', 'url': 'https://hitrecord.org/records/2954362'})

# Generated at 2022-06-24 12:38:44.800109
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(yt)

# Generated at 2022-06-24 12:38:45.323507
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:48.649675
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.suitable('http://hitrecord.org/records/2954362') == True
    assert HitRecordIE.suitable('http://hitrecord.org/') == False


# Generated at 2022-06-24 12:38:50.226515
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE().download('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:38:52.982200
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    t = HitRecordIE('https://hitrecord.org/records/2954362')
    assert t.url_name == 'HitRecord'
    assert t.app_name == 'HitRecord'



# Generated at 2022-06-24 12:38:54.794027
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:38:56.539755
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ie = HitRecordIE()

# Generated at 2022-06-24 12:38:57.659984
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # HitRecordIE()
    assert HitRecordIE



# Generated at 2022-06-24 12:39:01.104696
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    assert 'https://hitrecord.org/records/%s' % HitRecordIE._TEST['url'].split('/')[-1] == hitrecord._VALID_URL

# Generated at 2022-06-24 12:39:04.935066
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE()
    assert hitRecord.name == 'HitRecord'
    assert hitRecord._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'



# Generated at 2022-06-24 12:39:08.184669
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ie = HitRecordIE()
	assert ie.ie_key() == 'hitrecord'
	assert ie.ie_name() == 'hitrecord'
	assert HitRecordIE.suitable('https://hitrecord.org/records/5913130')

# Generated at 2022-06-24 12:39:08.757617
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:10.478076
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:39:15.647930
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Create HitRecordIE object
    ie = HitRecordIE()

    # Check that url is expected
    o = ie._VALID_URL
    a = 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert o == a

    # Check that extraction works
    assert ie._real_extract(ie._TEST['url']) == ie._TEST['info_dict']

# Generated at 2022-06-24 12:39:24.636094
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.get_info_extractor = HitRecordIE.get_info_extractor
    ie.get_login = HitRecordIE.get_login
    ie.suitable = HitRecordIE.suitable

    # Invalid URL
    assert ie._VALID_URL is None and ie._TEST is None
    # Valid URL
    ie._VALID_URL = 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:39:28.559985
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    # Comment out for unit test
    #assert ie.suitable(ie.extract('https://hitrecord.org/records/2954362')) == True
    #assert ie.suitable(ie.extract('https://hitrecord.org/records/')) == False
    #assert ie.suitable(ie.extract('https://hitrecord.org/records/2954362.html')) == False

# Generated at 2022-06-24 12:39:31.103790
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    assert hitrecord.IE_NAME == 'hitrecord'
    assert hitrecord.IE_DESC == 'HitRecord'

# Generated at 2022-06-24 12:39:31.702225
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:33.625054
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("http://hitrecord.org/records/2949941")

# Generated at 2022-06-24 12:39:34.510027
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-24 12:39:44.735803
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test first constructor
    hitrecord = HitRecordIE()
    assert hitrecord._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:39:46.125132
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.suitable("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:39:52.092950
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie.VALID_URL == HitRecordIE._VALID_URL
    assert ie.TEST == HitRecordIE._TEST
    assert ie.params == {'YouTube': {'add_ie': ['Youtube']}}



# Generated at 2022-06-24 12:39:59.340902
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    class_ = HitRecordIE
    assert hasattr(class_, '_VALID_URL'), '_VALID_URL not found in class HitRecordIE'
    assert hasattr(class_, '_TEST'), '_TEST not found in class HitRecordIE'
    assert hasattr(class_, '_download_json'), '_download_json not found in class HitRecordIE'
    assert hasattr(class_, '_match_id'), '_match_id not found in class HitRecordIE'
    assert hasattr(class_, '_real_extract'), '_real_extract not found in class HitRecordIE'

# Generated at 2022-06-24 12:40:01.113311
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:02.699375
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()
    print("Testing availability of class HitRecordIE: " + str(obj.test()))


# Generated at 2022-06-24 12:40:04.086449
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("")

# Generated at 2022-06-24 12:40:05.502449
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:40:15.709734
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test valid URL
    hitrecordIE = HitRecordIE('https://hitrecord.org/records/2954362')
    assert (hitrecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

    # Test extractor used

# Generated at 2022-06-24 12:40:25.288487
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:26.467523
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Initializing object of class HitRecordIE
    HitRecordIE()

# Generated at 2022-06-24 12:40:33.876846
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    unit_test = HitRecordIE()
    assert unit_test._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:40.608718
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ie = HitRecordIE("https://hitrecord.org/records/2954362",False,None,None)
	assert ie.url == 'https://hitrecord.org/records/2954362'
	assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
	assert ie.ie_key == 'HitRecord'
	assert ie.name == 'HitRecord'
	assert ie.SUITABLE_DEFAULT
	assert ie.extractor_key == 'HitRecord'
	assert ie.IE_NAME == 'HitRecord'
	assert ie.search_ie

# Generated at 2022-06-24 12:40:44.157934
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:44.742966
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('')

# Generated at 2022-06-24 12:40:52.727262
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    video_id = HitRecordIE._match_id(url)
    info_dict = HitRecordIE._TEST
    HitRecordIE.suite()
    assert video_id == '2954362'
    assert info_dict['url'] == 'https://hitrecord.org/records/2954362'
    assert info_dict['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert info_dict['info_dict']['id'] == '2954362'
    assert info_dict['info_dict']['ext'] == 'mp4'
    assert info_dict['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert info_

# Generated at 2022-06-24 12:40:53.266966
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:40:54.320243
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE = VideoInfoExtractor()

# Generated at 2022-06-24 12:40:55.901427
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.__name__ == 'HitRecordIE'

# Generated at 2022-06-24 12:40:59.078183
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:59.997323
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:41:05.944531
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('http://hitrecord.org/records/2954362')
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert not ie.suitable('http://hitrecord.org/')
    assert not ie.suitable('https://hitrecord.org/')

# Generated at 2022-06-24 12:41:06.568998
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:09.944795
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE()
    assert info_extractor._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert info_extractor._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert info_extractor._TEST['info_dict']


# Generated at 2022-06-24 12:41:12.781850
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie.url == 'https://hitrecord.org/records/2954362'

# Unit test to check whether correct video is being downloaded

# Generated at 2022-06-24 12:41:13.652516
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert ie

# Generated at 2022-06-24 12:41:16.646889
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test case for HitRecordIE constructor
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'

# Generated at 2022-06-24 12:41:18.429388
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE(HitRecordIE._make_valid_url(VALID_URL), VALID_URL)

# Generated at 2022-06-24 12:41:19.931592
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE()
    assert info_extractor is not None

# Generated at 2022-06-24 12:41:20.512255
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:21.760475
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert(HitRecordIE('', {}).ie_key() == 'HitRecord')

# Generated at 2022-06-24 12:41:22.812224
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('HitRecord') == HitRecordIE(info_extractor_key='HitRecord')

# Generated at 2022-06-24 12:41:25.901745
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecordie = HitRecordIE()

    url = 'https://hitrecord.org/records/2954362'

    hitrecordie.extract(url)

# Generated at 2022-06-24 12:41:27.341782
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(HitRecordIE._TEST['url'])

# Generated at 2022-06-24 12:41:27.948022
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:29.486978
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	result = HitRecordIE(_VALID_URL)
	assert result == HitRecordIE

# Generated at 2022-06-24 12:41:30.094942
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-24 12:41:38.244781
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['url'] == 'https://hitrecord.org/api/web/records/2954362'

# Generated at 2022-06-24 12:41:39.986850
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Test constructor of the class HitRecordIE"""
    ie = HitRecordIE()
    assert isinstance(ie, HitRecordIE)

# Generated at 2022-06-24 12:41:41.915990
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_data = {}
    hit_record = HitRecordIE()
    for id in hit_record.suitable(test_data["url"]):
        print(id)



# Generated at 2022-06-24 12:41:42.783369
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    print(ie)

# Generated at 2022-06-24 12:41:46.360126
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.suitable('https://hitrecord.org/records/2954362')
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:41:47.960580
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract(HitRecordIE._TEST['url'])

# Generated at 2022-06-24 12:41:49.452317
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test class constructor
    HitRecordIE()


# Unit test: access protected members of class HitRecordIE

# Generated at 2022-06-24 12:41:51.578105
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:41:59.910030
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # the test_* method name must be the same as the function name in the module
    # the _real_extract method in the module must be renamed to extract
    ie = HitRecordIE()
    result = ie._real_extract("https://hitrecord.org/records/1383154")
    assert result['id'] == '1383154'
    assert result['title'] == 'The Things I Forgot To Say'
    assert result['uploader'] == 'miniminter'
    assert result['uploader_id'] == '190658'
    assert result['timestamp'] == 1386630369
    assert result['view_count'] == 1
    assert len(result['tags']) == 0

test_HitRecordIE()

# Generated at 2022-06-24 12:42:01.692109
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.suitable("""https://hitrecord.org/records/2954362""")

# Generated at 2022-06-24 12:42:02.826691
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:04.077278
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert hasattr(ie, '_VALID_URL')

# Generated at 2022-06-24 12:42:06.790102
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """ Unit test for constructor of class HitRecordIE

    This test only checks if the class initializes.
    """
    ie = HitRecordIE()
    assert ie is not None, 'Failed to initialize HitRecordIE.'

# Generated at 2022-06-24 12:42:07.988804
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert 'HitRecord' in ie.IE_NAME

# Generated at 2022-06-24 12:42:08.980094
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()
    print(obj)

# Generated at 2022-06-24 12:42:19.910338
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    m = HitRecordIE()
    assert m._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:42:22.285119
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, HitRecordIE)

# Generated at 2022-06-24 12:42:23.300425
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert isinstance(HitRecordIE(), InfoExtractor)

# Generated at 2022-06-24 12:42:24.326715
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()



# Generated at 2022-06-24 12:42:24.924115
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE

# Generated at 2022-06-24 12:42:34.374110
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
      Test HitRecordIE works as expected
    """
    ie = HitRecordIE()
    url = 'https://hitrecord.org/records/290001'

# Generated at 2022-06-24 12:42:37.841967
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-24 12:42:48.301984
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert type(ie._TEST) == dict
    assert type(ie._TEST['url']) == str
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert type(ie._TEST['info_dict']) == dict
    assert type(ie._TEST['info_dict']['id']) == str
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert type(ie._TEST['info_dict']['ext']) == str
    assert ie._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 12:42:49.092508
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:51.653429
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = InfoExtractor()
    ie.add_ie(HitRecordIE())

    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:43:01.038975
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._TEST.get('id') == '2954362'
    assert ie._TEST.get('url') == 'https://hitrecord.org/records/2954362'
    assert ie._TEST.get('title') == 'A Very Different World (HITRECORD x ACLU)'
    assert ie._TEST.get('description') == 'md5:e62defaffab5075a5277736bead95a3d'
    assert ie._TEST.get('duration') == 139.327
    assert ie._TEST.get('timestamp') == 1471557582
    assert ie._TEST.get('upload_date') == '20160818'
    assert ie._TEST.get('uploader') == 'Zuzi.C12'

# Generated at 2022-06-24 12:43:01.520079
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:11.988898
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    obj = HitRecordIE()._real_extract(url)
    assert obj['id'] == '2954362'

# Generated at 2022-06-24 12:43:13.197155
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(InfoExtractor())

# Generated at 2022-06-24 12:43:13.552084
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:16.785870
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL =='https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie.IE_NAME == 'hitrecord'
    assert type(ie._TEST) is dict

# Generated at 2022-06-24 12:43:28.268324
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    extracted_video = HitRecordIE._real_extract("https://hitrecord.org/records/2954362")

    assert extracted_video['url'] == 'https://assets-0.hitrecord.org/assets/mp4s/16/11/16/2954362/2954362.mp4'
    assert extracted_video['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:43:30.547343
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(HitRecordIE._VALID_URL)
    print(ie._VALID_URL)
    print(ie._TEST)

# Generated at 2022-06-24 12:43:32.761518
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    assert HitRecordIE()._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:43:39.840070
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

     # test to check validity of URL r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    valid_url = 'https://hitrecord.org/records/2954362'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._VALID_URL == ie._downloader.VALID_URL
    assert ie._match_id('https://hitrecord.org/records/2954362') == '2954362'
    assert ie._match_id(valid_url) == '2954362'

     # test to check validity of metadata

# Generated at 2022-06-24 12:43:41.219881
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:43:43.327478
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    ie = HitRecordIE()
    ie.extract(url)

# Generated at 2022-06-24 12:43:49.360660
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  # This test is to test if the constructor of class HitRecordIE works well.
  hitRecordIE = HitRecordIE()
  # Two successful cases
  assert (hitRecordIE._VALID_URL ==
      r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-24 12:43:50.603147
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from .. import initialize_extractor_for_testing
    initialize_extractor_for_testing(HitRecordIE)

# Generated at 2022-06-24 12:43:59.841697
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:01.754009
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Testing HitRecordIE
    HitRecordIE()

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:44:11.160217
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:16.065933
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    obj1 = ie._real_extract('https://hitrecord.org/records/2954362')
    assert (obj1['title'] == 'A Very Different World (HITRECORD x ACLU)')
    assert (obj1['view_count'] == 3750)
    assert (obj1['like_count'] == 64)
    assert (obj1['comment_count'] == 64)

# Generated at 2022-06-24 12:44:17.277088
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from . import HitRecordIE
    from . import InfoExtractor

# Generated at 2022-06-24 12:44:17.762175
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:44:18.636263
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None, None)

# Generated at 2022-06-24 12:44:19.645653
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-24 12:44:24.701681
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie_hitrecord = HitRecordIE()
    assert ie_hitrecord.ie_key() == 'hitrecord'
    #assert url is not empty
    url = 'https://hitrecord.org/records/2954362'
    assert ie_hitrecord._match_id(url) == '2954362'

# Generated at 2022-06-24 12:44:30.337561
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	print("Running Unit Test on the constructor of class HitRecordIE")
	url = 'https://www.hitrecord.org/records/2954362'
	try:
		print("\tCreating HitRecordIE(", url,")")
		p = HitRecordIE(url)
		print("\tSuccess")
		return True
	except:
		print("\tFailure")
		return False


# Generated at 2022-06-24 12:44:39.842826
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    # Warning: Do not forget to initialize all attributes of a classe in its constructor
    # otherwise you'll have unexpected behaviours in your unit test
    hitrecordIE = HitRecordIE('https://hitrecord.org/records/2954362')

    assert hitrecordIE._VALID_URL is not None
    assert hitrecordIE._TEST is not None
    assert hitrecordIE._downloader is not None
    assert hitrecordIE._working_dir_fn is not None
    assert hitrecordIE._download_retcode is not None
    assert hitrecordIE._num_downloads is not None
    assert hitrecordIE._screen_file is not None
    assert hitrecordIE._download_stats is not None
    assert hitrecordIE._progress_hooks is not None
    assert hitrecordIE._ies is not None
    assert hitrecordIE._pp is not None


# Generated at 2022-06-24 12:44:41.895956
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')
    assert True

# Generated at 2022-06-24 12:44:43.513511
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE().extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:44:45.780066
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:44:47.383074
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie


# Generated at 2022-06-24 12:44:49.500438
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    extractor = HitRecordIE()
    print(extractor)
    assert extractor.__class__.__name__ == 'HitRecordIE'

# Generated at 2022-06-24 12:44:58.353935
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_class = HitRecordIE()
    assert test_class.suitable("https://hitrecord.org/records/2954362") == True
    assert test_class.suitable("http://hitrecord.org/records/2954362") == True
    assert test_class.suitable("https://hitrecord.org/records/29543623") == False
    assert test_class.suitable("https://hitrecord.org/records/a") == False
    assert test_class.suitable("https://hitrecord.org/records/2954362/") == True


# Generated at 2022-06-24 12:45:07.930996
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    c = HitRecordIE()

    assert(c._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')
    assert(c._TEST['url'] == 'https://hitrecord.org/records/2954362')
    assert(c._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71')
    assert(c._TEST['info_dict']['id'] == '2954362')
    assert(c._TEST['info_dict']['ext'] == 'mp4')
    assert(c._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)')

# Generated at 2022-06-24 12:45:08.458169
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  assert True

# Generated at 2022-06-24 12:45:10.577205
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    try:
        ie.suitable('https://hitrecord.org/records/2954362')
        assert False
    except:
        assert True

# Generated at 2022-06-24 12:45:20.439851
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:23.921617
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-24 12:45:30.323440
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_cases = [
        { 'url': 'https://hitrecord.org/records/2954362', 'video_id': '2954362' },
        { 'url': 'https://www.hitrecord.org/records/2954362', 'video_id': '2954362' }
    ]
    for tc in test_cases:
        ie = HitRecordIE(tc['url'])
        assert ie._match_id(tc['url']) == tc['video_id']

# Generated at 2022-06-24 12:45:33.102122
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    #Create an instance of class HitRecordIE
    test_class = HitRecordIE()
    #Check if it is an instance of HitRecordIE
    assert isinstance(test_class, HitRecordIE)

# Generated at 2022-06-24 12:45:34.503464
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-24 12:45:39.787791
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'hitrecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST[
        'url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST[
        'md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-24 12:45:40.873689
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:45:44.119549
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_ie = HitRecordIE()
    # Assert for instance of class HitRecordIE
    assert isinstance(test_ie, HitRecordIE)

# Generated at 2022-06-24 12:45:45.655209
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('hitrecord', 'hitrecord.org')

# Generated at 2022-06-24 12:45:47.779940
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print('TESTING HitRecord::InfoExtractor')
    extractor = HitRecordIE()
    print('TEST PASSED')

# Generated at 2022-06-24 12:45:49.946821
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    t = HitRecordIE()
    assert t._TEST['id'] == t._TEST['info_dict']['id']

# Generated at 2022-06-24 12:45:53.803306
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.url = "https://hitrecord.org/records/2954362"
    print(type(ie.url))
    print(ie.url)

if __name__ == "__main__":
    test_HitRecordIE()

# Generated at 2022-06-24 12:45:56.051347
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL;
    assert HitRecordIE()._TEST == HitRecordIE._TEST;

# Generated at 2022-06-24 12:45:56.547633
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:45:57.326379
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    m = HitRecordIE()


# Generated at 2022-06-24 12:45:59.417182
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'

# Generated at 2022-06-24 12:46:03.719839
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    infoExtractor = HitRecordIE()
    assert infoExtractor.suitable('https://hitrecord.org/records/2954362')
    assert not infoExtractor.suitable('https://hitrecord.org/records/2954363')


# Generated at 2022-06-24 12:46:04.080944
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:04.673467
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:13.401233
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'hitrecord.org'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:46:22.810659
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:46:28.255514
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Tests for Video URLs
    samples = [
        'https://hitrecord.org/records/2954362',
    ]
    for sample in samples:
        assert HitRecordIE._match_id(sample) is not None

    # Tests for invalid Video URLs
    samples = [
        'https://hitrecord.org/records/',
    ]
    for sample in samples:
        assert HitRecordIE._match_id(sample) is None

# Generated at 2022-06-24 12:46:29.088283
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:46:37.363284
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # The current test is to show the constructor of class HitRecordIE.
    # You can add some statements in the end of the current test to do more test for the class.

    # Construct an instance of class HitRecordIE for test
    HitRecordIE_test = HitRecordIE()
    print('Unit test for HitRecordIE:')
    print('    HitRecordIE_test = HitRecordIE()')
    print('    HitRecordIE_test is: ' + str(HitRecordIE_test))
    # If you want to do more test, pls write statements below.

# Unit test
if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:46:37.840537
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:39.993955
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:46:41.841922
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hri = HitRecordIE()
    assert hri.suitable('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:46:42.405703
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:46:49.950152
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie._VALID_URL == 'https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)'

# Generated at 2022-06-24 12:46:51.581362
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:46:53.958132
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # We need to check if the constructor of class HitRecordIE is correct or not
    HitRecordIE()

# Generated at 2022-06-24 12:46:54.589122
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:57.715531
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    m = HitRecordIE()
    x = m._extract_urls()
    assert x[0] == 'https://hitrecord.org/records/3001856'


# Generated at 2022-06-24 12:46:58.297077
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:59.354209
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()



# Generated at 2022-06-24 12:47:03.313160
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.description == 'hitrecord.org'
    assert ie.extract_id('https://hitrecord.org/records/2954362') == '2954362'

# Generated at 2022-06-24 12:47:07.170127
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test for InfoExtractor
    ie = HitRecordIE();
    info = ie.extract('https://hitrecord.org/records/2954362');
    print(info);
    assert(info['id'] == '2954362');
