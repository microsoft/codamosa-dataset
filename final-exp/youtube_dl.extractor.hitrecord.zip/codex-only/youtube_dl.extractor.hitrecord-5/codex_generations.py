

# Generated at 2022-06-24 12:37:12.433784
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:37:13.505682
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:37:14.567726
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:37:20.877689
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert HitRecordIE.__name__ == 'HitRecord'
    assert HitRecordIE.suitable('https://hitrecord.org/records/2954362')
    assert HitRecordIE.suitable('https://www.hitrecord.org/records/2954362')
    assert not HitRecordIE.suitable('https://hitrecord.org/records/')

# Generated at 2022-06-24 12:37:22.716351
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('hitrecord')
    assert ie != None

# Generated at 2022-06-24 12:37:24.939749
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie.name != None)
    assert(ie._VALID_URL == ie.VALID_URL)

# Generated at 2022-06-24 12:37:28.566663
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-24 12:37:39.077255
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:37:47.973356
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    assert(hitRecordIE.ie_key() == 'HitRecord')
    assert(hitRecordIE.display_id('https://hitrecord.org/records/2954362') == '2954362')
    assert(hitRecordIE.suitable('https://hitrecord.org/records/2954362') == True)
    assert(hitRecordIE.suitable('Not a URL') == False)
    assert(hitRecordIE.IE_DESC == 'HitRecord')
    assert(hitRecordIE.ie_key() == 'HitRecord')

# Generated at 2022-06-24 12:37:58.370786
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:00.245071
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE()._real_initialize()

# Generated at 2022-06-24 12:38:11.362291
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ieClass = HitRecordIE("http://hitrecord.org/records/2954362")
    print("ieClass._VALID_URL:", ieClass._VALID_URL)
    print("ieClass._TEST:", ieClass._TEST)
    print("ieClass.__name__:", ieClass.__name__)
    print("ieClass.__doc__:", ieClass.__doc__)
    print("ieClass.suitable:", ieClass.suitable('http://hitrecord.org/records/2954362'))
    print("ieClass.suitable:", ieClass.suitable('http://hitrecord.org/records/29543621'))
    print("ieClass._real_extract:", ieClass._real_extract('http://hitrecord.org/records/2954362'))

# Generated at 2022-06-24 12:38:23.085874
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('hitrecord', 'hitrecord.org')
    assert (ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-24 12:38:24.797644
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:38:27.962840
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	hitRecord_ie = HitRecordIE(_url, _video_id)
	assert hitRecord_ie is not None

if __name__ == '__main__':
	test_HitRecordIE()

# Generated at 2022-06-24 12:38:28.408426
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:29.354713
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(object)

# Generated at 2022-06-24 12:38:33.844725
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test a valid URL
    valid_url = 'https://hitrecord.org/records/2954362'
    hit_record_ie = HitRecordIE()
    match = hit_record_ie._VALID_URL.match(valid_url)
    assert match  # Assert there is a match for the URL
    assert match.group('id') == '2954362'  # Assert the URL ID matches


# Generated at 2022-06-24 12:38:35.732757
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	self = HitRecordIE()

	assert self._match_id('https://hitrecord.org/records/2954362') == '2954362'

# Generated at 2022-06-24 12:38:45.041788
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    m = HitRecordIE()
    assert m.IE_NAME == 'hitrecord:record'
    assert m._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:48.609076
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable(ie.IE_NAME, ie._VALID_URL)
    assert ie._VALID_URL == ie._real_extract('_')['url']

# Generated at 2022-06-24 12:38:50.541166
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  ie = HitRecordIE()
  ie._real_extract('test')


# Generated at 2022-06-24 12:38:59.385155
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie.url == 'https://hitrecord.org/records/2954362'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie.video_id == '2954362'
    assert ie.title == 'A Very Different World (HITRECORD x ACLU)'
    assert ie.description == 'md5:e62defaffab5075a5277736bead95a3d'
    assert ie.duration == 139.327
    assert ie.timestamp == 1471557582
    assert ie.upload_date == '20160818'
    assert ie.uploader == 'Zuzi.C12'
   

# Generated at 2022-06-24 12:39:10.768693
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
        HitRecordIE test class constructor
    """
    test_object = HitRecordIE()
    assert test_object.IE_NAME == 'HitRecord'
    assert test_object._VALID_URL== r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:39:20.454044
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    x = HitRecordIE()
    #print(x._TEST)

# Generated at 2022-06-24 12:39:21.168376
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:22.761985
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """HitRecordIE(InfoExtractor) unit test stub."""

    HitRecordIE(InfoExtractor)

# Generated at 2022-06-24 12:39:35.279186
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-24 12:39:45.599478
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    test = {'url': 'https://hitrecord.org/records/2954362'}
    url = test['url']

    match = ie._VALID_URL.match(url)
    if not match:
        return 'The url is not valid to HitRecordIE'

    video_id = match.group('id')

    video = ie._download_json(
        'https://hitrecord.org/api/web/records/%s' % video_id, video_id)
    if not video:
        return 'The video not exist for this id'

    tags = None
    tags_list = try_get(video, lambda x: x['tags'], list)

# Generated at 2022-06-24 12:39:56.489389
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:03.919099
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  """
  For the test of HitRecordIE(), the input url is the following:
  url: https://www.hitrecord.org/records/3619261 
  """
  # Set expected results
  ie = HitRecordIE()
  ie.extractor_key = 'hitrecord'
  ie.description = u'This is a test description'
  ie.duration = 403
  ie.id = '3619261'
  ie.title = u'Test Title'
  ie.upload_date = '20170809'
  ie.uploader = u'MaxTest'
  ie.url = u'https://www.hitrecord.org/records/3619261'
  ie.view_count = 0
  ie.like_count = 0
  ie.comment_count = 0

# Generated at 2022-06-24 12:40:07.657348
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    # verify that constructor does not fail
    except:
        assert(False)
        return

    # verify that object is instance of correct class
    assert isinstance(HitRecordIE(), InfoExtractor)


# Generated at 2022-06-24 12:40:08.279253
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-24 12:40:11.548898
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(HitRecordIE._VALID_URL)
    assert ie is not None
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:12.600304
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE()

# Generated at 2022-06-24 12:40:15.435744
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
        print("PASSED: HitRecordIE class constructor test")
    except Exception:
        print("FAILED: HitRecordIE class constructor test")

# Generated at 2022-06-24 12:40:17.879426
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')
    HitRecordIE('https://www.hitrecord.org/records/2954362')
    assert True

# Generated at 2022-06-24 12:40:20.609384
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:22.851904
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit = HitRecordIE('https://hitrecord.org/records/2954362')
    print(hit.url)

# Generated at 2022-06-24 12:40:23.325357
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    print(ie)

# Generated at 2022-06-24 12:40:26.903132
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.name == "hitrecord"
    assert ie.description == "HitRecord is an open collaborative production company, and this is our website."
    assert ie.valid_urls == [r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)']


# Generated at 2022-06-24 12:40:30.469812
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('HitRecordIE','HitRecordIE','hitrecord.org','HitRecordIE','HitRecordIE','HitRecordIE','HitRecordIE')
    print(ie)
    ie = HitRecordIE('HitRecordIE','HitRecordIE','hitrecord.org','HitRecordIE','HitRecordIE','HitRecordIE','HitRecordIE')

# Generated at 2022-06-24 12:40:40.446511
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    with open("hitrecord_examples/example_input_HitRecordIE.txt", "r") as f:
        json_txt = f.read()

    ie.video = json.loads(json_txt)

    assert(ie.video['id'] == "2954362")
    assert(ie.video['title'] == "A Very Different World (HITRECORD x ACLU)")
    assert(ie.video['source_url']['mp4_url'] == "https://hitrecord.org/files/642923/TOFN3qZJl6Kj.mp4")

# Generated at 2022-06-24 12:40:42.847476
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-24 12:40:51.406205
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-24 12:40:52.971846
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    url = 'https://hitrecord.org/records/2954362'
    ie._real_extract(url)

# Generated at 2022-06-24 12:40:53.620352
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_case = HitRecordIE()

# Generated at 2022-06-24 12:40:55.098685
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:41:01.568875
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    import sys
    import unittest

    class HitRecordIETestCase(unittest.TestCase):
        def test_constructor(self):
            pass

    # create an instance of a unittest class
    testcase = HitRecordIETestCase()
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromModule(testcase)
    if not runner.run(suite).wasSuccessful():
        sys.exit(1)

# Generated at 2022-06-24 12:41:11.255748
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_key() == 'HitRecord'
    assert ie.extract_id('https://hitrecord.org/records/2954362') == '2954362'
    assert ie.extract_id('https://hitrecord.org/records/2954362/') == '2954362'
    assert ie.extract_id('http://hitrecord.org/records/2954362/') == '2954362'
    assert ie.extract_id('https://hitrecord.org/records/2954362') == '2954362'



# Generated at 2022-06-24 12:41:22.070558
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    global HitRecordIE

    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert HitRecordIE._TEST.get('url') == 'https://hitrecord.org/records/2954362'
    assert HitRecordIE._TEST.get('md5') == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert HitRecordIE._TEST.get('info_dict').get('id') == '2954362'
    assert HitRecordIE._TEST.get('info_dict').get('ext') == 'mp4'
    assert HitRecordIE._TEST.get('info_dict').get('title') == 'A Very Different World (HITRECORD x ACLU)'
   

# Generated at 2022-06-24 12:41:23.806452
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362') is True

# Generated at 2022-06-24 12:41:30.381771
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    # Test invalid url
    invalidURL = 'https://not-a-real-url.com'
    assert hitRecordIE._match_id(invalidURL) == '"%s" does not match'
    
    # Test valid url
    validURL = 'https://hitrecord.org/records/2954362'
    assert hitRecordIE._match_id(validURL) == '2954362'

# Generated at 2022-06-24 12:41:33.802773
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/3009793')
    assert ie.suitable('http://hitrecord.org/records/5')

# Generated at 2022-06-24 12:41:42.304958
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record = HitRecordIE("https://hitrecord.org/records/2954362")
    assert hit_record._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"
    assert hit_record._TEST["url"] == "https://hitrecord.org/records/2954362"
    assert hit_record._TEST["md5"] == "fe1cdc2023bce0bbb95c39c57426aa71"
    assert hit_record._TEST["info_dict"]["id"] == "2954362"
    assert hit_record._TEST["info_dict"]["ext"] == "mp4"

# Generated at 2022-06-24 12:41:52.205436
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert "HitRecordIE" in dir(HitRecordIE)
    # check for valid url
    ie = HitRecordIE()
    ie._VALID_URL = r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    # check for valid request
    assert ie._download_json == 'https://hitrecord.org/records/%s' % video_id

# Generated at 2022-06-24 12:41:55.841598
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# >>> test_HitRecordIE()
# <__main__.HitRecordIE object at 0x106cc74a8>

# Generated at 2022-06-24 12:42:06.341593
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert HitRecordIE._TEST.get('url') == 'https://hitrecord.org/records/2954362'
    assert HitRecordIE._TEST.get('md5') == 'fe1cdc2023bce0bbb95c39c57426aa71'
    infoDict = HitRecordIE._TEST.get('info_dict')
    assert infoDict.get('id') == '2954362'
    assert infoDict.get('ext') == 'mp4'
    assert infoDict.get('title') == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:42:17.862505
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    import logging
    import unittest
    import inspect
    import sys
    import os
    import yaml
    from .common import TestCommon, getTestFile
    TestHitRecord = type(
        'Test' + 'HitRecordIE' + '_' + inspect.currentframe().f_code.co_name,
        (TestCommon, unittest.TestCase),
        dict(TestCommon._get_tests(HitRecordIE) ) )
    sys.stdout.write(yaml.dump(
        TestHitRecord._get_tests(HitRecordIE),
        default_flow_style=False,
        allow_unicode=True,
        encoding=None,
        width=80,
        indent=2,
        canonical=False,
        line_break='\n') )
# end of unit test for constructor of class HitRecordIE

# Generated at 2022-06-24 12:42:21.240623
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE(): 
    assert HitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:42:22.331185
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()



# Generated at 2022-06-24 12:42:23.295134
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:42:24.326280
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:25.986126
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from .common import InfoExtractor
    assert issubclass(HitRecordIE, InfoExtractor)

# Generated at 2022-06-24 12:42:26.563212
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:29.798975
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE();
    assert info_extractor._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:42:37.204501
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert(HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-24 12:42:37.797712
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:40.053076
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Simple test for the constructor of class HitRecordIE
    assert HitRecordIE()


# Generated at 2022-06-24 12:42:41.131684
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit = HitRecordIE()
    assert hit

# Generated at 2022-06-24 12:42:45.153405
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._match_id('https://hitrecord.org/records/2954362') == '2954362'
    assert ie._real_extract('https://hitrecord.org/records/2954362')['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:42:46.405187
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()

# Generated at 2022-06-24 12:42:48.748221
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-24 12:42:49.278223
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:50.239193
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie

# Generated at 2022-06-24 12:42:59.979152
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    url = 'https://hitrecord.org/records/2954362'
    result = ie._real_extract(url)
    assert result['id'] == '2954362', 'Should be equal'
    assert result['url'] == 'https://videos.hitrecord.org/video/2954362.mp4', 'Should be equal'
    assert result['title'] == 'A Very Different World (HITRECORD x ACLU)', 'Should be equal'
    assert result['description'] is not None, 'Should be not none'
    assert result['duration'] == 139.327, 'Should be equal'
    assert result['timestamp'] == 1471557582, 'Should be equal'
    assert result['uploader'] == 'Zuzi.C12', 'Should be equal'

# Generated at 2022-06-24 12:43:07.142630
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Unit test for constructor of class HitRecordIE."""
    # Pylint bug: https://github.com/PyCQA/pylint/issues/2822
    # pylint: disable=no-value-for-parameter
    ie = HitRecordIE()
    info = ie.extract('https://hitrecord.org/records/2954362')
    assert info['id'] == '2954362'
    assert info['uploader'] == 'Zuzi.C12'
    assert info['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:43:07.720879
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:17.493732
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print("Testing constructor of HitRecordIE...")
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:43:21.666780
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('test', 'test')
    assert hasattr(ie, '_VALID_URL') and ie._VALID_URL is not None
    assert hasattr(ie, '_TEST') and ie._TEST is not None


# Generated at 2022-06-24 12:43:31.983268
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == (
        r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-24 12:43:33.479253
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE().get_info('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:43:34.862654
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL

# Generated at 2022-06-24 12:43:35.752704
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:39.327581
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._download_json('https://hitrecord.org/api/web/records/2954362',2954362)
    ie._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:43:45.775822
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:43:51.911312
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # inherit methods of class InfoExtractor
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

    # inherit methods of class InfoExtractor

# Generated at 2022-06-24 12:43:52.799538
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'

# Generated at 2022-06-24 12:43:54.646225
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_ie = HitRecordIE()
    assert isinstance(hitrecord_ie, InfoExtractor)

# Generated at 2022-06-24 12:43:55.605451
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	obj = HitRecordIE()
	return

# Generated at 2022-06-24 12:43:58.462032
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:01.499305
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_url = 'https://hitrecord.org/records/2954362'
    test_obj = HitRecordIE()
    assert test_obj._match_id(test_url) == '2954362'



# Generated at 2022-06-24 12:44:02.390233
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:44:02.988478
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert(True)

# Generated at 2022-06-24 12:44:04.381147
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("www.hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:44:04.928183
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE

# Generated at 2022-06-24 12:44:08.265886
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE("hitrecord")  # Constructor
    result = hitRecordIE.suitable("https://hitrecord.org/records/2954362") # Check if the given URL is supported
    assert (result) # Return True if supported

# Generated at 2022-06-24 12:44:09.481344
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-24 12:44:11.160430
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    Test = HitRecordIE()
    Test._match_id('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:44:14.091988
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  ie = HitRecordIE()
  assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'



# Generated at 2022-06-24 12:44:17.471890
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'Hitrecord'

# Generated at 2022-06-24 12:44:27.821048
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# HitRecordIE initialized with url of the video
	# This unit test is for testing if following info can be extracted from a valid url:
	#   title, description, duration, uploader, uploader_id, timestamp, like_count, comment_count, tags, view_count
	#   and if the video can be downloaded

	ie = HitRecordIE(url='https://hitrecord.org/records/2954362')

	# Extracting info from the url
	info_dict = ie.extract()

	assert info_dict['id'] == '2954362'

# Generated at 2022-06-24 12:44:29.493203
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('http://www.hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:44:39.250692
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    InfoExtractor._download_webpage = lambda x,y: ''
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie.url == 'https://hitrecord.org/records/2954362'
    assert ie.video_id == '2954362'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:40.591745
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:44:50.699758
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:52.768849
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, HitRecordIE)

# Generated at 2022-06-24 12:45:03.901992
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    hitrecord = HitRecordIE()
    assert hitrecord._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    match =  hitrecord._VALID_URL_RE.match(url)
    assert match
    assert match.group('id') == '2954362'
    info_dict = hitrecord._real_extract(url)
    assert info_dict['id'] == '2954362'
    assert info_dict['url'] == 'http://cdn-images.hitrecord.org/Video/2016/08/12/b9/a9/2954362/mp4_source.mp4'

# Generated at 2022-06-24 12:45:04.467142
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()



# Generated at 2022-06-24 12:45:06.362138
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:07.569427
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('')

# Generated at 2022-06-24 12:45:09.844466
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test = HitRecordIE(None)

    assert test.ie_key() == 'HitRecord'

# Generated at 2022-06-24 12:45:19.777050
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:23.148336
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()
    assert obj._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:25.595620
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	test = HitRecordIE()
	test._real_extract()

if __name__ == '__main__':
	test_HitRecordIE()

# Generated at 2022-06-24 12:45:26.565212
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.suite()
    ie._TESTS

# Generated at 2022-06-24 12:45:27.193438
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:45:28.211434
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-24 12:45:29.249330
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:45:30.866897
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(HitRecordIE, HitRecordIE._VALID_URL)

# Generated at 2022-06-24 12:45:36.198101
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extractor = 'HitRecordIE'
    ie.ie_key = 'HitRecord'
    ie.suitable = staticmethod(lambda url: True)
    ie.video_id = staticmethod(lambda url: '2954362')
    ie._VALID_URL = r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    return ie

# Generated at 2022-06-24 12:45:38.823804
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecordIE = HitRecordIE(None)
    assert hitrecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:40.782954
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert (HitRecordIE()._VALID_URL ==
            HitRecordIE._VALID_URL)


# Generated at 2022-06-24 12:45:47.040152
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from .common import FakeYDL
    from .test_youtube import YoutubeIE
    fake_dl = FakeYDL()
    yt = YoutubeIE(fake_dl)
    hr = HitRecordIE(fake_dl)
    assert yt.get_info_extractors() == hr.get_info_extractors()


# Generated at 2022-06-24 12:45:49.223868
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.get_video_info('https://hitrecord.org/records/2954362') is not None

# Generated at 2022-06-24 12:45:52.429498
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.name == 'hitrecord.org'
    assert ie.VALID_URL == HitRecordIE._VALID_URL
    assert ie.TEST == HitRecordIE._TEST

# Generated at 2022-06-24 12:45:54.897537
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # Test if the URL is valid
    url = 'https://hitrecord.org/records/2954362'
    if ie.suitable(url) is True:
        ie.download(url)
# Unit test complete

# Generated at 2022-06-24 12:46:04.574480
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST.get('url') == 'https://hitrecord.org/records/2954362'
    assert ie._TEST.get('md5') == 'fe1cdc2023bce0bbb95c39c57426aa71'
    id = ie._TEST.get('info_dict').get('id')
    assert id == '2954362'
    ext = ie._TEST.get('info_dict').get('ext')
    assert ext == 'mp4'
    title = ie._TEST.get('info_dict').get('title')

# Generated at 2022-06-24 12:46:13.337379
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test case 1:
    test_dict_1 = {
        'url': 'https://hitrecord.org/records/2954362'
    }
    assert HitRecordIE._VALID_URL == HitRecordIE._TEST['url']
    assert HitRecordIE._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-24 12:46:15.531111
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    print ('after creating HitRecordIE')

# Generated at 2022-06-24 12:46:20.760013
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_cases = [
        [
            {
                'url': 'https://hitrecord.org/records/2954362',
                'only_matching': True,
            }
        ],
    ]
    for test_case in test_cases:
        hitRecordIE = HitRecordIE()
        assert hitRecordIE.suitable(test_case[0])
        assert hitRecordIE.extract(test_case[0])

# Generated at 2022-06-24 12:46:24.683339
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert not ie.suitable('https://www.youtube.com/watch?v=ZjrsQ1nXNTk')


# Generated at 2022-06-24 12:46:25.107786
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:32.642441
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'

    hitrecord_ie = HitRecordIE()
    output = hitrecord_ie._real_extract(url)

    assert output['id'] == '2954362'
    assert output['url'] is not None
    assert output['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert output['description'] is not None
    assert output['duration'] == 139.327
    assert output['timestamp'] == 1471557582
    assert output['uploader'] == 'Zuzi.C12'
    assert output['uploader_id'] == '362811'
    assert output['view_count'] is not None
    assert output['like_count'] is not None
    assert output['comment_count'] is not None
    assert output['tags']

# Generated at 2022-06-24 12:46:41.648622
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE()
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:46:49.451979
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('http://www.hitrecord.org/records/2954362')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:46:51.239952
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    _test_ie = HitRecordIE()
    assert _test_ie

# Generated at 2022-06-24 12:46:52.751399
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(InfoExtractor())

# Generated at 2022-06-24 12:46:55.283155
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE();
    assert str(type(ie)) == "<class 'youtube_dl.extractor.hitrecord.HitRecordIE'>"

# Generated at 2022-06-24 12:46:57.034837
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL


# Generated at 2022-06-24 12:46:59.062404
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE == HitRecordIE('HitRecord', True)


# test if the constructors of class HitRecordIE
# returns the exact class name

# Generated at 2022-06-24 12:46:59.524997
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:47:10.277306
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'