

# Generated at 2022-06-24 12:37:08.600658
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'hitrecord.org'

# Generated at 2022-06-24 12:37:09.307815
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-24 12:37:11.277646
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:37:12.167021
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test = HitRecordIE()


# Generated at 2022-06-24 12:37:19.495385
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test = HitRecordIE(HitRecordIE._VALID_URL, HitRecordIE._TEST)
    assert isinstance(test._VALID_URL, str)
    assert isinstance(test._TEST, dict)
    test._real_extract(HitRecordIE._VALID_URL)
    assert isinstance(test._real_extract(HitRecordIE._VALID_URL), dict)
    assert isinstance(HitRecordIE._download_json(
        'https://hitrecord.org/api/web/records/2954362', '2954362'), dict)

# Generated at 2022-06-24 12:37:24.599031
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Initialize a new class of HitRecordIE
    hitRecord = HitRecordIE('https://hitrecord.org/records/2954362')
    # Assert the name of class is as expected
    assert hitRecord.IE_NAME == 'HitRecord'
    # Assert the url of class is as expected
    assert hitRecord.IE_URL == 'https://hitrecord.org/'
    # Assert the _VALID_URL of class is as expected
    assert hitRecord._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:37:27.981637
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('')
    assert isinstance(ie, HitRecordIE)

if __name__ == "__main__":
    test_HitRecordIE()

# Generated at 2022-06-24 12:37:29.219113
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE.test('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:37:32.167112
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL

# Perform the unit test
test_HitRecordIE()

# Generated at 2022-06-24 12:37:39.656049
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    dect = {}
    dect['_VALID_URL'] = HitRecordIE._VALID_URL
    dect['_TEST'] = HitRecordIE._TEST
    dect['_match_id'] = HitRecordIE._match_id
    dect['_real_extract'] = HitRecordIE._real_extract
    dect['_download_json'] = HitRecordIE._download_json
    
    assert dect['_TEST']['url'] == 'https://hitrecord.org/records/2954362'
    return HitRecordIE(dect['_TEST']['url'])

# Generated at 2022-06-24 12:37:40.041586
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:37:41.126428
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert type(HitRecordIE) == type

# Generated at 2022-06-24 12:37:49.557009
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    # Test get_id method
    assert ie.get_id() == '2954362'

    # Test get_url method
    expected_url = 'https://hitrecord.org/records/2954362'
    assert ie.get_url() == expected_url

    # Test download method
    try:
        ie.download()
        print("Unit test for constructor of class HitRecordIE is successful.")
    except Exception as e:
        print("Unit test failed. Reason: ")
        print(e)

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:37:50.458365
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	pass


# Generated at 2022-06-24 12:37:51.617566
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:37:54.663216
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('www.hitrecord.org')
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:04.934302
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:05.544423
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:38:07.096881
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:38:07.700586
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:08.664615
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('HitRecordIE', 'Generic')

# Generated at 2022-06-24 12:38:10.773496
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except:
        AssertionError("Failed to create an instance of class HitRecordIE")

# Generated at 2022-06-24 12:38:11.297475
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:12.774457
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE().download_video('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:38:14.576406
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL is not None
    assert ie._TEST is not None

# Generated at 2022-06-24 12:38:26.670821
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    url = 'https://hitrecord.org/records/2954362'
    assert ie.suitable(url)
    assert ie.get_url_re() == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie.get_id(url) == '2954362'

# HitRecordIE tests
# Note: these tests were written for the old HitRecordIE, but I was too lazy
# to change them. Thus, these tests don't even run.
# from .common import InfoExtractor
# from ..compat import compat_str
# from ..utils import (
#     compat_urllib_parse_unquote,
#     compat_urllib_parse_

# Generated at 2022-06-24 12:38:34.765657
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'

# Generated at 2022-06-24 12:38:44.105276
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    test = HitRecordIE._TEST
    assert test['url'] == 'https://hitrecord.org/records/2954362'
    assert test['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    info_dict = test['info_dict']
    assert info_dict['id'] == '2954362'
    assert info_dict['ext'] == 'mp4'
    assert info_dict['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert info_dict['description'] == 'md5:e62defaffab5075a5277736bead95a3d'


# Generated at 2022-06-24 12:38:44.502045
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:51.651733
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_ie = HitRecordIE()

    # Test for declaring of _VALID_URL
    assert hit_record_ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

    # Test for declaring of _TESTS

# Generated at 2022-06-24 12:38:55.565436
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE()
    # In this case, we test for the HitRecord video
    # https://hitrecord.org/records/2954362

    assert(hitRecord._real_extract(
        'https://hitrecord.org/records/2954362')["id"] == "2954362")

# Generated at 2022-06-24 12:38:58.084173
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.download(HitRecordIE._TEST['url'])
    ie = HitRecordIE()
    ie.download(HitRecordIE._TEST['url'])

# Generated at 2022-06-24 12:39:00.952999
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = "https://hitrecord.org/records/2954362"
    video_id = 2954362
    print(url)
    print(video_id)
    hrie = HitRecordIE(None, None)
    print(hrie)
    # print(hrie._match_id(url))

# Generated at 2022-06-24 12:39:02.192634
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE.suite()

# Generated at 2022-06-24 12:39:08.160582
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:39:09.211331
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.__init__

# Generated at 2022-06-24 12:39:12.432742
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL
    assert HitRecordIE()._TEST == HitRecordIE._TEST


# Generated at 2022-06-24 12:39:16.292750
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:39:19.304177
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, InfoExtractor)
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-24 12:39:21.411974
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(HitRecordIE, 'https://hitrecord.org/records/2954362', 'mp4')


# Generated at 2022-06-24 12:39:23.983925
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_ie = HitRecordIE()
    assert hitrecord_ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:39:28.309424
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except:
        print("Cannot create instance of HitRecordIE")


# Generated at 2022-06-24 12:39:28.975252
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:39.652684
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_ie = HitRecordIE()
    assert hit_record_ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:39:43.741414
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test case 1
    # Video url: https://hitrecord.org/records/2954362
    url = 'https://hitrecord.org/records/2954362'
    # Output: html format video page content
    print(HitRecordIE(downloader=None).extract(url))


# Generated at 2022-06-24 12:39:48.326437
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie.extract('https://hitrecord.org/records/2954362')


if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:39:50.393285
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract(HitRecordIE._VALID_URL)

# Generated at 2022-06-24 12:39:52.807053
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_recordIE = HitRecordIE()
    assert hit_recordIE._TEST['url'] == 'https://hitrecord.org/records/2954362'

# Generated at 2022-06-24 12:39:54.869676
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    print("Created new HitRecordIE instance")


# Generated at 2022-06-24 12:39:55.474838
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:56.793625
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'

# Generated at 2022-06-24 12:39:58.336602
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_ie = HitRecordIE('')
    print(hitrecord_ie)


# Generated at 2022-06-24 12:40:03.559884
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    init_info = HitRecordIE()
    assert init_info._VALID_URL == "https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)"
    assert init_info._TEST["url"] == "https://hitrecord.org/records/2954362"
    assert init_info._TEST["md5"] == "fe1cdc2023bce0bbb95c39c57426aa71"
    assert init_info._TEST["info_dict"]["id"] == "2954362"

# Generated at 2022-06-24 12:40:06.662652
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org')

# Generated at 2022-06-24 12:40:12.782803
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL.split("/")[2] == "hitrecord.org"
    assert HitRecordIE._TEST["url"].split("/")[2] == "hitrecord.org"
    assert HitRecordIE._TEST["url"].split("/")[3] == "records"
    assert HitRecordIE._TEST["url"].split("/")[4] == HitRecordIE._TEST["info_dict"]["id"]

# Generated at 2022-06-24 12:40:14.886928
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = HitRecordIE._VALID_URL
    ie = HitRecordIE(url)
    assert ie._match_id(url) == "2954362"

# Generated at 2022-06-24 12:40:16.581043
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')


# Generated at 2022-06-24 12:40:19.388656
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(InfoExtractor())._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:21.793085
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	print("Begin test_HitRecordIE...")
	ie = HitRecordIE()
	print("Finished test_HitRecordIE!")

test_HitRecordIE()

# Generated at 2022-06-24 12:40:23.778556
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit = HitRecordIE(HitRecordIE._VALID_URL)
    assert hit.ie_key() == 'HitRecord'



# Generated at 2022-06-24 12:40:24.653312
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert isinstance(HitRecordIE, type)

# Generated at 2022-06-24 12:40:28.694870
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('hitrecord', 'hitrecord')
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:30.936025
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(HitRecordIE._VALID_URL, False)
    assert ie._real_extract('https://hitrecord.org/records/2954362') == HitRecordIE._TEST['info_dict']

# Generated at 2022-06-24 12:40:32.997331
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie is not None


# Generated at 2022-06-24 12:40:41.385911
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video_id = 2954362
    url = 'https://hitrecord.org/records/%s' % video_id
    expected_video_url = \
        'https://www.hitrecord.org/uploads/files/25c11/25c11a6c' + \
        '4ab4da1c03d9b400f4b8c2b7a/%s.mp4' % video_id
    expected_title = 'A Very Different World (HITRECORD x ACLU)'
    expected_description = 'md5:e62defaffab5075a5277736bead95a3d'
    expected_duration = 139.327
    expected_timestamp = 1471557582
    expected_uploader = 'Zuzi.C12'
    expected_uploader_id = '362811'

# Generated at 2022-06-24 12:40:43.407599
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from .. import HitRecordIE
    ie = HitRecordIE()
    assert isinstance(ie, HitRecordIE)

# Generated at 2022-06-24 12:40:45.828023
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:47.457531
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    infoExtractor = HitRecordIE()
    assert isinstance(infoExtractor, HitRecordIE)

# Generated at 2022-06-24 12:40:54.523576
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(_VALID_URL)
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:55.653608
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert callable(HitRecordIE)

# Generated at 2022-06-24 12:40:58.124798
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(u'https://hitrecord.org/records/2954362') == 1

# Generated at 2022-06-24 12:40:59.135930
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:41:01.664838
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(
        'hitrecord') == HitRecordIE(
            'hitrecord.org') == HitRecordIE(
                'https://hitrecord.org')

# Generated at 2022-06-24 12:41:03.896015
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    import sys
    if sys.version_info < (3, 0):
        return
    HitRecordIE()

# Generated at 2022-06-24 12:41:10.026879
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    fixture_url = 'https://hitrecord.org/records/2954362'

    instance = HitRecordIE(
        downloader=None,
        download_default_filename='test')

    result = instance._real_extract(fixture_url)

    assert len(result['tags']) == 6
    assert result['tags'][0] == 'a-different-world'

# Generated at 2022-06-24 12:41:11.337053
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()
    assert obj.ie_key() == "HitRecord"
    assert obj.ie_name() == "HitRecord"

# Generated at 2022-06-24 12:41:12.799903
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:41:14.595729
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.register_ie(HitRecordIE.ie_key(), HitRecordIE)

# Generated at 2022-06-24 12:41:15.424430
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:18.704836
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:41:26.221778
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:41:37.205249
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == HitRecordIE._VALID_URL
    assert ie._TEST == HitRecordIE._TEST
    assert ie.IE_NAME == HitRecordIE.IE_NAME
    assert ie.ie_key() == HitRecordIE.ie_key()
    assert ie.SUITABLE_GENERAL == HitRecordIE.SUITABLE_GENERAL
    assert ie.SUITABLE_BROWSE == HitRecordIE.SUITABLE_BROWSE
    assert ie.BROWSE_URL == HitRecordIE.BROWSE_URL
    assert ie.DEFAULT_BROWSE_DAYS == HitRecordIE.DEFAULT_BROWSE_DAYS
    assert ie.DEFAULT_BROWSE_CATEGORY == HitRecordIE.DEFAULT_BROWSE_CATEGORY

# Generated at 2022-06-24 12:41:38.406335
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    print(ie)

# Generated at 2022-06-24 12:41:40.741648
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE(None)

    assert hitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:41:41.225073
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:42.208890
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    construct = InfoExtractor
    instance = construct(HitRecordIE)
    assert instance != None

# Generated at 2022-06-24 12:41:42.646375
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:49.252285
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hie = HitRecordIE()
    print(hie)
    print(hie._VALID_URL)
    print(hie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')
    print(hie.IE_NAME)
    print(hie._TESTS)
    print(hie._TEST)
    print(hie._TEST['url'])


test_HitRecordIE()

# Generated at 2022-06-24 12:41:59.236816
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	e = HitRecordIE("http://www.hitrecord.org/records/2954362")
	assert e.id == "2954362"
	assert e.url == "http://www.hitrecord.org/records/2954362"
	assert e.title == "A Very Different World (HITRECORD x ACLU)"
	assert e.description == "md5:e62defaffab5075a5277736bead95a3d"
	assert e.duration == 139.327
	assert e.timestamp == 1471557582
	assert e.upload_date == "20160818"
	assert e.uploader == "Zuzi.C12"
	assert e.uploader_id == "362811"
	assert e.view_count == int
	assert e.like_count == int

# Generated at 2022-06-24 12:42:02.685993
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    #__name__ = 'HitRecordIE'
    url = 'https://hitrecord.org/records/2954362'
    obj = HitRecordIE()
    assert obj.suitable(url)
    assert obj.extract(url)

# Generated at 2022-06-24 12:42:06.181708
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()
    print(obj._VALID_URL)
    print(test_HitRecordIE.__name__)
    print(obj._TEST)
    print(obj._TEST['url'] == 'https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:42:09.884144
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    assert hitrecord != None
    assert hitrecord.ie_key() != None

# Generated at 2022-06-24 12:42:20.368673
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-24 12:42:31.127219
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hRIE = HitRecordIE('http://hitrecord.org/records/2954362')
    assert isinstance(hRIE, HitRecordIE)
    assert hRIE.url == 'https://hitrecord.org/records/2954362'
    assert hRIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:42:33.042559
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    x = HitRecordIE()

    assert x.ie_key() == 'hitrecord'
    assert x.ie_key_short() == 'hitrecord'

# Generated at 2022-06-24 12:42:34.230884
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(None, {})


# Generated at 2022-06-24 12:42:45.154325
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')

    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:42:45.742535
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:48.977401
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    extractor = HitRecordIE()
    assert extractor._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:42:53.294760
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    assert ie._TEST['url'] == ie._VALID_URL % ie._TEST['info_dict']['id']
    assert ie._TEST['info_dict']['id'] in ie.extract(ie._TEST['url'])['url']

# Generated at 2022-06-24 12:42:55.385692
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:42:56.658588
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:42:57.548336
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE()._TEST


# Generated at 2022-06-24 12:42:58.748919
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE({})

# Vimeo Video Test

# Generated at 2022-06-24 12:43:08.976890
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_ie = HitRecordIE()
    assert hitrecord_ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:43:09.910819
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()


# Generated at 2022-06-24 12:43:12.487845
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    url = ie._VALID_URL
    ie._real_extract(url)


# Generated at 2022-06-24 12:43:20.386310
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:43:22.968416
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# test_HitRecordIE() tests HitRecordIE
	HitRecord = HitRecordIE()
	print(HitRecord)
# end of test_HitRecordIE()


# Generated at 2022-06-24 12:43:26.623803
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Return a HitRecordIE instance for testing.
    This class is known to have a bug.
    """
    from .common import InfoExtractor
    from .generic import GenericIE
    return GenericIE()

# Generated at 2022-06-24 12:43:29.486775
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# Constructor 1
	HitRecordIE(downloader=None, download_defaults=None, ie_key=None,
																verbose=False)

# Generated at 2022-06-24 12:43:31.057287
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie


# Generated at 2022-06-24 12:43:33.558051
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Unit test for constructor of class HitRecordIE
    hitrecord_ie = HitRecordIE()
    assert hitrecord_ie.ie_key() == 'hitrecord'
    assert hitrecord_ie.exclude() is None

# Generated at 2022-06-24 12:43:36.644867
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test valid URL
    HitRecordIE('https://hitrecord.org/records/2954362')
    # Test invalid URL
    HitRecordIE('https://hitrecord.org/records')

# Generated at 2022-06-24 12:43:37.579033
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:43:39.025086
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  assert HitRecordIE().ie_key() == 'HitRecord'

# Generated at 2022-06-24 12:43:48.640101
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-24 12:43:50.433112
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE.suitable('https://hitrecord.org/records/2954362')
    assert info_extractor is not None, 'HitRecordIE not suitable for URL'

# Generated at 2022-06-24 12:43:51.323329
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("unit test for constructor of class HitRecordIE")


# Generated at 2022-06-24 12:43:54.502263
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    constructor_test_helper(
        HitRecordIE,
        "https://hitrecord.org/records/2954362",
        "A Very Different World (HITRECORD x ACLU)",
        "Expected to get a string back after downloading with HitRecordIE"
    )

# Generated at 2022-06-24 12:43:58.154195
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    if not ie.suitable('https://hitrecord.org/records/2954362'):
        assert False
    # TODO: Figure out how to test for a failed url.
    # assert ie.suitable('')

# Generated at 2022-06-24 12:43:59.097979
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	return HitRecordIE()


# Generated at 2022-06-24 12:44:08.139136
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:09.348511
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie

# Generated at 2022-06-24 12:44:10.660350
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except NameError:
        print("NameError")

# Generated at 2022-06-24 12:44:11.209082
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:44:12.138924
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Constructor of class HitRecordIE
	HitRecordIE()

# Generated at 2022-06-24 12:44:13.176464
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Unit test for the constructor of HitRecordIE class
    """
    HitRecordIE()

# Generated at 2022-06-24 12:44:19.051340
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'hitrecord'
    assert ie.suitable(u'https://hitrecord.org/records/2954362') is True
    assert ie.suitable(u'https://hitrecord.org/users/Zuzi.C12/videos') is False
    assert ie._VALID_URL == ie._VALID_URL_TEMPLATE
    assert ie._TEST.get('entry_protocol', 'http') == 'http'
    assert ie.host() == 'hitrecord.org'

# Generated at 2022-06-24 12:44:19.956703
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:44:23.104257
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Test HitRecordIE"""
    assert(HitRecordIE().extract("https://hitrecord.org/records/2954362"))

# Generated at 2022-06-24 12:44:23.744613
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:44:25.811047
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'hitrecord.org'

# Generated at 2022-06-24 12:44:30.398698
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    #! Given
    test_case = HitRecordIE()

    #! When
    actual_url = test_case._VALID_URL

    #! Then
    expected_url = r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert actual_url == expected_url

# Generated at 2022-06-24 12:44:30.800808
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:44:31.427884
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert type(HitRecordIE) is type

# Generated at 2022-06-24 12:44:33.302119
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:44:37.330336
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    # Test class name
    assert ie.IE_NAME == 'hitrecord:record'
    # Test video id
    assert ie._match_id('https://hitrecord.org/records/2954362') == '2954362'

# Generated at 2022-06-24 12:44:40.364309
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    #Test the constructor of HitRecordIE
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'
    assert ie.ie_key() == 'HitRecordIE.hitrecord.org'

# Generated at 2022-06-24 12:44:50.509371
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert HitRecordIE._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert HitRecordIE._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert HitRecordIE._TEST['info_dict']['id'] == '2954362'
    assert HitRecordIE._TEST['info_dict']['ext'] == 'mp4'
    assert HitRecordIE._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:44:52.686375
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert 'hitrecord' in ie.ie_key()


# Generated at 2022-06-24 12:44:53.335097
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:44:57.516905
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE('https://hitrecord.org/records/2954362')

    assert hitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:59.507393
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')
    assert True


# Generated at 2022-06-24 12:45:01.353593
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extractor
    print('test_HitRecordIE was successful!')

# Generated at 2022-06-24 12:45:02.074335
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	hitrecord = HitRecordIE()

# Test for method _real_extract()

# Generated at 2022-06-24 12:45:10.812997
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-24 12:45:18.406900
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

if __name__ == '__main__':
    import sys
    import os
    import pytest

    # Disable print function during unit test
    # to prevent printed output in travis
    sys.stdout = open(os.devnull, 'w')

    # Unit test for constructor of class HitRecordIE
    def test_HitRecordIE():
        hitrecordie = HitRecordIE()
        assert hitrecordie

    # Unit test for module HitRecordIE
    pytest.main()

    # Re-enable stdout
    sys.stdout = sys.__stdout__

# Generated at 2022-06-24 12:45:26.502767
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(
    )._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:29.187089
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    assert instance._VALID_URL == HitRecordIE._VALID_URL
    assert instance._TEST == HitRecordIE._TEST


# Generated at 2022-06-24 12:45:30.613618
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecordIE = HitRecordIE()
    assert hitrecordIE is not None

# Generated at 2022-06-24 12:45:32.972807
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    extractor = HitRecordIE()
    assert extractor.suitable(HitRecordIE._VALID_URL)
    assert not extractor.suitable('invalid url')


# Generated at 2022-06-24 12:45:34.373274
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(HitRecordIE._VALID_URL, {})

# Generated at 2022-06-24 12:45:36.068894
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == ie._TEST['url']

# Generated at 2022-06-24 12:45:41.668430
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	print("\nRunning tests for " + HitRecordIE.__name__)

	# Test id/url extraction
	ie = HitRecordIE("https://hitrecord.org/records/2954362")
	assert ie.suitable("https://hitrecord.org/records/2954362") is True, "Video ID extraction failed"

	# Test metadata extraction
	retrieved = ie.extract(ie._VALID_URL)
	assert "title" in retrieved, "Failed to extract title"
	print("Title: " + retrieved["title"])
	assert "description" in retrieved, "Failed to extract description"
	print("Description: " + retrieved["description"])
	assert "timestamp" in retrieved, "Failed to extract timestamp"
	print("Time Stamp: " + str(retrieved["timestamp"]))

# Generated at 2022-06-24 12:45:43.188396
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ext = HitRecordIE()
	print(ext)

# Generated at 2022-06-24 12:45:47.780237
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test for constructor of class HitRecordIE
    Test = HitRecordIE('https://hitrecord.org/records/2954362')
    Test_constructor = isinstance(Test, HitRecordIE) and isinstance(Test, InfoExtractor)
    assert Test_constructor



# Generated at 2022-06-24 12:45:48.859268
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:45:49.458003
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:45:50.396182
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:45:51.347424
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test = HitRecordIE()
    assert test

# Generated at 2022-06-24 12:45:53.271516
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # url = 'https://www.hitrecord.org/records/2954362'
    # ie = HitRecordIE()
    # res = ie.extract(url)
    # print(res)
    pass

# Generated at 2022-06-24 12:45:55.293127
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(info_dict=None)._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-24 12:45:57.297535
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    print(ie.IE_NAME)
    print(ie._VALID_URL)
    print(ie._TEST)

# Generated at 2022-06-24 12:45:58.666304
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    h = HitRecordIE()
    assert isinstance(h, HitRecordIE)


# Generated at 2022-06-24 12:46:02.198828
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(InfoExtractor)._VALID_URL == HitRecordIE._VALID_URL
    assert HitRecordIE(InfoExtractor)._TEST == HitRecordIE._TEST


# Generated at 2022-06-24 12:46:03.349844
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    URL = 'https://hitrecord.org/records/2954362'
    ie = HitRecordIE()
    ie._real_extract(URL)

# Generated at 2022-06-24 12:46:07.192291
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-24 12:46:07.815882
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:15.403004
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE('https://hitrecord.org/records/')
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert info_extractor._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert info_extractor._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert str(info_extractor._TEST['info_dict']['uploader_id']) == '362811'

# Generated at 2022-06-24 12:46:16.015916
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:16.589357
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:17.369526
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:20.158056
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Test to ensure all the fields are populated.
    """

    ie = HitRecordIE()
    ie.extract('http://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:46:22.167087
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.get_url_re().match('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:46:23.548413
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:25.924697
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:46:26.476810
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:27.048035
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:28.531434
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    extraction_instance = HitRecordIE()
    print(extraction_instance._VALID_URL)

# Generated at 2022-06-24 12:46:38.320467
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:46:38.821095
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:39.289819
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:41.478706
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    hitrecordIE = HitRecordIE()
    hitrecordIE._real_extract(url)

# Generated at 2022-06-24 12:46:42.012428
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:48.239261
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    class_HitRecordIE = HitRecordIE('https://hitrecord.org/records/2954362')
    assert class_HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert class_HitRecordIE._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert class_HitRecordIE._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-24 12:46:54.323254
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == HitRecordIE._VALID_URL
    assert ie._TEST == HitRecordIE._TEST
    assert ie._download_json == HitRecordIE._download_json
    assert ie._match_id == HitRecordIE._match_id
    assert ie._real_extract == HitRecordIE._real_extract

# Generated at 2022-06-24 12:46:58.928780
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Construct the info extractor
    ie = HitRecordIE()

    # Check that the regex works
    match = ie._VALID_URL_RE.match('https://hitrecord.org/records/2954362')
    assert match

    # Check that the returned video id is correct
    assert match.group('id') == '2954362'

# Generated at 2022-06-24 12:47:06.859801
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    video_id = '2954362'
    expected_video = ie._TEST
    actual_video = ie._real_extract(expected_video['url'])
    for key in expected_video.keys():
        if key != 'info_dict':
            assert (expected_video[key] == actual_video[key])
        else:
            for info_key in expected_video[key].keys():
                assert (expected_video[key][info_key] == actual_video[key][info_key])