

# Generated at 2022-06-24 12:37:06.661908
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.VALID_URL == HitRecordIE._VALID_URL

# Unit test: download video

# Generated at 2022-06-24 12:37:07.553055
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE().test()

# Generated at 2022-06-24 12:37:13.506977
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
#   hitRecordIE = HitRecordIE()
#   print(type(hitRecordIE))
    print(HitRecordIE._VALID_URL)
    hitRecordIE = HitRecordIE.suitable('https://hitrecord.org/records/2954362')
    print(hitRecordIE)


if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:37:16.672592
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Create the instance of class HitRecordIE
    output = HitRecordIE()
    # Run the test for the _real_extract method
    output.test()



# Generated at 2022-06-24 12:37:17.258690
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:37:27.506098
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print('Testing class HitRecordIE')
    HitRecordIE_extractor = HitRecordIE()
    if HitRecordIE_extractor._VALID_URL:
        print('Testing _VALID_URL')
        assert(HitRecordIE_extractor._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')
    if HitRecordIE_extractor._TEST:
        print('Testing _TEST')

# Generated at 2022-06-24 12:37:29.291633
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("HitRecordIE", "hitrecord.org", "2954362")


# Generated at 2022-06-24 12:37:30.242531
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:37:31.680408
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('test')


# Generated at 2022-06-24 12:37:32.949310
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    data = HitRecordIE()
    assert data.IE_NAME == 'hitrecord'

# Generated at 2022-06-24 12:37:36.697173
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Test HitRecordIE constructor
    """
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362') == True
    assert ie.suitable('http://foo.com/bar') == False



# Generated at 2022-06-24 12:37:44.777441
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert HitRecordIE._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert HitRecordIE._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert HitRecordIE._TEST['info_dict']['id'] == '2954362'
    assert HitRecordIE._TEST['info_dict']['ext'] == 'mp4'
    assert HitRecordIE._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert HitRecordIE._TEST['info_dict']['description']

# Generated at 2022-06-24 12:37:46.061094
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert str(ie) == 'hitrecord.org'

# Generated at 2022-06-24 12:37:57.016301
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from .common import InfoExtractor
    from .generic_downloader_extract_info import ExtractorInfo
    from .youtube_dl import YoutubeDL
    from .youtube_dl.extractor.common import InfoExtractor
    from .youtube_dl.extractor.youtube import YoutubeIE
    from .youtube_dl.utils import (
        ExtractorError,
    )
    ydl = YoutubeDL({'skip_download': True})
    url = 'https://hitrecord.org/records/2954362'
    e = HitRecordIE(ydl)
    e.extract(url)
    assert e.IE_NAME == 'hitrecord'
    e = YoutubeIE(ydl)
    url = 'https://www.youtube.com/watch?v=2Z4m4lnjxkY'

# Generated at 2022-06-24 12:37:58.231427
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    result = HitRecordIE()
    assert(result == "__main__")

# Generated at 2022-06-24 12:38:01.949654
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert(HitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-24 12:38:07.558795
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test URL for HitRecordIE
    HitRecordIEURL = HitRecordIE._TEST['url']

    # Test constructor for HitRecordIE
    HitRecordIEInstance = HitRecordIE(HitRecordIEURL)

    # Test if you can get id from class HitRecordIE
    assert HitRecordIEInstance._TEST['url'] == HitRecordIEURL

# Generated at 2022-06-24 12:38:08.900146
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  ie = HitRecordIE()
  assert(ie)

# Generated at 2022-06-24 12:38:10.247120
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(HitRecordIE._VALID_URL, HitRecordIE._TEST)

# Generated at 2022-06-24 12:38:11.465545
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    # Just instantiating the class should be enough
    HitRecordIE(None)

# Generated at 2022-06-24 12:38:16.037929
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'
    assert ie.ie_key() != 'HitRecordIE'
    assert ie.ie_key() != 'hitrecord'
    assert ie.ie_key() != 'hitrecord.org'

# Generated at 2022-06-24 12:38:16.661718
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:27.963226
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    inst = HitRecordIE()
    assert inst._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:28.609633
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:38:30.594217
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(InfoExtractor(str(1)))
    assert isinstance(ie, HitRecordIE)

# Main method for testing

# Generated at 2022-06-24 12:38:31.438422
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-24 12:38:41.644656
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE(): 
    from .common import InfoExtractor
    from .hitrecord import HitRecordIE
    from .pluralsight import PluralsightIE
    from .youtube import YoutubeIE
    from .youtube_dl import YoutubeDL
    from .youtube_list import YoutubePlaylistIE
    from .youtube_show import YoutubeShowIE
    from .youtube_search import YoutubeSearchIE
    from .ted import TEDIE
    from .vimeo import VimeoIE
    from .vimeo_album import VimeoAlbumIE
    from .vimeo_channel import VimeoChannelIE
    from .vimeo_group import VimeoGroupIE
    from .vimeo_ondemand import VimeoOnDemandIE
    from .vine import VineIE
    from .vk import VKIE
    from .vlive import VLiveIE
    from .vrt import VRTIE

# Generated at 2022-06-24 12:38:49.011022
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:38:53.125097
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    t = HitRecordIE()
    assert t._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"
    assert t._TEST["url"] == "https://hitrecord.org/records/2954362"


# Generated at 2022-06-24 12:38:53.700363
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:58.634420
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == HitRecordIE._TEST['url']
    assert HitRecordIE._TEST.get('md5') == HitRecordIE._TEST.get('info_dict').get('md5')
    assert HitRecordIE._TEST.get('info_dict').get('id') == HitRecordIE._valid_url(HitRecordIE._TEST['url'])

# Generated at 2022-06-24 12:39:01.013351
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('https://hitrecord.org/records/2954362') is not None

# Test url

# Generated at 2022-06-24 12:39:11.523482
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:39:17.853414
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    FakeHitRecordClass = type('FakeHitRecordIE', (HitRecordIE,), {'_VALID_URL': HitRecordIE._VALID_URL, '_TEST':HitRecordIE._TEST})

    assert  FakeHitRecordClass is not None
    assert  FakeHitRecordClass._VALID_URL == HitRecordIE._VALID_URL
    assert  FakeHitRecordClass._TEST == HitRecordIE._TEST
    assert  FakeHitRecordClass._download_json == HitRecordIE._download_json
    assert  FakeHitRecordClass._match_id == HitRecordIE._match_id
    assert  FakeHitRecordClass._real_extract == HitRecordIE._real_extract

# Generated at 2022-06-24 12:39:19.858671
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.download('https://hitrecord.org/records/2954362')
    ie.list_extractors()

# Generated at 2022-06-24 12:39:22.675760
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/3038833")
    assert ie.extractor.__class__.__name__ == "HitRecordIE"
    

# Generated at 2022-06-24 12:39:29.640745
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # contructor should not have parameters
    hitrecord=HitRecordIE()
    if hitrecord is None:
        assert(False)
        return
    if type(hitrecord) is not HitRecordIE:
        assert (False)
        return
    if hitrecord._VALID_URL != r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)':
        assert (False)
        return
    if hitrecord._TEST['url'] != 'https://hitrecord.org/records/2954362':
        assert (False)
        return
    if hitrecord._TEST['md5'] != 'fe1cdc2023bce0bbb95c39c57426aa71':
        assert (False)
        return

# Generated at 2022-06-24 12:39:34.386615
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Place holder for constructor of class HitRecordIE
    """
    print('Testing constructor of class HitRecordIE ...')
    test_object = HitRecordIE()
    # Place holder for test 
    assert test_object
    print('Testing constructor of class HitRecordIE done!')


# Generated at 2022-06-24 12:39:36.824275
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_ie = HitRecordIE()
    url = 'https://hitrecord.org/records/2954362'
    id = hitrecord_ie._match_id(url)
    assert id == '2954362'

# Generated at 2022-06-24 12:39:40.801946
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert HitRecordIE().IE_NAME == 'hitrecord'
    return 1


# Generated at 2022-06-24 12:39:41.267567
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE

# Generated at 2022-06-24 12:39:43.520347
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_ie = HitRecordIE()
    assert hit_record_ie

# Generated at 2022-06-24 12:39:44.350675
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie != None

# Generated at 2022-06-24 12:39:48.736303
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(HitRecordIE._VALID_URL)

    # Unit test for method _real_extract()
    info_dict = ie._real_extract(HitRecordIE._TEST['url'])

    # Testing values of info_dict
    assert info_dict['id'] == HitRecordIE._TEST['info_dict']['id']
    assert info_dict['title'] == HitRecordIE._TEST['info_dict']['title']

# Generated at 2022-06-24 12:39:50.392947
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:39:53.177822
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/collaborations')

# Generated at 2022-06-24 12:39:53.997388
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:39:55.057104
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    import HitRecordIE
    HitRecordIE.HitRecordIE

# Generated at 2022-06-24 12:40:00.568560
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records/')
    assert not ie.suitable('https://hitrecord.org/records/290/man')
    assert not ie.suitable('https://hitrecord.org/records/290-man')

# Generated at 2022-06-24 12:40:01.659937
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._real_extract('http://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:40:02.120291
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:40:02.702943
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:40:05.658719
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(HitRecordIE._VALID_URL)
    assert ie._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-24 12:40:08.177887
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(InfoExtractor._downloader())

#-------------------------------------------------------------------------------

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:40:09.539279
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'

# Generated at 2022-06-24 12:40:12.506798
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Test for method _real_extract

# Generated at 2022-06-24 12:40:17.193074
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    try:
        ie.suitable('https://hitrecord.org/records/2954362')
        ie.get_url_info('https://hitrecord.org/records/2954362')
        ie.get_urls('https://hitrecord.org/records/2954362')
    except Exception as e:
        print(e)

# Generated at 2022-06-24 12:40:20.054062
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:21.386608
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:40:29.363915
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, InfoExtractor)
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:32.946715
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test with a valid url
    url = 'https://hitrecord.org/records/2954362'
    assert HitRecordIE._VALID_URL == HitRecordIE._extract_url(url)

    # Test with a invalid url
    url = 'http://www.example.com/'
    try:
        assert HitRecordIE._VALID_URL == HitRecordIE._extract_url(url)
    except AttributeError:
        print('AttributeError: This url is not a hitrecord.org url')

# Generated at 2022-06-24 12:40:34.668164
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie_HitRecord = HitRecordIE()
    assert ie_HitRecord

# Generated at 2022-06-24 12:40:37.304838
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('http://www.hitrecord.org/records/2954362')
    assert isinstance(ie, HitRecordIE)

# Generated at 2022-06-24 12:40:44.748182
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	print("Testing class HitRecordIE")
	# Test 1
	print("Test 1")
	# url = "https://hitrecord.org/records/2954362"
	url = "https://hitrecord.org/records/2954362"
	ie = HitRecordIE()
	assert ie._VALID_URL == 'https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)'
	# Validate the URL
	assert ie._valid_url(url, "HITRECORD") is True

# Generated at 2022-06-24 12:40:46.001395
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    assert hitRecordIE != None

# Generated at 2022-06-24 12:40:49.818406
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.name == 'hitrecord'
    assert ie.description == 'hitrecord.org'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://hitrecord.org/records/2954362/test')

# Generated at 2022-06-24 12:40:50.619189
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('url')

# Generated at 2022-06-24 12:40:51.120865
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE()

# Generated at 2022-06-24 12:40:58.277610
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ie = HitRecordIE()
	assert ie is not None
	assert isinstance(ie, InfoExtractor)
	assert hasattr(ie, '_VALID_URL')
	assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
	assert hasattr(ie, '_TEST')
	assert ie._TEST is not None
	assert isinstance(ie._TEST, dict)

# Generated at 2022-06-24 12:40:59.304655
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE is not None

# Generated at 2022-06-24 12:40:59.869868
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:02.230504
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Create a new instance of HitRecordIE Class
    inst_HitRecordIE = HitRecordIE()

    # Check if the instance created is of type HitRecordIE
    assert isinstance(inst_HitRecordIE, HitRecordIE)

# Generated at 2022-06-24 12:41:03.156997
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-24 12:41:05.686484
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test if the constructor of HitRecordIE can be called
    ie = HitRecordIE()

# Generated at 2022-06-24 12:41:09.102829
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Constructor test. It is implicitly a unit test of HitRecordIE."""
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie.test()

# Generated at 2022-06-24 12:41:09.689058
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:41:10.242995
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:13.747997
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    h = HitRecordIE()
    assert type(h.IE_NAME) == str
    assert type(h.IE_DESC) == str
    assert type(h._VALID_URL) == str
    assert type(h._TEST) == dict
    assert type(h._download_webpage) == types.MethodType

# Generated at 2022-06-24 12:41:14.552911
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:19.448830
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test = HitRecordIE()
    #_VALID_URL is a regular expression with match groups, which should be accessed as if it was a dictionary.
    assert test._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-24 12:41:23.693722
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Direct construction
    ie = HitRecordIE(HitRecordIE._VALID_URL)
    # Indirect construction
    ie = InfoExtractor.ie_key_map[HitRecordIE.ie_key()](HitRecordIE._VALID_URL)
    assert isinstance(ie, HitRecordIE)
    assert ie._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-24 12:41:27.590558
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test for constructor of class HitRecordIE
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie is not None
    assert ie.url == 'https://hitrecord.org/records/2954362'

# Generated at 2022-06-24 12:41:29.130699
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Unit test for constructor of class HitRecordIE"""
    HitRecordIE()

# Generated at 2022-06-24 12:41:29.741470
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:30.719218
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:32.283004
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()
    assert obj._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:41:41.221968
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'HitRecord'
    assert ie.ie_key() == 'HitRecord'
    assert ie.SUCCESS.items() == {'success': True}.items()
    assert ie.FAIL.items() == {'success': False}.items()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:41:42.695804
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    u = "https://hitrecord.org/records/2954362"
    HitRecordIE(u)

# Generated at 2022-06-24 12:41:49.921362
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.name() == 'HITRECORD'
    assert ie.suitable(None) == True
    assert ie.suitable('https://hitrecord.org/records/2954362') == True
    assert ie.suitable('https://hitrecord.org/records/2954362/fake') == False
    assert ie.suitable('https://hitrecord.org/fake') == False
    assert ie.suitable('https://hitrecord.org/') == False



# Generated at 2022-06-24 12:41:51.578417
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    print("Constructor return value: " + str(ie))

# Generated at 2022-06-24 12:41:52.124290
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:55.759837
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert type(ie) == HitRecordIE


# Generated at 2022-06-24 12:41:56.259578
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE()

# Generated at 2022-06-24 12:41:59.304692
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """ Unit test for constructor of class HitRecordIE """
    instance = HitRecordIE()
    assert instance.__class__.__name__ == 'HitRecordIE'

# Generated at 2022-06-24 12:41:59.896389
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:00.910668
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("HitRecordIE")

# Generated at 2022-06-24 12:42:05.727549
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    '''
    # need unit test for this method
    def test_suitable(self, *args):
    '''
    # need unit test for this method
    def test_real_extract(self, *args):
        pass

    # need unit test for this method
    def test_extract_media_file(self, *args):
        pass

# Generated at 2022-06-24 12:42:07.810595
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
        assert True
    except:
        assert False


# Generated at 2022-06-24 12:42:09.294507
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(HitRecordIE._VALID_URL) == HitRecordIE

# Generated at 2022-06-24 12:42:15.544227
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Unit test for constructor of class HitRecordIE
    # It's not working as it requires moving 'youtube_dl/extractor/hitrecord.py' in the path
    hitRecordIE = HitRecordIE();
    assert(hitRecordIE.ie_key() == 'hitrecord')
    assert(hitRecordIE.ie_key() == 'HitRecord')

# Generated at 2022-06-24 12:42:16.240012
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-24 12:42:18.979814
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test that the constructor of the class returns an object
    ie_obj = HitRecordIE('http://www.hitrecord.org/records/2954362')
    assert ie_obj is not None
    # Test that the object is subclass of InfoExtractor
    assert isinstance(ie_obj, InfoExtractor)

# Generated at 2022-06-24 12:42:30.360699
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE({})
    info = ie.extract('https://hitrecord.org/records/2954362')

    assert info['id'] == '2954362'
    assert 'mp4' in info['ext']
    assert info['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert info['description'] == '<b>Soundtrack</b><br />All music composed, arranged, produced, and performed by Joseph Gordon-Levitt.<br /><br /><b>Editors</b><br />Zuzi.C12<br />James.evans'
    assert info['duration'] == 139.327
    assert info['timestamp'] == 1471557582
    assert info['upload_date'] == '20160818'
    assert info['uploader'] == 'Zuzi.C12'


# Generated at 2022-06-24 12:42:31.919916
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:42:34.405068
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.suitable('https://hitrecord.org/records/2954362')
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:42:45.330279
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.get_id_from_url('https://hitrecord.org/records/2954362') == '2954362'
    assert ie.get_id_from_url('https://hitrecord.org/records/2954362/') == '2954362'
    assert ie.get_id_from_url('http://hitrecord.org/records/2954362') == '2954362'
    assert ie.get_id_from_url('http://hitrecord.org/records/2954362/') == '2954362'
    assert ie.get_id_from_url('http://www.hitrecord.org/records/2954362') == '2954362'

# Generated at 2022-06-24 12:42:46.952576
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# Smoke test.
	assert (HitRecordIE(), HitRecordIE)

# Generated at 2022-06-24 12:42:53.041793
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # video_id '2954362' is the number at the end of the test url
    video_id = '2954362'
    # video is an instance of class InfoExtractor
    video = ie.extract(ie._VALID_URL % video_id)
    # testing for one of the dictionary entry in the return dictionary of class InfoExtractor
    assert 'id' in video
    assert video['id'] == video_id

# Generated at 2022-06-24 12:42:56.164754
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video_info = HitRecordIE().get_extractor_info()
    assert video_info._VALID_URL == HitRecordIE._VALID_URL
    assert video_info._TEST == HitRecordIE._TEST

# Generated at 2022-06-24 12:42:56.746059
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:01.689277
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url_test = 'https://hitrecord.org/records/2954362'
    check_1 = HitRecordIE()._real_extract(url_test) # info dictionary
    check_2 = HitRecordIE()._match_id(url_test) # url parameters
    check_3 = HitRecordIE()._download_webpage(url_test) # website pages
    check_4 = HitRecordIE()._download_json(url_test) # json download
    assert check_1 == check_2 == check_3 == check_4

# Generated at 2022-06-24 12:43:04.591578
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('md5:fe1cdc2023bce0bbb95c39c57426aa71', 'https://hitrecord.org/records/2954362', None, None, None)

# Generated at 2022-06-24 12:43:05.976672
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:08.521142
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    test for constructor of class HitRecordIE
    """
    hie = HitRecordIE()
    assert hie.ie_key() == 'HitRecord'

# Generated at 2022-06-24 12:43:18.116775
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    i = HitRecordIE()

    url = 'https://hitrecord.org/records/2954362'
    HitRecordIE._TEST = {'url': url}


# Generated at 2022-06-24 12:43:21.908510
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Unit test: check the constructor, the regular expression of class HitRecordIE
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:43:26.900655
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('hitrecord').new_instance('hitrecord')

    def new_instance(url):
        ie = HitRecordIE(url)
        return ie

    assert new_instance('hitrecord')
    assert not new_instance('http://some_other_website.org')


# Generated at 2022-06-24 12:43:27.497289
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	pass

# Generated at 2022-06-24 12:43:28.086338
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:33.676346
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract(t1['url'])


t1 = {
    'url': 'http://www.hitrecord.org/records/2954362',
    'info_dict': {'id': '2954362'},
    'playlist_mincount': 123,
}

t2 = {
    'url': 'https://www.hitrecord.org/records/2954362',
    'only_matching': True,
}


# Generated at 2022-06-24 12:43:38.121538
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.name == 'hitrecord'
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'hitrecord: https://www.hitrecord.org/'
    assert ie.IE_VERSION == '0.1'

# Generated at 2022-06-24 12:43:40.288571
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('http://hitrecord.org/records/2954362')
    assert not ie.suitable('http://hitrecord.org/')
    test_HitRecordIE()

# Generated at 2022-06-24 12:43:41.880410
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:43:43.958093
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:43:45.404238
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_ie = HitRecordIE()
    assert hitrecord_ie is not None

# Generated at 2022-06-24 12:43:47.304169
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE(InfoExtractor)
    assert info_extractor is not None

# Test for module functions

# Generated at 2022-06-24 12:43:50.340928
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    hitrecord_ie = HitRecordIE()
    hitrecord_ie._real_extract(url)
    assert hitrecord_ie._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-24 12:43:50.793680
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE();

# Generated at 2022-06-24 12:43:52.854318
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:02.711941
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from .common import InfoExtractor
    from ..utils import (
        clean_html,
        float_or_none,
        int_or_none,
        try_get,
    )

    ie = HitRecordIE()
    assert ie.name == "HitRecord"
    assert ie.url == "https://hitrecord.org/records/2954362"
    assert ie.md5 == "fe1cdc2023bce0bbb95c39c57426aa71"


# Generated at 2022-06-24 12:44:03.539451
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    untested = HitRecordIE()

# Generated at 2022-06-24 12:44:13.278749
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test with HitRecordIE from yt-dl test website
    ie = HitRecordIE()

# Generated at 2022-06-24 12:44:14.850499
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'


# Generated at 2022-06-24 12:44:15.254720
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:44:18.874661
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'Videos created by hitrecord.org'
    assert ie.VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie.IE_VERSION == '2018.11.07'

# Generated at 2022-06-24 12:44:20.824668
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test HitRecordIE constructor
    assert isinstance(HitRecordIE('HitRecordIE'), InfoExtractor)


# Generated at 2022-06-24 12:44:22.155928
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("/records/2954362")

# Generated at 2022-06-24 12:44:23.587034
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:44:24.171826
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-24 12:44:26.326780
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Unit test for constructor of class HitRecordIE"""
    class_instance = HitRecordIE()
    assert(class_instance._VALID_URL)

# Generated at 2022-06-24 12:44:27.127480
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:44:35.073046
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, HitRecordIE)
    # Test for download_json() method from InfoExtractor
    vid_1 = ie._download_json('https://hitrecord.org/api/web/records/2954362', '2954362')
    assert vid_1['id'] == 2954362
    # Test for download_json() method from InfoExtractor
    vid_2 = ie._download_json('https://hitrecord.org/api/web/records/2954363', '2954363')
    assert vid_2['id'] == 2954363

# Generated at 2022-06-24 12:44:36.611455
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    i=HitRecordIE()
    assert i is not None

# Generated at 2022-06-24 12:44:43.241961
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_obj = HitRecordIE()
    assert test_obj._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:46.333894
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()
    assert obj._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:49.062111
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()
    assert obj._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:52.609699
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE(None, None, True)
    except:
        assert False, "Unexpected assertion"
    try:
        HitRecordIE(None, None, False)
    except:
        assert True, "Expected assertion"
    try:
        HitRecordIE(None, None, None)
    except:
        assert True, "Expected assertion"

# Generated at 2022-06-24 12:44:55.531021
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == HitRecordIE._VALID_URL
    assert ie._TEST == HitRecordIE._TEST

# Generated at 2022-06-24 12:44:58.778523
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Constructor
    ie = HitRecordIE()

    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'

# Generated at 2022-06-24 12:44:59.851695
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()



# Generated at 2022-06-24 12:45:00.590206
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:45:06.291901
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Check if HitRecordIE is of correct type
    from .common import InfoExtractor
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert isinstance(ie, InfoExtractor)

    # Check if the URL of the page is valid
    assert ie.suitable("https://hitrecord.org/records/2954362") is True
    assert ie.suitable("https://hitrecord.org/records/2954362") is True
    assert ie.suitable("https://hitrecord.org/records/295436") is False

    # Check if the extractor actually can extract data
    # It will be an empty list because the real extraction is done
    # through the _real_extract function, which is tested separately

# Generated at 2022-06-24 12:45:09.057478
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    theHitRecordIE = HitRecordIE()
    theHitRecordIE._VALID_URL = 'https://hitrecord.org/records/2298287'

# Generated at 2022-06-24 12:45:09.921901
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE('hitrecord')

# Generated at 2022-06-24 12:45:12.236553
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://www.hitrecord.org/records/2954362")
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-24 12:45:15.459487
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:45:16.426469
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecordie = HitRecordIE()
    assert hitrecordie.name == 'hitrecord'

# Generated at 2022-06-24 12:45:17.476504
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    InfoExtractor(HitRecordIE._VALID_URL)

# Generated at 2022-06-24 12:45:30.182808
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('', {})

    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

    # Test the _match_id function
    # Should return the video id of the video
    assert ie._match_id('https://hitrecord.org/records/2954362') == '2954362'

    # Test the _download_json function
    # Should return the json data from the provided url
    json_data = ie._download_json('https://hitrecord.org/records/2954362')

    assert json_data['id'] == 2954362
    assert json_data['title'] == 'A Very Different World (HITRECORD x ACLU)'

    # Test the _real_extract function
    # Should return a

# Generated at 2022-06-24 12:45:33.640638
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie.LANG == 'en'

# Generated at 2022-06-24 12:45:36.107568
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url= 'https://hitrecord.org/records/2954362'
    hitrecord = HitRecordIE()
    metadata = hitrecord._real_extract(url)



# Generated at 2022-06-24 12:45:36.740287
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info = HitRecordIE()

# Generated at 2022-06-24 12:45:37.266086
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:45:39.260873
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Simple unit test for constructor of class HitRecordIE.
    """
    ie = HitRecordIE()
    print(ie)

# Generated at 2022-06-24 12:45:40.884447
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    print(hitRecordIE)

# Generated at 2022-06-24 12:45:41.679865
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:45:50.261302
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    expected_id = '2954362'
    actual_id = ie._match_id(ie._TEST['url'])
    assert actual_id == expected_id, "actual_id is %r and expected id is %r" % (actual_id, expected_id)
    expected_ext = 'mp4'
    actual_ext = ie._TEST['info_dict']['ext']
    assert actual_ext == expected_ext, "actual_ext is %r and expected ext is %r" % (actual_ext, expected_ext)

# Generated at 2022-06-24 12:45:52.375853
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'


# Generated at 2022-06-24 12:45:55.488544
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	constructor = HitRecordIE()
	print("Unit test for class HitRecordIE. ")
	print("Input: https://hitrecord.org/records/2954362")
	print("Output: " + str(constructor._real_extract("https://hitrecord.org/records/2954362")))
	print("")

# Generated at 2022-06-24 12:45:57.465629
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:46:08.043149
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.download("https://hitrecord.org/records/2954362")
    ie.download("https://www.hitrecord.org/records/2954362")
    ie.download("https://hitrecord.org/records/2954362?t=2")
    ie.download("https://www.hitrecord.org/records/2954362?t=2")
    ie.download("https://hitrecord.org/records/2954362?t=2&s=3")
    ie.download("https://www.hitrecord.org/records/2954362?t=2&s=3")
    ie.download("https://hitrecord.org/records/2954362?t=2&s=3&e=4")

# Generated at 2022-06-24 12:46:09.783931
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('hi', 'tr', 'org') == HitRecordIE('hi', 'tr', 'org')

# Generated at 2022-06-24 12:46:16.280279
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_ie = HitRecordIE()
    hitrecord_ie._VALID_URL = r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    hitrecord_ie._downloader = None
    hitrecord_ie._download_webpage = lambda x, y: None
    hitrecord_ie._match_id = lambda x: None
    url = "https://hitrecord.org/records/2954362"
    video_id = hitrecord_ie._match_id(url)

# Generated at 2022-06-24 12:46:17.758365
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """test for method HitRecordIE"""
    youtube_ie = HitRecordIE()
    assert youtube_ie != None


# Generated at 2022-06-24 12:46:27.372698
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.get_workflow().is_video_suitable_for_download('https://hitrecord.org/records/2954362')
    assert ie.get_workflow().is_video_suitable_for_download('https://www.hitrecord.org/records/2954362')
    assert not ie.get_workflow().is_video_suitable_for_download('http://www.hitrecord.org/records')
    assert not ie.get_workflow().is_video_suitable_for_download('http://www.hitrecord.org/records/')
    assert not ie.get_workflow().is_video_suitable_for_download('https://hitrecord.org/records/')
    assert not ie.get_workflow().is_video_suitable_

# Generated at 2022-06-24 12:46:28.538011
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    h = HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:46:38.320613
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Sample download
    video_id = '2954362'
    url = 'https://hitrecord.org/records/%s' % video_id
    test = HitRecordIE()._real_extract(url)
    assert test['id'] == video_id
    assert test['url'] == 'https://hitrecord.org/system/files/revisions/000/049/375/original/A_Very_Different_World.mp4'
    assert test['uploader'] == 'Zuzi.C12'
    assert test['title'] == 'A Very Different World (HITRECORD x ACLU)'

    # Different video to test the extractor
    video_id = '2948591'
    url = 'https://hitrecord.org/records/%s' % video_id
    test = HitRecordIE()._real_

# Generated at 2022-06-24 12:46:39.124718
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()


# Generated at 2022-06-24 12:46:44.702143
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Test HitRecordIE constructor."""
    # A new HitRecordIE object
    hitrecord_ie = HitRecordIE('http://www.hitrecord.org/records/2954362')
    # The URL used for this test
    url = 'http://www.hitrecord.org/records/2954362'
    # The expected value
    expected_value = '2954362'
    # Assertion of the result 
    assert hitrecord_ie._match_id(url) == expected_value

# Generated at 2022-06-24 12:46:45.933923
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Test constructor of class HitRecordIE"""
    HitRecordIE()

# Generated at 2022-06-24 12:46:47.515245
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    print(ie)


# Generated at 2022-06-24 12:46:48.014983
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:50.010922
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Test to ensure that class HitRecordIE is working okay
    """
    HitRecordIE()

# Generated at 2022-06-24 12:47:00.558172
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_HitRecordIE = HitRecordIE('https://hitrecord.org/records/2954362')
    assert test_HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:47:06.315145
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    x = HitRecordIE()
    assert x._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert x._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert x._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'