

# Generated at 2022-06-24 12:37:02.343759
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:37:07.178185
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-24 12:37:10.438891
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	from . import HitRecordIE
	from . import InfoExtractor

	assert HitRecordIE.__bases__ == (InfoExtractor,)

# Generated at 2022-06-24 12:37:20.366345
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie.url == "https://hitrecord.org/records/2954362"
    assert ie._TEST['url'] == "https://hitrecord.org/records/2954362"
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie.ext == 'mp4'
    assert ie.title == 'A Very Different World (HITRECORD x ACLU)'
    assert ie.description == 'md5:e62defaffab5075a5277736bead95a3d'
    assert ie.duration == 139.327
    assert ie.timestamp == 1471557582

# Generated at 2022-06-24 12:37:31.017336
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ie = HitRecordIE()
	assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:37:34.037266
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # Testing whether the HitRecordIE() constructor is correct
    assert ie.ie_key() == 'hitrecord'
    # Testing whether the HitRecordIE() constructor generates the correct object
    assert isinstance(ie, HitRecordIE)

# Generated at 2022-06-24 12:37:40.680731
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE().suitable('https://hitrecord.org/records/2954362') is True
    assert HitRecordIE().suitable('https://hitrecord.org/records/') is False
    assert HitRecordIE().suitable('https://hitrecord.org') is False
    assert HitRecordIE().suitable('https://www.youtube.com/watch?v=OoXJz9TY5R0') is False
    assert HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')



# Generated at 2022-06-24 12:37:42.888762
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(None)._VALID_URL == HitRecordIE._VALID_URL
    assert HitRecordIE(None)._TEST == HitRecordIE._TEST

# Generated at 2022-06-24 12:37:43.723859
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    a = HitRecordIE()
    assert a.dispatch

# Generated at 2022-06-24 12:37:45.563787
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    h = HitRecordIE()
    assert h.test_test()
    assert h.test_url()

# Generated at 2022-06-24 12:37:56.546307
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('hitrecord', 'Hit Record')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:37:58.521950
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL is not None
    assert HitRecordIE._TEST is not None
    assert HitRecordIE.__doc__ is not None

# Generated at 2022-06-24 12:38:10.689487
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    youtube_ie = HitRecordIE()
    url = 'https://hitrecord.org/records/2954362'
    info = youtube_ie.extract(url)
    assert info['id'] == '2954362'
    assert info['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert info['description'] == """md5:e62defaffab5075a5277736bead95a3d
""".strip()
    assert info['upload_date'] == '20160818'
    assert info['uploader'] == 'Zuzi.C12'
    assert info['uploader_id'] == '362811'
    assert info['view_count'] > 50000
    assert info['like_count'] > 2000
    assert info['comment_count'] > 0
    assert info['tags']

# Generated at 2022-06-24 12:38:12.853740
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:14.582241
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Basic test for HitRecordIE
    """
    return HitRecordIE()

# Generated at 2022-06-24 12:38:18.504610
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Arrange
    url = 'https://hitrecord.org/records/2954362'
    # Act
    HitRecordIE.__init__()
    # Assert

# Generated at 2022-06-24 12:38:29.086918
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)

    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-24 12:38:29.739472
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	pass
	#assert(True)

# Generated at 2022-06-24 12:38:39.755293
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:40.854855
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL

# Generated at 2022-06-24 12:38:42.530778
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	this_object = HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:38:43.513907
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    i = HitRecordIE()
    assert i


# Generated at 2022-06-24 12:38:50.832015
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:52.169973
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test = HitRecordIE()
    assert test._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:54.350450
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
        assert False
    except TypeError as e:
        assert "Can't instantiate abstract class" in str(e)

# Generated at 2022-06-24 12:38:55.943098
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:38:57.165675
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
        HitRecordIE(HitRecordIE._VALID_URL, HitRecordIE._TEST)

# Generated at 2022-06-24 12:38:59.319456
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:59.790665
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:02.380807
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
# Create instance of class HitRecordIE
    test_object = HitRecordIE()
    assert test_object.Test() == True

# Generated at 2022-06-24 12:39:03.310684
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('HitRecord')

# Generated at 2022-06-24 12:39:04.597262
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('HitRecord')
    print(ie)

# Generated at 2022-06-24 12:39:05.899604
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()
    assert HitRecordIE()._VALID_URL

# Generated at 2022-06-24 12:39:07.639530
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("HitRecordIE", "https://hitrecord.org/records/2954362")
    return

# Generated at 2022-06-24 12:39:08.577630
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE({})
    pass

# Generated at 2022-06-24 12:39:12.389087
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie.get_id('https://hitrecord.org/records/2954362') == '2954362'

# Generated at 2022-06-24 12:39:23.066855
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert(HitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-24 12:39:23.618667
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:25.976399
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    d = HitRecordIE()
    assert d.suitable('https://hitrecord.org/records/2954362')
    assert not d.suitable('https://hitrecord.org/records')


# Generated at 2022-06-24 12:39:38.332269
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    s = HitRecordIE()
    # Testing __init__ and this case will not pass
    #assert s.name == 'hitrecord'

    # Testing _VALID_URL
    url = 'https://hitrecord.org/records/2954362'
    assert s._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert s._match_id(url) == '2954362'

    # Testing _extract_formats
    video = 'https://hitrecord.org/records/2954362'

# Generated at 2022-06-24 12:39:38.870424
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:47.773768
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:39:48.635976
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:39:49.931880
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE().extract

# Generated at 2022-06-24 12:39:50.897698
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
     test_HitRecordIE = HitRecordIE()

# Generated at 2022-06-24 12:39:59.221027
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    IE = HitRecordIE("https://hitrecord.org/records/2954362")
    assert (IE.search_regex("https://hitrecord.org/records/2954362", IE.regex_id) == "2954362")
    assert (IE.extract("https://hitrecord.org/records/2954362")['timestamp'] == 1471557582)
    assert (IE.extract("https://hitrecord.org/records/2954362")['uploader'] == 'Zuzi.C12')
    assert (IE.extract("https://hitrecord.org/records/2954362")['description'] == '<p>A Very Different World <br></p>')

# Generated at 2022-06-24 12:39:59.858253
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    y = HitRecordIE()


# Generated at 2022-06-24 12:40:00.961069
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Test to instantiate class HitRecordIE
    """
    HitRecordIE(HitRecordIE._VALID_URL)

# Generated at 2022-06-24 12:40:01.370622
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:40:03.822108
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie.extract()
    assert ie.re_match()

# Generated at 2022-06-24 12:40:04.431134
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:40:14.799451
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    assert hitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:16.489885
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL


# Generated at 2022-06-24 12:40:25.958686
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    h = HitRecordIE("https://hitrecord.org/records/2954362")
    print("Test test_HitRecordIE() -> ")
    print(" h.md5: " + h.md5)
    print(" h.url: " + h.url)
    print(" h.id: " + h.id)
    print(" h.info: " + str(h.info))
    print(" h.video_url: " + h.video_url)
    print(" h.video_id: " + h.video_id)
    print(" h.title: " + h.title)
    print(" h.description: " + h.description)
    print(" h.duration: " + str(h.duration))
    print(" h.timestamp: " + str(h.timestamp))

# Generated at 2022-06-24 12:40:27.148457
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record = HitRecordIE()
    assert hit_record

# Generated at 2022-06-24 12:40:27.992185
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-24 12:40:28.504393
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE

# Generated at 2022-06-24 12:40:29.093666
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(HitRecordIE._VALID_URL)

# Generated at 2022-06-24 12:40:30.529534
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('hitrecord.org')
    assert ie._VALID_URL is HitRecordIE._VALID_URL
    assert ie._TEST is HitRecordIE._TEST


# Generated at 2022-06-24 12:40:33.484249
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print('Testing constructor of class HitRecordIE')
    hitrecord = HitRecordIE()
    assert type(hitrecord) == HitRecordIE
    assert hitrecord.ie_key() == 'hitrecord'
    assert hitrecord.server() == 'hitrecord'
    assert hitrecord.content_type() == 'Video'

# Generated at 2022-06-24 12:40:35.806203
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('HitRecord', 'https://hitrecord.org/records/2954362')
    pass

# Generated at 2022-06-24 12:40:42.549705
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	from ..compat import compat_str
	from ..utils import (
    	clean_html,
    	float_or_none,
    	int_or_none,
    	try_get,
	)
	hitrecord = HitRecordIE()

	video_id = hitrecord._match_id('https://hitrecord.org/records/2954362')
	print (video_id)
	assert(video_id == '2954362')

	video = hitrecord._download_json(
		'https://hitrecord.org/api/web/records/%s' % video_id, video_id)
	assert(video['user']['username'] == 'Zuzi.C12')

# Generated at 2022-06-24 12:40:45.129588
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:40:46.045290
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    o = HitRecordIE()

# Generated at 2022-06-24 12:40:46.974709
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test = HitRecordIE()

# Generated at 2022-06-24 12:40:48.348624
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('HitRecord', '2954362')
    assert ie.extractor_key == 'HitRecord'
    assert ie.video_id == '2954362'

# Generated at 2022-06-24 12:40:49.174842
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:00.420330
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
     Test constructor of class HitRecordIE
    """
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:41:02.320521
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://www.hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:41:03.979593
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_ie = HitRecordIE()
    assert hitrecord_ie

# Generated at 2022-06-24 12:41:07.252525
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE('hitrecord', 'hitrecord.org') == HitRecordIE('hitrecord', 'www.hitrecord.org')

# Generated at 2022-06-24 12:41:12.556242
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362', 'test')
    assert isinstance(ie, HitRecordIE)
    assert ie.VALID_URL == ie._VALID_URL
    assert ie.TEST == ie._TEST
    assert ie.IE_NAME == ie._IE_NAME
    assert ie.IE_DESC == ie._IE_DESC
    assert ie.BROWSER == ie._BROWSER

# Generated at 2022-06-24 12:41:13.732617
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(HitRecordIE._downloader).ie_key() == 'hitrecord'

# Generated at 2022-06-24 12:41:22.024043
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(HitRecordIE._TEST)
    # Check that the URL provided in _TEST is the same as the one extracted by url_result
    url_result = ie.url_result(HitRecordIE._TEST['url'])
    assert url_result['url'] == HitRecordIE._TEST['url']
    # Check that the id extracted by _real_extract is the same as provided in the url
    url_result = ie.extract(HitRecordIE._TEST['url'])
    assert url_result['id'] == HitRecordIE._match_id(HitRecordIE._TEST['url'])

# Generated at 2022-06-24 12:41:29.542319
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # will get the url and its title
    url = 'http://hitrecord.org/records/2954362'
    h = HitRecordIE(url)
    assert h.url == url
    assert h.title == 'A Very Different World (HITRECORD x ACLU)'

    # will get the url and its title
    url = 'http://www.hitrecord.org/records/2954362'
    h = HitRecordIE(url)
    assert h.url == url
    assert h.title == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:41:33.282544
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:41:35.144367
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Should be a subclass of InfoExtractor
    assert issubclass(InfoExtractor, HitRecordIE)


# Generated at 2022-06-24 12:41:41.245438
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:41:41.982311
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-24 12:41:42.532873
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:43.428183
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:45.259087
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("hitrecord.org/records")

# Generated at 2022-06-24 12:41:47.183087
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE(None)
    except Exception as e:
        assert(e.__str__() == "arg 'self' may not be None")



# Generated at 2022-06-24 12:41:48.507151
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    assert HitRecordIE('https://hitrecord.org/records/2954362') is not None

# Generated at 2022-06-24 12:41:49.737480
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract("https://hitrecord.org/records/2954362")


# Generated at 2022-06-24 12:41:50.280813
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:59.963578
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test a URL of a record in HitRecord.org
    site = HitRecordIE()
    query = site.extract('https://hitrecord.org/records/2954362')
    assert query['id'] == '2954362'
    assert query['url'] == 'https://hitrecord-production-assets.s3.amazonaws.com/uploads/record/source_url/492357/hitrecord_132.mp4'
    assert query['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert query['description'] == '<p>We asked you to create something that reflects on a world that is different for people of color, for LGBTQ people, for immigrants, for women, for people with disabilities, and for religious minorities.</p>'
    assert query['duration'] == 139.327
    assert query['timestamp'] == 147

# Generated at 2022-06-24 12:42:08.745287
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL
    assert HitRecordIE._TEST
    assert HitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:42:14.504544
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('http://www.hitrecord.org/records/2954362')
    ie._real_extract('http://www.hitrecord.org/records/2954362')
    ie.playlist_from_matches('http://www.hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:42:15.020756
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:19.914889
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.suitable('http://hitrecord.org/records/2953495') == True
    assert HitRecordIE.suitable('http://hitrecord.org/records/3') == True
    assert HitRecordIE.suitable('http://hitrecord.org/records/543') == True
    assert HitRecordIE.suitable('http://hitrecord.org/records/2214') == True
    assert HitRecordIE.suitable('http://hitrecord.org/records/8765') == True
    assert HitRecordIE.suitable('http://hitrecord.org/records/14689') == True
    assert HitRecordIE.suitable('http://hitrecord.org/records/4132') == True
    assert HitRecordIE.suitable('http://hitrecord.org/records/7426') == True

# Generated at 2022-06-24 12:42:21.432442
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:24.026786
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(1)
    assert ie.get_id() == 1
    assert ie.get_url() == 'https://hitrecord.org/records/1'

# Generated at 2022-06-24 12:42:25.336609
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:42:34.723917
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Setup some test variables
    url = 'https://hitrecord.org/records/3253064'
    # Create object
    hitrecord = HitRecordIE()
    # Test object type
    assert(type(hitrecord) == HitRecordIE)
    # Assert that the ID has been set correctly
    assert(hitrecord._match_id(url) == '3253064')
    # Assert that a valid URL matches the URL pattern
    assert(hitrecord._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')
    #Assert that the JSON API is being used correctly

# Generated at 2022-06-24 12:42:37.536022
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('http://hitrecord.org/records/2954362')
    assert 'HitRecord' in str(ie)

# Generated at 2022-06-24 12:42:40.598005
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('HitRecordIE')._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:42:45.056831
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'
    assert ie.ie_key(url='https://hitrecord.org/records/2954362') == 'HitRecord'
    assert ie.ie_key(url='https://www.hitrecord.org/records/2954362') == 'HitRecord'

# Generated at 2022-06-24 12:42:45.649026
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
   HitRecordIE()

# Generated at 2022-06-24 12:42:48.279235
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ie = HitRecordIE()
	assert ie is not None 

if __name__ == '__main__':
	test_HitRecordIE()

# Generated at 2022-06-24 12:42:49.163124
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # This constructor is not called directly
    pass

# Generated at 2022-06-24 12:42:50.538608
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-24 12:43:00.238285
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from .common import t, assertEquals
    from .common import make_absolute_url
    from .common import HitRecordIE
    from .common import InfoExtractor
    from . import yt_subtitles_extractor
    #import inspect
    #print(''.join(inspect.getsourcelines(HitRecordIE)[0]))

    #print HitRecordIE._VALID_URL
    # HitRecordIE._VALID_URL is a string, it's a regular expression, refer to
    # https://docs.python.org/2/library/re.html
    #print InfoExtractor._VALID_URL
    # InfoExtractor._VALID_URL is an instance of re._pattern_type
    #print HitRecordIE._TESTS
    # HitRecordIE._TESTS is a class 'dict'
    #print type(Hit

# Generated at 2022-06-24 12:43:01.294971
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # For unit test
    h = HitRecordIE('')
    assert h

# Generated at 2022-06-24 12:43:02.838549
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie is not None

# Generated at 2022-06-24 12:43:04.148804
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362', {})

# Generated at 2022-06-24 12:43:05.879340
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Create an object for HitRecordIE"""
    assert HitRecordIE()

# Generated at 2022-06-24 12:43:12.587004
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from .common import InfoExtractor
    from .youtube import YouTubeIE
    assert HitRecordIE.suitable('https://hitrecord.org/records/2954362')
    assert not HitRecordIE.suitable('https://youtube.com/records/2954362')
    assert not HitRecordIE.suitable('https://hitrecord.org/records/29543621')
    assert InfoExtractor.get_info_extractor('https://hitrecord.org/records/2954362') is YoutubeIE

# Generated at 2022-06-24 12:43:14.127412
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    print(ie._VALID_URL)

# Generated at 2022-06-24 12:43:21.155041
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert ie._TEST['info_dict']['duration'] == 139.327
    assert ie._TEST['info_dict']['timestamp'] == 1471557582


# Generated at 2022-06-24 12:43:26.474154
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  from HitRecordIE import HitRecordIE
  ie = HitRecordIE()
  res = ie.extract('https://hitrecord.org/records/2954362')
  assert (res['title'] == 'A Very Different World (HITRECORD x ACLU)')
  assert (res['uploader'] == 'Zuzi.C12')

# Generated at 2022-06-24 12:43:27.594569
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.Suite()

# Generated at 2022-06-24 12:43:28.895865
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:43:29.306649
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:43:31.567096
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie._VALID_URL == ie.VALID_URL


# Generated at 2022-06-24 12:43:32.760846
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Create a new HitRecordIE instance
    hitrecordIE = HitRecordIE()

# Generated at 2022-06-24 12:43:34.698383
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:43:35.589035
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE()._VALID_URL

# Generated at 2022-06-24 12:43:38.121198
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    constructor_test(HitRecordIE, {'url': 'https://hitrecord.org/records/2954362'})



# Generated at 2022-06-24 12:43:45.446602
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test case using a HitRecordIE instance
    hitrecord_ie1 = HitRecordIE("https://hitrecord.org/records/2954362")
    # Assert that the pattern matches with the URL to be tested
    assert hitrecord_ie1._match_id("https://hitrecord.org/records/2954362") == "2954362"
    # Assert the URL prefix
    assert hitrecord_ie1._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"


# Generated at 2022-06-24 12:43:47.178929
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        hitrecord = HitRecordIE()
        print(hitrecord)
        assert(True)
    except:
        assert(False)


# Generated at 2022-06-24 12:43:55.426327
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.__name__ == "HitRecord"
    assert ie.ie_key() == "HitRecord"
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:00.078557
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# Create instance
	hitrecord_ie = HitRecordIE()
	# Get its MD5
	hitrecord_ie_md5 = hitrecord_ie.ie_key()
	# Compare its MD5
	assert(hitrecord_ie_md5 == '5e56ae4a1f4dc769e8c9aa9f1753c73a')

# Generated at 2022-06-24 12:44:00.981730
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	return HitRecordIE(InfoExtractor())

# Generated at 2022-06-24 12:44:03.267117
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        unit = HitRecordIE()
    except:
        print("Failed to init HitRecordIE")
        sys.exit(1)
    assert(unit is not None)

# Generated at 2022-06-24 12:44:07.380525
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    assert ie.match_url('http://hitrecord.org/records/2954362')
    assert ie.match_url('https://hitrecord.org/records/2954362')
    assert not ie.match_url('https://www.hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:44:16.769150
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Set up for unit test
    hitrecordtest = HitRecordIE()
    hitrecordtest._real_extract('https://www.hitrecord.org/records/4430')
    assert hitrecordtest._match_id == '4430'
    assert hitrecordtest._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:19.688347
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()
    assert obj.get_url_re()
    assert obj.get_id_re()
    assert obj.extractor_key() == 'hitrecord'
    assert obj.get_url_type() == 'info'

# Generated at 2022-06-24 12:44:21.617375
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:44:32.170630
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  print("Testing constructor HitRecordIE()...")
  url = "https://hitrecord.org/records/2954362"
  ie = HitRecordIE(url)
  assert(ie.url == url)

  print("Testing function extract()...")
  info = ie.extract()
  assert(info['id'] == '2954362')
  assert(info['url'] == 'https://d2pq0u4uni88oo.cloudfront.net/videos/2954362/b5df5f5e5b7c8eaff323.mp4')
  assert(info['title'] == 'A Very Different World (HITRECORD x ACLU)')

# Generated at 2022-06-24 12:44:32.819517
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:44:34.868679
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract("https://hitrecord.org/records/2954362")
    ie.download("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:44:39.064115
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('Launchpad_test')
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'hitrecord'
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST

# Generated at 2022-06-24 12:44:41.106881
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  ie = HitRecordIE()
  print (ie._TEST)

if __name__ == '__main__':
  test_HitRecordIE()

# Generated at 2022-06-24 12:44:47.675138
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'HitRecord'
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-24 12:44:50.694144
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert hasattr(ie, '_download_json')
    assert hasattr(ie, '_match_id')
    assert hasattr(ie, '_real_extract')


# Generated at 2022-06-24 12:44:52.169088
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'

# Generated at 2022-06-24 12:44:53.891153
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:44:55.591356
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test class creation
    ie = HitRecordIE()
    assert(ie is not None)

# Generated at 2022-06-24 12:44:57.811639
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._match_id('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:44:59.852281
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = "https://hitrecord.org/records/42"
    _ = HitRecordIE(url)

# Generated at 2022-06-24 12:45:01.640235
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'



# Generated at 2022-06-24 12:45:10.503715
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    obj = HitRecordIE(url)
    assert obj._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert obj._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert obj._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert obj._TEST['info_dict']
    assert obj._TEST['info_dict']['id'] == '2954362'
    assert obj._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 12:45:12.531857
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE._download_json('https://hitrecord.org/api/web/records/2954362', '2954362')

# Generated at 2022-06-24 12:45:17.426020
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    '''
    Basic unit test where we create an instance of the HitRecordIE class to be able to call the _real_extract method.
    '''
    HitRecordIE()._real_extract(
        'https://hitrecord.org/records/2954362')

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:45:18.156533
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:45:18.714448
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:45:20.931224
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:45:22.047472
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()
    return 0


# Generated at 2022-06-24 12:45:24.559589
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Minimal unit test for the class HitRecordIE.
    """

    HitRecordIE()

# Generated at 2022-06-24 12:45:26.005066
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecIE = HitRecordIE()
    assert hitrecIE is not None

# Generated at 2022-06-24 12:45:30.713333
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    import inspect
    import pdb

    frame = inspect.currentframe()
    pdb.set_trace()
    assert frame.f_lineno == 15
    frame = frame.f_back
    count = 0
    while frame is not None:
        count += 1
        frame = frame.f_back
    assert count == 2


# Generated at 2022-06-24 12:45:39.105318
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    result = HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:45:42.609340
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert 'hitrecord.org' in ie._VALID_URL
    assert 'hitrecord.org' in ie._downloader.IE_NAME

# Generated at 2022-06-24 12:45:46.900546
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # A testing function for the HitRecordIE class.
    # The testing code for the class is in a separate
    # function so that it won't be run when the class
    # isn't used.
    ie = HitRecordIE()
    ie.suite()

# Generated at 2022-06-24 12:45:48.366713
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:45:49.315756
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE() is not None

# Generated at 2022-06-24 12:45:50.983572
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE(1)
    obj.to_screen(obj.get_id())

# Generated at 2022-06-24 12:45:52.377897
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-24 12:45:52.970596
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:45:53.432737
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:45:57.361101
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    assert ie.ie_key() == "HitRecord"
    assert ie.suitable("https://hitrecord.org/records/2954362")
    assert ie.suitable("https://www.hitrecord.org/records/2954362")
    assert not ie.suitable("http://youtube.com/watch?v=dQw4w9WgXcQ")

# Generated at 2022-06-24 12:45:58.153302
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.download()

# Generated at 2022-06-24 12:45:59.377420
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()
    pass

# Generated at 2022-06-24 12:46:00.311594
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE.suite()

# Generated at 2022-06-24 12:46:07.522540
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Test function for class HitRecordIE"""
    # Create an instance of class HitRecordIE
    hitrecordie = HitRecordIE()

    # Test video_id extraction
    video_id = hitrecordie._match_id('https://hitrecord.org/records/2954362')
    assert '2954362' == video_id
    video_id = hitrecordie._match_id('http://www.hitrecord.org/records/2954362')
    assert '2954362' == video_id

# Generated at 2022-06-24 12:46:14.636549
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # pylint: disable=protected-access
    url = 'https://hitrecord.org/records/2954362'
    hit_record_ie = HitRecordIE._build_ie(url)
    assert isinstance(hit_record_ie, HitRecordIE)
    assert hit_record_ie.IE_NAME == 'hitrecord'
    assert hit_record_ie.ie._VALID_URL == HitRecordIE._VALID_URL
    assert hit_record_ie._TESTS == [HitRecordIE._TEST]
    assert hit_record_ie._download_webpage
    assert hit_record_ie._download_json

# Generated at 2022-06-24 12:46:15.829412
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-24 12:46:25.501247
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:46:35.182476
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._VALID_URL = 'http://hitrecord.org/records/1234567'

# Generated at 2022-06-24 12:46:37.720485
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    For now, this test will make sure it doesn't throw an exception
    """
    HitRecordIE.suitable('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:46:38.201117
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HitRecordIE()

# Generated at 2022-06-24 12:46:39.056818
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video = HitRecordIE()
    assert video



# Generated at 2022-06-24 12:46:39.618120
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:40.800813
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('test')

# Test for the function test_HitRecordIE

# Generated at 2022-06-24 12:46:41.684114
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie

# Generated at 2022-06-24 12:46:43.937769
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:46:46.102338
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('')._VALID_URL == 'https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)'

# Generated at 2022-06-24 12:46:49.760189
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ie = HitRecordIE('hitrecord')
	# Check that given an input string, it matches the correct custom URL
	assert(ie._VALID_URL == ie._match_id('https://hitrecord.org/records/2954362'))
	# Check that an empty string does not match the regex
	assert(None == ie._match_id('https://google.com/records/2954362'))
	return

# Generated at 2022-06-24 12:46:54.427796
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    _TestHitRecordIE = HitRecordIE()
    assert type(_TestHitRecordIE) == HitRecordIE
    assert _TestHitRecordIE.url_result('https://hitrecord.org/records/2954362').get('ie_key', None) == 'HitRecord'

# Generated at 2022-06-24 12:46:57.579997
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()

    # assertIsInstance(instance, InfoExtractor)
    # assertEqual(instance.ie_key(), 'HitRecord')
    print("Success: HitRecordIE constructor")


# Generated at 2022-06-24 12:46:57.956146
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:47:00.835295
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
   assert HitRecordIE(None)._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-24 12:47:02.264130
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    print(ie.ie_key())