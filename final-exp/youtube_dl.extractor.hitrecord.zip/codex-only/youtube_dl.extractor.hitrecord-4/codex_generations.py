

# Generated at 2022-06-24 12:37:13.190923
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    input_data = [{'url': 'https://hitrecord.org/records/2972427'}]
    output_data = HitRecordIE()._call_extractor(input_data)
    assert len(output_data) == 1
    assert output_data[0]['id'] == '2972427'
    assert output_data[0]['uploader_id'] == '468844'
    assert output_data[0]['title'] == 'The Revolution Starts Here'
    assert output_data[0]['comment_count'] == 1
    assert output_data[0]['like_count'] == 1
    assert output_data[0]['view_count'] == 18
    assert output_data[0]['tags'] == ['TEDxBeaconStreet', 'HITRECORD', 'TEDx']
    assert output_

# Generated at 2022-06-24 12:37:18.719406
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie.extract("https://hitrecord.org/records/2954362")
    assert len(ie.extract("https://hitrecord.org/records/2954362")) == 17
    assert ie.extract("https://hitrecord.org/records/2954362").get("id") == "2954362"

# Generated at 2022-06-24 12:37:19.141698
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-24 12:37:20.727770
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert(HitRecordIE("https://hitrecord.org/records/2954362") != None)

# Generated at 2022-06-24 12:37:29.529748
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    import os
    print('\nTesting constructor of class HitRecordIE ...')

    # Test with an id, not a url
    video_id_test = '2954362'
    hi = HitRecordIE(video_id_test, file_md5=None)
    assert hi.get_id() == video_id_test

    # Test with an url
    url_test = 'https://hitrecord.org/records/2954362'
    hi = HitRecordIE(url_test, file_md5=None)
    assert hi.get_id() == video_id_test



# Generated at 2022-06-24 12:37:34.766286
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# main()
if __name__ == "__main__":
    extraction = HitRecordIE()
    extraction.extract('https://hitrecord.org/records/2954362')
    extraction.print_json()

# Generated at 2022-06-24 12:37:43.344405
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # First test with a valid and existing url as input
    ie = HitRecordIE(None)
    test_url = HitRecordIE._TEST['url']
    expected_id = HitRecordIE._TEST['info_dict']['id']
    expected_title = HitRecordIE._TEST['info_dict']['title']
    expected_url = HitRecordIE._TEST['info_dict']['url']
    expected_duration = HitRecordIE._TEST['info_dict']['duration']
    expected_upload_date = HitRecordIE._TEST['info_dict']['upload_date']

    result = ie._real_extract(test_url)

    assert result['id'] == expected_id
    assert result['title'] == expected_title
    assert result['url'] == expected_url

# Generated at 2022-06-24 12:37:45.821475
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    tryit = HitRecordIE()
    print("\ntest construct of HitRecordIE:")
    print("\t" + tryit.__class__.__name__)


# Generated at 2022-06-24 12:37:46.375805
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:37:47.277212
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:37:54.574219
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
        ie = HitRecordIE()
        assert ie.ie_key() == 'HitRecord', ie.ie_key()
        assert ie.ie_name() == 'HitRecord', ie.ie_key()
        assert ie.valid_url('http://www.hitrecord.org/records/2954362')
        assert ie.valid_url('https://hitrecord.org/records/2954362')
        assert not ie.valid_url('http://www.youtube.com/user/hitRECord')

# Generated at 2022-06-24 12:37:57.685343
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # sample unit test on the constructor of this class
    assert hasattr(HitRecordIE, '_VALID_URL')
    assert hasattr(HitRecordIE, '_TEST')
    assert hasattr(HitRecordIE, '_real_extract')

# Generated at 2022-06-24 12:38:01.201341
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:02.797409
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'

# Generated at 2022-06-24 12:38:03.434509
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:09.891751
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Part 1: Test without url
    ie = HitRecordIE()
    assert ie.url is None
    assert ie._VALID_URL is None
    # Part 2: Test with url
    ie.url = "some url"
    assert ie.url == "some url"
    assert ie._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"


# Generated at 2022-06-24 12:38:13.938856
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    Video = ie.extract('https://hitrecord.org/records/2954362')
    assert Video['id'] == '2954362'
    assert Video['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert Video['tags'][2] == 'film'
    assert Video['duration'] == 139.327

# Generated at 2022-06-24 12:38:14.492802
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-24 12:38:16.247365
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE._TEST

# Generated at 2022-06-24 12:38:19.072280
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:38:20.919822
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Test if HitRecordIE is a valid InfoExtractor.
    """
    HitRecordIE()

# Generated at 2022-06-24 12:38:31.149841
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ie = HitRecordIE('7')
	assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:35.605660
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    #test_urls = ['https://hitrecord.org/records/2954362']
    test_urls = ['https://hitrecord.org/records/2954362']
    ies = HitRecordIE()
    for url in test_urls:
        print(ies.suitable(url))

# Generated at 2022-06-24 12:38:38.238143
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL=='https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:41.432693
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_HitRecordIE = HitRecordIE()
    assert test_HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-24 12:38:42.031750
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:42.798077
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie)

# Generated at 2022-06-24 12:38:43.483222
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-24 12:38:49.659161
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	watch = HitRecordIE('https://hitrecord.org/records/2954362')
	assert watch.url == 'https://hitrecord.org/records/2954362'
	assert watch.video_id == '2954362'
	assert type(watch.title()) == str
	assert type(watch.description()) == str
	assert type(watch.duration()) == float
	assert type(watch.timestamp()) == int
	assert type(watch.uploader()) == str
	assert type(watch.uploader_id()) == str
	assert type(watch.view_count()) == int
	assert type(watch.like_count()) == int
	assert type(watch.comment_count()) == int
	assert type(watch.tags()) == list

# Generated at 2022-06-24 12:38:51.578401
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE();
    ie.extract('https://hitrecord.org/records/2954362');

# Generated at 2022-06-24 12:39:00.167979
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    infoIE = HitRecordIE()
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:39:05.343727
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    video_id = '2954362'
    url = 'https://hitrecord.org/records/2954362'
    expected_url = 'https://hitrecord.org/records/2954362'
    assert ie.match_url(url) == expected_url
    assert ie._match_id(url) == video_id

# Generated at 2022-06-24 12:39:05.945448
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:13.019263
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video_id = '1234567'
    HitRecordIE(HitRecordIE._VALID_URL)
    assert HitRecordIE._match_id(HitRecordIE._VALID_URL) == video_id
    assert HitRecordIE._download_json(
        'https://hitrecord.org/api/web/records/%s' % video_id, video_id)
    assert HitRecordIE._extract_urls(HitRecordIE._VALID_URL) == [HitRecordIE._VALID_URL]

# Generated at 2022-06-24 12:39:15.088006
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-24 12:39:15.650328
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:18.584358
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	try:
		ie = HitRecordIE()
	except Exception as e:
		print('Caught exception: ' + str(e))
	else:
		print('Such exception is never raised')
		assert 0


# Generated at 2022-06-24 12:39:19.286937
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:20.066570
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()
    pass

# Generated at 2022-06-24 12:39:21.117199
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    result = HitRecordIE()
    print(result)

# Generated at 2022-06-24 12:39:22.372639
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie != None


# Generated at 2022-06-24 12:39:24.897439
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.get_ie_key() == 'hitrecord'
    assert HitRecordIE.suitable('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:39:26.257324
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:39:29.299914
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE._TEST = {}
    assert hasattr(HitRecordIE, '_TEST')

# Generated at 2022-06-24 12:39:30.955155
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrec = HitRecordIE()
    assert(hitrec is not None)

# Generated at 2022-06-24 12:39:34.260539
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.name == 'hitrecord'
    assert ie.ie_key() == 'hitrecord'
    assert ie.get_default_suitable_test() == (True, None)

# Generated at 2022-06-24 12:39:38.282668
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    # print(instance)
    # print(instance._download_webpage(instance.url))
    instance._download_webpage(instance.url)
    # print("{}".format(instance._download_webpage(instance.url)))

# Generated at 2022-06-24 12:39:39.173309
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    pass

# Generated at 2022-06-24 12:39:42.035918
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_instance = HitRecordIE()
    assert test_instance._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:39:42.629818
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:43.957282
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:39:46.267088
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
        print("Passed constructor test of class HitRecordIE")
    except Exception as e:
        print("Failed constructor test of class HitRecordIE")


# Generated at 2022-06-24 12:39:48.536166
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:39:49.837332
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print(HitRecordIE())

# Generated at 2022-06-24 12:39:50.443793
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:59.183931
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video_id = '2954362'
    url = 'https://www.hitrecord.org/records/%s' % video_id
    test_obj = HitRecordIE()
    test_obj.suitable('https://www.hitrecord.org/records/2954362')
    id = test_obj._match_id('https://www.hitrecord.org/records/2954362')
    assert(id == video_id)
    assert(test_obj._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')
    assert(test_obj._TEST['url'] == url)
    assert(test_obj._TEST['id'] == video_id)

# Generated at 2022-06-24 12:39:59.829955
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert test_HitRecordIE()

# Generated at 2022-06-24 12:40:00.237674
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:40:02.627185
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    unit = HitRecordIE(None)
    assert unit._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert unit._TEST['url'] == 'https://hitrecord.org/records/2954362'




# Generated at 2022-06-24 12:40:04.083894
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:40:07.025743
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print("test_HitRecordIE\n")
    # This is a test of the HitRecords class constructor
    HitRecordIE()
    return True


# Generated at 2022-06-24 12:40:08.475820
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:40:09.820070
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:40:16.119599
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_HitRecordIE = HitRecordIE()
    assert test_HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert test_HitRecordIE._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert test_HitRecordIE._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-24 12:40:17.835458
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:40:19.485600
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print("Test of HitRecordIE class constructor")
    HitRecordIE()

# Generated at 2022-06-24 12:40:21.521611
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract(HitRecordIE._TEST['url'])
    assert ie._VALID_URL

# Generated at 2022-06-24 12:40:23.862750
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie.url == "https://hitrecord.org/records/2954362"

# Generated at 2022-06-24 12:40:24.636384
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Tests for methods and functions
    pass

# Generated at 2022-06-24 12:40:25.740605
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:40:32.526696
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    class_inst = HitRecordIE("https://hitrecord.org/records/2954362")
    assert class_inst._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:36.659843
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'
    assert ie.playlist_result_key() == 'entries'
    assert ie.ie_key() == HitRecordIE.ie_key(ie)

# Generated at 2022-06-24 12:40:47.241617
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:47.941622
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'

# Generated at 2022-06-24 12:40:49.392995
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = "https://www.youtube.com"
    HitRecordIE(url)

# Generated at 2022-06-24 12:40:54.151739
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    item = HitRecordIE()
    assert item.ie_key() == 'HitRecord'
    assert item.suitable('https://hitrecord.org/records/2954362')
    assert item.get_info('https://hitrecord.org/records/2954362')['id'] == '2954362'

# Generated at 2022-06-24 12:40:55.604344
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except:
        assert False

# Generated at 2022-06-24 12:40:58.076745
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-24 12:41:00.161879
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie = HitRecordIE()
    ie = HitRecordIE()
    ie = HitRecordIE()

# Generated at 2022-06-24 12:41:00.752605
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:01.956982
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'

# Generated at 2022-06-24 12:41:06.169233
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie.legal_urls(ie.IE_NAME, "https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:41:14.985727
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print("Testing HitRecordIE constructor")

# Generated at 2022-06-24 12:41:18.785878
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    instance._match_id(url=HitRecordIE._TEST['url'])
    instance._download_json(url=HitRecordIE._TEST['url'] + '/api/web/records/')

# Generated at 2022-06-24 12:41:23.950228
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test constructor of class HitRecordIE
    ie = HitRecordIE()
    # Test _VALID_URL
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

    # Test _REAL_EXTARCT
    valid_url = 'https://hitrecord.org/records/2954362'

# Generated at 2022-06-24 12:41:26.888131
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE(): 
    ie = HitRecordIE() 
    assert isinstance(ie, InfoExtractor)
    
# Test the video title and url of the video 2954362

# Generated at 2022-06-24 12:41:27.494575
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE()

# Generated at 2022-06-24 12:41:28.213872
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:29.634031
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('HitRecordIE', 'hitrecord.org')

# Generated at 2022-06-24 12:41:36.178527
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert HitRecordIE()._TEST['url']== 'https://hitrecord.org/records/2954362'
    assert HitRecordIE()._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'


# Generated at 2022-06-24 12:41:37.461106
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:41:46.597458
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:41:47.969843
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    HitRecordIE().extract(url)

# Generated at 2022-06-24 12:41:49.758210
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL
    assert ie._TEST
    assert ie._real_extract

# Generated at 2022-06-24 12:41:51.019795
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    t = HitRecordIE()
    assert t is not None

# Generated at 2022-06-24 12:42:00.158722
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:42:04.201834
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.suitable("https://hitrecord.org/records/2954362")
    assert not HitRecordIE.suitable("https://hitrecord.org/records/")
    assert not HitRecordIE.suitable("https://relay.hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:42:06.262846
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert isinstance(ie, HitRecordIE)

# Generated at 2022-06-24 12:42:10.397669
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.download("https://hitrecord.org/records/2663985")
    ie.download("https://hitrecord.org/records/2663985")
    ie.download("https://hitrecord.org/records/2663985")

# Generated at 2022-06-24 12:42:12.205686
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    _ = HitRecordIE()

# Generated at 2022-06-24 12:42:14.501919
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-24 12:42:15.498955
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-24 12:42:16.250679
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:16.905346
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # There is no URL for this unit test
    pass

# Generated at 2022-06-24 12:42:18.499519
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test positive case
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:42:19.951737
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:42:24.277929
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    i = HitRecordIE()
    assert i.ie_key() == 'hitrecord'
    assert i.ie_name() == 'HitRecord'
    assert i.suitable('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:42:25.986258
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("HitRecordIE", "https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:42:30.779627
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # test constructor
    ie = HitRecordIE(None)

    # test regex cases
    HitRecordIE._VALID_URL = 'https?://(?:www.)?hitrecord.org/records/(?P<id>\d+)'
    ie.info_extractor('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:42:37.733434
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_instance = HitRecordIE()
    hitrecord_instance._real_extract("https://hitrecord.org/records/2954362")
    assert hitrecord_instance._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert hitrecord_instance._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-24 12:42:42.692186
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.SUFFIX == ' hitrecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie.__name__ == 'HitRecord'
    assert ie.IE_NAME == 'hitrecord'

# Generated at 2022-06-24 12:42:46.997947
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    x = HitRecordIE()
    assert HitRecordIE.__name__ == 'HitRecordIE'
    assert x.__class__.__name__ == HitRecordIE.__name__
    assert x._VALID_URL == HitRecordIE._VALID_URL
    assert x._TEST == HitRecordIE._TEST

# Generated at 2022-06-24 12:42:51.526841
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie2 = InfoExtractor('HitRecordIE')
    assert ie == ie2
    assert ie == InfoExtractor.registry.get('HitRecordIE')
    assert ie.valid_urls == ie2.valid_urls
    assert ie.valid_urls == InfoExtractor.registry.get('HitRecordIE').valid_urls


# Generated at 2022-06-24 12:43:00.930931
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.hdrs['User-Agent'] == 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/60.0.3112.78 Safari/537.36'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST[0] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST[1] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST[2]['id'] == '2954362'

# Generated at 2022-06-24 12:43:03.429669
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Constructor of HITRECORDIE class
    ie = HitRecordIE()

### Test function for function _real_extract
# Test for extract an existing video, a normal case

# Generated at 2022-06-24 12:43:04.058736
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:04.639359
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-24 12:43:07.192552
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL
  assert HitRecordIE()._TEST == HitRecordIE._TEST

# Generated at 2022-06-24 12:43:08.882539
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:43:18.392364
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    video_id = '2954362'
    HRIE = HitRecordIE()
    # The class HitRecordIE should initialize an object with fields
    # _VALID_URL and _TEST, and _download_json function
    assert HRIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert isinstance(HRIE._TEST, dict)
    assert HRIE._download_json is not None
    # The class HitRecordIE should have a method _real_extract, which should return a
    # a dict with key and value as below
    video = HRIE._real_extract(url)
    assert isinstance(video, dict)

# Generated at 2022-06-24 12:43:20.621724
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    It is hard to provide unit test for this class since the video URL
    changes all the time.
    """
    pass

# Generated at 2022-06-24 12:43:31.100129
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    m_init = {
    '_downloader': 'downloader',
    '_match_id': lambda x: True,
    '_download_json': lambda x: {'title': 'hit_record_title', 'source_url': {'mp4_url': 'hit_record_url'}}
    }

    hitRecordIE = HitRecordIE(**m_init)
    assert(hitRecordIE.extract('hit_record_url')) == {'id': '', 'url': 'hit_record_url', 'title': 'hit_record_title', 'description': None, 'duration': None, 'timestamp': None, 'uploader': None, 'uploader_id': None, 'view_count': None, 'like_count': None, 'comment_count': None, 'tags': None}

# Generated at 2022-06-24 12:43:35.350102
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.suitable(HitRecordIE.IE_NAME, "https://hitrecord.org/records/2954362")
    assert HitRecordIE.suitable(HitRecordIE.IE_NAME, "http://hitrecord.org/records/2954362")
    assert not HitRecordIE.suitable(HitRecordIE.IE_NAME, "http://hitrecord.org/")


# Generated at 2022-06-24 12:43:38.213918
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-24 12:43:39.460584
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:43:42.022452
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_ie = HitRecordIE();
    try:
        hit_record_ie.logger.info("Unit test for constructor of class HitRecordIE");
    except :
        raise TypeError("Unit test for constructor of class HitRecordIE failed");


# Generated at 2022-06-24 12:43:51.150045
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video_page = HitRecordIE._download_webpage(
        "https://hitrecord.org/records/2954362", 2954362)

    video_page_html = HitRecordIE._html_search_regex(
        r'<div[^>]*?class="video-heading-content">(?P<video_page>.+?)</div>',
        video_page, 'video page html', default=None, group='video_page')

    assert video_page_html is not None and len(video_page_html) > 0, \
        "Video page html should not be None or empty."


# Generated at 2022-06-24 12:43:51.592611
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-24 12:43:56.674545
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:43:59.888221
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:01.164016
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie == HitRecordIE

# Generated at 2022-06-24 12:44:02.049580
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    raise Exception("Tests not implemented")

# Generated at 2022-06-24 12:44:05.156878
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # wrong url
    assert not ie.suitable('http://hitrecord.org/records/1a')
    # right url
    assert ie.suitable('http://hitrecord.org/records/2954362')


# Generated at 2022-06-24 12:44:08.522592
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    inst = HitRecordIE()
    assert(inst.IE_NAME == 'HitRecord')
    assert(inst.IE_DESC == 'HitRecord')
    #assert(inst.succeeded == True)


# Generated at 2022-06-24 12:44:17.686057
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:44:19.688222
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # tests for the instance attributes
    assert ie._VALID_URL is not None
    assert ie._TEST is not None

# Generated at 2022-06-24 12:44:23.189207
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    Instance = HitRecordIE()
    assert(Instance._VALID_URL=='https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-24 12:44:29.967848
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie_ = HitRecordIE()
    assert ie_.valid_url('https://hitrecord.org/records/2954362')
    assert ie_.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie_.valid_url('https://www.hitrecord.org/')
    assert not ie_.valid_url('https://www.hitrecord.org/users/362811')
    assert not ie_.valid_url('https://www.hitrecord.org/records/2954362/edit')

# Generated at 2022-06-24 12:44:32.768592
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    assert instance._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:34.073237
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie.ie_key() == 'HitRecord')

# Generated at 2022-06-24 12:44:34.985590
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract

# Generated at 2022-06-24 12:44:36.870188
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit = HitRecordIE()
    print('constructor of class HitRecordIE is ok')



# Generated at 2022-06-24 12:44:38.438760
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.download('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:44:39.880053
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE([])
    assert ie is not None

# Generated at 2022-06-24 12:44:45.724196
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """ Unit test for constructor of class HitRecordIE """

    # Test invalid input
    assert HitRecordIE(None, None) is not None
    assert HitRecordIE(None, None)._VALID_URL is not None

    # Test valid input
    assert HitRecordIE(HitRecordIE._VALID_URL, None)._VALID_URL == HitRecordIE._VALID_URL

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:44:48.517540
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print('Testing HitRecordIE')
    hitrecord = HitRecordIE()
    return hitrecord


# Retrieves the video information for a video given the url and the video id

# Generated at 2022-06-24 12:44:49.457126
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()


# Generated at 2022-06-24 12:44:50.908267
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'

# Generated at 2022-06-24 12:44:51.551032
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-24 12:44:54.497324
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:01.640423
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from .test_common import TestIE
    ie = TestIE(HitRecordIE)
    ie.download_webpage = lambda url, *args: url
    ie.extract_info = lambda *args: {}
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/')

# Generated at 2022-06-24 12:45:03.008502
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    print(hitRecordIE)

# Generated at 2022-06-24 12:45:04.365492
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:45:04.974435
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-24 12:45:07.268261
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie.url == 'https://hitrecord.org/records/2954362'

# Generated at 2022-06-24 12:45:07.810219
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-24 12:45:08.336649
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:45:09.518528
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:45:19.472758
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_obj = HitRecordIE()
    assert test_obj._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:23.817817
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    entry = ie._real_extract('https://hitrecord.org/records/2954362')
    assert isinstance(entry, dict)
    assert ie.suitable(entry.get('url'))

# Generated at 2022-06-24 12:45:25.289093
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # Check whether it's initialized
    assert ie._downloader

# Generated at 2022-06-24 12:45:26.791171
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:45:30.707367
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from .test_download import check_test_completes
    url = 'https://hitrecord.org/records/2954362'
    HitRecordIE(check_test_completes, url)

# Generated at 2022-06-24 12:45:39.105304
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Constructor with valid URL
    test_1 = HitRecordIE('https://hitrecord.org/records/2954362')

    # Constructor with invalid URL
    test_2 = HitRecordIE('https://hitrecord.org/records/this-is-an-invalid-url')

    assert test_1.VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert test_1.TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert test_1.TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert test_1.TEST['info_dict']['id'] == '2954362'
   

# Generated at 2022-06-24 12:45:41.626895
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  ie = HitRecordIE('http://hitrecord.org/records/2954362')
  assert ie.ie_key() == 'HitRecord'

# Generated at 2022-06-24 12:45:45.654820
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        info_extractor = HitRecordIE()
    except:
        info_extractor = False

    return True if info_extractor else False


# Generated at 2022-06-24 12:45:46.260190
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:45:55.937661
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ire = HitRecordIE()
    assert ire._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ire._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ire._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ire._TEST['info_dict']['id'] == '2954362'
    assert ire._TEST['info_dict']['ext'] == 'mp4'
    assert ire._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:45:58.187404
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
   ie = HitRecordIE()
   assert ie.suitable('https://hitrecord.org/records/2954362')
   assert not ie.suitable('https://hitrecord.org/users/Zuzi.C12')

# Generated at 2022-06-24 12:46:03.872507
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')
    # Test with complex URLs
    HitRecordIE('https://hitrecord.org/records/2954362?q=12&q=13&q=14')
    HitRecordIE('https://hitrecord.org/records/2954362?q=12?q=13?q=14?')

# Generated at 2022-06-24 12:46:12.857065
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test by calling constructor of class HitRecordIE
    obj = HitRecordIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:46:15.784754
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(HitRecordIE._VALID_URL)
    assert ie._VALID_URL == HitRecordIE._VALID_URL
    assert ie._TEST == HitRecordIE._TEST
    return

# Generated at 2022-06-24 12:46:17.405715
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('www.hitrecord.org')
    assert ie is not None


# Generated at 2022-06-24 12:46:18.295802
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-24 12:46:19.038771
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:20.287008
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # testing for return type
    assert(isinstance(HitRecordIE(), InfoExtractor))

# Generated at 2022-06-24 12:46:23.243415
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    infoExtractor = HitRecordIE()
    assert HitRecordIE._VALID_URL == 'https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)'

# Generated at 2022-06-24 12:46:31.458474
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-24 12:46:35.868956
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE().matching_url('https://hitrecord.org/records/2954362') == 'https://hitrecord.org/records/2954362'
    assert HitRecordIE().matching_url('https://hitrecord.org/records/sdfsdfsdfsdfsdf') == None

# Generated at 2022-06-24 12:46:37.093200
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:46:43.806801
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(HitRecordIE._VALID_URL, HitRecordIE._TEST)
    ie = HitRecordIE(ie._VALID_URL, ie._TEST)
    ie = HitRecordIE(ie._VALID_URL, ie._TEST)
    ie = HitRecordIE(ie._VALID_URL, ie._TEST)
    ie = HitRecordIE(ie._VALID_URL, ie._TEST)
    ie = HitRecordIE(ie._VALID_URL, ie._TEST)
    ie = HitRecordIE(ie._VALID_URL, ie._TEST)

test_HitRecordIE()

# Generated at 2022-06-24 12:46:44.702581
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:51.320298
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Constructor test
    """
    # Positive test case
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie.name == 'hitrecord'
    assert ie.url_re == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie.url_re == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie.test_url("https://hitrecord.org/records/2954362") is True
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:46:55.981859
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_instance = HitRecordIE()
    assert test_instance._VALID_URL.startswith("https?://")
    title = test_instance._TEST['info_dict']['title']
    assert "HITRECORD" in title
    assert "ACLU" in title

# Generated at 2022-06-24 12:47:00.653974
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print("Running tests for HitRecordIE")
    try:
        # Testing creation of new HitRecordIE object
        ie = HitRecordIE('www.hitrecord.org')
    except Exception as e:
        print("ERROR! Class 'HitRecordIE' could not be instantiated")
        print("Exception: %s" % e)
        return False
    print("Class 'HitRecordIE' instantiated successfully")
    return True


# Generated at 2022-06-24 12:47:02.529262
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	IE = HitRecordIE()
	test_url = 'https://hitrecord.org/records/2954362'
	id = IE._match_id(test_url)
	print ('Video id:', id)

# Generated at 2022-06-24 12:47:05.625410
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')

    ie.download(ie.url).get('id') == '2954362'