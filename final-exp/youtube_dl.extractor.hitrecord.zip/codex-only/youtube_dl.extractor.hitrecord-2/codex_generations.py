

# Generated at 2022-06-24 12:37:17.463084
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test case for constructing a HitRecordIE instance with valid url
    ie = HitRecordIE()
    HitRecordIE._VALID_URL = r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._match_id is not None

    # Test case for constructing a HitRecordIE instance with invalid url
    ie = HitRecordIE()
    HitRecordIE._VALID_URL = r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    ie.url = 'http://hitrecord.org/records/'
    assert ie._match_id is not None

    # Test case for constructing a HitRecordIE instance with invalid url
    ie = HitRecordIE()

# Generated at 2022-06-24 12:37:24.530287
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-24 12:37:29.778343
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    '''
    Unit test for constructor of class HitRecordIE
    '''
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie.url == 'https://hitrecord.org/records/2954362'
    assert ie.video_id == '2954362'
    assert ie.id == '2954362'


# Generated at 2022-06-24 12:37:31.456073
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie

# Generated at 2022-06-24 12:37:32.400992
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  ie = HitRecordIE()


# Generated at 2022-06-24 12:37:37.800215
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable("https://hitrecord.org/records/2954362")
    assert ie.IE_NAME == "hitrecord:record"
    assert ie.IE_DESC == "hitrecord.org videos"
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:37:38.742898
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    print(ie)

# Generated at 2022-06-24 12:37:42.075524
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('HitRecord', 'HitRecordIE', 'HitRecordIE._real_extract')
    assert ie.ie_key() == 'HitRecord'
    assert ie.ie_name() == 'HitRecordIE'
    assert ie._real_extract == HitRecordIE._real_extract

# Generated at 2022-06-24 12:37:42.823083
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-24 12:37:48.032564
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:37:49.198368
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:37:52.287218
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:37:53.009001
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE()

# Generated at 2022-06-24 12:37:56.016122
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert HitRecordIE()._TEST

# Generated at 2022-06-24 12:37:57.267452
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_ie = HitRecordIE()
    assert hit_record_ie

# Generated at 2022-06-24 12:37:58.193660
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie

# Generated at 2022-06-24 12:38:01.031903
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    assert instance._VALID_URL is not None
    assert instance._TEST is not None

# Generated at 2022-06-24 12:38:03.065030
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test = HitRecordIE('a', 'b', 'c')
    print("Test: ", test)

# Generated at 2022-06-24 12:38:08.057180
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_url = 'https://hitrecord.org/records/2954362'
    assert HitRecordIE().suitable(test_url)
    assert HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:10.513644
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-24 12:38:11.835302
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    print ("Test of class HitRecordIE completed.")

# Generated at 2022-06-24 12:38:13.017519
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL is not None

# Generated at 2022-06-24 12:38:14.401537
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    i = HitRecordIE()
    assert i.domain == 'hitrecord.org'

# Generated at 2022-06-24 12:38:18.819098
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE()
    assert(info_extractor.IE_NAME == 'HitRecord')
    assert(info_extractor.IE_DESC == 'HitRecord.org')

# Generated at 2022-06-24 12:38:19.420099
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:20.425465
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    pass

# Generated at 2022-06-24 12:38:30.756435
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:31.996935
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:32.683527
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:33.654520
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    IE = HitRecordIE()

# Generated at 2022-06-24 12:38:36.254830
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.suitable('https://hitrecord.org/records/2954362')
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:38:37.198539
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print(HitRecordIE._VALID_URL)

# Generated at 2022-06-24 12:38:40.127819
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:48.223540
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-24 12:38:52.660343
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE('hitrecord.org')
    assert obj._VALID_URL == HitRecordIE._VALID_URL
    assert obj._TEST == HitRecordIE._TEST 
    assert obj._match_id('https://hitrecord.org/records/2954362') == '2954362'


# Generated at 2022-06-24 12:38:54.099280
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert isinstance(HitRecordIE(), InfoExtractor)

# Generated at 2022-06-24 12:39:01.549291
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video = HitRecordIE()._real_extract("https://hitrecord.org/records/2954362")
    id = video['id']
    assert id == '2954362'
    title = video['title']
    assert title == 'A Very Different World (HITRECORD x ACLU)'
    description = video['description']

# Generated at 2022-06-24 12:39:02.248441
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:03.571762
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:39:10.854831
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test for invalid input URL
    failTest = False
    try:
        HitRecordIE('https://www.example.com')
    except ValueError:
        failTest = True
    assert failTest, 'HitRecordIE did not catch invalid input URL.'

    # Test for valid input URL
    successTest = False
    try:
        HitRecordIE('https://www.hitrecord.org/records/2954362')
        successTest = True
    except ValueError:
        pass
    assert successTest, 'HitRecordIE did not accept valid input URL.'

# Generated at 2022-06-24 12:39:11.780227
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ie = HitRecordIE()	


# Generated at 2022-06-24 12:39:12.645943
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HitRecordIE()

# Generated at 2022-06-24 12:39:16.288906
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:39:25.200703
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE()
    assert hitRecord._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert hitRecord._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert hitRecord._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert hitRecord._TEST['info_dict']['id'] == '2954362'
    assert hitRecord._TEST['info_dict']['ext'] == 'mp4'
    assert hitRecord._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:39:27.664997
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:28.098872
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:30.050105
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    print(ie)

# Generated at 2022-06-24 12:39:34.975512
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.ie_key() == 'hitrecord'
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert HitRecordIE._TEST['url'] == 'https://hitrecord.org/records/2954362'

# Generated at 2022-06-24 12:39:44.660956
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable("https://hitrecord.org/records/2954362")
    assert ie.suitable("http://hitrecord.org/records/2954362")
    assert not ie.suitable("http://hitrecord.org/")
    assert not ie.suitable("https://www.hitrecord.org/")
    assert not ie.suitable("https://youtu.be/records/2954362")
    assert not ie.suitable("https://www.youtube.com/watch?v=records/2954362")
    assert not ie.suitable("https://hitrecord.org/records")
    assert not ie.suitable("https://hitrecord.org/records/2954362/")

# Generated at 2022-06-24 12:39:47.360148
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Constructor of class HitRecordIE
    """
    print("Unit test for constructor of class HitRecordIE")
    assert HitRecordIE(HitRecordIE._VALID_URL)._VALID_URL == HitRecordIE._VALID_URL



# Generated at 2022-06-24 12:39:49.135437
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:39:50.616074
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:39:59.947929
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:05.142900
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord.org'
    assert ie.ie_name() == 'HitRecord'
    assert ie.suitable(False, 'http://hitrecord.org/records/2954362')
    assert ie.suitable(False, 'https://hitrecord.org/records/2954362')
    assert not ie.suitable(False, 'http://www.hitrecord.org/records/2954362')
    assert not ie.suitable(False, 'https://hitrecord.org/')
    assert not ie.suitable(False, 'https://hitrecord.org/records/')
    assert not ie.suitable(False, 'https://hitrecord.org/records/295436')

# Generated at 2022-06-24 12:40:06.865942
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    h = HitRecordIE()
    assert h != None



# Generated at 2022-06-24 12:40:10.227534
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://www.hitrecord.org/records/633966')
    assert ie.url == 'https://hitrecord.org/records/633966'
    assert ie.video_id == '633966'

# Generated at 2022-06-24 12:40:11.643348
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:40:15.663602
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE(): 
    """ Tests constructor of class HitRecordIE 
    """
    # Create instance of class HitRecordIE with parameters <url> and <ie>
    ie_HitRecord_instance = HitRecordIE(url="http://mockedurl.com", ie=InfoExtractor())
    assert ie_HitRecord_instance != None
    pass

# Generated at 2022-06-24 12:40:16.626142
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-24 12:40:26.036271
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:33.573588
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:41.565516
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:46.473507
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Create an object of class HitRecordIE
    ie_obj = HitRecordIE()
    # Test the method _match_id
    ie_obj._match_id("hhttp://hitrecord.org/records/2954362")
    # Test the method _real_extract
    ie_obj._real_extract("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:40:53.928881
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    m = HitRecordIE()
    assert m._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:59.611357
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert not(isinstance(HitRecordIE, object))
    assert hasattr(HitRecordIE, '_download_json')
    assert hasattr(HitRecordIE, '_match_id')
    assert hasattr(HitRecordIE, '_real_extract')
    assert hasattr(HitRecordIE, '_VALID_URL')
    assert hasattr(HitRecordIE, '_TEST')

# Generated at 2022-06-24 12:41:01.625851
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:41:06.469369
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    i = HitRecordIE()
    if i._VALID_URL != r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)':
        raise Exception('test_HitRecordIE function failed')

test_HitRecordIE()

# Generated at 2022-06-24 12:41:14.004564
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    result_IE = HitRecordIE()
    assert result_IE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert 'id' in result_IE._TEST.keys()
    assert 'videos' in result_IE._TEST.keys()
    assert 'soundtracks' in result_IE._TEST.keys()
    assert result_IE._TEST['url'] == 'https://hitrecord.org/records/2954362'

# Unit tests for fields in the returned information dictionary of class HitRecordIE's method _real_extract

# Generated at 2022-06-24 12:41:15.806686
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')
    return

# Generated at 2022-06-24 12:41:16.493147
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:17.941066
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Unit test for HitRecordIE.
    HitRecordIE()

# Generated at 2022-06-24 12:41:25.833311
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    #test empty URL
    test_HitRecordIE_url = '';
    test_HitRecordIE_ie = HitRecordIE();
    assert test_HitRecordIE_ie._match_id(test_HitRecordIE_url) == True;
	
    #test invalid URL
    test_HitRecordIE_url = 'https://hitrecord.org/records/';
    test_HitRecordIE_ie = HitRecordIE();
    assert test_HitRecordIE_ie._match_id(test_HitRecordIE_url) == False;
	
    #test valid URL
    test_HitRecordIE_url = 'https://hitrecord.org/records/2954362';
    test_HitRecordIE_ie = HitRecordIE();

# Generated at 2022-06-24 12:41:28.210310
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  ie = HitRecordIE(None)
  print(ie)

if __name__ == "__main__":
  test_HitRecordIE()

# Generated at 2022-06-24 12:41:28.836615
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:29.438981
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:31.179161
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test HitRecordIE
    HitRecordIE()

# Generated at 2022-06-24 12:41:32.596688
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:41:33.566675
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-24 12:41:37.290378
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE._download_json = lambda self, *_, **__: {}
    HitRecordIE._download_webpage = lambda self, *_, **__: ''
    HitRecordIE._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:41:46.360580
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # initialize a youtube_dl instance
    youtube_dl_obj = YoutubeDL()

    # extract video by url
    url = "https://hitrecord.org/records/2954362"
    video = youtube_dl_obj.extract_info(url)

    # video id
    video_id = video.get('id')
    assert video_id == '2954362'

    # video url
    video_url = video.get('url')
    assert video_url == 'https://cdn.hitrecord.org/video/wwtu-x4jz4t.mp4'

    # video title
    video_title = video.get('title')
    assert video_title == 'A Very Different World (HITRECORD x ACLU)'

    # video description
    video_desc = video.get('description')
    assert video_

# Generated at 2022-06-24 12:41:47.145324
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:41:48.992357
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-24 12:41:49.445438
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:41:51.998251
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:41:55.958611
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, HitRecordIE)

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:41:58.098433
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:42:07.800189
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-24 12:42:09.294676
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE is not None
test_HitRecordIE()

# Generated at 2022-06-24 12:42:20.149369
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-24 12:42:22.333090
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE()
    print(info_extractor)

# Generated at 2022-06-24 12:42:29.057538
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')
    assert(ie.__name__ == 'HitRecord')
    assert(ie.ie_key() == 'hitrecord')
    assert(ie.suitable('https://hitrecord.org/records/2954362'))
    assert(not ie.suitable('http://abc.com'))


# Generated at 2022-06-24 12:42:36.784150
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:42:47.305379
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.__name__ == 'HitRecordIE'
    assert HitRecordIE.__doc__ != None
    assert HitRecordIE.__doc__ != ""
    assert HitRecordIE._VALID_URL == 'https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)'

# Generated at 2022-06-24 12:42:50.394278
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # type: (None) -> None
    """Unit test for constructor of class HitRecordIE"""
    assert HitRecordIE(None)._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-24 12:42:54.202570
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()
    assert obj.name == "HitRecord"
    assert obj._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:42:57.049490
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL
    assert HitRecordIE()._TEST == HitRecordIE._TEST
    assert HitRecordIE()._download_json

# Generated at 2022-06-24 12:42:58.584899
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, HitRecordIE)


# Generated at 2022-06-24 12:43:01.999352
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Arrange
    url = 'https://hitrecord.org/records/2954362'

    # Act
    HitRecord = HitRecordIE()

    # Assert
    assert HitRecord._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'



# Generated at 2022-06-24 12:43:03.087209
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("HitRecordIE", "test")

# Generated at 2022-06-24 12:43:03.650345
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:14.343050
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # test for HitRecordIE
    hitrecord_ie_test = HitRecordIE()
    # extract id from the test url
    video_id = hitrecord_ie_test._match_id(HitRecordIE._TEST['url'])
    # test download_json
    video = hitrecord_ie_test._download_json(
        'https://hitrecord.org/api/web/records/%s' % video_id, video_id)
    # test duration
    duration = float_or_none(video.get('duration'), 1000)
    # test timestamp
    timestamp = int_or_none(video.get('created_at_i'))
    # test view_count
    view_count = int_or_none(video.get('total_views_count'))
    # test like_count

# Generated at 2022-06-24 12:43:17.099566
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.get_url_re() == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie.match_url('https://hitrecord.org/records/2954362') == True
    assert ie.match_url('https://hitrecord.org/records') == False


# Generated at 2022-06-24 12:43:19.447338
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('hitrecord', 'https://hitrecord.org/records/2954362')



# Generated at 2022-06-24 12:43:22.550046
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    ie = HitRecordIE()

    assert ie._match_id(url) == '2954362'


# Generated at 2022-06-24 12:43:26.623495
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    url = 'https://hitrecord.org/records/2954362'
    #url = 'https://hitrecord.org/records/3349343'

    vid = HitRecordIE()._real_extract(url)
    print (vid)

# Generated at 2022-06-24 12:43:26.957084
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE

# Generated at 2022-06-24 12:43:32.049835
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # Constructor should initialize the list class attributes.

# Generated at 2022-06-24 12:43:41.799315
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.__class__.__name__ == 'HitRecordIE'
    assert ie.__class__.__doc__ != None
    assert hasattr(ie, '_VALID_URL')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert hasattr(ie, '_TEST')

# Generated at 2022-06-24 12:43:42.264624
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:46.301502
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hie = HitRecordIE()
    result = hie.suitable('https://example.com/something/path')
    assert not result
    result2 = hie.suitable('https://hitrecord.org/records/2954362')
    assert result2

# Generated at 2022-06-24 12:43:46.847718
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:53.616675
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert hitrecord.HitRecordIE.IE_NAME == 'hitrecord'
    # Test for url, it should be valid url
    assert ie.valid_url("https://hitrecord.org/records/2954362")
    # Test for extract method, it should return valid dictionary
    assert len(ie.extract("https://hitrecord.org/records/2954362")) == 14
    # Test for md5 method, it should return md5 hash of the file
    assert ie.md5("https://hitrecord.org/records/2954362") == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-24 12:43:56.011853
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL
    assert HitRecordIE()._TEST == HitRecordIE._TEST

# Generated at 2022-06-24 12:43:57.292514
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(3,8)

# Generated at 2022-06-24 12:43:59.443158
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    print(str(ie))


# Generated at 2022-06-24 12:44:00.379256
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:44:00.939565
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
   HitRecordIE()

# Generated at 2022-06-24 12:44:02.174579
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('not a valid url')


# Generated at 2022-06-24 12:44:02.762612
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:44:04.896223
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    iE = HitRecordIE
    assert iE( compat_str, compat_str, compat_str, compat_str, compat_str,
               compat_str, compat_str, compat_str )

# Generated at 2022-06-24 12:44:07.865826
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    address = 'https://hitrecord.org/records/2954362'
    ie = HitRecordIE()
    result = ie.suitable(address)
    assert(result)



# Generated at 2022-06-24 12:44:09.076449
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()

# Generated at 2022-06-24 12:44:17.931426
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    # Keywords are case sensitive, so this check is necessary
    assert instance._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert instance._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert instance._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert instance._TEST['info_dict']['id'] == '2954362'
    assert instance._TEST['info_dict']['ext'] == 'mp4'
    assert instance._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:44:23.633134
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HRIE = HitRecordIE()
    print (HRIE)
    print (HRIE._downloader)
    print (HRIE._download_webpage)
    print (HRIE._download_json)
    print (HRIE._match_id)
    print (HRIE._real_extract)
    print (HRIE._download_webpage)

# Generated at 2022-06-24 12:44:26.026626
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecordIE = HitRecordIE()
    assert isinstance(hitrecordIE, InfoExtractor)
    assert isinstance(hitrecordIE._real_extract, types.FunctionType)

# Generated at 2022-06-24 12:44:28.706967
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    urls = ie.extract('https://hitrecord.org/records/2954362')
    assert urls[0]['id'].count('2954362') == 1

# Generated at 2022-06-24 12:44:30.160573
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_ie = HitRecordIE()
    assert hitrecord_ie

# Generated at 2022-06-24 12:44:31.754758
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    record = HitRecordIE()
    assert record.name == 'hitrecord'

# Generated at 2022-06-24 12:44:32.421640
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:44:32.804889
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:44:41.272198
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-24 12:44:45.723950
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("hitrecord.org/records/2954362")
    print("Extracting info from URL: https://hitrecord.org/records/2954362")
    ie.extract()

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:44:49.627513
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test that our test url is indeed in the constructor
    assert HitRecordIE._TEST['url'] in HitRecordIE._VALID_URL
    # Test that the url is properly extracted
    assert HitRecordIE._match_id(HitRecordIE._TEST['url']) == '2954362'

# Generated at 2022-06-24 12:44:51.817163
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    ie._real_extract("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:44:52.722330
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:45:03.809593
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('HitRecord', 'hitrecord.org')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/(?:records/)?(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:45:05.530488
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:45:06.292204
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    x = HitRecordIE()


# Generated at 2022-06-24 12:45:09.495147
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test basic constructor method.
    hitRecordIE = HitRecordIE()
    assert hitRecordIE.__class__.__name__ == "HitRecordIE"


# Generated at 2022-06-24 12:45:11.784815
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test with a URL from the constructor of class HitRecordIE
    url = 'https://hitrecord.org/records/2954362'
    HitRecordIE().extract(url)

# Generated at 2022-06-24 12:45:17.967218
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')
    assert ie.url_result == {'url': 'https://hitrecord.org/records/2954362'}
    assert ie.videoSong == ('A Very Different World (HITRECORD x ACLU)')
    assert ie.timestamp == 1471557582
    assert ie.duration == 139.327

# Generated at 2022-06-24 12:45:22.158919
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit = HitRecordIE()
    assert hit._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-24 12:45:23.256166
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-24 12:45:25.818336
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    hitrecord_url = 'https://hitrecord.org/records/2954362'
    assert ie.suitable(hitrecord_url)
    assert ie._match_id(hitrecord_url) == '2954362'

# Generated at 2022-06-24 12:45:28.211365
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# Initialize HitRecordIE object
	i = HitRecordIE()

	# Check validity of test URLs
	for url in i._TEST['url']:
		i.suitable('%s' % url)
		assert i._SUITABLE

# Generated at 2022-06-24 12:45:29.940105
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()


# Generated at 2022-06-24 12:45:31.371773
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    result = HitRecordIE()
    assert 'hitrecord' in result.IE_NAME

# Generated at 2022-06-24 12:45:31.947797
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:45:32.482705
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:45:33.350381
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE(3074395)

# Generated at 2022-06-24 12:45:36.817331
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Unit test for HitRecordIE"""
    ie = HitRecordIE("http://hitrecord.org/records/2954362")
    assert ie.url == "http://hitrecord.org/records/2954362"
    assert ie.ie_key() == "hitrecord"

# Generated at 2022-06-24 12:45:48.547466
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # first use of magic
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    # second use of magic

# Generated at 2022-06-24 12:45:52.069381
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(
        'https://hitrecord.org/records/2954362'
    )._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:53.007242
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    h = HitRecordIE()
    assert h == h

# Generated at 2022-06-24 12:45:54.431497
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = "https://hitrecord.org/records/2954362"
    ie = HitRecordIE(url=url)
    ie.test()

# Generated at 2022-06-24 12:46:01.254913
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = "https://hitrecord.org/records/2954362"
    assert HitRecordIE._VALID_URL == HitRecordIE._TEST['url']
    assert HitRecordIE._TEST['md5'] == HitRecordIE._TEST['info_dict']['md5']
    assert HitRecordIE._TEST['url'] == url
    assert HitRecordIE._TEST['info_dict']['id'] == HitRecordIE._TEST['info_dict']['id']
    assert HitRecordIE._TEST['info_dict']['ext'] == HitRecordIE._TEST['info_dict']['ext']
    assert HitRecordIE._TEST['info_dict']['title'] == HitRecordIE._TEST['info_dict']['title']

# Generated at 2022-06-24 12:46:11.552899
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('http://hitrecord.org/records/2954362')

    ie_info = ie.extract('http://hitrecord.org/records/2954362')
    assert ie_info['id'] == '2954362'
    assert ie_info['url'] == 'https://www.hitrecord.org/video/2954362.mp4'
    assert ie_info['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert ie_info['description'] == 'Created by Zuzi.C12'
    assert ie_info['duration'] == 139.327
    assert ie_info['timestamp'] == 1471557582
    assert ie_info['upload_date'] == '20160818'

# Generated at 2022-06-24 12:46:21.073241
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test = HitRecordIE()
    assert test.name == 'hitrecord'
    assert test.IE_NAME == 'hitrecord.org'
    assert test._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:46:22.035827
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()
    return 0

# Generated at 2022-06-24 12:46:23.191898
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-24 12:46:24.679908
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extractor = 'HitRecordIE'

# Generated at 2022-06-24 12:46:26.307453
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    'Note: HitRecordIE.__init__ is tested in extractor.test.test_utils'
    pass

# Generated at 2022-06-24 12:46:27.858032
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    assert isinstance(hitrecord, InfoExtractor)


# Generated at 2022-06-24 12:46:28.382492
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:31.478325
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # given URL
    url = 'https://hitrecord.org/records/2954362'
    # when we create InfoExtractor
    ie = HitRecordIE(url)
    # then it's valid
    assert ie.is_valid()

# Generated at 2022-06-24 12:46:36.209142
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    video_id = '2954362'
    url = 'https://hitrecord.org/records/%s' % video_id
    assert('HitRecordIE matches it' == ie.suitable(url))
    _, video = ie._real_extract(url)
    assert(video['id'] == video_id)

# Generated at 2022-06-24 12:46:38.232024
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # A sample url for testing
    url = 'https://hitrecord.org/records/2954362'
    HitRecordIE()._real_extract(url)

# Generated at 2022-06-24 12:46:38.976474
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE() == HitRecordIE()

# Generated at 2022-06-24 12:46:39.536475
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-24 12:46:41.790106
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:46:48.858552
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    # Constructor conditions
    obj = HitRecordIE(HitRecordIE._downloader, HitRecordIE._VALID_URL)
    assert obj._VALID_URL == HitRecordIE._VALID_URL
    assert obj.suitable('http://hitrecord.org/records/2954362')
    assert obj.suitable('https://hitrecord.org/records/2954362')
    assert obj.suitable('https://www.hitrecord.org/records/2954362')

    # Get id from url
    assert obj._match_id(HitRecordIE._VALID_URL) == '2954362'

    # Real test
    obj._real_extract(HitRecordIE._TEST['url'])

# Generated at 2022-06-24 12:46:50.012783
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('HitRecord', "")

# Generated at 2022-06-24 12:46:53.800773
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    h = HitRecordIE()
    
    url = "https://hitrecord.org/records/2954362"
    
    h._match_id(url)
    h._real_extract(url)

# Generated at 2022-06-24 12:46:57.757917
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Get the HITRECORD ID form url
    url = 'https://hitrecord.org/records/2954362'
    video_id = HitRecordIE._match_id(HitRecordIE, url)
    assert video_id == '2954362'

# Generated at 2022-06-24 12:47:02.895949
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(HitRecordIE.ie_key())
    assert isinstance(ie, HitRecordIE)
    assert isinstance(ie.IE_NAME, str)
    assert isinstance(ie.IE_DESC, str)
    assert ie.IE_NAME == "HitRecord"
    assert ie.IE_DESC == "HitRecord"

# Generated at 2022-06-24 12:47:05.078436
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_HitRecordIE.HitRecordIE = HitRecordIE()
    
test_HitRecordIE()

# Generated at 2022-06-24 12:47:06.768940
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE()
    assert isinstance(info_extractor, InfoExtractor)
