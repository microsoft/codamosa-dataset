

# Generated at 2022-06-24 12:37:10.783172
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    assert hitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert hitRecordIE._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert hitRecordIE._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert hitRecordIE._TEST['info_dict']['id'] == '2954362'
    assert hitRecordIE._TEST['info_dict']['ext'] == 'mp4'
    assert hitRecordIE._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert hitRecordIE._T

# Generated at 2022-06-24 12:37:20.617883
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)'

# Generated at 2022-06-24 12:37:23.732174
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE().working = True
    HitRecordIE().extract('http://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:37:27.398608
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    assert HitRecordIE._VALID_URL == HitRecordIE._VALID_URL
    assert HitRecordIE._TEST == HitRecordIE._TEST
    assert HitRecordIE.__name__ == 'HitRecordIE'

# Generated at 2022-06-24 12:37:28.688537
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie

# Generated at 2022-06-24 12:37:39.160869
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:37:39.934533
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE().extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:37:50.200226
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrec = HitRecordIE()
    assert hitrec._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:37:59.472951
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert HitRecordIE._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert HitRecordIE._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert HitRecordIE._TEST['info_dict']['id'] == '2954362'
    assert HitRecordIE._TEST['info_dict']['ext'] == 'mp4'
    assert HitRecordIE._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:38:01.473118
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    print('HitRecordIE loaded successfully')

# Generated at 2022-06-24 12:38:08.245105
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	print(u'Testing constructor of class HitRecordIE')
	try:
		# Asserting constructor of class HitRecordIE for correct Input
		assert HitRecordIE(HitRecordIE._VALID_URL)
		print(u'PASSED: Constructor of class HitRecordIE is working')
	except (AssertionError):
		print(u'FAILED: Constructor of class HitRecordIE is not working')
		

# Generated at 2022-06-24 12:38:10.730763
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hri = HitRecordIE()
    assert hri.suitable('http://hitrecord.org/records/2954362')
    assert hri.IE_NAME == 'HitRecord'

# Generated at 2022-06-24 12:38:12.261917
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:38:14.444752
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from .common import TestExample
    instance = TestExample()
    assert(instance.test_HitRecordIE() == 1)

# Generated at 2022-06-24 12:38:16.248449
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:27.588987
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
   video_id = '2954362'
   title = 'A Very Different World (HITRECORD x ACLU)'
   video_url = 'https://d2v6kzmj2dzjoq.cloudfront.net/recordings/mp4_videos/000/002/954/original/Zuzi_C12_davidf_inventing_violet_Wak0F0U6.mp4'
   tags = ['#babies', '#dancing', '#funny', '#kids', '#music', '#orgasm']

# Generated at 2022-06-24 12:38:28.276573
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    x= HitRecordIE()

# Generated at 2022-06-24 12:38:35.814591
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://hitrecord.org/records/2954362?t=1474626088')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362?t=1474626088')
    assert ie.valid_url('http://hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/collections/2954362')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/collections')
    assert not ie.valid_

# Generated at 2022-06-24 12:38:39.156555
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('hitrecord', extractor_key='HitRecord')
    assert ie._VALID_URL[0] == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:39.908066
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:40.465264
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:48.368352
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)'  # noqa

# Generated at 2022-06-24 12:38:51.711986
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # HitRecordIE: Test for contructor of class
    assert HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-24 12:38:55.304293
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    test = ie.get_test()
    #test if the url is valid
    assert test['url'] == 'https://hitrecord.org/records/2954362'

# Generated at 2022-06-24 12:39:00.793806
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable == 'hitrecord.org'
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_id() =="hitrecord"
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:39:03.179423
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE("https://hitrecord.org/records/2954362").extract("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:39:04.090504
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    d = HitRecordIE()
    assert d is not None

# Generated at 2022-06-24 12:39:14.442497
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """ Unit test for HitRecordIE """
    # Download url
    test_url = 'https://hitrecord.org/records/2954362'

    # Set up instance of HitRecordIE
    instance = HitRecordIE()

    # Test _match_id method
    match_id = instance._match_id(test_url)
    assert match_id == '2954362'

    # Test _real_extract method
    info_dict = instance._real_extract(test_url)
    assert info_dict.get('id') == '2954362'
    assert info_dict.get('url') == 'http://hitrecord.org/uploads/af/4f/a4c9a90b388948b0a19e5eac6bbf3c34/1-VeryDifWorld720p.mp4'


# Generated at 2022-06-24 12:39:16.081221
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie
    # TODO: Add more test cases!

# Generated at 2022-06-24 12:39:16.616448
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:17.851778
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.set_test()

# Generated at 2022-06-24 12:39:19.173726
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:39:20.076549
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    x = HitRecordIE()
    pass

# Generated at 2022-06-24 12:39:22.867328
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.SUFFIX == '.org/records/'
    assert ie.VALID_URL == HitRecordIE._VALID_URL
    assert ie.ADDITIONAL_URL_SUFFIX == '/records/{}'
    assert ie.TEST == HitRecordIE._TEST

# Generated at 2022-06-24 12:39:25.313510
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'



# Generated at 2022-06-24 12:39:25.796427
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:30.049329
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(http=None)
    assert HitRecordIE._VALID_URL == ie.VALID_URL
    assert HitRecordIE._TEST == ie.TEST

# Generated at 2022-06-24 12:39:31.012846
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE().to_screen('https://www.hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:39:32.953970
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie


# Generated at 2022-06-24 12:39:39.347136
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        global HitRecordIE
    except NameError:
        from .common import InfoExtractor

    info = HitRecordIE._VALID_URL
    assert isinstance(info, str), '%s must be strings' % info

    info = HitRecordIE._TEST
    assert type(info) == dict, '%s must be dictionary' % info

    info = HitRecordIE(None)
    assert isinstance(info, InfoExtractor), '%s must be instance' % info



# Generated at 2022-06-24 12:39:41.063246
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE("HitRecordIE", "http://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:39:42.086080
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:43.839406
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except Exception as e:
        print(e)
        assert False
    assert True

# Generated at 2022-06-24 12:39:46.533707
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'
    assert ie.ie_name() == 'hitrecord'
    assert ie.std_extractors() == [InfoExtractor]

# Generated at 2022-06-24 12:39:49.882251
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert repr(ie).startswith('<') and repr(ie).endswith('>')

# Generated at 2022-06-24 12:39:59.340764
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    assert hitrecord._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:05.865774
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Create instance of class
    hitrecord = HitRecordIE()
    # Test constructor of class
    assert(hasattr(hitrecord, "IE_NAME"))
    assert(isinstance(hitrecord, InfoExtractor))
    assert(hasattr(hitrecord, "BRIGHTCOVE_URL_TEMPLATE"))
    assert(hasattr(hitrecord, "BRIGHTCOVE_VIDEO_INFO_TEMPLATE"))
    assert(hasattr(hitrecord, "_VALID_URL"))
    assert(hasattr(hitrecord, "_TEST"))
    assert(isinstance(hitrecord._TEST, dict))
    assert('url' in hitrecord._TEST)
    assert('md5' in hitrecord._TEST)
    assert('info_dict' in hitrecord._TEST)

# Generated at 2022-06-24 12:40:07.088926
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(HitRecordIE._downloader).suitable('https://hitrecord.org/records/2954362') == True


# Generated at 2022-06-24 12:40:09.724704
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    title = 'A Very Different World (HITRECORD x ACLU)'
    assert title == ie.get_title(id_='2954362')

# Generated at 2022-06-24 12:40:14.932752
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Simple test for constructor of class HitRecordIE
    """
    # Create IE object
    ie = HitRecordIE()
    # Check for all information needed for instantiating of class
    assert ie.ie_key() == "HitRecord"
    assert ie.ie_name() == "HitRecord"
    # Check for correct pattern
    assert ie._VALID_URL == ie.VALID_URL


# Generated at 2022-06-24 12:40:15.529523
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE()

# Generated at 2022-06-24 12:40:19.104540
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('hitrecord', {})
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-24 12:40:21.204814
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(HitRecordIE._VALID_URL);
    print(ie._match_id(HitRecordIE._VALID_URL));

# Generated at 2022-06-24 12:40:29.230285
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._VALID_URL = r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:35.504744
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:37.453230
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    HitRecordIE(None);

# Generated at 2022-06-24 12:40:47.707288
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	obj = HitRecordIE()
	obj._real_extract("http://hitrecord.org/records/2954362")
	assert (obj.id == "2954362")
	assert (obj.ext == "mp4")
	assert (obj.title == "A Very Different World (HITRECORD x ACLU)")

# Generated at 2022-06-24 12:40:48.081779
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-24 12:40:50.065821
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    tester = HitRecordIE()
    tester._match_id('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:40:59.389589
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    info_extractor = InfoExtractor()

    assert HitRecordIE.suitable(
        "https://hitrecord.org/records/2954362") == True, \
        "URL for a hitrecord.org video is not classified as a suitable URL"


    assert HitRecordIE.suitable(
        "www.hitrecord.org") == False, \
        "URL for hitrecord.org is not classified as a suitable URL"

    assert HitRecordIE.suitable(
        "hitrecord.org") == False, \
        "URL for hitrecord.org without protocol is not classified as a suitable URL"

# Generated at 2022-06-24 12:40:59.991792
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:02.831207
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    temp = HitRecordIE("HitRecordIE", "hitrecord.org", "mp4")
    assert temp.name == "HitRecordIE"
    assert temp.ie_key == "hitrecord.org"
    assert temp.format == "mp4"


# Generated at 2022-06-24 12:41:12.360970
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_entry = HitRecordIE._TEST
    video_id = test_entry['info_dict']['id']
    video = HitRecordIE._download_json(
        'https://hitrecord.org/api/web/records/%s' % video_id, video_id)
    assert video.get('id') == video_id
    assert video.get('title') == test_entry['info_dict']['title']
    assert video.get('source_url')['mp4_url'] == test_entry['info_dict']['url']


# HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:41:14.035484
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    search_result = HitRecordIE.search_term('foo')
    print(search_result)

# Generated at 2022-06-24 12:41:15.242019
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._download_json()

# Generated at 2022-06-24 12:41:16.702213
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	print("Running HitRecordIE test")

# Generated at 2022-06-24 12:41:25.228049
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:41:26.836647
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    iege = HitRecordIE()
    assert bool(iege) == True


# Generated at 2022-06-24 12:41:37.713351
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie.id == HitRecordIE._TEST['info_dict']['id']
    assert ie.description == HitRecordIE._TEST['info_dict']['description']
    assert ie.duration == HitRecordIE._TEST['info_dict']['duration']
    assert ie.title == HitRecordIE._TEST['info_dict']['title']
    assert ie.timestamp == HitRecordIE._TEST['info_dict']['timestamp']
    assert ie.uploader == HitRecordIE._TEST['info_dict']['uploader']
    assert ie.uploader_id == HitRecordIE._TEST['info_dict']['uploader_id']
    assert ie.view_count == HitRecordIE._T

# Generated at 2022-06-24 12:41:46.917092
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert_equal(ie._VALID_URL, 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-24 12:41:48.204382
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Make HitRecordIE
    HitRecordIE()


# Generated at 2022-06-24 12:41:49.051335
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:50.026575
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert issubclass(HitRecordIE,InfoExtractor) == True

# Generated at 2022-06-24 12:41:51.957768
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, HitRecordIE)

# Generated at 2022-06-24 12:41:55.259830
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("HitRecordIE", HitRecordIE._VALID_URL, HitRecordIE._TEST)

# Generated at 2022-06-24 12:42:00.332827
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE()
    # info_extractor.asset_base_url = 'https://hitrecord.org' # asset url is not configurable
    # info_extractor.www_base_url = 'https://www.hitrecord.org' # www url is not configurable
    assert info_extractor != None

# Generated at 2022-06-24 12:42:01.326709
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(InfoExtractor)

# Generated at 2022-06-24 12:42:04.200123
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._VALID_URL = HitRecordIE._VALID_URL
    ie._TEST = HitRecordIE._TEST
    ie.matchUrl(ie._TEST['url'])

# Generated at 2022-06-24 12:42:05.936316
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable(HitRecordIE._VALID_URL)

# Generated at 2022-06-24 12:42:08.528963
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    test_values = ie._TEST
    assert(test_values['url'] == ie._VALID_URL)

# Generated at 2022-06-24 12:42:09.627694
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print(HitRecordIE._TEST)

# Generated at 2022-06-24 12:42:13.688701
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  """Unit test for HitRecordIE"""
  ie = HitRecordIE()
  assert ie.name == 'hitrecord'
  # TODO: test other attributes of class HitRecordIE

# Generated at 2022-06-24 12:42:14.280424
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:15.405951
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  ie = HitRecordIE()

# Generated at 2022-06-24 12:42:16.700752
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-24 12:42:17.594750
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:42:19.445702
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert 2954362 == ie._match_id('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:42:30.740539
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:42:32.286307
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2984172'
    q = HitRecordIE(url)

# Generated at 2022-06-24 12:42:33.042838
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE()._VALID_URL

# Generated at 2022-06-24 12:42:39.016393
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    expected_url = "https://hitrecord.org/api/web/records/2954362"
    assert ie._download_json(
        "https://hitrecord.org/api/web/records/2954362", "2954362")
    assert ie.url == "https://hitrecord.org/records/2954362"
    assert ie.video_id == "2954362"
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST[
        'info_dict']['title'] == "A Very Different World (HITRECORD x ACLU)"

# Generated at 2022-06-24 12:42:40.596253
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()



# Generated at 2022-06-24 12:42:50.064900
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    HitRecordIE._VALID_URL = r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    # test if HitRecordIE._TEST = {
    #     'url': 'https://hitrecord.org/records/2954362',
    #     'md5': 'fe1cdc2023bce0bbb95c39c57426aa71',
    #     'info_dict': {
    #         'id': '2954362',
    #         'ext': 'mp4',
    #         'title': 'A Very Different World (HITRECORD x ACLU)',
    #         'description': 'md5:e62defaffab5075a5277736bead95a3d',
    #         '

# Generated at 2022-06-24 12:42:51.086997
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:42:51.699850
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE

# Generated at 2022-06-24 12:43:01.073879
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    url = 'https://hitrecord.org/records/2954362'
    video_id = '2954362'
    
    def _real_extract(self, url):
        video_id = self._match_id(url)
        video = self._download_json(
            'https://hitrecord.org/api/web/records/%s' % video_id, video_id)
        title = video['title']
        video_url = video['source_url']['mp4_url']

        tags = None
        tags_list = try_get(video, lambda x: x['tags'], list)

# Generated at 2022-06-24 12:43:03.256389
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video_id = '2954362'
    HitRecordIE()._real_extract(HitRecordIE._TEST['url']+video_id)

# Generated at 2022-06-24 12:43:13.953450
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    raise NotImplementedError('TODO')
    # from .common import test_to_unicode  # NOQA

    # url = 'https://hitrecord.org/records/2954362'
    # obj = HitRecordIE()
    # assert obj.suitable(url)

    # # 1st: If a suite doesn't have a specific setup, using common.test_to_unicode
    # #   is recommended
    # test_to_unicode(obj, url)

    # # 2nd: Use self.assertIsInstance()
    # self.assertIsInstance(obj, HitRecordIE)
    # # self.assertIsInstance(obj, InfoExtractor)

    # # 3rd: self.assertEqual()
    # self.assertEqual(obj._VALID_URL, HitRecordIE._VALID_URL

# Generated at 2022-06-24 12:43:19.094446
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('http://hitrecord.org/records/2954362')
    assert not ie.suitable('https://www.hitrecord.org/')
    assert not ie.suitable('http://www.hitrecord.org')
    assert not ie.suitable('https://youtube.com/watch?v=uQV4xUNh4_4')


# Generated at 2022-06-24 12:43:25.160995
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Initialize HitRecordIE instance
    i = HitRecordIE()
    # Check if HitRecordIE instance is an InfoExtractor with given url
    assert i.get_info_extractor(i._VALID_URL) == i
    # Check if HitRecordIE instance is an InfoExtractor with given url
    assert i.get_info_extractor(i._TEST['url']) == i

# Generated at 2022-06-24 12:43:26.578102
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Test for constructor of class HitRecordIE
    """
    HitRecordIE()

# Generated at 2022-06-24 12:43:28.086053
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    global hitRecordIE
    hitRecordIE = HitRecordIE()

# Generated at 2022-06-24 12:43:28.587250
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE is InfoExtractor


# Generated at 2022-06-24 12:43:29.486673
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(HitRecordIE._TEST)

# Generated at 2022-06-24 12:43:29.868838
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:31.100910
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(compat_str, compat_str, compat_str)

# Generated at 2022-06-24 12:43:32.575769
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    assert instance._VALID_URL == HitRecordIE._VALID_URL


# Generated at 2022-06-24 12:43:33.286375
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie is not None

# Generated at 2022-06-24 12:43:34.657581
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract()

# Generated at 2022-06-24 12:43:35.872510
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract('hitrecord.org')

# Generated at 2022-06-24 12:43:36.439942
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:39.328965
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:43:41.383990
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('')

    assert hasattr(ie, '_REAL_EXTEND')
    assert ie._REAL_EXTEND is False

# Generated at 2022-06-24 12:43:45.448867
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	info_extractor = HitRecordIE(KalturaIE.IE_NAME)
	assert(info_extractor.ie_key() == KalturaIE.IE_NAME)
	assert(info_extractor.ie_name() == KalturaIE.IE_NAME)

# Generated at 2022-06-24 12:43:47.675188
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE().extract('https://hitrecord.org/records/2954362')
    # Test the empty url
    HitRecordIE().extract(None)

# Generated at 2022-06-24 12:43:50.383158
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test constructor of HitRecordIE
    print("==============================================================================================")
    print(".. Testing HitRecordIE's constructor ...")
    hit_record_ie = HitRecordIE()
    print("   >>> HitRecordIE's constructor test PASSED!!!")
    return hit_record_ie


# Generated at 2022-06-24 12:43:51.258736
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    class_ = HitRecordIE
    assert class_ is not None

# Generated at 2022-06-24 12:43:52.256024
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(0)
    assert ie


# Generated at 2022-06-24 12:43:54.695244
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    e = HitRecordIE()
    assert e._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:43:57.433346
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract_info(
        'https://hitrecord.org/records/2954362', 'Fake video', 'Fake video hash')

# Generated at 2022-06-24 12:43:58.255679
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('HitRecordIE')._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-24 12:43:59.186856
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(object())

# Generated at 2022-06-24 12:44:00.806949
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('HitRecord', 'https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:44:02.390237
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Tests the object is created using default constructor
    assert HitRecordIE(HitRecordIE.ie_key())

# Generated at 2022-06-24 12:44:02.877825
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-24 12:44:04.778059
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except NameError as e:
        print(e)
    else:
        raise AssertionError("Exception should have been thrown")

# Generated at 2022-06-24 12:44:12.102097
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # test URL
    hitrecord_ie = HitRecordIE()
    hitrecord_ie.download('https://hitrecord.org/records/2954362')
    # test date
    date = 1132450206.0
    timestamp = int(date)
    upload_date = '20061013'
    assert timestamp == hitrecord_ie._match_id(upload_date)
    # test search function
    query = 'test 123'
    query = hitrecord_ie._search_regex(r'(.*)', query, '', default=None)
    assert query == 'test 123'

# Generated at 2022-06-24 12:44:13.446484
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:44:16.308705
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie._VALID_URL == "https?://(?:www.)?hitrecord.org/records/(?P<id>\d+)"

# Generated at 2022-06-24 12:44:17.722180
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE == InfoExtractor.__getitem__(HitRecordIE._VALID_URL)

# Generated at 2022-06-24 12:44:28.069622
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:31.224138
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('hitrecord')._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:40.310630
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE().suitable('https://hitrecord.org/records/2954362')
    assert HitRecordIE().suitable('https://hitrecord.org/records/2954362')
    assert not HitRecordIE().suitable('https://hitrecord.org/records/')
    assert not HitRecordIE().suitable('https://hitrecord.org/records')
    assert not HitRecordIE().suitable('https://hitrecord.org/records/?blabla')
    assert not HitRecordIE().suitable('https://hitrecord.org/records/%X')
    assert not HitRecordIE().suitable('https://hitrecord.org/records/_')
    assert not HitRecordIE().suitable('https://hitrecord.org/records/')
    # For HitRecordIE, can't find an example of wrong url

# Generated at 2022-06-24 12:44:40.860585
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE

# Generated at 2022-06-24 12:44:42.852031
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._TEST['url'] == ie._VALID_URL % ie._TEST['info_dict']['id']

# Generated at 2022-06-24 12:44:51.125425
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://hitrecord.org/records/2954362') == True
    assert ie.suitable('http://www.hitrecord.org/records/2954362')
    assert ie.suitable('http://www.hitrecord.org/records/2954362') == True
    assert ie.suitable('http://www.hitrecord.org/records/295436200000000')
    assert ie.suitable('http://www.hitrecord.org/records/295436200000000') == False

# Generated at 2022-06-24 12:45:02.540623
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:45:03.901577
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    h = HitRecordIE()
    assert h == test_HitRecordIE()

# Generated at 2022-06-24 12:45:04.878580
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie is not None

# Generated at 2022-06-24 12:45:12.575228
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:17.478037
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test case 1
    url = 'https://hitrecord.org/records/2954362'
    instance = HitRecordIE()
    assert instance._match_id(url) == '2954362'
    assert instance._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:19.227955
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL is not None
    assert HitRecordIE._TEST is not None

# Generated at 2022-06-24 12:45:20.294262
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL

# Generated at 2022-06-24 12:45:23.199396
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()
    return 0

if __name__ == "__main__":
    import sys
    sys.exit(test_HitRecordIE())

# Generated at 2022-06-24 12:45:29.996517
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_object = HitRecordIE()
    assert test_object._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert (test_object._TEST['url'] == 'https://hitrecord.org/records/2954362')
    assert (test_object._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71')
    assert (test_object._TEST['info_dict']['id'] == '2954362')
    assert (test_object._TEST['info_dict']['ext'] == 'mp4')
    assert (test_object._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)')
   

# Generated at 2022-06-24 12:45:32.148362
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:45:39.944866
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	he = HitRecordIE()
	assert(he._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')
	assert(he._TEST['url'] == 'https://hitrecord.org/records/2954362')
	assert(he._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71')

# Generated at 2022-06-24 12:45:41.269532
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test no url
    assert HitRecordIE._VALID_URL() == False

# Generated at 2022-06-24 12:45:45.422581
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_key() in InfoExtractor._AVAILABLE_IE

# Generated at 2022-06-24 12:45:47.786925
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE()
    assert info_extractor._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-24 12:45:48.447899
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('HitRecord')

# Generated at 2022-06-24 12:45:49.412175
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_ie = HitRecordIE()

# Generated at 2022-06-24 12:45:58.332993
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-24 12:45:59.151106
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-24 12:46:09.590656
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.SUFFIX == ''
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:46:14.933043
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from bs4 import BeautifulSoup

    url = 'https://hitrecord.org/records/2954362'
    video_id = '2954362'

    html = HitRecordIE()._download_webpage(url, video_id)
    soup = BeautifulSoup(html)
    id = soup.find('meta', {'property': 'og:url'}).get('content').split('/')[-1]

    assert id == video_id

# Generated at 2022-06-24 12:46:15.324076
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:24.977250
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:46:29.991457
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    e = HitRecordIE('https://hitrecord.org/records/2954362')
    assert e._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert e._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert e._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-24 12:46:33.747860
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test with an url that passes the regex
    url = HitRecordIE._make_url('https://hitrecord.org/records/2954362')
    assert HitRecordIE._VALID_URL == HitRecordIE._TEST['url']

    # Test with an url that does not pass the regex
    url = HitRecordIE._make_url('https://hitrecord.org/records/')
    assert HitRecordIE._VALID_URL != HitRecordIE._TEST['url']

# Generated at 2022-06-24 12:46:35.566786
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:46:43.046917
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from .common import InfoExtractor
    from ..compat import compat_str
    from ..utils import (
        clean_html,
        float_or_none,
        int_or_none,
        try_get,
    )

    ie = InfoExtractor()
    ie.initialize()
    video = ie._download_json(
        'https://hitrecord.org/api/web/records/2954362', '2954362')
    title = video['title']
    video_url = video['source_url']['mp4_url']

    tags = None
    tags_list = try_get(video, lambda x: x['tags'], list)

# Generated at 2022-06-24 12:46:44.013991
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:46:45.577036
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordTest = HitRecordIE()
    assert isinstance(hitRecordTest, InfoExtractor) == True

# Generated at 2022-06-24 12:46:47.191533
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = HitRecordIE._TEST['url']
    info = HitRecordIE().extract_info(url)
    assert info['url'] == HitRecordIE._TEST['md5']

# Generated at 2022-06-24 12:46:48.805089
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(HitRecordIE.IE_NAME).ie_key() == HitRecordIE.IE_NAME

# Generated at 2022-06-24 12:46:52.705758
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    url = 'https://hitrecord.org/records/2954362'
    expected_id = '2954362'
    assert ie._match_id(url) == expected_id

# Generated at 2022-06-24 12:46:54.585322
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:46:59.833573
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Instantiating an object of the class HitRecordIE
    yt = HitRecordIE()

    # Assigning the URL to the variable
    test_url = 'https://hitrecord.org/records/2954362'

    # Extracting information from the URL
    info = yt.extract(test_url)

    # Printing the ID of the video
    print(info['id'])

    # Printing the title of the video
    print(info['title'])

    # Printing the length of the video in seconds (duration)
    print(info['duration'])

    # Printing the timestamp at which the video was uploaded (timestamp)
    print(info['timestamp'])

    # Printing the uploader of the video (uploader)
    print(info['uploader'])

    # Printing the ID of the uploader (uploader_

# Generated at 2022-06-24 12:47:02.895022
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Assert that the constructor of HitRecordIE does not throw an exception
    HitRecordIE("https://www.hitrecord.org/records/3997521")