

# Generated at 2022-06-24 12:37:12.035743
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362/test')

# Generated at 2022-06-24 12:37:12.614546
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:37:22.033942
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert ie.name == "hitrecord"
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:37:23.643543
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('hitrecord.org', 'HitRecordIE')

# Generated at 2022-06-24 12:37:28.069174
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == "hitrecord"
    assert ie.extract("https://hitrecord.org/records/2954362")
    #assert ie.suitable("https://hitrecord.org/records/2954362") == True

# Generated at 2022-06-24 12:37:29.223073
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == "hitrecord"

# Generated at 2022-06-24 12:37:31.770889
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:37:33.387019
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:37:36.783870
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'hitrecord'
    assert ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:37:38.699559
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    _ = HitRecordIE(HitRecordIE._VALID_URL, HitRecordIE._TEST)

# Generated at 2022-06-24 12:37:45.830318
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord:record'
    assert 'hitrecord.org/records/' in ie._VALID_URL
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:37:46.421189
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
        HitRecordIE()

# Generated at 2022-06-24 12:37:52.286985
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == HitRecordIE._VALID_URL
    assert ie._TEST == HitRecordIE._TEST
    assert ie._real_extract == HitRecordIE._real_extract
    assert ie.IE_NAME == HitRecordIE.IE_NAME
    assert ie.__name__ == HitRecordIE.__name__

# Generated at 2022-06-24 12:37:53.909788
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-24 12:37:55.885866
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Unit test for constructor of class HitRecordIE
    """
    hit_record_ie = HitRecordIE()

    assert hit_record_ie.get_info_extractor() == "HitRecordIE"

# Generated at 2022-06-24 12:38:02.778199
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')


# Generated at 2022-06-24 12:38:03.445984
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:06.906830
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:12.814203
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'


# Generated at 2022-06-24 12:38:13.870037
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:38:18.607670
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records/2954362/sample-videos')

# Generated at 2022-06-24 12:38:20.007691
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:38:30.427987
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE()
    assert info_extractor.__name__ == 'HitRecord'
    assert info_extractor.ie_key() == 'hitrecord'
    assert info_extractor._WORKING == True
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:35.815067
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    url = 'https://hitrecord.org/records/2954362'
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie.suitable(url)
    assert ie.ie_key() == 'HitRecord'

# Generated at 2022-06-24 12:38:36.386913
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-24 12:38:42.030113
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  ie = HitRecordIE('hitrecord.org', 'HitRecordIE.name')
  expected_regex = r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
  assert ie.VALID_URL == expected_regex
  assert ie.name == 'HitRecordIE.name'
  assert ie.WEB_PAGE_URL == 'https://hitrecord.org'

# Generated at 2022-06-24 12:38:43.065147
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    print(ie._VALID_URL)

# Generated at 2022-06-24 12:38:52.938359
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:53.902717
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_HitRecordIE.ee = HitRecordIE()



# Generated at 2022-06-24 12:39:00.744325
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    url = "https://hitrecord.org/records/2954362"
    assert ie.suitable(url)

    # extract and count number of non-empty keys as feature tests
    info = ie.extract(url)
    non_empty_keys = 0

    # count non empty keys
    for key, value in info.items():
        if value:
            non_empty_keys += 1

    assert non_empty_keys == 13

# Generated at 2022-06-24 12:39:02.381848
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Test the constructor of class HitRecordIE.
    """
    HitRecordIE()

# Generated at 2022-06-24 12:39:03.660577
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:39:04.225312
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:39:05.898907
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('HitRecordIE','hitrecord.org','https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:39:07.643440
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ie = HitRecordIE()
	assert ie.extract(test_HitRecordIE._TEST)

# Generated at 2022-06-24 12:39:08.228501
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:10.675955
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("HitRecordIE", "https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:39:11.274625
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:14.521749
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Simple test case to check the constructor of class HitRecordIE and to
    perform basic get info extraction.
    """
    url = 'https://hitrecord.org/records/2954362'
    HitRecordIE().extract(url)

# Generated at 2022-06-24 12:39:15.886590
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE()._test_extract_info('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:39:23.862388
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Test for HitRecordIE constructor."""
    ie_obj = HitRecordIE('http://hitrecord.org/records/2954362')
    expected_url = "https://hitrecord.org/api/web/records/2954362"
    assert(ie_obj._VALID_URL == 'http[s]?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')
    assert(ie_obj._TEST['url'] == 'https://hitrecord.org/records/2954362')
    assert(ie_obj._download_json('https://hitrecord.org/api/web/records/2954362', {'id'}) == '2954362')

# Generated at 2022-06-24 12:39:24.702441
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.suite()

# Generated at 2022-06-24 12:39:29.513994
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-24 12:39:30.162066
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:33.042395
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    x = HitRecordIE()
    assert x.ie_key() == 'hitrecord'
    assert x.info_dict is None

# Generated at 2022-06-24 12:39:33.629800
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:34.693096
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:39:43.402996
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Constructor test
    """
    ie = HitRecordIE(HitRecordIE._downloader)
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert not ie.valid_url('http://google.com/?q=hitrecord')
    assert ie.valid_url('https://hitrecord.org/records/2954362', ie.ie_key())
    assert ie.valid_url('http://google.com/?q=hitrecord', ie.ie_key())

# Generated at 2022-06-24 12:39:46.884424
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    url = "https://hitrecord.org/records/2954362"
    expected = ie._VALID_URL
    # Test with actual input data
    match = ie._VALID_URL_RE.match(url)
    # Assert the equality of Regex match and expected output
    assert match.group() == expected

# Generated at 2022-06-24 12:39:48.586511
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL

# Generated at 2022-06-24 12:39:52.092699
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Tested on: https://hitrecord.org/records/2954362
    #
    # This video is not available online any more.
    # We just check that it is not None.
    unit = HitRecordIE()
    assert unit is not None

# Generated at 2022-06-24 12:40:01.082217
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    #  ie = HitRecordIE('x', 'y', 'z')
    #  print type(ie)
    #  print ie
    #  print dir(ie)

# Generated at 2022-06-24 12:40:01.729376
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    #Constructor
    HitRecordIE()

# Generated at 2022-06-24 12:40:10.049777
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
# Set values of member variables
    ie.url = 'http://hitrecord.org/records/2954362'
# Get the output of method real_extract()
    test_output = ie._real_extract(ie.url)
# Compare the expected output and the output of real_extract()
    assert test_output.get('id') == ie._TEST.get('info_dict').get('id')
    assert test_output.get('title') == ie._TEST.get('info_dict').get('title')

# Generated at 2022-06-24 12:40:11.826606
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
   ie = HitRecordIE(None, None, None)
   assert ie is not None

# Generated at 2022-06-24 12:40:14.741430
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    import sys
    import os
    sys.path.append(os.path.realpath('youtube_dl'))
    from youtube_dl.extractor.hitrecord import HitRecordIE
    hitrecordie = HitRecordIE();

# Generated at 2022-06-24 12:40:15.709994
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_case = HitRecordIE()

# Generated at 2022-06-24 12:40:17.056432
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE().extract(test_HitRecordIE._TEST['url'])

# Generated at 2022-06-24 12:40:18.567410
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('test url', None)

# Generated at 2022-06-24 12:40:27.433571
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HITRECORD'
    assert ie.VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:32.277544
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# Test for a valid url
	url = "https://hitrecord.org/records/2954362"
	assert HitRecordIE._VALID_URL(url)

	# Test for a non-valid extension
	url = "https://hitrecord.org/records/2954362/fake_extension"
	assert HitRecordIE._VALID_URL(url) == False

	# Test for a non-valid url
	url = "https://hitrecord.org/records/2954362/0"
	assert HitRecordIE._VALID_URL(url) == False

# Generated at 2022-06-24 12:40:33.796126
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")

# Test for unit test of class constructor
test_HitRecordIE()

# Generated at 2022-06-24 12:40:34.762301
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert(HitRecordIE() != None)

# Generated at 2022-06-24 12:40:36.505746
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE().extract(HitRecordIE._TEST['url'])

# Generated at 2022-06-24 12:40:38.922352
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    if ie._VALID_URL == None:
        raise AssertionError('Invalid URL')
    if ie._TEST == None:
        raise AssertionError('Invalid Test')
    return

# Generated at 2022-06-24 12:40:43.104820
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:44.878673
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    s = HitRecordIE()

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:40:46.130281
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HitRecordIE(HitRecordIE._download_json)


# Generated at 2022-06-24 12:40:53.706109
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:56.315968
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')["title"]



# Generated at 2022-06-24 12:40:57.609479
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_ie = HitRecordIE()
    assert hitrecord_ie._VALID_URL == HitRecordIE._VALID_URL
    assert hitrecord_ie._TEST == HitRecordIE._TEST

# Generated at 2022-06-24 12:41:01.485364
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.get_url_re() == 'YW5kcm9pZG9lcmlraXNjaGx5IEluZmVjdGlvbiBFYXN0aW5nIDEgU3RyZWFtZmFibGU='
    assert ie.get_input_re() == 'YW5kcm9pZG9lcmlraXNjaGx5IEluZmVjdGlvbiBFYXN0aW5nIDEgU3RyZWFtZmFibGU='

# Generated at 2022-06-24 12:41:02.790485
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()     # does not raise exception



# Generated at 2022-06-24 12:41:03.488323
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:04.701049
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:41:06.990884
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    print(ie.SUITES)

# Generated at 2022-06-24 12:41:09.685216
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    url = "https://hitrecord.org/records/2954362"
    print(ie._VALID_URL)
    print(ie._TEST)

# Generated at 2022-06-24 12:41:11.391671
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        instance = HitRecordIE('http://hitrecord.org/records/2954362')

        assert(instance==True)
    except:
        assert(False)


# Generated at 2022-06-24 12:41:13.827366
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.workingDir = "/tmp/"
    ie.download("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:41:14.280214
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:24.130585
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:41:34.830612
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # test case #1, input url is invalid
    url = "https://www.google.com"
    ie = HitRecordIE()
    try:
        ie._real_extract(url)
        print("Test case #1: Invalid url is given")
    except ValueError:
        print("Test case #1: Invalid url is given, pass")

    # test case #2, input url is valid
    url = "https://hitrecord.org/records/2954362"
    ie = HitRecordIE()
    try:
        ie._real_extract(url)
        print("Test case #2: Valid url is given, but failure")
    except UnicodeEncodeError:
        print("Test case #2: Valid url is given, pass")

# Generated at 2022-06-24 12:41:38.243717
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # unit test for HitRecordIE
    d = HitRecordIE('HitRecordIE')
    print(d.extract('https://hitrecord.org/records/2954362'))


if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:41:40.895994
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video_url = "https://hitrecord.org/records/2954362"
    assert HitRecordIE().suitable(video_url)
    assert HitRecordIE().extract_url(video_url) == '2954362'

# Generated at 2022-06-24 12:41:42.676386
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert type(ie).__name__ == 'HitRecordIE'


if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:41:46.774072
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    try:
        ie.suitable('http://hitrecord.org/records/206666')
        ie.suitable('http://www.hitrecord.org/records/206666')
    except:
        assert False
    try:
        ie.suitable('http://hitrecord.org/records/206666/test')
        ie.suitable('http://www.hitrecord.org/records/206666/test')
    except:
        assert True

# Generated at 2022-06-24 12:41:57.319548
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:41:58.891557
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HitRecordIE()

# Test for test_HitRecordIE

# Generated at 2022-06-24 12:41:59.603775
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie



# Generated at 2022-06-24 12:42:00.149012
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()



# Generated at 2022-06-24 12:42:01.185775
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE



# Generated at 2022-06-24 12:42:01.784418
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE()

# Generated at 2022-06-24 12:42:09.749962
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('http://hitrecord.org/records/2954362')
    assert ie.REAL_URL == 'https://hitrecord.org/records/2954362'
    assert str(ie.info_dict['url']) == 'https://hitrecord.org/api/web/records/2954362'
    assert ie.info_dict['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie.info_dict['id'] == '2954362'
    assert ie.info_dict['uploader_id'] == '362811'
    assert ie.info_dict['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:42:10.497991
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:16.390494
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    def run_test(test_url, test_dict, ie):
        result = ie.url_result(test_url)
        result.test_result(test_dict)
    ie = HitRecordIE()
    for t in ie._TEST:
        run_test(t['url'], t['info_dict'], ie)

# Generated at 2022-06-24 12:42:17.935399
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:42:19.421097
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:42:22.332305
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Create a HitRecordIE object
    hitRecordIE = HitRecordIE('')
    assert hitRecordIE == hitRecordIE

# Generated at 2022-06-24 12:42:25.201442
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._real_extract('https://hitrecord.org/records/2954362')

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:42:26.609385
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-24 12:42:29.057135
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'
    assert ie.ie_name() == 'HitRecord'

# Generated at 2022-06-24 12:42:36.784618
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  """
  Asserts if instance of HitRecordIE is created with valid url,
  and if the url is not valid the constructor does not create an instance.
  """
  def create_HitRecordIE(url):
    return HitRecordIE(HitRecordIE._create_ie(url))

  assert create_HitRecordIE('https://hitrecord.org/records/2954362')
  assert create_HitRecordIE('http://hitrecord.org/records/2954362')
  assert create_HitRecordIE('www.hitrecord.org/records/2954362')
  assert create_HitRecordIE('hitrecord.org/records/2954362')
  assert create_HitRecordIE('https://www.hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:42:37.750944
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-24 12:42:39.774581
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362")


# Generated at 2022-06-24 12:42:44.763543
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # test for https://hitrecord.org/records/2954362
    HitRecordIE()._real_extract("https://hitrecord.org/records/2954362")
    # test for https://hitrecord.org/records/2954362
    HitRecordIE()._real_extract("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:42:45.692297
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HitRecordIE(None)

# Generated at 2022-06-24 12:42:48.342970
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    url = 'https://hitrecord.org/records/2954362'
    video_id = ie._match_id(url)
    assert video_id

# Generated at 2022-06-24 12:42:56.484851
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    # Unit test of constructor, it should return the name of the class
    hit_record_ie = HitRecordIE()
    assert hit_record_ie.ie_key() == 'HitRecord'
    # Unit test of the function extract
    assert hit_record_ie.extract(url)
    # Unit test of the function suitable
    assert hit_record_ie.suitable(url)
    # Unit test of the function _match_id
    assert hit_record_ie._match_id(url) == '2954362'

# Generated at 2022-06-24 12:42:57.048509
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE()

# Generated at 2022-06-24 12:42:58.144049
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._download_json('https://hitrecord.org/api/web/records/2954362', 2954362)

# Generated at 2022-06-24 12:42:58.724213
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(object)

# Generated at 2022-06-24 12:42:59.252889
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:06.409320
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)', "URL regex is not correct"
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362', "Test URL is not correct"
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71', "Test MD5 is not correct"

# Generated at 2022-06-24 12:43:16.388849
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print("Testing HitRecordIE constructor.")
    hitrecord = HitRecordIE("")

    assert hitrecord._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)', "HitRecordIE._VALID_URL failed!"
    assert hitrecord._TEST['url'] == 'https://hitrecord.org/records/2954362', "HitRecordIE._TEST failed!"
    assert hitrecord._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71', "HitRecordIE._TEST failed!"
    assert hitrecord._TEST['info_dict']['id'] == '2954362', "HitRecordIE._TEST failed!"

# Generated at 2022-06-24 12:43:17.847610
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    constructor = HitRecordIE()
    print("Successfully created Instance of HitRecordIE")

# Generated at 2022-06-24 12:43:19.366439
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('HitRecordIE', 'hitrecord.org')
    assert True

# Generated at 2022-06-24 12:43:20.533028
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(None) is not None

# Generated at 2022-06-24 12:43:21.110129
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:31.569469
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    r"""
    HitRecordIE test with info dict which is called by test.py.
    Please use python -m pytest test.py to test.
    """
    Test = HitRecordIE

# Generated at 2022-06-24 12:43:33.095546
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'


# Generated at 2022-06-24 12:43:41.005770
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.get_info_extractor_types()[0] == 'url'
    assert ie.get_info_extractor_types()[1] == 'md5'
    assert ie.get_info_extractor_types()[2] == 'info_dict'
    assert ie.get_info_extractor_types()[3] == 'no_skip'
    assert ie.get_info_extractor_types()[4] == 'playlist_title'
    assert ie.get_info_extractor_types()[5] == 'playlist_mincount'


# Generated at 2022-06-24 12:43:41.586440
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:50.766076
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(InfoExtractor())
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:43:51.444390
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:53.903385
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitreacord_unit_test = HitRecordIE(None)
    assert hitreacord_unit_test.suitable('https://hitrecor.org/records/2954362')
    assert not hitreacord_unit_test.suitable('https://hitrecor.org/home')

# Generated at 2022-06-24 12:44:03.656269
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-24 12:44:08.803054
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    import math
    import random
    from decimal import Decimal
    from fractions import Fraction
    from unittest.case import TestCase

    import google.protobuf.duration_pb2 as duration_pb2
    from nose2.tools import params
    from .nose_tools import youtube_it_matches, assert_raises_regexp
    from .common import InfoExtractor

    def _make_valid_value(value):
        return value if value is not None else 0


# Generated at 2022-06-24 12:44:16.617295
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    assert hitrecord.ie_key() == 'HitRecord'
    assert hitrecord.video_id == None
    assert hitrecord.title == None
    assert hitrecord.description == None
    assert hitrecord.webpage == None
    assert hitrecord.duration == None
    assert hitrecord.timestamp == None
    assert hitrecord.uploader == None
    assert hitrecord.uploader_id == None
    assert hitrecord.view_count == None
    assert hitrecord.like_count == None
    assert hitrecord.comment_count == None
    assert hitrecord.tags == None
    assert hitrecord.thumbnail == None
    assert hitrecord._downloader == None

# Generated at 2022-06-24 12:44:26.899172
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    info = ie.extract("http://hitrecord.org/records/2954362")
    assert info != None
    assert info["id"] == "2954362"

# Generated at 2022-06-24 12:44:28.271367
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.url_result('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:44:29.255717
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:44:32.469141
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    # assert ie._VALID_URL is not None
    assert ie._TEST is not None


# Generated at 2022-06-24 12:44:34.898039
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Test HitRecordIE
    """
    from .. import YoutubeIE
    assert HitRecordIE._TEST['url'] == YoutubeIE._TEST['url']

# Generated at 2022-06-24 12:44:36.073872
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-24 12:44:36.657856
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-24 12:44:43.261866
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    test_1 = ie._VALID_URL
    assert test_1.find('(?P<id>\d+)') is not -1
    test_2 = ie._TEST
    assert test_2['description'].find('md5:e62defaffab5075a5277736bead95a3d') is not -1
    assert test_2['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert test_2['info_dict']['id'] == '2954362'
    assert test_2['info_dict']['ext'] == 'mp4'
    assert test_2['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:44:45.134856
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE([])._VALID_URL is not None

# Generated at 2022-06-24 12:44:45.726684
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:44:47.269611
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """ Test download of a video from HitRecord """
    HitRecordIE()

# Generated at 2022-06-24 12:44:48.706984
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except TypeError:
        pass

# Generated at 2022-06-24 12:44:52.385142
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	dummy = HitRecordIE()
	assert HitRecordIE._VALID_URL == dummy._VALID_URL
	assert HitRecordIE._TEST['url'] == dummy._TEST['url']
	assert HitRecordIE._TEST['md5'] == dummy._TEST['md5']
	assert HitRecordIE._TEST['info_dict'] == dummy._TEST['info_dict']

# Generated at 2022-06-24 12:44:56.085475
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    a = HitRecordIE()
    url = a._VALID_URL
    assert url == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:57.311317
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_HitRecordIE.HitRecordIE(dict());

# Generated at 2022-06-24 12:44:57.918033
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:44:58.472712
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:44:59.506838
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hr = HitRecordIE()
    assert hr is not None

# Generated at 2022-06-24 12:45:00.405501
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    assert hitrecord


# Unit tests for HitRecordIE

# Generated at 2022-06-24 12:45:02.559348
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Unit test for constructor of class HitRecordIE
    """
    ie = HitRecordIE('hitrecord.org')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:11.137796
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_url = HitRecordIE._TEST['url']
    test_video_id = HitRecordIE._TEST['info_dict']['id']
    test_video = HitRecordIE._download_json(
        'https://hitrecord.org/api/web/records/%s' % test_video_id, test_video_id)
    test_title = test_video['title']
    test_video_url = test_video['source_url']['mp4_url']
    test_tags = None
    test_tags_list = try_get(test_video, lambda x: x['tags'], list)

# Generated at 2022-06-24 12:45:12.479953
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = HitRecordIE.VALID_URL
    HitRecordIE(url)

# Generated at 2022-06-24 12:45:13.563012
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    print(ie)

# Generated at 2022-06-24 12:45:17.476164
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE(HitRecordIE.__name__)
    assert hitRecordIE.NAME == HitRecordIE.__name__
    assert hitRecordIE.IE_NAME == HitRecordIE.__name__.lower()
    assert hitRecordIE.TEST == HitRecordIE._TEST

# Generated at 2022-06-24 12:45:25.912469
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST.get('info_dict')['id'] == '2954362'
    assert ie._TEST.get('info_dict')['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert ie._TEST.get('info_dict')['duration'] == 139.327

# Generated at 2022-06-24 12:45:26.626332
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE() is not None

# Generated at 2022-06-24 12:45:30.825642
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # A dummy URL
    URL = "http://hitrecord.org/records/2954362"
    obj = HitRecordIE()
    # Call method _real_extract with parameter URL
    result = obj._real_extract(URL)
    # Check fields in result
    for k in ['id', 'url', 'title', 'description', 'duration',
              'timestamp', 'uploader', 'uploader_id', 'view_count',
              'like_count', 'comment_count', 'tags']:
        assert k in result



# Generated at 2022-06-24 12:45:33.517450
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    '''
    Test for constructor of class HitRecordIE
    '''
    ie = HitRecordIE()
    ie.extract_info(u'https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:45:35.048980
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    assert hitRecordIE != None

# Generated at 2022-06-24 12:45:36.269119
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:45:38.215020
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    import HitRecordIE
    HitRecordIE.HitRecordIE._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:45:39.481443
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:45:51.258823
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:52.246937
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE({})
    ie.to_screen('hitrecord')

# Generated at 2022-06-24 12:45:53.525817
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('http://www.hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:45:54.202356
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Constructor of class does nothing
    HitRecordIE()

# Generated at 2022-06-24 12:45:56.128594
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Can't use constructor due to importing of try_get function
    he = HitRecordIE()
    return he._TEST['url']

# Generated at 2022-06-24 12:45:58.364411
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Note -- this test fails currently because of an API change:
    https://github.com/rg3/youtube-dl/issues/17409
    """
    assert HitRecordIE()

# Generated at 2022-06-24 12:46:00.310730
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.download("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:46:03.110331
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE(): # use 'python -m unittest' to test class
    # Unit test for constructor of class HitRecordIE
    assert HitRecordIE('test_HitRecordIE')

# Generated at 2022-06-24 12:46:04.124910
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_HitRecordIE()

# Generated at 2022-06-24 12:46:05.470333
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test HitRecordIE constructor
    HitRecordIE()
    assert(True)

# Generated at 2022-06-24 12:46:07.006639
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    infoExtractor = HitRecordIE()
    assert infoExtractor is not None

# Generated at 2022-06-24 12:46:09.409582
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(1, 2, 3)
    assert ie.ie_key() == 'HitRecord'
    assert ie.ie_name() == 'HitRecord'

# Generated at 2022-06-24 12:46:10.064647
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:10.541848
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:11.716686
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-24 12:46:14.543509
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecordie = HitRecordIE()
    assert hitrecordie.name == 'HitRecord'
    assert hitrecordie.ie_key() == 'HitRecord'
    assert isinstance(hitrecordie.ie_key(), str)

# Generated at 2022-06-24 12:46:17.152517
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:46:17.699544
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:46:18.762595
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('url')

# Generated at 2022-06-24 12:46:20.025370
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:46:22.725322
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-24 12:46:31.338302
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    import sys
    import urllib.parse
    from .common import InfoExtractor
    from .hitrecord import HitRecordIE
    from .brightcove import BrightcoveIE
    from .brightcove_new import BrightcoveNewIE
    from .generic import GenericIE
    from .youtube import YoutubeIE
    from .youtube_dl import YoutubeDL
    extractor_classes = [
        YoutubeIE,
        HitRecordIE,
        BrightcoveNewIE,
        BrightcoveIE,
        GenericIE
    ]
    for ie in extractor_classes:
        if ie in globals():
            globals()[ie.__name__] = ie
    # unit test rule 1
    i = HitRecordIE(InfoExtractor())

# Generated at 2022-06-24 12:46:32.763155
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE('https://hitrecord.org/records/2954362').test()

# Generated at 2022-06-24 12:46:34.118822
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:35.912553
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE().extract("http://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:46:38.016155
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Basic test to check constructor of class HitRecordIE
    hit_record = HitRecordIE()
    if hit_record:
        assert True
    else:
        assert False


# Generated at 2022-06-24 12:46:41.803493
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test for ID 2954362 (A Very Different World (HITRECORD x ACLU))
    id = '2954362'
    url = 'https://hitrecord.org/records/2954362'
    (valid, reason) = HitRecordIE._match_id(HitRecordIE, url)
    assert(valid)
    assert(id == reason)

# Generated at 2022-06-24 12:46:43.037410
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Basic test of HitRecordIE
    """
    HitRecordIE()

# Generated at 2022-06-24 12:46:44.276046
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Test for constructor of class HitRecordIE"""
    HitRecordIE()

# Generated at 2022-06-24 12:46:46.744889
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    url = 'https://hitrecord.org/records/2954362'
    # Video ID
    assert ie.getVideoId(url) == '2954362'

# Generated at 2022-06-24 12:46:51.567537
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL.match('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL.match('http://hitrecord.org/records/2954362')
    assert not ie._VALID_URL.match('https://hitrecord.org/?')

# Generated at 2022-06-24 12:46:53.126023
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	print("testing HitRecordIE ")

# Generated at 2022-06-24 12:46:55.637249
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE()
    assert hitRecord is not None

if __name__ == '__main__':
    
    test_HitRecordIE()

# Generated at 2022-06-24 12:46:57.352888
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie = HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:46:59.358960
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HitRecordIE = HitRecordIE()
	assert HitRecordIE.extract_info("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:47:10.064677
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'