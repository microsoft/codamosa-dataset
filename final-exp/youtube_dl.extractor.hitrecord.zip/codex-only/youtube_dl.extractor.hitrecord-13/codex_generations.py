

# Generated at 2022-06-24 12:37:14.883584
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Unit test for constructor of class HitRecordIE"""
    instance = HitRecordIE()
    assert type(instance._VALID_URL) is str
    assert type(instance._TEST) is dict
    assert instance._TEST['url'] is 'https://hitrecord.org/records/2954362'
    assert instance._TEST['md5'] is 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert type(instance._TEST['info_dict']) is dict
    assert instance._TEST['info_dict']['id'] is '2954362'
    assert instance._TEST['info_dict']['ext'] is 'mp4'
    assert instance._TEST['info_dict']['title'] is 'A Very Different World (HITRECORD x ACLU)'
    assert instance

# Generated at 2022-06-24 12:37:17.252555
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')


# Generated at 2022-06-24 12:37:17.796608
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:37:18.211876
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-24 12:37:28.811263
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.IE_NAME == 'hitrecord'
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:37:35.842366
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    testHitRecordIE = HitRecordIE()
    assert testHitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert testHitRecordIE._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert testHitRecordIE._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    

# Generated at 2022-06-24 12:37:37.132512
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(isinstance(ie, InfoExtractor))

# Generated at 2022-06-24 12:37:45.012448
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:37:45.563040
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:37:47.145483
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'

# Generated at 2022-06-24 12:37:57.721818
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:37:58.234838
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:02.912402
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')
    # If the video is not there, this will throw an error and the unit test will be a failure.
    # If the video is there, then the unit test will pass.

# Generated at 2022-06-24 12:38:13.156342
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test with sample from test/test_HitRecordIE.py
    url = 'https://hitrecord.org/records/2954362'
    hitrecord = HitRecordIE()
    info = hitrecord._real_extract(url)
    # Testing details on the video
    assert info['id'] == '2954362'
    assert info['url'] == 'http://hitrecord-uploads.s3.amazonaws.com/uploads/video/source_file/664229/HRC_065_Tribunal_Finished_v2.mp4'
    assert info['title'] == 'A Very Different World (HITRECORD x ACLU) by Zuzi.C12'

# Generated at 2022-06-24 12:38:14.534954
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'

# Generated at 2022-06-24 12:38:17.423252
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('http://www.hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:38:19.911003
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    e = HitRecordIE()
    e.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:38:20.901703
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-24 12:38:21.549326
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:22.988223
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    constructor = HitRecordIE('HitRecordIE')
    assert constructor != None

# Generated at 2022-06-24 12:38:32.700221
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-24 12:38:42.243618
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-24 12:38:51.847886
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie_obj = HitRecordIE()
    assert ie_obj._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:39:00.357200
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    a = HitRecordIE()
    assert a._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:39:01.569090
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()
    assert obj.get_url_regex() == obj._VALID_URL
    assert obj.get_test() == obj._TEST

if __name__ == "__main__":
    test_HitRecordIE()

# Generated at 2022-06-24 12:39:03.000684
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(HitRecordIE._VALID_URL, {})

# Generated at 2022-06-24 12:39:13.341465
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test = HitRecordIE()

# Generated at 2022-06-24 12:39:23.700404
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-24 12:39:36.024548
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie.IE_NAME == 'hitrecord:record'
    assert ie.IE_DESC == 'HitRecord'

# Generated at 2022-06-24 12:39:38.674947
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Test case constructor of class HitRecordIE"""
    ie = HitRecordIE()
    assert ie != None

# Generated at 2022-06-24 12:39:39.921721
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-24 12:39:42.871133
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records/2954362/sample')

# Generated at 2022-06-24 12:39:43.886998
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()



# Generated at 2022-06-24 12:39:44.520923
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:47.007474
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE(): 
    video_url = "https://hitrecord.org/records/2954362"
    
    HitRecordIE(video_url)
    try: 
        HitRecordIE(video_url)
    except:
        return False
    return True

# Generated at 2022-06-24 12:39:48.735082
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('test_context')

# Generated at 2022-06-24 12:39:54.776109
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie.video_id == '2954362'
    assert ie.video_url == 'https://s3.amazonaws.com/hr-production/file/' \
                            'records/2954362/A_Very_Different_World_-_' \
                            'HITRECORD_x_ACLU_HIGH_RES.mp4'

# Generated at 2022-06-24 12:39:57.810651
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert(HitRecordIE("https://hitrecord.org/records/2954362")._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-24 12:39:58.981385
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(u'http://hitrecord.org/records/2630576')

# Generated at 2022-06-24 12:39:59.800568
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-24 12:40:04.401739
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrec = HitRecordIE()
    assert hitrec.suitable("'https://hitrecord.org/records/2954362") == True
    assert hitrec.IE_NAME == 'hitrecord'
    assert hitrec._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:07.393658
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-24 12:40:08.026914
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:40:09.401722
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Basic unit test for HitRecordIE"""
    HitRecordIE()

# Generated at 2022-06-24 12:40:12.361314
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TEST')
    assert hasattr(ie, '_real_extract')

# Generated at 2022-06-24 12:40:21.884644
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from ..extractor import Extractor

    def hitrecord_constructor(self, *args, **kwargs):
        self.constructor_result = [args, kwargs]

    hitrecord_constructor_result = [
        [],
        {
            'ie': 'HitRecord',
            '_type': 'playlist',
            'playlist_id': '379340',
            'title': 'HITRECORD x ACLU: DontFilterMe'
        }
    ]

    HitRecordIE.__init__ = lambda *args, **kwargs: hitrecord_constructor(*args, **kwargs)
    extractor = Extractor.gen_extractor(HitRecordIE._VALID_URL)
    assert HitRecordIE.constructor_result == hitrecord_constructor_result

# Generated at 2022-06-24 12:40:23.948464
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE();
    assert(ie.IE_NAME == "HitRecord");
    assert(ie.IE_DESC == "HitRecord");

# Generated at 2022-06-24 12:40:24.419695
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:40:32.190322
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:33.229431
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'

# Generated at 2022-06-24 12:40:34.853692
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("test_test", "test_test", "test_test")

# Generated at 2022-06-24 12:40:39.378157
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    module = 'youtube_dl.extractor.hitrecord'
    ie = HitRecordIE()
    ie = HitRecordIE()
    ie = HitRecordIE()
    ie = HitRecordIE()

    ie._VALID_URL
    ie.valid

    ie.extract('https://hitrecord.org/records/2954362')

    ie.valid
    ie.valid

# Generated at 2022-06-24 12:40:42.220537
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.name() == 'hitrecord.org'

# Generated at 2022-06-24 12:40:47.410289
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()

    assert isinstance(hitrecord, InfoExtractor)
    assert hitrecord.IE_NAME == 'hitrecord'
    assert hitrecord.IE_DESC == 'HitRecord'
    assert hitrecord._VALID_URL == HitRecordIE._VALID_URL
    assert hitrecord._TEST == HitRecordIE._TEST
    assert hitrecord.__name__ == 'HitRecordIE'

# Generated at 2022-06-24 12:40:49.822048
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:41:01.135355
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Init HitRecordIE object
    obj = HitRecordIE()
    _VALID_URL = r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    obj._VALID_URL = _VALID_URL

# Generated at 2022-06-24 12:41:12.083800
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_case = HitRecordIE()
    assert(test_case._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-24 12:41:13.037713
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    _ = HitRecordIE()

# Generated at 2022-06-24 12:41:17.198052
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE(): 
    video = HitRecordIE()
    video.test()

test_HitRecordIE.func_doc = "Unit test for constructor of class HitRecordIE"


if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:41:17.766872
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:19.974536
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    import unittest
    import sys
    import os

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-24 12:41:20.898195
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE();



# Generated at 2022-06-24 12:41:23.694129
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    hitRecordIE = HitRecordIE()
    assert hitRecordIE.suitable(url)
    assert hitRecordIE._match_id(url) == '2954362'

# Generated at 2022-06-24 12:41:27.193931
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)

    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:41:30.716966
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    assert hitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:41:36.940917
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL is not None
    assert HitRecordIE._TEST['url'] is not None
    HitRecordIE._TEST['expected_title'] = HitRecordIE._TEST['info_dict']['title']
    HitRecordIE._TEST['expected_description'] = HitRecordIE._TEST['info_dict']['description']
    HitRecordIE._TEST['expected_thumbnail'] = HitRecordIE._TEST['info_dict']['thumbnail']
    HitRecordIE._TEST['expected_duration'] = HitRecordIE._TEST['info_dict']['duration']
    HitRecordIE._TEST['expected_like_count'] = None
    assert HitRecordIE._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert HitRecordIE._T

# Generated at 2022-06-24 12:41:38.796182
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = "https://hitrecord.org/records/2954362"
    ie = HitRecordIE(url)
    pass


# Generated at 2022-06-24 12:41:39.615783
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:40.376628
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE

# Generated at 2022-06-24 12:41:44.624351
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('http://hitrecord.org/records/2954362')
    assert ie.url == 'https://hitrecord.org/records/2954362'
    # _VALID_URL should have captured the group 'id' which is 2954362
    assert ie.video_id == '2954362'

# Generated at 2022-06-24 12:41:47.714995
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test the HitRecordIE
    print("Testing HitRecordIE")
    # Extract a record from the hitrecord.org
    extractor = HitRecordIE()
    # Test extracting the test url
    extractor.extract(extractor._TEST['url'])

# Generated at 2022-06-24 12:41:58.045522
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == ie.VALID_URL, 'The VALID_URL of class HitRecordIE should be %s' % ie._VALID_URL
    assert ie._TEST == ie._TESTS[0], 'The test of class HitRecordIE is wrong'
    assert ie._TEST['url'] == ie._TESTS[0]['url'], 'The url of test in class HitRecordIE is wrong'
    assert ie._TEST['md5'] == ie._TESTS[0]['md5'], 'The md5 of test in class HitRecordIE is wrong'

# Generated at 2022-06-24 12:41:59.454974
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    e = HitRecordIE()
    e

# Generated at 2022-06-24 12:42:00.044012
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:00.619853
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:01.281992
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:42:04.161844
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'



# Generated at 2022-06-24 12:42:08.714734
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert HitRecordIE._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert HitRecordIE._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    

# Generated at 2022-06-24 12:42:13.288068
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    result = HitRecordIE()

    try:
        assert result != None
    except AssertionError as e:
        print ('Unit test for constructor of class HitRecordIE Failed')


# Generated at 2022-06-24 12:42:14.273617
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL is not None

# Generated at 2022-06-24 12:42:16.481219
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # Should raise an error if called without parameters
    try:
        ie.extract()
    except:
        pass

# Generated at 2022-06-24 12:42:16.906866
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:42:18.160237
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:42:19.157367
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://www.hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:42:22.912355
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE_testclass_object = HitRecordIE()
    if hitRecordIE_testclass_object == None:
        print("HitRecordIE object created successfully")

# Generated at 2022-06-24 12:42:25.764022
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    x = HitRecordIE()
    assert x.suitable("http://hitrecord.org/records/2954362")
    assert not x.suitable("http://google.com/")



# Generated at 2022-06-24 12:42:29.843105
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # TODO: Move to tests directory
    hr_ie = HitRecordIE()

    # Test get_info function returns proper info
    assert hr_ie._TEST == hr_ie.get_info('https://hitrecord.org/records/2954362')


# Generated at 2022-06-24 12:42:35.418481
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie_obj = HitRecordIE()
    # Check if the right URL is returned
    extractor = ie_obj._real_extract("https://hitrecord.org/records/2954362")
    # Check if the url is a valid url
    assert extractor['url'] == 'https://hitrecord-production-website.s3.amazonaws.com/uploads/record/source_file/229461/2954362_EPISODE_1_DRAFT_BY_WOLFPACK_AND_THE_OTHER_DOGS.mp4'

# Generated at 2022-06-24 12:42:46.644881
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_ie = HitRecordIE()
    assert hitrecord_ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert hitrecord_ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert hitrecord_ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert hitrecord_ie._TEST['info_dict']['id'] == '2954362'
    assert hitrecord_ie._TEST['info_dict']['ext'] == 'mp4'
    assert hitrecord_ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'


# Generated at 2022-06-24 12:42:47.917303
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# test for downloading a video from HitRecordIE

# Generated at 2022-06-24 12:42:55.074210
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # First test the constructor works correctly
    instance = HitRecordIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:42:59.036423
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test = HitRecordIE(HitRecordIE._downloader, HitRecordIE._TEST)
    print(test._VALID_URL)
    print(test._TEST)
    print(test._download_json(
        'https://hitrecord.org/api/web/records/%s' % 2954362, 2954362))

# Generated at 2022-06-24 12:43:00.801430
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:43:04.290805
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE()
    assert info_extractor.suitable("http://hitrecord.org/records/2954362")
    assert not info_extractor.suitable("https://hitrecord.org/records/2954362/some_other_sub")
    assert not info_extractor.suitable("http://hitrecord.org/some_other_sub")
    assert not info_extractor.suitable("http://www.hitrecord.org/some_other_sub/2954362")
    assert not info_extractor.suitable("http://hitrecord.org")
    assert not info_extractor.suitable("https://hitrecord.org")
    assert not info_extractor.suitable("https://www.google.com")

# Generated at 2022-06-24 12:43:09.777295
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    '''
        TestCase for class HitRecordIE
    '''
    test_case = HitRecordIE
    assert test_case._TEST['url'] == HitRecordIE._VALID_URL, "url not valid"
    assert test_case._TEST['info_dict']['id'] == HitRecordIE._TEST['url'].split('/')[-1], "video id not correct"

# Generated at 2022-06-24 12:43:10.676762
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:11.288052
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:12.736804
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Create a HitRecordIE object"""
    HitRecordIE()

# Generated at 2022-06-24 12:43:13.015041
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:13.370427
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:14.976537
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_test=HitRecordIE()
    print("test case for HitRecordIE ",hitrecord_test.test())

# Generated at 2022-06-24 12:43:16.507289
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_ie = HitRecordIE()
    print(hit_record_ie._VALID_URL)

# Generated at 2022-06-24 12:43:17.338973
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Check constructor without any parameters
    HitRecordIE()

# Generated at 2022-06-24 12:43:21.291553
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ins = HitRecordIE(InfoExtractor())
    _VALID_URL = r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ins._VALID_URL == _VALID_URL

# Generated at 2022-06-24 12:43:31.733853
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:43:33.094923
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract(HitRecordIE._TEST['url'])

# Generated at 2022-06-24 12:43:33.963458
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    print(instance)

# Generated at 2022-06-24 12:43:36.151739
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Simple test
    assert HitRecordIE(None) is not None
    # Test with URL
    assert HitRecordIE(None, 'http://www.hitrecord.org/records/2954362') is not None

# Generated at 2022-06-24 12:43:39.714932
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE._download_json = lambda a, b: {}

    i = HitRecordIE('http://hitrecord.org/records/2954362')
    assert isinstance(i, InfoExtractor, msg='HitRecordIE is type InfoExtractor')

# Generated at 2022-06-24 12:43:40.451604
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():     
    HitRecordIE()

# Generated at 2022-06-24 12:43:42.763150
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
        YoutubeIE: Test constructor of class HitRecordIE
    """
    HitRecordIE(HitRecordIE._VALID_URL, {}, HitRecordIE._TEST)

# Generated at 2022-06-24 12:43:48.902284
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert HitRecordIE()._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert HitRecordIE()._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert HitRecordIE()._TEST['info_dict']['id'] == '2954362'
    assert HitRecordIE()._TEST['info_dict']['ext'] == 'mp4'
    assert HitRecordIE()._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:43:49.601998
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Test HitRecordIE constructor"""
    HitRecordIE()

# Generated at 2022-06-24 12:43:51.362026
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'



# Generated at 2022-06-24 12:43:52.742883
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._TEST['url'] == 'https://hitrecord.org/records/2954362'


# Generated at 2022-06-24 12:44:02.564199
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    inp = HitRecordIE()
    assert inp._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert inp._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert inp._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert inp._TEST['info_dict']['id'] == '2954362'
    assert inp._TEST['info_dict']['ext'] == 'mp4'
    assert inp._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:44:04.249346
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = "https://hitrecord.org/records/2954362"
    HitRecordIE()._real_extract(url)

# Generated at 2022-06-24 12:44:05.587961
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test instantiation
    HitRecordIE(InfoExtractor())
    print("HitRecordIE is instantiated")



# Generated at 2022-06-24 12:44:07.575976
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.download(HitRecordIE._TEST['url'])

# Generated at 2022-06-24 12:44:08.481049
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test = HitRecordIE()

# Generated at 2022-06-24 12:44:10.804252
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = HitRecordIE._TEST['url']
    ie = HitRecordIE(url)
    assert(ie.url == url)

# Generated at 2022-06-24 12:44:19.083957
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:29.858411
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert(ie._TEST['url'] == 'https://hitrecord.org/records/2954362')
    assert(ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71')
    assert(ie._TEST['info_dict']['id'] == '2954362')
    assert(ie._TEST['info_dict']['ext'] == 'mp4')
    assert(ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)')

# Generated at 2022-06-24 12:44:30.315890
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:44:33.161775
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test = HitRecordIE()
    assert test._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:33.941367
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-24 12:44:35.248722
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_test = HitRecordIE()
    print(hitrecord_test._TEST)

# Generated at 2022-06-24 12:44:35.935733
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:44:42.880903
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert(ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-24 12:44:45.918114
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	hitRecordIE = HitRecordIE()
	print(type(hitRecordIE))

	assert isinstance(hitRecordIE, HitRecordIE)


test_HitRecordIE()

# Generated at 2022-06-24 12:44:46.584463
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:44:47.331562
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-24 12:44:52.500745
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie_url = ie.ie_key()
    ie_name = ie.ie_name()
    ie_description = ie.ie_description()
    ie_version = ie.ie_version()
    ie_downloader = ie.downloader

    # All information extracted correctly
    assert ie_url == 'hitrecord'
    assert ie_name == 'HitRecord'
    assert ie_description == 'HitRecord'
    assert ie_version is not None
    assert ie_downloader is not None

# Generated at 2022-06-24 12:44:53.863746
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video_url = 'https://hitrecord.org/records/2954362'
    ie = HitRecordIE()
    assert ie.match(video_url) is True


# Generated at 2022-06-24 12:44:57.670250
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = "https://hitrecord.org/records/2954362"
    hit_record_ie = HitRecordIE()
    assert(hit_record_ie._match_id(url) == "2954362")

# Generated at 2022-06-24 12:45:01.353564
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    url = "https://www.youtube.com/watch?v=C5fjzgv0dc4"
    assert hitrecord._build_url_result(url, {})[0]['url'] == url

# Generated at 2022-06-24 12:45:05.343600
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	"""
	This function tests the constructor of class HitRecordIE
	"""
	assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

#Unit test for _real_extract of class HitRecordIE

# Generated at 2022-06-24 12:45:05.860294
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:45:16.335143
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:25.218420
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('www.hitrecord.org/records/2954362')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:27.084231
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:45:27.696613
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:45:28.894183
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hr = HitRecordIE()
    # Constructor does not need to return anything



# Generated at 2022-06-24 12:45:34.244645
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # This is a quick test for the HitRecordIE
    # in its current form, it should have at least one test for each method
    # This should be expanded to catch more cases

    # Create a HitRecordIE object, just so we can test its methods
    ie = HitRecordIE()
    # The method _real_extract should be able to run without any errors
    assert ie._real_extract('https://hitrecord.org/records/2954362')


#Unit test for constructor of class HitRecordIE

# Generated at 2022-06-24 12:45:41.025132
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Basic test for constructor of class HitRecordIE.
    See https://github.com/rg3/youtube-dl/issues/5204 for more information.
    """
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:52.922422
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    e = HitRecordIE()
    assert e._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:53.871935
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:45:55.769970
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL
    assert HitRecordIE()._TEST == HitRecordIE._TEST

# Generated at 2022-06-24 12:45:56.258301
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:45:57.603124
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # HitRecordIE should initialize properly
    _ = HitRecordIE(HitRecordIE._VALID_URL)

# Generated at 2022-06-24 12:45:59.417554
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract(HitRecordIE._TEST['url'])

# Generated at 2022-06-24 12:46:00.350441
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie

# Generated at 2022-06-24 12:46:01.242585
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert issubclass(HitRecordIE, InfoExtractor)

# Generated at 2022-06-24 12:46:04.624024
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    r = HitRecordIE()
    r._real_extract(url)

# Generated at 2022-06-24 12:46:06.162669
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_instance = HitRecordIE()
    return test_instance

# Generated at 2022-06-24 12:46:07.144917
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  hitRecordIE = HitRecordIE()

# Generated at 2022-06-24 12:46:10.909083
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	instance_of_HitRecorIE = HitRecordIE()
	print("Test 1: Type of HitRecordIE")
	print("Expected type: InfoExtractor")
	print("Actual type: " + str(type(instance_of_HitRecordIE)))
	assert isinstance(instance_of_HitRecordIE, InfoExtractor)
	print("\nTest passed! \n")


# Generated at 2022-06-24 12:46:12.329375
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-24 12:46:14.233166
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = HitRecordIE._VALID_URL
    ie = HitRecordIE(url)
    assert(ie._VALID_URL == url)

# Generated at 2022-06-24 12:46:19.073394
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    # Testing with a None input
    assert hitrecord._match_id(None) == None
    # Testing with a not valid input
    assert hitrecord._match_id("test") == None
    # Testing with a valid input
    assert hitrecord._match_id("https://hitrecord.org/records/2954362") == "2954362"

# Generated at 2022-06-24 12:46:19.982739
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-24 12:46:22.001493
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    HitRecordIE()._real_extract(url)

# Generated at 2022-06-24 12:46:24.087391
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    test_instance = HitRecordIE()
    assert test_instance.ie_key() == 'hitrecord'

# Generated at 2022-06-24 12:46:25.017965
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('HitRecordIE')

# Generated at 2022-06-24 12:46:25.969357
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-24 12:46:27.610091
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	hri = HitRecordIE()
	assert str(hri) == '<HitRecordIE>'

# Generated at 2022-06-24 12:46:28.761092
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:46:31.656741
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/295436')
    assert ie.IE_NAME == 'hitrecord'
    

# Generated at 2022-06-24 12:46:34.450235
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    youtube_ie = HitRecordIE()
    assert youtube_ie.suitable("https://hitrecord.org/records/2954362") == True


# Generated at 2022-06-24 12:46:35.051515
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE()

# Generated at 2022-06-24 12:46:36.907782
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        h = HitRecordIE()
    except:
        assert False, "Can't instansiate class HitRecordIE"
    else:
        assert True

# Generated at 2022-06-24 12:46:38.854425
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ex = HitRecordIE('https://hitrecord.org/records/2954362')
	print('HitRecordIE: test successful')
	return ex


# Generated at 2022-06-24 12:46:40.084145
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('HitRecordIE', 'hitrecord.org')


# Generated at 2022-06-24 12:46:42.268692
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  url = "https://hitrecord.org/records/2954362"
  hitrecordie = HitRecordIE()
  # Check if the instance of HitRecordIE is created
  assert isinstance(hitrecordie, HitRecordIE)

# Generated at 2022-06-24 12:46:44.865091
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from .common import InfoExtractor
    from .HitRecordIE import HitRecordIE
    assert (HitRecordIE.__module__ == 'hitrecord.HitRecordIE.HitRecordIE')


# Generated at 2022-06-24 12:46:45.397312
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:47.441803
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:46:50.060180
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert(HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-24 12:46:51.632601
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    myHitRecordIE = HitRecordIE()
    myHitRecordIE == myHitRecordIE

# Generated at 2022-06-24 12:46:58.160020
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitr = HitRecordIE()
    assert hitr.ie_key() == 'hitrecord'
    assert hitr.ie_name() == 'hitrecord.org/records'
    assert hitr.ie_description() == 'hitrecord.org/records/HHH'
    assert hitr.url_re.pattern == r'https?://(?:.*\.)?hitrecord\.org/records/(?P<id>[0-9]+)'

# Generated at 2022-06-24 12:47:01.561311
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"
    assert ie


# Generated at 2022-06-24 12:47:11.532916
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie.suitable("https://hitrecord.org/records/2954362")
    assert ie.get_url() == "https://hitrecord.org/records/2954362"
    assert ie.get_title() == "A Very Different World (HITRECORD x ACLU)"
    assert ie.get_desc() == "HITRECORD x ACLU: A VERY DIFFERENT WORLD<br><br>HITRECORD was inspired to partner with ACLU and create this short, animated piece in the wake of the ban proposed by the new administration. We are all immigrants, no matter where we're from. If we stick together, we can create a different world."
    assert ie.get_upload_date() == "20160818"
    assert ie.get_duration