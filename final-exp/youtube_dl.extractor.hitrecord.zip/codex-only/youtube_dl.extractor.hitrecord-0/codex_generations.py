

# Generated at 2022-06-24 12:37:07.410088
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.suitable('http://www.hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:37:12.833519
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    class_ = HitRecordIE
    url = 'https://hitrecord.org/records/2954362'
    video_id = class_._match_id(url)
    class_(url)
    class_._download_json(
        'https://hitrecord.org/api/web/records/%s' % video_id, video_id)

# Generated at 2022-06-24 12:37:17.121677
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(2954362)

    # Constructor of class InfoExtractor
    assert ie.id == 2954362
    assert ie.url == 'http://hitrecord.org/records/2954362'
    assert ie.video_id == 2954362

# Generated at 2022-06-24 12:37:17.740423
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('HitRecord') == HitRecordIE

# Generated at 2022-06-24 12:37:18.918281
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Basic test for HitRecordIE.
    """
    HitRecordIE()

# Generated at 2022-06-24 12:37:20.042957
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:37:24.157178
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        # test_HitRecordIE is supposed to be run in python3.
        # python3 and python2 have different behaviour regarding the
        # implementation of __ne__.
        # In python2, __ne__ is called if and only if __eq__ is not implemented.
        # In python3, == and != calls __eq__ and __ne__ respectively.
        # This is why the following code cannot be run in python2.
        assert HitRecordIE() != None
    except:
        assert False

# Generated at 2022-06-24 12:37:25.487572
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("HitRecordIE", "hitrecord", False)

# Generated at 2022-06-24 12:37:26.337376
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.test('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:37:28.239370
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Get an instance of HitRecordIE
    extractor = HitRecordIE()
    assert extractor is not None

# Generated at 2022-06-24 12:37:28.733577
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:37:30.281623
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL


# Generated at 2022-06-24 12:37:32.733391
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    with InfoExtractor() as ie:
        assert ie.IE_NAME == 'hitrecord'
        assert ie.SUFFIX == 'HitRecord'

# Generated at 2022-06-24 12:37:38.175319
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('hitrecord.org/records/12345')
    assert ie.suitable('https://hitrecord.org/records/12345')
    assert not ie.suitable('hitrecord.org/12345')
    assert not ie.suitable('hitrecord.org/records/12345/extra')
    assert ie._VALID_URL == ie.VALID_URL

# Generated at 2022-06-24 12:37:41.598390
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("")
    assert ie.host == "hitrecord.org"
    assert ie.ie_key == "HitRecord"
    assert ie.patterns == [r'.*hitrecord.org/(records)/(\d+)']
    assert ie.ie_key == "HitRecord"

# Generated at 2022-06-24 12:37:42.360182
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert ie

# Generated at 2022-06-24 12:37:53.057838
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	import re
	from .common import InfoExtractor

	_VALID_URL = r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:37:54.115465
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:01.838123
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from .common import InfoExtractor
    from .common import InfoExtractor
    from ..utils import try_get 
    from ..compat import compat_str

    url = "https://hitrecord.org/records/2954362"
    video_id = "2954362"
    video = InfoExtractor._download_json(
      'https://hitrecord.org/api/web/records/%s' % video_id, video_id)
    video_url = video['source_url']['mp4_url']
    tags_list = try_get(video, lambda x: x['tags'], list)

# Generated at 2022-06-24 12:38:12.463976
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:13.497109
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HitRecordIE()

# Generated at 2022-06-24 12:38:15.515279
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('http://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:38:18.347235
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Create instance of HitRecordIE
    hric = HitRecordIE()
    assert hric.url == 'hitrecord.org'

# Generated at 2022-06-24 12:38:18.974565
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  HitRecordIE()

# Generated at 2022-06-24 12:38:29.496252
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test for Title
    ie = HitRecordIE()
    assert ie._VALID_URL == \
    r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

    # Test for md5
    ie = HitRecordIE()

# Generated at 2022-06-24 12:38:35.605264
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  infoExtractor = HitRecordIE()
  assert infoExtractor._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
  assert infoExtractor._TEST['url'] == 'https://hitrecord.org/records/2954362'
  assert infoExtractor._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-24 12:38:36.151269
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:37.063679
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-24 12:38:46.186065
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:46.703549
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:38:47.742253
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('', HitRecordIE._TEST)

# Generated at 2022-06-24 12:38:57.165645
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    class_ = HitRecordIE
    assert class_._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:38:57.964003
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    return

# Generated at 2022-06-24 12:39:08.357026
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    
    assert instance._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert instance._downloader.params.get('noprogress', False) == True
    assert instance._downloader.params.get('progress_with_newline', False) == True

# Generated at 2022-06-24 12:39:10.016417
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:13.340757
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print("Testing HitRecordIE")
    test_url = 'https://hitrecord.org/records/2954362'
    HitRecordIE().suitable(test_url) == True
    HitRecordIE()._real_extract(test_url)

# Generated at 2022-06-24 12:39:23.702486
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Test constructor of class HitRecordIE.
    """
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie.VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:39:30.283010
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    #contstruct a dummy HitRecordIE object
    ie = HitRecordIE()
    ie._download_json('http://www.hitrecord.org/records/2954362', '2954362')
    assert ie._match_id('https://hitrecord.org/records/2954362') == '2954362'
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:39:32.194277
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:39:32.547660
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:39:34.977317
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert ie.SUFFIX == 'L'
    assert ie.ie_key() == 'hitrecord'


# Generated at 2022-06-24 12:39:45.257564
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:39:47.330324
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    print(ie._VALID_URL)
    print(ie._TEST)

# Generated at 2022-06-24 12:39:52.266694
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	hit_record = HitRecordIE()
	assert hit_record.name == "hitrecord"
	mi = hit_record.info_extractors[0]._real_extract("http://www.hitrecord.org/records/2954362")
	assert mi["id"] == "2954362"


# Generated at 2022-06-24 12:39:54.682128
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    HitRecordIE()._real_extract(url)

# Generated at 2022-06-24 12:40:00.845263
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    url = 'https://hitrecord.org/records/2954362'
    video_id = '2954362'
    assert video_id == ie._match_id(url), 'id mismatch for url %s' % url
    assert video_id == ie._real_extract(url)['id'], 'id mismatch for url %s' % url
    assert 'https://hitrecord-res.cloudinary.com/video/upload/' in ie._real_extract(url)['url'], 'url mismatch for url %s' % url

# Generated at 2022-06-24 12:40:07.764730
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test constructor of HitRecordIE
    hitrecord_ie = HitRecordIE('https://www.hitrecord.org/records/2954362')
    assert(hitrecord_ie.url == 'https://hitrecord.org/records/2954362')
    assert(hitrecord_ie.video_id == '2954362')
    assert(hitrecord_ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')


# Generated at 2022-06-24 12:40:08.783104
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()
    return

# Generated at 2022-06-24 12:40:09.727145
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-24 12:40:19.776545
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_ie = HitRecordIE()
    assert hitrecord_ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert hitrecord_ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert hitrecord_ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert hitrecord_ie._TEST['info_dict']['id'] == '2954362'
    assert hitrecord_ie._TEST['info_dict']['ext'] == 'mp4'
    assert hitrecord_ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'


# Generated at 2022-06-24 12:40:28.188228
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    youtubeIE = HitRecordIE('test-domain')
    assert youtubeIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:40:37.764802
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video = HitRecordIE()._real_extract("https://hitrecord.org/records/2936167")
    assert("2936167" == video["id"])
    assert("mp4" == video["ext"])
    assert("Get This Picture/Poem!" == str(video["title"]))
    assert("https://s3.amazonaws.com/hotrecord/assets/record_assets/2936167/GetThisPicturePoem_1508712527.mp4" == str(video["url"]))
    assert("https://hitrecord.org/records/2936167" == video["url"])
    assert("Jakob22" == str(video["uploader"]))
    assert(138.834 == video["duration"])
    assert(int == type(video["view_count"]))

# Generated at 2022-06-24 12:40:40.028542
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == "https://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"


# Generated at 2022-06-24 12:40:40.592842
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:40:41.941305
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-24 12:40:42.750097
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:40:44.570130
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    f = HitRecordIE()
    assert f.extract("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:40:52.603545
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    tags = [
        {
            "text": "test"
        }
    ]

# Generated at 2022-06-24 12:40:54.320271
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print(HitRecordIE().extract('https://hitrecord.org/records/2954362'))

# Generated at 2022-06-24 12:40:54.872672
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:40:59.126272
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    extractor = HitRecordIE(None)
    assert extractor.suitable('https://hitrecord.org/records/2954362')
    assert not extractor.suitable('https://hitrecord.org/projects/2954362')

# Generated at 2022-06-24 12:41:00.419150
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:41:06.505186
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:41:06.998502
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-24 12:41:08.593249
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:41:09.204120
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:11.799899
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test for a valid url
    HitRecordIE("http://hitrecord.org/records/2954362")
    # Test for an invalid url
    HitRecordIE("http://hitrecord.org/123")

# Generated at 2022-06-24 12:41:17.535824
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test case for class HitRecordIE
    ie = HitRecordIE(None)
    assert isinstance(ie, HitRecordIE)
    # Test for the method "_real_extract"
    url = 'https://hitrecord.org/records/2954362'
    # Test for the input value: url
    assert ie._real_extract(url) is not None

# Generated at 2022-06-24 12:41:18.119303
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:20.681832
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()
    assert obj._VALID_URL ==  r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:41:21.930398
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(HitRecordIE._downloader, HitRecordIE._VALID_URL)

# Generated at 2022-06-24 12:41:22.810166
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # TODO: Fill this
    pass

# Generated at 2022-06-24 12:41:25.902066
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    '''
    test for unit constructor of class HitRecordIE
    '''
    instance = HitRecordIE()
    assert isinstance(instance, HitRecordIE)


# Generated at 2022-06-24 12:41:27.341921
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Unit test for HitRecordIE"""
    HitRecordIE()

# Generated at 2022-06-24 12:41:27.947783
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:28.672713
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:29.286686
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  HitRecordIE()

# Generated at 2022-06-24 12:41:32.301814
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie is not None
    assert ie.url_re == HitRecordIE._VALID_URL

# Generated at 2022-06-24 12:41:35.150092
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    tests = {
        'HitRecordIE': {
            'type': 'Video',
            'pattern': 'https://hitrecord.org/records/2954362',
            'url': 'https://hitrecord.org/records/2954362',
        }
    }
    for test in tests:
        assert test in tests

# Generated at 2022-06-24 12:41:36.442724
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(isinstance(ie, InfoExtractor))

# Generated at 2022-06-24 12:41:37.705658
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Unit tests for other functions in class HitRecordIE

# Generated at 2022-06-24 12:41:38.140274
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:41:47.602507
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	test_object = HitRecordIE()
	test_object.url = "https://hitrecord.org/records/2954362"
	test_object.extractor = "hitrecord"
	test_object.data["id"] = "2954362"
	test_object.data["ext"] = "mp4"
	test_object.data["title"] = "A Very Different World (HITRECORD x ACLU)"
	test_object.data["description"] = "md5:e62defaffab5075a5277736bead95a3d"
	test_object.data["duration"] = 139.327
	test_object.data["timestamp"] = 1471557582
	test_object.data["upload_date"] = "20160818"

# Generated at 2022-06-24 12:41:49.119770
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:41:59.148516
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:42:08.228328
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    test = ie._TEST
    test_url = test['url']
    assert test_url == 'https://hitrecord.org/records/2954362'
    test_md5 = test['md5']
    assert test_md5 == 'fe1cdc2023bce0bbb95c39c57426aa71'
    test_info_dict = test['info_dict']
    test_info_id = test_info_dict['id']
    assert test_info_id == '2954362'
    test_info_ext = test_info_dict['ext']
    assert test_info_ext == 'mp4'


# Generated at 2022-06-24 12:42:12.250911
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    _ = HitRecordIE(
        HitRecordIE._VALID_URL,
        HitRecordIE._TEST['url'],
        HitRecordIE._TEST['md5']
    )

# Generated at 2022-06-24 12:42:16.539684
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.get_url_regex() == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\\d+)"
    assert ie.get_host_name() == "hitrecord.org"

# Generated at 2022-06-24 12:42:23.160585
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test with invalid URL
    invalid_url = 'https://invalid.url'
    assert HitRecordIE._VALID_URL_RE.match(invalid_url) is None
    # Test with valid URL
    valid_url = 'https://hitrecord.org/records/2954362'
    assert HitRecordIE._VALID_URL_RE.match(valid_url) is not None
    # Test with invalid video_id
    invalid_video_id = 'haha'
    assert HitRecordIE._VALID_URL_RE.match(HitRecordIE._VALID_URL % invalid_video_id) is None
    # Test with valid video_id
    valid_video_id = '12345'

# Generated at 2022-06-24 12:42:32.951918
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:42:40.647277
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("http://hitrecord.org/records/2954362")
    assert ie.REAL_URL == "https://hitrecord.org/records/2954362"
    assert ie.VIDEO_ID == "2954362"
    assert ie.VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"
    assert ie.VALID_URL_TEMPLATE == "https?://(?:www\.)?hitrecord\.org/records/{id}"

# Generated at 2022-06-24 12:42:41.665787
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE({})

# Generated at 2022-06-24 12:42:42.645023
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None, None)

# Generated at 2022-06-24 12:42:52.094569
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    assert HitRecordIE.suitable(url)
    test = HitRecordIE._TEST
    assert test['url'] == url
    assert test['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    pattern = re.compile(HitRecordIE._VALID_URL)
    match = re.search(pattern, test['url'])
    assert test['info_dict']['id'] == match.group('id')
    assert test['info_dict']['ext'] == 'mp4'
    assert test['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-24 12:42:54.295610
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    e = HitRecordIE('https://hitrecord.org/records/2954362')
    assert e

# Generated at 2022-06-24 12:42:54.862290
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:00.023473
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    class HitRecordIE(InfoExtractor):
        _VALID_URL = r'https://(?:www.)?hitrecord.org/records/(?P<id>\d+)'

        def _real_extract(self, url):
            video_id = self._match_id(url)
            video = self._download_json(
                'https://hitrecord.org/api/web/records/%s' % video_id, video_id)
            # Test variables returned by _real_extract
            title = video['title']
            video_url = video['source_url']['mp4_url']

            return {
                'id': video_id,
                'url': video_url,
                'title': title,
            }
    # Test instance of class HitRecordIE
    ie = HitRecordIE()

# Generated at 2022-06-24 12:43:04.858491
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    data = HitRecordIE('https://hitrecord.org/records/2954362')
    data = HitRecordIE('https://hitrecord.org/records/2954362')
    assert type(data.video_id) == int
    assert type(data.video) == type(dict())
    assert type(data.title) == type(str())
    assert type(data.video_url) == type(str())

# Generated at 2022-06-24 12:43:15.436710
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    assert hitRecordIE.ie_key() == 'HitRecord'
    assert hitRecordIE.exclude() is False
    assert hitRecordIE.suitable('https://hitrecord.org/records/2954362') is True
    assert hitRecordIE.suitable('https://www.hitrecord.org/records/2954362') is True
    assert hitRecordIE.suitable('https://hitrecord.org/records/66') is True
    assert hitRecordIE.suitable('https://hitrecord.org/records/1') is True
    assert hitRecordIE.suitable('https://hitrecord.org/records/') is False
    assert hitRecordIE.suitable('https://hitrecord.org/records/hello') is False

# Generated at 2022-06-24 12:43:15.983692
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:43:18.045452
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	h = HitRecordIE()
	assert h._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:43:28.896972
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from .common import InfoExtractor
    from ..utils import try_get
    from ..compat import compat_str
    from ..compat import compat_urllib_parse
    import datetime
    hitrecordIE = InfoExtractor()
    #downloading the json data of the video specified by the given url
    hitrecord_json = hitrecordIE._download_json(
        'https://hitrecord.org/api/web/records/2954362', 2954362)
    # getting the description
    description = clean_html(try_get(
        hitrecord_json, lambda x: x['body'], compat_str))

# Generated at 2022-06-24 12:43:36.807094
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    class_name = 'HitRecordIE'
    ie = globals()[class_name](None)
    # http://stackoverflow.com/questions/2798956/programmatically-get-the-source-code-of-a-method-in-python
    ie_code = ie.extract.im_func.func_code
    # http://stackoverflow.com/questions/2064489/how-to-get-all-the-members-of-a-class
    class_members = ie.__class__.__dict__
    # http://stackoverflow.com/questions/1769403/understanding-pythons-slice-notation
    default_args = ie_code.co_varnames[:ie_code.co_argcount]

# Generated at 2022-06-24 12:43:39.284353
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test HitRecordIE class constructor
    import requests
    requests.get('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:43:41.005366
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    HitRecordIE()

# Generated at 2022-06-24 12:43:41.586117
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert True

# Generated at 2022-06-24 12:43:47.344473
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test for constructor of HitRecordIE
    # Constructor should return an object for extracting information from hitrecord.org url
    hitRecordIE = HitRecordIE()
    assert hitRecordIE
    # This should parse the URL for the video given on this website and return an object.
    hitRecordIE._real_extract("https://www.hitrecord.org/records/2954362")
    return True

print("HitRecordIE is imported")

# Generated at 2022-06-24 12:43:53.346829
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    class args:
        id = 'Test_ID'
        url = 'Test_URL'
    test = HitRecordIE(args)
    assert test._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert test._TEST['url'] == 'https://hitrecord.org/records/2954362'

# Generated at 2022-06-24 12:44:03.229719
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test with a major URL
    test_video = HitRecordIE()._real_extract(
        'https://hitrecord.org/records/2954362')
    # Test some important fields
    assert test_video['id'] == '2954362'
    assert test_video['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert test_video['description'] == 'md5:e62defaffab5075a5277736bead95a3d'
    assert test_video['timestamp'] == 1471557582
    assert test_video['upload_date'] == '20160818'
    assert test_video['uploader'] == 'Zuzi.C12'
    assert test_video['uploader_id'] == '362811'

# Generated at 2022-06-24 12:44:05.274282
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    ie = HitRecordIE()
    (info_dict) = ie.extract(url)

# Generated at 2022-06-24 12:44:06.800942
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'

# Generated at 2022-06-24 12:44:09.884468
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    #test if the class can be created
    HitRecordIE()
    print ("Succes, HitRecordIE was created")


if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:44:11.205319
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('http://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:44:19.280545
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord:record'
    assert ie.IE_DESC == 'HitRecord Records'
    assert HitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert HitRecordIE._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert HitRecordIE._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert HitRecordIE._TEST['info_dict']['id'] == '2954362'
    assert HitRecordIE._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-24 12:44:20.172402
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-24 12:44:31.272500
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:34.232620
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-24 12:44:36.477345
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    url = 'https://hitrecord.org/records/2954362'
    ie.extract(url)

# Generated at 2022-06-24 12:44:43.174392
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.working == True
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:44.616223
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Check channel
    channel = HitRecordIE()

# Generated at 2022-06-24 12:44:53.058395
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:44:57.260888
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    assert ie
    assert ie.IE_NAME == "hitrecord"
    assert ie.IE_DESC == "HitRecord"


if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:45:00.117158
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Basic unit test of HitRecordIE
    """
    loader = HitRecordIE()
    loader.extract(_test_url)
    assert loader is not None

# Generated at 2022-06-24 12:45:05.251376
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print("Testing HITRECORD constructor")
    video_id = '2954362'
    result = HitRecordIE()._real_extract(HitRecordIE._TEST['url'])
    assert result['id'] == video_id
    assert result['ext'] == 'mp4'
    assert result['title'] == HitRecordIE._TEST['info_dict']['title']


# Generated at 2022-06-24 12:45:07.690541
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    import re
    url = 'https://hitrecord.org/records/2954362'
    assert re.match(HitRecordIE._VALID_URL, url)

# Generated at 2022-06-24 12:45:08.214616
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:45:09.069992
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None, None, None)

# Generated at 2022-06-24 12:45:10.089590
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE is not None


# Generated at 2022-06-24 12:45:11.693741
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # test instantiation of HitRecordIE
    ie = HitRecordIE()
    assert ie != None

# Generated at 2022-06-24 12:45:21.355014
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Test HitRecordIE constructor"""
    loader = HitRecordIE()
    assert loader._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert loader._TEST.get('url') == 'https://hitrecord.org/records/2954362'
    assert loader._TEST.get('md5') == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-24 12:45:23.921432
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-24 12:45:24.582903
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:45:27.762555
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert(HitRecordIE(None)._VALID_URL == HitRecordIE._VALID_URL)
    assert(HitRecordIE(None)._TEST['url'] == HitRecordIE._TEST['url'])
    assert(HitRecordIE(None)._TEST['md5'] == HitRecordIE._TEST['md5'])

# Generated at 2022-06-24 12:45:29.379368
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except Exception as e:
        if isinstance(e, TypeError):
            print(e)
        else:
            raise e


# Generated at 2022-06-24 12:45:31.980943
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('http://hitrecord.org/records/3870400')
    assert ie.url == 'http://hitrecord.org/records/3870400'

# Generated at 2022-06-24 12:45:40.172244
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.IE_NAME == 'HitRecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:45:40.786016
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:45:42.980691
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("http://hitrecord.org/records/2954362")

# Generated at 2022-06-24 12:45:50.983834
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie.IE_NAME == 'HitRecord')
    assert(ie.IE_DESC == 'HitRecord')
    assert(ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')
    assert(ie._TEST['url'] == 'https://hitrecord.org/records/2954362')
    assert(ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71')

# Generated at 2022-06-24 12:45:59.479769
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    hitRecord = HitRecordIE()
    hitRecord._match_id(test_HitRecordIE.test_url)

    results = hitRecord._real_extract(test_HitRecordIE.test_url)

    assert('id' in results)
    assert(results['id'] == test_HitRecordIE.test_id)

    assert('url' in results)
    assert(results['url'] == test_HitRecordIE.test_url)

    assert('title' in results)
    assert(results['title'] == test_HitRecordIE.test_title)

    assert('extractor' in results)
    assert(results['extractor'] == 'HitRecordIE')

    assert('extractor_key' in results)
    assert(results['extractor_key'] == 'HitRecord')


# Generated at 2022-06-24 12:46:01.071512
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie = HitRecordIE(HitRecordIE.ie_key())

# Generated at 2022-06-24 12:46:02.309199
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:46:05.368986
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._real_initialize()
    assert ie.ie_key() == "HitRecord"
    assert ie.ie_key() in ie.gen_extractor_classes().keys()

# Generated at 2022-06-24 12:46:06.114747
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-24 12:46:11.589506
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("hitRecordIE")
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-24 12:46:12.696758
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    print(ie)

# Generated at 2022-06-24 12:46:14.635818
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  ie = HitRecordIE()
  ie.url = 'https://hitrecord.org/records/2954362'
  ie.extract()

# Generated at 2022-06-24 12:46:18.762761
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('https://hitrecord.org/records/2954362') is not None
    assert HitRecordIE('https://hitrecord.org/records/2954362') is not None
    assert HitRecordIE('https://hitrecord.org/records/2954362') is not None

# Generated at 2022-06-24 12:46:19.677066
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    res = HitRecordIE()
    assert res is not None

# Generated at 2022-06-24 12:46:24.957469
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie.name == 'hitrecord'
    assert ie.ie_key() == 'hitrecord'
    assert ie.generation == 1


test_HitRecordIE.unitTests = []
test_HitRecordIE.param_test_cases = []
test_HitRecordIE.error_test_cases = []

# Generated at 2022-06-24 12:46:27.939890
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('https://hitrecord.org/records/2954362')._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-24 12:46:32.258117
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    assert hitrecord.IE_NAME == 'hitrecord' # Ensures name is correct
    assert hitrecord.VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)' # Ensures URL is correct
    assert hitrecord.__name__ == 'hitrecord' # Ensures class is named correctly
    assert hitrecord.IE_DESC == "HitRecord" # Ensures IE is described properly

# Generated at 2022-06-24 12:46:35.566381
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-24 12:46:38.213520
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records/2954362/test')

# Generated at 2022-06-24 12:46:38.745071
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-24 12:46:41.677187
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    url = 'https://hitrecord.org/records/2954362'

    HR = HitRecordIE()
    x = HR.extract(url)

    print(x)

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-24 12:46:42.914669
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie_test = ie._TEST

# Generated at 2022-06-24 12:46:45.720771
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_desc() == 'HitRecord'
    assert HitRecordIE._VALID_URL == ie._VALID_URL
    assert HitRecordIE._TEST == ie._TEST

# Generated at 2022-06-24 12:46:48.543091
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    global hitRecordIE
    hitRecordIE = HitRecordIE("https://www.hitrecord.org/records/2954362")
    assert hitRecordIE.suitable("http://www.hitrecord.org/records/2954362") == True


# Generated at 2022-06-24 12:46:53.230088
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE("https://hitrecord.org/records/2954362 ")
    assert hitRecordIE._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"

# Generated at 2022-06-24 12:46:56.124196
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    vid='https://hitrecord.org/records/2954362'
    HitRecordIE().suitable(vid)
    HitRecordIE()._real_extract(vid)

# Generated at 2022-06-24 12:46:57.086910
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)._real_initialize()

# Generated at 2022-06-24 12:46:57.670954
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()


# Generated at 2022-06-24 12:46:58.252464
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE

# Generated at 2022-06-24 12:46:58.843398
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-24 12:47:03.201453
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    h = HitRecordIE()
    _VALID_URL = h._VALID_URL
    _TEST = h._TEST

    url = 'https://hitrecord.org/records/2954362'
    assert url == _TEST['url']

    video_id = h._match_id(url)
    assert video_id == '2954362'

    video_url = h._real_extract(url)['url']
    assert video_url == _TEST['info_dict']['url']

# Generated at 2022-06-24 12:47:04.785058
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:47:05.813588
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None, None)
