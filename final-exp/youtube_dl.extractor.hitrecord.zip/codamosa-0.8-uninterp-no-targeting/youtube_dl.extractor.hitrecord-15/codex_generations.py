

# Generated at 2022-06-22 07:47:30.728729
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  assert HitRecordIE != None
  return

# Generated at 2022-06-22 07:47:35.840197
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecordIE = HitRecordIE()
    assert hitrecordIE.name == 'HitRecord'
    assert hitrecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert hitrecordIE.__class__.__name__ == 'HitRecordIE'

# Generated at 2022-06-22 07:47:39.576939
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HITRECORD_ATTEMPTS = 3
    url = 'https://hitrecord.org/records/2954362'
    IE = HitRecordIE(url, HITRECORD_ATTEMPTS)
    video = IE.extract()
    assert video['id'] == '2954362'

# Generated at 2022-06-22 07:47:40.853885
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	hitrecordIE = HitRecordIE()
	assert hitrecordIE != None


# Generated at 2022-06-22 07:47:42.065616
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:47:45.709299
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(HitRecordIE.name, HitRecordIE._VALID_URL)
    assert ie.IE_NAME == HitRecordIE.name
    assert ie._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-22 07:47:47.149375
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:47:54.899275
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable(ie.ie_key())
    assert ie.suitable(ie.ie_key(), url='http://hitrecord.org/records/2954362')
    assert ie.suitable(
        ie.ie_key(), url='https://www.hitrecord.org/records/2954362')
    assert not ie.suitable(
        ie.ie_key(), url='https://www.hitrecord.org/records/2954362/2954362')
    assert not ie.suitable(
        ie.ie_key(), url='http://hitrecord.org/records')

# Generated at 2022-06-22 07:47:55.531659
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:47:56.327705
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('http://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:48:12.472993
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    # Test for video #1
    url = 'https://hitrecord.org/records/2954362'
    video = ie.extract(url)

    assert video['id'] == '2954362'
    assert video['url'] == 'https://8.vhx.tv/assets/173/h264_high/2954362.mp4'
    assert video['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-22 07:48:24.205073
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from ..utils import TestCase

    url = HitRecordIE._TEST['url']

    test_case = TestCase()
    test_case.assertEqual(HitRecordIE._VALID_URL, HitRecordIE._VALID_URL)
    test_case.assertTrue(HitRecordIE._TEST['md5'])
    test_case.assertEqual('2954362', HitRecordIE._TEST['info_dict']['id'])
    test_case.assertTrue('mp4' in HitRecordIE._TEST['info_dict']['ext'])
    test_case.assertTrue('A Very Different World (HITRECORD x ACLU)' in HitRecordIE._TEST['info_dict']['title'])

# Generated at 2022-06-22 07:48:24.942234
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:48:26.617499
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(None)

# Generated at 2022-06-22 07:48:29.105488
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract("https://hitrecord.org/records/2954362")

# Generated at 2022-06-22 07:48:31.414824
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Unit test for constructor of class HitRecordIE.
    """
    HitRecordIE('hitrecord', 'hitrecord.org')

# Generated at 2022-06-22 07:48:40.329322
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Variable that holds all the information about the HitRecordIE
    HitRecordIE_dict = {
        "id": "2954362",
        "ext": "mp4",
        "title": "A Very Different World (HITRECORD x ACLU)",
        "description": "md5:e62defaffab5075a5277736bead95a3d",
        "duration": 139.327,
        "timestamp": 1471557582,
        "upload_date": "20160818",
        "uploader": "Zuzi.C12",
        "uploader_id": "362811",
        "view_count": int,
        "like_count": int,
        "comment_count": int,
        "tags": list,
    }
    # Assert that all the data from HitRecordIE_dict is

# Generated at 2022-06-22 07:48:42.370944
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(HitRecordIE._VALID_URL, None) is not None


# Generated at 2022-06-22 07:48:43.077908
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:48:45.374556
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('', '', '', '', '', 'Yes')
    assert ie.is_id_lookup() == False

# Generated at 2022-06-22 07:49:01.118264
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Unit test for the constructor of the class HitRecordIE
    """
    url_list = [
        'https://hitrecord.org/records/2954362',
        'http://www.hitrecord.org/records/3003359'
    ]

    for url in url_list:
        hit_record_ie = HitRecordIE()
        assert hit_record_ie.suitable(url)

# Generated at 2022-06-22 07:49:02.980223
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie != None

# Generated at 2022-06-22 07:49:09.738237
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.name == 'HitRecord'
    url = 'https://www.hitrecord.org/records/2954362'
    assert ie.match_url(url) == 'https://www.hitrecord.org/records/2954362'
    assert ie.valid_url(url) is True
    assert ie.valid_url('https://www.hitrecord.org/records/') is False

# Generated at 2022-06-22 07:49:11.205421
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    record = HitRecordIE()
    assert record.ie_key() == 'hitrecord'

# Generated at 2022-06-22 07:49:14.675334
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract(HitRecordIE._TEST['url'])
    assert('hitrecord.org' in ie.IE_NAME)
    assert(ie._VALID_URL == ie._TEST['url'])

# Generated at 2022-06-22 07:49:15.171168
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-22 07:49:18.829365
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.name == 'hitrecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-22 07:49:19.428500
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:49:30.863110
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(HitRecordIE._VALID_URL)
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-22 07:49:33.727125
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    video_id = ie._match_id('https://hitrecord.org/records/2954362')
    assert video_id == '2954362'

# Generated at 2022-06-22 07:49:59.135880
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    ie = HitRecordIE()
    assert ie._VALID_URL == ie._VALID_URL
    assert ie._TEST['url'] == url

# Generated at 2022-06-22 07:50:02.983130
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Unit test for constructor of class HitRecordIE
    """
    hitrecord_ie = HitRecordIE()
    assert hitrecord_ie.ie_key() == "hitrecord"
    assert hitrecord_ie.ie_name() == "HitRecord.org"

# Generated at 2022-06-22 07:50:04.333510
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract(ie._TEST['url'])

# Generated at 2022-06-22 07:50:04.897997
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:50:07.808293
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:50:08.422387
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-22 07:50:14.673576
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-22 07:50:26.376697
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:50:28.826499
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    print(ie)

test_HitRecordIE()
# End unit test for constructor


# Generated at 2022-06-22 07:50:30.222986
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:51:25.212577
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    class testHitRecordIE(HitRecordIE):
        def __init__(self, *args, **kwargs):
            super(testHitRecordIE, self).__init__(*args, **kwargs)
            self._downloader = None
            self._download_webpage = self._real_extract
            self._match_id = lambda url: url.split('?')[0].split('/')[-1]

    from ..utils import Downloader
    from ..compat import StringIO
    from ..compat import compat_urllib_request

    def _download_webpage(self, *args, **kwargs):
        return self._download_json(*args, **kwargs)


# Generated at 2022-06-22 07:51:27.036117
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE('A Very Different World (HITRECORD x ACLU)')
    print(hitrecord)

# Generated at 2022-06-22 07:51:29.576330
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:51:31.252714
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._real_extract("https://hitrecord.org/records/2954362")

# Generated at 2022-06-22 07:51:32.990312
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecordIE = HitRecordIE()
    return hitrecordIE

# Generated at 2022-06-22 07:51:44.875356
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE();
    assert(ie.embed_url == 'http://hitrecord.org/records/%s')
    assert(ie.suitable('hitrecord.org') == True)
    assert(ie.suitable('hitrecord.net') == False)
    assert(ie.IE_NAME == 'hitrecord:video')
    assert(ie.IE_DESC == 'HitRecord: video')

# Generated at 2022-06-22 07:51:45.464882
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:51:46.845044
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE == HitRecordIE('hitrecord', 'hitrecord.org')

# Generated at 2022-06-22 07:51:49.170773
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE("https://www.hitrecord.org/records/2954362")

# Generated at 2022-06-22 07:51:51.022660
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE().ie_key() == 'HitRecord'

# Generated at 2022-06-22 07:53:25.661796
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    # Assert that the extracted video ID is '2954362'
    assert ie._match_id('https://hitrecord.org/records/2954362') == '2954362'

# Generated at 2022-06-22 07:53:26.129042
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:53:33.729888
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-22 07:53:34.748385
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE() # Does not raise any error

# Generated at 2022-06-22 07:53:35.361583
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:53:35.971451
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:53:37.333980
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-22 07:53:40.574955
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_VideoIE = HitRecordIE()
    assert test_VideoIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    

# Generated at 2022-06-22 07:53:43.260448
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-22 07:53:43.938761
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HitRecordIE()

# Generated at 2022-06-22 07:57:22.721763
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    result = ie.extract('https://hitrecord.org/records/2954362')
    print(result)