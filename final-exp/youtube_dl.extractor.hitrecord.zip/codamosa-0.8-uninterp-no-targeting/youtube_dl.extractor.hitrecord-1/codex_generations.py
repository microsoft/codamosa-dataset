

# Generated at 2022-06-22 07:47:28.991718
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    e = HitRecordIE()

# Generated at 2022-06-22 07:47:30.238582
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-22 07:47:32.088481
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record = HitRecordIE()
    assert isinstance(hit_record, HitRecordIE)

# Generated at 2022-06-22 07:47:34.645569
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Basic test to read if it gives correct info
    """

    HitRecordIE(downloader=None) # pylint: disable=E1002

# Generated at 2022-06-22 07:47:35.366209
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:47:37.243964
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2976863')

# Generated at 2022-06-22 07:47:40.066509
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test for HitRecordIE constructor
    ie = HitRecordIE(HitRecordIE._downloader, HitRecordIE._VALID_URL)
    assert ie._VALID_URL == ie._VALID_URL

# Generated at 2022-06-22 07:47:42.442508
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Simple unit test for checking whether HitRecordIE
    is loading or not.
    """
    ie = HitRecordIE()

# Generated at 2022-06-22 07:47:52.518152
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info = HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')
    print(info)
    assert info['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert info['id'] == '2954362'
    assert info['url'] == 'http://www.hitrecord.org/files/files/original/9177.mp4'
    assert info['tags'] == ['aclu', 'hitrecord', 'immigration', 'opencollab', 'rickygervais']
    assert info['description'] == 'md5:e62defaffab5075a5277736bead95a3d'
    assert info['duration'] == 139.327
    assert info['timestamp'] == 1471557582
    assert info['upload_date'] == '20160818'


# Generated at 2022-06-22 07:47:53.732990
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('fake_url')

# Generated at 2022-06-22 07:48:02.905529
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()


# Generated at 2022-06-22 07:48:03.999055
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Create instance of class
    HitRecordIE()

# Generated at 2022-06-22 07:48:04.852069
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:48:09.088531
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Make up for not having the real constructor
    hitRecordIE = HitRecordIE()
    # Test with a fake URL
    result = hitRecordIE._real_extract("notRealURL")
    # Check to see if method always returns None
    assert(result == None)

# Generated at 2022-06-22 07:48:10.742402
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:48:11.431187
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:48:13.075253
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    print(ie._VALID_URL)

# Generated at 2022-06-22 07:48:13.788330
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:48:16.042579
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except TypeError:
        try:
            HitRecordIE(InfoExtractor)
        except TypeError:
            pass

# Generated at 2022-06-22 07:48:19.789492
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE([], {}, {})
    assert ie.IE_NAME == 'HitRecord'
    assert ie.SUFFIX == 'org'
    assert ie.VALID_URL == HitRecordIE._VALID_URL
    assert ie.TEST == HitRecordIE._TEST

# Generated at 2022-06-22 07:48:37.645188
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie = HitRecordIE("HitRecord")

# Generated at 2022-06-22 07:48:38.730115
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    e = HitRecordIE()
    assert isinstance(e, HitRecordIE)

# Generated at 2022-06-22 07:48:49.277203
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Simple test for constructor of class HitRecordIE
    video_info_extractor = HitRecordIE()

    assert video_info_extractor._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert video_info_extractor._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert video_info_extractor._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert video_info_extractor._TEST['info_dict']['id'] == '2954362'
    assert video_info_extractor._TEST['info_dict']['ext'] == 'mp4'
    assert video_info_extractor._T

# Generated at 2022-06-22 07:48:55.003830
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    unit = HitRecordIE()
    assert unit._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert unit._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'


# Generated at 2022-06-22 07:48:59.700727
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    ex = HitRecordIE()
    ex.check_extraction(url)
    ex.extract(url)

# Generated at 2022-06-22 07:49:05.610731
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ie = HitRecordIE()
	assert ie.NAME == 'hitrecord'
	assert ie.IE_NAME == 'hitrecord'
	assert ie.VALID_URL == 'https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)'
	assert ie.IE_DESC == 'hitrecord'


# Generated at 2022-06-22 07:49:16.222194
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE();
    assert ie.info_extractors != [];
    assert ie.info_extractors[0] != [];
    assert ie.info_extractors[0][0] == HitRecordIE;
    assert ie.info_extractors[0][1] == 'HitRecord';
    assert ie.suitable('https://hitrecord.org/records/2954362');
    assert ie.IE_NAME == 'HitRecord';
    assert ie.IE_DESC == 'HitRecord';
    assert ie._VALID_URL == 'https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)';
    assert ie._TEST != [];
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362';
   

# Generated at 2022-06-22 07:49:26.780163
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.url = 'https://test.com'
    assert ie.ie_key() == 'HitRecord'
    assert ie.ie_key() == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:49:38.262461
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # Test for URL that must be valid
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    # Test for valid link that must be valid

# Generated at 2022-06-22 07:49:39.264408
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()



# Generated at 2022-06-22 07:50:20.811569
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie is not None
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-22 07:50:24.516443
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE('https://hitrecord.org/records/2954362')
    assert info_extractor._match_id('https://hitrecord.org/records/2954362') == '2954362'


# Generated at 2022-06-22 07:50:31.308919
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    assert ie.is_suitable('https://hitrecord.org/records/2954362') == True

    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-22 07:50:41.174081
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:50:41.752534
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:50:44.489805
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, HitRecordIE)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 07:50:49.015035
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video_id = '2954362'
    test_obj = HitRecordIE()
    actual_url = test_obj._real_extract('https://hitrecord.org/records/2954362')
    assert actual_url['id'] == video_id

# Generated at 2022-06-22 07:50:50.022963
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()



# Generated at 2022-06-22 07:50:50.594892
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-22 07:50:55.892550
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert not ie.suitable('https://www.hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:52:27.558188
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.suitable('https://hitrecord.org/records/2954362')
    ie.download('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:52:30.747714
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL



# Generated at 2022-06-22 07:52:39.623485
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test without a video id
    with pytest.raises(ExtractorError) as excinfo:
        HitRecordIE(HitRecordIE._create_ie_instance())
    assert 'Cannot identify video' in str(excinfo.value)

    # Test with a video id
    with pytest.raises(ExtractorError) as excinfo:
        HitRecordIE(HitRecordIE._create_ie_instance('a1234567'))._real_extract('https://hitrecord.org')
    assert 'Video a1234567 does not exist' in str(excinfo.value)

# Generated at 2022-06-22 07:52:41.290640
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    assert hitrecord is not None

# Generated at 2022-06-22 07:52:46.012363
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('/records/2954362')
    assert ie.get_id() == '2954362'
    assert ie.get_url() == 'https://hitrecord.org/records/2954362'

# Generated at 2022-06-22 07:52:47.558963
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(True)
    assert ie



# Generated at 2022-06-22 07:52:57.295269
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('test', 'url')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-22 07:53:03.390250
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test constructor
    ie = HitRecordIE()

    # Test `_real_extract`
    result = ie._real_extract('https://hitrecord.org/records/2954362')
    assert result['id'] == '2954362'

# Generated at 2022-06-22 07:53:03.957478
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:53:04.871824
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:56:20.848689
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie.IE_NAME == 'hitrecord')
    assert(ie.IE_DESC == 'hitrecord.org')
    assert(ie._VALID_URL == ie._TEST['url'])
    assert(ie.IE_VERSION == '0.0.1')
    assert(ie.BRIGHTCOVE_URL_TEMPLATE == None)
    assert(ie.BRIGHTCOVE_SUFFIX_URL == None)
    assert(ie.BRIGHTCOVE_ID_TEMPLATE == None)

# Generated at 2022-06-22 07:56:21.545307
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-22 07:56:24.919876
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    unit = HitRecordIE()
    assert unit.name() == 'hitrecord'
    assert unit.test() == HitRecordIE._TEST
    assert unit.validate_url(HitRecordIE._VALID_URL)
    assert unit.suitable('http://foo.bar') == False

# Generated at 2022-06-22 07:56:28.749658
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie.extractor_key == 'hitrecord'
    assert ie.valid_url == 'https://hitrecord.org/records/2954362'
    assert ie.BASE_URL == 'http://hitrecord.org'
    assert ie.video_id == '2954362'

# Generated at 2022-06-22 07:56:30.325051
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:56:39.332151
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE()
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:56:42.064535
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE('HitRecord', True)
    assert(hitrecord.IE_NAME == 'HitRecord')
    assert(hitrecord.ie_key() == 'hitrecord')
    assert(hitrecord.WORKING == True)

# Generated at 2022-06-22 07:56:51.624777
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()
    assert obj._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert obj._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert obj._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert obj._TEST['info_dict']['id'] == '2954362'
    assert obj._TEST['info_dict']['ext'] == 'mp4'
    assert obj._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-22 07:56:54.919957
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Method that tests the HitRecordIE constructor
    """
    hit_record_ie = HitRecordIE()
    assert "HitRecordIE" in str(hit_record_ie)


# Generated at 2022-06-22 07:56:56.316970
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  ie = HitRecordIE()
  assert ie._VALID_URL