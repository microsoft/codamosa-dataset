

# Generated at 2022-06-22 07:47:31.788483
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_info = HitRecordIE._TEST
    url = test_info['url']
    extractor = HitRecordIE(HitRecordIE());
    assert extractor._match_id(url) == '2954362'

# Generated at 2022-06-22 07:47:34.342996
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Make sure we can initialize an instance of HitRecordIE
    ie = HitRecordIE()
    assert isinstance(ie, HitRecordIE)

# Generated at 2022-06-22 07:47:36.302128
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    if __name__ == '__main__':
        raise Exception('Unit test only. Aborting.')


# Generated at 2022-06-22 07:47:38.994909
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:47:47.260326
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    unit = HitRecordIE()
    print("test_HitRecordIE()")
    print("  " + str(unit.__class__))
    print("  " + str(unit.__class__.__base__))
    print("  " + str(unit.__class__.__bases__))

    # print("  " + str(unit.__doc__))
    # print("  " + str(unit.__dict__))
    # print("  " + str(unit.__file__))
    # print("  " + str(unit.__name__))
    # print("  " + str(unit.__package__))
    # print("  " + str(unit.__path__))
    # print("  " + str(unit.__self__))
    # print("  " + str(unit.__slots

# Generated at 2022-06-22 07:47:48.322459
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-22 07:47:49.272468
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:47:51.336908
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE().get_info('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:47:52.679075
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, HitRecordIE)


# Generated at 2022-06-22 07:47:53.369173
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Instantion
    HitRecordIE()

# Generated at 2022-06-22 07:48:04.960371
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_HitRecordIE.test_object = HitRecordIE()
    assert test_HitRecordIE.test_object


# Generated at 2022-06-22 07:48:16.279783
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == "hitrecord"
    assert ie.IE_DESC == "HitRecord"
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-22 07:48:26.617641
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-22 07:48:29.533114
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
        assert HitRecordIE._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"

# Generated at 2022-06-22 07:48:32.235383
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    This file is only for testing purposes.
    """
    # HitRecordIE - Constructor
    # Constructor of class HitRecordIE for testing purpose
    ie = HitRecordIE()

# Generated at 2022-06-22 07:48:33.039267
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-22 07:48:45.374719
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Get unit test source video URLs
    video_urls = HitRecordIE._TEST['url']
    print(f'{video_urls}')

    # Get unit test expected video metadata
    video_info_dicts = HitRecordIE._TEST['info_dict']
    print(f'{video_info_dicts}')

    # Import the constructor from class HitRecordIE
    from .HitRecordIE import HitRecordIE
    # Instantiate an object of class HitRecordIE
    instance = HitRecordIE(video_urls)
    # Run the unit test and assert on result of extraction
    assert(instance.extract() == video_info_dicts)

# Run the unit test
test_HitRecordIE()

# Print the unit test results to terminal
print("HitRecordIE unit test complete")


# Import the main class

# Generated at 2022-06-22 07:48:47.113336
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except:
        return False

    return True

# Generated at 2022-06-22 07:48:49.028866
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE.HitRecordIE(HitRecordIE)
        assert True
    except:
        assert False

# Generated at 2022-06-22 07:48:52.767746
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    a = HitRecordIE(HitRecordIE._VALID_URL)
    assert a._VALID_URL == HitRecordIE._VALID_URL
    assert a.ie_key() == 'HitRecord'

# Generated at 2022-06-22 07:49:04.692615
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362', 'mp4')
    assert ie == 'HitRecordIE(https://hitrecord.org/records/2954362)'

# Generated at 2022-06-22 07:49:05.821035
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._download_webpage

# Generated at 2022-06-22 07:49:12.348768
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    # assert ie.ie_type() == 'video'
    assert ie.is_suitable('https://hitrecord.org/records/2954362')
    assert not ie.is_suitable('https://hitrecord.org/')
    assert not ie.is_suitable('A different url')

# Generated at 2022-06-22 07:49:23.538177
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-22 07:49:28.440995
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == HitRecordIE.ie_key() # check that class name is correct
    assert ie.suitable("https://hitrecord.org/records/4856279") # check that correct url is suitable
    assert not ie.suitable("https://hitrecord.org/records/4856279/") # check that url with slash at the end is not suitable

# Generated at 2022-06-22 07:49:31.417386
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'HitRecord'


# Generated at 2022-06-22 07:49:32.618850
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE() != None

# Generated at 2022-06-22 07:49:39.099839
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    youtube_ie = ie.get_info_extractor("https://www.hitrecord.org/records/2954362")
    yt_ie = ie.get_info_extractor("https://www.youtube.com/watch?v=26x_GDSShIY")
    assert(youtube_ie == ie)
    assert(yt_ie != ie)

# Generated at 2022-06-22 07:49:44.360081
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:49:46.214554
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._real_extract('http://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:50:11.886633
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:50:13.745906
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    HitRecordIE(url)

# Generated at 2022-06-22 07:50:15.160559
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('HitRecordIE', ('2954362', 'HitRecord'))

# Generated at 2022-06-22 07:50:26.862346
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    url = "https://hitrecord.org/records/2954362"
    id = ie._match_id(url)
    assert ie._VALID_URL == "https://hitrecord.org/records/(?P<id>\d+)"

# Generated at 2022-06-22 07:50:27.471065
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:50:31.006292
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print("Test for HitRecordIE")
    infoExtractor = HitRecordIE('https://hitrecord.org/records/2954362')
    print("Pass!")

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-22 07:50:31.628984
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:50:42.821099
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from .common import shared
    from .common import InfoExtractor
    from .hitrecord import HitRecordIE
  
    x = HitRecordIE()
    assert x._VALID_URL is not None
    assert x.__name__ is not None
    assert shared.testedExtractors[HitRecordIE] is not None
    assert x.SUCCESS is not None
    assert x.FAILED is not None
    assert x.ie is not None
    assert x.ie_key() is not None
    assert x.server is not None
    assert x.sd_url is not None
    assert x.https() is True
    assert x.canExtract(x) is True
    assert x.url_result(x) is not None
    assert x.workingUrl(x) is not None
    assert x._WORKING is True

# Generated at 2022-06-22 07:50:46.078589
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    global ie
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:50:47.056925
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE()



# Generated at 2022-06-22 07:51:40.686767
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:51:48.743591
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ies = {
        'HitRecordIE': HitRecordIE(),
    }
    for name, ie in ies.items():
        assert ie._VALID_URL == HitRecordIE._VALID_URL
        assert ie._TEST == HitRecordIE._TEST
        assert ie._download_json == HitRecordIE._download_json
        assert ie._match_id == HitRecordIE._match_id
        assert ie._real_extract == HitRecordIE._real_extract

# Generated at 2022-06-22 07:51:52.019132
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('0')
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TEST')


# Generated at 2022-06-22 07:51:56.007362
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:51:56.991272
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # This test should not fail
    HitRecordIE()

# Generated at 2022-06-22 07:51:57.452108
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_HitRecordIE

# Generated at 2022-06-22 07:52:05.066095
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE()
    assert hitRecord.ie_key() == 'hitrecord'
    assert hitRecord.ie_name() == 'HitRecord'
    assert hitRecord.exclude() is None
    assert hitRecord._VALID_URL == HitRecordIE._VALID_URL
    assert hitRecord._TEST == HitRecordIE._TEST

# Generated at 2022-06-22 07:52:11.013875
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:52:12.326289
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:52:13.534150
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()

# Generated at 2022-06-22 07:53:51.316495
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:53:59.199468
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video_id = '2954362'
    title = "A Very Different World (HITRECORD x ACLU)"
    video_url = 'https://hitrecord.org/api/records/2954362/file/source_file'
    description = """<p>Here's the third and final episode for the ACLU collaboration! It's about religious freedom...and the lack thereof&#8230;</p>"""
    timestamp = 1471557582
    tags = ["religion", "religious freedom", "student loans", "noah baumbach", "aclu", "hitrecord", "mistertango", "taylor ferber", "joey griffin", "zuzi.c12", "zuzi.c12"]
    hitrecord = HitRecordIE()

# Generated at 2022-06-22 07:54:03.082209
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('HitRecordIE','HitRecordIE','abc','abc','abc','abc','abc','abc','abc','abc')

# Generated at 2022-06-22 07:54:05.601321
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    obj = ie.suitable("https://hitrecord.org/records/2954362")
    assert obj == True


# Generated at 2022-06-22 07:54:06.778921
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:54:07.355903
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:54:08.455159
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-22 07:54:13.200741
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('www.hitrecord.org/records/2954362') == 2954362
    assert HitRecordIE('https://hitrecord.org/records/2954362') == 2954362
    assert HitRecordIE('http://www.hitrecord.org/records/2954362') == 2954362

# Generated at 2022-06-22 07:54:14.932415
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.RE_ID in ie._VALID_URL

# Generated at 2022-06-22 07:54:19.432159
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'