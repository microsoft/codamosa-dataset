

# Generated at 2022-06-22 07:47:33.182588
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Unit test for the HitRecordIE class
    """

    # Instantiate an object of the HitRecordIE class
    hr_ie = HitRecordIE()

    # Instantiate an object of the InfoExtractor class. InfoExtractor
    # is the base class which is inherited by the HitRecordIE class
    ie = InfoExtractor()

    # Assert equality
    assert hr_ie == ie



# Generated at 2022-06-22 07:47:37.867582
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	url = 'https://hitrecord.org/records/2954362'
	i = HitRecordIE(url)
	assert i.url == url
	assert i.video_id == '2954362'
	assert i.__class__.__name__ == 'HitRecordIE'



# Generated at 2022-06-22 07:47:49.574998
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test for constructor of HitRecordIE
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:47:51.280837
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:47:53.094715
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert isinstance(HitRecordIE, InfoExtractor)

# Generated at 2022-06-22 07:47:54.977361
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # If successful, the constructor will return a HitRecordIE object
    assert isinstance(HitRecordIE({}), HitRecordIE)

# Generated at 2022-06-22 07:48:03.786641
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:48:09.664781
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie.ie_key() == 'hitrecord')
    assert(ie.suitable('https://hitrecord.org/records/2954362') == True)
    assert(ie.suitable('https://hitrecord.org/records/2954362') == True)
    assert(ie.suitable('https://hitrecord.org/') == False)

# Generated at 2022-06-22 07:48:10.179241
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:48:20.809000
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test constructing HitRecordIE with url
    url = 'https://hitrecord.org/records/2954362'
    ie = HitRecordIE(url)
    assert ie.url == url
    assert ie.video_id == '2954362'
    assert not ie.headers

    # Test constructing HitRecordIE with url and headers
    url = 'https://hitrecord.org/records/2954362'
    headers = {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:57.0) Gecko/20100101 Firefox/57.0'}
    ie = HitRecordIE(url, headers)
    assert ie.url == url
    assert ie.video_id == '2954362'
    assert ie.headers == headers

    # Test constructing HitRecordIE with

# Generated at 2022-06-22 07:48:32.233432
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except Exception as e:
        assert False, 'Unexpected exception: ' + str(e)

# Generated at 2022-06-22 07:48:36.614933
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE('http://hitrecord.org/records/2954362')
    assert hitRecordIE.ie_key() == 'HitRecord'
    assert hitRecordIE.suitable(hitRecordIE.ie_key())

# Generated at 2022-06-22 07:48:39.416918
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test object creation of HitRecordIE
    HitRecordIE('https://hitrecord.org/records/2954362')
    # end

# Generated at 2022-06-22 07:48:42.643738
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE(InfoExtractor)._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:48:43.617989
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()


# Generated at 2022-06-22 07:48:46.009778
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:48:46.740491
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:48:49.161441
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL
    assert HitRecordIE()._TEST == HitRecordIE._TEST

# Generated at 2022-06-22 07:48:51.531780
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    '''Unit test for constructor of class HitRecordIE'''
    obj = HitRecordIE()
    assert obj != None

# Generated at 2022-06-22 07:49:03.722378
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # some of the key words are from _TEST in HitRecordIE
    # param1: 'url', 'md5', 'info_dict'
    # param2: 'ext', 'title', 'description', 'duration', 'timestamp', 'upload_date', 'uploader',
    #         'uploader_id', 'view_count', 'like_count', 'comment_count', 'tags'
    check_input_1 = HitRecordIE._TEST['url']
    check_input_2 = HitRecordIE._TEST['md5']
    check_input_3 = dict(HitRecordIE._TEST['info_dict'])
    test_obj = HitRecordIE(check_input_1, check_input_2, check_input_3)
    print(test_obj)



# Generated at 2022-06-22 07:49:23.782883
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print(HitRecordIE._TEST)
    HitRecordIE()._real_extract(HitRecordIE._TEST['url'])

# Generated at 2022-06-22 07:49:26.542720
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test = HitRecordIE()
    test._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:49:28.317133
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL
    assert ie._TEST

# Generated at 2022-06-22 07:49:29.794164
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-22 07:49:34.736286
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_cases = [
                "https://hitrecord.org/records/2954362",
                "https://www.hitrecord.org/records/2954362",
                ]
    for url in test_cases:
        url_obj = HitRecordIE.url_result(url)
        assert url_obj == HitRecordIE._VALID_URL

# Generated at 2022-06-22 07:49:36.989221
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    h = HitRecordIE()
    assert(str(h) == "HitRecord Video Extractor")

# Generated at 2022-06-22 07:49:38.424375
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:49:45.454844
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	info = {
		'id': '2954362',
		'title': 'A Very Different World (HITRECORD x ACLU)',
		'description': 'A Very Different World (HITRECORD x ACLU)',
		'url': 'https://d3uijgxjw7pv1m.cloudfront.net/2016/08/1f55c9f0-e62d-11e5-bcc5-d200b63a851c-medium.mp4'
	}
	HitRecordIE._real_extract(HitRecordIE(), info)

# Generated at 2022-06-22 07:49:51.223441
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    global HitRecordIE
    # Test for exception when no '_VALID_URL' is set
    orig_VALID_URL = HitRecordIE._VALID_URL
    HitRecordIE._VALID_URL = None
    try:
        with pytest.raises(Exception, match="HitRecordIE._VALID_URL must be set"):
            HitRecordIE({})
    finally:
        HitRecordIE._VALID_URL = orig_VALID_URL

# Generated at 2022-06-22 07:49:54.007338
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    assert HitRecordIE().suitable(url)



# Generated at 2022-06-22 07:50:44.571455
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hre = HitRecordIE()
    assert hre._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:50:46.027208
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'

# Generated at 2022-06-22 07:50:47.006383
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-22 07:50:48.181371
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    pass

# Generated at 2022-06-22 07:50:50.396489
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE().HitRecordIE.__init__(self, HitRecordIE._VALID_URL, HitRecordIE._TEST)

# Generated at 2022-06-22 07:50:56.032792
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:50:57.925071
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('http://www.hitrecord.org/records/2954362')


# Generated at 2022-06-22 07:51:05.749121
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # pylint: disable=redefined-outer-name
    original_assertEquals = assertEquals
    def new_assertEquals(first, second, msg):
        # assertEquals fails comparing None with a string,
        # even though it says it compares anything
        # http://docs.python.org/2/library/unittest.html#unittest.TestCase.assertEquals
        # To avoid these issues, we compare only strings and ints
        if (isinstance(first, (int, compat_str)) and
                isinstance(second, (int, compat_str))):
            original_assertEquals(first, second)
        elif second is None:
            pass
        else:
            original_assertEquals(first, second)

    # Do not write the new method to class HitRecordIE,
    # because

# Generated at 2022-06-22 07:51:10.502563
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie.id is None
    assert ie.url == 'https://hitrecord.org/records/2954362'
    assert ie.video_id == '2954362'

# Generated at 2022-06-22 07:51:17.173496
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.suitable('https://hitrecord.org/records/2954362')
    url = 'https://hitrecord.org/records/2954362'
    _VALID_URL = r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._match_id(url) == '2954362'


#Unit test for method real_extract of class HitRecordIE

# Generated at 2022-06-22 07:52:53.578327
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:52:56.380239
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL


# Generated at 2022-06-22 07:52:57.132728
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE() != None

# Generated at 2022-06-22 07:52:57.840601
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-22 07:52:58.326040
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:53:09.919592
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = "https://hitrecord.org/records/2954362"
    he = HitRecordIE()
    video = he.extract(url)
    assert video['id'] == '2954362'
    assert he._VALID_URL == url
    assert url == he._TEST['url']
    assert video['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert video['description'] == 'md5:e62defaffab5075a5277736bead95a3d'
    assert 'hitrecord.org/records/2954362' in video['url']
    assert video['duration'] == 139.327
    assert video['timestamp'] == 1471557582
    assert video['upload_date'] == '20160818'

# Generated at 2022-06-22 07:53:12.670231
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Unit test for constructor of class HitRecordIE
    """
    return InfoExtractor("'HitRecordIE")


# Generated at 2022-06-22 07:53:14.238353
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video = HitRecordIE()
    video.extract("https://hitrecord.org/records/2954362")

# Generated at 2022-06-22 07:53:19.632544
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print('Testing constructor of HitRecordIE')

    # Testing with a video URL
    url = "https://hitrecord.org/records/2954362"
    hitRecord_object = HitRecordIE()
    assert hitRecord_object._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert hitRecord_object._match_id(url) == "2954362" 


# Generated at 2022-06-22 07:53:24.846633
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie_HitRecord = HitRecordIE()
    assert ie_HitRecord._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:55:17.099621
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert HitRecordIE._VALID_URL == ie._VALID_URL

# Generated at 2022-06-22 07:55:18.536813
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert isinstance(HitRecordIE, InfoExtractor)

# Generated at 2022-06-22 07:55:20.183955
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('http://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:55:20.789221
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:55:28.031307
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print("Unit test for constructor of class HitRecordIE")
    # Exercise for IE HitRecordIE
    ie = HitRecordIE()
    url = 'https://hitrecord.org/records/2954362'
    result = ie._real_extract(url)
    assert result['url'] == 'https://s3.amazonaws.com/hr-record/source/record/2954362/mp4_file/source.mp4'
    assert result['view_count'] == '0'
    assert result['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert result['id'] == '2954362'
    print("Unit test for constructor of class HitRecordIE ends successfully")

# Generated at 2022-06-22 07:55:32.726842
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.extract_id('https://hitrecord.org/records/2954362') == '2954362'
    assert ie.extract_id('https://hitrecord.org/records/2954362/') == '2954362'

# Generated at 2022-06-22 07:55:34.700129
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  hitRecordIE = HitRecordIE(HitRecordIE._VALID_URL)
  assert hitRecordIE._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-22 07:55:35.559828
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Tests if the object can be constructed
    HitRecordIE()

# Generated at 2022-06-22 07:55:39.023801
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE._VALID_URL = r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:55:40.987530
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie = HitRecordIE(HitRecordIE.ie_key())