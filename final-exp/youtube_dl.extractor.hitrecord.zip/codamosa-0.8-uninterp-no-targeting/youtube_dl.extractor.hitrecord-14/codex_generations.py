

# Generated at 2022-06-22 07:47:28.609445
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:47:31.190641
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # To check if this constructor takes a parameter other than string, return false
    assert 1, HitRecordIE(1)


# Generated at 2022-06-22 07:47:33.031252
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract("https://hitrecord.org/records/2954362")


# Generated at 2022-06-22 07:47:33.937506
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:47:38.301505
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_case = HitRecordIE._TEST
    video_id = HitRecordIE._match_id(test_case['url'])
    test_case['info_dict']['id'] = video_id

    ie = HitRecordIE()
    ie.extract(test_case['url'])

# Generated at 2022-06-22 07:47:49.620756
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(HitRecordIE._VALID_URL, HitRecordIE._TEST)._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:47:54.192430
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(test_URL=u'https://hitrecord.org/records/2954362')
    # Test extract ID
    assert ie._match_id(u'https://hitrecord.org/records/2954362') == '2954362'



# Generated at 2022-06-22 07:47:55.236070
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE({})
    assert ie

# Generated at 2022-06-22 07:47:55.824930
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test = HitRecordIE()
    test.suite()

# Generated at 2022-06-22 07:48:01.022226
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('hitrecord.org')
    assert ie.ie_key() == 'HitRecord'
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('http://www.hitrecord.org/records/2954362') == False

# Generated at 2022-06-22 07:48:06.759424
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-22 07:48:11.083085
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test a custom url
    video_url = 'https://hitrecord.org/records/2954362'
    hitrecord_ie = HitRecordIE()
    hitrecord_ie.suitable([video_url])
    hitrecord_ie.extract(video_url)

# Generated at 2022-06-22 07:48:21.577353
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test case 1: Normal case
    normal_test_case = HitRecordIE(1)
    assert normal_test_case._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert normal_test_case._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert normal_test_case._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert normal_test_case._TEST['info_dict']['id'] == '2954362'
    assert normal_test_case._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-22 07:48:23.769757
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._match_id('https://hitrecord.org/records/2954362')
    assert '2954362' == ie._match_id('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:48:25.837640
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-22 07:48:38.302551
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records/2954362/')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')
    assert ie._VALID_URL == 'https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)'
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HITRECORD: Creative Collaborations'
    assert ie.info_dict['url'] is not None
    assert ie.info_dict['md5'] is not None
    assert ie.info_dict['id'] is not None
    assert ie.info_dict

# Generated at 2022-06-22 07:48:42.208932
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE()
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:48:42.732328
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:48:43.351860
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:48:45.226197
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    assert isinstance(instance, HitRecordIE)



# Generated at 2022-06-22 07:48:57.662314
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('https://hitrecord.org/records/123')
    assert HitRecordIE.suitable('https://hitrecord.org/records/123')
    assert HitRecordIE.suitable('http://hitrecord.org/records/123')

# Generated at 2022-06-22 07:49:09.452263
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    url = 'https://hitrecord.org/records/2954362'
    ie = HitRecordIE()
    ie_video = ie.extract(url)

    expected_id = '2954362'
    expected_url = 'https://www.media.hitrecord.org/videos/2954362/mp4s/2954362.mp4'
    expected_title = 'A Very Different World (HITRECORD x ACLU)'
    expected_description = 'md5:e62defaffab5075a5277736bead95a3d'
    expected_duration = 139.327
    expected_timestamp = 1471557582
    expected_upload_date = '20160818'
    expected_uploader = 'Zuzi.C12'
    expected_uploader_id = '362811'
    expected_

# Generated at 2022-06-22 07:49:19.365858
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit = HitRecordIE()
    test = hit._TEST
    assert hit._VALID_URL == test['url']
    assert hit._match_id(test['url']) == '2954362'
    extract = hit._real_extract(test['url'])
    assert type(extract['title']) == str
    assert type(clean_html(extract['description'])) == str
    assert type(extract['duration']) == float
    assert type(extract['id']) == str
    assert type(extract['timestamp']) == int
    assert type(extract['uploader']) == str
    assert type(extract['uploader_id']) == str
    assert type(extract['view_count']) == int
    assert type(extract['like_count']) == int
    assert type

# Generated at 2022-06-22 07:49:20.352407
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:49:21.410937
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(HitRecordIE._TEST)

# Generated at 2022-06-22 07:49:22.219857
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE() is not None

# Generated at 2022-06-22 07:49:25.699988
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    assert HitRecordIE()._match_id(url) == '2954362'

# Generated at 2022-06-22 07:49:31.213610
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    class_ = HitRecordIE
    instance = class_('https://hitrecord.org/records/2954362')
    assert instance._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert instance._match_id == '2954362'


# Generated at 2022-06-22 07:49:32.880144
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:49:36.838442
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # HitRecordIE's constructor does not check if passed URL is valid or not
    # So this test just construct an instance of HitRecordIE with a random URL
    # No exception will mean test passes
    HitRecordIE(HitRecordIE._VALID_URL)

# Generated at 2022-06-22 07:50:02.376791
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE("HitRecordIE") != None


# Generated at 2022-06-22 07:50:10.150719
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    data = ie._real_extract('https://hitrecord.org/records/2954362')
    assert data['id'] == '2954362'
    assert data['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert data['description'] == '<p>A very different world.</p><p>I sent out the poem &quot;A Very Different World&quot; by Fern Schumer Chapman and asked people to respond.  Jan Willem wrote an original score for Adam\'s and my voice recordings, and VOILA!</p>'
    assert data['duration'] == 139.327
    assert data['like_count'] == 95
    assert data['comment_count'] == 12
    assert data['view_count'] == 1442
    assert data['timestamp'] == 1471557582
   

# Generated at 2022-06-22 07:50:13.304834
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert isinstance(ie, HitRecordIE)

# Generated at 2022-06-22 07:50:14.366319
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    return ie

# Generated at 2022-06-22 07:50:17.127145
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.SUITES == [{
        'suite': 'global',
        'regex': ie._VALID_URL,
        'query': 'url',
    }]

    test = ie._TEST
    assert test['url'] == ie._VALID_URL
    assert test['md5']
    assert test['info_dict']
    assert test['info_dict']['id']
    assert test['info_dict']['title']

# Generated at 2022-06-22 07:50:21.153223
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # test url
    url = 'https://hitrecord.org/records/2954362'
    test = HitRecordIE()._real_extract(url)
    print(test)


if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-22 07:50:29.064540
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # test on empty constructor
    ie = HitRecordIE()
    print(ie)
    # test on normal constructor
    ie = HitRecordIE('http://hitrecord.org/records/2954362')
    print(ie)
    # test on object constructor
    ie = HitRecordIE(HitRecordIE.TEST)
    print(ie)
    # test on YDL object constructor
    HitRecordIE.YDL = {'username': 'peter', 'password': '123'}
    ie = HitRecordIE(HitRecordIE.TEST)
    print(ie)

# Generated at 2022-06-22 07:50:29.915456
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-22 07:50:32.816872
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    testHitRecordIE = HitRecordIE('https://hitrecord.org/records/2954362', lambda x: None)
    assert(testHitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-22 07:50:37.243737
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    '''
    Basic test.
    '''
    assert HitRecordIE()._VALID_URL =="https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"

# Generated at 2022-06-22 07:51:27.957475
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_ie = HitRecordIE('HitRecordIE', 'https://hitrecord.org/records/2954362')
    hitrecord_ie.extractor = 'HitRecordIE'
    hitrecord_ie.video_id = '2954362'
    hitrecord_ie.video_url = 'https://hitrecord.org/records/2954362'
    assert hitrecord_ie.video_id == '2954362'



# Generated at 2022-06-22 07:51:28.578713
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:51:31.426815
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('http://www.hitrecord.org/records/2954362')
    assert ie.host('https://example.org') == 'example.org'


# Generated at 2022-06-22 07:51:32.357719
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert True

# Generated at 2022-06-22 07:51:34.148650
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

test_HitRecordIE()

# Generated at 2022-06-22 07:51:37.524886
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(HitRecordIE._VALID_URL, HitRecordIE._downloader)._downloader == HitRecordIE._downloader

# Generated at 2022-06-22 07:51:38.307553
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	pass

# Generated at 2022-06-22 07:51:42.049459
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE(HitRecordIE._VALID_URL)
    HitRecordIE._TEST
    assert instance.suitable(HitRecordIE._VALID_URL) is True
    assert instance._match_id(HitRecordIE._VALID_URL) == '2954362'

# Generated at 2022-06-22 07:51:53.877805
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.VALID_URL == IE_DESC['hitrecord']['re']

# Generated at 2022-06-22 07:51:54.751523
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')



# Generated at 2022-06-22 07:53:31.220030
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    i = HitRecordIE()
    assert i.suitable('https://hitrecord.org/records/2954362'), "IE.suitable() test"
    assert i.extract('https://hitrecord.org/records/2954362')["title"] == 'A Very Different World (HITRECORD x ACLU)'
    assert i.extract('https://hitrecord.org/records/2954362')["uploader"] == 'Zuzi.C12'

# Generated at 2022-06-22 07:53:41.778874
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:53:47.273589
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie.VALID_URL == HitRecordIE._VALID_URL
    assert ie.VERSION == '0.0.5'
    assert ie._VALID_URL == HitRecordIE._VALID_URL
    assert ie._TEST == HitRecordIE._TEST

# Generated at 2022-06-22 07:53:57.445209
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    # Test the method: HitRecordIE._download_json
    # Test all possible case of the method
    # For example:
    assert HitRecordIE._download_json('https://hitrecord.org/api/web/records/2954362')
    # For example:
    assert HitRecordIE._download_json('https://hitrecord.org/api/web/records/2954363')
    # For example:
    assert HitRecordIE._download_json('https://hitrecord.org/api/web/records/2954359')
    # For example:
    assert HitRecordIE._download_json('https://hitrecord.org/api/web/records/2954361')
    # For example:
    assert HitRecordIE._download_json('https://hitrecord.org/api/web/records/2954365')


# Generated at 2022-06-22 07:53:58.722176
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:54:02.542866
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  ie = HitRecordIE('www.hitrecord.org')
  assert ie.suitable(HitRecordIE._VALID_URL) == True

# Generated at 2022-06-22 07:54:13.199908
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():     # pylint: disable=redefined-outer-name
    ie = HitRecordIE()
    assert ie.suitable('http://www.hitrecord.org/records/2954362')
    assert ie.suitable('http://www.hitrecord.org/records/2954362')
    assert not ie.suitable('http://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:54:23.121725
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    #assert ie._TEST == {'url': 'https://hitrecord.org/records/2954362', 'md5': 'fe1cdc2023bce0bbb95c39c57426aa71', 'info_dict': {'id': '2954362', 'ext': 'mp4', 'title': 'A Very Different World (HITRECORD x ACLU)', 'description': 'md5:e62defaffab5075a5277736bead95a3d', 'duration': 139.327, 'timestamp': 1471557582, 'upload_date': '20160818', 'uploader': 'Zuzi.C12

# Generated at 2022-06-22 07:54:28.177714
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test class constructor
    module = HitRecordIE(None, None)
    assert module.suitable('https://hitrecord.org/records/2954362')
    assert module.extract('https://hitrecord.org/records/2954362') == {}

# Generated at 2022-06-22 07:54:28.764009
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE