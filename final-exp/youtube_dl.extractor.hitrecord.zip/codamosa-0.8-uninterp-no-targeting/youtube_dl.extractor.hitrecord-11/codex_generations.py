

# Generated at 2022-06-22 07:47:30.141477
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	print("\ntesting constructor of HitRecordIE")
	# HitRecordIE object creation
	ie = HitRecordIE()
	# printing all attributes of HitRecordIE object
	print(ie)


# Generated at 2022-06-22 07:47:30.651906
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-22 07:47:41.156423
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Unit test for function _real_extract of class HitRecordIE
    """
    ie = HitRecordIE()
    result_dict = ie._real_extract(
        'https://hitrecord.org/records/2954362')
    assert result_dict['id'] == '2954362'
    assert result_dict['ext'] == 'mp4'
    assert result_dict['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert result_dict['description'] == 'md5:e62defaffab5075a5277736bead95a3d'
    assert result_dict['duration'] == 139.327
    assert result_dict['timestamp'] == 1471557582
    assert result_dict['upload_date'] == '20160818'
    assert result_dict['uploader']

# Generated at 2022-06-22 07:47:42.242656
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()


# Generated at 2022-06-22 07:47:43.372097
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HitRecordIE.suite()

# Generated at 2022-06-22 07:47:45.708448
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.__class__.__name__ == "HitRecordIE"

# Generated at 2022-06-22 07:47:50.191068
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """ Test creation of HitRecordIE """
    # Test hitrecord video
    HitRecordIE(compat_urllib_request.Request('https://hitrecord.org/records/2954362'))

    # Test invalid url
    HitRecordIE(compat_urllib_request.Request('https://hitrecord.org/'))

# Generated at 2022-06-22 07:48:02.273837
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Initialize a HitRecordIE instance
    ie = HitRecordIE()
    # Test HitRecordIE._VALID_URL
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    # Test HitRecordIE._TEST

# Generated at 2022-06-22 07:48:02.962845
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:48:09.145690
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Assume that the constructor is defined in extractor/common.py
    # with the name of InfoExtractor().
    ie = InfoExtractor("test_site", {}, False, None)
    # Since it is hard to obtain a test video for this site,
    # We will test only the constructor here
    assert ie.ie_key() == "HitRecord"
    assert ie.ie_key() == "HitRecord"
    return

# Generated at 2022-06-22 07:48:19.643242
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    TestHitRecordIE = HitRecordIE()
    assert TestHitRecordIE

# Generated at 2022-06-22 07:48:20.228457
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:48:23.357701
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("test_HitRecordIE")
    assert type(ie) == HitRecordIE
    assert ie._VALID_URL == HitRecordIE._VALID_URL


# Generated at 2022-06-22 07:48:27.084439
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print ("Testing constructor and extract of class HitRecordIE")
    testHitRecordIE = HitRecordIE()
    testHitRecordIE.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:48:28.182450
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test for constructor
    HitRecordIE()

# Generated at 2022-06-22 07:48:32.184534
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """ Test for constructor of class HitRecordIE """
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_key() in HitRecordIE.ie_key()



# Generated at 2022-06-22 07:48:36.475414
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie.url == 'https://hitrecord.org/records/2954362'
    assert ie._VALID_URL == ie._VALID_URL

# Generated at 2022-06-22 07:48:37.104746
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:48:38.118536
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:48:48.840285
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:49:09.145881
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:49:17.886587
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')


# Generated at 2022-06-22 07:49:20.387620
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  assert HitRecordIE( 'HitRecordIE', 'hitrecord' )

# Generated at 2022-06-22 07:49:23.134833
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    ie = HitRecordIE()
    assert ie.suitable(url)
    assert ie._VALID_URL == ie.IE_NAME

# Generated at 2022-06-22 07:49:34.468363
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:49:35.838205
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    i = HitRecordIE()

# Generated at 2022-06-22 07:49:37.688091
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._VALID_URL
    ie._TEST


# Generated at 2022-06-22 07:49:38.341677
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:49:43.300588
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test the constructor of class HitRecordIE
    test_url = 'https://hitrecord.org/records/2954362'
    ie = HitRecordIE()
    assert ie._VALID_URL == HitRecordIE._VALID_URL
    assert ie._TEST == HitRecordIE._TEST
    assert ie._match_id(test_url) == '2954362'


# Generated at 2022-06-22 07:49:51.005806
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # For testing
    import doctest
    from .common import InfoExtractor
    from ..compat import compat_str
    from ..utils import (
        clean_html,
        float_or_none,
        int_or_none,
        try_get,
    )

    class HitRecordIE(InfoExtractor):
        _VALID_URL = r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:50:13.905464
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.suite()

# Generated at 2022-06-22 07:50:18.858979
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    module = 'youtube_dl.extractor.hitrecord.HitRecordIE'
    instance = HitRecordIE()
    for key, value in HitRecordIE._TEST.items():
        assert getattr(instance, key) == value, 'test failed for %s' % key

# Generated at 2022-06-22 07:50:19.504228
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:50:22.084817
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Constructor of HitRecordIE class
    """
    ie = HitRecordIE()
    ie.extract('http://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:50:23.158058
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-22 07:50:23.793259
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    Video

# Generated at 2022-06-22 07:50:33.999414
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-22 07:50:44.345414
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    import re
    import sys
    import os
    try:
        re.search(r"^\w+://", "https://hitrecord.org/records/2954362")
        assert sys.argv[1] == "https://hitrecord.org/records/2954362"
        assert not os.path.exists(sys.argv[1])
        assert os.path.exists(os.path.dirname(sys.argv[2]))
    except Exception as e:
        print(e)
        assert False

    ie = HitRecordIE()
    ie.extract()
    assert ie._match_id(sys.argv[1]) == '2954362'
    assert ie._download_json('https://hitrecord.org/api/web/records/2954362', '2954362')

# Generated at 2022-06-22 07:50:47.348115
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE();

# Generated at 2022-06-22 07:50:49.346024
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.__class__.__name__ == "HitRecordIE"

# Generated at 2022-06-22 07:51:44.502192
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    # Test the HitRecordIE instance initialization
    ie = HitRecordIE('HitRecord')
    assert ie._VALID_URL
    assert ie._TEST['url']

# Generated at 2022-06-22 07:51:47.802574
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_HitRecordIE = HitRecordIE()
    assert test_HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-22 07:51:51.862284
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'
    assert ie.ie_name() == 'HitRecord'



# Generated at 2022-06-22 07:51:54.633641
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:51:55.192792
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-22 07:51:57.060368
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# Testing video url.
	url = 'https://hitrecord.org/records/2954362'
	# This creates an instance of the HitRecordIE class.
	HitRecordIE()._real_extract(url)

# Generated at 2022-06-22 07:51:58.257888
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Unit test for constructor of HitRecordIE"""
    assert(HitRecordIE(HitRecordIE._downloader) != None)

# Generated at 2022-06-22 07:52:09.387967
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Testing parameters
    url = "https://hitrecord.org/records/2954362"

# Generated at 2022-06-22 07:52:15.207378
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._match_id(ie._VALID_URL) == '2954362'

# Generated at 2022-06-22 07:52:16.620193
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-22 07:53:18.563660
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    ie = HitRecordIE()._call_api(url)
    assert ie.id == '2954362'
    assert ie._TEST['url'] == ie.url
    assert ie._TEST['id'] == ie.id
    assert ie._TEST['title'] == ie.title
    assert ie._TEST['uploader'] == ie.uploader
    assert ie._TEST['uploader_id'] == ie.uploader_id
    assert ie._TEST['ext'] == ie.ext
    assert ie._TEST['duration'] == ie.duration
    assert ie._TEST['timestamp'] == ie.timestamp
    assert ie._TEST['view_count'] == ie.view_count
    assert ie._TEST['like_count'] == ie

# Generated at 2022-06-22 07:53:23.719315
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Check the unit test of the constructor
    ie = HitRecordIE()
    assert try_get(ie, lambda x: x._VALID_URL)

# Generated at 2022-06-22 07:53:26.985030
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL
    assert HitRecordIE()._TEST == HitRecordIE._TEST
    assert HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:53:27.763756
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:53:28.553647
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	infoExtractor = HitRecordIE()


# Generated at 2022-06-22 07:53:31.656850
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:53:32.654352
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-22 07:53:33.300107
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:53:35.174628
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract(test_HitRecordIE._TEST['url'])

# Generated at 2022-06-22 07:53:36.290662
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None, None)

# Generated at 2022-06-22 07:55:22.796275
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:55:31.118587
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	info = HitRecordIE()
	assert(info._VALID_URL=='https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')
	assert(info._TEST['url']=='https://hitrecord.org/records/2954362')
	assert(info._TEST['md5']=='fe1cdc2023bce0bbb95c39c57426aa71')

	assert(info._TEST['info_dict']['id']=='2954362')
	assert(info._TEST['info_dict']['ext']=='mp4')
	assert(info._TEST['info_dict']['title']=='A Very Different World (HITRECORD x ACLU)')

# Generated at 2022-06-22 07:55:33.964928
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE._download = HitRecordIE._download_json
    HitRecordIE._download_webpage = HitRecordIE._download_json
    HitRecordIE._real_initialize()
    HitRecordIE.ie_key = 'HitRecord'

# Generated at 2022-06-22 07:55:35.196127
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE()

# Generated at 2022-06-22 07:55:37.600866
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print(HitRecordIE.__name__)
    return HitRecordIE

# Generated at 2022-06-22 07:55:48.754972
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    url = "https://hitrecord.org/records/2954362"
    assert hitrecord._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert hitrecord._match_id(url) == '2954362'
    assert hitrecord._TEST['url'] == url
    assert hitrecord._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert hitrecord._TEST['info_dict']['id'] == '2954362'
    assert hitrecord._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-22 07:55:50.224247
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 07:55:54.708886
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'



# Generated at 2022-06-22 07:55:58.138879
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    print(hitRecordIE)

# Generated at 2022-06-22 07:56:00.801303
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('www.hitrecord.org')
    print(ie.__class__.__name__)
