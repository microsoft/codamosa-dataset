

# Generated at 2022-06-22 07:47:29.248405
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:47:34.141891
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._TEST['url'] == HitRecordIE._TEST['url']
    assert ie._TEST['md5'] == HitRecordIE._TEST['md5']
    assert ie._TEST['info_dict'] == HitRecordIE._TEST['info_dict']

# Generated at 2022-06-22 07:47:42.458053
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from .test_video_hitrecord import test_HitRecordIE
    mp4_url = "https://s3.amazonaws.com/record-dev/record/1/1/3559/original/S2954362___1461781587_1080.mp4"
    video_url = "https://hitrecord.org/records/2954362"
    hitrecord_ie = HitRecordIE()
    video = hitrecord_ie._real_extract(video_url)
    assert video['url'] == mp4_url
    assert video['id'] == "2954362"
    assert video['title'] == "A Very Different World (HITRECORD x ACLU)"

# Generated at 2022-06-22 07:47:52.550661
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE({})

# Generated at 2022-06-22 07:47:53.323363
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:47:58.876326
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("http://hitrecord.org/records/2954362")
    # All fields of InfoExtractor can be found and are correct
    assert ie.name == "HitRecord"
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:47:59.565302
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:48:01.234566
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-22 07:48:02.608707
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362")


# Generated at 2022-06-22 07:48:10.227786
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie.url == 'https://hitrecord.org/records/2954362'
    assert ie.video_id == '2954362'

    ie = HitRecordIE('https://hitrecord.org/records/2954362/test')
    assert ie.url == 'https://hitrecord.org/records/2954362'
    assert ie.video_id == '2954362'



# Generated at 2022-06-22 07:48:30.535434
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    assert(hitRecordIE._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)")

# Generated at 2022-06-22 07:48:31.398617
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None,None)

# Generated at 2022-06-22 07:48:32.895772
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'HitRecord'

# Generated at 2022-06-22 07:48:33.510684
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE

# Generated at 2022-06-22 07:48:34.525611
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # TODO
    pass

# Generated at 2022-06-22 07:48:36.635071
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:48:37.916031
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test constructor HitRecordIE()
    HitRecordIE()

# Generated at 2022-06-22 07:48:41.294840
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'

    hrIE = HitRecordIE(url)
    video = hrIE.extract()

    assert video['url']

# Generated at 2022-06-22 07:48:51.788868
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-22 07:49:03.991351
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-22 07:49:15.117547
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    IE = HitRecordIE()
    assert IE.get_url()

# Generated at 2022-06-22 07:49:16.202664
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    e = HitRecordIE()
    assert(e)

# Generated at 2022-06-22 07:49:26.779698
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-22 07:49:38.262719
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('hitrecord.org')
    assert ie.suitable('https://hitrecord.org')
    assert not ie.suitable('https://youtube.com')
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/artists/362811')
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord, an open online community of creative collaborators'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:49:40.791461
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:49:50.889195
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:49:54.007455
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    h = HitRecordIE('http://hitrecord.org/records/12345')
    assert h.url == 'https://hitrecord.org/records/12345'

# Generated at 2022-06-22 07:49:54.802779
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:49:57.070121
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Todo: Improve this unittest
    HitRecordIE()

# Generated at 2022-06-22 07:49:58.609440
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_extractor = HitRecordIE()


# Generated at 2022-06-22 07:50:22.345841
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        if __name__ == "__main__":
            test_HitRecordIE()
    except:
        print ("test_HitRecordIE Error!\n")
        import traceback
        traceback.print_exc()
        os._exit(-1)
    else:
        print ("test_HitRecordIE OK!\n")

__END__ = True

# Generated at 2022-06-22 07:50:23.053175
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:50:25.112305
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable("https://hitrecord.org/records/2954362")

# Generated at 2022-06-22 07:50:27.610999
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE().suitable("https://hitrecord.org/records/2954362") == True
    assert HitRecordIE().suitable("https://hitrecord.org/") == False

# Generated at 2022-06-22 07:50:34.120636
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable("http://hitrecord.org/records/2954362")
    assert ie._VALID_URL == "https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)"
    assert ie._TEST["url"] == "https://hitrecord.org/records/2954362"
    assert ie._TEST["md5"] == "fe1cdc2023bce0bbb95c39c57426aa71"

# Generated at 2022-06-22 07:50:35.371471
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:50:37.148892
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(HitRecordIE.create_ie())._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-22 07:50:40.668001
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        assert HitRecordIE(InfoExtractor={})
    except:
        raise AssertionError("Failed to create HitRecordIE instance")


# Generated at 2022-06-22 07:50:41.220592
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:50:42.999421
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:51:41.452300
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:51:42.453912
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # TODO
    assert True

# Generated at 2022-06-22 07:51:45.836498
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_obj = HitRecordIE('HitRecordIE', '/home/mjbales/projects/youtube-dl/hitrecord.py')
    assert test_obj.name == 'HitRecordIE'

# Generated at 2022-06-22 07:51:46.845726
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-22 07:51:48.684461
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    #Test instantiating HitRecordIE
    HitRecordIE()

# Generated at 2022-06-22 07:51:51.967844
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    e = HitRecordIE()
    assert e._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:51:54.332396
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    if hasattr(hitrecord, HitRecordIE):
        tester = HitRecordIE(hitrecord)
    assert tester




# Generated at 2022-06-22 07:51:56.943392
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()
    assert obj._TEST == HitRecordIE._TEST
    assert obj._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-22 07:51:59.059038
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:52:02.706813
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Constructor: HitRecordIE(HitRecordIE)
    HitRecordIE()

# Generated at 2022-06-22 07:53:36.139544
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:53:46.744655
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:53:56.023458
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie == ie


# Generated at 2022-06-22 07:53:57.591799
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:54:09.174971
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-22 07:54:10.842826
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-22 07:54:11.983865
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-22 07:54:13.822559
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hIE = HitRecordIE(HitRecordIE._VALID_URL);
    assert hIE != None;

# Generated at 2022-06-22 07:54:15.852749
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('HitRecordIE','http://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:54:19.636464
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'