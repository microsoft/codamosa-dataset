

# Generated at 2022-06-22 07:47:29.294722
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Test case for constructor of class HitRecordIE
    """

    HitRecordIE()
    HitRecordIE.ie_key()
    HitRecordIE.suitable(HitRecordIE._VALID_URL)

# Generated at 2022-06-22 07:47:30.144333
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:47:31.106138
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:47:32.575872
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('hitrecord.org/records/2954362')
    # pass

# Generated at 2022-06-22 07:47:42.733023
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-22 07:47:43.476351
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:47:51.039485
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    url1 = HitRecordIE._VALID_URL + '1'
    url2 = HitRecordIE._VALID_URL + '2'

    ie1 = HitRecordIE(url1)
    ie2 = HitRecordIE(url2)

    if not ie1.url == url1:
        raise AssertionError("HitRecordIE's url is not correct")
    if not ie1._match_id("https://hitrecord.org/records/2954362") == "2954362":
        raise AssertionError("HitRecordIE's match_id is not correct")

# Generated at 2022-06-22 07:47:57.347217
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.name == 'HitRecord'
    assert ie.ie_key == 'HitRecord'
    assert ie.host == 'hitrecord.org'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:47:58.732268
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(HitRecordIE._TEST)

# Generated at 2022-06-22 07:48:01.907713
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:48:16.093860
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._TEST == test_HitRecordIE.__dict__['_TEST']

# Generated at 2022-06-22 07:48:16.857585
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('hitrecord.org')

# Generated at 2022-06-22 07:48:27.971676
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:48:29.047170
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-22 07:48:33.019188
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE()
    assert info_extractor.suitable

    def test_HitRecordIE_download(self):
        pass
    # testing extractor
    info_extractor.download('http://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:48:33.949493
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE()

# Generated at 2022-06-22 07:48:36.118555
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie.name == 'HitRecord'
    assert ie.url == 'https://hitrecord.org/records/2954362'

# Generated at 2022-06-22 07:48:36.741695
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:48:40.250505
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('HitRecord')
    print("Test: construct of class")
    assert ie.__class__.__name__ == HitRecordIE.__name__


# Generated at 2022-06-22 07:48:40.922031
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:49:02.649299
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    init = HitRecordIE.__name__
    assert init != None
    assert init == 'HitRecordIE'

# Generated at 2022-06-22 07:49:13.956072
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_file_dir = os.path.dirname(os.path.abspath(__file__))
    test_file_name = 'test_HitRecordIE_constructor.py'
    with open(os.path.join(test_file_dir, test_file_name), 'r') as test_file:
        content = test_file.read()
    init_file_name = '__init__.py'
    with open(os.path.join(test_file_dir, init_file_name), 'w') as init_file:
        init_file.write(content)
    
    from .test_HitRecordIE_constructor import TestHitRecordIE
    # unittest.main()
    suite = unittest.TestLoader().loadTestsFromTestCase(TestHitRecordIE)
    unittest

# Generated at 2022-06-22 07:49:15.882063
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE("http://hitrecord.org/records/2954362")

# Generated at 2022-06-22 07:49:19.059950
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from .embed import EmbedBaseIE

    ie = HitRecordIE()
    embed_ie = EmbedBaseIE()
    assert ie is not embed_ie
    assert ie.embed_pattern == embed_ie.embed_pattern

# Generated at 2022-06-22 07:49:20.913720
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:49:21.513264
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:49:21.993474
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Exercise
    HitRecordIE()

# Generated at 2022-06-22 07:49:25.467390
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    import HitRecordIE as module
    return module

if __name__ == "__main__":
    test_HitRecordIE()

# Generated at 2022-06-22 07:49:26.263230
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	hitRecord_test = InfoExtractor.test

# Generated at 2022-06-22 07:49:29.793882
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")

    assert ie.match("https://hitrecord.org/records/2954362")

# Generated at 2022-06-22 07:49:55.033279
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-22 07:50:05.888369
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-22 07:50:07.310716
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    s = HitRecordIE("https://hitrecord.org/records/2954362")
    assert s

# Generated at 2022-06-22 07:50:16.575806
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.IE_NAME == 'hitrecord'
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:50:17.863725
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    assert hitrecord.ie_key() == 'hitrecord'
    assert hitrecord.IE_DESC == 'HitRecord'

# Generated at 2022-06-22 07:50:28.730462
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.url_result(_TEST['url'])
    #assert ie.extract(_TEST['url'])['id'] == _TEST['info_dict']['id']
    assert ie.extract(_TEST['url'])['title'] == _TEST['info_dict']['title']
    #assert ie.extract(_TEST['url'])['ext'] == _TEST['info_dict']['ext']
    assert ie.extract(_TEST['url'])['md5'] == _TEST['md5']
    #assert ie.extract(_TEST['url'])['duration'] == _TEST['info_dict']['duration']

# Generated at 2022-06-22 07:50:29.525918
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert type(HitRecordIE({}) == HitRecordIE)

# Generated at 2022-06-22 07:50:30.525266
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(HitRecordIE._downloader, HitRecordIE._VALID_URL)

# Generated at 2022-06-22 07:50:40.433877
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    i = HitRecordIE()
    assert i.get_info('https://hitrecord.org/records/2954362') != None
    assert i.get_info('https://hitrecord.org/records/2954362') == 'mp4'
    assert i.get_info('https://hitrecord.org/records/2954362') == 139.327
    assert i.get_info('https://hitrecord.org/records/2954362') == 1471557582
    assert i.get_info('https://hitrecord.org/records/2954362') == 'Zuzi.C12'
    assert i.get_info('https://hitrecord.org/records/2954362') == '362811'
    assert i.get_info('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:50:43.959881
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    aHR = HitRecordIE()
    assert aHR._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:51:42.337515
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'

# Generated at 2022-06-22 07:51:43.317903
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-22 07:51:46.305530
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"
    

# Generated at 2022-06-22 07:51:49.023277
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  #assert HitRecordIE(InfoExtractor(), 'https://hitrecord.org/records/2954362')
  assert True

# Generated at 2022-06-22 07:51:59.827097
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    url = 'https://hitrecord.org/records/2954362'
    video_id = ie._match_id(url)
    video_url = 'https://hitrecord.org/api/web/records/%s' % video_id
    video_json = ie._download_json(video_url, video_id)

# Generated at 2022-06-22 07:52:09.547312
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2972528', True)

    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-22 07:52:14.076562
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    class TestHitRecordIE(HitRecordIE):
        _VALID_URL = HitRecordIE._VALID_URL
        _TEST = HitRecordIE._TEST

    # Test constructor
    HitRecordIE() == TestHitRecordIE()

# Generated at 2022-06-22 07:52:15.731352
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	hitRecordIE = HitRecordIE()
	print (hitRecordIE._VALID_URL)

# Generated at 2022-06-22 07:52:16.374604
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:52:23.534593
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Basic test
    url = 'https://hitrecord.org/records/2954362'
    ie = HitRecordIE(HitRecordIE._VALID_URL)
    match = ie._match_id(url)
    assert match.group('id') == '2954362'

    # Test fetching url
    url = ie._real_extract(url)['url']
    data = ie._download_webpage(url, 'tmp.mp4')
    assert(len(data) > 0)

# Generated at 2022-06-22 07:54:23.251227
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('http://hitrecord.org/records/2954362')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie.name == 'HitRecord'
    assert ie.url == 'https://hitrecord.org/records/2954362'
    assert ie.video_id == '2954362'


# Generated at 2022-06-22 07:54:34.566775
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')

    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/%s/%s_default/index.html?videoId=%s'

# Generated at 2022-06-22 07:54:40.693105
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # This url parses successfully
    url = "http://www.hitrecord.org/records/2954362"
    HitRecordIE(url)
    # This one does not
    url = "http://www.HitRecord.org/records/2954362"
    try:
        HitRecordIE(url)
    except:
        return

# Generated at 2022-06-22 07:54:49.429342
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-22 07:55:00.457612
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video = HitRecordIE._TEST
    test = HitRecordIE()._download_json(
        video['url'], video['id'])
    assert test['url'] == video['url']
    assert test['title'] == video['title']
    assert test['description'] == video['description']
    assert test['duration'] == video['duration']
    assert test['timestamp'] == video['timestamp']
    assert test['uploader'] == video['uploader']
    assert test['uploader_id'] == video['uploader_id']
    assert test['view_count'] == video['view_count']
    assert test['like_count'] == video['like_count']
    assert test['comment_count'] == video['comment_count']
    assert test['tags'] == video['tags']

# Generated at 2022-06-22 07:55:01.883238
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert(HitRecordIE == HitRecordIE(InfoExtractor()))



# Generated at 2022-06-22 07:55:02.401635
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:55:07.189670
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()

    url = "https://hitrecord.org/records/2954362"
    IEkey = hitRecordIE.extract(url)

    assert(IEkey['view_count'] >= 0)

# Generated at 2022-06-22 07:55:17.523059
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:55:29.870598
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_data = HitRecordIE._TEST
    url = test_data['url']

    ie = HitRecordIE(url)
    data = ie._real_extract(url)
    assert ie._match_id(url) in url
    assert data['id'] == test_data['info_dict']['id']
    assert data['url'] == test_data['info_dict']['url']
    assert data['title'] == test_data['info_dict']['title']
    assert data['description'] == test_data['info_dict']['description']
    assert data['duration'] == test_data['info_dict']['duration']
    assert data['timestamp'] == test_data['info_dict']['timestamp']