

# Generated at 2022-06-22 07:47:31.385378
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    print('Test HitRecordIE constructor')
    assert isinstance(hitRecordIE, HitRecordIE)
    print('Test HitRecordIE constructor: OK')


# Generated at 2022-06-22 07:47:34.343509
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:47:43.819333
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == 'https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)', "Invalid _VALID_URL"
    assert HitRecordIE._TEST['url'] == 'https://hitrecord.org/records/2954362', "Invalid _TEST['url']"
    assert HitRecordIE._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71', "Invalid _TEST['md5']"
    assert HitRecordIE._TEST['info_dict']['id'] == '2954362', "Invalid _TEST['info_dict']['id']"

# Generated at 2022-06-22 07:47:47.289491
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:47:50.781992
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
        test_success = True
    except Exception as e:
        print("[error] HitRecordIE() returns an error: %s" % e)
        test_success = False
    assert test_success == True

# Generated at 2022-06-22 07:47:58.359373
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie = HitRecordIE('HitRecord')
    assert ie.ie_key() == 'HitRecord'
    ie = HitRecordIE('HitRecord', {'some_key': 'some_value'})
    ie = HitRecordIE('HitRecord', {'username': 'some_value'})
    ie = HitRecordIE('HitRecord', {'password': 'some_value'})
    ie = HitRecordIE('HitRecord', {'username': 'some_value', 'password': 'some_value'})

# Generated at 2022-06-22 07:48:03.781468
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecordie = HitRecordIE()
    # Make sure IEs have a working _match_id method
    assert hitrecordie._match_id('https://hitrecord.org/records/2954362') == '2954362'
    assert hitrecordie._match_id('https://hitrecord.org/records/2954362') is not None

# Generated at 2022-06-22 07:48:04.559244
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:48:05.231465
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:48:05.934318
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE

# Generated at 2022-06-22 07:48:11.960159
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(HitRecordIE._VALID_URL) is not None

# Generated at 2022-06-22 07:48:12.691553
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:48:23.085931
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._component_re_str == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:48:25.104587
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    assert isinstance(instance, HitRecordIE)


# Generated at 2022-06-22 07:48:27.469804
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hr_ie = HitRecordIE()
    assert hr_ie == HitRecordIE()


# Generated at 2022-06-22 07:48:39.886866
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE({})._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:48:40.757632
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:48:46.115500
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # Test with a url that is not valid
    assert ie._valid_url("https://www.hitrecord.org/records/2954362/") == False
    # Test with a valid url
    assert ie._valid_url("https://hitrecord.org/records/2954362") == '2954362'


# Generated at 2022-06-22 07:48:55.115751
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    constructor = HitRecordIE("'https://hitrecord.org/records/2954362")
    #Test the valid url of the constructor
    assert constructor._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    #Test the video ID of the constructor
    assert constructor._match_id("'https://hitrecord.org/records/2954362").group("id") == "2954362"
    #Test the extract function of the constructor to make sure the extract function does indeed return the correct
    #title, description, uploader, and view_count
    test_extract = constructor._real_extract("'https://hitrecord.org/records/2954362")

# Generated at 2022-06-22 07:48:58.086409
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:49:10.862391
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie.url == 'https://hitrecord.org/records/2954362'

# Generated at 2022-06-22 07:49:12.183114
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    HitRecordIE(url)

# Generated at 2022-06-22 07:49:12.674129
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:49:15.188598
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    video_id = '2954362'
    assert video_id == HitRecordIE._match_id(url)

# Generated at 2022-06-22 07:49:15.944231
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:49:21.949816
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.suitable('https://hitrecord.org/records/2954362')
    assert '2954362' == ie._match_id('https://hitrecord.org/records/2954362')
    assert 'https://hitrecord.org/records/2954362' == ie.IE_NAME
    assert 'HitRecordIE' == ie.ie_key()

# Generated at 2022-06-22 07:49:22.553043
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:49:23.152390
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test = HitRecordIE()
    test.suite()

# Generated at 2022-06-22 07:49:24.962608
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    a = HitRecordIE()

# Generated at 2022-06-22 07:49:25.740226
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:49:48.382991
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE({})
    assert(hitRecordIE
        ._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-22 07:49:52.742972
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:49:56.680167
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HitRecordIE()
	print("Unit test for constructor of class HitRecordIE")
	print("Unit test passed")


# Generated at 2022-06-22 07:50:06.451344
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE._VALID_URL = r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:50:11.128087
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = url = 'https://hitrecord.org/records/2954362'
    ie = HitRecordIE.ie_key()(url)
    assert ie.__class__ == HitRecordIE
    assert ie._VALID_URL == HitRecordIE._VALID_URL
    # test that the regex compiles
    assert ie._match_id(url)

# Generated at 2022-06-22 07:50:14.760418
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362")
    HitRecordIE("https://www.hitrecord.org/records/2954362")
    HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-22 07:50:15.915961
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('HitRecord', 'HitRecord', 'HitRecord')
    assert ie.ie_key() == 'HitRecord'

# Generated at 2022-06-22 07:50:19.853217
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
#    self._test_real_extract('hitrecord', '2954362', 'HitRecordIE', '2954362')
    HitRecordIE().download('https://www.hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:50:23.740553
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Test HitRecordIE."""
    assert HitRecordIE._VALID_URL == HitRecordIE._TEST['url']
    assert HitRecordIE._TEST['info_dict'] == HitRecordIE()._real_extract(HitRecordIE._TEST['url'])

# Generated at 2022-06-22 07:50:24.566583
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:51:08.535840
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:51:09.257662
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-22 07:51:09.870175
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:51:10.892327
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE() is not None

# Generated at 2022-06-22 07:51:21.192904
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == "hitrecord"
    assert HitRecordIE.IE_NAME == "hitrecord"
    assert ie.IE_DESC == "HitRecord"
    assert HitRecordIE.IE_DESC == "HitRecord"
    assert ie.IE_VERSION == "0.0.1"
    assert HitRecordIE.IE_VERSION == "0.0.1"
    assert ie.VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert HitRecordIE.VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:51:22.830425
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    class_HitRecordIE = HitRecordIE()

# Generated at 2022-06-22 07:51:25.762191
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  url = 'https://hitrecord.org/records/2954362'
  x = HitRecordIE().suitable(url)
  assert x == True

# Generated at 2022-06-22 07:51:27.184427
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-22 07:51:29.331168
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE(None)
    except TypeError as e:
        assert "__init__() missing 1 required positional argument" in str(e)

# Generated at 2022-06-22 07:51:30.723247
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL is not None

# Generated at 2022-06-22 07:52:57.571320
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert(HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')


# Generated at 2022-06-22 07:53:01.259358
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# Just check that the constructor of HitRecordIE doesn't raise exception
	ie = HitRecordIE()
	assert ie != None

# Generated at 2022-06-22 07:53:06.352843
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ht = HitRecordIE(HitRecordIE._VALID_URL, HitRecordIE._TEST)
    if ht is None:
        return "Unit test for constructor of class HitRecordIE failed"
    return "Unit test for constructor of class HitRecordIE succeeded"


# Generated at 2022-06-22 07:53:10.587543
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'hitrecord.org'


# Generated at 2022-06-22 07:53:12.239657
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    h = HitRecordIE()
    h.extract()

# Generated at 2022-06-22 07:53:14.237400
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie=HitRecordIE();
    assert ie.get_info('https://hitrecord.org/records/2954362') != None

# Generated at 2022-06-22 07:53:15.670636
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._VALID_URL

# Generated at 2022-06-22 07:53:18.178000
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hie = HitRecordIE()
    hie.extract('https://hitrecord.org/records/2954362')


# Generated at 2022-06-22 07:53:19.298546
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('http://www.hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:53:19.781938
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:56:54.513652
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    IE = HitRecordIE()
    assert IE.suitable("http://hitrecord.org/records/2954362")

# Generated at 2022-06-22 07:56:55.208214
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:57:00.606317
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert str(type(ie)) == "<class 'youtube_dl.extractor.hitrecord.HitRecordIE'>"
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\\d+)'
    

# Generated at 2022-06-22 07:57:04.140661
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    # Test id extractor
    assert '2954362' == ie._match_id(
        'https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:57:08.355989
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Arrange
    expected_HitRecordIE = HitRecordIE(None)

    # Act
    HitRecordIE_obj = HitRecordIE(None)

    # Assert
    assert HitRecordIE_obj._VALID_URL == expected_HitRecordIE._VALID_URL

# Generated at 2022-06-22 07:57:10.124365
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    assert hitRecordIE._VALID_URL is not None

# Generated at 2022-06-22 07:57:13.510785
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:57:21.420480
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Create object
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'