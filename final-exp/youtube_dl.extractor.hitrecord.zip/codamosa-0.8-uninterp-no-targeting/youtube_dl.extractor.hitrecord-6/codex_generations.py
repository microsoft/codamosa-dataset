

# Generated at 2022-06-22 07:47:31.205724
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:47:33.780022
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    Constructor = HitRecordIE('https://hitrecord.org/records/2954362')
    assert (isinstance(Constructor,InfoExtractor))

# Generated at 2022-06-22 07:47:37.775739
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._VALID_URL = r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Unit testing for _real_extract method of HitRecordIE class

# Generated at 2022-06-22 07:47:40.820293
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Basic test for HitRecordIE"""
    hr = HitRecordIE()
    assert isinstance(hr, HitRecordIE)


# Generated at 2022-06-22 07:47:41.855107
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(HitRecordIE._downloader)

# Generated at 2022-06-22 07:47:44.080158
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	return HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:47:45.357803
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.name

# Generated at 2022-06-22 07:47:46.430638
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:47:48.308008
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:47:48.881546
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:47:59.110796
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:48:02.070009
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:48:04.051455
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hr_ie = HitRecordIE()
    assert hr_ie.IE_NAME == 'hitrecord'

# Generated at 2022-06-22 07:48:05.818439
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, HitRecordIE)

# Generated at 2022-06-22 07:48:07.278819
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:48:09.770496
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE(): 
        ie = HitRecordIE()
        ie.extract("https://hitrecord.org/records/2954362")
test_HitRecordIE()

# Generated at 2022-06-22 07:48:20.517869
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    # Test cases for playing video
    test_cases = {
        'basic' : 'https://hitrecord.org/records/2954362',
        'subtitles' : 'https://hitrecord.org/records/1630343'
    }

    for key in test_cases:
        # Download IE
        hitrecord_ie = HitRecordIE()

        # Get info
        info_dict = hitrecord_ie._real_extract(test_cases[key])

        # Check info_dict
        assert isinstance(info_dict, dict)
        assert info_dict.get('url')
        assert info_dict.get('id')
        assert info_dict.get('ext')
        assert info_dict.get('title')
        assert info_dict.get('description')
        assert info_dict.get('timestamp')

# Generated at 2022-06-22 07:48:23.666201
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    '''
    Test constructor of class HitRecordIE
    '''
    url = 'https://hitrecord.org/records/2954362'
    test = HitRecordIE(url)

    assert test

# Generated at 2022-06-22 07:48:24.826948
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE() is not None

# Generated at 2022-06-22 07:48:25.942181
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    testVideo = HitRecordIE()


# Generated at 2022-06-22 07:48:51.970780
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    ie = HitRecordIE(url)
    assert ie.valid_url(url)
    assert ie.valid_url('https://hitrecord.org/records/2954362') is True
    assert ie.valid_url('https://hitrecord.org/records/2954362/test') is False
    assert ie.valid_url('https://hitrecord.org/records/2954362/test/') is False

# Generated at 2022-06-22 07:48:52.769291
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()


# Generated at 2022-06-22 07:48:55.383682
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE()
    assert hitRecord.ie_key() == 'hitrecord'

# Generated at 2022-06-22 07:49:06.946266
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-22 07:49:18.048663
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    # Test for method _real_extract
    test_HitRecordIE.info_dict = ie._real_extract(test_HitRecordIE.url)
    assert test_HitRecordIE.info_dict['id'] == '2954362'
    assert test_HitRecordIE.info_dict['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert test_HitRecordIE.info_dict['description'] == 'md5:e62defaffab5075a5277736bead95a3d'
    assert test_HitRecordIE.info_dict['duration'] == 139.327

# Generated at 2022-06-22 07:49:20.856360
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('http://www.hitrecord.org/records/2954362', {})

# Generated at 2022-06-22 07:49:23.640859
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    IE = HitRecordIE()
    assert IE.IE_NAME == 'hitrecord'
    assert IE.IE_DESC == 'hitrecord.org'
    assert len(IE._TESTS) == 1


# Generated at 2022-06-22 07:49:25.800596
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert 'HitRecord' in ie._VALID_URL
    assert 'HitRecord' in ie._TEST

# Generated at 2022-06-22 07:49:27.388529
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362');

# Generated at 2022-06-22 07:49:28.589591
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE()

# Generated at 2022-06-22 07:50:11.837185
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE() is not None


# Generated at 2022-06-22 07:50:20.957962
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    unit_test_url = 'https://hitrecord.org/records/2954362'
    test = HitRecordIE()
    assert test._VALID_URL == HitRecordIE._VALID_URL
    assert test._TEST['url'] == HitRecordIE._TEST['url']
    assert test._TEST['md5'] == HitRecordIE._TEST['md5']
    assert test._TEST['info_dict'] == HitRecordIE._TEST['info_dict']
    assert test._real_extract(unit_test_url) == HitRecordIE._real_extract(test, unit_test_url)

# Generated at 2022-06-22 07:50:24.256645
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'

    try:
        HitRecordIE()._real_extract(url)
    except Exception:
        print('test_HitRecordIE failed!')

# Generated at 2022-06-22 07:50:34.201240
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = "https://hitrecord.org/records/2954362"
    video_id = str(2954362)
    title = "A Very Different World (HITRECORD x ACLU)"
    description = "<p>A short film I made based on the @JayJay's great " \
        "script and my own personal experiences growing up as a Vietnamese " \
        "American.</p>"
    duration = 139.327
    timestamp = int(1471557582)
    uploader = "Zuzi.C12"
    uploader_id = str(362811)
    view_count = int()
    like_count = int()
    comment_count = int()
    tags = []

    infoextractor = HitRecordIE()
    result = infoextractor._real_extract(url)


# Generated at 2022-06-22 07:50:36.729038
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:50:39.147878
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE()
    assert hitRecord is not None

# Generated at 2022-06-22 07:50:40.790662
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Not implemented
    assert True

# Generated at 2022-06-22 07:50:41.349844
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:50:53.354539
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE._VALID_URL = 'https://hitrecord.org/records/2954362'

# Generated at 2022-06-22 07:50:56.742240
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    IE = HitRecordIE()
    assert IE.IE_NAME == 'hitrecord'
    assert IE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:51:47.532823
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:51:49.026679
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:51:52.276459
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    my_tester = HitRecordIE(url)
    my_tester._real_extract(url)

# Generated at 2022-06-22 07:51:52.761439
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return

# Generated at 2022-06-22 07:51:58.093357
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert HitRecordIE._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-22 07:52:00.656864
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:52:09.599082
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE.__bases__[0] == InfoExtractor
	assert HitRecordIE.NAME == 'HitRecord'
	assert HitRecordIE.MAIN_URL == 'https://hitrecord.org/'
	assert HitRecordIE.IE_NAME == 'hitrecord.org'
	assert HitRecordIE.VALID_URL == HitRecordIE._VALID_URL
	assert HitRecordIE.LANG == [None]
	assert HitRecordIE.IE_DESC == 'HitRecord'
	assert HitRecordIE.QUALITIES == {'hd': 1080}
	assert HitRecordIE.DOMAIN_TO_CHANNEL_ID == {}
	assert HitRecordIE.JWPLAYER_KEY == None
	assert HitRecordIE.BUILTIN_PROFILES == {}
	return HitRecordIE

# Generated at 2022-06-22 07:52:14.982117
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    res = ie.extract(HitRecordIE._TEST['url'])
    assert ie.get_video_url(HitRecordIE._TEST['url']) == res['url']
    assert ie.get_video_info(HitRecordIE._TEST['url']) == res

# Generated at 2022-06-22 07:52:16.220636
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()
    HitRecordIE('HitRecordIE')

# Generated at 2022-06-22 07:52:20.048631
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:54:01.507234
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	pass

# Generated at 2022-06-22 07:54:03.381179
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Constructor test for HitRecordIE
    """
    HitRecordIE()


# Generated at 2022-06-22 07:54:06.332631
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE()
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:54:08.659586
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362")

# Test if function _real_extract() can be called

# Generated at 2022-06-22 07:54:10.315760
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._TEST['url'] == HitRecordIE._VALID_URL

# Generated at 2022-06-22 07:54:20.712641
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:54:22.704839
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert 'HitRecord' in ie.IE_NAME

# Generated at 2022-06-22 07:54:33.564632
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:54:35.318338
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:54:39.172805
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'