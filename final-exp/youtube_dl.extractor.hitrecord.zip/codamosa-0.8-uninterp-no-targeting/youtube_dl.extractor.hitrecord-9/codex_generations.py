

# Generated at 2022-06-22 07:47:33.182881
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE()

    # Test with valid url
    url = 'https://hitrecord.org/records/2954362'
    ie_result = info_extractor.extract(url)
    assert ie_result is not None

    # Test with non-exists url
    url = 'https://hitrecord.org/records/29543620'
    ie_result = info_extractor.extract(url)
    assert ie_result is None


# Generated at 2022-06-22 07:47:41.977385
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video = HitRecordIE("test")._real_extract("test")
    assert(video['id'] == 'test')
    assert(video['url'] == 'test')
    assert(video['title'] == 'test')
    assert(video['description'] == 'test')
    assert(video['duration'] == None)
    assert(video['timestamp'] == None)
    assert(video['uploader'] == 'test')
    assert(video['uploader_id'] == 'test')
    assert(video['view_count'] == None)
    assert(video['like_count'] == None)
    assert(video['comment_count'] == None)
    assert(video['tags'] == None)

# Generated at 2022-06-22 07:47:45.609075
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE()
    assert(hitRecord._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-22 07:47:49.445500
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'
    assert ie.ie_name() == 'HitRecord'
    assert isinstance(ie.md5, str)
    assert isinstance(ie.test, dict)


# Generated at 2022-06-22 07:47:50.678789
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-22 07:47:51.739589
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	a = HitRecordIE()
	assert a

# Generated at 2022-06-22 07:47:53.851514
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HitRecordIE()
# End of Unit test

# Generated at 2022-06-22 07:47:54.507811
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-22 07:47:56.818027
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print("Test for constructor of class HitRecordIE")
    T = HitRecordIE()
    print("Constructor test is passed")


# Generated at 2022-06-22 07:48:00.594977
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Test constructor of HitRecordIE for passing the test
    """
    obj = HitRecordIE()
    assert obj.suitable("https://hitrecord.org/records/2954362")

# Generated at 2022-06-22 07:48:12.125117
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-22 07:48:15.900268
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('Test', 'Test', 'HitRecord')


# Generated at 2022-06-22 07:48:17.872276
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL 
	assert HitRecordIE()._TEST == HitRecordIE._TEST

# Generated at 2022-06-22 07:48:18.521639
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:48:30.332459
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Tests instance creation and attribute initialization
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie.ie_key() == "HitRecord"
    assert ie.ie_key() == HitRecordIE.ie_key()
    assert ie.name == "HitRecord"
    assert ie.name == HitRecordIE.ie_key()
    assert ie.app_version is None
    assert ie.app_version == HitRecordIE.app_version
    assert ie.host == "hitrecord.org"
    assert ie.host == HitRecordIE.host
    assert ie.webpage_url == "https://hitrecord.org/records/2954362"
    assert ie.webpage_url == HitRecordIE.webpage_url
    assert ie.video_id == "2954362"

# Generated at 2022-06-22 07:48:31.077688
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Should succeed
    HitRecordIE()

# Generated at 2022-06-22 07:48:33.360490
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except TypeError as e:
        assert(False)
    else:
        assert(True)



# Generated at 2022-06-22 07:48:43.625987
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.suitable("https://hitrecord.org/records/2954362")
    assert ie.suitable("https://www.hitrecord.org/records/2954362")
    assert not ie.suitable("https://gitrecord.org/records/2954362")
    assert not ie.suitable("https://www.hitrecord.org/record/2954362")
    assert not ie.suitable("https://hitrecord.org/2954362")
    assert not ie.suitable("https://www.hitrecord.org/2954362")

# Generated at 2022-06-22 07:48:54.728183
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/')
    assert ie.get_content_url('https://hitrecord.org/records/2954362') == 'https://hitrecord.org/api/web/records/2954362'
    assert ie.get_id('https://hitrecord.org/records/2954362') == '2954362'
    assert ie.get_content_id('https://hitrecord.org/records/2954362') == '2954362'

# Generated at 2022-06-22 07:48:56.280167
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-22 07:49:14.937050
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('http://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:49:25.660131
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-22 07:49:26.190634
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:49:27.516431
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert "HitRecordIE" in globals()


# Generated at 2022-06-22 07:49:39.522626
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:49:40.149305
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-22 07:49:50.034901
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    # test for _VALID_URL
    match = instance._VALID_URL
    assert match == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'    
    # test for _TEST
    url = 'https://hitrecord.org/records/2954362'
    md5 = 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-22 07:49:52.449011
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE(None)
        raise AssertionError('The constructor of class HitRecordIE should be private!')
    except AttributeError:
        pass # expected exception



# Generated at 2022-06-22 07:49:53.426898
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:49:56.067973
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('https://www.hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:50:17.728056
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord_ie = HitRecordIE(None)

# Generated at 2022-06-22 07:50:19.243335
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(HitRecordIE._VALID_URL)


# Generated at 2022-06-22 07:50:19.855396
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:50:25.172556
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = HitRecordIE._VALID_URL
    assert HitRecordIE._TEST['url'] == url
    assert HitRecordIE._TEST['md5'] == HitRecordIE._TEST['info_dict']['md5']

# Generated at 2022-06-22 07:50:27.718190
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # test that the constructor has no errors
    ie = HitRecordIE()
    ie = HitRecordIE(ie)
    assert ie

# Generated at 2022-06-22 07:50:30.912070
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    assert hitrecord._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-22 07:50:33.727690
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Test constructor of class HitRecordIE"""
    assert HitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:50:37.587483
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.SUFFIX == 'mp4', 'Unexpected value of ie.SUFFIX'
    assert ie.IE_NAME == 'HitRecord'

# Generated at 2022-06-22 07:50:38.913220
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:50:39.959054
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.download()

# Generated at 2022-06-22 07:51:33.051454
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test = HitRecordIE()
    test._downloader.http._sleep_time = 0.1
    url = 'https://hitrecord.org/records/2954362'
    info_dict = test._real_extract(url)
    for key, value in test._TEST['info_dict'].items():
        if info_dict[key] == value:
            print (key, ": SUCCESS")
        else:
            print (key, ": FAILURE")

# Generated at 2022-06-22 07:51:39.008252
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # The constructor of HitRecordIE use re.search and we need to find the id
    # of a video in the url
    url = 'https://hitrecord.org/records/2954362'
    id = HitRecordIE._match_id(url)
    assert id == '2954362'

# Generated at 2022-06-22 07:51:40.448487
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-22 07:51:41.038728
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:51:47.764563
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362', {'extract-title': True})
    print(ie._VALID_URL)
    print(ie._TEST)
    print(ie._match_id(ie._TEST['url']))
    print(ie._real_extract(ie._TEST['url']))
test_HitRecordIE()

# Generated at 2022-06-22 07:51:49.981769
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE == HitRecordIE()

# Generated at 2022-06-22 07:51:50.612143
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:51:52.576342
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        assert HitRecordIE(None).initialized()
    except:
        assert False, "HitRecordIE constructed with wrong parameters"



# Generated at 2022-06-22 07:51:57.896727
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-22 07:52:02.514355
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract("https://hitrecord.org/records/2954362")

# Generated at 2022-06-22 07:52:47.956941
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:52:49.482518
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(HitRecordIE._VALID_URL)



# Generated at 2022-06-22 07:52:50.170402
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:52:51.591218
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('')
    assert ie == HitRecordIE('')

# Generated at 2022-06-22 07:53:00.711120
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:53:10.129706
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ie = HitRecordIE()
	assert (ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')
	assert (ie._TEST['url'] == 'https://hitrecord.org/records/2954362')
	assert (ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71')
	assert (ie._TEST['info_dict']['id'] == '2954362')
	assert (ie._TEST['info_dict']['ext'] == 'mp4')
	assert (ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)')

# Generated at 2022-06-22 07:53:11.780233
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(1)


# Generated at 2022-06-22 07:53:13.171182
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.info(ie._TEST['url'])

# Generated at 2022-06-22 07:53:13.679704
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:53:15.587593
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://www.hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:55:01.273361
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:55:12.556940
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    '''
    Unit test for constructor of class HitRecordIE.
    '''
    instance = HitRecordIE()
    assert instance._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:55:14.273484
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-22 07:55:16.492165
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.get_url() == 'http://www.hitrecord.org/records/2954362'



# Generated at 2022-06-22 07:55:22.313639
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Testing correct URL
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    # Testing incorrect URL
    with pytest.raises(ExtractorError):
        ie = HitRecordIE('https://hitrecord.com/records/2954362')

# Generated at 2022-06-22 07:55:22.898177
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-22 07:55:25.267976
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info = HitRecordIE('https://hitrecord.org/records/2954362')
    assert info == HitRecordIE._TEST


# Generated at 2022-06-22 07:55:26.462434
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE == HitRecordIE()

# Generated at 2022-06-22 07:55:28.261278
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(HitRecordIE.ie_key()) is not None

# Generated at 2022-06-22 07:55:29.685173
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  # url =
  # info_dict =
  # test =
  # assert 1 == 1
  pass