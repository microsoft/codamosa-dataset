

# Generated at 2022-06-22 07:47:32.140781
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert ie.get_url_regex() == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"

# Generated at 2022-06-22 07:47:34.695479
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362') == True


# Generated at 2022-06-22 07:47:35.425676
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE([])

# Generated at 2022-06-22 07:47:39.577052
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:47:41.902967
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_video = HitRecordIE(InfoExtractor())
    assert isinstance(hitrecord_video, HitRecordIE)




# Generated at 2022-06-22 07:47:42.954751
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('HitRecord', 'hitrecord.org')

# Generated at 2022-06-22 07:47:43.667291
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:47:44.583367
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE()

# Generated at 2022-06-22 07:47:45.823258
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie is not None

# Generated at 2022-06-22 07:47:56.039248
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# in the browser this url returns an mp4 video
	url = 'https://hitrecord.org/records/2954362'
	
	ie = HitRecordIE()
	info_dict = ie._real_extract(url)
	assert info_dict['id'] == '2954362'
	assert info_dict['url'] == 'https://hitrecord-files.s3.amazonaws.com/files/video/2016/8/2954362/AVeryDifferentWorldHITRECORDxACLU_mp4_1501150786225.mp4'
	assert info_dict['title'] == 'A Very Different World (HITRECORD x ACLU)'
	assert 'description' in info_dict
	assert info_dict['duration'] == 139.327
	assert info_dict['timestamp'] == 1471557582
	assert info

# Generated at 2022-06-22 07:48:05.821521
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:48:07.358235
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:48:15.026893
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    # unit tests for HitRecordIE.__init__()
    ie = HitRecordIE()

    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-22 07:48:22.424554
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    unit_test_instance = HitRecordIE()
    # Test case for method '_match_id'
    result = unit_test_instance._match_id('https://hitrecord.org/records/2954362')
    assert result == '2954362', "result != '2954362'"
    # Test case for method '_fetch_page'
    assert isinstance(unit_test_instance._fetch_page('https://hitrecord.org/api/web/records/2954362'), dict)
    print('Passed')


# Generated at 2022-06-22 07:48:23.379349
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert(HitRecordIE(None)._VALID_URL)

# Generated at 2022-06-22 07:48:24.517029
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-22 07:48:35.339955
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	hitRecordIE = HitRecordIE()
	assert hitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
	assert hitRecordIE._TEST['url'] == 'https://hitrecord.org/records/2954362'
	assert hitRecordIE._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
	assert hitRecordIE._TEST['info_dict']['id'] == '2954362'
	assert hitRecordIE._TEST['info_dict']['ext'] == 'mp4'
	assert hitRecordIE._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'
	assert hitRecordIE._TEST

# Generated at 2022-06-22 07:48:46.869571
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert isinstance(ie, HitRecordIE)
    assert ie.name() == 'HitRecord.org'
    assert ie.ie_key() == 'HitRecord'
    # Test the 'extract' method (result is the url)
    assert ie.extract('https://hitrecord.org/records/2954362') == 'https://d1xb6v4l02u1vs.cloudfront.net/videos/mp4/451820_2954362-1481981526.mp4'

# Generated at 2022-06-22 07:48:50.695941
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.suitable('https://hitrecord.org/records/2954362')
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:49:02.823422
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """ Basic unit test for HitRecordIE """
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:49:27.057704
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ins = HitRecordIE()
    # A None parameter raises a ValueError
    assert_raises(ValueError, ins.extract, None)
    # An invalid URL raises a RegexNotFoundError
    assert_raises(RegexNotFoundError, ins.extract, 'http://www.google.com')
    # A valid URL doesn't raise any exception
    ins.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:49:31.446561
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from EClass import HitRecordIE
    result = HitRecordIE(None, None)._VALID_URL
    assert result == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:49:32.617712
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-22 07:49:39.024534
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ie = HitRecordIE("https://hitrecord.org/records/2954362")
	print("URL: " + ie.url)
	print("ID: " + ie.video_id)
	assert(ie.url == "https://hitrecord.org/records/2954362")
	assert(ie.video_id == "2954362")

#	Unit test for function _real_extract of class HitRecordIE

# Generated at 2022-06-22 07:49:39.699505
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:49:46.396855
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    # Unit test for class HitRecordIE, the case if the URL is valid.
    assert ie.suitable('https://hitrecord.org/records/2954362') == True

    # Unit test for class HitRecordIE, the case if the URL is invalid but looks like valid.
    assert ie.suitable('') == False

    # Unit test for class HitRecordIE, the case if the URL is invalid and does not look like valid.
    assert ie.suitable('https://facebook.com/records/2954362') == False

# Generated at 2022-06-22 07:49:46.988665
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-22 07:49:48.730061
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_ie=HitRecordIE()
    assert test_ie is not None;

# Generated at 2022-06-22 07:49:51.744001
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:49:53.366984
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-22 07:50:35.950672
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-22 07:50:44.996758
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE()

# Generated at 2022-06-22 07:50:46.859419
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract("https://hitrecord.org/records/2954362")

# Generated at 2022-06-22 07:50:48.901706
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')


# Generated at 2022-06-22 07:50:52.941220
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._real_initialize()
    ie._download_webpage = lambda url: url
    ie._real_extract("http://www.hitrecord.org/records/2954362")

# Generated at 2022-06-22 07:50:56.132339
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    h = HitRecordIE()
    assert h.ie_key() == 'HitRecord'
    assert h.ie_name() == 'HitRecord'
    assert h._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:50:59.998097
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE('https://hitrecord.org/records/2954362')
    assert info_extractor._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert info_extractor._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert info_extractor._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert info_extractor._TEST['info_dict']['id'] == '2954362'

# Generated at 2022-06-22 07:51:01.097898
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-22 07:51:02.711170
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.set_downloader(None)
    assert ie is not None

# Generated at 2022-06-22 07:51:04.377451
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('HitRecordIE', 'hitrecord.org')

# Generated at 2022-06-22 07:52:44.326973
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.ie_key() == "hitrecord"

# Generated at 2022-06-22 07:52:47.261558
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Simple unit test for HitRecordIE
    """
    ie = HitRecordIE()
    assert(ie._VALID_URL)

# Generated at 2022-06-22 07:52:47.959007
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:52:57.574271
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('HitRecord', False)
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:53:02.210258
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HITRecord'
    assert ie.ie_name() == 'HITRecord'
    assert ie.test() == True

# Generated at 2022-06-22 07:53:06.421670
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Create object of class HitRecordIE, pass it url of a video,
    # and extract the video
    ie = HitRecordIE()
    ie.extract(ie._TEST['url'])

# Generated at 2022-06-22 07:53:18.263596
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    IE = HitRecordIE('https://hitrecord.org/records/2954362')
    assert IE.url == 'https://hitrecord.org/records/2954362'
    assert IE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:53:19.374803
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(HitRecordIE._VALID_URL, {})

# Generated at 2022-06-22 07:53:28.178190
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-22 07:53:31.600919
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("http://www.hitrecord.org/records/2954362")
    assert ie is not None

# Generated at 2022-06-22 07:55:21.714258
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-22 07:55:23.037807
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-22 07:55:27.353188
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'
    assert ie.ie_key() in HitRecordIE.ie_key()
    assert ie.suitable('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:55:28.510482
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert(HitRecordIE('www.hitrecord.org'));

# Generated at 2022-06-22 07:55:29.307308
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return test_HitRecordIE

# Generated at 2022-06-22 07:55:32.186610
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == r'^https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)$'

# Generated at 2022-06-22 07:55:32.730272
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:55:33.256043
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:55:33.766709
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:55:40.022087
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Arrange
    ie = HitRecordIE(None)

    # Act
    actual = ie._VALID_URL

    # Assert
    expected = r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert actual == expected
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'