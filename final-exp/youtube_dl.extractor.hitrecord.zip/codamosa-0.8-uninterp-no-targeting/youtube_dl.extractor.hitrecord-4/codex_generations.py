

# Generated at 2022-06-22 07:47:26.386418
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE

# Generated at 2022-06-22 07:47:27.186160
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:47:28.938984
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-22 07:47:35.582278
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # initialize an object of class HitRecordIE
    HitRecord = HitRecordIE()
    # test url
    url = 'https://hitrecord.org/records/2954362'
    # test video_id
    video_id = HitRecord._match_id(url)
    assert video_id == '2954362'
    # test _real_extract
    # test method _real_extract()
    HitRecord._real_extract(url)

# Generated at 2022-06-22 07:47:44.655988
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-22 07:47:45.861939
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  hitRecordIE = HitRecordIE()

# Generated at 2022-06-22 07:47:46.539708
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:47:50.150659
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-22 07:47:50.990731
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:48:02.906050
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-22 07:48:08.708522
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-22 07:48:09.825099
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ex = HitRecordIE()
    assert ex

# Generated at 2022-06-22 07:48:20.566725
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
		url = 'https://hitrecord.org/records/2954362'
		video_id = 2954362
		ext = 'mp4'
		title = 'A Very Different World (HITRECORD x ACLU)'
		description = 'md5:e62defaffab5075a5277736bead95a3d'
		duration = 139.327
		timestamp = 1471557582
		upload_date = '20160818'
		uploader = 'Zuzi.C12'
		uploader_id = '362811'
		view_count = int
		like_count = int
		comment_count = int
		tags = list

		video = HitRecordIE(url)
		assert video.video_id == video_id

# Generated at 2022-06-22 07:48:25.997353
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Unit test for class HitRecordIE
    """
    h = HitRecordIE()
    # get _VALID_URL
    url = h._VALID_URL
    m = url.split('/')
    assert (len(m) > 2)

    # get _TEST
    t = h._TEST
    assert (len(t) > 0)



# Generated at 2022-06-22 07:48:29.227874
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    vid = HitRecordIE()
    assert vid.ie_key() == 'hitrecord'
    assert vid.ie_name() == 'HitRecord'

# Generated at 2022-06-22 07:48:31.491531
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie_obj = HitRecordIE()
    assert ie_obj is not None
    assert 'hitrecord' in ie_obj.IE_NAME

# Generated at 2022-06-22 07:48:34.167636
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == HitRecordIE._VALID_URL
    assert ie._TEST == HitRecordIE._TEST


# Generated at 2022-06-22 07:48:36.790951
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie is not None

# Generated at 2022-06-22 07:48:38.023216
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    inst = HitRecordIE()

# Generated at 2022-06-22 07:48:39.371495
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE is not None

# Generated at 2022-06-22 07:48:58.998142
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info = HitRecordIE().extract('https://hitrecord.org/records/2954362')
    assert info['id'] == '2954362'
    assert info['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert info['description'] == 'A Very Different World'
    assert info['duration'] == 139.327
    assert info['timestamp'] == 1471557582
    assert info['uploader'] == 'Zuzi.C12'
    assert info['uploader_id'] == '362811'
    assert info['like_count'] > 500
    assert info['tags'] == ['world', 'aclu', 'documentary', 'short film']

# Generated at 2022-06-22 07:49:10.894666
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('https://hitrecord.org/') == HitRecordIE('https://hitrecord.org')
    assert HitRecordIE('https://hitrecord.org/records/2954362') == HitRecordIE('https://www.hitrecord.org/records/2954362')
    assert HitRecordIE('https://hitrecord.org/records/2954362') == HitRecordIE('https://hitrecord.org/records/2954362?a=b')
    assert HitRecordIE('https://www.hitrecord.org/records/2954362') == HitRecordIE('https://www.hitrecord.org/records/2954362?a=b')

# Generated at 2022-06-22 07:49:11.679928
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL

# Generated at 2022-06-22 07:49:12.298461
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:49:14.851210
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  assert HitRecordIE()._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"

# Generated at 2022-06-22 07:49:17.693280
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:49:25.072647
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST.get("md5") == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST.get("info_dict").get("title") == 'A Very Different World (HITRECORD x ACLU)'


# Generated at 2022-06-22 07:49:30.567412
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    url = 'https://hitrecord.org/records/2954362'
    result = ie.extract(url)
    #print(result)
    assert('A Very Different World (HITRECORD x ACLU)' == result['title'])
    assert('General' == result['tags'][0])
    assert('id' == result['tags'][1])
    assert('hitrecord' == result['tags'][2])
    assert('media' == result['tags'][3])
    assert('record' == result['tags'][4])
    assert('records' == result['tags'][5])
    assert('social' == result['tags'][6])
    assert('Social Justice' == result['tags'][7])
    assert('2954362' == result['id'])

# Generated at 2022-06-22 07:49:33.037359
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('foo')

# Generated at 2022-06-22 07:49:33.677119
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:49:59.031493
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie_class = HitRecordIE
    assert ie_class is not None

# Generated at 2022-06-22 07:49:59.627020
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE().init()

# Generated at 2022-06-22 07:50:02.137486
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE().extract_info(HitRecordIE._TEST['url'])

# Generated at 2022-06-22 07:50:10.645825
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    p = HitRecordIE()
    instance = p._real_initialize()

    # test for _VALID_URL
    match = p._VALID_URL_RE.match("http://hitrecord.org/records/1")
    assert match
    assert match.group("id") == "1"

    # test for _download_webpage
    # HitRecord.org is down, so we use youtube to test this function
    webpage = p._download_webpage("http://youtube.com", None)
    assert webpage.startswith("<!doctype html><html")

# Generated at 2022-06-22 07:50:14.197045
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Make sure it can construct an HitRecordIE object
    HitRecordIE(None)
    assert HitRecordIE(None) is not None



# Generated at 2022-06-22 07:50:14.676611
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():    
    HitRecordIE()

# Generated at 2022-06-22 07:50:15.294715
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test the existence of the constructor
    HitRecordIE()

# Generated at 2022-06-22 07:50:16.906181
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:50:17.550085
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:50:28.304373
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    infoExtractor = HitRecordIE()
    assert infoExtractor._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert infoExtractor._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert infoExtractor._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-22 07:51:14.373103
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'

# Generated at 2022-06-22 07:51:15.323538
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:51:18.569434
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_url = 'https://hitrecord.org/records/2954362'
    video_id = HitRecordIE._match_id(test_url)
    assert video_id == '2954362'

# Generated at 2022-06-22 07:51:23.810846
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie.url == 'https://hitrecord.org/records/2954362', 'URL of video page is wrong'
    assert ie.video_id == '2954362', 'ID of video is wrong'

# Generated at 2022-06-22 07:51:27.679075
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Test YouTube video info extraction"""
    video_id = '2954362'
    url = 'https://hitrecord.org/records/2954362'
    HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:51:33.120349
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert HitRecordIE().IE_NAME == 'hitrecord:record'
    assert HitRecordIE()._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert HitRecordIE()._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-22 07:51:37.637610
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    ie.set_test(True)
    assert ie.extract(HitRecordIE._TEST['url']) == HitRecordIE._TEST

# Generated at 2022-06-22 07:51:42.647380
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == "hitrecord"
    assert ie.ie_key() == "hitrecord"
    assert ie.IE_URL == "http://www.hitrecord.org/"
    assert ie.IE_DESC == "HitRecord.org is an open collaborative production company founded by actor Joseph Gordon-Levitt."


# Generated at 2022-06-22 07:51:54.482011
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")


# Generated at 2022-06-22 07:51:57.616875
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    assert instance.IE_NAME == 'hitrecord'
    assert instance.IE_DESC == 'HitRecord'
    assert instance.VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert instance.EXTRACTOR == 'HitRecordIE'
    assert instance.EXTRACTOR_KEY == 'hitrecord'


# Generated at 2022-06-22 07:53:39.462728
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    if ie is None:
        raise Exception("HitRecordIE() failed to initialize")

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-22 07:53:41.552179
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    loader = HitRecordIE()
    print(loader.get_info('https://hitrecord.org/records/2954362'))


# Generated at 2022-06-22 07:53:41.947982
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:53:49.403359
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('hitrecord')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)', ie._VALID_URL

# Generated at 2022-06-22 07:53:51.992940
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL
    assert HitRecordIE()._TEST == HitRecordIE._TEST


# Generated at 2022-06-22 07:53:55.920702
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Create a HitRecordIE object
    hitrecord_ie = HitRecordIE()

    # Test a url
    url = "https://hitrecord.org/records/2954362"
    hitrecord_ie.extract(url)

# Generated at 2022-06-22 07:53:56.728905
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HitRecordIE()

# Generated at 2022-06-22 07:54:03.670240
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    test_cases = [["http://hitrecord.org/records/0", "0"],
                  ["https://hitrecord.org/records/0", "0"],
                  ["http://hitrecord.org/records/234234", "234234"]]
    for test_case in test_cases:
        assert ie._match_id(test_case[0]) == test_case[1]

# Generated at 2022-06-22 07:54:04.209510
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-22 07:54:07.877916
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    x = HitRecordIE()
    print (x.title())
    print (x.description())
    print (x.version())