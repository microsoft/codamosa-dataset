

# Generated at 2022-06-22 07:47:28.542738
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:47:30.189917
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None, {'test': 'test_HitRecordIE'})

# Generated at 2022-06-22 07:47:39.255922
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Simple unit test for constructor of class HitRecordIE.
    """
    # HitRecordIE
    ie = HitRecordIE()

    # HitRecordIE._VALID_URL
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

    # HitRecordIE._TEST

# Generated at 2022-06-22 07:47:43.756899
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord:record'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:47:44.580782
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-22 07:47:47.912018
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-22 07:47:48.873332
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-22 07:47:56.242765
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	test_object = HitRecordIE()
	print(dir(test_object))
	if hasattr(test_object, '_real_extract'):
		print('has _real_extract')
	else:
		print('no _real_extract')
	if callable(getattr(test_object, '_real_extract', None)):
		print('_real_extract callable')
	else:
		print('_real_extract is not callable')

# Generated at 2022-06-22 07:47:57.318195
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie is not None

# Generated at 2022-06-22 07:47:58.124762
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:48:08.975617
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-22 07:48:12.014573
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    obj = ie.ie_key()
    if obj == 'hitrecord':
        return True
    else:
        return False


# Generated at 2022-06-22 07:48:18.527914
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-22 07:48:30.332459
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie._VALID_URL == 'https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)')

# Generated at 2022-06-22 07:48:31.876734
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = HitRecordIE()

# Unit test to check if all the functions in class HitRecordIE are working

# Generated at 2022-06-22 07:48:32.856222
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None, None)

# Generated at 2022-06-22 07:48:33.861437
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(InfoExtractor)

# Generated at 2022-06-22 07:48:35.758604
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    #print(ie.VALID_URL)
    #print(ie.TEST)


# Generated at 2022-06-22 07:48:47.210142
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    inst = HitRecordIE()
    assert inst.ie_key() == 'HitRecord'

# Generated at 2022-06-22 07:48:48.324294
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-22 07:49:11.436455
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        import hitrecord as hitrecord
    except ImportError:
        print("HitRecord library is not installed, please install it before you test HitRecord extractor.")
        return
    HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-22 07:49:14.807505
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Unittest for constructor of class HitRecordIE"""
    _HitRecordIE = HitRecordIE()
    if "hitrecord.org" not in _HitRecordIE.url_result():
        raise Exception("HitRecordIE does not contain hitrecord.org")

# Generated at 2022-06-22 07:49:21.164758
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-22 07:49:23.371351
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie.extract() != None

# Generated at 2022-06-22 07:49:26.737479
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-22 07:49:27.994065
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-22 07:49:30.420821
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    _HitRecordIE = HitRecordIE()
    assert _HitRecordIE.IE_DESC == "HitRecord.org"

# Generated at 2022-06-22 07:49:32.285662
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert(ie.test_cases==HitRecordIE._TEST)

# Generated at 2022-06-22 07:49:34.365601
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    h = HitRecordIE()
    assert h.extractor.name == HitRecordIE.ie_key()


# Generated at 2022-06-22 07:49:36.565674
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    print (ie)

# Generated at 2022-06-22 07:50:03.050587
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-22 07:50:10.337864
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:50:11.540422
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:50:14.219187
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    url_check = ie.suitable('https://hitrecord.org/records/2954362')
    assert url_check == True

# Generated at 2022-06-22 07:50:20.746771
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    This function tests the constructor of HitRecordIE class.
    """
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:50:21.740851
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL

# Generated at 2022-06-22 07:50:25.447551
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    tester = HitRecordIE()
    tester._real_initialize()
    assert tester._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:50:27.186177
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.suitable('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:50:33.402974
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie.IE_NAME == 'hitrecord'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-22 07:50:36.907885
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:51:41.256524
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  
  from .common import InfoExtractor
  from ..compat import compat_str
  from ..utils import (
      clean_html,
      float_or_none,
      int_or_none,
      try_get,
  )
  
  # Dummy url for testing
  url = 'https://hitrecord.org/records/2954362'
  # Expected id
  video_id = '2954362'
  
  # Test HitRecord constructor
  TestHitRecord = HitRecordIE(url)

  if not isinstance(TestHitRecord, HitRecordIE):
    print ("Error : Constructor not of type HitRecordIE")
  else:
    print ("Success : Constructor of type HitRecordIE")
  

# Generated at 2022-06-22 07:51:42.196590
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:51:44.083110
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 07:51:45.015668
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:51:56.845151
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Construct an instance of HitRecordIE
    ie = HitRecordIE()

    # Test whether the ie is successfully instantiated
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:51:58.062689
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL is not None

# test for "extract" function of class HitRecordIE

# Generated at 2022-06-22 07:52:00.360860
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:52:01.933843
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:52:09.662606
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Step 1: Create an instance of HitRecordIE
    ie = HitRecordIE()

    # Step 2: Obtain the info from the test cases
    for test_case in ie._TEST.values():
        # Extract URL from the test case
        url = test_case['url']

        # Call the real_extract method to obtain the video information
        video_info = ie._real_extract(url)

        # Print the video information
        print(video_info)



# Generated at 2022-06-22 07:52:11.261531
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("", "")

# Generated at 2022-06-22 07:54:06.905944
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'hitrecord.org'
    assert ie.ie_id() == 'hitrecord'
    assert ie.supported_extractors() is None
    assert ie.supported_domains() == ['hitrecord.org']

# Generated at 2022-06-22 07:54:07.486455
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-22 07:54:08.168295
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:54:15.612300
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert(ie._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)")
    assert(ie._TEST["url"] == "https://hitrecord.org/records/2954362")
    assert(ie._TEST["md5"] == "fe1cdc2023bce0bbb95c39c57426aa71")

# Generated at 2022-06-22 07:54:19.597920
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  url = 'https://hitrecord.org/records/2954362'
  HitRecordIE()._real_initialize()
  HitRecordIE()._real_extract(url)

# Generated at 2022-06-22 07:54:27.522417
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	hitRecordInfoExtractor = HitRecordIE('', {})
	assert hitRecordInfoExtractor._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
	assert hitRecordInfoExtractor._TEST['url'] == 'https://hitrecord.org/records/2954362'
	assert hitRecordInfoExtractor._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
	infoDict = hitRecordInfoExtractor._TEST['info_dict']
	assert infoDict['id'] == '2954362'
	assert infoDict['ext'] == 'mp4'
	assert infoDict['title'] == 'A Very Different World (HITRECORD x ACLU)'
	assert infoD

# Generated at 2022-06-22 07:54:38.809495
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:54:39.541555
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE

# Generated at 2022-06-22 07:54:40.738825
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-22 07:54:44.732896
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from .common import InfoExtractor

    ie = InfoExtractor(HitRecordIE)
    assert ie is not None
