

# Generated at 2022-06-22 07:47:30.881535
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(HitRecordIE._VALID_URL) is not None

# Generated at 2022-06-22 07:47:36.881406
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('hitrecord', 'hitrecord:%s' % HitRecordIE._VALID_URL)
    # could use HitRecordIE.ie_key()
    assert ie.ie_key() == 'HitRecord'
    assert ie.ie_key() != 'hitrecord'
    assert ie._VALID_URL == HitRecordIE._VALID_URL
    assert ie._TEST == HitRecordIE._TEST

# Generated at 2022-06-22 07:47:41.510553
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    _TestHitRecordIE = HitRecordIE()
    assert _TestHitRecordIE._VALID_URL == HitRecordIE._VALID_URL
    assert _TestHitRecordIE._TEST == HitRecordIE._TEST

# Generated at 2022-06-22 07:47:43.003017
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 07:47:43.710827
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE()

# Generated at 2022-06-22 07:47:44.993741
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL

# Generated at 2022-06-22 07:47:46.221934
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None, None)

# Generated at 2022-06-22 07:47:47.709239
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie == "HitRecordIE"

# Generated at 2022-06-22 07:47:49.097519
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:47:50.600264
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert type(ie) == HitRecordIE

# Generated at 2022-06-22 07:47:56.190862
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-22 07:48:03.615892
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL
    assert HitRecordIE()._downloader == HitRecordIE._downloader
    assert HitRecordIE()._TEST == HitRecordIE._TEST
    assert HitRecordIE()._real_extract == HitRecordIE._real_extract
    assert HitRecordIE()._real_initialize == HitRecordIE._real_initialize
    assert HitRecordIE()._match_id == HitRecordIE._match_id

# Generated at 2022-06-22 07:48:05.406716
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Unit tests for class HitRecordIE.
    """
    from .. import YoutubeIE

# Generated at 2022-06-22 07:48:06.538087
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert("HitRecordIE" in globals())

# Generated at 2022-06-22 07:48:09.086226
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ins = HitRecordIE()
    assert ins._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:48:11.655874
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    HitRecordIE()._real_extract(url)

# Generated at 2022-06-22 07:48:12.852300
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-22 07:48:15.606602
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:48:26.218519
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.IE_NAME == 'hitrecord:record'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:48:28.030911
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:48:39.370573
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('https://hitrecord.org/records/2954362', 'test_HitRecordIE.py')

# Generated at 2022-06-22 07:48:50.291449
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:48:52.099966
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    if ie:
        print('HitRecordIE successfully imported!')



# Generated at 2022-06-22 07:49:04.405390
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:49:05.118034
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:49:15.826459
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'
    assert ie.ie_name() == 'HitRecord'

# Generated at 2022-06-22 07:49:17.126209
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None, None)

# Generated at 2022-06-22 07:49:17.745022
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:49:19.471831
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(InfoExtractor(), 'https://hitrecord.org/records/3869974')

# Generated at 2022-06-22 07:49:23.718949
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"
    assert ie._TEST['url'] == "https://hitrecord.org/records/2954362"

# Generated at 2022-06-22 07:49:46.147263
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"


# Generated at 2022-06-22 07:49:48.355457
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    data_test_HitRecordIE = HitRecordIE()
    assert(data_test_HitRecordIE.class_name == 'HitRecordIE')

# Generated at 2022-06-22 07:49:54.910612
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    x = HitRecordIE()
    assert x._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'



# Generated at 2022-06-22 07:50:04.071251
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.SUFFIX == 'mp4'

    # Testing InfoExtractor class
    assert ie.__name__ == 'hitrecord'
    assert ie.__class__.__name__ == 'HitRecordIE'
    test_url = 'https://hitrecord.org/records/2954362'
    match = ie._VALID_URL.match(test_url)
    assert match is not None
    assert ie._match_id(test_url) == '2954362'
    assert ie._real_extract(test_url)['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-22 07:50:09.565268
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Website is currently returning 404 on all videos.
    # test_HitRecordIE_constructor = HitRecordIE('https://hitrecord.org/records/2954362')
    # assert test_HitRecordIE_constructor.__class__ == HitRecordIE
    pass

# Generated at 2022-06-22 07:50:11.592387
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE is not None

# Generated at 2022-06-22 07:50:12.977951
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:50:23.327276
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print("Testing HitRecordIE.__init__")
    print("Total tests: 1")
    hr_ie = HitRecordIE("http://www.hitrecord.org/records/2954362")
    # Test for equality of the two strings
    assert(hr_ie._VALID_URL == "https?:\\/\\/(?:www\\.)?"
                                "hitrecord\\.org\\/records\\/(?P<id>\\d+)")
    # Test for equality of the id
    assert(hr_ie._match_id("http://www.hitrecord.org/records/2954362") ==
           "2954362")
    print("HitRecordIE.__init__ test passed")


# Generated at 2022-06-22 07:50:25.351467
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    IE = HitRecordIE('test')
    assert isinstance(IE, InfoExtractor)


# Generated at 2022-06-22 07:50:26.717103
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE()
    assert 'HitRecord' in hitRecord.IE_NAME

# Generated at 2022-06-22 07:51:14.643753
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('HitRecord', 'https://hitrecord.org/records/2954362')
    assert ie.title == 'HitRecord'
    assert ie.url == 'https://hitrecord.org/records/2954362'
    assert ie.media_id == '2954362'

# Generated at 2022-06-22 07:51:15.973317
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("http://hitrecord.org/records/2946678")

# Generated at 2022-06-22 07:51:19.925970
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # To test hitrecord plugin, you should use command like this:
    # youtube-dl -s https://hitrecord.org/records/2954362
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:51:20.834430
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()



# Generated at 2022-06-22 07:51:26.298613
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == HitRecordIE._TEST['url']
    IE = HitRecordIE()
    assert IE._VALID_URL == HitRecordIE._TEST['url']
    assert IE._downloader.troubleshoot.options['noprogress'] == True


# Generated at 2022-06-22 07:51:27.283433
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie =HitRecordIE()
    ie.download()

# Generated at 2022-06-22 07:51:27.880048
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:51:28.530031
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:51:31.383972
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://www.hitrecord.org/records/2954362')
    assert ie._match_id('https://www.hitrecord.org/records/2954362') == '2954362'

# Generated at 2022-06-22 07:51:33.717268
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print('Running Test for HitRecordIE constructor\n')
    h = HitRecordIE('hitrecord', 'HitRecord')
    print(h)

# Generated at 2022-06-22 07:53:05.099794
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    if __name__ == '__main__':
        assert HitRecordIE._TEST['url'] == HitRecordIE._VALID_URL
        HitRecordIE._TEST

# Generated at 2022-06-22 07:53:10.185930
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    # Initialize object
    ie = HitRecordIE()

    # Define string
    string = '<p><strong>Directed By:</strong> <a href="javascript:;" onclick="javascript:GotoUserProfile(114964);">Aaron.C15</a></p>'

    # Convert string to dict
    dict = ie.str2dict(string)

    # Test conversion
    assert dict == {'Directed By': ['Aaron.C15']}, 'Conversion is incorrect!'



# Generated at 2022-06-22 07:53:15.629700
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
# HitRecordIE is constructed
    hitRecordIE = HitRecordIE()
# HitRecordIE is valid
    assert hitRecordIE.suitable('https://hitrecord.org/records/2954362')
# HitRecordIE is not valid
    assert not hitRecordIE.suitable('https://www.google.com/')

# Test for the method _real_extract of class HitRecordIE

# Generated at 2022-06-22 07:53:16.636130
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(False)

# Generated at 2022-06-22 07:53:17.845778
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE({})
        assert True
    except:
        assert False

# Generated at 2022-06-22 07:53:18.343085
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-22 07:53:19.779256
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    inst = HitRecordIE()
    inst._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:53:24.882458
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:53:25.426259
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:53:26.200744
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-22 07:57:07.434807
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE is HitRecordIE


# Generated at 2022-06-22 07:57:09.021678
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:57:13.130755
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    versions = [{'url' : 'https://hitrecord.org/records/2954362', 'id': '2954362'}]

    for v in versions:
        ie = HitRecordIE().working_video(v['url'])
        assert ie.SUBTITLE == { v['id']: [{'ext': 'srt'}]}

# Generated at 2022-06-22 07:57:20.333742
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    import youtube_dl.YoutubeDL
    ydl = youtube_dl.YoutubeDL({})
    obj = ydl.extract_info('https://hitrecord.org/records/2954362', download=False)
    assert obj['id'] == '2954362'
    assert obj['url'] == 'https://cdn.hitrecord.org/uploads/production/record/data/808911/mp4_h264_aac_hd.mp4'
    assert obj['uploader'] == 'Zuzi.C12'
    assert obj['duration'] == 139.327
    assert obj['timestamp'] == 1471557582

# Generated at 2022-06-22 07:57:22.896049
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()