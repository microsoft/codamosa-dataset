

# Generated at 2022-06-22 07:47:28.990707
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert isinstance(HitRecordIE(), InfoExtractor)

# Generated at 2022-06-22 07:47:31.132187
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == "hitrecord"


# Generated at 2022-06-22 07:47:35.700231
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-22 07:47:39.004882
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	hitRecordObj = HitRecordIE()
	assert isinstance(hitRecordObj, InfoExtractor)

# Generated at 2022-06-22 07:47:49.990119
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    h = HitRecordIE()
    # Unit test:
    # h.search_videos_by_keyword("United States", 10)
    # h.search_videos_by_keyword("浙江", 10)
    # h.search_videos_by_keyword("서울", 10)
    # h.search_videos_by_keyword("китай", 10)
    # h.search_videos_by_keyword("cina", 10)
    # h.search_videos_by_keyword("nhật bản", 10)
    # h.search_videos_by_keyword("日本", 10)
    # h.search_videos_by_keyword("한국", 10)
    # h.search_videos_

# Generated at 2022-06-22 07:47:50.450996
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:47:58.947859
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test = HitRecordIE('https://hitrecord.org/records/2954362')
    assert test.VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert test.IE == 'HitRecord'
    assert test.NAME == 'hitrecord'

# Generated at 2022-06-22 07:48:05.954068
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-22 07:48:07.093729
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:48:08.176461
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(InfoExtractor())

# Generated at 2022-06-22 07:48:20.760087
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE().extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:48:23.964341
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # It is impossible to unit test 'real_extract' because of using of external
    # services (scraping YouTube url and downloading JSON request to the website
    # https://hitrecord.org)

# Generated at 2022-06-22 07:48:27.693274
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TEST == ie.TEST
    assert 'HitRecord' in repr(ie)

# Generated at 2022-06-22 07:48:29.216714
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ighit=HitRecordIE()

# Generated at 2022-06-22 07:48:41.403111
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(InfoExtractor())
    # Matching a valid URL
    assert ie._match_id('https://hitrecord.org/records/2954362') == '2954362'
    # Matching an invalid URL
    assert ie._match_id('https://hitrecord.org/records/k') is None
    # Trying to get the video url
    video_id = '2954362'

# Generated at 2022-06-22 07:48:43.415485
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, HitRecordIE)


# Generated at 2022-06-22 07:48:46.440741
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie



# Generated at 2022-06-22 07:48:50.662008
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE._VALID_URL.startswith("https?://(?:www\\.)?hitrecord\\.org/records/")
	assert HitRecordIE._VALID_URL.endswith("")

# Generated at 2022-06-22 07:48:53.897335
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert (HitRecordIE()._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-22 07:48:59.907441
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.name == 'HitRecord'
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.ie_key() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362', ie.name) == 'https://hitrecord.org/records/2954362'

# Generated at 2022-06-22 07:49:21.163945
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    infoExtractor = HitRecordIE()
    print(infoExtractor)

# Generated at 2022-06-22 07:49:21.729527
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Unit test for constructor of class HitRecordIE
    """
    HitRecordIE()

# Generated at 2022-06-22 07:49:22.756799
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-22 07:49:23.713093
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	test_HitRecordIE = HitRecordIE()
	test_HitRecordIE.report_disclaimer()

# Generated at 2022-06-22 07:49:25.625431
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:49:27.393752
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Testcase for HitRecordIE."""

    # test correct instantiation of HitRecordIE
    assert HitRecordIE(HitRecordIE._VALID_URL) is not None

# Generated at 2022-06-22 07:49:28.590010
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:49:32.094569
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    h = HitRecordIE()
    assert h._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert h._TEST

# Generated at 2022-06-22 07:49:34.571044
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except ImportError:
        pass

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-22 07:49:35.570669
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:50:23.717571
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hri = HitRecordIE()

# Generated at 2022-06-22 07:50:25.352077
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert hasattr(ie, '_VALID_URL')

# Generated at 2022-06-22 07:50:27.517011
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test = HitRecordIE()
    test._match_id("https://hitrecord.org/records/2954362")


# Generated at 2022-06-22 07:50:30.022390
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()



# Generated at 2022-06-22 07:50:30.494576
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("")

# Generated at 2022-06-22 07:50:32.576104
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'http://hitrecord.org/records/2954362'
    hitrecordie = HitRecordIE()
    hitrecordie._match_id(url)
    hitrecordie._real_extract(url)

# Generated at 2022-06-22 07:50:35.268834
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://www.hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:50:36.775874
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:50:38.749901
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE._TEST

# Generated at 2022-06-22 07:50:40.138621
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    global HitRecordIE; HitRecordIE('test',True)
    assert 1

# Generated at 2022-06-22 07:52:22.665779
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:52:24.982060
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    constructor_test(HitRecordIE, {'url': 'https://hitrecord.org/records/2954362'})

# Generated at 2022-06-22 07:52:25.987889
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-22 07:52:29.987783
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test construction without a video_id
    HitRecordIE(None, 'https://hitrecord.org/records/2954362')
    HitRecordIE(None, 'https://hitrecord.org/records/2954362', '2954362')

    # Test construction with bad data
    with pytest.raises(Exception):
        HitRecordIE(None, 'https://hitrecord.org/records/2954362', '')
        HitRecordIE(None, 'https://hitrecord.org/records/2954362', '     ')


# Generated at 2022-06-22 07:52:31.213156
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE()
    print(hitRecord)

# Generated at 2022-06-22 07:52:32.315707
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:52:36.942362
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    if ie._VALID_URL:
        url = ie._TEST['url']
        m = ie._VALID_URL_RE.match(url)
        assert m, 'fails to match URL'
        video_id = m.group('id')

# Generated at 2022-06-22 07:52:49.068946
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-22 07:52:50.218096
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(HitRecordIE._TEST)

# Generated at 2022-06-22 07:52:51.331637
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE({})
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'hitrecord'

# Generated at 2022-06-22 07:54:50.839896
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test the valid url
    HitRecordIE()._extract_info(HitRecordIE._TEST)

    # Test the url with a non-existing video
    HitRecordIE()._extract_info({
        'url': 'https://hitrecord.org/records/123456'
    })

    # Test the url  with an invalid video id
    HitRecordIE()._extract_info({
        'url': 'https://hitrecord.org/records/abcde'
    })

# Generated at 2022-06-22 07:54:51.406235
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE()

# Generated at 2022-06-22 07:54:52.803631
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-22 07:55:02.853704
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print("***** TESTS FOR HITRECORD INFO EXTRACTOR *****")
    info_extractor = HitRecordIE()
    test_url = "https://hitrecord.org/records/2954362"
    result = info_extractor.extract(test_url)
    print("Title: " + result['title'])
    print("Video URL: " + result['url'])
    print("Video ID: " + result['id'])
    print("Duration: " + str(result['duration']))
    print("Timestamp: " + str(result['timestamp']))
    print("Uploader: " + result['uploader'])
    print("Uploader ID: " + result['uploader_id'])
    print("View count: " + str(result['view_count']))

# Generated at 2022-06-22 07:55:06.420666
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Constructor for testing
    ie = HitRecordIE()

    assert ie.SUFFIX == '.org'

# test_HitRecordIE()

# Generated at 2022-06-22 07:55:10.755109
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    global globals
    hitrecord = HitRecordIE
    #Unit test for method HitRecordIE._real_extract()
    hitrecord._real_extract(hitrecord, 'https://hitrecord.org/records/2954362')

# Generated at 2022-06-22 07:55:12.714876
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    v = HitRecordIE("https://hitrecord.org/records/2954362")
    assert v is not None

# Generated at 2022-06-22 07:55:13.313120
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-22 07:55:18.442913
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')

    assert ie.video_id == '2954362'
    assert ie.title == 'A Very Different World (HITRECORD x ACLU)'
    assert ie.description != None
    assert ie.tags != None

# Generated at 2022-06-22 07:55:23.619288
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE._download_json = lambda x, y: {'title': 'test title', 'tags': [{'text': 'test tag'}]}
    HitRecordIE._real_extract("https://hitrecord.org/records/2954362")