

# Generated at 2022-06-12 17:35:26.788323
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    extractor = HitRecordIE()
    assert extractor._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:35:27.676968
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	obj = HitRecordIE()
	assert obj is not None

# Generated at 2022-06-12 17:35:28.128500
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:35:30.360651
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Test class constructor
    """
    HitRecordIE()

# Generated at 2022-06-12 17:35:33.380976
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_video = HitRecordIE()
    assert hitrecord_video._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:35:34.130238
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-12 17:35:35.250348
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    _constructor = HitRecordIE()

# Generated at 2022-06-12 17:35:44.819278
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE({})
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:35:45.978132
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# Constructs the HitRecordIE object
	ie = HitRecordIE()

# Generated at 2022-06-12 17:35:56.594758
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	unit_test_case_instance = HitRecordIE()
	video_id = unit_test_case_instance._match_id(
		'https://hitrecord.org/records/2954362')
	video_info = unit_test_case_instance._download_json(
		'https://hitrecord.org/api/web/records/%s' % video_id, video_id)
	title = video_info['title']
	video_url = video_info['source_url']['mp4_url']
	tags = unit_test_case_instance._download_json(
		'https://hitrecord.org/api/web/records/%s' % video_id, 'tags')
	description = clean_html(video_info.get('body'))
	duration = float_or_none

# Generated at 2022-06-12 17:36:06.020793
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:36:09.206531
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Should call instance of class InfoExtractor"""
    assert HitRecordIE()

# Generated at 2022-06-12 17:36:11.847253
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert 'HitRecord' in ie.IE_NAME
    assert ie.IE_NAME == ie.ie_key()

# Generated at 2022-06-12 17:36:13.987379
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:36:17.851755
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE()
    test = hitRecord._TEST
    url = test['url']
    url_test = hitRecord._VALID_URL
    id = hitRecord._match_id(url)
    assert url == url_test % {'id': id}

# Generated at 2022-06-12 17:36:18.536040
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:36:19.425538
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:36:20.369236
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()


# Generated at 2022-06-12 17:36:24.504548
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE('test', 'http://www.hitrecord.org/records/2954362')
    assert hitrecord.name == 'test'
    assert hitrecord.url == 'http://www.hitrecord.org/records/2954362'
    assert 'hitrecord.org' in hitrecord._VALID_URL

# Generated at 2022-06-12 17:36:32.993620
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# Arrange
	# HitRecordIE object
	hitRecordIE_obj=HitRecordIE()

	# Act
	#  check if the object is instance of InfoExtractor
	try:
		assert isinstance(hitRecordIE_obj, InfoExtractor)
	except Exception as err:
		assert False, "The object is not an instance of InfoExtractor"

	#  check if the object is instance of HitRecordIE
	if not isinstance(hitRecordIE_obj, HitRecordIE):
		assert False, "The object is not an instance of HitRecordIE"

	# Assert
	# Object is instance of HitRecordIE
	assert True

# Generated at 2022-06-12 17:36:52.998759
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract("https://hitrecord.org/records/2954362")

# Generated at 2022-06-12 17:36:55.330667
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract(HitRecordIE._TEST['url'])

# Generated at 2022-06-12 17:37:04.847990
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(InfoExtractor).suitable('https://hitrecord.org/records/2954362') == True
    assert HitRecordIE(InfoExtractor).suitable('http://hitrecord.org/records/2954362') == True
    assert HitRecordIE(InfoExtractor).suitable('https://www.hitrecord.org/records/2954362') == True
    assert HitRecordIE(InfoExtractor).suitable('http://www.hitrecord.org/records/2954362') == True
    assert HitRecordIE(InfoExtractor).suitable('https://hitrecord.org/records/2954362/foo') == False
    assert HitRecordIE(InfoExtractor).suitable('http://hitrecord.org/records/2954362/foo') == False
    assert HitRecordIE(InfoExtractor).su

# Generated at 2022-06-12 17:37:08.982602
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    e = HitRecordIE('https://hitrecord.org/records/2954362')
    assert e.url_result == 'https://hitrecord.org/records/2954362'
    assert e.ID == '2954362'
    assert e.VIDEO_ID == '2954362'
    assert e.IE_NAME == 'hitrecord'
# End of the Unit test for constructor of class HitRecordIE

# Generated at 2022-06-12 17:37:09.438710
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:37:09.857405
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:37:16.698405
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_ie = HitRecordIE()
    assert str(hitrecord_ie.IE_NAME) == "hitrecord.org"
    assert hitrecord_ie.IE_DESC == "Video hosting website for people to work on projects together, share their work, and get discovered."
    assert hitrecord_ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:37:18.869345
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    h = HitRecordIE()
    return h


# Generated at 2022-06-12 17:37:20.732028
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.ie_key() == 'hitrecord'

# Generated at 2022-06-12 17:37:21.688433
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("", "")

# Generated at 2022-06-12 17:37:57.860734
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:38:02.957242
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # HitRecordIE.__init__ should create an instance of class HitRecordIE
    ie = HitRecordIE()
    # HitRecordIE.url should return the URL of the extracted video
    url = ie.url
    # HitRecordIE.video_id should return the id of the extracted video
    video_id = ie.video_id
    # HitRecordIE.video_info should return the information of the extracted video
    info = ie.video_info
    # HitRecordIE.video_url should return the URL of the extracted video
    video_url = ie.video_url

# Generated at 2022-06-12 17:38:03.540771
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-12 17:38:07.094262
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'
    assert ie.ie_id() == 'hitrecord.org'
    assert ie._VALID_URL == ie.valid_url()
    assert ie._TEST == ie.test()

# Generated at 2022-06-12 17:38:08.599941
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  HitRecordIE()

# Generated at 2022-06-12 17:38:09.230409
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE(): pass

# Generated at 2022-06-12 17:38:09.832535
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:38:11.796477
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert type(ie) == HitRecordIE

# Generated at 2022-06-12 17:38:16.805825
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'
    assert ie.suitable(ie.create_ie_urls('HitRecord', 'hitrecord.org/records/2954362')[0])
    assert ie.ie_key() in ie.known_extractors

# Generated at 2022-06-12 17:38:22.940273
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()._real_extract(url='https://hitrecord.org/records/2959982')
        HitRecordIE()._real_extract(url='https://hitrecord.org/records/2954362')
        HitRecordIE()._real_extract(url='https://hitrecord.org/records/2954361')
        HitRecordIE()._real_extract(url='https://hitrecord.org/records/2954363')
    except Exception as e:
        assert False, "HitRecordIE test failed with exception : %s" % type(e).__name__

# Generated at 2022-06-12 17:39:17.136774
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'HitRecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-12 17:39:23.503175
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE().suitable('https://hitrecord.org/records/2954362')
    assert HitRecordIE().suitable('http://hitrecord.org/records/2954362')
    assert not HitRecordIE().suitable('https://www.hitrecord.org/records/2954362')
    assert not HitRecordIE().suitable('https://hitrecord.org/records/29543628')

# Generated at 2022-06-12 17:39:25.581825
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ied = HitRecordIE()
    assert ied.short_name == "hitrecord"
    assert ied.SUFFIX == ".org"

# Generated at 2022-06-12 17:39:27.822581
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE();
    assert ie == HitRecordIE();

# Generated at 2022-06-12 17:39:28.324041
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:39:29.950969
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(HitRecordIE.create_ie(), 'https://hitrecord.org/records/2954362')
    

# Generated at 2022-06-12 17:39:37.827846
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_dict = {}
    # Testing creating a HitRecordIE object
    try:
        test_dict['hitRecord'] = HitRecordIE()
    except:
        print('FAIL creating HitRecordIE object')
        return False
    print('PASS creating HitRecordIE object')
    # Testing if the HitRecordIE object is of the correct type
    try:
        from .common import InfoExtractor
        if not(isinstance(test_dict['hitRecord'], InfoExtractor)):
            print('FAIL HitRecordIE is not of type InfoExtractor')
            return False
    except:
        print('FAIL could not determine type of HitRecordIE object')
        return False
    print('PASS HitRecordIE type is correct')
    return True

# Generated at 2022-06-12 17:39:38.586315
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    a = HitRecordIE()

# Generated at 2022-06-12 17:39:39.941232
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:39:41.181319
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('test', {}, {}, {}, 'http://hitrecord.org', '')

# Generated at 2022-06-12 17:41:30.288055
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie_object = HitRecordIE()
    assert ie_object != None


# Generated at 2022-06-12 17:41:30.826526
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:41:37.133752
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# Create instance of HitRecordIE and hit the url
	# HitRecordIE returns a dict with keys id, url, title, description etc.
	dict_hitrecord = HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')
	
	# Check if the value of the key 'id' is 2954362 as expected
	# Look up functions to test a value
	assert dict_hitrecord['id'] == '2954362'
	# Check the value using dot notation if possible
	assert dict_hitrecord.id == '2954362'
	
	# Check if the value of the key 'url' is https://hitrecord.org/records/2954362 as expected
	assert dict_hitrecord['url'] == 'https://hitrecord.org/records/2954362'
	assert dict_hit

# Generated at 2022-06-12 17:41:43.222608
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # In the current implementation, test only URL formats is enough to
    # verify whether the constructor worked correctly or not.
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert HitRecordIE._TEST['url'] == 'https://hitrecord.org/records/2954362'
    # Now, let's check the URL format by ourselves.
    assert True if re.match(HitRecordIE._VALID_URL, 'https://hitrecord.org/records/2954362') else False
    assert False if re.match(HitRecordIE._VALID_URL, 'https://hitrecord.org/records/1234567890ABCDEFG') else True



# Generated at 2022-06-12 17:41:44.803232
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Constructor test
    """
    HitRecordIE()

# Generated at 2022-06-12 17:41:47.817480
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_obj = HitRecordIE()
    assert test_obj._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-12 17:41:55.308092
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:41:56.499553
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	if __name__ == "__main__":
		test_HitRecordIE()

# Generated at 2022-06-12 17:41:57.222703
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-12 17:42:05.083739
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'