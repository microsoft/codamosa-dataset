

# Generated at 2022-06-12 17:35:25.748310
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    url = "https://hitrecord.org/records/2954362"
    pattern = iie.HitRecordIE._VALID_URL
    match = iie.HitRecordIE._match_id(url)
    
    assert re.match(pattern, url)
    assert match == "2954362"

# Generated at 2022-06-12 17:35:27.746729
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:35:31.070393
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    #self.assertTrue(ie is not None)
    #self.assertTrue(isinstance(ie, HitRecordIE))




# Generated at 2022-06-12 17:35:32.013355
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-12 17:35:34.991727
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
        print('Test constructor of HitRecordIE class')
        url = 'https://hitrecord.org/records/2954362'
        obj = HitRecordIE()
        obj.prepare_url(url)
        print(obj.match_id)

# Generated at 2022-06-12 17:35:35.876220
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE



# Generated at 2022-06-12 17:35:36.467356
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:35:37.900250
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("")


# Generated at 2022-06-12 17:35:39.825512
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # Test for matching input url
    assert ie.suitable('https://hitrecord.org/records/2954362') is True

# Generated at 2022-06-12 17:35:41.425975
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:35:51.276942
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    infoExtractor = HitRecordIE("http://hitrecord.org/records/2954362")
    assert infoExtractor._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert infoExtractor.IE_NAME == 'hitrecord:record'


# Generated at 2022-06-12 17:35:53.788470
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'
    assert ie.suitable('https://hitrecord.org/records/2954362') == True

# Generated at 2022-06-12 17:35:57.938870
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie.VALID_URL == HitRecordIE._VALID_URL
    assert ie._TEST == HitRecordIE._TEST

# Generated at 2022-06-12 17:35:58.859689
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Create a HitRecordIE instance
    HitRecordIE()

# Generated at 2022-06-12 17:36:02.303651
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord:record'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie.IE_DESC == 'HITRECORD'

# Generated at 2022-06-12 17:36:05.267943
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    class_ = HitRecordIE
    inst = class_("http://hitrecord.org/records/2954362")
    assert isinstance(inst, class_) != None
    assert inst.suitable("http://hitrecord.org/records/2954362") != None



# Generated at 2022-06-12 17:36:05.804659
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:36:12.569929
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video_id = '2954362'
    url = 'https://hitrecord.org/records/2954362'
    assert HitRecordIE(hitrecord_id=video_id)._VALID_URL == url
    assert HitRecordIE(url)._match_id(url) == video_id

# Generated at 2022-06-12 17:36:13.868593
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:36:16.504583
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """ Test constructor of class HitRecordIE """
    Test_IE = HitRecordIE('test_HitRecordIE', 'test_HitRecordIE')


# Generated at 2022-06-12 17:36:26.864152
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.download('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:36:27.428859
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:36:31.128381
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_dict = HitRecordIE._TEST
    url = info_dict['url']
    hit_record = HitRecordIE(HitRecordIE.ie_key())
    info = hit_record._real_extract(url)
    assert info == info_dict

# Generated at 2022-06-12 17:36:31.746272
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:36:35.827491
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    title = ie._TEST['info_dict']['title']
    video_url = ie._TEST['info_dict']['url']
    assert ie._title == title
    assert ie._video_url == video_url


# Generated at 2022-06-12 17:36:37.175978
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-12 17:36:47.433304
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_obj = HitRecordIE.unit_test('https://hitrecord.org/records/2954362')
    assert test_obj._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert test_obj._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert test_obj._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert test_obj._TEST['info_dict']['id'] == '2954362'
    assert test_obj._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-12 17:36:51.550481
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-12 17:36:52.170998
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:37:02.480139
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_info_extractor = HitRecordIE()
    assert test_info_extractor._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:37:22.681589
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-12 17:37:24.305225
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE().test_video('http://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:37:26.138485
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ie = HitRecordIE()
	assert ie is not None
	assert ie._VALID_URL is not None
	assert ie._TEST is not None

# Generated at 2022-06-12 17:37:33.495270
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-12 17:37:37.191957
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# prepare
	url_test = 'https://hitrecord.org/records/2954362'
	url = url_test
	# test
	test = HitRecordIE()
	test._real_extract(url)

# Generated at 2022-06-12 17:37:42.583980
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    il = HitRecordIE()
    assert il._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert il._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert il._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-12 17:37:44.720016
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-12 17:37:45.871611
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()



# Generated at 2022-06-12 17:37:46.796454
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HitRecordIE()

# Generated at 2022-06-12 17:37:48.168441
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE is not None

# Generated at 2022-06-12 17:38:32.328142
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_video = HitRecordIE('HitRecordIE', 'HitRecordIE')
    assert test_video._TEST['url'] == 'https://hitrecord.org/records/2954362'

# Generated at 2022-06-12 17:38:34.056934
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # note: HitRecordIE() constructor can take several inputs
    # first create an instance of InfoExtractor class
    ie = InfoExtractor()

    assert ie is not None

# Generated at 2022-06-12 17:38:35.310748
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    globals()['HitRecordIE']()

# Compilation of all unit tests in this file

# Generated at 2022-06-12 17:38:36.578475
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie


# Generated at 2022-06-12 17:38:38.100314
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert isinstance(ie, HitRecordIE)

# Generated at 2022-06-12 17:38:39.337886
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	url = 'https://hitrecord.org/records/2954362'
	video = HitRecordIE()
	assert url == video._VALID_URL

# Generated at 2022-06-12 17:38:40.342109
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE(HitRecordIE._VALID_URL)._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-12 17:38:45.490582
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:38:53.363681
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert HitRecordIE()._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert HitRecordIE()._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert HitRecordIE()._TEST['info_dict']['id'] == '2954362'
    assert HitRecordIE()._TEST['info_dict']['ext'] == 'mp4'
    assert HitRecordIE()._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-12 17:39:03.087289
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    classname = ie.__class__.__name__
    assert classname == 'HitRecordIE', \
        'Expected HitRecordIE to be a class, but got {}'.format(classname)
    assert ie._VALID_URL == HitRecordIE._VALID_URL, \
        'Expected HitRecordIE.VALID_URL to be {} but got {}'.format(
            HitRecordIE._VALID_URL, ie._VALID_URL)


# Generated at 2022-06-12 17:40:40.658574
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(HitRecordIE._VALID_URL)

# Generated at 2022-06-12 17:40:42.557320
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == HitRecordIE._VALID_URL
    assert ie.__name__ == 'HitRecordIE'

# Generated at 2022-06-12 17:40:43.926692
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    IE = HitRecordIE(None)
    assert IE.name == 'hitrecord'
    assert IE._VALID_URL == HitRecordIE._VALID_URL

# Unit tests for class HitRecordIE

# Generated at 2022-06-12 17:40:53.903324
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:41:00.804721
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('http://hitrecord.org/records/2954362')
    assert ie.url == 'https://hitrecord.org/records/2954362'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:41:08.973757
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:41:10.322880
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.match('https://hitrecord.org/records/2954362')
    assert ie.match('https://www.hitrecord.org/records/2954362')
    assert not ie.match('https://hitrecord.org/')

# Generated at 2022-06-12 17:41:11.925016
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    q1 = ie.suitable('https://hitrecord.org/records/2954362')
    assert q1 is True

# Generated at 2022-06-12 17:41:16.699143
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:41:26.621316
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Test HitRecordIE constructor."""
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_slug() == 'hitrecord'
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org')
    assert not ie.suitable('https://hitrecord.com/records/2954362')
    assert not ie.suitable('https://hitrecord.org/videos/2954362')