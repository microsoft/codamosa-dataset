

# Generated at 2022-06-12 17:35:24.787776
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie1 = HitRecordIE()
    ie2 = HitRecordIE()
    assert ie1 == ie2

# Generated at 2022-06-12 17:35:27.305284
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract("https://www.hitrecord.org/records/2954362")

# Generated at 2022-06-12 17:35:30.222067
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'



# Generated at 2022-06-12 17:35:31.460891
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    assert instance

# Generated at 2022-06-12 17:35:35.400986
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Unit test is required since hitrecord might change records url at anytime
    url = 'https://hitrecord.org/records/id'
    ie = HitRecordIE(url)
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:35:43.322670
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    class_name = "HitRecordIE"

    # test 1: when type is None
    ie = HitRecordIE(None)
    result = ie._type
    expected = "video"
    message = "Testing HitRecordIE._type when type is None"
    assertCompare(result, expected, message)

    # test 2: when type is "audio"
    ie = HitRecordIE("audio")
    result = ie._type
    expected = "audio"
    message = "Testing HitRecordIE._type when type is 'audio'"
    assertCompare(result, expected, message)

    print("{} passed.".format(class_name))



# Generated at 2022-06-12 17:35:44.401587
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(HitRecordIE._downloader) is not None


# Generated at 2022-06-12 17:35:44.911601
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HitRecordIE()

# Generated at 2022-06-12 17:35:45.428624
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE()

# Generated at 2022-06-12 17:35:52.387194
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'
    assert ie.ie_name() == 'HitRecord'
    assert HitRecordIE.suitable('https://hitrecord.org/records/2954362')
    assert HitRecordIE.suitable('https://www.hitrecord.org/records/2954362')
    assert not HitRecordIE.suitable('http://hitrecord.org/records/')


# Generated at 2022-06-12 17:36:04.322946
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-12 17:36:10.385366
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")

    assert(ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-12 17:36:21.077673
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hr = HitRecordIE()

    assert hr._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert hr._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert hr._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    info_dict = hr._TEST['info_dict']
    assert info_dict['id'] == '2954362'
    assert info_dict['ext'] == 'mp4'
    assert info_dict['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-12 17:36:23.084918
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE is not None


if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-12 17:36:31.454179
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    extraction_test_set = [
        {
            'url': 'https://hitrecord.org/records/2954362',
            'expected_id': '2954362',
        },
    ]

    for extractor_test in extraction_test_set:
        hitrecord_ie = HitRecordIE(extractor_test['url'])
        assert hitrecord_ie.url == extractor_test['url']
        assert hitrecord_ie._match_id(extractor_test['url']) == extractor_test['expected_id']

# Generated at 2022-06-12 17:36:34.613720
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._match_id("https://hitrecord.org/records/2954362")
    assert ie._match_id("https://hitrecord.org/records/2954362") == '2954362'

# Generated at 2022-06-12 17:36:36.933479
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    _ = HitRecordIE()

# Generated at 2022-06-12 17:36:37.559604
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:36:38.922703
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-12 17:36:43.257602
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        inst = HitRecordIE()
    except (TypeError, AttributeError, ImportError):
        assert False, 'HitRecordIE() raised an exception.'
    else:
        assert isinstance(inst, HitRecordIE)

# Generated at 2022-06-12 17:36:56.033764
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:36:56.584394
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE(): 
    HitRecordIE()

# Generated at 2022-06-12 17:36:58.945676
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.name == 'HitRecord'
    assert ie.ie_key == 'hitrecord'
    assert ie.test_test_ie(ie)

# Generated at 2022-06-12 17:36:59.485005
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:37:01.648485
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:37:03.537904
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie


# Generated at 2022-06-12 17:37:07.337009
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        yt = HitRecordIE()
        url = 'https://hitrecord.org/records/2954362'
        yt.extract(url)
    except Exception as e:
        print('test failed: '+str(e))

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-12 17:37:09.653476
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:37:15.560987
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info = HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')

    # Title
    assert info['title'] == 'A Very Different World (HITRECORD x ACLU)'

    # Id
    assert info['id'] == '2954362'

    # Duration
    assert info['duration'] == 139.327

    # Tags should be a list
    assert isinstance(info['tags'], list)

    # Tags length
    assert len(info['tags']) == 10

    # Comment count should be an int
    assert isinstance(info['comment_count'], int)

    # Comment count should be 349
    assert info['comment_count'] == 349

# Generated at 2022-06-12 17:37:16.066090
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    InfoExtractor()

# Generated at 2022-06-12 17:37:36.688760
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info = HitRecordIE('https://hitrecord.org/records/2954362')
    assert info == HitRecordIE._TEST

# Generated at 2022-06-12 17:37:37.814913
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://www.hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:37:39.168525
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-12 17:37:46.076306
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Test class constructor and download method of class HitRecordIE
    """
    import sys
    import os.path
    assert sys.version_info >= (3, 4, 0), \
        'Python >= 3.4.0 is required. Current version: %s' % sys.version
    assert os.path.isfile('test.data') and os.path.isfile('test.in'), \
        'Unit test example not found. Reload the page or download it.'

    sys.path.append(os.path.dirname(__file__))
    try:
        from . import test_HitRecord
    except ImportError:
        print('Unit test code not present. Reload the page or download again.')
        return

    from .common import InfoExtractor
    from .common import FileDownloader
    from .common import ForbidURLAdder

# Generated at 2022-06-12 17:37:47.569370
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test of a constructor
    HitRecordIE(InfoExtractor)

# Generated at 2022-06-12 17:37:54.259991
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.name == 'hitrecord.org'
    assert ie.ie_key() == 'hitrecord:record'
    assert ie.valid_url('https://hitrecord.org/records/1159448')
    assert ie.valid_url('http://hitrecord.org/records/21039')
    assert not ie.valid_url('https://hitrecord.org/')
    assert ie._VALID_URL == ie.valid_url

# Generated at 2022-06-12 17:37:57.283864
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('http://www.hitrecord.org/records/2954362')
    assert ie.id == '2954362'

    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie.id == '2954362'

# Generated at 2022-06-12 17:38:04.081469
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:38:05.479262
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    assert hitrecord is not None

# Generated at 2022-06-12 17:38:13.284449
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:39:01.810922
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')


# Generated at 2022-06-12 17:39:03.558812
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    infoExtractor = HitRecordIE()
    assert 'HitRecordIE' in infoExtractor.IE_NAME

# Generated at 2022-06-12 17:39:05.708646
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:39:08.113625
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    # test with the default URL
    info = hitrecord._real_extract('https://hitrecord.org/records/2954362')
    assert info['id'] == '2954362'
    assert info['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert float_or_none(info['duration'], 1000) == 139.327

# Generated at 2022-06-12 17:39:18.431049
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE.__name__ == 'HitRecordIE'
	assert HitRecordIE.__doc__ == 'An Extractor for HitRecord.org\n\nParameters\n----------\n'
	assert HitRecordIE.__module__ == 'youtube_dl.extractor.hitrecord'
	assert HitRecordIE.IE_NAME == 'hitrecord:record'
	assert HitRecordIE.VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:39:21.053121
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    down = HitRecordIE()
    assert down.suitable(url)

# Generated at 2022-06-12 17:39:22.200152
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE([],{});

# Generated at 2022-06-12 17:39:27.340161
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.set_downloader(None)
    ie.set_downloader(object)
    ie.add_default_info_extractors()
    ie.set_info_extractors([])
    assert ie.IE_DESC == 'hitrecord'
    assert ie.ie_key() == 'HitRecord'
    assert ie.get_host_name() == 'gdata.youtube.com'

# Generated at 2022-06-12 17:39:29.636487
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie.suitable('https://hitrecord.org/records/2954362'))
    assert(ie.IE_NAME == 'hitrecord:record')

# Generated at 2022-06-12 17:39:30.848144
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:41:19.649997
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL
    assert HitRecordIE()._TEST == HitRecordIE._TEST

# Generated at 2022-06-12 17:41:31.412402
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == "hitrecord"
    assert ie.suitable("https://hitrecord.org/records/2954362")
    assert ie.suitable("https://hitrecord.org/records/3355698")
    assert ie.suitable("https://hitrecord.org/records/2954362")
    assert ie.suitable("https://www.hitrecord.org/records/2954362")
    assert ie.suitable("http://hitrecord.org/records/2954362")
    assert ie.suitable("http://www.hitrecord.org/records/2954362")
    assert not ie.suitable("https://hitrecord.org")
    assert not ie.suitable("https://www.hitrecord.org")
    assert not ie.suitable

# Generated at 2022-06-12 17:41:32.409336
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:41:33.575024
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video_url='https://www.hitrecord.org/records/2954362'
    HitRecordIE().get_info(video_url)

# Generated at 2022-06-12 17:41:34.650938
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	obj = HitRecordIE('https://hitrecord.org/records/2954362')
	assert isinstance(obj, HitRecordIE)


# Generated at 2022-06-12 17:41:35.634974
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    '''
    Test HitRecordIE
    '''
    assert HitRecordIE()

# Generated at 2022-06-12 17:41:36.336587
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    global ie
    ie = HitRecordIE()

# Generated at 2022-06-12 17:41:38.975961
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Basic construct
    test_class_instance = HitRecordIE()
    assert test_class_instance.url_patterns != []
    assert test_class_instance.IE_NAME != []


# Generated at 2022-06-12 17:41:42.460135
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('hitrecord_org', 'HitRecordIE', HitRecordIE._TEST)

# Generated at 2022-06-12 17:41:43.341119
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()