

# Generated at 2022-06-12 17:35:31.936547
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-12 17:35:35.509396
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    e = HitRecordIE('')
    e._VALID_URL = 'https://hitrecord.org/records/(?P<id>\d+)'
    assert e._VALID_URL == 'https://hitrecord.org/records/(?P<id>\d+)'


# Generated at 2022-06-12 17:35:36.417573
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-12 17:35:37.803506
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()

# Generated at 2022-06-12 17:35:40.479294
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'



# Generated at 2022-06-12 17:35:41.064795
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:35:43.232918
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE('HitRecordIE', 'http://hitrecord.org/records/2954362', '2954362')

# Generated at 2022-06-12 17:35:45.166075
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_video = HitRecordIE().extract('https://hitrecord.org/records/2954362')
    assert hitrecord.org in test_video


# Generated at 2022-06-12 17:35:49.691885
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE("http://hitrecord.org/records/2954362")
    assert hitRecordIE._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"
    assert hitRecordIE._TEST['url'] == "https://hitrecord.org/records/2954362"
    assert hitRecordIE._TEST['md5'] == "fe1cdc2023bce0bbb95c39c57426aa71"
    assert hitRecordIE._TEST['info_dict']['id'] == "2954362"
    assert hitRecordIE._TEST['info_dict']['ext'] == "mp4"

# Generated at 2022-06-12 17:35:52.121666
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:36:01.637612
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:36:03.481883
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    h = HitRecordIE()
    assert h.ie_key() == 'hitrecord'


# Generated at 2022-06-12 17:36:03.995187
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert isinstance(HitRecordIE(), HitRecordIE)

# Generated at 2022-06-12 17:36:11.999979
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_url = 'https://hitrecord.org/records/2954362'
    obj = HitRecordIE()
    assert obj._VALID_URL == 'https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)'
    assert obj._TEST['url'] == test_url
    assert obj._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-12 17:36:21.936222
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-12 17:36:24.254736
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:36:26.534567
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE('hitrecord', 'https://hitrecord.org/records/2954362')
    assert obj is not None


# Generated at 2022-06-12 17:36:27.585051
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-12 17:36:37.108233
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)'

# Generated at 2022-06-12 17:36:37.751393
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:36:59.602168
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("www.hitrecord.org", "http://www.hitrecord.org/records/2954362")
    assert ie._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"
    assert ie.USER_NAME == "Zuzi.C12"

# Generated at 2022-06-12 17:37:05.971099
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    extractor = HitRecordIE()
    assert extractor._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:37:06.586827
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ie = HitRecordIE()

# Generated at 2022-06-12 17:37:07.396783
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-12 17:37:10.035352
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie is not None
    assert ie._VALID_URL is not None
    assert ie._TEST is not None

# Generated at 2022-06-12 17:37:11.410316
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE("http://fakeurl.com/records/12345")



# Generated at 2022-06-12 17:37:12.166124
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie != None

# Generated at 2022-06-12 17:37:13.150467
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(object)

# Generated at 2022-06-12 17:37:14.280099
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    assert hitRecordIE is not None

# Generated at 2022-06-12 17:37:15.281612
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('http://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:37:51.374799
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert 0 == 1

# Generated at 2022-06-12 17:37:52.925079
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test = InfoExtractor()
    test = None
    assert test == None


# Generated at 2022-06-12 17:37:55.773724
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records')

# Generated at 2022-06-12 17:37:57.519407
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Simple test for creation of instance of HitRecordIE
    """
    HitRecordIE()

# Generated at 2022-06-12 17:38:04.216110
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE('test')
    assert instance._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)' # pylint: disable=protected-access
    assert instance.name == 'hitrecord'

# Generated at 2022-06-12 17:38:05.953122
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('http://www.hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:38:06.502467
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:38:07.095042
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE

# Generated at 2022-06-12 17:38:09.745580
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE().to_screen('https://hitrecord.org/records/2797054')


# Generated at 2022-06-12 17:38:11.763860
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(HitRecordIE._VALID_URL, HitRecordIE._TEST)

# Generated at 2022-06-12 17:39:05.928881
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    extractor = HitRecordIE()
    assert 'HitRecordIE' == extractor.IE_NAME, \
        'Unexpected class name for HitRecordIE'
    assert extractor._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:39:09.055150
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE();
    ie.extract(HitRecordIE._TEST['url']);

# Generated at 2022-06-12 17:39:14.360798
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # HitRecordIE.suitable returns True when given the right URL
    assert HitRecordIE.suitable("https://hitrecord.org/records/2954362")
    # HitRecordIE.suitable returns False when given the wrong URL
    assert (not HitRecordIE.suitable("https://hitrecord.org/miss/records/2954362"))


# Generated at 2022-06-12 17:39:24.681861
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  """Test HitRecordIE (GET requests, success case). """
  from ..semantic import semantic_extractors
  from datetime import date
  
  # test the constructor of the HitRecordIE class
  ie = HitRecordIE()
  assert ie.name == 'HitRecord'
  assert hasattr(ie, '_VALID_URL')
  assert ie.url_result(ie._VALID_URL)
  assert ie.ie_key() == 'HitRecord'
  assert ie.age_limit == 0
  
  # test the constructor of the SemanticInfoExtractor class
  sie = semantic_extractors.SemanticInfoExtractor()
  assert sie.name == 'SemanticInfoExtractor'
  assert hasattr(sie, '_VALID_URL')

# Generated at 2022-06-12 17:39:25.116501
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:39:26.659681
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    InfoExtractor._call_downloader('HitRecordIE', 'https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:39:27.134649
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:39:28.284248
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("HitRecordIE", None, None, None)

# Generated at 2022-06-12 17:39:28.781409
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:39:29.847876
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE()
    assert hitRecord is not None

# Generated at 2022-06-12 17:41:18.073505
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:41:19.794175
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_ie = HitRecordIE()
    print ("The object of HitRecordIE has been created")


# Generated at 2022-06-12 17:41:21.649647
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Test contructor of class HitRecordIE"""
    # Given
    HitRecordIE()

# Generated at 2022-06-12 17:41:25.121247
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	import sys
	sys.path.append('/Users/Zuzi/Desktop/bopomo-backend/yt')

	from yt import HitRecordIE

	a = HitRecordIE()

# Generated at 2022-06-12 17:41:27.134084
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_ie = HitRecordIE(test=True)
    assert test_ie.suitable('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:41:32.322648
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    additional_tests = [
        {
            'url': 'https://hitrecord.org/records/3002599',
            'playlist_mincount': 4,
        }
    ]

    for test in additional_tests:
        ie = HitRecordIE()
        test_func = lambda: ie.suitable(test['url'])
        assert test_func()

# Generated at 2022-06-12 17:41:32.758659
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-12 17:41:39.965640
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    assert(isinstance(ie, InfoExtractor))  # Test constructor works
    assert(isinstance(ie._DOWNLOAD_WEBPAGE_METHOD, str))  # Test it has a download webpage method
    # Test it has a URL regex and that it matches the one above
    assert(isinstance(ie._VALID_URL, str))
    assert(ie._VALID_URL != "")
    testUrl = "https://hitrecord.org/records/123456"
    m = re.match(r"(https?://(?:www\.)?hitrecord\.org/records/)(\d+)", testUrl)
    assert(ie._VALID_URL == m.re.pattern)  # Test it matches a valid URL
    assert(m.group(1) != "")

# Generated at 2022-06-12 17:41:41.597787
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    assert isinstance(instance._VALID_URL, compat_str)
    assert isinstance(instance._TEST, dict)

# Generated at 2022-06-12 17:41:42.454202
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()