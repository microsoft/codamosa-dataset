

# Generated at 2022-06-12 17:35:33.825663
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:35:43.586179
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # instantiate the IE
    ie = HitRecordIE()

    # expected result
    expectations = {
        'id': '2954362',
        'ext': 'mp4',
        'title': 'A Very Different World (HITRECORD x ACLU)',
        'description': 'md5:e62defaffab5075a5277736bead95a3d',
        'duration': 139.327,
        'timestamp': 1471557582,
        'upload_date': '20160818',
        'uploader': 'Zuzi.C12',
        'uploader_id': '362811',
        'view_count': int,
        'like_count': int,
        'comment_count': int,
        'tags': list,
    }

    # test the method with a known url
    test

# Generated at 2022-06-12 17:35:47.399908
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_ie = HitRecordIE()
    assert hit_record_ie.ie_key() == 'HitRecord'
    assert hit_record_ie.ie_name() == 'HitRecord'

# Generated at 2022-06-12 17:35:57.612769
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'HitRecord'
    assert ie.IE_DESC == 'HitRecord: Recordings'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:35:59.204876
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL is not None
    assert HitRecordIE._TEST is not None

# Generated at 2022-06-12 17:35:59.763316
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HitRecordIE()

# Generated at 2022-06-12 17:36:01.003314
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.name == 'hitrecord:video'


# Generated at 2022-06-12 17:36:03.693393
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    ie = HitRecordIE()
    ie.extract(url)


# Generated at 2022-06-12 17:36:04.639699
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract("https://hitrecord.org/records/2954362")

# Generated at 2022-06-12 17:36:05.838918
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("http://www.hitrecord.org/records/2954362")

# Generated at 2022-06-12 17:36:15.630029
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	import json
	import os
	from objc._objc import select
	import requests
	from requests.compat import urljoin

	from youtube_dl import YoutubeDL

	with YoutubeDL(dict(simulate=True)) as ydl:
		# ydl.params['simulate'] = True
		# ydl.params['json_output'] = True
		# ydl.params['skip_download'] = True
		result = ydl.extract_info(
			# video_id,
			'https://hitrecord.org/records/2954362',
			# download=False
			# process=False
		)
		# print(result['url'])
		# print(json.dumps(result, indent=4))
		# print(result['web

# Generated at 2022-06-12 17:36:21.553777
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie.extract_video == ie._real_extract
    assert ie.extract_video._func_code.co_name == ie._real_extract._func_code.co_name

# Generated at 2022-06-12 17:36:25.457245
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, HitRecordIE)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:36:32.665767
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # Test for class variable VALID_URL and its format
    test = 'https://hitrecord.org/records/2954362'
    match = ie._VALID_URL in test
    assert match, 'Did not match valid URL'
    # Test for class variable _TEST, which is a dictionary with a required amount of keys
    ie_test = ie._TEST
    assert 'url' in ie_test and 'md5' in ie_test and 'info_dict' in ie_test, 'Missing keys in _TEST dictionary'

# Generated at 2022-06-12 17:36:33.963550
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract(HitRecordIE()._TEST['url'])

# Generated at 2022-06-12 17:36:46.161291
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    hit_record_url1 = "https://hitrecord.org/records/2954362"
    hit_record_url2 = "https://hitrecord.org/records/2954363"
    hit_record_url3 = "https://hitrecord.org/records/2954367"
    hit_record_url4 = "https://hitrecord.org/records/2954332"
    hit_record_url5 = "https://hitrecord.org/records/2954333"
    hit_record_url6 = "https://hitrecord.org/records/2954334"
    hit_record_url7 = "https://hitrecord.org/records/2954307"
    hit_record_url8 = "https://hitrecord.org/records/2954308"

# Generated at 2022-06-12 17:36:48.244227
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	hitrecord_ie = HitRecordIE()
	hitrecord_ie.download('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:36:52.074606
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == 'https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)'

# Generated at 2022-06-12 17:37:02.442993
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:37:06.274237
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# Test using empty data set
	HitRecordIE()
	# Test using real data set
	url = 'https://hitrecord.org/records/2954362'
	assert HitRecordIE().suitable(url) == True
	assert HitRecordIE()._TEST['url'] == url

# Generated at 2022-06-12 17:37:21.449764
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie = HitRecordIE("HitRecordIE")
    ie = HitRecordIE("HitRecordIE", "HitRecordIE")

# Generated at 2022-06-12 17:37:22.561598
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-12 17:37:29.705388
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert(HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-12 17:37:37.080138
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('http://hitrecord.org/records/2954362')
    assert ie.suitable('https://hitrecord.org/records/2954362/')
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/people/362811')
    assert not ie.suitable('https://www.youtube.com/watch?v=1sXAKRJFPhM')
    assert not ie.suitable('https://hitrecord.org/records/2954362/edit')
    assert not ie.suitable('https://hitrecord.org/this/2954362')

# Generated at 2022-06-12 17:37:38.019429
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_ie = HitRecordIE()
    assert hit_record_ie != None

# Generated at 2022-06-12 17:37:40.172762
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL is not None
    assert ie._TEST is not None


# Generated at 2022-06-12 17:37:43.307884
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.match('https://hitrecord.org/records/2954362')
    assert ie.match('https://www.hitrecord.org/records/2954362')
    assert not ie.match('https://hitrecord.org/records/2954362/comments')

# Generated at 2022-06-12 17:37:54.909840
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print("Unit Testing the HitRecordIE constructor")
    hitRecord = HitRecordIE()
    assert(hitRecord._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')
    assert(hitRecord._TEST['url'] == 'https://hitrecord.org/records/2954362')
    assert(hitRecord._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71')
    assert(hitRecord._TEST['info_dict']['id'] == '2954362')
    assert(hitRecord._TEST['info_dict']['ext'] == 'mp4')

# Generated at 2022-06-12 17:37:55.445683
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:37:57.455819
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == HitRecordIE._VALID_URL
    assert ie._TEST == HitRecordIE._TEST

# Generated at 2022-06-12 17:38:23.585181
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_HitRecordIE = HitRecordIE('https://www.hitrecord.org/records/2954362')
    assert test_HitRecordIE.url == 'https://www.hitrecord.org/records/2954362'
    assert test_HitRecordIE.valid_url == 'https://www.hitrecord.org/records/2954362'

# Generated at 2022-06-12 17:38:24.924357
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.__class__ == HitRecordIE


# Generated at 2022-06-12 17:38:32.951435
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('HitRecordIE', 'https://hitrecord.org/records/2954362');

    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:38:34.682871
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:38:35.433396
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.login()

# Generated at 2022-06-12 17:38:36.336481
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-12 17:38:37.449597
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video = HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-12 17:38:38.925304
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    HitRecordIE(HitRecordIE._VALID_URL, url)

# Generated at 2022-06-12 17:38:40.538961
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_object = HitRecordIE()
    result = test_object._VALID_URL
    assert result == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:38:45.740591
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-12 17:39:34.506829
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:39:35.224769
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:39:37.686649
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Testing for invalid URL
    HitRecordIE(HitRecordIE._build_url_result('url'), HitRecordIE._download_json,
                HitRecordIE._match_id)
    # TODO: Add tests for valid URLs

# Generated at 2022-06-12 17:39:41.725825
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('http://hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/')
    assert not ie.suitable('https://hitrecord.org/records/')
    assert not ie.suitable('https://hitrecord.org/records/test')

# Generated at 2022-06-12 17:39:44.112072
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# Initialization
	extractor = HitRecordIE('https://hitrecord.org/records/2954362')
	assert extractor.IE_NAME == 'hitrecord'
	assert extractor.IE_DESC  == 'HitRecord'
	

# Generated at 2022-06-12 17:39:44.509455
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    HitRecordIE()

# Generated at 2022-06-12 17:39:52.084226
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.name == 'hitrecord'
    assert HitRecordIE.description == 'HitRecord is an online community for creative collaboration'
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert HitRecordIE._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert HitRecordIE._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    info_dict = HitRecordIE._TEST['info_dict']
    assert info_dict['id'] == '2954362'
    assert info_dict['ext'] == 'mp4'

# Generated at 2022-06-12 17:39:52.832397
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE().extract_info(None)

# Generated at 2022-06-12 17:39:53.367214
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:39:55.645822
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # HitRecordIE is an abstract class, it should not be instantiated
    with pytest.raises(TypeError):
        related_videos = HitRecordIE();

# Generated at 2022-06-12 17:41:49.421917
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()
    assert obj.ie_key() == 'hitrecord'
    assert obj.ie_name() == 'HitRecord'



# Generated at 2022-06-12 17:41:49.999429
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:41:52.405681
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert (ie.ie_key() == 'hitrecord')
    assert (ie.ie_name() == 'HitRecord')

# Generated at 2022-06-12 17:41:53.811268
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('HitRecordIE', 'hitrecord.org')
    assert ie == 'HitRecordIE'
    assert ie.ie_key() == 'HitRecordIE'



# Generated at 2022-06-12 17:41:54.193670
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:41:56.112905
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"



# Generated at 2022-06-12 17:41:57.510206
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._TEST['url'] is not None
    assert HitRecordIE._TEST['info_dict'] is not None

# Generated at 2022-06-12 17:41:58.180003
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie != None

# Generated at 2022-06-12 17:42:00.097936
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except:
        print("HitRecordIE class failed to initialize")

# Generated at 2022-06-12 17:42:05.261625
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    IE = HitRecordIE()
    assert IE.IE_NAME == 'hitrecord'
    assert IE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert IE.IE_DESC == 'Hitrecord'
    assert IE.BEST_URL == 'http://hitrecord.org/video/{id}'
    assert IE.VIDEO_URL == 'http://hitrecord.org/video/{id}'
    assert not hasattr(IE, 'WEBPAGE_URL')

