

# Generated at 2022-06-12 17:35:24.010979
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE();
    assert type(ie) is HitRecordIE;
    assert ie.IE_NAME == 'hitrecord:video';

# Generated at 2022-06-12 17:35:25.464069
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
        assert False
    except AssertionError:
        pass

# Generated at 2022-06-12 17:35:27.782476
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE().to_screen('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:35:28.414258
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video = HitRecordIE()

# Generated at 2022-06-12 17:35:31.319404
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract_info(HitRecordIE._TEST['url'])

# Generated at 2022-06-12 17:35:31.928164
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:35:36.348978
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    #Test 1: Input as valid URL
    HitRecordIE('https://hitrecord.org/records/2954362')
    #Test 2: Input as invalid URL
    HitRecordIE('https://hitrecord.org/records/')
    #Test 3: Input as integer
    HitRecordIE(2954362)
    #Test 4: Input as string
    HitRecordIE('2954362')


# Generated at 2022-06-12 17:35:38.105353
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('http://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:35:38.942088
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:35:40.571127
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.download('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:35:51.947258
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == HitRecordIE._VALID_URL
    assert ie._TEST == HitRecordIE._TEST

# Generated at 2022-06-12 17:35:53.373238
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'

# Generated at 2022-06-12 17:35:55.148427
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie_hitrecord = HitRecordIE()
    assert ie_hitrecord, 'HitRecordIE object is not created'

# Generated at 2022-06-12 17:36:04.112985
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = "https://hitrecord.org/records/2954362"
    hr = HitRecordIE()
    hr._real_extract(url)
    assert hr._real_extract(url).get("title") == 'A Very Different World (HITRECORD x ACLU)'
    assert hr._real_extract(url).get("id") == '2954362'
    assert hr._real_extract(url).get("uploader") == 'Zuzi.C12'
    assert hr._real_extract(url).get("uploader_id") == '362811'

# Generated at 2022-06-12 17:36:17.177696
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE._VALID_URL == "^https?://(?:www\.)?hitrecord\.org/records/(?:[0-9]+)$"
    #assert HitRecordIE._TEST == "{'url': 'https://hitrecord.org/records/2954362', 'md5': 'fe1cdc2023bce0bbb95c39c57426aa71', 'info_dict': {'id': '2954362', 'ext': 'mp4', 'title': 'A Very Different World (HITRECORD x ACLU)', 'description': 'md5:e62defaffab5075a5277736bead95a3d', 'duration': 139.327, 'timestamp': 1471557582, 'upload_date': '20160818', 'uploader': 'Zuzi.C12', 'uploader

# Generated at 2022-06-12 17:36:19.845545
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except TypeError:
        return True
    
    return False

# Generated at 2022-06-12 17:36:21.353170
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362")
    return True

# Generated at 2022-06-12 17:36:22.598177
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_initialize()

# Generated at 2022-06-12 17:36:29.630835
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.suitable('https://hitrecord.org/records/2954362')
    ie.extract('https://hitrecord.org/records/2954362')
    ie.suitable('https://www.hitrecord.org/records/2954362')
    ie.extract('https://www.hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:36:30.804395
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    extractor = HitRecordIE()

# Generated at 2022-06-12 17:36:41.828207
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(isinstance(ie, HitRecordIE))

# Generated at 2022-06-12 17:36:43.724132
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract(HitRecordIE._TEST['url'])


# Generated at 2022-06-12 17:36:45.247064
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE().extract('https://video.hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:36:46.136870
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-12 17:36:46.979306
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None, {})

# Generated at 2022-06-12 17:36:48.166740
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ie = HitRecordIE()



# Generated at 2022-06-12 17:37:00.038568
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    he = HitRecordIE()
    assert he._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert he._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert he._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert he._TEST['info_dict']['id'] == '2954362'
    assert he._TEST['info_dict']['ext'] == 'mp4'
    assert he._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-12 17:37:08.918227
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    e = HitRecordIE("http://www.hitrecord.org/records/2954362")
    assert e._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"
    assert e._TEST["url"] == "https://hitrecord.org/records/2954362"
    assert e._TEST["md5"] == "fe1cdc2023bce0bbb95c39c57426aa71"
    assert e._TEST["info_dict"]["id"] == "2954362"
    assert e._TEST["info_dict"]["ext"] == "mp4"
    assert e._TEST["info_dict"]["title"] == "A Very Different World (HITRECORD x ACLU)"
    assert e._TEST

# Generated at 2022-06-12 17:37:15.987221
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
        ie = HitRecordIE()
        assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:37:19.751784
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    i = ie.extract('https://hitrecord.org/records/2864576')
    assert i['id'] == '2864576'

# Generated at 2022-06-12 17:37:40.052340
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.suitable('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:37:40.532747
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:37:41.018470
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-12 17:37:41.503381
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE();

# Generated at 2022-06-12 17:37:45.657380
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie.match('https://hitrecord.org/records/2954362') is not None)
    assert(ie.match('https://hitrecord.org/records/2954362') is not None)
    assert(ie.match('https://hitrecord.org/records/2954362') is not None)
    assert(ie.match('https://hitrecord.org/records/29543622') is None)

# Generated at 2022-06-12 17:37:47.521025
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:37:49.524984
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Can't be tested because of broken API
    # (returns `status`:`error` on successful request)
    pass

# Generated at 2022-06-12 17:37:49.888500
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-12 17:37:51.908169
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_ie = HitRecordIE()
    assert hitrecord_ie._TEST['url'] == hitrecord_ie._VALID_URL

# Generated at 2022-06-12 17:37:54.825506
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:38:43.016740
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    video_id = ie._match_id(ie._TEST['url'])
    video = ie._download_json(
        'https://hitrecord.org/api/web/records/%s' % video_id, video_id)
    title = video['title']
    assert title == ie._TEST['info_dict']['title']

# Generated at 2022-06-12 17:38:45.054305
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Check if constructor raises an exception or not
    try:
        HitRecordIE()
    except Exception as e:
        assert(isinstance(e, Exception))


# Generated at 2022-06-12 17:38:45.955440
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362", {}, None)

# Generated at 2022-06-12 17:38:53.731132
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Constructor of class HitRecordIE
    hit_record_ie = HitRecordIE()

    # Testing the valid condition for HitRecordIE
    assert_equals(hit_record_ie._VALID_URL, "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)")

    # Testing the test condition for HitRecordIE

# Generated at 2022-06-12 17:38:56.979885
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    assert instance._downloader.params['nocheckcertificate'] == '1'

# Generated at 2022-06-12 17:38:59.178651
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    ie = HitRecordIE(None)
    assert ie



# Generated at 2022-06-12 17:39:01.858218
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # Test to not crash on malformed URL
    ie.extract("https://hitrecord.org/records")

# Generated at 2022-06-12 17:39:04.213965
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    _HitRecordIE = HitRecordIE()
    assert _HitRecordIE.ie_key() == 'hitrecord'
    assert _HitRecordIE.ie_name() == 'hitrecord'

# Generated at 2022-06-12 17:39:05.455295
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:39:09.462195
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('http://hitrecord.org/records/2954362')
    assert ie.url == 'https://hitrecord.org/records/2954362'

# Generated at 2022-06-12 17:40:51.901781
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test for method __init__
    ie = HitRecordIE()
    assert ie



# Generated at 2022-06-12 17:40:59.769640
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    # Testing constructor for HitRecordIE
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:41:03.230433
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(
        'https://hitrecord.org/records/2954362', {}, {})

    assert ie._api_endpoint == (
        'https://hitrecord.org/api/web/records/2954362')

# Generated at 2022-06-12 17:41:07.203752
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    hit_record = HitRecordIE('https://hitrecord.org/records/2954362');

    print(hit_record.url)
    # print(hit_record.ie_key())
    # print(hit_record._match_id(hit_record.url))
    # print(hit_record._download_json(hit_record.url))

# test_HitRecordIE()

# Generated at 2022-06-12 17:41:08.162582
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Tests the HitRecordIE constructor"""
    assert HitRecordIE

# Generated at 2022-06-12 17:41:09.513066
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:41:10.114278
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-12 17:41:12.558207
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)', "Private var _VALID_URL not initialized correctly."

# Generated at 2022-06-12 17:41:13.017478
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-12 17:41:14.502508
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.url = 'https://hitrecord.org/records/2954362'
    ie.extract()

# Generated at 2022-06-12 17:45:06.697991
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:45:09.298346
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Test constructor of class HitRecordIE.
    """
    url = "https://hitrecord.org/records/2954362"
    ie = HitRecordIE(url)
    print(ie.url)

# Generated at 2022-06-12 17:45:13.400654
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.name == 'hitrecord'
    assert ie.description == (
        'HitRecord is an open-collaborative production company founded by'
        ' actor and director Joseph Gordon-Levitt.')
    assert ie.test_url('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'