

# Generated at 2022-06-12 17:35:23.885697
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()
    assert HitRecordIE('id')
    assert HitRecordIE('url')
    assert HitRecordIE('url', 'id')

# Generated at 2022-06-12 17:35:25.654316
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:35:29.848982
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.set_downloader(None)
    ie.set_progress_hooks(None)
    ie.set_worker_threads(None)
    ie.set_file_downloader_hooks(None)
    ie.set_request_hooks(None)
    ie.set_opener(None)

# Generated at 2022-06-12 17:35:31.459753
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE({}) != {}
    assert HitRecordIE != {}

# Generated at 2022-06-12 17:35:40.839858
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-12 17:35:41.478277
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:35:42.792994
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:35:49.178416
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  parameters = {'url': 'https://hitrecord.org/records/2954362',
              'md5': 'fe1cdc2023bce0bbb95c39c57426aa71'}
  #test = HitRecordIE._test_suite()
  #test.test_info_dict(HitRecordIE, parameters)
  url = parameters['url']
  video_id = HitRecordIE._match_id(url)
  #video = HitRecordIE._download_json(
  #        'https://hitrecord.org/api/web/records/%s' % video_id)
  #print(video)

# Generated at 2022-06-12 17:35:53.929877
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    test_urls = [
        ("https://hitrecord.org/records/2954362", "2954362", "mp4")
    ]
    for url, video_id, ext in test_urls:
        assert ie._match_id(url) == video_id
        assert ie._real_extract(url)["ext"] == ext

# Generated at 2022-06-12 17:35:54.918812
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-12 17:36:04.734844
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    hitRecordIE = HitRecordIE()


# Generated at 2022-06-12 17:36:17.680710
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.suitable('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:36:19.223258
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()

# Generated at 2022-06-12 17:36:23.196372
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('http://hitrecord.org/records/2954362')
    assert ie.url == 'https://hitrecord.org/records/2954362'
    assert ie.video_id == '2954362'
    assert ie.title == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-12 17:36:29.849484
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecordIE = HitRecordIE("http://www.hitrecord.org/records/2954362")

    assert hitrecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:36:31.398510
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # test creation of the playlist creator
    creator = HitRecordIE()
    assert creator != None

if __name__ == '__main__':
    # test creation of the playlist creator
    test_HitRecordIE()

# Generated at 2022-06-12 17:36:32.351241
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    HitRecordIE()

# Generated at 2022-06-12 17:36:40.342578
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:36:51.888618
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-12 17:36:55.164334
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    if hitRecordIE != None:
        print('True')
    else:
        print('False')

# Generated at 2022-06-12 17:37:14.017226
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:37:15.531001
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.get_instance() is ie


if __name__ == '__main__':
	test_HitRecordIE()

# Generated at 2022-06-12 17:37:17.855114
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    a = HitRecordIE()
    assert a.suitable('https://www.hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:37:27.734569
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        from .test_classes import DummyExtractor
    except ImportError:
        from .test_classes import DummyExtractor
    ie = HitRecordIE(DummyExtractor(), 'https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:37:29.170672
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('2954362')

# Generated at 2022-06-12 17:37:30.014537
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie != None

# Generated at 2022-06-12 17:37:37.352974
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:37:42.727694
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('http://hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')
    assert ie.suitable('http://www.hitrecord.org/records/2954362')
    assert ie.suitable('http://www.hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362?foo=bar')
    assert ie.suitable('http://www.hitrecord.org/records/2954362?foo=bar')
    assert not ie.suitable('https://hitrecord.org/records')


# Generated at 2022-06-12 17:37:46.145310
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('http://hitrecord.org/records/2954362')
    assert isinstance(ie, HitRecordIE)

# Generated at 2022-06-12 17:37:49.168925
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    info_dict = ie.extract(ie._TEST['url'])
    assert info_dict['id']


# Generated at 2022-06-12 17:38:35.570128
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HITRECORD'
    assert ie.valid_url() == HitRecordIE._VALID_URL
    assert ie.test_video() == HitRecordIE._TEST

# Generated at 2022-06-12 17:38:36.938851
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()


if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-12 17:38:42.464535
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:38:47.626384
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # pylint: disable=redefined-outer-name, no-member
    from .test_main import test_main
    from .test_main import test_video_result
    from .test_main import test_video_url
    from ..compat import compat_str

    url = 'https://hitrecord.org/records/2954362'

# Generated at 2022-06-12 17:38:49.379638
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-12 17:38:56.563989
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    srcIE = HitRecordIE()
    assert srcIE.ie_key() == 'hitrecord'
    assert srcIE.ie_name() == 'hitrecord'
    assert srcIE.ie_version() is None
    assert srcIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:38:58.295440
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    x = HitRecordIE()


# Generated at 2022-06-12 17:39:00.684017
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:39:01.756119
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video = HitRecordIE()


# Generated at 2022-06-12 17:39:02.812192
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-12 17:39:43.625764
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE() # Pass
    print('test_HitRecordIE passes!')


# Generated at 2022-06-12 17:39:45.575580
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert (HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL)
    assert (HitRecordIE()._TEST == HitRecordIE._TEST)

# Generated at 2022-06-12 17:39:53.596606
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ied = HitRecordIE("http://www.hitrecord.org/records/2954362", {}, {})
    assert ied.params["_VALID_URL"] == r"https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"

# Generated at 2022-06-12 17:39:56.402124
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    print(ie)
    print(dir(ie))
    print(dir(ie.IE_DESC))

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-12 17:39:58.385779
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable("https://hitrecord.org/records/2954362")
    assert not ie.suitable("https://blah.org/records/2954362")

# Generated at 2022-06-12 17:39:58.886238
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:40:00.026517
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL is not None



# Generated at 2022-06-12 17:40:01.266816
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(object())
    assert ie.url_result.get_host() == 'HitRecord'

# Generated at 2022-06-12 17:40:07.600396
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    # Make sure that we have something to test
    assert ie._VALID_URL is not None, 'Must define _VALID_URL to use this base class'

    # Make sure that we have a test defined
    assert ie._TEST is not None, 'Must define _TEST to use this base class'

    assert ie._TEST == HitRecordIE._TEST, 'It seems you overrided the static _TEST var'


# Initializing the class using the hitrecord URL
_ = HitRecordIE()._extract_video_info(_TEST['url'], _TEST['id'])

# Pass the MD5 checksum of the file to the unit test and compare it with the original
# If there is a mismatch, an exception will be thrown to let you know

# Generated at 2022-06-12 17:40:08.541367
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("")  # Will raise an error if it can't read the page

# Generated at 2022-06-12 17:41:15.388212
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-12 17:41:22.050625
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# Test for a video with a valid HitRecord url
	HitRecordIE()._match_id('http://www.hitrecord.org/records/2954362') == '2954362'

	# Test for an unvalid HitRecord url
	HitRecordIE()._match_id('http://www.youtube.com/records/2954362') is None

# Generated at 2022-06-12 17:41:25.729404
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE()
    assert hitRecord.suitable('https://hitrecord.org/records/2954362')
    assert hitRecord.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:41:33.165272
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from .common import InfoExtractor
    from .testsuite import TestSuite
    from .testsuite import ExtractorTestCase
    # Initialize
    class MockExtractor(InfoExtractor):
        def _real_extract(self, url):
            pass

    # Call constructor
    MockExtractor('TestExtractor', 'testdesc')
    # Call test_suite
    suite = TestSuite('http://example.com/')
    # Call test_case
    case = ExtractorTestCase('test_suite', 'test_case', 'http://example.com/')
    suite.run()

# Generated at 2022-06-12 17:41:40.527324
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    ie_obj = HitRecordIE()
    assert ie_obj._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie_obj._match_id('https://hitrecord.org/records/2954362') == '2954362'

# Generated at 2022-06-12 17:41:50.399340
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # (1) Test with a valid url to a video
    HitRecordIE().extract('http://www.hitrecord.org/records/2954362')
    # (2) Test with an invalid url (non-number in url)
    HitRecordIE().extract('http://www.hitrecord.org/records/sdfsdf')
    # (3) Test with a valid url that returns a 404
    HitRecordIE().extract('http://www.hitrecord.org/records/123123')
    # (4) Test with an invalid url (non-hitrecord.org url)
    HitRecordIE().extract('http://www.pornhub.com')
    # (5) Test with an invalid url (non-hitrecord.org url)
    HitRecordIE().extract('http://www.youtube.com')
   

# Generated at 2022-06-12 17:41:57.799981
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    _VALID_URL = r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._VALID_URL == _VALID_URL or ie._VALID_URL == '^' + _VALID_URL + '$'


# Generated at 2022-06-12 17:41:59.544606
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    print(ie.ie_key())
    print(ie.ie_key_)

# Generated at 2022-06-12 17:42:01.520635
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    assert instance.IE_NAME == 'hitrecord'



# Generated at 2022-06-12 17:42:04.635296
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        # giving url as argument
        url = 'https://hitrecord.org/records/2954362'
        HitRecordIE(url)
        print("Unit test for constructor of class HitRecordIE passed")
    except Exception as e:
        print("Unit test for constructor of class HitRecordIE failed")



# Generated at 2022-06-12 17:44:11.610394
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('hitrecord')

# Generated at 2022-06-12 17:44:13.550298
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    '''
    It will create an instance of HitRecordIE
    '''
    HitRecordIE()

# Generated at 2022-06-12 17:44:15.188465
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    a = HitRecordIE()
    assert a.__class__.__name__ == "HitRecordIE"

# Generated at 2022-06-12 17:44:15.683835
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:44:23.031485
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, HitRecordIE)
    assert hasattr(ie, '_VALID_URL')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert hasattr(ie, '_TEST')
    assert isinstance(ie._TEST, dict)
    url = ie._TEST['url']
    assert url == 'https://hitrecord.org/records/2954362'
    assert hasattr(ie, '_real_extract')
    assert callable(getattr(ie, '_real_extract', None))
    #assert hasattr(ie, 'suitable')
    #assert callable(getattr(ie, 'suitable', None))
    #assert

# Generated at 2022-06-12 17:44:25.667921
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:44:27.020630
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:44:27.483418
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-12 17:44:29.924181
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print("Constructing an instance of HitRecordIE...")
    HitRecordIE()
    print("Success!")


# Generated at 2022-06-12 17:44:38.845153
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'