

# Generated at 2022-06-12 17:35:27.565021
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL
    assert HitRecordIE()._TEST == HitRecordIE._TEST


# Generated at 2022-06-12 17:35:28.796224
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Should be able to create a class instance of HitRecordIE
    HitRecordIE()


# Generated at 2022-06-12 17:35:31.223595
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-12 17:35:32.130947
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('hitrecord.org', )

# Generated at 2022-06-12 17:35:32.706292
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:35:37.225438
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == '''https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)'''
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-12 17:35:37.764726
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:35:38.325642
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:35:41.152788
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test with valid URL
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    # Test with an invalid URL
    ie = HitRecordIE("https://www.google.com/maps/dir/")
    # Test with an non string argument
    ie = HitRecordIE(2954362)

# Generated at 2022-06-12 17:35:41.702503
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:35:51.131272
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert type(ie)

# Generated at 2022-06-12 17:35:57.522340
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.name == 'hitrecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-12 17:36:05.431327
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # 1. Test constructor
    ie = HitRecordIE()

    # 1.1. Test extrator name
    assert ie._name is not None

    # 1.2. Test extractor description
    assert ie._description is not None

    # 1.3. Test extractor download pattern
    assert ie._VALID_URL is not None

    # 1.4. Test extractor extract pattern
    id = '2954362'
    url = 'https://hitrecord.org/records/%s' % id
    ie._downloader.download(url)
    info = ie.extract(url)
    assert info['id'] == id
    assert info['url'] is not None
    assert info['title'] is not None
    assert info['description'] is not None
    assert info['duration'] > 0

# Generated at 2022-06-12 17:36:08.775375
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-12 17:36:10.024284
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass


# Generated at 2022-06-12 17:36:11.997668
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == ie.ie._VALID_URL

# Generated at 2022-06-12 17:36:18.482098
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    r = HitRecordIE()
    # The Data needed to create a HitRecordIE object
    testUrl = "https://hitrecord.org/records/2954362"

    r._match_id(testUrl)
    assert r.VIDEO_ID == "2954362"
    # Make sure the id is all digits
    assert r.VIDEO_ID.isdigit()

    # Make sure it is a valid URL
    assert r._VALID_URL == r._TEST['url']

# Generated at 2022-06-12 17:36:19.423107
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:36:27.280220
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    a = HitRecordIE()

# Generated at 2022-06-12 17:36:32.836235
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # Test case # 1
    def test_login_required_index_ie(self):
        """ Test case 1
        Correct get_info_dict"""
        record_id = '2954362'
        url = 'https://hitrecord.org/records/%s' % record_id
        video = self._call_api(url)

# Generated at 2022-06-12 17:36:43.169118
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362');

# Generated at 2022-06-12 17:36:44.499308
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Test constructor for HitRecordIE class"""
    assert HitRecordIE

# Generated at 2022-06-12 17:36:52.132504
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE("https://hitrecord.org/records/2954362")
    assert hitrecord._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert hitrecord._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert hitrecord._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert hitrecord._TEST['info_dict']['id'] == '2954362'
    assert hitrecord._TEST['info_dict']['ext'] == 'mp4'
    assert hitrecord._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'
   

# Generated at 2022-06-12 17:36:56.582212
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, HitRecordIE), "HitRecordIE is not derived from InfoExtractor"
# Test for method _real_extract in HitRecordIE
    # assert _real_extract()


# Generated at 2022-06-12 17:36:57.890478
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-12 17:36:59.212139
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:36:59.728287
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:37:01.892708
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:37:02.529011
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE();

# Generated at 2022-06-12 17:37:03.542302
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:37:23.630773
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'

# Generated at 2022-06-12 17:37:25.523169
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # construct an instance of HitRecordIE
    HitRecordIE(None)

# Generated at 2022-06-12 17:37:28.288838
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Arrange
    url = 'https://hitrecord.org/records/2915466'

    # Act
    hitRecordIE = HitRecordIE()

    # Assert
    assert hitRecordIE.suitable(url) == True



# Generated at 2022-06-12 17:37:36.441777
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    global HitRecordIE

# Generated at 2022-06-12 17:37:37.113565
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.suite()

# Generated at 2022-06-12 17:37:44.542417
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    e = HitRecordIE('https://hitrecord.org/records/2954362')
    expected_video_id = '2954362'
    assert e.video_id == expected_video_id

    # Check that the test case is present

# Generated at 2022-06-12 17:37:46.101362
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert(ie.name == "HitRecord")

# Generated at 2022-06-12 17:37:49.481072
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # pylint: disable=E0102
    ie = HitRecordIE()
    ie._download_json('https://hitrecord.org/api/web/records/2954362')
    assert ie

# Generated at 2022-06-12 17:37:50.037054
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:37:54.152040
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Arrange
    url = "https://hitrecord.org/records/2954362";

    # Act
    hitrecord = HitRecordIE.suitable(url);

    # Assert
    assert hitrecord is not None, "HitRecordIE should be suitable for %s" % url

# Generated at 2022-06-12 17:38:44.174169
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()

# Generated at 2022-06-12 17:38:44.727683
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# test_HitRecordIE()
	HitRecordIE()

# Generated at 2022-06-12 17:38:52.309994
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test = HitRecordIE()
    assert test._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:38:55.888581
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from .common import InfoExtractor
    from .youtube import YoutubeIE
    from .hitrecord import HitRecordIE

    ie = InfoExtractor(YoutubeIE.ie_key())
    ie2 = InfoExtractor(HitRecordIE.ie_key())
    assert type(ie) == YoutubeIE, 'I(YoutubeIE) should be a YoutubeIE type'
    assert type(ie2) == HitRecordIE, 'I(HitRecordIE) should be a HitRecordIE type'


# Generated at 2022-06-12 17:38:56.976995
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:39:01.216071
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-12 17:39:02.768747
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    constructor_test(HitRecordIE, {'url': HitRecordIE._VALID_URL})

# Generated at 2022-06-12 17:39:04.283590
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('')
    print(ie._VALID_URL)


# Generated at 2022-06-12 17:39:12.949868
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    # Class HitRecordIE tests
    assert ie.ie_key() == 'HitRecord'

    # Test incorrect urls
    assert ie.suitable('http://www.youtube.com/watch?v=BaW_jenozKc') is False

    # Test HitRecordIE._VALID_URL match
    assert ie._VALID_URL == HitRecordIE._VALID_URL

    # Test HitRecordIE._TEST
    assert ie._TEST == HitRecordIE._TEST

# Generated at 2022-06-12 17:39:15.591552
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    url = 'https://hitrecord.org/records/2954362'
    hitrecord._real_extract(url)

# Generated at 2022-06-12 17:40:56.529623
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL is not None

# Generated at 2022-06-12 17:40:57.987129
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE == HitRecordIE

# Generated at 2022-06-12 17:41:07.848038
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-12 17:41:09.879390
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    assert hitrecord._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:41:10.388263
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE

# Generated at 2022-06-12 17:41:12.516645
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:41:14.853266
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print("Creating a test instance of HitRecordIE")
    test_url = HitRecordIE._VALID_URL
    print("    valid url: %s" % test_url)
    ie = HitRecordIE(test_url)



# Generated at 2022-06-12 17:41:16.523211
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = "https://hitrecord.org/records/2954362"
    hrie = HitRecordIE(info_extractors)
    hrie._real_extract(url)

# Generated at 2022-06-12 17:41:19.180512
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  ie = HitRecordIE()
  ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:41:20.929637
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL is not None
    assert ie._TEST is not None

# Generated at 2022-06-12 17:45:12.304225
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_dict = {
        'id': '2954362',
        'ext': 'mp4',
        'title': 'A Very Different World (HITRECORD x ACLU)',
        'description': 'md5:e62defaffab5075a5277736bead95a3d',
        'duration': 139.327,
        'timestamp': 1471557582,
        'upload_date': '20160818',
        'uploader': 'Zuzi.C12',
        'uploader_id': '362811',
        'view_count': int,
        'like_count': int,
        'comment_count': int,
        'tags': list,
    }

    url = 'https://hitrecord.org/records/2954362'
    ie = HitRecordIE()
    assert ie

# Generated at 2022-06-12 17:45:14.043462
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL is not None
    assert HitRecordIE._TEST is not None
    assert HitRecordIE.__name__ != 'HitRecordIE'

# Generated at 2022-06-12 17:45:15.208219
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.download('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:45:15.627714
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE()

# Generated at 2022-06-12 17:45:16.873134
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(HitRecordIE.ie_key())
    assert ie.ie_key() == 'HitRecord'