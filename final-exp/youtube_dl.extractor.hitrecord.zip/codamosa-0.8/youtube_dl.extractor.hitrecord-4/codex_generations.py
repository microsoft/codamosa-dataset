

# Generated at 2022-06-12 17:35:24.079241
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL is not None
    assert ie._TEST['url'] is not None

# Generated at 2022-06-12 17:35:32.357148
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_url = 'https://hitrecord.org/records/2954362'
    test_video_id = '2954362'
    test_title = 'A Very Different World (HITRECORD x ACLU)'
    test_description = 'md5:e62defaffab5075a5277736bead95a3d'
    test_duration = 139.327
    test_timestamp = 1471557582
    test_upload_date = '20160818'
    test_uploader = 'Zuzi.C12'
    test_uploader_id = '362811'
    test_md5 = 'fe1cdc2023bce0bbb95c39c57426aa71'
    test_view_count = int
    test_like_count = int
    test_comment_count = int


# Generated at 2022-06-12 17:35:32.917724
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:35:34.805366
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')


# Generated at 2022-06-12 17:35:37.628441
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:35:44.915940
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Constructor test
    """
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')

# Generated at 2022-06-12 17:35:46.893817
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('example')

# Generated at 2022-06-12 17:35:53.408358
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_cases = [
        {
            # From http://hitrecord.org/records/2954362
            'input': 'https://hitrecord.org/records/2954362',
            'id': '2954362'
        },
        # From https://hitrecord.org/records/172879
        {
            'input': 'https://hitrecord.org/records/172879',
            'id': '172879'
        }
    ]

    for test_case in test_cases:
        response = HitRecordIE()._real_extract(test_case.get('input'))
        assert test_case.get('id') == response.get('id')

# Generated at 2022-06-12 17:35:54.842847
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:35:55.248685
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-12 17:36:06.245749
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE('https://hitrecord.org/records/2954362')
    video = info_extractor._real_extract('https://hitrecord.org/records/2954362')
    assert video['duration'] == 139.327
    assert video['tags'][0] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-12 17:36:08.283337
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:36:15.998334
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    ie_info = ie.ie_key().lower()
    assert ie_info == 'hitrecord', 'Expected ' + ie.ie_key() + ' but is ' + ie_info
    assert ie.search_title == 'HitRecord'
    assert ie.search_title_exclude == 'Star Wars'
    HitRecordIE._TESTS

# Generated at 2022-06-12 17:36:18.297437
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.name == 'HITRECORD'
    assert ie.ie_key() == 'hitrecord'
    assert ie.description == 'Make art together'

# Generated at 2022-06-12 17:36:20.974576
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:36:22.559080
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    testc = HitRecordIE()
    assert testc.name() == 'HitRecord'

# Generated at 2022-06-12 17:36:24.628733
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name == 'HitRecord'



# Generated at 2022-06-12 17:36:26.798673
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.params = ie._get_params()
    ie.params['url'] = 'https://hitrecord.org/records/2954362'
    ie.params['id'] = '2954362'

# Generated at 2022-06-12 17:36:27.822543
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()


# Generated at 2022-06-12 17:36:29.414822
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    global HitRecordIE
    HitRecordIE = HitRecordIE



# Generated at 2022-06-12 17:36:49.769627
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # HitRecordIE(InfoExtractor) method test
    HitRecordIE(InfoExtractor)._real_extract(HitRecordIE._TEST['url'])

# Generated at 2022-06-12 17:36:52.939715
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        from .test_HitRecordIE import HitRecordIE_test
        HitRecordIE_test(False)
    except ImportError:
        pass

# Generated at 2022-06-12 17:37:03.614242
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Test HitRecordIE constructor"""
    # Valid video
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:37:05.030482
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:37:05.819923
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    print(ie)


# Generated at 2022-06-12 17:37:14.094792
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert HitRecordIE()._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert HitRecordIE()._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert HitRecordIE()._TEST['info_dict']['id'] == '2954362'
    assert HitRecordIE()._TEST['info_dict']['ext'] == 'mp4'
    assert HitRecordIE()._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-12 17:37:19.801247
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from ..extractor import BaseIE
    assert issubclass(HitRecordIE, BaseIE)
    assert HitRecordIE.__name__ == 'HitRecordIE'
    assert HitRecordIE.__dict__['_VALID_URL'] == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert HitRecordIE._TEST.get('url') == 'https://hitrecord.org/records/2954362'
    assert HitRecordIE._TEST.get('md5') == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert HitRecordIE._TEST.get('info_dict.id') == '2954362'
    assert HitRecordIE._TEST.get('info_dict.ext') == 'mp4'


# Generated at 2022-06-12 17:37:20.768694
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-12 17:37:28.821586
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Testing constructor of class HitRecordIE
    """
    
    # Test valid URL
    valid_url = 'https://hitrecord.org/records/2954362' # A valid URL
    hitrecord = HitRecordIE()
    assert hitrecord._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)' # Test valid URL regular expression

    # Test invalid URL
    invalid_url = 'https://hitrecord.org/records/2954362343213214' # An invalid URL, not present in the 'hitrecord' database
    hitrecord = HitRecordIE()
    assert hitrecord._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)' # Test valid URL regular

# Generated at 2022-06-12 17:37:31.461255
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    tester = HitRecordIE()
    assert hasattr(tester, '_VALID_URL')
    assert hasattr(tester, '_TEST')
    assert hasattr(tester, '_real_extract')

# Generated at 2022-06-12 17:37:58.146504
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:38:02.373645
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract(
        'https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:38:03.159172
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:38:05.722047
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.url = "https://hitrecord.org/records/2954362"
    assert ie.valid_url()

# Generated at 2022-06-12 17:38:09.745010
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    h = HitRecordIE()
    assert h._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Unit tests for method extract() of class HitRecordIE

# Generated at 2022-06-12 17:38:11.189310
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:38:17.793101
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test error message caused by wrong url
    info = HitRecordIE._build_url_result("https://hitrecord.org/records/")
    assert info['_type'] == 'url_result'
    assert info['ie_key'] == 'HitRecord'
    assert info['url'] == 'https://hitrecord.org/records/'
    assert info['title'] == 'HitRecord'
    assert info['description'] == 'Wrong URL. Maybe related to wrong ID.'


# Generated at 2022-06-12 17:38:21.305749
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE(): # pylint: disable=redefined-outer-name
    video_info = HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')
    assert video_info.get('id') == '2954362'
    assert video_info.get('view_count') >= 0

# Generated at 2022-06-12 17:38:22.362384
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('HitRecord')
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:38:23.479479
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_HitRecordIE.ie = HitRecordIE()
    return True

# Generated at 2022-06-12 17:38:50.337591
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.__name__ == "HitRecordIE"
    assert HitRecordIE.__module__ == "youtube_dl.extractor.hitrecord"
    assert HitRecordIE.__doc__ is not None


# Generated at 2022-06-12 17:38:51.618531
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE() == HitRecordIE()


# Generated at 2022-06-12 17:38:52.877276
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert type(ie) == HitRecordIE

# Generated at 2022-06-12 17:38:56.788963
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/')
    assert not ie.suitable('https://hitrecord.org/records/')
    url = 'https://hitrecord.org/records/2954362'
    assert ie._match_id(url) == '2954362'

# Generated at 2022-06-12 17:39:00.734393
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('A Very Different World (HITRECORD x ACLU)', 'md5:e62defaffab5075a5277736bead95a3d')

# Generated at 2022-06-12 17:39:03.391011
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-12 17:39:04.024225
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:39:08.713898
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.suitable('https://hitrecord.org/records/2954362') is True

if __name__ == "__main__":
    test_HitRecordIE()

# Generated at 2022-06-12 17:39:10.630956
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    instance._match_id('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:39:12.394446
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test = HitRecordIE()
    test._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:39:35.945106
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE("http://hitrecord.org/records/2954362")
    assert info_extractor.get_info("http://hitrecord.org/records/2954362")['id']=='2954362'
    return

# Generated at 2022-06-12 17:39:36.536370
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:39:37.756639
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.__name__ == "HitRecordIE"

# Generated at 2022-06-12 17:39:39.567017
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Unit test to check constructor of class HitRecordIE
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'



# Generated at 2022-06-12 17:39:39.944949
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
   HitRecordIE()

# Generated at 2022-06-12 17:39:41.184709
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ie = HitRecordIE()
	assert ie == HitRecordIE(info_extractors={'hitrecord': HitRecordIE})

# Generated at 2022-06-12 17:39:41.613283
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-12 17:39:42.517069
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:39:43.446985
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Testing if HitRecordIE constructor has been successfully created
    assert HitRecordIE()

# Generated at 2022-06-12 17:39:44.070125
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-12 17:40:44.185923
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:40:45.482393
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract(HitRecordIE._TEST['url'])

# Generated at 2022-06-12 17:40:48.147005
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:40:49.074754
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    unit_test = HitRecordIE()

# Generated at 2022-06-12 17:40:49.782554
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:40:50.268764
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-12 17:40:54.860450
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    hitRecordIE.url = "https://hitrecord.org/records/2954362"
    hitRecordIE.video_id = "2954362"
    assert hitRecordIE.video_id == "2954362"
    assert hitRecordIE.url == "https://hitrecord.org/records/2954362"


# Generated at 2022-06-12 17:41:01.347467
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_urls = [
        'https://hitrecord.org/records/2954362',
        'http://www.hitrecord.org/records/2954362',
        'http://hitrecord.org/records/2954362'
    ]
    for test_url in test_urls:
        class_under_test = HitRecordIE(test_url, downloader=None)
        assert class_under_test._VALID_URL == HitRecordIE._VALID_URL
        assert class_under_test._TEST == HitRecordIE._TEST
        assert class_under_test._match_id(test_url) == class_under_test._match_id(HitRecordIE._TEST['url'])
        assert class_under_test._real_extract(test_url)

# Generated at 2022-06-12 17:41:08.802420
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    hitRecord = ie._real_extract('https://hitrecord.org/records/2954362')
    print(hitRecord)
    assert hitRecord['url'] == 'https://s3.amazonaws.com/hitrecord-assets-dev/record-assets/362811/bfd4ec9d14691b4cf90c4d4359cc78a4e65a70db.mp4?Signature=vkNfA%2FNGZM%2B2BHw8%2FyLgR%2BVHU6Q%3D&Expires=1500032387&AWSAccessKeyId=AKIAIVY5PFDY7BXQU45A'

# Generated at 2022-06-12 17:41:13.478203
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    path_url = "https://hitrecord.org/records/2954362"
    print("\n")
    print("Unit test for HitRecordIE - ")
    assert HitRecordIE._check_url(HitRecordIE._VALID_URL, path_url), "The valid URL - %s is not valid" % path_url
    print("[OK] Unit test for HitRecordIE passed !")
    print("----------------------------------")

# Generated at 2022-06-12 17:43:00.504188
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records')

# Generated at 2022-06-12 17:43:02.180927
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except TypeError:
        pass
    else:
        assert False

# Generated at 2022-06-12 17:43:06.400710
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE._TEST["info_dict"]["view_count"] = 6000
    HitRecordIE._TEST["info_dict"]["like_count"] = 100
    HitRecordIE._TEST["info_dict"]["comment_count"] = 40
    HitRecordIE(HitRecordIE._VALID_URL)
    
if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-12 17:43:08.120761
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"

# Generated at 2022-06-12 17:43:08.502270
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:43:09.324951
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie, 'HitRecordIE not created successfuly!'

# Generated at 2022-06-12 17:43:11.413434
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from .hitrecord import HitRecordIE
    from .common import InfoExtractor
    from ..utils import (
        clean_html,
        float_or_none,
        int_or_none,
        try_get,
    )
    import unittest
    return 0


# Generated at 2022-06-12 17:43:11.995048
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-12 17:43:12.851661
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Check if HitRecordIE can be created
    ie = HitRecordIE()

# Generated at 2022-06-12 17:43:19.864617
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    assert hitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'