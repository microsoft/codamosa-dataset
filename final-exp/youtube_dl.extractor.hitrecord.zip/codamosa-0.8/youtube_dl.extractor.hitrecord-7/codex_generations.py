

# Generated at 2022-06-12 17:35:23.379102
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    print(ie)



# Generated at 2022-06-12 17:35:31.460496
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-12 17:35:34.807597
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  try:
    record = HitRecordIE()
  # Assert that HitRecordIE is an instance of InfoExtractor
    assert isinstance(record,InfoExtractor)
  except:
    assert False, "HitRecordIE is not an instance of InfoExtractor"


# Generated at 2022-06-12 17:35:39.020291
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    ie = HitRecordIE(url)
    assert ie._TEST['url'] == url
    assert ie._TEST['md5'] == ie.test_md5
    assert ie.extract() == ie._TEST

# Generated at 2022-06-12 17:35:39.796799
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('/records/2954362')

# Generated at 2022-06-12 17:35:40.391198
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-12 17:35:47.052715
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
"""
if __name__ == '__main__':
    test_HitRecordIE()
"""
is_match = HitRecordIE._VALID_URL.match(r'https://hitrecord.org/records/2954362')
is_match

url = r'https://hitrecord.org/records/2954362'

result = HitRecordIE().extract(url)
result

import json
json.dumps(result)

print(json.dumps(result, sort_keys=False, indent=2, separators=(',', ': ')))

# Generated at 2022-06-12 17:35:48.842589
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._match_id("https://hitrecord.org/records/2954362")

# Generated at 2022-06-12 17:35:57.031175
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    # Test function when url is not provided
    assert ie._match_id(None) is None

    # Test case when url provided is not valid
    assert ie._match_id('https://hitrecord.org/records') is None

    # Test case when url provided is valid
    assert ie._match_id('https://hitrecord.org/records/2954362') is not None

    # Test case when url provided is valid
    assert ie._match_id('https://hitrecord.org/records/2954362') == '2954362'

# Generated at 2022-06-12 17:35:58.423343
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  ie = HitRecordIE()
  assert isinstance(ie, HitRecordIE)

# Generated at 2022-06-12 17:36:14.275596
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie.__name__ == 'HitRecord'
    assert ie.__class__.__name__ == 'HitRecordIE'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-12 17:36:16.123837
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    expected = HitRecordIE
    assert HitRecordIE == expected


# Generated at 2022-06-12 17:36:17.324869
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test __init__()
    HitRecordIE()

# Generated at 2022-06-12 17:36:20.975050
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    url = "https://hitrecord.org/records/2954362"
    assert ie.suitable(url)
    assert ie.get_info(url) is not None

# Generated at 2022-06-12 17:36:23.550776
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:36:28.014623
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Simple unit test to check if constructing object of class HitRecordIE works
    (without fetching the actual data from the website)
    """
    ie = HitRecordIE()
    ie.extract('https://www.hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:36:37.382101
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'HitRecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie.VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie.TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie.TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie.TEST['info_dict']['id'] == '2954362'
    assert ie.TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-12 17:36:39.160781
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:36:40.428807
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Initialize class object
    HitRecordIE()

# Generated at 2022-06-12 17:36:42.293052
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:37:09.969284
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-12 17:37:10.796294
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	print(HitRecordIE('test'))

# Generated at 2022-06-12 17:37:17.386437
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-12 17:37:27.703743
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-12 17:37:35.799448
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie.url == "https://hitrecord.org/records/2954362"

# Generated at 2022-06-12 17:37:36.236100
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:37:37.455229
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie_test = HitRecordIE()
    print(ie_test)



# Generated at 2022-06-12 17:37:37.948017
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:37:38.350485
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:37:40.971809
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-12 17:38:23.855471
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract("https://hitrecord.org/records/2954362")

# Generated at 2022-06-12 17:38:26.643435
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:38:27.122361
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:38:27.634368
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:38:28.619416
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:38:30.675432
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    a = HitRecordIE()
    assert a._VALID_URL == HitRecordIE._VALID_URL
    assert a._TEST == HitRecordIE._TEST


# Generated at 2022-06-12 17:38:31.156034
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:38:31.645679
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:38:33.237594
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    assert hitrecord == HitRecordIE
    assert hitrecord.ie_key() == 'hitrecord'

# Generated at 2022-06-12 17:38:35.991510
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit = HitRecordIE("https://hitrecord.org/records/2954362")
    assert hit._match_id("https://hitrecord.org/records/2954362") == '2954362'



# Generated at 2022-06-12 17:40:05.504419
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:40:10.711186
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:40:13.379820
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('http://www.hitrecord.org/records/2954362')
    assert ie._VALID_URL
    assert ie._TEST
    assert ie._real_extract

# Generated at 2022-06-12 17:40:14.489702
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:40:16.599070
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    ie = HitRecordIE()
    assert ie.suitable(url)
    assert 'ID of Video' in ie._real_extract(url)

# Generated at 2022-06-12 17:40:19.468623
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie._VALID_URL, compat_str)

# Generated at 2022-06-12 17:40:27.854774
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """ Test creation of HitRecordIE class and its functions """
    ie = HitRecordIE()
    ie.IE_NAME = 'hitrecord'
    ie.IE_DESC = 'HitRecord'
    ie.VALID_URL = ie._VALID_URL
    ie.assertIsInstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    ie.assertIsInstance(ie._TEST, dict)

# Generated at 2022-06-12 17:40:29.369896
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None, 'http://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:40:30.422452
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    i = HitRecordIE()
    print(i.extract(''))

# Generated at 2022-06-12 17:40:36.995202
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(None)._VALID_URL == HitRecordIE._VALID_URL
    assert HitRecordIE(None)._TEST == HitRecordIE._TEST
    assert HitRecordIE(None)._DOWNLOAD_WEBPAGE_METHOD == 'GET'
    assert HitRecordIE(None)._API_BASE_URL == 'https://hitrecord.org/api/web'
    assert HitRecordIE(None)._TITLE_REGEX == r'(?:<title>|, title: ")(?P<title>[^"]+)'
    assert HitRecordIE(None)._TITLE_REPLACEMENTS == [
        (r' - HitRecord$', '')
    ]
    assert HitRecordIE(None)._API_KEY_NOT_REQUIRED == True
    assert HitRecordIE(None)._GEO

# Generated at 2022-06-12 17:44:31.253465
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-12 17:44:33.192990
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except:
        return False
    return True

# Generated at 2022-06-12 17:44:38.316946
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE()
    assert info_extractor.IE_NAME == 'hitrecord'
    assert info_extractor._VALID_URL == HitRecordIE._VALID_URL
    info_extractor._VALID_URL = 'http://google.com'
    assert info_extractor._VALID_URL == 'http://google.com'
    assert info_extractor.__class__.__name__ == 'HitRecordIE'
    assert info_extractor._WORKING == True

# Generated at 2022-06-12 17:44:43.899691
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    HitRecordIE._TEST['url'] = 'https://hitrecord.org/records/2954362'
    url = 'https://hitrecord.org/records/2954362'
    HitRecordIE._TEST['urls'] = [url]
    assert(instance.suitable(url)) == True



# Generated at 2022-06-12 17:44:44.424726
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-12 17:44:45.491089
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_HitRecordIE = HitRecordIE()
    test_HitRecordIE

# Generated at 2022-06-12 17:44:45.964653
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-12 17:44:47.267489
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:44:48.852992
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video_url = 'https://hitrecord.org/records/2954362'
    HitRecordIE()._match_id(video_url)

# Generated at 2022-06-12 17:44:49.291874
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()