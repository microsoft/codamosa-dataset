

# Generated at 2022-06-12 17:35:33.755066
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.match('https://www.hitrecord.org/records/2954362')
    assert ie.match('https://hitrecord.org/records/2954362')
    assert ie.match('https://www.hitrecord.org/records/2954362')
    assert ie.match('https://hitrecord.org/records/2954362')
    assert ie.match('https://hitrecord.org/records/2954362')
    assert ie.match('https://hitrecord.org/records/2954362') == {'id': '2954362'}
    assert ie.match('https://hitrecord.org/records/2954362') == {'id': '2954362'}

# Generated at 2022-06-12 17:35:34.232746
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:35:35.251037
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # test
    HitRecordIE()

# Generated at 2022-06-12 17:35:44.819281
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:35:46.445893
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE



# Generated at 2022-06-12 17:35:47.236228
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie

# Generated at 2022-06-12 17:35:47.713350
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:35:48.250931
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:35:49.296933
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    #Create an object HitRecordIE
    HitRecordIE()

# Generated at 2022-06-12 17:35:52.121721
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable("https://hitrecord.org/records/2954362")
    assert ie.suitable("https://www.hitrecord.org/records/2954362")

# Generated at 2022-06-12 17:36:04.251927
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	#Instantiate "HitRecordIE" object
	test_HitRecordIE = HitRecordIE()
	#Test
	test_HitRecordIE._real_extract(test_HitRecordIE._TEST['url'])

# Generated at 2022-06-12 17:36:06.660041
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE({'url': HitRecordIE._TEST['url'], 'record': HitRecordIE._VALID_URL}, None)
    assert ie.url == HitRecordIE._TEST['url']
    assert ie.video_id == '2954362'

# Generated at 2022-06-12 17:36:08.358962
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:36:11.204432
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	url = 'https://hitrecord.org/records/2954362'
	inst = HitRecordIE()
	inst.initialize(url)
	inst.extract()
	print(inst.extract())

# Generated at 2022-06-12 17:36:11.849394
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:36:16.132395
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    # test for info_dict
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-12 17:36:18.421450
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-12 17:36:20.777217
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362') == True

# Generated at 2022-06-12 17:36:23.358047
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:36:27.585559
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    v = HitRecordIE(compat_str(test_HitRecordIE.__name__))
    try:
        v.suite()
    except Exception as e:
        assert False, "Exception raised: " + str(e)

# Generated at 2022-06-12 17:36:55.422149
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record = HitRecordIE()
    url = "https://hitrecord.org/records/2954362"
    info = hit_record._real_extract(url)
    assert(info['title'] == "A Very Different World (HITRECORD x ACLU)")
    assert(info['id'] == "2954362")
    assert(info['url'] == "https://aes.hitrecord.org/video/4891328/source/mp4")

# Generated at 2022-06-12 17:36:56.875312
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE(): # pylint: disable=missing-docstring
    HitRecordIE()

# Generated at 2022-06-12 17:36:57.444558
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:37:06.706162
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    info = ie._real_extract('https://hitrecord.org/records/2954362')
    assert info['id'] == '2954362'
    assert info['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert info['description'] == 'md5:e62defaffab5075a5277736bead95a3d'
    assert info['duration'] == 139.327
    assert info['url'] == 'https://hitrecord.org/uploads/video/file/2954362/A_VERY_DIFFERENT_WORLD_HITRECORD_x_ACLU_H264_3_MBPS_720p_0100.mp4'
    assert info['upload_date'] == '20160818'
    assert info['timestamp'] == 147155

# Generated at 2022-06-12 17:37:07.429907
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:37:09.769477
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Constructor test
    HitRecordIE('https://hitrecord.org/records/2954362');

# Generated at 2022-06-12 17:37:17.208656
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    _VALID_URL = r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:37:20.443030
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('HitRecordIE.get_video_info', HitRecordIE._TEST['url'])

# Generated at 2022-06-12 17:37:22.859472
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("")
    assert ie.IE_NAME == "HitRecord"
    assert ie.VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:37:27.199372
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # test 1
    url = HitRecordIE._VALID_URL
    reObj = HitRecordIE._VALID_URL_RE
    matchObj = reObj.match(url)
    assert matchObj is not None
    assert matchObj.group(0) == 'https://hitrecord.org/records/2954362'
    assert matchObj.group('id') == '2954362'

# Generated at 2022-06-12 17:38:06.158833
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()



# Generated at 2022-06-12 17:38:08.329825
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print("HitRecordIE.__name__ = " + HitRecordIE.__name__)

# Generated at 2022-06-12 17:38:14.207064
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:38:20.496321
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie.valid_url("https://hitrecord.org/records/2954362")
    assert not ie.valid_url("https://hitrecord.org/records/295436")
    assert not ie.valid_url("https://hitrecord.org")
    assert not ie.valid_url("https://not.hitrecord.org/records/2954362")

# Generated at 2022-06-12 17:38:21.239426
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:38:23.428396
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract("https://hitrecord.org/records/2954362")

# Generated at 2022-06-12 17:38:25.463061
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('xyz')._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-12 17:38:26.101660
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:38:31.685534
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-12 17:38:33.012219
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._download_json.__name__ == 'HitRecordIE._download_json'

# Generated at 2022-06-12 17:40:07.324134
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:40:08.485652
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # test class initialization
    if not ie == None:
        return True
    return False

# Generated at 2022-06-12 17:40:17.318017
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_HitRecordIE.__name__ = 'test_HitRecordIE'

    test_HitRecordIE.test_HitRecordIE = test_HitRecordIE
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST is not None

# Generated at 2022-06-12 17:40:24.223834
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'hitrecord.org'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:40:29.178759
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:40:29.945343
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()

# Generated at 2022-06-12 17:40:32.872238
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(_VALID_URL)
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:40:33.316256
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE

# Generated at 2022-06-12 17:40:39.206479
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    vid = HitRecordIE('https://hitrecord.org/records/2954362')
    assert(vid)
    assert(vid.video_id)
    assert('info' in vid)
    assert(vid.video_id == '2954362')
    assert(vid.video_url)
    assert(vid.duration == 139.327)
    assert(vid.timestamp == 1471557582)
    assert(vid.uploader == 'Zuzi.C12')
    assert(vid.uploader_id == '362811')
    assert(vid.view_count > 0)
    assert(vid.like_count > 0)
    assert(vid.comment_count > 0)
    assert(vid.tags)
    assert(vid.tags[0] == 'hitrecord')

# Generated at 2022-06-12 17:40:39.797195
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    iExtractor = HitRecordIE()



# Generated at 2022-06-12 17:42:34.058630
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL
    assert len(HitRecordIE()._TEST) == 3
    assert HitRecordIE()._TEST['url'] == HitRecordIE._TEST['url']
    assert HitRecordIE()._TEST['md5'] == HitRecordIE._TEST['md5']
    assert len(HitRecordIE()._TEST['info_dict']) == 13


# Generated at 2022-06-12 17:42:35.455238
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:42:37.224765
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    class_name = HitRecordIE.__name__
    assert class_name == 'HitRecordIE'



# Generated at 2022-06-12 17:42:40.078101
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    url = 'https://hitrecord.org/records/2954362'
    info = ie._real_extract(url)
    id = '2954362'
    assert info['id'] == id
    assert info['url'] == 'https://distribution.hitrecord.org/video/mp4/%s/source.mp4' % id

# Generated at 2022-06-12 17:42:41.926586
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE(None)
    except Exception as e:
        print(e)
        assert False

if __name__ == '__main__':

    test_HitRecordIE()

# Generated at 2022-06-12 17:42:43.560407
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:42:45.393445
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # This is a simple unit test for the constructor of this class
    hre1 = HitRecordIE()
    assert hre1.ie_key() == "HitRecord"

# Generated at 2022-06-12 17:42:47.488230
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
   ie = HitRecordIE();
   ie._download_json('https://hitrecord.org/api/web/records/2954362', 2954362);
   ie._real_extract('https://hitrecord.org/records/2954362');

# Generated at 2022-06-12 17:42:53.151880
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:42:54.014384
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert isinstance(HitRecordIE(None), HitRecordIE)