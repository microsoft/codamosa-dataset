

# Generated at 2022-06-12 17:35:23.044837
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:35:25.432003
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')
    # This is a test extractor, no test of the actual IE
    assert(1)

# Generated at 2022-06-12 17:35:25.979203
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE

# Generated at 2022-06-12 17:35:27.566933
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie is not None

# Generated at 2022-06-12 17:35:27.956988
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:35:30.459473
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:35:38.699986
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Unit test for class HitRecordIE"""
    ie = HitRecordIE()
    ie_app = ie.app
    ie_app.pgctl = ie.pgctl
    ie_app.cfg = ie.cfg
    ie_app.db_conn = ie.db_conn
    ie_app.logger = ie.logger
    ie._extract_item = ie.extract_item
    ie._real_extract = ie.real_extract
    ie.url = ie.VALID_URL
    ie.init()

    ie.test()
    assert ie.url == HitRecordIE.VALID_URL, "invalid URL"
    assert ie.valid_url(ie.url), "invalid URL"
    assert ie.valid_url(ie.VALID_URL), "invalid URL"

# Generated at 2022-06-12 17:35:39.573637
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('hitrecord', 'hitrecord.org')

# Generated at 2022-06-12 17:35:44.874542
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-12 17:35:47.821736
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("unit testing")
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-12 17:35:53.279901
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    x = HitRecordIE(None)

# Generated at 2022-06-12 17:36:02.703400
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE('https://www.hitrecord.org/records/2954362')
    info = info_extractor._real_extract('https://www.hitrecord.org/records/2954362')
    assert info_extractor is not None
    assert info is not None
    assert 'id' in info.keys()
    assert 'title' in info.keys()
    assert 'url' in info.keys()
    assert 'uploader' in info.keys()
    assert 'uploader_id' in info.keys()
    assert 'like_count' in info.keys()
    assert 'comment_count' in info.keys()
    assert 'view_count' in info.keys()
    assert 'duration' in info.keys()
    assert 'timestamp' in info.keys()

# Generated at 2022-06-12 17:36:03.794533
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.set_downloader(None)

# Generated at 2022-06-12 17:36:04.940991
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_video = HitRecordIE()
    assert test_video

# Generated at 2022-06-12 17:36:11.110823
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    if not HitRecordIE.suitable('https://hitrecord.org/records/2954362'):
        print(HitRecordIE.suitable('https://hitrecord.org/records/2954362'))
        print("Error in unit_test for constructor of class HitRecordIE")


# Generated at 2022-06-12 17:36:13.170085
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    global HitRecordIE
    assert(HitRecordIE is not None)

# Generated at 2022-06-12 17:36:13.818826
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:36:17.138889
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    e = HitRecordIE()
    e.suitable('http://hitrecord.org/records/2954362')
    e.extract('http://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:36:18.379136
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:36:20.736092
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:36:31.025802
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-12 17:36:31.589623
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-12 17:36:32.861890
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	"""test the HitRecordIE class constructor"""

	HitRecordIE()

# Generated at 2022-06-12 17:36:34.139337
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("http://hitrecord.org/records/2954362")

# Generated at 2022-06-12 17:36:34.767388
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-12 17:36:37.550428
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL

# Generated at 2022-06-12 17:36:48.024407
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.SUITES == HttpSigAuthIE.SUITES
    # assert ie.IE_NAME returns the class name
    ie_name_returns_class_name = ie.IE_NAME is HitRecordIE.__name__
    assert ie_name_returns_class_name
    # assert ie._VALID_URL is the regex for matching the url
    assert ie._VALID_URL is HitRecordIE._VALID_URL
    # assert HitRecordIE._TEST is a dictionary containing url, md5, and info_dict
    assert isinstance(HitRecordIE._TEST, dict)
    # assert HitRecordIE._TEST['url'] is the url
    assert isinstance(HitRecordIE._TEST['url'], str)
    # assert HitRecordIE._TEST['md5']

# Generated at 2022-06-12 17:36:53.287488
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    e = HitRecordIE()
    assert e.extract_id(
        'https://hitrecord.org/records/2954362') == "2954362"
    assert e.extract_id('http://hitrecord.org/records/2954362') == "2954362"

# Generated at 2022-06-12 17:36:54.673379
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:36:55.322440
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:37:18.460161
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Test for constructor of class HitRecordIE
    """
    url = 'https://hitrecord.org/records/2954362'
    hitrecord = HitRecordIE()
    match = hitrecord._match_id(url)
    IE_name = hitrecord._real_extract(url)
    assert match == '2954362'
    assert IE_name == "A Very Different World (HITRECORD x ACLU)"

# Generated at 2022-06-12 17:37:22.482223
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_ie = HitRecordIE()
    assert hitrecord_ie._VALID_URL == HitRecordIE.__dict__['_VALID_URL']
    assert HitRecordIE.__dict__['_TEST'] == HitRecordIE._TEST

# Generated at 2022-06-12 17:37:23.128652
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-12 17:37:23.529247
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:37:24.934509
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE()

# Generated at 2022-06-12 17:37:26.526467
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert ie is not None

# Generated at 2022-06-12 17:37:27.063687
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:37:28.586311
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(HitRecordIE._VALID_URL, HitRecordIE._TEST, HitRecordIE._TEST)

# Generated at 2022-06-12 17:37:33.053740
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("hitrecord.org", "https://hitrecord.org/records/2954362")
    assert ie.name == "HitRecord"
    assert ie.ie_key() == "hitrecord"
    assert ie.webpage_url == "https://hitrecord.org/records/2954362"
    assert ie.get_urls_info() is None

# Generated at 2022-06-12 17:37:36.766319
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    IE_test = HitRecordIE()
    assert IE_test._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:38:23.478779
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert(ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')
    assert(ie._TEST['url'] == 'https://hitrecord.org/records/2954362')
    assert(ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71')
    assert(ie._TEST['info_dict']['id'] == '2954362')
    assert(ie._TEST['info_dict']['ext'] == 'mp4')
    assert(ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)')


# Generated at 2022-06-12 17:38:26.231399
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(None)._VALID_URL == HitRecordIE._VALID_URL
    assert HitRecordIE(None)._TEST == HitRecordIE._TEST
    assert HitRecordIE(None)._real_extract(HitRecordIE(None)._TEST['url'])

# Generated at 2022-06-12 17:38:27.318849
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    assert hitrecord.extractor_key == " Hit Record"

# Generated at 2022-06-12 17:38:27.937550
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-12 17:38:29.472490
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    assert(isinstance(hitRecordIE, InfoExtractor))

# Generated at 2022-06-12 17:38:31.185717
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print("Unit Test for class HitRecordIE")
    testObj = HitRecordIE()
    print("%s" % str(testObj))

# Generated at 2022-06-12 17:38:37.377515
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('http://hitrecord.org/records/2954362')
    assert ie.url == 'http://hitrecord.org/records/2954362'
    assert ie.video_id == '2954362'
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    ie = HitRecordIE('http://www.hitrecord.org/records/2954362')
    assert ie.url == 'http://www.hitrecord.org/records/2954362'
    assert ie.video_id == '2954362'


# Generated at 2022-06-12 17:38:39.905070
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    print(hitRecordIE.supported_in())
    print(hitRecordIE._VALID_URL)
    for k, v in hitRecordIE._TEST.items():
        print (k, v)

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-12 17:38:41.352109
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    if __name__ == '__main__':
        import unittest
        unittest.main()

# Generated at 2022-06-12 17:38:43.255203
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.supported_extractors() == ['HitRecord']

# Generated at 2022-06-12 17:40:13.261969
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # pylint: disable=redefined-outer-name
    global HitRecordIE
    # pylint: enable=redefined-outer-name

    assert HitRecordIE is not None

# Generated at 2022-06-12 17:40:21.719486
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == 'https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)'

# Generated at 2022-06-12 17:40:23.896342
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE("https://www.hitrecord.org/records/2954362")

# Generated at 2022-06-12 17:40:25.547733
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('https://hitrecord.org/records/2954362')


# Generated at 2022-06-12 17:40:25.995906
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:40:28.342253
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    x = HitRecordIE(None)
    assert x == x

# Generated at 2022-06-12 17:40:28.904433
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:40:35.849611
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-12 17:40:36.524953
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    rie = HitRecordIE()

# Generated at 2022-06-12 17:40:36.965856
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:44:28.339067
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:44:38.021029
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:44:41.658138
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Unit test for constructor of class HitRecordIE
    url = 'https://hitrecord.org/records/2954362'
    HitRecordIE(url)

# Generated at 2022-06-12 17:44:42.190998
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:44:49.711246
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video = HitRecordIE()._real_extract(HitRecordIE._TEST['url'])
    assert(video['title'] == HitRecordIE._TEST['info_dict']['title'])
    assert(video['id'] == HitRecordIE._TEST['info_dict']['id'])
    assert(video['url'] == HitRecordIE._TEST['info_dict']['url'])
    assert(video['ext'] == HitRecordIE._TEST['info_dict']['ext'])
    assert(video['description'] == HitRecordIE._TEST['info_dict']['description'])
    assert(video['duration'] == HitRecordIE._TEST['info_dict']['duration'])

# Generated at 2022-06-12 17:44:54.832537
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-12 17:45:00.326720
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:45:01.102288
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except ValueError:
        pass

# Generated at 2022-06-12 17:45:02.149692
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie
    assert ie._VALID_URL
    assert ie._TEST

# Generated at 2022-06-12 17:45:03.456517
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	test_HitRecordIE = HitRecordIE()
	test_HitRecordIE
	return test_HitRecordIE