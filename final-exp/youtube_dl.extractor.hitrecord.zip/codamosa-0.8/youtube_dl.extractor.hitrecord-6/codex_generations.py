

# Generated at 2022-06-12 17:35:23.551506
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

test_HitRecordIE()

# Generated at 2022-06-12 17:35:31.720254
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('http://www.hitrecord.org/records/123456')
    assert ie.id == '123456'
    assert ie.url == 'http://www.hitrecord.org/records/123456'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:35:34.419862
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Initial test to make sure that the class HitRecordIE is constructed
    """
    # Arrange
    ie = HitRecordIE()
    # Act
    # Assert
    assert type(ie) is HitRecordIE

# Generated at 2022-06-12 17:35:37.280373
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(InfoExtractor())
    print(ie.IE_NAME)
    assert_equal(ie.IE_NAME, 'HitRecord')



# Generated at 2022-06-12 17:35:38.222529
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Constructor of class HitRecordIE.
    """
    HitRecordIE()

# Generated at 2022-06-12 17:35:39.413930
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('http://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:35:42.567784
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord:record'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == HitRecordIE._VALID_URL


# Generated at 2022-06-12 17:35:44.438253
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'http://hitrecord.org/records/2954362'
    hitRecordIE = HitRecordIE()
    print(hitRecordIE.extract(url))



# Generated at 2022-06-12 17:35:49.252136
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	try:
		ie = HitRecordIE()
	except Exception as e:
		raise AssertionError # Need to do this in order to get output
		# print("HitRecordIE() throws exception: " + str(e))
		# assert False



# Generated at 2022-06-12 17:35:49.852730
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:36:00.776467
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

if __name__ == "__main__":
    test_HitRecordIE()

# Generated at 2022-06-12 17:36:02.140929
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test basic construction
    HitRecordIE(None)

# Generated at 2022-06-12 17:36:02.633210
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:36:03.657318
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record = HitRecordIE()
    assert type(hit_record) == HitRecordIE

# Generated at 2022-06-12 17:36:06.789164
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# GIVEN
	url = 'https://hitrecord.org/records/2954362'

	# WHEN
	test_video = HitRecordIE()

	# THEN
	assert test_video._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
	assert test_video._TEST['url'] == 'https://hitrecord.org/records/2954362'
	assert test_video._TEST['info_dict']['id'] == '2954362'

# Generated at 2022-06-12 17:36:07.604254
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:36:10.075568
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Unit test for the constructor of HitRecordIE class
    """
    # Instance creation
    HitRecordIE()

    # Throws assertion error if url doesn't match the regular expression
    # pylint: disable=no-member
    assert_raises(RegexMatchError, HitRecordInfoExtractor, 'http://youtu.be/watch')

# Generated at 2022-06-12 17:36:11.645614
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:36:13.711828
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except:
        assert False

# Generated at 2022-06-12 17:36:17.059525
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._downloader.http.close()
    ie.http.close()
    return ie

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-12 17:36:46.858619
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    UnitTest = HitRecordIE()
    assert UnitTest._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:36:47.656687
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:36:49.497100
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:36:51.790450
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:36:52.352915
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:36:57.179670
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://hitrecord.org/records/2954362#?sortBy=rating&sortOrder=DESC')

# Generated at 2022-06-12 17:36:57.749753
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-12 17:36:58.652873
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE("")


# Generated at 2022-06-12 17:37:01.165913
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:37:06.113682
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL
    HitRecordIE._download_json = lambda *args: {
        'source_url': {'mp4_url': 'https://example.com/video.mp4'}
    }
    HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:37:46.290307
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.__class__.__name__ == "HitRecordIE"

# Generated at 2022-06-12 17:37:47.286854
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    t = HitRecordIE()

# Generated at 2022-06-12 17:37:48.943215
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ''' Unit test for constructor of class HitRecordIE '''
    assert HitRecordIE()

# Generated at 2022-06-12 17:37:50.299374
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print("Testing HitRecordIE - constructor")
    ie = HitRecordIE()
    ie.extract(url="https://hitrecord.org/records/2954362")


# Generated at 2022-06-12 17:37:50.740273
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	pass

# Generated at 2022-06-12 17:37:52.020924
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE()
    assert hitRecord is not None


# Generated at 2022-06-12 17:37:52.717057
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:37:54.028803
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(2954362)

# Generated at 2022-06-12 17:37:54.577512
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:38:05.841935
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'
    assert ie.ie_key() == 'HitRecord'
    assert ie.video_id_re() == [r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)']
    assert ie.extract_urls('https://hitrecord.org/records/2954362') == ['https://hitrecord.org/records/2954362']
    assert ie.url_result('https://hitrecord.org/records/2954362') == 'https://hitrecord.org/records/2954362'
    assert ie.suitable('https://hitrecord.org/records/2954362') == True

# Generated at 2022-06-12 17:38:58.296337
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test = HitRecordIE()
    print(test)

# Generated at 2022-06-12 17:38:59.490052
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()



# Generated at 2022-06-12 17:39:08.197896
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:39:10.126609
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:39:20.146683
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    assert hitrecord._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:39:22.159206
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'

# Generated at 2022-06-12 17:39:30.674963
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:39:31.178515
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:39:32.237139
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(HitRecordIE._TEST['url'])

# Generated at 2022-06-12 17:39:34.881909
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Unit test for constructor of HitRecordIE class
    """
    hitRecord_ie = HitRecordIE()
    assert hitRecord_ie

# Generated at 2022-06-12 17:41:30.165291
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract("http://hitrecord.org/records/2954362")

if __name__ ==  "__main__":
    test_HitRecordIE()

# Generated at 2022-06-12 17:41:34.035335
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    #basic test
    ie = HitRecordIE()
    url = 'https://hitrecord.org/records/2954362'
    md5 = 'fe1cdc2023bce0bbb95c39c57426aa71'
    ie.extract(url)
    # This is a stub test. Just assume everything runs OK
    assert ie.extract(url).get('md5') == md5

# Generated at 2022-06-12 17:41:35.457424
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, HitRecordIE)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:41:40.938375
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')
    assert hitrecord['id'] == '2954362'
    assert hitrecord['url'] == 'https://hitrecord.org-production.s3.amazonaws.com/record_videos/2954362.mp4?ETag=%22d41d8cd98f00b204e9800998ecf8427e%22&Expires=1588771441&AWSAccessKeyId=AKIAJS4Y4YOPR7RNSIVA&Signature=%2BpfbAszgNhqZa%2BVX9Yt%2FBdz1Bgw%3D'
    assert hitrecord['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-12 17:41:44.657758
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-12 17:41:47.026493
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL
    assert HitRecordIE()._TEST == HitRecordIE._TEST

# Generated at 2022-06-12 17:41:47.579085
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-12 17:41:55.140903
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"

# Generated at 2022-06-12 17:41:56.551462
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_ie = HitRecordIE()
    print(hitrecord_ie)
    assert hitrecord_ie is not None

# Generated at 2022-06-12 17:42:04.759507
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE()
    assert hitRecord.IE_NAME == 'hitrecord'
    assert hitRecord._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert hitRecord._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert hitRecord._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    expected_keys = [
        'id', 'ext', 'title', 'description', 'duration', 'timestamp', 'upload_date', 'uploader', 'uploader_id',
        'view_count', 'like_count', 'comment_count', 'tags'
    ]