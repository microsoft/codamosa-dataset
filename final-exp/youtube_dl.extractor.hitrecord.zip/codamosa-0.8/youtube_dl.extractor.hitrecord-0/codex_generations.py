

# Generated at 2022-06-12 17:35:29.886570
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    infoExtractor = HitRecordIE()
    assert(infoExtractor._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-12 17:35:36.141170
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        import nose.tools as nose_tools
        import urllib.parse as urlparse
    except ImportError:
        return

    # Constructor with empty URL
    nose_tools.eq_(InfoExtractor({})._VALID_URL, None,
                   msg="Empty constructor allowed")

    # Constructor with invalid URL
    nose_tools.eq_(InfoExtractor({
        'url': 'https://hitrecord.org'
    })._VALID_URL, None, msg="Empty constructor allowed")


# Generated at 2022-06-12 17:35:38.320392
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_hitRecordIE = HitRecordIE.HitRecordIE(None)
    assert test_hitRecordIE is not None

# Generated at 2022-06-12 17:35:41.742574
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    sound_url = 'https://hitrecord.org/records/2954362'
    test_dict = {'url': sound_url}
    HitRecordIE()._download_json(
        test_dict['url'],
        HitRecordIE()._match_id(sound_url))

# Generated at 2022-06-12 17:35:42.301497
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-12 17:35:44.577219
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    ie.extract("https://hitrecord.org/records/2954362")

# Generated at 2022-06-12 17:35:48.147010
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    i = HitRecordIE()
    assert i.IE_NAME == 'HitRecord'
    assert i.IE_DESC == 'HitRecord'
    assert i._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert isinstance(i, InfoExtractor)

# Generated at 2022-06-12 17:35:48.600999
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-12 17:35:49.076389
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:35:50.038440
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	hit_record = HitRecordIE()

# Generated at 2022-06-12 17:36:00.458594
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, HitRecordIE)

# Generated at 2022-06-12 17:36:01.286994
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(1, 1, 2)

# Generated at 2022-06-12 17:36:01.997106
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-12 17:36:02.771734
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._download_json

# Generated at 2022-06-12 17:36:03.586696
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(HitRecordIE._VALID_URL)

# Generated at 2022-06-12 17:36:04.323533
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    print(ie)

# Generated at 2022-06-12 17:36:05.240042
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_ie = HitRecordIE()
    assert isinstance(test_ie, HitRecordIE)

# Generated at 2022-06-12 17:36:06.093503
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE._TEST

# Generated at 2022-06-12 17:36:11.285067
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE
    HitRecordIE
    assert HitRecordIE.__name__ == 'HitRecordIE'
    assert HitRecordIE.__module__ == 'youtube_dl.extractor.hitrecord'

# Generated at 2022-06-12 17:36:11.902065
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:36:29.591347
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:36:31.495347
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    if ie._VALID_URL is "":
        assert(0)

# Generated at 2022-06-12 17:36:33.065237
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:36:33.962727
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-12 17:36:37.990815
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:36:41.351973
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')

# Unit tests for the methods of class HitRecordIE

# Generated at 2022-06-12 17:36:41.979002
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-12 17:36:43.559616
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:36:45.961849
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:36:52.963336
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-12 17:37:37.136441
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE()

    assert(info_extractor._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-12 17:37:39.179862
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('http://www.hitrecord.org/records/2954362')


if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-12 17:37:39.662657
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:37:46.459150
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    testUrl = 'https://hitrecord.org/records/2954362'
    ie = HitRecordIE(testUrl)
    assert ie is not None
    assert ie.url == testUrl
    assert ie.ie_key() == 'HitRecord'
    assert ie.video_id == '2954362'
    assert ie.video_url == 'https://hitrecord.org/records/2954362'
    assert ie.video_info is None
    assert ie.init_video_info() == True # Successfully get video info from url
    assert isinstance(ie.video_info, HitRecordVideoInfo)
    assert ie.video_info.video_id == '2954362'
    assert ie.video_info.url == testUrl

# Generated at 2022-06-12 17:37:47.812333
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()
    assert(True)

# Generated at 2022-06-12 17:37:57.423157
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # check the constructor of class HitRecordIE
    HitRecordIE('https://hitrecord.org/records/2954362', 'HitRecordIE', 'HitRecordIE')
    # check the value of _VALID_URL 
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    # check the value of _TEST

# Generated at 2022-06-12 17:37:58.753120
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    x = HitRecordIE()

# Generated at 2022-06-12 17:38:02.423107
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')



# Generated at 2022-06-12 17:38:04.352437
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    expected_results = 'hitrecord'
    assert ie._VALID_URL == expected_results

# Generated at 2022-06-12 17:38:05.107151
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:39:31.279715
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TEST['url'] == ie.get_test_url()
    assert ie._TEST['md5'] == ie.get_test_md5()
    assert ie._TEST['info_dict'] == ie.get_test_info_dict()

# Generated at 2022-06-12 17:39:36.292617
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.constructor_enabled = False
    # Test if the URL is of the right type (a HitRecord record)
    assert ie.evaluate_url('https://hitrecord.org/records/2954362')

    # Test if the URL is of a wrong type (not a HitRecord record)
    assert not ie.evaluate_url('https://hitrecord.org')

# Generated at 2022-06-12 17:39:43.267581
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-12 17:39:44.301161
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('http://hitrecord.org/records/1950611')

# Generated at 2022-06-12 17:39:47.080821
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL.match('https://hitrecord.org/records/2954362')
    assert HitRecordIE._VALID_URL.match('http://hitrecord.org/records/2954362')
    assert not HitRecordIE._VALID_URL.match('http://hitrecord.org/records')

# Generated at 2022-06-12 17:39:47.515588
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:39:48.265333
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    print(ie)

# Generated at 2022-06-12 17:39:50.382876
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('HitRecordIE', 'http://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:39:51.500348
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME in ie._VALID_URL

# Generated at 2022-06-12 17:39:59.415415
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:43:32.954367
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	pass

# Generated at 2022-06-12 17:43:38.585196
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'

# Generated at 2022-06-12 17:43:40.600080
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:43:42.880756
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert not ie.suitable('asdasdad')

# Generated at 2022-06-12 17:43:43.998674
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie != None


# Generated at 2022-06-12 17:43:46.177794
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Note that this scraper is basically unusable with the current implementation
    because it depends of javascript/flash stuff, so it will always fail.
    """
    HitRecordIE()
    return True


# Generated at 2022-06-12 17:43:46.626378
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:43:47.110397
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    HitRecordIE()

# Generated at 2022-06-12 17:43:47.814768
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE._VALID_URL

# Generated at 2022-06-12 17:43:48.895795
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord_obj = HitRecordIE()
    assert(isinstance(hitRecord_obj, InfoExtractor))