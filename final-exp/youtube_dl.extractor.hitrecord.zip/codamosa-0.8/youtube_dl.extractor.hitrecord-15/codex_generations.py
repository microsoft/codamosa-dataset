

# Generated at 2022-06-12 17:35:25.210063
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:35:27.566474
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-12 17:35:36.951346
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test for valid URL
    HitRecordIE_test = HitRecordIE()
    result = HitRecordIE_test._real_extract(HitRecordIE_test._TEST['url'])
    assert(result['id'] == '2954362')
    assert(result['url'] == 'https://hitrecord-post-production.s3.amazonaws.com/files/recordings/2954362/mp4/2954362_1473959976.mp4')
    assert(result['title'] == 'A Very Different World (HITRECORD x ACLU)')

# Generated at 2022-06-12 17:35:42.428350
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.IE_NAME = 'HitRecord'
    ie.VALID_URL = HitRecordIE._VALID_URL
    ie._TESTS = HitRecordIE._TEST
    ie._TESTS.update({'skip': 'uses non-static video urls'})

    # test youtube-dl logic
    assert ie.IE_NAME == 'HitRecord'
    assert ie.VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TESTS['url'] == 'https://hitrecord.org/records/2954362'

    return ie

# Generated at 2022-06-12 17:35:43.018119
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:35:50.649573
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert hasattr(ie, '_TEST')

# Generated at 2022-06-12 17:35:56.325277
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.suitable('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL

    assert ie._TEST
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-12 17:36:04.963003
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test for properties of class HitRecordIE
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:36:05.478655
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:36:06.016371
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:36:13.222414
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:36:17.017930
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('HitRecord', 'hitrecord', 'mp4')
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:36:26.412835
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Unit test for HitRecordIE class"""
    ie = HitRecordIE()
    test_info = ie._TEST
    assert ie._VALID_URL == test_info['url']
    assert ie._real_extract(test_info['url'])['id'] == test_info['info_dict']['id']
    assert ie._real_extract(test_info['url'])['title'] == test_info['info_dict']['title']
    assert ie._real_extract(test_info['url'])['description'] == test_info['info_dict']['description']
    assert ie._real_extract(test_info['url'])['duration'] == test_info['info_dict']['duration']
    assert ie._real_extract(test_info['url'])['timestamp'] == test

# Generated at 2022-06-12 17:36:27.379379
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE = HitRecordIE()

# Generated at 2022-06-12 17:36:29.790097
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Unit test checking if object of class HitRecordIE is created if the URL is
    correct.
    """
    HitRecordIE()

# Generated at 2022-06-12 17:36:32.490234
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie.url == 'https://hitrecord.org/records/2954362'

# Generated at 2022-06-12 17:36:34.671093
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert 'HitRecord' in HitRecordIE.__name__
    ie = HitRecordIE()
    assert ie is not None

# Generated at 2022-06-12 17:36:37.397739
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362", {})

# Generated at 2022-06-12 17:36:39.160342
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('HitRecordIE', 'www.hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:36:43.805591
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    class_ = HitRecordIE('', 'www.hitrecord.org')
    get_info = class_.get_info
    unit_test = _TEST
    get_info(
        'https://hitrecord.org/records/2954362'
    )

# Generated at 2022-06-12 17:36:55.059054
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:36:55.673863
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:36:57.829640
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE.HitRecordIE(
        'https://hitrecord.org/records/2954362', './')
    assert hitRecord.url == 'https://hitrecord.org/records/2954362'
    assert hitRecord.video_id == '2954362'
    assert hitRecord.dest == './'


# Generated at 2022-06-12 17:37:07.050542
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:37:07.779309
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)


# Generated at 2022-06-12 17:37:09.768910
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ie = HitRecordIE()
	assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:37:16.612405
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test for default values of class
    # This will instantiate a HitRecordIE object
    ie = HitRecordIE()
    # Check if the values of class variables are assigned as expected
    assert ie._VALID_URL == 'https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)'

# Generated at 2022-06-12 17:37:20.543051
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    a=HitRecordIE(HitRecordIE._VALID_URL)
    assert a._TEST['url']=='https://hitrecord.org/records/2954362'

# Generated at 2022-06-12 17:37:21.984810
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    assert isinstance(hitrecord, HitRecordIE)

# Generated at 2022-06-12 17:37:23.037680
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie != None)

# Generated at 2022-06-12 17:37:46.234533
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    assert ie.extract_id(ie._TEST['url']) == ie._TEST['id']
    assert ie._VALID_URL == ie._TEST['url']

# Generated at 2022-06-12 17:37:48.370032
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE().suitable('https://hitrecord.org/records/2954362') == True

# Generated at 2022-06-12 17:37:48.853927
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(InfoExtractor)

# Generated at 2022-06-12 17:37:49.341533
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-12 17:37:51.069916
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL


# Generated at 2022-06-12 17:37:51.656209
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
        return HitRecordIE()

# Generated at 2022-06-12 17:37:53.938148
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-12 17:37:55.157624
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert type(ie) == HitRecordIE

# Generated at 2022-06-12 17:37:56.932744
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert isinstance(ie, HitRecordIE)

# Generated at 2022-06-12 17:38:03.894514
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_cases = (
        (None, None, 'https://hitrecord.org/records/2954362'),
        (None, None, 'https://www.hitrecord.org/records/2954362'),
        ('https://hitrecord.org/records/2954362', '2954362', None),
        ('https://www.hitrecord.org/records/2954362', '2954362', None),
    )
    for expected_url, expected_video_id, url_or_video_id in test_cases:
        ie = HitRecordIE(url_or_video_id)
        assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:38:54.212689
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test for constructor of HitRecordIE class
    info_extractor = HitRecordIE(False)
    assert 'hitrecord.org' == info_extractor._VALID_URL[4:18]

# Generated at 2022-06-12 17:39:04.702793
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie.suitable("""<a href="https://hitrecord.org/records/2954362" target="_blank"></a>"""))
    assert(not ie.suitable("""<a href="https://www.hitrecord.org/records/2954362" target="_blank"></a>"""))
    assert(not ie.suitable("""<a href="https://hitrecord.org/recordparks/2954362" target="_blank"></a>"""))
    assert(not ie.suitable("""<a href="https://hitrecord.org/records/295436" target="_blank"></a>"""))


# Generated at 2022-06-12 17:39:16.639094
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-12 17:39:19.025233
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():  # pylint: disable=redefined-outer-name
    ie = HitRecordIE()
    assert str(ie) == 'HitRecord'

# Generated at 2022-06-12 17:39:22.280012
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    '''
    Tests the constructor of HitRecordIE
    '''
    HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-12 17:39:23.704161
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    int_or_none(None)
    int_or_none("")

# Generated at 2022-06-12 17:39:31.819364
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    url_1 = 'https://hitrecord.org/records/2954362'
    url_2 = 'https://hitrecord.org/records/2954363'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == url_1
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-12 17:39:33.879014
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("HitRecordIE", "HitRecord")

# Generated at 2022-06-12 17:39:35.740388
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	try:
		_ = HitRecordIE()
	except:
		print('fail')
	else:
		print('pass')

# Generated at 2022-06-12 17:39:36.328845
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:41:30.034152
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:41:32.592600
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# To test download functionality, we just check if it can be initialized without throwing error
	assert HitRecordIE._VALID_URL is not None
	HitRecordIE("https://hitrecord.org/records/2954362")
	assert True

# Generated at 2022-06-12 17:41:33.355193
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:41:37.632056
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.extract('https://hitrecord.org/records/2954362') == {
        '_type': 'url_transparent',
        'url': 'https://hitrecord.org/records/2954362',
        'id': '2954362',
        'display_id': '2954362'
    }


# Generated at 2022-06-12 17:41:47.563708
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    assert hitrecord._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:41:50.483978
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# Create an instance of HitRecordIE
	ie = HitRecordIE()

	# Print the metadata
	print(ie._VALID_URL)
	print(ie._TEST)

# Generated at 2022-06-12 17:41:52.608116
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    res = HitRecordIE()
    assert (res.SUFFIX == '.org/records/')

# Generated at 2022-06-12 17:41:54.118121
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._download_json('https://hitrecord.org/api/web/records/2954362', '2954362')

# Generated at 2022-06-12 17:41:55.412796
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    obj = HitRecordIE()
    print(obj.extract(url))

# Generated at 2022-06-12 17:42:03.732345
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    global hitrecord_info_1
    HitRecordIE()
    hitrecord_info_1 = HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')
    assert(hitrecord_info_1['id'] == '2954362')
    assert(hitrecord_info_1['url'] == 'https://s3.amazonaws.com/hitrecord-public/record/mp4/2954362/a5d5c018-f1ae-11e5-9b77-0e4b4a4c4a12.mp4')
    assert(hitrecord_info_1['title'] == 'A Very Different World (HITRECORD x ACLU)')