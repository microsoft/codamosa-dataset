

# Generated at 2022-06-12 17:35:25.114669
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Constructor test for HitRecordIE
    """
    HitRecordIE()

# Generated at 2022-06-12 17:35:28.357951
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    '''
    A method that test constructor of class HitRecordIE.
    It tests if the object is created correctly.
    '''
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:35:32.488318
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie._TEST['url'] == ie._VALID_URL)
    assert(ie._TEST['md5'] == ie._TEST['info_dict']['md5'])

# Generated at 2022-06-12 17:35:35.896820
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362') == True
    assert ie.suitable('https://google.com/records/2954362') == False
    assert ie.suitable('https://hitrecord.org/') == False



# Generated at 2022-06-12 17:35:40.479171
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    assert(hitrecord._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')
    assert(hitrecord.IE_NAME == 'hitrecord')
    assert(hitrecord.IE_DESC == 'hitrecord')

# Generated at 2022-06-12 17:35:48.834976
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.__name__ == "Hit Record"
    assert ie.valid_url('https://hitrecord.org/records/2954362') == (
        ie.regex['url'] == ie._VALID_URL ) 
    assert ie.valid_url('https://hitrecord.org/records/2954362/test') == False
    assert ie.valid_url('https://hitrecord.org/records/?page=1') == False
    assert ie.valid_url('https://hitrecord.org/records/2954362/test') == False
    assert ie.valid_url('https://hitrecord.org/records/2954362') == True

# Generated at 2022-06-12 17:35:50.556527
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)._real_extract("https://hitrecord.org/records/2954362")

# Generated at 2022-06-12 17:35:57.428903
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL.match('https://hitrecord.org/records/2954362')
    assert HitRecordIE._VALID_URL.match('http://hitrecord.org/records/2954362')
    assert HitRecordIE._VALID_URL.match('http://www.hitrecord.org/records/2954362')
    assert not HitRecordIE._VALID_URL.match('http://www.hitrecord.org/videos/2954362')


# Generated at 2022-06-12 17:35:58.381634
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE


# Generated at 2022-06-12 17:35:59.288796
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test constructor
    HitRecordIE()

# Generated at 2022-06-12 17:36:05.561464
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Since class is final, and there are no other specializations of the class,
    # just call the constructor
    HitRecordIE()

# Generated at 2022-06-12 17:36:06.096812
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:36:17.099353
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    result = ie.extract("https://hitrecord.org/records/2954362")
    assert isinstance(result, dict)
    assert 'id' in result
    assert 'url' in result
    assert 'title' in result
    assert 'description' in result
    assert 'duration' in result
    assert 'timestamp' in result
    assert 'uploader' in result
    assert 'uploader_id' in result
    assert 'view_count' in result
    assert 'like_count' in result
    assert 'comment_count' in result
    assert 'tags' in result

# Generated at 2022-06-12 17:36:19.747025
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  info_extractor = HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:36:20.935511
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:36:23.196257
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# Test that HitRecordIE is instance of InfoExtractor
	assert(isinstance(HitRecordIE, InfoExtractor))



# Generated at 2022-06-12 17:36:26.398920
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    ie = HitRecordIE()
    ie.extract(url)

# Generated at 2022-06-12 17:36:27.823420
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE(None)
    assert obj is not None

# Generated at 2022-06-12 17:36:28.672666
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE();

# Generated at 2022-06-12 17:36:30.489103
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == ie._TEST['url']

# Generated at 2022-06-12 17:36:50.158436
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    if not hasattr(ie, '_VALID_URL'):
        raise AttributeError('Error: HitRecordIE misses an attribute')
    if not ie._VALID_URL or not ie._VALID_URL.strip():
        raise ValueError('Error: HitRecordIE has empty _VALID_URL attribute value')
    if not hasattr(ie, '_TEST'):
        raise AttributeError('Error: HitRecordIE misses an attribute')
    if not ie._TEST or not isinstance(ie._TEST, dict):
        raise ValueError('Error: HitRecordIE has empty _TEST attribute value')
    if not ie._TEST.get('url'):
        raise ValueError('Error: HitRecordIE has no url in its _TEST attribute')

# Generated at 2022-06-12 17:37:01.367212
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test case with valid url
    HitRecordIE._VALID_URL = \
    r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    hitRecordIE = HitRecordIE()

# Generated at 2022-06-12 17:37:03.612311
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('hitrecord')
    HitRecordIE('hitrecord', 'hitrecord')

# Generated at 2022-06-12 17:37:04.807951
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:37:06.973296
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-12 17:37:09.848082
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    H = HitRecordIE()
    class_name = H.__class__.__name__
    assert(class_name == "HitRecordIE")


# Generated at 2022-06-12 17:37:11.231332
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:37:13.898200
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    my_hitRecordIE = HitRecordIE()

    # To test url == url
    assert my_hitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'



# Generated at 2022-06-12 17:37:15.348252
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL
    assert ie._TEST
    assert ie._download_json

# Generated at 2022-06-12 17:37:16.950989
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Basic test to ensure constructor of the class HitRecordIE
    """
    obj = HitRecordIE()
    assert obj.ie_key() == 'hitrecord'

# Generated at 2022-06-12 17:37:37.047978
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert isinstance(ie, HitRecordIE)

# Generated at 2022-06-12 17:37:44.510489
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Create a HitRecordIE instance
    ie = HitRecordIE(None)

    assert ie.IE_NAME == HitRecordIE.IE_NAME

    # the HitRecordIE will take the URL and extract the video id from it.
    # format of the URL: https://hitrecord.org/records/ID_NUMBER
    # for example: https://hitrecord.org/records/2954362
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

    # Extract() method will start the extracting process.
    # the HitRecordIE will extract the URL, id and check if the video is downloadable

# Generated at 2022-06-12 17:37:49.604706
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)._real_initialize()
    HitRecordIE(None).suitable('https://www.hitrecord.org')
    HitRecordIE(None).extract('https://www.hitrecord.org/records', '123')
    HitRecordIE(None).extract('https://www.hitrecord.org/records/123')

# Generated at 2022-06-12 17:37:59.566035
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
        test_url = 'https://hitrecord.org/records/2954362'
        test_case = HitRecordIE()

        test_dict = test_case._real_extract(test_url)
        test_id = test_dict['id']
        test_title = test_dict['title']
        test_url = test_dict['url']
        test_desc = test_dict['description']
        test_dur = test_dict['duration']
        test_ts = test_dict['timestamp']
        test_up = test_dict['uploader']
        test_upid = test_dict['uploader_id']
        test_vc = test_dict['view_count']
        test_lc = test_dict['like_count']
        test_cc = test_dict['comment_count']

# Generated at 2022-06-12 17:38:04.060395
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-12 17:38:08.842215
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # Check if the url can be processed
    assert ie.suitable('https://hitrecord.org/records/2954362')

    # Check if it returns the correct id
    assert '2954362' == ie._match_id('https://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:38:10.120393
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(None).ie_key() == 'HitRecord'

# Generated at 2022-06-12 17:38:12.080020
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert type(HitRecordIE) == type(InfoExtractor)

# Generated at 2022-06-12 17:38:14.172571
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    IE = HitRecordIE(None)
    IE._real_extract('http://hitrecord.org/records/2954362')

# Generated at 2022-06-12 17:38:14.703847
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:39:08.199182
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert(ie._TEST.keys() == ['url', 'md5', 'info_dict'])

# Generated at 2022-06-12 17:39:09.553998
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract_info()

# Generated at 2022-06-12 17:39:10.273783
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:39:13.113527
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit = HitRecordIE()
    assert_equal(hit._VALID_URL, r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-12 17:39:13.886959
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:39:14.269747
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE

# Generated at 2022-06-12 17:39:16.486904
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('www.hitrecord.org/records/2954362')
    print(ie.get_metadata('hitrecord.org/records/2954362'))

# Generated at 2022-06-12 17:39:26.881696
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-12 17:39:29.269738
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video_id = '2954362'
    url = 'http://hitrecord.org/records/' + video_id

    i = HitRecordIE(url)
    assert i._VALID_URL == url

# Generated at 2022-06-12 17:39:35.912359
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    # Test HitRecordIE object
    tests = [
        "https://hitrecord.org/records/2954362",
        "https://www.hitrecord.org/records/2954362"
    ]
    for test in tests:
        url = try_get(ie, lambda x: x._match_id(test))
        assert url == '2954362'
        _url = try_get(ie, lambda x: x._VALID_URL)
        assert test[:len(_url)] == _url

    # Test extract method
    _extract = try_get(ie, lambda x: x._real_extract('https://www.hitrecord.org/records/2954362'))
    assert _extract['id'] == '2954362'

# Generated at 2022-06-12 17:41:25.291614
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:41:26.974041
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    print(ie._VALID_URL)
    print(ie.IE_NAME)

# Generated at 2022-06-12 17:41:27.499150
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-12 17:41:33.480710
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Input is the HITRECORD website's URL
    e = HitRecordIE('https://hitrecord.org/records/2954362')
    assert e._match_id('https://hitrecord.org/records/2954362') == '2954362'
    assert e._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert e.IE_NAME == 'hitrecord'

# Generated at 2022-06-12 17:41:37.410489
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-12 17:41:38.216665
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()



# Generated at 2022-06-12 17:41:38.943781
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("test", {})

# Generated at 2022-06-12 17:41:41.750928
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE() != None

# Generated at 2022-06-12 17:41:43.713069
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_ie = HitRecordIE()
    assert hitrecord_ie

# Generated at 2022-06-12 17:41:50.525834
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == "HitRecord"
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'