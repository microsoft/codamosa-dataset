

# Generated at 2022-06-26 12:10:37.348099
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()


# Generated at 2022-06-26 12:10:44.043361
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)', \
		"Test Case Failed: Valid Url of Hit Record website should be matched"


# Generated at 2022-06-26 12:10:45.454170
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_ = HitRecordIE()

# Generated at 2022-06-26 12:10:48.148881
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url0 = 'https://hitrecord.org/records/2954362'
    hit_record_i_e_0 = HitRecordIE()
    assert hit_record_i_e_0

# Generated at 2022-06-26 12:10:50.362850
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    if __name__ == '__main__':
        test_case_0()

# Generated at 2022-06-26 12:10:52.447000
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()


# Generated at 2022-06-26 12:11:03.231243
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:11:05.034237
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()

# Generated at 2022-06-26 12:11:11.615176
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from ykdl.util.html import get_content

    url = 'https://hitrecord.org/records/2954362'
    html = get_content(url)

    hit_record_i_e_1 = HitRecordIE()
    info_dict_0 = hit_record_i_e_1._real_extract(url)

# Generated at 2022-06-26 12:11:13.591831
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()
    hit_record_i_e._VALID_URL

# Generated at 2022-06-26 12:11:29.103794
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:11:37.347429
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        # pylint: disable=unused-variable
        hitrecord = HitRecordIE()
        test = True
    except:
        test = False
    if not test:
        print("Unit test for constructor of class HitRecordIE failed.")
    else:
        print("Unit test for constructor of class HitRecordIE succeded.")

# Generated at 2022-06-26 12:11:50.007150
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Unit test for constructor of class HitRecordIE
    """
    test_instance = HitRecordIE()
    assert test_instance._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:11:56.934076
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    #local testing
    #url = 'https://hitrecord.org/records/2954362'

    #remote testing
    url = 'https://hitrecord.org/records/5712193'

    test_obj = HitRecordIE()
    test_obj._real_extract(url)

# Generated at 2022-06-26 12:11:57.830348
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE

# Generated at 2022-06-26 12:12:06.907217
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-26 12:12:08.225442
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # A test case to test the constructor
    assert HitRecordIE()

# Generated at 2022-06-26 12:12:09.289966
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HitRecordIE()

# Generated at 2022-06-26 12:12:12.881719
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_HitRecordIE = HitRecordIE() 
    print(test_HitRecordIE._VALID_URL) # Print url that this extraction is capable of handling
    print(test_HitRecordIE._TEST) # Print test cases


# Generated at 2022-06-26 12:12:14.109242
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE();

# Generated at 2022-06-26 12:12:24.546025
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_HitRecordIE = HitRecordIE()
    assert test_HitRecordIE

# Generated at 2022-06-26 12:12:27.191487
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    h = HitRecordIE()
    assert h.ie_key() == 'hitrecord'
    assert h.ie_name() == 'HitRecord'

# Generated at 2022-06-26 12:12:33.214172
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ie = HitRecordIE('http://hitrecord.org/records/2954362')
	assert ie is not None
	assert ie._VALID_URL == 'http://hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-26 12:12:34.602360
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('HitRecordIE', 'HitRecordIE')

# Generated at 2022-06-26 12:12:35.740389
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:12:40.534805
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  yt = HitRecordIE({})
  assert yt.suitable("https://hitrecord.org/records/2954362") == True
  assert yt.suitable("https://hitrecord.org/records/2954362?autoplay=1") == True
  assert yt.suitable("https://hitrecord.org/records/2954362#") == False
  assert yt.suitable("https://hitrecord.org/records/2954362#autoplay") == False

# Generated at 2022-06-26 12:12:41.952634
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL is not None
    assert HitRecordIE._TEST is not None
    return True

# Generated at 2022-06-26 12:12:47.631089
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  # Test that HitRecordIE returns expected value for url
  # Assert that it is a valid url to hitrecord.org, and assert that
  # the url contains /records
  hitRecordIE = HitRecordIE("https://www.hitrecord.org/records/2954362")
  assert (len(hitRecordIE._extract()) > 0)

# Generated at 2022-06-26 12:12:48.447275
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-26 12:12:50.291210
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('HitRecordIE', 'hitrecord.org')

# Generated at 2022-06-26 12:13:10.938340
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # The unit test for video with source_url
    HitRecordIE('2954362')
    # The unit test for video without source_url
    HitRecordIE('3068886')

# Generated at 2022-06-26 12:13:18.400551
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    hit_record = HitRecordIE()
    assert hit_record._VALID_URL == HitRecordIE._VALID_URL
    assert hit_record._TEST == HitRecordIE._TEST
    assert hit_record._download_webpage == InfoExtractor._download_webpage
    assert hit_record._match_id == InfoExtractor._match_id
    assert hit_record._real_extract == HitRecordIE._real_extract

# Generated at 2022-06-26 12:13:25.436564
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-26 12:13:27.040059
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None, None)



# Generated at 2022-06-26 12:13:29.361525
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(HitRecordIE._download_webpage, HitRecordIE._real_extract)

# Generated at 2022-06-26 12:13:30.231896
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-26 12:13:31.106380
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert ie.test == HitRecordIE._TEST

# Generated at 2022-06-26 12:13:36.265756
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test = HitRecordIE._TEST
    url = test['url']
    video_id = test['info_dict']['id']
    video = HitRecordIE._download_json(
            'https://hitrecord.org/api/web/records/%s' % video_id, video_id)
    tags_list = try_get(video, lambda x: x['tags'], list)
    if tags_list:
        tags = [
            t['text']
            for t in tags_list
            if isinstance(t, dict) and t.get('text')
            and isinstance(t['text'], compat_str)]

    assert HitRecordIE._VALID_URL.match(url)
    assert HitRecordIE._TEST['info_dict']['uploader'] == 'Zuzi.C12'


# Generated at 2022-06-26 12:13:46.074845
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    it = HitRecordIE()
    # Test _VALID_URL constant of class HitRecordIE
    it._VALID_URL = it._VALID_URL.lower()
    assert it._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert it._TEST['url'] == it._TEST['url'].lower()
    # Test test method of class HitRecordIE
    it.test()

# Generated at 2022-06-26 12:13:48.061924
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('hitrecord', 'hitrecord.org')._VALID_URL

# Generated at 2022-06-26 12:14:38.663568
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert str(type(ie)) == "<class 'youtube_dl.extractor.hitrecord.HitRecordIE'>"

# Generated at 2022-06-26 12:14:40.032573
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE();

# Generated at 2022-06-26 12:14:41.929730
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE is not None

# Generated at 2022-06-26 12:14:44.329407
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print('Testing HitRecordIE')
    HitRecordIE('test url')


# Generated at 2022-06-26 12:14:46.357331
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    h = HitRecordIE()
    assert h is not None


# Generated at 2022-06-26 12:14:47.340688
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.testInput('') == False

# Generated at 2022-06-26 12:14:48.524565
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    inst = HitRecordIE()

# Generated at 2022-06-26 12:14:59.221935
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Unit test for the constructor of the class HitRecordIE
    """
    ie = HitRecordIE()
    TestCase = type(
        'TestCase',
        (),
        { 'assertRe': staticmethod(lambda patt, value: TestCase.assertTrue(re.search(patt, value))) }
    )
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)',\
        'ie._VALID_URL is wrong'

# Generated at 2022-06-26 12:15:05.315784
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TEST == ie.TEST
    ie.suite()

# Generated at 2022-06-26 12:15:05.767335
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-26 12:16:43.373505
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hIE = HitReocrdIE()
    assert(hIE.ie_key() == 'hitrecord')

# Generated at 2022-06-26 12:16:44.242313
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:16:53.911747
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE(2954362)
    video = instance._download_json(
        'https://hitrecord.org/api/web/records/%s' % 2954362, 2954362)
    assert video['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert video['source_url']['mp4_url'] == 'https://hitrecord.org/uploads/production/record/video/55/55_55_5543311_1452871521.mp4'
    assert int_or_none(video.get('total_views_count')) > 300


# Generated at 2022-06-26 12:16:57.519025
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    e = HitRecordIE()
    assert e._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:17:02.177299
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    # Constructor should assign the value of _VALID_URL
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-26 12:17:07.763105
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Constructor case, where url is a string
    hitrecordIE = HitRecordIE("")
    assert(hitrecordIE.ie_key() == "HitRecord")
    assert(hitrecordIE.ie_name() == "HitRecord")

# Generated at 2022-06-26 12:17:11.155451
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # This should succeed
    ie.extract('https://www.hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:17:12.303676
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    me = HitRecordIE()
    print(me)

# Generated at 2022-06-26 12:17:14.667041
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.suitable('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:17:19.013290
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(HitRecordIE._downloader)._VALID_URL(HitRecordIE._TEST['url']) == True

# Unit test extractor