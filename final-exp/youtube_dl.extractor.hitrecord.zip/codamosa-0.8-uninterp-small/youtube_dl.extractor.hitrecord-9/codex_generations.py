

# Generated at 2022-06-26 12:10:38.573373
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_case_0()

# Generated at 2022-06-26 12:10:43.193456
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-26 12:10:46.277894
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_1 = HitRecordIE()
    assert hit_record_i_e_1.NAME == "hitrecord"


# Generated at 2022-06-26 12:10:53.673230
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()
    assert hit_record_i_e._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:10:56.372965
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()
    assert hit_record_i_e is not None


# Generated at 2022-06-26 12:10:59.153290
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()
    hit_record_i_e.set_downloader(None)
    hit_record_i_e.to_screen = None

# Generated at 2022-06-26 12:11:04.528056
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    expected_id = '2954362'
    hit_record_i_e = HitRecordIE()
    actual_id = hit_record_i_e._match_id(url)
    assert actual_id == expected_id


# Generated at 2022-06-26 12:11:16.680889
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert_equal(hit_record_i_e_0.url, 'https://hitrecord.org/records/2954362')
    assert_equal(hit_record_i_e_0.video_id, '2954362')
    assert_equal(hit_record_i_e_0.info_dict, '2954362')
    assert_equal(hit_record_i_e_0.title, 'A Very Different World (HITRECORD x ACLU)')
    assert_equal(hit_record_i_e_0.description, 'md5:e62defaffab5075a5277736bead95a3d')
    assert_equal(hit_record_i_e_0.duration, 139.327)

# Generated at 2022-06-26 12:11:19.311076
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_0 = HitRecordIE()

# Generated at 2022-06-26 12:11:29.378055
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # HitRecordIE with default args
    hit_record_ie_default = HitRecordIE()
    assert hit_record_ie_default.extractor._VALID_URL == HitRecordIE._VALID_URL
    assert hit_record_ie_default.extractor._TEST == HitRecordIE._TEST
    # HitRecordIE test with dummy url
    url_dummy = 'https://www.youtube.com/watch?v=5NL5k1hR_wA'
    hit_record_ie_default = HitRecordIE(url=url_dummy)
    assert hit_record_ie_default.extractor._VALID_URL == HitRecordIE._VALID_URL
    assert hit_record_ie_default.extractor._TEST == HitRecordIE._TEST


# Generated at 2022-06-26 12:11:40.228079
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert (HitRecordIE() != None)


# Generated at 2022-06-26 12:11:51.314487
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_0 = HitRecordIE()
    assert hit_record_i_e_0._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:11:52.813282
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_case_0()


# Generated at 2022-06-26 12:11:53.634009
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-26 12:12:05.034403
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # check parameters of HitRecordIE
    assert HitRecordIE.__name__ == "test_HitRecordIE"

# Generated at 2022-06-26 12:12:05.843585
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    unit_test_case_0 = HitRecordIE()

# Generated at 2022-06-26 12:12:07.226685
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass
# #####################################################



# Generated at 2022-06-26 12:12:08.372521
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_1 = HitRecordIE()


# Generated at 2022-06-26 12:12:09.289671
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-26 12:12:13.143713
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    hit_record_ie_1 = HitRecordIE(url)
    assert hit_record_ie_1


# Generated at 2022-06-26 12:12:23.934821
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'

# Generated at 2022-06-26 12:12:31.736069
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-26 12:12:33.155889
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# Implement test later
	return

# Generated at 2022-06-26 12:12:42.007217
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(downloader=None)

    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

    # unit test for _match_id()
    assert ie._match_id('https://hitrecord.org/records/2954362') == '2954362'

    # unit test for _real_extract()

# Generated at 2022-06-26 12:12:42.874507
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:12:46.943068
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    er = HitRecordIE(HitRecordIE._VALID_URL, HitRecordIE._TEST)
    x = er._real_extract(HitRecordIE._VALID_URL)
    print(x)

# Generated at 2022-06-26 12:12:49.764067
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # HitRecordIE() constructor takes no parameter
    HitRecordIE()
    # HitRecordIE() contructor should take no exception in normal case


# Generated at 2022-06-26 12:12:51.092337
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE


# Generated at 2022-06-26 12:12:51.889748
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HitRecordIE()

# Generated at 2022-06-26 12:12:52.565874
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-26 12:13:12.062795
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie

# Generated at 2022-06-26 12:13:14.564726
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("HitRecordIE", "HitRecordIE_test_case")

# Generated at 2022-06-26 12:13:17.598979
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.__doc__ == InfoExtractor.__doc__
    assert ie._TEST == InfoExtractor._TEST
    assert ie.IE_NAME == 'hitrecord:record'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:13:20.163149
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('http://hitrecord.org/records/2954362')
    #Test for hitrecord

# Generated at 2022-06-26 12:13:20.955847
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:13:23.383418
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract("https://hitrecord.org/records/2954362")

# Generated at 2022-06-26 12:13:25.847977
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_ie = HitRecordIE(InfoExtractor())
    assert hit_record_ie is not None

# Generated at 2022-06-26 12:13:26.280116
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:13:32.996508
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    assert hitRecordIE._TEST["url"] == "https://hitrecord.org/records/2954362"
    assert hitRecordIE._TEST["md5"] == "fe1cdc2023bce0bbb95c39c57426aa71"

    info_dict = hitRecordIE._TEST["info_dict"]
    assert info_dict["id"] == "2954362"
    assert info_dict["ext"] == "mp4"
    assert info_dict["title"] == "A Very Different World (HITRECORD x ACLU)"
    assert info_dict["description"] == "md5:e62defaffab5075a5277736bead95a3d"
    assert info_dict["duration"] == 139.327
    assert info_dict["timestamp"] == 147

# Generated at 2022-06-26 12:13:33.377062
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE

# Generated at 2022-06-26 12:14:21.385912
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

test_HitRecordIE()

# Generated at 2022-06-26 12:14:27.006793
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    import unittest
    class TestHitRecordIE(unittest.TestCase):
        def test_constructor(self):
            hitRecordIE = HitRecordIE()
            self.assertEqual(hitRecordIE.ie_key(), 'HitRecord')
    unittest.main()

# Generated at 2022-06-26 12:14:33.917079
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:14:41.920463
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
#Url to be passed to constructor
    url= 'https://hitrecord.org/records/2954362'
#Creating object of class HitRecordIE
    test_obj=HitRecordIE()
#Testing if the url is valid
    assert test_obj._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
#Testing if the parameters are correct
    assert test_obj._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert test_obj._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert test_obj._TEST['info_dict']['id'] == '2954362'

# Generated at 2022-06-26 12:14:44.317354
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('')
    assert isinstance(ie, HitRecordIE)

# Generated at 2022-06-26 12:14:49.884332
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    IE = HitRecordIE()
    inst = IE('https://hitrecord.org/records/2954362')
    expected = HitRecordIE._TEST
    assert inst.url == expected['url']
    assert inst.md5 == expected['md5']
    assert inst.info_dict['id'] == expected['info_dict']['id']
    assert inst.info_dict['ext'] == expected['info_dict']['ext']
    assert inst.info_dict['title'] == expected['info_dict']['title']
    assert inst.info_dict['description'] == expected['info_dict']['description']
    assert inst.info_dict['duration'] == expected['info_dict']['duration']
    assert inst.info_dict['timestamp'] == expected['info_dict']['timestamp']
    assert inst

# Generated at 2022-06-26 12:14:50.991434
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:14:51.791196
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-26 12:14:58.294714
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.get_domain() == "hitrecord.org"
    assert ie.get_match_regex() == HitRecordIE._VALID_URL
    assert ie.get_example_url() == "https://hitrecord.org/"

# Generated at 2022-06-26 12:15:05.324570
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	hitrecord_ie = HitRecordIE('HitRecordIE')
	assert (hitrecord_ie.name == 'HitRecordIE')
	assert (hitrecord_ie.ie_key == 'hitrecord')
	assert (hitrecord_ie.ie_key == 'HitRecord')
	assert (hitrecord_ie.extractor_key == 'IEHitRecord')
	assert (hitrecord_ie.thumbnail == None)
	assert (hitrecord_ie.uploader_id == None)
	assert (hitrecord_ie.view_count == None)
	assert (hitrecord_ie.title == None)
	assert (hitrecord_ie.description == None)
	assert (hitrecord_ie.webpage_url == None)
	assert (hitrecord_ie.duration == None)
	assert (hitrecord_ie.timestamp == None)
	

# Generated at 2022-06-26 12:16:56.223680
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:16:57.073229
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:17:00.022053
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:17:01.332412
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL is not None

# Generated at 2022-06-26 12:17:02.043631
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE

# Generated at 2022-06-26 12:17:03.719570
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-26 12:17:05.954276
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')



# Generated at 2022-06-26 12:17:07.787922
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    if __name__ == '__main__':
        assert HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:17:08.218461
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:17:11.616828
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_HitRecordIE()