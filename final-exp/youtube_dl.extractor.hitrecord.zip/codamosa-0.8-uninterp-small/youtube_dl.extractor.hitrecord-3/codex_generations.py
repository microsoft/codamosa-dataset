

# Generated at 2022-06-26 12:10:50.704039
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()
    assert hit_record_i_e
    assert hit_record_i_e._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:10:51.761527
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-26 12:11:02.927223
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video_id = '2954362'
    url = "https://hitrecord.org/records/2954362"
    api_url = 'https://hitrecord.org/api/web/records/%s' % video_id

# Generated at 2022-06-26 12:11:05.223721
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_case_0()

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-26 12:11:09.665592
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == 'https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)'


# Generated at 2022-06-26 12:11:11.472088
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert isinstance(hit_record_i_e_0, HitRecordIE)


# Generated at 2022-06-26 12:11:20.848661
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert hasattr(HitRecordIE, '_download_json')
    assert callable(getattr(HitRecordIE, '_download_json', None))
    assert hasattr(HitRecordIE, '_real_extract')
    assert callable(getattr(HitRecordIE, '_real_extract', None))
    assert hasattr(HitRecordIE, '_TEST')
    assert isinstance(getattr(HitRecordIE, '_TEST', None), dict)
    assert hasattr(HitRecordIE, '_VALID_URL')
    assert isinstance(getattr(HitRecordIE, '_VALID_URL', None), str)
    assert hasattr(HitRecordIE, 'IE_DESC')
    assert isinstance(getattr(HitRecordIE, 'IE_DESC', None), str)

# Generated at 2022-06-26 12:11:22.247058
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()

# Generated at 2022-06-26 12:11:23.336217
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:11:24.805152
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()

# Generated at 2022-06-26 12:11:34.233630
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie.valid_url()
    assert ie.valid_url(ie._valid_url)

# Generated at 2022-06-26 12:11:35.769063
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE()


# Generated at 2022-06-26 12:11:39.324136
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    h = HitRecordIE()
    assert h._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-26 12:11:40.619346
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:11:42.469072
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE("hitrec.org")



# Generated at 2022-06-26 12:11:51.341352
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    HitRecordIE.extract_id('http://hitrecord.org/records/2954362')
    HitRecordIE.extract_id('https://hitrecord.org/records/2954362')
    assert ie._download_json('https://hitrecord.org/api/web/records/2954362', '2954362')
    assert ie._real_extract('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:11:56.021646
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME in HitRecordIE._ies
    assert '2954362' in HitRecordIE._WORKING_IE_NAME
    assert ie.IE_DESC == 'HitRecord'

# Generated at 2022-06-26 12:11:57.987149
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(HitRecordIE._VALID_URL)

# Generated at 2022-06-26 12:12:06.999587
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:12:09.909092
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(InfoExtractor)._VALID_URL == HitRecordIE._VALID_URL
    assert HitRecordIE(InfoExtractor)._TEST == HitRecordIE._TEST

# Generated at 2022-06-26 12:12:20.940372
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(HitRecordIE._TEST) == HitRecordIE._TEST

# Generated at 2022-06-26 12:12:22.827878
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('', {}, {})

# Generated at 2022-06-26 12:12:31.397375
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    class HitRecordIE(InfoExtractor):
        _VALID_URL = r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:12:36.596078
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.SUCCESS
    assert ie._VALID_URL
    assert ie._TEST

# Generated at 2022-06-26 12:12:49.366228
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    o = HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')
    assert o.get('id') == '2954362'
    assert o.get('title') == 'A Very Different World (HITRECORD x ACLU)'
    assert isinstance(o.get('description'), str)
    assert isinstance(o.get('duration'), float)
    assert isinstance(o.get('timestamp'), int)
    assert isinstance(o.get('uploader'), str)
    assert isinstance(o.get('uploader_id'), str)
    assert isinstance(o.get('view_count'), int)
    assert isinstance(o.get('like_count'), int)
    assert isinstance(o.get('comment_count'), int)

# Generated at 2022-06-26 12:12:50.690601
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-26 12:12:56.106228
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'


# Function to test HitRecordIE._real_extract

# Generated at 2022-06-26 12:13:08.414436
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.get_url_re().match('https://hitrecord.org/records/2954362')
    assert ie.get_url_re().match('https://www.hitrecord.org/records/2954362')
    assert ie.get_url_re().match('https://hitrecord.org/records/2954362/something-else') is None
    assert ie.get_url_re().match('https://hitrecord.org/records/2954362/something-else/something-else-2') is None
    assert ie.get_url_re().match('https://hitrecord.org/records/2954362.something-else') is None

# Generated at 2022-06-26 12:13:09.261816
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:13:11.351673
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    ie = HitRecordIE()
    ie.extract(url)

# Generated at 2022-06-26 12:13:29.841846
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:13:36.672703
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # testing constructor creation
    # test sample link is correctly entered
    test_sample_link = 'https://hitrecord.org/records/2954362'
    HitRecordIE.suitable(test_sample_link)
    # test sample link is incorrectly entered
    test_sample_link = 'https://hitrecord.org/records/2954'
    HitRecordIE.suitable(test_sample_link)


# Generated at 2022-06-26 12:13:39.670393
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == HitRecordIE._VALID_URL_test._VALID_URL

# Generated at 2022-06-26 12:13:41.060659
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(InfoExtractor)



# Generated at 2022-06-26 12:13:44.754365
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:13:46.698549
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:13:53.024390
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ie = HitRecordIE()
	assert(ie.__class__.__name__ == 'HitRecordIE')
	assert(ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-26 12:13:56.241310
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'
    assert ie.ie_name() == 'HitRecord'

# Generated at 2022-06-26 12:13:56.784321
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-26 12:14:03.152400
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # check if the regex is valid
    ie.suitable('https://hitrecord.org/records/2954362')
    # check if it can retrive the id
    assert ie._match_id('https://hitrecord.org/records/2954362') == '2954362'

# Generated at 2022-06-26 12:14:50.495824
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:14:53.078568
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.suitable(HitRecordIE._TEST['url'])

# Generated at 2022-06-26 12:15:01.240459
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    url = "https://hitrecord.org/records/2954362"
    info = ie._real_extract(url)
    assert info['id'] == '2954362'
    assert info['url'] != None
    assert info['duration'] == 139.327
    assert info['timestamp'] == 1471557582
    assert info['uploader'] == 'Zuzi.C12'
    assert info['uploader_id'] == '362811'
    assert info['view_count'] >= 7384

# Generated at 2022-06-26 12:15:08.174445
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie != None
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert ie._TEST['info_dict']['description']

# Generated at 2022-06-26 12:15:10.753252
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_video_link = "https://hitrecord.org/records/2954362"
    HitRecordIE()
    # Test to make sure the constructor worked
    # TODO: Make this test work

# Generated at 2022-06-26 12:15:12.924777
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.match_url('https://hitrecord.org/records/2954362')
    assert ie.match_id('2954362')
    assert ie.match_id('2954362') == '2954362'

# Generated at 2022-06-26 12:15:14.775482
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    assert ie.IE_NAME == 'hitrecord'

# Generated at 2022-06-26 12:15:17.436872
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test whether the HitRecordIE constructor is running without error
    HitRecordIE()

# Generated at 2022-06-26 12:15:21.102994
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # Downloading a non-existing video
    with pytest.raises(ExtractorError):
        ie.extract('https://hitrecord.org/records/999999999')

# Generated at 2022-06-26 12:15:22.321854
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    raise NotImplementedError

# Generated at 2022-06-26 12:17:13.744647
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    #ToDO:
    #  Test HitRecordIE.suitable
    return

# Generated at 2022-06-26 12:17:14.669614
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:17:22.837387
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._search_json_ld('youtube') != []
    assert HitRecordIE._search_json_ld('hitrecord') != []
    assert HitRecordIE._search_regex(HitRecordIE._VALID_URL, 'https://hitrecord.org/records/2954362') == '2954362'
    assert HitRecordIE._html_search_regex(r'<a href="/contributions/362811">(.*)</a>', '', 'Zuzi.C12') == 'Zuzi.C12'

# Generated at 2022-06-26 12:17:28.870471
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == HitRecordIE._VALID_URL
    assert ie._TEST == HitRecordIE._TEST
    assert ie._extract_video_info == HitRecordIE._extract_video_info

# Generated at 2022-06-26 12:17:30.855262
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('HitRecord', 'hitrecord.org')
    return


# Generated at 2022-06-26 12:17:33.588934
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL


# Generated at 2022-06-26 12:17:35.192594
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-26 12:17:37.767950
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()._real_extract("")
    assert ie == {}

# Generated at 2022-06-26 12:17:40.310834
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    extractor = HitRecordIE()
    # we don't have assert statement
    pass

# Generated at 2022-06-26 12:17:47.481849
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    temp = HitRecordIE()
    assert temp._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'