

# Generated at 2022-06-26 12:10:36.977952
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    raise RuntimeError("Test not implemented!")

# Generated at 2022-06-26 12:10:43.262608
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE._VALID_URL = r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    hit_record_i_e_0 = HitRecordIE()


# Generated at 2022-06-26 12:10:44.674074
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert(HitRecordIE)


# Generated at 2022-06-26 12:10:52.615370
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:10:54.422874
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_case_0()


# Generated at 2022-06-26 12:10:55.223488
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert True



# Generated at 2022-06-26 12:10:57.223501
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_0 = HitRecordIE()



# Generated at 2022-06-26 12:10:58.307786
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert True


# Generated at 2022-06-26 12:10:58.861166
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-26 12:11:00.763529
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass


# Generated at 2022-06-26 12:11:07.731854
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    global HitRecordIE
    HitRecordIE()

# Generated at 2022-06-26 12:11:10.273758
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')


# Generated at 2022-06-26 12:11:20.270658
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    module = ("hitrecord", "HitRecord")
    input_url = "https://hitrecord.org/records/2954362"

# Generated at 2022-06-26 12:11:21.274168
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.download('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:11:24.151092
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Get test case for HitRecordIE
    """
    return HitRecordIE._TEST

# Generated at 2022-06-26 12:11:26.202301
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.download("https://hitrecord.org/records/2954362")

# Generated at 2022-06-26 12:11:27.861975
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(InfoExtractor)

# Generated at 2022-06-26 12:11:30.749393
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    t = ie._TEST
    ie._extract_url(t['url'])

# Generated at 2022-06-26 12:11:33.692993
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.download("https://hitrecord.org/records/2954362")

# Generated at 2022-06-26 12:11:38.318238
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    i = HitRecordIE()
    assert i._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-26 12:11:48.610813
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:11:52.887284
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert (ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-26 12:11:57.738131
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'



# Generated at 2022-06-26 12:12:00.591598
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Test constructor for HitRecordIE"""
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:12:01.513734
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_obj=HitRecordIE()

# Generated at 2022-06-26 12:12:04.827336
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    if ie != None:
        print("The constructor of class HitRecordIE is ok")


# Generated at 2022-06-26 12:12:06.798113
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(None)._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-26 12:12:08.956868
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert isinstance(ie, HitRecordIE), "The test fails"



# Generated at 2022-06-26 12:12:19.014996
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('http://www.hitrecord.org/records/2954362')
    assert ie.is_suitable('http://www.hitrecord.org/records/2954362') == True
    assert ie.is_suitable('https://www.hitrecord.org/records/2954362') == True
    assert ie.is_suitable('http://hitrecord.org/records/2954362') == True
    assert ie.is_suitable('https://hitrecord.org/records/2954362') == True
    assert ie.is_suitable('https://www.hitrecord.org/records/1234567') == False
    assert ie.is_suitable('https://www.hitrecord.org/records/abcde') == False

# Generated at 2022-06-26 12:12:21.776532
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video_id = "5188"
    video = HitRecordIE(video_id)
    video.download()

# Generated at 2022-06-26 12:12:45.413466
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    filename = "test_HitRecordIE.py"
    constructor = HitRecordIE

    assert constructor._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert constructor._TEST != {}

# Generated at 2022-06-26 12:12:46.266685
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:12:47.381449
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE()
    assert hitRecord is not None


# Generated at 2022-06-26 12:12:51.285432
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('http://www.hitrecord.org/records/2954362')
    print(ie.extract('http://www.hitrecord.org/records/2954362'))

# Generated at 2022-06-26 12:12:51.881173
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:12:56.170871
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

if __name__ == "__main__":
    test_HitRecordIE()

# Generated at 2022-06-26 12:12:56.910515
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:12:58.265158
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.name

# Generated at 2022-06-26 12:13:03.287982
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-26 12:13:11.829439
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        hitRecordIE = HitRecordIE(InfoExtractor)
    except Exception as ex:
        assert isinstance(ex, TypeError)

    hitRecordIE = HitRecordIE(InfoExtractor)
    expected = {}
    expected['webpage_url'] = 'https://hitrecord.org/records/2954362'
    expected['ie_key'] = 'HitRecord'
    expected['video_id'] = '2954362'
    expected['video_url'] = 'https://www.google.com/'

# Generated at 2022-06-26 12:13:59.840119
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    import sys
    import subprocess
    import types
    if sys.version_info[:2] < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

# Generated at 2022-06-26 12:14:10.109168
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert (ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')
    assert (ie._TEST['url'] == 'https://hitrecord.org/records/2954362')
    assert (ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71')

# Generated at 2022-06-26 12:14:12.266136
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Constructor of class HitRecordIE()
    ie = HitRecordIE()

# Generated at 2022-06-26 12:14:15.317831
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('netloc')
    assert 'HitRecord' in ie._USER_AGENT

# Generated at 2022-06-26 12:14:16.962256
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:14:23.023544
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('hitrecord', HitRecordIE._TEST['url'])
    ie.extract('hitrecord', 'https://hitrecord.org/records/3970310')


# Generated at 2022-06-26 12:14:32.650098
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE(): # pylint: disable=unused-argument
    ie = HitRecordIE('example.com')

# Generated at 2022-06-26 12:14:41.709453
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:14:42.526315
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:14:51.027313
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE('hitrecord', 'http://www.hitrecord.org/records/2954362')
    assert instance.suitable('http://www.hitrecord.org/records/2954362') == True
    assert instance.suitable('http://www.hitrecord.org') == False
    assert instance.suitable('https://www.hitrecord.org/records/2954362') == True
    assert instance.suitable('http://www.hitrecord.org/records/2954362/download/Dishonor_on_your_cow_scene_01') == False

# Generated at 2022-06-26 12:16:26.270795
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.url_result('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:16:30.516602
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_url = "https://hitrecord.org/records/2954362"
    HitRecordIE(HitRecordIE._create_get_href(test_url))

# Generated at 2022-06-26 12:16:32.930132
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('')
    assert ie._VALID_URL.match('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:16:36.333261
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """ test HitRecordIE class constructor """
    info_extractor = HitRecordIE()
    assert info_extractor.ie_key() == 'hitrecord'

# Generated at 2022-06-26 12:16:45.545641
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('http://www.hitrecord.org/')
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    #assert ie._TEST == {
    #    'url': 'https://hitrecord.org/records/2954362',
    #    'md5': 'fe1cdc2023bce0bbb95c39c57426aa71',
    #    'info_dict': {
    #        'id': '2954362',
    #        'ext': 'mp4',
    #        'title': 'A Very Different World (HITRECORD x ACLU)',
    #        'description': 'md5:e62defaffab5075a5277736bead95a3d',

# Generated at 2022-06-26 12:16:47.754811
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()



# Generated at 2022-06-26 12:16:48.976286
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:16:56.958649
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('test-id', 'test-url')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-26 12:17:04.511719
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert len(ie._VALID_URL) > 0
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert ie._TEST['info_dict']['description'] == 'md5:e62defaffab5075a5277736bead95a3d'
    assert ie._TEST['info_dict']['duration'] == 139.327

# Generated at 2022-06-26 12:17:05.641558
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie.valid_url