

# Generated at 2022-06-26 12:10:41.793996
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    hit_record_i_e_1 = HitRecordIE()
    assert hit_record_i_e_1._VALID_URL == HitRecordIE._VALID_URL
    assert hit_record_i_e_1._TEST == HitRecordIE._TEST
    assert hit_record_i_e_1._downloader == None
    assert hit_record_i_e_1._match_id(url) == '2954362'
    assert hit_record_i_e_1._real_initialize() == None

# Generated at 2022-06-26 12:10:43.759877
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert isinstance(HitRecordIE, InfoExtractor)


# Generated at 2022-06-26 12:10:45.743150
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.__module__ == 'hitrecord'



# Generated at 2022-06-26 12:10:53.369169
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:10:54.640694
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-26 12:10:56.589444
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_0 = HitRecordIE()


# Generated at 2022-06-26 12:10:58.605490
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert test_case_0() is not None

# All methods in class HitRecordIE

# Generated at 2022-06-26 12:11:04.907436
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_1 = HitRecordIE()
    assert hit_record_i_e_1.suitable('https://hitrecord.org/records/2954362')
    assert not hit_record_i_e_1.suitable('http://www.youtube.com/watch?v=BaW_jenozKc')


# Generated at 2022-06-26 12:11:06.628659
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_0 = HitRecordIE()


# Generated at 2022-06-26 12:11:09.757733
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert(HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')


# Generated at 2022-06-26 12:11:15.084452
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-26 12:11:16.008970
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_initialize()

# Generated at 2022-06-26 12:11:28.723777
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.name == 'hitrecord.org'
    assert ie.IE_DESC == 'HITRECORD'
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:11:33.772064
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:11:34.967752
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

	assert True

# Generated at 2022-06-26 12:11:35.855714
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:11:41.387834
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Simple test to see if HitRecordIE works.
    # Tests for the class are in the format:
    # def test_<Test Name>(self):
    #     assert(condition)
    #
    # If the condition is true, the test passes, else the test fails
    #
    # Here we are testing whether an instance of the HitRecordIE class
    # can be created without throwing any errors.
    HitRecordIE()

# Generated at 2022-06-26 12:11:50.218534
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('www.hitrecord.org/records/ID')
    assert ie.ie_key() == 'HitRecord'
    assert ie.ie_url('http://www.hitrecord.org/records/ID') == 'http://www.hitrecord.org/records/ID'
    assert ie.suitable('http://www.hitrecord.org/records/ID') == True
    assert ie.suitable('http://www.hitrecord.org/records/') == False
    assert ie.video_id('http://www.hitrecord.org/records/ID') == 'ID'
    assert ie.video_id('http://www.hitrecord.org/records/') == None

# Generated at 2022-06-26 12:11:53.783291
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_instance = HitRecordIE()
    assert isinstance(hitrecord_instance, HitRecordIE)
    

# Generated at 2022-06-26 12:12:05.059983
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE('http://www.hitrecord.org/records/2954362')
    assert hitRecordIE._VALID_URL == 'https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)'

# Generated at 2022-06-26 12:12:14.901562
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:12:20.359520
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hie = HitRecordIE()
    assert hie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    # Test that the test field is a dictionary
    assert isinstance(hie._TEST, dict)
    # Test that the test field contains the key 'url'
    test_url_key = 'url' in hie._TEST
    assert test_url_key == True
    # Test that the test field contains the key 'md5'
    test_md5_key = 'md5' in hie._TEST
    assert test_md5_key == True
    # Test that the test field contains the key 'info_dict'
    test_info_dict_key = 'info_dict' in hie._TEST
    assert test

# Generated at 2022-06-26 12:12:21.439966
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:12:25.139474
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.extract_id(ie.VALID_URL) == '2954362'



# Generated at 2022-06-26 12:12:27.239658
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE()
    assert(hitrecord is not None)



# Generated at 2022-06-26 12:12:32.162490
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    assert "https://hitrecord.org/api/web/records/2954362" == ie._url

# Generated at 2022-06-26 12:12:39.450713
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Unit test for constructor of class HitRecordIE
    """
    # Valid url can be parse
    url = "https://hitrecord.org/records/2954362"
    ie = HitRecordIE()
    assert ie.suitable(url)
    assert ie.extract(url)

    # Invalid url can not be parse
    url = "https://www.youtube.com/watch?v=vwY2QhQRdaM"
    ie = HitRecordIE()
    assert not ie.suitable(url)


# Generated at 2022-06-26 12:12:46.334699
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test broken url
    HitRecordIE._VALID_URL = 'https://notaurl.com'
    with pytest.raises(RegexNotFoundError):
        HitRecordIE('https://notaurl.com')
    # Test valid url
    HitRecordIE._VALID_URL = r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-26 12:12:47.701169
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")


# Generated at 2022-06-26 12:12:48.617877
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-26 12:13:08.008351
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:13:08.992297
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(url = 'https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:13:09.818825
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:13:10.659146
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:13:12.063997
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ie = HitRecordIE()

# Generated at 2022-06-26 12:13:13.136150
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    print(ie)


# Generated at 2022-06-26 12:13:13.962386
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        assert HitRecordIE(HitRecordIE._VALID_URL)
    except Exception:
        return False
    return True

# Generated at 2022-06-26 12:13:14.867409
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:13:15.238193
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-26 12:13:17.490172
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # HitRecordIE should be an instance of InfoExtractor
    ie = HitRecordIE(None)
    assert isinstance(ie, InfoExtractor)

    # Creating HitRecordIE should set patterns property
    # to a list of regular expressions
    assert hasattr(ie, '_VALID_URL') and ie._VALID_URL

# Generated at 2022-06-26 12:14:09.901563
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-26 12:14:11.185135
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-26 12:14:12.335335
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HitRecordIE()

# Generated at 2022-06-26 12:14:16.562831
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Unit test for class HitRecordIE
    """
    ie = HitRecordIE()
    ie.extract('http://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:14:18.177779
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    t = HitRecordIE()
    # test __init__()
    assert t
    # test _VALID_URL
    assert t._VALID_URL


# Generated at 2022-06-26 12:14:19.218155
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:14:20.848103
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:14:22.208270
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    _ = HitRecordIE()

# Generated at 2022-06-26 12:14:23.158790
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:14:25.672658
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.suitable('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:15:58.343584
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(InfoExtractor)._VALID_URL == HitRecordIE._VALID_URL


# Generated at 2022-06-26 12:16:01.373942
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.download('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:16:03.448929
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.supported_extractors()['hitrecord'] == True


# Generated at 2022-06-26 12:16:05.539806
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie != None)

# Generated at 2022-06-26 12:16:10.330017
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://www.hitrecord.org/records/2954362")
    assert ie.suitable("https://www.hitrecord.org/records/2954362")

# Generated at 2022-06-26 12:16:12.525687
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://www.hitrecord.org/records/2954362')
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:16:25.033368
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-26 12:16:35.215067
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    inst = HitRecordIE()
    assert inst._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert inst._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert inst._TEST['info_dict']['id'] == '2954362'
    assert inst._TEST['info_dict']['ext'] == 'mp4'
    assert inst._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert inst._TEST['info_dict']['description'] == 'md5:e62defaffab5075a5277736bead95a3d'
    assert inst._TEST['info_dict']['duration'] == 139.327

# Generated at 2022-06-26 12:16:45.162159
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	test_ie = HitRecordIE(TestInfoExtractor())
	assert test_ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:16:49.227660
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE()
    assert hitRecord._VALID_URL == 'http://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'