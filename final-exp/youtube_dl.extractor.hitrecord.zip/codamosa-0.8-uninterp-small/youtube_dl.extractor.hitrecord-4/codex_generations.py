

# Generated at 2022-06-26 12:10:42.402093
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()


# Generated at 2022-06-26 12:10:51.694346
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_1 = HitRecordIE()
    assert re.match(r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)', hit_record_i_e_1._VALID_URL)
    assert hit_record_i_e_1._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert hit_record_i_e_1._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert hit_record_i_e_1._TEST['info_dict']['id'] == '2954362'
    assert hit_record_i_e_1._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-26 12:11:02.929338
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:11:04.719786
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_test = HitRecordIE()


# Generated at 2022-06-26 12:11:17.107089
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert hasattr(HitRecordIE, '_VALID_URL'), "The HitRecordIE class must include an attribute _VALID_URL"
    assert hasattr(HitRecordIE, '_TEST'), "The HitRecordIE class must include an attribute _TEST"
    assert hasattr(HitRecordIE, '_download_json'), "The HitRecordIE class must include an attribute _download_json"
    assert hasattr(HitRecordIE, '_match_id'), "The HitRecordIE class must include an attribute _match_id"
    assert hasattr(HitRecordIE, '_real_extract'), "The HitRecordIE class must include an attribute _real_extract"
    assert hasattr(HitRecordIE, '_real_extract'), "The HitRecordIE class must include an attribute _real_extract"
    assert HitRecordIE._VALID_

# Generated at 2022-06-26 12:11:20.075258
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert type(HitRecordIE) == type(hit_record_i_e_0)



# Generated at 2022-06-26 12:11:29.797743
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == 'https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)'

# Generated at 2022-06-26 12:11:42.538060
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert hit_record_i_e_0.getdomain() == "hitrecord.org"
    assert hit_record_i_e_0.getid() == "2954362"

# Generated at 2022-06-26 12:11:49.516617
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert(hit_record_i_e_0.suitable('https://hitrecord.org/records/2954362'))
    assert(hit_record_i_e_0.suitable('http://hitrecord.org/records/2954362'))
    assert(not hit_record_i_e_0.suitable('https://abc.org/records/2954362'))
    assert(not hit_record_i_e_0.suitable('https://hitrecord.org/2954362'))
    return

# Generated at 2022-06-26 12:12:02.867329
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:12:08.488684
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:12:12.957982
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video = HitRecordIE()._real_extract(HitRecordIE._TEST['url'])
    assert video['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert video['id'] == '2954362'

# Generated at 2022-06-26 12:12:13.692402
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:12:14.415157
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-26 12:12:15.622294
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    t = HitRecordIE()
    assert t.test()

# Generated at 2022-06-26 12:12:17.548474
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecInst = HitRecordIE()
    assert isinstance(hitRecInst, HitRecordIE)

# Generated at 2022-06-26 12:12:18.398502
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HitRecordIE()

# Generated at 2022-06-26 12:12:22.618891
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    hitRecordIE = HitRecordIE(url)
    assert hitRecordIE

# Generated at 2022-06-26 12:12:23.449358
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-26 12:12:26.784715
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.subtype == 'hitrecord'
    assert isinstance(ie.subtype, compat_str)

# Generated at 2022-06-26 12:12:40.736631
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE({
        'url': 'https://hitrecord.org/records/2954362'
    })
    print(ie._VALID_URL)

# Generated at 2022-06-26 12:12:43.432733
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    class_ = HitRecordIE('https://hitrecord.org/records/2954362')
    ie_instance = class_()
    assert ie_instance._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:12:51.985532
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('hitrecord')
    assert ie.test_test()

# Generated at 2022-06-26 12:12:55.428353
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:12:59.234403
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://www.hitrecord.org/records/138972')
    HitRecordIE('http://www.hitrecord.org/records/-5')

# Generated at 2022-06-26 12:13:02.486403
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-26 12:13:11.682258
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Constructor test
    obj = HitRecordIE()

    # public functions
    test_url = 'https://hitrecord.org/records/2238892'
    info = obj._real_extract(test_url)

    # testing various attributes
    assert obj.IE_NAME == 'hitrecord'
    assert obj._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert info['id'] == '2238892'
    assert info['ext'] == 'mp4'
    assert info['description'] == 'md5:dcdfb6e067f30cad6ae2d6c552210285'
    assert info['duration'] == 473.0
    assert info['timestamp'] == 1455255522
   

# Generated at 2022-06-26 12:13:14.783084
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	url = 'https://hitrecord.org/records/2954362'
	HitRecordIE(url)

# Generated at 2022-06-26 12:13:17.039511
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        obj = HitRecordIE()
        print("Test HitRecordIE: PASS")
    except:
        print("Error: Can't instatial HitRecordIE")

# Generated at 2022-06-26 12:13:18.122654
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:13:41.199064
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	hre = HitRecordIE()
	hre._real_extract('https://hitrecord.org/records/2954362')
	assert True

# Generated at 2022-06-26 12:13:50.727161
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    i = HitRecordIE()
    test = i._TEST
    assert(test["url"] == "https://hitrecord.org/records/2954362")
    assert(test["md5"] == "fe1cdc2023bce0bbb95c39c57426aa71")
    assert(test["info_dict"]["id"] == "2954362")
    assert(test["info_dict"]["ext"] == "mp4")
    assert(test["info_dict"]["title"] == "A Very Different World (HITRECORD x ACLU)")
    assert(test["info_dict"]["description"] == "md5:e62defaffab5075a5277736bead95a3d")
    assert(test["info_dict"]["duration"] == 139.327)

# Generated at 2022-06-26 12:14:00.504052
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:14:01.858387
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-26 12:14:02.638186
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:14:03.416316
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:14:09.072597
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE("https://hitrecord.org/records/2954362")
    assert info_extractor != None
    assert info_extractor.ie_key() == "HitRecord"
    assert info_extractor.suitable("https://hitrecord.org/records/2954362")
    assert not info_extractor.suitable("http://www.youtube.com/watch?v=BaW_jenozKc")

# Generated at 2022-06-26 12:14:10.537345
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    return ie

# Generated at 2022-06-26 12:14:11.314804
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-26 12:14:14.384866
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:15:09.201007
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record = HitRecordIE()
    assert hit_record._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert hit_record._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert hit_record._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'


# Generated at 2022-06-26 12:15:15.585881
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    class_name = HitRecordIE.__name__

    # test case: HitRecordIE
    assert class_name == 'HitRecordIE', 'Failed to get class name "{}", got "{}"'.format(class_name, "HitRecordIE")


# Generated at 2022-06-26 12:15:24.612264
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Note: to initialize a class, you can use class name or the instance of it,
    #       see: https://stackoverflow.com/questions/10742994/python-class-instantiation-via-reference-to-class
    ie = HitRecordIE(HitRecordIE._VALID_URL)
    
    info_dict = ie.extract('https://hitrecord.org/records/2954362')

    print(info_dict)
    print(info_dict['id'])
    print(info_dict['url'])
    print(info_dict['title'])
    print(info_dict['description'])
    
    print(info_dict.keys())
    for key in info_dict.keys():
        print(info_dict[key])

#print('id: %s, url: %

# Generated at 2022-06-26 12:15:25.948556
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-26 12:15:26.778122
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:15:28.151066
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.test()

# Generated at 2022-06-26 12:15:28.975309
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:15:31.061938
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    "Test for constructor of class HitRecordIE"
    obj = HitRecordIE()
    actual = obj.IE_NAME
    assert actual == 'hitrecord'

# Generated at 2022-06-26 12:15:33.026752
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:15:33.833723
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:17:34.491589
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract("https://hitrecord.org/records/2954362")

# Generated at 2022-06-26 12:17:36.379633
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE.suite()

# Generated at 2022-06-26 12:17:37.633044
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:17:46.715537
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:17:47.209358
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:17:48.466938
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert 'hitrecord' in ie._downloader.IE_NAME

# Generated at 2022-06-26 12:17:53.912694
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    # valid_url
    ie.valid_url("https://hitrecord.org/records/2954362")
    ie.valid_url("http://hitrecord.org/records/2954362")

    # invalid_url
    ie.valid_url("http://hitrecord.org/records/")
    ie.valid_url("http://hitrecord.org/records/1")
    ie.valid_url("https://hitrecord.org/")

# Generated at 2022-06-26 12:17:54.428944
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:17:56.543739
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Test for class HitRecordIE
    """
    HitRecordIE()

# Generated at 2022-06-26 12:17:57.143681
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()