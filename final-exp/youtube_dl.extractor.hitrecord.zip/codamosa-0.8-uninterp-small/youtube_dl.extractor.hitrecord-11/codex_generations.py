

# Generated at 2022-06-26 12:10:42.548367
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()
    assert hit_record_i_e is not None


# Generated at 2022-06-26 12:10:46.212021
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == 'https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)'
    

# Generated at 2022-06-26 12:10:47.534043
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()


# Generated at 2022-06-26 12:10:51.971150
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()
    hit_record_i_e.suitable('https://hitrecord.org/records/2954362')


# Generated at 2022-06-26 12:11:03.065189
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-26 12:11:06.330866
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-26 12:11:08.332941
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_0 = HitRecordIE()

# Generated at 2022-06-26 12:11:10.720475
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_0 = HitRecordIE()
    hit_record_i_e_0.test_HitRecordIE()


# Generated at 2022-06-26 12:11:12.764026
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()
    assert hit_record_i_e

# Generated at 2022-06-26 12:11:13.368138
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-26 12:11:23.618840
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	hitRecord = HitRecordIE()
	assert hitRecord._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
	assert hitRecord.__name__ == 'HitRecord'

# Generated at 2022-06-26 12:11:25.044601
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()



# Generated at 2022-06-26 12:11:30.205379
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie.FILE_EXTENSIONS == {'mp4'}
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:11:31.113803
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE

# Generated at 2022-06-26 12:11:32.086333
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:11:35.207193
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE('https://hitrecord.org/records/2954362', {}).run()

# Generated at 2022-06-26 12:11:37.503932
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(HitRecordIE.ie)


# Generated at 2022-06-26 12:11:40.030562
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:11:41.807657
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()



# Generated at 2022-06-26 12:11:47.619631
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records')
    assert not ie.suitable('https://hitrecord.org/records/2954362/invalid')

# Generated at 2022-06-26 12:11:57.753380
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    d=HitRecordIE()
    assert None!=d

# Generated at 2022-06-26 12:11:59.624226
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.extractor == HitRecordIE

# Generated at 2022-06-26 12:12:01.941799
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:12:02.826526
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
     HitRecordIE('HitRecord', 'HitRecord')

# Generated at 2022-06-26 12:12:06.297651
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL
    assert HitRecordIE()._TEST == HitRecordIE._TEST

# Generated at 2022-06-26 12:12:09.767156
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_input = 'https://hitrecord.org/records/2954362'
    test_instance = HitRecordIE()
    expected_result = True
    actual_result = test_instance._match_id(test_input)
    assert(expected_result == actual_result)



# Generated at 2022-06-26 12:12:11.544336
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie


# Generated at 2022-06-26 12:12:12.298111
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:12:19.560291
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	info_extractor_service = HitRecordIE();
	assert info_extractor_service._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)', 'Verifying Unit Test HitRecordIE._VALID_URL'
	assert info_extractor_service._TEST['url'] == 'https://hitrecord.org/records/2954362', 'Verifying Unit Test HitRecordIE._TEST[\'url\']'
	assert info_extractor_service._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71', 'Verifying Unit Test HitRecordIE._TEST[\'md5\']'

# Generated at 2022-06-26 12:12:20.367525
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:12:50.412618
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('HitRecordIE', 'https://hitrecord.org/records/2954362')
    assert ie.IE_NAME == 'HitRecordIE'
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:12:51.157119
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:12:58.939769
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    tester = HitRecordIE('https://hitrecord.org/records/2954362')
    assert tester.url == 'https://hitrecord.org/records/2954362'
    assert tester.video_id == '2954362'

# Generated at 2022-06-26 12:13:09.934291
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video_unit_test = HitRecordIE()
    
    video_unit_test.set_downloader('youtube_dl')
    video_unit_test.set_downloader_parameters(params={})
    video_unit_test.set_progress_hooks([]);
    video_unit_test.set_worker_threads(1);
    video_unit_test.set_file_downloader_threads(1);
    video_unit_test.set_socket_timeout(10);
    video_unit_test.set_outside_downloader(None);

    assert (video_unit_test.get_progress_hooks() == [])
    assert (video_unit_test.get_worker_threads() == 1)
    assert (video_unit_test.get_file_downloader_threads() == 1)

# Generated at 2022-06-26 12:13:10.729055
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	pass

# Generated at 2022-06-26 12:13:13.111511
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie = HitRecordIE()



# Generated at 2022-06-26 12:13:13.585180
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:13:15.006154
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()


# Generated at 2022-06-26 12:13:16.884196
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('youtube:K0ibBPhiaG0')
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:13:20.556209
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    match = ie._VALID_URL
    matches = HitRecordIE._match_id(match)

# Generated at 2022-06-26 12:14:07.924750
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('test','test','test','test','test','test','test','test')
    print(ie.ie_key())
    print(ie.ie_key())

# Generated at 2022-06-26 12:14:09.832614
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_instance=HitRecordIE()

# Generated at 2022-06-26 12:14:19.506592
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:14:23.947470
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:14:25.879527
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	instance = HitRecordIE()
	instance = HitRecordIE()

# Generated at 2022-06-26 12:14:33.639767
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('')
    assert isinstance(ie._VALID_URL, compat_str)
    assert ie.SUCCESS == 'SUCCESS'
    assert ie.FAILED == 'FAILED'
    assert ie._request_webpage == InfoExtractor._request_webpage
    assert ie._download_json == InfoExtractor._download_json
    assert ie._match_id == InfoExtractor._match_id
    assert ie._real_extract == InfoExtractor._real_extract
    assert ie._html_search_regex == InfoExtractor._html_search_regex
    assert ie._extract_info == InfoExtractor._extract_info
    assert ie._extract_info_dict == InfoExtractor._extract_info_dict
    assert ie._apply_descrambler == InfoExtractor._

# Generated at 2022-06-26 12:14:38.409813
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    hitRecordIE.suitable('https://hitrecord.org/records/2954362') == True
    hitRecordIE.suitable('https://hitrecord.org/records/295436') == False

# Generated at 2022-06-26 12:14:51.154176
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Test constructor of class HitRecordIE"""
    h = HitRecordIE()
    assert h.name == 'hitrecord'
    assert h._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert h.__doc__ == 'hitrecord.org extractor'
    assert h.IE_NAME == 'hitrecord'
    assert h.ie_key() == 'hitrecord'

# Generated at 2022-06-26 12:14:53.010796
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    e = HitRecordIE()
    print(e)
    return e

# Generated at 2022-06-26 12:15:03.623081
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    assert hitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:16:54.423220
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.FAVORITE_COUNT_SUFFIX == "_count"


# Generated at 2022-06-26 12:16:57.582869
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    print(ie)
    # True
    print(ie.IE_NAME in HitRecordIE.ie_key())

# Generated at 2022-06-26 12:16:59.652833
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/4568234")

# Generated at 2022-06-26 12:17:02.654261
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'Hit Record'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:17:04.698972
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	he = HitRecordIE(None)

# Generated at 2022-06-26 12:17:05.497346
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:17:12.460222
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # Check if given_id is same as required_id
    given_id = "2954362"
    required_id = ie._match_id(ie._VALID_URL)
    assert required_id == given_id
    # Check if the id is valid or not
    given_id = "2954362"
    required_id = ie._match_id(ie._VALID_URL)
    assert given_id == required_id

# Generated at 2022-06-26 12:17:15.462652
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Initializing an instance of class HitRecordIE
    h = HitRecordIE()
    print("test_HitRecordIE: ", h)

# Generated at 2022-06-26 12:17:21.235237
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Unit test for constructor of class HitRecordIE
    """
    # The following is the URL to be extracted.
    url = "https://hitrecord.org/records/2954362"
    # The following is an extractor created.
    extractor = HitRecordIE(url)

# Generated at 2022-06-26 12:17:33.134808
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')
    assert(ie._TEST['url'] == 'https://hitrecord.org/records/2954362')
    assert(ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71')
    assert(ie._TEST['info_dict']['id'] == '2954362')
    assert(ie._TEST['info_dict']['ext'] == 'mp4')
    assert(ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)')