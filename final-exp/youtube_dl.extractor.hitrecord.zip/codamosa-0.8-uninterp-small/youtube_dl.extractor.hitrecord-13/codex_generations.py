

# Generated at 2022-06-26 12:10:37.291738
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert (True)


# Generated at 2022-06-26 12:10:38.573604
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()

# Generated at 2022-06-26 12:10:43.759718
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    if not HitRecordIE:
        assert False, 'HitRecordIE definition error'
    assert HitRecordIE, 'constructor error'

class_name = HitRecordIE.__name__

# Generated at 2022-06-26 12:10:52.265292
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()
    assert HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:10:53.076601
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-26 12:10:55.027181
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_0 = HitRecordIE()
    # hit_record_i_e_0._real_extract(hit_record_i_e_0, 'https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:11:04.006916
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:11:08.383230
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        assert isinstance(HitRecordIE(), InfoExtractor)
    except AssertionError as e:
        print('test_HitRecordIE failed: AssertionError raised')


# Generated at 2022-06-26 12:11:09.524229
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert callable(HitRecordIE._real_extract)

# Generated at 2022-06-26 12:11:19.732998
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:11:25.893092
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-26 12:11:31.488822
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.VALID_URL == '^https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:11:38.222675
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert not ie.suitable('https://coub.com/view/1x0v1')
    assert ie.IE_NAME == 'hitrecord'



# Generated at 2022-06-26 12:11:43.261832
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test for instance of class HitRecordIE
    ie = HitRecordIE()
    assert isinstance(ie, HitRecordIE)

    # Test for class attributes of HitRecordIE
    assert ie._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-26 12:11:45.090235
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ext = ie.ie_key()
    assert ext == 'HitRecord'

# Generated at 2022-06-26 12:11:46.540715
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(InfoExtractor())

# Generated at 2022-06-26 12:11:46.840019
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:11:52.060538
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE('https://www.hitrecord.org/records/2954362')
    assert (hitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-26 12:11:52.897162
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:11:54.993621
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except:
        return False
    return True

# Generated at 2022-06-26 12:12:09.205048
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    url = 'https://hitrecord.org/records/2954362'
    video_id = ie._match_id(url)
    # TODO: increase parameter values of assertEqual of hitRecordIE
    assert video_id.__class__.__name__ == 'str'
    assert video_id.__len__() == int(7)

# Generated at 2022-06-26 12:12:10.174115
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test: Create an instance of class HitRecordIE
    HitRecordIE()

# Generated at 2022-06-26 12:12:14.198639
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    try:
        ie.suitable("https://hitrecord.org/records/2954362")
        assert(True)
    except AssertionError:
        assert(False)

# Generated at 2022-06-26 12:12:21.884057
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # The url of video
    url = 'https://hitrecord.org/records/2954362'
    # Relevant info of video

# Generated at 2022-06-26 12:12:24.772989
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-26 12:12:27.598515
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:12:28.308953
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:12:30.498954
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('www.hitrecord.org')

# Generated at 2022-06-26 12:12:36.390734
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	hitrecordIE = HitRecordIE('https://hitrecord.org/records/2954362')
	assert(hitrecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')
test_HitRecordIE()

# Generated at 2022-06-26 12:12:37.963191
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362');

# Generated at 2022-06-26 12:12:57.929842
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# TODO:
	return 0

# Generated at 2022-06-26 12:13:09.401653
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:13:13.597802
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Using valid url
    HitRecordIE('https://hitrecord.org/records/2954362')
    # Using invalid url
    HitRecordIE('https://hitrecord.org/')

# Generated at 2022-06-26 12:13:14.119638
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-26 12:13:14.558911
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:13:15.376230
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:13:16.489652
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    HitRecordIE.__init__(ie)

# Generated at 2022-06-26 12:13:29.416008
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.__name__ == 'hitrecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:13:32.441989
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    x = HitRecordIE(HitRecordIE._VALID_URL, HitRecordIE._TEST)
    assert x._TEST == HitRecordIE._TEST

# Generated at 2022-06-26 12:13:32.843764
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:14:21.738323
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert ie is not None

# Generated at 2022-06-26 12:14:24.357249
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.__class__.__name__ == 'HitRecordIE'

# Generated at 2022-06-26 12:14:28.674567
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE({})

    except:
        print("Unit test for constructor of class HitRecordIE is failed!")
        assert False

    print("Unit test for constructor of class HitRecordIE is successful!")
    assert True


# Generated at 2022-06-26 12:14:35.766022
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from .common import InfoExtractor
    ie = InfoExtractor()
    ie.add_info_extractor(HitRecordIE)

    video_id = '2954362'
    url = 'https://hitrecord.org/records/%s' % video_id
    ie.extract(url)


# Generated at 2022-06-26 12:14:38.817390
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:14:39.562416
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-26 12:14:40.651447
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE({})

# Generated at 2022-06-26 12:14:43.652803
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    a = HitRecordIE()
    assert a._VALID_URL is not None
    assert a._TEST is not None

# Generated at 2022-06-26 12:14:44.717734
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:14:48.405429
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("foo", "bar")
    assert ie.ie_key() == "HitRecord"
    assert ie.ie_name() == "hitrecord.org"

# Generated at 2022-06-26 12:16:23.027512
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert(HitRecordIE() is not None)


# Generated at 2022-06-26 12:16:24.242749
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-26 12:16:26.715756
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:16:35.626810
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HRIE = HitRecordIE()
	assert HRIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:16:42.700049
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE('', 'https://hitrecord.org/records/2954362', '')
    assert hitRecord.url_result.get('url') == 'https://hitrecord.org/records/2954362'
    assert hitRecord.proxy == ''
    assert hitRecord.url == 'https://hitrecord.org/records/2954362'

# Generated at 2022-06-26 12:16:43.562505
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE

# Generated at 2022-06-26 12:16:44.791088
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("HitRecordIE")



# Generated at 2022-06-26 12:16:47.925556
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE("hitrecord", "https://hitrecord.org/records/2954362")

# Generated at 2022-06-26 12:16:56.592733
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video_id = '2954362'
    title = 'A Very Different World (HITRECORD x ACLU)'
    video_url = 'https://hitrecord.org/uploads/file/file/104611/HQ_A-Very-Different-World.mp4?AWSAccessKeyId=AKIAISFZFSMOQ2W7XHJA&Expires=1534961580&Signature=eaAKs78ZlN%2FpllACjfHHX9RvjKk%3D'
    duration = 139.327
    timestamp = 1471557582
    uploader = 'Zuzi.C12'
    uploader_id = '362811'
    uploader_url = 'https://hitrecord.org/users/Zuzi.C12'


# Generated at 2022-06-26 12:17:02.003998
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from . import HitRecordIE
    from ..compat import compat_str
    from ..utils import (
        clean_html,
        float_or_none,
        int_or_none,
        try_get,
    )
    HitRecordIE.test(url='https://hitrecord.org/records/2954362', output='test.mp4')