

# Generated at 2022-06-26 12:10:44.396091
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert(hit_record_i_e_0.valid_url('https://hitrecord.org/records/2954362') == True)


# Generated at 2022-06-26 12:10:46.348590
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_0 = HitRecordIE()


# Generated at 2022-06-26 12:10:46.877953
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:10:48.186706
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()


# Generated at 2022-06-26 12:10:49.678177
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()


# Generated at 2022-06-26 12:11:01.772457
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()
    assert hit_record_i_e is not None
    # test_valid_url()
    assert hit_record_i_e._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    # test_TEST

# Generated at 2022-06-26 12:11:03.498680
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_0 = HitRecordIE()

# Generated at 2022-06-26 12:11:04.693965
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._real_extract(
        "https://hitrecord.org/records/2954362")

# Generated at 2022-06-26 12:11:16.755160
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_0 = HitRecordIE()
    assert (type(hit_record_i_e_0) == HitRecordIE)

    assert (hit_record_i_e_0._VALID_URL ==
            'https?://(?:www\\.)?hitrecord\\.org/records/(?P<id>\\d+)')
    assert (hit_record_i_e_0._TEST['url'] ==
            'https://hitrecord.org/records/2954362')
    assert (hit_record_i_e_0._TEST['md5'] ==
            'fe1cdc2023bce0bbb95c39c57426aa71')
    assert (hit_record_i_e_0._TEST['info_dict']['id'] == '2954362')
   

# Generated at 2022-06-26 12:11:18.821366
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()
    

# Generated at 2022-06-26 12:11:29.787625
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()

# Generated at 2022-06-26 12:11:30.970043
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-26 12:11:42.967661
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert hit_record_i_e_0._VALID_URL == r"https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"

# Generated at 2022-06-26 12:11:44.921224
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_1 = HitRecordIE()


# Generated at 2022-06-26 12:11:50.427742
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    _VALID_URL = r'httpx://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert HitRecordIE.get_test_cases()[0]['url'] == _VALID_URL
    assert HitRecordIE.get_test_cases()[0]['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'



# Generated at 2022-06-26 12:11:54.457408
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert(HitRecordIE(
        {
            'url': '',
            'md5': '',
            'info_dict': {}
        }
    )) != None


# Generated at 2022-06-26 12:11:59.195707
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  hit_record_i_e_1 = HitRecordIE()
  assert hit_record_i_e_1 != None

#Unit test for method _real_extract of class HitRecordIE

# Generated at 2022-06-26 12:12:01.857173
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_0 = HitRecordIE()
    if hit_record_i_e_0 is not None:
        assert True
    else:
        assert False


# Generated at 2022-06-26 12:12:03.380882
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor_1 = HitRecordIE()
    assert(info_extractor_1 != None)

# Generated at 2022-06-26 12:12:05.475826
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_0 = HitRecordIE()



# Generated at 2022-06-26 12:12:14.500906
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:12:20.398682
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	hitrecord = HitRecordIE().extract('https://hitrecord.org/records/2954362')
	expected_fields = ['id', 'url', 'title', 'description', 'duration', 'timestamp', 'uploader', 'uploader_id', 'view_count', 'like_count', 'comment_count', 'tags'];

	for field in expected_fields:
		assert field in hitrecord
		assert hitrecord[field] is not None
		assert isinstance(hitrecord[field], type(hitrecord['duration']))

# Generated at 2022-06-26 12:12:22.899536
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        info_extractor = HitRecordIE()
    except:
        assert False

# Generated at 2022-06-26 12:12:24.546313
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()
    return True

# Generated at 2022-06-26 12:12:25.354570
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:12:28.751478
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    try:
        assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    except AssertionError:
        return False
    return True

# Generated at 2022-06-26 12:12:40.330491
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    '''Unit test for HitRecordIE class'''
    # test valid URL: https://hitrecord.org/records/2954362
    test_class = HitRecordIE()
    test_class._match_id("https://hitrecord.org/records/2954362") == "2954362"

    # test valid URL: https://www.hitrecord.org/records/2954362
    test_class = HitRecordIE()
    test_class._match_id("https://www.hitrecord.org/records/2954362") == "2954362"

    # test invalid URL: https://hitrecord.org/records/123
    test_class = HitRecordIE()
    test_class._match_id("https://hitrecord.org/records/123") == None

# Generated at 2022-06-26 12:12:42.942360
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie is not None

# Generated at 2022-06-26 12:12:43.754414
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:12:47.091560
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    construct = lambda url: HitRecordIE._build_request(HitRecordIE._VALID_URL, url)
    assert construct('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:13:06.644982
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info = HitRecordIE()
    assert info.suitable('https://hitrecord.org/records/2954362')
    assert info.suitabl

# Generated at 2022-06-26 12:13:09.259014
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL.match('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:13:10.656268
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
     HitRecordIE._TEST

# Generated at 2022-06-26 12:13:16.335733
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    class_to_test = HitRecordIE()
    class_to_test._match_id('https://hitrecord.org/records/2954362')
    class_to_test._download_json('https://hitrecord.org/api/web/records/2954362', '2954362')

# Generated at 2022-06-26 12:13:19.489083
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._download_webpage == ie._download_webpage_handle

# Generated at 2022-06-26 12:13:20.231342
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE()

# Generated at 2022-06-26 12:13:21.550931
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-26 12:13:22.907684
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie

# Generated at 2022-06-26 12:13:24.268074
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('HitRecordIE')

# Generated at 2022-06-26 12:13:28.487920
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE('hitrecord')
    assert hitrecord._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Unittest for method extract of class HitRecordIE

# Generated at 2022-06-26 12:14:19.150546
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('HitRecord')
    ie._VALID_URL = r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:14:31.392505
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# Testing with valid url
	url = "https://hitrecord.org/records/2954362"
	ie = HitRecordIE()
	# Check that url from _RE matches url
	assert ie._VALID_URL == ie._match_id(url)
	# Check that url extracts id from url
	assert ie._match_id(url) == "2954362"
	# Check if extractor works
	hitRecord = ie.extract(url)
	assert hitRecord

# Generated at 2022-06-26 12:14:36.348248
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'hitrecord'
    assert ie.supported_url() == ie._VALID_URL

# Generated at 2022-06-26 12:14:42.209928
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE('https://hitrecord.org/records/2954362')
    assert info_extractor._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert info_extractor._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert info_extractor._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert info_extractor._TEST['info_dict']['id'] == '2954362'
    assert info_extractor._TEST['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-26 12:14:46.361150
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    url = 'https://hitrecord.org/records/2954362'
 
    ie.test(url)

# Generated at 2022-06-26 12:14:49.309505
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # No need to test this class
    pass


if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-26 12:14:53.148301
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except Exception as e:
        raise AssertionError('Fail test_HitRecordIE() : ' + str(e))



# Generated at 2022-06-26 12:14:54.869435
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('', True)

# Generated at 2022-06-26 12:14:57.637602
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    x = HitRecordIE()
    print(x.__class__.__name__)

# Generated at 2022-06-26 12:14:59.547109
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('https://hitrecord.org/records/2954362') is not None

# Generated at 2022-06-26 12:16:32.930020
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hrietest = HitRecordIE()
    assert (hrietest._TEST['url'] == hrietest._VALID_URL)

# Generated at 2022-06-26 12:16:34.523902
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-26 12:16:36.060846
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    result = HitRecordIE()

# Generated at 2022-06-26 12:16:45.461391
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Checking constructor
    try:
        HitRecordIE('https://hitrecord.org/records/2954362')
    except TypeError as e:
        print("TypeError: " + str(e))
        assert False
    except:
        assert False

    # Checking video_id retrieving
    try:
        video_id = HitRecordIE._match_id('https://hitrecord.org/records/2954362')
        assert video_id == '2954362'
    except:
        assert False

    # Checking get_url method

# Generated at 2022-06-26 12:16:56.020225
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('http://hitrecord.org/records/2954362')
    assert ie.suitable('https://hitrecord.org/records/2954363')
    assert ie.suitable('https://hitrecord.org/records/2954364')
    assert ie.suitable('https://hitrecord.org/records/2954365')
    assert ie.suitable('https://hitrecord.org/records/2954366')
    assert not ie.suitable('https://hitrecord.org/records/2954367')
    assert not ie.suitable('https://hitrecord.org/records/2954368')

# Generated at 2022-06-26 12:17:04.284106
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE(): 
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:17:04.944450
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-26 12:17:07.311638
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:17:09.175370
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:17:13.442894
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	class_constructor = getattr(HitRecordIE, '__init__')
	def_init = getattr(InfoExtractor, '__init__')
	def_init(HitRecordIE, 'HitRecordIE', 'hitrecord')
	setattr(InfoExtractor, '__init__', def_init)
	HitRecordIE()
	class_constructor(HitRecordIE, 'HitRecordIE', 'hitrecord')