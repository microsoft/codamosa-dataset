

# Generated at 2022-06-26 12:10:41.083615
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    title_0 = HitRecordIE().IE_NAME
    assert title_0 == 'hitrecord'
    description_0 = HitRecordIE()._VALID_URL
    assert description_0 == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    id_0 = HitRecordIE()._TEST

# Generated at 2022-06-26 12:10:45.702991
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.__bases__ == (InfoExtractor,)
    assert HitRecordIE._VALID_URL == HitRecordIE._VALID_URL.replace('hitrecord', 'hitrecord')
    payload = HitRecordIE._TEST.copy()
    payload["url"] = HitRecordIE._TEST["url"].format(HitRecordIE._VALID_URL)
    # Checking if constructor of class HitRecordIE is launch without issues.
    with HitRecordIE() as hit_record_i_e:
        # Checking if method of class HitRecordIE is launch without issues.
        hit_record_i_e._real_extract(payload["url"])
        # Checking if member of class HitRecordIE is launch without issues.
        payload["md5"] == hit_record_i_e._TEST["md5"]


# Generated at 2022-06-26 12:10:47.746774
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # ==> Verify that class HitRecordIE has inherited from class InfoExtractor
    assert issubclass(HitRecordIE, InfoExtractor)



# Generated at 2022-06-26 12:10:50.836001
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert isinstance(hit_record_i_e_0, HitRecordIE)


# Generated at 2022-06-26 12:10:55.737122
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()
    try:
        hit_record_i_e.assertRaisesRegexp(AssertionError, Exception)
    except:
        assert False


# Generated at 2022-06-26 12:10:56.519482
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:10:58.263127
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_0 = HitRecordIE()

# Generated at 2022-06-26 12:10:59.152028
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()

# Generated at 2022-06-26 12:11:00.992498
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_0 = HitRecordIE()


# Generated at 2022-06-26 12:11:02.249839
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()

# Generated at 2022-06-26 12:11:20.105847
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    video_id = hit_record_i_e_0._match_id(url)
    video = hit_record_i_e_0._download_json('https://hitrecord.org/api/web/records/%s' % video_id, video_id)
    video_url = video['source_url']['mp4_url']
    if video_url.endswith('.mp4') == False:
        raise AssertionError("Failed to load the video")
    hit_record_i_e_0._real_extract(url)


# Generated at 2022-06-26 12:11:20.918549
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-26 12:11:23.760888
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE() is not None, "Constructor for HitRecordIE() is broken"


# Generated at 2022-06-26 12:11:25.581098
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()


# Generated at 2022-06-26 12:11:26.475637
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    i = HitRecordIE()


# Generated at 2022-06-26 12:11:28.010089
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert test_case_0() == True

# Generated at 2022-06-26 12:11:32.966092
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()
    hit_record_i_e.set_duration(799.927)
    hit_record_i_e.set_duration(1000)


# Generated at 2022-06-26 12:11:35.450572
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert isinstance(hit_record_i_e_0, HitRecordIE)



# Generated at 2022-06-26 12:11:37.201988
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_case_0()

# Generated at 2022-06-26 12:11:39.620536
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    _VALID_URL_0 = 'https://hitrecord.org/records/2954362'
    ie_0 = HitRecordIE(_VALID_URL_0)

# Generated at 2022-06-26 12:11:50.505792
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(False)

# Generated at 2022-06-26 12:11:51.595738
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-26 12:11:56.737672
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'hitrecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-26 12:11:58.070037
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-26 12:11:59.530398
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    construct_test = HitRecordIE()

# Generated at 2022-06-26 12:12:00.451086
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(None)

# Generated at 2022-06-26 12:12:03.068254
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'

    ie = HitRecordIE(ie_key='test_key')
    assert ie.IE_NAME == 'test_key'

# Generated at 2022-06-26 12:12:06.477951
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Constructs an instance of HitRecordIE.
    """
    ie_HitRecord = HitRecordIE()

test_HitRecordIE.skip = 'see test_HitRecordIE.pass'  # to do: make test pass

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-26 12:12:06.948745
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:12:09.298955
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    name = 'HitRecord'
    HitRecordIE(name)
    if name != HitRecordIE.ie_key():
        raise Exception('test fails')

# Generated at 2022-06-26 12:12:28.570997
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:12:29.756655
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:12:37.178348
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://www.hitrecord.org/records/2954362'
    class_name = 'HitRecord'
    ie = HitRecordIE(url)
    yaml_text = ie._get_yaml_text()
    assert yaml_text.startswith('- %s\r\n  - %s' % (class_name, url))


# Generated at 2022-06-26 12:12:39.665001
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:12:41.254497
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    i = HitRecordIE()
    assert i.test()

# Generated at 2022-06-26 12:12:42.062331
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:12:43.510677
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HitRecordIE();
	HitRecordIE();
	HitRecordIE();
	HitRecordIE();



# Generated at 2022-06-26 12:12:44.416979
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:12:46.789948
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(name='HitRecord')._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-26 12:12:51.218636
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)', \
        "HitRecordIE._VALID_URL has unexpected value."

# Generated at 2022-06-26 12:13:28.898681
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:13:34.174727
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_info_dict = HitRecordIE._TEST['info_dict']
    ie = HitRecordIE()
    ie._real_initialize()
    assert_equal(ie._downloader.params['outtmpl'], '%(id)s.mp4')

# Generated at 2022-06-26 12:13:35.593348
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == ie.IE_DESC
    assert ie.IE_NAME in HitRecordIE.ie_key()

# Generated at 2022-06-26 12:13:48.313000
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecordIE = HitRecordIE()
    valid_uuid = "4fc4c7ff-9647-4d7e-8012-095b106d5fe3"
    invalid_uuid = "4fc4c7ff96474d7e8012095b106d5fe3"
    print("valid_uuid = [%s]"%valid_uuid)
    print("invalid_uuid = [%s]"%invalid_uuid)
    print("is_valid_uuid(valid_uuid) = %s"% hitrecordIE._is_valid_uuid(valid_uuid))
    print("is_valid_uuid(invalid_uuid) = %s"% hitrecordIE._is_valid_uuid(invalid_uuid))

# Generated at 2022-06-26 12:13:59.972738
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert isinstance(ie._TEST['info_dict'], dict)
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert ie

# Generated at 2022-06-26 12:14:00.943250
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE({})

# Generated at 2022-06-26 12:14:10.451582
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:14:11.250761
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:14:12.400185
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    (HitRecordIE)

# Generated at 2022-06-26 12:14:17.837965
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Check that a HitRecordIE is created for a valid url
    HitRecordIE(HitRecordIE._VALID_URL)

    # Check that a HitRecordIE is not created for a invalid url
    try:
        HitRecordIE('https://hitrecord.org/records/')
        assert(False)
    except RegexMatchError:
        pass

# Generated at 2022-06-26 12:15:48.949244
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE('https://hitrecord.org/records/2954362') != None


# Generated at 2022-06-26 12:15:49.844291
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:15:56.757328
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    i = HitRecordIE()
    assert i._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:16:00.842994
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # Test for instantiation of class HitRecordIE
    assert isinstance(ie, HitRecordIE)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-26 12:16:06.596940
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:16:10.122694
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE();
    assert hitrecord.VIDEO_URL=='https://hitrecord.org/records/2954362'

# Generated at 2022-06-26 12:16:16.092845
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    he = HitRecordIE()
    assert he._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert he._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert he._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert he._TEST['info_dict']['id'] == '2954362'
    assert he._TEST['info_dict']['ext'] == 'mp4'
    assert he._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-26 12:16:26.270973
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:16:30.516550
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    e = HitRecordIE('hitrecord', 'org')
    assert e.ie_key() == 'HitRecord'
    assert e.ie_key() in e.gen_extractors()

# Generated at 2022-06-26 12:16:36.512513
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract(URL)

    urlparse.urljoin(URL, snippet_url)
    urlparse.urljoin(URL, snippet_url)
    urlparse.urljoin(URL, snippet_url)
    
    # FIXME: Can it be refactored to instantiate different classes?