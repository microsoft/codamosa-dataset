

# Generated at 2022-06-26 12:10:36.070106
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE


# Generated at 2022-06-26 12:10:37.949634
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # No argument
    hit_record_i_e_1 = HitRecordIE()

    # One argument
    # hit_record_i_e_2 = HitRecordIE(url)

# Generated at 2022-06-26 12:10:38.703142
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-26 12:10:41.538804
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_case_0()

# Generated at 2022-06-26 12:10:43.547058
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_1 = HitRecordIE()

# Generated at 2022-06-26 12:10:52.176302
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # function setUp
    hit_record_i_e = HitRecordIE()
    assert hit_record_i_e._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert hit_record_i_e._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert hit_record_i_e._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert hit_record_i_e._TEST['info_dict']['id'] == '2954362'
    assert hit_record_i_e._TEST['info_dict']['ext'] == 'mp4'
    assert hit_record_i_e

# Generated at 2022-06-26 12:10:53.860935
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()

# Generated at 2022-06-26 12:10:56.025004
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.__name__ == "HitRecordIE"

# Generated at 2022-06-26 12:10:57.366371
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_case_0()


# Generated at 2022-06-26 12:10:59.114274
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.__name__ is not None
    assert HitRecordIE.__doc__ is n

# Generated at 2022-06-26 12:11:08.092285
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Unit test for the HitRecordIE class.
    """
    url = "https://hitrecord.org/records/2954362"
    ie = HitRecordIE()
    ie.extract(url)

# Generated at 2022-06-26 12:11:09.428359
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
     HitRecordIE('HitRecordIE', {})

# Generated at 2022-06-26 12:11:11.216593
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:11:15.503730
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Try to create instance of HitRecordIE
    """
    hitRecordIE = HitRecordIE()
    if hitRecordIE is not None:
        print("Unit test for HitRecordIE is passed")
    else:
        print("Unit test for HitRecordIE is failed")


# Generated at 2022-06-26 12:11:16.834085
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_object = HitRecordIE()
    assert test_object

# Generated at 2022-06-26 12:11:25.320196
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    load_tests = test_HitRecordIE.__dict__.get('pytest_load_tests')
    if load_tests is not None:
        # pytest magic
        load_tests(None, None, [])
    else:
        from unittest import TestLoader, main
        TestLoader.testMethodPrefix = 'test'
        main(module='test_HitRecord_IE', verbosity=2)

# Generated at 2022-06-26 12:11:25.945639
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:11:26.783607
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    h = HitRecordIE()

# Generated at 2022-06-26 12:11:30.822421
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = "https://hitrecord.org/records/2954362"
    info_extractor = HitRecordIE()
    info_extractor._real_extract(url)

# Generated at 2022-06-26 12:11:42.862497
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE("test_HitRecordIE")
    assert hitrecord._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:12:04.432548
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    ie._match_id('https://hitrecord.org/records/2954362')
    ie._download_json('https://hitrecord.org/api/web/records/2954362', '2954362')
    result = ie._real_extract('https://hitrecord.org/records/2954362')
    assert(result['id'] == '2954362')
    assert(result['url'] == 'https://s3.amazonaws.com/hr-record/819101/mp4/2954362.mp4')
    assert(result['title'] == 'A Very Different World (HITRECORD x ACLU)')

# Generated at 2022-06-26 12:12:08.475906
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Checks if the constructor of HitRecordIE is working correctly or not
    assert HitRecordIE(HitRecordIE._VALID_URL) is not None, \
        'The constructor of class HitRecordIE is not working correctly'


# Generated at 2022-06-26 12:12:10.834908
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecordIE = HitRecordIE()
    print (hitrecordIE)
    print (dir(hitrecordIE))

# Generated at 2022-06-26 12:12:20.398124
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test should be updated
    instance = HitRecordIE("https://hitrecord.org/records/2954362")
    assert instance.url == "https://hitrecord.org/records/2954362"
    assert instance._VALID_URL == r"https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"
    assert instance._TEST.get("url") == "https://hitrecord.org/records/2954362"
    assert instance._TEST.get("md5") == "fe1cdc2023bce0bbb95c39c57426aa71"
    assert instance._TEST.get("info_dict").get("id") == "2954362"
    assert instance._TEST.get("info_dict").get("ext") == "mp4"


# Generated at 2022-06-26 12:12:30.708839
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._VALID_URL = r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:12:37.141807
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test with a record URL.
    HitRecordIE()._real_initialize()

    # Test with a non-existent record URL.
    HitRecordIE()._real_initialize(url='https://hitrecord.org/records/2954362.notext')

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-26 12:12:47.632627
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie.get_id_re().match('https://hitrecord.org/records/2954362') is not None)
    assert(ie.get_id_re().search('https://hitrecord.org/records/2954362')['id'] == '2954362')
    assert(ie.get_id_re().match('https://hitrecord.org/records/2954363') is None)
    assert(ie.get_id_re().match('https://hitrecord.org/records/AAAAAAAAAA') is None)

# Generated at 2022-06-26 12:12:49.435487
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Construct and check
    assert HitRecordIE(HitRecordIE._VALID_URL)

# Generated at 2022-06-26 12:12:58.474080
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362') == True
    assert ie.suitable('https://www.hitrecord.org/records/2954362') == True
    assert ie.suitable('http://hitrecord.org/records/2954362') == True
    assert ie.suitable('http://www.hitrecord.org/records/2954362') == True
    assert ie.suitable('https://www.youtube.com/watch?v=dQw4w9WgXcQ') == False
    assert ie.suitable('https://www.dailymotion.com/video/x53bzx5') == False
    assert ie.suitable('https://www.dailymotion.com/records/2954362') == False

# Generated at 2022-06-26 12:13:09.670260
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Construct a HitRecordIE object and verify that it is correctly constructed.
    """
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:13:36.887356
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    expected_url = 'https://hitrecord.org/records/2954362'
    assert ie._url == expected_url, "Expected url to be %s and got %s " % (expected_url, ie._url)
    expected_video_id = '2954362'
    assert ie._video_id == expected_video_id, "Expected video id to be %s and got %s " % (expected_video_id, ie._video_id)

# Generated at 2022-06-26 12:13:37.627774
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE

# Generated at 2022-06-26 12:13:40.168271
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie_obj = HitRecordIE()
    assert ie_obj is not None

# Generated at 2022-06-26 12:13:43.335578
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert_equal(ie.IE_NAME, 'hitrecord')

# Generated at 2022-06-26 12:13:48.635383
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Unit test for constructor of class HitRecordIE
    """
    # Test for the case that initialization of HitRecordIE objects with valid URLs
    try:
        HitRecordIE(VALID_URL)
    except TypeError:
        assert False
    # Test for the case that initialization of HitRecordIE objects with invalid URLs
    try:
        HitRecordIE(INVALID_URL)
        assert False
    except RegexNotFoundError:
        assert True

# Generated at 2022-06-26 12:13:51.562074
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(HitRecordIE._VALID_URL)

# Generated at 2022-06-26 12:13:55.898891
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-26 12:13:57.159505
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    for t in HitRecordIE._TEST:
        HitRecordIE(t['url'])

# Generated at 2022-06-26 12:13:58.994140
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:14:00.574573
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:14:58.362507
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    valid_url = ie._VALID_URL
    test = ie._TEST
    test_url = test['url']
    assert valid_url == ie._VALID_URL
    assert test_url == ie._TEST['url']

# Generated at 2022-06-26 12:15:00.619078
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test URL does not contain the usual 'hitrecord.org', so make sure that it
    # is supported nonetheless
    return HitRecordIE('https://foo.hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:15:03.946422
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._match_id('https://hitrecord.org/records/3034983') == '3034983'

# Generated at 2022-06-26 12:15:10.120330
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie.ie_key() == 'HitRecord'
    assert ie.video_id == '2954362'

# Generated at 2022-06-26 12:15:14.640455
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == "hitrecord"
    assert ie.IE_DESC == "HITRECORD"
    assert len(ie._TESTS) == 1

# Generated at 2022-06-26 12:15:24.313299
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie.test_url("https://hitrecord.org/records/2954362"), 'hitrecord.org/records/2954362'
    assert ie.test_url("https://hitrecord.org/records/2954362") is True, 'hitrecord.org/records/2954362'
    assert ie.test_url("https://hitrecord.org/records/2954362", 'https://hitrecord.org/records/2954362')
    assert not ie.test_url("https://hitrecord.org/records/2954362", 'https://hitrecord.org/records/29543655')
   

# Generated at 2022-06-26 12:15:31.490274
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    exp_url = ie.url_result(
        'https://hitrecord.org/records/2954362',
        'HitRecord',
        '2954362'
    )
    assert exp_url.url == 'https://hitrecord.org/records/2954362'
    assert exp_url.ie_key == 'HitRecord'
    assert exp_url.video_id == '2954362'

# Generated at 2022-06-26 12:15:35.703225
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    assert hitRecordIE is not None


# Generated at 2022-06-26 12:15:37.057924
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE.test()

# Generated at 2022-06-26 12:15:41.221433
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie.IE_NAME == ie.ie_key())
    ie = HitRecordIE(False)
    assert(ie.IE_NAME == ie.ie_key())

# Generated at 2022-06-26 12:17:41.820620
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TEST')


# Generated at 2022-06-26 12:17:50.126163
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:17:53.272416
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test for Create Success
    try:
        HitRecordIE()
        assert True
    except:
        assert False

if __name__ == '__main__':
    test_HitRecordIE()

# Generated at 2022-06-26 12:17:55.662930
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE().extract(HitRecordIE._TEST['url'])['video_url'] == HitRecordIE._TEST['info_dict']['url']

# Generated at 2022-06-26 12:17:57.316962
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-26 12:17:58.039293
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE();

# Generated at 2022-06-26 12:18:00.685716
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_hitRecordIE = HitRecordIE({})
    assert type(test_hitRecordIE) is HitRecordIE
    return test_hitRecordIE

# Generated at 2022-06-26 12:18:05.841221
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    #assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-26 12:18:06.648861
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie

# Generated at 2022-06-26 12:18:07.915134
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == HitRecordIE._VALID_URL