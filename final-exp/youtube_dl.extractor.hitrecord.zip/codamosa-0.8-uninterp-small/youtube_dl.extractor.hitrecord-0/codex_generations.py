

# Generated at 2022-06-26 12:10:36.446321
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    hit_record_ie = HitRecordIE()

    assert isinstance(hit_record_ie, HitRecordIE)



# Generated at 2022-06-26 12:10:37.693767
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Call constructor
    hit_record_i_e_1 = HitRecordIE()


# Generated at 2022-06-26 12:10:49.703218
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_0 = HitRecordIE()
    assert hit_record_i_e_0.test_cases[0] == "test_case_0"
    assert hit_record_i_e_0.test_cases[1] == "test_case_1"
    assert hit_record_i_e_0.test_cases[2] == "test_case_2"
    assert hit_record_i_e_0.test_cases[3] == "test_case_3"
    assert hit_record_i_e_0.test_cases[4] == "test_case_4"
    assert hit_record_i_e_0.test_cases[5] == "test_case_5"


# Generated at 2022-06-26 12:10:53.073905
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    expected_result = HitRecordIE()
    actual_result = HitRecordIE
    assert expected_result == actual_result


# Generated at 2022-06-26 12:10:57.818354
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video_url = 'https://hitrecord.org/records/2954362'
    video_id = '2954362'

    hit_record_i_e = HitRecordIE()

    # Test for _match_id
    assert hit_record_i_e._match_id(video_url) == video_id

    # Test for _real_extract
    info_dict = hit_record_i_e._real_extract(video_url)
    assert 'id' in info_dict
    assert info_dict['id'] == video_id

# Generated at 2022-06-26 12:10:59.352306
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from HitRecordIE import HitRecordIE
    hit_record_i_e = HitRecordIE()


# Generated at 2022-06-26 12:11:12.063724
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print("Testing constructor")
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:11:14.719478
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()

if __name__ == "__main__":
    test_HitRecordIE()

# Generated at 2022-06-26 12:11:18.185452
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    # Test with no arguments passed
    hit_record_i_e_0 = HitRecordIE()
    if hit_record_i_e_0 is None:
        print("Constructor test case 0 passed.")
    else:
        print("Contstuctor test case 0 failed.")


# Generated at 2022-06-26 12:11:20.222107
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_0 = HitRecordIE()


# Generated at 2022-06-26 12:11:31.472093
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE


# Generated at 2022-06-26 12:11:43.173518
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_0 = HitRecordIE()
    assert hit_record_i_e_0._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:11:45.211296
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_1 = HitRecordIE()


# Generated at 2022-06-26 12:11:46.439573
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert callable(HitRecordIE.__init__)


# Generated at 2022-06-26 12:11:53.600270
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:11:55.866767
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()


# Generated at 2022-06-26 12:11:56.709650
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-26 12:12:06.375024
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    assert hitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:12:07.142586
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass


# Generated at 2022-06-26 12:12:09.706046
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_0 = HitRecordIE()
    assert hit_record_i_e_0 is not None

# Generated at 2022-06-26 12:12:24.550139
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print('HitRecordIE: Testing construction of class')
    try:
        HitRecordIE()
        print('HitRecordIE: Class construction test success')
    except TypeError:
        print('HitRecordIE: Class construction test failed')
        raise

# Generated at 2022-06-26 12:12:31.839002
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('hitrecord', 'https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['upload_date'] == '20160818'
    assert ie._TEST['info_dict']['uploader'] == 'Zuzi.C12'

# Generated at 2022-06-26 12:12:36.833115
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE('http://www.hitrecord.org/records/2954362')
    assert instance.url == 'https://hitrecord.org/records/2954362'
    assert instance.video_id == '2954362'

# Generated at 2022-06-26 12:12:40.662820
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test url
    url = 'https://hitrecord.org/records/2954362'
    # Create object from url
    HitRecordIE(url)

# Generated at 2022-06-26 12:12:41.549131
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:12:51.127526
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:12:54.428069
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._match_id('https://hitrecord.org/records/2954362')
    assert ie._download_json('https://hitrecord.org/api/web/records/2954362', '2954362')
    assert ie._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:13:06.721850
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'HitRecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST[
        'url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST[
        'md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-26 12:13:08.048755
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()


# Generated at 2022-06-26 12:13:08.517867
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:13:28.765107
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	try:
		HitRecordIE()
	except Exception as e:
		print("HitRecordIE(): ", e)


# Generated at 2022-06-26 12:13:38.746751
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert HitRecordIE._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert HitRecordIE._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-26 12:13:41.547793
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract("https://hitrecord.org/records/2954362")

# Generated at 2022-06-26 12:13:50.853490
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:14:00.530684
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from .common import InfoExtractor
    from .common import compat_str
    from .common import compat_urllib_request
    from .common import unescapeHTML
    from .common import update_url_query
    from .common import USER_AGENTS
    from .common import US_RATINGS
    from .common import UUID
    from .common import IEServerError
    from .common import ParseError
    from .common import extract_attributes
    from .common import ExtractorError
    from .common import int_or_none
    from .common import float_or_none
    from .common import urlencode_postdata
    from .common import xpath_text
    from .common import xpath_attr
    from .common import xpath_element
    from .common import xpath_with_ns

# Generated at 2022-06-26 12:14:05.607805
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_video_ie = HitRecordIE.ie_keywords['hitrecord'](HitRecordIE.ie_keywords)
    assert isinstance(test_video_ie, HitRecordIE)
    assert test_video_ie.IE_NAME == 'hitrecord'

# Generated at 2022-06-26 12:14:07.437175
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE("https://hitrecord.org/records/2954362") is not None


# Generated at 2022-06-26 12:14:10.797596
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362') == True

# Generated at 2022-06-26 12:14:15.236895
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.test()


# Generated at 2022-06-26 12:14:16.638889
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL

# Generated at 2022-06-26 12:15:01.585018
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HitRecordIE()

# Generated at 2022-06-26 12:15:03.517905
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert type(ie) == HitRecordIE

# Generated at 2022-06-26 12:15:04.379203
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:15:05.174298
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:15:07.804756
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:15:08.683630
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:15:15.422016
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    e = HitRecordIE('http://www.hitrecord.org/records/2954362');
    assert e._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:15:18.850239
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test = HitRecordIE()
    test._real_extract(test._TEST['url'])

# Generated at 2022-06-26 12:15:21.140848
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Test constructor of class HitRecordIE"""
    assert HitRecordIE(None)._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-26 12:15:23.935767
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Unit test for constructor of class HitRecordIE"""
    inst = HitRecordIE()
    assert inst.ie_key() == 'HitRecord'

# Generated at 2022-06-26 12:17:09.651534
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("");

# Generated at 2022-06-26 12:17:11.528040
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.extractor_key() == 'hitrecord'

# Generated at 2022-06-26 12:17:23.275419
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-26 12:17:24.036845
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:17:24.873113
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:17:34.299852
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(HitRecordIE._VALID_URL)
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:17:39.345170
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    unit = HitRecordIE()
    print(unit._TEST['url'])
    print(unit._TEST['id'])
    print(unit._TEST['info_dict'])

# Generated at 2022-06-26 12:17:40.165506
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:17:47.457313
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    @staticmethod
    def extract_info(url, expected_results):
        # The following code is copied from the file common.py
        ie = HitRecordIE()
        video_id = ie._match_id(url)
        webpage = ie._download_webpage(url, video_id)
        info = ie._extract_info(url, webpage)
        for field, value in expected_results.items():
            assert info[field] == value


# Generated at 2022-06-26 12:17:47.913349
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass