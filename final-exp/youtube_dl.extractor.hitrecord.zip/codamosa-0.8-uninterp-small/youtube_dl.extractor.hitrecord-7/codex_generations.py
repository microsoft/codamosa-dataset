

# Generated at 2022-06-26 12:10:41.016103
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert 'hitrecord.org' in HitRecordIE._VALID_URL

# Generated at 2022-06-26 12:10:45.645915
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    video_id = '2954362'

# Generated at 2022-06-26 12:10:46.577510
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()

# Generated at 2022-06-26 12:10:53.831110
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL is 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:10:55.954654
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.__name__ == 'HitRecordIE'


# Generated at 2022-06-26 12:10:59.548543
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # test_case_0
    _url = "https://www.hitrecord.org/records/2954362"
    _expected_id = '2954362'
    assert HitRecordIE()._match_id(_url) == _expected_id

# Generated at 2022-06-26 12:11:00.330734
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:11:02.133793
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_0 = HitRecordIE()


# Generated at 2022-06-26 12:11:03.888750
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert callable(HitRecordIE) == 1


# Generated at 2022-06-26 12:11:16.423815
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_0 = HitRecordIE()
    assert hit_record_i_e_0._VALID_URL == 'http://(?:www.)?hitrecord.org/records/(?P<id>\d+)/#additional'
    assert hit_record_i_e_0._TEST.get('url') == 'http://hitrecord.org/records/2954362/'
    assert hit_record_i_e_0._TEST.get('md5') == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-26 12:11:23.472679
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE is not None, 'Unit test for constructor of class HitRecordIE failed.'


# Generated at 2022-06-26 12:11:25.789382
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable("https://hitrecord.org/records/2954362")

# Generated at 2022-06-26 12:11:26.938394
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE(HitRecordIE._TEST)

# Generated at 2022-06-26 12:11:28.278133
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_initialize()

# Generated at 2022-06-26 12:11:39.054577
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.SUCCESS == 0
    assert ie.FAILED == 1
    assert ie.SKIPPED == 2
    assert ie.EXCEPTION == 3
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_id() == 'hitrecord'
    assert ie.extract('https://hitrecord.org/records/2954362') == ie._download_json(
        'https://hitrecord.org/api/web/records/2954362', '2954362')

# Generated at 2022-06-26 12:11:43.115980
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.IE_NAME == 'hitrecord'

# Generated at 2022-06-26 12:11:52.217234
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

    # Test cases for constructor of HitRecordIE
    test_cases = (
        # test case #1: Valid URL
        {
            'url': 'https://hitrecord.org/records/2954362',
            'expected_id': '2954362',
        },
        # test case #2: Invalid URL
        {
            'url': 'https://hitrecord.org/records/21+',
            'expected_id': None,
        },
    )

    for test_case in test_cases:
        result = ie.suitable(test_case['url'])

        if test_case['expected_id'] is None:
            assert result is False
        else:
            assert ie._match_id(test_case['url']) == test_case['expected_id']


#

# Generated at 2022-06-26 12:11:59.667741
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://hitrecord.org/records/2954362")
    print("Created HitRecordIE with URL: ", ie.url)
    print("Created HitRecordIE with valid URL regex: ", ie._VALID_URL)
    print("Created HitRecordIE with video id: ", ie._match_id(ie.url))
    

# Generated at 2022-06-26 12:12:00.235063
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:12:01.142506
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    i = HitRecordIE()

# Generated at 2022-06-26 12:12:13.333336
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:12:21.733740
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'
    assert ie.ie_key() == ie.IE_NAME
    assert ie.ie_key() == ie.get_ie_key()
    assert ie.SITE_NAME == 'hitrecord.org'
    assert ie.VALID_URL == HitRecordIE._VALID_URL
    assert ie.VALID_URL == ie._VALID_URL
    assert ie.VALID_URL == ie.get_valid_url()
    assert ie.valid_url('https://www.hitrecord.org/records/2954361')
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert ie

# Generated at 2022-06-26 12:12:26.218178
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE()
    assert hitRecord is not None
    assert hitRecord._VALID_URL is not None
    assert hitRecord._TEST is not None

# Generated at 2022-06-26 12:12:27.419011
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord_test = HitRecordIE()

# Generated at 2022-06-26 12:12:28.628153
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE is not None

# Generated at 2022-06-26 12:12:38.264632
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    info_dict = ie.extract('https://hitrecord.org/records/2954362')
    assert info_dict['id'] == '2954362'
    assert info_dict['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert ie.suitable('https://hitrecord.org/records/2954362') is True
    assert ie.suitable('https://google.com/') is False

# Generated at 2022-06-26 12:12:39.245093
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:12:50.441174
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ie = HitRecordIE()
	urls = []

	#case 1, valid video
	url = 'https://hitrecord.org/records/2954362'

# Generated at 2022-06-26 12:12:51.281772
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:12:54.802727
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE.test()
    HitRecordIE.test(
        {'url': 'https://hitrecord.org/records/1091272','only_matching': True}
    )

# Generated at 2022-06-26 12:13:15.233880
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert isinstance(ie, HitRecordIE)

# Generated at 2022-06-26 12:13:16.376230
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-26 12:13:20.492003
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    if HitRecordIE.suitable(HitRecordIE._TEST['url']) is False:
        raise AssertionError("Unit test for HitRecordIE failed.")

# Generated at 2022-06-26 12:13:22.906705
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    global HitRecordIE
    HitRecordIE = HitRecordIE('hitrecord')
    assert HitRecordIE == HitRecordIE

# Generated at 2022-06-26 12:13:24.268591
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE is not None

# Generated at 2022-06-26 12:13:32.429597
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_data = HitRecordIE._TEST
    assert HitRecordIE._VALID_URL == test_data['url']
    assert HitRecordIE._TEST['md5'] == test_data['md5']
    assert HitRecordIE._TEST['id'] == test_data['id']
    assert HitRecordIE._TEST['title'] == test_data['title']
    assert HitRecordIE._TEST['description'] == test_data['description']
    assert HitRecordIE._TEST['duration'] == test_data['duration']
    assert HitRecordIE._TEST['timestamp'] == test_data['timestamp']
    assert HitRecordIE._TEST['upload_date'] == test_data['upload_date']
    assert HitRecordIE._TEST['uploader'] == test_data['uploader']
    assert HitRecordIE._T

# Generated at 2022-06-26 12:13:40.669169
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    t_url = HitRecordIE._TEST['url']
    t_id = HitRecordIE._TEST['info_dict']['id']
    t_md5 = HitRecordIE._TEST['md5']
    t_title = HitRecordIE._TEST['info_dict']['title']
    t_desc = HitRecordIE._TEST['info_dict']['description']
    t_down = HitRecordIE._TEST['info_dict']['downloader']
    t_uploader = HitRecordIE._TEST['info_dict']['uploader']
    
    # Checking a value of data member _VALID_URL
    m = HitRecordIE._VALID_URL
    x_url = HitRecordIE._TEST['url']
    assert(re.match(m, x_url))
    


# Generated at 2022-06-26 12:13:44.966410
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert(HitRecordIE()._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)")


# Generated at 2022-06-26 12:13:46.519005
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    assert hitRecordIE is not None

# Generated at 2022-06-26 12:13:47.312423
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:14:38.306866
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie is not None
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-26 12:14:39.062795
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HitRecordIE()

# Generated at 2022-06-26 12:14:40.722139
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE



# Generated at 2022-06-26 12:14:41.787635
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:14:42.597335
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:14:44.470788
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
   ie = HitRecordIE()

# Generated at 2022-06-26 12:14:45.286916
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:14:53.414952
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-26 12:14:57.713752
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE._VALID_URL == "https://hitrecord.org/records/(?P<id>\d+)"


# Generated at 2022-06-26 12:15:00.310953
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Test for constructor of class HitRecordIE
    """
    # Test for non-existing URL
    assert HitRecordIE._match_id(HitRecordIE._TEST['url']) == HitRecordIE._TEST['info_dict']['id']

# Generated at 2022-06-26 12:16:37.412467
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:16:39.474381
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE()
    hitRecord = HitRecordIE('hitRecord')

# Generated at 2022-06-26 12:16:42.610196
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    return ie.suitable('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:16:43.497795
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:16:51.716408
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"
    assert ie._TEST['url'] == "https://hitrecord.org/records/2954362"
    assert ie._TEST['md5'] == "fe1cdc2023bce0bbb95c39c57426aa71"

# Generated at 2022-06-26 12:16:52.882664
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    result = HitRecordIE('HitRecord')
    assert result

# Generated at 2022-06-26 12:16:56.020226
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    i = HitRecordIE()
    assert i._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:17:00.586708
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()._real_extract('https://hitrecord.org/records/2954362')
    
if __name__ == '__main__':
    test_HitRecordIE()

 


# Generated at 2022-06-26 12:17:02.238234
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:17:09.376093
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test for a valid url
    valid_url = 'https://hitrecord.org/records/2954362'
    HitRecordIE(valid_url)

    # Test for an invalid url
    invalid_url = 'https://hitrecord.org/records/2954362/12634812'
    HitRecordIE(invalid_url)