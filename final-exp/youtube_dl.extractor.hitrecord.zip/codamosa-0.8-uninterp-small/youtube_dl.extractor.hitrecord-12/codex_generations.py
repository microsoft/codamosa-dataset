

# Generated at 2022-06-26 12:10:43.263483
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_0 = HitRecordIE()
    assert(hit_record_i_e_0)


# Generated at 2022-06-26 12:10:45.154185
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_1 = HitRecordIE()



# Generated at 2022-06-26 12:10:51.577579
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # This case checks the constructor of class HitRecordIE with None parameter
    hit_record_i_e_1 = HitRecordIE(None, None, None)
    hit_record_i_e_2 = HitRecordIE(None, [2, 3], None)
    hit_record_i_e_3 = HitRecordIE(None, None, {"cookie": "thread"})
    hit_record_i_e_4 = HitRecordIE(None, [2, 3], {"cookie": "thread"})
    hit_record_i_e_5 = HitRecordIE(None, [2, 3], {"cookie": {'a': 11, 'b': 12}})



# Generated at 2022-06-26 12:10:53.494996
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE.__name__ == 'HitRecordIE'


# Generated at 2022-06-26 12:10:55.810154
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass # when constructor is implemented, remove this


# Generated at 2022-06-26 12:10:57.439055
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_0 = HitRecordIE()


# Generated at 2022-06-26 12:11:05.186082
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    from .common import InfoExtractor

    hit_record_i_e_0 = HitRecordIE()
    assert hasattr(hit_record_i_e_0, '_VALID_URL')
    assert hit_record_i_e_0._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert hasattr(hit_record_i_e_0, '_TEST')

# Generated at 2022-06-26 12:11:10.043525
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    
    from .common import InfoExtractor

    arg0 = HitRecordIE()
    assert isinstance(arg0, HitRecordIE)
    assert isinstance(arg0, InfoExtractor)


# Generated at 2022-06-26 12:11:20.135564
# Unit test for constructor of class HitRecordIE

# Generated at 2022-06-26 12:11:20.927014
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-26 12:11:26.974820
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert ie.get_test_cases() != None

# Generated at 2022-06-26 12:11:34.563546
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	from nose.tools import assert_true, assert_equal
	hitrecord = HitRecordIE()
	assert_equal(hitrecord._VALID_URL, r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')
	assert_true(hitrecord._TEST is not None)

# Generated at 2022-06-26 12:11:37.510720
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    HitRecordIE().match_url(url)

# Generated at 2022-06-26 12:11:38.500603
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  HitRecordIE()

# Generated at 2022-06-26 12:11:50.493951
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-26 12:11:53.332378
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:11:55.562948
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'

# Generated at 2022-06-26 12:11:57.737900
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	hitRecordIE = HitRecordIE()
	return hitRecordIE

# Generated at 2022-06-26 12:12:01.706230
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    assert HitRecordIE()._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:12:05.879502
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie.BRAND == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:12:22.485715
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	class HitRecordIE(InfoExtractor):
		_VALID_URL = r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:12:26.531792
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"

# Generated at 2022-06-26 12:12:31.315556
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE()
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:12:37.140714
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert isinstance( ie, InfoExtractor )
    assert isinstance( ie._VALID_URL, type(re.compile('pattern')) )
    assert hasattr( ie, '_real_extract')
    assert hasattr( ie, '_download_json')

# Generated at 2022-06-26 12:12:44.762303
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = "https://hitrecord.org/records/2954362"
    currentTest = HitRecordIE()
    currentTest._real_extract(url)
    assert currentTest._VALID_URL ==  r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:12:46.192588
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-26 12:12:47.160390
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:12:50.559308
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE("https://www.youtube.com/watch?v=IaM1hO6jXBo")
    assert ie.name == "HitRecordIE"

# Generated at 2022-06-26 12:12:56.292830
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert 'hitrecord.org' in ie.hosts
    assert ie.hosts[ie.canonical_name(ie.ie_key())] == ie.hosts['hitrecord.org']
    assert ie.hosts['hitrecord.org'] == HitRecordIE._VALID_URL
    assert ie.ie_key() == 'hitrecord'

# Generated at 2022-06-26 12:13:07.970523
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.match_url('https://hitrecord.org/records/2954362')
    assert ie.match_url('https://www.hitrecord.org/records/2954362')
    assert ie.match_url('https://www.hitrecord.org/records/2954362')
    assert not ie.match_url('https://www.hitrecord.org/')
    assert not ie.match_url('https://hitrecord.org/records/')
    assert not ie.match_url('https://hitrecord.org/records/abc123')
    assert not ie.match_url('https://hitrecord.org/')
    assert not ie.match_url('https://www.hitrecord.org')

# Generated at 2022-06-26 12:13:29.292770
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # Test with one example
    ie.extract('https://hitrecord.org/records/2954362')
    # Test with 0 videos
    ie.extract('https://hitrecord.org/records/')

# Generated at 2022-06-26 12:13:31.822091
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    return HitRecordIE()

# Unit tests for each of the sites processed by HitRecordIE

# Generated at 2022-06-26 12:13:35.765168
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test if HitRecordIE constructor is working
    # If constructor works well, we do not need to test any other
    # method of HitRecordIE
    assert HitRecordIE(HitRecordIE._VALID_URL)

# Generated at 2022-06-26 12:13:38.479007
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
        ie = HitRecordIE('http://hitrecord.org/records/2954362')
        assert ie.extractor()

# Generated at 2022-06-26 12:13:40.923085
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    obj = HitRecordIE()
    assert obj.ie_key() == 'HitRecord'

# Generated at 2022-06-26 12:13:45.798739
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecordIE = HitRecordIE()
    assert hitrecordIE is not None
    assert hitrecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/()'

# Generated at 2022-06-26 12:13:47.488663
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.suitable('https://hitrecord.org/records/2954362')
    ie.get_video_url()

# Generated at 2022-06-26 12:13:48.387683
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-26 12:13:50.857012
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-26 12:13:52.031281
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test 1
    # Just make sure we can create an instance of the class
    extractor = HitRecordIE()
    assert(extractor)

# Generated at 2022-06-26 12:14:53.053259
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Test to instantiate HitRecordIE class.
    """
    # Instantiate class
    hitrecord_ie = HitRecordIE()

    # Test to validate info
    assert hitrecord_ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert hitrecord_ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert hitrecord_ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert hitrecord_ie._TEST['info_dict']['id'] == '2954362'
    assert hitrecord_ie._TEST['info_dict']['ext'] == 'mp4'
    assert hitrecord

# Generated at 2022-06-26 12:15:02.429584
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():

    global TEST_CASE,TEST_WRONG_CASE
    TEST_CASE = 'https://hitrecord.org/records/2954362'
    TEST_WRONG_CASE = 'https://hitrecord.org/records/2954369'
    #  class TestHitRecordIE
    test = HitRecordIE()
    #  Test extraction
    test.extract(TEST_CASE)
    #  Test wrong extraction
    try:
        test.extract(TEST_WRONG_CASE)
        assert False, "Expected exception not fired, test failed"
    except:
        assert True, "Expected exception fired, test passed"


# Generated at 2022-06-26 12:15:06.145361
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    assert instance._VALID_URL == "https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)"

# Generated at 2022-06-26 12:15:08.180547
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'

# Generated at 2022-06-26 12:15:10.448036
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    #test_HitRecordIE()
    m = HitRecordIE()
    m._real_extract('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:15:11.996383
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-26 12:15:13.972921
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('http://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:15:17.723030
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TEST')

# Generated at 2022-06-26 12:15:19.928871
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie == HitRecordIE

# Generated at 2022-06-26 12:15:21.896900
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    if not HitRecordIE.suitable('https://hitrecord.org/records/2954362'):
        print('Unit test for constructor of class HitRecordIE failed')


# Generated at 2022-06-26 12:17:23.671568
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE = HitRecordIE('https://www.youtube.com/watch?v=BaW_jenozKc')
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:17:24.479485
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	HitRecordIE()

# Generated at 2022-06-26 12:17:25.898261
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE

# Generated at 2022-06-26 12:17:34.444377
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:17:36.312025
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE_object = HitRecordIE()

# Generated at 2022-06-26 12:17:37.570095
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:17:41.749144
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:17:46.949462
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    x = HitRecordIE('Test Name', 'https://www.hitrecord.org/records/2954362')
    fixture_url = 'https://hitrecord.org/records/2954362'
    assert x._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert x._TEST['url'] == fixture_url

# Generated at 2022-06-26 12:17:55.405112
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # Test constructor of this IE
    ie == HitRecordIE()
    ie = HitRecordIE(ie)

    url = ie.url_result(
        'https://hitrecord.org/records/2954362'
        '?utm_campaign=embed&utm_source=embed&utm_medium=embed')
    result = ie.extract(url)
    assert result['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert result['id'] == '2954362'
    assert result['duration'] == 139.327
    assert result['description'] == \
            'md5:e62defaffab5075a5277736bead95a3d'
    assert result['uploader'] == 'Zuzi.C12'
    assert result['uploader_id']

# Generated at 2022-06-26 12:18:00.761056
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    ie = HitRecordIE()
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'