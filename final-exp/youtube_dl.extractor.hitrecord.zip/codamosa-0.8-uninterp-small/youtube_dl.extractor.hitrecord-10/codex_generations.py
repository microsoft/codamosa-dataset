

# Generated at 2022-06-26 12:10:38.366512
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert hit_record_i_e_0._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'


# Generated at 2022-06-26 12:10:41.757048
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_1 = HitRecordIE()


# Generated at 2022-06-26 12:10:42.671657
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert len(hit_record_i_e_0.IE_NAME) > 0


# Generated at 2022-06-26 12:10:44.043765
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert isinstance(HitRecordIE(), InfoExtractor)

# Generated at 2022-06-26 12:10:45.943961
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    print("inside test_HitRecordIE")
    HitRecordIE()


# Generated at 2022-06-26 12:10:47.179123
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert hit_record_i_e_0 != None


# Generated at 2022-06-26 12:10:49.013726
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    test_HitRecordIE = HitRecordIE.test


# Generated at 2022-06-26 12:10:54.565067
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_0 = HitRecordIE()
    video_url = 'https://hitrecord.org/records/2954362'
    hit_record_i_e_0._real_extract(video_url)


# Generated at 2022-06-26 12:10:56.517391
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_1 = HitRecordIE()


# Generated at 2022-06-26 12:10:58.220017
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert isinstance(HitRecordIE(), HitRecordIE)


# Generated at 2022-06-26 12:11:05.409913
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(HitRecordIE.ie_key())._VALID_URL == HitRecordIE._VALID_URL

# Generated at 2022-06-26 12:11:17.548555
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST.get('url') == 'https://hitrecord.org/records/2954362'
    assert ie._TEST.get('md5') == 'fe1cdc2023bce0bbb95c39c57426aa71'
    info_dict = ie._TEST.get('info_dict')
    assert info_dict.get('id') == '2954362'
    assert info_dict.get('ext') == 'mp4'
    assert info_dict.get('title') == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-26 12:11:28.965351
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Create instance of HitRecordIE
    h = HitRecordIE()
    assert h._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:11:29.790437
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:11:33.615206
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    loader_object = HitRecordIE(None)

    assert loader_object.name != None
    assert loader_object._VALID_URL != None

# Generated at 2022-06-26 12:11:44.021679
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    url = 'https://hitrecord.org/records/2954362'
    data = ie.extract(url)
    assert data['id'] == '2954362'

# Generated at 2022-06-26 12:11:44.852725
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:11:45.562367
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    pass

# Generated at 2022-06-26 12:11:46.977736
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    extractor = HitRecordIE()
    return

# Generated at 2022-06-26 12:11:47.825494
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-26 12:11:59.249992
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    class_under_test = HitRecordIE()
    assert class_under_test.ie_key() == 'hitrecord'
    assert class_under_test.ie_name() == 'HitRecord'
    assert class_under_test.ie_description() == 'HitRecord'

# Generated at 2022-06-26 12:12:04.628673
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitrecord = HitRecordIE(HitRecordIE._download_json, HitRecordIE._match_id)
    assert hitrecord._VALID_URL == HitRecordIE._VALID_URL
    assert hitrecord._TEST == HitRecordIE._TEST


# Generated at 2022-06-26 12:12:14.901808
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    video = 'https://hitrecord.org/records/2954362'
    result = ie.suitable(video)
    assert result
    video = 'https://www.hitrecord.org/records/2954362'
    result = ie.suitable(video)
    assert result
    video = 'https://hitrecord.org/record/2954362'
    result = ie.suitable(video)
    assert not result
    video = 'https://hitrecord.org/records/2954362/asd'
    result = ie.suitable(video)
    assert not result
    video = 'https://hitrecord.org/records/2954362.asd'
    result = ie.suitable(video)
    assert not result

# Generated at 2022-06-26 12:12:15.889557
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-26 12:12:22.857459
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie_HitRecord = HitRecordIE()
    assert ie_HitRecord._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie_HitRecord.name == 'HitRecord'
    assert ie_HitRecord.ie_key() == 'hitrecord'

# Generated at 2022-06-26 12:12:24.292345
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-26 12:12:26.077216
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:12:27.702244
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:12:38.824594
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # No good way to test download of video because the site is hit-or-miss on
    # whether the video url is allowed to be loaded.  Here, we just test that
    # we can initialize the class and call the extract() method.
    ie = HitRecordIE(None)
    assert isinstance(ie, HitRecordIE)
    assert ie.IE_NAME == 'hitrecord.org'
    assert ie._VALID_URL == HitRecordIE._VALID_URL
    assert ie.info_dict == HitRecordIE._TEST['info_dict']
    assert ie._real_extract(HitRecordIE._TEST['url']) == HitRecordIE._TEST['info_dict']

# Generated at 2022-06-26 12:12:40.813648
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:13:01.621647
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("test")


# Generated at 2022-06-26 12:13:02.421952
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:13:05.973146
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.suitable(None) is False
    assert ie.suitable('https://hitrecord.org/records/2954362') is True

# Generated at 2022-06-26 12:13:08.059327
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  ie = HitRecordIE()
  ie.supertitled()

# Generated at 2022-06-26 12:13:10.099860
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert(ie.IE_NAME == 'HitRecord')

# Generated at 2022-06-26 12:13:11.493970
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-26 12:13:15.228801
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    t = HitRecordIE()
    print(t.extract('https://hitrecord.org/records/2954362'))

# Generated at 2022-06-26 12:13:15.738413
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:13:18.861908
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('HitRecordIE', True)

# Generated at 2022-06-26 12:13:29.987727
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:14:24.358397
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:14:33.105198
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:14:33.688268
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    globals()['HitRecordIE']

# Generated at 2022-06-26 12:14:36.348251
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE("")._real_extract("https://hitrecord.org/records/2954362")

# Generated at 2022-06-26 12:14:42.495677
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	ie = HitRecordIE()
	assert(ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-26 12:14:45.495946
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    loaded_ie = HitRecordIE()
    assert loaded_ie.IE_NAME == 'hitrecord'



# Generated at 2022-06-26 12:14:53.487167
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE()


# Generated at 2022-06-26 12:15:03.787171
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('https://hitrecord.org/records/2954362')
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-26 12:15:12.351474
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    video_url = 'https://hitrecord.org/records/2954362'
    hit_record = HitRecordIE(exit_early=True)
    hit_record_url = hit_record._real_extract(video_url)
    assert hit_record_url == 'https://hitrecord.s3.amazonaws.com/video/recordings/2954362/source.mp4?AWSAccessKeyId=AKIAJB7G3VWBYZ3L7NAA&Expires=1520989818&Signature=fAw%2FFOQTiWtUIkZ3Gp0BHh9J9Rg%3D'


# Generated at 2022-06-26 12:15:17.540084
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:17:11.571144
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    constructor_test.do_test(HitRecordIE)

# Generated at 2022-06-26 12:17:12.708320
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:17:17.170657
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecordIE = HitRecordIE()
    assert hitRecordIE._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\\d+)'

# Generated at 2022-06-26 12:17:21.909447
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	# Construct an instance of class HitRecordIE
	hitRecord = HitRecordIE()

	# Test if instance has defined _VALID_URL
	print("Checking _VALID_URL")
	assert(hasattr(hitRecord, '_VALID_URL'))


# Generated at 2022-06-26 12:17:33.408815
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'hitrecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:17:38.877920
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HITRECORD'
    assert ie.ie_name() == 'HITRECORD'
    assert ie.http_headers()

# Generated at 2022-06-26 12:17:42.136208
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    class_name = 'HitRecordIE'
    class_ = globals()[class_name]
    if hasattr(class_, 'test'):
        return class_.test()

# Generated at 2022-06-26 12:17:43.342790
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Test that HitRecordIE is constructor of InfoExtractor
    assert isinstance(HitRecordIE(), InfoExtractor)

# Generated at 2022-06-26 12:17:44.626071
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    a = HitRecordIE()
    print (a._VALID_URL)
# test_HitRecordIE()

# Generated at 2022-06-26 12:17:51.053788
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # Tests for non-existing video
    test_url = 'https://hitrecord.org/records/99999999'
    # HitRecordIE should raise ExtractorError (or one of its descendants) with proper error message
    #if not raises_exception(HitRecordIE(test_url)._real_extract):
        #print(HitRecordIE(test_url)._real_extract)
    try:
        HitRecordIE(test_url)._real_extract()
    except:
        raise