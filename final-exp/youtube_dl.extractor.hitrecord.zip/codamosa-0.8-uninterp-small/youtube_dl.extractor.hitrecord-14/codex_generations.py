

# Generated at 2022-06-26 12:10:42.547773
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert hit_record_i_e_0._downloader is None
    assert hit_record_i_e_0._match_id == '2954362'


# Generated at 2022-06-26 12:10:44.374530
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    url = 'https://hitrecord.org/records/2954362'
    hit_record_i_e = HitRecordIE()

    object_id = hit_record_i_e._match_id(url)
    assert object_id == '2954362'


# Generated at 2022-06-26 12:10:52.522509
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()
    assert hit_record_i_e._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    # Tests the function _real_extract
    video_id = hit_record_i_e._match_id('https://hitrecord.org/records/2954362')
    video = hit_record_i_e._download_json('https://hitrecord.org/api/web/records/%s' % video_id, video_id)
    title = video['title']
    video_url = video['source_url']['mp4_url']
    tags = None
    tags_list = try_get(video, lambda x: x['tags'], list)

# Generated at 2022-06-26 12:11:01.390078
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_0 = HitRecordIE()
    p = hit_record_i_e_0._download_json('https://hitrecord.org/api/web/records/2954362', '2954362')
    assert p['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert p['source_url']['mp4_url'] == 'https://s3.amazonaws.com/hr-storage/records/files/000/295/436/original/A_Very_Different_World_(HITRECORD_x_ACLU).mp4'


# Generated at 2022-06-26 12:11:05.159030
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e = HitRecordIE()
    assert hit_record_i_e is not None, "Failed to create HitRecordIE"


# Unit tests for HitRecordIE._real_extract()

# Generated at 2022-06-26 12:11:07.732300
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()


# Generated at 2022-06-26 12:11:09.897091
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE != None
    assert HitRecordIE != ["Hello World"]


# Generated at 2022-06-26 12:11:20.020089
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hit_record_i_e_0 = HitRecordIE()
    assert_equal(hit_record_i_e_0._VALID_URL, 'https://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-26 12:11:21.407000
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()


# Generated at 2022-06-26 12:11:23.053866
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    test_case_0()

# Generated at 2022-06-26 12:11:30.561119
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == ie._TEST["url"]

# Generated at 2022-06-26 12:11:42.753230
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:11:44.701495
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie._match_id()

# Generated at 2022-06-26 12:11:47.245269
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.extract('http://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:11:48.483137
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:11:52.739559
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Basic unit test of class HitRecordIE
    """
    ie = HitRecordIE()
    ie.download(HitRecordIE._TEST['url'])

# Generated at 2022-06-26 12:11:57.597951
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    from .common import InfoExtractor
    from .hitrecord import HitRecordIE

    ie = HitRecordIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, HitRecordIE)

# Generated at 2022-06-26 12:11:58.821690
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:11:59.718141
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	pass

# Generated at 2022-06-26 12:12:00.278135
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE(): assert HitRecordIE is not None

# Generated at 2022-06-26 12:12:12.405051
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
  ie = HitRecordIE('2954362')
  assert ie.url == 'https://hitrecord.org/records/2954362'
  assert ie.ie_key() == b'HitRecord:2954362'

# Generated at 2022-06-26 12:12:15.143996
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    unit test for HitRecordIE, a constructor class
    """
    assert isinstance(HitRecordIE(), HitRecordIE)

# Generated at 2022-06-26 12:12:19.881740
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    class_constructor = lambda: HitRecordIE()
    assert_raises_regex(
        TypeError,
        "descriptor '_VALID_URL' of 'HitRecordIE' object needs an argument",
        class_constructor)

    assert_raises_regex(
        TypeError,
        "descriptor '_TEST' of 'HitRecordIE' object needs an argument",
        class_constructor)


# Generated at 2022-06-26 12:12:20.701509
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:12:22.622058
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-26 12:12:24.033305
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie

# Generated at 2022-06-26 12:12:25.138996
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:12:32.010594
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE() # pylint: disable=redefined-outer-name
    assert ie.IE_NAME == 'hitrecord:video'
    assert ie.IE_DESC == 'HITRECORD'
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'

# Generated at 2022-06-26 12:12:33.366441
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()


# Generated at 2022-06-26 12:12:42.091311
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE('hitrecord', 'https://hitrecord.org/records/2954362')
    assert_equal(ie._VALID_URL, r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)')

# Generated at 2022-06-26 12:13:10.354157
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable("https://hitrecord.org/records/2954362") == True
    assert ie.suitable("https://hitrecord.org/records/29543621") == False
    assert ie.suitable("https://hitrecord.org/") == False
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._T

# Generated at 2022-06-26 12:13:11.352297
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
	assert HitRecordIE() is not None


# Generated at 2022-06-26 12:13:13.821074
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE(HitRecordIE._VALID_URL)


# Generated at 2022-06-26 12:13:22.631012
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = InfoExtractor(HitRecordIE._VALID_URL, HitRecordIE._VALID_URL)
    assert ie._VALID_URL == HitRecordIE._VALID_URL
    info = ie.extract(ie._VALID_URL)
    assert info['id'] == '2954362'
    assert info['url'] == 'https://l3b.hitrecord.org/video/000/000/691/2954362.mp4'
    assert info['title'] == 'A Very Different World (HITRECORD x ACLU)'
    assert 'md5:e62defaffab5075a5277736bead95a3d' in info['description']
    assert info['duration'] == 139.327
    assert info['timestamp'] == 1471557582
    assert info['upload_date'] == '20160818'


# Generated at 2022-06-26 12:13:24.543069
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:13:25.359203
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:13:32.842414
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    TestHitRecordIE = HitRecordIE()
    # Test if url is "_VALID_URL"
    assert TestHitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    # Test if id is id of video
    assert TestHitRecordIE._match_id('https://hitrecord.org/records/2954362') == '2954362'
    # Test if extractor get all the correct information

# Generated at 2022-06-26 12:13:33.691673
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:13:36.918671
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'
    assert ie.ie_short() == 'HitRecord'
# Test video downloader (and get video title)
# It is testing the HitRecordIE() class

# Generated at 2022-06-26 12:13:39.956254
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE().suitable('https://hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:14:28.553111
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE()

# Generated at 2022-06-26 12:14:40.646615
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
        class video_id(InfoExtractor):
            pass
        obj = HitRecordIE("https://hitrecord.org/records/2954362")
        assert obj._match_id("https://hitrecord.org/records/2954362") == "2954362"
        obj1 = HitRecordIE("https://hitrecord.org/records/2954362")
        assert obj1._real_extract("https://hitrecord.org/records/2954362")["id"] == "2954362"
        assert obj1._real_extract("https://hitrecord.org/records/2954362")["url"] == "https://hitrecord.org/records/2954362"
        obj2 = HitRecordIE("https://hitrecord.org/records/2954362")

# Generated at 2022-06-26 12:14:49.387901
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_desc() == 'HitRecord'
    assert ie.root_dir() == ie._downloader.params.get(
        'outtmpl').rpartition('%(id)s')[0]
    assert ie.working_dir() == ie._downloader.params.get(
        'outtmpl').rpartition('%(id)s')[0]



# Generated at 2022-06-26 12:14:52.123738
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    try:
        HitRecordIE()
    except:
        assert False, 'HitRecordIE constructor failed'


# Generated at 2022-06-26 12:14:53.534204
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # test for empty url
    HitRecordIE('')

# Generated at 2022-06-26 12:14:55.234699
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    info_extractor = HitRecordIE()

# Generated at 2022-06-26 12:14:56.109525
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:14:58.219793
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()

# Generated at 2022-06-26 12:14:59.814340
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.url_result == ie.result_from_url

# Generated at 2022-06-26 12:15:08.255688
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    ie.suitable('https://hitrecord.org/records/2954362')
    ie.extract('https://hitrecord.org/records/2954362')
    ie.suitable('https://www.hitrecord.org/records/2954362')
    ie.extract('https://www.hitrecord.org/records/2954362')

# Generated at 2022-06-26 12:16:50.426985
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    instance = HitRecordIE()
    assert instance

# Generated at 2022-06-26 12:16:57.410723
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """Test to check if constructor of HitRecordIE class works as expected
    """
    ie = HitRecordIE()

    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:17:00.996096
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    """
    Basic test to hitrecord.org URL to confirm it is instance of class HitRecordIE
    """
    HitRecordIE('https://hitrecord.org/records/4285697')

# Generated at 2022-06-26 12:17:13.181390
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable(
        'https://hitrecord.org/records/2954362') == True
    assert ie.suitable(
        'https://hitrecord.org/records/2954362') == True
    assert ie.suitable(
        'https://hitrecord.org/records/2954362') == True
    assert ie.suitable(
        'https://hitrecord.org/records/2954362') == True
    assert ie.suitable(
        'https://hitrecord.org/records/2954362') == True
    assert ie.suitable(
        'https://hitrecord.org/records/2954362') == True

# Generated at 2022-06-26 12:17:23.941056
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    record_ie = HitRecordIE(None, None, None)

# Generated at 2022-06-26 12:17:34.048415
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-26 12:17:36.450565
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    hitRecord = HitRecordIE()
    assert hitRecord is not None

# Generated at 2022-06-26 12:17:37.632652
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-26 12:17:40.159295
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    # TODO: Implement unit test for constructor of class HitRecordIE
    pass

# Generated at 2022-06-26 12:17:45.170964
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    # https://hitrecord.org/records/2954362
    assert ie.ie_key() == 'hitrecord:2954362'
    assert ie.suitable(ie.ie_key())
    assert not ie.suitable('http://www.youtube.com/watch?v=BaW_jenozKc')
    assert ie.suitable(ie.url_result('https://hitrecord.org/records/2954362'))