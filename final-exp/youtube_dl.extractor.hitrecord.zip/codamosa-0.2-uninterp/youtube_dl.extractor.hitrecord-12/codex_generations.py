

# Generated at 2022-06-18 14:03:56.405716
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:04:03.596716
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:04:14.385488
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert ie.valid_url('https://hitrecord.org/records/2954362/')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://www.hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid

# Generated at 2022-06-18 14:04:23.287260
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert ie.valid_url('https://hitrecord.org/records/2954362/')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/abc')


# Generated at 2022-06-18 14:04:33.743289
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'hitrecord.org'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:04:44.039279
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert ie.valid_url('https://hitrecord.org/records/2954362', 'HitRecord')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362', 'HitRecord')
    assert ie.valid_url('https://hitrecord.org/records/2954362', 'HitRecord') == ie.valid_url('https://hitrecord.org/records/2954362')

# Generated at 2022-06-18 14:04:54.538460
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://hitrecord.org/records/2954362/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/12345')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/12345/')

# Generated at 2022-06-18 14:04:55.364010
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:05:03.567449
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/comments')

# Generated at 2022-06-18 14:05:04.115842
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:05:22.600230
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/abc')

# Generated at 2022-06-18 14:05:31.521686
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'hitrecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/test')

# Generated at 2022-06-18 14:05:31.991614
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:05:44.069454
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:05:54.350826
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:06:04.388848
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records/2954362/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/12345')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/12345/')

# Generated at 2022-06-18 14:06:15.294628
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:06:25.819223
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/')
    assert not ie.suitable('https://hitrecord.org/records/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/test')
    assert not ie.suitable('https://hitrecord.org/records/2954362/test/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/test/test')
    assert not ie.su

# Generated at 2022-06-18 14:06:35.467304
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:06:44.334532
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie.VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:07:10.801702
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert ie.valid_url('https://hitrecord.org/records/2954362/')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/test')

# Generated at 2022-06-18 14:07:19.821177
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:07:20.354257
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:07:30.234233
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/')
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert ie.valid_url('https://hitrecord.org/records/2954362', 'HitRecord')
    assert not ie.valid_url('https://hitrecord.org/', 'HitRecord')
    assert ie.valid_url('https://hitrecord.org/records/2954362', 'hitrecord')
    assert not ie.valid_

# Generated at 2022-06-18 14:07:41.077250
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:07:49.701027
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:08:00.105623
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:08:08.588806
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/foo')

# Generated at 2022-06-18 14:08:19.870387
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:08:20.382257
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:09:14.417958
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:09:23.626899
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:09:34.140605
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/comments')

# Generated at 2022-06-18 14:09:42.463336
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:09:50.293102
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/abc')
    assert not ie.valid_url('https://hitrecord.org/records/123abc')

# Generated at 2022-06-18 14:10:00.361822
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie.VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:10:11.532355
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie.VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:10:20.178675
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert ie.valid_url('https://hitrecord.org/records/2954362/')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://www.hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid

# Generated at 2022-06-18 14:10:29.694913
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/test')
    assert not ie.valid_url('https://hitrecord.org/records/295436')
   

# Generated at 2022-06-18 14:10:36.530826
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records/2954362/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/123')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/123/')

# Generated at 2022-06-18 14:12:17.362702
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/abc')

# Generated at 2022-06-18 14:12:21.239113
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'

# Generated at 2022-06-18 14:12:28.867599
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:12:30.132209
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:12:40.288559
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/test')

# Generated at 2022-06-18 14:12:40.787406
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:12:49.493616
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:12:49.979909
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:12:58.788333
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:13:09.672180
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records/2954362/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/edit')
    assert not ie.suitable('https://hitrecord.org/records/2954362/edit/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/edit/1')
    assert not ie.suitable('https://hitrecord.org/records/2954362/edit/1/')