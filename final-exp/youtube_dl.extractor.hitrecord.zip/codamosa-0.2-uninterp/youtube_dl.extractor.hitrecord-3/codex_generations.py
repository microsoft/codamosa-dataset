

# Generated at 2022-06-18 14:04:01.173165
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:04:12.988411
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'hitrecord'
    assert ie.SUCCESS == 'SUCCESS'
    assert ie.FAILED == 'FAILED'
    assert ie.SUCCESS == 'SUCCESS'
    assert ie.FAILED == 'FAILED'
    assert ie.extract_id('https://hitrecord.org/records/2954362') == '2954362'
    assert ie.valid_url('https://hitrecord.org/records/2954362') == True
    assert ie.valid_url('https://hitrecord.org/records/2954362', 'hitrecord') == True

# Generated at 2022-06-18 14:04:21.272035
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records/2954362/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/1')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/1/')

# Generated at 2022-06-18 14:04:29.620504
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/comments')

# Generated at 2022-06-18 14:04:40.168706
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:04:48.625237
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:04:59.178837
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/test')
    assert not ie.valid_url('https://hitrecord.org/records/test')

# Generated at 2022-06-18 14:05:07.921025
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    assert HitRecordIE._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:05:14.593679
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.suitable(ie.ie_key())
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/123')

# Generated at 2022-06-18 14:05:21.620126
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')

# Generated at 2022-06-18 14:05:34.202698
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/test')
    assert not ie.valid_url('https://hitrecord.org/records/test')

# Generated at 2022-06-18 14:05:45.612031
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:05:55.662742
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:06:05.525372
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:06:16.722125
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:06:17.391678
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:06:27.445721
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:06:36.836061
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records/2954362/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/12345')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/12345/')

# Generated at 2022-06-18 14:06:46.414541
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:06:54.379889
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:07:12.395634
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/test')

# Generated at 2022-06-18 14:07:21.430002
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:07:31.772614
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:07:42.278488
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'hitrecord'
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records/2954362/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/edit')
    assert not ie.suitable('https://hitrecord.org/records/2954362/edit/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/edit/edit')
    assert not ie.suitable('https://hitrecord.org/records/2954362/edit/edit/')

# Generated at 2022-06-18 14:07:42.856974
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:07:50.675831
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records/2954362/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/123')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/123/')

# Generated at 2022-06-18 14:07:53.272640
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:08:02.712599
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:08:03.118291
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:08:10.974478
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:08:45.051442
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/comments')

# Generated at 2022-06-18 14:08:54.813919
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:09:03.162802
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:09:11.818407
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:09:20.924126
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/abc')

# Generated at 2022-06-18 14:09:21.529732
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:09:26.073935
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'hitrecord'
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records/2954362/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/1')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/1/')

# Generated at 2022-06-18 14:09:36.493672
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records/2954362/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/edit')
    assert not ie.suitable('https://hitrecord.org/records/2954362/edit/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/edit/1')
    assert not ie.suitable('https://hitrecord.org/records/2954362/edit/1/')

# Generated at 2022-06-18 14:09:44.175482
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:09:53.362577
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/comments')

# Generated at 2022-06-18 14:10:37.215592
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('http://hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/comments')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/comments/')


# Generated at 2022-06-18 14:10:47.979553
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:10:55.343049
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/test')
    assert not ie.valid_url('https://hitrecord.org/records/test')

# Generated at 2022-06-18 14:11:03.840477
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:11:11.465178
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:11:17.035049
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records/2954362/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/123')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/123/')

# Generated at 2022-06-18 14:11:26.443066
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:11:35.472264
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/test')

# Generated at 2022-06-18 14:11:42.133935
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:11:51.655499
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/test')
    assert not ie.suitable('https://hitrecord.org/records/2954362/test/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/test/test')

# Generated at 2022-06-18 14:13:52.114180
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.suitable(ie.suitable('https://hitrecord.org/records/2954362'))
    assert not ie.suitable('https://hitrecord.org/records/2954362/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/edit')
    assert not ie.suitable('https://hitrecord.org/records/2954362/edit')
    assert not ie.suitable('https://hitrecord.org/records/2954362/edit')
    assert not ie.suitable('https://hitrecord.org/records/2954362/edit')