

# Generated at 2022-06-18 14:04:02.219087
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:04:13.477540
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:04:13.865695
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:04:14.397110
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:04:23.290997
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records/2954362/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/test')
    assert not ie.suitable('https://hitrecord.org/records/2954362/test/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/test/test')
    assert not ie.suitable('https://hitrecord.org/records/2954362/test/test/')

# Generated at 2022-06-18 14:04:33.740985
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records/2954362/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/edit')
    assert not ie.suitable('https://hitrecord.org/records/2954362/edit/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/edit/1')
    assert not ie.suitable('https://hitrecord.org/records/2954362/edit/1/')

# Generated at 2022-06-18 14:04:34.334694
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:04:44.587279
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:04:45.077411
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:04:45.666993
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:04:55.230628
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:05:03.473576
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:05:11.681255
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:05:12.293734
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:05:22.979260
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:05:31.836804
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:05:38.914871
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.name == 'hitrecord'
    assert ie.ie_key() == 'hitrecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')

# Generated at 2022-06-18 14:05:39.513350
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:05:49.847101
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:05:53.760169
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/')

# Generated at 2022-06-18 14:06:11.344903
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:06:22.361152
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records/2954362/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/edit')
    assert not ie.suitable('https://hitrecord.org/records/2954362/edit/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/edit/new')
    assert not ie.suitable('https://hitrecord.org/records/2954362/edit/new/')

# Generated at 2022-06-18 14:06:32.622110
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'hitrecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/comments')

# Generated at 2022-06-18 14:06:33.082946
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:06:39.947555
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:06:49.300179
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/comments')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/comments/')

# Generated at 2022-06-18 14:06:49.819418
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:06:57.144362
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:07:07.517367
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:07:15.985204
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:08:00.105647
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/test')
    assert not ie.valid_url('https://hitrecord.org/records/test')

# Generated at 2022-06-18 14:08:08.578275
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:08:19.871218
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:08:20.381966
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:08:27.856588
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:08:33.716461
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:08:34.186189
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:08:43.947371
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:08:44.494155
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:08:54.467780
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:10:10.434163
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:10:19.450615
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'
    assert ie._TEST['url'] == 'https://hitrecord.org/records/2954362'
    assert ie._TEST['md5'] == 'fe1cdc2023bce0bbb95c39c57426aa71'
    assert ie._TEST['info_dict']['id'] == '2954362'
    assert ie._TEST['info_dict']['ext'] == 'mp4'
    assert ie._TEST['info_dict']['title'] == 'A Very Different World (HITRECORD x ACLU)'

# Generated at 2022-06-18 14:10:29.180934
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:10:29.557115
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:10:36.440839
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records/2954362/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/12345')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/12345/')

# Generated at 2022-06-18 14:10:37.162965
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:10:47.980015
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records/2954362/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/12345')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/12345/')

# Generated at 2022-06-18 14:10:55.312751
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/')
    assert not ie.suitable('https://hitrecord.org/records/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/test')
    assert not ie.suitable('https://hitrecord.org/records/2954362/test/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/test/test')
    assert not ie.su

# Generated at 2022-06-18 14:10:59.489342
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'HitRecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.suitable(ie.suitable('https://hitrecord.org/records/2954362'))
    assert not ie.suitable(ie.suitable('https://hitrecord.org/'))

# Generated at 2022-06-18 14:11:07.466465
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'