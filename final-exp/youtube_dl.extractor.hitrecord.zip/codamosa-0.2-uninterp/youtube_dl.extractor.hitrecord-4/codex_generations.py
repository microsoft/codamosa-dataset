

# Generated at 2022-06-18 14:03:55.970042
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'hitrecord'
    assert ie.SUCCEEDED == 'SUCCEEDED'
    assert ie.FAILED == 'FAILED'
    assert ie.SKIPPED == 'SKIPPED'

# Generated at 2022-06-18 14:04:03.317075
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/comments')

# Generated at 2022-06-18 14:04:14.235905
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie.VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:04:23.153586
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:04:30.933373
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:04:41.462703
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:04:49.363949
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:04:59.768826
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/test')

# Generated at 2022-06-18 14:05:08.472493
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert ie.valid_url('https://hitrecord.org/records/2954362/')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://www.hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid

# Generated at 2022-06-18 14:05:14.935023
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'hitrecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/test')
    assert not ie.valid_url('https://hitrecord.org/records/test')

# Generated at 2022-06-18 14:05:31.698618
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records/2954362/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/1234')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/1234/')

# Generated at 2022-06-18 14:05:43.665840
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records/2954362/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/123')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/123/')

# Generated at 2022-06-18 14:05:44.275851
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:05:54.559260
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:06:04.589659
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:06:15.614695
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'hitrecord'
    assert ie.suitable(ie.suitable('https://hitrecord.org/records/2954362'))
    assert ie.suitable(ie.suitable('https://www.hitrecord.org/records/2954362'))
    assert not ie.suitable(ie.suitable('https://hitrecord.org/'))
    assert not ie.suitable(ie.suitable('https://hitrecord.org/records/'))
    assert not ie.suitable(ie.suitable('https://hitrecord.org/records/2954362/'))

# Generated at 2022-06-18 14:06:26.039398
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'hitrecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/test')

# Generated at 2022-06-18 14:06:29.816794
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:06:30.648553
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:06:38.412922
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:07:08.840034
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:07:17.435316
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:07:25.154825
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:07:28.444952
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'

# Generated at 2022-06-18 14:07:39.273096
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:07:48.634936
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:07:55.004917
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')

# Generated at 2022-06-18 14:08:04.072652
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:08:04.585954
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:08:12.034986
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:09:06.464209
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:09:07.345713
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:09:16.464406
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://hitrecord.org/records/2954362')

# Generated at 2022-06-18 14:09:17.104024
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:09:25.655281
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:09:35.910626
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:09:43.763917
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'hitrecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/test')

# Generated at 2022-06-18 14:09:53.007203
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/test')

# Generated at 2022-06-18 14:10:03.305446
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/123')

# Generated at 2022-06-18 14:10:03.868488
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    HitRecordIE()

# Generated at 2022-06-18 14:11:47.617158
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:11:55.380431
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records/2954362/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/1')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/1/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/1/edit')

# Generated at 2022-06-18 14:12:01.297291
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:12:06.563232
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'hitrecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/comments')

# Generated at 2022-06-18 14:12:15.974733
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.ie_key() == 'hitrecord'
    assert ie.ie_name() == 'HitRecord'
    assert ie.valid_url('https://hitrecord.org/records/2954362')
    assert ie.valid_url('https://www.hitrecord.org/records/2954362')
    assert not ie.valid_url('https://hitrecord.org/')
    assert not ie.valid_url('https://hitrecord.org/records/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/')
    assert not ie.valid_url('https://hitrecord.org/records/2954362/test')

# Generated at 2022-06-18 14:12:26.942766
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:12:33.483734
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.IE_NAME == 'hitrecord'
    assert ie.IE_DESC == 'HitRecord'
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:12:44.143114
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie.suitable('https://hitrecord.org/records/2954362')
    assert ie.suitable('https://www.hitrecord.org/records/2954362')
    assert not ie.suitable('https://hitrecord.org/records/2954362/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/12345')
    assert not ie.suitable('https://hitrecord.org/records/2954362/comments/12345/')

# Generated at 2022-06-18 14:12:52.687607
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'

# Generated at 2022-06-18 14:13:01.163258
# Unit test for constructor of class HitRecordIE
def test_HitRecordIE():
    ie = HitRecordIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?hitrecord\.org/records/(?P<id>\d+)'