

# Generated at 2022-06-24 18:04:57.675735
# Unit test for function file_lock
def test_file_lock():
    with file_lock(''):
        pass


# Generated at 2022-06-24 18:05:02.732701
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    import sys
    import traceback

    try:
        main()
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        traceback.print_tb(exc_tb, limit=20)
        print(exc_obj)

# Generated at 2022-06-24 18:05:05.734583
# Unit test for method handler of class ConnectionProcess
def test_ConnectionProcess_handler():
    try:
        var_1 = main()
        var_1.start()
    except:
        var_1.shutdown()
        raise


# Generated at 2022-06-24 18:05:09.414330
# Unit test for method handler of class ConnectionProcess
def test_ConnectionProcess_handler():
    # Create a dummy frame object
    frame = traceback.extract_stack()
    # Create a dummy signum object
    signum = 1

    # Call the method
    ConnectionProcess.handler(signum, frame)


# Generated at 2022-06-24 18:05:21.016113
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    my_connection_process = ConnectionProcess(name='class_ConnectionProcess', play_context=play_context, socket_path='str', original_path='str', task_uuid='str', ansible_playbook_pid='str')
    my_connection_process.connection = Connection(name='new_connection', host='str', port='str', user='str', password='str', private_key_file='str', pipelining='bool', remote_user='str', connection='str', timeout='int', become='bool', become_method='str', become_user='str', become_pass='str', become_exe='str', become_flags='str', check=False, diff=False, demux='bool', start_at_task='str', verbosity='int', set_environment='dict')

# Generated at 2022-06-24 18:05:22.981811
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    var_0 = main()
    var_1 = var_0.shutdown()
    assert(var_1 is None)


# Generated at 2022-06-24 18:05:24.667268
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    var_0 = ConnectionProcess(None, None, None, None)
    var_0.shutdown()

# Generated at 2022-06-24 18:05:36.592351
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    try:
        from ansible.plugins.connection import network_cli
        from ansible.plugins.connection import persistent_connection_common as connection
        from ansible.plugins.connection.local import Connection as ConnectionLocal
    except:
        pass
    try:
        from ansible.plugins.connection import network_cli
        from ansible.plugins.connection import persistent_connection_common as connection
        from ansible.plugins.connection.ssh import Connection as ConnectionSsh
    except:
        pass
    connection_0 = ConnectionProcess({}, {}, 'socket_path', 'original_path', 'task_uuid', 'ansible_playbook_pid')
    connection_0.connection = network_cli.Connection(PlayContext({}), '/dev/null', 'network_cli', 'task_uuid', 'ansible_playbook_pid')
    connection_

# Generated at 2022-06-24 18:05:46.153256
# Unit test for function read_stream

# Generated at 2022-06-24 18:05:56.200960
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    testplay = dict(
        name="Ansible internal test case to force plugin exit",
        hosts="none",
        gather_facts="no",
        connection="network_cli",
        tasks=[
            dict(action=dict(module="set_fact", args=dict(ansible_network_os="ios")))
        ]
    )

    display = Display()
    play_context = PlayContext()
    play_context._run_as_root = False
    play_context._connection = 'local'
    play_context._tqm = None
    play_context._loader = None
    play_context._variable_manager = None

    socket_fd, socket_path = socket.socketpair()
    socket_fd.setblocking(0)
    lockfile = "/tmp/test.lock"

# Generated at 2022-06-24 18:06:16.114380
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    connection_process = ConnectionProcess
    connection_process.run(connection_process)


# Generated at 2022-06-24 18:06:18.341985
# Unit test for function main
def test_main():
    test_case_0()

# if __name__ == "__main__":
#     test_main()

# Generated at 2022-06-24 18:06:22.912161
# Unit test for function file_lock
def test_file_lock():
    var_0 = main()
    var_1 = JsonRpcServer(var_0)
    var_2 = JsonRpcServer(var_0)

    assert var_1 == var_2
    assert var_1 != None
    assert var_1 != True



# Generated at 2022-06-24 18:06:32.694946
# Unit test for method connect_timeout of class ConnectionProcess
def test_ConnectionProcess_connect_timeout():
    var_0 = ConnectionProcess(fd, play_context, socket_path, original_path, self.connection.get_option('persistent_connect_timeout'),
                                        task_uuid=self._task_uuid, ansible_playbook_pid=self._ansible_playbook_pid)
    with patch.object(display, 'display') as mock_display:
        with raises(Exception):
            var_0.connect_timeout(signum, frame)
        assert mock_display.call_count == 1


# Generated at 2022-06-24 18:06:38.936429
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    fd = None # TODO
    play_context = None # TODO
    socket_path = None # TODO
    original_path = None # TODO
    task_uuid=None # TODO
    ansible_playbook_pid=None # TODO
    cp = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)
    cp.shutdown()


# Generated at 2022-06-24 18:06:40.099960
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == "__main__":
    main()

# Generated at 2022-06-24 18:06:42.917462
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    from ansible.module_utils.connection import Connection
    # Call method run of class ConnectionProcess with first argument
    # is an instance of class TCPConnection
    # TODO: Need to add real values for all the arguments.
    a = ConnectionProcess(0, TCPConnection, '127.0.0.1', 2222, 'username', 'password')
    a.run()



# Generated at 2022-06-24 18:06:45.894485
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    print('Testing ConnectionProcess.shutdown')
    var_ConnectionProcess = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid=None, ansible_playbook_pid=None)
    var_ConnectionProcess.shutdown()


# Generated at 2022-06-24 18:06:50.549110
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    print("\033[0;32m Testing run \x1B[0m\n")
    ansible_playbook_pid = os.getpid()
    test_case_0()


# Generated at 2022-06-24 18:06:54.714516
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    p = ConnectionProcess(0,
                          PlayContext(constants=C),
                          '/tmp/ansible-local-33122.sock',
                          '.')
    p.run()


# Generated at 2022-06-24 18:07:16.489613
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    conPro_inst = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid=None, ansible_playbook_pid=None)
    conPro_inst.shutdown()



# Generated at 2022-06-24 18:07:18.865939
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-24 18:07:21.007481
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == 0

# Generated at 2022-06-24 18:07:31.291945
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    var_0 = ConnectionProcess()
    var_1 = PlayContext()
    var_0.play_context = var_1
    var_2 = StringIO()
    var_0.fd = var_2
    var_3 = "/var/folders/tr/t2dklvgn0jg8dzvk1sx1p26m0000gn/T/tmpCvE_qo"
    var_0.socket_path = var_3
    var_4 = "ansible_playbook_pid=44761"
    var_5 = "ansible_playbook_pid"
    var_6 = "44761"
    var_7 = dict()
    var_7.update(var_4)
    var_7.__setitem__(var_5, var_6)
    var_7

# Generated at 2022-06-24 18:07:36.471306
# Unit test for function read_stream
def test_read_stream():
    var_0 = b'20\n12345678901234567890\n'
    var_1 = StringIO(var_0)
    var_2 = read_stream(var_1)
    assert var_2 == b'12345678901234567890'


# Generated at 2022-06-24 18:07:38.652104
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    var_0 = ConnectionProcess(string, string, string, string)
    var_1 = var_0.start(dict)



# Generated at 2022-06-24 18:07:40.330057
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    var_c = test_case_0()
    var_c.start()
    print("Test unit test for method start of class ConnectionProcess: successful")


# Generated at 2022-06-24 18:07:41.850986
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    var_0 = ConnectionProcess(arg_0=arg_0)
    var_0.shutdown()


# Generated at 2022-06-24 18:07:45.350922
# Unit test for function file_lock
def test_file_lock():
    with file_lock('/tmp/bbb'):
        f = open('/tmp/bbb','w')
        f.write('hello')
        f.close()
    with file_lock('/tmp/bbb'):
        f = open('/tmp/bbb','r')
        print(f.read())
        f.close()


# Generated at 2022-06-24 18:07:48.735574
# Unit test for method command_timeout of class ConnectionProcess
def test_ConnectionProcess_command_timeout():
    var_0 = ConnectionProcess()
    var_1 = 0
    var_2 = None
    var_0.command_timeout(0, None)


# Generated at 2022-06-24 18:08:10.190021
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    # Instantiate a new connection process
    cp = ConnectionProcess()
    # Call method run of ConnectionProcess class
    cp.run()
    # Should assert with error message, No active frommets remain
    # assert()


# Generated at 2022-06-24 18:08:17.412472
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    var_0 = PlayContext()
    var_1 = "/tmp/2"
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = ConnectionProcess(var_5, var_0, var_1, var_2, var_3, var_4)
    var_8 = {}
    var_7.start(var_8)


# Generated at 2022-06-24 18:08:27.135232
# Unit test for function read_stream
def test_read_stream():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves.StringIO import StringIO

    # Input parameters for the module

# Generated at 2022-06-24 18:08:28.456853
# Unit test for function main
def test_main():
    Test = TestCase([
        TestCase(test_case_0)
    ])
    Test.run_test()

test_main()

# Generated at 2022-06-24 18:08:30.994370
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    var_0 = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid=None, ansible_playbook_pid=None)
    var_0.run()



# Generated at 2022-06-24 18:08:42.558470
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():

    # Setup
    fd = StringIO()
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = None
    play_context.become_user = None
    play_context.connection = 'network_cli'
    play_context.diff = False
    play_context.private_key_file = None
    play_context.remote_addr = None
    play_context.remote_user = None
    play_context.verbosity = 0
    play_context.password = None
    socket_path = '/var/tmp/ansible/ansible-local/0/0'
    original_path = '/var/tmp/ansible/ansible-local/0'
    task_uuid = None
    ansible_playbook_pid = None

# Generated at 2022-06-24 18:08:46.516891
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    var_1 = ConnectionProcess(fd=file, play_context=PlayContext(), socket_path=str, original_path=str, task_uuid=str, ansible_playbook_pid=int)
    var_1.run()


# Generated at 2022-06-24 18:08:48.600597
# Unit test for function main
def test_main():
    with mock.patch('sys.argv', [__file__, '1', '2']):
        # Testing normal case
        test_case_0()

# Generate test cases for function main

# Generated at 2022-06-24 18:08:53.074496
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    # Main test program for run
    try:
        var_1 = sys.argv[1]
    except IndexError:
        var_1 = None
    if var_1 == 'unit-test' or var_1 == 'unit_test':
        test_case_0()



# Generated at 2022-06-24 18:08:55.645373
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    conn_proc = ConnectionProcess(sys.stdin, PlayContext(), 'socket_path', 'original_path')
    conn_proc.run()


# Generated at 2022-06-24 18:09:36.784266
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    return_value = None
    fd = StringIO()
    play_context = PlayContext()
    socket_path = unfrackpath(C.DEFAULT_LOCAL_TMP + "/ansible-local-134842PdL/tmpRkT7jK")
    original_path = C.DEFAULT_LOCAL_TMP + "/ansible-local-134842PdL/tmpRkT7jK"
    task_uuid = "82d55282-6cbb-46e1-b0b5-5b5e5d914a05"
    ansible_playbook_pid = 29498
    variables = None
    connection_process_obj = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)

# Generated at 2022-06-24 18:09:39.861373
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except Exception as exc:
        print('Exception: %s' % exc)

# provide a differnet entry point for debug purposes
if __name__ == "__main__":
    test_main()

# Generated at 2022-06-24 18:09:42.684904
# Unit test for function main
def test_main():
    print('Test of function main')

    # Tests execution

    test_case_0()

    # Output
    print('\nTest of function main: PASSED')


# Execute the function main
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-24 18:09:49.346631
# Unit test for function main

# Generated at 2022-06-24 18:10:00.584402
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    var_8 = JsonRpcServer()
    var_9 = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    var_10 = PlayContext()
    var_10.private_key_file = '~/.ssh/id_ecs1'
    var_11 = '~/.ssh/id_ecs1'
    var_12 = '/home/arista/playbooks'
    var_10.connection = 'network_cli'
    var_13 = 'network_cli'
    
    var_5 = []
    var_6 = {}


# Generated at 2022-06-24 18:10:07.514024
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    play_context = None
    socket_path = u'__main__.py'
    original_path = u'scripts/ansible-connection'
    task_uuid = u'12345678-1234-5678-1234-567812345678'
    ansible_playbook_pid = None
    variables = u"/usr/local/bin"

    obj = ConnectionProcess(play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)
    obj.start(variables)


# Generated at 2022-06-24 18:10:09.627206
# Unit test for method handler of class ConnectionProcess
def test_ConnectionProcess_handler():
    var_0 = True
    var_1 = 2
    ConnectionProcess.handler( var_0, var_1)
    return var_0


# Generated at 2022-06-24 18:10:11.694708
# Unit test for function file_lock
def test_file_lock():
    with file_lock('testFileLock'):
        pass


# Generated at 2022-06-24 18:10:13.127591
# Unit test for function read_stream
def test_read_stream():
    assert 1 == 0


# Generated at 2022-06-24 18:10:18.505383
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    try:
        var_0 = ConnectionProcess()
        var_0.run()
    except Exception as e:
        print("test_case_0")
        traceback.print_exc()
        sys.exit("Error - exception thrown")

display = Display()
persistent_process = None


# Generated at 2022-06-24 18:10:43.342392
# Unit test for method handler of class ConnectionProcess
def test_ConnectionProcess_handler():
    display = Display()
    handler.display = display
    handler.handler(signum=2, frame=None)

if __name__ == '__main__':
    test_case_0()
    test_ConnectionProcess_handler()

# Generated at 2022-06-24 18:10:49.480602
# Unit test for method command_timeout of class ConnectionProcess
def test_ConnectionProcess_command_timeout():
    var_1 = Connection()
    var_2 = PlayContext()
    var_3 = ''
    var_4 = ''
    var_5 = None

    # Call the method
    var_6 = ConnectionProcess(var_1, var_2, var_3, var_4, var_5)
    var_6.command_timeout()


# Generated at 2022-06-24 18:11:00.343809
# Unit test for function read_stream
def test_read_stream():
    with open("/root/ansible-2.0.0.0/test/integration/targets/moduletest/lib/ansible/module_utils/basic.py",'rb') as fp:
        data = fp.read()
    sha1_object = hashlib.sha1(data)
    hex_dig = to_bytes(sha1_object.hexdigest())

    # create a virtual file like object
    fobj = StringIO()
    fobj.write(to_bytes(str(len(data))))
    fobj.write(b'\n')
    fobj.write(data)
    fobj.write(b'\n')
    fobj.write(hex_dig)
    fobj.write(b'\n')
    fobj.seek(0)

# Generated at 2022-06-24 18:11:04.649141
# Unit test for method command_timeout of class ConnectionProcess
def test_ConnectionProcess_command_timeout():
    # Initialize test variables
    var_0 = ConnectionProcess(arg_0, arg_1, arg_2, arg_3)
    var_1 = None
    var_2 = None

    # Execute test target
    var_0.command_timeout(var_1, var_2)


# Generated at 2022-06-24 18:11:05.317346
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    # Testcase0:
    test_case_0()

# Generated at 2022-06-24 18:11:06.459631
# Unit test for function main
def test_main():
    # mock __main__ """ Called to initiate the connect to the remote device
    # """
    pass


# Generated at 2022-06-24 18:11:10.741041
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    the_socket = None
    the_fd = StringIO()
    play_ctx = PlayContext()
    the_fd.write("")
    the_fd.seek(0)
    connection_process = ConnectionProcess(fd=the_fd, play_context=play_ctx, socket_path="/var/ansible-sock", original_path="")
    # TODO: test call to run method
    connection_process.run()


# Generated at 2022-06-24 18:11:16.841251
# Unit test for method command_timeout of class ConnectionProcess
def test_ConnectionProcess_command_timeout():
    try:
        var_0 = ConnectionProcess()
        assert isinstance(var_0.command_timeout, ufunc)
        var_1 = main()
    except Exception as inst:
        display.error(inst)
        display.error(traceback.format_exc())
        return False
    return True


# Generated at 2022-06-24 18:11:19.566042
# Unit test for method handler of class ConnectionProcess
def test_ConnectionProcess_handler():
    obj = Connection()
    # TODO: need to add parameters for ConnectionProcess.handler
    obj.handler()


# Generated at 2022-06-24 18:11:24.758164
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    fd = StringIO()
    play_context = PlayContext()
    play_context.network_os = 'ios'
    socket_path = 'socket_path'
    original_path = 'original_path'
    cp = ConnectionProcess(fd, play_context, socket_path, original_path)
    test_case_0()

if __name__ == '__main__':
    test_ConnectionProcess_run()

# Generated at 2022-06-24 18:11:56.129694
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    var_1 = ConnectionProcess()
    var_1.shutdown()
    if var_1.fd:
        assert var_1.fd == 'fd'



# Generated at 2022-06-24 18:12:04.558294
# Unit test for method connect_timeout of class ConnectionProcess
def test_ConnectionProcess_connect_timeout():
    var_0 = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid=None, ansible_playbook_pid=None)
    var_0.srv = JsonRpcServer()
    var_1 = "~/temp/ansible_test/json_call.json"
    var_2 = os.open(var_1, os.O_RDWR | os.O_CREAT, 0o600)
    var_3 = JsonRpcServer()
    var_4 = "~/temp/ansible_test/json_call.json"
    var_5 = os.open(var_4, os.O_RDWR | os.O_CREAT, 0o600)
    var_6 = JsonRpcServer()
    var_0.fd = var_2
   

# Generated at 2022-06-24 18:12:14.433169
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    print("Test for method run in ConnectionProcess")
    var_0 = (1, 2)
    var_1 = {'persistent_command_timeout': '', 'persistent_connect_timeout': '', 'persistent_connection': '', 'persistent_log_messages': ''}
    var_2 = PlayContext()
    var_3 = "/tmp/.ansible_unix1"
    var_4 = "/tmp"
    var_5 = None
    var_6 = None
    var_7 = ConnectionProcess(var_0, var_2, var_3, var_4, task_uuid=var_5, ansible_playbook_pid=var_6)
    var_7.srv = JsonRpcServer()
    var_7.sock = None
    var_7.connection = Connection()
   

# Generated at 2022-06-24 18:12:18.756930
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    var_1 = ConnectionProcess(fd=None, play_context=None, socket_path=None, original_path=None, task_uuid=None, ansible_playbook_pid=None)

    # Call the method
    result = var_1.run()
    return result


# Generated at 2022-06-24 18:12:19.846617
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-24 18:12:21.695317
# Unit test for function main
def test_main():
    var_0 = main()
    assert 'error' in var_0
    assert 'exception' in var_0
    assert 'messages' in var_0
    assert 'socket_path' in var_0


# Generated at 2022-06-24 18:12:25.235828
# Unit test for function read_stream
def test_read_stream():
    byte_stream = StringIO()
    byte_stream.write("Hello Wold!")
    byte_stream.seek(0)
    data = read_stream(byte_stream)

test_read_stream()

# Generated at 2022-06-24 18:12:26.712244
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    var_1 = main()



# Generated at 2022-06-24 18:12:37.003048
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    proto_field = 'ansible_ssh_common_args'
    options = ['-q', '-o ControlMaster=no']
    options.extend(to_text(opt) for opt in PlayContext()._ssh_common_args)
    control_path = os.path.abspath("/home/ansible/.ansible/cp/39f1762b78")
    play_context = PlayContext()
    play_context._original_basedir = '/home/ansible/Tower3.3/work/data/projects/ansible-module/checkouts/ansible/hacking/testsuite/units/callbacks/connection_plugins/persistent/test_case_0/test_0_dir/'

# Generated at 2022-06-24 18:12:41.976922
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    connection_process = ConnectionProcess()
    try:
        connection_process.run()
        assert 1 == 1
    except AssertionError:
        display.error("AssertionError !")
    except Exception:
        display.error("Exception !")



# Generated at 2022-06-24 18:13:02.589551
# Unit test for function main
def test_main():
    try:
        assert(str(var_0) == "None")
    except AssertionError:
        raise AssertionError(str(var_0))


# Generated at 2022-06-24 18:13:06.213291
# Unit test for function main
def test_main():
    try:
        main()
    except:
        print('Caught exception')
        raise

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-24 18:13:07.912335
# Unit test for function read_stream
def test_read_stream():
    # First test
    var_1 = StringIO(b'123')


# Generated at 2022-06-24 18:13:15.911540
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    var_1 = connection_loader.get('localhost')
    var_2 = PlayContext()
    var_3 = '/tmp/ansible_test.sock'
    var_4 = os.getcwd()
    var_5 = None
    var_6 = None
    var_7 = None
    var_7 = ConnectionProcess(var_1, var_2, var_3, var_4, var_5, var_6)
    var_8 = None
    var_7.start(var_8)


# Generated at 2022-06-24 18:13:17.768691
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    connection_process = ConnectionProcess( sys.stdout.buffer, PlayContext(private_key_file=C.DEFAULT_PRIVATE_KEY_FILE, remote_user=C.DEFAULT_REMOTE_USER), None, None)
    connection_process.start(None)


# Generated at 2022-06-24 18:13:20.882888
# Unit test for function main
def test_main():
    assert(main() == 0)

if __name__ == '__main__':
    # test_main()
    main()

# Generated at 2022-06-24 18:13:22.105673
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    var_0 = ConnectionProcess()
    var_0.run()


# Generated at 2022-06-24 18:13:33.341324
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    var_0 = type('', (), {})()
    var_0.sock = None
    var_0.connection = type('', (), {})()
    var_0.__dict__.update(type('', (), {}).__dict__)
    var_0.__dict__.update(type('', (), {}).__dict__)
    var_0.socket_path = "/var/ansible/pc/3b4f0c1f4a3097d9b9a1b6eba437e0e06382d7a8"
    var_0.connection._socket_path = "/var/ansible/pc/3b4f0c1f4a3097d9b9a1b6eba437e0e06382d7a8"
    var_0.shutdown()

# Unit test

# Generated at 2022-06-24 18:13:39.153130
# Unit test for function file_lock

# Generated at 2022-06-24 18:13:43.241308
# Unit test for function read_stream
def test_read_stream():
    o_byte_stream = ByteStream(b'20\n{"data": "this is the data"}\n3d3cf40c6858bffcd0d8bea1e2a32cadf71ac7c4\n')
    read_stream(o_byte_stream)


# Generated at 2022-06-24 18:14:31.202549
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    main()
