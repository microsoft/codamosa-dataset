

# Generated at 2022-06-20 13:23:25.716031
# Unit test for function file_lock
def test_file_lock():
    lock_path = '/tmp/test_file_lock'
    try:
        with file_lock(lock_path):
            assert os.path.exists(lock_path)
    finally:
        if os.path.exists(lock_path):
            os.remove(lock_path)
    assert os.path.exists(lock_path) is False



# Generated at 2022-06-20 13:23:27.673188
# Unit test for method command_timeout of class ConnectionProcess
def test_ConnectionProcess_command_timeout():
    """
    :return:
    """
    import unittest



# Generated at 2022-06-20 13:23:37.308140
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    fd = mock.MagicMock()
    play_context = mock.MagicMock()
    socket_path = ''
    original_path = ''
    task_uuid = ''
    ansible_playbook_pid = ''
    variables = ''
    connection_process = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)
    # pass
    try:
        connection_process.start(variables)
    except Exception as e:
        print(e)
    # pass
    try:
        connection_process.start(variables)
    except Exception as e:
        print(e)

# Generated at 2022-06-20 13:23:48.521066
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    pc_var_options = dict(
        ansible_socket='.ansible_persistent_%s' % hashlib.sha1(to_bytes("socket_path", errors='surrogate_or_strict')).hexdigest(),
        persistent_connect_timeout=C.PERSISTENT_COMMAND_TIMEOUT,
        persistent_command_timeout=C.PERSISTENT_COMMAND_TIMEOUT,
        ansible_connection=C.DEFAULT_NETWORK_TRANSPORT,
        ansible_network_os=C.DEFAULT_NETWORK_OS,
        ansible_host=C.DEFAULT_REMOTE_HOST,
        ansible_user=C.DEFAULT_REMOTE_USER
    )

    pc_context = PlayContext()

# Generated at 2022-06-20 13:23:50.941830
# Unit test for function file_lock
def test_file_lock():
    try:
        with file_lock("/tmp/.{}.lock".format(os.getpid())):
            time.sleep(1)
    except Exception as e:
        return False
    return True



# Generated at 2022-06-20 13:23:57.050948
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    fd = StringIO()
    play_context = PlayContext()
    socket_path = '/var/tmp/ansible-pc-test'
    with file_lock(socket_path):
        os.remove(socket_path)
    original_path = '.'
    task_uuid = None
    ansible_playbook_pid = None

    connection_process = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid=None, ansible_playbook_pid=None)
    variables = {}
    connection_process.start(variables)

    assert connection_process.sock is not None
    assert connection_process.connection.socket_path == socket_path
    assert connection_process.connection._socket_path == socket_path
    assert connection_process.exception is None
    assert connection_process

# Generated at 2022-06-20 13:24:03.164079
# Unit test for method handler of class ConnectionProcess
def test_ConnectionProcess_handler():
    """
    This method tests the handler method of the ConnectionProcess class
    """
    cp = ConnectionProcess(None, None, None, None, None, None)
    cp.handler(signum=-1, frame=None)

# Generated at 2022-06-20 13:24:13.210504
# Unit test for function main
def test_main():
    from units.mock.proc import MockProcess
    from units.mock.sys import MockSysModules

    mock_sys_module = MockSysModules()
    mock_sys_module.FINDPATH_CACHE = {}
    mock_sys_module.PATH = []

    process = MockProcess()

    # We don't want to actually fork here, so just disable doing so
    process.fork_process = lambda: 0

    # Patch the real function with the Mock
    connection_process = ConnectionProcess(None, None, None, None)
    connection_process.fork_process = lambda: 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 13:24:21.645124
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    import pytest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.connection import Connection
    import SocketServer

    socket_path = '/tmp/ansible_test_socket'
    lock_path = '/tmp/.ansible_pc_lock_ansible_test_socket'
    if os.path.exists(socket_path):
        os.remove(socket_path)
    if os.path.exists(lock_path):
        os.remove(lock_path)

    class TestConnection(Connection):
        def __init__(self, play_context, new_stdin, *args, **kwargs):
            super(TestConnection, self).__init__(play_context, new_stdin, *args, **kwargs)
            self._connected = True


# Generated at 2022-06-20 13:24:22.127104
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    pass



# Generated at 2022-06-20 13:25:04.242768
# Unit test for function read_stream
def test_read_stream():

    stdin_data = b'5\r\n1234\r\n2\r\n0a\r\n\r\n5\r\n1234\r\n2\r\n0b\r\n\r\n'
    byte_stream = StringIO(stdin_data)
    data = read_stream(byte_stream)
    assert data == b'1234\r\n'

    byte_stream = StringIO(stdin_data)
    data = read_stream(byte_stream)
    assert data == b'1234'

    stdin_data = b'4\r\n1234\r\n2\r\n0a\r\n\r\n4\r\n1234\r\n2\r\n0b\r\n\r\n'

# Generated at 2022-06-20 13:25:06.611328
# Unit test for method handler of class ConnectionProcess
def test_ConnectionProcess_handler():

    print ('test_ConnectionProcess_handler')
    cp=ConnectionProcess(2,2,2,2,2)
    test_result=cp.handler(1,2)
    print (test_result)
    assert test_result==None


# Generated at 2022-06-20 13:25:18.933228
# Unit test for method connect_timeout of class ConnectionProcess
def test_ConnectionProcess_connect_timeout():
    display = Display()
    setattr(display, '_supports_reduction', True)

    test_instance = ConnectionProcess(fd=None,
                                      play_context=PlayContext(),
                                      socket_path=None,
                                      original_path=unfrackpath(C.DEFAULT_LOCAL_TMP),
                                      task_uuid=None,
                                      ansible_playbook_pid=65536)
    # Exception is raised as part of connect_timeout method
    # TODO: Need a better way to test timeouts (signal.alarm())
    with pytest.raises(Exception) as excinfo:
        test_instance.connect_timeout(signal.SIGALRM, None)

    assert "persistent connection idle timeout triggered, timeout value is 60 secs." in str(excinfo.value)

# Generated at 2022-06-20 13:25:26.340268
# Unit test for function file_lock
def test_file_lock():
    """
    Unit test for function file_lock.
    """
    # Create directory for testing
    tmp_dir = "tmp_dir"
    makedirs_safe(tmp_dir)
    # Create lock_file
    lock_file = "/tmp/lock_file"
    # Check file doesn't already exist
    if os.path.isfile(lock_file) or os.path.isdir(lock_file):
        raise Exception('Lock file already exists! Abort!')
    # Create lock
    with file_lock(lock_file):
        # Check file exists
        assert os.path.isfile(lock_file)



# Generated at 2022-06-20 13:25:39.298205
# Unit test for constructor of class ConnectionProcess
def test_ConnectionProcess():
    fd, fd_path = tempfile.mkstemp()
    play_context = PlayContext()
    socket_path = tempfile.mkdtemp()
    original_path = tempfile.mkdtemp()
    conn = ConnectionProcess(fd, play_context, socket_path, original_path)

    assert os.path.exists(fd_path)
    assert fd
    assert os.path.exists(socket_path)
    assert os.path.exists(original_path)
    assert conn.fd
    assert conn.play_context
    assert conn.socket_path
    assert conn.original_path
    assert conn.exception is None
    assert conn.srv
    assert conn.sock is None
    assert conn.connection is None

    os.remove(fd_path)

    fd.close()

# Generated at 2022-06-20 13:25:47.764100
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    host = '127.0.0.1'
    remote_port = 9999
    conn = Connection(host, port=remote_port, connection_lock=None)
    pl_path = '/my/tmp/sock'
    op_path = '/my/original/path'
    cp = ConnectionProcess(None, None, pl_path, op_path, None)
    setattr(cp, 'connection', conn)
    setattr(conn, '_socket_path', pl_path)
    setattr(conn, '_connected', False)
    
    os.makedirs(os.path.dirname(cp.socket_path))
    with open(cp.socket_path, 'w') as fd:
        fd.write("some dummy data")    
    

# Generated at 2022-06-20 13:25:55.603190
# Unit test for function read_stream
def test_read_stream():
    checksum = hashlib.sha1(b'hello').hexdigest()
    outfile = StringIO()
    outfile.write(str(len(b'hello')).encode())
    outfile.write(b'\n')
    outfile.write(b'hello')
    outfile.write(b'\n')
    outfile.write(checksum.encode())
    outfile.write(b'\n')

    outfile.seek(0)
    data = read_stream(outfile)
    assert data == b'hello'


# Generated at 2022-06-20 13:25:56.502127
# Unit test for function main
def test_main():
    assert True


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 13:26:04.344828
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    import ansible.playbook
    import ansible.plugins
    import ansible.plugins.loader
    import ansible.utils

    import ansible.module_utils.connection

    import os
    import StringIO

    ctx = ansible.playbook.PlayContext()
    fd = StringIO.StringIO()

    sock_path = '/tmp/ansible_test_ConnectionProcess.sock'

    if os.path.exists(sock_path):
        os.remove(sock_path)

    cp = ansible.module_utils.connection.ConnectionProcess(fd, ctx, sock_path, '/tmp')
    cp.start(None)
    assert cp.exception == None

    assert os.path.exists(sock_path)

    if os.path.exists(sock_path):
        os

# Generated at 2022-06-20 13:26:14.093983
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():

    fd = None
    play_context = PlayContext()
    socket_path = "./test-run-ansible/testing/tmp/ansible-test-connection-5l5Ynz"
    original_path = "./test-run-ansible/testing/tmp"
    task_uuid = None
    ansible_playbook_pid = None

    obj = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)

    args = [{}]
    if len(args) > 1:
        raise Exception("Expected 1 arguments, got %d" % len(args))

    variables = args[0]
    obj.start(variables)


# Generated at 2022-06-20 13:27:13.437043
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    # FIXME: not sure how to test this
    pass


# Generated at 2022-06-20 13:27:28.771021
# Unit test for function read_stream
def test_read_stream():

    # Test data smaller than the size in the header
    data_stream = StringIO()
    data_stream.write('10\nabcdefghij\nabcdefghijabcdefghijabcdefghijabcdefghij\n')  # size + 2 newlines
    data_stream.seek(0)
    assert read_stream(data_stream) == b'abcdefghij'

    # Test data bigger than the size in the header
    data_stream = StringIO()
    data_stream.write('10\nabcdefghijklmnop\nabcdefghijklmnopabcdefghijklmnopabcdefghijklmnop\n')  # size + 2 newlines
    data_stream.seek(0)
    assert read_stream(data_stream) == b'abcdefghijklmnop'

    #

# Generated at 2022-06-20 13:27:30.948825
# Unit test for method handler of class ConnectionProcess
def test_ConnectionProcess_handler():
    connection_process = ConnectionProcess(None, None, None, None, None, None)
    connection_process.handler(signum = None, frame = None)
    assert True


# Generated at 2022-06-20 13:27:41.289373
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    fd = StringIO()
    play_context = PlayContext()
    socket_path = "/path/to/connection.sock"
    original_path = "/"
    cp = ConnectionProcess(fd, play_context, socket_path, original_path)

    #  exception raised from constructor

# Generated at 2022-06-20 13:27:45.310692
# Unit test for method handler of class ConnectionProcess
def test_ConnectionProcess_handler():
    # Test exception
    # Test not exception
    pass


# Generated at 2022-06-20 13:27:52.410071
# Unit test for function file_lock
def test_file_lock():
    try:
        with file_lock(unfrackpath(C.DEFAULT_LOCAL_TMP, None) + "/ansible_tempfile.lock"):
            assert True
    except:
        assert False



# Generated at 2022-06-20 13:27:59.927680
# Unit test for function file_lock
def test_file_lock():
    lock_fd = os.open("/tmp/unit_test_lock", os.O_RDWR | os.O_CREAT, 0o600)
    fcntl.lockf(lock_fd, fcntl.LOCK_EX)
    fcntl.lockf(lock_fd, fcntl.LOCK_UN)
    os.close(lock_fd)
    try:
        os.unlink("/tmp/unit_test_lock")
    except Exception as e:
        pass


# Generated at 2022-06-20 13:28:07.737478
# Unit test for function file_lock
def test_file_lock():
    lock_path = "/tmp/lock_path"

    def assert_file_lock_exists(lock_path):
        file_lock_exists = False
        try:
            with file_lock(lock_path):
                file_lock_exists = True
        except IOError:
            pass

        assert file_lock_exists, "File lock does not exist"

    # These tests are only expected to work on Posix platforms.
    assert os.name == "posix", "Platform is %s not Posix" % os.name

    # Check if file lock is acquired.
    assert_file_lock_exists(lock_path)

    # Check that file lock is released after using `with file_lock()`
    with assert_file_lock_exists(lock_path):
        pass

    # Clean up

# Generated at 2022-06-20 13:28:14.601020
# Unit test for constructor of class ConnectionProcess
def test_ConnectionProcess():
    fd = None
    play_context = PlayContext()
    socket_path = "socket path"
    original_path = "original path"
    obj = ConnectionProcess(fd, play_context, socket_path, original_path)
    assert obj.play_context == play_context
    assert obj.socket_path == socket_path
    assert obj.original_path == original_path
    assert obj.fd == fd


# Generated at 2022-06-20 13:28:17.746676
# Unit test for method command_timeout of class ConnectionProcess
def test_ConnectionProcess_command_timeout():

    test_process = ConnectionProcess(display, PlayContext(), 'test_socket_path', 'relative_path', task_uuid='test_task_uuid')
    test_process.connection = Connection()


# Generated at 2022-06-20 13:28:56.092215
# Unit test for method command_timeout of class ConnectionProcess
def test_ConnectionProcess_command_timeout():
    pname = os.path.join(C.DEFAULT_LOCAL_TMP, 'ansible-test-{0}'.format(time.time()))
    makedirs_safe(C.DEFAULT_LOCAL_TMP, 0o700)
    fd = os.open(pname, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    play_context = PlayContext()

# Generated at 2022-06-20 13:29:05.687774
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    fd = sys.stdin
    play_context = PlayContext()
    socket_path = 'test socket path'
    original_path = 'test original path'
    task_uuid = 'test task uuid'
    variables = 'test variables'
    c = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid)
    c.start(variables)


# Generated at 2022-06-20 13:29:15.496119
# Unit test for function main
def test_main():

    # Read environment variable ANSIBLE_PERSISTENT_COMMAND_TIMEOUT
    # If not set, set to 600 seconds (10 minutes)
    global C
    timeout = os.getenv('ANSIBLE_PERSISTENT_COMMAND_TIMEOUT')
    if not timeout:
        timeout = 600
    else:
        # if the environment variable is set, we need to ensure it is an int
        try:
            timeout = int(timeout)
        except ValueError:
            timeout = 600

    ansible_playbook_pid = '1234'
    task_uuid = '4567'

    # Create a string with the play context data

# Generated at 2022-06-20 13:29:23.517790
# Unit test for method command_timeout of class ConnectionProcess
def test_ConnectionProcess_command_timeout():
    fd = StringIO()
    lock_path = '.ansible_pc_lock'
    socket_path = '/tmp/test-socket'
    play_context = PlayContext()
    play_context.connection = 'local'
    connection_process = ConnectionProcess(fd, play_context, socket_path, '.')

# Generated at 2022-06-20 13:29:30.706871
# Unit test for function file_lock
def test_file_lock():
    """Test lock file created in with file_lock statement and deleted after end."""
    # Create lock file
    l_file = "/tmp/lockfile"
    with file_lock(l_file):
        assert os.path.exists(l_file)
    # Verify lock file is deleted
    assert not os.path.exists(l_file)



# Generated at 2022-06-20 13:29:37.882312
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():

    pid = os.getpid()
    cwd = os.getcwd()
    play_context = PlayContext('<host-tests.py>')
    socket_path = unfrackpath("%s/.ansible_pc/ansible-pc-%s-%s" % (cwd, pid, play_context.remote_addr))
    original_path = os.path.dirname(os.path.dirname(__file__))
    persistent_log_messages = True
    persistent_log_messages = False
    fd = StringIO()

    conn_process = ConnectionProcess(fd, play_context, socket_path, original_path)
    conn_process.start({'ansible_persistent_log_messages': persistent_log_messages})
    conn_process.run()
    # test for method run of class

# Generated at 2022-06-20 13:29:41.345822
# Unit test for method handler of class ConnectionProcess
def test_ConnectionProcess_handler():
    try:
        print("In handler method")
    except Exception:
        raise

# Generated at 2022-06-20 13:29:42.229486
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    pass

# Generated at 2022-06-20 13:29:52.919069
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    display = Display()
    csock = "/var/tmp/ansible_test_foo"
    os.mkdir(csock)
    os.rmdir(csock)
    pc = PlayContext()
    cp = ConnectionProcess('', pc, csock, "")
    cp.connection = Connection(pc, csock)
    cp.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    cp.sock.bind(csock)
    cp.sock.listen(1)
    assert os.path.exists(csock)
    assert cp.connection._connected is False
    assert cp.connection._socket_path is None
    cp.shutdown()
    assert not os.path.exists(csock)
    assert cp.connection._connected is False

# Generated at 2022-06-20 13:30:01.761652
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    context = PlayContext()
    context.private_key_file = '~/.ssh/id_rsa'
    context.password = 'ansible'
    context.connection = 'network_cli'
    context.network_os = 'junos'
    context.become = False
    context.become_method = 'enable'
    context.become_pass = 'ansible'

    try:
        os.remove("./ansible_connection.sock")
    except:
        pass
    fd, file_name = tempfile.mkstemp(text=False)
    os.close(fd)
    pro = ConnectionProcess(file_name, context, "ansible_connection.sock", ".")
    pro.run()


# Generated at 2022-06-20 13:30:41.987903
# Unit test for method command_timeout of class ConnectionProcess
def test_ConnectionProcess_command_timeout():
    dummy_module_set_module_args=dict()
    dummy_module_set_module_args['connection'] = 'network_cli'
    dummy_module_set_module_args['persistent_command_timeout'] = '30'
    dummy_module_set_module_args['host'] = 'localhost'
    dummy_module_set_module_args['username'] = 'admin'
    dummy_module_set_module_args['password'] = 'admin'
    dummy_module_set_module_args['persistent_connect_timeout'] = '5'
    dummy_module_set_module_args['use_ssl'] = 'no'

    play_context = PlayContext()
    play_context.__setattr__('network_os', 'ios')
    play_context.__setattr__('become', 'no')
   

# Generated at 2022-06-20 13:30:43.958794
# Unit test for function file_lock
def test_file_lock():
    import tempfile
    with file_lock(tempfile.gettempdir()):
        pass



# Generated at 2022-06-20 13:30:53.033602
# Unit test for method command_timeout of class ConnectionProcess
def test_ConnectionProcess_command_timeout():
    play_context = PlayContext()
    socket_path = '/home/test'
    original_path = '/home/ansible'
    fd, path = tempfile.mkstemp()
    cp = ConnectionProcess(fd, play_context, socket_path, original_path)
    msg = 'command timeout triggered, timeout value is %s secs.\nSee the timeout setting options in the Network Debug and Troubleshooting Guide.' % cp.connection.get_option('persistent_command_timeout')
    try:
        cp.command_timeout(1, 1)
    except Exception as e:
        assert msg in str(e)


# Generated at 2022-06-20 13:31:06.762425
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    fd, socket_path, original_path, play_context, uuid, pid = (1, 'path', 'original_path', PlayContext(), '1234', '1234')

    mock_dict = {'method': 'exec_command', 'params': {}, 'jsonrpc': '2.0', 'id': '1'}
    mock_resp = to_bytes(json.dumps({'jsonrpc': '2.0', 'id': '1', 'result': {}}, cls=AnsibleJSONEncoder))

    mock_s = MagicMock(spec_set=socket.socket)

    mock_s.accept.return_value = (mock_s, 'addr')
    mock_s.recv_data.return_value = to_bytes(json.dumps(mock_dict))

    mock_s

# Generated at 2022-06-20 13:31:13.155136
# Unit test for function read_stream
def test_read_stream():
    fake_stream = StringIO()
    fake_stream.write(b"78\n"  # size of 78
                      b"{\"x\": \"1\\r\\n\"}\n"  # literal JSON plus escaped newlines
                      b"0a7b2278223a20222e442a240a227d\n")  # SHA1 of the json
    fake_stream.seek(0)
    assert json.loads(read_stream(fake_stream)) == {"x": "1\n"}



# Generated at 2022-06-20 13:31:25.367100
# Unit test for function main
def test_main():
    from ansible import constants
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_executor import TaskExecutor

    play_context = PlayContext()
    task_vars = dict()
    host_vars = dict()
    result = dict()
    result['error'] = ''
    # Test if error is False and rc is 1
    def mock_error(self, *args, **kwargs):
        return False
    # Test if error is True and rc is not 0
    def mock_error_true(self, *args, **kwargs):
        return True


# Generated at 2022-06-20 13:31:32.781349
# Unit test for method connect_timeout of class ConnectionProcess
def test_ConnectionProcess_connect_timeout():
    from ansible.errors import AnsibleError
    from ansible.module_utils.six.moves import StringIO
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    cp = ConnectionProcess(fd=None, play_context=None, socket_path=None, original_path=None, task_uuid=None, ansible_playbook_pid=None)
    cp.connect_timeout(signum=None, frame=None)


# Generated at 2022-06-20 13:31:36.734314
# Unit test for method handler of class ConnectionProcess
def test_ConnectionProcess_handler():
    # Create an object of class ConnectionProcess
    obj = ConnectionProcess(fd=None, play_context=None, socket_path=None, original_path=None)
    # Call method handler of class ConnectionProcess
    obj.handler(signum=1, frame=None)


# Generated at 2022-06-20 13:31:48.102635
# Unit test for function file_lock
def test_file_lock():
    # Create lock file
    lock_dir  = 'test_dir/'
    lock_path = 'test_dir/test_file'
    if not os.path.exists(lock_dir):
        os.makedirs(lock_dir)
    with open(lock_path, 'w') as f:
        fcntl.lockf(f.fileno(), fcntl.LOCK_EX)
        fcntl.lockf(f.fileno(), fcntl.LOCK_UN)
    fcntl.lockf(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    with file_lock(lock_path):
        assert True

# Generated at 2022-06-20 13:31:49.354499
# Unit test for method handler of class ConnectionProcess
def test_ConnectionProcess_handler():
    pass


# Generated at 2022-06-20 13:32:24.992508
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    global display
    display = Display()
    cp = ConnectionProcess(fd = sys.stdout,
                           play_context = PlayContext(),
                           socket_path = './test',
                           original_path = '/test/path')
    cp.run()


# Generated at 2022-06-20 13:32:29.194145
# Unit test for method connect_timeout of class ConnectionProcess
def test_ConnectionProcess_connect_timeout():
	"""
	:param:
	:reutrn:
	"""
	pass


# Generated at 2022-06-20 13:32:42.836009
# Unit test for method command_timeout of class ConnectionProcess
def test_ConnectionProcess_command_timeout():
    testargs = []
    testargs.append('ansible-connection')
    testargs.append('--tmp=%s' % os.getcwd())
    testargs.append('--forks=1')
    testargs.append('--module-path=lib/ansible/modules/network')
    testargs.append('--module-name=cli_command')
    testargs.append('-a')
    testargs.append('--host=%s' % '10.0.0.0')
    testargs.append('--network_os=arista_eos')
    testargs.append('-u')
    testargs.append('--user=%s' % 'vagrant')
    testargs.append('-k')
    testargs.append('-i')

# Generated at 2022-06-20 13:32:47.017916
# Unit test for method handler of class ConnectionProcess
def test_ConnectionProcess_handler():
    ConnectionProcess_handler = ConnectionProcess(None, None, None, None, None, None)
    assert ConnectionProcess_handler


# Generated at 2022-06-20 13:32:54.518583
# Unit test for constructor of class ConnectionProcess
def test_ConnectionProcess():
    fd, play_context, socket_path, original_path, task_uuid = sys.stdin, PlayContext(), None, None, None
    ansible_playbook_pid = os.getpid()
    connection_process = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)
    assert connection_process.fd == fd
    assert connection_process.play_context == play_context
    assert connection_process.socket_path == socket_path
    assert connection_process.original_path == original_path
    assert connection_process._task_uuid == task_uuid
    assert connection_process._ansible_playbook_pid == ansible_playbook_pid
    assert connection_process.srv.registered_objects