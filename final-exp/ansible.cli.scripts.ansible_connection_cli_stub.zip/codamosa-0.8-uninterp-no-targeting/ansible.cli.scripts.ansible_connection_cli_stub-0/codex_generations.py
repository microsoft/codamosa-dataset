

# Generated at 2022-06-20 13:23:36.023740
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    import psutil, os
    from ansible.module_utils.connection import Connection, ConnectionError
    from ansible.plugins.connection.local import Connection as LocalConnection
    class ConnectionProcessTester(ConnectionProcess):
        def __init__(self, fd, play_context, socket_path, original_path):
            super(ConnectionProcess, self).__init__(fd, play_context, socket_path, original_path)

    class ConnectionTester(Connection):
        '''
        This connection class is used for testing purposes.
        '''
        def __init__(self, play_context, new_stdin, task_uuid, ansible_playbook_pid):
            super(ConnectionTester, self).__init__(play_context, new_stdin, task_uuid, ansible_playbook_pid)
            self._

# Generated at 2022-06-20 13:23:48.322618
# Unit test for function main
def test_main():
    fork_process = MagicMock()
    pid = MagicMock()
    r,w = MagicMock()
    rfd = MagicMock()
    wfd = MagicMock()
    data = MagicMock()
    os.pipe = MagicMock(return_value=(r,w))
    os.fdopen = MagicMock(side_effect=(wfd,rfd))
    wfd.write = MagicMock()
    rfd.read = MagicMock(return_value = data)
    os.close = MagicMock()
    os.getcwd = MagicMock()
    socket_path = MagicMock()
    lock_path = MagicMock()

# Generated at 2022-06-20 13:23:55.980679
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    fd = StringIO()
    socket_path = "/var/process/ansible_proc/a.sock"
    original_path = "/var/process/ansible_proc"
    play_context = PlayContext()
    cp = ConnectionProcess(fd, play_context, socket_path, original_path)
    # test with a.sock
    assert cp.shutdown() == None, cp.shutdown()
    # test with /var/process/ansible_proc/.ansible_pc_lock_a.sock
    cp.socket_path = "/var/process/ansible_proc/.ansible_pc_lock_a.sock"
    assert cp.shutdown() == None, cp.shutdown()
    cp.socket_path = "/var/process/ansible_proc/a.sock"
    cp.s

# Generated at 2022-06-20 13:23:56.416969
# Unit test for method connect_timeout of class ConnectionProcess
def test_ConnectionProcess_connect_timeout():
    pass

# Generated at 2022-06-20 13:24:02.501441
# Unit test for method command_timeout of class ConnectionProcess
def test_ConnectionProcess_command_timeout():
    '''
    Unit test method command_timeout of class ConnectionProcess
    '''
    instance = ConnectionProcess("fd", "play_context", "socket_path", "original_path")
    instance.command_timeout("signum", "frame")


# Generated at 2022-06-20 13:24:09.907743
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    from ansible.module_utils.six.moves import StringIO

    sys.stdout = StringIO()

    display = Display()
    display.verbosity = 4

    fd = StringIO()
    play_context = PlayContext()
    play_context.connection = 'persistent'
    play_context.network_os = 'ios'
    variables = {}
    connection_process = ConnectionProcess(fd, play_context, "/tmp/foo/bar", to_bytes(__file__), task_uuid="1-1-1-1")
    connection_process.start(variables)


# Generated at 2022-06-20 13:24:19.696230
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():

    # test for method start
    # list of return values for mocked function start
    mock_start_return_values = [{
        "error": None,
        "messages": [
            ('vvvv', 'control socket path is /tmp/ansible-pc-1000.sock')
        ],
        "exception": None
    }]

    # list of arguments for mocked function `start`

# Generated at 2022-06-20 13:24:27.560958
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    # create a ConnectionProcess object
    result = None
    # try:
    #     fd = open('/tmp/test_stdin', 'r+')
    # except IOError:
    #     print('Could not open /tmp/test_stdin')
    #     sys.exit(1)
    #
    # play_context = PlayContext()
    # socket_path = '/tmp/test_socket'
    # original_path = '/tmp'
    # task_uuid = None
    # ansible_playbook_pid = None
    # variables = {"persistent_command_timeout": 300}
    #
    # conn = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)
    # conn.start(variables)
    # conn.run

# Generated at 2022-06-20 13:24:35.961073
# Unit test for method command_timeout of class ConnectionProcess

# Generated at 2022-06-20 13:24:44.985915
# Unit test for function read_stream
def test_read_stream():
    data = b'{"foo": "bar"}'

    data_stream = StringIO()
    data_stream.write(to_bytes(len(data)))
    data_stream.write(b"\n")
    data_stream.write(to_bytes(data))
    data_stream.write(to_bytes("\n"))
    data_stream.write(to_bytes(hashlib.sha1(data).hexdigest()))
    data_stream.write(to_bytes("\n"))

    # restore escaped loose \r characters
    data_stream.seek(0, 0)
    result = read_stream(data_stream)
    assert result == data


# Generated at 2022-06-20 13:25:25.723253
# Unit test for function main
def test_main():
    jsonrpc_server_mock = MockJsonRpcServer()
    with patch.object(server, 'JsonRpcServer', return_value=jsonrpc_server_mock):
        with patch.object(sys, 'stderr', new_callable=StringIO) as mock_stderr:
            with patch.object(sys, 'stdout', new_callable=StringIO) as mock_stdout:
                main()
                assert jsonrpc_server_mock.init_called is True
                assert mock_stderr.getvalue() == ""


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 13:25:26.992620
# Unit test for method handler of class ConnectionProcess
def test_ConnectionProcess_handler():
    pass


# Generated at 2022-06-20 13:25:36.319526
# Unit test for constructor of class ConnectionProcess
def test_ConnectionProcess():
    connection_process = ConnectionProcess(sys.stdout, PlayContext(), 'test/path', 'original/path',
                                           'unique_string_for_this_play')
    assert connection_process.socket_path == 'test/path'
    assert connection_process.original_path == 'original/path'
    assert connection_process._task_uuid == 'unique_string_for_this_play'
    assert connection_process.connection is None
    assert connection_process.exception is None
    assert connection_process.sock is None



# Generated at 2022-06-20 13:25:46.360165
# Unit test for method command_timeout of class ConnectionProcess
def test_ConnectionProcess_command_timeout():
    import pytest
    from ansible.module_utils.connection import connection_loader

    class MockConnection(object):
        def __init__(self, context, new_stdin, task_uuid=None, ansible_playbook_pid=None):
            self._task_uuid = task_uuid
            self.connected = False

        def connect(self):
            self.connected = True

        def get_option(self, option):
            return 1

    connection_loader._fact_cache.clear()
    connection_loader._variables.clear()
    # Making sure there is no other connection plugin loaded
    assert len(connection_loader._plugins) == 0
    connection_loader._plugins = ('mock',)
    connection_loader._fact_cache['mock'] = MockConnection

# Generated at 2022-06-20 13:25:57.435076
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    # Create mock objects and mock functions
    mock_play_context = mock.patch.object(PlayContext, '__init__').start()
    mock_connection = mock.patch('ansible.module_utils.paramiko.connection.Paramiko', autospec=True).start()
    mock_ansible_playbook_pid = mock.patch('ansible.module_utils.persistent_connection.os.getpid').start()
    mock_connection.set_options.return_value = None
    mock_ansible_playbook_pid.return_value = '9'
    mock_sys_stdout = mock.Mock()
    # mock_sys_stdout.getvalue.return_value = list()
    # mock_sys_stdout.splitlines.return_value = list()

# Generated at 2022-06-20 13:26:07.608656
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    fd = StringIO()
    play_context = PlayContext()
    socket_path = StringIO()
    original_path = StringIO()
    task_uuid = StringIO()
    ansible_playbook_pid = StringIO()
    cp = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)
    variables = StringIO()
    cp.start(variables)



# Generated at 2022-06-20 13:26:11.486124
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    cp_obj = ConnectionProcess("fd", "play_context", "socket_path", "original_path", "task_uuid")
    retval = cp_obj.shutdown("fd", "play_context", "task_uuid")
    assert retval == None


# Generated at 2022-06-20 13:26:19.878772
# Unit test for function read_stream

# Generated at 2022-06-20 13:26:32.742118
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    play_context = PlayContext()
    socket_path = '/var/lib/awx/projects/project_folder/54.host'
    original_path = '/var/lib/awx/projects/project_folder'
    task_uuid = '09c7f80d-2b51-414e-b768-15aae9b2a47b'
    ansible_playbook_pid = 11
    fd = open('test.json', 'w')
    connection = ConnectionProcess(fd,play_context,socket_path,original_path,task_uuid,ansible_playbook_pid)
    connection.start({'connection': 'network_cli'})



# Generated at 2022-06-20 13:26:42.222959
# Unit test for function file_lock
def test_file_lock():
    import tmp
    import shutil

    def exception_handler(exception_type, exception, traceback):
        traceback_str = ''.join(traceback.format_tb(traceback))
        sys.stderr.write(to_bytes('{0}: {1}\n{2}'.format(exception_type.__name__, exception, traceback_str)))

    # register the sys.excepthook to catch unhandled exceptions
    sys.excepthook = exception_handler

    # create a temporary directory to use for testing
    test_dir = tmp.mktemp()
    lock_path = os.path.join(test_dir, 'test.lock')

    # create a lock and lock the file
    lock = file_lock(lock_path)
    lock.__enter__()

    # create a second

# Generated at 2022-06-20 13:27:20.580166
# Unit test for method connect_timeout of class ConnectionProcess
def test_ConnectionProcess_connect_timeout():
    '''
    Tests for method connect_timeout of class ConnectionProcess
    '''
    from ansible.module_utils.network.common.utils import dict_difference
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import MagicMock


    klass = ConnectionProcess
    m_fcntl = MagicMock()
    fcntl = sys.modules[m_fcntl.__module__]
    fcntl.fcntl.lockf = m_fcntl


    # Replace the following methods with empty function
    # to suppress unwanted execution of sub functions
    def empty(self):
        return


# Generated at 2022-06-20 13:27:23.144968
# Unit test for method connect_timeout of class ConnectionProcess
def test_ConnectionProcess_connect_timeout():
    try:
        raise Exception('Something went wrong')
    except Exception as e:
        assert 'Something went wrong' == str(e)

# Generated at 2022-06-20 13:27:36.996412
# Unit test for function read_stream
def test_read_stream():
    # Fake out a socket
    try:
        # python 2
        from cStringIO import StringIO as BytesIO
    except ImportError:
        # python 3
        from io import BytesIO

    fake_socket = BytesIO()

    def write_stream(byte_stream, data):
        assert isinstance(data, bytes)
        byte_stream.write(to_bytes("{0}\n".format(len(data))))
        byte_stream.write(data)
        byte_stream.write(to_bytes("\n{0}".format(hashlib.sha1(data).hexdigest())))

    data = b"hello world"
    write_stream(fake_socket, data)
    fake_socket.seek(0)
    assert read_stream(fake_socket) == data


# Generated at 2022-06-20 13:27:47.454062
# Unit test for constructor of class ConnectionProcess
def test_ConnectionProcess():
    # (p1_fd, p2_fd) = os.pipe()
    C.ANSIBLE_LOG_PATH = '/dev/null'
    #display = Display()
    #display.verbosity = 10
    my_playcontext = PlayContext()
    socket_path = 'path'
    original_path = 'path'
    task_uuid = 'uuid'
    ansible_playbook_pid = 'pid'
    my_conn_obj = ConnectionProcess(None, my_playcontext, socket_path, original_path, task_uuid, ansible_playbook_pid)
    my_vars = dict()
    my_vars['ansible_user'] = 'user'
    my_vars['ansible_password'] = 'password'
    my_vars['ansible_connection'] = 'connection'


# Generated at 2022-06-20 13:28:00.556904
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    def fake_connection_loader_get(connection, play_context, new_stdin, task_uuid, ansible_playbook_pid):
        return (connection, play_context, new_stdin, task_uuid, ansible_playbook_pid)

    fd_ = StringIO()
    play_context = PlayContext()
    socket_path = '/usr/local/bin/ansible'
    original_path = '/etc/ansible'
    task_uuid = '12345'
    ansible_playbook_pid = '12346'
    cp = ConnectionProcess(fd_, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)

# Generated at 2022-06-20 13:28:03.829160
# Unit test for function file_lock
def test_file_lock():
    path = "/tmp/test_file_lock.%d.%d" % (os.getpid(), time.time())
    try:
        with file_lock(path):
            print("Got lock")
            time.sleep(3)
    finally:
        os.remove(path)



# Generated at 2022-06-20 13:28:07.737446
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    play_context = PlayContext()
    fd = StringIO()
    socket_path = "/tmp/ansible_test_2714_connection"
    original_path = "/tmp/ansible_test_2714_original"
    connection_process = ConnectionProcess(fd, play_context, socket_path, original_path)
    connection_process.start({})
    assert os.path.exists(socket_path)
    os.remove(socket_path)


# Generated at 2022-06-20 13:28:12.183733
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    process = ConnectionProcess()
    process.sock = "sock"

# Generated at 2022-06-20 13:28:15.532433
# Unit test for method handler of class ConnectionProcess
def test_ConnectionProcess_handler():
    try:
        cp = ConnectionProcess()
        cp.handler()
    except Exception as e:
        if 'signal handler' in to_text(e):
            assert True



# Generated at 2022-06-20 13:28:16.154612
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    pass



# Generated at 2022-06-20 13:28:48.625989
# Unit test for method command_timeout of class ConnectionProcess
def test_ConnectionProcess_command_timeout():
  con_proc = ConnectionProcess(sys.stdout, PlayContext(), '/var/run/ansible/ansible-ssh-uni-23', '', '', '')
  con_proc.command_timeout('', '')
  pass

# Generated at 2022-06-20 13:28:59.102108
# Unit test for function file_lock
def test_file_lock():
    import shutil
    from tempfile import mkdtemp
    from os.path import join

    # Create a temporary directory to hold the lock test files
    temp_dir = mkdtemp()

    # Try to raise an exception for locking the same file twice
    lock_file = join(temp_dir, 'lock.file')
    with file_lock(lock_file):
        exception_raised = False
        try:
            with file_lock(lock_file):
                pass
        except Exception:
            exception_raised = True
        assert exception_raised is True

    # Lock a file, read it, unlock it, then read it again.
    # The file should be locked during the first read
    lock_file = join(temp_dir, 'lock.file')

# Generated at 2022-06-20 13:29:01.895417
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    # TODO
    pass


# Generated at 2022-06-20 13:29:04.238039
# Unit test for method command_timeout of class ConnectionProcess
def test_ConnectionProcess_command_timeout():
    # Initializing an object of class ConnectionProcess
    cp = ConnectionProcess()
    # Calling function command_timeout
    cp.command_timeout()


# Generated at 2022-06-20 13:29:10.585924
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    fd = StringIO()
    play_context = PlayContext()
    play_context.remote_addr = 'localhost'
    socket_path = '/tmp/socket_path'
    original_path = '/tmp/original_path'
    variables = {}
    connection_process = ConnectionProcess(fd, play_context, socket_path, original_path)
    connection_process.start(variables)


# Generated at 2022-06-20 13:29:14.190610
# Unit test for function read_stream
def test_read_stream():
    stream = StringIO(to_bytes('''
        24
        The quick brown fox
        f13fb67affdcb2ac9e7ffd6ce782bbb4cf4396e3
    '''))

    assert read_stream(stream) == b'The quick brown fox'


# Generated at 2022-06-20 13:29:28.553641
# Unit test for method command_timeout of class ConnectionProcess
def test_ConnectionProcess_command_timeout():

    class FakeSignal:
        def __init__(self):
            self.called_signum = None

        def signal(self, signum, frame):
            self.called_signum = signum
            raise Exception("Connect Timeout")

    fake_signal = FakeSignal()

    class FakeConnection:
        def __init__(self):
            self.options = {}
            self.options['persistent_command_timeout'] = 7
            self.messages = list()

        def pop_messages(self):
            return self.messages

        def get_option(self, opt):
            return self.options[opt]

    pc = ConnectionProcess(None, None, None, None)

    pc.command_timeout = fake_signal.signal
    pc.connection = FakeConnection()

    test_data = "request"

# Generated at 2022-06-20 13:29:37.485179
# Unit test for method handler of class ConnectionProcess
def test_ConnectionProcess_handler():
    from unittest.mock import patch
    from multiprocessing import Process

    # Setup
    class TestProcess(Process):
        def __init__(self):
            super(TestProcess, self).__init__()

        def run(self):
            with open(fds[1], 'wb+') as fd:
                try:
                    with file_lock(lock_path) as lock:
                        # Create a connection process
                        connection_process = ConnectionProcess(fd, play_context, socket_path, temp_dir, uuid.uuid4())
                        # Start the connection process
                        connection_process.start(variables)

                        while True:
                            time.sleep(1)
                except Exception as e:
                    fd.write(to_bytes(e))

# Generated at 2022-06-20 13:29:49.262610
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    '''
    in this test we fake the setup of the connection process
    and use the signal mechanism to trigger the connect_timeout function
    '''
    signal.signal = fake_signal_signal

    def _signal_handler(*args, **kwargs):
        return True

    signal.signal_handler = _signal_handler

    import os
    import socket
    import traceback
    import subprocess

    # Create a temp directory and chdir there
    temp_dir = tempfile.mkdtemp()
    os.chdir(temp_dir)

    if PY3:
        fd, fd_path = tempfile.mkstemp(dir=temp_dir)
        fd = open(fd_path, 'wb+')

# Generated at 2022-06-20 13:29:58.787220
# Unit test for function main
def test_main():
    class FakeDisplay(Display):
        def __init__(self):
            self.verbosity = 0
            self.errors = []

        def display(self, msg, log_only=None):
            if msg not in self.errors:
                self.errors.append(msg)

    display.verbosity = 0
    display.display = FakeDisplay().display

    class FakeStdIn(StringIO):
        def __init__(self):
            StringIO.__init__(self)
            self.write(socket.socket(socket.AF_UNIX, socket.SOCK_STREAM).getsockname())

    class FakeStdOut(object):
        def __init__(self):
            self.buffer = StringIO()

        def write(self, data):
            self.buffer.write(data)


# Generated at 2022-06-20 13:30:29.050244
# Unit test for method connect_timeout of class ConnectionProcess
def test_ConnectionProcess_connect_timeout():
    obj = ConnectionProcess()
    def dummy(signum, frame):
        raise Exception()
    obj.connect_timeout(dummy, dummy)

# Generated at 2022-06-20 13:30:38.634435
# Unit test for method command_timeout of class ConnectionProcess
def test_ConnectionProcess_command_timeout():
    # create a play context
    play_context = PlayContext()
    # create a file descriptor
    fd = StringIO()
    # create a socket path
    socket_path = '/path/to/sock'
    # create a original path
    original_path = '/path/to'
    # create an instance of ConnectionProcess
    connection = ConnectionProcess(fd, play_context, socket_path, original_path)
    # check if the class has a method command_timeout
    assert 'command_timeout' in dir(connection)



# Generated at 2022-06-20 13:30:50.742639
# Unit test for constructor of class ConnectionProcess
def test_ConnectionProcess():

    play_context = PlayContext()
    play_context.remote_addr = "localhost"
    socket_path = "/tmp/test_socket_path"
    original_path = "/tmp/test_original_path"
    task_uuid = "12345-67890"

    cp = ConnectionProcess(None, play_context, socket_path, original_path, task_uuid)
    assert cp.play_context == play_context
    assert cp.socket_path == socket_path
    assert cp.original_path == original_path
    assert cp._task_uuid == task_uuid

    assert cp.fd is None
    assert cp.exception is None
    assert isinstance(cp.srv, JsonRpcServer)
    assert cp.sock is None
    assert cp.connection is None
    assert cp._ansible

# Generated at 2022-06-20 13:30:57.750030
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    # setup module args
    p = mock.patch('ansible.module_utils.connection.open', create=True)
    m = p.start()
    fd = mock.MagicMock()
    m.return_value = fd
    playbook_context = mock.Mock()
    socket_path = mock.sentinel.socket_path
    original_path = mock.sentinel.original_path
    task_uuid = mock.sentinel.task_uuid
    ansible_playbook_pid = mock.sentinel.ansible_playbook_pid
    cp = connection_process.ConnectionProcess(fd, playbook_context, socket_path, original_path, task_uuid, ansible_playbook_pid)
    variables = mock.sentinel.variables
    # test start
    cp.start(variables)
   

# Generated at 2022-06-20 13:31:06.116692
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    '''
    ConnectionProcess.start() unit test
    '''
    sys.path.insert(0, os.getcwd())
    #msg_obj = connection_loader.get('network_cli')(play_context, new_stdin, '/dev/null', 'network_cli')
    #msg_obj.set_options({'network_cli': {'persistent_connection': 'network_cli'}})
    tmp_dir = '/tmp/ansible'
    socket_path = '/tmp/ansible/pc'
    task_uuid = '1'
    ansible_playbook_pid = 1
    module_args = dict(
        username='test',
        password='test',
        provider='gig',

    )

# Generated at 2022-06-20 13:31:14.699245
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    fd = sys.stdout
    play_context = PlayContext()
    socket_path = '/Users/michal/git/ansible-dev/lib/ansible/executor/connection_plugins/localhost/12345'
    original_path = '/Users/michal/git/ansible-dev'
    task_uuid = '2a7a6b9e-e3a3-4a01-a162-186f3f3c3d99'
    ansible_playbook_pid = ''

    with patch('ansible.plugins.connection.socket.socket') as mocked_socket, patch('ansible.cfg.ConfigParser') as mocked_configparser:

        connection = mocked_socket.return_value
        connection._socket_path = socket_path
        connection._connected = True
        connection._connection = None
       

# Generated at 2022-06-20 13:31:25.368222
# Unit test for method connect_timeout of class ConnectionProcess
def test_ConnectionProcess_connect_timeout():
    fd = os.fdopen(1, 'a')
    play_context = PlayContext()
    socket_path = None
    original_path = None
    task_uuid = None
    ansible_playbook_pid = None
    variables = None
    ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid).start(variables)
    temp = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)
    temp.connection = PlayContext()
    temp.connection.get_option = lambda x: 0
    temp.run()
    temp.shutdown()

# Generated at 2022-06-20 13:31:33.582064
# Unit test for constructor of class ConnectionProcess
def test_ConnectionProcess():
    d = Display()
    # we should add test for contextmanager and ForkProcess class after we moved the code to module_utils
    try:
        with file_lock(unfrackpath('test_dir/test_socket_dir/test.lock')):
            pass
    except Exception:
        pass
    write_file = StringIO()
    # when the lock file exists, skip the test

# Generated at 2022-06-20 13:31:38.429907
# Unit test for function read_stream
def test_read_stream():
    data = '{"json_data" : "value"}\n'
    data_hash = hashlib.sha1(data).hexdigest()
    stream = StringIO(str(len(data)) + "\n" + data + "\n" + data_hash + "\n")
    assert read_stream(stream) == data


# Generated at 2022-06-20 13:31:49.154397
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    # Test context manager used to release file lock
    class TestContextManager():
        def __enter__(self): 
            pass 
        def __exit__(self, a, b, c): 
            pass 

    setattr(sys.modules['__main__'], '__file__', 'ansible-connection-plugin')
    setattr(sys.modules['__main__'], '__package__', '')

    # create fake fd
    fd = StringIO()
    # create fake play_context
    play_context = PlayContext()
    # create fake socket_path
    socket_path = os.path.join(C.DEFAULT_LOCAL_TMP, '.ansible_pc/ansible-ssh-22-127.0.0.1')

    # create connection process object