

# Generated at 2022-06-20 13:23:29.298130
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    display = Display()
    class DummyConnection(Connection):
        transport = 'dummy'
        def _connect(self):
            pass
        def exec_command(self, command):
            pass
        def put_file(self, in_path, out_path):
            pass
        def fetch_file(self, in_path, out_path):
            pass
        def close(self):
            pass
        def set_host_overrides(self, host):
            pass
    class DummyPlayContext():
        def __init__(self):
            self.become = False
            self.become_method = 'sudo'
            self.become_user = 'root'
            self.become_ask_pass = False
            self.connection = 'dummy'

# Generated at 2022-06-20 13:23:31.352305
# Unit test for method handler of class ConnectionProcess
def test_ConnectionProcess_handler():
    """ Unit test for method handler of class ConnectionProcess """

    # No test data available

    pass


# Generated at 2022-06-20 13:23:32.930837
# Unit test for constructor of class ConnectionProcess
def test_ConnectionProcess():
    fd = None
    assert ConnectionProcess(fd, None, None, None)


# Generated at 2022-06-20 13:23:38.747657
# Unit test for function read_stream
def test_read_stream():
    output = [
        b'3\n',
        b'123\n',
        b'40bd001563085fc35165329ea1ff5c5ecbdbbeef\n'
    ]
    expected_result = b'123'
    data = StringIO(b''.join(output))
    result = read_stream(data)
    assert result == expected_result



# Generated at 2022-06-20 13:23:43.179961
# Unit test for method handler of class ConnectionProcess
def test_ConnectionProcess_handler():
    c = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid=None, ansible_playbook_pid=None)
    assert c is not None     

# Generated at 2022-06-20 13:23:46.179581
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    global display
    play_context = PlayContext()
    c = ConnectionProcess(sys.stdout, play_context, [], [])
    c.run()



# Generated at 2022-06-20 13:23:54.472496
# Unit test for constructor of class ConnectionProcess
def test_ConnectionProcess():
    # pylint: disable=missing-docstring
    display = Display()
    cp_obj = ConnectionProcess(display, None, None, None)
    assert cp_obj
    assert cp_obj.play_context is None
    assert cp_obj.socket_path is None
    assert cp_obj.original_path is None
    assert cp_obj._task_uuid is None
    assert cp_obj.fd is display
    assert cp_obj.exception is None
    assert cp_obj.srv
    assert cp_obj.sock is None
    assert cp_obj.connection is None



# Generated at 2022-06-20 13:23:58.602505
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    user_context = None
    fd = None
    play_context = PlayContext()
    socket_path = None
    original_path = None
    task_uuid = None
    ansible_playbook_pid = None
    class_instance_connection_process = ConnectionProcess(user_context, fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid, None)
    class_instance_connection_process.start(variables='variables')

# Generated at 2022-06-20 13:24:02.639111
# Unit test for method connect_timeout of class ConnectionProcess
def test_ConnectionProcess_connect_timeout():
    fd = StringIO()
    play_context = PlayContext()
    socket_path = "/home/pansible/playbook/playbook.py"
    original_path = "/home/pansible/playbook/playbook.py"
    task_uuid = None
    ansible_playbook_pid = None
    cp = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)
    cp.connect_timeout(1, 2)


# Generated at 2022-06-20 13:24:09.983183
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    """
    A unit test for method run of class ConnectionProcess using mock python module to mock the socket and
    socket_pair created by the method
    """

    # Create a mock PlayContext object using patch library and returns the mock object
    play_context_mock = MagicMock(PlayContext)

    # Create a mock Connection object using patch library by passing the type to be mocked and returns the mock object
    connection_mock = patch.object(connection_loader, 'get').return_value

    # Create a mock socket object using patch library and returns the mock object
    socket_pair_mock = patch('socket.socketpair').return_value

    # Create a mock file descriptor object using patch library and returns the mock object
    fd_mock = patch('os.open')

    # Create a mock file lock object using patch library and returns the mock object
    file_

# Generated at 2022-06-20 13:25:15.394890
# Unit test for function main
def test_main():
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec = dict()
    )
    module.exit_json = mock.Mock(return_value = dict(rc=0))
    module.fail_json = mock.Mock(return_value = dict(rc=1))
    rc = main()
    assert rc == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 13:25:23.147549
# Unit test for method handler of class ConnectionProcess
def test_ConnectionProcess_handler():
    sys.stdin.close()

    stdout = sys.stdout
    stderr = sys.stderr
    sys.stdout = sys.stderr = open('/dev/null', 'a')

    p = ConnectionProcess(fd=None, play_context=PlayContext(), socket_path='/dev/null', original_path='/dev/null')
    try:
        p.handler(None, None)
    except Exception:
        pass

    sys.stdout = stdout
    sys.stderr = stderr


display = Display()



# Generated at 2022-06-20 13:25:27.346428
# Unit test for method handler of class ConnectionProcess
def test_ConnectionProcess_handler():
    from collections import namedtuple

    pc = namedtuple('PlayContext', 'connection_lock')
    pc.connection_lock = None
    cp = ConnectionProcess(sys.stdout, pc, 'bad', 'good')
    try:
        cp.handler(signal.SIGALRM, None)
    except Exception:
        assert True
    else:
        assert False, "Should have raised an exception"


# Generated at 2022-06-20 13:25:34.634014
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    display = Display()
    args = (display, "127.0.0.1", "stack", "secret", "network_os")

    p = ConnectionProcess(*args)

    p.play_context.private_key_file = "secret.key"
    p.play_context.network_os = "network_os"
    p.start({"var1": 1, "var2": 2})


# Generated at 2022-06-20 13:25:44.903403
# Unit test for method connect_timeout of class ConnectionProcess
def test_ConnectionProcess_connect_timeout():
    # Setup test env
    from tempfile import mkstemp
    from unittest.mock import patch
    from ansible.module_utils.connection import Connection
    # Testcase 1
    fd, socket_path = mkstemp()
    # patch the constructor none Connection object
    with patch.object(Connection, '__init__', return_value=None):
        connection_process_obj = ConnectionProcess(fd, None, socket_path, None)
        connection_process_obj.connection = Connection(fd, None, None, None)
        # patch the method connect of Connection object
        with patch.object(Connection, 'connect', return_value=None):
            connection_process_obj.connect_timeout(0, None)

# Generated at 2022-06-20 13:25:56.145052
# Unit test for constructor of class ConnectionProcess
def test_ConnectionProcess():

    display = Display()
    fd = StringIO()
    play_context = PlayContext()
    socket_path = '/socket_path'
    original_path = '/original_path'
    connection = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid=None, ansible_playbook_pid=None)

    # Assert whether fd is None
    assert fd is not None

    # Assert whether play_context is not None
    assert play_context is not None

    # Assert whether socket_path is not None
    assert socket_path is not None

    # Assert whether original_path is not None
    assert original_path is not None

    # Assert whether connection is not None
    assert connection is not None

    # Assert whether socket_path is '/socket_path'
    assert socket

# Generated at 2022-06-20 13:26:01.753940
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    display = Display()
    play_context = PlayContext()
    socket_path = None
    original_path = None
    task_uuid = None
    ansible_playbook_pid = None

    fd = StringIO()
    self = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid=task_uuid, ansible_playbook_pid=ansible_playbook_pid)
    self.fd = fd
    self.play_context = play_context
    self.socket_path = socket_path
    self.original_path = original_path
    self._task_uuid = task_uuid
    self.srv = None
    self.sock = None
    self.connection = None
    self._ansible_playbook_pid = ansible_playbook_pid


# Generated at 2022-06-20 13:26:06.179771
# Unit test for function read_stream
def test_read_stream():
    in_stream = StringIO(b'4\r\nxxx\r\naf812c7dfabd0ca46c517a67f752980c7a34f1d0\r\n')
    out_stream = read_stream(in_stream)
    assert out_stream == 'xxx'

    in_stream = StringIO(b'4\r\nxxx\r\naf812c7dfabd0ca46c517a67f752980c7a34f1d0af812c7dfabd0ca46c517a67f752980c7a34f1d0\r\n')
    out_stream = read_stream(in_stream)
    assert out_stream == 'xxx'


# Generated at 2022-06-20 13:26:15.896808
# Unit test for function main
def test_main():
    import pytest
    from ansible.utils.path import makedirs_safe
    from ansible.utils.debug import connection_debug_handler as debug
    from ansible.module_utils.connection import Connection
    from ansible.playbook.play_context import PlayContext
    play_context = PlayContext()
    sys.argv = ['persistent', '1234', 'uuid']
    tmp_path = unfrackpath(C.PERSISTENT_CONTROL_PATH_DIR)
    ssh = connection_loader.get('ssh', class_only=True)
    cp = ssh._create_control_path(play_context.remote_addr, play_context.port, play_context.remote_user, play_context.connection,'1234')
    makedirs_safe(tmp_path)
    socket_path = unfrackpath

# Generated at 2022-06-20 13:26:31.764112
# Unit test for function file_lock
def test_file_lock():
    from ansible.module_utils.common.text.converters import to_bytes
    # Ansible-specific imports
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    """ function used by unit test to test file_lock """
    def main():
        """ Create a fake ansible module and call file_lock """
        ansible_module = AnsibleModule(
            argument_spec=dict(),
            supports_check_mode=True,
        )
        lock_path = ansible_module.tmpdir + '/test_file_lock.lock'
        with file_lock(lock_path):
            ansible_module.exit_json(changed=True)

    # Ansible-specific module configuration

# Generated at 2022-06-20 13:27:06.943627
# Unit test for method connect_timeout of class ConnectionProcess
def test_ConnectionProcess_connect_timeout():
    fd = StringIO()
    play_context = PlayContext
    socket_path = "/Users/ronald/.ansible/pc/7aafc0ba51"
    original_path = "/Users/ronald/ansible"
    task_uuid = None
    ansible_playbook_pid = None
    connection_process = ConnectionProcess(
        fd,
        play_context,
        socket_path,
        original_path,
        task_uuid,
        ansible_playbook_pid)
    signal = None
    frame = None
    connection_process.connect_timeout(signal, frame)



# Generated at 2022-06-20 13:27:14.693079
# Unit test for function file_lock
def test_file_lock():
    """
    Test for function file_lock
    """
    # Make sure we are in a temp dir so that we don't affect anything.
    # This is a little hacky.
    if 'ANSIBLE_TEST_DIR' in os.environ:
        base_dir = os.environ['ANSIBLE_TEST_DIR']
    else:
        base_dir = '/tmp'
    with open(os.path.join(base_dir, "test_file_lock"), 'a'):
        os.utime(os.path.join(base_dir, "test_file_lock"), None)
    with file_lock(os.path.join(base_dir, "test_file_lock")):
        f = open(os.path.join(base_dir, "test_file_lock"))
        assert fcntl

# Generated at 2022-06-20 13:27:22.924528
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    # setup class
    fp = StringIO()
    fd = fp
    play_context = PlayContext()
    socket_path = 'sockpath'
    original_path = 'original_path'
    task_uuid = 'task_uuid'
    ansible_playbook_pid = 'ansible_playbook_pid'
    connection_process = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)

    # setup mocks
    mocker = Mocker()
    mocker.mock()
    setattr(mocker.context, 'exception', None)
    with mocker.order():
        mocker.result(True)
        mocker.replay()

    # invoke
    connection_process.shutdown()

    # validate


# Generated at 2022-06-20 13:27:35.328524
# Unit test for function file_lock
def test_file_lock():
    import uuid
    import tempfile

    lock_path = '/tmp/%s' % str(uuid.uuid4())

    lock_fd = os.open(lock_path, os.O_RDWR | os.O_CREAT)
    fcntl.lockf(lock_fd, fcntl.LOCK_EX)

    # Try to lock a file that is already locked
    assert False == file_lock(lock_path)._exit_stack._exit_callbacks # can't access private member, so hack around it

    fcntl.lockf(lock_fd, fcntl.LOCK_UN)
    os.close(lock_fd)

    os.remove(lock_path)



# Generated at 2022-06-20 13:27:37.096759
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 13:27:44.282149
# Unit test for method command_timeout of class ConnectionProcess
def test_ConnectionProcess_command_timeout():
    play_context = PlayContext()
    socket_path = "/tmp/ansible_pers_server"
    original_path = "/tmp"
    task_uuid = None
    ansible_playbook_pid = None

    cp = ConnectionProcess(play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)
    cp.command_timeout(signal.SIGALRM, None)


# Generated at 2022-06-20 13:27:47.945934
# Unit test for function file_lock
def test_file_lock():
    lock_path = './test.lock'
    with file_lock(lock_path):
        assert os.stat(lock_path).st_nlink == 1
    assert os.stat(lock_path).st_nlink == 1

    os.unlink(lock_path)


# Generated at 2022-06-20 13:27:59.157281
# Unit test for method connect_timeout of class ConnectionProcess
def test_ConnectionProcess_connect_timeout():
    '''
    Test Case:
    test_ConnectionProcess_connect_timeout

    Description:
    Test for connection timeout
    '''
    fd = StringIO()
    play_context = PlayContext()
    socket_path = os.path.join(os.path.dirname(__file__), "ansible_connection.socket")
    original_path = "/tmp"
    task_uuid = None
    ansible_playbook_pid = None
    test_object=ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)
    test_object.connect_timeout(1,1)


# Generated at 2022-06-20 13:28:06.714783
# Unit test for method run of class ConnectionProcess

# Generated at 2022-06-20 13:28:09.550266
# Unit test for method command_timeout of class ConnectionProcess
def test_ConnectionProcess_command_timeout():
    c_p = ConnectionProcess([], PlayContext(), "", "")
    assert c_p.command_timeout(1, 1) is None


# Generated at 2022-06-20 13:28:38.493726
# Unit test for function file_lock
def test_file_lock():
    with file_lock(b"foo") as fd:
        pass


# Generated at 2022-06-20 13:28:46.955743
# Unit test for method handler of class ConnectionProcess
def test_ConnectionProcess_handler():
    display = Display()
    cp = ConnectionProcess(fd=None, play_context=None, socket_path=None, original_path=None, task_uuid=None, ansible_playbook_pid=None)
    with display.override_logger_messages():
        cp.handler(size=1234, frame=None)



# Generated at 2022-06-20 13:28:57.578669
# Unit test for function file_lock
def test_file_lock():

    def test_func(lock_path, file_to_write):
        with file_lock(lock_path):
            f = open(file_to_write, 'w')
            f.write('locked')

    lock_path = '/tmp/some_lock_file'
    file_to_write = '/tmp/some_file'

    if os.path.isfile(file_to_write):
        os.remove(file_to_write)

    test_func(lock_path, file_to_write)
    test_func(lock_path, file_to_write)
    test_func(lock_path, file_to_write)

    os.remove(lock_path)
    os.remove(file_to_write)



# Generated at 2022-06-20 13:29:05.691857
# Unit test for method handler of class ConnectionProcess
def test_ConnectionProcess_handler():
    fd = os.open(os.devnull, os.O_RDWR)
    play_context = PlayContext()
    socket_path = unfrackpath('/tmp/.ansible_pc_socket_%s' % fd)
    original_path = unfrackpath('/tmp')
    connectionProcess = ConnectionProcess(fd, play_context, socket_path, original_path)
    signum = signal.SIGALRM
    frame = None
    connectionProcess.handler(signum, frame)
    assert(True)


# Generated at 2022-06-20 13:29:12.043620
# Unit test for function file_lock
def test_file_lock():
    import tempfile
    global_lock = tempfile.mktemp()
    with file_lock(global_lock):
        with file_lock(global_lock):
            with file_lock(global_lock):
                raise Exception("Locks shouldn't interleave")
        with file_lock(global_lock):
            pass
        with file_lock(global_lock):
            pass
    with file_lock(global_lock):
        pass
    os.remove(global_lock)



# Generated at 2022-06-20 13:29:14.273155
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    cpx = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)
    result = cpx.run()


# Generated at 2022-06-20 13:29:24.815105
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    fd = open(os.devnull, 'w')
    socket_path = '/tmp/ansible_connection_test'
    original_path = os.getcwd()
    task_uuid = None
    ansible_playbook_pid = ansible_playbook_pid = os.getpid()
    play_context = PlayContext()
    ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid).shutdown()



# Generated at 2022-06-20 13:29:32.629370
# Unit test for method connect_timeout of class ConnectionProcess
def test_ConnectionProcess_connect_timeout():
    fd = StringIO()
    play_context = PlayContext()
    socket_path = 'socket_path'
    original_path = 'original_path'
    task_uuid = 'task_uuid'
    ansible_playbook_pid = 'ansible_playbook_pid'
    obj = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)
    signum = 'signum'
    frame = 'frame'
    obj.connect_timeout(signum, frame)


# Generated at 2022-06-20 13:29:35.530712
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    # Test exception handling
    # Test close connection
    pass



# Generated at 2022-06-20 13:29:37.520993
# Unit test for function file_lock
def test_file_lock():
    with file_lock('./test_file_lock') as locked:
        assert locked is None


# Generated at 2022-06-20 13:30:16.706412
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    """This test case is for checking shutdown method of ConnectionProcess class.
    """
    # Create an instance of ConnectionProcess class
    connection_process = ConnectionProcess()
    # Check whether the shutdown method of ConnectionProcess returns None in case if socket path does not exists.
    assert connection_process.shutdown() is None
    # Check whether the shutdown method of ConnectionProcess returns None in case if socket path exists.
    assert connection_process.shutdown() is None



# Generated at 2022-06-20 13:30:28.558372
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    from collections import namedtuple
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib

    def get_loader(vault_secret):
        return DataLoader({}).set_vault_secrets([(vault_secret, VaultLib([(vault_secret, vault_secret)], 1, json=True))])

    display = Display()
    variable

# Generated at 2022-06-20 13:30:42.506013
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    """
    Test for method start of class ConnectionProcess
    """
    from ansible.plugins.loader import connection_loader

    play_context = PlayContext()
    socket_path = '/tmp/test_ansible_connection'
    original_path = '/tmp'
    task_uuid = 'test_uuid'
    ansible_playbook_pid = 'test_ansible_playbook_pid'
    variables = {}
    connection_process = ConnectionProcess(0, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)
    if os.path.exists(socket_path):
        os.remove(socket_path)

# Generated at 2022-06-20 13:30:46.570896
# Unit test for constructor of class ConnectionProcess
def test_ConnectionProcess():
    conn = ConnectionProcess(sys.stdout, None, None, None)
    assert isinstance(conn, ConnectionProcess)


# Generated at 2022-06-20 13:30:50.659919
# Unit test for constructor of class ConnectionProcess
def test_ConnectionProcess():
    play_context = PlayContext()
    play_context.connection = 'network_cli'
    socket_path = "/tmp/ansible_pc_socket"
    original_path = "/home/test"

    pc = ConnectionProcess(None, play_context, socket_path, original_path)
    assert pc is not None


# Generated at 2022-06-20 13:30:56.189085
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    display = Display()
    display.verbosity = 4
    context = PlayContext()
    connection_info = dict()

# Generated at 2022-06-20 13:31:06.033874
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    display = Display()
    class MockSocket(object):
        def close(self):
            print('close method called')
    class MockConnection(object):
        def __init__(self, args):
            self.args = args
        def close(self):
            print('close method called')
        def get_option(self, option):
            if option == 'persistent_log_messages':
                return True
            assert option == 'persistent_log_messages'
    class MockJsonRpcServer(object):
        def __init__(self):
            self._handlers = []
        def register(self, connection):
            self._handlers.append(connection)
        def handle_request(self, data):
            return ''

# Generated at 2022-06-20 13:31:14.649079
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    socket_path = "/home/users/abambad/.ansible/tmp/ansible-local-22120e7d-245d-4568-a0b2-ea6131e2f1ac/ansible-tmp-1567772380.36-26081873579370/socket"
    lock_path = "/home/users/abambad/.ansible/tmp/ansible-local-22120e7d-245d-4568-a0b2-ea6131e2f1ac/.ansible_pc_lock_ansible-tmp-1567772380.36-26081873579370"
    fd = open('/tmp/myfile', 'w')
    context = None
    original_path = '/tmp'
    task_uuid = None
    ansible_playbook_pid = None

# Generated at 2022-06-20 13:31:26.437277
# Unit test for constructor of class ConnectionProcess
def test_ConnectionProcess():
    fd, x_pipe = socket.socketpair()

    p = ConnectionProcess(fd, PlayContext(), '/tmp/foo/socket', '/tmp/foo')
    test_data = dict()

# Generated at 2022-06-20 13:31:28.419899
# Unit test for method connect_timeout of class ConnectionProcess
def test_ConnectionProcess_connect_timeout():
    ConnectionProcess.connect_timeout()

# 

# Generated at 2022-06-20 13:32:28.656423
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    pass

# Generated at 2022-06-20 13:32:30.004200
# Unit test for function file_lock
def test_file_lock():
    with file_lock('test_file_lock'):
        pass



# Generated at 2022-06-20 13:32:43.705740
# Unit test for method command_timeout of class ConnectionProcess
def test_ConnectionProcess_command_timeout():
    # This test case is to check the command_timeout method.
    # command_timeout() method is triggered when persistent_command_timeout value is reached.
    # persistent_command_timeout value is set to 20secs.
    # command_timeout() method raises an exception.
    # writing the test cases to check if the exception is triggered and the message is printed.

    class MockConnectionProcess():
        def __init__(self):
            self.connection=MockConnection()

        def command_timeout(self, signum, frame):
            msg = 'command timeout triggered, timeout value is %s secs.\nSee the timeout setting options in the Network Debug and Troubleshooting Guide.'\
              % self.connection.get_option('persistent_command_timeout')
            display.display(msg, log_only=True)
            raise Exception(msg)


# Generated at 2022-06-20 13:32:52.920810
# Unit test for constructor of class ConnectionProcess
def test_ConnectionProcess():
    display = Display()
    display.verbosity = 4

    # Testing the connection process purely for modules which are used for network connection
    test_connection = 'local'
    test_play_context = PlayContext()
    test_socket_path = '/tmp/ansible_test_socket_path'
    test_original_path = '/tmp/ansible_test_original_path'
    test_task_uuid = 'test_task_uuid'
    test_ansible_playbook_pid = 'test_ansible_playbook_pid'
    test_cp = ConnectionProcess(display, test_play_context, test_socket_path, test_original_path, test_task_uuid, test_ansible_playbook_pid)
    assert test_cp.connection._ansible_playbook_pid == test_ansible_playbook