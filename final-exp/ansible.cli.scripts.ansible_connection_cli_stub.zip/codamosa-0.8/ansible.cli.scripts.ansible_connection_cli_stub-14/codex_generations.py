

# Generated at 2022-06-10 22:30:26.783703
# Unit test for method connect_timeout of class ConnectionProcess
def test_ConnectionProcess_connect_timeout():
    # GIVEN an object of type ConnectionProcess with mocked required attributes or methods
    class ConnectionProcess_Mock():
        # mock the connection object, so we can get a proper connection attribute
        def __init__(self):
            self.connection = ConnectionProcess_Mock()
        def get_option(self, option):
            return 10
        # mock the method to handle requests from the server
        def handle_request(self, req):
            pass
        # mock the method to close the persistent connection
        def close(self, req):
            pass
        # mock the method to get messages of the persistent connection
        def pop_messages(self, req):
            pass
    # MOCK the display.display to make sure that we get something if the exception occurs
    class Display_Mock():
        def __init__(self):
            pass

# Generated at 2022-06-10 22:30:29.632629
# Unit test for function file_lock
def test_file_lock():
    with file_lock('/tmp/lock_test') as f:
        pass
    os.unlink('/tmp/lock_test')



# Generated at 2022-06-10 22:30:39.225247
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    # Pass in a file discriptor, play_context, socket_path, original_path, task_uuid and ansible_playbook_pid.
    #
    # This will test if the method run of class ConnectionProcess can run successfully when all the parameters are valid, in which case a
    # conn_closed attribute of class ConnectionProcess will return False
    ctx = PlayContext()
    ctx._set_task_and_variable_override('', False, False, '', '', '', '')
    fd, fname = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.close()
    cp1 = ConnectionProcess(f, ctx, fname, '.', None, None)
    ctx1 = cp1.play_context
    ctx1._set_task_and_

# Generated at 2022-06-10 22:30:47.067987
# Unit test for function read_stream
def test_read_stream():
    test_data = b"hi"
    test_data_len = len(test_data)
    test_data_hash = hashlib.sha1(test_data).hexdigest()
    test_stream = "%s\n%s\n%s\n" % (test_data_len, test_data, test_data_hash)

    sio = StringIO(test_stream)
    data = read_stream(sio)
    assert data == test_data



# Generated at 2022-06-10 22:30:51.132305
# Unit test for function file_lock
def test_file_lock():
    import shutil
    tmpdir = tempfile.mkdtemp(dir='/tmp')
    lock_path = os.path.join(tmpdir, 'lock')
    with file_lock(lock_path):
        pass
    shutil.rmtree(tmpdir)



# Generated at 2022-06-10 22:30:59.269599
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    # Build mocks
    class Base:
        def __init__(self):
            self.a_val = 0
            self.b_val = 0
            self.c_val = 0
            self.d_val = 0
            self.e_val = 0
            self.data = None
            self.signum = 0
            self.frame = 0
            self.exception = 0

        def recv_data(self, s):
            return self.b_val

        def json_loads(self, data):
            return self.c_val

        def handle_request(self, data):
            return self.d_val

        def send_data(self, s, data):
            self.e_val = data

        def shutdown(self):
            return self.a_val


# Generated at 2022-06-10 22:31:10.308339
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    # Get the current directory to place the socket file
    socket_dir = os.getcwd()
    connection_process = ConnectionProcess(sys.stdout, PlayContext(), 'localconnection', socket_dir)
    connection_process.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    connection_process.sock.bind(connection_process.socket_path)
    connection_process.connection = connection_loader.get("local", None, connection_process.socket_path, task_uuid='test_ConnectionProcess_shutdown', ansible_playbook_pid=1)
    connection_process.shutdown()
    assert not os.path.exists(connection_process.socket_path)

# Generated at 2022-06-10 22:31:10.973372
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    pass

# Generated at 2022-06-10 22:31:16.305459
# Unit test for function main
def test_main():
    rc = 0
    result = {}
    messages = [('vvvv', 'control socket path is /tmp/ansible-ssh-127.0.0.1-22-vagrant.lock')]
    socket_path = '/tmp/ansible-ssh-127.0.0.1-22-vagrant.lock'
    result.update({
        'messages': messages,
        'socket_path': socket_path
    })
    if 'exception' in result:
        rc = 1
        sys.stderr.write(json.dumps(result, cls=AnsibleJSONEncoder))
    else:
        rc = 0
        sys.stdout.write(json.dumps(result, cls=AnsibleJSONEncoder))
    return rc

if __name__ == '__main__':
    main

# Generated at 2022-06-10 22:31:17.985484
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        sys.stderr.write("ERROR: %s\n" % str(e))
        sys.exit(1)

# Generated at 2022-06-10 22:31:41.421854
# Unit test for function file_lock
def test_file_lock():
    import tempfile
    fd, lock_path = tempfile.mkstemp()
    with file_lock(lock_path):
        assert True
    os.close(fd)
    os.unlink(lock_path)



# Generated at 2022-06-10 22:31:55.040118
# Unit test for function main
def test_main():

    with mock.patch.object(sys, 'argv') as mock_argv:
        with mock.patch.object(cPickle, 'loads') as mock_loads:
            mock_argv.return_value = ['ansible_connection','123','123','123']
            mock_loads.return_value = {"play_context": "play_context"}

            for stream in (sys.stdin, sys.stdout, sys.stderr):
                stream.encoding = 'utf-8'


# Generated at 2022-06-10 22:31:59.566155
# Unit test for method connect_timeout of class ConnectionProcess
def test_ConnectionProcess_connect_timeout():
    fd = StringIO()
    pc = PlayContext()
    cp = ConnectionProcess(fd, pc, 'test_socket_file', 'test_original_path', 'test_uuid')
    exc = Exception()
    cp.connect_timeout(None, None)
    return cp.connect_timeout

# Generated at 2022-06-10 22:32:02.543906
# Unit test for method handler of class ConnectionProcess
def test_ConnectionProcess_handler():
    fork_process()
    # cp = ConnectionProcess(fork_process(), PlayContext(), 'socket_path', 'original_path')
    # TODO(pavlosek): add test


# Generated at 2022-06-10 22:32:10.381966
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    #Test for method shutdown(self)
    # Tests for class ConnectionProcess
    # The connection process wraps around a Connection object that manages
    # the connection to a remote device that persists over the playbook
    #self._testMethodDoc = "ConnectionProcess: The connection process wraps around a Connection object that manages\n        the connection to a remote device that persists over the playbook"
    #self._testMethodDoc = "ConnectionProcess: the connection to a remote device that persists over the playbook"
    cp = ConnectionProcess(None, None, None, None, None, None)
    # self.connection = connection_loader.get(self.play_context.connection, self.play_context, '/dev/null', task_uuid=self._task_uuid, ansible_playbook_pid=self._ansible_playbook_pid)
    # self.srv.register(self

# Generated at 2022-06-10 22:32:15.666971
# Unit test for function main
def test_main():
  import json
  import sys
  import re
  # We have a mock file to write the stdout.
  # This file has the test stdout data.
  # This function needs to read the data
  # and set it to the sys.stdout. We will
  # read the data and set it to sys.stdout.
  f = open("mock_stdout","r")
  data = f.read()
  f.close()
  sys.stdout = StringIO()
  # We need to set sys.argv[1] and sys.argv[2]
  # to call the main function.
  sys.argv = [None, '100', '100']
  # The main function will set return code 'rc'.
  main()
  # We need to convert the stdout to text
  # to compare.
 

# Generated at 2022-06-10 22:32:23.172077
# Unit test for function main
def test_main():
    """
    [Unit test of main]
    :return:
    """
    if PY3:
        stdin = sys.stdin.buffer
    else:
        stdin = sys.stdin

    # Note: update the below log capture code after Display.display() is refactored.
    saved_stdout = sys.stdout
    sys.stdout = StringIO()


# Generated at 2022-06-10 22:32:24.503234
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    pass


# Generated at 2022-06-10 22:32:33.451827
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    import unittest
    import mock
    import os

    # create instance of ConnectionProcess
    class args:
        def __init__(self):
            self.play_context = mock.MagicMock()
            self.socket_path = '/tmp/foo'
            self.original_path = '/tmp'
            self.task_uuid = None
            self.ansible_playbook_pid = None
    instance = ConnectionProcess(args, None, None)

    old_sock = instance.sock
    old_connection = instance.connection
    old_socket_path = instance.socket_path
    old_lock_path = unfrackpath("%s/.ansible_pc_lock_%s" % os.path.split(instance.socket_path))

    instance.sock = mock.MagicMock()

# Generated at 2022-06-10 22:32:42.660362
# Unit test for method handler of class ConnectionProcess
def test_ConnectionProcess_handler():
    # initialize process object
    process = ConnectionProcess(fd=None, play_context=None, socket_path=None, original_path=None)
    # initialize signal handler
    signal.signal(signal.SIGALRM, process.command_timeout)
    # set socket timeout
    signal.alarm(process.connection.get_option('persistent_command_timeout'))
    # test command_timeout method
    process.command_timeout(signum=signal.SIGALRM, frame=None)
    # close process with exception
    process.close()



# Generated at 2022-06-10 22:33:41.688130
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    mod_args = dict()
    mod_args['remote_addr'] = "/tmp/ansible-connection-zJEZOu"
    mod_args['port'] = None
    mod_args['remote_user'] = "root"
    mod_args['password'] = ""
    mod_args['private_key_file'] = "/home/vagrant/.ssh/id_rsa"
    mod_args['connection'] = "network_cli"
    mod_args['timeout'] = 10
    mod_args['network_os'] = "ios"
    mod_args['timeout'] = 10
    mod_args['persistent_command_timeout'] = 60
    mod_args['persistent_connect_timeout'] = 30
    mod_args['become'] = False
    mod_args['become_method'] = "enable"
   

# Generated at 2022-06-10 22:33:47.997331
# Unit test for method handler of class ConnectionProcess
def test_ConnectionProcess_handler():
    """
    This unit test checks the correctness of method handler of the class ConnectionProcess.
    The handler method is triggered when a signal is received by the process.
    The handler method should throw an exception with the message that it received the signal.
    :return:
    """

    # Create a ConnectionProcess object
    instance = ConnectionProcess(None, None, None, None, None, None)

    # Capture the output of the handler method
    try:
        instance.handler(None, None)
    except Exception as e:
        assert str(e) == 'signal handler called with signal None.'

# Generated at 2022-06-10 22:33:59.952494
# Unit test for method handler of class ConnectionProcess
def test_ConnectionProcess_handler():
    def mock_get_option(self, option):
        return 30
    with patch.object(Display, 'display') as mock_display, \
            patch.object(time, 'sleep') as mock_sleep, \
            patch.object(socket.socket, 'close') as mock_close, \
            patch.object(os, 'remove') as mock_remove, \
            patch.object(Connection, 'close') as mock_conn_close, \
            patch.object(Connection, 'get_option', side_effect=mock_get_option) as mock_get_option:
        fd, fd_path = tempfile.mkstemp()
        play_context = PlayContext()
        socket_path = "/tmp/test_socket_path"
        task_uuid = "test_task_uuid"
        obj = ConnectionProcess

# Generated at 2022-06-10 22:34:08.362215
# Unit test for method connect_timeout of class ConnectionProcess
def test_ConnectionProcess_connect_timeout():
    play_context = PlayContext()
    socket_path = '/data/workspace/ansible/data/connections/ansible_connection_999ca7b46060e3bb1.sock'
    original_path = '/data/workspace/ansible'

    connectionProcess = ConnectionProcess('test_fd', play_context, socket_path, original_path)
    assert connectionProcess.start('test_variables')

    connectionProcess.run()

    connectionProcess.connect_timeout('test_signal', 'test_frame')

    connectionProcess.handler('test_signal', 'test_frame')

    connectionProcess.shutdown()


# Generated at 2022-06-10 22:34:08.963018
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    pass

# Generated at 2022-06-10 22:34:10.929235
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    a = ConnectionProcess(sys.stdout, "string", "string", "string")
    a.run()



# Generated at 2022-06-10 22:34:21.978170
# Unit test for function main
def test_main():
    # expected socket path based on the current machine and date
    base_path = '/root/.ansible/pc/d41d8cd98f/root@10.0.0.1_22'
    # list of attributes connection class needs.  Some are not part of connection instantiation, so we have to check for those
    attributes = ['_socket_path', '_task_uuid', '_connected']
    # place holders for default values that will be set by main
    play_context = PlayContext()
    variables = {}
    task_uuid = None
    init_data = None
    play_context.remote_user = 'root'
    play_context.remote_addr = '10.0.0.1'
    play_context.port = 22

    # start the process to create a connection
    pid = fork_process()

    #

# Generated at 2022-06-10 22:34:30.139022
# Unit test for function main
def test_main():
    sys.argv = ['', '1', 'test_task_uuid']
    try:
        main()
        assert False
    except Exception as e:
        sys.argv = ['', '1', 'test_task_uuid']
        main()
        assert True
    finally:
        display.verbosity = 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-10 22:34:36.817142
# Unit test for function file_lock
def test_file_lock():
    lock_path = "/tmp/test_file_lock"
    lock_fd = os.open(lock_path, os.O_RDWR | os.O_CREAT, 0o600)
    with file_lock(lock_path):
        assert fcntl.lockf(lock_fd, fcntl.LOCK_EX|fcntl.LOCK_NB) == -1, "File should be locked"
    assert fcntl.lockf(lock_fd, fcntl.LOCK_EX|fcntl.LOCK_NB) != -1, "File should not be locked"
    os.close(lock_fd)
    os.remove(lock_path)


# Generated at 2022-06-10 22:34:38.392474
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    cnx_proc = ConnectionProcess(None, None, None, None)
    cnx_proc.shutdown()



# Generated at 2022-06-10 22:35:05.271845
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    # create Persistent connection object for unit testing
    play_context = PlayContext()
    variables = dict()
    socket_path = "../test_files/test_socket"
    original_path = "../test_files/"
    task_uuid = "test"
    ansible_playbook_pid = "test"

    # create and start the process
    (rfile, wfile) = os.pipe()
    p = ConnectionProcess(wfile, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)
    p.start(variables)
    while True:
        if os.path.exists(socket_path):
            connection = Connection(play_context, '/dev/null', task_uuid, ansible_playbook_pid)
            connection._socket_path = socket_

# Generated at 2022-06-10 22:35:08.162377
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    # import ansible_persistent_connection.connection_plugins.network_cli
    main()

# Generated at 2022-06-10 22:35:18.696268
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    # Inits
    task_uuid = 'a1d42c4a-2c96-4fe4-b4c8-acbce4015509'
    ansible_playbook_pid = 123456
    connection_type = 'network_cli'
    # Sets
    play_context = PlayContext()
    connection = connection_loader.get(connection_type, play_context=play_context)
    connection_process = ConnectionProcess(1, play_context, 2, 3)
    connection_process.connection = connection
    # Sets
    connection_process.shutdown()
    # Checks
    assert connection_process.connection._socket_path is None
    assert connection_process.connection._connected is False


# Generated at 2022-06-10 22:35:20.143263
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-10 22:35:30.534402
# Unit test for function main
def test_main():
    # Make run_main happy, we don't need those
    def shutdown(self):
        pass

    def conn(self):
        return True

    ConnectionProcess.shutdown = shutdown
    ConnectionProcess.run = conn
    # Note: if you change the test case, don't forget to update test_main() too!
    data = dict(
        path='/home/alex/.ansible/test/ansible_test_ssh_persistent_connections',
        port=22,
        connection='smart',
        remote_user='alex',
        remote_addr='127.0.0.1'
    )
    play_context = PlayContext()
    play_context.port = data['port']
    play_context.connection = data['connection']
    play_context.remote_user = data['remote_user']
    play_

# Generated at 2022-06-10 22:35:37.447523
# Unit test for function read_stream
def test_read_stream():
    test_string = b"abc"
    input_stream = StringIO(str(len(test_string)).encode('utf-8') + b'\n' + test_string + b'\n' +
                            hashlib.sha1(test_string).hexdigest().encode('utf-8') + b'\n')
    data = read_stream(input_stream)
    assert data == test_string

    # Test too much data
    input_stream = StringIO(str(len(test_string)).encode('utf-8') + b'\n' + test_string + b'1\n' +
                            hashlib.sha1(test_string + b'1').hexdigest().encode('utf-8') + b'\n')

# Generated at 2022-06-10 22:35:42.395910
# Unit test for function main
def test_main():
    try:
        os.remove('/tmp/ansible_test')
    except OSError:
        pass
    sys.argv = ['ssh-connection', 'pid', 'task_uuid']
    main()



# Generated at 2022-06-10 22:35:56.128239
# Unit test for method command_timeout of class ConnectionProcess
def test_ConnectionProcess_command_timeout():
    display = Display()
    display.verbosity = 4
    display.deprecate = mock.Mock()
    mock_signum = mock.Mock()
    mock_frame = mock.Mock()
    cp = ConnectionProcess(None, None, None, None, None, None)
    with mock.patch.object(display, 'display') as mock_display:
        cp.command_timeout(mock_signum, mock_frame)
    assert mock_display.called
    assert mock_display.call_args[0][0] == 'command timeout triggered, timeout value is %s secs.\nSee the timeout setting options in the Network Debug and Troubleshooting Guide.' % cp.connection.get_option('persistent_command_timeout')


# Generated at 2022-06-10 22:36:08.529294
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    import pickle
    import os
    import signal
    import socket
    import time
    import traceback
    import unittest
    from nose.plugins.skip import SkipTest

    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import cPickle, StringIO
    from ansible.module_utils.connection import Connection, ConnectionError, send_data, recv_data
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.service import fork_process
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import connection_loader
    from ansible.utils.path import unfrackpath, makedirs_safe, get_dist_path, get_role_path

# Generated at 2022-06-10 22:36:18.817374
# Unit test for function file_lock
def test_file_lock():

    # Create test file
    lock_path = os.path.join(C.DEFAULT_LOCAL_TMP, "test_file_lock.lock")
    with open(lock_path, 'w') as f:
        f.write("test lock file")

    # Lock file, write, unlock
    with file_lock(lock_path) as lock:
        try:
            with open(lock_path, 'r+') as f:
                f.write("test lock file")
            raise Exception("Expected IOError when file is locked")
        except IOError:
            pass
        with open(lock_path, 'r') as f:
            assert "test lock file" in f.read()

    # Delete file
    os.unlink(lock_path)
# Reads the arguments out of a pickle stream
# This format is

# Generated at 2022-06-10 22:37:45.959348
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    """
    ConnectionProcess shutdown complete
    """
    pass

    # -- END -- << test_ConnectionProcess_shutdown >>



# Generated at 2022-06-10 22:37:51.251440
# Unit test for method handler of class ConnectionProcess
def test_ConnectionProcess_handler():
    conn_proc = ConnectionProcess(fd=None, play_context=None, socket_path=None, original_path=None, task_uuid=None, ansible_playbook_pid=None)
    for x in range(0, 10):
        conn_proc.handler(signum=x,frame=None)

# Generated at 2022-06-10 22:38:04.050659
# Unit test for method command_timeout of class ConnectionProcess
def test_ConnectionProcess_command_timeout():
    C.ANSIBLE_SSH_CONTROL_PATH = '/tmp/ansible-ssh-%%h-%%p-%%r'
    display = Display()
    p, fd = os.pipe()
    c_pid = fork_process()
    try:
        if c_pid == 0:
            os.close(p)
            f = os.fdopen(fd, "wb", 0)
            socket_path = '/tmp/ansible-conn-test.socket'
            play_context = PlayContext(connection='local', remote_addr=None)
            cp = ConnectionProcess(f, play_context, socket_path, '/tmp')
            cp.command_timeout('test', 'test')
    except Exception:
        os.waitpid(c_pid, 0)

# Generated at 2022-06-10 22:38:13.047838
# Unit test for function file_lock
def test_file_lock():
    lock_path = '/tmp/test_file_lock'
    child_pid = os.fork()
    if child_pid == 0:
        # child process
        time.sleep(1)
        with file_lock(lock_path):
            raise Exception('Child should not enter this context')
    else:
        # parent process
        with file_lock(lock_path):
            os.kill(child_pid, signal.SIGTERM)
        os.waitpid(child_pid, 0)



# Generated at 2022-06-10 22:38:24.915933
# Unit test for function read_stream
def test_read_stream():
    from io import BytesIO
    from tempfile import TemporaryFile
    with TemporaryFile(mode='w+b') as tf:
        tf.write(b'123\n{"a": "b"}\nbc5965db7aec468b4a6b8f29b54f3889caae6ddf\n')
        tf.seek(0)

        assert read_stream(tf) == b'{"a": "b"}'

# Generated at 2022-06-10 22:38:34.645376
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    """
    Call function to close connection
    """

    # Create a named pipe to receive data from child process
    from os import pipe, O_NONBLOCK, O_CLOEXEC, O_RDONLY
    read_fd, write_fd = pipe()

    # Create a child process and get pid
    child_pid = os.fork()

    if child_pid == 0:
        # Child Process
        play_context = PlayContext()
        socket_path = '/tmp/test_socket'
        original_path = '/tmp'
        test_connection = ConnectionProcess(
            write_fd,
            play_context,
            socket_path,
            original_path,
            task_uuid=None,
            ansible_playbook_pid=None
        )
        test_connection.start(variables=None)

       

# Generated at 2022-06-10 22:38:43.595588
# Unit test for function file_lock
def test_file_lock():
    from contextlib import contextmanager

    @contextmanager
    def test_context_manager(lock_path):
        yield

    lock_path_test = '/etc/ansible/test_lock'
    if os.path.exists(lock_path_test):
        os.unlink(lock_path_test)

    with file_lock(lock_path_test):
        with file_lock(lock_path_test):
            assert True

    # Test using test_context_manager (i.e. not locking)
    with test_context_manager(lock_path_test):
        assert True
    os.unlink(lock_path_test)



# Generated at 2022-06-10 22:38:50.185773
# Unit test for function read_stream
def test_read_stream():
    from tempfile import TemporaryFile
    data = b"This is a test"
    data_hash = hashlib.sha1(data).hexdigest()
    fp = TemporaryFile()
    fp.write(b'%s\n%s\n' % (len(data), data_hash))
    fp.write(data)
    fp.seek(0)

    data = read_stream(fp)
    assert data == b"This is a test"


# Generated at 2022-06-10 22:38:52.918640
# Unit test for function file_lock
def test_file_lock():
    """
    Test file_lock.
    """
    lock_path = "/tmp/test_file_lock.lock"
    with file_lock(lock_path):
        pass
    pass



# Generated at 2022-06-10 22:39:02.628936
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    self = ConnectionProcess(None, None, None, None, None, None)
    self.connection = MockConnection(None, None, None, None, None)
    self.connection._conn_closed = False
    self.sock = MockSocket(None, None)
    self.sock.accept = Mock()
    self.sock.accept.return_value = (None, None)
    self.srv = Mock()
    self.srv.handle_request = Mock()
    self.srv.handle_request.return_value = None
    with patch('signal.signal', return_value=None) as signal:
        with patch('ansible.module_utils.connection.recv_data', return_value=""):
            self.run()
