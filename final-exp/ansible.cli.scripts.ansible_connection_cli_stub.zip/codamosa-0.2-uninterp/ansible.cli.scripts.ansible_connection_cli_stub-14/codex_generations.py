

# Generated at 2022-06-16 20:12:59.441473
# Unit test for function file_lock
def test_file_lock():
    lock_path = '/tmp/test_file_lock'
    with file_lock(lock_path):
        pass
    assert os.path.exists(lock_path)
    os.remove(lock_path)


# Generated at 2022-06-16 20:13:06.645223
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    fd = StringIO()
    play_context = PlayContext()
    socket_path = '/tmp/ansible_test_socket'
    original_path = '/tmp/ansible_test_original_path'
    task_uuid = 'test_task_uuid'
    ansible_playbook_pid = 'test_ansible_playbook_pid'
    variables = dict()
    connection_process = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)
    connection_process.start(variables)
    assert connection_process.fd == fd
    assert connection_process.exception == None
    assert connection_process.srv == JsonRpcServer()
    assert connection_process.sock == None
    assert connection_process.connection == None


# Generated at 2022-06-16 20:13:12.028341
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    # Create a connection process object
    fd = StringIO()
    play_context = PlayContext()
    socket_path = "/tmp/ansible_test_socket"
    original_path = "/tmp"
    task_uuid = "test_task_uuid"
    ansible_playbook_pid = "test_ansible_playbook_pid"
    connection_process = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)
    # Create a socket file
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.bind(socket_path)
    sock.listen(1)
    # Create a lock file

# Generated at 2022-06-16 20:13:19.203587
# Unit test for method run of class ConnectionProcess

# Generated at 2022-06-16 20:13:25.677063
# Unit test for function read_stream
def test_read_stream():
    test_data = '{"test": "data"}'
    test_hash = hashlib.sha1(test_data).hexdigest()
    test_stream = StringIO()
    test_stream.write(str(len(test_data)))
    test_stream.write('\n')
    test_stream.write(test_data)
    test_stream.write('\n')
    test_stream.write(test_hash)
    test_stream.write('\n')
    test_stream.seek(0)
    assert read_stream(test_stream) == test_data


# Generated at 2022-06-16 20:13:35.109419
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    fd = StringIO()
    play_context = PlayContext()
    socket_path = '/tmp/ansible_test_socket'
    original_path = '/tmp'
    task_uuid = 'test_task_uuid'
    ansible_playbook_pid = 'test_ansible_playbook_pid'
    variables = dict()
    variables['ansible_network_os'] = 'test_os'
    variables['ansible_connection'] = 'network_cli'
    variables['ansible_user'] = 'test_user'
    variables['ansible_ssh_pass'] = 'test_ssh_pass'
    variables['ansible_become_pass'] = 'test_become_pass'
    variables['ansible_become'] = 'test_become'
    variables['ansible_become_method']

# Generated at 2022-06-16 20:13:40.996613
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    fd = StringIO()
    play_context = PlayContext()
    socket_path = '/tmp/ansible-test-socket'
    original_path = '/tmp'
    task_uuid = 'test-task-uuid'
    ansible_playbook_pid = 'test-ansible-playbook-pid'
    cp = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)
    variables = {}
    cp.start(variables)


# Generated at 2022-06-16 20:13:52.715757
# Unit test for function main

# Generated at 2022-06-16 20:14:01.737413
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    fd = StringIO()
    play_context = PlayContext()
    socket_path = 'test_socket_path'
    original_path = 'test_original_path'
    task_uuid = 'test_task_uuid'
    ansible_playbook_pid = 'test_ansible_playbook_pid'
    variables = 'test_variables'
    connection_process = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)
    connection_process.start(variables)
    connection_process.run()
    connection_process.shutdown()

# Generated at 2022-06-16 20:14:12.136688
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    # Create a mock object for the class ConnectionProcess
    class MockConnectionProcess(object):
        def __init__(self, fd, play_context, socket_path, original_path, task_uuid=None, ansible_playbook_pid=None):
            self.play_context = play_context
            self.socket_path = socket_path
            self.original_path = original_path
            self._task_uuid = task_uuid

            self.fd = fd
            self.exception = None

            self.srv = JsonRpcServer()
            self.sock = None

            self.connection = None
            self._ansible_playbook_pid = ansible_playbook_pid


# Generated at 2022-06-16 20:14:44.269583
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    # Create a connection process object
    fd = StringIO()
    play_context = PlayContext()
    socket_path = '/tmp/ansible_test_socket'
    original_path = '/tmp/ansible_test_original_path'
    task_uuid = 'test_task_uuid'
    ansible_playbook_pid = 'test_ansible_playbook_pid'
    connection_process = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)

    # Create a connection object
    connection = Connection()
    connection._socket_path = socket_path
    connection._connected = True
    connection._conn_closed = False
    connection._play_context = play_context
    connection._task_uuid = task_uuid
    connection._ans

# Generated at 2022-06-16 20:14:52.732146
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    # Create a mock socket
    class MockSocket(object):
        def __init__(self):
            self.closed = False

        def close(self):
            self.closed = True

    # Create a mock connection
    class MockConnection(object):
        def __init__(self):
            self.closed = False
            self.messages = []

        def close(self):
            self.closed = True

        def pop_messages(self):
            return self.messages

        def get_option(self, option):
            return True

    # Create a mock file
    class MockFile(object):
        def __init__(self):
            self.closed = False

        def close(self):
            self.closed = True

    # Create a mock os

# Generated at 2022-06-16 20:15:04.227103
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    # Create a mock object for the connection
    class MockConnection(object):
        def __init__(self):
            self._conn_closed = False
            self._connected = False
            self._socket_path = None
            self.messages = []

        def set_options(self, var_options=None):
            pass

        def get_option(self, key):
            return 0

        def close(self):
            self._conn_closed = True

        def connected(self):
            return self._connected

        def connect(self):
            self._connected = True

        def pop_messages(self):
            return self.messages

    # Create a mock object for the socket
    class MockSocket(object):
        def __init__(self):
            self.sock = None
            self.addr = None


# Generated at 2022-06-16 20:15:05.562118
# Unit test for function file_lock
def test_file_lock():
    with file_lock('/tmp/test_file_lock'):
        pass


# Generated at 2022-06-16 20:15:07.841921
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    # Create a connection process object
    connection_process = ConnectionProcess(None, None, None, None)
    # Call the shutdown method
    connection_process.shutdown()



# Generated at 2022-06-16 20:15:13.184633
# Unit test for function read_stream
def test_read_stream():
    data = b'{"foo": "bar"}'
    data_hash = hashlib.sha1(data).hexdigest()
    data_size = len(data)
    data_size_str = to_bytes(str(data_size))
    data_hash_str = to_bytes(data_hash)
    data_stream = b'\n'.join([data_size_str, data, data_hash_str])
    data_stream_io = StringIO(data_stream)
    assert read_stream(data_stream_io) == data

# Generated at 2022-06-16 20:15:14.134054
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    pass


# Generated at 2022-06-16 20:15:15.456888
# Unit test for function file_lock
def test_file_lock():
    with file_lock('/tmp/test_file_lock'):
        pass


# Generated at 2022-06-16 20:15:22.835685
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    # Create a ConnectionProcess object
    fd = StringIO()
    play_context = PlayContext()
    socket_path = '/tmp/ansible_test_socket'
    original_path = '/tmp'
    task_uuid = 'test_task_uuid'
    ansible_playbook_pid = 'test_ansible_playbook_pid'
    connection_process = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)
    # Call method run of ConnectionProcess object
    connection_process.run()
    # Check if the method run of ConnectionProcess object is working as expected
    assert True == True


# Generated at 2022-06-16 20:15:28.540880
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    fd = StringIO()
    play_context = PlayContext()
    socket_path = '/tmp/ansible_test_socket'
    original_path = '/tmp'
    task_uuid = 'test_task_uuid'
    ansible_playbook_pid = 'test_ansible_playbook_pid'
    connection_process = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)
    connection_process.run()


# Generated at 2022-06-16 20:15:53.284756
# Unit test for function file_lock
def test_file_lock():
    with file_lock('/tmp/test_file_lock'):
        pass



# Generated at 2022-06-16 20:16:02.385097
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    # create a ConnectionProcess object
    fd = StringIO()
    play_context = PlayContext()
    socket_path = '/tmp/ansible_test_socket'
    original_path = '/tmp'
    task_uuid = 'test_task_uuid'
    ansible_playbook_pid = 'test_ansible_playbook_pid'
    connection_process = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)
    # test start method
    variables = {}
    connection_process.start(variables)
    # test start method with exception
    variables = {}
    connection_process.play_context.connection = 'network_cli'
    connection_process.start(variables)


# Generated at 2022-06-16 20:16:11.515266
# Unit test for function main
def test_main():
    """
    Unit test for function main
    """
    # Test case 1
    # Test case with invalid json data
    sys.argv = ['ansible_connection', '123', '123']
    sys.stdin = StringIO('{"test": "test"}')
    main()

# Generated at 2022-06-16 20:16:21.321365
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    # Create a connection process object
    play_context = PlayContext()
    socket_path = '/tmp/ansible-test-socket'
    original_path = '/tmp'
    task_uuid = 'test_task_uuid'
    ansible_playbook_pid = 'test_ansible_playbook_pid'
    fd = StringIO()
    connection_process = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)

    # Create a connection object
    connection = Connection(play_context, '/dev/null', task_uuid, ansible_playbook_pid)
    connection_process.connection = connection

    # Create a socket object
    class MockSocket:
        def __init__(self):
            self.sock = None

# Generated at 2022-06-16 20:16:26.099379
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    # Create a ConnectionProcess object
    fd = StringIO()
    play_context = PlayContext()
    socket_path = '/tmp/ansible_test_socket'
    original_path = '/tmp'
    task_uuid = '1234567890'
    ansible_playbook_pid = '12345'
    connection_process = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)

    # Test the run method
    connection_process.run()



# Generated at 2022-06-16 20:16:31.090308
# Unit test for function read_stream
def test_read_stream():
    test_data = b'{"test": "data"}'
    test_data_hash = hashlib.sha1(test_data).hexdigest()
    test_stream = StringIO(b'%d\n%s\n%s\n' % (len(test_data), test_data, test_data_hash))
    assert read_stream(test_stream) == test_data


# Generated at 2022-06-16 20:16:36.190471
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    fd = StringIO()
    play_context = PlayContext()
    socket_path = '/tmp/test_socket'
    original_path = '/tmp'
    task_uuid = 'test_uuid'
    ansible_playbook_pid = 'test_pid'
    cp = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)
    cp.sock = StringIO()
    cp.connection = Connection()
    cp.shutdown()
    assert not os.path.exists(socket_path)
    assert not os.path.exists(unfrackpath("%s/.ansible_pc_lock_%s" % os.path.split(socket_path)))
    assert cp.connection._socket_path is None
    assert cp.connection._

# Generated at 2022-06-16 20:16:43.308491
# Unit test for function main
def test_main():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import cPickle
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import zip
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import connection_loader
    from ansible.utils.display import Display
    from ansible.utils.jsonrpc import JsonRpcServer

    # Unit test for function main
    def test_main():
        from ansible.module_utils.six import StringIO
        from ansible.module_utils.six.moves import cPickle

# Generated at 2022-06-16 20:16:45.674302
# Unit test for function main
def test_main():
    # Test with no arguments
    with pytest.raises(SystemExit):
        main()


# Generated at 2022-06-16 20:16:49.451316
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    # Create a ConnectionProcess object
    connection_process = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid=None, ansible_playbook_pid=None)
    # Call method shutdown of class ConnectionProcess
    connection_process.shutdown()



# Generated at 2022-06-16 20:17:37.832776
# Unit test for function main
def test_main():
    # Test with no arguments
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 0

    # Test with arguments
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        main(1, 2)
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 0


# Generated at 2022-06-16 20:17:43.730844
# Unit test for function read_stream
def test_read_stream():
    data = b'{"foo": "bar"}'
    data_hash = hashlib.sha1(data).hexdigest()
    stream = StringIO()
    stream.write(to_bytes(str(len(data)) + '\n'))
    stream.write(data)
    stream.write(to_bytes(data_hash + '\n'))
    stream.seek(0)
    assert read_stream(stream) == data


# Generated at 2022-06-16 20:17:50.938859
# Unit test for function read_stream
def test_read_stream():
    data = b'{"foo": "bar"}'
    data_hash = hashlib.sha1(data).hexdigest()
    data_stream = StringIO()
    data_stream.write(to_bytes(str(len(data))))
    data_stream.write(b'\n')
    data_stream.write(data)
    data_stream.write(b'\n')
    data_stream.write(to_bytes(data_hash))
    data_stream.write(b'\n')
    data_stream.seek(0)
    assert read_stream(data_stream) == data


# Generated at 2022-06-16 20:17:59.731698
# Unit test for method handler of class ConnectionProcess
def test_ConnectionProcess_handler():
    # Create a ConnectionProcess object
    fd = StringIO()
    play_context = PlayContext()
    socket_path = '/tmp/ansible_test_socket'
    original_path = '/tmp'
    task_uuid = 'test_task_uuid'
    ansible_playbook_pid = 'test_ansible_playbook_pid'
    connection_process = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)

    # Call method handler of ConnectionProcess object
    connection_process.handler(signum=1, frame=None)


# Generated at 2022-06-16 20:18:04.238891
# Unit test for method start of class ConnectionProcess
def test_ConnectionProcess_start():
    fd = StringIO()
    play_context = PlayContext()
    socket_path = '/dev/null'
    original_path = '/dev/null'
    task_uuid = None
    ansible_playbook_pid = None
    cp = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)
    variables = {}
    cp.start(variables)


# Generated at 2022-06-16 20:18:15.085227
# Unit test for method command_timeout of class ConnectionProcess

# Generated at 2022-06-16 20:18:23.934069
# Unit test for method shutdown of class ConnectionProcess

# Generated at 2022-06-16 20:18:26.281025
# Unit test for function main
def test_main():
    # Test with no args
    with pytest.raises(SystemExit):
        main()

    # Test with args
    with pytest.raises(SystemExit):
        main(1, 2)


# Generated at 2022-06-16 20:18:36.234423
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    # Create a ConnectionProcess object
    fd = StringIO()
    play_context = PlayContext()
    socket_path = '/tmp/ansible_test_socket'
    original_path = '/tmp'
    task_uuid = 'test_task_uuid'
    ansible_playbook_pid = 'test_ansible_playbook_pid'
    connection_process = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)

    # Create a Connection object
    connection = Connection()
    connection.set_options(var_options={})
    connection._socket_path = socket_path
    connection_process.srv.register(connection)

    # Create a socket object

# Generated at 2022-06-16 20:18:47.190880
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    # Create a mock socket
    class MockSocket(object):
        def __init__(self):
            self.closed = False

        def close(self):
            self.closed = True

    # Create a mock connection
    class MockConnection(object):
        def __init__(self):
            self.closed = False
            self.messages = []

        def close(self):
            self.closed = True

        def pop_messages(self):
            return self.messages

        def get_option(self, option):
            return True

    # Create a mock display
    class MockDisplay(object):
        def __init__(self):
            self.messages = []

        def display(self, message, log_only=False):
            self.messages.append(message)

    # Create a mock os

# Generated at 2022-06-16 20:19:24.022505
# Unit test for method shutdown of class ConnectionProcess
def test_ConnectionProcess_shutdown():
    # Create a connection process object
    connection_process = ConnectionProcess(None, None, None, None)
    # Call the shutdown method
    connection_process.shutdown()



# Generated at 2022-06-16 20:19:33.867020
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    # Create a connection process object
    fd = StringIO()
    play_context = PlayContext()
    socket_path = '/tmp/ansible_test_socket'
    original_path = '/tmp'
    task_uuid = 'test_task_uuid'
    ansible_playbook_pid = 'test_ansible_playbook_pid'
    connection_process = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)

    # Create a connection object
    connection = connection_loader.get(play_context.connection, play_context, '/dev/null',
                                                    task_uuid=task_uuid, ansible_playbook_pid=ansible_playbook_pid)
    connection_process.connection = connection
    connection_process.sr

# Generated at 2022-06-16 20:19:39.943684
# Unit test for method run of class ConnectionProcess

# Generated at 2022-06-16 20:19:46.497559
# Unit test for function read_stream
def test_read_stream():
    data = b'{"foo": "bar"}'
    data_hash = hashlib.sha1(data).hexdigest()
    data_size = len(data)
    data_stream = b'%d\n%s\n%s\n' % (data_size, data, data_hash)
    stream = StringIO(data_stream)
    assert read_stream(stream) == data


# Generated at 2022-06-16 20:19:51.094138
# Unit test for function read_stream
def test_read_stream():
    data = b'{"foo": "bar"}'
    data_hash = hashlib.sha1(data).hexdigest()
    data_size = len(data)
    data_stream = b'%d\n%s\n%s\n' % (data_size, data, data_hash)
    stream = StringIO(data_stream)
    assert read_stream(stream) == data



# Generated at 2022-06-16 20:19:52.987230
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    # Create a ConnectionProcess object
    cp = ConnectionProcess()
    # Test the method run
    cp.run()


# Generated at 2022-06-16 20:20:00.622410
# Unit test for function read_stream
def test_read_stream():
    data = b'{"foo": "bar"}'
    data_hash = hashlib.sha1(data).hexdigest()
    data_size = len(data)
    data_size_str = b'%d' % data_size
    data_size_str_len = len(data_size_str)
    data_size_str_len_str = b'%d' % data_size_str_len
    data_size_str_len_str_len = len(data_size_str_len_str)
    data_size_str_len_str_len_str = b'%d' % data_size_str_len_str_len
    data_size_str_len_str_len_str_len = len(data_size_str_len_str_len_str)
    data_size_

# Generated at 2022-06-16 20:20:12.617831
# Unit test for function main

# Generated at 2022-06-16 20:20:22.886437
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    # Create a connection process object
    fd = StringIO()
    play_context = PlayContext()
    socket_path = '/tmp/ansible_test_socket'
    original_path = '/tmp'
    task_uuid = 'test_task_uuid'
    ansible_playbook_pid = 'test_ansible_playbook_pid'
    connection_process = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)

    # Create a connection object
    connection = Connection()
    connection._socket_path = socket_path
    connection._connected = False
    connection._play_context = play_context
    connection._task_uuid = task_uuid
    connection._ansible_playbook_pid = ansible_playbook_pid
    connection._

# Generated at 2022-06-16 20:20:35.216301
# Unit test for function main

# Generated at 2022-06-16 20:21:20.676767
# Unit test for method connect_timeout of class ConnectionProcess
def test_ConnectionProcess_connect_timeout():
    # Create a ConnectionProcess object
    fd = StringIO()
    play_context = PlayContext()
    socket_path = '/tmp/ansible_test_socket'
    original_path = '/tmp/ansible_test_original_path'
    task_uuid = 'ansible_test_task_uuid'
    ansible_playbook_pid = 'ansible_test_ansible_playbook_pid'
    connection_process = ConnectionProcess(fd, play_context, socket_path, original_path, task_uuid, ansible_playbook_pid)

    # Call method connect_timeout
    connection_process.connect_timeout(signum=None, frame=None)


# Generated at 2022-06-16 20:21:31.618174
# Unit test for method run of class ConnectionProcess

# Generated at 2022-06-16 20:21:41.111850
# Unit test for method run of class ConnectionProcess

# Generated at 2022-06-16 20:21:43.168490
# Unit test for function file_lock
def test_file_lock():
    with file_lock('/tmp/test_file_lock'):
        pass


# Generated at 2022-06-16 20:21:49.642677
# Unit test for function main

# Generated at 2022-06-16 20:22:00.409614
# Unit test for method run of class ConnectionProcess
def test_ConnectionProcess_run():
    # Test with no exception
    fd = StringIO()
    play_context = PlayContext()
    socket_path = "/tmp/ansible_test_socket"
    original_path = "/tmp"
    task_uuid = "test_task_uuid"
    ansible_playbook_pid = "test_ansible_playbook_pid"
    variables = dict()
    variables['ansible_connection'] = 'network_cli'
    variables['ansible_network_os'] = 'eos'
    variables['ansible_user'] = 'vagrant'
    variables['ansible_ssh_pass'] = 'vagrant'
    variables['ansible_become_pass'] = 'vagrant'
    variables['ansible_become'] = True
    variables['ansible_become_method'] = 'enable'
    variables

# Generated at 2022-06-16 20:22:01.651763
# Unit test for function main
def test_main():
    # Test with no arguments
    with pytest.raises(SystemExit):
        main()


# Generated at 2022-06-16 20:22:11.522898
# Unit test for function main
def test_main():
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.network.common.utils import to_list
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigError
    from ansible.module_utils.network.common.parsing import NetworkParseError
    from ansible.module_utils.network.common.parsing import Conditional
    from ansible.module_utils.network.common.parsing import NetworkConfigError
    from ansible.module_utils.network.common.parsing import NetworkParseError
    from ansible.module_utils.network.common.parsing import Conditional

# Generated at 2022-06-16 20:22:17.776180
# Unit test for function read_stream
def test_read_stream():
    data = b'{"foo": "bar"}'
    data_hash = hashlib.sha1(data).hexdigest()
    data_stream = StringIO()
    data_stream.write(b'%d\n' % len(data))
    data_stream.write(data)
    data_stream.write(b'\n')
    data_stream.write(to_bytes(data_hash))
    data_stream.write(b'\n')
    data_stream.seek(0)
    assert read_stream(data_stream) == data


# Generated at 2022-06-16 20:22:29.630724
# Unit test for function main