

# Generated at 2022-06-11 21:05:51.410272
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import fields
    from dataclasses import dataclass, field
    import dataclasses_json

    @dataclass
    class Num:
        num: int = field(default=0)

    @dataclass
    class Item:
        num: Num = field(default_factory=Num)
        numbers: typing.List[Num] = field(default_factory=list)
        numbers_opt: typing.Optional[typing.List[Num]] = dataclasses_json.config.omit

    data = Item()
    data.numbers.append(Num(1))
    data.numbers.append(Num(2))
    data.numbers.append(Num(3))
    data.numbers_opt = [Num(1), Num(2), Num(3)]


# Generated at 2022-06-11 21:05:54.198759
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class A(object):
        a: int
        b: str


# Generated at 2022-06-11 21:05:59.028671
# Unit test for constructor of class _IsoField
def test__IsoField():
    x = datetime.now()
    y = datetime.fromisoformat(_IsoField()._serialize(x, 'attr', 'obj'))
    assert x.year == y.year
    assert x.month == y.month
    assert x.day == y.day



# Generated at 2022-06-11 21:06:06.037251
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Test(SchemaF[Test]):
        val: int = fields.Int()

    t = Test()
    s = t.dumps({"val": 1})
    assert s == '{"val": 1}'

    s = t.dumps([{"val": 1}, {"val": 2}])
    assert s == '[{"val": 1}, {"val": 2}]'


# Generated at 2022-06-11 21:06:16.962384
# Unit test for function schema
def test_schema():
    import pytest
    from dataclasses_json.lettercase import LetterCase

    from typing import Union
    from datetime import date
    from marshmallow import fields
    from marshmallow_enum import EnumField

    from dataclasses import dataclass

    @dataclass(init=True, repr=True, eq=True, unsafe_hash=True, frozen=False)
    class NewType:
        int_field: int

    @dataclass(init=True, repr=True, eq=True, unsafe_hash=True, frozen=False)
    class SomeAncestor(NewType):
        pass

    @dataclass(init=True, repr=True, eq=True, unsafe_hash=True, frozen=False)
    class SomeClass:
        int_field: int


# Generated at 2022-06-11 21:06:21.786564
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    obj = [1, 2]
    assert SchemaF[int].dump(obj) == [1, 2]  # type: ignore

    obj = 1
    assert SchemaF[int].dump(obj) == 1  # type: ignore



# Generated at 2022-06-11 21:06:32.370482
# Unit test for function build_schema
def test_build_schema():
    class TestType(Schema):
        pass
    class Force(metaclass=CachedType):
        def __init__(self, newtons: float):
            self.newtons = newtons
        @classmethod
        def _compute_schema(cls):
            return build_schema(cls, None, True, False)
    class Length(metaclass=CachedType):
        def __init__(self, meters: float):
            self.meters = meters
        @classmethod
        def _compute_schema(cls):
            return build_schema(cls, None, True, False)
    class Area(metaclass=CachedType):
        def __init__(self, square_meters: float):
            self.square_meters = square_meters

# Generated at 2022-06-11 21:06:40.798306
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    assert issubclass(SchemaF['int'], Schema)
    import marshmallow as mm
    @mm.post_load
    def make_num(data):
        return 1
    class NumSchema(SchemaF['int']):
        num = mm.fields.Int()
    data = {'num': 1}
    assert NumSchema().dumps(1, many=False) == '{"num": 1}'
    assert NumSchema().dump(1, many=False) == {'num': 1}
    assert NumSchema().load({'num': 1}, many=False) == 1
    assert NumSchema().loads('{"num": 1}', many=False) == 1
    assert NumSchema().loads('{"num": 1}', many=False) == 1
    assert NumSchema(strict=True).loads

# Generated at 2022-06-11 21:06:50.236193
# Unit test for function build_type
def test_build_type():
    from dataclasses_json.api import Configuration
    from dataclasses_json.api import mm_dump
    import typing
    import marshmallow as mm
    import datetime


    class Example(mm.Schema):
        dt = mm.DateTime()

    class S(mm.Schema):
        dt = mm.DateTime(required=False)


# Generated at 2022-06-11 21:06:58.794512
# Unit test for function schema
def test_schema():
  class Foo:
    def __init__(self, x: int, y: str):
      self.x = x
      self.y = y
  class Bar:
    def __init__(self, x: typing.List[Foo]):
      self.x = x
  class Baz:
    def __init__(self, x, y):
      self.x = x
      self.y = y
  assert schema(Foo, None, False) == {'x': fields.Int(missing=MISSING), 'y': fields.Str(missing=MISSING)}
  assert schema(Bar, None, False) == {'x': fields.List(fields.Nested(schema(Foo, None, False), missing=MISSING, allow_none=False), missing=MISSING)}

# Generated at 2022-06-11 21:07:13.850523
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class _SchemaF(SchemaF):
        class Meta:
            pass
    data = [{'a': 1}]
    res = _SchemaF.load(data, many=True)
    assert isinstance(res, list)
    assert hasattr(res[0], 'a')


# Generated at 2022-06-11 21:07:20.618570
# Unit test for constructor of class _IsoField
def test__IsoField():
    f = _IsoField()
    assert f._serialize(datetime(1, 1, 1, 0, 0, 0, 0)) == '0001-01-01T00:00:00'
    assert f._deserialize('0001-01-01T00:00:00') == datetime(1, 1, 1, 0, 0, 0, 0)


# Generated at 2022-06-11 21:07:31.344548
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from typing import List, Optional

    @dataclass_json
    @dataclass
    class Nested:
        d: str
        e: Optional[str]

    @dataclass_json
    @dataclass
    class TestDataClass:
        a: str
        b: Optional[str]
        c: List[str]
        f: Nested

    class SomeEnum(Enum):
        E1 = 1
        E2 = 2

    @dataclass_json
    @dataclass
    class TestDataClass_outer:
        a: str
        b: Optional[str]
        c: List[str]
        d: Optional[SomeEnum]

# Generated at 2022-06-11 21:07:42.408562
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class ExampleSchema(SchemaF):
        name = fields.Str()
        age = fields.Int()

    class ExampleClass:
        def __init__(self, name, age):
            self.name = name
            self.age = age

        def __repr__(self):
            return "ExampleClass(%r, %r)" % self.name, self.age

    assert ExampleSchema().dump([ExampleClass("John", 20), ExampleClass("Doe", 30)]), \
        [{"name": "John", "age": 20}, {"name": "Doe", "age": 30}]


# Generated at 2022-06-11 21:07:49.409286
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class A:
        a: str
        b: int
        c: float

    DataClassSchema = build_schema(A, Schema, False, False)
    assert DataClassSchema.Meta.fields == ('a', 'b', 'c')
    assert isinstance(DataClassSchema.a, fields.Str)
    assert isinstance(DataClassSchema.b, fields.Int)
    assert isinstance(DataClassSchema.c, fields.Float)



# Generated at 2022-06-11 21:07:52.086401
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert isinstance(_TimestampField(), _TimestampField)



# Generated at 2022-06-11 21:08:03.479395
# Unit test for function schema
def test_schema():
    import pytest
    from marshmallow import Schema, fields

    from dataclasses_json import dataclass_json


    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str = 'bbbbb'
        c: str = 'ccccc'
        d: str = 'ddddd'
        e: typing.List[str] = field(default_factory=list)
        f: typing.List[str] = field(default_factory=list)
        g: typing.List[str] = field(default_factory=list)
        h: typing.Optional[str] = None

    class CustomSchema(Schema):
        a = fields.Int()
        b = fields.String()
        c = fields.String()
        d = fields.String

# Generated at 2022-06-11 21:08:16.514435
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass

    @dataclass
    class SampleJSONClass:
        string_field: str
        optional_field: typing.Optional[int]
        any_field: typing.Any
        union_field: typing.Union[str, float]
        tuple_field: typing.Tuple[int, ...]
        list_field: typing.List[str]
        list_union_field: typing.List[typing.Union[str, float]]

    class SampleNoDataclassClass:
        a = 3

    assert build_type(SampleJSONClass, {}, None, None, None)(
        SampleJSONClass, {}) == fields.Nested(SampleJSONClass.schema(),
                                              field_many=False)

# Generated at 2022-06-11 21:08:27.956005
# Unit test for function schema
def test_schema():
    import typing
    @dataclass_json
    @dataclass
    class Student:
        name: str
        age: int

    @dataclass_json
    @dataclass
    class Clazz:
        name: str
        enroll_date: datetime
        students: typing.List[Student]

    @dataclass_json
    @dataclass
    class FailStudent:
        name: str
        age: int

    @dataclass_json
    @dataclass
    class FailClazz:
        name: str
        enroll_date: datetime
        students: typing.List[FailStudent]

    schema = schema(Clazz, DataclassJsonMixin, False)


# Generated at 2022-06-11 21:08:38.250050
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_field = _IsoField(required=True)
    assert iso_field.default_error_messages['required']
    assert iso_field._deserialize("2020-03-05T08:00:00.000+00:00", "attr", None) is not None
    assert iso_field._deserialize("2020-03-05T08:00:00.000000+00:00", "attr", None) is None
    assert iso_field._serialize("2020-03-05T08:00:00.000+00:00", "attr", None) is not None
    assert iso_field._serialize("2020-03-05T08:00:00.000000+00:00", "attr", None) is None


# Generated at 2022-06-11 21:09:14.820251
# Unit test for function build_schema
def test_build_schema():
    def capture_log_messages(func, *args, **kwargs):
        with capture_log() as buffer:
            func(*args, **kwargs)
        return buffer.getvalue()

    @dataclass_json
    class ClassA:
        a: str

    @dataclass_json
    class ClassB:
        b: str

    @dataclass_json
    class DataClass:
        field: typing.Union[ClassA, ClassB]

    DataClassSchema = build_schema(DataClass, type(None), False, False)

    # Test values
    dc_value = DataClass('a')
    encoded = '{"field": {"a": "a", "__type": "ClassA"}}'
    with pytest.raises(ValidationError) as ex:
        DataClassSchema().loads

# Generated at 2022-06-11 21:09:24.255392
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class ClassTest(SchemaF[int]):
        pass
    instance = ClassTest()
    a = instance.loads("{}", many=None)
    assert a == 0
    a = instance.loads("{}", many=True)
    assert a == [0]
    b = instance.loads(b"{}", many=None)
    assert b == 0
    b = instance.loads(b"{}", many=True)
    assert b == [0]

# Generated at 2022-06-11 21:09:26.437752
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # type: () -> None
    data = {'test': 'value1'}
    res = SchemaF[str].dumps(data)
    assert res == '{"test": "value1"}'


# Generated at 2022-06-11 21:09:31.056129
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    f = _TimestampField()
    assert f._serialize(datetime(2019, 1, 1), '', None) == 1546300800.0
    assert f._deserialize(1546300800.0, '', None) == datetime(2019, 1, 1)
    assert f._deserialize(None, '', None) == None



# Generated at 2022-06-11 21:09:35.947453
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    assert 2 == TOneOrMultiEncoded[1]
    assert 3 == TOneOrMulti[1]

    assert 0 == SchemaF


# Generated at 2022-06-11 21:09:41.046818
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    @dataclass
    class DataModel:
        name: str

    DataModelSchema = build_schema(DataModel, object, False, True) #type: ignore
    assert type(DataModelSchema) == type
    
    

# Generated at 2022-06-11 21:09:47.155338
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # Setup
    schema = SchemaF[A]()
    obj = AClass()
    # Verify
    result: TOneOrMultiEncoded = schema.dump(obj)
    # Assert
    assert result == {'a': 'a', 'b': 1, 'c': True}

# Generated at 2022-06-11 21:09:49.820447
# Unit test for function schema
def test_schema():
    assert schema({'name': 'Hello World'}, {'name': 'Hello World'}, True) == {'name': 'Hello World'}


# Generated at 2022-06-11 21:09:53.210706
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # type: () -> None
    def m():
        # type: () -> None
        SchemaF([int], unknown = "EXCLUDE")
    m()

# Generated at 2022-06-11 21:10:02.994975
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses import dataclass
    from typing import List, Optional

    @dataclass
    class Data:
        a: int
        b: Optional[int] = None
        c: List[int] = None

    schema = SchemaF[Data]({
        'a': fields.Int(),
        'b': fields.Int(),
        'c': fields.List(fields.Int())
    })

    _: str = schema.dumps([Data(1, 2, [3, 4]), Data(2)])  # error: not compatible with overloaded function
    _: str = schema.dumps([])  # error: not compatible with overloaded function


# Generated at 2022-06-11 21:11:25.244802
# Unit test for function build_schema
def test_build_schema():
    class Mixin:
        pass

    @dataclass_json
    @dataclass
    class Cls(Mixin):
        a: int = Config.field(default=1)
        b: str = Config.field(metadata={'d': 1})
        c: Optional[str] = Config.field(default=None)
    assert build_schema(Cls, Cls, True, False) == None

# Main function

# Generated at 2022-06-11 21:11:36.250748
# Unit test for function build_type
def test_build_type():
    from typing import Optional, Union
    from marshmallow import fields as mmf
    from marshmallow_enum import EnumField as mmef
    from enum import Enum as ee
    from datetime import datetime as dt
    from dataclasses import dataclass as dc
    from uuid import UUID as uuid

    from dataclasses_json import mm

    from . import TestCase

    class Foo(ee):
        a = 'a'

    @dc
    @mm.schema
    class Baz:
        x: str
        y: int

    @dc
    class Bar:
        y: float

    class Qux(mmf.Field):
        pass

    @dc
    class Example2:
        a: str
        b: int
        c: Optional[float]
        d: dt
        e: u

# Generated at 2022-06-11 21:11:47.106508
# Unit test for function schema
def test_schema():
    import pytest
    from dataclasses_json.mixins import EnumDecoderMixin
    from dataclasses import dataclass, field
    from dataclasses_json import DataClassJsonMixin, config

    @config
    @dataclass
    class A(DataClassJsonMixin):
        x: int
        y: str
        z: bool = field(default=True)
        w: bool = True

    @dataclass
    class Inner(DataClassJsonMixin):
        a: A

    @dataclass
    class Outer(DataClassJsonMixin):
        inner: Inner

    @dataclass
    class Inner1(DataClassJsonMixin):
        a: int

    @dataclass
    class Outer1(DataClassJsonMixin):
        inner: Inner1

   

# Generated at 2022-06-11 21:12:00.751747
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass, field
    from typing import Dict, Optional

    @dataclass
    class AdminUser:
        name: str
        role: str
        permission: Optional[Dict[str, bool]] = field(default_factory=dict)

    class User:
        def __init__(self, name: str, age: int, admin_user: AdminUser):
            self.name = name
            self.age = age
            self.admin_user = admin_user

    UserSchema: SchemaType = build_schema(User)


if sys.version_info >= (3, 7):
    SchemaF.__module__ = 'typing'
    # We can't assign to a variable in a class body
    # so we set it after the fact
    SchemaF.__origin__ = typing

# Generated at 2022-06-11 21:12:01.933478
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    assert 0

# Generated at 2022-06-11 21:12:13.205420
# Unit test for function build_type
def test_build_type():
    class Foo:
        pass

    @dataclass_json
    @dataclass
    class Bar:
        pass

    assert isinstance(build_type(str, {}, Foo, object(), object()), fields.Str)
    assert isinstance(build_type(int, {}, Foo, object(), object()), fields.Int)
    assert isinstance(build_type(float, {}, Foo, object(), object()), fields.Float)
    assert isinstance(build_type(bool, {}, Foo, object(), object()), fields.Bool)
    assert isinstance(build_type(datetime, {}, Foo, object(), object()), _TimestampField)
    assert isinstance(build_type(UUID, {}, Foo, object(), object()), fields.UUID)

# Generated at 2022-06-11 21:12:22.014127
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    assert SchemaF[int].dumps([1,2,3]) == '[1, 2, 3]'
    assert SchemaF[int].dumps(1) == '1'
    assert SchemaF[int].dumps([1,2,3], many=True) == '[1, 2, 3]'
    assert SchemaF[int].dumps(1, many=False) == '1'
    assert SchemaF[int].dumps(1, many=True) == '1'



# Generated at 2022-06-11 21:12:31.157281
# Unit test for function build_schema
def test_build_schema():
    class Expected(Dataclass):
        mm = MM()
        name: str = mm.field(metadata=dict(dataclasses_json=DCJson(mm_field=fields.String())))
        age: int = mm.field()
        is_valid: bool = mm.field(metadata=dict(dataclasses_json=DCJson(mm_field=fields.Boolean())))
        birthday: datetime = mm.field(metadata=dict(dataclasses_json=DCJson(mm_field=_TimestampField())))
        gender: Gender = mm.field(metadata=dict(dataclasses_json=DCJson(mm_field=EnumField(enum=Gender, by_value=True))))
        favourite_number: Union[int, None] = mm.field()

    # Dataclass Schema built from build

# Generated at 2022-06-11 21:12:40.663533
# Unit test for function build_type
def test_build_type():
    class TestUserSchema(Schema):
        name = fields.Str()
        age = fields.Int()


    class TestUser(metaclass=_ExtendedEncoder):
        schema = TestUserSchema
        name: str
        age: int


    class TestSchema(Schema):
        name = fields.Str()
        age = fields.Int()
        user = fields.Nested(TestUser.schema)
        users = fields.Nested(TestUser.schema, many=True)
        dt = fields.DateTime()


    class TestItem(metaclass=_ExtendedEncoder):
        schema = TestSchema
        name: str
        age: int
        user: TestUser
        users: typing.List[TestUser]
        dt: datetime


# Generated at 2022-06-11 21:12:50.272705
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import fields
    from typing import List, Dict

    class MySchema(SchemaF[List]):
        a = fields.List(fields.Int())

    assert MySchema().load([{'a': [1, 2, 3]}]) == [[1, 2, 3]]

    class MySchema2(SchemaF[Dict]):
        # mm has the wrong return type annotation (dict) so we can ignore the mypy error
        # for the return type overlap
        a = fields.Int()

    assert MySchema2().load({'a': 42}) == {'a': 42}


# Generated at 2022-06-11 21:14:51.140302
# Unit test for function build_type
def test_build_type():
    assert build_type(None, None, None, None, None) == fields.Field
    assert build_type(int, None, None, None, None) == fields.Int
    assert build_type(typing.Optional[int], None, None, None, None) == fields.Int


# Generated at 2022-06-11 21:15:02.668719
# Unit test for function schema
def test_schema():
    import unittest
    from dataclasses_json.mm import MM

    @dataclass_json
    @dataclass
    class Nested:
        nested_field: int

    @dataclass_json
    @dataclass
    class TestClass:
        field: int
        float: float = 1.1
        string: str = "str"
        nested: Nested
        enum: TestEnum = TestEnum.D
        opt_enum: TestEnum = None
        opt_nested: Optional[Nested] = None
        union: Union[int, Nested] = 42
        opt_union: Optional[Union[int, Nested]] = 42

    class TestEnum(Enum):
        A = 1
        B = "2"
        C = 3.1
        D = 1.1

   

# Generated at 2022-06-11 21:15:15.007281
# Unit test for function build_type
def test_build_type():
    class A:
        pass

    class B(A):
        pass

    class C(A):
        pass

    @dataclass_json
    @dataclass
    class NewTypeA(TypedDict):
        a: str

    @dataclass_json
    @dataclass
    class NewTypeB(TypedDict):
        b: str

    @dataclass_json
    @dataclass
    class TestClass(TypedDict):
        a_is_a: A
        a_is_b: A
        a_is_c: A
        b_is_a: B
        b_is_b: B
        b_is_c: B
        c_is_a: C
        c_is_b: C
        c_is_c: C