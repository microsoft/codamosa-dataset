

# Generated at 2022-06-11 21:05:32.939549
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._serialize(datetime.now(), None, None)


# Generated at 2022-06-11 21:05:37.776966
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    def use_schemaF_dump():
        schema = SchemaF[str]()
        schema.dump("abc")

    use_schemaF_dump()



# Generated at 2022-06-11 21:05:48.074212
# Unit test for function schema
def test_schema():
    import dataclasses

    @dataclasses.dataclass
    class Foo:
        foo: str

    @dataclasses.dataclass
    class Bar:
        a: int

    @dataclasses.dataclass
    class Foobar:
        foo: Foo
        bar: Bar
        n: typing.Optional[str]
        b: typing.List[str]

    ret = SchemaType.from_dataclass(Foobar)
    assert isinstance(ret, SchemaF)
    assert ret().load({'foo': {'foo': 'hello'}}) == {'foo': {'foo': 'hello'}}
    assert ret().load({'foo': {'foo': 'hello'}}) == {'foo': {'foo': 'hello'}}



# Generated at 2022-06-11 21:05:50.586475
# Unit test for function build_type
def test_build_type():
    foo = build_type(int, {}, None, None, None)
    assert foo


# Generated at 2022-06-11 21:05:57.945004
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields

    class Bar(Schema):
        b = fields.Str()

    class Foo(SchemaF[typing.Any]):
        a = fields.Nested(Bar)

    bar = Bar().load({'b': 'aaa'})
    foo = Foo().load({'a': bar})
    dump_foo = Foo(strict=True).dump(foo)



# Generated at 2022-06-11 21:06:11.290431
# Unit test for function build_type
def test_build_type():
    from marshmallow import fields
    from marshmallow_enum import EnumField

    from dataclasses_json.core import _ExtendedEncoder
    from dataclasses import dataclass
    from typing import List, Union

    @dataclass
    class Child:
        x: int
        y: str

    @dataclass_json
    @dataclass
    class Parent:
        a: Child
        b: List[int]
        c: Union[int, str]
        d: Child
        e: str


# Generated at 2022-06-11 21:06:12.666378
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field.__class__.__name__ == "_TimestampField"



# Generated at 2022-06-11 21:06:15.966766
# Unit test for function schema
def test_schema():
    assert _is_optional(typing.Optional[int]) is True
    class Test:
        word: str
        def __init__(self, word):
            self.word = word
    assert schema(Test, None, False)['word']._serialize(Test('test'), '', None) == 'test'



# Generated at 2022-06-11 21:06:28.564986
# Unit test for function build_schema
def test_build_schema():
    from typing import Optional
    from dataclasses import dataclass

    @dataclass
    class Data:
        name: Optional[str] = None
        age: int = 0

    DataClassSchema = build_schema(Data, [], False, False)
    assert DataClassSchema.__name__ == "DataSchema"
    assert "name" in DataClassSchema._declared_fields.keys()
    assert "age" in DataClassSchema._declared_fields.keys()
    assert "Meta" in DataClassSchema.__dict__.keys()
    assert "make_age" in DataClassSchema.__dict__.keys()
    assert DataClassSchema.Meta.__name__ == "Meta"
    assert DataClassSchema.Meta.fields == ("name",)

# Generated at 2022-06-11 21:06:39.968944
# Unit test for function schema
def test_schema():
    class Class:
        a: int
        b: str
        c: datetime
        d: typing.Optional[datetime]
        e: typing.List[datetime]
        f: typing.List[int]
        g: typing.Optional[str]
        h: typing.Optional[str]

        def __init__(self, a=None, b=None, c=None, d=None, e=None, f=None, g=None, h=None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d
            self.e = e
            self.f = f
            self.g = g
            self.h = h


# Generated at 2022-06-11 21:06:58.809189
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from typing import Union, List
    from marshmallow import Schema, fields

    class Example:
        def __init__(self, id: int, name: str):
            self.id = id
            self.name = name

    class ExampleSchema(SchemaF[Example]):
        id = fields.Int(required=True)
        name = fields.Str(required=True)

        @post_load
        def make_example(self, data, **kwargs):
            return Example(**data)

    a = Example(1, 'example')
    schema = ExampleSchema()
    res = schema.dumps(a)
    assert res == json.dumps(dict(id=1, name='example'))

    res = schema.dumps([a])

# Generated at 2022-06-11 21:07:05.963493
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass, field
    import marshmallow_dataclass.types as t
    from marshmallow import Schema, fields


    @dataclass
    class SampleData:
        foo: str = field(metadata=t.dataclass_json(data_key='bar'))


    assert build_schema(SampleData, None, False, False) is not None



# Generated at 2022-06-11 21:07:08.677914
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), 'attr', 'obj') is not None
    assert _TimestampField()._deserialize(123, 'attr', {}) is not None


# Generated at 2022-06-11 21:07:14.291598
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    import dataclasses
    import typing
    import marshmallow

    @dataclasses.dataclass
    class PersonRow:
        name: str
        age: int

    class PersonSchema(marshmallow.Schema):
        name = marshmallow.fields.String()
        age = marshmallow.fields.Integer()

    if False:
        ps = PersonSchema()

        ps.dump(1)

        ps.dump(PersonRow('John', 35))

        ps.dump([PersonRow('John', 35), PersonRow('Jane', 28)])  # type: ignore



# Generated at 2022-06-11 21:07:27.379035
# Unit test for function build_type
def test_build_type():
    from marshmallow import fields

    class class_X:
        pass

    class class_Y:
        pass

    class_X.schema = lambda: fields.Field()
    class_Y.schema = lambda: fields.Field()

    class Enum_A(Enum):
        a = 1
        b = 2
        c = 3

    class Enum_B(Enum):
        a = 1
        b = 2
        c = 3

    def test_type_simple(mm_field):
        assert isinstance(mm_field(str), fields.String)
        assert isinstance(mm_field(int), fields.Integer)
        assert isinstance(mm_field(float), fields.Float)
        assert isinstance(mm_field(UUID), fields.UUID)

# Generated at 2022-06-11 21:07:34.165130
# Unit test for function schema
def test_schema():
    class Per(metaclass=_ExtendedEncoder):
        def __init__(self, p: int):
            self.p = p

    class C(metaclass=_ExtendedEncoder):
        per: Per
        x: typing.List[Per]

    res = schema(C, dataclasses_json.Mapping, infer_missing=False)
    assert res == {'per': fields.Dict, 'x': fields.List(fields.Dict)}
    res = schema(C, dataclasses_json.Mapping, infer_missing=True)
    assert res == {'per': fields.Dict, 'x': fields.List(fields.Dict)}



# Generated at 2022-06-11 21:07:41.102114
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo:
        bar: int
    class FooSch(SchemaF[Foo]):
        bar = fields.Int()
    example = Foo(1)
    j = FooSch().dumps(example)
    assert(j == '{"bar": 1}')
    j = FooSch().dumps([example, example])
    assert(j == '[{"bar": 1}, {"bar": 1}]')
test_SchemaF_dumps()


# Generated at 2022-06-11 21:07:43.296573
# Unit test for function build_type
def test_build_type():
    assert build_type(Tuple, {}, object, object, object)

# Generated at 2022-06-11 21:07:49.729369
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from typing import Optional, Dict
    from marshmallow import fields

    @dataclass
    class Tree:
        name: str
        num: int

    @dataclass
    class Animal:
        class Meta:
            dataclass = Tree
        name: str
        num: int

    schema = build_schema(Animal, None, None, None)
    assert isinstance(schema.Meta, type)
    assert len(schema.Meta.fields) == 2
    assert isinstance(schema.name, fields.Field)
    assert isinstance(schema.num, fields.Int)




# Generated at 2022-06-11 21:07:54.742689
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField(default=None)._serialize(value=None, attr=None, obj=None) == None
    assert _TimestampField(default=None)._deserialize(value=None, attr=None, data=None) == None


# Generated at 2022-06-11 21:08:18.951816
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class SomeClass:
        a: str
        b: int
    a = build_schema(SomeClass, None, False, False)
    assert isinstance(a, type)


# Generated at 2022-06-11 21:08:19.950546
# Unit test for function schema
def test_schema():
    assert schema(1, "aa", "bb") == {}

# Generated at 2022-06-11 21:08:32.750257
# Unit test for constructor of class _IsoField
def test__IsoField():
    from .unittest_classes import User
    from datetime import datetime
    from uuid import UUID

    class MySchema(Schema):
        aa = fields.UUID(error_messages={"required": "UUID is required"})
        bb = fields.DateTime(error_messages={"required": "DateTime is required"})
    s_obj = MySchema()
    jstr = """{
        "aa": "00000000-0000-0000-0000-000000000000",
        "bb": "2020-05-22T06:56:49.999990"
    }"""
    res = s_obj.loads(jstr)
    assert res['aa'] == UUID(int=0)

# Generated at 2022-06-11 21:08:38.124140
# Unit test for constructor of class _IsoField
def test__IsoField():
    # Arrange
    test_value = datetime.now()
    test_field = _IsoField()

    # Act
    serialized = test_field._serialize(test_value, "my_attr", None)
    deserialized = test_field._deserialize(serialized, "my_attr", None)

    # Assert
    assert serialized == test_value.isoformat()
    assert deserialized == test_value



# Generated at 2022-06-11 21:08:48.938640
# Unit test for function build_schema
def test_build_schema():
    import inspect
    @dataclass
    class DataClassSchema:

        Meta = type('Meta',
                    (),
                    {'fields': tuple(field.name for field in dc_fields(cls)
                                     if
                                     field.name != 'dataclass_json_config' and field.type !=
                                     typing.Optional[CatchAllVar])
                     })
        @post_load
        def make_instance(self, kvs, **kwargs):
            return _decode_dataclass(cls, kvs, partial)

        def dumps(self, *args, **kwargs):
            if 'cls' not in kwargs:
                kwargs['cls'] = _ExtendedEncoder

            return Schema.dumps(self, *args, **kwargs)


# Generated at 2022-06-11 21:08:55.224647
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass, field
    from typing import Optional
    from marshmallow.validate import Equal
    @dataclass
    class C:
        a: int = field(metadata={'dataclasses_json': {'mm_field': fields.Field(validate=Equal(1))}})
        b: bool
        def __post_init__(self):
            pass
    assert(str(build_schema(C, {})()).find('a = Integer(validate=<marshmallow.validate.Equal object at ') >= 0)


# Generated at 2022-06-11 21:08:57.326977
# Unit test for function build_type
def test_build_type():
    # test build_type works without any exceptions
    assert True

# Generated at 2022-06-11 21:09:08.434643
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json, configure


    def test_schema(cls, mixin, infer_missing):
        schema = {}
        overrides = _user_overrides_or_exts(cls)
        # TODO check the undefined parameters and add the proper schema action
        #  https://marshmallow.readthedocs.io/en/stable/quickstart.html
        for field in dc_fields(cls):
            metadata = (field.metadata or {}).get('dataclasses_json', {})
            metadata = overrides[field.name]
            if metadata.mm_field is not None:
                schema[field.name] = metadata.mm_field
            else:
                type_ = field.type
                options = {}
               

# Generated at 2022-06-11 21:09:16.236501
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField(allow_none=False)._serialize(datetime.now()) == datetime.now().timestamp()
    assert _TimestampField(allow_none=True)._serialize(datetime.now()) == datetime.now().timestamp()
    assert _TimestampField(allow_none=True)._deserialize(datetime.now().timestamp()) == _timestamp_to_dt_aware(datetime.now().timestamp())
    assert _TimestampField(allow_none=False)._deserialize(datetime.now().timestamp()) == _timestamp_to_dt_aware(datetime.now().timestamp())



# Generated at 2022-06-11 21:09:18.117176
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field._deserialize(None, None, None) is None



# Generated at 2022-06-11 21:10:07.177203
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()

# Generated at 2022-06-11 21:10:16.114197
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin
    from dataclasses_json.config import Config

    @dataclass
    class Foo(DataClassJsonMixin):
        name: str
        age: int
        is_adult: bool = False


# Generated at 2022-06-11 21:10:17.788450
# Unit test for function build_type
def test_build_type():
    assert True

# Generated at 2022-06-11 21:10:27.231002
# Unit test for function build_schema
def test_build_schema():
    import dataclasses_json.api
    @dataclasses_json.api.dataclass_json
    class Test:
        a: int
    TestSchema: typing.Type[SchemaType] = build_schema(Test, object, False, False)
    assert isinstance(TestSchema, type)
    assert issubclass(TestSchema, SchemaType)
    test = Test(a=1)
    dumped = TestSchema().dump(test)
    assert isinstance(dumped, dict)
    assert dumped == {'a': 1}
    loaded = TestSchema().load(dumped)
    assert isinstance(loaded, Test)
    assert loaded == test


# Generated at 2022-06-11 21:10:35.775268
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from typing import Union
    name = SchemaF.load.__name__
    assert name == 'load'
    signature = typing.get_type_hints(SchemaF.load)  # type: ignore
    assert signature['self'] == typing.Type[SchemaF]
    assert signature['data'] == Union[dict, list]
    assert signature['many'] == bool
    assert signature['partial'] == bool
    assert signature['unknown'] == str
    assert signature['return'] == typing.Union[A, list]
test_SchemaF_load()

# Generated at 2022-06-11 21:10:44.111497
# Unit test for function build_type
def test_build_type():
    assert build_type(type(None), {}, None, None, None) == \
                    Schema._registry['fields']['Null']
    assert build_type(str, {}, None, None, None) == \
                    Schema._registry['fields']['String']
    assert build_type(str, {}, None, None, None) == \
                    Schema._registry['fields']['String']



# Generated at 2022-06-11 21:10:54.643484
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from collections import namedtuple
# lgtm [py/unused-local]
    class MySchema(SchemaF[namedtuple('MyTuple', 'a b c')]):
        a = fields.Str()
        b = fields.Str()
        c = fields.Str()

    x = namedtuple('MyTuple', 'a b c')
    result = x('a', 'b', 'c')
    assert MySchema().dumps(result) == '{"a": "a", "b": "b", "c": "c"}'



# Generated at 2022-06-11 21:10:59.516826
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class T(typing.Protocol):
        def __init__(self): ...

    class Base(SchemaF[T]):
        pass

    class Child(Base):
        pass



# Generated at 2022-06-11 21:11:05.910467
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField().serialize(datetime.utcnow()) is not None
    assert _TimestampField().deserialize(datetime.utcnow()) is not None
    assert _TimestampField().serialize(MISSING) is None
    assert _TimestampField().deserialize(MISSING) is None



# Generated at 2022-06-11 21:11:15.194906
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    assert SchemaF[A].dumps(obj=__any_object__,many=__any_object__,*__any_args__,**__any_kwargs__) == __any_str__
    assert SchemaF[A].dumps(obj=__any_object__,many=False,*__any_args__,**__any_kwargs__) == __any_str__
    assert SchemaF[A].dumps(obj=__any_object__,many=True,*__any_args__,**__any_kwargs__) == __any_str__
    assert SchemaF[A].dumps(obj=__any_object__,*__any_args__,**__any_kwargs__) == __any_str__


# Generated at 2022-06-11 21:14:50.709202
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class FooSchema(SchemaF[int]):
        a = fields.Int()

        @post_load
        def make_object(self, data, **kwargs):
            return data['a']

    assert FooSchema().dump(1) == {'a': 1}



# Generated at 2022-06-11 21:15:02.373910
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    import marshmallow as mm
    class Foo(typing.NamedTuple):
        val: str
    class FooSchema(SchemaF[Foo]):
        val = mm.fields.Str()
    x = Foo('wow')
    y = FooSchema()
    y.dumps(x) == y.dumps([x])
    s = y.dumps(x)
    y.loads(s) == x
    y.loads(s) == [x]

if sys.version_info >= (3, 7):
    class SchemaF(Schema, typing.Generic[A]):
        """Lift Schema into a type constructor"""


# Generated at 2022-06-11 21:15:14.733949
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclasses.dataclass
    class Person:
        name: str
        age: int

    class PersonSchema(SchemaF[Person]):
        name = fields.String()
        age = fields.Integer()

    @dataclasses.dataclass
    class PersonWithList:
        name: str
        friends: typing.List[Person]

    class PersonWithListSchema(SchemaF[PersonWithList]):
        name = fields.String()
        friends = fields.Nested(PersonSchema, many=True)

    person = Person(name='Jeremy', age=35)
    person2 = Person(name='Rachel', age=30)
    personFriendList = PersonWithList(name='Jeremy', friends=[person, person2])

    s = PersonSchema()
    s.dump(person)