

# Generated at 2022-06-11 21:05:45.288192
# Unit test for function schema
def test_schema():
    from dataclasses_json.core import encode, decode
    from dataclasses import dataclass
    from marshmallow import ValidationError
    from marshmallow_enum import EnumField
    from dataclasses_json import DataClassJsonMixin

    class TestEnum(Enum):
        a = 'a'
        b = 'b'

    @dataclass
    class Test(DataClassJsonMixin):
        test_str: str
        test_list: typing.List[int]
        test_enum: TestEnum

    schema = Test.schema()
    assert schema['test_str'].__class__ is fields.Str
    assert schema['test_list'].__class__ is fields.List
    assert isinstance(schema['test_list'].container, fields.Integer)

# Generated at 2022-06-11 21:05:58.893277
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass(frozen=True)
    class TestSchema:
        value: int
        value2: int

    DataClassSchema = build_schema(TestSchema, mixin=None,
                                   infer_missing=False,
                                   partial=False)
    schema = DataClassSchema()
    assert ((schema.dump(TestSchema(value=100, value2=200)),
             schema.load(schema.dump(TestSchema(value=100, value2=200)))),
            (schema.dump(TestSchema(value=100, value2=200)),
             TestSchema(value=100, value2=200))) == (
        {'value': 100, 'value2': 200}, {'value': 100, 'value2': 200})



# Generated at 2022-06-11 21:06:11.688903
# Unit test for function build_schema
def test_build_schema():
    # Case 1: _user_overrides_or_exts
    dc_schema = build_schema(SimpleModel, None, None, None)
    assert SimpleModel.schema().dump(SimpleModel()) == dc_schema.dump(
        SimpleModel())

    # Case 2: build_type
    @dataclass
    class Model1:
        dataclass_json = DCJsonConfig(mm_field=None)

        aaa: str = None
        bbb: str = "bbb"
        ccc: int = 456
        ddd: typing.List[float] = field(default_factory=lambda: [1, 2, 3])
        eee: typing.List[float] = field(default_factory=lambda: [None])
        fff: typing.Optional[dict] = None
       

# Generated at 2022-06-11 21:06:15.887558
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json.mm import mm_schema
    @dataclass
    class A:
        a: int
        b: float

    @dataclass
    class B:
        a: A
        b: bytes

    schema = schema(B, mm_schema, False)
    assert 'a' in schema
    assert 'b' in schema



# Generated at 2022-06-11 21:06:28.435796
# Unit test for function schema
def test_schema():
    import typing
    import dataclasses
    import marshmallow

    class CatSchema(marshmallow.Schema):
        name = fields.String(default='Miao')
        color = fields.String(default='white')
    class DogSchema(marshmallow.Schema):
        name = fields.String(default='Wang')
        color = fields.String(default='black')
    @dataclasses.dataclass
    class Cat:
        name: str
        color: str
    @dataclasses.dataclass
    class Dog:
        name: str
        color: str
    @dataclasses.dataclass
    class Animal:
        name: str
        color: str
        @classmethod
        def schema(cls):
            if cls == Cat:
                return CatSchema

# Generated at 2022-06-11 21:06:29.773274
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():

    parsed = SchemaF[None].loads("{}")


# Generated at 2022-06-11 21:06:39.193145
# Unit test for function schema
def test_schema():
    from dataclasses_json import dataclass_json
    from marshmallow.exceptions import ValidationError
    from marshmallow.fields import Field, Nested

    @dataclass_json
    @dataclass
    class Dummy:
        a: str

    class DummySchema:
        a = fields.Str()

    @dataclass_json
    @dataclass
    class Foo:
        str: str
        int: int
        float: float
        bool: bool
        dt: datetime
        id: UUID
        dc: Dummy
        dpc: typing.Optional[Dummy]
        dl: typing.List[Dummy]
        l: typing.List[int]
        t: typing.Tuple[int, int]
        d: typing.Dict[str, str]
        m

# Generated at 2022-06-11 21:06:49.560045
# Unit test for function build_type
def test_build_type():
    @dataclass_json
    @dataclass
    class Test:
        pass

    assert fields.Nested(Test.schema(), allow_none=True) == build_type(
        typing.Optional[Test], {'allow_none': False}, SerializerMixin,
        dc_fields(Test)[0], Test)
    assert fields.Field(allow_none=True) == build_type(
        typing.Any, {'allow_none': True}, SerializerMixin, dc_fields(Test)[0],
        Test)
    assert fields.Field(allow_none=True) == build_type(
        typing.Type[Test], {'allow_none': True}, SerializerMixin,
        dc_fields(Test)[0], Test)

# Generated at 2022-06-11 21:06:58.213886
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass

    @dataclass
    class Foo:
        a: int
        b: str
        c: bool

    class FooMixin:
        pass

    @dataclass_json(mm_field=fields.Str)
    @dataclass
    class Bar:
        b: str = "foo"
        c: bool = False
        d: Foo = Foo(1, "2", False)

    @dataclass
    class FooBar:
        b: typing.List[Bar]

    @dataclass_json
    @dataclass
    class Baz:
        b: typing.Optional[Bar] = None
        c: typing.Optional[Bar] = None

    @dataclass_json
    @dataclass
    class Baz2:
        b: Bar
        c: typing

# Generated at 2022-06-11 21:07:05.626861
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class CData(object):
        def __init__(self, i, c):
            self.i = i
            self.c = c

    class CDataF(SchemaF):
        i = fields.Int()
        c = fields.Int()

    CDataF().load({"i": 1, "c": 2})
    CDataF().load([{"i": 1, "c": 2}])


# Generated at 2022-06-11 21:07:21.306055
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field is not None

if sys.version_info[:2] >= (3, 7):
    from dataclasses import dataclass



# Generated at 2022-06-11 21:07:28.121538
# Unit test for function schema
def test_schema():
    from typing import Optional
    from dataclasses import dataclass, field
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class MyClass:
        a: str
        b: Optional[str] = None
        c: int = 1
        d: typing.List[str] = field(default_factory=list)

    _ = schema(MyClass, None, False)



# Generated at 2022-06-11 21:07:35.338392
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass, field
    from marshmallow import fields

    @dataclass
    class Inner:
        value: int
        field2: int

    @dataclass
    class Middle:
        field1: int
        inner: Inner

    @dataclass
    class Outer:
        field1: int
        middle: Middle

    assert build_type(int, {}, None, field('value', int), type(Inner)) == fields.Int()
    assert build_type(Inner, {}, None, field('inner', Inner), type(Middle)) == fields.Nested(Inner.schema(), field_many=False)
    assert build_type(Middle, {}, None, field('middle', Middle), type(Outer)) == fields.Nested(Middle.schema(), field_many=False)


# Generated at 2022-06-11 21:07:36.438903
# Unit test for function build_type
def test_build_type():
    assert 1 == 1 # TODO


# Generated at 2022-06-11 21:07:38.986425
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    assert SchemaF.dumps(None, None, None, None) is not None

# Generated at 2022-06-11 21:07:49.296205
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from marshmallow_dataclass import class_schema

    @dataclass
    class Person:
        name: str
        age: int

    s = class_schema(Person)
    assert s.__name__ == "PersonSchema"
    assert s.__qualname__ == "PersonSchema"
    assert s.Meta.fields == ("name", "age")

    @dataclass
    class Employee(Person):
        salary: float

    s = class_schema(Employee)
    assert s.__name__ == "EmployeeSchema"
    assert s.__qualname__ == "EmployeeSchema"
    assert s.Meta.fields == ("name", "age", "salary")

    @dataclass
    class Student:
        person: Person


# Generated at 2022-06-11 21:08:02.486997
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    import uuid
    @dataclass
    class InnerSchema(object):
        id: int
        data: str
    @dataclass
    class TestSchema(object):
        id: int
        data: InnerSchema
    @dataclass
    class TestSchema2(object):
        id: int
        data: typing.Optional[InnerSchema]
    desc = dict(
        id=fields.Int,
        data=fields.Nested(InnerSchema.schema())
    )
    desc2 = dict(
        id=fields.Int,
        data=fields.Nested(InnerSchema.schema(), allow_none=True)
    )
    schema = Schema.from_dict(desc)
    schema2 = Schema.from_dict

# Generated at 2022-06-11 21:08:07.479626
# Unit test for function build_type
def test_build_type():
    T = typing.TypeVar('T')
    class MyType(typing.NewType('MyType', int)):
        pass
    assert build_type(MyType, {}, None, None, None)(MyType, {}) == fields.Int()



# Generated at 2022-06-11 21:08:17.651159
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class A(SchemaF[typing.List[str]]):
        pass

    da = A().dump(['asdf'], many=True)
    assert da == ['asdf']

    da = A().dump(['asdf'], many=False)
    assert da == ['asdf']

    da = A().dump(['asdf'])
    assert da == ['asdf']

    da = A().dump('asdf', many=True)
    assert da == 'asdf'

    da = A().dump('asdf', many=False)
    assert da == 'asdf'

    da = A().dump('asdf')
    assert da == 'asdf'



# Generated at 2022-06-11 21:08:29.249037
# Unit test for function build_schema
def test_build_schema():
    from boto3.dynamodb.types import Binary
    from dataclasses_json.api import load, dump
    from marshmallow import fields as mm_fields
    from dataclasses import dataclass
    from dataclasses_json.api_config import ApiConfig
    from dataclasses_json.mm import MM
    from dataclasses_json.api import serialize, deserialize
    @dataclass
    class Simple:
        x: int
        y: float

    @dataclass
    class ApiConfigSimple:
        x: int
        y: float

        class Config(ApiConfig):
            pass

    TestSchema = build_schema(Simple, mixin=MM, infer_missing=True, partial=True)

# Generated at 2022-06-11 21:09:02.521039
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_field = _IsoField()

    assert iso_field._serialize(datetime(2020, 12, 12, 12, 12, 12), None, None, None) == '2020-12-12T12:12:12'
    assert iso_field._deserialize('2020-12-12T12:12:12', None, None, None) == datetime(2020, 12, 12, 12, 12, 12)


# Generated at 2022-06-11 21:09:10.296145
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    A = typing.TypeVar('A')
    class Foo:
        x: int
    @dataclass_json
    @dataclass
    class Bar:
        x: int
    @dataclass_json
    @dataclass
    class Baz(Bar):
        z: str
    assert SchemaF[Foo].loads({'x': 42}) == Foo(x=42)
    assert SchemaF[Bar].loads({'x': 42}) == Bar(x=42)
    assert SchemaF[Baz].loads({'x': 42, 'z': 'abc'}) == Baz(x=42, z='abc')
    assert SchemaF[Bar].loads([{'x': 42}]) == [Bar(x=42)]

# Generated at 2022-06-11 21:09:18.659305
# Unit test for function schema
def test_schema():
    from typing import Optional, Any
    from dataclasses import dataclass, field
    from marshmallow import fields
    from dataclasses_json import DataClassJsonMixin, mm_field
    @dataclass
    class Obj(DataClassJsonMixin):
        a: str
        b: int = mm_field(default=2)
    o = Obj("a")
    s = schema(Obj, DataClassJsonMixin, False)
    assert isinstance(s['a'], fields.Str)
    assert isinstance(s['b'], fields.Int)
    assert s['a'].default == None
    assert s['b'].default == 2
    @dataclass
    class OptionalObj(DataClassJsonMixin):
        a: Optional[str]
    o = OptionalObj(a="a")
   

# Generated at 2022-06-11 21:09:29.080333
# Unit test for function build_type
def test_build_type():
    import marshmallow as ma
    from marshmallow_enum import EnumField as Ef

    assert build_type(int, {}, int, int, int) == fields.Int
    assert build_type(str, {}, str, str, str) == fields.Str
    assert build_type(float, {}, float, float, float) == fields.Float
    assert build_type(bool, {}, bool, bool, bool) == fields.Bool

    # TODO: How to test that?
    # assert build_type(datetime, {}, datetime, datetime, datetime) == _TimestampField

    assert build_type(UUID, {}, UUID, UUID, UUID) == fields.UUID
    assert build_type(Decimal, {}, Decimal, Decimal, Decimal) == fields.Decimal

    assert build

# Generated at 2022-06-11 21:09:41.239421
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from marshmallow import Schema

    @dataclass
    class TempSchema(Schema):
        ...

    class Temp:
        def __init__(self, a: int):
            self.a = a

        def __eq__(self, other):
            if not isinstance(other, self.__class__):
                return False
            return self.a == other.a

    @dataclass
    class Mixin:
        a: int

        schema = Schema(schema={})

    @dataclass
    class A(Mixin):
        b: Temp


# Generated at 2022-06-11 21:09:49.211492
# Unit test for function build_schema
def test_build_schema():
    from mypy_extensions import TypedDict
    # print(build_schema(Tmp, dataclass_json.mixin(Tmp), True, False).__name__)
    # assert build_schema(Tmp, dataclass_json.mixin(Tmp), True, False).__name__ == "TmpSchema"

    # Test class without optional args
    class Test(TypedDict):
        application_id: str
        description: str
        sharing_status: str
        lineage: bool
        attributes: dict
        owner_id: str
        read_only: bool
        has_subscribers: bool
        version: int
        created_by: str
        created_at: int
        modified_by: str
        modified_at: int


# Generated at 2022-06-11 21:09:57.789124
# Unit test for function build_type
def test_build_type():
    class TestClass:
        @property  # type: ignore
        def schema(self) -> 'TestClass':
            return self
        def __init__(self, *args, **kwargs):
            pass
        def _serialize(self, value, attr, obj, **kwargs):
            pass
        def _deserialize(self, value, attr, data, **kwargs):
            pass

    class TestClass2:
        @property  # type: ignore
        def schema(self) -> 'TestClass2':
            return self
        def __init__(self, *args, **kwargs):
            pass
        def _serialize(self, value, attr, obj, **kwargs):
            pass
        def _deserialize(self, value, attr, data, **kwargs):
            pass


# Generated at 2022-06-11 21:10:07.537379
# Unit test for function schema
def test_schema():
    from typing import Dict
    from dataclasses import dataclass
    from dataclasses_json.api import Schema

    @dataclass
    class Child:
        name: str

    @dataclass
    class Parent(Schema):
        child: Child

    s = schema(Parent, Schema, False)
    assert isinstance(s['child'], fields.Nested)

    @dataclass
    class ParentWithDict(Schema):
        child: Child
        child2: Dict[str, str]

    s = schema(ParentWithDict, Schema, False)
    assert isinstance(s['child2'], fields.Dict)



# Generated at 2022-06-11 21:10:17.642080
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    a = SchemaF.dumps([1, 2, 3], many=True)
    b = SchemaF.dumps(1, many=False)
    c = SchemaF.loads(a, many=True)
    d = SchemaF.loads(b, many=False)

# Generated at 2022-06-11 21:10:27.761670
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses import dataclass
    @dataclass()
    class TestSchemaFTyping1:
        a: int
    xx: TestSchemaFTyping1 = SchemaF[TestSchemaFTyping1]().load({"a": 1})
    xx: TestSchemaFTyping1 = SchemaF[TestSchemaFTyping1]().load([{"a": 1}], many=True)
    xx: TestSchemaFTyping1 = SchemaF[TestSchemaFTyping1]().load([{"a": 1}])
    xx: TestSchemaFTyping1 = SchemaF[TestSchemaFTyping1]().load({"a": 1}, many=False)

# Generated at 2022-06-11 21:11:24.579541
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._deserialize('2020-09-11T23:24:35.094715') == datetime(2020, 9, 11, 23, 24, 35, 94715)
    assert _IsoField()._deserialize('2020-09-11T23:24:35.094715+01:00') == datetime(2020, 9, 11, 23, 24, 35, 94715)
    assert _IsoField()._deserialize('2020-09-11T23:24:35.094715+01:00[Europe/Berlin]') == datetime(2020, 9, 11, 23, 24, 35, 94715)


# Generated at 2022-06-11 21:11:27.205672
# Unit test for function build_schema
def test_build_schema():
    assert type(build_schema(TestSchema1, None, True, True)) == type(Schema)



# Generated at 2022-06-11 21:11:37.241732
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():  # type: ignore
    from .models import P

    data = [{'x': 1, 'y': 2}, {'x': 3, 'y': 4}]

    def fun(p: P, **kwargs):
        return p

    SchemaF[P].dump(fun(P(1, 2)))  # type: ignore
    SchemaF[P].dump([fun(P(1, 2)), fun(P(1, 2))])  # type: ignore
    SchemaF[P].dump(fun(P(1, 2)), many=True)  # type: ignore

    # Type mismatch:
    SchemaF[P].dump(fun(P(1, 2)), many=False)  # type: ignore

    # Type mismatch:
    SchemaF[P].dump(fun(P(1, 2)), many=None)

# Generated at 2022-06-11 21:11:47.309445
# Unit test for function build_schema
def test_build_schema():
    '''
    Function `build_schema` is tested by this unit test.
    The unit test also tests the inherited functions from the `Schema` class.
    '''
    def _build_dataclass(name: str) -> typing.Type[A]:
        dataclass_type = type(name, (object,), {})

        @dataclass(dataclass_type)
        class X:
            y: int = 3
            z: str = 'z'

        return dataclass_type

    MyMixin = type('MyMixin', (object,), {})
    schema = build_schema(_build_dataclass('X'), MyMixin, True, True)

    assert issubclass(schema, Schema)
    data = {'y':4, 'z': 'c'}
    assert schema

# Generated at 2022-06-11 21:11:55.364629
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import Set

    class Football(Enum):
        FCB = 1
        FCR = 2

    @dataclass_json
    @dataclass
    class FootballSchema(SchemaF[Football]):
        fcb: int = 1
        fcr: int = 2

    fs = FootballSchema()
    assert fs.dump(Football.FCB) == {'fcb': 1, 'fcr': 2}
    assert fs.dump(Football.FCR) == {'fcb': 1, 'fcr': 2}
    assert fs.dump([Football.FCB, Football.FCR]) == \
                         [{'fcb': 1, 'fcr': 2}, {'fcb': 1, 'fcr': 2}]
    fs2 = FootballSchema(many=True)

# Generated at 2022-06-11 21:12:06.063828
# Unit test for function build_type
def test_build_type():
    from marshmallow import Schema, fields
    import typing

    class _TestDataclass():
        def __init__(self, val):
            self.val = val

    class _TestDataclass2(_TestDataclass):
        pass

    class _TestEnum(Enum):
        a = 1
        b = 2

    class _TestSchema(Schema):
        pass

    class _TestDataclassSchema(_TestSchema):
        pass

    class _TestDataclassSchema2(_TestSchema):
        pass

    class _TestUnionDataclassSchema(_TestSchema):
        pass

    class _NestedDataclassSchema(_TestSchema):
        class Meta:
            dataclass = _TestDataclass2
            unknown = EXCLUDE


# Generated at 2022-06-11 21:12:14.309916
# Unit test for function build_schema
def test_build_schema():
    import dataclasses
    import dataclasses_json

    @dataclasses.dataclass
    class Address:
        street: str
        city: str

    @dataclasses.dataclass
    class Person:
        name: str
        age: int
        address: Address

    person_schema_class = dataclasses_json.build_schema(Person)
    assert isinstance(person_schema_class, type)
    assert issubclass(person_schema_class, SchemaType)
    assert person_schema_class.Meta.fields == ('name', 'age', 'address')



# Generated at 2022-06-11 21:12:16.435137
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert type(_TimestampField()) == _TimestampField



# Generated at 2022-06-11 21:12:23.727354
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    assert isinstance(SchemaF.dumps(Schema(), {}), str)
    assert isinstance(SchemaF.dumps(Schema(), {}, many=True), str)
    assert isinstance(SchemaF.dumps(Schema(), [], many=True), str)
    assert isinstance(SchemaF.dumps(Schema(), [{}, {}]), str)
    assert isinstance(SchemaF.dumps(Schema(), [{}, {}], many=True), str)



# Generated at 2022-06-11 21:12:32.223594
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # type: () -> None
    class _SchemaClass(SchemaF):
        def __init__(self, *args, **kwargs):
            """
            Raises exception because this class should not be inherited.
            This class is helper only.
            """

            super().__init__(*args, **kwargs)
            raise NotImplementedError()

    # test list of dataclasses
    d = dataclasses.asdict(_SimpleDataclass(b=1, c=2))

    l = [_SimpleDataclass(b=1, c=2),
         _SimpleDataclass(b=1, c=2)]

    assert _SchemaClass().dump(l) == [d, d]
    assert _SchemaClass().dump([1, 2, 3]) == [1, 2, 3]
    assert _

# Generated at 2022-06-11 21:14:47.510261
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    s = SchemaF.loads()  # type: ignore



# Generated at 2022-06-11 21:14:53.356153
# Unit test for function build_schema
def test_build_schema():
    from .types import DataClassBase

    class TestClass(DataClassBase):
        a: int
        b: str

    from .config import GlobalConfig

    cfg = GlobalConfig(infer_missing=True)
    DataClassSchema = build_schema(TestClass, DataClassBase, cfg.infer_missing,
                                   cfg.mm_partial)

    assert TestClass.schema() is DataClassSchema
    assert TestClass.schema() is build_schema(TestClass, DataClassBase,
                                              cfg.infer_missing, cfg.mm_partial)

# Generated at 2022-06-11 21:15:03.432725
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from typing import Union
    from marshmallow import Schema, fields, post_load

    class Foo(typing.NamedTuple):
        x: int
        y: str

    class Bar:
        def __init__(self, x, y):
            self.x = x
            self.y = y

    class FooSchema1(SchemaF[Foo]):
        x = fields.Int()
        y = fields.Str()

        @post_load
        def make_foo(self, data, **kwargs):
            return Foo(**data)

    data = {'x': 42, 'y': 'hello'}
    assert [Foo(x=42, y='hello')] == FooSchema1().load([data])

# Generated at 2022-06-11 21:15:04.332790
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()


# Generated at 2022-06-11 21:15:14.101059
# Unit test for constructor of class _IsoField
def test__IsoField():
    isoField = _IsoField(required=False)
    assert isoField._serialize("2018-12-24T00:00:00", None, None) == "2018-12-24T00:00:00"
    assert isoField._deserialize("2018-12-24T00:00:00", None, None) == datetime(2018, 12, 24, 0, 0, 0)
    assert isoField._deserialize("2018-12-24T00:00:00.000", None, None) == datetime(2018, 12, 24, 0, 0, 0)
