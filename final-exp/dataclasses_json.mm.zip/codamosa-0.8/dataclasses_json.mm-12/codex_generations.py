

# Generated at 2022-06-11 21:05:40.723554
# Unit test for constructor of class _IsoField
def test__IsoField():
    f = _IsoField()
    assert f._serialize(datetime(2016, 1, 2)) == '2016-01-02T00:00:00'
    assert f._deserialize('2016-01-02T00:00:00') == datetime(2016, 1, 2)


# Generated at 2022-06-11 21:05:53.036096
# Unit test for function build_type
def test_build_type():
    assert build_type(str,None,None,None,None) == TYPES[str]
    assert build_type(int,None,None,None,None) == TYPES[int]
    assert build_type(bool,None,None,None,None) == TYPES[bool]
    assert build_type(float,None,None,None,None) == TYPES[float]
    assert build_type(Decimal,None,None,None,None) == TYPES[Decimal]
    assert build_type(UUID,None,None,None,None) == TYPES[UUID]
    assert build_type(datetime,None,None,None,None) == _TimestampField
    assert build_type(list,None,None,None,None) == TYPES[list]
    assert build_

# Generated at 2022-06-11 21:05:56.116329
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema = SchemaF()
    assert isinstance(schema.dumps('{"a": 1}'), str)

# Generated at 2022-06-11 21:05:57.788803
# Unit test for function build_type
def test_build_type():
    assert build_type(int, {}, int, None, None) == fields.Int

# Generated at 2022-06-11 21:06:05.777658
# Unit test for function build_schema
def test_build_schema():
    import dataclasses
    import typing
    import marshmallow_dataclass

    class JsonType:
        def __init__(self, key, value):
            self.key = key
            self.value = value

        def __eq__(self, other):
            return self.key == other.key and self.value == other.value

    class MySchema(Schema):
        class Meta:
            fields = ("key", "value")

    class MySchemaF1(Schema, typing.Generic[JsonType]):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            raise NotImplementedError()


# Generated at 2022-06-11 21:06:16.826960
# Unit test for function schema
def test_schema():
    import dataclasses
    import marshmallow
    @dataclasses.dataclass
    class SimpleType:
        a: str

    print(schema(SimpleType, SimpleType, True))
    @dataclasses.dataclass
    class SimpleTypeWithAssert:
        a: str
        b: int = dataclasses.field(metadata={'dataclasses_json': {'letter_case': dataclasses.camelcase}})
        c: int = dataclasses.field(metadata={'dataclasses_json': {'mm_field': marshmallow.fields.UUID()}})
        d: int = dataclasses.field(default=dataclasses.MISSING)
        e: int = dataclasses.field(default=dataclasses.MISSING)

# Generated at 2022-06-11 21:06:26.733466
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    @dataclasses.dataclass
    class Foo:
        foo: int
        bar: str

    @dataclasses.dataclass
    class FooList:
        list_foos: typing.List[Foo]

    f = Foo(1, "a")
    f_list = FooList([Foo(1, "a"), Foo(2, "b")])
    schema = SchemaF[Foo]()
    schema.loads(schema.dumps(f))
    schema.loads(schema.dumps(f_list))
    return



# Generated at 2022-06-11 21:06:29.861472
# Unit test for function schema
def test_schema():
    assert False, "Need to write tests for function schema"

# Generated at 2022-06-11 21:06:36.767878
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class Test:
        a: int

    @dataclass
    class Test2:
        b: int

    TestDataClassSchema = build_schema(Test, {}, False, False)
    test_instance = TestDataClassSchema()
    TestDataClassSchema2 = build_schema(Test2, {}, False, False)
    test_instance2 = TestDataClassSchema2()
    assert isinstance(test_instance, SchemaType)
    assert isinstance(test_instance2, SchemaType)



# Generated at 2022-06-11 21:06:47.899922
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class UserSchemaF(SchemaF[dict]):
        name = fields.Str()

    schema = UserSchemaF()
    schema.loads('{"name": "Monty"}')
    #output: {'name': 'Monty'}

# Generated at 2022-06-11 21:07:08.679988
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from datetime import datetime
    from dataclasses import dataclass
    from marshmallow import Schema

    @dataclass
    class A:
        i: int

    @dataclass
    class B(A):
        dt: datetime

    class BS(SchemaF[B]):
        dt = _TimestampField()

    x = B(1, datetime.fromtimestamp(1488281283))
    y = BS().dumps(x)  # type:ignore
    assert y == '{"i": 1, "dt": 1488281283.0}'



# Generated at 2022-06-11 21:07:11.265126
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class NoOpDecoder(json.JSONDecoder):
        def decode(self, input_, _w=json.decoder.WHITESPACE.match):
            return input_



# Generated at 2022-06-11 21:07:23.062215
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    data = [{'name': 'Monty', 'age': 100}, {'name': 'Python', 'age': 5}]
    assert (SchemaF[dict].dumps(data) == '[{"name": "Monty", "age": 100}, {"name": "Python", "age": 5}]')

    data = {'name': 'Monty', 'age': 100}
    assert (SchemaF[dict].dumps(data) == '{"name": "Monty", "age": 100}')

    data = 'data'
    assert (SchemaF[str].dumps(data) == '"data"')

    data = [{'name': 'Monty', 'age': 100}, {'name': 'Python', 'age': 5}]

# Generated at 2022-06-11 21:07:23.657590
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    assert issubclass(SchemaF, Schema)



# Generated at 2022-06-11 21:07:33.292399
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses import dataclass

    @dataclass
    class SimpleDataclass:
        a: int
        b: float

    @dataclass
    class NestedDataclass:
        c: SimpleDataclass
        d: typing.List[SimpleDataclass]

    class SimpleDataclassSchema(SchemaF[SimpleDataclass]):
        a = fields.Int()
        b = fields.Float()

    class NestedDataclassSchema(SchemaF[NestedDataclass]):
        c = fields.Nested(SimpleDataclassSchema)
        d = fields.List(fields.Nested(SimpleDataclassSchema))

    sd = SimpleDataclass(1, 2.3)
    sds = SimpleDataclassSchema()

# Generated at 2022-06-11 21:07:40.747108
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses import dataclass, field
    from marshmallow import fields

    @dataclass
    class A():
        b: int

    class C(SchemaF[A]):
        b = fields.Int()

    assert C(many=False).dump(A(b=1)) == {'b': 1}
    assert C(many=True).dump([A(b=1), A(b=2)]) == [{'b': 1}, {'b': 2}]



# Generated at 2022-06-11 21:07:49.791409
# Unit test for function schema
def test_schema():
    def get_field(field, field_name):
        return next((f for f in dc_fields(field.type) if f.name == field_name), None)

    def has_field(field, field_name):
        return get_field(field, field_name) is not None

    @dataclass_json
    @dataclass
    class X:
        a: str
        b: str = field(mm_field=fields.Str(required=True))

    x = XSchema(strict=True)
    assert has_field(x, 'a')
    assert hasattr(get_field(x, 'a'), 'required')

    assert has_field(x, 'b')
    assert not hasattr(get_field(x, 'b'), 'required')



# Generated at 2022-06-11 21:08:02.565356
# Unit test for function schema
def test_schema():
    from dataclasses import field, dataclass
    from dataclasses_json import DataClassJsonMixin, config
    from marshmallow import fields as mm_fields

    @dataclass
    class Foo(DataClassJsonMixin):
        s: str = field(metadata=dict(dataclasses_json=config(mm_field=mm_fields.Integer())))
        s2: str = field(metadata=dict(dataclasses_json=config(mm_field=mm_fields.Integer())))
        s3: mm_fields.Integer = field(metadata=dict(dataclasses_json=config()))


# Generated at 2022-06-11 21:08:15.794167
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class UserSchema(SchemaF[User]):
        name = fields.Str()
        age = fields.Int()

    u = User('John', 18)
    data, errors = UserSchema().dump(u)
    assert isinstance(data, dict)
    assert type(data) == dict
    assert isinstance(errors, dict)
    assert type(errors) == dict
    assert data['name'] == 'John'
    assert data['age'] == 18

    users = [User('John', 18), User('Jane', 19)]
    data_many, errors = UserSchema().dump(users, many=True)
    assert isinstance(data_many, list)
    assert type(data_many) == list
    assert data_many[0]['name'] == 'John'
    assert data_many[0]['age']

# Generated at 2022-06-11 21:08:26.309516
# Unit test for function build_type
def test_build_type():
    assert issubclass(build_type(dict, {}, None, None, None), fields.Dict)
    assert issubclass(
        build_type(typing.List[str], {}, None, None, None), fields.List
    )
    assert issubclass(
        build_type(typing.Optional[str], {}, None, None, None),
        fields.Field,
    )
    assert issubclass(
        build_type(typing.List[typing.Optional[str]], {}, None, None, None),
        fields.List,
    )
    assert issubclass(
        build_type(typing.Union[int, str], {}, None, None, None),
        _UnionField,
    )



# Generated at 2022-06-11 21:08:53.057522
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    SchemaF[User].load(
        {
            "name": "John",
            "email": "john@example.com",
            "phone": "555-0123",
            "address": {
                "city": "San Francisco",
                "state": "CA"
            }
        }
    )

# Generated at 2022-06-11 21:08:57.951823
# Unit test for function schema
def test_schema():
    class User:
        def __init__(self, name: str, age: int):
            self.name = name
            self.age = age

    class UserSchema(Schema):
        name = fields.Str()
        age = fields.Integer()

        @post_load
        def make_user(self, data, **kwargs):
            return User(**data)

    j = UserSchema().dump(User('Monty', 42))
    assert(j == {"name": "Monty", "age": 42})



# Generated at 2022-06-11 21:09:08.722160
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses_json.api import _SchemaF
    from decimal import Decimal
    from uuid import UUID

    class C:
        def __init__(self, d: Decimal, u: UUID):
            self.d = d
            self.u = u

    schema_f: _SchemaF[C]
    schema_f = _SchemaF[C](strict=True, unknown=EXCLUDE)

    a = C(Decimal('2.2'), UUID('12345678-1234-5678-1234-567812345678'))
    assert schema_f.dumps(a) == '{"d": "2.2", '\
                                '"u": "12345678-1234-5678-1234-567812345678"}'


# Generated at 2022-06-11 21:09:17.834613
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    T1 = typing.List[int]
    T2 = typing.List[A]
    T3 = typing.List[typing.List[int]]
    T4 = typing.List[typing.List[A]]
    T5 = A
    T6 = int

    # test with one type at a time
    schema: SchemaF[T1]
    x = schema.load([1, 2, 3])
    # type: ignore
    assert isinstance(x, typing.List[int])
    y = schema.load({'a': 1})
    # type: ignore
    assert isinstance(y, typing.List[int])

    schema: SchemaF[T2]
    x = schema.load([1, 2, 3])
    # type: ignore
    assert isinstance(x, typing.List[A])


# Generated at 2022-06-11 21:09:28.571895
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # given
    class SomeClass(object):

        def __init__(self, value):
            self.value = value

    class SomeClassSchema(SchemaF[SomeClass]):

        value = fields.String()

        @post_load
        def make_some_class(self, data, **kwargs):
            return SomeClass(**data)

    some_data_1: TEncoded = {"value": "test"}
    expected_deserialize_1: typing.List[SomeClass] = [SomeClass(value="test")]
    some_data_2: TEncoded = {"value": "test"}
    expected_deserialize_2: SomeClass = SomeClass(value="test")

    expected_dump_1 = [{"value": "test"}]
    expected_dump_2 = {"value": "test"}



# Generated at 2022-06-11 21:09:30.313033
# Unit test for constructor of class _IsoField
def test__IsoField():
  assert _IsoField(attribute="test").attribute == "test"


# Generated at 2022-06-11 21:09:42.621142
# Unit test for function build_type
def test_build_type():
    assert build_type(str, {}, object, _ExtendedEncoder.any, object) == fields.Str
    assert build_type(str, {}, object, _ExtendedEncoder.any, object) == fields.Str

    class T(typing.TypedDict):
        a: str

    assert build_type(T, {}, object, _ExtendedEncoder.any, object) == fields.Dict
    class M:
        a = ...

    assert build_type(typing.Mapping[str, str], {}, object, _ExtendedEncoder.any, object) == fields.Field
    assert build_type(typing.MutableMapping[str, str], {}, object, _ExtendedEncoder.any, object) == fields.Field

# Generated at 2022-06-11 21:09:49.757882
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # Type: Union[SchemaF[int], SchemaF[List[int]]]
    sch0: typing.TypeVar('sch0')
    # Type: SchemaF[int]
    sch1: typing.TypeVar('sch1')
    # Type: List[int]
    sch2: typing.TypeVar('sch2')

    # Type: SchemaF[int]
    a: typing.TypeVar('a')
    # Type: List[int]
    b: typing.TypeVar('b')
    # Type: Union[SchemaF[int], SchemaF[List[int]]]
    c: typing.TypeVar('c')

    # Type: Union[int, List[int]]
    d: typing.TypeVar('d')

    sch0 = SchemaF[int]

# Generated at 2022-06-11 21:09:52.482572
# Unit test for constructor of class _IsoField
def test__IsoField():
    with open('tests/test_data.json', 'r') as f:
        jsonData = json.load(f)
    #print(jsonData)
    return jsonData


# Generated at 2022-06-11 21:10:04.948508
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses import dataclass

    @dataclass
    class A:
        x: int

    @dataclass
    class B:
        x: int
        a: typing.List[A]

    @dataclass
    class C:
        x: int
        a: typing.Set[A]
        b: typing.List[B]

    @dataclass
    class C_1:
        x: int
        a: typing.Set[A]
        b: typing.List[B]

    @dataclass
    class C_2:
        x: int
        a: typing.Set[A]
        b: typing.Set[B]

    @dataclass
    class D:
        x: typing.List[C]


# Generated at 2022-06-11 21:11:00.246460
# Unit test for function schema
def test_schema():
    assert schema is not None


# Generated at 2022-06-11 21:11:13.206308
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow.fields import String
    @dataclasses.dataclass
    class Foo:
        a: str

    class FooSchema(SchemaF[Foo]):
        a = String(missing="")

        @post_load
        def make_foo(self, data, **kwargs):
            return Foo(**data)

    fs = FooSchema()
    f1 = Foo("x")
    f2 = Foo("y")
    l = [f1, f2]
    assert fs.dump(f1) == {"a": "x"}
    assert fs.dump(l) == [{"a": "x"}, {"a": "y"}]
    assert fs.dump(f1, many=True) == [{"a": "x"}]

# Generated at 2022-06-11 21:11:16.029959
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    global json
    import json
    schema = SchemaF[str]()

    json_str = schema.dumps("abc")
    json_str = schema.dumps("abc", many=True)
    json_str = schema.dumps(["abc", "def"])
    json.loads(json_str)

# Generated at 2022-06-11 21:11:17.396610
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(None) == None


# Generated at 2022-06-11 21:11:21.233798
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    s = SchemaF().load([{'i': 0}, {'i': 1}], many=True)
    s = SchemaF().load({'i': 1})
    pass


# Generated at 2022-06-11 21:11:30.647158
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    x: TOneOrMultiEncoded = {"name": "foo"}
    y: TOneOrMultiEncoded = [{"name": "foo"}]
    z: TOneOrMultiEncoded = [{"name": "foo"}, {"name": "bar"}]
    class Person(typing.NamedTuple):
        name: typing.Optional[str]
    class PersonSchema(SchemaF[Person]):
        name = fields.Str()
    person_schema = PersonSchema()
    assert person_schema.loads(x) == Person(name="foo")
    assert person_schema.loads(y) == [Person(name="foo")]
    assert person_schema.loads(z) == [Person(name="foo"), Person(name="bar")]

# Generated at 2022-06-11 21:11:38.565484
# Unit test for function schema
def test_schema():
    from typing import Optional, Union, List
    import dataclasses
    import dataclasses_json
    @dataclasses.dataclass
    class Person:
        name: str
        last_name: str
        age: int = dataclasses.field(metadata=dataclasses_json.config(mm_field=fields.Int(missing=20)))
        address: List[str] = dataclasses.field(default_factory=lambda: ['Calle falsa 123', 'Otra calle 456'])
        age_optional: Optional[int] = None
        optional_string: Optional[str] = None
        union_nullable: Union[str, None] = None

    for field in dataclasses.fields(Person):
        metadata = (field.metadata or {}).get('dataclasses_json', {})

# Generated at 2022-06-11 21:11:47.650480
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    # type: () -> None
    class MySchema(SchemaF[int]):
        field = fields.Int()

    schema = MySchema()
    obj = schema.loads('{"field": "123"}', many=False)
    assert obj == 123
    obj_list = schema.loads('[{"field": "123"}, {"field": "123"}]')
    assert obj_list == [123, 123]
    with pytest.raises(ValidationError) as e:
        schema.loads('{"field": "123"}', many=True)
    assert e
    with pytest.raises(ValidationError) as e:
        schema.loads('[{"field": "123"}, {"field": "foo"}]')
    assert e

# Generated at 2022-06-11 21:11:55.546770
# Unit test for function build_type
def test_build_type():
    from typing import Union
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from dataclasses_json.core import _UnionField
    from dataclasses_json import dataclass_json
    from marshmallow_dataclass.schema import SchemaType

    @dataclass_json
    class Foo:
        class TestEnum(Enum):
            a = 'a'
            b = 'b'

        @dataclass_json
        class TestSubClass:
            pass

        @dataclass_json
        class TestSubClassInner(dataclass_json.DataClassJsonMixin):
            pass

        @dataclass_json
        class TestSubClass2:
            pass


# Generated at 2022-06-11 21:12:01.724494
# Unit test for constructor of class _IsoField
def test__IsoField():
    # This is a Unit test for _IsoField
    # Much simpler than the original test___IsoField in marshmallow
    assert _IsoField()._deserialize('2019-12-26T17:14:02.423260+00:00') == datetime(2019, 12, 26, 17, 14, 2, 42326)



# Generated at 2022-06-11 21:14:20.325816
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    @dataclass_json
    @dataclass
    class Foo:
        field_1: int
        field_2: typing.List[typing.Dict[str, bool]] = field(default_factory=list)

    SchemaF[Foo].load([
        {'field_1': 2},
        {'field_1': 3},
        {'field_1': 2},
    ], many=True)  # type: ignore

    SchemaF[Foo].load({
        'field_1': 2
    }, many=None)  # type: ignore

    # check type errors
    # SchemaF[Foo].load([
    #     {'field_1': 2},
    #     {'field_1': 3},
    #     {'field_1': 2},
    # ], many=

# Generated at 2022-06-11 21:14:26.721434
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin
    from marshmallow import fields, Schema
    @dataclass
    class Student(DataClassJsonMixin):
        name: str
    @dataclass
    class Class(DataClassJsonMixin):
        class_name: str
        students: List[Student]

    from pprint import pprint as print
    print(schema(Class, DataClassJsonMixin, False))



# Generated at 2022-06-11 21:14:37.471517
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    pass

# Generated at 2022-06-11 21:14:50.140942
# Unit test for function build_schema
def test_build_schema():
    # TODO: Test is not working properly, will be fixed
    def dummy_mixin():
        ...
    class dummy_type:
        @staticmethod
        def name():
            ...
    class dummy:
        fields = [dummy_type]
        default = ...
        default_factory = ...
        metadata = {'dataclasses_json': ...}
    class dummy_cls:
        @staticmethod
        def dc_fields():
            return [dummy]
        @staticmethod
        def __name__():
            return "class1"
    dummy_schema = build_schema(dummy_cls, dummy_mixin)
    assert dummy_schema.Meta.fields == ('field1')
    assert dummy_schema.make_class1 == dummy_schema.make_class1
    assert dummy_

# Generated at 2022-06-11 21:14:53.296600
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    a = SchemaF[int].dumps(1)
    assert a == "1"


# Generated at 2022-06-11 21:15:03.369617
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    obj: typing.List[typing.List[str]]
    obj = [['foo', 'bar']]
    obj = SchemaF(unknown='EXCLUDE').dumps(obj, many=True)
    obj = SchemaF(unknown='EXCLUDE').dumps(obj, many=False)



# Generated at 2022-06-11 21:15:15.437210
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclasses.dataclass
    class CData:
        name: str
        age: int

    @dataclasses.dataclass
    class CContainer:
        data: typing.List[CData]
        description: str

    cdata_schema = dataclasses_json.configure_schema(CData)
    ccontainer_schema = dataclasses_json.configure_schema(CContainer)
    cdata = CData("John", 24)
    cdata_encoded = cdata_schema.dump(cdata)
    assert isinstance(cdata_encoded, dict)
    ccontainer = CContainer([cdata], "Test")
    ccontainer_encoded = ccontainer_schema.dump(ccontainer)
    assert isinstance(ccontainer_encoded, dict)

