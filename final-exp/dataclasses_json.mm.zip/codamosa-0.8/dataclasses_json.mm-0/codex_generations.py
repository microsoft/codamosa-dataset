

# Generated at 2022-06-11 21:05:33.978536
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    @dataclass
    class TestData:
        field: int
    t = build_schema(TestData, dataclass_json.Mutable.Mixin, False, False)
    assert isinstance(t, type)

# Generated at 2022-06-11 21:05:40.211561
# Unit test for function build_schema
def test_build_schema():
    class Person(Schema):
        def __init__(self, *args, **kwargs):
            self.name = kwargs.get('name', None)
            self.age = kwargs.get('age', None)

    assert _get_fields(Person) == ['name', 'age']

    class PersonField(Field):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    assert PersonField().serialize('name', 'Michelle') == 'Michelle'

    class PersonSchema(Schema):
        name = PersonField()
        age = PersonField()

        class Meta:
            fields = ['name', 'age']

    assert _get_fields(PersonSchema) == ['name', 'age']

# Generated at 2022-06-11 21:05:51.105368
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from typing import Optional
    from dataclasses_json import dataclass_json


    @dataclass_json
    @dataclass
    class User:
        name: Optional[str] = None
        title: str
        ignored: str


    def test_schema():
        s = schema(User, dataclass_json(User), infer_missing=True)
        assert isinstance(s, dict)
        assert s == {'name': fields.Str(allow_none=True, missing=None),
                     'title': fields.Str(allow_none=False, missing=None),
                     'ignored': fields.Field(allow_none=False, missing=None)}



# Generated at 2022-06-11 21:06:02.412916
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from marshmallow import fields
    from marshmallow.validate import OneOf
    from dataclasses_json import DataClassJsonMixin, dataclass_json

    @dataclass
    class Foo(DataClassJsonMixin):
        int_field: int = 1
        str_field: str = 'foo'
        another_field: str = 'bar'
        only_in_schema: int = 2
        case_insensitive: str = 'bar'
        only_in_overrides: str = 'bar'
        int_optional: typing.Optional[int] = None
        field_with_validation: str = 'foo'
        field_with_alter_validation: str = 'foo'
        datetime_field: datetime = datetime.utcnow()
       

# Generated at 2022-06-11 21:06:14.654493
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass


    class Mixin:
        class Meta(object):
            unknown = 'IGNORE'


    @dataclass
    class InnerMixinData(Mixin):
        class Meta(object):
            unknown = 'PASS'
        number: int


    @dataclass
    class InnerData:
        number: int


    @dataclass
    class TestSchema(Mixin):
        name: str
        numbers: typing.List[int]
        nested_dict: typing.Dict[str, typing.List[str]]
        nested_dataclasses: typing.List[InnerData]
        nested_dataclasses_from_mixins: typing.List[InnerMixinData]

# Generated at 2022-06-11 21:06:26.873609
# Unit test for function build_type
def test_build_type():
    from typing import Dict, Optional, List, Union
    from collections import OrderedDict
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow.exceptions import ValidationError

    @dataclass_json
    class NestedClassMixin:
        pass

    @dataclass_json
    class NestedClass(NestedClassMixin):
        pass

    @dataclass_json
    class TestClass1:
        b: int
        nested: NestedClass

    @dataclass_json
    class TestClass2:
        b: Optional[NestedClass]
        nested_with_options: fields.Nested(NestedClass, required=True)
        nested_with_options_and_many: fields.Nested(NestedClass, many=True)


# Generated at 2022-06-11 21:06:38.348863
# Unit test for function build_schema
def test_build_schema(): 
    import unittest
    class TestDataclass:
        def __init__(self, dc):
            self.dc = dc
        def test_build_schema(self):
            from dataclasses import dataclass, field
            from typing import Optional, Any
            import marshmallow
            from dataclasses_json import config as global_config, Schema, DataClassJsonMixin
            from dataclasses_json import typing, fields, dataclass_json
            from dataclasses_json import build_schema
            
            # type / origin are not available in python 3.5
            class _Optional:
                @staticmethod
                def __getitem__(t):
                    return t


            Optional = getattr(typing, 'Optional', _Optional)


# Generated at 2022-06-11 21:06:39.694113
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_field = _IsoField()
    assert iso_field is not None


# Generated at 2022-06-11 21:06:49.857130
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    def dump1(data: str) -> int:
        return 5

    dump1('data')

    def dump2() -> typing.List[int]:
        return []

    dump2()

    def dump3(data: str, many: bool) -> typing.List[int]:
        return []

    dump3('data', True)

    def dump4(data: str, many: None) -> int:
        return 5

    dump4('data', None)

    def dump5(data: str, many: bool = True) -> typing.List[int]:
        return []

    dump5('data')
    dump5('data', True)
    dump5('data', False)



# Generated at 2022-06-11 21:06:58.303966
# Unit test for function schema
def test_schema():
    import unittest
    from dataclasses import dataclass
    from typing import List


    @dataclass
    class A:
        a: bool = False

    @dataclass
    class B:
        b: str = 'b'

    @dataclass
    class C:
        a: A = A()
        b: List[B] = []

    assert schema(C, C, True) == {'a': fields.Nested(schema(A, A, True), missing=A(), allow_none=False),
                                  'b': fields.Nested(schema(B, B, True), many=True, missing=[], allow_none=False)}

    @dataclass
    class A:
        a: bool = False


# Generated at 2022-06-11 21:07:14.090585
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class TestSchema(SchemaF[str]):
        pass
    TestSchema().load(['a'])
    TestSchema().load('a')
    TestSchema().load(['a'], many=True)
    TestSchema().load('a', many=True)
    TestSchema().load('a', many=False)



# Generated at 2022-06-11 21:07:27.179246
# Unit test for function schema
def test_schema():
    cls = [type(None), int, UUID, Decimal, datetime]

    class _M(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        @classmethod
        def dataclass_json(cls):
            return cls

        @classmethod
        def schema(cls):
            from marshmallow import Schema, fields
            return Schema.from_dict(schema(cls, _M, False))

        @classmethod
        def schem(cls):
            from marshmallow import Schema, fields
            return Schema.from_dict(schema(cls, _M, True))

    for t in cls:
        class _A(object):
            s = t

# Generated at 2022-06-11 21:07:34.028920
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from datetime import datetime
    from dataclasses import dataclass
    from dataclasses_json.api import load, dump, DataClassJsonMixin, config

    @dataclass
    class A(DataClassJsonMixin):
        a: int
        b: datetime

    @config
    class Json:
        datetime_format = 'iso'

    schema = SchemaF[A]()

    dump_data = {'a': 1, 'b': datetime.now()}

    assert isinstance(schema.load(dump_data), A)
    assert isinstance(load(dump_data, schema), A)



# Generated at 2022-06-11 21:07:44.859989
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    def _schema_f_test():
        class A(typing.Generic[A]):
            def __init__(self, a: A):
                self.a = a

        class SchemaA(SchemaF[A]):
            a = fields.Dict()

        # Assertions
        # https://mypy.readthedocs.io/en/stable/kinds_of_types.html#type-variables
        # generic type parameter A is bound to int
        schema = SchemaA(many=True)
        json = '[{"a": 1}]'
        schema.loads(json)
        schema.load([{'a': 1}])
        schema.dump([{'a': 1}])
        schema.dumps([{'a': 1}])

        # generic type parameter A is bound to int


# Generated at 2022-06-11 21:07:55.125092
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    def f1(a: List[A]) -> None:
        pass

    f1([B(), C()])

    class D(SchemaF[A]):
        pass

    assert D().dumps(B()) == "{}"
    assert D().dumps([B()]) == "[{}]"
    assert D().dumps([B(), C()]) == "[{}, {}]"
    assert eval(D().dumps([B(), C()])) == [{}, {}]  # type: ignore
    assert eval(D().dumps(B())) == {}  # type: ignore
    assert eval(D().dumps([B()])) == [{}]  # type: ignore

# Generated at 2022-06-11 21:07:55.917843
# Unit test for function build_schema
def test_build_schema():
    pass

# Generated at 2022-06-11 21:08:05.184183
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields

    class Inner(Schema):
        a = fields.Int()
        b = fields.Str()

    class Test(SchemaF[Inner]):
        c = fields.Int()
        d = fields.Nested(Inner)

    assert Test().dump({'c': 1, 'd': {'a': 2, 'b': 'asdf'}}) == \
        {'c': 1, 'd': {'a': 2, 'b': 'asdf'}}


# Generated at 2022-06-11 21:08:13.504031
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    json_dict = {'x': [{'a': 1}, {'b': 2}]}
    class TestClass(typing.NamedTuple):
        x: typing.List[typing.Tuple[int, int]]
    schema = SchemaF[TestClass]
    value = schema.loads(json_dict)

# Generated at 2022-06-11 21:08:24.413297
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    data = [{'a': 1}]
    assert SchemaF[int].load(data, many=True, partial=True, unknown='EXCLUDE') == [int(d['a']) for d in data]
    data = {'a': 1}
    assert SchemaF[int].load(data, many=False, partial=True, unknown='EXCLUDE') == int(data['a'])


# Generated at 2022-06-11 21:08:30.522186
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    assert SchemaF[int].dumps(1, many=False) == '1'
    assert SchemaF[int].dumps(1, many=True) == '1'
    assert SchemaF[int].dumps([1], many=True) == '[1]'
    assert SchemaF[int].dumps([1], many=False) == '[1]'



# Generated at 2022-06-11 21:09:02.613353
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class A:
        pass

    s = SchemaF[A]()
    s.dumps([A()])
    s.dumps(A())

# Generated at 2022-06-11 21:09:12.905631
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    try:
        _TimestampField()._deserialize(1234)
        assert False
    except ValidationError:
        pass

    try:
        _TimestampField()._serialize(1234)
        assert False
    except ValidationError:
        pass

    try:
        _TimestampField()._serialize(None, None, None, required=True)
        assert False
    except ValidationError:
        pass

    try:
        _TimestampField()._deserialize(None, None, None, required=True)
        assert False
    except ValidationError:
        pass

    assert _TimestampField()._serialize(None, None, None, required=False) == None
    assert _TimestampField()._deserialize(None, None, None, required=False) == None


# Generated at 2022-06-11 21:09:25.494806
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    import marshmallow as mm
    from typing import Dict, List
    from dataclasses import dataclass
    from marshmallow import Schema as mmSchema

    # Test: Function: dump, Type: Dict, many: False

    @dataclass
    class DCE_0:
        a: str

    class Schema_DCE_0(mmSchema):
        class Meta:
            unknown = "EXCLUDE"

        a = mm.fields.Str()

    a_0 = DCE_0(a="a value")
    s_0: SchemaF[DCE_0] = Schema_DCE_0()
    assert s_0.dump(a_0) == {"a": "a value"}

    # Test: Function: dump, Type: Dict, many: True


# Generated at 2022-06-11 21:09:36.312420
# Unit test for function schema
def test_schema():
    import marshmallow
    from dataclasses import dataclass

    @dataclass
    class Post:
        title: str
        author: str
        tags: list

    @dataclass
    class Tag:
        name: str
        weight: int

    post_schema = marshmallow.Schema.from_dict(schema(Post, None, False))
    tag_schema = marshmallow.Schema.from_dict(schema(Tag, None, False))

    post_data = post_schema.load({"title": "foo", "author": "bar",
                                  "tags": [{"foo": "bar"}]})

    tag_data = tag_schema.load({"name": "foo", "weight": "2"})

    assert isinstance(post_data.data["tags"][0], Tag)



# Generated at 2022-06-11 21:09:47.009747
# Unit test for function schema
def test_schema():
    from typing import get_type_hints
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json, DataClassJsonMixin

    class T(DataClassJsonMixin):

        @classmethod
        def schema(cls):
            return {k: fields.Field() for k, v in get_type_hints(cls).items()}

    @dataclass_json
    @dataclass
    class C(T):  # type: ignore
        a: str
        b: int
        c: typing.Optional[int] = None
        d: typing.Dict[int, str] = field(default_factory=dict)
        e: typing.Union[int, str]


# Generated at 2022-06-11 21:09:56.322713
# Unit test for function build_type
def test_build_type():
    from marshmallow import fields
    from typing import Optional, List, Union, Dict
    #  dataclasses
    from dataclasses import MISSING
    import datetime
    from dataclasses_json import DataClassJsonMixin, dataclass_json
    @dataclass_json
    @dataclass
    class TestDataclassNested(DataClassJsonMixin):
        field1: int
    @dataclass_json
    @dataclass
    class TestDataclass(DataClassJsonMixin):
        field1: int
        field2: str
        field3: Optional[TestDataclassNested] = None

    @dataclass
    class OtherDataclass:
        field1: int


# Generated at 2022-06-11 21:10:07.690952
# Unit test for function build_type
def test_build_type():
    assert build_type(Optional[List[str]]) == fields.List(fields.Str(), allow_none=True)
    assert build_type(float) == fields.Float()
    assert build_type(List[str]) == fields.List(fields.Str())
    assert build_type(Optional[float]) == fields.Float(allow_none=True)
    assert build_type(Optional[List[float]]) == fields.List(fields.Float(), allow_none=True)
    assert build_type(Mapping[int, Optional[float]]) == fields.Mapping(fields.Float(), allow_none=True)
    assert build_type(Mapping[int, float]) == fields.Mapping(fields.Float())
    assert build_type(Optional[List[int]]) == fields.List(fields.Int(), allow_none=True)

# Generated at 2022-06-11 21:10:15.956136
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class MySchema(SchemaF[int]):
        i = fields.Int()

    assert MySchema().dump(1) == {'i': 1}
    assert MySchema().dump([1]) == [{'i': 1}]
    assert MySchema().dump([1], many=True) == [{'i': 1}]
    assert MySchema().dump([1], many=False) == {'i': 1}
    assert MySchema().dump([1], many=False) == {'i': 1}



# Generated at 2022-06-11 21:10:18.031476
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field.default == MISSING


# Generated at 2022-06-11 21:10:27.348940
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    _tstampfield = _TimestampField()
    assert _tstampfield._serialize(datetime.now(), None, None) is not None
    assert _tstampfield._deserialize(0.0) is not None
    try:
        _tstampfield._serialize(None, None, None)
    except ValidationError as e:
        assert e.messages == {'required': ['Missing data for required field.']}
        assert e.fields == []
    try:
        _tstampfield._deserialize(None)
    except ValidationError as e:
        assert e.messages == {'required': ['Missing data for required field.']}
        assert e.fields == []



# Generated at 2022-06-11 21:11:27.221492
# Unit test for function build_schema
def test_build_schema():
    class MyDataclass(dataclass):
        a: int = field(metadata=dict(dataclasses_json=dict(mm_field=fields.Str)))

    assert build_schema(MyDataclass, None, False, False)

    class MyDataclass2(dataclass):
        a: int = field(metadata=dict(dataclasses_json=dict(mm_field=fields.Str,
                                                           letter_case=str.capitalize)))

    assert build_schema(MyDataclass2, None, False, False)



# Generated at 2022-06-11 21:11:33.339016
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    tf = _TimestampField()
    dt = datetime.fromtimestamp(1524299909)
    assert dt.isoformat() == '2018-04-21T14:25:09'
    assert tf.serialize(dt, None, None) == 1524299909
    assert tf.deserialize(1524299909, None, None) == dt
    assert tf.deserialize(None, None, None) == None
    assert tf.deserialize(None, None, None, required=False) == None
    try:
        tf.deserialize(None, None, None, required=True)
        assert False
    except:
        assert True



# Generated at 2022-06-11 21:11:45.232392
# Unit test for function build_type
def test_build_type():
    from datetime import date
    from typing import Mapping, List
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from enum import Enum as E
    from typing import Dict, List, Optional


    class MyEnum(E):
        RED = 'red'
        BLUE = 'blue'


    @dataclass
    class A:
        date: date = field(metadata={'mm_field': fields.Date})


    @dataclass
    class B:
        enum: MyEnum = field(metadata={'mm_field': EnumField(MyEnum)})


    @dataclass
    class Container:
        a: A
        b: B


    @dataclass_json(mm_mixin=True)
    class C:
        container: Container


   

# Generated at 2022-06-11 21:11:54.258764
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields

    class InnerSchema(SchemaF[float]):
        f = fields.Float()

    class TestSchema(SchemaF[int]):
        i = fields.Int()
        s = fields.Str()
        in_s = fields.Nested(InnerSchema)
        __model__ = int

    class TestMultiSchema(SchemaF[int]):
        i = fields.Int()
        s = fields.Str()
        __model__ = typing.List[int]

    # test single
    schema = TestSchema()
    schema.load({"i": 1, "s": "1", "in_s": {"f": 1.0}}).i == 1

    # test multiple
    schema = TestMultiSchema()

# Generated at 2022-06-11 21:12:00.854896
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class SomeData(typing.NamedTuple):
        id: str

    class SomeDataSchema(SchemaF[SomeData]):
        id = fields.Str()

    assert SomeDataSchema().dump([SomeData(id='abc')]) == \
           [{'id': 'abc'}]



# Generated at 2022-06-11 21:12:12.277658
# Unit test for function schema
def test_schema():
    import sys
    if sys.version_info < (3, 7):
        return

    import dataclasses
    import typing
    import marshmallow

    @dataclasses.dataclass
    class A:
        a: typing.List[int]
        b: int = dataclasses.field(metadata={
            'dataclasses_json': {'mm_field': marshmallow.fields.Int()}
        })
        c: typing.Union[int, str] = dataclasses.field(metadata={
            'dataclasses_json': {'mm_field': marshmallow.fields.Int()}
        })
        d: typing.Optional[typing.List[int]] = dataclasses.field(metadata={
            'dataclasses_json': {'mm_field': marshmallow.fields.Int()}
        })
       

# Generated at 2022-06-11 21:12:22.584730
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class User:
        user_id: int
        user_name: str

    class UserSchema(SchemaF[User]):
        user_id = fields.Int()
        user_name = fields.Str()

    user = User(123, "abc")
    user_schema = UserSchema()
    res = user_schema.dump(user)
    assert res == {"user_id": 123, "user_name": "abc"}


# Generated at 2022-06-11 21:12:30.350506
# Unit test for function build_schema
def test_build_schema():
    # def test_schema(cls):
    class TestInner(NamedTuple):
        inner: str
        inner2: int

    class Test:
        def __init__(self, value, inner=None):
            self.value = value
            self.inner = inner

    a = Test(1)

    dict_schema = build_schema(Test, NamedTuple, False, False)
    encoded = dict_schema().dump(a)
    re_decoded = dict_schema().load(encoded)
    assert re_decoded is not None
    assert re_decoded.value == 1



# Generated at 2022-06-11 21:12:38.423280
# Unit test for function schema
def test_schema():
    @dataclass
    class Person:
        name: str

        @classmethod
        def schema(cls):
            return {'name': fields.Str()}

    @dataclass_json
    @dataclass
    class Event:
        name: str
        people: typing.List[Person]

    assert (hasattr(Event, 'schema'))
    s = Event.schema()
    assert (isinstance(s, Schema))
    assert (isinstance(s._declared_fields['name'], fields.Str))
    assert (isinstance(s._declared_fields['people'], fields.List))



# Generated at 2022-06-11 21:12:49.855874
# Unit test for function schema
def test_schema():
    from .decorators import dataclass_json
    from typing import Optional
    from dataclasses import dataclass
    from marshmallow import fields
    from marshmallow.validate import OneOf

    @dataclass_json
    @dataclass
    class A:
        a: str
        b: int
        c: Optional[int] = None
        d: bool = False
        e: int = 0
        f: Optional[int] = 0
        g: typing.List[str]
        h: typing.Dict[str, int]
        i: Optional[typing.List[str]]
        j: Optional[typing.Dict[str, int]]

    s = schema(A, object(), False)
    assert isinstance(s['e'], fields.Int)

# Generated at 2022-06-11 21:14:08.010912
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField(attribute=None, required=True, primary_key=False)



# Generated at 2022-06-11 21:14:18.793105
# Unit test for function build_type
def test_build_type():
    import typing
    import pytest

    from marshmallow import Schema, fields, MISSING

    from dataclasses_json.schema import build_type

    from marshmallow_oneofschema import OneOfSchema, ONE_OF_SCHEMA_TYPE_FIELD, OneOfSchemaField

    class A:
        pass

    class B:
        pass

    class C:
        pass

    class D:
        pass

    class E:
        pass

    class MySchema(Schema):
        pass

    class UnionOfStringTypes(typing.Union):
        pass

    @dataclass_json
    @dataclass
    class Person:
        firstname: str
        lastname: str
        age: int

    @dataclass_json
    @dataclass
    class Address:
        street: str


# Generated at 2022-06-11 21:14:25.747037
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import Union, List
    from marshmallow import fields
    from dataclasses import dataclass
    from marshmallow_dataclass import class_schema
    @dataclass
    class Data:
        a: List[Union[int, str]]

    schema: SchemaF[Data] = class_schema(Data)
    data = Data([1, 'a'])
    res = schema.dump(data)
    assert res == {'a': [1, 'a']}



# Generated at 2022-06-11 21:14:36.794879
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class Author:
        name: str
        age: int
    @dataclass_json
    @dataclass
    class Book:
        title: str
        author: str
        is_published: bool = False
    @dataclass_json
    @dataclass
    class Book2:
        title: str
        author: Author
        is_published: bool = False

    assert type(build_schema(Book, dataclass_json(), False, False)) == marshmallow.schema.SchemaMeta
    assert type(build_schema(Author, dataclass_json(), False, False)) == marshmallow.schema.SchemaMeta

# Generated at 2022-06-11 21:14:49.691449
# Unit test for function schema
def test_schema():

    @dataclass_json
    @dataclass
    class CustomSchemaMixin(JS):
        mm_field: fields.Field

    @dataclass_json
    @dataclass
    class SchemaField(CustomSchemaMixin):
        s: str
        mm_field: fields.Field = fields.String()

    @dataclass_json
    @dataclass
    class Base(CustomSchemaMixin):
        i: int = 1
        mm_field: fields.Field = fields.Int()

    @dataclass_json
    @dataclass
    class Base2(JS):
        i: int = 1


    @dataclass_json(mm_rename_fields=True)
    @dataclass
    class C(Base):
        mm_field: fields.Field = fields.Int

# Generated at 2022-06-11 21:14:54.385845
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field.deserialize(1422568543.511) == datetime(2015, 2, 15, 2, 43, 2, 63000)
    assert field.deserialize(None) == None
    

# Generated at 2022-06-11 21:15:04.173863
# Unit test for function schema
def test_schema():
    if sys.version_info >= (3, 7):
        from dataclasses import dataclass, field

        from dataclasses_json.core import _MixinHelper

        from marshmallow import fields as mmfields


        class User:  # noqa
            def __init__(self, name, lastname):
                self.name = name
                self.lastname = lastname


        class UserSchema(Schema):
            name = mmfields.String()
            lastname = mmfields.String()


        @dataclass
        class UserDataclass:  # noqa
            name: str
            lastname: str


        @dataclass
        class UserListDataclass:  # noqa
            users: typing.List[User]



# Generated at 2022-06-11 21:15:16.592698
# Unit test for constructor of class _IsoField
def test__IsoField():
    from datetime import datetime
    from marshmallow import fields
    from marshmallow.exceptions import ValidationError
    from marshmallow.utils import isoformat
    from dataclasses_json.marshmallow_ import _IsoField

    datetime_ = datetime(2019, 1, 1, 12, 0)
    isoformat(datetime_)

    isoformat.__globals__['datetime'].isocalendar
    t = _IsoField()
    t._serialize(datetime_, '', '')

    assert t._deserialize(t._serialize(datetime_, '', ''), '', '') == datetime_

    t = _IsoField(required=True)
    with pytest.raises(ValidationError):
        t._serialize(None, '', '')
