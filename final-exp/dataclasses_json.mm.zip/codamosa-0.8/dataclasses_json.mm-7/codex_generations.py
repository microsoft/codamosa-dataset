

# Generated at 2022-06-11 21:06:00.710586
# Unit test for function build_schema
def test_build_schema():
    class mixin:
        pass

    @dataclass_json
    @dataclass
    class GrandParent:
        name: Optional[str]
        surname: str

        @staticmethod
        def abc():
            return "abc"

    @dataclass_json
    @dataclass
    class Parent(GrandParent):
        attribute: int

    @dataclass_json
    @dataclass
    class Child(Parent):
        foo: Optional[str]

    @dataclass_json
    @dataclass
    class Child2(GrandParent):
        def __init__(self, name: str):
            self.name = name

    @dataclass_json
    @dataclass
    class DictClass:
        attribute: Dict[str, int]


# Generated at 2022-06-11 21:06:12.725770
# Unit test for function build_type
def test_build_type():
    from typing import Optional, Union, List
    from marshmallow import Schema, fields as mm_fields
    from dataclasses_json import DataClassJsonMixin as Mixin
    from dataclasses import dataclass, field
    from marshmallow_enum import EnumField as Enum
    from marshmallow import ValidationError as MMValidationError
    from dataclasses_json import ValidationError as DCValidationError
    from enum import Enum as EnumType

    class MyEnum(EnumType):
        foo = 1
        bar = 2

    @dataclass
    class Foo:
        foo: str

    @dataclass
    class FooSchema(Schema):
        foo = fields.Str()

    @dataclass
    class Bar:
        bar: str


# Generated at 2022-06-11 21:06:18.142036
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class A:
        x: int
        y: str
        z: float
    assert schema(A, dataclass_json, True) == {'x': fields.Int(allow_none=False, default=MISSING),
        'y': fields.Str(allow_none=False, default=MISSING), 'z': fields.Float(allow_none=False, default=MISSING)}


# Generated at 2022-06-11 21:06:24.167544
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    def f(v: typing.Any) -> None:
        schema = SchemaF()
        for x in [None, [], 1]:
            schema.dumps(x)
        for x in [None, [], 1]:
            schema.dump(x)
    f(None)



# Generated at 2022-06-11 21:06:35.502181
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    # type: () -> None
    class Foo:
        foo: int

    class FooSchema(SchemaF[Foo]):
        foo = fields.Int(required=True)

        @post_load
        def make_foo(self, data):
            # type: (typing.Dict[str, typing.Any]) -> Foo
            return Foo(**data)
    input_data = b'{"foo": 1}'
    actual = FooSchema().loads(input_data)
    assert actual.foo == 1


# Generated at 2022-06-11 21:06:38.140135
# Unit test for function schema
def test_schema():
    assert 'simple_field' in schema(TestDC, None, False)
    assert 'simple_field' in schema(TestDC, None, True)



# Generated at 2022-06-11 21:06:49.665427
# Unit test for function schema
def test_schema():
    import typing
    import marshmallow

    f = lambda x: x
    g = lambda x: x

    class Foo:
        def __init__(self, x: str, y: str, z: int,
                     p: typing.Optional[str] = 'a',
                     q: typing.Optional[int] = None):
            self.x = x
            self.y = y
            self.z = z
            self.p = p
            self.q = q


# Generated at 2022-06-11 21:06:54.586544
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert isinstance(_TimestampField(), fields.Field)
    assert isinstance(_TimestampField()._serialize(datetime(2020, 7, 27, 14, 52, 45), None, None), float)
    assert isinstance(_TimestampField()._deserialize(1595864165.000001, None, None), datetime)



# Generated at 2022-06-11 21:07:05.963403
# Unit test for function build_type
def test_build_type():
    from dataclasses_json.api import dataclass_json
    from dataclasses import dataclass, field

    class Mixin:
        @classmethod
        def schema(cls) -> SchemaType:
            from marshmallow import Schema, fields

            class _MixinSchema(Schema):
                new_type = fields.Int(default=42)

            return _MixinSchema

    @dataclass_json
    @dataclass
    class DataClass:
        new_type: int
        internal: int = field(metadata={'mm_field': fields.Int})

        @classmethod
        def schema(cls) -> SchemaType:
            from marshmallow import Schema, fields

            class _DataClassSchema(Schema):
                internal = fields.Int()

            return _DataClassSchema

   

# Generated at 2022-06-11 21:07:09.067532
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    now = datetime.now()
    assert now.timestamp() == _TimestampField()._serialize(now, None, None)

    assert None == _TimestampField(required=False)._serialize(None, None, None)



# Generated at 2022-06-11 21:07:28.667009
# Unit test for constructor of class _IsoField
def test__IsoField():
    from datetime import datetime
    current_time = datetime.now().isoformat()
    iso_field = _IsoField(data_key='field')
    assert iso_field.serialize('timestamp', current_time) == current_time
    assert iso_field.deserialize('timestamp', current_time) ==\
        datetime.fromisoformat(current_time)



# Generated at 2022-06-11 21:07:40.140856
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import SchemaF
    import typing
    import datetime

    class User(typing.Generic[A]):
        username: str
        email: str
        created_at: datetime

    class UserSchema(SchemaF[User[A]]):
        username = fields.Str()
        email = fields.Email()
        created_at = fields.DateTime()

    u = User(username='Mick', email='mick@stones.com', created_at=datetime.datetime.now())
    result = UserSchema().dump(u)
    assert result['username'] == 'Mick'
    assert result['email'] == 'mick@stones.com'


# Generated at 2022-06-11 21:07:50.020372
# Unit test for function build_schema
def test_build_schema():
    from datetime import date, datetime

    @dataclass_json
    @dataclass
    class Obj:
        name: str
        age: int
        birth: date
        registered: datetime
        sub: "Obj"
        list_sub: typing.List["Obj"]

    @dataclass
    class Obj2:
        name: str

    schema = build_schema(Obj, dataclass_json, False, False)
    assert issubclass(schema, Schema)
    assert schema.Meta.fields == ('name', 'age', 'birth', 'registered', 'sub',
                                  'list_sub')

    @dataclass_json
    @dataclass
    class Obj3:
        name: str
        age: int
        birth: date
        registered: datetime
        sub: Obj
       

# Generated at 2022-06-11 21:07:53.230893
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class _Test(SchemaF[JsonData]):
        def __init__(self):
            raise NotImplementedError()
    _Test()
    assert True
    pass


# Generated at 2022-06-11 21:08:04.095906
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    loaded_data: TOneOrMulti
    # This is only a test method
    # noinspection PyUnusedLocal
    def load_data(data_: TOneOrMultiEncoded, many: bool = None,
                  partial: bool = None, unknown: str = None) -> TOneOrMulti:
        nonlocal loaded_data
        loaded_data = data_
        return data_

    class DummySchema(SchemaF[A]):
        def __init__(self):
            raise NotImplementedError()

    ds = DummySchema()
    ds.load = load_data
    ds.__init__ = lambda: None
    ds.load(1)
    assert loaded_data == 1
    ds.load([1, 2, 3])

# Generated at 2022-06-11 21:08:17.010788
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class TestClass(object):
        a: str = f'a_test'
        b: int = f'b_test'
        c: str = f'c_test'
        d: int = f'd_test'
        e: str = f'e_test'
        f: str = f'f_test'
        g: int = f'g_test'
        h: str = f'h_test'
        i: Union[int, str]
        j: Optional[int]
        k: Optional[int]

        def __post_init__(self):
            assert isinstance(self.a, str)
            assert isinstance(self.b, int)
            assert isinstance(self.c, str)

# Generated at 2022-06-11 21:08:28.647068
# Unit test for function schema
def test_schema():
    import dataclasses
    class A:
        x: typing.Union[str, typing.Dict[str,int]]
        @dataclasses.dataclass
        class B:
            y: typing.List[typing.Union[int,bool]]
        b: B
        z: bool

    assert not hasattr(A, "__dataclass_json__")
    assert not hasattr(A, "__dataclass_json_module__")

# Generated at 2022-06-11 21:08:39.493483
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import fields
    from marshmallow_dataclass import dataclass

    @dataclass
    class Test:
        a: int
        b: typing.List[str]
    s = SchemaF[Test]({'a': fields.Int(), 'b': fields.List(fields.Str())})
    data = s.dumps(Test(a=1, b=['a', 'b']), many=False)
    assert isinstance(data, str)  # type: ignore
    assert data == '{"a": 1, "b": ["a", "b"]}'
    data = s.dumps(Test(a=1, b=['a', 'b']), many=True)
    assert isinstance(data, str)  # type: ignore

# Generated at 2022-06-11 21:08:51.684189
# Unit test for function build_schema
def test_build_schema():
    global JsonSerializable
    global GlobalConfig

    @dataclass_json
    @dataclass
    class Person:
        __module__ = '__main__'
        name: str
        age: int = field(metadata={'dataclasses_json': {
            'mm_field': fields.Int(validate=lambda n: 0 <= n <= 120)}})

    @dataclass_json
    @dataclass
    class Employee(Person):
        __module__ = '__main__'
        salary: int
        boss: typing.Optional[Person]
        test: typing.List[Person] = field(
            default_factory=lambda: [Person('Jerry', 20), Person('Jerry', 21)])

    schema = build_schema(Employee, JsonSerializable, True, False, GlobalConfig)


# Generated at 2022-06-11 21:08:53.397036
# Unit test for constructor of class _IsoField
def test__IsoField():
    a = _IsoField()


# Generated at 2022-06-11 21:09:46.079879
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    assert isinstance(SchemaF[str].loads('"a"'), str)
    assert isinstance(SchemaF.loads('"a"'), str)
    assert isinstance(SchemaF.loads([]), list)
    assert isinstance(SchemaF.loads({}), dict)
    assert isinstance(SchemaF[dict].loads([]), list)
    assert isinstance(SchemaF[dict].loads('{}'), dict)
    assert isinstance(SchemaF.loads('[{}]'), list)


# Generated at 2022-06-11 21:09:55.706920
# Unit test for function schema
def test_schema():
    from enum import Enum
    from dataclasses import dataclass
    from typing import List, Dict, Optional
    from marshmallow import fields as f
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class MyDataclass:
        """
        Testing
        """
        test: int

    class LetterCase(Enum):
        TEST1 = 1
        TEST2 = 2
        test3 = 3

    @dataclass_json
    @dataclass
    class My2Dataclass:
        """
        Testing
        """
        now: datetime

    @dataclass_json
    @dataclass
    class My3Dataclass:
        """
        Testing
        """
        letter_case: LetterCase


# Generated at 2022-06-11 21:10:04.512631
# Unit test for constructor of class _IsoField
def test__IsoField():
    tst = _IsoField()
    assert tst._deserialize(None, "attr", {}) is None
    # datetime.fromisoformat requires python version >= 3.7
    if sys.version_info >= (3, 7):
        assert tst._serialize(datetime(1970, 1, 1), "attr", {}) == "1970-01-01T00:00:00"
        assert tst._deserialize("1970-01-01T00:00", "attr", {}) == datetime(1970, 1, 1, 0, 0)



# Generated at 2022-06-11 21:10:08.465463
# Unit test for function build_schema
def test_build_schema():

    from marshmallow import Schema, fields
    import dataclasses

    @dataclasses.dataclass
    class A:
        x: int
        y: float = dataclasses.field(default=1.1)

    _: Schema = build_schema(A, "mixin", False, False)



# Generated at 2022-06-11 21:10:13.142482
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields

    class Foo(Schema):
        x = fields.Int()

    f = SchemaF()
    rc = f.load({"x": 1})
    assert rc == ...



# Generated at 2022-06-11 21:10:25.364770
# Unit test for function schema
def test_schema():
    import pytest
    from dataclasses import MISSING
    from dataclasses_json import DataClassJsonMixin, config
    class UserSchema(DataClassJsonMixin):
        def __init__(self):
            self.age = config.Field(
                metadata=config.Meta(mm_field=fields.Int(validate=validate.Range(min=10))))
            self.name = config.Field(metadata=config.Meta(mm_field=fields.String(required=True)))
            self.surname = config.Field(
                metadata=config.Meta(mm_field=fields.String(required=True, validate=validate.Length(min=3))))
            self.email = config.Field(default=MISSING, metadata=config.Meta(mm_field=fields.Email()))
            self.tru

# Generated at 2022-06-11 21:10:35.277241
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    def check_load(cls, s, *args, **kwargs):
        return cls.Schema().load(*args, **kwargs)

    class S:
        class Schema(SchemaF[S]):
            pass

    class A(S):
        pass

    class B(S):
        pass

    class C:
        pass

    class D(C, S):
        pass

    def test_one(cls):
        assert isinstance(check_load(cls, {}, {}), cls)
        assert isinstance(check_load(cls, {}, [{}]), cls)

        assert isinstance(check_load(cls, {}, {}, many=False), cls)
        assert isinstance(check_load(cls, {}, [{}], many=False), cls)



# Generated at 2022-06-11 21:10:40.556860
# Unit test for function build_type
def test_build_type():
    import marshmallow_dataclass as md
    @dataclass_json
    @dataclass
    class SchemaClass:
        field: str = 'hello'

    class SchemaClassMm(md.Schema):
        field = md.field(default='hello', metadata={'data_key': 'field'})

    @dataclass_json
    @dataclass
    class TestClass:
        schema: SchemaClass = SchemaClass()
        schema_list: typing.List[SchemaClass] = field(default_factory=list)
        schema_optional: typing.Optional[SchemaClass] = None
        schema_optional_list: typing.List[typing.Optional[SchemaClass]] = field(
            default_factory=list)
        str1: str = field(default='hello')
        str_

# Generated at 2022-06-11 21:10:45.260598
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class A:
        a: str = "aa"
        b: int = 1

    schema = build_schema(A, None, False, False)
    assert isinstance(schema.a, fields.Field)
    assert isinstance(schema.b, fields.Int)



# Generated at 2022-06-11 21:10:48.318732
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class T(typing.Generic[A]):
        pass

    c = SchemaF[T[int]]()



# Generated at 2022-06-11 21:12:26.159455
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import List
    from marshmallow import Schema, fields

    class TestSchema(SchemaF[int]):
        pass

    TestSchema().dump([1], many=True)
    TestSchema().dump([1], many=False)
    TestSchema().dump(1)
    TestSchema().dump(1, many=True)
    TestSchema().dump(1, many=False)
    TestSchema().dump([1])

    class TestSchema2(SchemaF[List[int]]):
        pass

    TestSchema2().dump([1, 2], many=True)
    TestSchema2().dump([1, 2], many=False)
    TestSchema2().dump([1, 2])
    TestSchema2().dump([1, 2], many=True)

# Generated at 2022-06-11 21:12:33.316366
# Unit test for function build_schema
def test_build_schema():
    optional_union_field = typing.Optional[typing.Union[float, str]]
    default_field = str
    default_field_with_default = typing.Optional[str] = 'test'
    optional_datetime = typing.Optional[datetime]

    @dataclass
    class Person:
        name: typing.Optional[str] = ''
        age: typing.Optional[int] = 0
        address: typing.Optional[str]

    mixin = object
    infer_missing = False

    DataClassSchema = build_schema(Person, mixin, infer_missing, False)
    assert DataClassSchema.__name__ == 'PersonSchema'
    assert hasattr(DataClassSchema, 'make_person')
    assert DataClassSchema.Meta.fields == ('name', 'age', 'address')

# Generated at 2022-06-11 21:12:34.567632
# Unit test for function build_schema
def test_build_schema():
    # TODO
    assert False



# Generated at 2022-06-11 21:12:41.116882
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():

    class TestSchemaF(SchemaF[A]):
        pass

    assert TestSchemaF().loads('{}', many=True) == [{}]
    assert TestSchemaF().loads('[]', many=True) == []
    assert TestSchemaF().loads('{}') == {}
    assert TestSchemaF().loads('[]') == []
    assert TestSchemaF().loads('hello') == 'hello'
    assert TestSchemaF().loads(b'hello') == b'hello'


T = typing.TypeVar('T', bound=Schema)



# Generated at 2022-06-11 21:12:52.200437
# Unit test for function build_type
def test_build_type():
    from typing import List, Mapping
    @dataclass(frozen=False)
    class MyEnum(Enum):
        test1 = 1
        test2 = 2

    @dataclass(frozen=False)
    class OtherType(dataclass_json.DataClassJsonMixin):
        def __init__(self):
            print("Created OtherType")

    @dataclass(frozen=False)
    class InnerType(dataclass_json.DataClassJsonMixin):
        some_dict: Mapping[str, str]

    @dataclass(frozen=False)
    class Type(dataclass_json.DataClassJsonMixin):
        some_list: List[int]
        some_enum: MyEnum
        some_other_type: OtherType
        some_nested

# Generated at 2022-06-11 21:12:53.116661
# Unit test for function build_type
def test_build_type():
    assert 1 == 1


# Generated at 2022-06-11 21:12:59.733517
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import fields  # noqa: F401
    list_field = fields.List(fields.Int)
    list_schema: SchemaF[typing.List[int]] = SchemaF(
        only=["number_list"],
        additional=["additional"],
        unknown=EXCLUDE,
        dump_only=[],
    )
    list_schema.declared_fields["number_list"] = list_field

    class Wrapper:
        def __init__(self, number_list):
            self.number_list = number_list
    the_wrapper = Wrapper([3, 4, 5])
    res = list_schema.load(the_wrapper)
    assert res == [3, 4, 5]



# Generated at 2022-06-11 21:13:09.192930
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():

    class ExampleSchema(SchemaF[Example]):
        s = fields.Str()
        i = fields.Int()
        b = fields.Bool()

    @dataclass_json
    @dataclass
    class Example:
        s: str
        i: int
        b: bool

    example = Example('foo', 4, True)
    schema = ExampleSchema()
    s = schema.dumps(example)
    assert s == '{"s": "foo", "i": 4, "b": true}'
    assert schema.dump(example) == {'s': 'foo', 'i': 4, 'b': True}

# Generated at 2022-06-11 21:13:19.189708
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json(letter_case=LetterCase.CAMEL)
    @dataclass(frozen=True)
    class CamelCase:
        a: int
        b: str


    @dataclass_json(letter_case=LetterCase.PASCAL)
    @dataclass(frozen=True)
    class PascalCase:
        c_d: int
        e_f: str


    @dataclass_json(letter_case=LetterCase.SNAKE)
    @dataclass(frozen=True)
    class SnakeCase:
        g_h: int
        i_j: str


    @dataclass_json(letter_case=LetterCase.KEBAB)
    @dataclass(frozen=True)
    class KebabCase:
        k_l

# Generated at 2022-06-11 21:13:25.904301
# Unit test for constructor of class _IsoField
def test__IsoField():
    try:
        _IsoField()
    except Exception as e:
        return False
    return True

try:
    from dataclasses_json.marshmallow3_types import _serialize_tzinfo, _deserialize_tzinfo
except ImportError:
    def _serialize_tzinfo(value, attr, obj):
        if value is not None:
            return value.tzname()
        else:
            return None

    def _deserialize_tzinfo(tz_name):
        return None


#
# def _debug(obj):
#     print(f'{obj.__class__.__name__} {" - ".join(map(str, obj.__dict__.keys()))}')
#
