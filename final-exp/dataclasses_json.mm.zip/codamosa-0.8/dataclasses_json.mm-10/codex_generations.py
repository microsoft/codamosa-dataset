

# Generated at 2022-06-11 21:05:45.290766
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    """Test for typing.overload-ed method dump"""
    class SimpleS(SchemaF[A]):
        id = fields.Int()
    s = SimpleS(unknown='EXCLUDE')
    data = [{'id': 1}, {'id': 2}]
    result = s.dump(data, many=True)
    assert {'id': 1} in result
    assert {'id': 2} in result

    result = s.dump(data, many=False)
    assert isinstance(result, list)
    assert {'id': 1} in result
    assert {'id': 2} in result

    data = {'id': 1}
    result = s.dump(data, many=True)
    assert {'id': 1} in result

    result = s.dump(data, many=False)
   

# Generated at 2022-06-11 21:05:58.894098
# Unit test for function schema
def test_schema():
    from dataclasses_json import DataClassJsonMixin, config

    class Foo(DataClassJsonMixin):
        firstname: str
        age: int
        family: dict

    class Bar(Foo):
        lastname: str

        def __post_init__(self):
            self.lastname = self.lastname.lower()

    class FooSchema(Schema):
        firstname = fields.String()
        age = fields.Int()
        family = fields.Dict()

        @post_load
        def create_Foo(self, data):
            return Foo(**data)

    class BarSchema(FooSchema):
        lastname = fields.String()

        @post_load
        def create_Bar(self, data):
            return Bar(**data)


# Generated at 2022-06-11 21:06:04.127864
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    dt_naive = datetime.now()
    assert dt_naive.tzinfo is None
    dt_aware = field._deserialize(dt_naive.isoformat())
    assert dt_aware.tzinfo is not None



# Generated at 2022-06-11 21:06:05.022367
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    assert True


# Generated at 2022-06-11 21:06:16.102307
# Unit test for function schema
def test_schema():
    import typing
    from dataclasses_json.mm_schema import Schema
    @dataclass
    class Simple:
        foo: typing.Any
        bar: int
        baz: typing.Optional[typing.Mapping[typing.Any, typing.Any]] = None
    assert Simple.schema().dump({'foo': 1, 'bar': 2, 'baz': {'foo': 2}}) == {'foo': 1, 'bar': 2, 'baz': {'foo': 2}}
    assert Schema(schema(Simple, dataclasses_json.ABCSchema, False)).load({'foo': 1, 'bar': 2, 'baz': {'foo': 2}}) == Simple(1, 2, Simple.baz.default if Simple.baz.default is MISSING else Simple.baz.default())



# Generated at 2022-06-11 21:06:22.964455
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field._serialize(datetime.now()) is not None
    assert field._serialize(12345, attr='a', obj='o') is not None
    assert field._deserialize(12345) is not None
    assert field._deserialize(12345, attr='a', data='d') is not None


# Generated at 2022-06-11 21:06:31.318210
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():  # type: ignore
    t = typing.TypeVar('T')
    class Test:
        pass
    @dataclasses.dataclass
    class MyClass:
        foo: Test
    obj = Test()
    MyClassF = SchemaF[MyClass]
    assert isinstance(MyClassF(), SchemaF)
    my_schema = MyClassF()
    my_schema.fields['foo'] = fields.Field(default_error_messages={
        'required': 'foo is required'
    })
    try:
        my_schema.dump(obj)
    except NotImplementedError:
        pass



# Generated at 2022-06-11 21:06:37.195130
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class S(SchemaF[str]):
        def __init__(self):
            super().__init__(strict=True)

    s = S()
    t = s.dump('hello')
    assert t == 'hello' and isinstance(t, str)

    t = s.dump(['hello', 'world'])
    assert t == ['hello', 'world'] and isinstance(t, list)



# Generated at 2022-06-11 21:06:48.342834
# Unit test for function build_type
def test_build_type():
    from collections import namedtuple
    from typing import NewType
    from marshmallow import fields, Schema
    from marshmallow_enum import EnumField  # type: ignore
    from datetime import datetime
    from dataclasses_json import dataclass_json
    from dataclasses import dataclass
    import uuid
    from decimal import Decimal

    from typing_inspect import is_new_type, is_union_type  # type: ignore
    @dataclass_json
    @dataclass
    class Inner:
        val: int = 1
        val2: str = 'test'

    @dataclass_json
    @dataclass
    class Inner2:
        val: int = 1
        val2: str = 'test'


# Generated at 2022-06-11 21:06:53.943612
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses import dataclass

    @dataclass
    class SchemaF_dump(object):
        x: int

    concrete_schema = SchemaF_dump(SchemaF_dump(1))
    assert isinstance(concrete_schema, SchemaF_dump)
    assert concrete_schema.x == 1


# Generated at 2022-06-11 21:07:15.010449
# Unit test for function schema
def test_schema():
    @dataclass
    class Child:
        l1: typing.List[int] = field(metadata={'dataclasses_json': {
            'mm_field': fields.List(fields.Int())}})
        d1: typing.Dict[str, int] = field(metadata={'dataclasses_json': {
            'mm_field': fields.Dict(fields.Str(), fields.Int())}})
        t1: typing.Tuple[int, str] = field(metadata={'dataclasses_json': {
            'mm_field': fields.Tuple(fields.Int(), fields.Str())}})


# Generated at 2022-06-11 21:07:18.989441
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    assert SchemaF[str].dumps(('toto',)) == '["toto"]'
    assert SchemaF[str].dumps('toto') == '"toto"'



# Generated at 2022-06-11 21:07:30.445425
# Unit test for function schema
def test_schema(): # pylint: disable=unused-variable,too-many-locals,function-redefined
    import marshmallow
    import marshmallow.fields
    import typing
    from enum import Enum

    class Schema:
        a: str
        b: int
        c: typing.Dict[str, float]
        d: typing.Union[str, float]
        e: typing.Tuple[str, int, float]
        f: typing.Optional[str]
        g: int = None
        h: typing.Optional[int] = None
        i: typing.List[int]
        j: int = 0
        k: typing.Optional[float] = None
        l: typing.List[float] = None
        m: None = None
        n: typing.Optional[None] = None
        _o: int = 0


# Generated at 2022-06-11 21:07:41.750344
# Unit test for constructor of class _TimestampField
def test__TimestampField(): # pylint: disable=W0613
    field = _TimestampField()

    # Test serialization
    assert field.serialize(None, None, None) == None
    assert field.serialize(datetime.now(), None, None) == datetime.now().timestamp()
    assert field.serialize(datetime.fromtimestamp(0), None, None) == 0

    assert field._serialize(None, None, None) == None
    assert field._serialize(datetime.now(), None, None) == datetime.now().timestamp()
    assert field._serialize(datetime.fromtimestamp(0), None, None) == 0

    # Test deserialization
    assert field.deserialize(None) == None
    assert field.deserialize(datetime.now().timestamp()) == _timestamp_to_dt

# Generated at 2022-06-11 21:07:52.550669
# Unit test for function build_type
def test_build_type():
    # Build regular fields
    assert type(build_type(str, {}, None, None, None)) == fields.Str
    assert type(build_type(int, {}, None, None, None)) == fields.Int
    assert type(build_type(float, {}, None, None, None)) == fields.Float
    assert type(build_type(bool, {}, None, None, None)) == fields.Bool
    assert type(build_type(dict, {}, None, None, None)) == fields.Dict
    assert type(build_type(list, {}, None, None, None)) == fields.List
    assert type(build_type(typing.List, {}, None, None, None)) == fields.List

# Generated at 2022-06-11 21:08:01.436485
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Member(typing.Generic[A]):
        a: A
        b: typing.List[str]

    class TestSchema(SchemaF[Member[str]]):
        a = fields.Str()
        b = fields.List(fields.Str())

    d = {'a': 'a', 'b': ['b', 'b']}
    TestSchema().load(d)
    TestSchema().load([d])
    TestSchema().loads(json.dumps(d))
    TestSchema().loads(json.dumps([d]))


if sys.version_info >= (3, 7):
    DCSchema = SchemaF  # type: typing.Callable
else:
    DCSchema = Schema  # type: typing.Callable



# Generated at 2022-06-11 21:08:04.614898
# Unit test for function build_type
def test_build_type():
    from dataclasses_json.core import _asdict
    options = {'field_many': False}
    assert build_type(CatchAllVar, options, CatchAllVar, None, None) == fields.Dict

# Generated at 2022-06-11 21:08:12.200568
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    @dataclass
    class Foo():
        x: int = 1
        y: float = 2.0
        z: str = '3'
    sch = schema(Foo, None, True)
    assert sch['x'] is fields.Int
    assert sch['y'] is fields.Float
    assert sch['z'] is fields.Str


# Generated at 2022-06-11 21:08:16.066538
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    s = SchemaF[int]()
    s.dump(42)
    s.dump([42, 43])
    s = SchemaF[str]()
    s.dump('42')
    s.dump(['42', '43'])



# Generated at 2022-06-11 21:08:27.416129
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    TypeA = typing.TypeVar('TypeA')
    class CustomSchema(SchemaF[TypeA]):
        pass
    class CustomSchemaImpl(CustomSchema):
        pass
    custom_schema = CustomSchemaImpl(many=True)
    assert custom_schema.dumps(None, many=True) == "[]"
    assert custom_schema.dumps([], many=True) == "[]"
    assert custom_schema.dumps([None], many=True) == "[null]"
    assert custom_schema.dumps(None, many=None) == "null"
    assert custom_schema.dumps([], many=False) == "null"
    assert custom_schema.dumps([None], many=False) == "null"

# Generated at 2022-06-11 21:08:58.010590
# Unit test for function build_schema
def test_build_schema():
    pass
    # TODO



# Generated at 2022-06-11 21:09:08.751714
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    @dataclass
    class SimplePoint:
        x: float
        y: float
    @dataclass
    class Point:
        x: float
        y: float
    @dataclass
    class PointWithSchema:
        x: int
        y: int
        __schema__ = Point
    @dataclass
    class Inner:
        z: float
    @dataclass
    class OptionalInner:
        z: float = 3.14
    @dataclass
    class Outer:
        str: str
        inner: Optional[Inner]
        optional_inner: OptionalInner
        list_inner: List[Inner]
        dict_inner: Dict[str, Inner]
        dict_list_inner: Dict[str, List[Inner]]


# Generated at 2022-06-11 21:09:17.802716
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    @dataclass
    class Person:
        name: str
        age: int

    @dataclass
    class PersonList:
        people: typing.List[Person]

    @dataclass
    class PersonMap:
        people: typing.Dict[str, Person]

    @dataclass
    class PersonUnion:
        person: typing.Union[Person, PersonList]

    from marshmallow import fields, Schema, post_load
    class PersonSchema(SchemaF[Person]):
        name = fields.Str()
        age = fields.Int()

        @post_load
        def make_person(self, data, **kwargs):
            return Person(**data)

    class PersonUnionSchema(SchemaF[PersonUnion]):
        person = fields.Nested(PersonUnion)


# Generated at 2022-06-11 21:09:28.542856
# Unit test for function build_type
def test_build_type():
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from dataclasses_json import DataClassJsonMixin
    import typing
    import dataclasses
    @dataclasses.dataclass
    class A(DataClassJsonMixin):
        pass
    @dataclasses.dataclass
    class B(DataClassJsonMixin):
        pass
    @dataclasses.dataclass
    class C(DataClassJsonMixin):
        pass
    @dataclasses.dataclass
    class En(Enum):
        a = 1
        b = 2
    @dataclasses.dataclass
    class D(DataClassJsonMixin):
        a: int
        b: typing.Optional[str]
        c: typing.Mapping[str, A]

# Generated at 2022-06-11 21:09:39.205815
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_field = _IsoField()
    # test _deserialize
    assert iso_field._deserialize("2020-10-05T09:12:55.001000") == datetime(2020, 10, 5, 9, 12, 55, 1000)
    iso_field.required = False
    assert iso_field._deserialize(None) == None
    # test _serialize
    assert iso_field._serialize(datetime(2020, 10, 5, 9, 12, 55, 1000)) == "2020-10-05T09:12:55.001000"
    iso_field.required = False
    assert iso_field._serialize(None) == None


# Generated at 2022-06-11 21:09:42.725860
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow.exceptions import MarshmallowError
    from marshmallow import Schema
    from typing import Any


    class MySchema(Schema):
        field: Any


    assert MySchema.SchemaF.loads("")


# Generated at 2022-06-11 21:09:49.351252
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class TestSchema(SchemaF[int]):
        a = fields.Int()

    x = TestSchema().dump(5)  # TestSchema[int]
    assert isinstance(x, dict)
    assert x['a'] == 5
    y = TestSchema().dump([5])
    assert isinstance(y, list)
    assert len(y) == 1
    assert y[0]['a'] == 5
    z = TestSchema().dump([5, 6, 7])
    assert isinstance(z, list)
    assert len(z) == 3
    for a, b in zip(z, [5, 6, 7]):
        assert a['a'] == b


# Generated at 2022-06-11 21:09:57.507147
# Unit test for function schema
def test_schema():
    import marshmallow
    
    class A(SchemaType):
        test: str
    
    class B(SchemaType):
        test: str

    class C(SchemaType):
        test: str
    
    class D(SchemaType):
        test: str
    
    schema_a = schema(A, None, True)
    schema_b = schema(B, None, True)
    schema_c = schema(C, None, True)
    schema_d = schema(D, None, True)
    
    assert schema_a['test'] == schema_b['test']
    assert schema_a['test'] == schema_c['test']
    assert schema_a['test'] == schema_d['test']



# Generated at 2022-06-11 21:10:08.999089
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    json_ = serializer.dumps({'foo': 'bar'})
    # assert json_ == ...


# Generated at 2022-06-11 21:10:13.496640
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._serialize(datetime.utcnow(), None, None) is not None
    assert _IsoField()._deserialize(datetime.utcnow().isoformat(), None, None) is not None


# Generated at 2022-06-11 21:11:25.836082
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField(attribute='date-time')._deserialize('2020-02-20T09:30:22')
    assert _IsoField(attribute='date-time')._serialize(datetime.now())


# Generated at 2022-06-11 21:11:36.581874
# Unit test for function schema
def test_schema():
    import marshmallow as mm
    import typing
    import dataclasses
    @dataclasses.dataclass
    class A:
        x: int
        y: typing.Optional[int]
    @dataclasses.dataclass
    class B:
        l: typing.List[int]
        d: typing.Dict[str,int]
    @dataclasses.dataclass
    class C:
        l: typing.List[A]
        d: A
        c: B

    assert isinstance(schema(A, dataclasses, False)['y'], mm.fields.Integer)
    assert isinstance(schema(A, dataclasses, False)['y'], mm.fields.Integer)

# Generated at 2022-06-11 21:11:43.109143
# Unit test for function build_type
def test_build_type():
    from dataclasses_json.unchecked_cast import _UncheckedType  # type: ignore
    from typing import List, Optional, Union, Any, Mapping, MutableMapping
    import pytest
    from marshmallow import fields
    from marshmallow.exceptions import ValidationError
    from marshmallow_enum import EnumField  # type: ignore
    from dataclasses_json.utils import CatchAllVar

    class ClassWithInner(object):
        @staticmethod
        def schema():
            class Inner(Schema):
                pass

            return Inner

    class InnerSerialize(Schema):
        class Meta:
            fields = ("inner", "field")

        inner = fields.Nested(ClassWithInner.schema(), dump_only=True)
        field = fields.Str()


# Generated at 2022-06-11 21:11:46.979340
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class TestSchema(SchemaF[int]):
        pass

    assert TestSchema().loads('"1"', many=False) == 1
    assert TestSchema().loads('"1"', many=True) == [1]



# Generated at 2022-06-11 21:12:00.489557
# Unit test for constructor of class _IsoField
def test__IsoField():
    from datetime import timezone
    from datetime import time
    from time import timezone as tz
    from dataclasses_json import dataclass_json
    from dataclasses_json.utils import dataclass_to_schema as d2


# Generated at 2022-06-11 21:12:11.785753
# Unit test for function build_type
def test_build_type():

    import marshmallow as mm

    class MySchema(Schema):
        name = mm.fields.String()

    class MyDataclass(object):
        def __init__(self, name):
            self.name = name

    type_ = build_type(MyDataclass, {}, None, None, None)
    assert isinstance(type_, mm.fields.Nested)
    assert type_.schema == MyDataclass.schema


    type_ = build_type(MySchema, {}, None, None, None)
    assert isinstance(type_, mm.fields.Nested)
    assert type_.schema == MySchema


    type_ = build_type(str, {}, None, None, None)
    assert isinstance(type_, mm.fields.String)



# Generated at 2022-06-11 21:12:14.576357
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Foo(SchemaF[str]):
        pass

    assert Foo().load({'bar': 42}) == 'bar'

    assert Foo().load({'bar': 42}, many=True) == ['bar']



# Generated at 2022-06-11 21:12:26.544955
# Unit test for function build_type
def test_build_type():
    import marshmallow.exceptions as exceptions

    def type_eq(t1, t2):
        if sys.version_info < (3, 7):
            return t1 == t2
        else:
            return t1 == t2 or (is_dataclass(t1) and is_dataclass(t2) and
                                t1.__name__ == t2.__name__)

    @dataclass_json
    @dataclass
    class WithSchema:
        pass

    @dataclass_json
    @dataclass
    class WithoutSchema:
        pass

    @dataclass
    class MixWithSchema:
        pass

    MixWithSchema.schema()

    @dataclass
    class MixWithoutSchema:
        pass


# Generated at 2022-06-11 21:12:27.916969
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()
    assert _TimestampField(required=False)


# Generated at 2022-06-11 21:12:36.229627
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    @dataclass_json
    @dataclass
    class Data:
        age: int

    schema: SchemaF[Data] = SchemaF[Data]()

    assert schema.load([{"age": 12}, {"age": 11}], many=True) == [Data(age=12), Data(age=11)]
    assert schema.load({"age": 12}) == Data(age=12)
    assert schema.load({"age": 12}, many=False) == Data(age=12)  # type: ignore
    assert schema.load({"age": 12}, many=True) == [Data(age=12)]  # type: ignore

