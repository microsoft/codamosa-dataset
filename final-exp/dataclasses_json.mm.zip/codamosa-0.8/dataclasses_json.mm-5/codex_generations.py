

# Generated at 2022-06-11 21:05:39.107364
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema = SchemaF[int]()
    assert schema.dump(1) == 1
    assert schema.dump([1]) == [1]



# Generated at 2022-06-11 21:05:50.587167
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass, asdict
    from marshmallow import pre_dump, post_dump, pre_load, post_load
    from dataclasses_json import mm_field, dataclass_json

    @dataclass_json
    @dataclass
    class DataClass:
        a: str
        b: int
        c: bool = False
        d: typing.List[int] = field(default_factory=list)
        e: typing.List[int] = field(default_factory=lambda: [])
        f: typing.List[int] = field(default_factory=lambda: [1])
        g: typing.Dict[str, int] = field(default_factory=dict)

# Generated at 2022-06-11 21:05:55.596284
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class Test:
        a: str
        b: int

    a = build_schema(Test, mixin=dict, infer_missing=True, partial=True)
    print(a)



# Generated at 2022-06-11 21:06:04.452658
# Unit test for function build_schema
def test_build_schema():
    import pytest
    import dataclasses_json as dcj
    from marshmallow import fields
    fixtures = [
        ('Dataclass', {'a': fields.Str, 'b': fields.Int}),
        ('Dataclass2', {'a': fields.Str, 'b': fields.Int}),
        ('Dataclass3', {'a': fields.Str, 'b': fields.Int})
    ]
    @dataclass_json
    @dataclass
    class Dataclass:
        a: str
        b: int
    @dataclass_json
    @dataclass
    class Dataclass2:
        a: str
        b: int
    @dataclass_json
    @dataclass
    class Dataclass3:
        a: str
        b: int

# Generated at 2022-06-11 21:06:15.894449
# Unit test for function schema
def test_schema():
    import uuid
    from datetime import timezone, timedelta
    import dataclasses_json
    @dataclasses_json.dataclass_json
    @dataclasses.dataclass
    class A:
        x: typing.Optional[str]
        y: uuid.UUID = dataclasses.field(default_factory=uuid.uuid4)
        z: typing.Union[str, datetime.datetime] = dataclasses.field(default_factory=datetime.now)
    @dataclasses_json.dataclass_json
    @dataclasses.dataclass
    class B:
        id: int
        a: A = dataclasses.field(default_factory=A)
        b: typing.Dict[str, typing.Union[bool, int]] = dataclasses

# Generated at 2022-06-11 21:06:28.436003
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Schema(SchemaF[int]):
        pass
    raw_data = [{'field': '1'}, {'field': 'a'}]
    data = Schema().load(raw_data)
    assert data == [1, None]


if sys.version_info >= (3, 8):

    class SchemaF8(Schema[A], typing.Generic[A]):
        """Lift Schema into a type constructor"""

        def __init__(self, *args, **kwargs):
            """
            Raises exception because this class should not be inherited.
            This class is helper only.
            """

            super().__init__(*args, **kwargs)
            raise NotImplementedError()


# Generated at 2022-06-11 21:06:33.878822
# Unit test for function build_type
def test_build_type():
    import dataclasses as dc
    import marshmallow as mm

    @dc.dataclass
    class Test:
        x: int

    s = Schema(
        mm_field=mm.fields.Int(),
        mm_unknown=mm.fields.Int())

    Test.schema = s

    @dc.dataclass
    class Test2:
        foo: typing.Optional[Test]

    t2 = Test2(Test(x=1))
    dump_data = t2.schema.dump(t2)
    assert dump_data == {'foo': {'x': 1}}

    load_data = t2.schema.load({'foo': {'x': 1}})
    assert load_data == Test2(Test(x=1))


# Generated at 2022-06-11 21:06:41.727245
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import Any
    from marshmallow import Schema

    class A(Schema):
        pass

    a: A
    a.dump([1, 2, 3], many=False)
    a.dump([1, 2, 3])
    a.dump([1, 2, 3], many=True)

    a.dump(1)
    a.dump(1, many=True)

    x: Any = ...
    x = a.dump([1, 2, 3], many=True)
    x = a.dump([1, 2, 3])



# Generated at 2022-06-11 21:06:50.448754
# Unit test for function build_type
def test_build_type():
    assert repr(build_type(str, {}, dataclasses_json.DataClassJsonMixin, dataclasses.field(str), "test")) == "<Field(attribute=test, default=missing, default_setter=<function set_value_from_default at 0x7f0c4d9b9168>, error_messages={'required': 'Missing data for required field.'}, load_from=None, missing=missing, partial=False, validate=None, required=False)>"

# Generated at 2022-06-11 21:06:58.421780
# Unit test for function schema
def test_schema():
    from dataclasses_json.mm_schema import schema
    from dataclasses_json.mm_schema import SchemaType
    from typing import TypeVar, Optional, Union
    from enum import Enum
    from dataclasses import dataclass
    from marshmallow import Schema, fields
    T = TypeVar('T')
    class _BaseSchema(Schema, typing.Generic[T]):
        """Lift Schema into a type constructor"""

    @dataclass
    class Person:
        name: str
        email: str
        class Meta:
            jit = True

    # @dataclass
    # class Animal:
    #     name: str
    #     email: str
    #     class Meta:
    #         jit = True


# Generated at 2022-06-11 21:07:18.372413
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    expected_type_info = typing.get_type_hints(
        typing.cast(type, SchemaF).loads)
    assert expected_type_info == typing.get_type_hints(
        SchemaF[CatchAllVar].loads)



# Generated at 2022-06-11 21:07:31.042864
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField.__name__ == "_TimestampField"
    assert _TimestampField.__module__ == "dataclasses_json.marshmallow"

    assert _TimestampField()._serialize(None, None, None) is None
    assert _TimestampField(required=False)._serialize(None, None, None) is None
    assert _TimestampField(required=True)._serialize(None, None, None) is None

    test_dt = datetime(year=2020, month=1, day=1)
    assert _TimestampField()._serialize(test_dt, None, None) == 1577836800.0

    assert _TimestampField()._deserialize(None, None, None) is None
    assert _TimestampField(required=False)._deserialize(None, None, None)

# Generated at 2022-06-11 21:07:34.243763
# Unit test for function schema
def test_schema():
    import inspect
    args, _, _, defaults = inspect.getargspec(schema)
    assert len(args) == 4
    assert defaults == (False,)

# Generated at 2022-06-11 21:07:45.201643
# Unit test for constructor of class _IsoField
def test__IsoField():
    f = _IsoField()
    assert f._serialize(datetime.now(), 'attr', 'obj')
    assert f._deserialize('2019-01-15T12:14:32', 'attr', 'data')

# Marshmallow marshmallow_dataclass
# Allows users to pass in a schema or a schema class that is used for the fields
# of the dataclass
#
# For example:
#
# @dataclass_json
# @dataclass
# class Local:
#     val: int
#     val2: int
#
# @dataclass_json
# @dataclass
# class LocalSchema(Schema):
#     val: int
#     val2: int
#
# @dataclass_json
# @dataclass
# class Outer:
#     val: int


# Generated at 2022-06-11 21:07:46.520942
# Unit test for function build_schema
def test_build_schema():
    # TODO Add tests
    pass



# Generated at 2022-06-11 21:07:55.661650
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():  # type: ignore
    class S(Schema):
        name = fields.Str()

    elem = S.dump([{'name': 'name'}], many=True)
    assert elem == [{'name': 'name'}]
    elem = S.dump(S(many=True).load([{'name': 'name'}]))
    assert elem == [{'name': 'name'}]
    elem = S.dump(S(many=False).load({'name': 'name'}))
    assert elem == {'name': 'name'}
    elem = S.dump({'name': 'name'}, many=None)
    assert elem == {'name': 'name'}


# Generated at 2022-06-11 21:07:58.077216
# Unit test for function build_type
def test_build_type():
    result = build_type(str, {}, object, 'field', 'cls')
    assert result == fields.Str



# Generated at 2022-06-11 21:08:06.007085
# Unit test for function build_type
def test_build_type():
    from marshmallow import fields
    import dataclasses
    import typing
    from typing import Tuple, Union, List
    import datetime
    from dataclasses_json.utils import _is_collection
    from dataclasses_json.mm_field import build_type
    options = {}
    mixin = dataclasses.json.DataClassJsonMixin
    class dummy():
        name = None
        type = None
    field = dummy()
    cls = dummy()

    @dataclasses.dataclass
    class A(mixin):
        x: typing.Tuple[int, int]

    A.schema()
    field.name = 'x'
    field.type = typing.Tuple[int, int]
    type_ = typing.Tuple[int, int]

# Generated at 2022-06-11 21:08:14.437446
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields

    class MySchema(Schema):
        a = fields.Str(required=True)


    class MySchemaF(SchemaF[MySchema.__model__]):
        pass


    ms = MySchemaF()
    res = ms.dumps([MySchema(a='a'), MySchema(a='b')])
    assert res == '[{"a": "a"}, {"a": "b"}]'



# Generated at 2022-06-11 21:08:25.512128
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass, fields as dc_fields
    from dataclasses_json import DataClassJsonMixin, config

    @dataclass
    class DemoSchema(DataClassJsonMixin):
        a: int
        b: typing.List[int]
        any_field: Any
        Optional_field: typing.Optional[Any]
        subclass_field: typing.Optional[subclass_field]
        subclass_field2: subclass_field

    @dataclass
    class subclass_field:
        a: int
        b: typing.List[int]


# Generated at 2022-06-11 21:08:58.489179
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from .test_app_models import Order


    class OrderSchema(SchemaF[Order]):
        class Meta:
            strict = True

        name = fields.Str()


    # type: typing.List[Order]
    orders = [Order('hi'), Order('yo')]
    expected_result = [{'name': 'hi'}, {'name': 'yo'}]
    result = OrderSchema().dump(orders)
    assert result == expected_result
    # type: Order
    order = Order('hi')
    expected_result = {'name': 'hi'}
    result = OrderSchema().dump(order)
    assert result == expected_result



# Generated at 2022-06-11 21:09:08.928630
# Unit test for function build_schema
def test_build_schema():
    class Example(MappingMixin):
        attr1: int = field(default=1)
        attr2: int = field(default=2)
        attr3: int = field(default=3)
    class ExampleConfig:
        dataclass_json = {
            'mm_field': fields.Integer(required=True),
            'letter_case': 'camel'
        }
    Example.dataclass_json_config = ExampleConfig

    test_schema = build_schema(Example, MappingMixin, infer_missing=False, partial=False)
    test_schema.make_example()
    test_schema.dump(Example())
    test_schema.dumps(Example())

if __name__ == '__main__':
    test_build_schema()

# Generated at 2022-06-11 21:09:17.952863
# Unit test for function build_schema
def test_build_schema():
    import uuid
    import datetime as dt
    import enum
    import dataclasses
    import typing
    import marshmallow
    import dataclasses_json
    import marshmallow_dataclass
    from datetime import datetime

    class EnumTest(enum.Enum):
        A = 'A'
        B = 'B'
        C = 'C'

    @dataclasses.dataclass
    class T:
        a: int
        b: typing.Optional[int]
        c: typing.Optional[int] = dataclasses.field(default=None)
        d: typing.Any = dataclasses.field(default=None)
        e: typing.Optional[int] = dataclasses.field(default=None)
        f: typing.Tuple[int, int]
        g: typing.List

# Generated at 2022-06-11 21:09:28.664372
# Unit test for function build_schema
def test_build_schema():
    import json
    import datetime
    import dataclasses

    @dataclasses.dataclass
    class MyType:
        foo: str
        bar: int = 5
        baz: typing.Optional[str] = typing.Optional[str](None)
        # This is not part of the dataclass, but part of the schema,
        # just to show that we can include it in the schema
        qux: str = "hello"
        a: int = dataclasses.field(
            metadata={
                "dataclasses_json": {
                    "mm_field": fields.Email()
                }
            })
        b: str = dataclasses.field(
            metadata={
                "dataclasses_json": {
                    "mm_field": fields.Str(allow_empty=False)
                }
            })
       

# Generated at 2022-06-11 21:09:40.048731
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field._deserialize(None, None, None) is None
    assert field._deserialize(1234567890, None, None) == datetime(2009, 2, 13, 23, 31, 30)
    assert field._serialize(None, None, None) is None
    assert field._serialize(datetime(2009, 2, 13, 23, 31, 30), None, None) == 1234567890

# define base dict to set default values for internal variables
_BASE_CONFIG = {
    "ignore_decorators": [],
    "handle_inheritance": False,
    "union_strategy": "fallback",
    "undefined": CatchAllVar(ValidationError),
}



# Generated at 2022-06-11 21:09:41.231902
# Unit test for function build_schema
def test_build_schema():
    assert True

# Generated at 2022-06-11 21:09:49.063546
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Test(typing.NamedTuple):
        foo: str
        bar: int

    s = SchemaF[Test]()  # type: ignore
    assert s.dump([Test(foo='a', bar=1)]) == [{'foo': 'a', 'bar': 1}]
    assert s.dump(Test(foo='a', bar=1)) == {'foo': 'a', 'bar': 1}


# Generated at 2022-06-11 21:09:51.914176
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    _TimestampField(required=True)._deserialize(
        _TimestampField(required=True)._serialize(datetime.now())
    )



# Generated at 2022-06-11 21:10:04.663123
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json.mm_converter import _asdict
    from marshmallow import Schema

    @dataclass
    class I:
        a: int
        b: str

    @dataclass
    class Test(Schema):
        i: I
        j: typing.Dict[str, typing.List[int]]

    i_field = build_type(I, {}, Schema, Test.__annotations__['i'], Test)
    assert i_field.__class__ == fields.Nested

    j_field = build_type(Test.__annotations__['j'], {}, Schema,
                         Test.__annotations__['j'], Test)
    assert j_field.__class__ == fields.Mapping

# Generated at 2022-06-11 21:10:15.521067
# Unit test for function schema
def test_schema():
    from typing import Optional
    from dataclasses import dataclass

    @dataclass
    class A:
        b: Optional[int] = field(default=None, metadata={'dataclasses_json': {'mm_field': fields.Int(allow_none=True)}})

    assert A.__dataclass_fields__['b'].type == Optional[int]
    assert A.__dataclass_fields__['b'].metadata['dataclasses_json']['mm_field'].allow_none is True
    assert schema(A, object, False)['b'].allow_none is True



# Generated at 2022-06-11 21:11:28.434797
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # No flake8 check because we are testing the typing.overload decorators
    from typing import Dict, List, Optional
    from dataclasses import dataclass
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError

    @dataclass
    class Test:
        some_int: int

    schema = Schema.from_dataclass(Test)
    assert isinstance(schema, SchemaF)
    instance = Test(some_int=1)
    dict_ = {"some_int": 1}
    assert schema.dump(instance) == dict_
    assert schema.dump([instance]) == [dict_]

    # Test if correct error is raised for wrong usage
    with pytest.raises(ValidationError):
        schema.dump("SomeString")


# Generated at 2022-06-11 21:11:37.928398
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    def run():
        class Person(SchemaF[Person]):
            name = fields.Str()
            age = fields.Int()

        p = Person().load({"name": "John", "age": "42"})

    run()


# Generated at 2022-06-11 21:11:40.301198
# Unit test for constructor of class _IsoField
def test__IsoField():
    i = _IsoField()
    assert i.__class__ == _IsoField



# Generated at 2022-06-11 21:11:50.546811
# Unit test for function build_schema
def test_build_schema():
    from datetime import datetime
    from uuid import uuid4
    from decimal import Decimal
    from typing import Optional, Union


    @dataclass_json
    @dataclass
    class A:
        a: str
        b: 'A'
        c: UUID
        d: Decimal
        e: datetime

    @dataclass_json
    @dataclass
    class B:
        a: str
        b: 'B'
        c: UUID
        d: Decimal
        e: datetime

    @dataclass_json
    @dataclass
    class C:
        a: str
        b: 'C'
        c: UUID
        d: Decimal
        e: datetime


# Generated at 2022-06-11 21:11:54.285888
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    value = 1582671200
    assert value == field.serialize(datetime.fromtimestamp(value))
    assert datetime.fromtimestamp(value) == field.deserialize(value)



# Generated at 2022-06-11 21:12:05.574521
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass, field
    from dataclasses_json import dataclass_json
    from marshmallow import ValidationError

    @dataclass_json
    @dataclass
    class Person:
        name: str
        age: int = field(metadata={"dataclasses_json": {"mm_field": fields.UUID}})
        lname: str = field(metadata={"dataclasses_json": {"letter_case": "upper"}})

    p_schema = schema(Person, dataclasses_json.DataClassJsonMixin, False)

    assert p_schema == {"name": fields.Str(required=True),
                        "age": fields.UUID(),
                        "lname": fields.Str(required=True, data_key="LNAME")}


# Generated at 2022-06-11 21:12:07.924425
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Foo(SchemaF):
        pass
    instance = Foo()
    b = instance.loads(b"1")
    assert b == 1



# Generated at 2022-06-11 21:12:11.545185
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class A:
        a: str

    assert A.schema().Meta.fields == ('a',)


# Module level API



# Generated at 2022-06-11 21:12:25.823110
# Unit test for function schema
def test_schema():
    import unittest.mock

    import marshmallow.fields

    from dataclasses_json.core import (
        _T_ORIGIN, _get_type_origin, _user_overrides_or_exts)

    new_type = typing.NewType('SomeNewType', str)
    cls = unittest.mock.Mock()
    cls.__name__ = 'MockedClass'
    field = unittest.mock.Mock()
    field.name = 'mocked_field'
    field.type = int
    assert {
        field.name: marshmallow.fields.Int(missing=None, allow_none=True),
    } == schema(cls, unittest.mock.Mock, None)

    field = unittest.mock.Mock()
    field

# Generated at 2022-06-11 21:12:33.127912
# Unit test for function schema
def test_schema():
    from marshmallow import fields
    from dataclasses import dataclass, asdict
    from typing import List, Dict, Set, Optional, Union

    @dataclass
    class A:
        a: int
        b: str
        c: Optional[float]

    class B(A):
        pass
    class C(B):
        pass
    class D(C):
        pass

    @dataclass
    class E:
        d: List[A]
        e: Set[A]
        f: Dict[str, A]
        g: str
        h: Optional[str]
        i: Union[str, int, A]
        j: Optional[Union[str, int, A]]

    # Test that if the field is subclass of dataclasses_json.NewType we get the dataclasses_json.New

# Generated at 2022-06-11 21:14:49.345053
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    @dataclass_json
    @dataclass
    class Person:
        name: str
        age: int

    class PersonSerializer(SchemaF[Person]):
        class Meta:
            unknown = EXCLUDE

        name = fields.Str()
        age = fields.Int()

    person = Person(name='John', age=25)
    assert PersonSerializer().load(
        PersonSerializer().dump(person)
    ) == person

    people = [Person(name='John', age=25), Person(name='Jane', age=23)]
    assert PersonSerializer().load(
        PersonSerializer().dump(people)
    ) == people



# Generated at 2022-06-11 21:14:53.822839
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.utcnow(), None, None)
    assert _TimestampField()._deserialize(datetime.utcnow().timestamp(), None, None)



# Generated at 2022-06-11 21:14:54.519592
# Unit test for function build_schema
def test_build_schema():
    # TODO write tests
    pass



# Generated at 2022-06-11 21:15:01.174297
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    l = [{'a': 1, 'b': 2}, {'b': 3, 'a': 4}]

    class MySchema(SchemaF[A]):
        b = fields.Int()

    s = MySchema()
    assert s.load(l) == [{'a': 1, 'b': 2}, {'a': 4, 'b': 3}]



# Generated at 2022-06-11 21:15:13.391561
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass

    @dataclass
    class A:
        a: str
        b: int = 3


    @dataclass
    class B:
        a: str
        b: A
        c: typing.Optional[str] = "test"
        d: typing.Optional[int] = None
        e: typing.Optional[A] = None
        f: typing.Optional[A] = A("test", 0)
        g: typing.Union[int, str]
        h: typing.Union[int, str, A]
        i: typing.Union[None, str, A]

    SchemaB = build_schema(B, "a", False, True)

    assert B.schema() == SchemaB