

# Generated at 2022-06-11 21:05:45.591381
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Person(typing.Generic[A]):
        def __init__(self, name: str, age: int):
            self.name = name
            self.age = age

    tc = typing.TypeVar("tc")
    t = typing.TypeVar("t")
    class PersonSchema(SchemaF[A]):
        name = fields.Str()
        age = fields.Int()

    p1 = Person[str]("John", 44)
    p2 = Person[str]("Jane", 38)
    p3 = Person[int]("Jane", 38)
    p4 = Person[int](44, "Jane")

    ps1 = PersonSchema()
    assert ps1.dump(p1) == {"name": "John", "age": 44}

# Generated at 2022-06-11 21:05:59.165374
# Unit test for constructor of class _IsoField
def test__IsoField():
    sample_date = "2020-07-10"
    iso_field = _IsoField(required=False)
    serialized_date = iso_field._serialize(datetime.fromisoformat(sample_date), "attr", "obj")
    assert serialized_date == sample_date
    if sys.version_info < (3, 7):
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            # cause all warnings to always be triggered
            serialized_date = iso_field._serialize(datetime.fromisoformat(sample_date), "attr", "obj")
            # verify some things
            assert len(w) == 1
            assert issubclass(w[-1].category, DeprecationWarning)

# Generated at 2022-06-11 21:06:03.161478
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str
        c: str


    assert isinstance(build_schema(A, typing.Any, False, False), type)



# Generated at 2022-06-11 21:06:15.079191
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class Reader(DataClassJsonMixin):
        uuid: UUID

    @dataclass
    class Book(DataClassJsonMixin):
        title: str
        uuid: UUID
        published: datetime

    @dataclass
    class Library(DataClassJsonMixin):
        uuid: UUID
        name: str
        city: str
        books: typing.List[Book]

    @dataclass
    class Store(DataClassJsonMixin):
        name: str
        books: typing.List[Book]

    assert schema(Reader, DataClassJsonMixin, False) == {'uuid': fields.UUID(missing='extract_missing')}


# Generated at 2022-06-11 21:06:27.365869
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class CW(typing.Generic[A]):
        def __init__(self, w: A) -> None:
            self.w = w

    class InnerSchema(SchemaF[CW]):
        w = fields.Int()

    class InnerNestedSchema(SchemaF[CW[typing.List[A]]]):
        w = fields.List(fields.Int())

    class OuterSchema(SchemaF[CW[A]]):
        @post_load
        def wrap(self, data):
            return CW(data)

    @_user_overrides_or_exts('load')
    class InnerNestedSchemaExtended(InnerNestedSchema):
        pass

    class CWSchema(SchemaF[A]):
        x = fields.Str()

    assert InnerSchema().load

# Generated at 2022-06-11 21:06:30.226895
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    @dataclass
    class A:
        i: int

    def func(v: Schema) -> typing.List[A]:
        return v.load([{'i': 1}])

    def func2(v: Schema) -> A:
        return v.load({'i': 1})

    _ = func(SchemaF[A]())
    _ = func2(SchemaF[A]())



# Generated at 2022-06-11 21:06:31.063079
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()


# Generated at 2022-06-11 21:06:40.160530
# Unit test for function schema
def test_schema():
    import dataclasses
    import typing
    from marshmallow import EXCLUDE
    @dataclasses.dataclass
    class Person:
        name: str
        age: int
    # We can't use `schema` directly because the `schema` method expects
    # the first argument to be the dataclass. We need to call `schema`
    # using the `schema` method of a dataclass.

# Generated at 2022-06-11 21:06:50.106995
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class Test(DataClassJsonMixin):
        v: int

    assert SchemaF[Test].dumps(Test(v=1)) == '{"v": 1}'
    assert SchemaF[Test].dumps([Test(v=1), Test(v=2)]) == ('[{"v": 1}, {"v": 2}]')
    assert SchemaF[Test].dumps(Test(v=1), many=False) == '{"v": 1}'
    assert SchemaF[Test].dumps([Test(v=1), Test(v=2)], many=True) == ('[{"v": 1}, {"v": 2}]')

# Generated at 2022-06-11 21:06:52.477960
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Test(SchemaF[str]):
        pass


# Generated at 2022-06-11 21:07:09.097003
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():  # type: ignore
    # This needs to be defined in order to test the function
    class MySerializableClass:  # type: ignore
        pass
    s = SchemaF[MySerializableClass]()  # type: ignore
    s.dumps([MySerializableClass()])  # type: ignore



# Generated at 2022-06-11 21:07:15.312254
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclass_json
    class Point:
        x: int
        y: int

    @dataclass_json(encoder=ExtendedEncoder)
    class PointList(list):
        x: int
        y: int

    pl = PointList([Point(1, 2), Point(2, 3)], 3, 4)
    pl_schema: SchemaF[PointList] = PointList.Schema()
    print(pl_schema.dump(pl))
    print(pl_schema.dump(pl, many=True))
    print(pl_schema.dump([pl, pl]))
    print(pl_schema.dump([pl, pl], many=True))



# Generated at 2022-06-11 21:07:28.033025
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # Test with not custom class
    class TestSchema(SchemaF[str]):
        class Meta:
            ordered = True

        name = fields.Str()

    schema = TestSchema()
    one_obj = schema.dump("test")
    assert isinstance(one_obj, dict)
    assert isinstance(one_obj["name"], str)
    assert one_obj["name"] == "test"
    multi_obj = schema.dump(["test", "test2"])
    assert isinstance(multi_obj, list)
    assert isinstance(multi_obj[0]["name"], str)
    assert multi_obj[0]["name"] == "test"
    assert multi_obj[1]["name"] == "test2"
    # Test with custom class

# Generated at 2022-06-11 21:07:30.025954
# Unit test for function build_type
def test_build_type():
    assert build_type(str, {'default': 'foo'}, mixin=None, field=None, cls=None, )



# Generated at 2022-06-11 21:07:41.492546
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses_json import dataclass_json
    from typing import List

    @dataclass_json
    @dataclass
    class Person:
        name: str

    @dataclass_json
    @dataclass
    class Company:
        name: str
        employees: List[Person]

    company1 = {
        "name": "ACME",
        "employees": [
            {"name": "John"},
            {"name": "Jane"}
        ]
    }
    company2 = [
        {
            "name": "ACME",
            "employees": [
                {"name": "John"},
                {"name": "Jane"}
            ]
        }
    ]
    load = Company.Schema().load(company1, many=False)
    assert company1 == load.to_dict()

# Generated at 2022-06-11 21:07:50.099362
# Unit test for function build_type
def test_build_type():
    class Cls(Schema):
        pass

    class Cls2(Cls):
        pass

    class Enum_(Enum):
        A = 'a'

    @dataclass_json
    @dataclass
    class Dc:
        pass

    @dataclass_json
    @dataclass
    class Dc2(Dc):
        pass

    assert build_type(str, {'required': True}, None, None, None)(str, {
        'required': True}, {}) == fields.Str(required=True)
    assert build_type(UUID, {}, None, None, None)(UUID, {}, {}) == fields.UUID()
    assert build_type(datetime, {}, None, None, None)(datetime, {}, {}) == _TimestampField()
    assert build_

# Generated at 2022-06-11 21:07:59.983071
# Unit test for function build_type
def test_build_type():
    class TestMixin:
        pass
    import typing as t
    assert build_type(t.MutableMapping, {}, TestMixin, Field('a', t.MutableMapping, default_factory=dict), object) == fields.Mapping
    assert build_type(t.List, {}, TestMixin, Field('a', t.List, default_factory=list), object) == fields.List
    assert build_type(t.Dict, {}, TestMixin, Field('a', t.Dict, default_factory=dict), object) == fields.Dict
    assert build_type(t.Tuple, {}, TestMixin, Field('a', t.Tuple, default_factory=tuple), object) == fields.Tuple

# Generated at 2022-06-11 21:08:03.116641
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Example(typing.NamedTuple):
        a: int

    sch = SchemaF[Example]()
    sch.dump([Example(a=3), Example(a=5)])


# Generated at 2022-06-11 21:08:03.660702
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    pass

# Generated at 2022-06-11 21:08:10.548402
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Foo:
        def __init__(self, x):
            self.x = x

    class FooSchema(SchemaF[Foo]):
        x = fields.Int()

    assert isinstance(FooSchema().loads("{}"), Foo)



# Generated at 2022-06-11 21:08:42.654492
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    import json
    data = [
        {'a': 1, 'b': [1, 2, 3]}
    ]
    class SchemaD(Schema):
        a = fields.Int()
        b = fields.List(fields.Int())

    sd = SchemaD(unknown='EXCLUDE')
    assert SchemaF[SchemaD.__result__](unknown='EXCLUDE').dumps(sd, many=True) == json.dumps(data, indent=2)  # type: ignore


# Generated at 2022-06-11 21:08:53.293917
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    s = SchemaF[int]()
    s.load([1, 2, 3])
    s.load({1: 2, 3: 4})
    s.load(1)
    s.load([1])

    try:
        # noinspection PyTypeChecker
        s.load(True)  # type: ignore
        assert False, 'Should not get there.'
    except TypeError:
        pass

    try:
        # noinspection PyTypeChecker
        s.load([{'k': 1}])  # type: ignore
        assert False, 'Should not get there.'
    except TypeError:
        pass

    # todo: this should be the error message for wrong dict value type
    #  but it does not work with an empty list either

    # "Expected a list of items but got type "list"."

# Generated at 2022-06-11 21:09:00.892734
# Unit test for function schema
def test_schema():
    # test_schema_1
    class TestSchema(Schema):
        bla = fields.Field(allow_none=True, required=True)
    actual_result = schema(TestSchema, None, False)
    expected_result = {'bla': fields.Field(allow_none=True, required=True)}
    assert actual_result == expected_result

    # test_schema_2
    class TestSchema(Schema):
        bla = fields.Field(allow_none=True, required=True)
    actual_result = schema(TestSchema, None, True)
    expected_result = {'bla': fields.Field(allow_none=True, required=True)}
    assert actual_result == expected_result

    # test_schema_3
    class TestSchema(Schema):
        bl

# Generated at 2022-06-11 21:09:06.794003
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    a = _TimestampField(default=None)
    assert a._deserialize(None, None, None) is None
    assert a._serialize(None, None, None) is None
    assert _timestamp_to_dt_aware(a._serialize(datetime.utcnow(), None, None)) == datetime.utcnow()
    assert a._deserialize(1514602205.0, None, None) == datetime(2018, 1, 1, 19, 50, 5, tzinfo=None)



# Generated at 2022-06-11 21:09:09.445211
# Unit test for function build_schema
def test_build_schema():
  @dataclass_json
  @dataclass
  class User:
    name: str
    password: str

  UserSchema.dump(User('test1', 'test2'), many=None)


# Generated at 2022-06-11 21:09:18.272409
# Unit test for function schema
def test_schema():
    from marshmallow import fields, Schema
    import marshmallow
    from dataclasses_json import dataclass_json, DataClassJsonMixin
    import pytest
    import datetime as dt

    # Case 1
    @dataclass_json
    @dataclass
    class Dc:
        test1: str
        test2: typing.Dict[int, str]
        test3: dt.datetime
        test4: typing.Optional[int]
        test5: typing.Optional[typing.Union[int, str]]
        test6: typing.Optional[typing.Union[int, str, int]]
        test7: typing.List[int]
        test8: typing.MutableMapping[str, str]

    # Case 2

# Generated at 2022-06-11 21:09:28.866135
# Unit test for function schema
def test_schema():
    # Test issue #18
    import typing
    import datetime
    from dataclasses_json import dataclass_json

    class Schema(dataclass_json.Schema):
        pass

    @dataclass_json.dataclass_json
    @dataclass_json.data_class
    class Test:
        x: typing.Union[str, int]
        y: typing.Union[int, datetime.datetime]

    result = schema(Test, Schema, False)
    assert len(result) == 2

# Generated at 2022-06-11 21:09:41.045964
# Unit test for function build_schema
def test_build_schema():
    import dataclasses_json_marshmallow.schema
    import marshmallow as mm
    import typing
    class Metadata(typing.NamedTuple):
        letter_case: typing.Optional[dataclasses_json_marshmallow.schema.LetterCase] = None
        mm_field: typing.Optional[mm.fields.Field] = None
        usage: typing.Optional[str] = None
        decoder: typing.Optional[typing.Callable] = None
        encoder: typing.Optional[typing.Callable] = None
        default: typing.Optional[typing.Any] = None
        default_factory: typing.Optional[typing.Any] = None
        factory: typing.Optional[typing.Callable] = None

# Generated at 2022-06-11 21:09:43.749174
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()



# Generated at 2022-06-11 21:09:47.684191
# Unit test for constructor of class _IsoField
def test__IsoField():
    test_value = datetime.fromtimestamp(int("1547662745"))
    test_field = _IsoField()
    return test_field._deserialize(test_field._serialize(test_value, "attr", "obj"), "attr", "data")


# Generated at 2022-06-11 21:11:00.260908
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    assert SchemaF[SchemaF[int]].dump([[1, 2, 3]]) == [[1, 2, 3]]
    assert SchemaF[SchemaF[int]].dump(SchemaF[int].dump([1, 2, 3])) == [1, 2, 3]
    assert SchemaF[SchemaF[int]].dump([1, 2, 3]) == [1, 2, 3]
    assert SchemaF[SchemaF[int]].dump([1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-11 21:11:03.944586
# Unit test for function build_schema
def test_build_schema():
    DataClassSchema = build_schema(cls=object, mixin=object(), infer_missing=True, partial=True)
    assert DataClassSchema().Meta.fields == ()

# Generated at 2022-06-11 21:11:14.670395
# Unit test for constructor of class _IsoField
def test__IsoField():
    # Arrange
    sample = _IsoField()
    test_case = [
        ("2020-06-25T11:00:00", datetime(2020, 6, 25, 11, 00, 00)),
        ("2020-06-25", datetime(2020, 6, 25, 0, 0, 0)),
        ("2020-06-25T11:00", datetime(2020, 6, 25, 11, 00, 00)),
        ("2020-06-25T11:00:00+00:00", datetime(2020, 6, 25, 11, 00, 00))
    ]

    # Act
    for i in range(len(test_case)):
        assert test_case[i][1] == sample._deserialize(test_case[i][0], "", "")



# Generated at 2022-06-11 21:11:24.746566
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # type: () -> None
    """
    This test was generated automatically from a doctest.
    Please run `pytest` from the root of the repo to test.
    """
    from marshmallow import Schema, fields, ValidationError
    from marshmallow_dataclass import dataclass

    @dataclass
    class DataClassWithDict:
        d: typing.Dict[str, float]

    class SchemaWithDict(Schema):
        d = fields.Dict(keys=fields.Str(), values=fields.Float())

    d = {'a': 0.5, 'b': 1.5}
    d_class = DataClassWithDict(d)
    expected = b'{"d":{"a":0.5,"b":1.5}}'

# Generated at 2022-06-11 21:11:33.264853
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField(deserialize_from='test_serialize', default=1,
        attribute='test_attribute', data_key='test_key', error='test_error', error_messages={'test_key': 'test_value'},
        required=False, allow_none=True, load_only=True, dump_only=True, missing=None,
        validate=None, validators=None, allow_default=False, load_from=None,
        dump_to=None, missing=None, metadata=None)



# Generated at 2022-06-11 21:11:38.000318
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields

    class A(SchemaF[str]):
        field = fields.Str()

    assert A().dump('test') == {'field': 'test'}  # type: ignore


# Generated at 2022-06-11 21:11:48.097209
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from typing import List, Dict, Any
    from marshmallow import Schema
    from marshmallow.fields import Field

    class A:
        pass

    class B:
        pass

    class C(Schema):
        a: List[A] = Field(...)  # type: ignore
        b: Dict[str, B] = Field(...)  # type: ignore
        c: Any = Field(...)

    c = C(many=True)
    c.loads({'a': [], 'b': {}, 'c': []})


if sys.version_info >= (3, 7):
    # noinspection PyAbstractClass
    class _SchemaFactory:
        schema_base_class = SchemaF

        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs

# Generated at 2022-06-11 21:11:56.101056
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    MyField = _TimestampField()
    dt_value = datetime(2020, 12, 2)
    # encode
    timestamp = MyField._serialize(dt_value, None, None)
    assert timestamp == dt_value.timestamp()
    # decode
    decoded_dt = MyField._deserialize(timestamp, None, None)
    assert isinstance(decoded_dt, datetime)
    assert decoded_dt.replace(tzinfo=None) == dt_value



# Generated at 2022-06-11 21:12:06.338153
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    tf = _TimestampField()
    assert tf._serialize(datetime(2019, 1, 1, 0, 0, 0), 'datetime', {}) == 1546300800.0
    assert tf._deserialize(1546300800.0, 'datetime', {}) == datetime(2019, 1, 1, 0, 0, 0)
    # None value
    with pytest.raises(ValidationError):
        tf._deserialize(None, 'datetime', {})
    # Wrong value
    tf.required = False
    assert tf._deserialize(None, 'datetime', {}) == None
    with pytest.raises(ValidationError):
        tf._deserialize("2019-01-01T00:00:00", 'datetime', {})


# Generated at 2022-06-11 21:12:11.917724
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields
    from marshmallow.fields import Field
    from typing import List, TypeVar
    from marshmallow.exceptions import ValidationError
    from marshmallow_dataclass import dataclass

    # Local import to avoid circular imports
    from marshmallow_dataclass.schema import SchemaF
    from marshmallow_dataclass.utils import JsonData

    A = TypeVar('A')

    @dataclass
    class Test:
        foo: str
        bar: int = 42

    class TestSchema(SchemaF[A]):  # type: ignore
        foo = fields.Str()
        bar = fields.Int()

    TestSchema().dump(List[Test]([Test('abc', 42)]))



# Generated at 2022-06-11 21:14:49.784871
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    def t():
        class A(SchemaF[int]):
            pass
    assert t() is None

    def t():
        class A(SchemaF[int]):
            pass
        return A(many=True)
    assert t() is None

    def t():
        class A(SchemaF[int]):
            pass
        return A()
    assert t() is None



# Generated at 2022-06-11 21:15:01.912579
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses_json.tests.test_marshmallow_support import Basic, ISchema
    dump = ISchema[Basic].dumps([Basic(a=1, b=2)])
    dump2 = ISchema[Basic].dumps(Basic(a=1, b=2))
    dump3 = ISchema[Basic].dumps(Basic(a=1, b=2), many=True)
    assert dump.startswith("[{") and dump.endswith("}]")
    assert dump2.startswith("{") and dump2.endswith("}")
    assert dump3.startswith("[{") and dump3.endswith("}]")
    # Unit test for method load of class SchemaF
    res1 = ISchema[Basic].loads(dump)
    res2

# Generated at 2022-06-11 21:15:14.235816
# Unit test for function build_type
def test_build_type():
    from unittest import TestCase
    from marshmallow import Schema, EXCLUDE

    class TestSchema(Schema):
        class Meta:
            unknown = EXCLUDE

    class DummyEnum(Enum):
        A = "A"
        B = "B"

    @dataclass_json
    @dataclass
    class SubDataclass(JsonMixin):
        a: str

    @dataclass_json
    @dataclass
    class MixinDataclass(JsonMixin):
        a: str = field(metadata={"required": True})

    @dataclass_json
    @dataclass
    class MainDataclass(JsonMixin):
        a: Optional[str] = field(metadata={"required": True})