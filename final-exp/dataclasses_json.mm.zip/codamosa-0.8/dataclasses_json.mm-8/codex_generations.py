

# Generated at 2022-06-11 21:05:39.689272
# Unit test for function build_schema
def test_build_schema():

    @dataclass
    class A:
        a: str
        b: int = field(metadata={'dataclasses_json': {'mm_field': fields.Str()}})

    @dataclass
    class B:
        a: typing.Optional[int]

    @dataclass
    class C:
        a: typing.List[int]

    @dataclass
    class D:
        a: int = field(metadata={'dataclasses_json': {'mm_field': fields.Str()}})

    @dataclass
    class E:
        a: typing.List[str]

    @dataclass
    class F:
        a: typing.List[int]

    @dataclass
    class G:
        a: typing.Mapping[str, int]


# Generated at 2022-06-11 21:05:45.458443
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class MySchemaF(SchemaF[str]):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)


    s = MySchemaF()
    assert s.load({"a": "b"}) == "b"
    assert s.load([{"a": "b"}, {"a": "c"}]) == ["b", "c"]



# Generated at 2022-06-11 21:05:59.030834
# Unit test for function build_type
def test_build_type():
    from marshmallow import Schema
    from typing import Optional

    class DummySchema(Schema):
        pass


    # this is a fake class to trick the type checker of build_type
    class DummyType(type):
        __supertype__ = None
        # this is overridden because the type checker thinks this is a union type
        __args__ = None

    class DummyClass(metaclass=DummyType):
        pass
    # end of fake class

    assert build_type(DummyClass, {}, object, type('', (object,), {}), object) == fields.Field
    assert build_type(Optional[DummyClass], {}, object, type('', (object,), {}), object) == fields.Field

# Generated at 2022-06-11 21:06:11.779299
# Unit test for function build_type
def test_build_type():
    def _inner(type_, options):
        while True:
            if not _is_new_type(type_):
                break

            type_ = type_.__supertype__

        if is_dataclass(type_):
            from dataclasses_json import dataclass_json
            from dataclasses_json.annotations import dataclass_json_config

            # if _issubclass_safe(type_, dataclass_json_config):
            #     options['field_many'] = bool(
            #         _is_supported_generic(field.type) and _is_collection(
            #             field.type))
            #     return fields.Nested(type_.schema(), **options)
            # else:
            #     warnings.warn(f"Nested dataclass field {field.name} of type "

# Generated at 2022-06-11 21:06:19.059341
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema
    from typing import List
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin, config

    @dataclass
    class A(DataClassJsonMixin):
        a: int

    @dataclass
    class B(DataClassJsonMixin):
        b: List[A]

    # mypy should complain here, if it would be a real implementation
    class MySchema(SchemaF[A]):
        pass

    MySchema().load([{'a': 0}, {'a': 1}], many=True)
    MySchema().load({'a': 1}, many=False)
    MySchema().load([{'a': 0}, {'a': 1}])
    MySchema().load({'a': 1})



# Generated at 2022-06-11 21:06:20.417715
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    pass

# Generated at 2022-06-11 21:06:23.403746
# Unit test for constructor of class _IsoField
def test__IsoField():
    f = _IsoField()
    assert f.deserialize("2020-01-02") == datetime(2020, 1, 2)


# Generated at 2022-06-11 21:06:34.481049
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    assert isinstance(SchemaF.loads([]), list)
    assert isinstance(SchemaF.loads([], many=True), list)
    assert not isinstance(SchemaF.loads([], many=False), list)
    assert not isinstance(SchemaF.loads(b'', many=False), list)



# Generated at 2022-06-11 21:06:44.618676
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses import dataclass

    @dataclass
    class Foo:
        bar: str

    schema = SchemaF[Foo]()

    assert schema.dump([Foo('hello')], many=True) == [{"bar": "hello"}]
    assert schema.dump([Foo('hello'), Foo('world')], many=True) == \
        [{"bar": "hello"}, {"bar": "world"}]

    assert schema.dump(Foo('hello')) == {"bar": "hello"}

    # Test error cases
    # wrong type for `many`
    try:
        schema.dump([Foo('hello')], many=1)
        assert False
    except TypeError:
        pass

    # many=False but dump not single element

# Generated at 2022-06-11 21:06:56.525197
# Unit test for function build_type

# Generated at 2022-06-11 21:07:14.985892
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    @dataclass_json
    @dataclass
    class TTest:
        m: str = 'my_str'
    json_data: JsonData = b'{"m": "my_str"}'

    class TSchema(SchemaF[TTest]):
        m: str = fields.Str()

    schema = TSchema()
    res = schema.loads(json_data)
    assert isinstance(res, TTest)


if sys.version_info >= (3, 7):
    class JsonSchema(SchemaF[A]):
        """Base class for marshmallow schema"""


# Generated at 2022-06-11 21:07:27.765674
# Unit test for function build_schema
def test_build_schema():
    t = typing.TypeVar('t')
    class V(typing.Generic[t]): ...
    class MM():
        dataclass_json_config = Config()
    class N(MM, V[str]): ...
    class O(MM): ...
    class P(MM, V[str]): ...
    class Q(MM): ...
    class R():
        dataclass_json_config = Config()
        x: int
    class Q1(Q, R): ...
    class Q2(O, P): ...
    assert 'x' not in build_schema(N, MM, False, False).__dict__
    assert 'x' not in build_schema(Q1, MM, False, False).__dict__
    assert 'x' in build_schema(Q2, MM, False, False).__dict

# Generated at 2022-06-11 21:07:36.792994
# Unit test for function build_schema
def test_build_schema():
    class A(Mixin):
        @classmethod
        def schema(cls):
            return build_schema(cls, cls, False)

        id: int
        title: str


    assert issubclass(A.schema, Schema)
    assert len(A.schema().opts.fields) == 2
    assert A.schema().__name__ == 'ASchema'
    assert A.schema().Meta.fields == ('id', 'title')



# Generated at 2022-06-11 21:07:41.534231
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    assert SchemaF[datetime].dump(datetime(2020, 1, 1)) == "2020-01-01T00:00:00"
    assert SchemaF[int].dump(1) == 1
    with pytest.raises(NotImplementedError):
        x = SchemaF[int]()



# Generated at 2022-06-11 21:07:52.349009
# Unit test for function schema
def test_schema():
    import types
    import dataclasses
    import marshmallow
    import dataclasses_json

    @dataclasses.dataclass(unsafe_hash=True)
    class TestDataClass:
        test_a: int
        test_b: int = dataclasses.field(metadata={'dataclasses_json': {'mm_field': marshmallow.fields.Integer()}})
        test_c: int = dataclasses.field(metadata={'dataclasses_json': {'mm_field': marshmallow.fields.Integer()}})
        test_d: int = dataclasses.field(metadata={
            'dataclasses_json': {
                'mm_field': marshmallow.fields.Integer()
            }
        })

# Generated at 2022-06-11 21:07:53.392434
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    _TimestampField()


# Generated at 2022-06-11 21:08:03.200874
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    import marshmallow as mm
    @mm.schema_class
    class MySchema(mm.Schema):
        name: str
        age: int
    data = [{"name": "David", "age": 48}, {"name": "Natalie", "age": 44}]
    expected_res = "[{'name': 'David', 'age': 48}, {'name': 'Natalie', 'age': 44}]"
    res = MySchema.SchemaF[dict].dumps(data)
    assert res == expected_res, \
        f'MySchema.SchemaF[dict].dumps(data) failed, expected {expected_res}, got {res}'



# Generated at 2022-06-11 21:08:16.190024
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class TestSchema(SchemaF):
        pass
    @dataclass
    class TestA:
        a: int
    @dataclass
    class TestB:
        b: str = 'default'
    s = TestSchema(strict=True)
    json_data = '{"a": 42}'
    a = TestA(42)
    a2 = s.loads(json_data)
    a3 = s.load(json.loads(json_data))
    a4 = s.load([json.loads(json_data)])
    a5 = s.loads('[{"a": 42}]', many=True)
    a6 = s.load([json.loads(json_data)], many=True)
    a7 = s.dump([a])

# Generated at 2022-06-11 21:08:18.457009
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    if field is not None:
        pass
    else:
        test__TimestampField()


# Generated at 2022-06-11 21:08:23.305665
# Unit test for function build_schema
def test_build_schema():
    import sys
    import pytest
    try:
        build_schema(dict,
                 mixin,
                 infer_missing,
                 partial)
    except Exception as e:
        pytest.fail(f"There is not exception expected but {sys.exc_info()} was raised")
 


# Generated at 2022-06-11 21:08:55.251758
# Unit test for function build_type
def test_build_type():
    @dataclass
    class A:
        list_of_ints: typing.List[int]
        list_of_bools: typing.List[bool]
        u: typing.Union[int, str]

    assert build_type(A.list_of_ints.type, {}, None, A.list_of_ints, A) == fields.List[int]
    assert build_type(A.list_of_bools.type, {}, None, A.list_of_bools, A) == fields.List[bool]
    assert build_type(A.u.type, {}, None, A.u, A) == _UnionField[typing.Union[int, str]]



# Generated at 2022-06-11 21:08:57.978677
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    res = _TimestampField()
    assert res != None


# Generated at 2022-06-11 21:09:02.058580
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class MySchema(SchemaF[int]):
        pass
    res = MySchema().dump(1)
    res = MySchema().dump([1, 2, 3])


# Generated at 2022-06-11 21:09:03.777310
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert isinstance(_IsoField(required=True), _IsoField)



# Generated at 2022-06-11 21:09:08.899989
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclass
    class TestClass:
        a: int
        b: str

    def dumps(obj):
        return '{"a": 1, "b": "test"}'

    schema = SchemaF[TestClass](dump_function=dumps)
    assert isinstance(schema.dumps(TestClass(1, "test")), str)



# Generated at 2022-06-11 21:09:17.953857
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from typing import List
    from marshmallow import Schema, fields

    class C(SchemaF):
        pass

    class S(Schema):
        pass

    assert C.dumps([1, 2, 3], many=True) == '1,2,3'
    assert C.dumps(1, many=False) == '1'
    assert C.dumps(1, many=None) == '1'

    assert SchemaF.dumps([1, 2, 3], S(), many=True) == '1,2,3'
    assert SchemaF.dumps(1, S(), many=False) == '1'
    assert SchemaF.dumps(1, S(), many=None) == '1'

# Generated at 2022-06-11 21:09:28.663703
# Unit test for function build_schema
def test_build_schema():
    import json
    import unittest
    import uuid

    from dataclasses import dataclass, field
    from dataclasses_json import DataClassJsonMixin, dataclass_json

    @dataclass
    class CommonMixin(DataClassJsonMixin):
        pass


    @dataclass
    class Bar(CommonMixin):
        bar: int = field(metadata={'dataclasses_json': {'mm_field': fields.Int()}})


    @dataclass
    class Foo(CommonMixin):
        foo: Bar = field(metadata={'dataclasses_json': {'mm_field': fields.Str()}})


    @dataclass
    class FooBar(CommonMixin):
        foo: Bar

# Generated at 2022-06-11 21:09:29.479944
# Unit test for function schema
def test_schema():
    assert True



# Generated at 2022-06-11 21:09:41.683890
# Unit test for function build_type
def test_build_type():
    def make_field(type_):
        return lambda: type_
    def check(type_, expected):
        type_ = make_field(type_)
        actual = build_type(type_(), {'foo': 'bar', 'baz': 'qux'}, None, type_,
                            None)
        assert actual == expected
    check(None, fields.Field)
    check(typing.Any, fields.Raw)
    check(typing.List[typing.Any], fields.List)
    check(typing.List[CatchAllVar], fields.List)
    check(typing.List['j'], fields.List)
    check(typing.List['h'], fields.List)
    check(typing.List['i'], fields.List)

# Generated at 2022-06-11 21:09:52.209863
# Unit test for function build_schema
def test_build_schema():

    from dataclasses import dataclass, field

    @dataclass
    class TestClass:
        id: int
        d: Decimal = 2
        m: Decimal = field(metadata={Mapping.LETTER_CASE: camelcase})
        optional: Optional[TestClass] = field(default=None)

    DataClassSchema = build_schema(TestClass, dataclass_json, True, False)
    assert DataClassSchema.dump({'id': 1, 'd':1, 'm': 1, 'optional': {'id': 1, 'd':1, 'm': 1}}) == {'id':1, 'd': 1, 'm': 1}


# Generated at 2022-06-11 21:11:01.124131
# Unit test for function build_type
def test_build_type():
    from unittest import TestCase
    from dataclasses import dataclass
    from typing import List

    @dataclass
    class TestSchema:
        field: List[int]

    class TestClass:
        @staticmethod
        def decode_schema(schema):
            return _decode_dataclass(schema)[0]

    test_case = TestCase()
    cls = TestClass()
    schema_info = cls.decode_schema(TestSchema)
    field = schema_info["fields"][0]
    result = build_type(field.type, {}, cls, field, cls)
    test_case.assertIs(fields.List, result)



# Generated at 2022-06-11 21:11:13.645991
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields, validate
    import dataclasses

    @dataclasses.dataclass
    class Person:
        name: str = dataclasses.field(
            metadata={'marshmallow_field': fields.String()})
        age: int = dataclasses.field(
            metadata={'marshmallow_field': fields.Integer(validate=validate.Range(min=1))})

    person = Person('foo', 2)
    print(person.name)
    print(person.age)

    @dataclasses.dataclass
    class PersonSchema(SchemaF[Person]):
        name: fields.String = fields.String()
        age: fields.Integer = fields.Integer(validate=validate.Range(min=1))

    schema = PersonSchema()
    assert isinstance

# Generated at 2022-06-11 21:11:21.840508
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses_json.schema import SchemaF  # pylint: disable=no-name-in-module
    import dataclasses
    import typing
    import marshmallow

    @dataclasses.dataclass
    class CMember(typing.Protocol):
        identifier: str
        value: typing.Any

    class C(typing.Generic[CMember], metaclass=dataclasses.dataclass):
        members: typing.List[CMember]
        a: typing.List[str]

    @dataclasses.dataclass
    class A:
        b: int
        c: C[CMember]

    @dataclasses.dataclass
    class AMember(typing.Protocol):
        identifier: str
        value: A


# Generated at 2022-06-11 21:11:29.985026
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin, config
    import marshmallow_dataclass

    @dataclass
    class A(DataClassJsonMixin):
        a: str
        b: int

    @dataclass
    class B(DataClassJsonMixin):
        a: str
        b: int

    @dataclass
    class C(DataClassJsonMixin):
        b: typing.Union[A, B]

    assert schema(C, DataClassJsonMixin, infer_missing=False) == \
           {'b': marshmallow_dataclass.class_schema(A)}



# Generated at 2022-06-11 21:11:37.303922
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class Test(DataClassJsonMixin):
        a: int
        b: str = "b"
        c: typing.Optional[CatchAllVar] = None

    s = schema(Test, DataClassJsonMixin, True)
    print(s)
    assert s == {"a": fields.Int(missing=MISSING, allow_none=False), "b": fields.Str(missing="b", allow_none=False), "c": fields.Field(allow_none=True, default=None)}



# Generated at 2022-06-11 21:11:39.243183
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # type: () -> None
    class Schema(SchemaF[str]):
        pass

    schema = Schema()
    schema.dump(['asdf'])
    schema.dump('asdf')

# Generated at 2022-06-11 21:11:48.522356
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class F(SchemaF[str]): pass
    def func(load):
        load(b"[1, 2]", many=True)
        load(b'{"x": 1}', many=False)
        load(bytearray(b"[1, 2]"), many=True)
        load(bytearray(b'{"x": 1}'), many=False)
        load(b"[1, 2]", many=None)
        load(b'{"x": 1}', many=None)
        load(bytearray(b"[1, 2]"), many=None)
        load(bytearray(b'{"x": 1}'), many=None)
    func(F().loads)
    func(F().load)

# Generated at 2022-06-11 21:11:53.314242
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.utcnow().replace(tzinfo=None), 'test_attr', object, **{})
    assert _TimestampField()._deserialize(int(datetime.utcnow().timestamp()), 'test_attr', {}, **{})
    assert _TimestampField(required=False)._deserialize(None, 'test_attr', {}, **{}) is None


# Generated at 2022-06-11 21:12:01.091477
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    assert isinstance(  # type: ignore
        SchemaF.load(SchemaF, [{}], many=True), typing.List[A]
    )
    assert isinstance(
        SchemaF.load(SchemaF, {}), A
    )
    assert isinstance((SchemaF.load(SchemaF, [{}], many=True)[0]), A)  # type: ignore



# Generated at 2022-06-11 21:12:09.486370
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import fields, Schema

    class TestSchema(Schema):
        x = fields.Int()

    Test1 = typing.List[int]

    class M(SchemaF, typing.Generic[Test1]):
        @post_load
        def extract_data(self, data, **kwargs):
            return data

    M(TestSchema, load_kwargs={'many': True}).load([{'x': 1}])


if sys.version_info < (3, 7):
    SchemaF = Schema



# Generated at 2022-06-11 21:14:41.653514
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    _TimestampField()

TimestampField = _TimestampField

# TODO(gm) add option to serialize to isoformat

# Generated at 2022-06-11 21:14:51.823113
# Unit test for function schema
def test_schema():
    from dataclasses_json.api import mm
    from marshmallow_enum import EnumField
    from marshmallow import fields
    from dataclasses import dataclass
    import typing

    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError

    class Pet(str, Enum):
        cat = 'cat'
        dog = 'dog'
        horse = 'horse'

    @dataclass
    class PetClass:
        name: str

    @dataclass
    class Person:
        name: str
        age: int
        pet: Pet
        petclass: PetClass

    @mm.schema(infer_missing=True)
    class SchemaPerson(Schema):
        name = fields.Str(required=True)
        age = fields.Int(dump_to='Age')
       

# Generated at 2022-06-11 21:14:53.779307
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    pass


# Generated at 2022-06-11 21:15:03.708796
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class TestA:
        b: str

    @dataclass_json
    class TestB:
        c: TestA
        d: typing.Dict[str, TestA]
        e: typing.List[TestA]

    schema = TestB.schema(mm_field={TestA: fields.String()})
    assert len(schema.declared_fields) == 3

    field = schema.declared_fields.get('c')
    assert isinstance(field, fields.String)

    field = schema.declared_fields.get('d')
    assert isinstance(field, fields.Field)

    field = schema.declared_fields.get('e')

# Generated at 2022-06-11 21:15:14.190689
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    try:
        from dataclasses import dataclass
    except ImportError:
        return
    from datetime import timezone

    _TIMESTAMPFIELD = _TimestampField()
    dt_aware = datetime(2018, 9, 17, 1, 5, 9, 0, timezone.utc)
    dt_timestamp = dt_aware.timestamp()
    assert(_TIMESTAMPFIELD._serialize(dt_aware, None, None) == dt_timestamp)
    assert(_TIMESTAMPFIELD._deserialize(dt_timestamp, None, None) == dt_aware)
