

# Generated at 2022-06-11 21:05:42.106687
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class SchemaF(Schema):
        pass

    class TestSchemaSubclassSchemaF(SchemaF[A]):
        pass

# Generated at 2022-06-11 21:05:46.463767
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field._serialize(datetime.now(), "test_attr", None) is not None
    assert field._deserialize(1589650483, "test_attr", None) is not None
    assert field._serialize(None, "test_attr", None, required=False) is None
    assert field._deserialize(None, "test_attr", None, required=False) is None



# Generated at 2022-06-11 21:05:59.893309
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class A(object):
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b
    class ASchema(SchemaF[A]):
        a = fields.Int()
        b = fields.Int()
        @post_load
        def make_a(self, data, **kwargs):
            return A(**data)
    assert ASchema().load({"a": 1, "b": 2}) == A(1, 2)
    assert ASchema().loads(b'{"a": 1, "b": 2}') == A(1, 2)

# Generated at 2022-06-11 21:06:12.219824
# Unit test for function build_type
def test_build_type():
    import pytest
    class TestUnion(Enum):
        A = 1
        B = 2

    class TestDataclass:
        pass

    @dataclass_json
    @dataclass
    class TestMixin:
        pass

    @dataclass_json
    @dataclass
    class TestDataclassRecursive1(TestMixin):
        class TestDataclassRecursive2(TestMixin):
            pass

    @dataclass_json
    @dataclass
    class TestDataclassNonRecursive(TestMixin):
        class TestDataclassNonRecursive(TestMixin):
            pass

    class TestDataclassNonRecursive2(TestMixin):
        pass

    # Top-level dataclass
    type_ = typing.Optional[int]
    options = {}
    field

# Generated at 2022-06-11 21:06:24.395687
# Unit test for function schema
def test_schema():
    import marshmallow
    import marshmallow.fields

    S = marshmallow.Schema

    assert type(schema(None, None, None)) == dict
    assert schema(None, None, None) == {}

    class Empty:
        f1: MarshmallowField = MarshmallowField(marshmallow.fields.Field(), metadata={'dataclasses_json': {
            'mm_field': marshmallow.fields.Field()}})
        f2: MarshmallowField = MarshmallowField(marshmallow.fields.Field(), metadata={'dataclasses_json': {
            'mm_field': marshmallow.fields.Field()}})

    assert type(schema(Empty, None, None)) == dict

# Generated at 2022-06-11 21:06:35.756078
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass_json, dataclass, field
    from typing import Optional
    from marshmallow import Schema, fields

    @dataclass_json
    @dataclass
    class Inner:
        a_field: str

    @dataclass_json
    @dataclass
    class WithOptionalFields:
        a_field: Optional[str] = field(default=None)

    @dataclass_json
    @dataclass
    class NormalFields:
        a_field: str

    @dataclass_json
    @dataclass
    class A:
        a_field: int

    @dataclass_json
    @dataclass
    class B:
        a_field: str


# Generated at 2022-06-11 21:06:41.530460
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class MyDc(typing.NamedTuple):
        x: int
        y: typing.Optional[str]
    sf = SchemaF[MyDc]()
    res = sf.loads('{"x": 5, "y": "test"}')  # type: MyDc
    assert res.x == 5
    assert res.y == "test"


# Generated at 2022-06-11 21:06:48.685218
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import fields
    from typing import Any, List, Dict

    class MySchema(SchemaF[List[Dict[str, Any]]]):
        a = fields.Str()
        b = fields.Int()

    o = [{'a': 'foo', 'b': 1}, {'a': 'bar', 'b': 2}]
    assert o == MySchema().load(o)


TKey = typing.TypeVar('TKey', bound=str)
TValue = typing.TypeVar('TValue')
T = typing.TypeVar('T')


# Generated at 2022-06-11 21:06:57.269637
# Unit test for function schema
def test_schema():
    from dataclasses_json import dataclass_json
    from marshmallow import validate
    @dataclass_json
    @dataclass
    class A:
        test: typing.Union[str, int]
        test_a: typing.Optional[int]
        test_b: typing.Optional[typing.Union[str, int]]
    s = schema(A, dataclass_json.MM_MIXIN, False)
    assert s == {'test': fields.Field(allow_none=True), 'test_a': fields.Field(allow_none=True), 'test_b': fields.Field(allow_none=True)}


MetaData = typing.NewType('MetaData', typing.Any)



# Generated at 2022-06-11 21:07:08.468411
# Unit test for function build_schema
def test_build_schema():
    import uuid
    class Person:
        name: str
        age: int
        information: dict
        id: uuid.UUID
    result = build_schema(Person, None, False, False)
    assert issubclass(result, Schema)
    assert 'name' in result.__dict__
    assert result.__dict__['name'] == fields.Str()
    assert 'information' in result.__dict__
    assert result.__dict__['information'] == fields.Dict()
    assert 'id' in result.__dict__
    assert result.__dict__['id'] == fields.UUID()
    assert 'age' in result.__dict__
    assert result.__dict__['age'] == fields.Int()
    assert 'Meta' in result.__dict__
    assert result.__dict__['Meta']

# Generated at 2022-06-11 21:07:24.941429
# Unit test for function build_schema
def test_build_schema():
    """
    Test the function build_schema()
    """
    class _Person(object):

        def __init__(self, name, age):
            self.name = name
            self.age = age

    class TestBuildSchema(unittest.TestCase):

        def test_build_schema(self):
            """
            Test the function build_schema()
            """
            cls = _Person
            mixin = None
            infer_missing = None
            partial = None
            self.assertRaises(NameError, build_schema, cls, mixin, infer_missing, partial)
    unittest.main()



# Generated at 2022-06-11 21:07:31.816066
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field._serialize(datetime.utcnow(), 'datetime', None)
    with pytest.raises(ValidationError):
        field._serialize(None, 'datetime', None)
    with pytest.raises(ValidationError):
        field._deserialize(None, 'datetime', None)
    field = _TimestampField(allow_none=True)
    assert field._serialize(None, 'datetime', None) is None
    assert field._deserialize(None, 'datetime', None) is None


# Generated at 2022-06-11 21:07:32.998327
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    SchemaF.loads('')


# Generated at 2022-06-11 21:07:43.582088
# Unit test for function build_schema
def test_build_schema():
    from marshmallow import Schema, fields, post_load
    from dataclasses import dataclass
    import datetime
    @dataclass
    class Obj:
        _x: float = 1.0
        @property
        def x(self):
            return self._x

        @x.setter
        def x(self, value):
            self._x = value

    class ObjSchema(Schema):
        x = fields.Float()
        @post_load
        def make_instance(self, kvs, **kwargs):
            return Obj(**kvs)

    if builtin_json is not None:
        assert ObjSchema().dump({'x': 2.0}) == {'x': 2.0}

# Generated at 2022-06-11 21:07:50.881781
# Unit test for function schema
def test_schema():
    @dataclass_json
    @dataclass
    class TestDC:
        name: str
        surname: Optional[str] = None

    assert schema(TestDC, json_data_serializer.JsonSerializable, True) == {
        'name': fields.Str(),
        'surname': fields.Str(allow_none=True, missing=None)
    }
    assert schema(TestDC, json_data_serializer.JsonSerializable, False) == {
        'name': fields.Str(),
        'surname': fields.Str(allow_none=True, default=None)
    }
    # Test for datetime
    @dataclass_json
    @dataclass
    class TestDT:
        name: str
        date: Optional[datetime] = None


# Generated at 2022-06-11 21:08:00.329240
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class TestSchema(SchemaF[str]):
        pass

    TestSchema.load(['foo'])  # type: ignore



# Generated at 2022-06-11 21:08:04.857683
# Unit test for constructor of class _IsoField
def test__IsoField():
    
    class TestSchema(Schema):
        test_field = _IsoField()

    obj = {'test_field': '2020-08-16T03:34:51.115219'}
    schema = TestSchema()

    result = schema.load(obj)
    assert result.data['test_field'].year == 2020



# Generated at 2022-06-11 21:08:17.701522
# Unit test for constructor of class _IsoField
def test__IsoField():
    if sys.version_info[1] >= 8:
        obj = _IsoField()
        assert obj._serialize(datetime(2020, 2, 12, 8, 6, 44, 854702), "", "") == "2020-02-12T08:06:44.854702"
        assert obj._deserialize("2020-02-12T08:06:44.854702", "", "") == datetime(2020, 2, 12, 8, 6, 44, 854702)
        assert obj._deserialize("2020-02-12T08:06:44", "", "") == datetime(2020, 2, 12, 8, 6, 44)
        assert obj._deserialize("2020-02-12T08:06", "", "") == datetime(2020, 2, 12, 8, 6)


# Generated at 2022-06-11 21:08:29.294920
# Unit test for function build_type
def test_build_type():
    assert build_type(int,{},None,None,None)(int,{})==fields.Int()
    assert build_type(str,{},None,None,None)(str,{})==fields.Str()
    assert build_type(float,{},None,None,None)(float,{})==fields.Float()
    assert build_type(bool,{},None,None,None)(bool,{})==fields.Bool()
    assert build_type(Decimal,{},None,None,None)(Decimal,{})==fields.Decimal()
    assert build_type(typing.Dict[str,int],{},None,None,None)(typing.Dict[str,int],{})==fields.Mapping(fields.Int())

# Generated at 2022-06-11 21:08:39.435497
# Unit test for function schema
def test_schema():
    import marshmallow
    class MySchema(marshmallow.Schema):
        pass


# Generated at 2022-06-11 21:09:22.704071
# Unit test for function schema
def test_schema():
    import unittest
    from dataclasses_json import dataclass_json
    from typing import Optional

    @dataclass_json
    @dataclass_json
    class Foobar:
        foo: Optional[str]
        bar: int = 42
        baz: Optional[CatchAllVar] = dataclass_json.field(metadata={'dataclasses_json': \
            {
                'mm_field': fields.Str()
            }
        })

    fields_list = schema(Foobar, dataclass_json.DataClassJsonMixin, True).items()
    expected = [ \
        ('foo', fields.Str(allow_none=True, missing=None)), \
        ('bar', fields.Int(missing=42)), \
        ('baz', fields.Str())
    ]
    assert list

# Generated at 2022-06-11 21:09:25.122028
# Unit test for constructor of class _IsoField
def test__IsoField():
    # TODO: we need to see a way to test this
    _IsoField()



# Generated at 2022-06-11 21:09:34.868679
# Unit test for function build_schema
def test_build_schema():
    def test():
        cls = typing.TypeVar('A')
        mixin = typing.TypeVar('A')
        infer_missing = False
        partial = False
        DataClassSchema = build_schema(cls,mixin,infer_missing, partial)
        assert DataClassSchema is not None
        assert isinstance(DataClassSchema, Schema)
        assert DataClassSchema.Meta.fields is not None
        assert isinstance(DataClassSchema.Meta.fields,tuple)
        assert hasattr(DataClassSchema,'make_')
        assert hasattr(DataClassSchema,'dumps')
        assert hasattr(DataClassSchema,'dump')
        print('function build_schema unit test passed')
    test()



# Generated at 2022-06-11 21:09:36.709226
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField(required=True).required
    assert _TimestampField().required == False


# Generated at 2022-06-11 21:09:47.262238
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    with pytest.raises(ValidationError) as excinfo:
        field._deserialize(None, 'attr', {})
    assert excinfo.value.messages == {'attr': ['Missing data for required field.']}
    assert field._deserialize(None, 'attr', {}, required=False) == None
    assert field._deserialize('2020-04-26T14:36:56+01:00', 'attr', {}) == datetime(2020, 4, 26, 14, 36, 56, tzinfo=datetime.timezone(datetime.timedelta(seconds=3600)))

# Generated at 2022-06-11 21:09:48.654711
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    f1 = _TimestampField()


# Generated at 2022-06-11 21:09:57.506969
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():  # type: ignore
    from typing import NewType, Union
    from marshmallow import Schema
    import json

    A = NewType('A', int)
    B = NewType('B', int)
    class MyJsonSchema(SchemaF[Union[A, B]]):  # type: ignore
        class Meta(Schema.Meta):
            unknown = 'EXCLUDE'
    myjson = json.dumps([1, 2, 3])
    mylist: typing.List[Union[A, B]] = MyJsonSchema().loads(myjson)
    assert mylist == [A(1), A(2), A(3)]
    mylist_wrong_type: typing.List[Union[A, B]] = MyJsonSchema().loads('[1,2,3,null]')
    assert mylist_wrong

# Generated at 2022-06-11 21:10:08.939353
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from datetime import date
    from typing import Optional, List
    from dataclasses import dataclass, field

    @dataclass
    class Person:
        name: str
        age: int

    @dataclass
    class User:
        id: int
        person: Optional[Person] = None

    assert SchemaF[List[User]].dumps([User(id=1, person=Person(name='John', age=100))]) == '[{"id": 1, "person": {"name": "John", "age": 100}}]'
    assert SchemaF[User].dumps(User(id=1, person=Person(name='John', age=100))) == '{"id": 1, "person": {"name": "John", "age": 100}}'

    @dataclass
    class UserV2:
        id: int

# Generated at 2022-06-11 21:10:17.904423
# Unit test for function schema
def test_schema():
    from dataclasses_json.enum import EnumDecoder
    from datetime import date
    from typing import Optional, List

    @dataclass_json(encode_tz=True)
    class SubData:
        id: int

    @dataclass_json(mm_field=fields.Date())
    class Data:
        id: int
        desc: Optional[str]
        sub: Optional[SubData]
        sub_list: List[SubData]
        date: date


# Generated at 2022-06-11 21:10:27.885499
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from typing import List
    from marshmallow import Schema, fields, SchemaF  # type: ignore
    class TestSchema(Schema):
        a = fields.Integer()
        b = fields.String()
    test_schema = TestSchema()
    test_schema.loads(b'[{"a":1,"b":"c"}]')
    test_schema.loads('[{"a":1,"b":"c"}]')
    test_schema.loads(bytearray(b'[{"a":1,"b":"c"}]'))
    test_schema.loads([{"a": 1, "b": "c"}])
    test_schema.loads([{"a": 1, "b": "c"}], many=False)
    class TestSchemaF(SchemaF[TestSchema], Schema): pass

# Generated at 2022-06-11 21:11:45.512244
# Unit test for function build_type
def test_build_type():
    assert build_type(int, {}, None, None, None)(int, {}) == fields.Int()
    assert build_type(str, {}, None, None, None)(str, {}) == fields.Str()
    assert build_type(float, {}, None, None, None)(float, {}) == fields.Float()
    assert build_type(bool, {}, None, None, None)(bool, {}) == fields.Bool()
    assert build_type(typing.List[int], {}, None, None, None)(typing.List[int], {}) == fields.List(fields.Int())
    assert build_type(typing.Mapping[int, str], {}, None, None, None)(typing.Mapping[int, str], {}) == fields.Mapping(fields.Int(), fields.Str())
    assert build

# Generated at 2022-06-11 21:11:54.050238
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin, dataclass_json, config

    @config(mm_field=fields.Str())
    @dataclass
    class TestMMField:
        test_mm_field: str

    @dataclass_json
    @dataclass
    class TestConfig:
        test_config: TestMMField
        test_config_optional: typing.Optional[TestMMField]

    assert schema(TestConfig, DataClassJsonMixin, True) == {
        'test_config': fields.Str(),
        'test_config_optional': fields.Nested(schema(TestMMField, DataClassJsonMixin, True))
    }



# Generated at 2022-06-11 21:12:02.925317
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from marshmallow import fields
    from dataclasses_json.core import Schema
    from dataclasses_json.mm import MM

    @dataclass
    class Child(MM):
        name: str

    @dataclass
    class Parent(MM):
        name: str
        child: Child

    assert schema(Parent, MM, infer_missing=False) == {'name': fields.String()}
    assert schema(Parent, Schema, infer_missing=False) == {'name': fields.String()}

# Generated at 2022-06-11 21:12:08.309682
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    a: typing.List[int] = SchemaF(many=True).load([1, 2])
    assert a == [1, 2]
    a: typing.List[int] = SchemaF(many=False).load([1, 2])
    assert a == [1, 2]

# Generated at 2022-06-11 21:12:17.048834
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses import dataclass

    @dataclass
    class A(object):
        a: str = 'B'
        b: int = 3
        c: list = None

    expected_encoded = dict(a='B', b=3, c=None)

    schema = SchemaF[A](ordered=True, only=('a', 'b'))
    a = A(a='B', b=3, c=None)
    encoded = schema.dumps(a)
    assert dict(json.loads(encoded)) == expected_encoded

    schema = SchemaF[A](ordered=True, only=('a', 'b'))
    a = A(a='B', b=3, c=None)
    encoded = schema.dumps([a])

# Generated at 2022-06-11 21:12:21.564977
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field.__class__.__name__ == 'TimestampField'
    assert field._serialize(datetime.now(), 'attr', 'obj') is not None
    assert field._deserialize(datetime.now().timestamp(), 'attr', 'data') is not None


# Generated at 2022-06-11 21:12:26.312056
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Foo:
        pass

    class FooSchema(SchemaF[Foo]):
        pass

    _ = FooSchema().load([{}], many=True)  # type: typing.List[Foo]
    _ = FooSchema().load({})  # type: Foo


# Generated at 2022-06-11 21:12:27.333020
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()



# Generated at 2022-06-11 21:12:28.397340
# Unit test for constructor of class _IsoField
def test__IsoField():
    f = _IsoField()
    assert f


# Generated at 2022-06-11 21:12:38.079173
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # type: () -> None
    @dataclasses_json.dataclass_json
    @dataclasses.dataclass
    class User:
        id: int
        name: str

    user = User(id=1, name='Marcin')

    schema = SchemaF[User](strict=True)
    res = schema.dumps(user)
    assert res == '{"id": 1, "name": "Marcin"}'

    res = schema.dumps([user])
    assert res == '[{"id": 1, "name": "Marcin"}]'

    res = schema.dumps([user, user])
    assert res == '[{"id": 1, "name": "Marcin"}, {"id": 1, "name": "Marcin"}]'

