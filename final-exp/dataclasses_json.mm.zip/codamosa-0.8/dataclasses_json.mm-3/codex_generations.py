

# Generated at 2022-06-11 21:05:49.576836
# Unit test for function build_type
def test_build_type():
    class D:
        @classmethod
        def schema(cls):
            return cls

    assert build_type(int, {}, D, 'a', D).__class__ == fields.Int
    assert build_type(float, {}, D, 'a', D).__class__ == fields.Float
    assert build_type(str, {}, D, 'a', D).__class__ == fields.Str
    assert build_type(UUID, {}, D, 'a', D).__class__ == fields.UUID
    assert build_type(datetime, {}, D, 'a', D).__class__ == _TimestampField
    assert build_type(Decimal, {}, D, 'a', D).__class__ == fields.Decimal
    assert build_type(D, {}, D, 'a', D).__class__

# Generated at 2022-06-11 21:06:01.984059
# Unit test for function schema
def test_schema():
    from marshmallow import post_load
    from dataclasses import dataclass

    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class Person(DataClassJsonMixin):
        name: str
        surname: str
        age: int

    class PersonSchema(Schema):
        name = fields.String()
        surname = fields.String()
        age = fields.Integer()

    @post_load
    def make_person(self, data, **kwargs):
        return self.DEV_CLS(**data)

    class AnotherPersonSchema(PersonSchema):
        DEV_CLS = Person


# Generated at 2022-06-11 21:06:14.254646
# Unit test for function build_type
def test_build_type():
    from typing import List, Optional, Tuple
    from marshmallow import fields as f
    from marshmallow_enum import EnumField as ef
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from decimal import Decimal
    from marshmallow import fields
    from datetime import date, time
    from enum import Enum
    import uuid
    import typing

    class TestEnum(Enum):
        TEST_ENUM = 1

    @dataclass_json
    @dataclass
    class TestObj:
        name: str
        age: int
        birthdate: date

    @dataclass_json
    @dataclass
    class TestObj2:
        name: str
        age: TestObj
        birthdate: TestEnum


# Generated at 2022-06-11 21:06:19.114840
# Unit test for function schema
def test_schema():
    class A:
        a: str
        b: typing.List[int]
        c: typing.Union[int, str]
        d: typing.Optional[int]
        e: typing.Optional[typing.List[int]]

    assert schema(A, None, False) == {
        'a': fields.Str,
        'b': fields.List,
        'c': fields.Nested,
        'd': fields.Int,
        'e': fields.Nested
    }



# Generated at 2022-06-11 21:06:20.675604
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    a = SchemaF.dumps([1, 2, 3], many=True)  # type: ignore
    b = SchemaF.dumps({}, many=True)  # type: ignore



# Generated at 2022-06-11 21:06:31.837759
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses import dataclass

    @dataclass
    class Foo:
        val: int

    class FooSchema(SchemaF[Foo]):
        val = fields.Int()

    foo0 = Foo(val=1)
    assert FooSchema().dump(foo0) == {'val': 1}
    assert FooSchema().dump([foo0]) == [{'val': 1}]
    assert FooSchema().dump(foo0, many=True) == [{'val': 1}]
    assert FooSchema().dumps(foo0) == '{"val": 1}'
    assert FooSchema().dumps([foo0]) == '[{"val": 1}]'
    assert FooSchema().dumps(foo0, many=True) == '[{"val": 1}]'



# Generated at 2022-06-11 21:06:40.595262
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass, field
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class ABC:
        a: int
        b: str

    assert 'a' in schema(ABC, ..., ...)
    assert 'b' in schema(ABC, ..., ...)
    assert len(schema(ABC, ..., ...)) == 2

    @dataclass_json
    @dataclass
    class ABC2:
        a: int = field(metadata=dict(dataclasses_json=dict(mm_field=0)))
        b: str

    assert 'a' in schema(ABC2, ..., ...)
    assert 'b' in schema(ABC2, ..., ...)

# Generated at 2022-06-11 21:06:45.553969
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class A:
        a: str
        b: List[str]

    sc = build_schema(A, None, False, False).__mro__
    assert sc[0] == A
    assert sc[1] == dataclasses.dataclass



# Generated at 2022-06-11 21:06:53.528572
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    @dataclass
    class A(object):
        x: int
    A._schema = build_schema(A, None, False, False)
    a = A(1)
    assert A._schema().dump(a) == {'x': 1}
    assert A._schema().load({'x':1}).x == 1
    A._schema = None



# Generated at 2022-06-11 21:06:56.719072
# Unit test for constructor of class _IsoField
def test__IsoField():
    f = _IsoField()
    assert f.deserialize('2019-11-21T11:22:33') == datetime(2019, 11, 21, 11, 22, 33)


# Generated at 2022-06-11 21:07:11.979718
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    # We use round-trip tests here, serialize the datetime object and then deserialize it
    before = datetime.now()
    after = _TimestampField().deserialize(_TimestampField().serialize(before))
    assert (before - after).total_seconds() < 0.1
    assert before.utcoffset() == after.utcoffset()


# Generated at 2022-06-11 21:07:24.057690
# Unit test for function build_type
def test_build_type():
    assert build_type(int, {}, None, None, None) == fields.Int
    assert build_type(float, {}, None, None, None) == fields.Float
    assert build_type(datetime, {}, None, None, None) == _TimestampField
    assert build_type(UUID, {}, None, None, None) == fields.UUID
    assert build_type(str, {}, None, None, None) == fields.Str
    assert build_type(bool, {}, None, None, None) == fields.Bool
    assert build_type(CatchAllVar, {}, None, None, None) == fields.Dict
    assert isinstance(build_type(typing.Match[str], {}, None, None, None), fields.Str)

# Generated at 2022-06-11 21:07:28.759087
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    dt_value = "2019-11-12T11:13:42.140000"
    result = field._deserialize(dt_value, "attr", "data")
    assert result == datetime.fromisoformat(dt_value)




# Generated at 2022-06-11 21:07:41.276467
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import List
    from dataclasses import dataclass

    @dataclass
    class Foo:
        test: int

    @dataclass
    class Foo2:
        test: int

    sf = SchemaF.from_dict({})
    assert isinstance(sf.dump([Foo(test=1)]), List[dict])
    assert isinstance(sf.dump([Foo2(test=1)]), List[dict])
    assert isinstance(sf.dump(Foo(test=1)), dict)
    assert isinstance(sf.dump(Foo2(test=1)), dict)

    with pytest.raises(NotImplementedError):
        SchemaF[Foo].from_dict({})

# Generated at 2022-06-11 21:07:43.295750
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    ts = _TimestampField()
    assert ts.data_key is None



# Generated at 2022-06-11 21:07:54.074698
# Unit test for function build_schema
def test_build_schema():
    import dataclasses_json

    @dataclasses_json.dataclass_json
    @dataclasses.dataclass
    class MyClass:
        a: str

    # Test catch all field
    MyClassSchema = build_schema(MyClass, dataclasses_json.DataClassJsonMixin,
                                 False, False)
    schema = MyClassSchema()
    assert schema.dump(MyClass(a="a"), many=False) == dict(a="a")
    assert schema.dump(MyClass(a="a"), many=True) == [dict(a="a")]
    assert schema.loads('{"a": "a"}', many=False) == MyClass(a="a")

# Generated at 2022-06-11 21:08:02.292180
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    def t_dump(a: TOneOrMultiEncoded, many: bool, b: TOneOrMulti):
        # this is a helper function for unit tests to make correct mypy types possible for the call
        SchemaF[str].dump(a, many) == b

# Generated at 2022-06-11 21:08:05.214394
# Unit test for function build_type
def test_build_type():
    assert build_type(typing.List[typing.Optional[int]], {}, None, None, None) == fields.List(fields.Int(allow_none=True))


# Generated at 2022-06-11 21:08:18.013303
# Unit test for constructor of class _IsoField
def test__IsoField():
    dt = datetime(2020, 4, 3)
    dt_iso = dt.isoformat()
    f = _IsoField(required=False, default=MISSING)
    assert f.deserialize(None) is None
    assert f.deserialize(dt_iso) == dt
    assert f.serialize(None) is None
    assert f.serialize(dt) == dt_iso
    try:
        f.deserialize("2020-04-03T01:23")
        assert False
    except ValidationError:
        pass
    try:
        f.deserialize("2020-04-03T01:23:45+09:00")
        assert False
    except ValidationError:
        pass

# Generated at 2022-06-11 21:08:28.196925
# Unit test for function schema
def test_schema():
    SchemaType = typing.TypeVar('SchemaType', bound=Schema)


    @dataclasses_json.dataclass_json
    @dataclasses.dataclass
    class SchemaObj:
        x: int


    class TestSchema(SchemaType, typing.Generic[SchemaObj]):
        x = fields.Int()

        @post_load  # type: ignore
        def create_obj(self, data, **kwargs):  # type: ignore
            return SchemaObj(**data)


    # The override should have priority
    _schema = schema(SchemaObj, TestSchema, True)

    assert _schema['x'] is TestSchema.declared_fields['x']

# Generated at 2022-06-11 21:08:53.962889
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclass
    class SomeDC:
        value: str

    schema_f = SchemaF[SomeDC]()
    some_dc = SomeDC("test")
    dumped = schema_f.dumps(some_dc, many=False)
    assert "test" in dumped



# Generated at 2022-06-11 21:08:56.813720
# Unit test for function build_type
def test_build_type():
    build_type(type({}), {}, object, object, object)
    build_type(type(None), {}, object, object, object)
    build_type(Decimal, {}, object, object, object)
    build_type(type(list()), {}, object, object, object)


# Generated at 2022-06-11 21:08:59.027110
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert not hasattr(_IsoField, '__init_subclass__')


# Generated at 2022-06-11 21:09:09.035382
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # type: () -> None
    @dataclasses_json.dataclass_json
    @dataclasses.dataclass
    class DC:
        pass

    schema = dataclasses_json.config.Schema.from_dataclasses(DC)
    assert isinstance(schema, SchemaF[DC])
    assert schema.dump([DC()], True) == [{}]
    assert schema.dumps([DC()], True) == "[{}]"
    assert schema.dump(DC()) == {}
    assert schema.dumps(DC()) == "{}"
    assert schema.load_from_file('{"a": 1}') == {'a': 1}
    assert schema.load_from_file(b'{"a": 1}', many=True) == [{'a': 1}]



# Generated at 2022-06-11 21:09:15.191264
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclasses.dataclass
    class A:
        x: List[int]

    class A_Schema(SchemaF[A]):
        x = fields.List(fields.Int())

    a = A([1, 2, 3])
    a_schema = A_Schema()
    a_encoded = a_schema.dump(a)
    assert a_encoded == {'x': [1, 2, 3]}



# Generated at 2022-06-11 21:09:26.522138
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from marshmallow import Schema
    """
    For testing purposes we create a simple dataclass that has a field
    with a type that is very similar to the _DictStrAny type in dataclasses_json
    """
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class test(DataClassJsonMixin):
        a: dict
        b: int

    test_schema = schema(test, DataClassJsonMixin, False)
    assert isinstance(test_schema['a'], fields.Dict), \
        'field a should have a type of Dict'

# Generated at 2022-06-11 21:09:30.770833
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    assert typing.get_type_hints(SchemaF.loads) == {
        'self': SchemaF,
        'json_data': JsonData,
        '*': typing.Any,
        '**': typing.Any,
        'return': TOneOrMulti
    }



# Generated at 2022-06-11 21:09:36.808216
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    value = field.deserialize(datetime.now().timestamp())
    assert value.__class__ is datetime, value.__class__
    assert value.timestamp() == datetime.now().timestamp(), \
        '{0} == {1}'\
            .format(value.timestamp(),
                    datetime.now().timestamp())

# Generated at 2022-06-11 21:09:47.308974
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin
    class _Mixin(DataClassJsonMixin):
        @classmethod
        def from_dict(cls, d: typing.Dict[str, typing.Any]) -> '_Mixin':
            # TODO: Implement this
            return cls(**d)

        def to_dict(self) -> typing.Dict[str, typing.Any]:
            # TODO: Implement this
            return self.__dict__

        def to_json(self) -> str:
            # TODO: Implement this
            return self.to_dict()

        @classmethod
        def from_json(cls, json_str: str) -> '_Mixin':
            # TODO: Implement this
            return cls.from_dict

# Generated at 2022-06-11 21:09:53.126442
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields
    class PersonSchema(SchemaF[Person]):
        schema_class_override = Person
        name = fields.Str()

    person = Person("Monty", datetime(2015, 1, 1, 0, 30))
    person_dict = PersonSchema().dump(person)
    assert person_dict == {'name': "Monty"}



# Generated at 2022-06-11 21:10:03.800303
# Unit test for constructor of class _IsoField
def test__IsoField():
    # _IsoField()
    assert _IsoField() is not None


# Generated at 2022-06-11 21:10:15.979970
# Unit test for function build_type
def test_build_type():
    from . import dataclass_json
    import typing
    @dataclass_json
    class A:
        a: typing.List[str]

    @dataclass_json
    class B:
        a: typing.Mapping[str, int]

    @dataclass_json
    class C:
        a: typing.Dict[str, int]

    @dataclass_json
    class D:
        a: typing.Tuple[str, int]

    @dataclass_json
    class E:
        a: typing.Collection

    @dataclass_json
    class F:
        a: typing.Any

    @dataclass_json
    class G:
        a: dict

    @dataclass_json
    class H:
        a: list


# Generated at 2022-06-11 21:10:19.944259
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(1, None, None) == 1
    assert _TimestampField()._deserialize(1, None, None) == _timestamp_to_dt_aware(1)



# Generated at 2022-06-11 21:10:27.661452
# Unit test for function build_type
def test_build_type():
    import pytest

    # Tests
    @dataclass_json
    @dataclass
    class A:
        a: str

    @dataclass_json(mm_field=fields.String)
    @dataclass
    class B:
        b: str

    @dataclass_json(mm_field=lambda type_, options, mixin, field, cls:
                    fields.Integer())
    @dataclass
    class C:
        c: int

    @dataclass_json(mm_field=lambda type_, options, mixin, field, cls:
                    fields.Field(**options))
    @dataclass
    class D:
        d: int


# Generated at 2022-06-11 21:10:37.239104
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json(letter_case=LetterCase.CAMEL)
    @dataclass
    class DataClassWithSerialization:
        field1: str
        field2: int
        field3: str = field(metadata={"dataclasses_json": {"m": "mmm"}})
        field4: datetime
        field5: List[int]
        field6: Optional[List[int]]
        field7: Union[int, str]
        field8: Optional[Union[int, str]]
        field9: Enum
        field10: Optional[Enum]

    @dataclass
    class DataClassWithSerializationX(DataClassWithSerialization):
        new_field: str


    @dataclass
    class DataClassWithoutSerialization:
        field1: str
        field2: int
       

# Generated at 2022-06-11 21:10:44.384802
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema = SchemaF[int].loads('5')
    assert schema == 5
    schema = SchemaF[int].loads('5', many=True)
    assert schema == [5]
    schema = SchemaF[int].loads(b'5')
    assert schema == 5
    schema = SchemaF[int].loads(b'5', many=True)
    assert schema == [5]



# Generated at 2022-06-11 21:10:51.351311
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_date = '2020-01-01T01:24:25'
    iso_field = _IsoField()
    value = iso_field.serialize(datetime.fromisoformat(iso_date))
    assert iso_date == value
    value = iso_field.serialize(None)
    assert None == value


# Generated at 2022-06-11 21:11:02.128129
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from typing import List, Optional
    
    @dataclass
    class Address:
        street: Optional[str]
        city: str
        country: str
        number: Optional[int]
        
    @dataclass
    class Customer:
        id: str
        name: Optional[str]
        last_name: Optional[str]
        addresses: List[Address]
        created: datetime
        
    DataClassSchema = build_schema(Customer, None, False, False)
    dcs = DataClassSchema()

# Generated at 2022-06-11 21:11:14.067821
# Unit test for function build_schema
def test_build_schema():
    from marshmallow import Schema
    from typing import List
    class Foo(Schema):
        from typing import Optional
        a = c = 'a'
        b = d = 1
        e = Optional[int]
        f = List[int]
        g = {'a': 1, 'b': 2}
        h = [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]
        Meta = type('Meta', (), {'fields': ('a', 'b', 'e', 'f', 'g', 'd', 'h')})

        @post_load
        def make_dataclass(self, kvs, **kwargs):
            kvs['d'] = 2
            kvs['c'] = 'b'
            return kvs
    s = Foo()

# Generated at 2022-06-11 21:11:20.523187
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    import json

    class TestClass:
        pass

    class TestSchema(SchemaF[TestClass]):
        pass

    schema = TestSchema()
    assert isinstance(schema.loads(json.dumps([TestClass()])), list)
    assert isinstance(schema.loads(json.dumps(TestClass())), TestClass)
    # Test overloaded method load
    assert isinstance(schema.load([TestClass()]), list)
    assert isinstance(schema.load(TestClass()), TestClass)

# Generated at 2022-06-11 21:11:38.134651
# Unit test for function schema
def test_schema():
    import json
    import unittest

    class MyTestCase(unittest.TestCase):
        def test_something(self):
            import datetime
            from dataclasses import dataclass, field
            from dataclasses_json import dataclass_json

            @dataclass_json
            @dataclass
            class Time(object):
                hour: int
                minute: int

            @dataclass_json
            @dataclass
            class TimeSchema(Schema):
                hour: fields.Int()
                minute: fields.Int()


# Generated at 2022-06-11 21:11:46.761628
# Unit test for constructor of class _IsoField
def test__IsoField():
    from datetime import datetime
    from marshmallow import Schema
    from marshmallow.exceptions import ValidationError
    from marshmallow.fields import String
    from marshmallow.utils import isoformat
    from dataclasses_json.marshmallow_schemas import _IsoField
    def test__IsoField():
        class TestSchema(Schema):
            test_field = _IsoField(String())
        test_data = TestSchema().load({'test_field': isoformat(datetime.now())})
        assert isinstance(test_data['test_field'], datetime)
        with pytest.raises(ValidationError):
            TestSchema().load({'test_field': 'invalid_datetime_format'})
    test__IsoField()


# Generated at 2022-06-11 21:11:49.187611
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema

    class SchemaF(Schema, typing.Generic[A]):
        pass


# Generated at 2022-06-11 21:11:52.044029
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    field._deserialize('2020-01-17T01:04:01.187843')
    field._serialize(datetime(2020, 1, 17, 1, 4, 1, 187843))


# Generated at 2022-06-11 21:11:52.613949
# Unit test for function build_type
def test_build_type():
    pass



# Generated at 2022-06-11 21:11:59.049978
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    sf = SchemaF[int]()
    assert sf.load(1) == 1
    assert sf.load([1, 2, 3]) == [1, 2, 3]
    assert sf.loads('[1, 2, 3]') == [1, 2, 3]


# Generated at 2022-06-11 21:12:07.077236
# Unit test for function schema
def test_schema():
    import marshmallow as ma
    from dataclasses_json.mm import MM
    import dataclasses

    @dataclasses.dataclass
    class B(MM):
        b: str = 'b'
        foo: bool = False
        none: str = None
        dc: B = dataclasses.field(default=None)
    b = B()
    class _B(ma.Schema):
        b = ma.fields.Str()
        foo = ma.fields.Bool()
        none = ma.fields.Str()
        dc = ma.fields.Nested('B')

        class Meta:
            unknown = ma.EXCLUDE
    assert schema(B, MM, False) == _B().declared_fields


# Generated at 2022-06-11 21:12:08.882095
# Unit test for function build_schema
def test_build_schema():
    class SomeClass:
        config: Any = None

    assert build_schema(SomeClass, None, None, None) == SomeClass



# Generated at 2022-06-11 21:12:17.121638
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields

    class DummySchema(Schema):
        name = fields.Str()
        weight = fields.Decimal(required=True, as_string=True)
        age = fields.Int()

        class Meta:
            unknown = "EXCLUDE"

    # Test many=True
    s = DummySchema(many=True)
    dump_result_many = s.dump([{'name': 'Foo', 'weight': 1.1},
                                   {'name': 'Bar', 'weight': 2.2}])
    assert dump_result_many == [{'name': 'Foo', 'weight': '1.10'}, # type: ignore
                                    {'name': 'Bar', 'weight': '2.20'}] # type: ignore

    # Test many=False
   

# Generated at 2022-06-11 21:12:27.959791
# Unit test for function build_schema
def test_build_schema():
    from marshmallow import ValidationError

    class Inner:
        def __init__(self, x: int):
            self.x = x

    # noinspection PyUnusedLocal
    @dataclass_json
    class A:
        a: int
        b: str
        c: typing.Optional[Inner]
        d: typing.Optional[int]

    S = build_schema(A, False)
    assert isinstance(S.c, fields.Nested)
    assert isinstance(S.d, fields.Int)
    assert S.d.allow_none is True
    try:
        assert S.d.missing is None
    except AttributeError:
        # marshmallow==3.0.0b9
        assert S.d.default is None


# Generated at 2022-06-11 21:13:54.816782
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from marshmallow import Schema, fields
    import sys
    import typing

    from dataclasses_json.core import TypeWrapper

    class InnerSchema(Schema):
        pass

    @dataclass
    class InnerDataClass:
        name: str = 'name'
        value: typing.Optional[int] = 1

        class Meta:
            json_module = None
            # render_module = global_config.json_module
            enums = None
            encoders = None

    @dataclass
    class DateTimeWrapper(TypeWrapper):
        pass

    @dataclass
    class InnerDataClassWithSchema(InnerDataClass):
        class Meta:
            # render_module = global_config.json_module
            schema_cls = InnerSchema



# Generated at 2022-06-11 21:14:03.950599
# Unit test for function build_schema

# Generated at 2022-06-11 21:14:13.015540
# Unit test for function build_schema
def test_build_schema():
    class MyClass(SchemaType): ...

    for i in range(1, 5):
        with pytest.raises(NotImplementedError):  # can't be instantiated
            MyClass()

    assert MyClass().dump(None) is None

    class MyClass(SchemaType[int]): ...

    with pytest.raises(NotImplementedError):  # can't be instantiated
        MyClass()

    assert MyClass().dump(None) is None

    class MyClass(SchemaType[int, str]): ...

    with pytest.raises(NotImplementedError):  # can't be instantiated
        MyClass()

    assert MyClass().dump(None) is None

# Generated at 2022-06-11 21:14:15.596788
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()
    assert _TimestampField(required=True)

####################
# Core classes
####################


# Generated at 2022-06-11 21:14:17.514596
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    u = SchemaF[typing.Any]() # type: SchemaF


# Generated at 2022-06-11 21:14:27.482495
# Unit test for function schema
def test_schema():
    from marshmallow import fields
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    
    @dataclass_json
    @dataclass
    class Person:
        name: str = 'foo'
        age: int = None
        flag: bool = True
        birthdate: datetime = None
        not_func_field: str = fields.Field(dump_to='not_func')
    
    # ensure type_ hints are passed properly
    print(Person.schema().fields)
    assert Person.schema().fields['name']._type_hint == str
    assert Person.schema().fields['age']._type_hint == int
    assert Person.schema().fields['flag']._type_hint == bool

# Generated at 2022-06-11 21:14:37.830447
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    if sys.version_info >= (3, 7):
        from dataclasses import dataclass
        from marshmallow import Schema, fields

        @dataclass
        class Foo:
            id: int
            name: str

        class FooSchema(SchemaF[Foo]):
            id = fields.Integer()
            name = fields.String()

        foo_schema = FooSchema()

        foo = Foo(id=1, name='bar')

        assert foo_schema.dump(foo) == {'id': 1, 'name': 'bar'}
        assert foo_schema.dump([foo]) == [{'id': 1, 'name': 'bar'}]

# Generated at 2022-06-11 21:14:50.257370
# Unit test for constructor of class _IsoField
def test__IsoField():
    import pytest
    iso_field = _IsoField()
    assert iso_field._serialize(datetime(2001, 11, 23), "attr", "obj") == "2001-11-23T00:00:00"
    assert iso_field._deserialize("2001-11-23T00:00:00", "attr", "data") == datetime(2001, 11, 23)
    with pytest.raises(ValidationError) as excinfo:
        iso_field._deserialize(None, "attr", "data") == datetime(2001, 11, 23)
    assert "required" in str(excinfo.value)

# Generated at 2022-06-11 21:15:02.065576
# Unit test for function build_type
def test_build_type():
    class SomeEnum(Enum):
        A = 1
        B = 2

    @dataclass
    class SomeDataClass:
        a: str = 'A'
        b: int = 1
        c: typing.Optional[str] = None
        d: typing.List[int] = field(default_factory=list)

    @dataclass_json
    @dataclass
    class MixinDC:
        pass

    @dataclass_json
    @dataclass
    class SomeDataClassDC(MixinDC):
        a: str = 'A'
        b: int = 1
        c: typing.Optional[str] = None
        d: typing.List[int] = field(default_factory=list)

    @dataclass
    class User:
        a: SomeDataClass
        b

# Generated at 2022-06-11 21:15:14.407268
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json.core import mm_schema
    import marshmallow as mm
    import typing

    @dataclass
    class H:
        name: str = 'H'

    @dataclass
    class G:
        name: str = 'G'

    @dataclass
    class F(mm_schema()):
        name: typing.Optional[str] = 'F'
        n: int = 2
        h: H = None
        g: G = None

    s = schema(F, mm_schema, False)
    assert isinstance(s['name'], mm.fields.Field)
    assert isinstance(s['n'], mm.fields.Int)
    assert isinstance(s['h'], mm.fields.Nested)
    assert isinstance