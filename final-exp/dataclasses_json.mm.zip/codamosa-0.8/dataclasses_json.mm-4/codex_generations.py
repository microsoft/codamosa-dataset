

# Generated at 2022-06-11 21:05:38.756805
# Unit test for function build_schema
def test_build_schema():

    @dataclass_json
    @dataclass
    class Person:
        name: str
        age: int = 0
    build_schema(Person, mixin={}, infer_missing=True, partial=False)



# Generated at 2022-06-11 21:05:49.665432
# Unit test for function build_schema
def test_build_schema():
    import marshmallow.fields as fields

    class SomeClassSchema(Schema):
        Meta = type('Meta', (), {'fields': tuple()})

    def _build_schema(cls):

        schema = {}
        for field in dc_fields(cls):
            type_ = field.type
            options = {}

            if field.default is not MISSING:
                options['default'] = field.default
            elif field.default_factory is not MISSING:
                options['default'] = field.default_factory

            if options.get('default', ...) is None:
                options['allow_none'] = True

            if _is_optional(type_):
                options.setdefault('default', None)
                options['allow_none'] = True

# Generated at 2022-06-11 21:06:02.019369
# Unit test for function schema
def test_schema():
    assert schema({'a': fields.Bool(missing=False)}, {}, False) == {
        'a': fields.Bool(missing=False)}
    assert schema({'a': fields.Bool(missing=False)}, {}, True) == {
        'a': fields.Bool(missing=False)}
    assert schema({'a': fields.Bool()}, {}, False) == {
        'a': fields.Bool(default=..., allow_none=True)}
    assert schema({'a': fields.Bool()}, {}, True) == {
        'a': fields.Bool(missing=..., allow_none=True)}

# Generated at 2022-06-11 21:06:10.512273
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class Foo:
        bar: int

    DataClassSchema = build_schema(Foo, AppMetaclass, True, True)

    class Meta:
        fields = ['bar']

    assert DataClassSchema.Meta.fields == Meta.fields
    assert DataClassSchema.__name__ == 'FooSchema'
    assert DataClassSchema.__dict__['make_foo']('hello world', None, None)



# Generated at 2022-06-11 21:06:17.985844
# Unit test for function build_schema
def test_build_schema():
    from .asdict import test_asdict
    from .fromdict import test_fromdict
    from .fromjson import test_fromjson
    from .fromtuple import test_fromtuple
    from .tojson import test_tojson
    from .totuple import test_totuple

    class TestMixin:
        pass

    class TestSchemaContext:
        pass
    class TestSchema:
        @classmethod
        def schema(cls):
            return TestSchemaContext

    DataClassSchema = build_schema(TestSchema, TestMixin, infer_missing=False, partial=None)
    assert DataClassSchema.Meta.fields == tuple()

    # TODO autodetect the schema and test
    @dataclass_json
    @dataclass
    class SchemaTest1:
        pass

# Generated at 2022-06-11 21:06:28.075948
# Unit test for function schema
def test_schema():
    import dataclasses_json  # noqa
    from typing import Optional

    @dataclasses_json.dataclass_json
    class A:
        a: int = dataclasses_json.field()

    assert(schema(A, None, False) == {'a': fields.Int()})

    @dataclasses_json.dataclass_json
    class B:
        b: Optional[int] = dataclasses_json.field(allow_none=True)

    assert(schema(B, None, False) == {'b': fields.Int(allow_none=True)})



# Generated at 2022-06-11 21:06:30.441697
# Unit test for function build_schema
def test_build_schema():
    # Given
    @dataclass_json
    @dataclass
    class SomeClass:
        a: int

    # When
    s = build_schema(SomeClass, typing.Any, False, False)

    # Then
    s.Meta.fields[0].name == 'a'



# Generated at 2022-06-11 21:06:39.672282
# Unit test for function build_type
def test_build_type():
    from typing import Optional, List, Dict, Union, TypeVar
    from dataclasses import dataclass
    from marshmallow import fields
    class Generic(str):
        pass
    class Dataclass(str):
        pass
    class DataclassT(Dataclass):
        pass
    class EnumT(Enum):
        a = 'a'
    A = TypeVar('A')
    from dataclasses_json import dataclass_json, LetterCase, DataClassJsonMixin
    @dataclass_json(letter_case=LetterCase.CAMEL)
    @dataclass
    class MmUnion(DataClassJsonMixin):
        v: Union[str, int]

# Generated at 2022-06-11 21:06:47.381046
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Model:
        i: int
        b: bool

    class S(SchemaF[Model]):
        i = fields.Int()
        b = fields.Bool()

    m = Model(2, True)
    assert isinstance(S().dump(m), dict)

    ms = [Model(1, True), Model(2, False)]
    assert isinstance(S().dump(ms), list)


# Generated at 2022-06-11 21:06:51.812679
# Unit test for function schema
def test_schema():
    import pytest
    from dataclasses import dataclass
    from marshmallow import Schema as MM_Schema, fields

    @dataclass
    class Cls1:
        field1: str
        field2: int
        field3: typing.Optional[typing.Mapping[str, int]] = None

    class Schema(MM_Schema):
        field1 = fields.Field()
        field2 = fields.Field()
        field3 = fields.Field()

    assert schema(Cls1, None, False) == Schema().fields



# Generated at 2022-06-11 21:07:23.804150
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class A:
        a: str
        b: int

    @dataclass
    class B_A(A):
        c: str

    # @dataclass
    # class B(A):
    #     c: str

    # @dataclass
    # class C(B):
    #     d: str

    assert A.schema() == build_schema(A, A, False, False)
    assert B_A.schema() == build_schema(B_A, A, False, False)

# Generated at 2022-06-11 21:07:33.394678
# Unit test for function build_type
def test_build_type():
    from marshmallow import Schema, fields
    from marshmallow_enum import EnumField
    from typing import List

    from dataclasses import dataclass, field
    from dataclasses_json import DataClassJsonMixin
    from dataclasses_json.utils import CatchAllVar
    @dataclass
    class Person(DataClassJsonMixin):
        name: str

    @dataclass
    class Room(DataClassJsonMixin):
        name: str

    @dataclass
    class User(DataClassJsonMixin):
        name: str
        age: int
        friends: List[Person]
        catch_all: CatchAllVar
        age_opt: typing.Optional[int]
        optional_field: typing.Optional[int] = None

    input_fields = dc_fields(User)


# Generated at 2022-06-11 21:07:36.493488
# Unit test for function build_type
def test_build_type():
    assert callable(build_type)

    # verify that the function returns a function that is callable
    # with two args
    assert callable(build_type(None, None))



# Generated at 2022-06-11 21:07:37.600796
# Unit test for constructor of class _IsoField
def test__IsoField():
    return _IsoField()



# Generated at 2022-06-11 21:07:46.840852
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    import marshmallow
    from datetime import date
    from dataclasses import dataclass

    @dataclass
    class Model:
        id: int
        date: date

    s = SchemaF[Model]({
        'id': marshmallow.fields.Int(),
        'date': marshmallow.fields.Date()
    })

    assert s.dumps([Model(1, date.today())]) == '[{"id": 1, "date": "%s"}]' % date.today().isoformat()
    assert s.dumps(Model(1, date.today())) == '{"id": 1, "date": "%s"}' % date.today().isoformat()



# Generated at 2022-06-11 21:07:57.079811
# Unit test for function build_type
def test_build_type():

    from dataclasses_json.api import decode, encode
    from dataclasses import dataclass
    from marshmallow import Schema

    @dataclass
    class A:
        a: float

    @dataclass
    class B(mixin):
        b: A

    @dataclass
    class C(mixin):
        c: typing.Optional[B]

    class ASchema(Schema):
        class Meta:
            ordered = True
        a = fields.Float()

    class BSchema(Schema):
        class Meta:
            ordered = True
        b = fields.Nested(ASchema)

    class CSchema(Schema):
        class Meta:
            ordered = True
        c = fields.Nested(BSchema, allow_none=True)


# Generated at 2022-06-11 21:08:00.701648
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # type: () -> None
    class PointSchema(Schema):
        x = fields.Int()
        y = fields.Int()

    point_schema = PointSchema()
    loaded = point_schema.load({"x": 1, "y": 2})  # type: ignore
    assert loaded['x'] == 1



# Generated at 2022-06-11 21:08:06.883557
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # Should infer return type TOneOrMultiEncoded
    assert isinstance(SchemaF[int].dump(
        [1], many=True), typing.List[TEncoded])
    # Should infer return type TOneOrMultiEncoded
    assert isinstance(SchemaF[int].dump(1), TEncoded)
    # Should infer return type TOneOrMultiEncoded
    assert isinstance(SchemaF[typing.List[int]].dump(
        [[1]]), typing.List[TEncoded])
    # Should infer return type TOneOrMultiEncoded
    assert isinstance(SchemaF[typing.List[int]].dump(
        [[1]], many=True), typing.List[TEncoded])
    # Should infer return type TOneOrMultiEncoded

# Generated at 2022-06-11 21:08:09.370637
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert isinstance(_TimestampField(), _TimestampField)


# Generated at 2022-06-11 21:08:20.301778
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # type: () -> None
    @dataclasses_json.dataclass_json
    @dataclasses.dataclass
    class Foo(object):
        bar: str = dataclasses.field(
            metadata={dataclasses_json.config: dataclasses_json.Config()})

    assert SchemaF[Foo]().dumps(Foo(bar='baz')) == '{"bar": "baz"}'
    assert SchemaF[Foo]().dumps([Foo(
        bar='baz')]) == '[{"bar": "baz"}]'
    SchemaF[Foo]().dumps(Foo(bar='baz')) == '{"bar": "baz"}'

# Generated at 2022-06-11 21:08:56.180794
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    @dataclass
    class Dummy:
        a: int
        b: str
        c: bool = False
    from_dict = build_schema(Dummy, dict, infer_missing=True, partial=False)
    assert from_dict.dump(Dummy(a=1, b='b')) == {'a': 1, 'b': 'b', 'c': False}
    assert from_dict.dump({'a': 1, 'b': 'b'}) == {'a': 1, 'b': 'b', 'c': False}

# Generated at 2022-06-11 21:09:02.702586
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import fields, Schema

    class MySchema(SchemaF[int]):
        pass

    MySchema().dumps(0)
    MySchema().dumps([0], many=True)
    MySchema().dump([1], many=True)
    MySchema().dump(2)


# Generated at 2022-06-11 21:09:13.002244
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class TestType:
        str_: str
    assert 'str_' in build_schema(TestType, None, True, False).__dict__
    assert 'Meta' in build_schema(TestType, None, True, False).__dict__
    assert 'make_testtype' in build_schema(TestType, None, True, False).__dict__
    assert build_schema(TestType, None, True, False).__dict__['Meta'].__dict__['fields'] == ('str_',)
    assert build_schema(TestType, None, True, False).__dict__['Meta'].__dict__['ordered'] is True

# Generated at 2022-06-11 21:09:25.586298
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():  # type: ignore
    # type: () -> None
    class MyInt(int):
        pass

    # mm has the wrong return type annotation (dict) so we can ignore the mypy error
    class MySchema(SchemaF):  # type: ignore
        i = fields.Field(default=1)
        j = fields.Field()

    class MySubSchema(SchemaF):  # type: ignore
        d = fields.Field(default=1.5)
        s = fields.Field()

    out = typing.cast(
        str, MySchema(partial=('i',)).dumps({'j': 3}))  # type: ignore
    assert out == '{"j": 3}'

    out = typing.cast(str, MySchema().dumps({'i': 2, 'j': 3}))  # type:

# Generated at 2022-06-11 21:09:36.517593
# Unit test for function build_schema

# Generated at 2022-06-11 21:09:43.596808
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field._deserialize("2018-11-12T12:40:05.410010") == datetime(2018, 11, 12, 12, 40, 5, 410010, tzinfo=None)
    assert field._serialize(datetime(2018, 11, 12, 12, 40, 5, 410010, tzinfo=None)) == "2018-11-12T12:40:05.410010"


# Generated at 2022-06-11 21:09:46.898461
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), 'foobar', object())
    assert _TimestampField()._deserialize(datetime.now().timestamp(), 'foobar', object())


# Generated at 2022-06-11 21:09:48.654320
# Unit test for constructor of class _IsoField
def test__IsoField():
    obj = _IsoField()
    assert obj is not None



# Generated at 2022-06-11 21:09:57.532027
# Unit test for function schema
def test_schema():
    @dataclass
    class Bar:
        pass

    @dataclass
    class Foo:
        b: int
        i: typing.Optional[int]
        d: typing.Dict[str, int]
        l: typing.List[int]
        b1: typing.Optional[Bar]
        b2: typing.List[Bar]
        bar: Bar


# Generated at 2022-06-11 21:10:08.999527
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from typing import Optional, Type

    from dataclasses_json import DataClassJsonMixin
    from dataclasses_json.utils import _is_optional, _get_type_origin

    @dataclass
    class A(DataClassJsonMixin):
        a: int = 0
        b: Optional[str] = None
        c: Type['A'] = ()
        d: Optional['A'] = None
        f: typing.List[int] = None
        g: Optional[typing.List[str]] = None
    print('111')
    s = schema(A, DataClassJsonMixin, False)
    assert isinstance(s['a'], fields.Int)
    assert isinstance(s['b'], fields.Str)

# Generated at 2022-06-11 21:10:57.744183
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    import typing
    import marshmallow
    from dataclass_json import DataClassJsonMixin
    from dataclass_json.undefined import Undefined

    @dataclass
    class A(DataClassJsonMixin):
        a_field: str

    @dataclass
    class B(DataClassJsonMixin):
        b_field: typing.Optional[str]

        @classmethod
        def schema(cls):
            return marshmallow.fields.Str()

        @classmethod
        def _encode(cls, kvs):
            return {'b_field': kvs.get('b_field', '<b_field is not defined>')}


# Generated at 2022-06-11 21:10:59.707479
# Unit test for function schema
def test_schema():
    assert isinstance(schema({'key1': fields.Int()}, Schema, False), dict)



# Generated at 2022-06-11 21:11:04.052991
# Unit test for function schema
def test_schema():
    from pydantic import BaseModel
    from typing import List

    class MyModel(BaseModel):
        a = str
        b = int

    class MySubModel(MyModel):
        c = List[MyModel]



# Generated at 2022-06-11 21:11:14.434403
# Unit test for function build_type
def test_build_type():
    try:
        warnings.warn = lambda *args, **kwargs: None
        class Test:
            pass

        class TestA(Test):
            def __init__(self, a):
                self.a = a

            def __eq__(self, other):
                return self.a == other.a

        assert build_type(TestA, {}, Test, Test, Test)(TestA, {}).__class__ == fields.Nested
        # Nested is not a possible subclass for other fields
        assert build_type(TestA, {}, Test, Test, Test)(list, {}).__class__ != fields.Nested
    finally:
        warnings.warn = lambda *args, **kwargs: print(*args, **kwargs)



# Generated at 2022-06-11 21:11:24.578493
# Unit test for method load of class SchemaF
def test_SchemaF_load():  # type: ignore
    from typing import List, Optional
    from marshmallow import Schema, fields
    class FooSchema(SchemaF[Foo]):
        a: int
        b: str = fields.String(required=False)

        @post_load
        def make_foo(self, data, many):
            return Foo(**data)
    # pass

    class Foo:
        def __init__(self, a: int, b: Optional[str] = None):
            self.a = a
            self.b = b
    assert isinstance(FooSchema.load([{'a': 1}]), List[Foo])
    assert isinstance(FooSchema.load({'a': 1}), Foo)

# Generated at 2022-06-11 21:11:32.517610
# Unit test for function build_schema
def test_build_schema():
    class Person:
        def __init__(self, name: str, age: int = 10, weight: float = None, alive: bool = True, uuid: UUID = None):
            self.name = name
            self.age = age
            self.weight = weight
            self.alive = alive
            self.uuid = uuid

    class PersonSchema(Schema):
        name = fields.Str()
        age = fields.Int()
        weight = fields.Float()
        alive = fields.Bool()
        uuid = fields.UUID()

    class NewPerson:
        def __init__(self, name: str, age: int = 10, weight: float = None, alive: bool = True, uuid: UUID = None):
            self.name = name
            self.age = age

# Generated at 2022-06-11 21:11:44.745245
# Unit test for function build_schema
def test_build_schema():
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class Simple:
        name: str

    assert build_schema(Simple, {}) == {
        "name": fields.Str(default=MISSING, data_key="name",
                           required=True, allow_none=True)
    }

    @dataclass_json
    @dataclass
    class Optional:
        name: Optional[str]

    assert build_schema(Optional, {}) == {
        "name": fields.Str(default=MISSING, data_key="name",
                           required=False, allow_none=True)
    }

    @dataclass_json
    @dataclass
    class Default:
        name: str = "John"

    assert build_

# Generated at 2022-06-11 21:11:53.958547
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin, dataclass_json
    from datetime import date
    from typing import List, Union, Optional

    @dataclass
    class Foo(DataClassJsonMixin):
        bar: str

    @dataclass_json
    class B(DataClassJsonMixin):
        s: str
        i: int
        d: Decimal
        o: Optional[int]
        f: Foo
        l: List[int]

    @dataclass_json
    class C(DataClassJsonMixin):
        b: Union[int, str, list]
        d: Union[date, str]

    dcb, dcc = B.schema(), C.schema()

# Generated at 2022-06-11 21:12:03.834913
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Test1(SchemaF[int]):
        pass
    assert Test1.loads('[1,2,3]') == [1, 2, 3]
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        Test1.loads(b'[1,2,3]')
        assert len(w) == 1
        assert issubclass(w[-1].category, UserWarning)
        assert 'bytes' in str(w[-1].message)
    class Test2(SchemaF[int]):
        pass
    assert Test2.loads('1') == 1



# Generated at 2022-06-11 21:12:14.469367
# Unit test for function schema

# Generated at 2022-06-11 21:13:48.677045
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class SomeSchema(SchemaF):
        id = fields.Int(allow_none=False)

    assert SomeSchema().dumps({'id': 1}, many=False) == '{"id": 1}'
    assert SomeSchema().dumps({'id': 1}, many=True) == '[{"id": 1}]'

    assert SomeSchema().dumps([{'id': 1}], many=True) == '[{"id": 1}]'
    assert SomeSchema().dumps([{'id': 1}], many=False) == '[{"id": 1}]'

    assert SomeSchema().dumps([{'id': 1}, {'id': 2}], many=True) == '[{"id": 1}, {"id": 2}]'

# Generated at 2022-06-11 21:13:53.538635
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class TestSchema:
        string: str
        integer: int
        number: float
        boolean: bool
        date: datetime
        date2: Optional[datetime] = None
        datetime: datetime

    DataClassSchema = build_schema(typing.Type[TestSchema], None, False, False)
    assert isinstance(DataClassSchema(strict=True).fields['string'], fields.Str)

# Generated at 2022-06-11 21:13:57.848394
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclass_json
    @dataclass
    class X:
        a: str
        b: int
    x = [X('a', 1), X('b', 2)]
    S = typing.cast(schema.Schema, SchemaF[X])
    assert S().dump(x) == [{'a': 'a', 'b': 1}, {'a': 'b', 'b': 2}]


# Generated at 2022-06-11 21:14:02.219114
# Unit test for function build_schema
def test_build_schema():
    class S(Schema):
        a = fields.Field()
        b = fields.Field()

    class A(dataclass):
        a: int
        b: int

    assert S.Meta.fields == ('a', 'b')
    assert set(build_schema(A, None, True, True).Meta.fields) == {'a', 'b'}



# Generated at 2022-06-11 21:14:12.416231
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    import marshmallow as mm
    from dataclasses_json import dataclass_json
    from dataclasses import asdict
    from marshmallow import Schema, fields
    @dataclass_json
    @dataclass
    class User:
        name: str
        age: int
        scheme: mm.fields.Dict
        schem: mm.fields.Dict
    UserSchema = build_schema(User, None, True, False)
    user_schema = UserSchema()
    user = User("marshmallow", 17, {'hello': 'world'}, {})
    user_dict = asdict(user)
    user_dict['name'] = 'marshmallow_callable'
    user_dict['age'] = 18
    user_dump = user_schema

# Generated at 2022-06-11 21:14:20.844246
# Unit test for function schema
def test_schema():
    from typing import Dict, Any
    from dataclasses import dataclass

    @dataclass
    class Foo:
        a: int
        b: Dict[int, Any] = field(metadata=dict(dataclasses_json=dict(mm_field=fields.Str())))

    assert schema(Foo, None, True) == {'a': fields.Int(allow_none=True, missing=None), 'b': fields.Str()}
    assert schema(Foo, None, False) == {'a': fields.Int(allow_none=True, default=None), 'b': fields.Str()}



# Generated at 2022-06-11 21:14:25.404938
# Unit test for constructor of class _IsoField
def test__IsoField():
    test_value = datetime.now()
    field = _IsoField(default=test_value, required=None)
    assert field._serialize(test_value, None, None) != None
    assert field._deserialize(test_value.isoformat(), None, None) != None


# Generated at 2022-06-11 21:14:31.166209
# Unit test for function schema
def test_schema():
    class _S(Schema):
        x = fields.Int()
        y = fields.Str()
        z = fields.UUID()
    _S()

if sys.version_info >= (3, 7):
    class SchemaF(Schema, typing.Generic[A]):
        """Lift Schema into a type constructor"""

        def __init__(self, *args, **kwargs):
            """
            Raises exception because this class should not be inherited.
            This class is helper only.
            """

            super().__init__(*args, **kwargs)
            raise NotImplementedError()


# Generated at 2022-06-11 21:14:32.590394
# Unit test for function build_schema
def test_build_schema():
    assert _issubclass_safe(build_schema, Schema)

# Generated at 2022-06-11 21:14:37.384016
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field.__repr__() == '<_TimestampField>'
    assert field.__str__() == '_TimestampField'
    assert field.__module__ == __name__
    assert field.__name__ == '_TimestampField'
    assert field.__class__.__name__ == 'TimestampField'

