

# Generated at 2022-06-11 21:05:46.703101
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from typing import List
    from marshmallow import Schema, fields
    class Schema1(SchemaF[List[int]]):
        id = fields.Int(required=True)
    class Schema2(SchemaF[int]):
        id = fields.Int(required=True)
    class Schema3(SchemaF[int]):
        id = fields.Int(required=True)
    s1 : SchemaF[List[int]] = Schema1()
    s2 : SchemaF[int] = Schema2()
    s3 : SchemaF[int] = Schema3()
    x = s1.load([{
        "id": 1
    }])
    y = s2.load({
        "id": 1
    })

# Generated at 2022-06-11 21:06:00.058666
# Unit test for function build_schema
def test_build_schema():
    """
    A unit test for the function build_schema

    Returns
    -------
    :return: None
    """
    from typing import Optional, List, Union
    from enum import Enum
    from dataclasses import dataclass, asdict
    from marshmallow import Schema, fields, post_load
    from marshmallow.validate import Length, Range
    from uuid import UUID
    from decimal import Decimal

    class Ipv4Address(str, Enum):
        LOCAL_HOST = "127.0.0.1"

    @dataclass
    class Ipv6Address:
        address: str

        @classmethod
        def schema(cls):
            return fields.String()

    @dataclass
    class Person:
        name: str
        surname: str
        age: int
       

# Generated at 2022-06-11 21:06:06.957894
# Unit test for function schema
def test_schema():
    import pytest
    from dataclasses_json.mm import MM
    from typing import Optional, List

    class A(dataclasses.dataclass, MM):
        a: Optional[List[int]]
        b: str = 'non'
        c: int = 0
        d: str = 'default'

    s = schema(A, MM, False)
    assert s == \
        {
            'a': fields.List(),
            'b': fields.Str(),
            'c': fields.Int(),
            'd': fields.Str(default='default'),
        }
    # Test for Optional[CatchAllVar] as a type
    with pytest.raises(NotImplementedError):
        s = schema(A, MM, False)

# Generated at 2022-06-11 21:06:12.519231
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # type: () -> None
    class MySchema(SchemaF[str]):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    s = MySchema()
    assert [{}] == s.dump([''])
    assert {} == s.dump('')



# Generated at 2022-06-11 21:06:19.617650
# Unit test for function build_schema
def test_build_schema():
  import sys
  sys.path.append('..')
  from script_processing.session_wrapper import SessionWrapper
  from dataclasses import dataclass, field
  from dataclasses_json import dataclass_json
  from datetime import datetime, date
  import pytz

  @dataclass_json
  @dataclass
  class Period:
    start: datetime
    end: date = date.min


  @dataclass_json
  @dataclass
  class Data:
    name: str
    period: Period = field(default_factory=lambda: Period(datetime(2020, 1, 1, tzinfo=pytz.timezone('Europe/Moscow'))))


# Generated at 2022-06-11 21:06:31.230726
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Foo(SchemaF):
        pass
    f = Foo()
    assert f.load(5) == 5
    assert f.load('string') == 'string'
    assert f.load(5, many=False) == 5
    assert f.load('string', many=False) == 'string'
    assert f.load([5, 10], many=True) == [5, 10]
    assert f.load(['string', 'otherstring'], many=True) == ['string', 'otherstring']
    f = Foo(unknown='EXCLUDE')
    assert f.load(5) == 5
    assert f.load('string') == 'string'
    assert f.load(5, many=False) == 5
    assert f.load('string', many=False) == 'string'

# Generated at 2022-06-11 21:06:32.260299
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    _TimestampField()



# Generated at 2022-06-11 21:06:33.717584
# Unit test for constructor of class _IsoField
def test__IsoField():
    pass


generic_type_mapping = {object: str}



# Generated at 2022-06-11 21:06:40.628109
# Unit test for constructor of class _IsoField
def test__IsoField():
    @dataclass
    class User:
        name: str
        dt: datetime

    user_schema = Schema.from_dataclass(User)
    test_user = User("test_user", datetime.now())
    user_json = user_schema.dumps(test_user)
    loaded_user = user_schema.loads(user_json)
    assert(loaded_user.dt == test_user.dt)



# Generated at 2022-06-11 21:06:50.024836
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Person(SchemaF):
        name = fields.String()
        age = fields.Integer()

    person = Person(unknown='raise')
    person.dump(dict(age=10, name='Jim'))
    person.dumps(dict(age=10, name='Jim'))
    person.dumps([dict(age=10, name='Jim')])
    person.dumps([dict(age=10, name='Jim'), dict(age=11, name='Jack')])
    person.dump(dict(age=10, name='Jim'), many=True)
    person.dump([dict(age=10, name='Jim')])
    person.dump([dict(age=10, name='Jim'), dict(age=11, name='Jack')])



# Generated at 2022-06-11 21:07:10.942657
# Unit test for function build_schema
def test_build_schema():
    '''
    Test the function by a simple data class
    '''
    @dataclass_json
    @dataclass
    class DataClass:
        a: int
        b: int
    dc = DataClass(1,2)
    dc_schema = build_schema(DataClass, [], False, False)
    assert isinstance(dc_schema, type(Schema))
    assert isinstance(dc_schema(), Schema)
    assert isinstance(dc_schema().dump(dc), dict)
    assert isinstance(dc_schema().load(dc_schema().dump(dc)), DataClass)
    print('Test passed')



# Generated at 2022-06-11 21:07:22.582016
# Unit test for function build_type
def test_build_type():
    class Test_Enum(Enum):
        value1 = 1
        value2 = 2

    import typing


    @dataclass_json
    @dataclass
    class Test_Nested(SchemaType):
        foo: str
        bar: int
        baz: int = 1


    @dataclass_json
    @dataclass
    class Test_Schema(SchemaType):
        num: int
        num_opt: typing.Optional[int] = None
        str_opt: typing.Optional[str] = None
        f: float
        f_opt: typing.Optional[float] = None
        b: bool
        b_opt: typing.Optional[bool] = None
        dt: datetime
        dt_opt: typing.Optional[datetime] = None

# Generated at 2022-06-11 21:07:32.718019
# Unit test for function build_type
def test_build_type():
    from marshmallow import Schema, fields
    from marshmallow_enum import EnumField
    from dataclasses import dataclass
    from enum import Enum
    from typing import List, Union

    class TeEnum(Enum):
        a = 1
        b = 2
        c = 3

    @dataclass
    class TeDataclass:
        pass

    class TeSchema(Schema):
        pass

    @dataclass
    class MixTest:
        field: typing.Any = "data"
        field2: typing.Mapping = {1: 2, 3: 4}
        field3: typing.List[int] = [1, 2, 3]
        field4: typing.Union[float, str] = "data"
        field5: typing.Callable = lambda x: x

# Generated at 2022-06-11 21:07:43.338680
# Unit test for function build_schema
def test_build_schema():
    from . import dataclass_json
    from typing import Optional

    @dataclass_json
    @dataclass
    class A:
        id: int
        name: str
        age: Optional[int]

    class B:
        def __init__(self, id):
            self.id = id

    @dataclass_json(letter_case=LetterCase.snake)
    @dataclass
    class C:
        id: int
        name: str = field(metadata=dict(dataclasses_json=dict(mm_field=fields.Int())))
        age: Optional[int] = field(metadata=dict(dataclasses_json=dict(mm_field=fields.Int())))

# Generated at 2022-06-11 21:07:50.742517
# Unit test for function schema
def test_schema():
    from dataclasses_json.utils import types, to_camel_case, to_snake_case
    import marshmallow.fields as mfields
    # 1. Nested
    """
    class A(Schema, typing.Generic[A]):
        pass
    class B(A[C]):
        pass
    """
    # 2. Optional
    """
    class A(Schema, typing.Generic[A]):
        @TODO: Are Optional fields always nullable?
        a = mfields.Field(required=False)
    class B(A[C]):
        a = Optional[List[Decimal]]
    """
    # 3. TypeVar

# Generated at 2022-06-11 21:07:53.310282
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_field = _IsoField()
    x = datetime.now()
    assert x == iso_field._deserialize(x.isoformat(), None, None)


# Generated at 2022-06-11 21:07:55.132284
# Unit test for constructor of class _IsoField
def test__IsoField():
  field = _IsoField()
  assert field.__repr__() == '<IsoField()>'



# Generated at 2022-06-11 21:08:04.757688
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    typeData = typing.List[typing.Any]  # type: ignore
    typeData = typing.List[typing.Any]  # type: ignore



# Generated at 2022-06-11 21:08:17.651862
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import config

    @dataclass
    class DataClass:
        name: str
        val: int
        fl: float
        uuid: UUID
        dt: datetime
        d: Decimal
        e: Enum = Enum('Enum', ('FOO', 'BAR'))
        i: Enum = Enum('Enum', ('FOO', 'BAR'), type_=int)
        t: typing.Tuple = ('foo', 'bar')
        l: typing.List[int] = None

        def __post_init__(self):
            self.l = list(range(10))

        def __init__(self, other: str = 'foo'):
            self.other = other



# Generated at 2022-06-11 21:08:20.133369
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso = datetime.now().isoformat()
    assert (_IsoField()._deserialize(iso, "", {}) ==
            datetime.fromisoformat(iso))


# Generated at 2022-06-11 21:08:57.127910
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass
    class R:
        a: typing.List[typing.Mapping[str, int]]

    @dataclass_json
    class A:
        r: R
        b: typing.List[int]
        c: str = 'hi'
        d: typing.List[str] = None
        e: typing.Set[int]
        f: typing.Optional[int] = 5
        g: typing.Optional[typing.Dict[str, typing.Optional[int]]] = None
        h: typing.Optional[typing.Union[str, int]] = 'a'
        i: typing.Optional[typing.Union[str, int, None]] = None
       

# Generated at 2022-06-11 21:09:08.415364
# Unit test for function schema
def test_schema():
    import marshmallow as ma
    from dataclasses_json.mixin import JsonMixin, ExtraTypeMixin, SchemaMixin
    from dataclasses import dataclass, asdict

    from typing import Optional
    import uuid
    from decimal import Decimal

    class B(ma.Schema, ExtraTypeMixin): # tested class
        name: str
        time: Optional[datetime] = None
        date: Optional[datetime]
        time_iso: Optional[datetime]
        uid: uuid.UUID
        decimal: Decimal

    @dataclass
    class A(JsonMixin, ExtraTypeMixin): # tested class
        name: str
        time: datetime = None
        date: datetime
        time_iso: datetime
        uid: uuid.UUID
        decimal: Dec

# Generated at 2022-06-11 21:09:10.584429
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class MySchema(SchemaF[A]):
        pass

    MySchema(many=True).dumps(['test'])



# Generated at 2022-06-11 21:09:12.312995
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field is not None


# Generated at 2022-06-11 21:09:17.543961
# Unit test for function schema
def test_schema():
    class Example:
        def __init__(self, a: int):
            self.a = a

    assert schema(Example, None, False) == {'a': fields.Int()}
    assert schema(Example, None, True) == {'a': fields.Int(missing=None, allow_none=True)}


# Generated at 2022-06-11 21:09:25.720900
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # mm has the wrong return type annotation (dict) so we can ignore the mypy error
    SchemaF[List[int]].dump([1, 2, 3, 4], many=True)
    # $ExpectError[call-arg]
    SchemaF[List[int]].dump([1, 2, 3, 4], many=False)
    SchemaF[int].dump(1, many=False)
    # $ExpectError[call-arg]
    SchemaF[int].dump(1, many=True)


# Generated at 2022-06-11 21:09:36.660036
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    def test_impl(schema: SchemaF[A], data: TOneOrMultiEncoded, many: bool = None, partial: bool = None,
                  unknown: str = None) -> TOneOrMulti:
        return schema.load(data, many, partial, unknown)



# Generated at 2022-06-11 21:09:39.107577
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert isinstance(field, fields.Field)



# Generated at 2022-06-11 21:09:46.548614
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    """
    For now just to guarantee that changes do not break this typing without mypy.
    Also, we do not want to use mypy because it is not able to detect the type annotations
    in the decorators like typing.overload
    """
    def _test_SchemaF_dumps(obj, many, *args, **kwargs):
        # type: (TOneOrMulti, bool, *args, **kwargs) -> str
        schema = SchemaF[A]()
        return schema.dumps(obj, many, *args, **kwargs)



# Generated at 2022-06-11 21:09:51.578164
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    json_data = b'{"name": "foo"}'
    # Define a class
    @dataclass_json
    @dataclass
    class User:
        name: str
    schema = SchemaF[User]()
    user = schema.loads(json_data)
    assert (user.name == "foo")



# Generated at 2022-06-11 21:11:15.794867
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class A:
        pass
    class B(SchemaF[A]):
        pass
    assert isinstance(B.loads([]), typing.List[A])
    assert isinstance(B.loads(''), A)
    assert isinstance(B.loads(b''), A)
    assert isinstance(B.loads(bytearray()), A)

# Generated at 2022-06-11 21:11:16.838801
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()


# Generated at 2022-06-11 21:11:27.418090
# Unit test for function build_schema
def test_build_schema():
    schema_ = build_schema(cls=MappingClass, mixin=None, infer_missing=True, partial=False)
    assert type(schema_).__name__ == 'MappingClassSchema'
    assert hasattr(schema_, 'Meta')
    assert hasattr(schema_, 'make_mappingclass')
    assert hasattr(schema_, 'dumps')
    assert hasattr(schema_, 'dump')
    assert hasattr(schema_, 'my_mapping')
    assert hasattr(schema_, 'my_list')
    assert hasattr(schema_, 'my_str')
    assert hasattr(schema_, 'my_int')
    assert hasattr(schema_, 'my_bool')
    assert hasattr(schema_, 'my_optional')

# Generated at 2022-06-11 21:11:37.426536
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from enum import Enum
    from dataclasses_json import dataclass_json, DataClassJsonMixin

    @dataclass
    class A(DataClassJsonMixin):
        a: int

    @dataclass_json
    @dataclass
    class B(DataClassJsonMixin):
        b: str
        b_: str = dataclass_json(data_key='b__')
        b__: str
        b___: str = dataclass_json(data_key='b')
        c: typing.List[str]
        a: typing.Union[str, int, A]
        d: typing.Union[str, int]
        e: typing.List[A]
        f: typing.Union[str, int, A, None] 

# Generated at 2022-06-11 21:11:45.345187
# Unit test for function build_type
def test_build_type():
    if sys.version_info >= (3, 5):
        from dataclasses import dataclass, field

        @dataclass
        class A(SchemaMixin):
            @classmethod
            def schema(cls) -> SchemaType:
                return SchemaType(cls)

        class B(SchemaMixin):
            @classmethod
            def schema(cls) -> SchemaType:
                return SchemaType(cls)

        @dataclass
        class C(A):
            @classmethod
            def schema(cls) -> SchemaType:
                return SchemaType(cls)

        @dataclass
        class D:
            pass


# Generated at 2022-06-11 21:11:50.095293
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import fields, Schema
    class MySchema(SchemaF[str]):
        pass
    MySchema.Meta = type('Meta', (), {'fields': {'a': fields.Int()}})
    s = MySchema()
    s.dump({'a': 'b'})


# Generated at 2022-06-11 21:12:02.567666
# Unit test for function schema
def test_schema():
    from dataclasses_json.mm import dataclass_json
    @dataclass_json
    @dataclass
    class A:
        some_string: str
        some_list: list
    assert schema(A, object, False) == {'some_string': fields.Str(), 'some_list': fields.List()}
    assert schema(A, object, True) == {'some_string': fields.Str(allow_none=True, default=None), 'some_list': fields.List(allow_none=True, default=None)}
    @dataclass_json
    @dataclass
    class B:
        some_string: str
        some_list: list
        some_optional: typing.Optional[str] = None
        some_optional_string: typing.Optional[str] = 'lul'
   

# Generated at 2022-06-11 21:12:03.933022
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    pass  # noqa



# Generated at 2022-06-11 21:12:07.925105
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema
    from marshmallow import fields
    class MySchema(Schema):
        a = fields.Integer()
    schema_f = SchemaF[int]()
    schema_f.loads('{"a": 4}', many=False)



# Generated at 2022-06-11 21:12:15.269774
# Unit test for function schema
def test_schema():
    @dataclass
    class Nested:
        value: int

    @dataclass
    class MyType:
        value: Nested

    @dataclass_json
    class MyTypeSchema(Schema):
        value: NestedSchema = fields.Nested(NestedSchema)

    Nested.schema = dataclass_json(mm_schema=MyTypeSchema)
    assert (schema(MyType, None, False)) == {"value": Nested.schema.get_fields()['value'].mm_field}

