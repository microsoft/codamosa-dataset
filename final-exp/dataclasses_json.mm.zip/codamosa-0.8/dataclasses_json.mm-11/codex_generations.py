

# Generated at 2022-06-11 21:05:44.752294
# Unit test for function schema
def test_schema():
    from marshmallow import Schema

    def test_dc(cls, mixin):
        schema(cls, mixin, False)

    from dataclasses import dataclass, field
    from dataclasses_json import dataclass_json

    import typing


    @dataclass_json
    @dataclass
    class D:
        f: typing.Dict[str, int]


    test_dc(D, Schema)

    @dataclass_json
    @dataclass
    class F:
        f: typing.Mapping[str, int]
        g: typing.Optional[typing.Mapping[str, int]]


    test_dc(F, Schema)
    test_dc(F(f={}, g={}), Schema)

# Generated at 2022-06-11 21:05:58.214778
# Unit test for function build_type
def test_build_type():
    import pytest
    from datetime import date
    from typing import Optional, List, Union, Tuple, Text, Literal
    from marshmallow_enum import EnumField, EnumMeta
    from marshmallow.fields import Integer, UUID, Decimal, Boolean, EnumField as MEnumField
    from marshmallow.fields import Dict, List as MList, Field  # type: ignore
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError

    class TestMixin:
        if sys.version_info >= (3, 7):
            def __new__(cls, *args, **kwargs):
                return super().__new__(cls)
        else:
            pass

    @dataclass_json(mm_field=None)
    class TestSubclass:
        x: int



# Generated at 2022-06-11 21:06:11.340926
# Unit test for function build_type
def test_build_type():
    from marshmallow import fields, Schema

    class MySchema(Schema):
        test_field = fields.Field()

        @post_load
        def postload_action(self, data):
            return data['test_field']

    from dataclasses import dataclass
    from marshmallow_oneofschema import OneOfSchema, fields

    @dataclass
    class SubSchema(MySchema):
        test_field: str

    class TestUnion(OneOfSchema):
        type_schemas = {
            'string': SubSchema,
        }
        type_field = 'type_field'

    type_ = typing.Union[str, bool]
    field = dc_fields(type_)[0]
    assert build_type(type_, {}, type, field, type) == \
            fields

# Generated at 2022-06-11 21:06:13.551094
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    value = datetime.utcnow()
    assert value == _TimestampField()._deserialize(
        _TimestampField()._serialize(value, None, None), None, None
    )



# Generated at 2022-06-11 21:06:16.541506
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    a = ['a']
    assert 'a' == SchemaF.loads(a, many=False)
    b = [{'a' : 1}]
    assert [{'a' : 1}] == SchemaF.loads(b, many=True)


# Generated at 2022-06-11 21:06:28.948926
# Unit test for function build_schema
def test_build_schema():
    class A:
        @classmethod
        def load(cls, data):
            ...


    class B(A):
        ...


    class C(B):
        ...


    class Mixin(metaclass=ABCMeta):
        @abstractmethod
        def load(cls, data):
            return map(lambda d: B(**d), data)


    class MyDataClass:
        a: int


    assert build_schema(cls=MyDataClass,
                        mixin=Mixin,
                        infer_missing=False,
                        partial=True)

    class MyDataClass2(MyDataClass):
        b: str


    assert build_schema(cls=MyDataClass2,
                        mixin=Mixin,
                        infer_missing=False,
                        partial=True)


# Generated at 2022-06-11 21:06:31.285152
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField(required=False).deserialize(None)
    assert _TimestampField(required=False, allow_none=True).deserialize(None)



# Generated at 2022-06-11 21:06:35.102077
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    import marshmallow as mm
    class TestSchema(mm.Schema):
        value = mm.fields.Integer()
    myschema = SchemaF[int](TestSchema)
    myschema.dump(12)
    myschema.dump([12])


# Generated at 2022-06-11 21:06:40.835221
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    # type: () -> None
    obj_data = {'foo': 42}
    data = '{"foo": 42}'
    data2 = bytearray('{"foo": 42}', encoding='utf-8')
    schema = SchemaF[typing.Any]()

    assert schema.loads(data) == obj_data
    assert schema.loads(data2) == obj_data



# Generated at 2022-06-11 21:06:44.692341
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    pass

if sys.version_info[:2] >= (3, 7):
    from dataclasses import dataclass
else:
    from dataclasses_json.compat import dataclass  # type: ignore



# Generated at 2022-06-11 21:06:58.865213
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field.__class__.__name__ == '_IsoField'


# Generated at 2022-06-11 21:07:09.473615
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    def it(many: bool, obj: typing.List[A], json: str) -> List[A]:
        print(many)
        print(json)
        return obj
    st = typing.get_type_hints(it)
    print(st)
    d = dataclasses.dataclass(st)
    print(d)
    ls = [1, 2]
    st = typing.get_type_hints(ls)
    print(st)
    d = dataclasses.dataclass(st)
    print(d)
    print(SchemaF.loads('[1, 2]', many=True))
    print(SchemaF.loads('[1, 2]', many=False))

# Generated at 2022-06-11 21:07:10.436189
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    _TimestampField()


# Generated at 2022-06-11 21:07:11.906192
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema = SchemaF[int]()
    assert schema.loads('1') == 1



# Generated at 2022-06-11 21:07:20.141254
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    assert SchemaF[int].dump([1, 2, 3]) == [1, 2, 3]
    assert SchemaF[int].dump(1) == 1
    assert SchemaF[int].dump([1, 2, 3], True) == [1, 2, 3]
    assert SchemaF[int].dump(1, True) == 1
    assert SchemaF[int].dump([1, 2, 3], False) == [1, 2, 3]
    assert SchemaF[int].dump(1, False) == 1

# Generated at 2022-06-11 21:07:22.178508
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField(required=False).description == "Timestamp float to datetime"


# Generated at 2022-06-11 21:07:27.031459
# Unit test for function schema
def test_schema():
    assert schema(CatchAllVar, EncodeMixin, False) == {'data': fields.Dict(default=None)}
    assert schema(CatchAllVar, EncodeMixin, True) == {'data': fields.Dict(missing=None)}



# Generated at 2022-06-11 21:07:33.513651
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    f = _TimestampField()
    assert f._serialize(datetime(2020,12,24,12,30,0), "datetime", "obj") == 1608792200.0
    assert f._deserialize(1608792200.0, "datetime", "data") == datetime(2020,12,24,12,30,0)


# Generated at 2022-06-11 21:07:40.177559
# Unit test for function build_schema
def test_build_schema():
    import dataclasses

    @dataclasses.dataclass
    class A:
        a: typing.List[str]
        b: datetime
        c: Decimal
        d: str
        e: typing.List[datetime]
        f: typing.List[datetime]


    assert build_schema(A, None, False, True) == build_schema(A, None, False, False)



# Generated at 2022-06-11 21:07:47.964683
# Unit test for function schema
def test_schema():
    from dataclasses_json.test.test_api import TestMixinC
    from dataclasses_json.test.test_api import Person
    s = schema(Person, TestMixinC, True)
    return s
    # assert s == {
    #     'child': <class 'dataclasses_json.api.Nested'>,
    #     'full_name': <class 'marshmallow.fields.Str'>,
    #     'age': <class 'marshmallow.fields.Int'>,
    # }



# Generated at 2022-06-11 21:08:13.709208
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), 'attr', 'obj') is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), 'attr', 'data') is not None



# Generated at 2022-06-11 21:08:24.675737
# Unit test for function build_schema
def test_build_schema():
    import datetime
    import typing
    import marshmallow
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.Optional[str] = None
        d: typing.Optional[str] = None
        e: datetime.datetime
        f: typing.List[str]
        g: typing.Dict[str, int]

    TestSchema = build_schema(Test, None, False, False)()
    test = Test(1, 'b', d='d', e=datetime.datetime.now(), f=['f', 'f'],
                g={'g': 1})

# Generated at 2022-06-11 21:08:26.095671
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    _TimestampField()
    assert True



# Generated at 2022-06-11 21:08:37.612532
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # type: () -> None
    class MySchema(SchemaF[A]):
        pass

    MySchema().load({'a': 'a'})
    MySchema().load([{'a': 'a'}])
    MySchema().load({'a': 'a'}, many=None)
    MySchema().load([{'a': 'a'}], many=True)
    MySchema().load([{'a': 'a'}], many=False)
    MySchema().load([{'a': 'a'}], many=None)
    MySchema().load({'a': 'a'}, many=None, partial=True)
    MySchema().load([{'a': 'a'}], many=False, partial=False)

# Generated at 2022-06-11 21:08:39.158532
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    try:
        _TimestampField()
    except:
        assert False

test__TimestampField()



# Generated at 2022-06-11 21:08:50.710696
# Unit test for function build_schema
def test_build_schema():
    import io
    import json
    from datetime import datetime
    from dataclasses import dataclass

    class MyDateTimeEncoder(json.JSONEncoder):
        def default(self, obj):
            if isinstance(obj, datetime):
                return obj.isoformat()

            return json.JSONEncoder.default(self, obj)

    class MyDateTimeDecoder(json.JSONDecoder):
        def __init__(self, *args, **kwargs):
            json.JSONDecoder.__init__(self, object_hook=self.dict_to_object,
                                      *args, **kwargs)

        def dict_to_object(self, d):
            if '__type__' not in d:
                return d

            class_name = d.pop('__type__')

# Generated at 2022-06-11 21:08:54.097371
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    instance: typing.List[int] = SchemaF[int]().loads('[1, 2, 3]')

# Generated at 2022-06-11 21:09:05.919962
# Unit test for constructor of class _IsoField
def test__IsoField():
    from datetime import datetime
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError

    example = datetime.fromisoformat('2018-10-15T11:30:22')
    example2 = datetime.fromisoformat('2018-10-15T11:30:22')
    print('example ', example)
    print('example2 ', example2)
    assert example == example2

    class MySchema(Schema):
        my_field = _IsoField()

    schema = MySchema()
    data, error = schema.dump({"my_field": example})
    print('data', data)
    print('error', error)
    assert data == {"my_field": "2018-10-15T11:30:22"}
    assert error == {}

    example2 = datetime

# Generated at 2022-06-11 21:09:15.897210
# Unit test for function build_schema
def test_build_schema():
    DataClassSchema = build_schema(User, mixin, infer_missing, partial)
    assert DataClassSchema.__name__ == 'UserSchema'
    assert DataClassSchema.Meta.fields[0] == 'name'
    assert DataClassSchema.Meta.fields[1] == 'age'
    assert DataClassSchema.Meta.fields[2] == 'address'
    assert DataClassSchema.make_user.__name__ == 'make_user'
    assert DataClassSchema.dumps.__name__ == 'dumps'
    assert DataClassSchema.dump.__name__ == 'dump'
    assert DataClassSchema.schema.__name__ == 'schema'
    assert isinstance(DataClassSchema.schema, dict)

# Generated at 2022-06-11 21:09:27.038757
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert (isinstance(_TimestampField(default=MISSING), fields.Field))
    assert (_TimestampField().deserialize(None) is None)
    assert (_TimestampField().serialize(None) is None)
    assert (_TimestampField().required is False)
    assert (_TimestampField(required=True).required is True)
    assert (_TimestampField(required=True).deserialize(None) is None)
    assert (_TimestampField(required=True).serialize(None) is None)
    assert (_TimestampField().deserialize(1605583120) ==
            datetime(2020, 11, 21, 21, 22, 0, tzinfo=timezone.utc))

# Generated at 2022-06-11 21:10:17.347338
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    @dataclass
    class TestClass():
        foo: int
        bar: str
    t = TestClass(1, "test")
    s = SchemaF(strict=True)
    l = s.load([t])
    assert l[0].foo
    assert l[0].bar == "test"

# Generated at 2022-06-11 21:10:27.138760
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # type: () -> None
    class User(typing.NamedTuple):
        address: str
    class UserSchema(SchemaF[User]):
        address = fields.Str()
    user_schema = UserSchema()
    user = User(address="test")
    dump = user_schema.dumps(user)
    assert isinstance(dump, str)
    dump = user_schema.dumps(user, many=True)
    assert isinstance(dump, str)
    dump = user_schema.dump(user)
    assert isinstance(dump, dict)
    dump = user_schema.dump(user, many=True)
    assert isinstance(dump, list)


# Generated at 2022-06-11 21:10:30.322656
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclass_json
    @dataclass
    class Foo:
        pass
    schema = SchemaF[Foo]()
    assert not schema.dumps([Foo(), Foo()])

# Generated at 2022-06-11 21:10:38.843960
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():  # noqa
    class SomeClass(object):
        ...
    class AnotherClass(object):
        ...
    some = SomeClass()  # type: TOneOrMulti
    another = AnotherClass()  # type: TOneOrMulti
    union = typing.Union[typing.List[SomeClass], SomeClass]
    list_of_unions = typing.List[union]
    schema = SchemaF[union]()  # type: typing.Any

    def check_data(data: TOneOrMultiEncoded):
        assert data == {'some_attr': 5}
    def check_list_data(data: TOneOrMultiEncoded):
        assert data == [{'some_attr': 5},{'some_other_attr': 7}]
    check_data(schema.dump(some))
    check_list_data

# Generated at 2022-06-11 21:10:44.836152
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    start_value = datetime.now()
    test = _TimestampField()
    serialized = test._serialize(start_value, None, None)
    should = start_value.timestamp()
    assert serialized == should
    deserialized = test._deserialize(serialized, None, None)
    should = _timestamp_to_dt_aware(should)
    assert deserialized == should



# Generated at 2022-06-11 21:10:59.358337
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Test(typing.NamedTuple):
        a: int
        b: str
        c: typing.List[int]

    class TestSchema(SchemaF[Test]):

        def __init__(self):
            super().__init__()
            self._declared_fields["a"] = fields.Int
            self._declared_fields["b"] = fields.Str
            self._declared_fields["c"] = fields.Nested(_TestListSchemaF)
            self._dict_cls = dict
            self._many = False

    class _TestListSchemaF(SchemaF[typing.List[int]]):

        def __init__(self):
            super().__init__()
            self._declared_fields["c"] = fields.List(fields.Int)
            self._dict_cl

# Generated at 2022-06-11 21:11:12.384909
# Unit test for function build_type
def test_build_type():
    from marshmallow import fields
    from dataclasses_json import DataClassJsonMixin
    from typing import MutableMapping, List, Tuple, Optional, Mapping, Union, \
        NewType, Callable, Any, TypeVar

    class Test(DataClassJsonMixin):
        N = NewType('N', int)
        y: Union[Decimal, List[Mapping[str, str]]] = Decimal(10)
        # void functions are not handled yet
        # x: Callable[[int], None]

    F = TypeVar('F', bound=fields.Field)
    assert isinstance(
        build_type(Test.y.type, {'required': True}, Test, Test.y, Test),
        fields.List)


# Generated at 2022-06-11 21:11:18.469177
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # type: () -> None
    class Test(object):
        pass

    class TestSchema(SchemaF[Test]):
        pass

    t = Test()
    TestSchema().dump(t)
    TestSchema().dump([t, t])
    t1 = Test()
    t2 = Test()
    TestSchema().dump([t1, t2])


# Generated at 2022-06-11 21:11:29.476007
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    @dataclass_json
    @dataclass
    class MySchema(SchemaF[A]):
        pass

    MySchema().loads('[{"my_field":"my_value"}]')
    MySchema().loads('{"my_field":"my_value"}')

    @dataclass_json
    @dataclass
    class MySchema1(SchemaF[A]):
        pass

    MySchema1().loads('[{"my_field":"my_value"}]', many=True)
    MySchema1().loads('{"my_field":"my_value"}', many=False)

    @dataclass_json
    @dataclass
    class MySchema2(SchemaF[A]):
        pass


# Generated at 2022-06-11 21:11:36.365153
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclass_json import DataClassJsonMixin
    from dataclass_json import config
    config.config.json_module = 'ujson'
    @dataclass
    class User(DataClassJsonMixin):
        id: int
        name: str
     # generic type
    __name__ = 'test_build_schema'
    assert build_schema(User,type(User), False, False) is not None
    config.config.json_module = None


# Generated at 2022-06-11 21:13:37.255251
# Unit test for function build_type
def test_build_type():

    class M(object):
        pass

    class N(M):
        pass

    class D(N):
        pass

    class E(Enum):
        a = 1

    @dataclass_json
    @dataclass
    class X:
        y: int
        z: float

    def assert_build_type(typ: typing.Type, expected_type: typing.Type):
        assert isinstance(
            build_type(typ, {}, object, dc_fields(X)[0], X), expected_type)

    assert_build_type(typing.Mapping[str, int], fields.Mapping)
    assert_build_type(typing.MutableMapping[str, int], fields.Mapping)
    assert_build_type(typing.List[int], fields.List)
    assert_build_

# Generated at 2022-06-11 21:13:38.330293
# Unit test for function build_type
def test_build_type():
    pass  # TODO



# Generated at 2022-06-11 21:13:44.500114
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields, validate  # type: ignore

    class TestSchema(Schema):
        __annotations__ = {'a': int}  # type: ignore
        a = fields.Int(validate=validate.Range(min=10))
        b = fields.Str()

    schema = SchemaF[TestSchema]()
    loaded = schema.load({'a':1, 'b':'a'})


# Generated at 2022-06-11 21:13:53.094436
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    import json
    from typing import List, Set
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError
    class Foo(Schema):
        x = fields.Int()
    f: Foo = Foo().loads('{"x": 5}')
    if isinstance(f, Foo):
        print(f)
    f: Foo = Foo().loads(b'{"x": 5}')
    if isinstance(f, Foo):
        print(f)
    f: List[Foo] = Foo(many=True).loads('[{"x": 5}]')
    if isinstance(f, list):
        print(f)
    f: List[Foo] = Foo(many=True).loads(b'[{"x": 5}]')

# Generated at 2022-06-11 21:13:53.975030
# Unit test for function schema
def test_schema():
    assert schema == _SchemaBuilder().schema



# Generated at 2022-06-11 21:13:59.263951
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import List
    from dataclasses import dataclass
    from marshmallow_dataclass import dataclass as m_dataclass

    @m_dataclass
    class TestSchemaF:
        a: str
        b: int
        c: float

    data: List[TestSchemaF] = []
    # type: ignore
    test_schema: SchemaF[TestSchemaF] = SchemaF()
    result = test_schema.dump(data)


if sys.version_info < (3, 7):
    SchemaF = Schema



# Generated at 2022-06-11 21:14:08.794429
# Unit test for function schema
def test_schema():
    from marshmallow import fields
    from dataclasses import dataclass
    from dataclasses_json import DataclassJSON
    from dataclasses_json.mm import MMSchema

    from typing import Optional

    @dataclass
    class A:
        x: int


    @dataclass_json
    @dataclass
    class B:
        x: Optional[int] = None


    @dataclass_json
    @dataclass
    class C:
        x: str


    @dataclass_json
    @dataclass
    class D:
        x: Optional[str] = None


    @dataclass_json
    @dataclass
    class E:
        x: typing.Dict



# Generated at 2022-06-11 21:14:15.931888
# Unit test for function build_schema
def test_build_schema():
    class Base(metaclass=_ExtendedType):
        @classmethod
        def __pre_init__(cls, *args, **kwargs):
            pass
        pass

    @dataclass
    class A(Base):
        name: str
        value: int
        another_value: int = 2
        some_value: typing.Optional[int]
    assert A.schema() == build_schema(A, Base, True, True)

# Unit tests for the build_type function

# Generated at 2022-06-11 21:14:26.508294
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Foo:
        pass

    class Bar(Foo):
        pass

    def _test(schema: SchemaF[typing.Union[Bar, Foo]], data: typing.Union[Bar, Foo, typing.List[Bar], typing.List[Foo]], many: bool) -> typing.Union[Dict[AnyStr, Any], List[Dict[AnyStr, Any]]]:
        return schema.dump(data, many)

    class FooSchema(SchemaF[Foo]):
        pass

    class BarSchema(FooSchema):
        pass

    foo_schema = FooSchema()
    bar_schema = BarSchema()

    bar = Bar()
    foo = Foo()
    data = [bar, foo]
    res = _test(bar_schema, bar, False)
    res

# Generated at 2022-06-11 21:14:37.384058
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    value = datetime(2014, 1, 1)
    assert field._serialize(value, 'attr', 'obj', test='test') == '2014-01-01T00:00:00'
    # if you write assert field._serialize(value, 'attr', 'obj', test='test') == '2014-01-01T00:00:00'
    # error will be happened. because _deserialize is not implemented
    assert field._deserialize('2014-01-01T00:00:00', 'attr', 'data', test='test') == datetime(2014, 1, 1)


# if you write assert field._deserialize('2014-01-01T00:00:00', 'attr', 'data', test='test') == datetime(2014, 1, 1)
# error will