

# Generated at 2022-06-11 21:05:52.428860
# Unit test for function build_type
def test_build_type():
    def check_rec(schema):
        if isinstance(schema, _UnionField):
            for a in schema.desc.values():
                check_rec(a)

    class Mixin:
        @classmethod
        def schema(cls):
            return SchemaType.from_dataclass(cls)


    @dataclass_json(encoder=_ExtendedEncoder)
    class Test:
        foo: typing.Optional[int]
        bar: typing.Dict[str, int]
        baz: typing.List[str]
        boo: typing.Callable
        bat: typing.Union[int, float]
        gee: typing.Tuple[int, float]
        roo: typing.Union[Mixin, Test]
        mee: typing.List[Mixin]
        bee: typing

# Generated at 2022-06-11 21:06:02.745209
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class A:
        a: str
        b: int = 3
        c: datetime
        d: typing.List[str]

    Schema = build_schema(A, None, False, False)
    assert len(Schema.__fields__) == 4
    assert Schema._declared_fields['a'].__class__ == fields.Str
    assert Schema._declared_fields['b'].__class__ == fields.Int
    assert Schema._declared_fields['c'].__class__ == _TimestampField
    assert Schema._declared_fields['d'].__class__ == fields.List
    assert Schema._declared_fields['d'].inner.__class__ == fields.Str

# Generated at 2022-06-11 21:06:14.861290
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass, field, fields
    from dataclasses_json.mm import MmSchema
    from dataclasses_json.core import _get_fields
    from dataclasses_json.core import _check_for_required_none_in_fields
    import pytest

    @dataclass
    class TestSchema:
        t: int

        def __new__(cls, t: int):
            return TestSchema.__new__(cls)

    @dataclass
    class TestOptionalSchema:
        t: typing.Optional[TestSchema] = field(default=None)

    @dataclass
    class TestUnionSchema:
        t: typing.Union[TestSchema]


# Generated at 2022-06-11 21:06:21.574633
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    @dataclass
    class Test:
        a: int
    assert type(build_schema(Test, None, False, False)) == type(build_schema(Test, None, False, False))
    assert type(build_schema(Test, None, True, False)) != type(build_schema(Test, None, False, False))




# Generated at 2022-06-11 21:06:26.917894
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():  # type: ignore
    class Foo(TypedSchema):
        foo: int


    foo = Foo(foo=1)
    assert foo.dump().get('foo') == 1
    foo_list = [Foo(foo=1), Foo(foo=2)]
    assert foo_list.dump().get('foo') == 1



# Generated at 2022-06-11 21:06:38.564095
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import List
    from marshmallow import Schema
    from dataclasses_json import dataclass_json
    from dataclasses import dataclass

    @dataclass_json
    @dataclass
    class MyDataClass:
        f: int

    class MySchema(SchemaF[MyDataClass]):
        f = fields.Int()

        @post_load
        def make(self, data):
            return MyDataClass(**data)

    data = MyDataClass(f=5)
    schema = MySchema()

    dumped_data: TEncoded = schema.dump(data)
    dumped_data_list: TEncoded = schema.dump([data])

    assert dumped_data == {'f': 5}
    assert dumped_data_list == {'f': 5}

# Generated at 2022-06-11 21:06:42.236389
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class SimpleSchema(SchemaF[int]):
        n: fields.Int = fields.Int()

    sch = SimpleSchema()

    assert sch.load({'n': 5}) == 5
    assert sch.load([{'n': 1}, {'n': 2}]) == [1, 2]



# Generated at 2022-06-11 21:06:54.638434
# Unit test for function schema
def test_schema():

    from dataclasses_json.api import mm_schema
    from dataclasses import dataclass, field
    import typing

    @dataclass
    class Nested:
        val: int

    @dataclass
    class Obj:
        nested: Nested
        val: typing.Optional[float]
        opt_nested: typing.Optional[Nested] = field(default=None)
        nested_opt: Nested = field(default=Nested(-1))

    assert Obj.schema() == {
        'nested': {'val': fields.Int(required=True)}
    }


# Generated at 2022-06-11 21:07:01.218903
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    data = '{"a": {"b": {"c": ["d", "e"]}}}'
    d = SchemaF.loads(data, unknown='EXCLUDE')
    assert d == {'a': {'b': {'c': ['d', 'e']}}}



# Generated at 2022-06-11 21:07:03.618036
# Unit test for constructor of class _IsoField
def test__IsoField():
    my_field = _IsoField()
    assert my_field.__repr__() == "Iso Field"


# Generated at 2022-06-11 21:07:27.988515
# Unit test for function build_type
def test_build_type():
    import pytest
    from dataclasses_json.mm import Schema

    @Schema.from_dataclass
    @dataclasses.dataclass
    class A:
        a: str

    assert isinstance(build_type(str, {}, Schema,
                      dc_fields(str)[0], A), fields.Str)

    assert isinstance(build_type(int, {}, Schema,
                      dc_fields(int)[0], A), fields.Int)

    assert isinstance(build_type(bool, {}, Schema,
                      dc_fields(bool)[0], A), fields.Bool)

    var = dataclasses.field(
        default=None, metadata={"mm_field": fields.Float(allow_none=True)})

# Generated at 2022-06-11 21:07:32.237236
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class A(typing.NamedTuple):
        x: typing.Tuple[int, ...]
    class B(SchemaF[A]): pass
    B().loads('{"x": [1, 2, 3]}')
    B().loads('[{"x": [1, 2, 3]}]')

# Generated at 2022-06-11 21:07:40.602243
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Foo(): ...
    class FooSchema(SchemaF[Foo]): pass
    print(FooSchema.loads(b'{"foo":1}'))

# Generated at 2022-06-11 21:07:50.020765
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from typing import List
    from dataclasses_json import DataClassJsonMixin
    @dataclass
    class Ttest(DataClassJsonMixin):
        a: int
        b: List[int]

    assert schema(Ttest(a=1, b=[1,2]), DataClassJsonMixin, False)['b'] == fields.List(fields.Int())
    assert schema(Ttest(a=1, b=[1,2]), DataClassJsonMixin, False)['a'] == fields.Int()
    assert schema(Ttest(a=1), DataClassJsonMixin, False)['a'] == fields.Int()
    assert len(schema(Ttest(a=1), DataClassJsonMixin, False)) == 2


# Generated at 2022-06-11 21:07:59.980518
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    def test_load(
            self: "This",
            data: typing.Union[typing.List[A], A],
            many: bool = None,
            partial: bool = None,
            unknown: str = None,
    ) -> typing.Union[typing.List[A], A]:
        pass

    test_load(SchemaF, [])  # a
    test_load(SchemaF, "")  # aa
    test_load(SchemaF, [{}])  # b
    test_load(SchemaF, {})  # bb
    test_load(SchemaF, [{1: 2}])  # c
    test_load(SchemaF, {1: 2})  # cc
    test_load(SchemaF, [{1: 2}], True)  # d


# Generated at 2022-06-11 21:08:03.478093
# Unit test for constructor of class _IsoField
def test__IsoField():
    f = _IsoField()
    dt = datetime(2001, 2, 3, 4, 5, 6)
    assert f.serialize(dt, None, None) == dt.isoformat()
    assert f.deserialize(dt.isoformat(), None, None) == dt



# Generated at 2022-06-11 21:08:14.931719
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    json_data = SchemaF[A]().dumps('a')
    json_data = SchemaF[A]().dumps(['1'])
    # works
    A = typing.TypeVar('A')
    new_type = typing.NewType('new_type', int)
    new_type_a = typing.NewType('new_type', A)
    json_data = SchemaF[new_type_a]().dumps(new_type(1))
    json_data = SchemaF[new_type_a]().dumps([new_type(1)])

# Generated at 2022-06-11 21:08:19.122594
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class SC(SchemaF[User]):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            raise NotImplementedError()


    class User:
        pass
    SC.dumps(User)



# Generated at 2022-06-11 21:08:25.461987
# Unit test for function build_schema
def test_build_schema():
    mixin = type('Mixin', (object,), {'schema': lambda x: None})
    infer_missing = False
    partial = False
    class Test:
        a: int

    assert issubclass(build_schema(Test, mixin, infer_missing, partial), Schema)
    assert build_schema(Test, mixin, infer_missing, partial).Meta.fields == ('a',)



# Generated at 2022-06-11 21:08:37.369053
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    data = [1,2,3]
    schema = SchemaF[list].from_dict({"fields":{"data":{"type_":list,"validate":True}}})
    assert isinstance(data, (typing.List, list)) and isinstance(schema.dumps(data), str)

    data = [{'a': 1}, {'a': 2}]
    schema = SchemaF[dict].from_dict({"fields":{"data":{"type_":dict,"validate":True}}})
    assert isinstance(data, (typing.List, list)) and isinstance(schema.dumps(data), str)

    data = {'a': 1}
    schema = SchemaF[dict].from_dict({"fields":{"data":{"type_":dict,"validate":True}}})

# Generated at 2022-06-11 21:09:18.519318
# Unit test for function schema
def test_schema():
    # Example of how a Schema object is created in the process of creating a schema dictionary
    # For the class below schema dictionary would look like:
    # {'id': <marshmallow.fields.UUID object at 0x000002A3670B7788>, 'count': <marshmallow.fields.Int object at 0x000002A3670B7748>, 'name': <marshmallow.fields.Str object at 0x000002A3670B77C8>, 'timeout': <marshmallow.fields.Int object at 0x000002A3670B7828>, 'data': <marshmallow.fields.Dict object at 0x000002A3670B78C8>, 'obj_list': <marshmallow.fields.Nested object at 0x000002A3670B7848>}
    import dataclasses

# Generated at 2022-06-11 21:09:29.001629
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class SchemaA(SchemaF[A]):  # type: ignore
        pass

    class SchemaB(SchemaF[B]):  # type: ignore
        pass

    class SchemaC(SchemaF[C]):  # type: ignore
        pass

    class SchemaD(SchemaF[D]):  # type: ignore
        pass

    class SchemaE(SchemaF[E]):  # type: ignore
        pass

    class SchemaF(SchemaF[F]):  # type: ignore
        pass

    class SchemaG(SchemaF[G]):  # type: ignore
        pass

    class SchemaH(SchemaF[H]):  # type: ignore
        pass

    class SchemaI(SchemaF[I]):  # type: ignore
        pass

   

# Generated at 2022-06-11 21:09:35.480511
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime(2010, 10, 10, 12, 0, 1, 123)) == \
        datetime(2010, 10, 10, 12, 0, 1, 123).timestamp()
    assert _TimestampField()._deserialize(1284285701.123) == \
        datetime(2010, 10, 10, 12, 0, 1, 123000)



# Generated at 2022-06-11 21:09:40.992695
# Unit test for constructor of class _IsoField
def test__IsoField():
    f = _IsoField()
    # test serialize function
    assert f.serialize(None, None, None) is None
    assert f.serialize(datetime(2000, 1, 2, 3, 4, 5, 6), None, None) == "2000-01-02T03:04:05.000006"


# Generated at 2022-06-11 21:09:42.922964
# Unit test for function build_schema

# Generated at 2022-06-11 21:09:46.232054
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    assert SchemaF[User].dumps(User('Peter')) == '{"name": "Peter"}'


# Generated at 2022-06-11 21:09:54.097690
# Unit test for function build_type
def test_build_type():
    assert repr(build_type(typing.Type[int], dict(), None, None, None)) == '<class \'int\'>'
    assert repr(build_type(typing.Type[float], dict(), None, None, None)) == '<class \'float\'>'
    assert repr(build_type(typing.Type[dict], dict(), None, None, None)) == '<class \'dict\'>'
    assert repr(build_type(typing.Union[typing.Type[int], typing.Type[float]], dict(), None, None, None)) ==\
           '<class \'function\'>'

# Generated at 2022-06-11 21:10:05.662784
# Unit test for function build_type
def test_build_type():
    from marshmallow import Schema
    from marshmallow.fields import Field
    from marshmallow.fields import Mapping, Dict, List, Tuple, Function, Raw, Str, Int, Float, Bool, Field, Nested, Decimal, UUID
    from marshmallow.exceptions import ValidationError
    from datetime import datetime
    from uuid import uuid4
    from decimal import Decimal
    from dataclasses import dataclass

    @dataclass
    class Test(object):
        v: int
    class TS(Schema):
        v = Int(required=True)

    @dataclass
    class Foo(object):
        v: int
    foo = Foo(1)

    @dataclass
    class Bar(object):
        r: int
        v: float


# Generated at 2022-06-11 21:10:14.927370
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass

    @dataclass
    class Point:
        x: float
        y: float

    @dataclass
    class Data:
        p: Point

    assert schema(Data, Data, infer_missing=False) == {'p': fields.Nested(schema(Point, Data, infer_missing=False))}
    assert schema(Point, Data, infer_missing=False) == {'x': fields.Float(), 'y': fields.Float()}



# Generated at 2022-06-11 21:10:26.801461
# Unit test for function build_type
def test_build_type():
    import json
    import dataclasses
    from dataclasses import dataclass as dc
    from dataclasses_json.api import DataClassJsonMixin, Schema

    T = typing.TypeVar('T')

    @dc(repr=False)
    class DC(DataClassJsonMixin):
        x: str = "Hello"

        def __init__(self, x):
            self.x = x

        def __repr__(self):
            return json.dumps(self.to_json())

    @dc(repr=False)
    class DC2(DataClassJsonMixin):
        x: typing.List[DC] = [DC('World')]

        def __repr__(self):
            return json.dumps(self.to_json())


# Generated at 2022-06-11 21:11:21.561687
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    import marshmallow as mm

    @dataclass
    class A:
        a: typing.List[int]
        b: typing.Dict[str, float]
        c: bool
        d: typing.Mapping[str, bool]
        e: typing.Callable
        f: datetime
        g: UUID
        h: Decimal
        i: CatchAllVar
        j: typing.Union[int, str]
        k: typing.MutableMapping
        l: str
        m: int
        n: float
        o: typing.Tuple[str, int]


# Generated at 2022-06-11 21:11:30.897287
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Foo:
        def __init__(self, a: int, b: str):
            self.a = a
            self.b = b

    class FooSchema(Schema, typing.Generic[A]):
        a: fields.Field = fields.Int()
        b: fields.Field = fields.Str()

    f = Foo(1, 'a')
    fs = FooSchema()
    f_ = fs.dump(f)



# Generated at 2022-06-11 21:11:38.636697
# Unit test for function schema
def test_schema():
    class EnumTest(Enum):
        A = 1
        B = 2

    from dataclasses import dataclass
    from dataclasses_json.mm import Schema

    @dataclass
    class NestedDataclass:
        a: int
        b: float

        class Schema(Schema):
            pass

    @dataclass
    class Test:
        a: int
        b: float
        n: typing.Optional[NestedDataclass]
        e: EnumTest
        t: typing.Optional[typing.List[int]]
        d: typing.Dict[str, int]
        u: typing.Union[str, int, NestedDataclass]

        class Schema(Schema):
            pass


# Generated at 2022-06-11 21:11:39.392560
# Unit test for function build_schema
def test_build_schema():
    pass



# Generated at 2022-06-11 21:11:48.706190
# Unit test for function build_type
def test_build_type():
    class Test:
        pass

    class Test1:
        pass

    class Test2:
        pass

    @dataclass_json(mm_field=build_type)
    class A(JsonMixin):
        pass

    @dataclass_json(mm_field=build_type)
    class B(JsonMixin):
        a: typing.List[A]
        b: A = None

    @dataclass_json(mm_field=build_type)
    class C(JsonMixin):
        t: typing.Union[Test, Test1, Test2]

    assert B.schema().fields['a'].nested == A.schema()

    assert B.schema().fields['b'].allow_none == True

# Generated at 2022-06-11 21:11:51.764967
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    assert isinstance(SchemaF(many=False).dumps(None), str)

# Generated at 2022-06-11 21:12:04.122178
# Unit test for function build_type
def test_build_type():
    import marshmallow as ma
    from dataclasses_json.config import config
    import typing
    import dataclasses
    import datetime

    class DT(datetime.datetime):
        pass

    config.encode_datetime = lambda x: DT(x.year, x.month, x.day, x.hour, x.minute,
                                          x.second, x.microsecond, x.tzinfo)
    config.decode_datetime = lambda x: datetime.datetime(x.year, x.month, x.day,
                                                         x.hour, x.minute,
                                                         x.second,
                                                         x.microsecond,
                                                         x.tzinfo)
    config.encode_repr = True

    @dataclasses.dataclass
    class TestClass:
        a

# Generated at 2022-06-11 21:12:14.520277
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin
    from marshmallow import fields as mm_fields

    @dataclass
    class SomeClass(DataClassJsonMixin):
        field_1: int
        field_2: str

        class JsonSchema:
            field_1 = mm_fields.Int()
            field_2 = mm_fields.Str()

        class Config:
            arbitrary_types_allowed = True

    @dataclass
    class SomeOtherClass(DataClassJsonMixin):
        field_1: SomeClass

        class Config:
            arbitrary_types_allowed = True


# Generated at 2022-06-11 21:12:26.501914
# Unit test for function schema
def test_schema():
    import typing
    from dataclasses import dataclass
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError
    from dataclasses_json.mm import SchemaType
    from marshmallow.validate import OneOf
    from dataclasses_json.undefined import raise_error
    class ConcreteSchema(SchemaType):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    class ExampleEnum(Enum):
        x = 1
        y = 2

    @dataclass
    class Example:
        string: str
        integer: typing.Optional[int]
        long: typing.Optional[CatchAllVar] = None
        float_: float = 1.2
        boolean: bool = False
        list_

# Generated at 2022-06-11 21:12:33.048955
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclasses.dataclass
    class A:
        x: int = 1
        y: str = '2'
    schema = DataclassJsonMixin.Schema
    assert isinstance(schema[A].dumps([], many=True), str)
    assert isinstance(schema[A].dumps(A(), many=False), str)
    assert isinstance(schema[A].dumps([A()]), str)
    assert isinstance(schema[A].dumps(A()), str)
    assert isinstance(schema[typing.List[A]].dumps([A()]), str)
    assert isinstance(schema[typing.List[A]].dumps(A()), str)


# Generated at 2022-06-11 21:14:24.986432
# Unit test for function schema
def test_schema():
    import dataclasses
    import typing
    @dataclasses.dataclass
    class Inner:
        foo: int
    @dataclasses.dataclass
    class Dummy:
        inner: Inner
    print(Dummy.schema())
    assert Dummy.schema() == {'inner': {'foo': 'foo'}}




# Generated at 2022-06-11 21:14:26.124166
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    schema = SchemaF[int, str]()



# Generated at 2022-06-11 21:14:36.828967
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():

    class Dc(typing.Generic[A], typing.List[A]):
        def __init__(self, *args):
            super().__init__(*args)

    class Schema(dataclasses_json.Schema):
        def get_obj_type(self, obj):
            return obj.__class__

        @post_load
        def make(self, data):
            return Dc(data['a'], data['b'])

    schema = Schema()
    # $ExpectError: cannot construct with List
    schema.dump(Dc([1, 2], [3, 4]))
    # $ExpectError: cannot construct with List
    schema.dumps(Dc([1, 2], [3, 4]))



# Generated at 2022-06-11 21:14:49.691536
# Unit test for function build_type
def test_build_type():
    from typing import Dict, List
    from marshmallow import Schema
    from dataclasses import dataclass, field

    @dataclass
    class MmOptions:
        pass

    @dataclass
    class Mixin:
        pass

    @dataclass
    class Field:
        name = str
        type = str

    @dataclass
    class Cls:
        pass

    type_ = Dict[str, str]
    options = MmOptions()
    mixin = Mixin
    field = Field
    cls = Cls

    assert isinstance(
        build_type(type_, options, mixin, field, cls),
        fields.Mapping
    )

    type_ = List[str]

# Generated at 2022-06-11 21:14:51.208517
# Unit test for function schema
def test_schema():
    schema(object, object, False)



# Generated at 2022-06-11 21:14:53.341160
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    pass


# Generated at 2022-06-11 21:14:57.297204
# Unit test for function build_schema
def test_build_schema():
    class ClassWithNotExistingField:
        def __init__(self, a, b, c):
            self.a = a
            self.b = b
            self.c = c

    class ClassWithNotExistingFieldSchema(Schema):
        a = fields.Str(missing=2)
        b = fields.Int()
        c = fields.Int()

    assert build_schema(ClassWithNotExistingField, None, False, None) == ClassWithNotExistingFieldSchema

# Generated at 2022-06-11 21:15:04.088946
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields
    @dataclass
    class X:
        i: int
        s: str
    class XSchema(Schema):
        i = fields.Int()
        s = fields.Str()
    xs = X(1, 'a')
    sfx = SchemaF[X](XSchema)
    d = sfx.dump(xs)
    assert d == {'i': 1, 's': 'a'}
    d = sfx.dump([xs])
    assert d == [{'i': 1, 's': 'a'}]

# Generated at 2022-06-11 21:15:16.556295
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import TypeVar, Generic, List, Any
    @dataclass_json(encoder=_ExtendedEncoder)
    @dataclass
    class Person:
        name: str
    def print_it(x: List[Person]):  # type: ignore
        print('hello')
    print_it(SchemaF[Person]().dump([Person('x'), Person('y')], many=True))

if sys.version_info >= (3, 7):
    class SchemaC(SchemaF[A]):
        """Class schema, accept as argument a class to convert"""

        def __init__(self, *args, cls: typing.Type[A], **kwargs) -> None:
            super().__init__(*args, cls=cls, **kwargs)
