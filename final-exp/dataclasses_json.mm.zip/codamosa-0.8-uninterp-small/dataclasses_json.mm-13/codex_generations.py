

# Generated at 2022-06-25 16:02:42.943206
# Unit test for constructor of class _IsoField
def test__IsoField():
    obj = _IsoField()
    assert obj is not None



# Generated at 2022-06-25 16:02:44.954762
# Unit test for function build_type
def test_build_type():
    schema_f_3 = SchemaF()
    build_type(schema_f_3, {}, str, [], str)

# Generated at 2022-06-25 16:02:53.481995
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema_f_1 = SchemaF()
    dumps_result_1 = schema_f_1.dumps
    assert dumps_result_1 in [str]
    schema_f_2 = SchemaF()
    dumps_result_2 = schema_f_2.dumps(1)
    assert dumps_result_2 in [str]
    schema_f_3 = SchemaF()
    dumps_result_3 = schema_f_3.dumps([])
    assert dumps_result_3 in [str]
    schema_f_4 = SchemaF()
    try:
        dumps_result_4 = schema_f_4.dumps(1,1)
    except TypeError:
        dumps_result_4 = True
    assert dumps_result_4 in [True]


# Generated at 2022-06-25 16:03:05.480925
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass, field
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class DC0(DataClassJsonMixin):
        d: int = 1
        e: int = field(default=2)

    assert issubclass(build_schema(DC0, DataClassJsonMixin, False, False), SchemaF)

    @dataclass
    class DC1(DataClassJsonMixin):
        a: str
        b: int = 1
        c: int = field(default=2)
        f: typing.List[DC0] = field(default_factory=lambda: [DC0()])

    assert issubclass(build_schema(DC1, DataClassJsonMixin, False, False), SchemaF)



# Generated at 2022-06-25 16:03:17.727204
# Unit test for function schema
def test_schema():
    # test for the correct type 
    type_ = _is_new_type(typing.MutableMapping)
    if type(type_) is bool:
        print("test_schema -> test_for_correct_type_type is True")
    else:
        print("test_schema -> test_for_correct_type_type is False")
    # test for the correct type 
    type_ = _is_new_type(typing.Mapping)
    if type(type_) is bool:
        print("test_schema -> test_for_correct_type_type is True")
    else:
        print("test_schema -> test_for_correct_type_type is False")
    # test for the correct type 
    type_ = _is_new_type(typing.List)

# Generated at 2022-06-25 16:03:24.745040
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass, field
    from typing import List, Optional

    @dataclass
    class DataClass:
        value: List[Optional[int]]

    @dataclass
    class DataClass0:
        value: int

    @dataclass
    class DataClass1:
        value: List[Optional[DataClass0]]

    @dataclass
    class DataClass2:
        value: List[Optional[DataClass1]]

    schema_f = build_type(DataClass, {}, {}, DataClass.__annotations__, {})
    schema_f.dump({})
    schema_f.dump([])
    schema_f.dumps({})
    schema_f.dumps([])
    schema_f.load({})
    schema_f.load([])
    schema_f.loads

# Generated at 2022-06-25 16:03:35.612995
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class MySchema(SchemaF):
        str_field = fields.Str()

    schema_f_0 = MySchema()

    # type: typing.Dict[str, typing.Any]
    json_value = schema_f_0.dumps({'str_field': 'foo'})  # type: ignore

    # type: typing.Dict[str, typing.Any]
    json_value = schema_f_0.dumps([{'str_field': 'foo'}, {'str_field': 'bar'}])  # type: ignore

    # type: typing.Dict[str, typing.Any]
    json_value = schema_f_0.dumps([{'str_field': 'foo'}, {'str_field': 'bar'}], many=True)  # type: ignore


# Unit

# Generated at 2022-06-25 16:03:36.448936
# Unit test for constructor of class _IsoField
def test__IsoField():
    _ = _IsoField()


# Generated at 2022-06-25 16:03:39.027301
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema_f_0 = SchemaF()
    res_0 = schema_f_0.dumps(['123', '456'])
    assert res_0 == '["123", "456"]'


# Generated at 2022-06-25 16:03:40.085703
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_field_0 = _IsoField()


# Generated at 2022-06-25 16:03:55.341942
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class TestSchemaF(SchemaF[dict]):
        id = fields.Int()
        name = fields.Str()

    @dataclass_json
    @dataclass
    class TestClassF:
        id: int
        name: str

    schema = TestSchemaF()
    test_class = TestClassF(id=43, name='test')
    assert schema.dumps(test_class) == '{"name": "test", "id": 43}'
    assert schema.dumps([test_class, test_class]) == '[{"name": "test", "id": 43}, {"name": "test", "id": 43}]'


# Generated at 2022-06-25 16:03:59.905316
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema_f_dumps = SchemaF()
    schema_f_dumps.dumps(10, many=True)
    schema_f_dumps.dumps(10, many=False)
    schema_f_dumps.dumps(10)
    schema_f_dumps.dumps([10], many=False)
    schema_f_dumps.dumps([10])
    schema_f_dumps.dumps([10], many=True)


# Generated at 2022-06-25 16:04:03.622073
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema = SchemaF()
    item = schema.dumps({"name": "John", "surname": "Doe"})
    assert isinstance(item, str)


# Generated at 2022-06-25 16:04:08.589527
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    assert SchemaF(['a']).dump(['a']) == ['a']
    assert SchemaF([1]).dump([1]) == [1]
    assert SchemaF(['a']).dump('a') == ['a']
    assert SchemaF([]).dump([]) == []
    assert SchemaF('a').dump('a') == 'a'
    assert SchemaF(1).dump(1) == 1
    assert SchemaF(None).dump(None) == None


# Generated at 2022-06-25 16:04:13.972638
# Unit test for constructor of class _IsoField
def test__IsoField():
    obj = _IsoField()
    assert isinstance(obj, _IsoField)
    assert obj.missing == None
    assert obj.context == None
    assert obj.load_only == False
    assert obj.dump_only == False
    assert obj.default == None
    assert obj.attribute == None
    assert obj.metadata == {}
    assert obj.validate == []
    assert obj.required == False
    assert obj.allow_none == False
    assert obj.load_from == None
    assert obj.dump_to == None
    assert obj.error_messages == {}
    assert obj.data_key == None
    assert isinstance(obj.error_messages,dict)
    assert isinstance(obj.error_messages,dict)
    assert isinstance(obj.error_messages,dict)
    assert isinstance

# Generated at 2022-06-25 16:04:22.010304
# Unit test for function build_type
def test_build_type():
    test_dict = {
        "type_": typing.Mapping,
        "options": {"options"},
        "mixin": typing.Callable,
        "field": {"field"},
        "cls": {"cls"}
    }
    field, marshmallow_field = build_type(**test_dict)
    with open(
            "/home/user/mypy_boto3_builder/mypy_boto3_builder/parsed_types/test_build_type.txt",
            "w",
    ) as file:
        file.write(str(field))
        file.write(str(marshmallow_field))
        file.write(str(test_dict))
    return marshmallow_field



# Generated at 2022-06-25 16:04:25.159916
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert (isinstance(_IsoField(), fields.Field))


# Generated at 2022-06-25 16:04:35.304857
# Unit test for function build_type
def test_build_type():
    class Recursive:
        @classmethod
        def schema(cls):
            return None

    class RecursiveSubclass(Recursive):
        pass

    class RecursiveSubclassDecorated(Recursive):
        @dataclass_json
        @dataclass
        class RecursiveSubclassSubDecorated:
            pass

    class RecursiveMixin:
        pass

    class RecursiveMixinDecorated(RecursiveMixin):
        @dataclass_json
        @dataclass
        class RecursiveMixinSubDecorated:
            pass

    @dataclass
    class RecursiveDataclass:
        pass

    @dataclass_json
    @dataclass
    class RecursiveDataclassDecorated:
        pass

    from marshmallow import fields
    import enum

# Generated at 2022-06-25 16:04:41.649311
# Unit test for function schema
def test_schema():

    @dataclass_json
    @dataclass
    class SimpleTest:
        count: int = 5
        message: str = 'aaa'

    s = schema(SimpleTest, SchemaF, False)
    count = s.get('count')
    message = s.get('message')

    print(count)
    print(message)

    count_t = typing.get_type_hints(SimpleTest).get('count')
    message_t = typing.get_type_hints(SimpleTest).get('message')

    print(count_t)
    print(message_t)

    # dataclasses_json.mm.test.test_schema.test_schema.<locals>.<lambda>.<locals>.<lambda>.<locals>.<lambda> at 0x7f1f6563d730>
   

# Generated at 2022-06-25 16:04:43.430599
# Unit test for constructor of class _IsoField
def test__IsoField():
    try:
        _IsoField()
        assert True
    except Exception:
        assert False



# Generated at 2022-06-25 16:05:02.103802
# Unit test for function build_schema
def test_build_schema():
    cls = TestClass

    mixin = {}
    infer_missing = False
    partial = False

    schema_f = build_schema(cls, mixin, infer_missing, partial)

    assert schema_f(strict=True).dump(TestClass(1, 2, 3)) == {'a': 1, 'b': 2, 'c': 3}


# Generated at 2022-06-25 16:05:05.167282
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # Test 1: test case obj is not list or tuple
    schema_f_1 = SchemaF()
    assert(False)


# Generated at 2022-06-25 16:05:16.438864
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    __type_0 = typing.List[typing.List[typing.Dict[str, int]]]
    __obj_0 = [[{'a': 1}]]
    __many_0 = True
    __expected_0 = [[{'a': 1}]]

    __type_1 = typing.List[typing.Dict[str, int]]
    __obj_1 = [{'a': 1}]
    __many_1 = False
    __expected_1 = [{'a': 1}]

    __type_2 = typing.List[typing.Dict[str, int]]
    __obj_2 = [{'a': 1}]
    __many_2 = True
    __expected_2 = [{'a': 1}]

    __type_3 = typing.Dict[str, int]


# Generated at 2022-06-25 16:05:19.378124
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f_1 = SchemaF()
    # SUT
    result = schema_f_1.loads(json_data=b'data', many=False)
    assert type(result) == list or type(result) == dict


# Generated at 2022-06-25 16:05:25.071021
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema_f_1 = SchemaF()
    schema_f_2 = SchemaF()
    schema_f_3 = SchemaF()
    schema_f_4 = SchemaF()
    schema_f_5 = SchemaF()



# Generated at 2022-06-25 16:05:26.653012
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    try:
        f_0 = _TimestampField()
        assert f_0 is not None
        assert True
    except Exception:
        assert False


# Generated at 2022-06-25 16:05:35.085098
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json(letter_case=LetterCase.CAMEL)
    class BookSchema0:
        title: str
        author: str
        pages: int = 0
        price: float = 0.0
        published: datetime = field(
            default_factory=datetime.utcnow)
        is_published: bool = field(
            default_factory=lambda: False, metadata={'data_key': 'isPublished'})
        notes: typing.List[str] = field(default_factory=list)

    BookType = build_schema(BookSchema0, mixin.JsonMixin, infer_missing=True,
                            partial=False)
    bs = BookType()
    bs.dumps(BookSchema0('The Hobbit', 'J. R. R. Tolkien'))

# Generated at 2022-06-25 16:05:38.883776
# Unit test for function build_type
def test_build_type():
    build_type



# Generated at 2022-06-25 16:05:41.489176
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    @dataclass
    class Cls:
        i: int
    schema = schema(Cls, None, False)
    assert type(schema['i']) is fields.Int


# Generated at 2022-06-25 16:05:45.788085
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema_f_1 = SchemaF()
    class A(object):
        def __init__(self, x: int, y: str) -> None:
            self.x = x
            self.y = y
    schema_f_1.dump([A(3, "3"), A(4, "4")])
    schema_f_1.dump([A(3, "3")])
    schema_f_1.dump(A(3, "3"))


# Generated at 2022-06-25 16:06:13.371283
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    schema_f_1 = SchemaF()
    result_1 = schema_f_1.load(None)
    assert result_1 == None

    result_2 = schema_f_1.load(None, many=True)
    assert result_2 == []



# Generated at 2022-06-25 16:06:19.643967
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f_loads = SchemaF()
    schema_f_loads.loads([{"a": 1}, {"b": 2}], many=True)
    schema_f_loads.loads({"a": 1}, many=False)
    schema_f_loads.loads({"a": 1}, many=True)
    schema_f_loads.loads([{"a": 1}], many=False)


# Generated at 2022-06-25 16:06:28.765313
# Unit test for function schema
def test_schema():
    # Test function schema
    class TestCls1:
        a: str
        b: int
        c: tuple
        d: typing.Optional[typing.Union[int, str]] = "default"
    schema_dict_1 = schema(TestCls1, "_", infer_missing=True)
    assert isinstance(schema_dict_1['a'], fields.Str)
    assert isinstance(schema_dict_1['b'], fields.Int)
    assert isinstance(schema_dict_1['c'], fields.Tuple)
    assert isinstance(schema_dict_1['d'], fields.Str)
    assert schema_dict_1['d']['missing'] == 'default'
    assert schema_dict_1['d']['allow_none'] == True
    # TODO: add more

# Generated at 2022-06-25 16:06:39.635378
# Unit test for function schema
def test_schema():
    from typing import List
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin, config
    from dataclasses_json.mm import M, mm_field

    # schema
    @dataclass
    class B(DataClassJsonMixin):
        b: int

    @dataclass
    class A(DataClassJsonMixin):
        a: str
        b: List[B] = mm_field(default=M(schema=B.Schema, many=True))
    
    result = schema(A, DataClassJsonMixin, infer_missing=True)
    assert result['b'].many == True
    assert isinstance(result['b'], fields.Nested)


# Generated at 2022-06-25 16:06:46.793750
# Unit test for function schema
def test_schema():
    class Person:
        def __init__(self, first_name: str, last_name: str):
            self.first_name = first_name
            self.last_name = last_name

    class Person(Schema):
        first_name = fields.Str()
        last_name = fields.Str()

    person_schema = schema(Person, {}, True)
    assert person_schema == {'first_name': fields.Str(), 'last_name': fields.Str()}

# Generated at 2022-06-25 16:06:49.800944
# Unit test for constructor of class _IsoField
def test__IsoField():
    x = _IsoField()


# Generated at 2022-06-25 16:06:57.310348
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema_f_0 = SchemaF()
    if (sys.version_info >= (3, 7)):
        # Test with all possible types of obj
        # Test with obj = None for type <class 'NoneType'>
        schema_f_0.dump(None)
        # Test with obj = [] for type <class 'list'>
        schema_f_0.dump([])
        # Test with obj = 1 for type <class 'int'>
        schema_f_0.dump(1)
        # Test with obj = 1.1 for type <class 'float'>
        schema_f_0.dump(1.1)
        # Test with obj = '1' for type <class 'str'>
        schema_f_0.dump('1')
        # Test with obj = {'a': 'b'} for type <class 'dict

# Generated at 2022-06-25 16:07:04.058279
# Unit test for function schema

# Generated at 2022-06-25 16:07:08.785558
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema_f_1 = SchemaF()
    schema_f_1.dumps('asdf', many=False)
    schema_f_1.dumps(['asdf', 'asdf'], many=True)
    schema_f_1.dumps(['asdf', 'asdf'])


# Generated at 2022-06-25 16:07:11.856853
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    if sys.version_info >= (3, 7):
        class TestUserSchema(SchemaF[User]):
            id = fields.Int()
            name = fields.Str()

        schema = TestUserSchema()
        user = User(1, 'test')
        assert schema.dumps(user) == '{"id": 1, "name": "test"}'


# Generated at 2022-06-25 16:08:04.863234
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # check case 0
    schema_f_0 = SchemaF()
    schema_f_0.dump(['aaa', 'bbb'], many=True)
    schema_f_0.dump(['aaa', 'bbb'], many=False)
    schema_f_0.dump(['aaa', 'bbb'])
    schema_f_0.dump('aaa')


# Generated at 2022-06-25 16:08:12.189912
# Unit test for function build_type
def test_build_type():
    type_0 = True
    options_0 = {}
    mixin_0 = False
    field_0 = SchemaType()
    cls_0 = bool
    build_type(type_0, options_0, mixin_0, field_0, cls_0)


# Generated at 2022-06-25 16:08:17.162181
# Unit test for function build_schema
def test_build_schema():
    def set_up_class_0():
        class Mixin0:
            pass

        class DC0:
            a: int = 1
            b: List[DC0] = []
            c: List[int] = [1]
            dataclass_json_config = __default_config__

        DC0.schema = build_schema(DC0, Mixin0, False, False)
        return DC0

    def set_up_class_1():
        def obj_to_dict(obj):
            return obj.__dict__

        class Mixin1:
            obj_to_dict = obj_to_dict

        class DC1:
            a: int = 1
            b: List[DC1] = []
            c: List[int] = [1]
            dataclass_json_config = __default_

# Generated at 2022-06-25 16:08:26.550435
# Unit test for function build_type
def test_build_type():
    class TestMixin:
        pass

    class TestCase:
        pass

    type_0 = typing.Dict
    options = {}
    mixin = TestMixin
    field = {}
    cls = TestCase
    result = build_type(type_0, options, mixin, field, cls)
    assert isinstance(result, fields.Mapping)
    assert result._required == False

    type_1 = typing.MutableMapping
    options = {}
    mixin = TestMixin
    field = {}
    cls = TestCase
    result = build_type(type_1, options, mixin, field, cls)
    assert isinstance(result, fields.Mapping)
    assert result._required == False

    type_2 = typing.Any
    options = {}
    mixin = TestMixin


# Generated at 2022-06-25 16:08:32.211123
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class Address:
        street: str
        city: str

    @dataclass_json
    @dataclass
    class Person:
        name: str
        age: int
        address: typing.Optional[Address] = None

    PersonSchema = build_schema(Person, {}, False, False)

    spy = Person('John', 30, None)

    assert type(PersonSchema) == type(Schema)
    assert len(PersonSchema.__dict__) == 5
    assert PersonSchema.Meta.fields == ("name", "age", "address")
    assert PersonSchema.__dict__["name"].data_key == "name"
    assert PersonSchema.__dict__["age"].data_key == "age"

# Generated at 2022-06-25 16:08:37.849401
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    assert SchemaF().load({}) is None
    # assert SchemaF().load([]) == []
    # assert SchemaF().loads([{"a": 1, "b": 2}, {"a": 3, "b": 4}]) == [{"a": 1, "b": 2}, {"a": 3, "b": 4}]



# Generated at 2022-06-25 16:08:47.653070
# Unit test for function build_schema
def test_build_schema():
    # Test case 0
    @dataclass
    class BasicDataclass:
        name: str
    @dataclass
    class BasicDataclassV2:
        name: str
    schema_f_0: typing.Type[SchemaF] = build_schema(BasicDataclass,
                                                    mixin = None,
                                                    infer_missing = False,
                                                    partial = False)
    assert schema_f_0 is SchemaF

    # Test case 1
    schema_f_1 = SchemaF[BasicDataclassV2]()  # type: ignore
    assert isinstance(schema_f_1, SchemaType)

    # Test case 2
    @dataclass
    class BasicDataclassV3:
        dc: BasicDataclassV2

# Generated at 2022-06-25 16:08:58.521881
# Unit test for function build_schema
def test_build_schema():
    @dataclasses.dataclass
    class A:
        a: int
        b: str
        c: typing.Dict[str, int]

    A_Schema = SchemaType[A]

    # Test argument cls
    assert issubclass(build_schema(A, None, None, None), SchemaType)

    # Test argument mixin
    assert issubclass(build_schema(A, A_Schema, None, None), SchemaType)

    # Test argument infer_missing
    assert issubclass(build_schema(A, None, True, None), SchemaType)

    # Test argument partial
    assert issubclass(build_schema(A, None, None, True), SchemaType)



# Generated at 2022-06-25 16:09:05.131301
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class _TestDataclass_0:
        int1: int = field(default=3)
        list1: list = field(default_factory=lambda: list())
        string1: str = field(default='string')

        class dataclass_json_config:
            mm_field = fields.Integer()

    @dataclass
    class _TestDataclass_1:
        int1: int
        list1: list
        string1: str

        class dataclass_json_config:
            mm_field = fields.Integer()

    @dataclass
    class _TestDataclass_2:
        list1: list

    @dataclass
    class _TestDataclass_3:
        list1: list = field(default_factory=lambda: list())


# Generated at 2022-06-25 16:09:11.444463
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    schema_f_1 = SchemaF()
    schema_f_1.load([{'field_name': 'field_value'}])


# Generated at 2022-06-25 16:11:56.875296
# Unit test for function schema
def test_schema():
    class _Test0:
        pass

    class Test(metaclass=_Test0):
        def __init__(self):
            self.i = int
            self.j = str
            self.nested_test = Test

    assert schema(Test, Test, False) == {
        'i': fields.Int,
        'j': fields.Str,
        'nested_test': fields.Nested(Test.schema())
    }

    assert schema(Test, None, False) == {
        'i': fields.Int,
        'j': fields.Str,
        'nested_test': fields.Field
    }



# Generated at 2022-06-25 16:11:58.619530
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    _TimestampField()


# Generated at 2022-06-25 16:12:05.492091
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema_f_0 = SchemaF()
    obj_0 = schema_f_0.dump([1])
    _return_type_0 = typing.Union[typing.List[TEncoded], TEncoded]
    assert isinstance(obj_0, _return_type_0)
    obj_1 = schema_f_0.dump([1], many=False)
    _return_type_0 = typing.Union[typing.List[TEncoded], TEncoded]
    assert isinstance(obj_1, _return_type_0)


# Generated at 2022-06-25 16:12:12.575340
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin, config
    from dataclasses_json._config import (Undefined, INFER, RAISE)

    @dataclass
    class Person(DataClassJsonMixin):
        name: str
        age: int


    @dataclass
    class Cat(DataClassJsonMixin):
        name: str
        kind: str


    @dataclass
    class Owner(DataClassJsonMixin):
        name: str
        pet: Cat


    @dataclass
    class Complex(DataClassJsonMixin):
        owner: Owner
        friends: typing.List[Person]


    @dataclass
    class SpecialData(DataClassJsonMixin):
        special_field: str = '42'
