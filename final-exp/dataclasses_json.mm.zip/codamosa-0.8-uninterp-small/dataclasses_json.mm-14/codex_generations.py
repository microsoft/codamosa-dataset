

# Generated at 2022-06-25 16:02:35.975004
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema_f_0 = SchemaF()
    schema_f_0.dumps()
    schema_f_0.dumps([])
    schema_f_0.dumps({})


# Generated at 2022-06-25 16:02:41.833352
# Unit test for function schema
def test_schema():
    from dataclasses_json import DataClassJsonMixin
    from dataclasses import dataclass
    from dataclasses_json.mm_schema import schema

    @dataclass
    class U(DataClassJsonMixin):
        val: int = 1

    @dataclass
    class T(DataClassJsonMixin):
        u: U

    T.schema().dump(T(u=U()))
    # schema(T, DataClassJsonMixin, False)


# Generated at 2022-06-25 16:02:46.871598
# Unit test for function schema
def test_schema():
    from typing import Literal
    from dataclasses_json import DataClassJsonMixin

    class MyDataClass(DataClassJsonMixin):
        name: str
        age: int
        is_admin: bool

    @dataclasses_json.dataclass_json
    class DataClass(DataClassJsonMixin):
        name: str
        age: int
        is_admin: bool

    @dataclasses_json.dataclass_json
    class DataClass2(DataClassJsonMixin):
        name: str
        age: int
        is_admin: Literal[True]

    @dataclasses_json.dataclass_json
    class DataClass3(DataClassJsonMixin):
        name: Literal["John", "Jane"]
        age: int

# Generated at 2022-06-25 16:02:57.409804
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    s = SchemaF()
    s.load({"a": 1, "b": "2"})
    s.load([{"a": 1, "b": "2"}])

if sys.version_info >= (3, 7):
    class SchemaF2(Schema, typing.Generic[A]):  # type: ignore
        """Lift Schema into a type constructor"""

        def __init__(self, *args, **kwargs):
            """
            Raises exception because this class should not be inherited.
            This class is helper only.
            """

            super().__init__(*args, **kwargs)
            raise NotImplementedError()

        # noinspection PyUnresolvedReferences,PyArgumentList

# Generated at 2022-06-25 16:03:04.168129
# Unit test for function schema
def test_schema():
    class A:
        def __init__(self, field: str):
            self.field = field
        def __repr__(self):
            return str(self.field)
    class B:
        def __init__(self, field: A):
            self.field = field
        def __repr__(self):
            return str(self.field)
    result_1 = schema(B, None, False)
    result_2 = schema(A, None, False)


# Generated at 2022-06-25 16:03:05.674858
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    schema_f = SchemaF()
    schema_f.load({})


# Generated at 2022-06-25 16:03:08.167009
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()



# Generated at 2022-06-25 16:03:09.931989
# Unit test for constructor of class _IsoField
def test__IsoField():
    schema_f_1 = SchemaF()
    assert schema_f_1.str_required_field


# Generated at 2022-06-25 16:03:19.854176
# Unit test for function schema
def test_schema():
    import dataclasses
    from dataclasses_json.api import Schema

    @dataclasses.dataclass
    class Example:
        name: str = dataclasses.field(metadata=Schema(letter_case="upper"))
        age: int = dataclasses.field(metadata=Schema(default=100))
        optional: typing.Optional[int] = None

    assert schema(Example, mixin=Schema, infer_missing=True) == {
        "name": fields.Str(data_key="name", missing="", allow_none=True),
        "age": fields.Int(data_key="age", default=100, allow_none=True),
        "optional": fields.Int(data_key="optional", allow_none=True, missing=None)
    }



# Generated at 2022-06-25 16:03:30.905299
# Unit test for function build_schema
def test_build_schema():
    class TestMixin0:
        pass

    class TestMixin1:
        def func1(self):
            pass

    class Test0(TestMixin0):
        def func0(self):
            pass

    class Test1(TestMixin1):
        def func1(self):
            pass

    class Test2(TestMixin1):
        def func2(self):
            pass

    class Test3(TestMixin0):
        def func2(self):
            pass

    class Test4:
        def func4(self):
            pass

    class Test5(Test4):
        def func5(self):
            pass

    class Test6(Test4):
        def func6(self):
            pass


# Generated at 2022-06-25 16:03:43.411854
# Unit test for function schema
def test_schema():
    assert True



# Generated at 2022-06-25 16:03:53.169921
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    schema = Schema()
    schema_f = SchemaF()

    @schema.load_instance
    def load_instance(self, data, many=None, partial=None, unknown=None):
        return schema_f.load_instance(self, data, many=many, partial=partial, unknown=unknown)

    @schema.dump_instance
    def dump_instance(self, obj, many=None, update_fields=None,
                      **kwargs):
        return schema_f.dump_instance(self, obj, many=many, update_fields=update_fields, **kwargs)

    @schema.dump
    @schema.load
    def f(obj, **kwargs):
        return obj


# Generated at 2022-06-25 16:03:55.179608
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField("foo")



# Generated at 2022-06-25 16:04:00.568174
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    timestamp_field0 = _TimestampField()
    assert isinstance(timestamp_field0, fields.Field)
    assert timestamp_field0.required
    assert timestamp_field0._creation_index == 0
    assert timestamp_field0.data_key == None
    assert timestamp_field0.missing == MISSING
    assert timestamp_field0.allow_none == False
    assert timestamp_field0.load_from == None
    assert timestamp_field0.dump_to == None
    assert timestamp_field0.allow_none == False
    assert timestamp_field0.metadata == {}


# Generated at 2022-06-25 16:04:06.469325
# Unit test for function build_schema
def test_build_schema():
    class User:
        def __init__(self, name: str, email: str = '') -> None:
            self.name = name
            self.email = email

        def __repr__(self):
            return f'<User name={self.name} email={self.email}>'

    class Address:
        def __init__(self, full: str) -> None:
            self.full = full

        def __repr__(self):
            return f'<Address full={self.full}>'

    UserSchema = build_schema(
        User, mixin=None, infer_missing=False, partial=None)

    json_data = {"name": "Rob", "email": ""}
    user = UserSchema().load(json_data)

    # print(user)



# Generated at 2022-06-25 16:04:12.784292
# Unit test for function schema
def test_schema():
    # ! for `dataclasses_json.schema` and `dataclasses_json.mixin`,
    # ! we only test the dataclass with type annotations
    from dataclasses import dataclass, field
    from dataclasses_json import config
    @dataclass
    class A(object):
        a: typing.List[int]
        b: int
    assert schema(A, config.MIXIN_IGNORE, False) == {'a': fields.List(fields.Int()), 'b': fields.Int(), }
    assert schema(A, config.MIXIN_IGNORE, True) == {'a': fields.List(fields.Int()), 'b': fields.Int(), }

# Generated at 2022-06-25 16:04:14.204870
# Unit test for constructor of class _IsoField
def test__IsoField():
    test_case_0()


# Generated at 2022-06-25 16:04:17.049923
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    test = _TimestampField()
    assert test._serialize.__name__ == "_serialize"
    assert test._deserialize.__name__ == "_deserialize"



# Generated at 2022-06-25 16:04:20.540665
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField(required=False)
    assert not field.required
    field = _TimestampField()
    assert field.required


# Generated at 2022-06-25 16:04:27.873465
# Unit test for function build_type
def test_build_type():
    class TestSchema(SchemaF[A]):
        pass
    type_ = typing.List
    options = {}
    mixin = SchemaF
    field = fields
    cls = TestSchema
    fieldGenerated = build_type(type_, options, mixin, field, cls)
    assert isinstance(fieldGenerated, fields.List)

# Generated at 2022-06-25 16:04:57.096592
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class SchemaF_Test(SchemaF, Schema):
        def __init__(self, fields: typing.Dict[str, fields.Field]):
            super().__init__(fields=fields)

    class TestWithFoo(typing.Generic[A]):
        def __init__(self, foo: A):
            self.foo = foo

    schema_f_0 = SchemaF_Test({'foo': fields.Str()})
    res_0 = schema_f_0.dump(TestWithFoo(foo=42))

    assert res_0['foo'] == '42'


# Generated at 2022-06-25 16:05:02.551666
# Unit test for function schema
def test_schema():
    schema_f = SchemaF()
    schema_f_0 = SchemaF(cls=object, mixin=object, infer_missing=True)
    assert(schema_f.__class__.__name__ == 'SchemaF')
    assert(schema_f_0.__class__.__name__ == 'SchemaF')


# Generated at 2022-06-25 16:05:14.164073
# Unit test for function build_type
def test_build_type():
    build_type_f_a = build_type(type_=typing.List, options={"age": 100}, mixin=None, field=None, cls=None)
    build_type_f_b = build_type(type_=typing.Mapping, options={"age": 100}, mixin=None, field=None, cls=None)
    build_type_f_c = build_type(type_=typing.MutableMapping, options={"age": 100}, mixin=None, field=None, cls=None)
    build_type_f_d = build_type(type_=typing.Tuple, options={"age": 100}, mixin=None, field=None, cls=None)

# Generated at 2022-06-25 16:05:16.328134
# Unit test for function schema
def test_schema():
    schema({}, Schema, False)


# Generated at 2022-06-25 16:05:24.513549
# Unit test for function schema
def test_schema():
    import typing
    from dataclasses import dataclass, field
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class Dc0:
        a: typing.List[int]
        b: typing.Dict[int, int]
        c: typing.Tuple[int, int]
        d: typing.Mapping[int, int]
        e: typing.MutableMapping[int, int]
        f: int = field(default=1)
        g: typing.Optional[int] = None
        h: typing.Optional[typing.List[int]] = None
        i: typing.Optional[typing.List[int]] = field(default_factory=list)
        j: typing.Callable = lambda: None
        k: typing.Any

# Generated at 2022-06-25 16:05:34.272633
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    def f_a(arg: typing.Union[A, None]) -> str:
        return "Hey"
    def f_b(self, arg: A, many: None = None, partial: bool = None, unknown: str = None, **kwargs) -> str:
        return "Hey"
    schema_f_1 = SchemaF()
    schema_f_2 = SchemaF()
    schema_f_3 = SchemaF()
    schema_f_4 = SchemaF()
    schema_f_5 = SchemaF()
    schema_f_6 = SchemaF()
    schema_f_1.dumps(None)
    schema_f_2.dumps(None, many=None)
    schema_f_3.dumps(None, many=None, partial=None)
    schema_f_4

# Generated at 2022-06-25 16:05:35.772646
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()


# Generated at 2022-06-25 16:05:38.672310
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    f = _TimestampField()
    assert f.missing is None
    assert f.allow_none is False
    assert f.__repr__() == "<fields.TimestampField>"


# Generated at 2022-06-25 16:05:45.884139
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # Type variables
    A = typing.TypeVar('A')

    # Local variables
    # Local type definitions
    class SchemaF(Schema, typing.Generic[A]):
        """Lift Schema into a type constructor"""

        def __init__(self, *args, **kwargs):
            """
            Raises exception because this class should not be inherited.
            This class is helper only.
            """

            super().__init__(*args, **kwargs)
            raise NotImplementedError()

        @typing.overload
        def dump(self, obj: typing.List[A], many: bool = None) -> typing.List[
            TEncoded]:  # type: ignore
            # mm has the wrong return type annotation (dict) so we can ignore the mypy error
            pass


# Generated at 2022-06-25 16:05:50.135557
# Unit test for function schema
def test_schema():
    print("test_schema - start")

    test_schema_0 = schema(object, object, True)
    test_schema_0 = schema(int, object, True)
    test_schema_0 = schema(str, object, True)
    # test_schema_0 = schema(UUID, object, True)
    test_schema_0 = schema(Decimal, object, True)
    test_schema_0 = schema(float, object, True)

    print("test_schema - done")


if __name__ == '__main__':
    test_case_0()
    test_schema()

# Generated at 2022-06-25 16:06:52.259996
# Unit test for function build_type
def test_build_type():
    class MyClass(object):
        def __init__(self, name):
            self.name = name
        def __str__(self):
            return str(self.name)

    @dataclass_json
    @dataclass
    class MyDataClass:
        val: str

    @dataclass
    class MyDataClass2:
        val: str

    @dataclass_json
    @dataclass
    class foo:
        f1: typing.Dict
        f2: typing.List
        f3: typing.Tuple
        f4: typing.Callable
        f5: typing.Any
        f6: dict
        f7: list
        f8: str
        f9: int
        f10: float
        f11: bool
        f12: datetime
        f13: U

# Generated at 2022-06-25 16:06:59.023953
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f = SchemaF()
    data = "{ 'a': 3 }"
    schema_f.loads(data)


# Generated at 2022-06-25 16:07:09.330290
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # Test of SchemaF.load with an argument obj of type List[A],
    # an argument many of type bool, an argument partial of type None
    # and an argument unknown of type None
    # Input:
    # obj=list of a generic type A
    # many=False
    # partial=False
    # unknown=None
    # Output:
    # List of type A
    schema_f_1 = SchemaF()
    obj = list()
    many = False
    partial = False
    unknown = None
    out_ = schema_f_1.load(obj, many, partial, unknown)
    assert list == type(out_)
    # Test of SchemaF.load with an argument obj of type A,
    # an argument many of type None, an argument partial of type bool
    # and an argument unknown of type None

# Generated at 2022-06-25 16:07:15.016186
# Unit test for function build_type
def test_build_type():
    import dataclasses
    import enum
    import typing

    @dataclasses.dataclass
    class TestClass:
        pass

    @enum.Enum
    class TestEnum(enum.Enum):
        A = 2
        B = 3

    # Numbers 0 - 4
    test_cases = [
        dataclasses.field(metadata={'mm_field': fields.Integer}),
        dataclasses.field(metadata={'mm_field': fields.Field}),
        dataclasses.field(metadata={'mm_field': fields.Integer}),
        dataclasses.field(metadata={'mm_field': fields.Field}),
        dataclasses.field(metadata={'mm_field': fields.Integer}),
    ]


# Generated at 2022-06-25 16:07:17.909211
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f_1 = SchemaF()
    res_loads_0 = schema_f_1.loads(b'{"field_0": 2.5}')
    assert res_loads_0 == {'field_0': 2.5}


# Generated at 2022-06-25 16:07:25.514531
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema_f_1 = SchemaF[str]
    schema_f_2 = SchemaF[int]
    schema_f_3 = SchemaF[float]
    schema_f_4 = SchemaF[bool]
    schema_f_5 = SchemaF[UUID]
    schema_f_6 = SchemaF[datetime]
    schema_f_7 = SchemaF[Decimal]
    schema_f_8 = SchemaF[typing.List[str]]
    schema_f_9 = SchemaF[typing.List[int]]
    schema_f_10 = SchemaF[typing.List[float]]
    schema_f_11 = SchemaF[typing.List[bool]]
    schema_f_12 = SchemaF[typing.List[UUID]]
    schema

# Generated at 2022-06-25 16:07:26.919504
# Unit test for constructor of class _IsoField
def test__IsoField():
    result = _IsoField()
    assert isinstance(result, fields.Field)


# Generated at 2022-06-25 16:07:33.842953
# Unit test for function build_type
def test_build_type():
    # test case 1: if the type is a basic type
    class TestCase1():
        def __init__(self, test_int = 1, test_str = 'test',
                     test_float = 1.1, test_bool = True):
            self.test_int = test_int
            self.test_str = test_str
            self.test_float = test_float
            self.test_bool = test_bool
    class TestCase1Schema(Schema):
        class Meta:
            strict = True

        test_int = fields.Integer(required=False)
        test_str = fields.Str(required=False)
        test_float = fields.Float(required=False)
        test_bool = fields.Bool(required=False)


# Generated at 2022-06-25 16:07:43.476575
# Unit test for function build_schema
def test_build_schema():
    from typing import List

    @dataclass_json
    @dataclass
    class MySchema:
        list_of_ints: List[int]

    @dataclass_json
    @dataclass
    class MySchema2(MySchema):
        name: str

    # Test the types
    assert SchemaType == type(SchemaF[MySchema2])

    # Test 1
    schema_f_1 = build_schema(MySchema, [], False, False)
    assert SchemaType == type(schema_f_1)

    # Test 2
    schema_f_2 = build_schema(MySchema2, [], True, True)
    assert SchemaType == type(schema_f_2)

# Generated at 2022-06-25 16:07:46.928683
# Unit test for function build_schema
def test_build_schema():
    class Point:
        x: int
        y: bool

    schema = build_schema(Point, None, False, False) # type: ignore
    assert 'x' in schema.__dict__['Meta'].__dict__['fields']
    assert 'y' in schema.__dict__['Meta'].__dict__['fields']


# Generated at 2022-06-25 16:10:38.483939
# Unit test for function build_schema
def test_build_schema():
    def mixin():
        return

    def infer_missing():
        return

    def partial():
        return

    class TestClass1:
        pass
    class TestClass2:
        pass

    class TestClass0:
        field1: TestClass1
        field2: TestClass2

    build_schema(TestClass0, mixin, infer_missing, partial)

# Generated at 2022-06-25 16:10:43.493659
# Unit test for function schema
def test_schema():
    from typing import List
    from dataclasses import dataclass
    from marshmallow import fields

    @dataclass
    class Test0:
        a: str
        b: int
    schema = schema(Test0, object, infer_missing=True)

    assert schema == {'a': fields.String(), 'b': fields.Integer(), 'c': fields.Dict()}

# Generated at 2022-06-25 16:10:53.024537
# Unit test for function build_type
def test_build_type():
    # Case1: MM_TYPES[origin] in TYPES
    type_1 = typing.List[str]
    options_1 = {'data_key': 'test data'}
    mixin_1 = None  # What type should be passed in?
    field_1 = None  # What type should be passed in?
    cls_1 = None  # What type should be passed in?
    build_type(type_1, options_1, mixin_1, field_1, cls_1)

    # Case2: is_union_type
    type_2 = typing.Union
    options_2 = {'data_key': 'test data'}
    mixin_2 = None  # What type should be passed in?
    field_2 = None  # What type should be passed in?
    cls_

# Generated at 2022-06-25 16:10:59.139201
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Parent:
        name = str
        surname = str

    @dataclass
    class Child(Parent):
        birth_date = datetime
        is_active = bool
    schema = Schema.from_dataclass(Child)
    assert schema.dump(Child(name='John', surname='Doe', birth_date=datetime.now(), is_active=True)) == {
        'name': 'John',
        'surname': 'Doe',
        'birth_date': datetime.now().timestamp(),
        'is_active': True
    }


# Generated at 2022-06-25 16:11:00.478490
# Unit test for function schema
def test_schema():
    result = schema({}, object, True)
    assert type(result) == dict

# Generated at 2022-06-25 16:11:07.756722
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class TestSchemaF_dump(SchemaF):
        pass

    class TestDataClass(object):
        def __init__(self, a: int, b: typing.Optional[str]):
            self.a = a
            self.b = b

        def __eq__(self, o: typing.Any) -> bool:
            if type(o) is type(self):
                return o.__dict__ == self.__dict__
            return False

    schema_f_1 = SchemaF()
    schema_f_2 = TestSchemaF_dump()
    d = TestDataClass(1, "hi")
    assert_equal(schema_f_1.dump(d), schema_f_2.dump(d))


# Generated at 2022-06-25 16:11:16.614506
# Unit test for function schema
def test_schema():
    @dataclass_json
    @dataclass
    class PersonSchema:
        id: int
        name: str
        email: str

    @dataclass_json
    @dataclass
    class DataModelSchema:
        id: int
        person: PersonSchema
        createdAt: datetime
        lastUpdate: datetime
        version: int = 1

    class NullSchema(Schema):  # type: ignore
        id = fields.Int()
        person = fields.Nested(PersonSchema.schema(), allow_none=True)  # type: ignore
        createdAt = _IsoField(allow_none=True)
        lastUpdate = _TimestampField()
        version = fields.Int()

    def _remove_version(data):
        del data['version']
        return data


# Generated at 2022-06-25 16:11:23.162192
# Unit test for function build_schema

# Generated at 2022-06-25 16:11:23.865292
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    timestamp = _TimestampField()



# Generated at 2022-06-25 16:11:34.239429
# Unit test for function build_schema
def test_build_schema():
    class User(dataclasses.dataclass):
        username: str = dataclasses.field(metadata={'dataclasses_json': {'mm_field': fields.Str()}})
        password: str = dataclasses.field(metadata={'dataclasses_json': {'mm_field': fields.Str()}})

    class UserSchema(Schema):
        class Meta:
            fields = ('username', 'password')

        make_user = post_load(User)

    u1 = UserSchema().load({'username': 'john', 'password': 'password'})
    u2 = _UserSchema().load({'username': 'john', 'password': 'password'})

    assert u1 == u2

if __name__ == "__main__":
    test_build_schema()