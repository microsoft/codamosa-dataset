

# Generated at 2022-06-25 16:02:50.883480
# Unit test for function schema
def test_schema():
    class TestSchema:
        def __init__(self, *args, **kwargs):
            raise NotImplementedError()

        @typing.overload
        def dump(self, obj: typing.List['TestSchema'], many: bool = None) -> typing.List[
            TEncoded]:  # type: ignore
            # mm has the wrong return type annotation (dict) so we can ignore the mypy error
            pass

        @typing.overload
        def dump(self, obj: 'TestSchema', many: bool = None) -> TEncoded:
            pass

        def dump(self, obj: 'TestSchema',
                 many: bool = None) -> TOneOrMultiEncoded:
            pass


# Generated at 2022-06-25 16:03:02.978665
# Unit test for function build_schema
def test_build_schema():

    # ----------
    # Check case 1: cls is Union[int, str]
    # ----------

    cls_1 = Union[str, int]
    mixin_1 = None
    infer_missing_1 = False
    partial_1 = False
    result_1 = build_schema(cls_1, mixin_1, infer_missing_1, partial_1)
    expected_result_1 = SchemaType
    assert result_1 == expected_result_1

    # ----------
    # Check case 2: cls is Union[int, str, Union[str, str]]
    # ----------

    cls_2 = Union[str, int, Union[str, str]]
    mixin_2 = None
    infer_missing_2 = False
    partial_2 = False
    result_2 = build_

# Generated at 2022-06-25 16:03:07.761045
# Unit test for function build_schema
def test_build_schema():
    class TestMixin:
        some_value: int

    class Test2(DataclassJsonMixin):
        some_value: int

    class Test:
        some_value: int

        @dataclass_json()
        class Test2:
            some_value: int

    @dataclass_json()
    class Test2(TestMixin):
        some_value: int

    build_schema(Test, TestMixin, False, False)
    build_schema(Test2, TestMixin, False, False)

# Generated at 2022-06-25 16:03:15.701742
# Unit test for function schema
def test_schema():
    from marshmallow_dataclass import dataclass
    from dataclasses import field

    @dataclass
    class Dc0:
        name: str
        quantity: int = field(default=0)

    @dataclass
    class Dc1:
        name: str = field(metadata=dict(dataclasses_json=dict(mm_field=fields.Int())))
        price: float = field(default=0.01)
        others: typing.List = field(default_factory=list)

    @dataclass
    class Dc3(mixin=mixin):
        name: str = field(metadata=dict(dataclasses_json=dict(mm_field=fields.Int())))
        price: float = field(default=0.01)

# Generated at 2022-06-25 16:03:21.503375
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass(frozen=True)
    class TestClass_0:
        a: int = field(default=0)
        b: str = field(default=None)

    TestClass_0_schema = build_schema(TestClass_0, Schema, True, False)
    mm_inst_0 = TestClass_0_schema()
    data_0 = {'a': 123, 'b': 'hello'}
    mm_inst_0.load(data_0)


# Generated at 2022-06-25 16:03:27.882988
# Unit test for function schema
def test_schema():
    import dataclasses
    from dataclasses import dataclass
    from marshmallow import Schema

    # Test build_type()
    @dataclass
    class Foo: pass
    @dataclass
    class Bar: pass
    class Baz(Enum): A=1; B=2; C=3
    @dataclass
    class Qux:
        @property
        def name(self):
            return None
    @dataclass
    class QuxWithProp:
        @property
        def name(self):
            return "A"
    @dataclass
    class Base:
        arr: typing.Sequence[typing.Tuple[int, Baz]]
        a: typing.Sequence[Foo]
        b: typing.Union[Foo, Bar]


# Generated at 2022-06-25 16:03:29.903200
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class Test:
        val_1: int

    s = build_schema(Test, None, False, False)
    print(s.Meta.fields)

# Generated at 2022-06-25 16:03:36.537478
# Unit test for function build_schema
def test_build_schema():
    assert hasattr(build_schema(Person, mm_base, True, True), 'Meta')
    assert hasattr(build_schema(Person, mm_base, True, True), 'make_person')
    assert hasattr(build_schema(Person, mm_base, True, True), 'dump')
    assert hasattr(build_schema(Person, mm_base, True, True), 'dumps')
    assert hasattr(build_schema(Person, mm_base, True, True), 'name')
    assert hasattr(build_schema(Person, mm_base, True, True), 'age')
    assert hasattr(build_schema(Person, mm_base, True, True), 'tags')
    assert hasattr(build_schema(Person, mm_base, True, True), 'friends')
    assert hasattr

# Generated at 2022-06-25 16:03:43.622574
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields
    from marshmallow import pprint

    class UserSchema(Schema):
        id = fields.Int()
        name = fields.Str(required=True)

    schema_f_2 = SchemaF()

    # Test valid data case
    obj_f_2 = UserSchema().load({"name": "Monty"})
    res_f_2 = schema_f_2.dumps(obj_f_2)

    # Test invalid data case
    obj_f_2 = UserSchema().load({"name2": "Monty"})
    res_f_2 = schema_f_2.dumps(obj_f_2)

    # Test multi-valid data case

# Generated at 2022-06-25 16:03:46.709288
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f_0 = SchemaF()
    schema_f_0.loads('')  # bytes
    schema_f_0.loads('')  # str


# Generated at 2022-06-25 16:04:01.560724
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    s = SchemaF()
    s.dumps(1)

# Test case for _union_field of module dataclasses_json

# Generated at 2022-06-25 16:04:03.900014
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema_f_1 = SchemaF()
    schema_f_2 = SchemaF()

# Generated at 2022-06-25 16:04:11.016884
# Unit test for function schema
def test_schema():
    class Obj:
        def __init__(self, name):
            self.name = name

    @dataclass_json
    @dataclass
    class A:
        a: int
        b: typing.Optional[str]
        c: typing.Optional[bool]
        d: typing.Optional[typing.Union[str, int]]
        e: typing.Optional[Obj]
        f: typing.Optional[typing.List[str]]
        g: typing.Optional[typing.Union[str, int]] = None
        h: typing.Optional[typing.List[Obj]] = None

    @dataclass_json
    @dataclass
    class B:
        a: A


# Generated at 2022-06-25 16:04:16.378859
# Unit test for function build_type
def test_build_type():
    test_list = []
    test_options = {}
    test_mixin = {}
    test_field = {}
    test_cls = {}
    assert not build_type(test_list, test_options, test_mixin, test_field, test_cls)


# Generated at 2022-06-25 16:04:20.540707
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    try:
        _TimestampField()
    except Exception as e:
        assert dataclasses_json.core.APIException(
            "Default arguments are not allowed for _TimestampField")
    # expected exception



# Generated at 2022-06-25 16:04:31.231995
# Unit test for function build_type
def test_build_type():
    class DogMixin(dataclass_json.dataclass_json):
        class Config:
            unknown = EXCLUDE

    @dataclass_json.dataclass_json
    class Person(DogMixin):
        name: str
        age: int

    class GenericSchema(dataclass_json.Schema):
        name = fields.Str()
        age = fields.Int()

    @dataclass_json.dataclass_json
    class Dog:
        name: str


    @dataclass_json.dataclass_json
    class Cat(DogMixin):
        name: str

    @dataclass_json.dataclass_json
    class Pet(DogMixin):
        name: str
        age: int



# Generated at 2022-06-25 16:04:35.786020
# Unit test for function build_schema
def test_build_schema():
    test_data = {'name': 'test', 'age': 10}
    test_json = json.dumps(test_data, cls=_ExtendedEncoder)
    @dataclass_json(infer_missing=True)
    @dataclass
    class User:
        name: str
        age: int
    UserSchema = build_schema(User, dataclass_json, False, False)
    user_schema = UserSchema()
    user_obj = user_schema.loads(test_json)
    user_schema.dumps(user_obj)
    user_schema.dump(user_obj)

test_build_schema()

# Generated at 2022-06-25 16:04:41.858387
# Unit test for function build_type
def test_build_type():
    type_1 = dict
    options_1 = {}
    mixin_1 = {}
    field_1 = None
    cls_1 = None
    assert build_type(type_1, options_1, mixin_1, field_1, cls_1) == fields.Dict

type_2 = list
options_2 = {}
mixin_2 = {}
field_2 = None
cls_2 = None
assert build_type(type_2, options_2, mixin_2, field_2, cls_2) == fields.List

type_3 = str
options_3 = {}
mixin_3 = {}
field_3 = None
cls_3 = None

# Generated at 2022-06-25 16:04:45.132378
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema_f_str = SchemaF()
    schema_f_str_data = schema_f_str.dumps({'a': 1, 'b': '2'})


# Generated at 2022-06-25 16:04:52.654414
# Unit test for function schema
def test_schema():
    class Metadata:
        def __init__(self):
            self.mm_field = None
            self.letter_case = ''

    def merge_abc(abc):
        return type('_MergedClass',
                    (abc, ), {
                        'schema': lambda self: self,
                        'mm_field': Metadata(),
                        '__module__': 'test'
                    })

    M = merge_abc
    # basic class
    class Class1:
        pass

    class_1 = Class1()
    class_dict = schema(class_1, M, False)
    assert class_dict == {}

    # class with no fields
    @dataclasses.dataclass
    class Class2:
        pass

    class_2 = Class2()
    class_dict = schema(class_2, M, False)
   

# Generated at 2022-06-25 16:05:16.073404
# Unit test for function build_type
def test_build_type():
    # Simple case, union of str and int
    t1 = typing.Union[int, str]
    options = {"allow_none": False}
    assert build_type(t1, options, None, None, None) == fields.Field(**{"allow_none": False})
    options = {"allow_none": True}
    assert build_type(t1, options, None, None, None) == fields.Field(**{"allow_none": True})
    # Nested union of str and int
    t2 = typing.Union[int, typing.Union[str, bool]]
    options = {"allow_none": False}
    assert build_type(t2, options, None, None, None) == fields.Field(**{"allow_none": False})
    options = {"allow_none": True}

# Generated at 2022-06-25 16:05:24.099510
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # Case 0
    # Prepare
    class A(typing.NamedTuple):
        b: int
        c: str
    a0 = A(b=0, c='foo')
    a1 = A(b=42, c='bar')
    a_dict_0 = [{'b': 42, 'c': 'bar'}, {'b': 0, 'c': 'foo'}]

    class SchemaA(SchemaF[A]):
        b = fields.Int()
        c = fields.Str()

    # Act
    res0 = SchemaA().load(a_dict_0, many=True)

    # Assert
    assert res0[0] == a1
    assert res0[1] == a0

    # Case 1
    # Prepare

# Generated at 2022-06-25 16:05:34.243403
# Unit test for function build_type
def test_build_type():
    class Foo:
        def __init__(self, id):
            self.id = id

    class Bar:
        def __init__(self, id):
            self.id = id

    BAR_TYPE_IN_FIELD = typing.Union[Bar, None]

    @dataclass
    class FooBarUnion:
        id: BAR_TYPE_IN_FIELD

    @dataclass
    class FooBarUnion2:
        id: typing.Union[Bar, None]

    @dataclass
    class FooBarUnion3:
        id: typing.Union[None, Bar]

    @dataclass
    class FooBarUnion4:
        id: typing.Union[None, Bar]

    @dataclass
    class FooBarUnion5:
        id: typing.Union[Bar, None, Foo]


# Generated at 2022-06-25 16:05:45.651816
# Unit test for function schema
def test_schema():
    Foo_schema = schema(Foo, mixin, infer_missing)
    assert Foo_schema == {'x': fields.List(fields.Integer(), missing=1),
                          'y': fields.Integer(missing=2),
                          'z': fields.Str(missing='1')}
    Bar_schema = schema(Bar, mixin, infer_missing)
    assert Bar_schema == {'a': fields.Nested(Foo.schema(), allow_none=True),
                          'b': fields.Nested(Foo.schema(), many=True)}


# Generated at 2022-06-25 16:05:58.863556
# Unit test for function schema
def test_schema():
    schema_f = SchemaF()

    schema = {}
    overrides = {}
    # TODO check the undefined parameters and add the proper schema action
    #  https://marshmallow.readthedocs.io/en/stable/quickstart.html

    field = dc_fields(DC).__getitem__(0)
    mixin = None
    cls = DC
    metadata = (field.metadata or {}).get('dataclasses_json', {})
    metadata = overrides[field.name]
    if metadata.mm_field is not None:
        schema[field.name] = metadata.mm_field
    else:
        type_ = field.type
        options = {}
        infer_missing = False
        missing_key = 'missing' if infer_missing else 'default'

# Generated at 2022-06-25 16:06:00.317225
# Unit test for function build_schema
def test_build_schema():
    try:
        schema_f_1 = SchemaF()
    except:
        pass


# Generated at 2022-06-25 16:06:01.634682
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema_f_1 = SchemaF()
    schema_f_1.dumps([])


# Generated at 2022-06-25 16:06:13.241511
# Unit test for function build_schema
def test_build_schema():
    import typing
    import enum
    import enum_decoder
    from dataclass_json import dataclass_json
    from typing import Optional, List

    @dataclass_json
    @dataclass
    class Test0:
        test: str
        test_0: int = field(metadata={'dataclasses_json': {'mm_field': fields.Int(validate=lambda value: int > 0)}})

    @dataclass_json
    @dataclass
    class Nested:
        test: str

    @dataclass_json
    @dataclass
    class Test1:
        test: str
        nested: Optional[Nested] = None

    @dataclass_json
    @dataclass
    class Test2:
        test: str

# Generated at 2022-06-25 16:06:14.093448
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()


# Generated at 2022-06-25 16:06:22.324582
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # Protocol for test case 0
    test_data_0: typing.List[A] = [1, 2, 3]
    expected_result_0: str = '[1, 2, 3]'

    # Protocol for test case 1
    test_data_1: A = [1, 2, 3]
    expected_result_1: str = '[1, 2, 3]'

    # Protocol for test case 2
    test_data_2: TOneOrMulti = 'abc'
    expected_result_2: str = '"abc"'

    results: typing.List[bool] = []
    results.append(expected_result_0 == SchemaF().dumps(test_data_0))
    results.append(expected_result_1 == SchemaF().dumps(test_data_1))

# Generated at 2022-06-25 16:06:51.907222
# Unit test for function build_type
def test_build_type():
    # Test case 1
    class A(object):
        pass

    assert build_type(type(A), {}, A, A, 'test') == fields.Raw


# Generated at 2022-06-25 16:07:02.070883
# Unit test for function schema
def test_schema():
    class A(Enum):
        pass
    from dataclasses import dataclass

    @dataclass
    class B:
        short_str: str
        short_str_opt: typing.Optional[str]
        short_str_def: str = '123'
        short_str_def_opt: typing.Optional[str] = '123'
        short_str_def_factory: str = '123'
        short_str_def_factory_opt: typing.Optional[str] = '123'

        short_float: float
        short_float_opt: typing.Optional[float]
        short_float_def: float = 123.3
        short_float_def_opt: typing.Optional[float] = 123.3

        bool_value: bool = False

# Generated at 2022-06-25 16:07:04.775309
# Unit test for function build_type
def test_build_type():
    # type: (Schema, )
    assert build_type(int, {}, '', {}, '') == fields.Int()
    assert build_type(int, {}, '', {}, '').marshmallow_field_name == 'Int'


# Generated at 2022-06-25 16:07:09.677139
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f = SchemaF()
    json_data = [{'__type': 'mytype', 'myvar': 'myvalue'}]
    loads = schema_f.loads(json_data, many=True)
    assert loads == json_data


if sys.version_info >= (3, 7):
    T = typing.TypeVar('T', covariant=True)
else:
    T = typing.TypeVar('T')



# Generated at 2022-06-25 16:07:21.740612
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Test0:
        def load(self, data: typing.List[TEncoded],
                 many: bool = True, partial: bool = None,
                 unknown: str = None) -> typing.List[A]:
            # ignore the mypy error of the decorator because mm does not define lists as an allowed input type
            pass

    class Test1:
        def load(self, data: TEncoded,
                 many: None = None, partial: bool = None,
                 unknown: str = None) -> A:
            pass

    class Test2:
        def load(self, data: TOneOrMultiEncoded,
                 many: bool = None, partial: bool = None,
                 unknown: str = None) -> TOneOrMulti:
            pass

    test0 = Test0()
    test1 = Test1()
    test2 = Test

# Generated at 2022-06-25 16:07:27.056367
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    from marshmallow import fields
    from marshmallow import validate
    field = fields.Field(required=True)
    field.error_messages = {}
    field.error_messages['required'] = "test"
    assert isinstance(_TimestampField(field), _TimestampField)
    assert isinstance(_TimestampField(validate=validate.Range(min=0)), _TimestampField)


# Generated at 2022-06-25 16:07:33.034158
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # TODO: Test case fails after changes to support typing.Optional List
    #       Check if it should fail or be fixed
    class TestSchema(SchemaF[typing.List[int]]):
        class Meta:
            unknown = 'raise'

    with warnings.catch_warnings(record=True) as warning_list:
        warnings.simplefilter("always")
        errors = TestSchema().load([1, 2, 3])
        assert len(errors) == 3
        assert issubclass(warning_list[-1].category, RuntimeWarning)
        assert str(errors[0]) == "UnmarshalWarning: Field 'id' missing from data"


# Generated at 2022-06-25 16:07:39.070302
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class C:
        def __init__(self, a: int, b: int):
            self.a = a
            self.b = b

    schema_f_0 = SchemaF()
    schema_f_0.load([1, 2]) # This will have an error in mypy because the SchemaF is not implemented
    schema_f_1 = SchemaF()
    schema_f_1.load(dict(a=1, b=2)) # This will have an error in mypy because the SchemaF is not implemented


# Generated at 2022-06-25 16:07:44.604556
# Unit test for function build_type
def test_build_type():
    import unittest
    import re

    class TestbuildType(unittest.TestCase):
        def test_mm_field(self):
            self.assertEqual(build_type(type, options, mixin, field, cls),
                             fields.Field(**options))

    # execute test
    unittest.main()



# Generated at 2022-06-25 16:07:54.114213
# Unit test for function build_type
def test_build_type():
    type_ = typing.Optional[int]
    options = {}
    mixin = type('MixinBase', (object,), {})
    field = typing.NamedTuple('field', [('name', str), ('type', type)])
    cls = typing.NamedTuple('cls', [('__name__', str)])
    build_type(type_, options, mixin, field, cls)


# Generated at 2022-06-25 16:09:20.142846
# Unit test for function build_type
def test_build_type():
    class MyEnum(Enum):
        a = 'a'
        b = 'b'

    class A:
        c = 'c'

    class TestDataclass:
        a = 'a'

    class TestDataclassB:
        a = 'a'

    class TestDataclassC:
        a = 'a'

    class TestGeneric(typing.Generic[A]):
        my_list: typing.List[A]

    origin_type = typing.Optional[typing.List[TestGeneric[TestDataclassC]]]
    options = {}
    mixin = Serializer
    cls = A
    field = dc_fields(A)[0]

    # Test case 0: normal case
    # First, test the inner function of build_type

# Generated at 2022-06-25 16:09:22.640150
# Unit test for function build_schema
def test_build_schema():
    class A:
        pass

    class SchemaA(Schema):
        class Meta:
            fields = (
                "aa",
            )
        
        aa = fields.Str()

    build_schema(A, SchemaA(), False, False)


# Generated at 2022-06-25 16:09:23.894463
# Unit test for function build_schema
def test_build_schema():
    assert issubclass(build_schema(MyClass, 1, 2, 3), SchemaType)


# Generated at 2022-06-25 16:09:30.047257
# Unit test for function schema
def test_schema():
    metadata = dict.fromkeys(['dataclasses_json'])
    field = dict.fromkeys(['metadata', 'name', 'default', 'default_factory', 'type'])

    field['metadata'] = metadata
    field['name'] = 'str_0'
    field['type'] = str
    field['default'] = 'default_0'
    str_0 = schema(field, 'mixin', True)

    field['name'] = 'str_1'
    field['metadata']['dataclasses_json']['mm_field'] = 'char'
    str_1 = schema(field, 'mixin', True)

    field['name'] = 'str_2'
    field['metadata']['dataclasses_json']['mm_field'] = 'email'

# Generated at 2022-06-25 16:09:32.825459
# Unit test for function build_type
def test_build_type():
    Int = typing.NewType('Int', int)
    IntField = build_type(Int, {}, lambda x: False, lambda:0, lambda:0)
    assert IntField.__class__.__name__ == "Int"


# Generated at 2022-06-25 16:09:43.745027
# Unit test for function build_schema
def test_build_schema():

    class Student:
        def __init__(self, name, age):
            self.name = name
            self.age = age

    @dataclass_json
    @dataclass
    class Author:
        name: str

    @dataclass_json
    @dataclass
    class Book:
        title: str
        author: Author
        pages: int

    schema = build_schema(Book, dataclass_json.DataClassJsonMixin, True, True)
    assert schema.__name__ == 'BookSchema'

    test_obj = Book(title='test', author=Author(name='zzz'), pages=123)
    test_obj_se = schema().dump(test_obj)
    assert test_obj_se['author'] == {'name': 'zzz'}
    test_obj_

# Generated at 2022-06-25 16:09:45.365552
# Unit test for function schema
def test_schema():
    schema_0 = schema(1, 1, 1)


# Generated at 2022-06-25 16:09:50.657247
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class MySchema(SchemaF):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
            super().__init__(*args, **kwargs)

        def dump(self, obj: TOneOrMulti,
                 many: bool = None) -> TOneOrMultiEncoded:
            return super().dump(obj, many)

    schema_f_0 = MySchema()


# Generated at 2022-06-25 16:09:54.852188
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    expected_result = [{'a': 1}, {'a': 2}]
    class SchemaF_dump(SchemaF[int]):
        a = fields.Int()

    class SchemaF_dumps(SchemaF[int]):
        a = fields.Int()

    assert isinstance(SchemaF_dump().dump([1,2], many=True), list)
    assert isinstance(SchemaF_dumps().dump([1,2], many=True), list)


# Generated at 2022-06-25 16:09:59.987133
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    # passing in the class, not the instance
    _TimestampField(required=True, allow_none=False, load_from=None, dump_to=None,
                    error_messages=None, attribute=None, data_key=None, missing=MISSING,
                    validate=None, allow_default=False, load_only=False, dump_only=False,
                    missing=MISSING)
