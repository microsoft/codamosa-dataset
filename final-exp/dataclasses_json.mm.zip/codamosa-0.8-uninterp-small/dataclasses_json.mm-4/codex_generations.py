

# Generated at 2022-06-25 16:02:45.688492
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class SchemaF_test(SchemaF):
        """Defines the class name and inherited class SchemaF which is required for SchemaF testing"""

    schema_f = SchemaF_test()
    with pytest.raises(NotImplementedError):
        schema_f.loads('{"asd": 100}')


# Generated at 2022-06-25 16:02:50.645930
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    @dataclasses.dataclass()
    class my_mapping_class:
        field_0: typing.Collection[int]

    schema_f_0 = SchemaF()
    obj_f_0 = schema_f_0.load([{'field_0': [11, 12]}])
    obj_f_1 = schema_f_0.load({'field_0': [11, 12]})


# Generated at 2022-06-25 16:02:55.673510
# Unit test for function build_type
def test_build_type():
    type_1 = typing.List[int]
    options = {'allow_none':True,
               'required':True}
    mixin = dataclasses.dataclass
    field = dc_fields(typing.List[int])[0]

##    build_type(type_1,options,mixin,field)
    schema_f_0 = SchemaF()

test_build_type()

# Generated at 2022-06-25 16:03:02.714309
# Unit test for function schema
def test_schema():
    from typing import Optional
    from dataclasses import dataclass
    from marshmallow import fields
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class TestClass:
        a: int
        b: Optional[str]

    assert schema(TestClass, TestClass, False) == {'a': fields.Int(), 'b': fields.Str(allow_none=True, default=None)}

test_schema()


# Generated at 2022-06-25 16:03:14.804672
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema_f_0 = SchemaF()
    assert not isinstance(schema_f_0, Schema)
    a = []
    ret = schema_f_0.dump(a)
    assert isinstance(ret, list)
    a = 5
    ret = schema_f_0.dump(a)
    assert isinstance(ret, dict)
    a = 5
    ret = schema_f_0.dump(a, 0)
    assert isinstance(ret, dict)
    a = 5
    ret = schema_f_0.dump(a, 1)
    assert isinstance(ret, dict)
    a = 5
    ret = schema_f_0.dump(a, "")
    assert isinstance(ret, dict)
    a = [1]

# Generated at 2022-06-25 16:03:15.824378
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()



# Generated at 2022-06-25 16:03:23.558995
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    schema_f_1 = SchemaF()
    schema_f_2 = SchemaF()
    schema_f_3 = SchemaF()
    schema_f_4 = SchemaF()
    schema_f_5 = SchemaF()
    schema_f_6 = SchemaF()
    schema_f_7 = SchemaF()
    schema_f_8 = SchemaF()
    schema_f_9 = SchemaF()
    schema_f_10 = SchemaF()
    schema_f_11 = SchemaF()
    schema_f_12 = SchemaF()
    schema_f_13 = SchemaF()
    schema_f_14 = SchemaF()
    schema_f_15 = SchemaF()
    schema_f_16 = SchemaF()

# Generated at 2022-06-25 16:03:28.980135
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    try:
        test_data = {}
        SchemaF().loads(test_data)
    except NotImplementedError:
        pass


# Generated at 2022-06-25 16:03:31.120149
# Unit test for function build_type
def test_build_type():
    tc0_schema = build_type(test_case_0, {}, None, None, None)
    assert(tc0_schema is None)


# Generated at 2022-06-25 16:03:34.337266
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    assert len(schema_f_0.loads("""{"a":5}""", many=False)) == 2
    assert len(schema_f_0.loads("""[{"a":5}]""", many=True)) == 2


# Generated at 2022-06-25 16:03:53.158667
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class DummyClass:
        pass

    schema_f = SchemaF()
    schema_f.load(DummyClass())
    schema_f.load([])
    schema_f.load([DummyClass()])
    schema_f.load(1)



# Generated at 2022-06-25 16:03:56.064854
# Unit test for constructor of class _IsoField
def test__IsoField():
    test_cases = [test_case_0]
    for case in test_cases:
        case()


# Generated at 2022-06-25 16:04:00.341542
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    schema_f_0 = SchemaF()
    dataclass_0 = schema_f_0.load()
    dataclass_1 = schema_f_0.load(manual_many=True)
    dataclass_2 = schema_f_0.load(manual_many=False)
    dataclass_3 = schema_f_0.load(partial=True)
    dataclass_4 = schema_f_0.load(partial=False)



# Generated at 2022-06-25 16:04:10.245029
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Object0:
        def __init__(self, name_0: str):
            self.name_0 = name_0

    class Object1:
        def __init__(self, name_1: str):
            self.name_1 = name_1

    class Schema0_0(SchemaF[Object0]):
        name_0 = fields.Str()

    class Schema0_1(SchemaF[Object1]):
        name_1 = fields.Str()

    class SchemaA(SchemaF[typing.Tuple[Object0, Object1]]):
        object0 = fields.Nested(Schema0_0)
        object1 = fields.Nested(Schema0_1)

    sf = SchemaA()

# Generated at 2022-06-25 16:04:12.004201
# Unit test for function build_schema
def test_build_schema():
    class Test0(Schema): pass
    assert str(build_schema(Test0, JsonMixin, False, False)) == '<class \'tests.schemas_test.Test0\'>'

# Generated at 2022-06-25 16:04:16.006273
# Unit test for function schema
def test_schema():
    class C(typing.Generic[A]):
        ...

    class Person:
        f: str

    assert schema(Person, C, False) == {'f': fields.Str()}


# Generated at 2022-06-25 16:04:19.780327
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    schema_f_0 = SchemaF()
    schema_f_0.load({'hello': 'world'})
    schema_f_0.load([{'hello': 'world'}])


# Generated at 2022-06-25 16:04:29.835310
# Unit test for function schema
def test_schema():
    from dataclasses_json.mm_field import mm_field
    from dataclasses import dataclass
    import pytest
    @dataclass
    class Test_Schema_0:
        a: int
    schema_0 = schema(Test_Schema_0, mixin, infer_missing=False)
    assert schema_0['a'].serialize("1") == 1
    assert schema_0['a'].validate("1") == "1"

    @dataclass
    class Test_Schema_1:
        a: int
        b: typing.List[int]

    schema_1 = schema(Test_Schema_0, mixin, infer_missing=False)
    # type(schema_1['b'])
    schema_1['b'].serialize("a")
    pytest.ra

# Generated at 2022-06-25 16:04:35.404619
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    schema_f_0 = SchemaF()
    class LoadTestSchema(Schema):
        string = fields.String()

    class LoadTestSchemaF(SchemaF):
        string = fields.String()

    schema = LoadTestSchema()
    schema_f = LoadTestSchemaF()
    schema.load({'string': 'text'})
    schema_f.load({'string': 'text'})
    schema.loads('{"string": "text"}')
    schema_f.loads('{"string": "text"}')
    # Checking if some of the different versions of schema.load and schema.loads work
    schema_f.load({'string': 'text'}, many=False)
    schema_f.load({'string': 'text'}, many=False, partial=False)

# Generated at 2022-06-25 16:04:37.948395
# Unit test for function build_type
def test_build_type():
    test_type = typing.List[int]
    options = {}
    mixin = SchemaType
    field = int
    cls = type(None)
    build_type(test_type, options, mixin, field, cls)

# Generated at 2022-06-25 16:04:53.479292
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_field = _IsoField()
    assert isinstance(iso_field, fields.Field)



# Generated at 2022-06-25 16:05:04.433793
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class TestSchemaF(SchemaF):
        @post_load
        def make_object(self, data: TEncoded) -> typing.Dict[str, str]:
            return data

    obj_f_0 = [{'key': 'value'}, {'key': 'value'}]
    obj_f_0_0 = [{'key': 'value'}]
    obj_f_0_1 = [{'key1': 'value1'}]
    obj_f_1 = {'key': 'value'}
    obj_f_1_0 = {'key': 'value'}
    obj_f_1_1 = {'key1': 'value1'}
    schema_f_1 = TestSchemaF()

# Generated at 2022-06-25 16:05:11.696340
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclasses.dataclass
    class Data0:
        x: int = 2

    schema_f_0 = SchemaF()
    assert schema_f_0.dump(
        [Data0(1), Data0(2)],
        many=True) == [{'x': 1}, {'x': 2}]
    assert schema_f_0.dump(
        Data0(1),
        many=False) == {'x': 1}
    assert schema_f_0.dump(
        [Data0(1), Data0(2)]) == [{'x': 1}, {'x': 2}]
    assert schema_f_0.dump(
        Data0(1)) == {'x': 1}


# Generated at 2022-06-25 16:05:13.505048
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    _TimestampField()



# Generated at 2022-06-25 16:05:14.926022
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    x = SchemaF.dump({"x": "y"})


# Generated at 2022-06-25 16:05:23.823969
# Unit test for function build_type
def test_build_type():
    class Foo(object):
        pass
    class Foo2(object):
        pass
    
    class MySchema(SchemaF):
        pass

    schema_f_0 = SchemaF()

    type_a = typing.Union[Foo, typing.Dict[str, int]]
    type_a_0 = typing.List[typing.Dict[str, int]]
    type_a_1 = typing.Union[Foo, Foo2]

    options = {}
    mixin = "Hello"
    field = typing.Dict[str, int]
    cls = typing.List[int]

    x_a = build_type(type_a, options, mixin, field, cls)
    x_a_0 = build_type(type_a_0, options, mixin, field, cls)

# Generated at 2022-06-25 16:05:34.256440
# Unit test for function build_schema
def test_build_schema():
    class TestMixin(object):
        pass

    class TestClass(object):
        def __init__(self, data: int = None, data2: int = None):
            self.data = data
            self.data2 = data2

    @dataclass_json
    @dataclass
    class TestClass(object):
        data: int = None
        data2: int = None

    @dataclass_json
    @dataclass
    class TestClass2(object):
        data: int = None
        data2: int = None

    class TestClass(object):
        def __init__(self, data: str = None, data2: TestClass2 = None):
            self.data = data
            self.data2 = data2


# Generated at 2022-06-25 16:05:39.695523
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert isinstance(field, fields.Field)


# Generated at 2022-06-25 16:05:41.627428
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class MySchema(SchemaF[str]):
        pass

    MySchema().dump("a")
    MySchema().dump(["a"])


# Generated at 2022-06-25 16:05:42.729169
# Unit test for function build_type
def test_build_type():
     _ = build_type(int, {}, int, 0, 0)

# Generated at 2022-06-25 16:06:02.121513
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class A:
        pass

    class B:
        pass

    x = A()
    y = [A(), A(), B()]
    schema_f_0 = SchemaF()
    output = schema_f_0.dump(x)
    output = schema_f_0.dump(y)
    output = schema_f_0.dump(y, many=False)


# Generated at 2022-06-25 16:06:13.653095
# Unit test for function build_schema
def test_build_schema():
    # test_0: Test union types
    class TestUnionSchema(UnionSchema):
        """
        Define union schema
        """

    test_schema = build_schema(TestUnionSchema, None, True, None)

    assert test_schema.__name__ == 'TestUnionSchemaSchema'
    assert hasattr(test_schema, 'Meta')

    # test_1: test for partial
    class TestPartialSchema(PartialSchema):
        """
        Define a partial schema
        """

    test_schema = build_schema(TestPartialSchema, None, False, True)

    assert test_schema.__name__ == 'TestPartialSchemaSchema'
    assert hasattr(test_schema, 'Meta')



# Generated at 2022-06-25 16:06:22.065002
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class A:
        pass
    class B(A):
        pass
    class C(A):
        pass
    class D(B, C):
        pass

    class SchemaA(SchemaF[A]):
        a = fields.Int()

    class SchemaB(SchemaF[B]):
        b = fields.Int()
        c = fields.Int()

    class SchemaC(SchemaF[C]):
        d = fields.Int()
        e = fields.Int()

    class SchemaD(SchemaF[D]):
        f = fields.Int()
        g = fields.Int()

    b_schema = SchemaB()
    c_schema = SchemaC()
    d_schema = SchemaD()

    # Check that schema.load works with input types expected by Marsh

# Generated at 2022-06-25 16:06:29.469881
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    t_0 = typing.List[TEncoded]
    instance_of_t_0 = [] # type: ignore
    assert isinstance(instance_of_t_0, t_0)
    assert isinstance(SchemaF.load, typing.Callable)
    assert isinstance(SchemaF().load, typing.Callable)
    assert SchemaF.load.__annotations__ == {'data': t_0, 'return': t_0}

    t_1 = typing.List[A]
    instance_of_t_1 = [] # type: ignore
    assert isinstance(instance_of_t_1, t_1)
    assert SchemaF.load.__annotations__ == {'data': t_1, 'return': t_1}

    t_2 = A

# Generated at 2022-06-25 16:06:31.309984
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert isinstance(_IsoField(), fields.Field)


# Generated at 2022-06-25 16:06:42.832994
# Unit test for function build_type
def test_build_type():
    from typing import List, Optional
    from marshmallow import fields
    from dataclasses import dataclass, fields as dc_fields
    from decimal import Decimal


    @dataclass
    class DecimalClass:
        test_decimal: Decimal

    @dataclass
    class MyClass:
        test_int: int
        test_float: float
        test_bool: bool
        test_str: str
        test_list: List[str]
        test_list_of_list: List[List[str]]
        test_list_of_list_null: List[Optional[List[str]]]

    @dataclass
    class MyClassExtended(MyClass):
        pass

    @dataclass
    class NestedClass:
        test_int: int
        test_float: float
        test_bool

# Generated at 2022-06-25 16:06:53.805410
# Unit test for function schema
def test_schema():
    @dataclass_json
    @dataclass
    class A:
        x: List[int]
        y: int = field(metadata=dict(mm_field=fields.Int()))
        z: typing.Optional[int]
        d: datetime
        f: None
        f2: typing.Optional[None]

    s = schema(A, dataclasses_json.DataClassJsonMixin, False)

# Generated at 2022-06-25 16:07:01.676071
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    # -- Arrange --
    # -- Act --
    # -- Assert --
    try:
        test_case_0()
    except NotImplementedError as e:
        assert str(e) == '__init__() is not implemented'
    else:
        assert False, 'NotImplementException expected.'



# Generated at 2022-06-25 16:07:12.299039
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from typing import List
    from marshmallow import Schema, fields, post_load
    import dataclasses_json
    from dataclasses_json.mm_schema import (
        build_schema,
        SchemaType,
    )

    @dataclass
    class Foo:
        name: str
        age: int

    @dataclass
    class Bar:
        name: str
        age: int

    @dataclass
    class Baz:
        foo: Foo
        bar: Bar
        name: str
        age: int

    bar_schema = build_schema(Bar, dataclasses_json, infer_missing=False, partial=False)
    assert issubclass(bar_schema, SchemaType)

# Generated at 2022-06-25 16:07:20.384868
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclasses.dataclass
    class DataClass:
        a: int = 1
        b: str = 'hello'

        @classmethod
        def __post_init__(cls):
            pass

    data_obj = DataClass()
    data_list = [DataClass(), DataClass()]
    data_list_jsons = ['{"a": 1, "b": "hello"}', '{"a": 1, "b": "hello"}']

    data_obj_json = '{"a": 1, "b": "hello"}'
    for x in data_list:
        data_obj_json += "," + '{"a": 1, "b": "hello"}'
    data_obj_json = "[" + data_obj_json + "]"


# Generated at 2022-06-25 16:07:58.345375
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    # Check for default variable
    assert _TimestampField().required is fields.Field.required
    assert _TimestampField().data_key is fields.Field.data_key
    assert _TimestampField().allow_none is fields.Field.allow_none
    assert _TimestampField().attribute is fields.Field.attribute
    assert _TimestampField().load_only is fields.Field.load_only
    assert _TimestampField().dump_only is fields.Field.dump_only
    assert _TimestampField().missing is fields.Field.missing
    assert _TimestampField().default is fields.Field.default
    assert _TimestampField().default_setter is fields.Field.default_setter
    assert _TimestampField().validate is fields.Field.validate
    assert _TimestampField().required is fields.Field.required
    assert _

# Generated at 2022-06-25 16:08:01.617534
# Unit test for function build_type
def test_build_type():
    r = build_type( typing.List[str], {'required': True, 'allow_none': True}, Schema, dc_fields(str)[0], str)
    assert(type(r) == fields.List)


# Generated at 2022-06-25 16:08:08.291133
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass, field
    class TestDataClass(object):
        def __init__(self, a: str, b: str):
            self.a = a
            self.b = b
        pass

    t = TestDataClass("1", "2")
    TestSchema: typing.Type[SchemaType] = build_schema(TestDataClass, object, False, False)
    print(TestSchema.dump(t))
    print(TestSchema.loads(TestSchema.dumps(t)))


# Generated at 2022-06-25 16:08:09.556385
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    from datetime import datetime
    a = _TimestampField()
    assert a is not None



# Generated at 2022-06-25 16:08:16.063349
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Foo():
        pass

    class FooSchema(Schema):
        pass

    f = Foo()
    fs = FooSchema()

    test_cases = [
        (fs.dump(f, many=False), False),
        (fs.dump(f, many=True), True),
        (fs.dump([f], many=False), False),
        (fs.dump([f], many=True), True),
        (fs.dump([], many=False), False),
        (fs.dump([], many=True), True),
        (fs.dump(None, many=False), False),
        (fs.dump(None, many=True), True),
    ]


# Generated at 2022-06-25 16:08:25.740768
# Unit test for function build_type
def test_build_type():
    @dataclass_json
    class Example0: 
        pass

    @dataclass_json
    @dataclass
    class Example1: 
        x: Example0

    @dataclass
    class Example2: 
        y: Example1

    result = build_type(type(Example2.y.x), {}, Example0, fields('y')[0], Example2)
    assert result.__class__.__name__ == 'Nested'
    assert result.schema().__class__ is Example0
    assert result.allow_none == False

    result = build_type(type(Example2.y.x), {'allow_none': True}, Example0, fields('y')[0], Example2)
    assert result.__class__.__name__ == 'Nested'

# Generated at 2022-06-25 16:08:31.385424
# Unit test for function build_schema
def test_build_schema():
    # Test the dataclass without annotations
    @dataclass_json
    @dataclass
    class TestDc:
        a: int
        b: str
        c: TestDc

    schema1 = build_schema(TestDc, Mixin, True, False)

    assert set(schema1.__dict__.keys()) == set(['a', 'b', 'c', 'Meta',
                                                f'make_{TestDc.__name__.lower()}'])

    assert set(schema1.__dict__['Meta'].__dict__.keys()) == set(['fields'])
    assert schema1.__dict__['Meta'].__dict__['fields'] == ('a', 'b', 'c')

    # Test the dataclass with annotations

# Generated at 2022-06-25 16:08:33.619990
# Unit test for function build_schema
def test_build_schema():
    # Test: build a schema for class Student
    class Student(Mixin):
        a: int
        b: int

    student_schema: SchemaType = build_schema(Student, Mixin, False, True)
    student_schema.dump(Student(a=1, b=2))


# Generated at 2022-06-25 16:08:35.361696
# Unit test for function build_type
def test_build_type():
    # @dataclass
    # class A:
    #     x: str
    #     y: int
    #     z: List[int]

    # assert type(build_type(A, {}, {}, {}, {}, {})) is fields.Nested
    pass



# Generated at 2022-06-25 16:08:37.285312
# Unit test for function schema
def test_schema():
    a = schema(cls, mixin, infer_missing)


# Generated at 2022-06-25 16:10:04.299311
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclasses.dataclass
    class Dummy0:
        a: int

    schema_f_dump_0 = SchemaF()
    schema_f_dump_0.dump(Dummy0(a=5), many=False)


# Generated at 2022-06-25 16:10:06.931882
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    _TimestampField(missing=MISSING)



# Generated at 2022-06-25 16:10:10.611221
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    schema_f_0 = SchemaF()

    result = schema_f_0.load(data = {}, many = False)


# Generated at 2022-06-25 16:10:13.291687
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    assert SchemaF().dump([]) == []


# Generated at 2022-06-25 16:10:14.944823
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema_f = SchemaF()
    schema_f.dump(['a', 'b', 'c'])
    schema_f.dump({'key': 'value'})


# Generated at 2022-06-25 16:10:18.923750
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema_f_0 = SchemaF()
    schema_f_0.dump([], False)
    schema_f_0.dump(42, True)
    schema_f_0.dump(42, False)


# Generated at 2022-06-25 16:10:21.770771
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f_0 = SchemaF()
    schema_f_0.loads("")
    schema_f_0.loads("", many=None)
    schema_f_0.loads("", many=True)


# Generated at 2022-06-25 16:10:23.843942
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f_1 = SchemaF()
    schema_f_1.loads('["hello, world!"]')

# Generated at 2022-06-25 16:10:26.171521
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    schema_f = SchemaF()
    schema_f.load({})
    schema_f.load([])



# Generated at 2022-06-25 16:10:31.211841
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field.__class__.__name__ == '_IsoField'
    assert field.__doc__ == fields.Field.__doc__
    assert field._creation_counter == 0
    assert field.allow_none
