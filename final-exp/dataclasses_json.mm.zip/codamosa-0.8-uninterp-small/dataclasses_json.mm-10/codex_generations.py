

# Generated at 2022-06-25 16:02:44.737523
# Unit test for function build_type
def test_build_type():
    """
    Test the build_type function
    """
    import json
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import Schema, fields

    @dataclass_json
    @dataclass
    class A(object):
        a : int = 1
        b : str = "test"
    
    @dataclass_json
    @dataclass
    class B(object):
        a : A = A()
        b : str = "test"

    @dataclass_json
    @dataclass
    class UserSchema(SchemaType):
        a : B = B()
        b : str = "test"

        class Meta(object):
            unknown = EXCLUDE

    print ("build_type - testcase 0:")



# Generated at 2022-06-25 16:02:45.988197
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    sf = SchemaF()
    sf.load()



# Generated at 2022-06-25 16:02:56.306719
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # Test for simple list of dataclasses
    class Test0(SchemaF):
        class Meta:
            ordered = True

        class TestSchema(Schema):
            class Meta:
                ordered = True

            class Test0:
                data = fields.Str()

            test0 = fields.Nested(Test0)

        test_schema = fields.Nested(TestSchema)

    schema = Test0([
        {
            'test0': {
                'data': 'asdf'
            }
        }, {
            'test0': {
                'data': 'asdf'
            }
        }
    ])

    schema.dumps()

    # Test for simple list of dataclasses
    class Test(SchemaF):
        class Meta:
            ordered = True

        user_id = fields.Integer()



# Generated at 2022-06-25 16:03:00.545158
# Unit test for function build_schema
def test_build_schema():
    import datetime

    @dataclass_json
    @dataclass
    class Temp:
        a: int

    @dataclass_json
    @dataclass
    class Temp2:
        a: int
        b: int

    @dataclass_json
    @dataclass
    class Temp3:
        a: int
        b: int
        c: Temp
        d: typing.List[Temp2]

    # test_case_1
    schema_f = build_schema(Temp, None, False, False)
    assert Temp.schema() == schema_f

    schema_f = build_schema(Temp2, None, False, False)
    assert Temp2.schema() == schema_f

    schema_f = build_schema(Temp3, None, False, False)

# Generated at 2022-06-25 16:03:05.598592
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema_f_1 = SchemaF()
    schema_f_1.dumps([])
    schema_f_1.dumps({})
    schema_f_1.dumps([], many=True)
    schema_f_1.dumps({}, many=True)


# Generated at 2022-06-25 16:03:17.816725
# Unit test for function schema
def test_schema():
    # Case 0: pass dataclass
    @dataclass
    class TestCase0:
        name: str
        desc: str

    # Case 1: pass dataclass without field
    @dataclass
    class TestCase1:
        pass

    # Case 2: pass dataclass with field_many
    # This is not a proper test case, but we need it to detect the instances of SchemaF
    # Otherwise, this will be detected as an invalid test case.
    @dataclass_json(field_many=False)
    class TestCase2:
        name: str
        desc: str

    # Case 3: pass dataclass with enum
    @dataclass
    class TestCase3:
        name: str
        desc: str
        gender: Enum

    # Case 4: pass dataclass with optional
   

# Generated at 2022-06-25 16:03:19.838795
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    tsf = _TimestampField()
    return tsf


# Generated at 2022-06-25 16:03:26.698432
# Unit test for function schema
def test_schema():
    from typing import List, Optional, Dict

    from dataclasses import dataclass

    from dataclasses_json import dataclass_json

    @dataclass_json(mm_field=fields.Int)
    @dataclass
    class Address:
        city: str = "Moscow"
        street: str = "Lenina"
        house: int = 24

    def test_case_1():
        return schema(Address, dataclass_json, False)
    def test_case_2():
        return schema(Address, dataclass_json, True)
    # test case 1: mm_field exist, infer_missing = false, do not infer missing value
    test_schema_1 = test_case_1()

# Generated at 2022-06-25 16:03:27.619063
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()


# Generated at 2022-06-25 16:03:29.366011
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    if not sys.platform == "win32":
        instance_of_object = _TimestampField()


# Generated at 2022-06-25 16:03:50.784031
# Unit test for function schema
def test_schema():
    from dataclasses_json.api import dataclass_json, config
    from marshmallow import fields

    from dataclasses import dataclass

    @config(unknown=EXCLUDE, mm_fallback=False)
    class A:
        a: int
        b: str

    @config(unknown=EXCLUDE, mm_fallback=False)
    @dataclass
    class Base:
        c: float

        if sys.version_info < (3, 7):
            @classmethod
            def schema(cls):
                schema = schema(cls, dataclass_json.DataClassJsonMixin, True)
                return type(cls.__name__, (Schema,), schema)



# Generated at 2022-06-25 16:03:58.151570
# Unit test for function schema
def test_schema():

    @dataclass_json
    @dataclass
    class Cat:
        name: str
        age: int
        toys: List[str] = field(default_factory=list)

    @dataclass_json
    @dataclass
    class House:
        owner_id: int = field(metadata={"dataclasses_json": {"mm_field": fields.Str}})
        cats: List[Cat] = field(default_factory=list)

    s = schema(House, mixin, infer_missing=False)
    assert s == {
        'owner_id': fields.Str,
        'cats': fields.List(fields.Nested(Cat.schema()))
    }



# Generated at 2022-06-25 16:04:03.820925
# Unit test for function schema
def test_schema():
    @dataclasses.dataclass
    class Class_0(object):
        field_0: str = "field_0"

    class_0 = Class_0()
    schema_0 = schema(class_0, f"{__file__}::{Class_0.__name__}", True)



# Generated at 2022-06-25 16:04:10.943205
# Unit test for constructor of class _IsoField
def test__IsoField():
    test_1 = _IsoField()
    test_2 = _IsoField(validate=lambda v: v.is_finite())
    test_3 = _IsoField(dump_only=True)
    test_4 = _IsoField(load_only=True)
    test_5 = _IsoField(attribute="my_attr")
    test_6 = _IsoField(default=datetime.today())
    test_7 = _IsoField(missing=datetime.today())
    test_8 = _IsoField(allow_none=True)
    test_9 = _IsoField(error="Error")

# Generated at 2022-06-25 16:04:14.725595
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f = SchemaF()
    schema_f.loads(b'', many=True)
    schema_f.loads('', many=False)


# Generated at 2022-06-25 16:04:22.637434
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from typing import Any

    # Check for inheritance
    @dataclass
    class TestClass(Any):
        pass

    # Check for single type
    @dataclass
    class TestClass1(TestClass):
        a: float = 0.0

    schema_f_1 = build_schema(TestClass1, TestClass, False, False)
    assert type(schema_f_1.a) == fields.Float
    assert 'a' in dir(TestClass1Schema)

    # Check for list type
    @dataclass
    class TestClass2(TestClass):
        a: typing.List[float] = typing.List[float]()

    schema_f_2 = build_schema(TestClass2, TestClass, False, False)

# Generated at 2022-06-25 16:04:26.053289
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema = typing.cast(typing.Type[SchemaF[int]], SchemaF)
    schema(many=True).dumps([1, 2, 3])
    schema().dumps(4)


# Generated at 2022-06-25 16:04:32.755818
# Unit test for function schema
def test_schema():
    schema_f_0 = SchemaF()
    class TestCls(SchemaType):
        dataclass_0 = fields.Dict(keys=fields.Str(), values=fields.Int())
        toradataclass_1 = fields.Nested("test_testcase0.TestCls")
        list_0 = fields.List(fields.Int())
        list_1 = fields.List(fields.Str())
        list_2 = fields.List(fields.Float())
        list_3 = fields.List(fields.Bool())
        list_4 = fields.List(fields.Decimal())
        list_5 = fields.Nested("test_testcase0.TestCls")
        list_6 = fields.List(fields.Function())
        list_7 = fields.List(fields.UUID())
        list_8

# Generated at 2022-06-25 16:04:37.229948
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    # Test for type check
    schema_f_loads = SchemaF()
    schema_f_loads.loads({})


# Generated at 2022-06-25 16:04:40.146975
# Unit test for function build_schema
def test_build_schema():
    a = build_schema(1, 2, True, False)

# Unit tests for function schema

# Generated at 2022-06-25 16:05:11.775977
# Unit test for function schema
def test_schema():
    # type: () -> None
    class Inner(metaclass=mixin):

        def __init__(self, d):
            self.d = d

        def __eq__(self, other):
            if isinstance(other, Inner):
                return self.d == other.d
            return False

    class InnerSchema(Schema):

        d = fields.Int()

        @post_load
        def make_inner(self, data, **kwargs):
            return Inner(**data)

    @dataclass_json(mm_field=fields.Field)
    class A:
        a: Inner = None

    s = schema(A, mixin, False)
    assert isinstance(s['a'], fields.Field)



# Generated at 2022-06-25 16:05:20.268152
# Unit test for function build_type

# Generated at 2022-06-25 16:05:23.951777
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f_0 = SchemaF()
    assert(schema_f_0.loads('{"key": "value"}', many=False) == {"key": "value"})
    assert(schema_f_0.loads('[{"key": "value"}]', many=True) == [{"key": "value"}])


# Generated at 2022-06-25 16:05:29.912194
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    # Test case 0 when many is False
    test_case_0_many = False
    json_data_0_many = '[{"__type": "A", "a": 1}, {"__type": "A", "a": 2}]'
    json_data_0_many_bytes = bytes(json_data_0_many, encoding='utf-8')
    A_0_many = typing.List[A]
    schema_f_0_many = SchemaF()
    schema_f_0_many.loads(json_data_0_many, many=test_case_0_many)
    schema_f_0_many.loads(json_data_0_many_bytes, many=test_case_0_many)


# Test case 0 with many
test_case_0_many = True
json_data_0_

# Generated at 2022-06-25 16:05:35.714251
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class _Base(SchemaF):
        pass
    class _Inherited(_Base):
        pass
    class _InheritedAgain(_Inherited):
        pass
    class _InheritedAgainAgain(_InheritedAgain):
        pass

    schema_0 = _InheritedAgainAgain()
    dumps_0 = schema_0.dumps([])
    dumps_1 = schema_0.dumps(dict())
    dumps_2 = schema_0.dumps([], many=True)
    dumps_3 = schema_0.dumps(dict(), many=False)
    dumps_4 = schema_0.dumps(dict(), many=True)


# Generated at 2022-06-25 16:05:39.449408
# Unit test for constructor of class _IsoField
def test__IsoField():
    temp_1 = _IsoField()
    assert temp_1 is not None


# Generated at 2022-06-25 16:05:47.816596
# Unit test for function schema
def test_schema():
    class mixin:
        pass

    class Test0(mixin):
        def __init__(self, x=1):
            self.x = x
        def __str__(self):
            return str(self.x)
    Test0.schema = SchemaType[Test0]
    Test0.schema = SchemaType[Test0]
    print(Test0.schema().dump(Test0()))
    print(Test0.schema().load({'x': 1}))

    class Test1:
        def __init__(self, x=1):
            self.x = x
        def __str__(self):
            return str(self.x)
    Test1.schema = SchemaType[Test1]
    print(Test1.schema().dump(Test1()))

# Generated at 2022-06-25 16:05:49.453967
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    try:
        SchemaF().load({})
    except NotImplementedError:
        pass



# Generated at 2022-06-25 16:05:54.719179
# Unit test for function schema
def test_schema():
    # test to see if it works with a simple class
    class MyClass(object):
        def __init__(self):
            self.a = 5
            self.b = 'test'
            self.c = 5.1

    try:
        my_schema = schema(MyClass(), object, False)
        result = {'a': fields.Int(), 'b': fields.Str(), 'c': fields.Float()}
        assert my_schema == result
    except Exception as e:
        print('Failed when testing a simple class:', e)

    # test to see if it works with a union
    class MyClassUnion(object):
        def __init__(self):
            self.a = 5
            self.b = 'test'
            self.c = 5.1
            self.d = None


# Generated at 2022-06-25 16:05:59.744561
# Unit test for function build_type
def test_build_type():
    assert(fields.Mapping == build_type(typing.Mapping,{},None,None,None))
    assert(fields.Mapping == build_type(typing.MutableMapping,{},None,None,None))
    assert(fields.List == build_type(typing.List,{},None,None,None))
    assert(fields.Dict == build_type(typing.Dict,{},None,None,None))
    assert(fields.Tuple == build_type(typing.Tuple,{},None,None,None))
    assert(fields.Function == build_type(typing.Callable,{},None,None,None))
    assert(fields.Raw == build_type(typing.Any,{},None,None,None))

# Generated at 2022-06-25 16:06:56.649682
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class BasicThing:
        def __init__(self, name):
            self.name = name

    class BasicThingSchema(SchemaF[BasicThing]):
        name = fields.Str()

    schemaF = BasicThingSchema()
    thing_list = [BasicThing('foo'), BasicThing('bar')]

    serialized = schemaF.dump(thing_list, many=True)
    assert serialized == [{'name': 'foo'}, {'name': 'bar'}]

    serialized = schemaF.dump(thing_list)
    assert serialized == [{'name': 'foo'}, {'name': 'bar'}]

    serialized = schemaF.dump(thing_list, many=False)
    assert serialized == {'name': 'foo'}

    serialized = schema

# Generated at 2022-06-25 16:07:08.001909
# Unit test for function build_type

# Generated at 2022-06-25 16:07:09.138569
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f = SchemaF()
    schema_f.loads('')


# Generated at 2022-06-25 16:07:09.904366
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()


# Generated at 2022-06-25 16:07:10.970123
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()



# Generated at 2022-06-25 16:07:17.798132
# Unit test for function build_schema
def test_build_schema():
    from datetime import datetime
    # Define test dataclasses
    @dataclass
    class A0:
        foo: str
        bar: int

    @dataclass
    class A1:
        a0: A0

    @dataclass
    class A2:
        a0: A0
        a1: A1

    class test_schema():

        def __init__(self):
            self.test_case_0()
            self.test_case_1()

        def test_case_0(self):
            DataClassSchema0 = build_schema(A0,
                                            mixin=None,
                                            infer_missing=True,
                                            partial=False)
            ds0 = DataClassSchema0()

# Generated at 2022-06-25 16:07:25.490048
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    expected_types = {
        'decimal': Decimal,
        'str': str,
        'bool': bool,
        'int': int,
        'list': list,
        'datetime': datetime,
        'float': float,
    }

    for field_type, class_value in expected_types.items():
        class TestClass(typing.NamedTuple):
            attr: typing.Any

        schema = SchemaF[TestClass]({'attr': _ExtendedEncoder(field_type, types_mapping={
            typing.Decimal: fields.Decimal
        })})

        s_res = schema.loads(f'{{"attr" : true}}')

        assert isinstance(s_res, TestClass)
        assert isinstance(s_res.attr, class_value)

# Unit

# Generated at 2022-06-25 16:07:30.679497
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # Case 0
    schema_f0 = SchemaF()
    obj = [1, 2, 3]
    assert schema_f0.dumps(obj) == '[1, 2, 3]'

    # Case 1
    u0 = UUID('12345678123456781234567812345678')
    schema_f1 = SchemaF()
    obj = u0
    assert schema_f1.dumps(obj) == '"12345678-1234-5678-1234-567812345678"'


# Generated at 2022-06-25 16:07:34.317798
# Unit test for function schema
def test_schema():
    class A():
        name = ""
        age : int
    class Schema4A(Schema):
        name = fields.Str()
        age = fields.Int()
    assert len(schema(A, None, True)) == 2
    assert len(schema(A, None, False)) == 2
    assert len(schema(A(), None, True)) == 2
    assert len(schema(A(), None, False)) == 2

# Generated at 2022-06-25 16:07:35.743630
# Unit test for constructor of class _IsoField
def test__IsoField():
    schema_f_0 = SchemaF()
    assert schema_f_0.fields['name'] is not None


# Generated at 2022-06-25 16:09:53.575810
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema_f_ = SchemaF()
    obj = ['a', 'b']
    many = True

    # Call method with params obj and many
    schema_f_.dump(obj=obj, many=many)

    # Call method with params obj and many
    schema_f_.dumps(obj=obj, many=many)

    # Call method with params obj and many
    schema_f_.loads(json_data=obj, many=many)

    # Call method with params obj and many
    schema_f_.load(data=obj, many=many)

    obj = ['a', 'b']
    many = False

    # Call method with params obj and many
    schema_f_.dump(obj=obj, many=many)

    # Call method with params obj and many

# Generated at 2022-06-25 16:09:59.275480
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    test_schemaF = SchemaF()
    obj = test_schemaF.load({'name': 'test name', 'email': 'test@mail.com'})
    assert isinstance(obj,
                      typing.Dict[str, typing.Any]) == True and obj is not None


# Generated at 2022-06-25 16:10:00.531386
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    _TimestampField('attr')


# Generated at 2022-06-25 16:10:07.048551
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema_f_1 = SchemaF()
    # Call function dumps of class SchemaF
    result_schema_f_1 = schema_f_1.dumps()

    # Check the result_schema_f_1 type
    assert isinstance(result_schema_f_1, str)


# Generated at 2022-06-25 16:10:13.204375
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    json_data_0 = "{}"
    schema_f_0 = SchemaF()
    schema_f_0.load(json_data_0, many=True)
    json_data_1 = "{}"
    schema_f_1 = SchemaF()
    schema_f_1.load(json_data_1)


# Generated at 2022-06-25 16:10:15.859676
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema_f = SchemaF()
    schema_f.dumps(0)


# Generated at 2022-06-25 16:10:21.188606
# Unit test for function build_schema
def test_build_schema():
    schema_f_0 = build_schema(object, object, bool, bool)
    assert type(schema_f_0) == object

    schema_f_1 = build_schema(test_case_0, object, bool, bool)
    assert type(schema_f_1) == object

    schema_f_2 = build_schema(dict, object, bool, bool)
    assert type(schema_f_2) == object

    schema_f_3 = build_schema(str, object, bool, bool)
    assert type(schema_f_3) == object

    schema_f_4 = build_schema(int, object, bool, bool)
    assert type(schema_f_4) == object

    schema_f_5 = build_schema(float, object, bool, bool)

# Generated at 2022-06-25 16:10:22.233834
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()


# Generated at 2022-06-25 16:10:23.969967
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    _TimestampField(attribute=None, default=None, allow_none=False, error_messages=None)


# Generated at 2022-06-25 16:10:32.436201
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema_f_dumps_0 = SchemaF()
    schema_f_dumps_0.dumps(list)
    schema_f_dumps_1 = SchemaF()
    schema_f_dumps_1.dumps(list, many=False)
    schema_f_dumps_2 = SchemaF()
    schema_f_dumps_2.dumps(list, many=True)
    schema_f_dumps_3 = SchemaF()
    schema_f_dumps_3.dumps(list, many=None)

