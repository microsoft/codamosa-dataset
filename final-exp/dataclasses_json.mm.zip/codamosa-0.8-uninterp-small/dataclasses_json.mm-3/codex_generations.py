

# Generated at 2022-06-25 16:02:43.484511
# Unit test for function schema
def test_schema():
    print('Running test_schema...')
    import dataclasses
    import typing
    @dataclasses.dataclass
    class A():
        x: str
    
    @dataclasses.dataclass
    class B(A):
        y: str
    
    @dataclasses.dataclass
    class C():
        field1: typing.List
        field2: typing.Set
        field3: typing.MutableSet
        field4: typing.Set
        field5: typing.Mapping
        field6: str
        field7: typing.Optional[str]
        @dataclasses.dataclass
        class InnerClass():
            inner_field1: str
            inner_field2: typing.Optional[str]

        field8: typing.Union[str, int, float]
        field9: typing

# Generated at 2022-06-25 16:02:46.742785
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema_f_1 = SchemaF()
    schema_f_1.dump([])
    schema_f_1.dump([{}])
    schema_f_1.dump(None)
    schema_f_1.dump(())


# Generated at 2022-06-25 16:02:54.728853
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    # Test normal case
    schema_f_1 = SchemaF()
    schema_f_1.loads({"hello": "world"}, many=False)
    # Test normal case
    schema_f_2 = SchemaF()
    schema_f_2.loads([{"hello": "world"}, {"hello": "world"}], many=True)
    # Test normal case
    schema_f_3 = SchemaF()
    schema_f_3.loads([{"hello": "world"}, {"hello": "world"}], many=None)



# Generated at 2022-06-25 16:02:57.408945
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f_0 = SchemaF()
    load_0 = schema_f_0.loads()


# Generated at 2022-06-25 16:03:00.007968
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class S(SchemaF):
        pass

    assert S().dumps(S()) == '{}'


# Generated at 2022-06-25 16:03:01.322433
# Unit test for function build_schema
def test_build_schema():
    # TODO
    pass


# Generated at 2022-06-25 16:03:04.513936
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema_f_0 = SchemaF()
    str_0: str = schema_f_0.dumps('a string')
    str_1: str = schema_f_0.dumps([1, 2, 3])


# Generated at 2022-06-25 16:03:08.422619
# Unit test for constructor of class _IsoField
def test__IsoField():
    try:
        _IsoField()
    except:
        assert False, 'unable to initialize new instance of _IsoField'
    else:
        assert True


# Generated at 2022-06-25 16:03:18.920470
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # Test for var "data"
    a_0 = SchemaF.load(data=1)
    # Test for var "data"
    a_1 = SchemaF.load(data=1)
    # Test for var "data"
    a_2 = SchemaF.load(data=[1])
    # Test for var "many"
    a_3 = SchemaF.load(data=1, many=True)
    # Test for var "many"
    a_4 = SchemaF.load(data=1, many=None)
    # Test for var "many"
    a_5 = SchemaF.load(data=1, many=None)
    # Test for var "many"
    a_6 = SchemaF.load(data=[1], many=True)
    # Test for var "many"

# Generated at 2022-06-25 16:03:26.105559
# Unit test for function build_type
def test_build_type():
    desc = {typing.AnyStr: fields.String()}

    assert build_type(typing.AnyStr, types={}, mixin=object, field=dc_fields(typing.AnyStr), cls=typing.AnyStr) is fields.String()
    assert build_type(typing.AnyStr, types={}, mixin=object, field='str', cls=typing.AnyStr) is fields.String()
    assert build_type(typing.Any, types={}, mixin=object, field=dc_fields(typing.Any), cls=typing.Any) is fields.Raw()
    assert build_type(typing.Any, types={}, mixin=object, field='any', cls=typing.Any) is fields.Raw()

# Generated at 2022-06-25 16:03:40.748454
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from typing import List, Optional

    @dataclass
    class A:
        i: int
        j: Optional[str]

    @dataclass
    class B:
        a: List[A]

    ret = schema(B, None, False)
    assert ret == {'a': fields.List()}



# Generated at 2022-06-25 16:03:45.135623
# Unit test for function build_type
def test_build_type():
    class T(typing.Generic[A]):
        pass

    class TT(T[A]):
        pass

    class UU:
        pass

    @dataclass
    class U(UU):
        pass

    Response = Tuple[str, int, T[U]]
    response_type = typing.get_type_hints(test_build_type)[
        'Response']
    res = build_type(response_type, {}, SchemaType, dc_fields(test_build_type)[0], test_build_type)
    print(res)

    Response2 = Optional[T[Union[int, float]]]
    response_type2 = typing.get_type_hints(test_build_type)[
        'Response2']

# Generated at 2022-06-25 16:03:55.060171
# Unit test for function build_schema
def test_build_schema():
    import typing
    import marshmallow.fields

    from marshmallow import post_load, Schema
    from marshmallow.exceptions import ValidationError
    from typing import List


    class Person:
        """A simple data class"""

        name: str
        age: int

        def __init__(self, name, age):
            self.name = name
            self.age = age


    class User:
        """A simple data class"""

        def __init__(self, name, age):
            self.name = name
            self.age = age


    # Test case 1: no mixin
    schema_f = build_schema(Person, None, 1, 1)
    assert isinstance(schema_f.name, fields.Str)
    assert isinstance(schema_f.age, fields.Int)

    #

# Generated at 2022-06-25 16:03:58.046656
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclass
    class Dummy0:
        id: int
        name: str
    SchemaF[Dummy0].dump([Dummy0(1, "foo"), Dummy0(2, "bar")], many=True)


# Generated at 2022-06-25 16:03:59.559006
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert isinstance(_TimestampField(), _TimestampField)
    assert isinstance(SchemaF().fields["time"], _TimestampField)


# Generated at 2022-06-25 16:04:00.920697
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    schema_f = SchemaF()
    schema_f.load(['test'])

    # Unit test for method loads of class SchemaF

# Generated at 2022-06-25 16:04:05.833883
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Person_0(typing.Generic[A]):
        person: A
    class Schema_0(typing.Generic[A]):
        pass
    person_0 = Person_0()
    schema_f_1 = SchemaF(Schema_0(), unknown=str, many=True)
    schema_f_1.dump(person_0)


# Generated at 2022-06-25 16:04:07.337465
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    schema_f_0 = SchemaF()
    schema_f_0.load()


# Generated at 2022-06-25 16:04:12.544635
# Unit test for function build_schema
def test_build_schema():
    class TestSchema(metaclass=SchemaMeta):
        def __init__(self, a: int, b: str):
            self.a = a
            self.b = b


# Generated at 2022-06-25 16:04:22.514047
# Unit test for function build_schema
def test_build_schema():
    # Use helper function build_schema_test_helper
    class A(metaclass=dataclasses.dataclass):
        a: str

    build_schema_test_helper(A)
    # Test that the letter case is respected

# Generated at 2022-06-25 16:04:48.919557
# Unit test for function schema
def test_schema():
    class A:
        x = 1

    class B(A):
        y = 2

    schema_f_0 = SchemaF()
    print('The type of schema:', type(schema_f_0))
    print('The result of schema:', schema_f_0)


if __name__ == '__main__':
    test_schema()

# Generated at 2022-06-25 16:04:56.073326
# Unit test for function build_type
def test_build_type():
    f_mapping = build_type(typing.Mapping, {'field_many': False}, "mixin", "field", "cls")

    # Call method _dump from f_mapping because it is a class object
    # f_mapping is a class object, so we make an instance of it
    f_mapping_obj = f_mapping({})
    f_mapping_obj._dump([], 'if_two')



# Generated at 2022-06-25 16:05:05.477863
# Unit test for function build_schema
def test_build_schema():
    from datetime import datetime
    from enum import Enum

    class TestEnum(Enum):
        FOO = "foo"
        BAR = "bar"


    # Test for typing.Mapping
    class MappingCls:
        def __init__(self, foo: typing.Mapping,
                     ):
            self.foo = foo


    class Bar:
        def __init__(self, bar: typing.MutableMapping):
            self.bar = bar


    class Mixin0:
        @classmethod
        def schema(cls):
            return build_schema(cls,
                                type(None), False, False)


    MappingCls.schema = build_schema(MappingCls, type(None), False, False)

# Generated at 2022-06-25 16:05:14.769803
# Unit test for function build_schema
def test_build_schema():
    # Data class definition
    @dataclass
    class Person0:
        name: str
        weight: int
        is_vegetarian: bool = False

    # Test function build_schema
    Person1: typing.Type[SchemaType] = build_schema(Person0, mixin, infer_missing=True, partial=False)
    assert issubclass(Person1, Schema)
    assert hasattr(Person1, "Meta")
    print(Person1.__dict__)
    assert hasattr(Person1, "make_person0")
    assert hasattr(Person1, "dumps")
    assert hasattr(Person1, "dump")
    assert hasattr(Person1, "name")
    assert hasattr(Person1, "weight")
    assert hasattr(Person1, "is_vegetarian")



# Generated at 2022-06-25 16:05:24.083021
# Unit test for function build_type
def test_build_type():
    class C(Enum):
        X = 0
        Y = 1
    class D:
        pass

    class E:
        def __init__(self, value):
            self.value = value

    class F:
        pass

    class G:
        pass

    class H:
        pass


# Generated at 2022-06-25 16:05:29.177560
# Unit test for function schema
def test_schema():
    from typing import List
    assert schema(List[int], None, True) == {
        'default': [],
        'allow_none': False,
        'required': False,
        'type': 'list',
        'schema': {'type': 'integer', 'required': False, 'nullable': False, 'allow_none': False}
    }
    assert schema(list, None, True) == {
        'default': [],
        'allow_none': False,
        'required': False,
        'type': 'list',
    }
    assert schema(str, None, True) == {
        'default': '',
        'allow_none': False,
        'required': False,
        'type': 'string',
    }

# Generated at 2022-06-25 16:05:30.596210
# Unit test for constructor of class _IsoField
def test__IsoField():
    schema_f_1 = _IsoField()


# Generated at 2022-06-25 16:05:36.817363
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema_f_1 = SchemaF()
    res1_1 = schema_f_1.dump(['a'])
    res1_2 = schema_f_1.dump(['a'], many=True)
    res2_2 = schema_f_1.dump({}, many=True)
    res2_3 = schema_f_1.dump({}, many=False)


# Generated at 2022-06-25 16:05:44.669978
# Unit test for function schema
def test_schema():
    from pprint import pprint
    from typing import List

    from dataclasses import dataclass, asdict

    @dataclass
    class B:
        a: int = 1

    @dataclass
    class A:
        b: B = B()
        c: List[B] = None

    schema_a = SchemaF.from_dataclass(A)
    schema_b = SchemaF.from_dataclass(B)

    pprint(schema_b._declared_fields)
    pprint(schema_a._declared_fields)

    schema_a.load({'b': {'a': 1}, 'c': [{'a': 2}]})


# Generated at 2022-06-25 16:05:50.019290
# Unit test for function build_schema
def test_build_schema():
    class User(metaclass=dataclass_json.dataclass_json):
        username: str
        password: str = field(mm_field=fields.Str(load_only=True))
        first_name: str = field(metadata=dict(dataclasses_json=dict(
            letter_case=lambda s: s.upper())))
        last_name: Optional[str] = None
        email: Optional[str] = None
        birthday: Optional[datetime] = None
        age: int = 0
        is_admin: bool = False
        website: Optional[URL] = None
        friends: List[str] = field(default_factory=lambda: [])
        balance: Decimal = Decimal('0.0')
        user_id: UUID = field(default_factory=uuid.uuid4)

# Generated at 2022-06-25 16:06:39.417969
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema_f_0 = SchemaF()
    serialized = schema_f_0.dumps(1, many=None)
    assert serialized == '1'



# Generated at 2022-06-25 16:06:43.634249
# Unit test for function build_schema
def test_build_schema():
    import pytest
    from typing_extensions import Literal
    assert _issubclass_safe(Literal["foo", "bar"], str) is True
    class Fruit(Enum):
        GRAPE = "grape"
        BANANA = "banana"

    @dataclass(frozen=True)
    class Millie:
        name: str
        age: int
        fruit: Literal["grape", "banana"]
    millies = [Millie("Millie", 10, "grape"), Millie("Alice", 8, "banana")]
    schema = build_schema(Millie, SchemaMixin, True, True)
    dumped = schema().dump(millies)

# Generated at 2022-06-25 16:06:46.460000
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f_loads = SchemaF.loads('', many=True, unknown='hello')


# Generated at 2022-06-25 16:06:51.962337
# Unit test for function build_schema
def test_build_schema():
    class _dataclass_json_schema_test_A(dataclass_json.JsonMixin):
        name: str
        cls: typing.Type["_dataclass_json_schema_test_B"]

    @dataclass_json
    @dataclass
    class _dataclass_json_schema_test_B:
        a: int
        b: typing.Optional[str]
        c: typing.List[str]
        d: typing.Optional[typing.List[int]]

    DataClassSchema = build_schema(_dataclass_json_schema_test_A, None, True, True)
    assert DataClassSchema.__name__ == "_dataclass_json_schema_test_A_mask"

# Generated at 2022-06-25 16:06:58.206120
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class JsonData(typing.Generic[A]):
        pass

    class JsonDictionary(JsonData[A]):
        pass

    class JsonNumber(JsonData[A]):
        pass

    class JsonString(JsonData[A]):
        pass

    class JsonList(JsonData[A]):
        pass

    class JsonBoolean(JsonData[A]):
        pass

    class JsonBool(JsonBoolean[A]):
        pass

    class JsonNull(JsonData[A]):
        pass

    class JsonObject(JsonData[A]):
        pass

    class JsonArray(JsonData[A]):
        pass

    class JsonValue(JsonData[A]):
        pass


# Generated at 2022-06-25 16:07:03.059106
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    schema_f_1 = SchemaF()
    schema_f_1.load(dict())
    schema_f_1.load('')
    schema_f_1.load([])
    schema_f_1.load(list())

test_SchemaF_load()


# Generated at 2022-06-25 16:07:13.507607
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema

    class SchemaF_test(Schema, typing.Generic[A]):
        """

        """
        def __init__(self, *arg, **kwargs):
            super().__init__(*arg, **kwargs)

        @typing.overload
        def dump(self, obj: typing.List[A], many: bool = None) -> typing.List[
            TEncoded]:  # type: ignore
            # mm has the wrong return type annotation (dict) so we can ignore the mypy error
            pass

        @typing.overload
        def dump(self, obj: A, many: bool = None) -> TEncoded:
            pass

        def dump(self, obj: TOneOrMulti,
                 many: bool = None) -> TOneOrMultiEncoded:
            pass

       

# Generated at 2022-06-25 16:07:20.502193
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from datetime import datetime

    class Address:
        def __init__(self, street: str, city: str, zipcode: str):
            self.street = street
            self.city = city
            self.zipcode = zipcode
    @dataclass
    class Person:
        name: str
        age: int
        address: Address
        hired_on: datetime = datetime.now()

    schema = schema(Person, mixin=Schema, infer_missing=False)
    assert 'name' in schema
    assert 'age' in schema
    assert 'address' in schema
    assert 'hired_on' in schema

    # Test that the schema can be used to serialize and deserialize
    schema = Schema.from_dict(schema)


# Generated at 2022-06-25 16:07:30.493425
# Unit test for function build_type
def test_build_type():
    # Test dictionary
    type_ = typing.Dict
    options = {}
    mixin = None
    field = MagicMock()
    field.type = dict
    cls = None
    field.name = "test"
    test_case = build_type(type_, options, mixin, field, cls)
    assert test_case == fields.Dict
    
    # Test list
    type_ = typing.List
    options = {}
    mixin = None
    field = MagicMock()
    field.type = list
    cls = None
    field.name = "test"
    test_case = build_type(type_, options, mixin, field, cls)
    assert test_case == fields.List
    
    # Test str
    type_ = str
    options = {}
    mixin

# Generated at 2022-06-25 16:07:34.372273
# Unit test for function schema
def test_schema():
    import dataclasses
    from dataclasses_json.mm_schema import SchemaF

    @dataclasses.dataclass
    class A(SchemaF):
        pass

    schema_f_1 = A()

    @dataclasses.dataclass
    class A(SchemaF):
        pass

    @dataclasses.dataclass
    class B:
        pass

    b = B()
    schema_f_2 = A()



# Generated at 2022-06-25 16:09:57.019996
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()


# Generated at 2022-06-25 16:10:07.738896
# Unit test for function build_schema
def test_build_schema():
    # Test for TypeError raise, type check
    # create class object for cls
    class_object = object()
    # create schema_type object for mixin
    schema_type_obj = object()
    # create bool object for infer_missing
    bool_obj = object()
    # create partial object
    partial_obj = object()

    with pytest.raises(TypeError):
        build_schema(class_object, schema_type_obj, bool_obj, partial_obj)



# Generated at 2022-06-25 16:10:12.177715
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema_f_0 = SchemaF()
    schema_f_0.dump(['abc'])
    schema_f_0.dump('abc')


# Generated at 2022-06-25 16:10:14.756608
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    schema_f = SchemaF()
    schema = schema_f.load(data=dict())


# Generated at 2022-06-25 16:10:24.812021
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema_f_0 = SchemaF()
    schema_f_1 = SchemaF()
    schema_f_2 = SchemaF()
    schema_f_3 = SchemaF()
    schema_f_4 = SchemaF()
    schema_f_5 = SchemaF()

    schema_f_6 = SchemaF()
    schema_f_7 = SchemaF()
    schema_f_8 = SchemaF()
    schema_f_9 = SchemaF()
    schema_f_10 = SchemaF()
    schema_f_11 = SchemaF()

    schema_f_12 = SchemaF()
    schema_f_13 = SchemaF()
    schema_f_14 = SchemaF()
    schema_f_15 = SchemaF()

# Generated at 2022-06-25 16:10:29.103203
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    obj = _TimestampField(allow_none=True, missing=MISSING, default=MISSING,
                          load_only=False, dump_only=False,
                          error_messages=None)
    assert isinstance(obj, _TimestampField)



# Generated at 2022-06-25 16:10:40.326851
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_field = _IsoField()
    assert isinstance(iso_field, fields.Field)
    assert iso_field.metas is None
    assert iso_field.attribute is None
    assert iso_field.default is None
    assert iso_field.default_setter is None
    assert iso_field.missing == MISSING
    assert iso_field.allow_none is False
    assert iso_field.required is False
    assert iso_field.load_only is False
    assert iso_field.dump_only is False
    assert iso_field.error is None
    assert iso_field.validators is None
    assert iso_field.source is None
    assert iso_field.dump_to is None
    assert iso_field.load_from is None
    assert iso_field.deserialize_from is None
    assert iso_

# Generated at 2022-06-25 16:10:49.836818
# Unit test for function build_type
def test_build_type():
    from typing import List, Dict
    from typing_extensions import TypedDict
    from dataclasses import dataclass
    import marshmallow
    from marshmallow.fields import Field

    # Test case 1: (given)
    class TestDataClass(dataclass):
        a: int
        b: List[int]
        c: TestDataClass
        d: Dict
        e: TypedDict

    result = build_type(type(TestDataClass.a), {}, TestDataClass,
                        TestDataClass.a, TestDataClass)
    expected = marshmallow.fields.Int()
    assert type(result) == type(expected)

    # Test case 2: (given)

# Generated at 2022-06-25 16:10:57.133725
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclass
    class TestCase:
        obj: typing.List[int]
        many: bool
        expected: typing.List[int]
    test_cases = [
        TestCase(obj=[1, 2, 3], many=True, expected=[1, 2, 3]),
    ]
    for test_case in test_cases:
        # This is a test case
        schema_f = SchemaF()
        actual = schema_f.dump(test_case.obj, many=test_case.many)
        assert actual == test_case.expected



# Generated at 2022-06-25 16:11:06.644052
# Unit test for function schema
def test_schema():
    class Sample:
        x: int
        y = 123
        z: typing.Optional[str] = None

    sample_schema = schema(Sample, None, False)
    assert len(sample_schema) == 3
    assert sample_schema['z'].allow_none
    assert 'allow_none' not in sample_schema['x'].__dict__
    assert sample_schema['y']._default == 123

    class Sample2(Sample):
        pass
    assert schema(Sample2, None, False) == schema(Sample, None, False)

    class Sample3:
        _x: int
        __y = 123
        __z: typing.Optional[str] = None

    sample_schema_3 = schema(Sample3, None, False)
    assert len(sample_schema_3) == 3
