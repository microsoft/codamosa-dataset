

# Generated at 2022-06-25 16:02:50.491397
# Unit test for function schema
def test_schema():
    class TeacherSchema(SchemaType):
        fullname = fields.String()
        age = fields.Integer()

    class StudentSchema(SchemaType):
        name = fields.String()
        age = fields.Integer()
        teachers = fields.Nested(TeacherSchema, many=True)

    @dataclass_json
    @dataclass
    class Teacher:
        fullname: str
        age: int

    @dataclass_json
    @dataclass
    class Student:
        name: str
        age: int
        teachers: typing.List[Teacher]

    s = schema(Student, dataclass_json, False)
    assert type(s['name']) == fields.Str
    assert type(s['age']) == fields.Int
    assert type(s['teachers']) == fields

# Generated at 2022-06-25 16:02:53.118073
# Unit test for function build_schema
def test_build_schema():
    class A(object):
        def __init__(self, a):
            self.a = a
    test_cls = dataclass(A)
    build_schema(test_cls(1))

# Generated at 2022-06-25 16:03:00.317306
# Unit test for function schema

# Generated at 2022-06-25 16:03:01.483291
# Unit test for function schema
def test_schema():
    schema_f_0 = SchemaF()


# Generated at 2022-06-25 16:03:08.585783
# Unit test for constructor of class _IsoField
def test__IsoField():
    # Test 1: Simple case of _IsoField
    # Define class for unit test
    class SchemaF(Schema):
        field_0 = _IsoField(required=True)

    schema_f_0 = SchemaF()
    value_datetime_0 = datetime.fromisoformat('2020-05-01T14:13:13')
    test_serialized_0 = schema_f_0.load({'field_0': value_datetime_0})
    assert test_serialized_0.data['field_0'] == value_datetime_0.isoformat()
    test_deserialized_0 = schema_f_0.dump({'field_0': value_datetime_0})
    assert test_deserialized_0.data['field_0'] == value_datetime_0

    #

# Generated at 2022-06-25 16:03:19.043609
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # In the case of dump many is not necessary to specify if obj is a single object
    @dataclass_json
    @dataclass
    class X:
        a: int

    schema_f_1 = SchemaF[X]()

    result_1 = schema_f_1.dump(X(1))
    assert result_1 == {'a': 1}

    result_2 = schema_f_1.dump([X(1)])
    assert result_2 == [{'a': 1}]

    # In the case of dumps many is necessary to specify if obj is a single object
    result_3 = schema_f_1.dumps([X(1)])
    assert result_3 == '[{"a":1}]'

    result_4 = schema_f_1.dumps(X(1), many=True)

# Generated at 2022-06-25 16:03:24.295533
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass

    @dataclass_json
    @dataclass
    class Test:
        _a: int = 1
        _b: str = "1"
        _c: float = 1.0

    test_sc = schema(Test, mixin=True, infer_missing=True)
    assert isinstance(test_sc["_a"], fields.Int)
    assert isinstance(test_sc["_b"], fields.Str)
    assert isinstance(test_sc["_c"], fields.Float)


# Generated at 2022-06-25 16:03:30.366538
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    schema_f = SchemaF()
    schema_f.load([{'b': 42}])
    schema_f.load({'b': 42})
    schema_f.load([{'b': 42}], many=True)
    schema_f.load({'b': 42}, many=False)
    schema_f.loads('[{"b": 42}]', many=True)
    schema_f.loads('{"b": 42}', many=False)


# Generated at 2022-06-25 16:03:31.230547
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()


# Generated at 2022-06-25 16:03:32.686370
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField(required=True) is not None


# Generated at 2022-06-25 16:03:51.053060
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class TestDataclass:
        pass

    class TestSchema(SchemaF[TestDataclass]):
        pass

    test_schema = TestSchema()

    with pytest.raises(NotImplementedError):
        test_schema.dumps(TestDataclass())


# Generated at 2022-06-25 16:04:01.589251
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Book:
        def __init__(self, author: str, id: int, status: str) -> None:
            self.author = author
            self.id = id
            self.status = status

    class BookSchema(SchemaF[Book]):
        author = fields.Str()
        id = fields.Int()
        status = fields.Str()

    book_schema = BookSchema()

    book = Book(author='John', id=1, status='Checked')
    data, errs = book_schema.dump(book)
    assert data == {'author': 'John', 'id': 1, 'status': 'Checked'}

    book = Book(author='John', id=1, status='Checked')
    book_list = [book]
    many_data, errs = book_schema

# Generated at 2022-06-25 16:04:03.194613
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()


# Generated at 2022-06-25 16:04:10.563533
# Unit test for function schema
def test_schema():
    # Test case 1
    # All correct input
    class UserF:
        def __init__(self, email, id_):
            self.email = email
            self.id = id_
    # Test case 1.1
    # Can't inherit class SchemaF
    class UserSchemaF(SchemaF[UserF]):
        email = fields.Email()
        id = fields.Integer()

        @post_load
        def make_user(self, data, **kwargs):
            return UserF(**data)
    # Test case 1.2
    class UserSchemaF(SchemaF[UserF]):
        email = fields.Email()
        id = fields.Integer()

        @post_load
        def make_user(self, data, **kwargs):
            return UserF(**data)

    #

# Generated at 2022-06-25 16:04:17.938015
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class A:
        x: int

    schema_a = build_schema(A, None, infer_missing=False, partial=False)
    # Unit test for function schema
    def test_schema():
        assert schema(A, None, infer_missing=False) == {'x': fields.Integer()}

    class B:
        x: int
        y: typing.Optional[int]

    # Unit test for function build_type
    def test_build_type():
        assert build_type(typing.Optional[int], {}) == fields.Integer(
            allow_none=True)
        assert build_type(int, {}) == fields.Integer()
        assert build_type(str, {}) == fields.String()

# Generated at 2022-06-25 16:04:28.386093
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # check if subclassing SchemaF is possible
    class TestSchema(SchemaF[User]):
        @post_load
        def make_object(self, data, **kwargs):
            return User(**data)

    ts = TestSchema()
    ts.dump([User(name='test', email='test@test.com'), User(name='test2', email='test2@test.com')])
    ts.dump(User(name='test', email='test@test.com'))
    
    # check if subclassing SchemaF is possible
    class TestSchema(SchemaF):
        @post_load
        def make_object(self, data, **kwargs):
            return User(**data)

    ts = TestSchema()

# Generated at 2022-06-25 16:04:29.548970
# Unit test for function schema
def test_schema():
    # TODO: add tests for schema function here
    pass

# Generated at 2022-06-25 16:04:35.191771
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    """
    Test the method dump of class SchemaF and the return type
    of the method.
    """
    # Test with one object
    class TestSerializer(SchemaF[A]):
        """
        Test class for testing the dump method and the return type of the dump
        method.
        """
    # Test with list of objects
    class TestListSerializer(SchemaF[A]):
        """
        Test class for testing the dump method and the return type of the dump
        method.
        """

    test_serializer = TestSerializer()
    test_list_serializer = TestListSerializer()
    # Test with one object
    assert test_serializer.dump({'test': 'test'}) == {'test': 'test'}
    # Test with list of objects
    assert test_list_serializer.dump

# Generated at 2022-06-25 16:04:39.223236
# Unit test for function schema
def test_schema():
    schema_f = SchemaF()
    passed_cls = namedtuple('TestClass', ['field_str', 'field_i', 'field_f'])

    expected_0 = {'field_str': fields.Str(),
                  'field_i': fields.Int(),
                  'field_f': fields.Float()}
    assert schema(passed_cls, None, False) == expected_0


test_schema()

# Generated at 2022-06-25 16:04:49.352136
# Unit test for function build_type
def test_build_type():
    class DiscriminatedMixin:
        __type__ = None

    @dataclass_json
    @dataclass
    class DiscriminatedA(DiscriminatedMixin):
        a: str

    @dataclass_json
    @dataclass
    class DiscriminatedB(DiscriminatedMixin):
        b: int

    @dataclass_json
    @dataclass
    class C:
        a: typing.Union[DiscriminatedA, DiscriminatedB]


    result = build_type(field=dc_fields(C)[0],
                        options={},
                        mixin=DiscriminatedMixin,
                        type_=typing.Union[DiscriminatedA, DiscriminatedB],
                        cls=C)
    assert isinstance(result, fields.Field)


# Generated at 2022-06-25 16:05:10.311305
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    import dataclasses_json

    @dataclass
    class foo:
        a : int
        b : float
        c : datetime
        d : typing.List[int]
        e : str
        f : typing.Optional[int]
        g : typing.Optional[typing.List[int]]
        h: typing.Optional[typing.List[typing.Optional[int]]]

    # print(schema(foo, dataclasses_json.Mixin, True))


if __name__ == "__main__":
    test_case_0()
    test_schema()

# Generated at 2022-06-25 16:05:20.185896
# Unit test for function build_type
def test_build_type():
    def t0_mixin(*args, **kwargs):
        pass
    def t0_func(x, y):
        pass

    t0_mixin = dataclass_json(mm_field=("a", str, True),
                          t0=t0_mixin,
                          field_many=True,
                          )

    t0_cls = dataclass_json(mm_field=("a", str, True),
                          t0=t0_mixin,
                          field_many=True,
                          )


# Generated at 2022-06-25 16:05:26.237348
# Unit test for function build_schema
def test_build_schema():
    from .main import MM
    from .patch import patch

    @patch
    @dataclass_json
    @dataclass
    class Person:
        id: int
        first_name: str
        last_name: str
        birth_date: datetime
        letter: Enum('A', 'B', 'C')
        union: Union[int, str]

    assert build_schema(Person, MM, False, False) is not None


# Generated at 2022-06-25 16:05:34.912907
# Unit test for function schema
def test_schema():
    from dataclasses_json.__version__ import version
    from dataclasses_json.test_utils import TestSchemaMixin

    @dataclass_json
    @dataclass
    class TestSchema(TestSchemaMixin):
        d: datetime

    s = schema(TestSchema, TestSchemaMixin, False)

# Generated at 2022-06-25 16:05:44.668316
# Unit test for function build_schema
def test_build_schema():
    # test for class: DataClassesWithSchema
    mixin = type("Mixin", (object,), {})
    assert DataClassesWithSchema.schema() == build_schema(DataClassesWithSchema, mixin, False, True)

    # test for class: DataClassesWithSchema
    assert DataClassesWithSchema.schema() == build_schema(DataClassesWithSchema, mixin, False, True)



# Generated at 2022-06-25 16:05:45.422264
# Unit test for function schema
def test_schema():
    schema_f = SchemaType()


# Generated at 2022-06-25 16:05:58.823264
# Unit test for function schema
def test_schema():
    class SchemaF(Schema, typing.Generic[A,B]):
        """Lift Schema into a type constructor"""

        def __init__(self, *args, **kwargs):
            """
            Raises exception because this class should not be inherited.
            This class is helper only.
            """

            super().__init__(*args, **kwargs)
            raise NotImplementedError()

        @typing.overload
        def dump(self, obj: typing.List[A], many: bool = None) -> typing.List[
            TEncoded]:  # type: ignore
            # mm has the wrong return type annotation (dict) so we can ignore the mypy error
            pass

        @typing.overload
        def dump(self, obj: A, many: bool = None) -> TEncoded:
            pass



# Generated at 2022-06-25 16:06:05.141626
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    schema_f_0 = SchemaF()
    obj_f_0 = schema_f_0.load(data=None, many=None, partial=None, unknown=None)
    obj_f_1 = schema_f_0.load(data=None, many=None, partial=None, unknown=None)
    obj_f_2 = schema_f_0.load(data=None, many=None, partial=None, unknown=None)
    obj_f_3 = schema_f_0.load(data=None, many=None, partial=None, unknown=None)
    obj_f_4 = schema_f_0.load(data=None, many=True, partial=None, unknown=None)

# Generated at 2022-06-25 16:06:06.082682
# Unit test for function schema
def test_schema():
    #TODO: implement
    pass

# Generated at 2022-06-25 16:06:18.476005
# Unit test for function build_type
def test_build_type():
    class TestType(Enum):
        A = 0

    class ChildType:
        pass

    class ParentType:
        pass

    class ParentChildType(ParentType):
        pass


# Generated at 2022-06-25 16:06:54.576728
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class MySchemaF(SchemaF):
        test_field_0: str
        test_field_0 = fields.Str()
    schema_f_0: MySchemaF = MySchemaF()
    assert isinstance(schema_f_0.dumps({'test_field_0': 'test_value_0'}), str)
    assert isinstance(schema_f_0.dumps([{'test_field_0': 'test_value_0'}, {'test_field_0': 'test_value_1'}], many=True), str)
    assert isinstance(schema_f_0.dumps({'test_field_0': 'test_value_0'}, many=False), str)

# Generated at 2022-06-25 16:06:57.528024
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    test_case_0()


# Generated at 2022-06-25 16:06:58.341703
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    _TimestampField()


# Generated at 2022-06-25 16:07:01.854894
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema_f_1 = SchemaF()
    res_1 = schema_f_1.dumps(object())
    assert isinstance(res_1, str)



# Generated at 2022-06-25 16:07:06.437259
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Inner:
        def __init__(self, field1: str, field2: int) -> None:
            self.field1: str = field1
            self.field2: int = field2

    class InnerSchema(Schema):
        field1 = fields.Str()
        field2 = fields.Int()

        @post_load
        def make_inner(self, data, **kwargs):
            return Inner(**data)

    class InnerClass:
        def __init__(self, field1: str, field2: int) -> None:
            self.field1 = field1
            self.field2 = field2

    # TODO: remove the ignore after mypy fixes the return type of mm.Schema.dump
    schema = SchemaF()
    assert '{}' == schema.dump([])  # type:

# Generated at 2022-06-25 16:07:16.176275
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class TestClassA:
        def __init__(self, i: int):
            self.i = i

    class TestClassB:
        def __init__(self, j: int):
            self.j = j

    class TestClassC:
        def __init__(self, k: int):
            self.k = k

    class TestClassD:
        def __init__(self, l: int):
            self.l = l

    @dataclasses.dataclass
    class DataclassA:
        i: int
        j: int

    @dataclasses.dataclass
    class DataclassB:
        k: int
        l: int

    class DataclassC:
        def __init__(self, i: int):
            self.i = i


# Generated at 2022-06-25 16:07:17.094790
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f_loads_0 = SchemaF()



# Generated at 2022-06-25 16:07:25.442674
# Unit test for function build_type
def test_build_type():
    '''
    This function tests whether we can build the correct data structure
    '''
    class A(object):
        a = 0
        b = 0
    
    class B(object):
        a = 0
        b = 0
        
    def inner(type_, options):
        while True:
            if not _is_new_type(type_):
                break
            type_ = type_.__supertype__

        if is_dataclass(type_):
            if _issubclass_safe(type_, mixin):
                options['field_many'] = bool(
                    _is_supported_generic(field.type) and _is_collection(
                        field.type))
                return fields.Nested(type_.schema(), **options)

# Generated at 2022-06-25 16:07:31.408563
# Unit test for function schema
def test_schema():
    class MySchema(Schema):
        id = fields.Int(metadata={"dataclasses_json": {"mm_field": None}},
                        required=False)

    class Person():
        def __init__(self, id, name, age):
            self.id = id
            self.name = name
            self.age = age

    p = Person(5, 'Jane', 22)
    # p does not have an id attribute
    try:
        schema_p = MySchema()
        result = schema_p.dump(p)
        print('result', result)
    except Exception as e:
        print(e)

    p.id = None
    result = MySchema().dump(p)
    print('result', result)

# Generated at 2022-06-25 16:07:35.808519
# Unit test for function schema
def test_schema():
    """
    >>> @dataclass_json
    ... @dataclass
    ... class Data:
    ...     foo: str
    ...     bar: int
    ...
    >>> schema(Data, mixin, True)
    {'foo': <class 'marshmallow.fields.String'>, 'bar': <class 'marshmallow.fields.Integer'>, '__type': <class 'marshmallow.fields.String'>}
    """

# Generated at 2022-06-25 16:08:50.156627
# Unit test for function schema
def test_schema():
    def serialize_decorator(method):
        def wrapper(self):
            return method(self)
        return wrapper

    class BaseMixin:

        @serialize_decorator
        def serialize(self):
            pass

        @serialize_decorator
        def deserialize(self):
            pass

        @classmethod
        def get_schema(cls) -> SchemaType:
            return cls.schema()


    class TempClass(BaseMixin):
        def __init__(self, test: str = 'test'):
            self.test = test
    print(f"TempClass.get_schema() = {TempClass.get_schema()}")
test_schema()

# Generated at 2022-06-25 16:09:01.023544
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from marshmallow_dataclass import dataclass as dataclass2
    @dataclass(unsafe_hash=True)
    class Foo:
        a: int
        b: str = 'abc'
        c: UUID = UUID('fada3c3f-66b8-42d0-82eb-c2385b7de9b9')
        d: datetime = datetime.now()
        e: typing.Tuple[int, ...]
        f: typing.Dict[str, int]
        g: typing.List[int]
        dataclass_json_config = {'type_determiner': 'type_determiner'}

    class my_mixin:
        pass


# Generated at 2022-06-25 16:09:04.025789
# Unit test for function build_schema
def test_build_schema():
    class C(object):
        pass

    result = build_schema(C, object, False, False)
    print(result.__dict__)
    assert(isinstance(result, type))
    assert(hasattr(result, 'Meta'))
    assert(hasattr(result, 'make_c'))



# Generated at 2022-06-25 16:09:05.727430
# Unit test for function build_schema
def test_build_schema():
    class Sub(BaseClass):
        name: str

    build_schema(Sub, Sub, False, False)
    build_schema(Sub, Sub, True, False)


# Generated at 2022-06-25 16:09:06.494139
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_field = _IsoField()


# Generated at 2022-06-25 16:09:13.523278
# Unit test for function build_type
def test_build_type():
    class SchemaF_0(Schema, typing.Generic[A]):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            raise NotImplementedError()

        @typing.overload
        def dump(self, obj: typing.List[A], many: bool = None) -> typing.List[
            TEncoded]:  # type: ignore
            # mm has the wrong return type annotation (dict) so we can ignore the mypy error
            pass

        @typing.overload
        def dump(self, obj: A, many: bool = None) -> TEncoded:
            pass

        def dump(self, obj: TOneOrMulti,
                 many: bool = None) -> TOneOrMultiEncoded:
            pass


# Generated at 2022-06-25 16:09:18.138607
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f_1 = SchemaF()
    json_data_1 = '[{"id": 1, "name": "XX"}]'
    result_1 = schema_f_1.loads(json_data_1)
    schema_f_1.dumps(result_1)


# Generated at 2022-06-25 16:09:28.807525
# Unit test for function schema
def test_schema():
    class Foo:
        def __init__(self, id, name):
            self.id = id
            self.name = name

    class FooSchema(Schema):
        id = fields.Int()
        name = fields.Str()

    FooSchema().dump(Foo(1, 'foo'))

    class FooParam(typing.NamedTuple):
        id: int
        name: str = 'bar'

    class Foo2:
        param: typing.Optional[FooParam] = None

    class Foo2Schema(Schema):
        param = fields.Nested(FooParam)

    from dataclasses import dataclass

    @dataclass
    class Foo3:
        id: int
        name: typing.Optional[str] = None


# Generated at 2022-06-25 16:09:29.925472
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field.required is False


# Generated at 2022-06-25 16:09:36.000646
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclasses.dataclass
    class DcClass:
        field_int: int

    schema_f_1 = SchemaF[DcClass]()

    my_obj_0: typing.List[DcClass] = [
        DcClass(field_int=0),
        DcClass(field_int=1)]
    my_dict_0 = schema_f_1.dump(my_obj_0, many=True)
    assert my_dict_0 == [
        {'field_int': 0},
        {'field_int': 1}]
    my_obj_1: typing.List[DcClass] = [
        DcClass(field_int=0)]
    my_dict_1 = schema_f_1.dump(my_obj_1, many=True)
    assert my

# Generated at 2022-06-25 16:12:19.597327
# Unit test for function build_schema
def test_build_schema():
    # TODO add support for generic dataclasses
    # see https://github.com/PRBonn/python-dataclasses-json/issues/129

    class Point:
        x: int
        y: int

    # parameter infer_missing
    build_schema(Point, False)
    build_schema(Point, True)

    # parameter partial
    build_schema(Point, False, False)
    build_schema(Point, False, True)

    # make sure default factory is respected
    class Point:
        x: int
        y: int = field(default_factory=lambda: 0)

    SchemaF[Point]().dump({'x': 0})


# Unit tests for function build_type