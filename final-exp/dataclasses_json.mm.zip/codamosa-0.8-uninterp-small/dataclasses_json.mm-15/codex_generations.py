

# Generated at 2022-06-25 16:02:41.771028
# Unit test for function schema
def test_schema():
    pass

# Generated at 2022-06-25 16:02:50.852058
# Unit test for function build_type
def test_build_type():
    from dataclasses_json import DataClassJsonMixin
    @dataclass_json
    @dataclass
    class DataClassMixin(DataClassJsonMixin):
        class Meta:
            unknown = UNDEFINED

    class SchemaF:
        pass

    options = {}
    mixin = DataClassMixin
    field = typing.Union[int, str]
    cls = DataClassMixin

    # Verify that the return value is the correct type
    assert type(build_type(int, options, mixin, field, cls)) == fields.Int
    assert type(build_type(typing.List[int], options, mixin, field, cls)) == fields.List
    assert type(build_type(typing.List[str], options, mixin, field, cls)) == fields.List


# Generated at 2022-06-25 16:02:57.852848
# Unit test for function build_schema
def test_build_schema():
    from .dataclasses import dataclass_json
    @dataclass_json
    @dataclass
    class DataTemp:
        a: str
        b: int = 2

    DataClassSchema = build_schema(DataTemp, mixin=None, infer_missing=False, partial=None)
    schema_0 = DataClassSchema()
    # Test if 
    assert isinstance(schema_0, Schema)

# Generated at 2022-06-25 16:03:07.108670
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema_f_1 = SchemaF()
    assert schema_f_1.dump([[1, 2], [3, 4, 5]], many = True) == [[1, 2], [3, 4, 5]]
    assert schema_f_1.dump([[1], [2, 3]], many = True) == [[1], [2, 3]]
    assert schema_f_1.dump([[1], [2, 3]], many = None) == [[1], [2, 3]]
    assert schema_f_1.dump([[1], [3, 4]], many = None) == [[1], [3, 4]]
    assert schema_f_1.dump([[1], [2, 3]], many = False) == [[1], [2, 3]]

# Generated at 2022-06-25 16:03:18.351148
# Unit test for function build_schema
def test_build_schema():
    mixin = Mixin()
    infer_missing = True
    partial = False
    schema_f_1 = build_schema(TestDataclass, mixin, infer_missing, partial)
    print(schema_f_1.__name__)
    print(schema_f_1.Meta.fields)
    # print(schema_f_1.make_testdataclass(null=None, integer=1, boolean=True, double=1.1, string='A string', array=[1, 2, 3], dictionary={'a': 1, 'b': 2}, nested={'a': {'b': 'c'}}))

    # The following line of code triggers 'AttributeError: 'EnumField' object has no attribute 'dumps'' error
    # print(schema_f_1.dumps(schema_f_

# Generated at 2022-06-25 16:03:25.127494
# Unit test for function build_schema
def test_build_schema():
    from marshmallow import Schema, fields, post_load, validates_schema
    from dataclasses import dataclass

    class Foo: pass
    class Bar: pass

    class Meta(Schema.Meta):
        fields = tuple()
        ordered = True

    @post_load
    def make_instance(self, data, **kwargs):
        return Foo(**data)

    def dumps(self, *args, **kwargs):
        if 'cls' not in kwargs:
            kwargs['cls'] = _ExtendedEncoder
        return Schema.dumps(self, *args, **kwargs)

    class FooSchema(Schema):
        Meta = Meta
        make_foo = make_instance
        dumps = dumps
        a = fields.Int(required=True)
        b = fields.Int

# Generated at 2022-06-25 16:03:33.997337
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class _TestClassSchemaF:
        def __init__(self, a: typing.List[int]):
            self.a = a

    class _TestSchema(SchemaF[typing.List[int]]):  # type: ignore
        a = fields.List(fields.Int)
        @post_load
        def make_object(self, data):
            return _TestClassSchemaF(**data)
    schema = _TestSchema()
    res = schema.dumps(_TestClassSchemaF([1, 2, 3]))
    assert res == '{"a": [1, 2, 3]}'


# Generated at 2022-06-25 16:03:41.862163
# Unit test for function build_type
def test_build_type():
    class TestClass:
        pass

    class TestClass0:
        pass

    class TestEnum(Enum):
        pass

    class TestMixin(object):
        pass

    my_type = typing.MutableMapping[str, typing.MutableMapping[str, typing.Tuple[typing.Tuple[str, typing.Set], typing.List[TestClass]]]]
    test_options = {}
    test_mixin = TestMixin
    my_field = dc_fields(TestClass0)[0]
    my_cls = TestClass0
    test_case_0()
    build_type(my_type, test_options, test_mixin, my_field, my_cls)

    my_field2 = dc_fields(TestClass)[0]
    my_cls2 = TestClass
   

# Generated at 2022-06-25 16:03:43.647306
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    test_json = b'{"a": 1, "b": "2"}'
    with pytest.raises(NotImplementedError):
        SchemaF().loads(test_json)


# Generated at 2022-06-25 16:03:46.301690
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclasses.dataclass
    class Adhoc0:
        x: typing.List[int]

    schema_f_0 = SchemaF[Adhoc0]
    instance_adhoc0 = Adhoc0([1, 2, 3])
    assert(schema_f_0.dumps(instance_adhoc0) == '{"x": [1, 2, 3]}')


# Generated at 2022-06-25 16:04:05.033405
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from typing import Optional, Dict, Any

    # Test dataclass for optional
    @dataclass
    class User2:
        name: str
        age: Optional[int]
    User2Schema = build_schema(User2, EmbeddedJsonMixin, True, False)
    user2_schema = User2Schema()
    user2 = User2('steven', 21)
    res = user2_schema.dump(user2)
    assert res['name'] == 'steven'
    assert res['age'] == 21

    # Test dataclass for list
    @dataclass
    class User3:
        name: str
        age: int
        family: list

# Generated at 2022-06-25 16:04:05.869512
# Unit test for function schema
def test_schema():
    pass


# Generated at 2022-06-25 16:04:12.771045
# Unit test for function schema
def test_schema():
    class Student:
        def __init__(self, name: str, age: typing.Optional[int]):
            self.name = name
            self.age = age

    schema_dict: dict = schema(Student, None, False)
    assert schema_dict == {
        "name": fields.Str,
        "age": fields.Integer,
    }


if __name__ == "__main__":
    test_case_0()
    test_schema()

# Generated at 2022-06-25 16:04:22.849594
# Unit test for function build_schema
def test_build_schema():
    import dataclasses
    import typing
    import pytest
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class Foo:
        bar: str
        baz: int
    schema_f = build_schema(Foo, None, False, False)
    assert schema_f.__name__ == "FooSchema"

    @dataclass
    class Foo_Test:
        bar: str
        baz: int
    schema_ = schema(Foo_Test, None, False)
    assert schema_ == {"bar": fields.Str, "baz": fields.Int}

    @dataclass
    class Foo_Test_0:
        baz: int
    schema_f_0 = build_schema

# Generated at 2022-06-25 16:04:27.390810
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Obj:
        def __init__(self):
            pass

    # Test for when many=False
    schema_f = SchemaF()
    obj = Obj()
    assert schema_f.loads(b'', many=False) == obj
    # Test for when many=True
    assert schema_f.loads(b'', many=True) == []


# Generated at 2022-06-25 16:04:29.920608
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    assert SchemaF[int].loads('1') == 1


# Generated at 2022-06-25 16:04:30.876701
# Unit test for function schema
def test_schema():
    class Foo:
        pass

    assert schema(Foo, None, False) == {}

# Generated at 2022-06-25 16:04:39.741415
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from datetime import datetime
    from dataclasses import dataclass

    @dataclass
    class Foo:
        x: int

    schema = SchemaF[Foo]()

    x = schema.dumps(Foo(x = 1))
    assert x == '{"x": 1}'

    x = schema.dumps(Foo(x = 1), many = False)
    assert x == '{"x": 1}'

    x = schema.dumps([Foo(x = 1)])
    assert x == '[{"x": 1}]'

    x = schema.dumps([Foo(x = 1)], many = True)
    assert x == '[{"x": 1}]'

    x = schema.dumps([Foo(x = 1), Foo(x = 2)])

# Generated at 2022-06-25 16:04:41.710290
# Unit test for constructor of class _IsoField
def test__IsoField():
    IsoField = _IsoField()


# Generated at 2022-06-25 16:04:43.476207
# Unit test for constructor of class _IsoField
def test__IsoField():
    # Init _IsoField
    d= _IsoField()
    assert d is not None


# Generated at 2022-06-25 16:05:06.075833
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    def test_case_0():
        schema_f_0 = SchemaF()

    def test_case_1():
        class User:
            pass

        schema_f_0 = SchemaF()
        schema_f_0.dumps([1, 2, 3])
        schema_f_0.dumps(1)
        schema_f_0.dumps([User(), User()])
        schema_f_0.dumps(User())

    def test_case_2():
        class User:
            pass

        schema_f_0 = SchemaF()
        schema_f_0.dumps([1, 2, 3], many = True)
        schema_f_0.dumps(1, many = True)
        schema_f_0.dumps([User(), User()], many = False)
        schema_

# Generated at 2022-06-25 16:05:15.198459
# Unit test for function build_schema
def test_build_schema():
    class TestClass(object):
        def __init__(self, *args, **kwargs):
            self.name = 'TestClass'
            super().__init__(*args, **kwargs)
    # assign a type to Schema to let we can use its methods
    SchemaF.Meta = type('Meta', (), {'fields': (),})
    # test for schema
    schema_f_0 = build_schema(TestClass, None, True, True)
    schema_f_1 = build_schema(TestClass, None, True, True)
    assert schema_f_0.__name__ == 'TestClassSchema'
    assert schema_f_1.__name__ == 'TestClassSchema'
    assert schema_f_0 == schema_f_1


# Generated at 2022-06-25 16:05:18.828660
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class TestDataInner:
        name: str
        value: int

    @dataclass
    class TestData:
        name: str
        value: List[TestDataInner]

    schema = build_schema(TestData, None, False, False)
    assert schema.Meta.fields == ('name', 'value')



# Generated at 2022-06-25 16:05:24.820986
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema_f_0 = SchemaF()
    schema_f_0.dump(1, 1)
    schema_f_0.dump(1, 2)
    schema_f_0.dump(None, 1)


# Generated at 2022-06-25 16:05:31.414415
# Unit test for function build_type
def test_build_type():
    from dataclasses_json.schema import schema_for
    from dataclasses import dataclass
    from typing import List
    opts = {}
    @dataclass
    class A:
        a: int = 1
        b: str = "test"
        c: float = 1.0
        d: List[int] = [1, 2, 3]
    schema_a = schema_for(A)
    f = fields.Nested(schema_a)
    assert f == build_type(A, opts, schema_a, A.__annotations__['a'], A)
    assert f.many == build_type(List[A], opts, schema_a, A.__annotations__['d'], A).many

# Generated at 2022-06-25 16:05:37.538246
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class MySchemaF(SchemaF):
        a = fields.Int()

    schema = MySchemaF()
    # Test with many=None
    assert schema.dumps({"a": 42}) == "{\n    \"a\": 42\n}"
    # Test with many=False
    assert schema.dumps({"a": 42}, many=False) == "{\n    \"a\": 42\n}"

# Unit tests for class _ExtendedEncoder

# Generated at 2022-06-25 16:05:45.149071
# Unit test for function build_type
def test_build_type():
    try:
        schema_f_0 = SchemaF()
        assert False
    except Exception:
        assert True

    schema_f_1 = SchemaF[int]
    assert isinstance(schema_f_1, typing.TypeVar)

    schema_f_2 = SchemaF[int]()
    assert isinstance(schema_f_2, Schema)

    schema_f_3 = SchemaF[int](many=True)
    assert isinstance(schema_f_3, Schema)

    schema_f_4 = SchemaF[int](many=True).dump(FieldTestClass())
    assert isinstance(schema_f_4, typing.List)

    schema_f_5 = SchemaF[int](many=True).dump(FieldTestClass(), many=True)
    assert isinstance

# Generated at 2022-06-25 16:05:48.940867
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclasses.dataclass
    class A:
        a: int
        b: str

    schema_f_1 = SchemaF(A)

    @dataclasses.dataclass
    class B:
        b: str
        c: A
        d: typing.List[A]

    schema_f_2 = SchemaF(B)

    @dataclasses.dataclass
    class C:
        c: A
        b: typing.List[A]

    schema_f_3 = SchemaF(C)


# Generated at 2022-06-25 16:05:50.108987
# Unit test for constructor of class _TimestampField
def test__TimestampField():

    assert issubclass(_TimestampField, fields.Field)


# Generated at 2022-06-25 16:05:58.823064
# Unit test for function build_schema
def test_build_schema():

    @dataclass
    class Foo:
        foo: str
        bar: int

    FooSchema = build_schema(Foo, None, True, False)
    assert len(FooSchema.__dict__) == 6
    assert len(FooSchema.__dict__['Meta'].__dict__) == 1
    assert FooSchema.__dict__['Meta'].__dict__['fields'] == ('foo', 'bar')
    assert not isinstance(FooSchema().fields['foo'], fields.Nested)
    assert not isinstance(FooSchema().fields['bar'], fields.Nested)



# Generated at 2022-06-25 16:06:27.836343
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema_f_1 = SchemaF()
    schema_f_1.dumps()


# Generated at 2022-06-25 16:06:30.808708
# Unit test for function schema
def test_schema():
    class cls:
        pass
    class mixin:
        pass
    class infer_missing:
        pass
    assert schema(cls, mixin, infer_missing) == {}



# Generated at 2022-06-25 16:06:35.479525
# Unit test for function build_schema
def test_build_schema():
    @dataclass(eq=False)
    class ABC:
        a: int
        b: str
        c: float
        d: typing.List[int]

    cls = ABC
    mixin = ABC
    infer_missing = True
    partial = False
    # Test case input
    # Test case expect
    # Test case output
    try:
        build_schema(cls, mixin, infer_missing, partial)
    except Exception as err:
        assert False, str(err)
    else:
        assert True
    # Test case input
    infer_missing = False
    # Test case expect
    # Test case output
    try:
        build_schema(cls, mixin, infer_missing, partial)
    except Exception as err:
        assert False, str(err)

# Generated at 2022-06-25 16:06:37.782246
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field.required is False


# Generated at 2022-06-25 16:06:48.604677
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    @dataclass
    class Foo:
        a: str
        b: int
        c: typing.List[int]
        d: typing.Dict[str, str]
        e: typing.Mapping[str, str]
        f: typing.MutableMapping[str, str]
        g: typing.Callable
        h: typing.Any
        i: int = 1

    schema_f = SchemaF()

# Generated at 2022-06-25 16:06:57.132573
# Unit test for function schema
def test_schema():
    import dataclasses_json.api as dataclasses_json

    class Mixin_0:
        field_many: bool

    class Simple_0(Mixin_0, schemabuilder=schema):
        a_0: int
        b_0: int = dataclasses_json.Field(metadata={
            'dataclasses_json': {
                'mm_field': fields.List(fields.Int)
            }
        })

    class Simple_1(Mixin_0, schemabuilder=schema):
        a_1: int
        b_1: int = dataclasses_json.Field(metadata={
            'dataclasses_json': {
                'mm_field': fields.List(fields.Int)
            }
        })


# Generated at 2022-06-25 16:06:59.712502
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    f = _TimestampField()
    assert f.load_from == 'timestamp'
    assert f.dump_to == 'timestamp'
    

# Generated at 2022-06-25 16:07:04.301272
# Unit test for function build_schema
def test_build_schema(): 
    # Set-up
    cls = None
    mixin = None
    infer_missing = True
    partial = True
    expected_type = Schema
    expected_result = SchemaType

    # Run
    result = build_schema(cls, mixin, infer_missing, partial)

    # Verify
    assert isinstance(result, expected_type)
    assert issubclass(result, expected_result)

# Generated at 2022-06-25 16:07:10.827867
# Unit test for function schema
def test_schema():
    # Define the mixin used by the dataclass

    class Mixin:
        pass

    # Define a dataclass
    @dataclass
    class A(Mixin):
        a: int = field(metadata=dict(dataclasses_json=dict(mm_field=fields.Str())))
        b: str
        c: typing.Mapping[str, typing.Optional[typing.List[int]]]

    assert schema(A, Mixin, infer_missing=False) == {
        'a': fields.Str(),
        'b': fields.Str(),
        'c': fields.Mapping(),
    }

# Generated at 2022-06-25 16:07:18.368310
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f_1 = SchemaF()
    s_f_1_test = schema_f_1.loads(b'1', many=False)
    s_f_2_test = schema_f_1.loads(b'[1]', many=True)
    s_f_3_test = schema_f_1.loads(b'[1]')
    s_f_4_test = schema_f_1.loads(b'1', many=True)


# Generated at 2022-06-25 16:09:00.592472
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    string_format = "test_format"

# Generated at 2022-06-25 16:09:01.741591
# Unit test for function build_schema
def test_build_schema():
    try:
        test_case_0()
        assert False
    except NotImplementedError:
        assert True

# Generated at 2022-06-25 16:09:11.545339
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    @dataclass
    class X:
        a: int
        b: int
        c: int

    @dataclass
    class Wrapper:
        xs: typing.List[X]

    @dataclass
    class Y:
        a: int
        b: int
        c: int

    @dataclass
    class Wrapper2:
        ys: typing.List[Y]

    schema_x_0 = SchemaF[X]()
    schema_wrapper_0 = SchemaF[Wrapper]()
    schema_y_0 = SchemaF[Y]()
    schema_wrapper_2 = SchemaF[Wrapper2]()

    schema_wrapper_0.loads(b'{"xs": [ {"a": 1, "b": 2, "c": 3} ]}')
    schema_

# Generated at 2022-06-25 16:09:17.919790
# Unit test for function schema
def test_schema():
    schema_f_0 = SchemaF()
    schema_f_1 = SchemaF()
    schema_f_2 = SchemaF()
    # print(type(schema_f_0))
    # print(type(schema_f_1))
    # print(type(schema_f_2))



# Generated at 2022-06-25 16:09:25.344237
# Unit test for function schema
def test_schema():
    class MyClass:
        a: str

    class MyMixin(dataclass_json.DataClassJsonMixin):
        def to_json(self):
            return {"a": self.a}

    class MyClass(MyMixin):
        a: str

    class MyClassSchema(SchemaType):

        class Meta:
            unknown = EXCLUDE

        @post_load
        def make_obj(self, data: typing.Dict[str, typing.Any], **_) -> MyClass:
            return MyClass.Schema().load(data)

    assert schema(MyClass, MyMixin, False) == {'a': fields.Str()}
    assert MyClassSchema().load({"a": "a"}) == MyClass("a")
    assert MyClassSchema().dump(MyClass("a"))

# Generated at 2022-06-25 16:09:26.836764
# Unit test for function build_type
def test_build_type():
    assert build_type(str, {}, None, None, None)



# Generated at 2022-06-25 16:09:32.090292
# Unit test for function schema
def test_schema():
    # Build template for testing
    class Mixin(object):
        def test_function(self):
            pass

        test_function.__func__.__annotations__['return'] = str

    class TestClass(Mixin):
        data: str

    # Test
    # Make sure that in the dataclass, a function is declared, but not in the schema
    result_schema = schema(TestClass, Mixin, False)
    assert {'data': fields.Field(default=None)} == result_schema

# Generated at 2022-06-25 16:09:43.364992
# Unit test for function schema
def test_schema():
    # Test case 0
    _is_new_type_0 = _is_new_type(1)
    assert _is_new_type_0 == False

    _is_new_type_1 = _is_new_type(CatchAllVar)
    assert _is_new_type_1 == True

    _is_new_type_2 = _is_new_type(int)
    assert _is_new_type_2 == False

    # Test case 1
    field = {"name": "test"}
    _infer_missing_0 = True
    mixin = Mixin
    cls = {"name": "test"}
    _test_1 = schema(cls, mixin, _infer_missing_0)
    assert _test_1 == {}

    # Test case 2

# Generated at 2022-06-25 16:09:45.598192
# Unit test for function build_type
def test_build_type():
    tu = typing.TypeVar('tu', str, int)
    class SchemaF(Schema, typing.Generic[tu]):
        pass



# Generated at 2022-06-25 16:09:46.443208
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    _TimestampField()
