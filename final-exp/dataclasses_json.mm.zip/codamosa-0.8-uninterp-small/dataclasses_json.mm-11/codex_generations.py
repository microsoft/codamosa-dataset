

# Generated at 2022-06-25 16:02:42.108714
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class ClassWithStr(object):
        def __init__(self, name: str):
            self.name = name

    class TestSchema(Schema):
        name = fields.Str()

    schema_f_1 = SchemaF[ClassWithStr]()
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        res_1 = schema_f_1.dump(ClassWithStr('Foo'))
        assert len(w) == 0
        res_2 = schema_f_1.dump([ClassWithStr('Foo'), ClassWithStr('Bar')])
        assert len(w) == 0
        # TestSchema is a subtype of SchemaF[A]
        schema_f_2 = TestSchema()
        res_3 = schema_f_2.dump

# Generated at 2022-06-25 16:02:49.587477
# Unit test for function schema
def test_schema():
    class QuizConverter(Schema):
        allow_unknown = True

        @post_load
        def make_quiz(self, data, **kwargs):
            return Quiz(**data)

    class Quiz(object):
        def __init__(self,
                     question: str,
                     published_at: datetime,
                     answers: list):
            self.question = question
            self.published_at = published_at
            self.answers = answers

    assert issubclass(QuizConverter, Schema)
    assert isinstance(QuizConverter(), QuizConverter)



# Generated at 2022-06-25 16:02:50.124204
# Unit test for function build_schema
def test_build_schema():
    pass

# Generated at 2022-06-25 16:02:58.907352
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class BoundFoo(typing.Generic[A]):

        def __init__(self, x: A):
            self.x = x

    class Foo(typing.Generic[A]):

        def __init__(self, x: A, y: A):
            self.x = x
            self.y = y

    class Bar(typing.Generic[A]):

        def __init__(self, x: A, y: str):
            self.x = x
            self.y = y

    class BarFixed(typing.Generic[A]):

        def __init__(self, x: A, y: float):
            self.x = x
            self.y = y


# Generated at 2022-06-25 16:03:07.612408
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f_0 = SchemaF()
    schema_f_1 = SchemaF()
    schema_f_2 = SchemaF()
    schema_f_3 = SchemaF()
    schema_f_4 = SchemaF()
    schema_f_5 = SchemaF()
    schema_f_6 = SchemaF()
    schema_f_7 = SchemaF()
    schema_f_8 = SchemaF()
    schema_f_9 = SchemaF()
    schema_f_10 = SchemaF()
    schema_f_11 = SchemaF()
    schema_f_12 = SchemaF()
    schema_f_13 = SchemaF()
    schema_f_14 = SchemaF()
    schema_f_15 = SchemaF()

# Generated at 2022-06-25 16:03:18.430289
# Unit test for function schema
def test_schema():
    class Encoder(_ExtendedEncoder):
        def default(self, o):
            if hasattr(o, '__schema__'):
                return o.__schema__()
            return super().default(o)

    class Person:
        def __init__(self, name):
            self.name = name

    class User:
        def __init__(self, sub: Person, tags: list, active: bool = True, age: int = 10):
            self.sub = sub
            self.tags = tags
            self.active = active
            self.age = age

    def json_dumps(o):
        return json.dumps(o, cls=Encoder)

    @dataclass_json
    @dataclass
    class UserS:
        sub: Person
        tags: list
        active: bool

# Generated at 2022-06-25 16:03:20.250897
# Unit test for function build_type
def test_build_type():
    assert build_type(type_='', options={}, mixin='', field='', cls='')



# Generated at 2022-06-25 16:03:23.376406
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclasses.dataclass
    class C0:
        a: str
        b: int

    schema_f_0 = SchemaF[C0]()
    data_0 = 'abc'
    assert isinstance(schema_f_0.dumps(data_0), str)

# Generated at 2022-06-25 16:03:32.323358
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class DateTimeField(fields.Field):
        def _deserialize(self, value, attr, data, **kwargs):
            return datetime.fromisoformat(value)

    class Movie(SchemaF):
        name = fields.String(required=True)
        date = DateTimeField(required=True)

        @post_load
        def make_movie(self, data, **kwargs):
            return data['name'], data['date']

    class Actor(SchemaF):
        name = fields.String(required=True)
        movies = fields.Nested(Movie, many=True)

        @post_load
        def make_actor(self, data, **kwargs):
            return data['name'], data['movies']


# Generated at 2022-06-25 16:03:38.715885
# Unit test for function build_schema
def test_build_schema():
    # class test_case_0(Schema, typing.Generic[A]):
    #     # def __init__(self, *args, **kwargs):
    #         print("Type: ", type(SchemaF))
    #         super().__init__(*args, **kwargs)
    #         raise NotImplementedError()
    # schema_f_0 = test_case_0()
    # print("schema_f_0 Type: ", type(schema_f_0))
    try:
        schema_f_0 = SchemaF()
    except NotImplementedError:
        print("NotImplementedError: ", NotImplementedError)
        assert True
    print("schema_f_0 Type: ", type(schema_f_0))


# Generated at 2022-06-25 16:03:58.657750
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f_0 = SchemaF()
    # Test case 1
    s_0: str = schema_f_0.loads(json_data=b'{"field_0": "string_0"}',
                                many=False, partial=False, unknown='EXCLUDE')
    s_0 = s_0 # type: str
    assert isinstance(s_0, str)


# Generated at 2022-06-25 16:04:09.318417
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Foo:
        val = 1

    class Foo2:
        val = 2

    @SchemaF.register_dump_handler(Foo)
    @SchemaF.register_dump_handler(Foo2)
    def dump_foo(foo, obj):
        return {
            'val': obj.val
        }

    class MySchema(SchemaF[Foo]):
        # val = fields.Int(required=True)

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.map_type_to_field(Foo, fields.Int(required=True))
            self.map_type_to_field(Foo2, fields.Int(required=True))

    schema = MySchema()

    data1 = Foo()

# Generated at 2022-06-25 16:04:12.938664
# Unit test for function build_type
def test_build_type():
    my_schema = SchemaF()
    my_field = dc_fields(my_schema)

# Now, let's test the other class in this module - SchemaF

# Generated at 2022-06-25 16:04:18.924997
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses import dataclass
    from typing import List
    @dataclass
    class Person:
      name: str
      age: int

    data = Person('John Doe', 42)
    schema = SchemaF[Person]()
    assert schema.dumps(data).startswith('{')

    data = [Person('John Doe', 42)]
    schema = SchemaF[List[Person]]()
    assert schema.dumps(data).startswith('[')


# Generated at 2022-06-25 16:04:29.102978
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema_f = SchemaF()
    obj = ['a']
    many = True
    T = typing.TypeVar('T')
    assert isinstance(T, type)
    T = typing.TypeVar('T', bound='SchemaF')
    assert isinstance(T, type)
    ans = schema_f.dump(obj, many)
    assert ans == obj
    assert isinstance(ans, typing.List)
    obj = 'b'
    many = False
    ans = schema_f.dump(obj, many)
    assert ans == obj
    assert isinstance(ans, str)
    obj = 'c'
    many = None
    ans = schema_f.dump(obj, many)
    assert ans == obj
    assert isinstance(ans, str)


# Generated at 2022-06-25 16:04:38.790473
# Unit test for function build_type
def test_build_type():
    # define dataclass
    class DataClass0(object):
        class Schema0(Schema):
            # Serialize dataclass
            def serialize(self, dataclass, **kwargs):
                return {}
            # Deserialize dataclass
            def deserialize(self, dataclass, **kwargs):
                return {}

    # define dataclass
    class DataClass1(DataClass0, object):
        class Schema1(Schema):
            # Serialize dataclass
            def serialize(self, dataclass, **kwargs):
                return {}
            # Deserialize dataclass
            def deserialize(self, dataclass, **kwargs):
                return {}

    # define dataclass

# Generated at 2022-06-25 16:04:39.595087
# Unit test for function build_type
def test_build_type():
    pass



# Generated at 2022-06-25 16:04:40.671084
# Unit test for function schema
def test_schema():
    ms = schema(TypeVar("A"), None, False)

# Generated at 2022-06-25 16:04:42.897393
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert(isinstance(_TimestampField(required=True, allow_none=False), _TimestampField))



# Generated at 2022-06-25 16:04:51.432246
# Unit test for function schema
def test_schema():
    # Build the dictionary
    class Mixin:
        schema_f_0 = SchemaF()
    class Student:
        name = 'Student'
    inner_field = dc_fields(Student)[0]
    inner_cls = Student
    inner_type_ = str
    inner_options = {}
    inner_mixin = Mixin
    inner_mapping = build_type(inner_type_, inner_options, inner_mixin, inner_field, inner_cls)
    inner_cls = Student
    inner_field = dc_fields(Student)[0]
    Student_dict = schema(inner_cls, inner_mixin, False)

    # Build the input
    options_0 = {}
    type_0 = str
    mm_field_0 = None

# Generated at 2022-06-25 16:06:00.283000
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    T = typing.TypeVar('T')

    class SchemaF0(Schema, typing.Generic[T]):
        @staticmethod
        def _load_generic(x: T) -> T:
            return x

    schema_f_0 = SchemaF0()

    class C0(typing.Generic[T]):
        def __init__(self, x: T):
            self.x = x

    class C1(typing.Generic[T]):
        def __init__(self, x: T):
            self.x = x

    def test_case_0():
        x = schema_f_0.loads(json.dumps(C0(1)), cls=C0)


# Generated at 2022-06-25 16:06:07.511021
# Unit test for function build_type
def test_build_type():
    @dataclass_json
    @dataclass
    class A:
        a: int
    @dataclass_json
    @dataclass
    class B:
        b: A
    type_ = B
    options = {}
    mixin = B
    class cls:
        __name__ = 'name'
    field = fields.Nested(A)
    assert type(build_type(type_, options, mixin, field, cls)) is fields.Nested


# Generated at 2022-06-25 16:06:08.804047
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_field = _IsoField()
    assert iso_field


# Generated at 2022-06-25 16:06:17.028113
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    for input_data in [[{'a': 1, 'b': 2}, {'a': 11, 'b': 12}],
                       [{'b': 2, 'a': 1}, {'b': 12, 'a': 11}],
                       [{'c': 2, 'a': 1}, {'b': 11, 'a': 11}]]:
        schema_f = SchemaF()
        schema_f.load(input_data, many=True)


# Generated at 2022-06-25 16:06:23.843536
# Unit test for function build_type
def test_build_type():
    options = {}
    type_ = int
    mixin = dataclasses_json.dataclass_json
    field = dc_fields(datetime)
    cls = datetime
    result = build_type(type_, options, mixin, field, cls)
    assert(result != None)
    assert(result != False)


# Generated at 2022-06-25 16:06:29.193929
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class P:
        x: int = 3

    @dataclass_json
    @dataclass
    class C:
        y: int = 5

    @dataclass_json
    @dataclass
    class A:
        z: int = 7

    @dataclass_json
    @dataclass
    class D:
        p: P = P()
        c: C = C()
        a: A = A()

    @dataclass_json
    @dataclass
    class G:
        d: D = D()

    mixin = typing.Any  # Get a fresh empty mixin
    infer_missing = True
    partial = False  # We don't have undefined fields

# Generated at 2022-06-25 16:06:30.946564
# Unit test for function build_type
def test_build_type():
    schema_f_0_schema = schema_f_0.Schema()


# Generated at 2022-06-25 16:06:32.308741
# Unit test for function schema
def test_schema():
  schema()


# Generated at 2022-06-25 16:06:42.586142
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class SubTestSchemaF(SchemaF):
        a = fields.Int()
        b = fields.Int()

    assert SubTestSchemaF().dump(SubTestSchemaF(strict=True).load({'a': 1, 'b': 2})) == {'a': 1, 'b': 2}
    assert SubTestSchemaF().dump([SubTestSchemaF(strict=True).load({'a': 1, 'b': 2}), SubTestSchemaF(strict=True).load({'a': 3, 'b': 4})], many=True) == [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]


# Generated at 2022-06-25 16:06:44.567722
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    test = _TimestampField()
    assert isinstance(test, fields.Field)


# Generated at 2022-06-25 16:08:01.564022
# Unit test for function build_schema
def test_build_schema():
    from dataclass_factory import SchemaF
    from dataclass_factory import _build_schema as build

    x = build(SchemaF, None, True, True)
    assert x == SchemaF


# Generated at 2022-06-25 16:08:04.357274
# Unit test for function build_schema
def test_build_schema():
    class Foo:
        @dataclass_json
        @dataclass
        class Inner:
            field: str

        field: Inner

    build_schema(Foo, None, True, False)

# Generated at 2022-06-25 16:08:11.910245
# Unit test for function schema
def test_schema():
    # Case 0:
    # Test with an empty class
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin
    @dataclass(repr=False)
    class SampleClass0(DataClassJsonMixin):
        pass
    assert schema(SampleClass0, DataClassJsonMixin, infer_missing=True) == {}

    # Case 1:
    # Test with a normal class
    @dataclass(repr=False)
    class SampleClass1(DataClassJsonMixin):
        val1: int
        val2: str
    assert schema(SampleClass1, DataClassJsonMixin, infer_missing=True) == {
        'val1': fields.Int(),  # inferred
        'val2': fields.Str(),  # inferred
    }

    #

# Generated at 2022-06-25 16:08:13.861011
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema_f_0 = SchemaF()
    schema_f_0.dumps()


# Generated at 2022-06-25 16:08:22.305611
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class UUIDClass():
        def __init__(self, value: int):
            self._value = value

        def __hash__(self) -> int:
            return self._value

        def __eq__(self, other) -> bool:
            return self._value == other._value

        def __ne__(self, other) -> bool:
            return self._value != other._value

        @classmethod
        def from_hash(cls, value: int) -> "UUIDClass":
            return cls(value)

        def __repr__(self):
            return str(self._value)

        def __str__(self):
            return str(self._value)

    class Obj_1():
        pass

    class Obj_2():
        pass

    class Obj_3():
        pass


# Generated at 2022-06-25 16:08:28.297072
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # Generic type variable annotation is int
    schema_f_1 = SchemaF[int]()
    # Generic type variable annotation is str
    schema_f_2 = SchemaF[str]()
    # Generic type variable annotation is int
    schema_f_1.dumps(123)
    # Generic type variable annotation is str
    schema_f_2.dumps("abc")
    # Generic type variable annotation is int
    schema_f_1.dumps([1,2,3])
    # Generic type variable annotation is str
    schema_f_2.dumps(["a", "b", "c"])



# Generated at 2022-06-25 16:08:32.819948
# Unit test for function schema
def test_schema():
    class Test0:
        a: int
    var_schema = schema(Test0, Schema, True)
    assert isinstance(var_schema['a'], fields.Int)



# Generated at 2022-06-25 16:08:37.405233
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema_f_1 = SchemaF()
    schema_f_1.dump([1, 2, 3], many=True)
    schema_f_1.dump([1, 2, 3])
    schema_f_1.dump(1)



# Generated at 2022-06-25 16:08:37.754807
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    pass


# Generated at 2022-06-25 16:08:47.321026
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class DataClassSchema:
        field1: str = MISSING
        field2: int = MISSING
        field3: typing.List[int] = MISSING
        b: UUID = MISSING
        x: Decimal = MISSING
        c: typing.Union[str, int, None] = MISSING
        d: typing.Optional[int] = MISSING
        e: typing.Optional[typing.Optional[str]] = MISSING
        f: typing.Callable = MISSING
        g: typing.MutableMapping = MISSING
        h: typing.MutableMapping[UUID, str] = MISSING
        i: typing.List[UUID] = MISSING


# Generated at 2022-06-25 16:12:00.696975
# Unit test for constructor of class _IsoField
def test__IsoField():

    # Case 0:
    # Verify that _IsoField can be instantiated with no arguments
    test_case_0()


# Generated at 2022-06-25 16:12:05.015681
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    test = _TimestampField()
    assert isinstance(test, _TimestampField)



# Generated at 2022-06-25 16:12:11.735451
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclasses.dataclass
    class Base:
        name: str = dataclasses.field(default_factory=lambda: "")

    @dataclasses.dataclass
    class A(Base):
        value: int = dataclasses.field(default_factory=lambda: 0)

    class ASchema(SchemaF[A]):
        class Meta:
            unknown = 'EXCLUDE'

    d = A('hello', 42)
    schema = ASchema()
    expected = {'name': 'hello', 'value': 42}
    result = schema.dump(d)
    assert expected == result, "dump A failed"
