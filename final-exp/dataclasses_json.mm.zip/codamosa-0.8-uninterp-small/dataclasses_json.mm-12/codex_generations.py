

# Generated at 2022-06-25 16:02:50.989325
# Unit test for constructor of class _IsoField
def test__IsoField():
    obj_0 = _IsoField()
    dict_0 = {
        'attribute_map': {},
        'missing': '',
        'missing_str': '',
        'required': '',
        'allow_none': '',
        'load_from': '',
        'dump_to': '',
        'error_messages': {},
        'data_key': '',
        'load_only': '',
        'dump_only': '',
        'validate_always': '',
        'load_field_name': '',
        'allow_none': '',
        'default': ''
    }
    dict_1 = obj_0.__dict__
    assert dict_1 == dict_0


# Generated at 2022-06-25 16:03:02.715670
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass, field

    @dataclass
    class E:
        a: int

    @dataclass
    class D:
        c: str
        d: E

    @dataclass
    class C:
        b: D
        c: str

    @dataclass
    class B:
        a: C

    @dataclass
    class A:
        a: B

    a_sch = build_schema(A, mixin={}, infer_missing=False, partial=False)
    a_inst = A(a=B(a=C(b=D(c="test", d=E(a=1)), c="test")))

    assert a_inst == a_sch().load(a_sch().dump(a_inst))

# Generated at 2022-06-25 16:03:14.803342
# Unit test for function build_type
def test_build_type():
    def side_effect_schema_f_0():
        return schema_f_0

    def side_effect_schema_f_1(arg_schema_f_1):
        return schema_f_1

    def side_effect_schema_f_2(arg_schema_f_2, default=dict_1):
        return schema_f_2

    def side_effect_schema_f_3(arg_schema_f_3, allow_none=arg_allow_none_3):
        return schema_f_3

    schema_f_0 = SchemaF()
    schema_f_0.load = Mock(side_effect=side_effect_schema_f_0)
    schema_f_0.loads = Mock(side_effect=side_effect_schema_f_0)


# Generated at 2022-06-25 16:03:22.968029
# Unit test for function build_schema

# Generated at 2022-06-25 16:03:25.136866
# Unit test for function build_type
def test_build_type():
    class TestDataclass:
        x: int = 0
        y: int = 0

    m = TestDataclass()
    build_type(type(m), {}, TestDataclass(), TestDataclass.x, TestDataclass)



# Generated at 2022-06-25 16:03:30.714865
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    try:
        # Test fail case of function loads
        # ValueError: 'List[int]' is not a subclass of type 'type'
        # while testing with these values:
        #  - json_data: '[]'
        #  - kwargs: {}
        #  - many: False
        #  - partial: None
        #  - unknown: None
        _mocked_schema_0 = SchemaF()
        _mocked_kwargs_0 = {}
        assert _mocked_schema_0.loads('[]', many=False, **_mocked_kwargs_0) == _mocked_schema_0.loads('[]', many=False, **_mocked_kwargs_0)
    except:
        pass


# Generated at 2022-06-25 16:03:31.618008
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field_0 = _TimestampField()



# Generated at 2022-06-25 16:03:36.936576
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass

    @dataclass(frozen=True)
    class Example:
        name: str

    schema_0 = build_schema(Example, "schema", 0, 0)
    assert len(schema_0.__dict__) > 0
    assert len(schema_0.__dict__['_declared_fields']) == 1
    assert type(schema_0.__dict__['_declared_fields']['name']) is fields.Str
    assert type(schema_0.__dict__['_declared_fields']['name'].metadata) is dict


# Generated at 2022-06-25 16:03:37.762397
# Unit test for constructor of class _IsoField
def test__IsoField():
    field_f_0 = _IsoField()


# Generated at 2022-06-25 16:03:40.015476
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    dict_0 = {}
    schema_f_0 = SchemaF()
    assert schema_f_0.load(data=dict_0) is None, "test_case_0 failed"


# Generated at 2022-06-25 16:03:58.965643
# Unit test for function schema
def test_schema():
    class User:
        name: str
        weight: float
        active: bool
        id: typing.Optional[int]

    cls_0 = User
    mixin_0 = SchemaType
    infer_missing_0 = False
    ret_val_0 = schema(cls_0, mixin_0, infer_missing_0)

# Generated at 2022-06-25 16:04:05.619628
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class ForTest_SchemaF_dumps(SchemaF):
        id = fields.Int(required=True,
                        allow_none=False)  # type: ignore
        text = fields.Str(required=True,
                          allow_none=False)  # type: ignore

    dc_str = """\
    from dataclasses import dataclass
    @dataclass
    class Hello:
        id: int
        text: str
    """
    dc_hello = _decode_dataclass(dc_str, globals_=globals())
    hello = dc_hello(id=1, text='world')  # type: ignore

    schema_f = ForTest_SchemaF_dumps()
    res = schema_f.dumps(hello)

# Generated at 2022-06-25 16:04:10.460373
# Unit test for function build_schema
def test_build_schema():
    class Mixin(ABC):
        pass

    # ...

    class Config(Mixin):
        config_path = "./config.yaml"
        config_parsed = None

        def __post_init__(self) -> None:
            self.config_parsed = self.open_config()

        def open_config(self) -> None:
            return {}

    config = Config()

    from pprint import pprint

    pprint(schema(config.__class__, Mixin, False))

    # ...

    class Base(Generic[A, B]):
        config: A
        logger: B

        def __init__(self, config: A, logger: B) -> None:
            self.config = config
            self.logger = logger


# Generated at 2022-06-25 16:04:17.744006
# Unit test for function build_schema
def test_build_schema():
    class Schema0(metaclass=SchemaMeta):
        i: int
        f: float
        s: str
        b: bool
        nullable_i: typing.Optional[int]

    class Schema1(metaclass=SchemaMeta, infer_missing=True):
        i: int
        f: float
        s: str
        b: bool
        nullable_i: typing.Optional[int]

    class Schema2(metaclass=SchemaMeta, infer_missing=True):
        i: int
        f: float
        s: str
        b: bool
        nullable_i: typing.Optional[int]
        n: typing.Optional[int] = None

    class Schema3(metaclass=SchemaMeta, infer_missing=True):
        i: int
        f: float


# Generated at 2022-06-25 16:04:25.810024
# Unit test for function build_schema
def test_build_schema():
    from typing import Optional

    import dataclasses
    import marshmallow
    from marshmallow import Schema, fields, post_load

    # DataClassSchema = build_schema(User, type(None), False, False)
    # assert isinstance(DataClassSchema, type)
    # assert issubclass(DataClassSchema, Schema)
    print("test_build_schema: Passed")


if __name__ == "__main__":
    test_build_schema()

# Generated at 2022-06-25 16:04:35.955889
# Unit test for function build_type
def test_build_type():
    # Test case 0
    # Union Type with str type
    origin_0 = typing.Union
    type_0 = typing.Union[str]
    options_0 = {}
    mixin_0 = JsonSchemaMixin
    field_0 = field = typing.NamedTuple(
        '_param', [('default', typing.Set[str]), ('default_factory', int),
                   ('init', bool), ('repr', bool), ('eq', bool),
                   ('order', bool), ('unsafe_hash', bool),
                   ('frozen', bool)])._field
    cls_0 = typing.NamedTuple
    iso_field_0 = build_type(type_=type_0, options=options_0, mixin=mixin_0, field=field_0, cls=cls_0)
   

# Generated at 2022-06-25 16:04:41.928135
# Unit test for function schema
def test_schema():
    class Field0:
        name = 'f0'
        type = float
        default = MISSING
        default_factory = MISSING
        metadata = {'dataclasses_json': {'mm_field': fields.Field}}

    class Field1:
        name = 'f1'
        type = float
        default = 1
        default_factory = MISSING
        metadata = {'dataclasses_json': {'mm_field': fields.Field}}

    class Field2:
        name = 'f2'
        type = typing.Optional[float]
        default = MISSING
        default_factory = MISSING
        metadata = {'dataclasses_json': {'mm_field': fields.Field}}

    class Field3:
        name = 'f3'
        type = typing.Optional[float]

# Generated at 2022-06-25 16:04:50.868640
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass

    class Schema(SchemaType):
        @post_load
        def make_obj(self, data, **kwargs):
            return _decode_dataclass(self.__dataclass__, data)

    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class A(DataClassJsonMixin):
        # class A(DataClassJsonMixin):
        b: int

    r = schema(A, DataClassJsonMixin, False)
    assert A.schema() == r
    assert A.schema().make_obj({"b": 123}) == A(b=123)
    assert A.schema().loads("{\"b\": 123}") == A(b=123)

# Generated at 2022-06-25 16:04:53.631399
# Unit test for function schema
def test_schema():
    class T(SchemaType):
        pass

    assert '__type' in schema(T, SchemaType, True)
    assert '__schema' not in schema(T, SchemaType, True)


# Generated at 2022-06-25 16:04:56.366588
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class MyTestCls:
        x: str
        y: str
        z: int

    my_test_cls_schema = build_schema(MyTestCls, mixin, _infer_missing, _partial)
    assert my_test_cls_schema is not None



# Generated at 2022-06-25 16:05:18.218866
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from enum import IntEnum
    import typing

    @dataclass_json
    @dataclass
    class S0(DataclassJsonMixin):
        my_map: typing.Mapping[str, int]
        my_list: List[int] = None
        my_dict: dict = dataclasses.field(metadata=dict(mm_field=fields.URL))
        my_mutable_mapping: typing.MutableMapping[str, int] = None
        my_tuple: typing.Tuple[float, float] = None
        my_callable: Callable[[str], str] = None
        my_any: typing.Any = None
        my_dict2: dict = None
        my_list

# Generated at 2022-06-25 16:05:21.305333
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    f = _TimestampField()
    assert f.__class__.__name__ == '_TimestampField'
    assert f.__class__.__module__ == 'dataclasses_json.mm_schema'


# Generated at 2022-06-25 16:05:28.553620
# Unit test for function build_schema
def test_build_schema():
    from typing import List

    @dataclass_json
    @dataclass(frozen=True)
    class Foo:
        id: int
        # name: str
        # address: Optional[str] = None

    schema_f_0 = build_schema(Foo, True, {})
    assert schema_f_0 == {'id': fields.Int}
    assert isinstance(schema_f_0, type)

    schema_f_1 = build_schema(Foo, False, {})
    assert schema_f_1 == {'id': fields.Int}
    assert isinstance(schema_f_1, type)

    @dataclass_json
    @dataclass(frozen=True)
    class Bar():
        id: int
        name: str
        # address: Optional[str

# Generated at 2022-06-25 16:05:34.173278
# Unit test for function build_schema
def test_build_schema():
    class Event(typing.NamedTuple):
        event_type: str
        data: typing.Dict[str, typing.Any]

    class EventSchema(SchemaType[Event]):
        event_type: str
        data: typing.Dict[str, typing.Any]

    return EventSchema().load({"event_type": "start", "data": {}})


if __name__ == "__main__":
    ret = test_build_schema()
    print(ret)

# Generated at 2022-06-25 16:05:39.288982
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    schema_f = SchemaF.load


# Generated at 2022-06-25 16:05:47.718332
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class S(SchemaF[A]):
        pass

    def check_dumps(obj, schema_f, many, exp_res):
        res = schema_f.dumps(obj, many)
        assert res == exp_res

    class A:
        pass

    class B:
        pass

    class C:
        pass

    a = A()
    b = B()
    c = C()
    bb = [b]
    cc = [c]


# Generated at 2022-06-25 16:05:58.981545
# Unit test for function schema
def test_schema():
    # Test case 0
    class test_class_0:
        pass
    class M:
        pass
    mm_result = schema(test_class_0, M, False)
    assert isinstance(mm_result, dict)
    # Test case 1
    class test_class_1(M):
        pass
    mm_result = schema(test_class_1, M, False)
    assert isinstance(mm_result, dict)
    # Test case 2
    class test_class_2(M):
        test_field = fields.Nested(test_class_1.schema())
    mm_result = schema(test_class_2, M, False)
    assert isinstance(mm_result, dict)
    # Test case 3
    class test_class_3(M):
        test_field = fields.Nested

# Generated at 2022-06-25 16:06:09.213326
# Unit test for function build_type
def test_build_type():
    # Case 0
    schema_f_0 = SchemaF()
    # This condition is not possible to be true because of the NotImplementedError
    # in the __init__ method.
    if(isinstance(schema_f_0, SchemaType) == True):
        pass
    else:
        assert False

    # Case 1
    import dataclasses
    import typing

    from dataclasses_json.api import _ConfigBase, DataclassDecorator

    @DataclassDecorator
    @dataclasses.dataclass
    class _Config(DataclassDecorator, _ConfigBase):
        unknown: typing.Optional[str] = None
        mm_field: typing.Any = None
        mm_schema_args: typing.Any = None
        mm_schema_kwargs: typing.Any

# Generated at 2022-06-25 16:06:14.442259
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    test_case_0()
    
test_SchemaF_load()

# Generated at 2022-06-25 16:06:26.191921
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema_f_1 = SchemaF()
    test_case_1_result = schema_f_1.dump(  # type: ignore
            [1, 2, 3, 4], many=False)  # type: ignore
    assert type(test_case_1_result)  == list
    for e in test_case_1_result:
        assert type(e)  == int
    test_case_2_result = schema_f_1.dump(  # type: ignore
            1, many=False)  # type: ignore
    assert type(test_case_2_result)  == int


# Generated at 2022-06-25 16:06:57.143593
# Unit test for function schema
def test_schema():
    # test for schema function
    class A:
        pass
    from dataclasses import dataclass

    @dataclass(frozen=True)
    class TestSchema:
        """Fake Test class for testing schema()"""
        i: int
        b: bool
        j: int = 0
        a: typing.List[int] = [1, 2, 3]

    schema_dict = schema(TestSchema, {}, False)
    assert (schema_dict['i'] == fields.Int(missing=0, allow_none=False))
    assert (schema_dict['b'] == fields.Bool(missing=False, allow_none=False))
    assert (schema_dict['j'] == fields.Int(missing=0, allow_none=False))

# Generated at 2022-06-25 16:06:59.502501
# Unit test for function schema
def test_schema():
    schema_f_0 = schema(None, None, None)
    if not isinstance(schema_f_0, dict):
        raise Exception



# Generated at 2022-06-25 16:07:00.474509
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert isinstance(_IsoField, fields.Field)


# Generated at 2022-06-25 16:07:11.151120
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass, field

    @dataclass
    class User:
        id: int
        name: str

    class UserMixin:
        @property
        def schema(self):
            return {
                'id': fields.Int(required=True),
                'name': fields.Str(required=True, allow_none=False)
            }

    @dataclass
    class UserW(UserMixin):
        id: int
        name: str
        age: int

    schema_f_1 = SchemaF()
    assert schema_f_1.schema == {}

    # There is no inherited class. So, we don't have to care about the mixin.
    schema_f_2 = SchemaF(User)
    schema_f_2_json = schema_f_2.dumps

# Generated at 2022-06-25 16:07:22.548539
# Unit test for function schema
def test_schema():
    import typing
    import unittest
    import warnings
    from dataclasses import dataclass, field
    from dataclasses_json import dataclass_json
    from dataclasses_json.mm import SchemaMM

    @dataclass_json(mm_schema=True)
    @dataclass
    class MySchema:
        foo: int
        bar: str = 'bar'

    class MyMixin:
        schema = schema(MySchema, MyMixin, False)

    def test_0():
        MySchema.schema

    def test_1():
        s = SchemaF()
        s.schema

    def test_2():
        @schema(MySchema, MyMixin, False)
        class MySchema:
            foo: int
            bar: str = 'bar'

# Generated at 2022-06-25 16:07:30.712370
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    schema_f_1 = SchemaF()
    schema_f_1.load([])
    schema_f_2 = SchemaF()
    schema_f_2.load({})
    schema_f_3 = SchemaF()
    schema_f_3.load([], many=True)
    schema_f_4 = SchemaF()
    schema_f_4.load({}, many=False)
    schema_f_5 = SchemaF()
    schema_f_5.load([], many=True, partial=True)
    schema_f_6 = SchemaF()
    schema_f_6.load({}, many=False, partial=False)
    schema_f_7 = SchemaF()
    schema_f_7.load([], many=True, unknown='strict')
    schema_f_

# Generated at 2022-06-25 16:07:34.320935
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclass
    class Test:
        b: bool

    schema_f_0 = SchemaF()
    json_data_0_0 =  schema_f_0.dumps(Test(True))
    json_data_0_1 =  schema_f_0.dumps([Test(True), Test(False)])


# Generated at 2022-06-25 16:07:35.475930
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    obj = 'hi'
    SchemaF().dumps(obj, many=None)


# Generated at 2022-06-25 16:07:40.502647
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    type_arg_1 = typing.List[int]
    class_arg_1 = typing.MutableSequence
    type_arg_2 = typing.MutableSequence
    schema_arg_1 = fields.List
    instance_arg_1 = fields.List()
    value_arg_1 = type_arg_1
    instance_arg_2 = fields.List()
    is_value_arg_1_none = True
    is_value_arg_2_none = True
    is_value_arg_3_none = True
    value_arg_2 = type_arg_1
    is_value_arg_4_none = True

    assert is_value_arg_1_none == False
    assert is_value_arg_2_none == False
    assert is_value_arg_3_none == False

# Generated at 2022-06-25 16:07:43.707164
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    schema_f_1 = SchemaF()
    load_result_1 = schema_f_1.load('str')


# Generated at 2022-06-25 16:09:17.853344
# Unit test for function build_schema
def test_build_schema():
    pass

# Generated at 2022-06-25 16:09:19.346132
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    _TimestampField()


# Generated at 2022-06-25 16:09:25.255885
# Unit test for function build_schema
def test_build_schema():
    from marshmallow import fields
    from dataclasses import dataclass, field
    from dataclasses_json import dataclass_json, config
    @dataclass
    class TestSchema0:
        test_field: str
    d = TestSchema0("test")
    TestS = build_schema(cls=TestSchema0, mixin=None, infer_missing=False, partial=False)
    assert type(TestS.Meta) == type
    assert TestS.Meta.fields == ("test_field",)
    assert TestS.schema["test_field"] == fields.Str()
    assert isinstance(TestS().load({"test_field": "test"}), TestSchema0)


# Generated at 2022-06-25 16:09:30.985074
# Unit test for function build_schema
def test_build_schema():
    def _test_schema(cls: typing.Type[A],
                     mixin,
                     infer_missing,
                     partial) -> typing.Type[SchemaType]:
        Meta = type('Meta',
                    (),
                    {'fields': tuple(field.name for field in dc_fields(cls)
                                     if
                                     field.name != 'dataclass_json_config' and field.type !=
                                     typing.Optional[CatchAllVar]),
                     # TODO #180
                     # 'render_module': global_config.json_module
                     })

        @post_load
        def make_instance(self, kvs, **kwargs):
            return _decode_dataclass(cls, kvs, partial)


# Generated at 2022-06-25 16:09:35.433088
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class Test_0:
        __str_0 = 'str_0'
        __str_1 = 'str_1'
        __str_2 = 'str_2'
        __str_3 = 'str_3'
        __int_0 = 0
        __int_1 = 1
        __int_2 = 2
        __int_3 = 3
    class_0 = Test_0()
    str_0 = class_0.__str_0
    str_1 = class_0.__str_1
    str_2 = class_0.__str_2
    str_3 = class_0.__str_3
    int_0 = class_0.__int_0
    int_1 = class_0.__int_1
    int_2

# Generated at 2022-06-25 16:09:44.569656
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    schema_f_0 = SchemaF()

    # loading from bytes raises exception
    try:
        result = schema_f_0.loads(
            b'[{"__type": "DATACLASS_NAME", "field_name": "field_value"}]',
            many=True)
        passed = False
    except TypeError:
        passed = True
    assert passed is True

    # loading from bytes raises exception
    try:
        result = schema_f_0.loads(b'{"__type": "DATACLASS_NAME", "field_name": "field_value"}',
                                  many=False)
        passed = False
    except TypeError:
        passed = True
    assert passed is True

    # loading from string raises exception

# Generated at 2022-06-25 16:09:53.091313
# Unit test for function build_schema
def test_build_schema():
    class ClassA:
        class_a: typing.Union[str, typing.Optional[str]]
    class ClassB(ClassA, dataclass_json.DataClassJsonMixin, dataclass_json.Config):
        class_b: typing.Union[str, typing.Optional[str]]
    class C(ClassB):
        class_c: typing.Union[str, typing.Optional[str]]
    class ClassD:
        class_b: typing.Union[str, typing.Optional[str]]
    class ClassE(ClassD):
        class_c: typing.Union[str, typing.Optional[str]]

    classA = build_schema(ClassA, dataclass_json.DataClassJsonMixin, False, False)

# Generated at 2022-06-25 16:09:57.874906
# Unit test for constructor of class _IsoField
def test__IsoField():
    try:
        f_0 = _IsoField()
    except:
        print("could not instanciate _IsoField")


# Generated at 2022-06-25 16:10:10.860224
# Unit test for function schema
def test_schema():
    import typing

    import dataclasses
    import pytest
    from marshmallow import Missing

    # Base schema test
    # Simple dataclass
    @dataclasses.dataclass
    class Person:
        name: str
        age: int

    expected_schema_Person = {
        'name': marshmallow.fields.Str(),
        'age': marshmallow.fields.Int()
    }

    assert(expected_schema_Person == schema(Person, None, False))

    # Optional dataclass
    @dataclasses.dataclass
    class OptionalPerson:
        name: typing.Optional[str]
        age: typing.Optional[str]


# Generated at 2022-06-25 16:10:12.863737
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    assert True
