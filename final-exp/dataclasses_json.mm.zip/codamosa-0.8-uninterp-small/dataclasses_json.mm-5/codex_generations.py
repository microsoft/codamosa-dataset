

# Generated at 2022-06-25 16:02:41.131802
# Unit test for function build_schema
def test_build_schema():
    class TestSchema(Schema):
        id = fields.Int(metadata={"dataclass_json": {"letter_case": "camel"}})
        name = fields.Str(required=True)

    class TestSchema2(Schema):
        id = fields.Int(metadata={"dataclass_json": {"letter_case": "camel"}})
        name = fields.Str(required=True)

    class Person:
        pass

    t = build_schema(Person, None, infer_missing=True, partial=False)
    assert t is not None
    assert t is not TestSchema
    assert t is not TestSchema2

    t2 = build_schema(Person, None, infer_missing=True, partial=False)
    assert t2 is not None
    assert t2 is not TestSchema

# Generated at 2022-06-25 16:02:48.775172
# Unit test for function schema
def test_schema():
    from core import DC, _user_overrides_or_exts
    class Override(DC):
        foo: str

        class MM:
            mm_field = fields.Str(allow_none=True)

    class NoOverride(DC):
        foo: str

    overrides = _user_overrides_or_exts(Override)
    assert isinstance(overrides[("foo")], Override.MM)

    overrides = _user_overrides_or_exts(NoOverride)
    assert not isinstance(overrides[("foo")], NoOverride.MM)


# Generated at 2022-06-25 16:02:52.608609
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    str_0 = "gPP;FQ4*8[<'1"
    schema_f_0 = SchemaF()

    # Method loads of class SchemaF
    data = schema_f_0.loads(str_0)



# Generated at 2022-06-25 16:03:04.514097
# Unit test for function build_schema
def test_build_schema():
    class A:
        pass

    class B:
        pass

    class C:
        pass
    class MySchema(SchemaType[B]):
        pass
    MySchema.__name__ = 'MySchema'

    class MySchema2(SchemaType[C]):
        pass
    MySchema2.__name__ = 'MySchema2'

    @dataclass_json
    @dataclass
    class MyDataClass:
        a: A
        b: typing.List[B]
        c: typing.List[C]
        d: MySchema
        e: MySchema2
        f: typing.List[MySchema]
        g: typing.List[MySchema2]


# Generated at 2022-06-25 16:03:12.609134
# Unit test for constructor of class _IsoField
def test__IsoField():
    schema_f_0 = SchemaF()
    assert isinstance(_IsoField(allow_none=True,
                                error_messages={'required': 'Field is required'},
                                missing=None,
                                missing_error=None,
                                required=True,
                                validate=None,
                                allow_none=True), _IsoField)
    str_0 = "gPP;FQ4*8[<'1"
    schema_f_0.test_0(str_0)

test_case_0()

# Generated at 2022-06-25 16:03:22.081220
# Unit test for constructor of class _IsoField
def test__IsoField():
    field_0 = _IsoField(attribute=None, default=None, load_from=None, dump_to=None, missing=None, validate=None, allow_none=True, error_messages=None)
    field_0_0 = _IsoField(attribute='str_1', default=None, load_from=None, dump_to=None, missing='str_0', validate=None, allow_none=True, error_messages={'str_2': 'str_3'})
    field_1 = _IsoField(attribute=None, default=None, load_from=None, dump_to=None, missing=None, validate=None, allow_none=True, error_messages=None)

# Generated at 2022-06-25 16:03:31.670781
# Unit test for function build_schema
def test_build_schema():
    import json
    
    from datetime import datetime
    from uuid import UUID
    from decimal import Decimal
    from enum import Enum
    from typing import ClassVar
    from dataclasses import dataclass, asdict, asdict
    
    
    class LetterCase(Enum):
        LOWER_CAMEL = 1
        LOWER_SNAKE = 2
        UPPER_CAMEL = 3
        UPPER_SNAKE = 4
    
    
    @dataclass
    class TestDataClass(metaclass=SchemaMeta):
        num: int
        name: str
        time: datetime
        uuid: UUID
    
        big_num: Decimal = Decimal(0)
        lower_camel: typing.Optional[float] = None

# Generated at 2022-06-25 16:03:33.400596
# Unit test for function schema
def test_schema():
    schema(test_case_0,test_case_0,test_case_0)


# Generated at 2022-06-25 16:03:41.444322
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    str_0 = "^L"
    str_1 = "P"
    str_2 = "{"
    str_3 = ")"
    str_4 = "n"
    str_5 = "ge_0"
    str_6 = "p"
    schema_f_0 = SchemaF()
    assert_equals(schema_f_0.dumps(str_0,
            many=True,
            cls=None,
            indent=None,
            separators=None,
            allow_nan=False,
            default=str_1,
            sort_keys=False), str_2)

# Generated at 2022-06-25 16:03:49.235358
# Unit test for constructor of class _IsoField
def test__IsoField():
    str_0 = "gPP;FQ4*8[<'1"
    schema_f_0 = SchemaF()
    str_1 = "rph3G"

    _iso_field = _IsoField()
    str_0 = _iso_field._serialize(schema_f_0, str_0, str_1)
    schema_f_0 = _iso_field._deserialize(str_0, str_0, str_1)
    assert str_0 is not None
    assert schema_f_0 is not None
    assert isinstance(_iso_field, fields.Field) == True


# Generated at 2022-06-25 16:04:11.397304
# Unit test for function schema
def test_schema():
    def schema_0(cls, mixin, infer_missing):
        schema = {}
        overrides = _user_overrides_or_exts(cls)
        for field in dc_fields(cls):
            metadata = (field.metadata or {}).get('dataclasses_json', {})
            metadata = overrides[field.name]
            if metadata.mm_field is not None:
                schema[field.name] = metadata.mm_field
            else:
                type_ = field.type
                options = {}
                missing_key = 'missing' if infer_missing else 'default'
                if field.default is not MISSING:
                    options[missing_key] = field.default
                elif field.default_factory is not MISSING:
                    options[missing_key] = field.default_factory



# Generated at 2022-06-25 16:04:21.440232
# Unit test for function schema
def test_schema():

    # mock a class: cls
    class some_class:
        mm_field = None
        metadata = {'dataclasses_json': {
            'mm_field': None,
            'letter_case': None}}
        _field_type = typing.Dict
        def __init__(self, dict1):
            self.field = dict1
        def __getitem__(self, key):
            return self.field[key]

    field = some_class({'name': 'foo'})

    # mock a class: cls
    class some_class:
        mm_field = None
        metadata = {'dataclasses_json': {
            'mm_field': None,
            'letter_case': None}}
        _field_type = typing.Dict

# Generated at 2022-06-25 16:04:28.639659
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    str_0 = 'foo'

    dump_0 = field_0.dump
    load_0 = field_0.load
    load_1 = field_0.loads
    str_1 = 'foo'
    load_2 = field_0.loads(str_1, False)
    type_0 = type(load_2)
    if type_0 is str:
        str_2 = load_2
        str_3 = 'foo'
        pass


# Generated at 2022-06-25 16:04:38.794337
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    str_0 = 'foo'
    str_1 = 'test_SchemaF_dump.test_dump'
    str_2 = '{}'
    str_3 = str_1
    str_3 = str_2.format(str_3)
    str_4 = 'test_dump'
    str_4 = '{}.{}'.format(str_0, str_4)
    str_5 = 'test_SchemaF_dump.test_dump.test_dump'
    str_6 = str_2.format(str_5)
    str_7 = '{}.{}'.format(str_0, str_4)
    str_8 = '{}.{}'.format(str_7, str_4)
    str_9 = str_2.format(str_8)

# Unit test

# Generated at 2022-06-25 16:04:49.106383
# Unit test for function build_schema
def test_build_schema():
    global config
    global Missing
    # Test with missing dataclass type
    cls = missing_cls()
    mixin = config

    with pytest.raises(ValueError) as info:
        build_schema(cls, mixin, True, True)
    assert 'missing dataclass' in str(info.value)

    # Test with empty schema
    # Default config
    cls = empty_cls()
    mixin = config
    schema_ = build_schema(cls, mixin, True, True)
    assert schema_ is not None
    obj = {'dataclass_json_config': {}}
    schema_obj = schema_()
    # Load should fail with config dict

# Generated at 2022-06-25 16:04:55.339440
# Unit test for function build_schema
def test_build_schema():
    class Mixin:
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            pass

    @dataclass
    class User(Mixin):
        user_id: str = field(metadata={'dataclasses_json': {'mm_field': fields.Str()}})
        password: str = field(metadata={'dataclasses_json': {'mm_field': fields.Str()}})
        name: str = field(metadata={'dataclasses_json': {'mm_field': fields.Str()}})

    @dataclass
    class Post(Mixin):
        title: str = field(metadata={'dataclasses_json': {'mm_field': fields.Str()}})

# Generated at 2022-06-25 16:05:05.019243
# Unit test for function schema
def test_schema():
    from dataclasses import Field, MISSING, dataclass
    from dataclasses_json import dataclass_json
    from datetime import datetime
    from typing import Optional
    @dataclass_json
    @dataclass
    class Foo_0:
        name: str
        time: datetime
    field_0 = Field('name', str, False, False, False, False, False, None, None, None, 'metadata', MISSING)
    field_1 = Field('time', datetime, False, False, False, False, False, None, None, None, 'metadata', MISSING)
    mixin_0 = dataclass_json
    infer_missing_0 = True
    ret_3 = schema(Foo_0, mixin_0, infer_missing_0)

# Generated at 2022-06-25 16:05:06.544951
# Unit test for function schema
def test_schema():
    test_case_0()
    return

# Unit test driver

# Generated at 2022-06-25 16:05:17.480557
# Unit test for constructor of class _IsoField

# Generated at 2022-06-25 16:05:22.790899
# Unit test for function schema
def test_schema():
    import dataclasses
    from dataclasses import dataclass
    @dataclass
    class Foo:
        bar: str
        baz: int
    mixin = dataclasses.dataclass
    infer_missing = True
    cls = Foo

# Generated at 2022-06-25 16:05:35.968812
# Unit test for constructor of class _IsoField
def test__IsoField():
    str_0 = "gPP;FQ4*8[<'1"
    schema_f_0 = _IsoField()


# Generated at 2022-06-25 16:05:44.051172
# Unit test for function schema

# Generated at 2022-06-25 16:05:48.343808
# Unit test for function schema
def test_schema():
    import dataclasses_json

    @dataclasses_json.dataclass_json
    @dataclasses.dataclass()
    class TestSchemaClass0:
        test_schema_field_0: int
        test_schema_field_1: str
        test_schema_field_2: float
        test_schema_field_3: List
        test_schema_field_4: Dict
    test_schema_0 = schema(TestSchemaClass0, dataclasses_json.M, True)
    print(test_schema_0)

# Generated at 2022-06-25 16:05:59.332250
# Unit test for function build_schema
def test_build_schema():
    from .example_data import ClassA, ClassB
    from .example_data import ClassC, ClassD
    from .example_data import ClassE, ClassF
    import marshmallow
    #  dataclass_json.config(
    # Arbitrary keyword arguments (there are no required arugments,
    #  see :func:`dataclass_json.configure`)
    #  letter_case=lambda f: f.upper(),
    #  meta=True,
    #  encoder=json.JSONEncoder,
    #  decoder=json.JSONDecoder,
    #  json_module=json,
    #  plugins=None,
    #  sort_keys=False,
    #  namedtupled_as_object=False,
    #  tuple_as_array=False,
    #  keep_

# Generated at 2022-06-25 16:06:02.118442
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    str_0 = "gPP;FQ4*8[<'1"
    schema_f_0 = SchemaF()
    try:
        schema_f_0.dumps(str_0)
    except NotImplementedError:
        pass

# Generated at 2022-06-25 16:06:13.579223
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class DataClass(typing.Generic[A]):
        def __init__(self, a: A) -> None:
            self.a = a
        def __repr__(self) -> str:
            repr_0 = repr(self.a)
            return repr_0
    schema_f_0 = SchemaF[DataClass[int]]()
    dc = DataClass[int](42)
    ret_0 = schema_f_0.dump(dc)
    int_0 = 42
    ret_1 = schema_f_0.dump(int_0)
    str_0 = '{"a": 42}'
    ret_2 = schema_f_0.dump(ret_0)
    ret_3 = schema_f_0.dump(ret_0)
    ret_4 = schema_f_0.dump

# Generated at 2022-06-25 16:06:18.249551
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    client_data_0 = '{"client": {"client_name": "TRENDY/DYNAMIC", "client_id": "tinman"}}'
    schema_f_0 = SchemaF()


# Generated at 2022-06-25 16:06:20.020867
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    obj = _TimestampField()
    assert obj is not None


# Generated at 2022-06-25 16:06:26.490179
# Unit test for function schema
def test_schema():
    class TestMixin:
        ...
    class TestCls:
        ...
    test_field = "test_field"
    test_metadata = "test_metadata"
    TestField = type(test_field, (object,), {
        "type": "test_type",
        "metadata": {"dataclasses_json": test_metadata}
    })
    ret = schema(TestCls, TestMixin, False)
    assert type(ret) == dict



# Generated at 2022-06-25 16:06:29.448567
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    json_data_0 = "I[X9F(P_/[\"'2"
    schema_f_0 = SchemaF()
    schema_f_0.loads(json_data_0)


# Generated at 2022-06-25 16:07:00.821097
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    str_0 = ">|^2NGX<\x1f\x1d"
    schema_f_0 = SchemaF()
    schema_f_1 = SchemaF()
    test_instance_2 = None  # type: typing.List[float]
    test_instance_5 = None  # type: float
    schema_f_0.load(
        test_instance_5,
        many=None,
        partial=None,  # type: bool
        unknown=str_0)
    schema_f_1.load(
        test_instance_2,
        many=True,
        partial=None,  # type: bool
        unknown=str_0)


# Generated at 2022-06-25 16:07:11.482410
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class D(object):
        type_: str
        data: str
        data_str: str
        data_int: int
        data_int_optional: Optional[int]
        data_uuid: UUID
        data_uuid_optional: Optional[UUID]
        data_enumeration: EnumType
        data_or_data2: typing.Union[str, str]
        data_or_data3: typing.Optional[typing.Union[int, float]]
        data_or_int_optional_none: typing.Optional[typing.Union[int, int, int]]
        data_or_data4: typing.Optional[typing.Union[int, None]]
        data_or_data5: typing.Union[int, None]

    DataClassSchema = build_schema

# Generated at 2022-06-25 16:07:17.981109
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    str_0 = "gPP;FQ4*8[<'1"
    schema_f_0 = SchemaF()
    # Call method dumps of class SchemaF to str_1 and str_2.
    str_1 = schema_f_0.dumps(str_0)
    str_2 = schema_f_0.dumps(str_0, many=False)



# Generated at 2022-06-25 16:07:19.044878
# Unit test for constructor of class _IsoField
def test__IsoField():
    obj_0 = _IsoField()
    assert obj_0 is not None


# Generated at 2022-06-25 16:07:25.950662
# Unit test for function schema
def test_schema():
    @dataclass_json
    @dataclass
    class User:
        id: int
        name: str
        email: str
        created_at: datetime

    # Fill in the missing parameters
    User_schema = schema(User, dataclass_json._SerializableDataclass, False)

    assert User_schema == {
        'id': fields.Int(
            default=marshmallow.missing,
            data_key='id'),
        'name': fields.Str(
            default=marshmallow.missing,
            data_key='name'),
        'email': fields.Str(
            default=marshmallow.missing,
            data_key='email'),
        'created_at': _TimestampField(
            default=marshmallow.missing,
            data_key='created_at')
    }

# Generated at 2022-06-25 16:07:26.788885
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    schema = _TimestampField()



# Generated at 2022-06-25 16:07:27.698827
# Unit test for function build_schema
def test_build_schema(): 
    pass


# Generated at 2022-06-25 16:07:28.475600
# Unit test for function build_type
def test_build_type():
    return 0


# Generated at 2022-06-25 16:07:34.063180
# Unit test for method load of class SchemaF
def test_SchemaF_load():

    class UserSchema(Schema):
        name = fields.Str()
        age = fields.Int()

    schema_user = SchemaF[User]()

    data = {
        'name': 'Monty',
        'age': 81
    }

    # test load
    user = schema_user.load(data)
    assert user.name == data['name']
    assert user.age == data['age']

    # test load_many
    users = schema_user.load(data, many=True)
    assert len(users) == 1
    assert users[0].name == data['name']
    assert users[0].age == data['age']



# Generated at 2022-06-25 16:07:39.242505
# Unit test for function build_schema
def test_build_schema():
    print('Test build_schema function')
    class EnumTest(Enum):
        A = 1
        B = 2

    @dataclass
    class Test:
        a: str
        b: int
        c: EnumTest
        d: typing.Optional[int] = None
        e: typing.Optional[str] = None
        f: typing.List[str] = field(default_factory=list)

    @dataclass
    class Test2:
        g: str
        h: typing.Mapping[int, int] = field(default_factory=dict)
        i: typing.Union[str, int]
        j: typing.Optional[typing.Union[str, int]] = None

# Generated at 2022-06-25 16:08:30.289610
# Unit test for function build_schema
def test_build_schema():
    assert(build_schema)
    assert(build_schema(None, None, None, None))
    print("Function build_schema... Pass")



# Generated at 2022-06-25 16:08:38.185478
# Unit test for function build_type
def test_build_type():
    try:
        # Test build_type for exception raised
        # Test for missing parameter type_
        try:
            test_case_0()
        except:
            raise NameError("Failed to test missing type_ parameter.")
        # Test for missing parameter options

        # Test for missing parameter mixin

        # Test for missing parameter field

        # Test for missing parameter cls

        # Test build_type for return type
    except NameError:
        print("Failed to test function build_type.")


# Generated at 2022-06-25 16:08:46.124836
# Unit test for constructor of class _IsoField
def test__IsoField():
    str_0 = "gPP;FQ4*8[<'1"
    schema_f_0 = SchemaF()
    str_1 = "gPP;FQ4*8[<'1"
    schema_f_1 = SchemaF()
    str_2 = "gPP;FQ4*8[<'1"
    schema_f_2 = SchemaF()
    str_3 = "gPP;FQ4*8[<'1"
    schema_f_3 = SchemaF()
    str_4 = "gPP;FQ4*8[<'1"
    schema_f_4 = SchemaF()
    str_5 = "gPP;FQ4*8[<'1"
    schema_f_5 = SchemaF()

# Generated at 2022-06-25 16:08:58.057223
# Unit test for function schema
def test_schema():
    # typed fields
    T = typing.TypeVar('T')
    class C0(SchemaType[T]):
        x: float
        y: int
        class Meta:
            unknown = EXCLUDE

    assert schema(C0, object, False) == {
        'x': fields.Float(required=True),
        'y': fields.Int(required=True)
    }

    class C1(SchemaType[T]):
        x: typing.Dict[str, int] = 'unknown'
        y: typing.List[UUID]
        class Meta:
            unknown = EXCLUDE


# Generated at 2022-06-25 16:09:04.486159
# Unit test for function build_schema
def test_build_schema():
    class C:
        a: Any

    @dataclass_json
    @dataclass
    class _C:
        a: Any

    test_cases = [
        C, # Type[A]
        _C, # Type[A]
        None, # Mixin
        True, # Infer_missing
        False # Partial
    ]

    test_build_schema_0 = build_schema(*test_cases)
    # TODO How to access nested class
    # test_build_schema_0.make_c
    # test_build_schema_1 = build_schema(*test_cases)
    # assert test_build_schema_0 is not test_build_schema_1




# Generated at 2022-06-25 16:09:05.686663
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    timestamp = _TimestampField()


# Generated at 2022-06-25 16:09:11.024888
# Unit test for function build_schema
def test_build_schema():
    class Meta_0():
        pass

    class TupleSchema_0(Schema):
        Meta = Meta_0

    class DataClassSchema_0(TupleSchema_0):
        pass

    assert DataClassSchema_0 is build_schema(DataClassSchema_0, DataClassSchema_0, False, False)

    class Meta_1():
        pass

    class TupleSchema_1(Schema):
        Meta = Meta_1

    class DataClassSchema_1(TupleSchema_1):
        pass

    assert DataClassSchema_1 is build_schema(DataClassSchema_1, DataClassSchema_1, True, False)

    class Meta_2():
        pass

    class TupleSchema_2(Schema):
        Meta = Meta_2


# Generated at 2022-06-25 16:09:21.840780
# Unit test for function build_schema
def test_build_schema():
    # Case 1: if type(obj) is not dataclasses_json.Schema:
    _obj_0 = typing.cast(dataclasses_json.Schema, None)
    assert type(_obj_0) is not dataclasses_json.Schema
    _cls_0 = typing.Union[type(None), type(None)]
    _mm_field_0 = typing.cast(dataclasses_json.Schema, str())
    _letter_case_0 = typing.cast(dataclasses_json.Schema, str())
    _kwargs_0 = {'mm_field': _mm_field_0, 'letter_case': _letter_case_0}

# Generated at 2022-06-25 16:09:23.527717
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()


# Generated at 2022-06-25 16:09:30.054641
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # Test 0
    f_0_0: SchemaF[A] = SchemaF() # type: ignore
    f_0_1 = f_0_0.load({'a': 'b'})
    assert f_0_1 == {'a': 'b'}
    # Test 1
    f_1_0: SchemaF[A] = SchemaF() # type: ignore
    f_1_1 = f_1_0.load({'a': 'b'})
    assert f_1_1 == {'a': 'b'}


# Generated at 2022-06-25 16:11:27.654034
# Unit test for constructor of class _IsoField
def test__IsoField():
    actual_result = _IsoField("_IsoField"
        , data_key="_IsoField"
        , default="_IsoField"
        , load_only="_IsoField"
        , dump_only="_IsoField"
        , missing="_IsoField"
        , validate=True
        , allow_none=True
        , error_messages=None
        , default_error_messages=None
        , preprocess=None
        , postprocess=None
        , required=True
        , load_from=None
        , dump_to=None
        , metadata=None
        , load_none=False)

# Generated at 2022-06-25 16:11:35.129565
# Unit test for function build_schema
def test_build_schema():
    # Test case 1
    @dataclass
    class MyModel:
        x: int

    @dataclass
    class MyModelGenerics:
        x: typing.List[MyModel]

    class MyModelMixin(SchemaMixin):
        pass

    MyModelSchema = build_schema(MyModel, MyModelMixin, infer_missing=True, partial=False)
    MyModelGenericsSchema = build_schema(MyModelGenerics, MyModelMixin, infer_missing=True, partial=False)

    # Test case 2
    @dataclass
    class MyModel1:
        x: int
        y: float

    @dataclass
    class MyModelGenerics1:
        x: typing.List[MyModel1]


# Generated at 2022-06-25 16:11:42.387302
# Unit test for function build_type
def test_build_type():
    class TestSchema(Schema):
        __dataclass_fields__ = ['name', 'age']
        name = fields.Str()
        age = fields.Int()

    class TestModel(object):
        def __init__(self, name, age):
            self.name = name
            self.age = age

    from dataclasses import dataclass, field

    @dataclass
    class DidNotUseDataclassJson(TestModel):
        name: str
        age: int

    @dataclass
    class Person(TestModel):
        name: str
        age: int

    @dataclass
    class PersonWithSchema(Person, Schema):
        __dataclass_fields__ = ['name', 'age']

    name: str = "gPP;FQ4*8[<'1"



# Generated at 2022-06-25 16:11:49.348429
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    str_0 = "gPP;FQ4*8[<'1"
    schema_f_0 = SchemaF()
    str_1 = "gPP;FQ4*8[<'1"
    schema_f_1 = SchemaF()
    str_2 = "gPP;FQ4*8[<'1"
    schema_f_2 = SchemaF()

# Generated at 2022-06-25 16:11:52.847385
# Unit test for function build_type
def test_build_type():
    str_0 = "gPP;FQ4*8[<'1"
    schema_f_0 = SchemaF()
    test_case_0()

if __name__ == "__main__":
    test_build_type()

# Generated at 2022-06-25 16:11:59.277295
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
  # Test a simple case of method SchemaF.dump
  str_0 = "gPP;FQ4*8[<'1"
  schema_f_0 = SchemaF()
  assert(schema_f_0.dump(str_0) is not None)
  # Test a more complex case of method SchemaF.dump
  int_0 = -2000
  schema_f_0 = SchemaF()
  assert(schema_f_0.dump(int_0) is not None)
  str_0 = "gPP;FQ4*8[<'1"
  schema_f_1 = SchemaF()
  assert(schema_f_1.dump(str_0) is not None)
  # Test a case of method SchemaF.dump with unknown types

# Generated at 2022-06-25 16:12:10.442157
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    str_0 = ">|hQlS=G]_5K0"
    t_0: typing.List[float] = [float(), float()]
    t_1: typing.Optional[typing.List[float]] = [float(), float()]
    t_2: typing.List[typing.List[str]] = [[str()], [str()]]
    schema_f_0 = SchemaF()
    schema_f_0.dump(t_0)
    schema_f_0.dump(t_1)
    schema_f_0.dump(t_2)


# Generated at 2022-06-25 16:12:11.172726
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    test_case_0()



# Generated at 2022-06-25 16:12:13.768791
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    # Arrange
    str_0 = "gPP;FQ4*8[<'1"
    schema_f_0 = SchemaF()

    # Assert
    assert str_0 == "gPP;FQ4*8[<'1"
    assert schema_f_0 is not None
