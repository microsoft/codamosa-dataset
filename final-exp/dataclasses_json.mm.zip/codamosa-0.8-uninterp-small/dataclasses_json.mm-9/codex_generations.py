

# Generated at 2022-06-25 16:02:55.748875
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():

    # Test case (a): many = True
    #  -> the user expect to serialize an array
    input_1_a = [0, 0, 0]
    schema_1_a = SchemaF()
    output_1_a = schema_1_a.dump(obj = input_1_a, many = True)

    # Test case (b): many = False
    #  -> the user expect to serialize a single object
    input_1_b = 0
    schema_1_b = SchemaF()
    output_1_b = schema_1_b.dump(obj = input_1_b, many = False)



# Generated at 2022-06-25 16:03:00.487683
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f_1 = SchemaF()
    schema_f_2 = SchemaF[int]()
    schema_f_3 = SchemaF[float]()
    schema_f_4 = SchemaF[int]()

# Generated at 2022-06-25 16:03:03.695586
# Unit test for function build_schema
def test_build_schema():
    import dataclass_json.tests.schema as sc_test
    assert isinstance(build_schema(sc_test.A, None, False, False), SchemaF[sc_test.A])

# Generated at 2022-06-25 16:03:09.933277
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # json_data is a JsonData
    # many is a bool
    # kwargs is a dict(str, str)
    schema_f_0 = SchemaF()
    result = schema_f_0.dumps(json_data=str(), many=bool(), kwargs = dict())
    assert isinstance(result, str)


# Generated at 2022-06-25 16:03:13.159798
# Unit test for function schema
def test_schema():
    schema_f_0 = SchemaF()
    schema_f_1 = SchemaF()
    assert(schema_f_0 != schema_f_1)

if __name__ == "__main__":
    test_schema()

# Generated at 2022-06-25 16:03:18.171201
# Unit test for function build_schema
def test_build_schema():
    class C0(metaclass=dataclass_json):
        field0:int

    class C1(metaclass=dataclass_json):
        field0: C0
    
    schema_f_0 = build_schema(C1,None,None,None)

test_build_schema()

# Generated at 2022-06-25 16:03:25.315154
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema_f_0 = SchemaF()
    obj_0 = []
    many_0 = True
    many_1 = False
    many_2 = None
    args_0 = ()
    kwargs_0 = {}
    result_0 = schema_f_0.dumps(obj_0, many_0, *args_0, **kwargs_0)
    result_1 = schema_f_0.dumps(obj_0, many_1, *args_0, **kwargs_0)
    result_2 = schema_f_0.dumps(obj_0, many_2, *args_0, **kwargs_0)
    assert result_0 == result_2
    assert result_1 != result_2


# Generated at 2022-06-25 16:03:31.035253
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json.mm import MM

    assert schema(MM, MM, False) == {}

    @mm_schema(letter_case=LetterCase.CAMEL)
    @dataclass
    class A(MM):
        pass

    assert schema(A, MM, False) == {}

    @dataclass
    class B(MM):
        a: int

    assert schema(B, MM, False) == {'a': fields.Int()}

    @dataclass
    class C(MM):
        a: typing.Optional[int]
        b: int = 0

    assert schema(C, MM, False) == {'a': fields.Int(allow_none=True),
                                    'b': fields.Int(missing=0)}


# Generated at 2022-06-25 16:03:39.771071
# Unit test for function schema
def test_schema():
    from dataclasses_json import dataclass_json, config
    @dataclass_json
    @dataclass
    class DCA:
        a: str

    @dataclass_json
    class DCB:
        b: DCA

    @dataclass_json
    @dataclass
    class DCUnion:
        c: typing.Union[int, Decimal]

    @dataclass_json
    @dataclass
    class DCUnionOptional:
        d: typing.Optional[int]

    @dataclass_json
    class DCUnionList:
        e: typing.List[typing.Union[int, Decimal]]

    @dataclass_json
    @dataclass
    class DCUnionTuple:
        f: typing.Tuple[int, Decimal]


# Generated at 2022-06-25 16:03:48.941455
# Unit test for function build_type
def test_build_type():
    assert isinstance(build_type(int, {}, None, 
        typing.List, None), fields.List)
    assert isinstance(build_type(int, {}, None, 
        typing.Mapping, None), fields.Mapping)
    assert isinstance(build_type(int, {}, None, 
        typing.MutableMapping, None), fields.Mapping)
    assert isinstance(build_type(int, {}, None, 
        typing.Tuple, None), fields.Tuple)
    assert isinstance(build_type(int, {}, None, 
        typing.Callable, None), fields.Function)
    assert isinstance(build_type(int, {}, None, 
        typing.Any, None), fields.Raw)

# Generated at 2022-06-25 16:04:06.168054
# Unit test for function build_schema
def test_build_schema():
    DataClassSchema = build_schema(
        cls=test.test_dataclass.Person,
        mixin=None,
        infer_missing=True,
        partial=False)

    # Test post_load
    man = Person(name="man", age=18, gender=Gender.MALE)
    schema = DataClassSchema(partial=False)
    out = schema.dumps(man)
    assert out == '{"age": 18, "gender": "male", "name": "man"}'



# Generated at 2022-06-25 16:04:17.328949
# Unit test for constructor of class _IsoField
def test__IsoField():
    test = _IsoField(allow_none=True)
    assert test.allow_none == True, "allow_none is not True"
    assert test.attribute is None, "attribute is not None"
    assert test.data_key is None, "data_key is not None"
    assert test.default is None, "default is not None"
    assert test.missing is None, "missing is not None"
    assert test.validate_all is False, "validate_all is not False"
    assert test.error_messages == {
        'invalid': 'Not a valid datetime.',
        'required': 'Missing data for required field.'}, "error_messages are not as expected"

# Generated at 2022-06-25 16:04:21.755119
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Test0(SchemaF):
        pass

    class Test1(SchemaF[str]):
        pass

    class Test2(SchemaF[int]):
        pass


# Generated at 2022-06-25 16:04:30.412404
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from typing import Any
    from marshmallow import Schema, fields, post_load

    @dataclass
    class DummyDataclass:
        a: int
        b: str
        test_field: Any

    @dataclass
    class DummyMixin:
        a: int
        b: str
        test_field: Any

    def make_instance(self, kvs, **kwargs):
        return DummyDataclass(**kvs)

    class DummySchema(Schema):
        a = fields.Int()
        b = fields.Str()
        test_field = fields.Field()
        Meta = type('Meta', (), {'fields': ('a', 'b', 'test_field')})
        make_dummy_mixin = make_instance

    #

# Generated at 2022-06-25 16:04:38.043445
# Unit test for function schema
def test_schema():
    class Student:
        def __init__(self, name, grade):
            self.name = name
            self.grade = grade

    class StudentSchema(SchemaType[Student]):
        name = fields.Str()
        grade = fields.Str()
        class Meta:
            ordered = True

    s = Student('John Doe', 'A')
    student_schema = StudentSchema()
    student_json = student_schema.dumps(s)
    assert student_json == '{"grade": "A", "name": "John Doe"}'



# Generated at 2022-06-25 16:04:41.668524
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f = SchemaF()

    data = {
        "attr": 123,
    }

    assert schema_f.loads(data) == data


# Generated at 2022-06-25 16:04:50.640256
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # Create a wrapper class for typing.List[A] to test the mypy error
    # for the mm decorator with the wrong return type
    class wrapper_a:
        def __init__(self, list_a: typing.List[A]):
            self.list_a = list_a

    class SchemaF_1(Schema[A], typing.Generic[A]):
        class Meta:
            unknown = 'raise'
        @post_load
        def make_object(self, data):
            return data
    schema_f_1 = SchemaF_1()
    dump_result = schema_f_1.dump([1, 2, 3])
    # Commented out to test the mypy error for the mm decorator with the wrong return type
    # dump_result_1 = schema_f_1.dump(wrapper_

# Generated at 2022-06-25 16:04:51.673476
# Unit test for function schema
def test_schema():
    pass


# Generated at 2022-06-25 16:04:55.872030
# Unit test for function schema
def test_schema():
    @dataclasses.dataclass
    class C:
        a: str
        b: int
    class M(Schema):
        b: fields.Int
    assert schema(C, M, True) == {'a': fields.Str(), 'b': fields.Int()}


# Generated at 2022-06-25 16:05:05.365705
# Unit test for function schema
def test_schema():
    @dataclass
    class A():
        x: int
        y: int
        z: str

    @dataclass
    class B():
        x: int
        y: A
        z: str

    @dataclass
    class C():
        x: int
        y: A
        z: str
        q: typing.List[A]

    @dataclass
    class D():
        x: int
        y: B
        z: str
        q: typing.List[B]

    @dataclass
    class E():
        x: int
        y: typing.List[A]
        z: str

    assert schema(A, '', False) == {}
    assert set(schema(B, '', False).keys()) == {'x', 'y', 'z'}
    assert set

# Generated at 2022-06-25 16:05:36.559448
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclass
    class Person:
        name: str
        id: int

    schema = SchemaF.from_dataclass(Person)
    person = Person(name="John Doe", id=42)
    json_data = schema.dumps(person)
    assert json_data == '{"name": "John Doe", "id": 42}'


# Generated at 2022-06-25 16:05:44.472490
# Unit test for function schema
def test_schema():
    f0 = fields.Field()
    f1 = fields.Field()
    f2 = fields.Field()
    f3 = fields.Field()
    f4 = fields.Field()
    f5 = fields.Field()
    f6 = fields.Field()
    f7 = fields.Field()
    f8 = fields.Field()
    f9 = fields.Field()
    f10 = fields.Field()
    f11 = fields.Field()
    f12 = fields.Field()
    f13 = fields.Field()
    f14 = fields.Field()
    f15 = fields.Field()
    f16 = fields.Field()
    f17 = fields.Field()
    f18 = fields.Field()
    f19 = fields.Field()
    f20 = fields.Field()
    f21 = fields.Field()
   

# Generated at 2022-06-25 16:05:49.880407
# Unit test for function schema
def test_schema():
    mixin = Schema
    class TestSchema(mixin):
        test: str
        test_int: int
        test_schema: typing.Optional[TestSchema]
        test_schema_list: typing.List[TestSchema]
        test_schema_optional: typing.Optional[typing.List[TestSchema]]
        test_optional: typing.Optional[str]
        test_dataclass: typing.Optional[TestDataclass]
        test_union: typing.Union[str, int]
        test_enum: Enum

    @dataclasses.dataclass
    class TestDataclass(mixin):
        test_encode: str
        test_string: str

    class TestF(SchemaF):
        test: str
        test_int: int
        test_schema: typing

# Generated at 2022-06-25 16:06:00.171326
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # Test with a Single Data
    schema_f_1 = SchemaF()
    obj_1 = 'test_object'
    # Check: dump(self, obj: TOneOrMultiEncoded, many: bool = None, **kwargs) -> TOneOrMulti:
    data_1 = schema_f_1.dump(obj_1)
    assert isinstance(data_1, dict)
    # Test with a Multiple Data
    schema_f_2 = SchemaF()
    obj_2 = ['test_object1', 'test_object2']
    # Check: dump(self, obj: TOneOrMultiEncoded, many: bool = None, **kwargs) -> TOneOrMulti:
    data_2 = schema_f_2.dump(obj_2)
    assert isinstance(data_2, list)

#

# Generated at 2022-06-25 16:06:01.980139
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    # given
    s = SchemaF()
    # then convert string to int
    a = s.loads("1")


# Generated at 2022-06-25 16:06:03.032677
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()


# Generated at 2022-06-25 16:06:14.158930
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f_0 = SchemaF()

    # Test case 1
    json_data_1 = '''"{\\"name\\": \\"a string\\"}"'''
    try:
        result_1 = schema_f_0.loads(json_data_1)
    except Exception as exception:
        print(exception)

    # Test case 2
    json_data_2 = '''{\\"name\\": \\"a string\\"}'''
    try:
        result_2 = schema_f_0.loads(json_data_2)
    except Exception as exception:
        print(exception)

    # Test case 3
    json_data_3 = '''"{\\"name\\": \\"a string\\", \\"a number\\": 1}"'''

# Generated at 2022-06-25 16:06:20.154406
# Unit test for function schema
def test_schema():
    #Class definition
    class MyClass:
        my_field_0: str
        my_field_1: int
        my_field_2: int
        my_field_3: typing.List[int]
    #Test
    my_schema = schema(MyClass, None, False)
    assert isinstance(my_schema, dict)
    assert len(my_schema) == 4


# Generated at 2022-06-25 16:06:22.196428
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    schema_f_1 = SchemaF()
    schema_f_1.load(data=[{'field_1': 1, 'field_2': 2}], many=True)
    schema_f_1.load(data={'field_1': 1, 'field_2': 2}, many=False)


# Generated at 2022-06-25 16:06:24.717274
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema_f_0 = SchemaF()
    schema_f_0.dump([1,2,3])
    schema_f_0.dump(1)


# Generated at 2022-06-25 16:07:25.442094
# Unit test for function build_schema
def test_build_schema():
    class DummySchema(Schema):
        pass
    
    assert build_schema(DummySchema, None, None, None) == DummySchema


# Generated at 2022-06-25 16:07:32.000596
# Unit test for function build_type
def test_build_type():
    @dataclass_json
    @dataclass
    class TestDc:
        field1: str
        field2: int

    class TestMixin:
        pass

    class TestCls:
        pass

    test_type_1 = typing.List[TestDc]

    test_field_1 = dc_fields(TestCls)[0]

    test_options_1 = {
        "allow_none": True,
        "validate": None,
        "required": True,
        "load_from": None,
        "dump_to": None,
        "attribute": "field1",
        "error_messages": None,
        "data_key": None
    }

    build_type(test_type_1, test_options_1, TestMixin, test_field_1, TestCls)

# Generated at 2022-06-25 16:07:35.310381
# Unit test for function build_type
def test_build_type():
    class MyClass(Schema):
        pass
    class MyClass2(Schema):
        pass

    build_type(MyClass, {'field_many': False}, Schema, 
             dc_fields(MyClass)[0], MyClass)
    
    build_type(MyClass2, {'field_many': False}, Schema, 
             dc_fields(MyClass2)[0], MyClass2)


# Generated at 2022-06-25 16:07:40.205592
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class obj1_class_0(object):
        def __init__(self, arg1: str, arg2: str) -> None:
            self.arg1 = arg1
            self.arg2 = arg2

    class obj1_class_1(object):
        def __init__(self, arg1: str) -> None:
            self.arg1 = arg1

    class obj1_class_2(object):
        def __init__(self, arg1: str) -> None:
            self.arg1 = arg1

    class obj1_class_3(object):

        def __init__(self) -> None:
            pass

    class schema_f_13(SchemaF):
        def __init__(self, *args, **kwargs):
            self.arg1 = fields.Str()
            self.arg

# Generated at 2022-06-25 16:07:48.775692
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from uuid import UUID
    from marshmallow import Schema, fields

    class User(Schema):
        name = fields.Str()
        uid = fields.UUID()

    class User2(Schema):
        name = fields.Str()
        uid = fields.UUID()

    data = {
        "name": "foo",
        "uid": str(UUID("c4f4a4bd-9ba1-4bb2-b6ce-7a110e46aef8"))
    }
    assert User2().loads(User().dumps(data)) == data
    assert User().loads(User().dumps(data)) == data


# Generated at 2022-06-25 16:07:49.891082
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    timestampfield = _TimestampField()



# Generated at 2022-06-25 16:07:54.435681
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclass
    class SomeClass:
        i: int
        d: float
    schema_f_0 = SchemaF()
    obj = SomeClass(i=1,d=4.4)
    obj_dumped = schema_f_0.dumps(obj)


# Generated at 2022-06-25 16:08:08.040836
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f_1 = SchemaF()
    assert schema_f_1.loads('[]') == []
    schema_f_1_1 = SchemaF()
    assert schema_f_1_1.loads([]) == []
    schema_f_1_2 = SchemaF()
    assert schema_f_1_2.loads([{}]) == [{}]
    schema_f_1_3 = SchemaF()
    assert schema_f_1_3.loads({}) == {}
    schema_f_1_4 = SchemaF()
    assert schema_f_1_4.loads('') == {}
    schema_f_2 = SchemaF()
    assert schema_f_2.loads('[]', many=None) == []
    schema_f_2_1 = SchemaF()
   

# Generated at 2022-06-25 16:08:10.764294
# Unit test for function build_schema
def test_build_schema():
    # use ordered dict so the order is preserved
    # the expected output is the same as the input
    test_schema = schema(TestDataClass, dataclass_json.DataClassJsonMixin, True)
    assert test_schema == OrderedDict(TestDataClass._schema_fields)

# Generated at 2022-06-25 16:08:15.990321
# Unit test for function schema
def test_schema():
    from typing import Tuple, Type, Callable, Union, Optional
    from dataclasses_json.api import _test_mixin, _test_dataclass
    from dataclasses import dataclass, field

    @dataclass
    class TestSchema:
        a: int
        b: float
        c: str
        d: datetime.date
        e: datetime.time
        f: datetime.datetime
        g: Tuple[int, str]
        h: dict
        i: _test_dataclass
        j: Type[_test_dataclass] = field(
            metadata={'dataclasses_json': {'mm_field': fields.Str}})
        k: _test_mixin

# Generated at 2022-06-25 16:11:39.426051
# Unit test for function build_schema
def test_build_schema():
    class S:
        mm_field = fields.Int()

    class X:
        a: int = field(metadata=S())

        class dataclass_json_config:
            mm_config = "abc"

    dc = build_schema(X, Schema, False, False)
    assert dc.Meta.fields == ("a",)
    assert dc.a == fields.Int()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 16:11:41.371686
# Unit test for function schema
def test_schema():
    # Check if the function returns the right type.
    assert type(schema(test_case_0, test_case_0.__name__, False)) is dict



# Generated at 2022-06-25 16:11:47.302960
# Unit test for function schema
def test_schema():
    class Printer(metaclass=_ExtendedEncoder):
        name: str
        price: int

    class PrinterSchema(SchemaF[Printer]):
        name = fields.Str()
        price = fields.Int()

    s = schema(Printer, PrinterSchema, False)
    assert type(s['name']) is fields.Str
    assert type(s['price']) is fields.Int

# Generated at 2022-06-25 16:11:48.442715
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField


# Generated at 2022-06-25 16:11:57.043386
# Unit test for function schema
def test_schema():
    @dataclasses_json.dataclass_json
    class SchemaTest:
        field_0: str
        field_1: int
        field_2: typing.List[int]
        field_3: typing.List[typing.Optional[int]]
        field_4: typing.Optional[int]
        field_5: typing.List[typing.List[typing.Optional[int]]]

    test_schema = schema(SchemaTest, SchemaTest, False)

# Generated at 2022-06-25 16:12:02.010878
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class TestSchemaF(SchemaF):
        def __init__(self, data: str):
            self.data = data

    test_case = TestSchemaF('data1')
    assert test_case.dumps() == '{"data": "data1"}'


# Generated at 2022-06-25 16:12:03.938482
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema_f = SchemaF()
    schema_f.dumps([1, 2, 3])


# Generated at 2022-06-25 16:12:11.920344
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class TestItem:
        def __init__(self, x):
            self.x = x

    class TestItemSchema(Schema):
        x = fields.Str()

    schema_f_0 = SchemaF()
    schema_f_1 = SchemaF[TestItem]()
    schema_f_0.load([{'x': 'abc'}], many=True)
    schema_f_1.load([{'x': 'abc'}], many=True)
    schema_f_0.load([{'x': 'abc'}], many=False)
    schema_f_1.load([{'x': 'abc'}], many=False)
    schema_f_0.load({
        'x': 'abc'
    }, many=True)

# Generated at 2022-06-25 16:12:21.125711
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # First test the case where the class does not have a post_load method
    class TestS1(SchemaF):
        pass
    # First test the case where the class does not have a post_load method
    # this is an error case
    try:
        TestS1.load()
    except NotImplementedError:
        pass

    class TestS2(SchemaF):
        def post_load(self, obj, **kwargs):
            return obj
    assert TestS2.load({"a":1}) == {"a":1}

    # Test the case where the class has a post_load method
    class TestS3(SchemaF):
        def post_load(self, obj, **kwargs):
            obj['a'] = 2
            return obj
