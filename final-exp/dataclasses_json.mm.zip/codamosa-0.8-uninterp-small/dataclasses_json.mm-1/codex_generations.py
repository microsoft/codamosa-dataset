

# Generated at 2022-06-25 16:02:50.502265
# Unit test for function build_schema
def test_build_schema():
    class Mixin0:
        x_0: typing.Optional[dict]
        x_1: typing.Union[None, str]
        x_2: typing.Optional[float]
        x_3: typing.Optional[float]
    class Test0:
        def __init__(self, x_0: typing.Optional[dict], x_1: typing.Union[None, str], x_2: typing.Optional[float], x_3: typing.Optional[float]):
            self.x_0 = x_0
            self.x_1 = x_1
            self.x_2 = x_2
            self.x_3 = x_3

    instance_0 = Test0(dict(), '', 2660.9, -9192.54)

# Generated at 2022-06-25 16:03:01.098182
# Unit test for function schema
def test_schema():
    import dataclasses_json
    from typing import Optional

    @dataclasses_json.dataclass_json
    @dataclasses.dataclass
    class TestSchemaA:
        a: int
        b: str = ''

    @dataclasses_json.dataclass_json
    @dataclasses.dataclass
    class TestSchemaB:
        c: Optional[TestSchemaA]

    schema_0 = schema(TestSchemaB, dataclasses_json.DataClassJsonMixin, False)
    str_0 = str(schema_0)
    set_0 = set()
    float_0 = 3746.949022
    return schema_0


# Generated at 2022-06-25 16:03:04.049844
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    dumps_0 = SchemaF()
    int_0 = 7600
    dumps_1 = dumps_0.dumps(int_0)
    assert dumps_1 == dumps_1


# Generated at 2022-06-25 16:03:06.753185
# Unit test for function build_schema
def test_build_schema():
    schema_f_0 = build_schema(mixin=None, infer_missing=False, partial=True)
    assert (isinstance(schema_f_0, SchemaF))
    assert (hasattr(schema_f_0, 'Meta'))


# Generated at 2022-06-25 16:03:18.304081
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class Base0():
        fld_0: datetime
        fld_1: datetime
        fld_2: typing.List[datetime]
        fld_3: typing.Mapping[str, datetime]
        fld_4: typing.MutableMapping[str, datetime]
        fld_5: typing.Dict[str, datetime]
        fld_6: typing.List[datetime]
        fld_7: typing.List[datetime]
        fld_8: typing.Tuple[datetime, datetime]
        fld_9: typing.Callable
        fld_10: typing.Any
        fld_11: dict
        fld_12: list
        fld_13: str
        fld

# Generated at 2022-06-25 16:03:25.101683
# Unit test for function build_schema
def test_build_schema():

    class mixin_0:
        def __init__(self, test_class_0: TestClass, **kwargs):
            self.test_class_0 = test_class_0

    infer_missing_0 = False
    partial_0 = True
    global_config.json_module = "test_module"

    class TestClass(mixin_0):
        test_class_0: int
        test_class_1: float
        test_class_2: str
        test_class_3: typing.List[float]
        test_class_4: typing.List[bool]
        test_class_5: typing.List[str]
        test_class_6: typing.Optional[typing.List[bool]]
        test_class_7: typing.Optional[typing.List[str]]
        test_class_

# Generated at 2022-06-25 16:03:29.283203
# Unit test for function build_schema
def test_build_schema():
    # Input parameters
    class_1 = None # type: ignore

    mixin_1 = None # type: ignore

    infer_missing_1 = False

    partial_1 = False

    # Return type annotation
    return_type = typing.Type[Schema]

    # Call the function
    return_value = build_schema(class_1, mixin_1, infer_missing_1, partial_1)

    # Check type of return value
    assert isinstance(return_value, return_type)

# Generated at 2022-06-25 16:03:30.445113
# Unit test for constructor of class _IsoField
def test__IsoField():
    field_0 = _IsoField()


# Generated at 2022-06-25 16:03:36.935976
# Unit test for function build_schema
def test_build_schema():

    # Test case 1
    class User(object):
        USER_ID = 1
        USER_NAME = 'My name'
        USER_TOKEN = 'My token'
        USER_PASSWORD = b'My password'

    def is_instance_of_schema(schema, obj):
        """
        Checks if object is instance of schema
        :param schema: schema object
        :param obj: object
        :return: True if object is instance of schema, False otherwise
        """
        if isinstance(schema, fields.List):
            return isinstance(obj, list)
        elif isinstance(schema, fields.Dict):
            return isinstance(obj, dict)
        else:
            return isinstance(obj, type(schema))

    # Test case 1
    User_schema = build_

# Generated at 2022-06-25 16:03:43.790227
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    schema_f_0 = SchemaF()
    str_0 = 'test_str'
    dict_0 = dict()
    timestampfield_0 = _TimestampField()
    timestampfield_1 = _TimestampField()
    timestampfield_1 = _TimestampField(data_key='test_str', default=5.5, error='test_str', missing=5.5, required=True, validate=5.5)
    timestampfield_2 = _TimestampField.__init__(timestampfield_1, data_key='test_str', default=5.5, error='test_str', missing=5.5, required=True, validate=5.5)
    timestampfield_0 = _TimestampField(**{'data_key':'test_str', 'missing':5.5, 'validate':5.5})

# Generated at 2022-06-25 16:03:56.426733
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    fields_0 = _TimestampField()


# Generated at 2022-06-25 16:03:59.574714
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f_0 = SchemaF()
    list_0 = [0, -1.875, -9, -9, -6.09025, -2, 0, -2, -6.09025, -9, -9, -1.875, 0]
    obj_0 = schema_f_0.loads(list_0)


# Generated at 2022-06-25 16:04:05.639434
# Unit test for function build_schema
def test_build_schema():
    test_class_0 = {'test_attr_0': 1, 'test_attr_1': 2, 'test_attr_2': 3}
    dc_schema_f_0 = build_schema(test_class_0)
    s = SchemaF(dc_schema_f_0)
    json_data = '{"test_attr_0": {"test_attr_0": 1, "test_attr_1": 2, "test_attr_2": 3}, "test_attr_1": {"test_attr_0": 1, "test_attr_1": 2, "test_attr_2": 3}, "test_attr_2": {"test_attr_0": 1, "test_attr_1": 2, "test_attr_2": 3}}'
    s.loads(json_data)
    s.dump

# Generated at 2022-06-25 16:04:07.728956
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    float_0 = SchemaF[int]()
    int_0 = 1
    byte_0 = float_0.dump(int_0)


# Generated at 2022-06-25 16:04:13.578748
# Unit test for function build_type
def test_build_type():
    schema_f_0 = SchemaF()
    float_0 = 3746.949022
    set_0 = set()
    mm_field_0 = build_type(schema_f_0, float_0, schema_f_0, set_0, set_0)
    mm_field_1 = build_type(schema_f_0, float_0, float_0, float_0, float_0)
    mm_field_2 = build_type(schema_f_0, float_0, set_0, float_0, set_0)
    mm_field_3 = build_type(schema_f_0, float_0, set_0, set_0, float_0)

# Generated at 2022-06-25 16:04:22.391663
# Unit test for function build_schema
def test_build_schema():
    class Test0(Schema):
        Test1 = 'test1'
        Test2 = 'test2'

    class Meta:
        Test3 = 'test3'
        Test4 = 'test4'

    def _validate_test0_def(cls: typing.Type[Schema]):
        assert cls.Test1 == 'test1', 'Attribute lookup failed.'
        assert cls.Test2 == 'test2', 'Attribute lookup failed.'
        assert cls.Meta.Test3 == 'test3', 'Attribute lookup failed.'
        assert cls.Meta.Test4 == 'test4', 'Attribute lookup failed.'

    def _validate_schema(schema: typing.Type[Schema]):
        _validate_test0_def(schema)

    _validate_schema(Test0)


# Unit

# Generated at 2022-06-25 16:04:28.946386
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    json_data_0 = b'\x0b\x08\x12\x05\x1a\x03"\x01\x00\x22\x00\x30\x00\x42\x00\x0a\x01\x20\x00'
    schema_f_0 = SchemaF()
    list_0 = schema_f_0.loads(json_data_0)
    list_0.append(bytearray())


# Generated at 2022-06-25 16:04:35.352780
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # Case 0
    class Test0_SchemaF(SchemaF[float]):
        pass

    schema_f_0 = Test0_SchemaF()
    float_0 = 3746.949022
    float_dump_0 = schema_f_0.dump(float_0)
    set_0 = set()
    set_0.add(float_dump_0)


# Generated at 2022-06-25 16:04:36.588658
# Unit test for function build_schema
def test_build_schema():
    try:
        import marshmallow._schema
    except ImportError:
        return
    else:
        test_case_0()

# Generated at 2022-06-25 16:04:42.171194
# Unit test for function schema
def test_schema():
    # TODO: Implement the tests.
    # Define functions that would be called in the "test" function.
    def build_type_0(type_, options, mixin, field, cls):
        def inner_0(type_, options):
            while True:
                while True:
                    if not _is_new_type(type_):
                        break

                    type_ = type_.__supertype__

                if is_dataclass(type_):
                    if _issubclass_safe(type_, mixin):
                        options['field_many'] = bool(
                            _is_supported_generic(field.type) and _is_collection(
                                field.type))
                        return fields.Nested(type_.schema(), **options)

# Generated at 2022-06-25 16:05:06.423102
# Unit test for function schema
def test_schema():
    assert hasattr(schema, '__call__')
    assert callable(schema)

# Generated at 2022-06-25 16:05:17.376286
# Unit test for function schema
def test_schema():
    class Mock(object):
        def __init__(self, args):
            self._args = args

        def __call__(self, *args, **kwargs):
            return (args, kwargs)

    from dataclasses import dataclass
    import typing

    from marshmallow import Schema
    from marshmallow.fields import Field
    from marshmallow.compat import _is_multiple

    mock_dict = {'many': True, 'sparse': False, 'partial': None, 'unknown': None}
    mock_dict_0 = {'many': True, 'sparse': True, 'partial': None, 'unknown': None}

    class Mock_0(object):
        def __init__(self, args):
            self._args = args

        def __call__(self, *args, **kwargs):
            return args

# Generated at 2022-06-25 16:05:24.975137
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema_0 = SchemaF()
    class Class_f_0(typing.Generic[A]):
        def __init__(self, cls: SCHEMA_A) -> SCHEMA_Z:
            self.cls = cls
        def __setitem__(self, key: SCHEMA_B, value: SCHEMA_A) -> None:
            self.cls[key] = value
    class Class_f_1(SchemaF):
        def __init__(self, cls: SCHEMA_A) -> SCHEMA_Z:
            self.cls = cls
        def __setitem__(self, key: SCHEMA_B, value: SCHEMA_A) -> None:
            self.cls[key] = value


# Generated at 2022-06-25 16:05:27.972334
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema_f_0 = SchemaF()
    float_0 = 3746.949022
    set_0 = {float_0}
    assert (
        schema_f_0.dumps(set_0) !=
        "{\"[\\\"\\ue7c0\\\", \\\"\\u00\\\")\\\"]\"}")


# Generated at 2022-06-25 16:05:35.850675
# Unit test for function build_schema
def test_build_schema():
    from typing import List
    from dataclasses import dataclass, field
    import marshmallow as mm

    class Test1Mixin:
        pass

    class Test2Mixin:
        pass

    @dataclass(frozen=True)
    class Test1(Test1Mixin):
        value: float
        values: List[float] = field(default_factory=list)

    @dataclass(frozen=True)
    class Test2(Test2Mixin):
        value: float
        values: List[float] = field(default_factory=list)

    # Test1Schema
    Test1Schema = build_schema(Test1, Test1Mixin, False, False)
    test1 = Test1(value=3746.949022)

# Generated at 2022-06-25 16:05:39.651144
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema_f_0 = SchemaF()
    schema_0 = schema_f_0.dump(())
    schema_1 = schema_f_0.dump({})
    schema_2 = schema_f_0.dumps(())
    schema_3 = schema_f_0.dumps({})


# Generated at 2022-06-25 16:05:46.600370
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f_0 = SchemaF()
    str_0 = '\"eRMY:NT:1e_b'
    str_1 = 'hH;A'
    loads_0 = schema_f_0.loads(str_0, many=False, partial=False)  # type: ignore
    loads_1 = schema_f_0.loads(str_0, many=True, partial=False)  # type: ignore
    loads_2 = schema_f_0.loads(str_1, many=False, partial=False)  # type: ignore
    loads_3 = schema_f_0.loads(str_1, many=True, partial=False)  # type: ignore
    dict_0 = deepcopy(loads_1)

# Generated at 2022-06-25 16:05:53.832678
# Unit test for function build_type
def test_build_type():
    dict_0 = dict()
    dict_0 = dict()
    mm_field_0 = build_type(bool, dict_0, bool, list_0, list_0)
    # mm_field_1 = build_type(bool, dict_0, bool, dict_0, dict_0)
    mm_field_2 = build_type(bool, dict_0, bool, mm_field_0, mm_field_0)
    mm_field_3 = build_type(bool, dict_0, bool, mm_field_1, mm_field_1)
    mm_field_4 = build_type(bool, dict_0, bool, mm_field_2, mm_field_2)

# Generated at 2022-06-25 16:06:02.399747
# Unit test for function build_type
def test_build_type():
    class A:
        pass
    f = lambda a: a

# Generated at 2022-06-25 16:06:03.806074
# Unit test for constructor of class _IsoField
def test__IsoField():
    c = _IsoField()


# Generated at 2022-06-25 16:06:56.175054
# Unit test for function build_type
def test_build_type():
    _TEST_DATE_ISO_STR = '2020-11-10T00:00:00'
    _TEST_DATE_EPOCH_SECS = 1605056800

    class CustomDateTimeSchema(SchemaType):
        date = _IsoField(required=True)
        
    datetime_schema = CustomDateTimeSchema()
    
    class TestPostSchema(SchemaType):
        title = fields.String(required=True)
        created = _TimestampField(required=True)

    test_post_schema = TestPostSchema()

    class TestUserSchema(SchemaType):
        username = fields.String(required=True)
        password = fields.String(required=False)
        created = _TimestampField(required=False)

    test_user_schema = Test

# Generated at 2022-06-25 16:07:03.496054
# Unit test for function schema
def test_schema():

    # Define a dataclass which inherits from the dataclass_json mixin
    @dataclasses.dataclass
    class Point(dataclasses_json.dataclass_json):
        x: int
        y: int

        def __repr__(self):
            return f'{self.__class__.__name__}(x={self.x!r}, ' \
                   f'y={self.y!r})'

        def __str__(self):
            return f'{self.__class__.__name__} object: x={self.x!s}, ' \
                   f'y={self.y!s}'

        def __eq__(self, other):
            return self.x == other.x and self.y == other.y

    # Define a dataclass which inherits from

# Generated at 2022-06-25 16:07:11.190837
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    from marshmallow import fields
    _TimestampField(allow_none=False, default=None, error_messages={'required': 'Field may not be null.', 'null': 'Field may not be null.', 'none': 'Field may not be null.', 'type': 'Invalid input type.', 'validator_failed': 'Invalid value.'}, missing=MISSING, load_only=False, required=True, validate=None, error_messages={'required': 'Field may not be null.'})


# Generated at 2022-06-25 16:07:22.565971
# Unit test for function build_schema
def test_build_schema():
    test_str = ''
    test_str = test_str
    test_str = test_str
    test_str = test_str
    test_str = test_str
    test_str = test_str
    test_str = test_str
    test_str = test_str
    test_str = test_str
    test_str = test_str
    test_str = test_str
    test_str = test_str
    test_str = test_str
    test_str = test_str
    test_str = test_str
    test_str = test_str
    test_str = test_str
    test_str = test_str
    test_str = test_str
    test_str = test_str
    test_int = 0
    test_int = test_int

# Generated at 2022-06-25 16:07:30.746125
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema_f_0 = SchemaF()
    float_0 = 3746.949022
    tuple_0 = (4743.87854, )
    dict_0 = {u'\xa3': float_0}
    list_0 = [float_0, float_0, float_0, float_0, float_0, float_0]
    assert (schema_f_0.dump(list_0) == list_0)
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool

# Generated at 2022-06-25 16:07:39.168290
# Unit test for function build_schema
def test_build_schema():
    print("\n*** Testing build_schema ***")
    schema_f_0 = build_schema(list, tuple, True, True)
    print("schema_f_0.__name__: " + str(schema_f_0.__name__))
    print("schema_f_0.__module__: " + str(schema_f_0.__module__))
    int_0 = 214448
    bool_0 = False
    str_0 = "str"
    float_0 = 3746.949022
    str_1 = "str"
    schema_f_0_vars = vars(schema_f_0)
    print("len(schema_f_0_vars): " + str(len(schema_f_0_vars)))

# Generated at 2022-06-25 16:07:42.652204
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema_f_0 = SchemaF()
    float_0 = 3746.949022
    set_0 = set()


# Generated at 2022-06-25 16:07:49.554441
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    schema_f_0 = SchemaF()
    schema_f_1 = SchemaF()
    schema_f_2 = SchemaF(many=False)
    schema_f_3 = SchemaF()
    schema_f_4 = SchemaF()
    schema_f_5 = SchemaF()
    schema_f_6 = SchemaF()
    schema_f_7 = SchemaF()
    schema_f_8 = SchemaF()

# Generated at 2022-06-25 16:07:52.937576
# Unit test for function build_schema
def test_build_schema():
    try:
        result = build_schema
    except Exception as e:
        print(str(e))
    else:
        assert callable(result)


# Generated at 2022-06-25 16:07:56.244394
# Unit test for function build_schema
def test_build_schema():
    # case 0
    test_case_0()


if __name__ == '__main__':
    # Unit test for function build_type
    # test_build_type()

    # Unit test for function schema
    # test_schema()

    # Unit test for function build_schema
    test_build_schema()

# Generated at 2022-06-25 16:10:03.106104
# Unit test for constructor of class _IsoField
def test__IsoField():
    obj_0 = _IsoField()


# Generated at 2022-06-25 16:10:04.428307
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    import marshmallow as mm
    import typing
    result_0 = SchemaF.dumps(mm.Schema)


# Generated at 2022-06-25 16:10:10.156763
# Unit test for method load of class SchemaF
def test_SchemaF_load():

    schema_f_0 = SchemaF()
    tuple_0 = (0, 1, 2)
    data_0 = {'0': 0, '1': 1, '2': 2}
    schema_f_0.load(data_0, many=False)
    schema_f_0.load(data_0, many=False)


# Generated at 2022-06-25 16:10:22.102940
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    set_0 = set()
    float_0 = 3746.949022
    schema_f_0 = SchemaF()
    class_0 = schema_f_0.loads('', False, False, False)
    class_1 = SchemaF.loads(schema_f_0, '', False, False, False)
    class_2 = SchemaF.loads(schema_f_0, '', False, False, False)
    class_3 = SchemaF.loads(schema_f_0, '', False, False, False)
    class_4 = SchemaF.loads(schema_f_0, '', False, False, False)
    class_5 = schema_f_0.loads('', False, False, False)


# Generated at 2022-06-25 16:10:31.262221
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema_f_0 = SchemaF()
    float_0 = 3746.949022
    json_data_0 = ''
    str_0 = schema_f_0.loads(json_data_0)
    json_data_1 = ''
    str_1 = schema_f_0.loads(json_data_1)
    json_data_2 = ''
    str_2 = schema_f_0.loads(json_data_2)
    json_data_3 = ''
    str_3 = schema_f_0.loads(json_data_3)


# Generated at 2022-06-25 16:10:32.955838
# Unit test for function build_schema
def test_build_schema():
    test_case_0()


# Generated at 2022-06-25 16:10:38.975054
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    schema_f_0 = SchemaF()
    float_0 = 3746.949022
    dict_0 = dict()
    dict_0['name_0'] = 'str_0'
    dict_0['name_1'] = 'str_1'
    schema_f_0.load(dict_0)
    dict_1 = dict()
    dict_1['name_0'] = 'str_2'
    dict_1['name_1'] = 'str_3'
    schema_f_0.load(dict_1)
    schema_f_0.load(dict_1, many=False)
    dict_2 = dict()
    dict_2['name_0'] = 'str_2'
    dict_2['name_1'] = 'str_3'

# Generated at 2022-06-25 16:10:48.662990
# Unit test for function build_schema
def test_build_schema():
    import math
    class Cat(ABC):
        @abstractmethod
        def __init__(self, name, colour):
            self.name = name
            self.colour = colour
    class CatClass(Cat):
        def __init__(self, name, colour):
            self.name = name
            self.colour = colour
    class Dog:
        def __init__(self, name, age, colour):
            self.name = name
            self.age = age
            self.colour = colour
            # This cls will not match the schema
            self.cls = cls
    class CatDogClass(Cat, Dog):
        def __init__(self, name, age, colour):
            self.name = name
            self.age = age
            self.colour = colour

# Generated at 2022-06-25 16:10:50.256319
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField(attribute=1, default=1, error_messages=1, missing=1, required=1)


# Generated at 2022-06-25 16:10:58.671517
# Unit test for function build_type
def test_build_type():

    # Test 0:
    # from dataclasses import dataclass
    # @dataclass
    # class cls_0:
    #     float_0: float
    #     set_0: set
    # options_0 = {
    #     'allow_none': False,
    #     'required': False,
    #     'attribute': None
    # }
    # mm_0 = build_type(cls_0, options_0, cls_0)
    # schema_f_0 = SchemaF()
    # float_0 = 3746.949022
    # set_0 = set()
    pass

if __name__ == '__main__':
    test_build_type()