

# Generated at 2022-06-25 16:02:45.451179
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    obj: typing.List[int] = [4]
    sf = SchemaF()
    assert type(sf.dumps(obj)) is str
    assert type(sf.dumps([4])) is str



# Generated at 2022-06-25 16:02:54.277321
# Unit test for function schema
def test_schema():
    @dataclass_json
    @dataclass
    class Person:
        name: str
        age: int = field(metadata={'mm_field': fields.Integer()})
        height: float = field(metadata={'mm_field': fields.Float(load_from='height_load')})
        weight: float = field(metadata={'mm_field': fields.Float(load_from='weight_load')})
        children: typing.List[int]

    n = Person("John", 32, 180.5, 78.9, [1, 2, 3])
    n_load = n.to_json(indent=4)

# Generated at 2022-06-25 16:03:01.186024
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # Testing SchemaF.dump with obj of type List[A] and many = None
    schema_f_1 = SchemaF()
    schema_f_1.dump([1, 2])

    # Testing SchemaF.dump with obj of type A and many = None
    schema_f_2 = SchemaF()
    schema_f_2.dump(1)



# Generated at 2022-06-25 16:03:03.954779
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    # Test with one element
    schema_f_1 = SchemaF()

    # Test with multiple elements
    schema_f_2 = SchemaF()



# Generated at 2022-06-25 16:03:11.520098
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class A:
        a: int
        b: int

    @dataclass
    class B:
        a: A
        b: int

    t = build_schema(B, None, True, False)
    assert t.Meta.fields == ('a', 'b',)
    u = t(strict=True)
    assert isinstance(u.fields['a'], fields.Nested)
    assert isinstance(u.fields['b'], fields.Integer)

    t = build_schema(A, None, True, False)
    u = t(strict=True)
    assert isinstance(u.fields['a'], fields.Integer)
    assert isinstance(u.fields['b'], fields.Integer)



# Generated at 2022-06-25 16:03:14.516987
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema_f = SchemaF()
    schema_f.dump([1, 2, 3], many=True)


# Generated at 2022-06-25 16:03:18.470544
# Unit test for function build_type
def test_build_type():
    from .test_schema_declarations import TestDataclass

    test_dataclass = TestDataclass()
    for f in dc_fields(test_dataclass):
        build_type(f.type, {}, test_dataclass, f, test_dataclass)

# Generated at 2022-06-25 16:03:20.569450
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    try:
        schema_f_0 = SchemaF()
    except Exception as e:
        assert type(e) == NotImplementedError


# Generated at 2022-06-25 16:03:23.569560
# Unit test for function schema
def test_schema():
    class Student:
        name: str
        score: str
    test_dct = {'name':'Name', 'score':'Score'}
    result = schema(Student, object, True)
    assert result == {'name': [type(None)], 'score': [type(None)]}

# Generated at 2022-06-25 16:03:35.652043
# Unit test for function schema
def test_schema():
    class TestMixin:
        @property
        def schema(self):
            return {'test': fields.Str()}

    @dataclass_json(mm_schema=True)
    @dataclass
    class Test0:
        a: str
        b = 1
        c: typing.List[int]
        d: typing.Optional[int]
        e: typing.Optional[int] = None
        f: typing.List[int] = field(default_factory=lambda: [])
        g: typing.Optional[TestMixin] = None

        def __missing__(self, key):
            raise Exception("test")

        schema = schema(cls=Test0, mixin=TestMixin, infer_missing=False)

    assert isinstance(Test0.schema, SchemaType)

# Generated at 2022-06-25 16:03:55.964763
# Unit test for function build_schema
def test_build_schema():
    global DataClassSchema
    DataClassSchema = build_schema(C, None, '', '')
    schema_f_0 = SchemaF()
    schema_f_1 = SchemaF[int]()
    a = DataClassSchema()
    b = DataClassSchema[int]()
    assert(type(a) == DataClassSchema)
    assert(type(b) == DataClassSchema)
    assert(type(schema_f_0) == SchemaF)
    assert(type(schema_f_1) == SchemaF)


test_build_schema()

# Generated at 2022-06-25 16:03:58.046506
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema_f_0 = SchemaF()
    res_0 = schema_f_0.dumps(obj = 1, many = True, indent = 3)


# Generated at 2022-06-25 16:04:04.666933
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from typing import List
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class Dummy(DataClassJsonMixin):
        a: str

    @dataclass
    class DummyList(DataClassJsonMixin):
        a: List[Dummy]

    schema_ = schema(Dummy, DataClassJsonMixin, infer_missing=False)
    schema_list = schema(DummyList, DataClassJsonMixin, infer_missing=False)
    assert issubclass(Dummy.schema, SchemaType)
    assert issubclass(DummyList.schema, SchemaType)
    assert schema_['a'] is not None
    assert schema_list['a'] is not None

# Generated at 2022-06-25 16:04:09.218594
# Unit test for function build_type
def test_build_type():
    from typing import List
    from marshmallow import Schema

    class options:
        pass
    class Field:
        pass
    class cls:
        pass
    class mixin:
        pass
    class type_:
        pass
    options = options()
    field = Field()
    cls = cls()
    mixin = mixin()
    type_ = type_()
    assert build_type(type_, options, mixin, field, cls)



# Generated at 2022-06-25 16:04:11.473837
# Unit test for constructor of class _IsoField
def test__IsoField():
    field1 = _IsoField()
    field2 = _IsoField(default=None)


# Generated at 2022-06-25 16:04:17.743533
# Unit test for function build_schema
def test_build_schema():


    class A(metaclass=abc.ABCMeta):
        pass


    @dataclass_json
    @dataclass
    class A1(A):
        a: str
        b: int = 1
        c: Set[int] = field(default_factory=set)


    @dataclass_json
    @dataclass
    class A2(A):
        a: str
        b: int = 1
        c: Set[int] = field(default_factory=set)


    @dataclass_json
    @dataclass
    class B:
        a: A

#Test Cases for function load

# Generated at 2022-06-25 16:04:27.067213
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema_f_1 = SchemaF[int]()
    assert schema_f_1.dump([1, 2, 3]) == [1, 2, 3]
    assert schema_f_1.dump(1) == 1

    schema_f_2 = SchemaF[pydantic.BaseModel]()
    assert schema_f_2.dump([pydantic.BaseModel(a=1), pydantic.BaseModel(a=2)]) == [{'a': 1}, {'a': 2}]
    assert schema_f_2.dump(pydantic.BaseModel(a=3)) == {'a': 3}


# Generated at 2022-06-25 16:04:36.885968
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class DC_Test0:
        n: int
    class Mixin0:
        pass
    class DC_Test(DC_Test0, Mixin0):
        n: int
        pass
    s = schema(DC_Test, Mixin0, False)
    assert len(s) == 2
    assert isinstance(s['n'], fields.Int)
    assert s['n'].metadata['loc'] == 'DC_Test.n: int'



# Generated at 2022-06-25 16:04:48.420952
# Unit test for function build_type
def test_build_type():
    class Options:
        key_id = 'test'
        missing = None
    class Field:
        name = 'test'
        type = None
        default = None
        default_factory = None
        init = True
        repr = True
        metadata = {}
    class Cls:
        name = 'test'
    options = Options()
    field = Field()
    cls = Cls()
    field.type = typing.List[int]
    options.missing = 'test'

# Generated at 2022-06-25 16:04:54.843876
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class C0:
        pass

    schema_f_0 = SchemaF()
    x_0 = C0()
    x_1 = 1
    x_2 = "abcd"
    x_3 = [1, 2, 3]
    x_4 = [C0(), C0(), C0()]
    x_5 = {'a': 1, 'b': 2, 'c': 3}
    x_6 = {'a': C0(), 'b': C0(), 'c': C0()}
    assert schema_f_0.dump(x_0) == {'_sa_instance_state': None}
    assert schema_f_0.dump(x_1) == 1
    assert schema_f_0.dump(x_2) == 'abcd'

# Generated at 2022-06-25 16:05:17.630131
# Unit test for function schema
def test_schema():
    from typing import Optional
    from dataclasses_json.core import mm_field, DC
    from dataclasses import dataclass
    from marshmallow.exceptions import ValidationError
    from marshmallow.fields import String, Int

    @dataclass
    class A:
        a: Optional[str]

    # test1: class without the metaclass
    try:
        _ = schema(A, DC, False)
        assert 0 == 1 # shouldn't reach here
    except:
        assert 1 == 1

    # test2: class with the metaclass but no field
    @dataclass
    class B(DC):
        pass
    _ = schema(B, DC, False)
    assert 1 == 1

    # test3: class with the metaclass and field but this field is not a valid field

# Generated at 2022-06-25 16:05:21.789844
# Unit test for function build_type
def test_build_type():

    origin = Bool
    args = []
    options = {}
    type_ = Bool
    result = build_type(type_, options, mixin, field, cls)
    assert isinstance(result, fields.Bool), \
        "build_type should return a Bool field"

    origin = type(None)
    args = []
    options = {}


# Generated at 2022-06-25 16:05:25.366416
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo(typing.Generic[A]):
        pass
    schemaf = SchemaF()
    assert(schemaf.dumps([], many=True) == "[]")
    assert(schemaf.dumps(Foo(), many=False) == "{}")


# Generated at 2022-06-25 16:05:33.272110
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class ExampleClass0_0:
        val = (1, 2, 3)

    class ExampleClass0_1:
        val = None  # type: typing.List[int]

    class ExampleClass0_2:
        val = "e"

    class ExampleClass0_3(Schema):
        val = fields.List(fields.Int())

    class ExampleClass0_4(Schema):
        val = fields.Nested(ExampleClass0_3)

    class ExampleClass0_5(Schema):
        val = fields.List(fields.Nested(ExampleClass0_3))

    schema_f_0_0: SchemaF[ExampleClass0_0] = SchemaF()
    schema_f_0_1: SchemaF[ExampleClass0_1] = SchemaF()
    schema_f_0_

# Generated at 2022-06-25 16:05:35.384741
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema_0 = SchemaF()
    schema_0.dump(0)



# Generated at 2022-06-25 16:05:40.469845
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    _SchemaF_loads_test_obj_0 = SchemaF()
    _SchemaF_loads_json_data_0 = b''
    _SchemaF_loads_unknown_0 = 'ignore'
    _SchemaF_loads_dict_0 = _SchemaF_loads_test_obj_0.loads(_SchemaF_loads_json_data_0, _SchemaF_loads_unknown_0)


# Generated at 2022-06-25 16:05:41.834409
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    timestamp_field = _TimestampField()
    return timestamp_field.__class__



# Generated at 2022-06-25 16:05:47.139805
# Unit test for function build_type
def test_build_type():
    class TestClass1(Schema):
        attr = fields.String()

    class TestClass2(Schema):
        attr = fields.String()

    class TestClass3(Schema):
        attr = fields.String()

    class OtherMixin(metaclass=abc.ABCMeta):
        pass

    @dataclasses.dataclass
    class TestClass4(OtherMixin):
        attr = build_type(typing.List[TestClass1], {}, type(OtherMixin),
                          dataclasses.field(type=typing.List[TestClass2]),
                          TestClass4)


# Generated at 2022-06-25 16:05:58.903614
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields

    class UserF(typing.TypedDict):
        name: str
        age: int

    class UserFSchema(Schema):
        name = fields.Str()
        age = fields.Int()

    uf = UserF(name="Michal", age=25)
    uf_list = [UserF(name="Michal", age=25)]

    schema = UserFSchema()
    schema_f = SchemaF()

    assert isinstance(schema.dumps(uf), str)
    assert isinstance(schema_f.dumps(uf), str)

    assert schema.dumps(uf) == schema_f.dumps(uf)
    assert schema.dumps(uf_list) == schema_f.dumps(uf_list)


# Unit test

# Generated at 2022-06-25 16:06:02.089879
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class Test:
        var1: str
        var2: int
        var3: typing.List[typing.Union[int, str]]

    assert isinstance(build_schema(Test, Mixin, False, True), SchemaF)



# Generated at 2022-06-25 16:06:28.544901
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class B:
        id: int

    @dataclass
    class A:
        data: int
        data2: str
        data3: B

    schema = build_schema(A, None, True, False)
    assert A.schema().__name__ == 'ASchema'
    assert str(schema.Meta.fields) == "('data', 'data2', 'data3')"
    schema_instance = schema()
    instance = schema_instance.dumps(A(5, 'data2', B(7)))
    assert instance == '{"data": 5, "data2": "data2", "data3": {"id": 7}}'


# Generated at 2022-06-25 16:06:33.277111
# Unit test for function build_schema
def test_build_schema():
    class SomeObject:
        def __init__(self):
            pass
    
    class Mixin:
        def __init__(self):
            pass

    @dataclass_json
    @dataclass(frozen=True)
    class TestSchema(Mixin):
        i: int = field(metadata=dict(dataclasses_json=dict(mm_field=fields.Int(required=False))))
        f: float = field(metadata=dict(dataclasses_json=dict(mm_field=fields.Float(required=False))))
        s: str = field(metadata=dict(dataclasses_json=dict(mm_field=fields.Str(required=False))))
        b: bool = field(metadata=dict(dataclasses_json=dict(mm_field=fields.Bool(required=False))))
        l

# Generated at 2022-06-25 16:06:35.335746
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f = SchemaF()
    schema_f.loads("")


# Generated at 2022-06-25 16:06:46.043459
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f_loads_0 = SchemaF()
    json_data_loads_0 = b'{"a": 5}'
    many_loads_0 = b'{"a": 5}'
    partial_loads_0 = b'{"a": 5}'
    unknown_loads_0 = b'{"a": 5}'
    a_loads_0 = schema_f_loads_0.loads(  # type: ignore
        json_data=json_data_loads_0, many=many_loads_0, partial=partial_loads_0,
        unknown=unknown_loads_0)
    assert isinstance(a_loads_0, dict)
    assert a_loads_0["a"] == 5


# Generated at 2022-06-25 16:06:52.615472
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f_0 = SchemaF()
    json_data_0: JsonData = None
    many_0: bool = False
    partial_0: bool = None
    unknown_0: str = None
    res_0 = schema_f_0.loads(json_data_0, many_0, partial_0, unknown_0)
    res_1 = schema_f_0.loads(json_data_0, many_0, partial_0, str)


# Generated at 2022-06-25 16:07:06.582410
# Unit test for function build_schema
def test_build_schema():
    from utils import parse_dataclass_args, dataclass_asdict, dataclass
    # case 0:
    class A:
        foo: typing.Optional[int]
    class B:
        foo: int
    class C:
        foo: typing.Optional[int]
    A_schema = build_schema(A, None, False, False)
    B_schema = build_schema(B, None, False, False)
    assert isinstance(A_schema, type)
    assert isinstance(B_schema, type)

    assert A_schema.Meta.fields == ('foo',)
    assert B_schema.Meta.fields == ('foo',)
    dump_a = A_schema().dump(A())
    dump_b = B_schema().dump(B())
   

# Generated at 2022-06-25 16:07:11.163397
# Unit test for function schema
def test_schema():
    # Test dataclass
    # with no type
    @dataclass_json
    @dataclass(init=False)
    class Test_0:
        name: str
        num: int

    # Test dataclass with optional type
    @dataclass_json
    @dataclass(init=False)
    class Test_1:
        name: str
        num: typing.Optional[int]

    # Test dataclass with default value for type
    @dataclass_json
    @dataclass(init=False)
    class Test_2:
        name: str
        num: typing.Optional[int] = 5

    # Test dataclass with default factory for type
    @dataclass_json
    @dataclass(init=False)
    class Test_3:
        name: str
       

# Generated at 2022-06-25 16:07:13.540764
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema_f_0 = SchemaF()
    obj_f_0 = [2, 3]

    result_f_0 = schema_f_0.dump(obj_f_0)
    assert result_f_0 == [2, 3], 'Incorrect value of result'


# Generated at 2022-06-25 16:07:19.755759
# Unit test for function build_schema
def test_build_schema():
    class TestMixin:
        def do_something():
            return

    @dataclass_json
    @dataclass
    class TestDataClass:
        opt_str: typing.Optional[str] = None
        mixed_list: typing.List[TestMixin]
        mixed_list_opt: typing.List[typing.Optional[TestMixin]] = None
        mixed_optional_list: typing.Optional[typing.List[TestMixin]] = None

    dc_schema = build_schema(TestDataClass, TestMixin, False, False)

    assert hasattr(dc_schema.Meta, 'fields')
    assert hasattr(dc_schema, 'make_testdataclass')
    assert hasattr(dc_schema, 'dump')
    assert hasattr(dc_schema, 'dumps')

# Generated at 2022-06-25 16:07:24.341773
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class _TestSchema(Schema):
        pass

    @dataclass
    class _Test:
        a: int
        b: str

    test_schema = _TestSchema()

    test_instance = _Test(0, 'a')
    test_result_instance_string = test_schema.dumps(test_instance)

    test_instance_list = [_Test(0, 'a'), _Test(1, 'b')]
    test_result_instance_list_string = test_schema.dumps(test_instance_list)

    # test instance as input should return string
    assert isinstance(test_result_instance_string, str)

    # test instance list as input should return string
    assert isinstance(test_result_instance_list_string, str)


# Generated at 2022-06-25 16:08:20.031159
# Unit test for function build_type
def test_build_type():
    class MySchema(SchemaType):
        class Meta:
            unknown = "EXCLUDE"

    class M:
        name: MySchema


# Generated at 2022-06-25 16:08:21.717947
# Unit test for function build_type
def test_build_type():
    build_type(list, {}, "", "", 0)


# Generated at 2022-06-25 16:08:28.985856
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass, field
    from typing import List

    @dataclass
    class SimpleDataClass:
        my_str: str
        my_int: int
        my_list: List[int]

    sdc_schema = schema(SimpleDataClass, None, False)
    assert isinstance(sdc_schema['my_str'], fields.Field)
    assert isinstance(sdc_schema['my_int'], fields.Field)
    # TODO this should be a list field but it is not the case at the moment. Fix it
    assert isinstance(sdc_schema['my_list'], fields.Field)
    # def test_case_2():
    #     schema_f_2 = SchemaF(String)
    #     schema_f_3 = SchemaF(2

# Generated at 2022-06-25 16:08:40.015541
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    data = [1, 2, 3]
    json_data = schema_f_0.dump(data)  # type: ignore
    assert isinstance(json_data, list)
    assert json_data == data

    data = [1, 2, 3]
    json_data = schema_f_0.dump(data, many=True)  # type: ignore
    assert isinstance(json_data, list)
    assert json_data == data

    data = 1
    json_data = schema_f_0.dump(data)  # type: ignore
    assert isinstance(json_data, int)
    assert json_data == data

    data = 1
    json_data = schema_f_0.dump(data, many=False)  # type: ignore
    assert isinstance(json_data, int)
    assert json

# Generated at 2022-06-25 16:08:46.010461
# Unit test for function schema
def test_schema():
    class Cls:
        def __init__(self, a: int, b: typing.List[int]):
            self.a = a
            self.b = b
    cls = SchemaType.__bases__[0]
    # The class schema is that of the schema of the class, with the fields for each of the features
    # metadata is the dataclass_json decorator with the dataclasses_json field
    # field is the field which is a dataclasses.Field
    assert schema(Cls, None, False) == schema(cls, None, False)

# Generated at 2022-06-25 16:08:47.600711
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class TestClassF:
        pass

    schema_f = SchemaF()
    schema_f.load([TestClassF()])
    schema_f.load(TestClassF())


# Generated at 2022-06-25 16:08:59.355378
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from marshmallow import Schema as MSchema
    from typing import Optional, Union, List, Dict

    @dataclass
    class Int(MSchema):
        int_: int

    @dataclass
    class MyDC:
        d: Optional[Int]
        l: List[Int]
        o: Union[str, int]

    options = {}
    mixin = None
    field = dc_fields(MyDC)[0]
    cls = MyDC

    type_ = field.type
    origin = getattr(type_, '__origin__', type_)
    args = [a for a in getattr(type_, '__args__', []) if a is not type(None)]

    #assert type(build_type(type_, options, mixin, field

# Generated at 2022-06-25 16:09:10.962644
# Unit test for function schema
def test_schema():
    @dataclasses.dataclass
    class RawClassTrue:
        def __init__(self, a=2):
            self.a = a

        def __eq__(self, other):
            return other.a == self.a

    assert schema(RawClassTrue, [RawClassTrue], True) == {"a": fields.Int()}
    assert schema(RawClassTrue, [RawClassTrue], False) == {"a": fields.Int()}

    @dataclasses.dataclass
    class RawClassFalse:
        def __init__(self, a=2):
            self.a = a

        def __eq__(self, other):
            return other.a == self.a

    assert schema(RawClassFalse, [RawClassFalse], True) == {"a": fields.Int()}

# Generated at 2022-06-25 16:09:17.450630
# Unit test for function build_schema
def test_build_schema():
    mixin = dataclass_json_config.Mixin
    infer_missing = False
    partial = True
    bad_cls = int
    good_cls = dict

    assert build_schema(bad_cls, mixin, infer_missing, partial) is not None
    assert build_schema(good_cls, mixin, infer_missing, partial) is not None

# Generated at 2022-06-25 16:09:25.016267
# Unit test for function build_type
def test_build_type():
    # schema_f_1 = SchemaF() - Not ImplementedError
    schema_f_2 = SchemaType[PersonSchema]()
    schema_f_3 = SchemaType[DataPoint]()
    schema_f_4 = SchemaType[DataPointJSON]()
    schema_f_5 = SchemaType[DataPointMessageSchema]()
    schema_f_6 = SchemaType[Mixin]()
    schema_f_7 = SchemaType[MixinJSON]()
    schema_f_8 = SchemaType[MixinMessageSchema]()
    schema_f_9 = SchemaType[DCPerson]()
    schema_f_10 = SchemaType[DCPersonJSON]()
    schema_f_11 = SchemaType[DCPersonMessageSchema]()
    schema_f

# Generated at 2022-06-25 16:11:59.077515
# Unit test for function schema
def test_schema():
    from typing import List
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    @dataclass_json(letter_case=True)
    @dataclass
    class TestData:
        # Required fields must be defined first!
        aa: int
        bb: str
        #  cc: Decimal
        # Optional fields come after required fields
        dd: int = None

        def test_schema_factory_0(self):
            # Testing SchemaF proper instantiation
            schema_f = SchemaF()
            assert isinstance(schema_f, SchemaF)
        def test_schema_factory_1(self):
            # Testing SchemaF proper instantiation
            schema_f = SchemaF()

# Generated at 2022-06-25 16:12:05.421769
# Unit test for function schema
def test_schema():
    @dataclass_json
    @dataclass
    class Book:
        title: str
        author: str
        isbn: str
        priced: Decimal
        book_type: str

    assert schema(Book, dataclass_json, False) == {
        'title': fields.Str(),
        'author': fields.Str(),
        'isbn': fields.Str(),
        'priced': fields.Decimal(),
        'book_type': fields.Str(),
    }



# Generated at 2022-06-25 16:12:12.077671
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Person:
        def __init__(self, name: str, age: int):
            self.name = name
            self.age = age

    class PersonSchema(SchemaF):
        name = fields.String()
        age = fields.Integer()

        class Meta:
            unknown = EXCLUDE

    schema = PersonSchema()
    p1 = Person("Bert", 30)
    p2 = Person("Ernie", 32)
    json_encoded = schema.dumps([p1, p2], many = True)
    p1_encoded = schema.dumps(p1, many = False)
    p2_encoded = schema.dumps(p2, many = False)


# Generated at 2022-06-25 16:12:21.315379
# Unit test for function build_type
def test_build_type():
    assert not _is_new_type(list)
    assert not _is_new_type(dict)
    assert not _is_new_type(typing.Dict)
    assert str(_get_type_origin(typing.List)) == "<class 'list'>"
    assert str(_get_type_origin(typing.Dict)) == "<class 'dict'>"
    assert str(_get_type_origin(typing.Tuple)) == "<class 'tuple'>"
    assert str(_get_type_origin(typing.List[str])) == "<class 'list'>"
    assert str(_get_type_origin(typing.Dict[int, str])) == "<class 'dict'>"
    assert str(_get_type_origin(typing.Tuple[int, str])) == "<class 'tuple'>"