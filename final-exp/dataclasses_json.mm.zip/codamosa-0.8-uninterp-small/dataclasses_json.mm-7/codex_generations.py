

# Generated at 2022-06-25 16:02:39.762077
# Unit test for function build_schema
def test_build_schema():
    schema_var_0 = build_schema(CommonConfig, Optional[CatchAllVar], False, False)
    # isinstance check of created type
    assert(isinstance(schema_var_0, type))
    # check that schema_var_0 is not None
    assert schema_var_0 is not None
    # check that schema_var_0 is not none
    #assert schema_var_0 is not None
    # check that schema_var_0 is type 'class'
    assert (schema_var_0 is type)


# Generated at 2022-06-25 16:02:45.647467
# Unit test for function schema
def test_schema():
    class A(mixin, object):
        x: str
        y: typing.Optional[str]
        z: typing.Optional[typing.Dict[str, str]]

    a = A('case', 'lower', {})
    assert schema(A, mixin, True) == {'x': fields.Str(missing="")}



# Generated at 2022-06-25 16:02:49.173636
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    # Create an instance of SchemaF
    schema_f_0 = SchemaF()
    json_data = {'value': 'hi'}
    assert schema_f_0.loads(json_data) == {'value': 'hi'}


# Generated at 2022-06-25 16:02:57.804339
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass

    @dataclass
    class TestDataclass:
        some_data: str
        some_optional_data: Optional[str]
        some_union_data: Union[str, None]
        some_dict_data: Optional[Dict[str, int]]

    test_build_schema_0 = build_schema(TestDataclass, None, True, None)
    test_build_schema_1 = build_schema(TestDataclass, None, True, None)
    assert test_build_schema_0 is test_build_schema_1


# Generated at 2022-06-25 16:03:05.328039
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclass
    class dataclass_0:
        a: str
        b: int

    @dataclass
    class dataclass_1:
        a: typing.List[dataclass_0]

    schema_f_0 = SchemaF()
    json_data_0: str = schema_f_0.dumps(dataclass_1(
        a=[dataclass_0(a='str_0', b=0)]))
    assert json_data_0 == '[{"a": "str_0", "b": 0}]'


# Generated at 2022-06-25 16:03:09.459992
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    optional_0 = None
    schema_f_0 = SchemaF()
    optional_1 = None
    schema_f_1 = SchemaF()


# Generated at 2022-06-25 16:03:17.784128
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class CustomEncoder(_ExtendedEncoder):
        def default(self, o):
            if isinstance(o, datetime):
                return o.isoformat()
            return o

    encoder = CustomEncoder()
    encoder_cfg_0 = {'t': datetime(2019, 11, 30, 23, 30, 30, 30)}
    schema_f_0 = SchemaF(encoder=encoder)
    # dumps class method of SchemaF should return str
    assert isinstance(schema_f_0.dumps(encoder_cfg_0), str)



# Generated at 2022-06-25 16:03:25.781334
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    test_obj_0 = 's'
    test_obj_1 = ['s']
    test_obj_2 = {'s': 's'}
    test_obj_3 = [{'s': 's'}]
    test_many_0 = True
    test_many_1 = False
    schema_f_0 = SchemaF()
    schema_f_1 = SchemaF()
    res_0 = schema_f_0.dump(test_obj_0)
    res_1 = schema_f_0.dump(test_obj_1)
    res_2 = schema_f_0.dump(test_obj_2)
    res_3 = schema_f_0.dump(test_obj_3)

# Generated at 2022-06-25 16:03:31.035278
# Unit test for function schema
def test_schema():
    class dataclass_test_0(dataclasses.dataclass):
        val_0: typing.Any
        val_1: typing.Any
        val_2: typing.Any
        val_3: typing.Any

    # Test 1 - both field present
    override_0: typing.Dict[str, typing.Any] = {'val_0': None, 'val_1': None}
    cls_0 = dataclass_test_0
    mixin_0 = dataclass_json.dataclass_json
    infer_missing_0 = False
    ret_0 = schema(cls_0, mixin_0, infer_missing_0)
    assert ret_0 is not None


# Generated at 2022-06-25 16:03:32.409740
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    optional_0 = None
    schema_f_0 = SchemaF()



# Generated at 2022-06-25 16:03:48.689818
# Unit test for function build_schema
def test_build_schema():
    from typing import Optional
    from dataclasses import dataclass

    @dataclass
    class A:
        v0: str
        v1: Optional[str]
        v2: Optional[int]

    schema = build_schema(A, {}, False, False)
    #print(f"schema: {schema}")

    s0 = schema()
    print(f"s0: {s0}")

    assert type(s0.fields['v1']) == fields.Field
    assert s0.fields['v1'].allow_none is True

# Generated at 2022-06-25 16:03:49.551224
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()


# Generated at 2022-06-25 16:03:51.533946
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert isinstance(field, _IsoField)


# Generated at 2022-06-25 16:03:59.516635
# Unit test for function schema
def test_schema():
    from typing import Optional
    from dataclasses import dataclass, field
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class User(DataClassJsonMixin):
        username: str
        password: str
        first_name: str
        last_name: str
        age: int = None
        active: Optional[bool] = None
        admin: bool = False
        misc: Optional[str] = field(metadata={'mm_field': fields.String(attribute='misc_field')})
        roles: list = field(default_factory=list)
        extra: dict = field(default_factory=dict)

    result_0 = schema(User, DataClassJsonMixin, True)

# Generated at 2022-06-25 16:04:09.914216
# Unit test for function build_type
def test_build_type():
    warnings.filterwarnings('ignore')

    class MyDataclass(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b
        def __eq__(self, other):
            return self.a == other.a and self.b == other.b

    from dataclasses import dataclass, field
    @dataclass
    class MyEnum(Enum):
        a: int
        b: int

    @dataclass
    class MyDataclass1:
        a: int
        b: MyDataclass

    @dataclass
    class MyDataclass2:
        a: typing.Optional[int]
        b: typing.Optional[MyDataclass]

    @dataclass
    class MyDataclass3:
        a: typing

# Generated at 2022-06-25 16:04:11.434181
# Unit test for function schema
def test_schema():
    pass



# Generated at 2022-06-25 16:04:13.061541
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    assert not True


# Generated at 2022-06-25 16:04:22.159315
# Unit test for function build_type
def test_build_type():
    # Test the type of the output of build_type
    class test_case_0(SchemaType):
        # Test if the output of build_type would be an SchemaType
        test_field_0 = fields.Bool()

        @post_load
        def make_test_case_0(self, data, **kwargs):
            return test_case_0_class(**data)

    @dataclass_json
    @dataclass
    class test_case_0_class:
        test_field_0: bool

        def __post_init__(self):
            self.test_field_0 = bool_0



# Generated at 2022-06-25 16:04:25.610282
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()
    bool_0 = False
    assert bool_0


# Generated at 2022-06-25 16:04:35.774850
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    bool_0 = False
    str_0 = None
    str_1 = "Q"
    str_2 = "gt"
    test_SchemaF_load_0_obj = None
    test_SchemaF_load_0_0_obj = None
    test_SchemaF_load_0_1_obj = None
    test_SchemaF_load_0_0_0_obj = None
    test_SchemaF_load_0_0_1_obj = None
    test_SchemaF_load_0_0_2_obj = None
    test_SchemaF_load_0_0_0_0_obj = None
    test_SchemaF_load_0_0_0_1_obj = None

# Generated at 2022-06-25 16:04:50.503943
# Unit test for function schema
def test_schema():
    dc_0 = _decode_dataclass(cls)
    schema_0 = schema(dc_0, cls, infer_missing)


# Generated at 2022-06-25 16:04:52.399766
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f = SchemaF()
    result = schema_f.loads('[]')
    assert [] == result
    result = schema_f.loads('{}')
    assert {} == result


# Generated at 2022-06-25 16:05:04.105418
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo:
        def __init__(self, val):
            self.val = val
        def __eq__(self, other):
            return self.val == other.val
        def __ne__(self, other):
            return not self == other
        def __hash__(self):
            return hash((self.val))
    class Bar:
        def __init__(self, val):
            self.val = val
        def __eq__(self, other):
            return self.val == other.val
        def __ne__(self, other):
            return not self == other
        def __hash__(self):
            return hash((self.val))
    class Foobar:
        def __init__(self, val):
            self.val = val

# Generated at 2022-06-25 16:05:12.238401
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from decimal import Decimal

    @dataclass
    class MySchema:
        t: str

    @dataclass
    class MySchema2:
        t:MySchema

    schema = schema(MySchema, Schema, infer_missing=False)
    assert len(schema) == 1
    assert isinstance(schema['t'], fields.Field)

    schema = schema(MySchema2, Schema, infer_missing=False)
    assert len(schema) == 1
    assert isinstance(schema['t'], fields.Field)

    @dataclass
    class MySchema3:
        t: typing.Union[MySchema, str]

    schema = schema(MySchema3, Schema, infer_missing=False)

# Generated at 2022-06-25 16:05:15.602399
# Unit test for constructor of class _IsoField
def test__IsoField():
    __IsoField = _IsoField()
    assert __IsoField.default_error_messages == {'required': 'Missing data for required field.'}


# Generated at 2022-06-25 16:05:24.081495
# Unit test for function build_type
def test_build_type():
    class Class1:
        pass
    class Class2(Class1):
        pass
    class Class3(Class1):
        pass
    class Class4:
        pass
    class Class5(Class4):
        pass

    class Schema1(Schema):
        pass
    class Schema2(Schema):
        pass

    class Schema3(Schema):
        pass
    class Schema4(Schema):
        pass

    class Schema5(Schema):
        pass
    class Schema6(Schema):
        pass

    import typing
    class A(typing.Dict[str,str]):
        pass
    class B(typing.Dict[str,str]):
        pass
    class C(typing.Dict[str,str]):
        pass


# Generated at 2022-06-25 16:05:28.440271
# Unit test for function schema
def test_schema():
    # Case 0:
    # Create a dataclass object and check if schema works.
    @dataclass
    class Person:
        name: str
        age: int
    Person.schema()
    
    # Case 1:
    @dataclass
    class Person:
        name: str
        age: int
        zipcode: int = 64321
    schema(Person)
    # Case 2:
    @dataclass
    class Person:
        name: str
        age: int
        zipcode: int
    schema(Person)


# Generated at 2022-06-25 16:05:30.159657
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    _TimestampField()


# Generated at 2022-06-25 16:05:32.747267
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f_loads = SchemaF.loads


# Generated at 2022-06-25 16:05:41.731771
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class FakeSchema(Schema):
        pass

    fake_schema = FakeSchema()

    class TestSchemaF(SchemaF):

        def __init__(self):
            super().__init__()

        def dump(self, obj: TOneOrMulti,
                 many: bool = None) -> TOneOrMultiEncoded:
            return fake_schema.dump(obj, many)

    schema_f_0 = TestSchemaF()
    int_list = [1, 2, 3]
    int_list_encoded = schema_f_0.dump(int_list)
    assert int_list == int_list_encoded
    str_list = ['a', 'b', 'c']
    str_list_encoded = schema_f_0.dump(str_list)

# Generated at 2022-06-25 16:06:13.317785
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass

    from dataclasses_json import dataclass_json

    @dataclass
    class Point:
        x: int
        y: int

    @dataclass_json
    @dataclass
    class Point3D(Point):
        z: int

    @dataclass_json
    @dataclass
    class Feature:
        name: str
        geom: Point3D

    assert schema(Feature, Point3D, False) == {
        'name': fields.Str(),
        'geom': fields.Nested(Point3D.schema, missing=None)
    }



# Generated at 2022-06-25 16:06:14.204985
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()



# Generated at 2022-06-25 16:06:18.646266
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    """
    When TEncoded is a primitive then TOneOrMultiEncoded is also a primitive.
    """
    class SchemaF0(SchemaF[typing.Dict[str, TEncoded]]):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    x: typing.Dict[str, TOneOrMultiEncoded] = {"a": 1}
    schema_f_0 = SchemaF0()
    res = schema_f_0.load(x)


# The only rationale for these unit tests is to make sure that mypy does not complain
# about this use case.

# Generated at 2022-06-25 16:06:25.706978
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Test_SchemaF_dumps_0(SchemaF):
        class Meta:
            pass

    test_SchemaF_dumps_0 = Test_SchemaF_dumps_0()

    test_data_0 = {
        "data": "test"
    }

    result_0 = test_SchemaF_dumps_0.dumps(test_data_0)
    assert result_0 == '{"data": "test"}'


# Generated at 2022-06-25 16:06:30.572657
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass, field
    from dataclasses_json import dataclass_json
    from dataclasses_json.api import pydantic_encoder

    @dataclass_json
    @dataclass
    class DataClassFoo:
        i: int
        s: str

    @dataclass_json
    @dataclass
    class DataClassBar:
        i: int = field(metadata={'dataclasses_json': {'mm_field': fields.Int()}})
        s: str = field(metadata={'dataclasses_json': {'mm_field': fields.Str()}})

    foo = DataClassFoo(1, 'str')
    bar = DataClassBar(1, 'str')

    # test case for pydantic_encoder
    DataClassFooSche

# Generated at 2022-06-25 16:06:35.279104
# Unit test for function build_schema
def test_build_schema():
    class SubSubMixin:
        pass
    class SubMixin(SubSubMixin, metaclass = _JsonMixinMetaclass):
        pass
    class Mixin(SubMixin, metaclass = _JsonMixinMetaclass):
        dataclass_json_config = Config(infer_missing=False, partial=False)
    class SubSubDataClass(SubSubMixin):
        def __init__(self):
            self.i = 1
    class SubDataClass(SubMixin):
        def __init__(self):
            self.subsub = SubSubDataClass()
            self.subsub_i = 1
    class DataClass(Mixin):
        def __init__(self):
            self.subdataclass = SubDataClass()

# Generated at 2022-06-25 16:06:38.039058
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f_1 = SchemaF()
    schema_f_1.loads("")


# Generated at 2022-06-25 16:06:40.068482
# Unit test for constructor of class _IsoField
def test__IsoField():
    ins = _IsoField(required=True)
    assert ins.required == True


# Generated at 2022-06-25 16:06:41.699224
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField().__dict__ == fields.Field().__dict__



# Generated at 2022-06-25 16:06:42.674073
# Unit test for constructor of class _IsoField
def test__IsoField():
    x = _IsoField()


# Generated at 2022-06-25 16:07:28.843456
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # Case 1
    schema_f_1 = SchemaF()
    try:
        schema_f_1.dumps('test')
    except NotImplementedError:
        pass
    else:
        assert False


# Generated at 2022-06-25 16:07:31.263812
# Unit test for function schema
def test_schema():
    class TestCls:
        a = 1
    
    result = schema(TestCls, mixin=None, infer_missing=False)
    assert result == {}, \
        "The result is wrong: result is {}".format(result)


# Generated at 2022-06-25 16:07:32.117301
# Unit test for function schema
def test_schema():
    schema(schema, None, False)

# Generated at 2022-06-25 16:07:34.964393
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    schema_f_0 = SchemaF()
    schema_f_1 = SchemaF()
    schema_f_2 = SchemaF()

    res_0 = schema_f_0.dump
    res_1 = schema_f_1.dump
    res_2 = schema_f_2.dump


# Generated at 2022-06-25 16:07:38.335600
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_field = _IsoField(
        allow_none=True,
        error_messages={"required": "This field is required."},
        required=True,
    )
    assert iso_field.deserialize(None) is None
    assert iso_field.deserialize(None, None, None) is None
    assert iso_field.serialize(None) is None
    assert iso_field.serialize(None, None, None) is None



# Generated at 2022-06-25 16:07:47.756815
# Unit test for function build_type
def test_build_type():
    assert type(build_type(type(None), None, None, None, None)) == fields.Field
    assert type(build_type(str, None, None, None, None)) == fields.Str
    assert type(build_type(int, None, None, None, None)) == fields.Int
    assert type(build_type(float, None, None, None, None)) == fields.Float
    assert type(build_type(list, None, None, None, None)) == fields.List
    assert type(build_type(dict, None, None, None, None)) == fields.Dict
    assert type(build_type(bool, None, None, None, None)) == fields.Bool
    assert type(build_type(UUID, None, None, None, None)) == fields.UUID

# Generated at 2022-06-25 16:07:53.216806
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class FooFSchema(SchemaF[FooF]):
        name = fields.Str(required=True)
        age = fields.Int(required=False, allow_none=True)
        is_dev = fields.Bool(required=True)
        created = fields.DateTime(required=True)
        tag: fields.Str = fields.Str(required=False)

        @post_load
        def munchify(self, data: Dict[str, Any], **kwargs) -> FooF:  # type: ignore
            return FooF(**data)

    class Foo2F(FooF, typing.Generic[str]):
        name: str

    class Foo2F2(Foo2F[str], typing.Generic[str]):
        name: str


# Generated at 2022-06-25 16:07:54.399973
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    a = _TimestampField()
    assert a


# Generated at 2022-06-25 16:08:03.972198
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from .dataclasses_json import dataclass_json, config

    @dataclass
    class A:
        a: int
        b: str
        c: int = 123
        d: str = '456'

    @dataclass_json
    @dataclass
    class B:
        a: int
        b: str
        c: int = 123
        d: str = '456'

    @dataclass_json
    @dataclass
    class C:
        a: int
        b: str
        c: int = 123

    @config(mm_field=8)
    @dataclass_json
    @dataclass
    class D:
        a: int
        b: str
        c: int = 123

# Generated at 2022-06-25 16:08:08.949147
# Unit test for constructor of class _TimestampField
def test__TimestampField():

    field = _TimestampField()
    assert field.required == False
    assert field.attribute == None
    assert field.required == False
    assert field.error_messages == {'required': 'Missing data for required field.'}
    assert field.load_from == None
    assert field.dump_to == None
    assert field.validate_all == True
    assert field.allow_none == True


# Generated at 2022-06-25 16:09:53.659122
# Unit test for function schema
def test_schema():
    class MyClass:
        def __init__(self, field1, field2):
            self.field1 = field1
            self.field2 = field2

    class SchemaClass(Schema):
        field1 = fields.Int(missing=1, default=None)
        field2 = fields.Str(missing=1, default=None)

        @post_load
        def make_object(self, data, **kwargs):
            return MyClass(**data)

    schema_cls_0 = SchemaClass()

    data_dict_0 = {'field1': 1}
    data_dict_1 = {}

    data_json_0 = b'{"field1": 1}'
    data_json_1 = b'{}'


# Generated at 2022-06-25 16:09:59.855571
# Unit test for function build_type
def test_build_type():
    assert issubclass(build_type(int, {}, {}, {}, {}),
                      fields.Int)
    assert issubclass(build_type(typing.Mapping[int, float], {}, {}, {}, {}),
                      fields.Mapping)
    assert issubclass(build_type(typing.List[int], {}, {}, {}, {}),
                      fields.List)


# Generated at 2022-06-25 16:10:11.222708
# Unit test for function schema
def test_schema():
    from .mixins import SchemaMixin

    from typing import Optional
    from datetime import date

    @dataclass_json.dataclass_json(letter_case=dataclass_json.LetterCase.CAMEL)
    class UserSchema(SchemaMixin):
        __dataclass_fields__ = {
            'first_name': 'firstName'
        }

        first_name: str
        last_name: str = None
        age: int = None
        gender: typing.Optional[str] = None

    @dataclass_json.dataclass_json(letter_case=dataclass_json.LetterCase.CAMEL)
    class User:
        first_name: str
        last_name: str = None
        age: int = None
        gender: typing.Optional[str] = None

# Generated at 2022-06-25 16:10:13.328232
# Unit test for constructor of class _IsoField
def test__IsoField():
    obj_IsoField = _IsoField()


# Generated at 2022-06-25 16:10:18.660572
# Unit test for constructor of class _TimestampField

# Generated at 2022-06-25 16:10:20.159684
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    # Arrange
    timestamp_field = _TimestampField()
    # Assert
    assert timestamp_field is not None


# Generated at 2022-06-25 16:10:31.731713
# Unit test for function build_type
def test_build_type():
    import datetime

    class Person:
        def __init__(self, name, age):
            self.name = name
            self.age = age

    class PersonSchema(SchemaType):
        name = fields.Str()
        age = fields.Int()

    class Employee:
        def __init__(self, name, age, employee_id):
            self.name = name
            self.age = age
            self.employee_id = employee_id

    class EmployeeSchema(SchemaType):
        name = fields.Str()
        age = fields.Int()
        employee_id = fields.Str()

    class Person(Person):
        def eat(self, food):
            print(f'{self.name} eats {food}.')


# Generated at 2022-06-25 16:10:34.841783
# Unit test for constructor of class _IsoField
def test__IsoField():
    try:
        _ = _IsoField
    except:
        assert False



# Generated at 2022-06-25 16:10:37.400417
# Unit test for function schema
def test_schema():
    pass

# Generated at 2022-06-25 16:10:39.535895
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField is not None
    assert _IsoField() is not None
