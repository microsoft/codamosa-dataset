

# Generated at 2022-06-25 16:02:50.393546
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    @dataclass_json
    @dataclass
    class Person:
        name: str
        age: int

    schema = SchemaF[Person]()
    p = Person("Alex", 21)
    schema.load(p.to_dict())
    schema.load([p.to_dict()])

    class Cat:
        def __init__(self, name, age):
            self.name = name
            self.age = age

    @dataclass_json
    @dataclass
    class CatPerson:
        name: str
        age: int
        cat: Cat

    schema = SchemaF[CatPerson]()
    cp = CatPerson("Alex", 21, Cat("Bob", 3))
    schema.load(cp.to_dict())
    schema.load([cp.to_dict()])


# Unit

# Generated at 2022-06-25 16:02:56.652659
# Unit test for function schema
def test_schema():
    class Test:
        def __init__(self, x : int = 0, y : float = 0.0, z : str = '') -> None:
            self.x = x
            self.y = y
            self.z = z

    test_f = schema(Test, None, infer_missing=False)
    print('Test for function schema:')
    print(test_f)


# Generated at 2022-06-25 16:03:00.164782
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f_1 = SchemaF()
    result_1 = schema_f_1.loads('{"value" : 1}')
    assert result_1 == {'value':1}



# Generated at 2022-06-25 16:03:06.115765
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class SchemaF_dump_field(fields.Field):
        def _serialize(self, value, attr, obj, *args, **kwargs):
            return {}

    class SchemaF_dump_schema(SchemaF):
        field = SchemaF_dump_field()

    obj = ['a', 'b']
    res = SchemaF_dump_schema().dump(obj)
    obj = 'obj'
    res = SchemaF_dump_schema().dump(obj)


# Generated at 2022-06-25 16:03:08.935231
# Unit test for function schema
def test_schema():
    @dataclass_json
    class Person:
        name: str

# Generated at 2022-06-25 16:03:19.316952
# Unit test for function build_schema
def test_build_schema():
    class Base:
        pass
    class A:
        pass
    class B(Base):
        pass
    class C(Base):
        pass
    class D(C):
        pass
    class E(A):
        pass
    class F(D):
        pass
    class G(E):
        pass

    type_set_1 = set([Base, A, B, C, D])
    type_set_2 = set([Base, E, F, G])
    type_set_3 = set([A])
    type_set_4 = set()

    # Test case 1
    dict_out = get_type_set_dict(type_set_1)
    assert dict_out == {True: {A, Base, B, C}, False: {D}}

    # Test case 2
    dict_out = get_

# Generated at 2022-06-25 16:03:25.152644
# Unit test for function build_schema
def test_build_schema():
    class TestClass1(dataclass):
        """Spam class."""
        number: int = 1000

    class TestClass2(dataclass):
        """Spam class."""
        number: int = 1000
        name: str = "test"
        my_id: UUID = UUID("8b2aa1b3-a798-4b98-8cae-db20b7d91ab9")

    print (build_schema(TestClass1, mixin=BaseModel, infer_missing=True,
                        partial=False))
    print (build_schema(TestClass2, mixin=BaseModel, infer_missing=True,
                        partial=False))


# Generated at 2022-06-25 16:03:31.753964
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class Person:
        name: str = None
        age: int = None
        addr: str = None

    # Tests for the build_schema and schema functions

    # Test the build_schema function
    assert isinstance(build_schema(Person, SchemaF, True, True), SchemaF)

    # Tests for the schema function
    dc_schema = schema(Person, SchemaF, True)
    assert isinstance(dc_schema, dict)
    assert len(dc_schema) >= 3
    assert "name" in dc_schema
    assert isinstance(dc_schema["name"], Field)
    assert "age" in dc_schema
    assert isinstance(dc_schema["age"], Field)
    assert "addr" in dc_schema

# Generated at 2022-06-25 16:03:40.015467
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json.mm import MM
    class MMType(MM): pass

    @dataclass  # type: ignore
    class A(MMType):
        a: str
        b: int = 42
        c: typing.Optional[float] = None
        d: typing.Optional[float]
        e: typing.Optional[float]

    schema_f_0 = schema(A, MMType, False)
    assert schema_f_0 == {'a': fields.Str(), 'b': fields.Int(default=42), 'c': fields.Float(allow_none=True, default=None), 'd': fields.Float(allow_none=True), 'e': fields.Float(allow_none=True, missing=None)}


# Generated at 2022-06-25 16:03:41.188552
# Unit test for function schema
def test_schema():
    schema_f_1 = SchemaF(load_only=['class_name'])

# Generated at 2022-06-25 16:04:02.038751
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    schema_f_0 = SchemaF()
    assert schema_f_0._timestamp_field_0 == _TimestampField
    assert schema_f_0._timestamp_field_0._serialize.__code__.co_code == _TimestampField._serialize.__code__.co_code


# Generated at 2022-06-25 16:04:06.893860
# Unit test for function build_schema
def test_build_schema():
    if not sys.version_info >= (3, 7):
        return
    from typing import Type
    from dataclasses import dataclass
    
    @dataclass
    class Person:
        name: str
        age: int
        test: Optional[int]
    
    cls: Type['Person'] = Person
    mixin = None
    infer_missing = True
    partial = True

    DataClassSchema = build_schema(cls, mixin, infer_missing, partial)

    assert DataClassSchema._declared_fields.get('age').allow_none == False
    assert DataClassSchema._declared_fields.get('test').allow_none == True

# Generated at 2022-06-25 16:04:10.291843
# Unit test for function schema
def test_schema():
    class TestClass(object):
        def __init__(self, a: Optional[int]):
            self.a = a
    type_ = TestClass.__dict__['a'].__annotations__['a']
    # Check case of Union[int, None]
    if _is_optional(type_):
        assert True
    else:
        assert False


# Generated at 2022-06-25 16:04:20.109109
# Unit test for function build_type
def test_build_type():
  from typing import Any
  from dataclasses import dataclass, field
  from marshmallow import Schema
  from marshmallow.fields import Field, List

  from dataclasses_json.mm_field import build_type
  from dataclasses_json.utils import _is_optional

  @dataclass
  class TestTypeClass:
    amap: typing.Mapping[str, int]
    adict: typing.Dict[str, int]
    alist: typing.List[int]
    alist_type: typing.List[TestTypeClass]
    anoptional: typing.Optional[int]
    astr: str
    atuple: typing.Tuple[int, str]
    amany: typing.Any


# Generated at 2022-06-25 16:04:25.920712
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert isinstance(fields.DateTime(), _IsoField)
    assert isinstance(fields.Date(), _IsoField)



# Generated at 2022-06-25 16:04:31.536998
# Unit test for function build_schema
def test_build_schema():
    class _TestSchema(Schema):
        name = fields.Str()

    class _TestSchema2(Schema):
        name = fields.Str()
        age = fields.Int()

    @dataclass_json
    @dataclass
    class _TestDataClass:
        name: str

    assert build_schema(_TestDataClass, _TestSchema, False, False) is _TestSchema
    assert build_schema(_TestDataClass, _TestSchema2, False, False) is not _TestSchema
    assert build_schema(_TestDataClass, _TestSchema2, False, False).name is not None


# Generated at 2022-06-25 16:04:37.232841
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    @dataclass_json(field_encode=build_type)
    @dataclass
    class TestClass: 
        a: int
        b: str

    schema_f = SchemaF[TestClass]()
    test_obj = TestClass(1, 'a')
    res = schema_f.dump(test_obj)


# Generated at 2022-06-25 16:04:48.659965
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    cschema_f_0 = SchemaF()
    cschema_f_1 = SchemaF()

    data_str_0: typing.Optional[str] = "abc"
    data_str_1: typing.Optional[str] = "abc"
    data_str_2: typing.Optional[str] = "abc"
    data_str_3: typing.Optional[str] = "abc"


    t0: typing.Optional[str] = cschema_f_0.load(data_str_0)
    t1: typing.Optional[str] = cschema_f_0.load(data_str_1, unknown="def")
    t2: typing.Optional[str] = cschema_f_0.load(data_str_2, many=False)

# Generated at 2022-06-25 16:04:52.761496
# Unit test for function schema
def test_schema():
    class TestUser(SchemaF):
        id: int
        username: str
        active: bool = True


    assert schema(TestUser, mixin=None, infer_missing=False) == {
        'id': fields.Field(missing=None, allow_none=True),
        'username': fields.Field(missing=None, allow_none=True),
        'active': fields.Field(missing=True, allow_none=True)
    }



# Generated at 2022-06-25 16:05:04.379982
# Unit test for function build_schema
def test_build_schema():
    from typing import Optional, Union, List
    @dataclass_json
    @dataclass
    class Person:
        name: str = "John Doe"
        age: Optional[int] = None
        address: Union[str, Address] = "1600 Pennsylvania Avenue NW, Washington, DC 20500"
        country_codes: List[Union[int, str]] = ["1", 1]
        is_active: bool = False
        phone_numbers: List[Union[int, str]] = ["+1", 1]

    @dataclass_json
    @dataclass
    class Address:
        street: str
        zip: str
        city: str
        country: str = "USA"

    address = Address("1600 Pennsylvania Avenue NW",
                      "20500",
                      "Washington",
                      "USA")


# Generated at 2022-06-25 16:05:30.960375
# Unit test for function build_schema
def test_build_schema():
    # Test for empty input
    assert build_schema(None, None, None, None) == SchemaType

    # Test for simple dataclass
    @dataclass_json
    @dataclass
    class TestClass:
        f0: int

    test_class = TestClass(f0=0)
    test_class_schema: SchemaType = build_schema(TestClass, "mixin", False, False)
    assert isinstance(test_class_schema(), SchemaF)


if __name__ == "__main__":
    print("hello world")
    test_build_schema()
    print("goodbye world")

# Generated at 2022-06-25 16:05:38.153524
# Unit test for function build_type
def test_build_type():
    class Company:
        def __init__(self, name, company_id):
            self.name = name
            self.company_id = company_id

    @dataclass_json
    @dataclass
    class Person:
        name: str
        age: int
        company: Company

    @dataclass_json
    @dataclass
    class PersonInfo:
        obj: Person

    assert isinstance(PersonInfo.schema()().fields['obj'], fields.Nested)


# Generated at 2022-06-25 16:05:42.147473
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert type(field) == _IsoField
    field = _IsoField(required=True)
    assert type(field) == _IsoField
    field = _IsoField(load_only=True)
    assert type(field) == _IsoField
    field = _IsoField(dump_only=True)
    assert type(field) == _IsoField



# Generated at 2022-06-25 16:05:48.638379
# Unit test for method dump of class SchemaF

# Generated at 2022-06-25 16:05:50.140835
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert(isinstance(field, _IsoField))


# Generated at 2022-06-25 16:05:54.614676
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f_1 = SchemaF()
    # type: TOneOrMultiEncoded
    enc = {'__type': 'a', 'foo': 1, 'bar': 2}
    schema_f_1.loads(enc)  # type: TOneOrMulti


# Generated at 2022-06-25 16:06:02.872437
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    print("test_SchemaF_dump")
    class MySchema(SchemaF[A]):
        pass
    my_schema_0 = MySchema()
    my_schema_0.dump([1, 2, 3])
    class MySchema(SchemaF[A]):
        pass
    my_schema_1 = MySchema()
    my_schema_1.dump(1)
    class MySchema(SchemaF[A]):
        pass
    my_schema_2 = MySchema()
    my_schema_2.dump([1, 2, 3])
    class MySchema(SchemaF[A]):
        pass
    my_schema_3 = MySchema()
    my_schema_3.dump(1)

# Generated at 2022-06-25 16:06:09.968434
# Unit test for function build_type
def test_build_type():
    class Test(object):
        def test(self, a: str) -> int:
            pass
    schema_f_1 = SchemaF()
    field_options_1 = {}
    field_options_1["allow_none"] = True
    actual_result = build_type(str, field_options_1, Test, 1, Test)
    assert str(actual_result) == "<class 'marshmallow.fields.Str'>"


# Generated at 2022-06-25 16:06:13.395538
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Test0(SchemaF):
        a: int

    schema = Test0()
    data = schema.dump({'a': 1})
    result = schema.dumps(data)
    assert isinstance(result, str)


# Generated at 2022-06-25 16:06:17.723047
# Unit test for function build_schema
def test_build_schema():
    class TestSchema(Schema):
        foo = fields.String()

    dc = dataclass_json(SimpleDataClass, schema_class=TestSchema)


# Generated at 2022-06-25 16:07:05.719025
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    global schema_f_1
    schema_f_1 = SchemaF()
    assert schema_f_1.loads('[]', many=True) == []
    assert schema_f_1.loads('[]') == []
    assert schema_f_1.loads(b'[]', many=True) == []
    assert schema_f_1.loads(b'[]') == []
    assert schema_f_1.loads(bytearray(b'[]'), many=True) == []
    assert schema_f_1.loads(bytearray(b'[]')) == []

# Generated at 2022-06-25 16:07:08.898082
# Unit test for function build_type
def test_build_type():
    _build_type = build_type(datetime, {}, Schema, dc_fields(datetime)[0], datetime)
    assert(_build_type(datetime, {}) == datetime)
    test_case_0()



# Generated at 2022-06-25 16:07:14.695522
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class SchemaX(SchemaF):
        def __init__(self, *args, **kwargs):
            # noinspection PyTypeChecker
            super().__init__(self, *args, **kwargs)
            raise NotImplementedError()

    class SchemaY(SchemaF):
        def __init__(self, *args, **kwargs):
            # noinspection PyTypeChecker
            super().__init__(self, *args, **kwargs)
            raise NotImplementedError()

    def test_case_0(p: SchemaX):
        p.dumps(['x'])

    def test_case_1(p: SchemaX):
        p.dumps(['x'], many=True)

    def test_case_2(p: SchemaX):
        p

# Generated at 2022-06-25 16:07:24.351883
# Unit test for function build_schema
def test_build_schema():
    class _TestClass:
        @dataclass_json
        @dataclass
        class _TestDataClass:
            field1: str
            field2: int

            def __post_init__(self) -> None:
                pass

            def __eq__(self, other: '_TestDataClass') -> bool:
                """Compares equality of dataclass fields

                :param other: other object to compare with
                :type other: _TestDataClass
                :return: True if the dataclasses are equal
                :rtype: bool
                """
                return self.__dict__ == other.__dict__

    test_object = _TestClass._TestDataClass("test", 0)
    test_schema = build_schema(_TestClass._TestDataClass, None, False, False)
    test_dump = test_schema

# Generated at 2022-06-25 16:07:28.345319
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclass
    class Sample:
        pass

    schema_f = SchemaF[Sample]()
    assert schema_f.dumps(Sample()) == '{}'
    assert schema_f.dumps([Sample(), Sample()]) == '[{}, {}]'



# Generated at 2022-06-25 16:07:34.867857
# Unit test for function schema
def test_schema():
    class A:
        b: int
        c: str

    class B:
        d: int
        a: A
        e: typing.List[A]

    class C:
        # We could define schema in dataclass
        class Schema(SchemaType):
            pass

        a: A = A(b=1, c='2')
        d: typing.List[A] = [A(b=1, c='2'), A(b=3, c='4')]
        e: typing.Tuple[str, int] = ('test', 1)
        f: typing.Set[str] = {'set_test'}
        g: typing.Dict[str, int] = {'test': 1, 'test2': 2}


# Generated at 2022-06-25 16:07:36.007189
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    SchemaF.dumps(MappingSchema, "42.2")


# Generated at 2022-06-25 16:07:38.287765
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema_f_0 = SchemaF()

    # Call loads
    data = str()
    load = schema_f_0.loads(data)
    assert load == None

    # Call loads
    data = str()
    load = schema_f_0.loads(data)
    assert load == None



# Generated at 2022-06-25 16:07:39.525907
# Unit test for constructor of class _IsoField
def test__IsoField():
    # test case with no arguments
    _IsoField()



# Generated at 2022-06-25 16:07:48.594105
# Unit test for function build_type
def test_build_type():
    @dataclass_json
    @dataclass
    class TestCase0:
        name: str
        age: int
    @dataclass
    class TestCase1:
        name: str
        age: int
    @dataclass
    class TestCase2:
        name: str
        age: int
    @dataclass
    class TestCase3:
        name: str
        age: int
    @dataclass
    class TestCase4:
        name: str
        age: int
    @dataclass
    class TestCase5:
        name: str
        age: int
    @dataclass
    class TestCase6:
        name: str
        age: int
    @dataclass
    class TestCase7:
        name: str
        age: int

# Generated at 2022-06-25 16:10:11.470276
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass

    @dataclass
    class TestClass:
        pass

    type_ = TestClass
    options = {}
    mixin = {}
    field = None
    cls = None
    expected_result = fields.Field()
    type_ = getattr(type_, '__origin__', type_)
    origin = getattr(type_, '__origin__', type_)
    args = [inner(a, {}) for a in getattr(type_, '__args__', []) if
            a is not type(None)]

    if _is_optional(type_):
        options["allow_none"] = True

    if origin in TYPES:
        schema_f_result = TYPES[origin](*args, **options)

# Generated at 2022-06-25 16:10:13.327251
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    timestamp_field = _TimestampField()


# Generated at 2022-06-25 16:10:17.771177
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # Test case 0
    schema_f_0 = SchemaF()
    assert schema_f_0.dumps(obj=None, many=None) == 'null'
    # Test case 1
    schema_f_1 = SchemaF()
    assert schema_f_1.dumps(obj=list(), many=None) == '[]'
    # Test case 2
    schema_f_2 = SchemaF()
    assert schema_f_2.dumps(obj=dict(), many=None) == '{}'
    # Test case 3
    schema_f_3 = SchemaF()
    assert schema_f_3.dumps(obj=[None], many=None) == '[null]'
    # Test case 4
    schema_f_4 = SchemaF()

# Generated at 2022-06-25 16:10:21.226802
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class Test:
        x: int
        y: str
        z: typing.Union[int, str]
        q: typing.Optional[int]

    schema_f = build_schema(Test, ImmutableConfig, False, False)
    assert issubclass(schema_f, SchemaF)
    assert schema_f.Meta.fields == ('x', 'y', 'z', 'q')



# Generated at 2022-06-25 16:10:32.420098
# Unit test for function schema
def test_schema():
    class _Test0(metaclass=SchemaF):
        pass

    class Test1(metaclass=SchemaF):
        pass

    class Test2(metaclass=SchemaF):
        pass

    class Test3(metaclass=SchemaF):
        pass

    class Test4(metaclass=SchemaF):
        pass

    class Test5(metaclass=SchemaF):
        pass

    class Test6(metaclass=SchemaF):
        pass

    class Test7(metaclass=SchemaF):
        pass

    assert schema(_Test0, SchemaF, False) == {
    }

    assert schema(Test1, SchemaF, False) == {
        'test_0': fields.Int(allow_none=True)
    }


# Generated at 2022-06-25 16:10:38.631299
# Unit test for function schema
def test_schema():
    # define data classes for testing schema function
    from dataclasses import dataclass, fields
    from dataclasses_json import DataClassJsonMixin
    from dataclasses_json.mm_schema import SchemaF, schema


    @dataclass
    class Book(DataClassJsonMixin):
        title: str
        author: str
        pages: int
        price: float
        available: bool


    @dataclass
    class Dictionary(DataClassJsonMixin):
        words: typing.List[str]


    @dataclass
    class MyDictionary(Dictionary):
        pages: int


    # cases:
    #   - original case: title, author, pages, price and available fields
    #   - pages field is missing, should be inferred by link to Dictionary
    #   - words is missing

# Generated at 2022-06-25 16:10:48.554664
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    @dataclass
    class TestClass:
        var: str
    v_0: typing.Optional[str] = '{"var":"a"}'
    v_1: typing.Optional[str] = '"abc"'
    v_2: typing.Optional[typing.List[TestClass]] = '[{"var":"a"},{"var":"b"}]'
    v_3: typing.Optional[typing.List[TestClass]] = '[{"var":"a"},{"var":"b"}]'
    schema_f_0: SchemaF[TestClass] = dataclasses_json.config(
        typ=SchemaF[TestClass])(type(TestClass))(TestClass)
    v_4: typing.Optional[SchemaF[TestClass]] = schema_f_0

# Generated at 2022-06-25 16:10:54.333294
# Unit test for function schema
def test_schema():
    class MyObject(object):
        pass

    class MyMixin(object):
        pass

    class Test(MyMixin, object):
        i: int

    TestSchema = type(
        "TestSchema",
        (SchemaType[Test],),
        schema(Test, MyMixin, True))
    assert TestSchema.__name__ == "TestSchema"
    assert Test.__name__ == "Test"
    assert MyObject.__name__ == "MyObject"

# Generated at 2022-06-25 16:11:00.450988
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    tsField = _TimestampField()
    assert tsField.required == False
    #test_case_0()


# Generated at 2022-06-25 16:11:03.629815
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from marshmallow import Schema
    @dataclass
    class TestClass_0:
        bar: str
    assert SchemaType[TestClass_0] == "42"

test_schema()
test_case_0()
