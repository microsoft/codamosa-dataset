

# Generated at 2022-06-17 17:56:17.081086
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[int]
        f: typing.Optional[typing.List[int]]
        g: typing.Optional[typing.Dict[str, int]]
        h: typing.Optional[typing.Union[str, int]]
        i: typing.Optional[typing.Union[str, int, None]]
        j: typing.Optional[typing.Union[str, int, None, typing.List[int]]]

# Generated at 2022-06-17 17:56:26.318099
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    assert SchemaF[int].loads('1') == 1
    assert SchemaF[int].loads('[1]') == [1]
    assert SchemaF[int].loads(b'1') == 1
    assert SchemaF[int].loads(b'[1]') == [1]
    assert SchemaF[int].loads(bytearray('1', 'utf-8')) == 1
    assert SchemaF[int].loads(bytearray('[1]', 'utf-8')) == [1]
    assert SchemaF[int].loads(b'1', many=False) == 1
    assert SchemaF[int].loads(b'[1]', many=False) == 1

# Generated at 2022-06-17 17:56:29.134034
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 17:56:41.098404
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from marshmallow.exceptions import ValidationError
    from dataclasses_json.mm import Schema
    from dataclasses_json.utils import _is_optional, _is_new_type
    from dataclasses_json.core import _is_supported_generic, _is_collection
    from dataclasses_json.core import _UnionField, _TimestampField, _IsoField
    from dataclasses_json.core import _get_type_origin, _issubclass_safe
    from datetime import datetime
    from typing import List, Optional, Union, Dict, Tuple, Any, Callable, Mapping, MutableMapping

# Generated at 2022-06-17 17:56:48.813626
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str
        c: typing.Optional[int]
        d: typing.Optional[str]
        e: typing.Optional[typing.Union[str, int]]
        f: typing.Optional[typing.Union[str, int, None]]
        g: typing.Optional[typing.Union[str, int, None, A]]
        h: typing.Optional[typing.Union[str, int, None, typing.List[A]]]
        i: typing.List[A]
        j: typing.Optional[typing.List[A]]

# Generated at 2022-06-17 17:56:59.335543
# Unit test for function build_type
def test_build_type():
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from dataclasses_json.mm import Schema

    class MyEnum(Enum):
        A = 1
        B = 2

    class MySchema(Schema):
        pass

    class MyMixin:
        pass

    class MyClass:
        pass

    class MyClass2:
        pass

    class MyClass3:
        pass

    class MyClass4:
        pass

    class MyClass5:
        pass

    class MyClass6:
        pass

    class MyClass7:
        pass

    class MyClass8:
        pass

    class MyClass9:
        pass

    class MyClass10:
        pass

    class MyClass11:
        pass

    class MyClass12:
        pass


# Generated at 2022-06-17 17:57:05.755980
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    assert FooSchema().dumps(Foo(1, 'a')) == '{"a": 1, "b": "a"}'
    assert FooSchema().dumps([Foo(1, 'a'), Foo(2, 'b')]) == '[{"a": 1, "b": "a"}, {"a": 2, "b": "b"}]'



# Generated at 2022-06-17 17:57:16.335369
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str
        c: typing.List[int]
        d: typing.List[str]
        e: typing.Dict[str, int]
        f: typing.Dict[str, str]
        g: typing.Tuple[int, str]
        h: typing.Tuple[str, int]
        i: typing.Optional[int]
        j: typing.Optional[str]
        k: typing.Optional[typing.List[int]]
        l: typing.Optional[typing.List[str]]
        m: typing.Optional[typing.Dict[str, int]]

# Generated at 2022-06-17 17:57:27.326035
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from typing import Optional, Union
    from marshmallow import fields

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        a: Optional[A]

    @dataclass
    class C:
        a: Union[A, B]

    assert build_type(A, {}, None, None, None)(A, {}) == fields.Nested(A.schema(), field_many=False)
    assert build_type(Optional[A], {}, None, None, None)(Optional[A], {}) == fields.Nested(A.schema(), field_many=False, allow_none=True)
    assert build_type(Union[A, B], {}, None, None, None)(Union[A, B], {}) == _UnionField

# Generated at 2022-06-17 17:57:38.209464
# Unit test for function build_type
def test_build_type():
    from marshmallow import fields
    from dataclasses import dataclass
    from typing import List, Optional, Union
    from dataclasses_json import dataclass_json
    from marshmallow_enum import EnumField
    from marshmallow import Schema
    from dataclasses_json.mm import SchemaF
    from dataclasses_json.mm import build_type
    from dataclasses_json.utils import _is_new_type
    from dataclasses_json.utils import _is_optional
    from dataclasses_json.utils import _issubclass_safe
    from dataclasses_json.utils import _is_collection
    from dataclasses_json.utils import _get_type_origin
    from dataclasses_json.utils import _is_supported_generic
    from dataclasses_json.utils import _is_

# Generated at 2022-06-17 17:58:00.993319
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class MySchema(SchemaF[int]):
        pass
    assert MySchema().loads('1') == 1
    assert MySchema().loads('[1]') == [1]
    assert MySchema().loads(b'1') == 1
    assert MySchema().loads(b'[1]') == [1]
    assert MySchema().loads(bytearray(b'1')) == 1
    assert MySchema().loads(bytearray(b'[1]')) == [1]


# Generated at 2022-06-17 17:58:08.982183
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class A(typing.Generic[A]):
        pass
    class B(typing.Generic[A]):
        pass
    class C(typing.Generic[A]):
        pass
    class D(typing.Generic[A]):
        pass
    class E(typing.Generic[A]):
        pass
    class F(typing.Generic[A]):
        pass
    class G(typing.Generic[A]):
        pass
    class H(typing.Generic[A]):
        pass
    class I(typing.Generic[A]):
        pass
    class J(typing.Generic[A]):
        pass
    class K(typing.Generic[A]):
        pass
    class L(typing.Generic[A]):
        pass

# Generated at 2022-06-17 17:58:18.205341
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Person:
        name: str
        age: int

    class PersonSchema(SchemaF[Person]):
        name = fields.Str()
        age = fields.Int()

    p = Person('John', 42)
    ps = PersonSchema()
    assert ps.dumps(p) == '{"name": "John", "age": 42}'
    assert ps.dumps([p]) == '[{"name": "John", "age": 42}]'
    assert ps.dumps(p, many=True) == '[{"name": "John", "age": 42}]'
    assert ps.dumps([p], many=False) == '{"name": "John", "age": 42}'


# Generated at 2022-06-17 17:58:29.941993
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields
    from typing import List, Dict
    class MySchema(Schema):
        a = fields.Int()
    assert isinstance(SchemaF[Dict[str, int]].loads(MySchema(), b'{"a": 1}'), Dict[str, int])
    assert isinstance(SchemaF[List[Dict[str, int]]].loads(MySchema(), b'[{"a": 1}]'), List[Dict[str, int]])
    assert isinstance(SchemaF[Dict[str, int]].loads(MySchema(), b'{"a": 1}'), Dict[str, int])

# Generated at 2022-06-17 17:58:41.372806
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json, config
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int = 1
        c: typing.Optional[int] = None
        d: typing.Optional[str] = None
        e: typing.Optional[typing.List[int]] = None
        f: typing.Optional[typing.List[str]] = None
        g: typing.Optional[typing.List[typing.Optional[int]]] = None
        h: typing.Optional[typing.List[typing.Optional[str]]] = None
        i: typing.Optional[typing.List[typing.Optional[typing.List[int]]]] = None

# Generated at 2022-06-17 17:58:55.207513
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField

    @dataclass_json
    @dataclass
    class A:
        a: str
        b: int
        c: typing.List[str]
        d: typing.Dict[str, int]
        e: typing.Optional[str]
        f: typing.Optional[int]
        g: typing.Optional[typing.List[str]]
        h: typing.Optional[typing.Dict[str, int]]
        i: typing.Union[str, int]
        j: typing.Union[str, int, None]
        k: typing.Union[typing.List[str], typing.List[int]]

# Generated at 2022-06-17 17:59:02.992168
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str

    schema = build_schema(Test, None, False, False)
    assert schema.__name__ == 'TestSchema'
    assert schema.Meta.fields == ('a', 'b')
    assert isinstance(schema.a, fields.Int)
    assert isinstance(schema.b, fields.Str)
    assert schema.make_test.__name__ == 'make_test'
    assert schema.dumps.__name__ == 'dumps'
    assert schema.dump.__name__ == 'dump'



# Generated at 2022-06-17 17:59:04.467293
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class TestSchema(SchemaF[A]):
        pass

    assert TestSchema().dump([1, 2, 3]) == [1, 2, 3]
    assert TestSchema().dump(1) == 1


# Generated at 2022-06-17 17:59:15.184324
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields
    from dataclasses import dataclass
    from typing import List

    @dataclass
    class Foo:
        bar: str

    class FooSchema(SchemaF[Foo]):
        bar = fields.Str()

    @dataclass
    class Bar:
        foo: List[Foo]

    class BarSchema(SchemaF[Bar]):
        foo = fields.Nested(FooSchema, many=True)

    schema = BarSchema()
    assert schema.loads('{"foo": [{"bar": "baz"}]}') == Bar(foo=[Foo(bar='baz')])

# Generated at 2022-06-17 17:59:26.721468
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    assert SchemaF[int].dumps(1) == '1'
    assert SchemaF[int].dumps([1, 2, 3]) == '[1, 2, 3]'
    assert SchemaF[int].dumps([1, 2, 3], many=True) == '[1, 2, 3]'
    assert SchemaF[int].dumps([1, 2, 3], many=False) == '[1, 2, 3]'
    assert SchemaF[int].dumps(1, many=True) == '1'
    assert SchemaF[int].dumps(1, many=False) == '1'
    assert SchemaF[int].dumps(1, many=None) == '1'
    assert SchemaF[int].dumps(1, many=None, indent=2) == '1'
    assert Sche

# Generated at 2022-06-17 18:00:02.768599
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Foo(typing.Generic[A]):
        def __init__(self, a: A):
            self.a = a

    class FooSchema(SchemaF[Foo[A]]):
        a = fields.Field()

    foo = Foo(1)
    foo_schema = FooSchema()
    foo_schema.load(foo_schema.dump(foo))



# Generated at 2022-06-17 18:00:14.221557
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class A(typing.Generic[A]):
        def __init__(self, a: A):
            self.a = a

    class B(SchemaF[A]):
        a = fields.Field()

    assert B().dump(A(1)) == {'a': 1}
    assert B().dump([A(1), A(2)]) == [{'a': 1}, {'a': 2}]
    assert B().dump(A(1), many=False) == {'a': 1}
    assert B().dump([A(1), A(2)], many=True) == [{'a': 1}, {'a': 2}]
    assert B().dump(A(1), many=True) == [{'a': 1}]

# Generated at 2022-06-17 18:00:16.407480
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    from typing import List
    class MySchema(SchemaF[int]):
        pass
    schema = MySchema()
    schema.load([1, 2, 3])
    schema.load({'a': 1})
    schema.load(1)


# Generated at 2022-06-17 18:00:29.099919
# Unit test for function build_type
def test_build_type():
    assert build_type(typing.List[int], {}, None, None, None) == fields.List
    assert build_type(typing.List[typing.Optional[int]], {}, None, None, None) == fields.List
    assert build_type(typing.Optional[typing.List[int]], {}, None, None, None) == fields.List
    assert build_type(typing.Optional[typing.List[typing.Optional[int]]], {}, None, None, None) == fields.List
    assert build_type(typing.Optional[typing.List[typing.Optional[int]]], {}, None, None, None) == fields.List

# Generated at 2022-06-17 18:00:40.491937
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str


# Generated at 2022-06-17 18:00:53.751310
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class A(typing.Generic[A]):
        def dump(self, obj: typing.List[A], many: bool = None) -> typing.List[
            TEncoded]:  # type: ignore
            # mm has the wrong return type annotation (dict) so we can ignore the mypy error
            pass

        def dump(self, obj: A, many: bool = None) -> TEncoded:
            pass

        def dump(self, obj: TOneOrMulti,
                 many: bool = None) -> TOneOrMultiEncoded:
            pass

    a = A()
    a.dump([1, 2, 3])
    a.dump(1)
    a.dump(1, many=True)
    a.dump([1, 2, 3], many=True)


# Generated at 2022-06-17 18:01:01.280524
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int

    class ASchema(SchemaF[A]):
        a = fields.Int()

    assert ASchema().load({'a': 1}) == A(a=1)
    assert ASchema().load([{'a': 1}, {'a': 2}]) == [A(a=1), A(a=2)]


# Generated at 2022-06-17 18:01:07.636905
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[int]
        f: typing.Optional[typing.List[int]]
        g: typing.Optional[typing.Dict[str, int]]
        h: typing.Optional[typing.Union[int, str]]
        i: typing.Optional[typing.Union[int, typing.List[int]]]
        j: typing.Optional[typing.Union[int, typing.Dict[str, int]]]

# Generated at 2022-06-17 18:01:16.608084
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class A(typing.NamedTuple):
        a: int
        b: str

    class B(typing.NamedTuple):
        a: int
        b: str

    class C(typing.NamedTuple):
        a: int
        b: str

    class D(typing.NamedTuple):
        a: int
        b: str

    class E(typing.NamedTuple):
        a: int
        b: str

    class F(typing.NamedTuple):
        a: int
        b: str

    class G(typing.NamedTuple):
        a: int
        b: str

    class H(typing.NamedTuple):
        a: int
        b: str

    class I(typing.NamedTuple):
        a

# Generated at 2022-06-17 18:01:19.560972
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo = Foo(a=1, b='b')
    assert FooSchema().dumps(foo) == '{"a": 1, "b": "b"}'



# Generated at 2022-06-17 18:02:19.692284
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Foo:
        pass
    class FooSchema(SchemaF[Foo]):
        pass
    foo = Foo()
    foo_schema = FooSchema()
    foo_schema.dump(foo)
    foo_schema.dump([foo])
    foo_schema.dump(foo, many=False)
    foo_schema.dump([foo], many=True)
    foo_schema.dump(foo, many=True)
    foo_schema.dump([foo], many=False)


# Generated at 2022-06-17 18:02:28.272845
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Foo:
        pass
    class FooSchema(SchemaF[Foo]):
        pass
    foo = Foo()
    foo_schema = FooSchema()
    foo_schema.dump(foo)
    foo_schema.dump([foo])
    foo_schema.dump(foo, many=True)
    foo_schema.dump([foo], many=False)
    foo_schema.dump([foo], many=True)
    foo_schema.dump([foo], many=False)
    foo_schema.dump(foo, many=False)
    foo_schema.dump(foo, many=True)
    foo_schema.dump(foo, many=False)
    foo_schema.dump(foo, many=True)
    foo_schema.dump([foo], many=False)

# Generated at 2022-06-17 18:02:38.443465
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class A:
        a: int

    @dataclass_json
    @dataclass
    class B:
        a: A

    @dataclass_json
    @dataclass
    class C:
        a: typing.List[A]

    @dataclass_json
    @dataclass
    class D:
        a: typing.List[typing.Optional[A]]

    @dataclass_json
    @dataclass
    class E:
        a: typing.Optional[A]


# Generated at 2022-06-17 18:02:42.412358
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field._serialize(datetime(2020, 1, 1), None, None) == '2020-01-01T00:00:00'
    assert field._deserialize('2020-01-01T00:00:00', None, None) == datetime(2020, 1, 1)


# Generated at 2022-06-17 18:02:55.271531
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Foo:
        pass

    class FooSchema(SchemaF[Foo]):
        pass

    # mypy error: Argument 1 to "load" of "SchemaF" has incompatible type "List[Dict[str, Any]]"; expected "Union[List[Dict[str, Any]], Dict[str, Any]]"
    FooSchema().load([{}])

    # mypy error: Argument 1 to "load" of "SchemaF" has incompatible type "Dict[str, Any]"; expected "Union[List[Dict[str, Any]], Dict[str, Any]]"
    FooSchema().load({})

    # mypy error: Argument 1 to "load" of "SchemaF" has incompatible type "List[Dict[str, Any]]"; expected "Union[List[Dict[str, Any]

# Generated at 2022-06-17 18:03:06.684807
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from dataclasses_json.mm import Mm

    @dataclass_json
    @dataclass
    class A:
        a: str

    @dataclass_json
    @dataclass
    class B:
        b: A

    @dataclass_json
    @dataclass
    class C:
        c: typing.List[A]

    @dataclass_json
    @dataclass
    class D:
        d: typing.List[B]

    @dataclass_json
    @dataclass
    class E:
        e: typing.List[C]


# Generated at 2022-06-17 18:03:15.531664
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.Optional[int]
        d: typing.Optional[str]
        e: typing.Optional[typing.List[int]]
        f: typing.Optional[typing.List[str]]
        g: typing.Optional[typing.List[typing.Optional[int]]]
        h: typing.Optional[typing.List[typing.Optional[str]]]
        i: typing.Optional[typing.List[typing.Optional[typing.List[int]]]]

# Generated at 2022-06-17 18:03:25.324841
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError
    from dataclasses import dataclass
    from typing import List, Optional
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class Foo(DataClassJsonMixin):
        a: int
        b: Optional[str]

    @dataclass
    class Bar(DataClassJsonMixin):
        c: int
        d: Optional[str]

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    class BarSchema(SchemaF[Bar]):
        c = fields.Int()
        d = fields.Str()


# Generated at 2022-06-17 18:03:31.382562
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Person:
        name: str
        age: int

    class PersonSchema(SchemaF[Person]):
        name = fields.Str()
        age = fields.Int()

    person_schema = PersonSchema()
    person = person_schema.load({'name': 'John', 'age': 42})
    assert person.name == 'John'
    assert person.age == 42

    persons = person_schema.load([{'name': 'John', 'age': 42}, {'name': 'Jane', 'age': 43}], many=True)
    assert persons[0].name == 'John'
    assert persons[0].age == 42
    assert persons[1].name == 'Jane'
    assert persons

# Generated at 2022-06-17 18:03:41.481604
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from dataclasses import dataclass
    from marshmallow import fields

    @dataclass
    class Foo:
        a: int

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()

    assert FooSchema().loads('{"a": 1}') == Foo(a=1)
    assert FooSchema().loads('[{"a": 1}]') == [Foo(a=1)]