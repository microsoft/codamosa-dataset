

# Generated at 2022-06-17 17:56:12.279316
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field._serialize(datetime.now(), None, None) is not None
    assert field._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 17:56:24.137345
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from typing import Optional, Union, List, Dict, Tuple, Any, Callable, Mapping, MutableMapping
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from dataclasses_json import dataclass_json
    from dataclasses_json.mm_field import build_type
    from dataclasses_json.core import _is_new_type, _is_optional, _issubclass_safe, _is_collection
    from dataclasses_json.utils import _get_type_origin
    from dataclasses_json.utils import _is_supported_generic
    from dataclasses_json.utils import _is_collection
    from dataclasses_json.utils import _is_optional
    from dataclasses_json.utils import _issubclass

# Generated at 2022-06-17 17:56:28.350172
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None)
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None)


# Generated at 2022-06-17 17:56:30.654214
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 17:56:42.092087
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class A(typing.Generic[A]):
        pass

    class B(typing.Generic[B]):
        pass

    class C(typing.Generic[C]):
        pass

    class D(typing.Generic[D]):
        pass

    class E(typing.Generic[E]):
        pass

    class F(typing.Generic[F]):
        pass

    class G(typing.Generic[G]):
        pass

    class H(typing.Generic[H]):
        pass

    class I(typing.Generic[I]):
        pass

    class J(typing.Generic[J]):
        pass

    class K(typing.Generic[K]):
        pass

    class L(typing.Generic[L]):
        pass


# Generated at 2022-06-17 17:56:49.431385
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
        c: typing.Optional[int]
        d: typing.Optional[typing.List[int]]
        e: typing.List[int]
        f: typing.Optional[typing.List[typing.Optional[int]]]
        g: typing.Optional[typing.List[typing.Optional[int]]] = None
        h: typing.Optional[typing.List[typing.Optional[int]]] = []
        i: typing.Optional[typing.List[typing.Optional[int]]] = [None]

# Generated at 2022-06-17 17:56:53.736477
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._serialize(datetime.now(), None, None) is not None
    assert _IsoField()._deserialize(datetime.now().isoformat(), None, None) is not None


# Generated at 2022-06-17 17:56:58.781388
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Foo(typing.Generic[A]):
        def __init__(self, x: A):
            self.x = x

    class FooSchema(SchemaF[Foo[int]]):
        x = fields.Int()

    foo = Foo(1)
    assert FooSchema().dump(foo) == {'x': 1}
    assert FooSchema().dump([foo]) == [{'x': 1}]



# Generated at 2022-06-17 17:57:04.082978
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses import dataclass
    from typing import List
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from marshmallow import Schema
    from dataclasses_json import dataclass_json
    from dataclasses_json.schema import SchemaF

    class Color(Enum):
        RED = 1
        GREEN = 2
        BLUE = 3

    @dataclass_json
    @dataclass
    class ColorSchema(Schema):
        color: Color = EnumField(Color)

    @dataclass_json
    @dataclass
    class Data:
        color: Color

    @dataclass_json
    @dataclass
    class DataSchema(SchemaF[Data]):
        color: ColorSchema


# Generated at 2022-06-17 17:57:07.025831
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class TestSchema(SchemaF[int]):
        pass
    assert TestSchema().dumps(1) == '1'
    assert TestSchema().dumps([1, 2]) == '[1, 2]'


# Generated at 2022-06-17 17:57:29.190292
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from typing import List, Optional, Union
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from marshmallow.exceptions import ValidationError
    from dataclasses_json import dataclass_json
    from dataclasses_json.mm import Schema

    class TestEnum(Enum):
        A = 'a'
        B = 'b'

    @dataclass_json
    @dataclass
    class TestSchema(Schema):
        a: int
        b: str
        c: List[int]
        d: Optional[str]
        e: Union[int, str]
        f: TestEnum


# Generated at 2022-06-17 17:57:39.952410
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from typing import Optional, List, Dict, Union, Tuple, Any, Callable, Mapping, MutableMapping
    from dataclasses_json.utils import CatchAllVar

    @dataclass_json
    @dataclass
    class Test:
        a: Optional[int]
        b: List[int]
        c: Dict[str, int]
        d: Union[int, str]
        e: Tuple[int, str]
        f: Any
        g: Callable
        h: Mapping
        i: MutableMapping
        j: CatchAllVar


# Generated at 2022-06-17 17:57:54.420929
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from typing import List
    from marshmallow import Schema, fields
    class MySchema(Schema):
        a = fields.Int()
    s = SchemaF[List[int]](MySchema())
    assert s.load([{'a': 1}, {'a': 2}]) == [1, 2]
    assert s.load({'a': 1}) == [1]
    assert s.load({'a': 1}, many=False) == 1
    assert s.load([{'a': 1}], many=False) == [1]
    assert s.load([{'a': 1}], many=True) == [1]
    assert s.load({'a': 1}, many=True) == [1]
    assert s.load([{'a': 1}], many=False) == [1]

# Generated at 2022-06-17 17:58:05.120432
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: str

    class ASchema(SchemaF[A]):
        a = fields.Int()

    class BSchema(SchemaF[B]):
        b = fields.Str()

    a_schema = ASchema()
    b_schema = BSchema()

    a = a_schema.loads('{"a": 1}')
    assert a.a == 1

    b = b_schema.loads('{"b": "b"}')
    assert b.b == "b"

    a_list = a_schema.loads('[{"a": 1}, {"a": 2}]')

# Generated at 2022-06-17 17:58:09.369355
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields

    class Foo(Schema):
        name = fields.Str()

    def test_foo(foo: Foo[int]):
        foo.dumps(1)



# Generated at 2022-06-17 17:58:15.984126
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from marshmallow.exceptions import ValidationError

    class LetterCase(Enum):
        CAMEL = 'camel'
        SNAKE = 'snake'
        PASCAL = 'pascal'

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.Optional[str]
        d: typing.Optional[int]
        e: typing.Optional[typing.List[int]]
        f: typing.Optional[typing.List[str]]
        g: typing.Optional[typing.List[typing.List[int]]]

# Generated at 2022-06-17 17:58:22.517969
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.Optional[int]
        d: typing.Optional[str]
        e: typing.Optional[typing.List[int]]
        f: typing.Optional[typing.List[str]]
        g: typing.Optional[typing.List[typing.Optional[int]]]
        h: typing.Optional[typing.List[typing.Optional[str]]]
        i: typing.Optional[typing.List[typing.Optional[typing.List[int]]]]
        j: typing.Optional[typing.List[typing.Optional[typing.List[str]]]]

# Generated at 2022-06-17 17:58:29.705225
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses import dataclass
    from marshmallow import Schema, fields

    @dataclass
    class Person:
        name: str
        age: int

    class PersonSchema(SchemaF[Person]):
        name = fields.Str()
        age = fields.Int()

    person = Person('John', 30)
    schema = PersonSchema()
    result = schema.load({"name": "John", "age": 30})
    assert result == person



# Generated at 2022-06-17 17:58:32.186855
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field.__class__.__name__ == "_TimestampField"


# Generated at 2022-06-17 17:58:42.717094
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo:
        pass

    class FooSchema(SchemaF[Foo]):
        pass

    assert FooSchema().dumps([Foo(), Foo()]) == "[{},{}]"
    assert FooSchema().dumps(Foo()) == "{}"
    assert FooSchema().dumps([Foo(), Foo()], many=True) == "[{},{}]"
    assert FooSchema().dumps(Foo(), many=False) == "{}"
    assert FooSchema().dumps([Foo(), Foo()], many=False) == "[{},{}]"
    assert FooSchema().dumps(Foo(), many=True) == "{}"
    assert FooSchema().dumps([Foo(), Foo()], many=None) == "[{},{}]"

# Generated at 2022-06-17 17:59:08.439577
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class MySchema(SchemaF[A]):
        pass

    assert MySchema().dump([1, 2]) == [1, 2]
    assert MySchema().dump(1) == 1


# Generated at 2022-06-17 17:59:17.054740
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from typing import Optional, List, Union, Dict, Any, Tuple, Callable, Mapping, MutableMapping
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from marshmallow.exceptions import ValidationError
    from dataclasses_json.core import _is_supported_generic, _is_collection
    from dataclasses_json.utils import _is_optional, _issubclass_safe, _is_new_type, _get_type_origin
    from dataclasses_json.schema import build_type
    from dataclasses_json.mixin import DataclassJSONMixin
    from dataclasses_json.core import _ExtendedEncoder
    from dataclasses_json.utils import _handle_undefined_parameters_safe

# Generated at 2022-06-17 17:59:27.968086
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo_schema = FooSchema()
    foo = Foo(a=1, b='foo')
    assert foo_schema.dumps(foo) == '{"a": 1, "b": "foo"}'
    assert foo_schema.dumps([foo]) == '[{"a": 1, "b": "foo"}]'
    assert foo_schema.dumps([foo], many=True) == '[{"a": 1, "b": "foo"}]'
    assert foo_schema.dumps([foo], many=False) == '{"a": 1, "b": "foo"}'
    assert foo_

# Generated at 2022-06-17 17:59:34.159373
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from typing import List
    from marshmallow import Schema, fields
    class TestSchema(Schema):
        name = fields.Str()
    class Test:
        def __init__(self, name: str):
            self.name = name
    class TestSchemaF(SchemaF[Test]):
        pass
    test_schema = TestSchemaF(schema_cls=TestSchema)
    assert test_schema.load([{'name': 'test'}]) == [Test('test')]
    assert test_schema.load({'name': 'test'}) == Test('test')
    assert test_schema.loads('[{"name": "test"}]') == [Test('test')]
    assert test_schema.loads('{"name": "test"}') == Test('test')
    assert test_

# Generated at 2022-06-17 17:59:45.676140
# Unit test for function schema
def test_schema():
    import marshmallow as mm
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str
        c: typing.Optional[int]
        d: typing.Optional[typing.List[int]]
        e: typing.Optional[typing.List[str]]
        f: typing.Optional[typing.List[A]]
        g: typing.Optional[typing.List[typing.List[int]]]
        h: typing.Optional[typing.List[typing.List[str]]]
        i: typing.Optional[typing.List[typing.List[A]]]

# Generated at 2022-06-17 17:59:52.784255
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.Optional[int] = None
        d: typing.Optional[str] = None
        e: typing.Optional[typing.List[int]] = None
        f: typing.Optional[typing.List[str]] = None
        g: typing.Optional[typing.List[typing.Optional[int]]] = None
        h: typing.Optional[typing.List[typing.Optional[str]]] = None
        i: typing.Optional[typing.List[typing.Optional[typing.List[int]]]] = None
        j: typing.Optional[typing.List[typing.Optional[typing.List[str]]]] = None

# Generated at 2022-06-17 18:00:04.093324
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json.api import DataclassJsonMixin

    @dataclass
    class A(DataclassJsonMixin):
        a: int
        b: str

    @dataclass
    class B(DataclassJsonMixin):
        a: A
        b: str

    @dataclass
    class C(DataclassJsonMixin):
        a: typing.List[A]
        b: str

    @dataclass
    class D(DataclassJsonMixin):
        a: typing.List[typing.List[A]]
        b: str

    @dataclass
    class E(DataclassJsonMixin):
        a: typing.List[typing.List[typing.List[A]]]


# Generated at 2022-06-17 18:00:15.565468
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
        c: typing.List[str]
        d: typing.List[int]
        e: typing.Dict[str, str]
        f: typing.Dict[str, int]
        g: typing.Optional[str]
        h: typing.Optional[int]
        i: typing.Optional[typing.List[str]]
        j: typing.Optional[typing.List[int]]
        k: typing.Optional[typing.Dict[str, str]]
        l: typing.Optional[typing.Dict[str, int]]

# Generated at 2022-06-17 18:00:20.567898
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from typing import Optional
    @dataclass
    class A:
        a: int
        b: Optional[str]
    assert build_schema(A, None, False, False) is not None


# Generated at 2022-06-17 18:00:25.909258
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields

    class Foo(Schema):
        bar = fields.Str()

    s = SchemaF[Foo]()
    s.load({'bar': 'baz'})
    s.load([{'bar': 'baz'}])



# Generated at 2022-06-17 18:01:20.507360
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin
    from dataclasses_json.config import config
    from dataclasses_json.undefined import Undefined

    @dataclass
    class A(DataClassJsonMixin):
        a: str
        b: int
        c: Undefined

    schema = build_schema(A, DataClassJsonMixin, False, False)
    assert schema.Meta.fields == ('a', 'b')
    assert schema.dump(A('a', 1, Undefined)) == {'a': 'a', 'b': 1}

# Generated at 2022-06-17 18:01:31.009913
# Unit test for function build_type
def test_build_type():
    from marshmallow import fields
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class A:
        a: int

    @dataclass_json
    @dataclass
    class B:
        b: A

    @dataclass_json
    @dataclass
    class C:
        c: typing.List[A]

    @dataclass_json
    @dataclass
    class D:
        d: typing.List[typing.Optional[A]]

    @dataclass_json
    @dataclass
    class E:
        e: typing.Optional[A]


# Generated at 2022-06-17 18:01:39.350261
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class User:
        name: str
        age: int

    class UserSchema(SchemaF[User]):
        name = fields.Str()
        age = fields.Int()

    schema = UserSchema()
    user = schema.load({'name': 'Monty', 'age': '42'})
    assert user.name == 'Monty'
    assert user.age == 42
    users = schema.load([{'name': 'Monty', 'age': '42'}, {'name': 'Guido', 'age': '56'}], many=True)
    assert users[0].name == 'Monty'
    assert users[0].age == 42
    assert users[1].name == 'Guido'


# Generated at 2022-06-17 18:01:53.654190
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import List
    from marshmallow import Schema, fields

    class Foo(Schema):
        a = fields.Int()

    class Bar(Schema):
        b = fields.Int()

    class FooBar(SchemaF[List[Foo]]):
        pass

    class FooBar2(SchemaF[Foo]):
        pass

    assert FooBar().dump([Foo(a=1), Foo(a=2)]) == [{'a': 1}, {'a': 2}]
    assert FooBar2().dump(Foo(a=1)) == {'a': 1}
    assert FooBar().dump([Foo(a=1), Bar(b=2)]) == [{'a': 1}, {'b': 2}]

# Generated at 2022-06-17 18:01:58.604277
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo = Foo(1, 'a')
    assert FooSchema().dumps(foo) == '{"a": 1, "b": "a"}'



# Generated at 2022-06-17 18:02:11.290140
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str

    @dataclass_json
    @dataclass
    class B:
        a: A
        b: str

    @dataclass_json
    @dataclass
    class C:
        a: typing.List[A]
        b: str

    @dataclass_json
    @dataclass
    class D:
        a: typing.List[A]
        b: typing.List[str]

    @dataclass_json
    @dataclass
    class E:
        a: typing.List[A]

# Generated at 2022-06-17 18:02:21.961058
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses import dataclass
    from marshmallow import Schema, fields

    @dataclass
    class Foo:
        x: int

    class FooSchema(SchemaF[Foo]):
        x = fields.Int()

    assert FooSchema().load({'x': 1}) == Foo(1)



# Generated at 2022-06-17 18:02:27.566910
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int

    class ASchema(SchemaF[A]):
        a = fields.Int()

    assert ASchema().load({'a': 1}) == A(1)
    assert ASchema().load([{'a': 1}]) == [A(1)]
    assert ASchema().load([{'a': 1}, {'a': 2}]) == [A(1), A(2)]
    assert ASchema().load([{'a': 1}, {'a': 2}], many=True) == [A(1), A(2)]
    assert ASchema().load({'a': 1}, many=False) == A(1)

# Generated at 2022-06-17 18:02:34.857309
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields

    class Person(Schema):
        name = fields.Str()

    class PersonF(SchemaF[Person]):
        pass

    person = PersonF().dump(Person(name="John"))
    assert person == {"name": "John"}

    people = PersonF().dump([Person(name="John"), Person(name="Jane")], many=True)
    assert people == [{"name": "John"}, {"name": "Jane"}]



# Generated at 2022-06-17 18:02:37.516465
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class A(typing.Generic[A]):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(SchemaF[A]):
        pass

    assert isinstance(D().dumps(B()), str)
    assert isinstance(D().dumps(C()), str)
    assert isinstance(D().dumps([B(), C()]), str)



# Generated at 2022-06-17 18:04:57.703689
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json, config
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
        c: typing.Optional[str]
        d: typing.Optional[int]
        e: typing.Optional[typing.List[int]]
        f: typing.Optional[typing.List[str]]
        g: typing.Optional[typing.List[typing.List[str]]]
        h: typing.Optional[typing.List[typing.List[int]]]
        i: typing.Optional[typing.List[typing.List[typing.List[int]]]]

# Generated at 2022-06-17 18:05:03.118268
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from typing import Optional, List, Union, Dict, Any, Tuple, Callable, Mapping, MutableMapping

    @dataclass_json
    @dataclass
    class A:
        a: int

    @dataclass_json
    @dataclass
    class B:
        b: str

    @dataclass_json
    @dataclass
    class C:
        c: Optional[int]

    @dataclass_json
    @dataclass
    class D:
        d: List[int]


# Generated at 2022-06-17 18:05:08.844831
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin, config
    from marshmallow import fields as mm_fields

    @dataclass
    class A(DataClassJsonMixin):
        a: int
        b: str

    @dataclass
    class B(DataClassJsonMixin):
        a: A
        b: str

    @dataclass
    class C(DataClassJsonMixin):
        a: typing.Optional[A]
        b: str

    @dataclass
    class D(DataClassJsonMixin):
        a: typing.Optional[typing.List[A]]
        b: str

    @dataclass
    class E(DataClassJsonMixin):
        a: typing.List[A]
        b: str

   

# Generated at 2022-06-17 18:05:19.887019
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses import dataclass
    from marshmallow import Schema, fields

    @dataclass
    class A:
        a: int

    class ASchema(SchemaF[A]):
        a = fields.Int()

    assert ASchema().load({'a': 1}) == A(1)



# Generated at 2022-06-17 18:05:30.206176
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[str]
        f: typing.Optional[int]
        g: typing.Optional[typing.List[int]]
        h: typing.Optional[typing.Dict[str, int]]
        i: typing.Optional[typing.Union[str, int]]
        j: typing.Optional[typing.Union[str, int, typing.List[int]]]

# Generated at 2022-06-17 18:05:36.294683
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field._serialize(datetime.now(), None, None) is not None
    assert field._deserialize(datetime.now().isoformat(), None, None) is not None


# Generated at 2022-06-17 18:05:43.986205
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from typing import List
    from marshmallow import Schema, fields
    class Foo(Schema):
        a = fields.Int()
    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
    assert isinstance(FooSchema().load([{'a': 1}], many=True), List[Foo])
    assert isinstance(FooSchema().load({'a': 1}), Foo)
    assert isinstance(FooSchema().load([{'a': 1}]), List[Foo])
    assert isinstance(FooSchema().load({'a': 1}, many=True), List[Foo])
    assert isinstance(FooSchema().load([{'a': 1}, {'a': 2}]), List[Foo])

# Generated at 2022-06-17 18:05:49.050307
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._serialize(datetime.now(), None, None) is not None
    assert _IsoField()._deserialize("2020-01-01T00:00:00", None, None) is not None
