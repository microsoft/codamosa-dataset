

# Generated at 2022-06-17 17:56:16.124645
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo:
        pass

    class Bar:
        pass

    class FooSchema(SchemaF[Foo]):
        pass

    class BarSchema(SchemaF[Bar]):
        pass

    foo = Foo()
    bar = Bar()

    foo_schema = FooSchema()
    bar_schema = BarSchema()

    foo_schema.dumps(foo)
    foo_schema.dumps([foo])
    bar_schema.dumps(bar)
    bar_schema.dumps([bar])



# Generated at 2022-06-17 17:56:21.311224
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str

    assert schema(Test, None, False) == {'a': fields.Int(), 'b': fields.Str()}



# Generated at 2022-06-17 17:56:29.353454
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields

    class Foo(Schema):
        a = fields.Int()

    class Bar(Schema):
        b = fields.Int()

    class FooBar(SchemaF[typing.Union[Foo, Bar]]):
        pass

    assert FooBar().load({'a': 1}) == Foo().load({'a': 1})
    assert FooBar().load([{'a': 1}, {'b': 2}]) == [Foo().load({'a': 1}), Bar().load({'b': 2})]
    assert FooBar().load({'b': 2}) == Bar().load({'b': 2})
    assert FooBar().load([{'b': 2}]) == [Bar().load({'b': 2})]


# Generated at 2022-06-17 17:56:41.378369
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from typing import List, Optional

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        a: List[A]

    @dataclass
    class C:
        a: Optional[A]

    @dataclass
    class D:
        a: Optional[List[A]]

    @dataclass
    class E:
        a: Optional[List[Optional[A]]]

    @dataclass
    class F:
        a: Optional[List[Optional[List[Optional[A]]]]]

    @dataclass
    class G:
        a: Optional[List[Optional[List[Optional[List[Optional[A]]]]]]]


# Generated at 2022-06-17 17:56:46.028367
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 17:56:50.055246
# Unit test for function build_type
def test_build_type():
    assert build_type(int, {}, None, None, None) == fields.Int
    assert build_type(float, {}, None, None, None) == fields.Float
    assert build_type(str, {}, None, None, None) == fields.Str
    assert build_type(bool, {}, None, None, None) == fields.Bool
    assert build_type(datetime, {}, None, None, None) == _TimestampField
    assert build_type(UUID, {}, None, None, None) == fields.UUID
    assert build_type(Decimal, {}, None, None, None) == fields.Decimal
    assert build_type(typing.List[int], {}, None, None, None) == fields.List

# Generated at 2022-06-17 17:56:59.893034
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class MySchema(SchemaF[A]):
        pass

    MySchema().dumps([1, 2, 3])
    MySchema().dumps(1)
    MySchema().dumps([1, 2, 3], many=True)
    MySchema().dumps(1, many=False)
    MySchema().dumps([1, 2, 3], many=False)
    MySchema().dumps(1, many=True)
    MySchema().dumps([1, 2, 3], many=None)
    MySchema().dumps(1, many=None)
    MySchema().dumps([1, 2, 3], many=False)
    MySchema().dumps(1, many=True)
    MySchema().dumps([1, 2, 3], many=None)
   

# Generated at 2022-06-17 17:57:05.837618
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Foo:
        a: int

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()

    foo = Foo(a=1)
    foo_schema = FooSchema()
    assert foo_schema.dump(foo) == {'a': 1}
    assert foo_schema.dump([foo]) == [{'a': 1}]


# Generated at 2022-06-17 17:57:16.364738
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Tuple[int, str]
        f: typing.Callable
        g: typing.Any
        h: typing.Optional[int]
        i: typing.Optional[typing.List[int]]
        j: typing.Optional[typing.Dict[str, int]]
        k: typing.Optional[typing.Tuple[int, str]]
        l: typing.Optional[typing.Callable]
        m: typing.Optional[typing.Any]


# Generated at 2022-06-17 17:57:27.410366
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo = Foo(a=1, b='2')
    foo_schema = FooSchema()
    assert foo_schema.dump(foo) == {'a': 1, 'b': '2'}
    assert foo_schema.dump([foo]) == [{'a': 1, 'b': '2'}]
    assert foo_schema.dump(foo, many=False) == {'a': 1, 'b': '2'}
    assert foo_schema.dump([foo], many=True) == [{'a': 1, 'b': '2'}]
    assert foo_

# Generated at 2022-06-17 17:57:47.402546
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._deserialize('2019-01-01T00:00:00') == datetime(2019, 1, 1, 0, 0, 0)
    assert _IsoField()._serialize(datetime(2019, 1, 1, 0, 0, 0)) == '2019-01-01T00:00:00'


# Generated at 2022-06-17 17:57:57.028299
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    from dataclasses import dataclass
    from typing import List

    @dataclass
    class Data:
        name: str

    class DataSchema(SchemaF[Data]):
        name = fields.Str()

    schema = DataSchema()
    data = schema.load([{'name': 'foo'}, {'name': 'bar'}])
    assert isinstance(data, List)
    assert isinstance(data[0], Data)
    assert data[0].name == 'foo'
    assert isinstance(data[1], Data)
    assert data[1].name == 'bar'

    data = schema.load({'name': 'foo'})
    assert isinstance(data, Data)
    assert data.name == 'foo'


# Generated at 2022-06-17 17:58:06.708766
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str

# Generated at 2022-06-17 17:58:12.270236
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo = Foo(a=1, b='b')
    assert FooSchema().dumps(foo) == '{"a": 1, "b": "b"}'



# Generated at 2022-06-17 17:58:20.265414
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin
    from marshmallow import Schema, fields
    from marshmallow.validate import OneOf

    @dataclass
    class Test(DataClassJsonMixin):
        a: int
        b: str


# Generated at 2022-06-17 17:58:31.352603
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Foo:
        a: int
        b: str = 'b'
        c: typing.Optional[int] = None
        d: typing.Optional[str] = None
        e: typing.Optional[str] = 'e'
        f: typing.Optional[typing.List[int]] = None
        g: typing.Optional[typing.List[str]] = None
        h: typing.Optional[typing.List[str]] = ['h']
        i: typing.Optional[typing.List[typing.Optional[int]]] = None

# Generated at 2022-06-17 17:58:42.372623
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class A:
        a: str
        b: int

    @dataclass_json
    @dataclass
    class B:
        a: str
        b: A

    class ASchema(SchemaF[A]):
        a = fields.Str()
        b = fields.Int()

    class BSchema(SchemaF[B]):
        a = fields.Str()
        b = fields.Nested(ASchema)

    b_schema = BSchema()
    b = B('a', A('b', 1))
    b_encoded

# Generated at 2022-06-17 17:58:55.661281
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # type: () -> None
    class MySchema(SchemaF[A]):
        pass

    assert MySchema().load([{'a': 1}], many=True) == [{'a': 1}]
    assert MySchema().load({'a': 1}, many=False) == {'a': 1}
    assert MySchema().load({'a': 1}, many=None) == {'a': 1}
    assert MySchema().load({'a': 1}) == {'a': 1}
    assert MySchema().load([{'a': 1}]) == [{'a': 1}]
    assert MySchema().load([{'a': 1}], many=False) == [{'a': 1}]

# Generated at 2022-06-17 17:59:04.959428
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    import marshmallow
    import marshmallow_enum
    import marshmallow_dataclass

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[int]
        f: typing.Optional[str]
        g: typing.Optional[typing.List[int]]
        h: typing.Optional[typing.Dict[str, int]]
        i: typing.Optional[typing.Union[int, str]]
        j: typing.Optional[typing.Union[int, str, typing.List[int]]]

# Generated at 2022-06-17 17:59:10.604553
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Foo(typing.Generic[A]):
        def __init__(self, a: A):
            self.a = a

    class FooSchema(SchemaF[A]):
        a = fields.Field()

    foo = Foo(1)
    foo_schema = FooSchema()
    assert foo_schema.dump(foo) == {'a': 1}
    assert foo_schema.dump([foo]) == [{'a': 1}]
    assert foo_schema.dump(foo, many=False) == {'a': 1}
    assert foo_schema.dump([foo], many=False) == [{'a': 1}]
    assert foo_schema.dump(foo, many=True) == {'a': 1}

# Generated at 2022-06-17 17:59:30.024308
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields

    class Foo(Schema):
        x = fields.Int()

    assert SchemaF[int]().dumps(1) == '1'
    assert SchemaF[int]().dumps([1, 2]) == '[1, 2]'
    assert SchemaF[Foo]().dumps(Foo(x=1)) == '{"x": 1}'
    assert SchemaF[Foo]().dumps([Foo(x=1), Foo(x=2)]) == '[{"x": 1}, {"x": 2}]'


# Generated at 2022-06-17 17:59:41.235721
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from typing import Optional
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: Optional[int]
        c: Optional[str]

# Generated at 2022-06-17 17:59:55.496981
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields
    from dataclasses import dataclass
    from typing import List

    @dataclass
    class Foo:
        a: int
        b: List[str]

    class FooSchema(Schema):
        a = fields.Int()
        b = fields.List(fields.Str())

    schema = SchemaF[Foo](FooSchema)
    assert schema.loads('{"a": 1, "b": ["a", "b"]}') == Foo(a=1, b=["a", "b"])

# Generated at 2022-06-17 18:00:05.800030
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class A:
        a: str
        b: int
        c: typing.Optional[str]
        d: typing.Optional[int] = None
        e: typing.Optional[typing.List[str]]
        f: typing.Optional[typing.List[int]] = None
        g: typing.Optional[typing.List[typing.Optional[str]]]
        h: typing.Optional[typing.List[typing.Optional[int]]] = None
        i: typing.Optional[typing.List[typing.Optional[typing.List[str]]]]

# Generated at 2022-06-17 18:00:16.684752
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: float
        d: bool
        e: list
        f: dict
        g: typing.List[int]
        h: typing.Dict[str, int]
        i: typing.Optional[int]
        j: typing.Optional[str]
        k: typing.Optional[float]
        l: typing.Optional[bool]
        m: typing.Optional[list]
        n: typing.Optional[dict]
        o: typing.Optional[typing.List[int]]
        p: typing.Optional[typing.Dict[str, int]]

# Generated at 2022-06-17 18:00:29.365085
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses import dataclass
    @dataclass
    class A:
        a: int
    a = A(1)
    s = SchemaF[A]()
    s.dumps(a)

# Generated at 2022-06-17 18:00:40.570316
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from typing import Optional, List, Dict, Union

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: str

    @dataclass
    class C:
        c: Optional[int]

    @dataclass
    class D:
        d: List[int]

    @dataclass
    class E:
        e: Dict[str, int]

    @dataclass
    class F:
        f: Union[A, B]

    @dataclass
    class G:
        g: Union[A, B, C]

    @dataclass
    class H:
        h: Union[A, B, C, D]

    @dataclass
    class I:
        i: Union

# Generated at 2022-06-17 18:00:45.667733
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Foo(typing.NamedTuple):
        a: int
        b: str
    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()
    assert FooSchema().loads({"a": 1, "b": "b"}) == Foo(a=1, b="b")
    assert FooSchema().loads([{"a": 1, "b": "b"}]) == [Foo(a=1, b="b")]
    assert FooSchema().loads(b'{"a": 1, "b": "b"}') == Foo(a=1, b="b")
    assert FooSchema().loads(b'[{"a": 1, "b": "b"}]') == [Foo(a=1, b="b")]
    assert FooSchema

# Generated at 2022-06-17 18:00:51.784980
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class SomeSchema(SchemaF[int]):
        pass

    assert SomeSchema().load([1, 2, 3]) == [1, 2, 3]
    assert SomeSchema().load({'a': 1}) == {'a': 1}
    assert SomeSchema().load(1) == 1



# Generated at 2022-06-17 18:01:02.478150
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, str]
        e: typing.Optional[int]
        f: typing.Optional[str]
        g: typing.Optional[typing.List[int]]
        h: typing.Optional[typing.Dict[str, str]]
        i: typing.Optional[typing.Union[int, str]]
        j: typing.Optional[typing.Union[typing.List[int], str]]
        k: typing.Optional[typing.Union[typing.Dict[str, str], str]]

# Generated at 2022-06-17 18:01:46.729555
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[str]
        f: typing.Optional[typing.List[int]]
        g: typing.Optional[typing.Dict[str, int]]
        h: typing.Optional[typing.Optional[str]]
        i: typing.Optional[typing.Optional[typing.List[int]]]
        j: typing.Optional[typing.Optional[typing.Dict[str, int]]]

# Generated at 2022-06-17 18:01:55.423345
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.List[str]
        e: typing.Dict[str, int]
        f: typing.Dict[str, str]
        g: typing.Optional[int]
        h: typing.Optional[str]
        i: typing.Optional[typing.List[int]]
        j: typing.Optional[typing.List[str]]
        k: typing.Optional[typing.Dict[str, int]]
        l: typing.Optional[typing.Dict[str, str]]
        m: typing.Optional[typing.Union[int, str]]
        n: typing.Optional[typing.Union[typing.List[int], str]]

# Generated at 2022-06-17 18:02:01.270680
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

        @post_load
        def make_foo(self, data, **kwargs):
            return Foo(**data)

    data = {'a': 1, 'b': 'b'}
    foo = FooSchema().load(data)
    assert foo == Foo(a=1, b='b')



# Generated at 2022-06-17 18:02:12.367692
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str
        c: typing.Optional[str]
        d: typing.Optional[int] = None
        e: typing.Optional[typing.List[int]] = None
        f: typing.Optional[typing.List[str]] = None
        g: typing.Optional[typing.List[typing.Optional[str]]] = None
        h: typing.Optional[typing.List[typing.Optional[int]]] = None
        i: typing.Optional[typing.List[typing.Optional[int]]] = None

# Generated at 2022-06-17 18:02:22.880136
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # type: () -> None
    class TestSchema(SchemaF[int]):
        pass

    schema = TestSchema()
    assert schema.dumps([1, 2, 3]) == '[1, 2, 3]'
    assert schema.dumps(1) == '1'
    assert schema.dumps(None) == 'null'
    assert schema.dumps(1, many=True) == '[1]'
    assert schema.dumps([1, 2, 3], many=False) == '1'
    assert schema.dumps([1, 2, 3], many=False, indent=2) == '1'
    assert schema.dumps([1, 2, 3], many=True, indent=2) == '[\n  1,\n  2,\n  3\n]'

# Generated at 2022-06-17 18:02:34.855531
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Mapping[str, int]
        f: typing.MutableMapping[str, int]
        g: typing.Tuple[int, str]
        h: typing.Callable
        i: typing.Any
        j: dict
        k: list
        l: str
        m: int
        n: float
        o: bool
        p: datetime
        q: UUID
        r: Decimal
        s: typing.Optional[int]
        t

# Generated at 2022-06-17 18:02:42.171992
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    # type: () -> None
    class A(object):
        pass

    class B(object):
        pass

    class C(object):
        pass

    class D(object):
        pass

    class E(object):
        pass

    class F(object):
        pass

    class G(object):
        pass

    class H(object):
        pass

    class I(object):
        pass

    class J(object):
        pass

    class K(object):
        pass

    class L(object):
        pass

    class M(object):
        pass

    class N(object):
        pass

    class O(object):
        pass

    class P(object):
        pass

    class Q(object):
        pass

    class R(object):
        pass

    class S(object):
        pass

   

# Generated at 2022-06-17 18:02:46.073403
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._deserialize("2020-01-01T00:00:00") == datetime(2020, 1, 1, 0, 0, 0)


# Generated at 2022-06-17 18:02:53.070160
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from dataclasses_json.mm import Mapping

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: Mapping[str, int]

    assert build_schema(Test, None, False, False) == TestSchema



# Generated at 2022-06-17 18:03:04.467889
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field.deserialize(None) is None
    assert field.deserialize(0) == datetime(1970, 1, 1, 0, 0, 0, tzinfo=None)
    assert field.deserialize(1500000000) == datetime(2017, 7, 14, 2, 40, 0, tzinfo=None)
    assert field.deserialize(1500000000.123) == datetime(2017, 7, 14, 2, 40, 0, 123000, tzinfo=None)
    assert field.serialize(datetime(2017, 7, 14, 2, 40, 0, 123000, tzinfo=None)) == 1500000000.123
    assert field.serialize(datetime(2017, 7, 14, 2, 40, 0, tzinfo=None)) == 1500000000

# Generated at 2022-06-17 18:04:34.656243
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class A(DataClassJsonMixin):
        a: int
        b: str

    @dataclass
    class B(DataClassJsonMixin):
        a: A

    @dataclass
    class C(DataClassJsonMixin):
        a: typing.List[A]

    @dataclass
    class D(DataClassJsonMixin):
        a: typing.List[A]
        b: B

    @dataclass
    class E(DataClassJsonMixin):
        a: typing.List[A]
        b: B
        c: C

    @dataclass
    class F(DataClassJsonMixin):
        a: typing.List

# Generated at 2022-06-17 18:04:43.377050
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class MySchema(SchemaF[A]):
        pass
    MySchema().dumps([1, 2, 3])
    MySchema().dumps(1)
    MySchema().dumps([1, 2, 3], many=True)
    MySchema().dumps(1, many=False)
    MySchema().dumps([1, 2, 3], many=False)
    MySchema().dumps(1, many=True)
    MySchema().dumps([1, 2, 3], many=None)
    MySchema().dumps(1, many=None)
    MySchema().dumps([1, 2, 3], many=None)
    MySchema().dumps(1, many=None)
    MySchema().dumps([1, 2, 3], many=None)
   

# Generated at 2022-06-17 18:04:48.856986
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    @dataclass
    class A:
        a: str
        b: int
    assert build_schema(A, None, False, False)


# Generated at 2022-06-17 18:04:59.015166
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from typing import Optional, List, Dict, Union, Any, Tuple, Callable, Mapping, MutableMapping

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: float
        d: bool
        e: datetime
        f: UUID
        g: Decimal
        h: Test
        i: Optional[int]
        j: Optional[str]
        k: Optional[float]
        l: Optional[bool]
        m: Optional[datetime]
        n: Optional[UUID]
        o: Optional[Decimal]
        p: Optional[Test]

# Generated at 2022-06-17 18:05:04.342631
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses import dataclass
    from marshmallow import Schema, fields

    @dataclass
    class Foo:
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo = Foo(a=1, b='b')
    schema = FooSchema()
    res = schema.dumps(foo)
    assert res == '{"a": 1, "b": "b"}'



# Generated at 2022-06-17 18:05:08.073346
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._deserialize("2020-01-01T00:00:00") == datetime(2020, 1, 1, 0, 0, 0)
    assert _IsoField()._serialize(datetime(2020, 1, 1, 0, 0, 0)) == "2020-01-01T00:00:00"


# Generated at 2022-06-17 18:05:12.416085
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class TestSchema(SchemaF[A]):
        pass

    assert TestSchema().dumps([1, 2, 3]) == '[1, 2, 3]'
    assert TestSchema().dumps(1) == '1'



# Generated at 2022-06-17 18:05:22.367896
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from dataclasses import dataclass
    from typing import List
    @dataclass
    class A:
        a: int
        b: str
    @dataclass
    class B:
        a: List[A]
    s = SchemaF[B]()
    assert s.loads('{"a": [{"a": 1, "b": "a"}, {"a": 2, "b": "b"}]}') == B([A(1, "a"), A(2, "b")])


# Generated at 2022-06-17 18:05:27.986613
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo:
        pass

    class FooSchema(SchemaF[Foo]):
        pass

    assert FooSchema().dumps([Foo()]) == "[{}]"
    assert FooSchema().dumps(Foo()) == "{}"
    assert FooSchema().dumps([Foo(), Foo()]) == "[{}, {}]"



# Generated at 2022-06-17 18:05:34.324834
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from typing import Optional
    @dataclass
    class Test:
        a: int
        b: Optional[str]
        c: Optional[int] = None