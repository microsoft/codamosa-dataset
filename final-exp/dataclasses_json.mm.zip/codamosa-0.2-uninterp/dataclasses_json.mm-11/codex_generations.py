

# Generated at 2022-06-17 17:56:26.537357
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from typing import List, Optional, Union
    from marshmallow import Schema

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: str

    @dataclass
    class C:
        c: List[A]

    @dataclass
    class D:
        d: Optional[int]

    @dataclass
    class E:
        e: Union[A, B]

    @dataclass
    class F:
        f: Union[A, B, C]

    @dataclass
    class G:
        g: Union[A, B, C, D]

    @dataclass
    class H:
        h: Union[A, B, C, D, E]


# Generated at 2022-06-17 17:56:33.897832
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin
    from marshmallow import Schema, fields
    from typing import Optional, List, Dict

    @dataclass
    class A(DataClassJsonMixin):
        a: int
        b: str
        c: Optional[str]
        d: List[str]
        e: Dict[str, str]


# Generated at 2022-06-17 17:56:44.808776
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Foo:
        bar: str

    class FooSchema(SchemaF[Foo]):
        bar = fields.Str()

    foo = Foo('baz')
    foo_schema = FooSchema()
    assert foo_schema.load({'bar': 'baz'}) == foo
    assert foo_schema.load([{'bar': 'baz'}]) == [foo]
    assert foo_schema.load([{'bar': 'baz'}], many=True) == [foo]
    assert foo_schema.load({'bar': 'baz'}, many=False) == foo
    assert foo_schema.load({'bar': 'baz'}, many=None) == foo


# Generated at 2022-06-17 17:56:51.326058
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[int]
        f: typing.Optional[typing.List[int]]
        g: typing.Optional[typing.Dict[str, int]]
        h: typing.Optional[typing.List[typing.Optional[int]]]
        i: typing.Optional[typing.Dict[str, typing.Optional[int]]]
        j: typing.Optional[typing.List[typing.Optional[typing.List[int]]]]
        k: typing.Optional[typing.Dict[str, typing.Optional[typing.List[int]]]]
        l: typing.Optional

# Generated at 2022-06-17 17:57:00.177103
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from typing import Optional
    from marshmallow import fields
    from dataclasses_json import dataclass_json
    from dataclasses_json.mm import Schema

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: Optional[int]
        c: Optional[str]
        d: Optional[int] = None
        e: Optional[str] = None
        f: Optional[str] = 'test'
        g: Optional[str] = None
        h: Optional[str] = 'test'
        i: Optional[str] = None
        j: Optional[str] = 'test'
        k: Optional[str] = None
        l: Optional[str] = 'test'
        m: Optional[str] = None
       

# Generated at 2022-06-17 17:57:09.274585
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.List[str]
        e: typing.List[typing.List[int]]
        f: typing.List[typing.List[str]]
        g: typing.List[typing.List[typing.List[int]]]
        h: typing.List[typing.List[typing.List[str]]]
        i: typing.List[typing.List[typing.List[typing.List[int]]]]

# Generated at 2022-06-17 17:57:11.376013
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class A:
        a: int
        b: str
        c: typing.List[int]

    @dataclass
    class B:
        a: int
        b: str
        c: typing.List[int]

    assert build_schema(A, None, False, False) == build_schema(B, None, False, False)



# Generated at 2022-06-17 17:57:19.747710
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from typing import List, Optional, Union

    class Color(Enum):
        RED = 1
        GREEN = 2
        BLUE = 3

    @dataclass_json
    @dataclass
    class Inner:
        name: str

    @dataclass_json
    @dataclass
    class Outer:
        name: str
        inner: Inner

    @dataclass_json
    @dataclass
    class Test:
        name: str
        inner: Optional[Inner]
        inner_list: List[Inner]
        color: Color
        color_list: List[Color]
        union: Union[int, str]
       

# Generated at 2022-06-17 17:57:22.972934
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 17:57:33.129062
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses import dataclass
    from marshmallow import fields

    @dataclass
    class Foo:
        a: int
        b: str

    @dataclass
    class Bar:
        c: Foo
        d: typing.List[Foo]

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    class BarSchema(SchemaF[Bar]):
        c = fields.Nested(FooSchema)
        d = fields.Nested(FooSchema, many=True)

    bar = Bar(Foo(1, 'a'), [Foo(2, 'b'), Foo(3, 'c')])
    bar_schema = BarSchema()
    bar_data = bar_schema.dump(bar)


# Generated at 2022-06-17 17:57:56.523026
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError
    from dataclasses import dataclass

    @dataclass
    class Foo:
        bar: str

    class FooSchema(SchemaF[Foo]):
        bar = fields.Str()

    foo = Foo('baz')
    foo_schema = FooSchema()
    assert foo_schema.dumps(foo) == '{"bar": "baz"}'
    assert foo_schema.dumps([foo]) == '[{"bar": "baz"}]'
    assert foo_schema.dumps([foo], many=True) == '[{"bar": "baz"}]'
    assert foo_schema.dumps(foo, many=False) == '{"bar": "baz"}'
    assert foo_schema.d

# Generated at 2022-06-17 17:58:01.089904
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
    assert build_schema(Test, None, False, False)


# Generated at 2022-06-17 17:58:11.696803
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields
    class Foo(Schema):
        a = fields.Str()
    class Bar(Schema):
        b = fields.Str()
    class FooBar(SchemaF[typing.Union[Foo, Bar]]):
        pass
    f = FooBar()
    f.dumps(Foo(a='a'))
    f.dumps(Bar(b='b'))
    f.dumps([Foo(a='a'), Bar(b='b')])

# Generated at 2022-06-17 17:58:19.424264
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class A(typing.Generic[A]):
        def dump(self, obj: typing.List[A], many: bool = None) -> typing.List[
            TEncoded]:  # type: ignore
            # mm has the wrong return type annotation (dict) so we can ignore the mypy error
            pass

        def dump(self, obj: A, many: bool = None) -> TEncoded:
            pass

        def dump(self, obj: TOneOrMulti,
                 many: bool = None) -> TOneOrMultiEncoded:
            pass

    a = A()
    a.dump([1], many=True)
    a.dump(1, many=False)
    a.dump(1)
    a.dump([1])


# Generated at 2022-06-17 17:58:30.773867
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo(typing.Generic[A]):
        def __init__(self, x: A):
            self.x = x

    class FooSchema(SchemaF[Foo[int]]):
        x = fields.Int()

    foo = Foo(1)
    assert FooSchema().dumps(foo) == '{"x": 1}'
    assert FooSchema().dumps([foo]) == '[{"x": 1}]'
    assert FooSchema().dumps(foo, many=False) == '{"x": 1}'
    assert FooSchema().dumps([foo], many=False) == '[{"x": 1}]'
    assert FooSchema().dumps(foo, many=True) == '{"x": 1}'

# Generated at 2022-06-17 17:58:41.925750
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from typing import List, Optional, Union
    from enum import Enum

    class MyEnum(Enum):
        A = 'a'
        B = 'b'

    @dataclass_json
    @dataclass
    class MyClass:
        my_field: str

    @dataclass_json
    @dataclass
    class MyClass2:
        my_field: str

    @dataclass_json
    @dataclass
    class MyClass3:
        my_field: str

    @dataclass_json
    @dataclass
    class MyClass4:
        my_field: str


# Generated at 2022-06-17 17:58:55.454980
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from marshmallow.exceptions import ValidationError
    from dataclasses_json.utils import _is_new_type, _get_type_origin
    from dataclasses_json.core import _is_supported_generic, _is_collection
    from dataclasses_json.mm import Schema

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.List[str]
        e: typing.List[typing.List[int]]
        f: typing.List[typing.List[str]]

# Generated at 2022-06-17 17:58:59.519033
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from typing import List
    from marshmallow import Schema, fields
    class TestSchema(Schema):
        name = fields.Str()
    schema = SchemaF[List[TestSchema]]()
    schema.loads('[{"name": "test"}]')

# Generated at 2022-06-17 17:59:07.376110
# Unit test for function build_type
def test_build_type():
    from typing import Optional, Union
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from dataclasses_json.mm_field import _UnionField
    from dataclasses import dataclass
    from enum import Enum

    @dataclass
    class Test:
        pass

    @dataclass
    class Test2:
        pass

    class TestEnum(Enum):
        A = 1
        B = 2

    assert build_type(int, {}, None, None, None) == fields.Int
    assert build_type(Optional[int], {}, None, None, None) == fields.Int(allow_none=True)
    assert build_type(Union[int, str], {}, None, None, None) == _UnionField

# Generated at 2022-06-17 17:59:16.536972
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from marshmallow.exceptions import ValidationError
    from dataclasses_json.utils import _is_optional
    from dataclasses_json.core import _is_new_type
    from dataclasses_json.core import _is_supported_generic
    from dataclasses_json.core import _is_collection
    from dataclasses_json.core import _issubclass_safe
    from dataclasses_json.core import _get_type_origin
    from dataclasses_json.core import _handle_undefined_parameters_safe
    from dataclasses_json.core import CatchAllVar
    from dataclasses_json.core import _Tim

# Generated at 2022-06-17 17:59:44.747298
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 17:59:56.586501
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    @dataclass
    class A:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Optional[int]
        e: typing.Optional[typing.List[int]]
        f: typing.Optional[typing.List[typing.Optional[int]]]
        g: typing.Optional[typing.List[typing.Optional[typing.List[int]]]]
        h: typing.Optional[typing.List[typing.Optional[typing.List[typing.Optional[int]]]]]
        i: typing.Optional[typing.List[typing.Optional[typing.List[typing.Optional[typing.List[int]]]]]]

# Generated at 2022-06-17 18:00:03.117397
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields

    class MySchema(Schema):
        name = fields.Str()

    class MyData:
        def __init__(self, name: str):
            self.name = name

    schema = SchemaF[MyData](MySchema)
    data = MyData('test')
    result = schema.dump(data)
    assert result == {'name': 'test'}



# Generated at 2022-06-17 18:00:12.136887
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int

    class ASchema(SchemaF[A]):
        a = fields.Int()

    assert ASchema().loads('{"a": 1}') == A(1)
    assert ASchema().loads('[{"a": 1}]') == [A(1)]
    assert ASchema().loads(b'{"a": 1}') == A(1)
    assert ASchema().loads(b'[{"a": 1}]') == [A(1)]



# Generated at 2022-06-17 18:00:20.390521
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses import dataclass
    from marshmallow import Schema, fields

    @dataclass
    class Foo:
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo_schema = FooSchema()

    foo = foo_schema.load({'a': 1, 'b': 'b'})
    assert foo.a == 1
    assert foo.b == 'b'

    foos = foo_schema.load([{'a': 1, 'b': 'b'}, {'a': 2, 'b': 'c'}])
    assert foos[0].a == 1
    assert foos[0].b == 'b'
    assert foos[1].a == 2
   

# Generated at 2022-06-17 18:00:24.762904
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    assert SchemaF[int].dumps([1, 2, 3]) == '[1, 2, 3]'
    assert SchemaF[int].dumps(1) == '1'


# Generated at 2022-06-17 18:00:32.066976
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclass_json
    @dataclass
    class A:
        a: int

    @dataclass_json
    @dataclass
    class B:
        b: typing.List[A]

    @dataclass_json
    @dataclass
    class C:
        c: typing.List[B]

    a = A(1)
    b = B([a])
    c = C([b])

    assert SchemaF[A].dump(a) == {'a': 1}
    assert SchemaF[A].dump([a]) == [{'a': 1}]
    assert SchemaF[B].dump(b) == {'b': [{'a': 1}]}

# Generated at 2022-06-17 18:00:41.597164
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Foo:
        def __init__(self, x: int):
            self.x = x

    class FooSchema(SchemaF[Foo]):
        x = fields.Int()

        @post_load
        def make_foo(self, data, **kwargs):
            return Foo(**data)

    schema = FooSchema()
    assert schema.load({'x': 1}) == Foo(1)
    assert schema.load([{'x': 1}, {'x': 2}]) == [Foo(1), Foo(2)]
    assert schema.loads('{"x": 1}') == Foo(1)
    assert schema.loads('[{"x": 1}, {"x": 2}]') == [Foo(1), Foo(2)]



# Generated at 2022-06-17 18:00:54.190105
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from dataclasses_json.mm import Mapping
    from marshmallow import fields
    from typing import Optional, List

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: Optional[str]
        d: List[str]
        e: Mapping[str, int]


# Generated at 2022-06-17 18:01:03.980362
# Unit test for function build_type
def test_build_type():
    from typing import List, Optional, Union
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from dataclasses_json.mm import Schema
    from dataclasses_json.core import _is_new_type, _is_optional, _is_collection
    from dataclasses_json.utils import _issubclass_safe
    from dataclasses import dataclass
    from enum import Enum

    class TestEnum(Enum):
        A = 1
        B = 2

    @dataclass
    class TestDC:
        pass

    @dataclass
    class TestDC2(Schema):
        pass

    @dataclass
    class TestDC3(Schema):
        pass

    @dataclass
    class TestDC4(Schema):
        pass


# Generated at 2022-06-17 18:01:58.020222
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._deserialize('2020-01-01T00:00:00') == datetime(2020, 1, 1, 0, 0)
    assert _IsoField()._serialize(datetime(2020, 1, 1, 0, 0)) == '2020-01-01T00:00:00'


# Generated at 2022-06-17 18:02:02.408833
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from dataclasses import dataclass
    from marshmallow import Schema, fields

    @dataclass
    class A:
        a: int

    class ASchema(SchemaF[A]):
        a = fields.Int()

    assert ASchema().loads('{"a": 1}') == A(1)
    assert ASchema().loads('[{"a": 1}]') == [A(1)]



# Generated at 2022-06-17 18:02:03.661229
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()


# Generated at 2022-06-17 18:02:13.702068
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from typing import List
    from marshmallow import Schema, fields
    class Foo(Schema):
        a = fields.Int()
    class FooF(SchemaF[Foo]):
        pass
    f = FooF()
    f.load([{'a': 1}, {'a': 2}])
    f.load([{'a': 1}, {'a': 2}], many=True)
    f.load({'a': 1})
    f.load({'a': 1}, many=False)
    f.load({'a': 1}, many=None)
    f.load({'a': 1}, many=True)
    f.load([{'a': 1}, {'a': 2}])
    f.load([{'a': 1}, {'a': 2}], many=True)

# Generated at 2022-06-17 18:02:23.893975
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field.deserialize(None) is None
    assert field.deserialize(0) == datetime(1970, 1, 1, 0, 0, 0)
    assert field.deserialize(1) == datetime(1970, 1, 1, 0, 0, 1)
    assert field.deserialize(1.5) == datetime(1970, 1, 1, 0, 0, 1, 500000)
    assert field.deserialize(1.123456789) == datetime(1970, 1, 1, 0, 0, 1, 123457)
    assert field.deserialize(1.123456789, required=True) == datetime(1970, 1, 1, 0, 0, 1, 123457)
    assert field.deserialize(None, required=True) is None


# Generated at 2022-06-17 18:02:29.178428
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import Schema, fields

    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int


# Generated at 2022-06-17 18:02:39.177047
# Unit test for function build_schema
def test_build_schema():
    class Mixin:
        pass

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[int]
        f: typing.Optional[str]
        g: typing.Optional[typing.List[int]]
        h: typing.Optional[typing.Dict[str, int]]
        i: typing.Union[int, str]
        j: typing.Union[typing.List[int], str]
        k: typing.Union[typing.Dict[str, int], str]
        l: typing.Union[int, str, typing.List[int], typing.Dict[str, int]]

# Generated at 2022-06-17 18:02:44.996475
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.utcnow(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.utcnow().timestamp(), None, None) is not None



# Generated at 2022-06-17 18:02:57.257908
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin, dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from marshmallow.exceptions import ValidationError
    from dataclasses_json.utils import _is_optional, _is_new_type, _get_type_origin
    from typing import Optional, Union, List, Dict, Any, Tuple, Callable, Mapping, MutableMapping
    from datetime import datetime
    from decimal import Decimal
    from uuid import UUID
    from enum import Enum
    from typing_inspect import is_union_type  # type: ignore

    class LetterCase(Enum):
        SNAKE = 'snake'
        CAMEL = 'camel'
        PASCAL

# Generated at 2022-06-17 18:03:00.952106
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field._serialize(datetime.now(), None, None) is not None
    assert field._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 18:04:10.378214
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields
    from dataclasses import dataclass
    from typing import List

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: List[A]

    class ASchema(SchemaF[A]):
        a = fields.Int()

    class BSchema(SchemaF[B]):
        b = fields.Nested(ASchema, many=True)

    b = B(b=[A(a=1), A(a=2)])
    b_schema = BSchema()
    b_json = b_schema.dumps(b)
    b_loaded = b_schema.loads(b_json)
    assert b == b_loaded



# Generated at 2022-06-17 18:04:20.759603
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError
    from dataclasses import dataclass
    from typing import List
    @dataclass
    class A:
        a: int
    class ASchema(Schema):
        a = fields.Integer()
    schema = ASchema()
    assert schema.loads('{"a": 1}') == A(1)
    assert schema.loads('[{"a": 1}]') == [A(1)]
    assert schema.loads('[{"a": 1}, {"a": 2}]') == [A(1), A(2)]
    try:
        schema.loads('[{"a": 1}, {"a": "2"}]')
        assert False
    except ValidationError:
        pass

# Generated at 2022-06-17 18:04:27.283132
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses import dataclass
    from marshmallow import fields

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: str

    @dataclass
    class C:
        c: typing.List[A]

    @dataclass
    class D:
        d: typing.List[B]

    @dataclass
    class E:
        e: typing.List[C]

    @dataclass
    class F:
        f: typing.List[D]

    @dataclass
    class G:
        g: typing.List[E]

    @dataclass
    class H:
        h: typing.List[F]

    @dataclass
    class I:
        i: typing.List[G]


# Generated at 2022-06-17 18:04:36.251916
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from marshmallow.exceptions import ValidationError
    from dataclasses_json.utils import _is_new_type
    from dataclasses_json.core import _is_supported_generic, _is_collection
    from typing import Optional, List, Union, Dict, Any, Callable, Mapping, MutableMapping, Tuple, AnyStr
    from datetime import datetime
    from uuid import UUID
    from decimal import Decimal
    from enum import Enum
    from typing_inspect import is_union_type
    from dataclasses_json.utils import _is_optional, _issubclass_safe, _get_type_origin, CatchAll

# Generated at 2022-06-17 18:04:44.498391
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from typing import Optional, Union, List, Dict, Any
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from enum import Enum

    @dataclass
    class A:
        pass

    @dataclass
    class B:
        pass

    @dataclass
    class C:
        a: Optional[Union[A, B]]

    assert isinstance(build_type(C.a.type, {}, None, C.a, C), fields.Field)

    @dataclass
    class D:
        a: Optional[Union[A, B, str]]

    assert isinstance(build_type(D.a.type, {}, None, D.a, D), fields.Field)

    @dataclass
    class E:
        a

# Generated at 2022-06-17 18:04:55.931295
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Foo(typing.Generic[A]):
        def __init__(self, a: A):
            self.a = a

    class FooSchema(SchemaF[A]):
        a = fields.Field()

    assert FooSchema().dump(Foo(1)) == {'a': 1}
    assert FooSchema().dump([Foo(1), Foo(2)]) == [{'a': 1}, {'a': 2}]
    assert FooSchema().dump(Foo('a')) == {'a': 'a'}
    assert FooSchema().dump([Foo('a'), Foo('b')]) == [{'a': 'a'}, {'a': 'b'}]


# Generated at 2022-06-17 18:05:02.341986
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[int]
        f: typing.Optional[typing.List[int]]
        g: typing.Optional[typing.Dict[str, int]]
        h: typing.Optional[typing.Union[str, int]]
        i: typing.Optional[typing.Union[str, int, typing.List[int]]]
        j: typing.Optional[typing.Union[str, int, typing.List[int], typing.Dict[str, int]]]

# Generated at 2022-06-17 18:05:08.409076
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import Schema, fields, post_load

    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
        c: float
        d: bool
        e: list
        f: dict
        g: typing.List[int]
        h: typing.Dict[str, int]
        i: typing.Optional[int]
        j: typing.Optional[typing.List[int]]
        k: typing.Optional[typing.Dict[str, int]]
        l: typing.Optional[typing.Union[str, int]]
        m: typing.Optional[typing.Union[str, int, None]]

# Generated at 2022-06-17 18:05:19.862738
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from typing import List, Optional

    @dataclass
    class Test:
        name: str
        age: int
        weight: Optional[float]
        friends: List[str]
        friends_opt: Optional[List[str]]

    class TestSchema(Schema):
        name = fields.Str()
        age = fields.Int()
        weight = fields.Float()
        friends = fields.List(fields.Str())
        friends_opt = fields.List(fields.Str(), allow_none=True)

    Test.schema = TestSchema

    assert build_type(Test, {}, None, None, None)(Test, {}) == fields.Nested(
        TestSchema, field_many=False)

# Generated at 2022-06-17 18:05:24.830226
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Foo(typing.Generic[A]):
        def __init__(self, a: A):
            self.a = a

    class FooSchema(SchemaF[Foo[A]]):
        a = fields.Field()

    assert FooSchema().load({'a': 'b'}) == Foo('b')

