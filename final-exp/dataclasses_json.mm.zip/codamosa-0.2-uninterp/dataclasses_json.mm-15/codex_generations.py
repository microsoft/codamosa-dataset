

# Generated at 2022-06-17 17:56:23.470281
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    @dataclass
    class TestClass:
        a: int
        b: str
        c: typing.List[int]
        d: typing.List[str]
        e: typing.List[typing.List[int]]
        f: typing.List[typing.List[str]]
        g: typing.List[typing.List[typing.List[int]]]
        h: typing.List[typing.List[typing.List[str]]]
        i: typing.List[typing.List[typing.List[typing.List[int]]]]
        j: typing.List[typing.List[typing.List[typing.List[str]]]]

# Generated at 2022-06-17 17:56:29.987297
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Foo(typing.NamedTuple):
        a: int
        b: str
    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()
    foo_schema = FooSchema()
    foo_schema.loads('{"a": 1, "b": "foo"}')
    foo_schema.loads('[{"a": 1, "b": "foo"}]')
    foo_schema.loads(b'{"a": 1, "b": "foo"}')
    foo_schema.loads(b'[{"a": 1, "b": "foo"}]')
    foo_schema.loads(bytearray('{"a": 1, "b": "foo"}', 'utf-8'))

# Generated at 2022-06-17 17:56:36.325885
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class S(SchemaF[A]):
        pass
    s = S()
    s.dump([1, 2, 3])
    s.dump(1)
    s.dump(None)
    s.dump(1, many=False)
    s.dump([1, 2, 3], many=True)
    s.dump(1, many=True)
    s.dump(None, many=True)
    s.dump(1, many=False)
    s.dump([1, 2, 3], many=False)
    s.dump(1, many=None)
    s.dump([1, 2, 3], many=None)
    s.dump(1, many=None)
    s.dump(None, many=None)
    s.dump(1, many=None)

# Generated at 2022-06-17 17:56:46.061811
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from typing import List, Optional

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: List[A]

    @dataclass
    class C:
        c: Optional[A]

    @dataclass
    class D:
        d: Optional[List[A]]

    @dataclass
    class E:
        e: Optional[List[Optional[A]]]

    @dataclass
    class F:
        f: Optional[List[Optional[List[A]]]]

    @dataclass
    class G:
        g: Optional[List[Optional[List[Optional[A]]]]]


# Generated at 2022-06-17 17:56:55.728423
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None)
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None)
    assert _TimestampField(required=False)._serialize(None, None, None) is None
    assert _TimestampField(required=False)._deserialize(None, None, None) is None
    try:
        _TimestampField()._serialize(None, None, None)
        assert False
    except ValidationError:
        assert True
    try:
        _TimestampField()._deserialize(None, None, None)
        assert False
    except ValidationError:
        assert True



# Generated at 2022-06-17 17:56:59.873511
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin
    from dataclasses_json.utils import _is_new_type
    from marshmallow import fields
    from marshmallow.exceptions import ValidationError
    from marshmallow.schema import Schema
    from typing import Optional
    from dataclasses_json.utils import _is_optional
    from dataclasses_json.utils import _is_new_type
    from dataclasses_json.utils import _is_supported_generic
    from dataclasses_json.utils import _is_collection
    from dataclasses_json.utils import _issubclass_safe
    from dataclasses_json.utils import _get_type_origin
    from dataclasses_json.utils import is_dataclass

# Generated at 2022-06-17 17:57:03.421653
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class MySchema(SchemaF[A]):
        pass

    assert MySchema().dump([]) == []
    assert MySchema().dump(None) is None
    assert MySchema().dump([1, 2, 3]) == [1, 2, 3]
    assert MySchema().dump(1) == 1


# Generated at 2022-06-17 17:57:13.350076
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from typing import List
    from marshmallow import Schema, fields
    class MySchema(Schema):
        name = fields.Str()
    schema = SchemaF[MySchema]()
    schema.load([{'name': 'foo'}, {'name': 'bar'}])
    schema.load({'name': 'foo'})
    schema.load([{'name': 'foo'}, {'name': 'bar'}], many=True)
    schema.load({'name': 'foo'}, many=False)
    schema.load([{'name': 'foo'}, {'name': 'bar'}], many=False)
    schema.load({'name': 'foo'}, many=True)
    schema.load([{'name': 'foo'}, {'name': 'bar'}], many=None)
   

# Generated at 2022-06-17 17:57:18.487898
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._serialize(datetime(2020, 1, 1), 'attr', 'obj') == '2020-01-01T00:00:00'
    assert _IsoField()._deserialize('2020-01-01T00:00:00', 'attr', 'data') == datetime(2020, 1, 1)


# Generated at 2022-06-17 17:57:23.834805
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    @dataclass
    class A:
        a: int
        b: str
    @dataclass
    class B:
        a: A
        b: str
    @dataclass
    class C:
        a: A
        b: B
    @dataclass
    class D:
        a: A
        b: typing.List[B]
    @dataclass
    class E:
        a: typing.List[A]
        b: typing.List[B]
    @dataclass
    class F:
        a: typing.List[A]
        b: typing.List[B]
        c: typing.List[C]
    @dataclass
    class G:
        a: typing.List[A]

# Generated at 2022-06-17 17:57:50.912128
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json.api import from_dict, from_json, from_json_dict, from_json_list, from_json_str, from_json_tuple, from_json_union, from_json_value, from_json_value_list, from_json_value_tuple, from_json_value_union, from_json_value_value, from_json_value_value_list, from_json_value_value_tuple, from_json_value_value_union, from_json_value_value_value, from_json_value_value_value_list, from_json_value_value_value_tuple, from_json_value_value_value_union, from_json_value_value_value_value, from_json_value_value_value_value

# Generated at 2022-06-17 17:57:59.047769
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class A:
        a: int

    @dataclass_json
    @dataclass
    class B:
        a: A

    assert schema(B, dataclass_json.DataClassJsonMixin, False) == {'a': fields.Nested(A.schema())}


# Generated at 2022-06-17 17:58:09.466051
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: float
        d: typing.List[int]
        e: typing.Dict[str, int]
        f: typing.List[typing.Dict[str, int]]
        g: typing.List[typing.Optional[int]]
        h: typing.Optional[typing.List[int]]
        i: typing.Optional[int]
        j: typing.Optional[typing.Optional[int]]
        k: typing.Optional[typing.Optional[typing.Optional[int]]]

# Generated at 2022-06-17 17:58:18.308923
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import List, Dict, Any
    from marshmallow import Schema, fields
    class MySchema(Schema):
        a = fields.Int()
        b = fields.Str()
    class MySchemaF(SchemaF[Dict[str, Any]]):
        pass
    MySchemaF.__bases__ = (MySchema,)
    s = MySchemaF()
    assert s.dump({"a": 1, "b": "2"}) == {"a": 1, "b": "2"}
    assert s.dump([{"a": 1, "b": "2"}, {"a": 3, "b": "4"}]) == [{"a": 1, "b": "2"}, {"a": 3, "b": "4"}]

# Generated at 2022-06-17 17:58:30.051138
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from typing import List, Optional, Union

    @dataclass_json
    @dataclass
    class Test:
        a: Optional[int]
        b: List[int]
        c: Union[int, str]
        d: Union[int, Test]

    assert build_type(int, {}, dataclass_json.DataClassJsonMixin,
                      dc_fields(Test)[0], Test) == fields.Int(allow_none=True)

# Generated at 2022-06-17 17:58:41.459769
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Optional[int]
        e: typing.Optional[typing.List[int]]
        f: typing.Optional[typing.List[typing.Optional[int]]]
        g: typing.Optional[typing.List[typing.Optional[typing.List[int]]]]
        h: typing.Optional[typing.List[typing.Optional[typing.List[typing.Optional[int]]]]]

# Generated at 2022-06-17 17:58:55.207552
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class TestSchema(SchemaF[A]):
        pass
    assert TestSchema().dumps([1, 2, 3]) == '[1, 2, 3]'
    assert TestSchema().dumps(1) == '1'
    assert TestSchema().dumps(1, many=False) == '1'
    assert TestSchema().dumps([1, 2, 3], many=False) == '[1, 2, 3]'
    assert TestSchema().dumps(1, many=True) == '1'
    assert TestSchema().dumps([1, 2, 3], many=True) == '[1, 2, 3]'
    assert TestSchema().dumps(1, many=False, indent=2) == '1'

# Generated at 2022-06-17 17:59:04.540535
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import fields, Schema
    from dataclasses import dataclass
    from typing import List

    @dataclass
    class Foo:
        a: int
        b: str

    @dataclass
    class Bar:
        c: List[Foo]

    class FooSchema(Schema):
        a = fields.Int()
        b = fields.Str()

    class BarSchema(Schema):
        c = fields.Nested(FooSchema, many=True)

    foo = Foo(a=1, b='2')
    bar = Bar(c=[foo])

    foo_schema = FooSchema()
    bar_schema = BarSchema()

    foo_schema_f = SchemaF[Foo]()
    bar_schema_f = SchemaF[Bar]()

# Generated at 2022-06-17 17:59:15.251381
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass, field
    from dataclasses_json import dataclass_json
    from marshmallow import Schema, fields

    @dataclass_json
    @dataclass
    class Foo:
        a: int
        b: str
        c: typing.Optional[str] = None
        d: typing.Optional[str] = field(default=None)
        e: typing.Optional[str] = field(default_factory=lambda: None)
        f: typing.Optional[str] = field(default=None, metadata={'dataclasses_json': {'mm_field': fields.Str()}})


# Generated at 2022-06-17 17:59:26.712252
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from typing import Optional, Union, List, Dict, Any

    @dataclass_json
    @dataclass
    class Test:
        a: Optional[Union[int, str]]
        b: List[int]
        c: Dict[str, Any]
        d: Optional[Union[int, str]]

    @dataclass_json
    @dataclass
    class Test2:
        a: Optional[Union[int, str]]
        b: List[int]
        c: Dict[str, Any]
        d: Optional[Union[int, str]]

    @dataclass_json
    @dataclass
    class Test3:
        a: Optional[Union[int, str]]

# Generated at 2022-06-17 18:00:03.540350
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from typing import Optional, Union, List, Dict

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: str

    @dataclass
    class C:
        c: Optional[int]

    @dataclass
    class D:
        d: Union[A, B]

    @dataclass
    class E:
        e: List[int]

    @dataclass
    class F:
        f: Dict[str, int]

    @dataclass
    class G:
        g: Union[A, B, C]

    @dataclass
    class H:
        h: Union[A, B, C, D]

    @dataclass
    class I:
        i: Union

# Generated at 2022-06-17 18:00:15.017727
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class Foo:
        bar: str

    @dataclass_json
    @dataclass
    class FooSchema(SchemaF[Foo]):
        bar: str = fields.Str()

    assert FooSchema.loads('{"bar": "baz"}') == Foo('baz')
    assert FooSchema.loads('[{"bar": "baz"}]') == [Foo('baz')]
    assert FooSchema.loads('[{"bar": "baz"}, {"bar": "baz"}]') == [Foo('baz'), Foo('baz')]

# Generated at 2022-06-17 18:00:21.535585
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str

    assert schema(Test, None, False) == {'a': fields.Int(), 'b': fields.Str()}



# Generated at 2022-06-17 18:00:29.063754
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Foo(typing.Generic[A]):
        def __init__(self, a: A):
            self.a = a

    class FooSchema(SchemaF[Foo[int]]):
        a = fields.Int()

    assert FooSchema().load({'a': 1}) == Foo(1)
    assert FooSchema().load([{'a': 1}]) == [Foo(1)]
    assert FooSchema().load([{'a': 1}, {'a': 2}]) == [Foo(1), Foo(2)]



# Generated at 2022-06-17 18:00:40.445817
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class A(typing.NamedTuple):
        a: int
        b: str

    class B(typing.NamedTuple):
        a: int
        b: str

    class C(typing.NamedTuple):
        a: int
        b: str

    class D(typing.NamedTuple):
        a: int
        b: str

    class E(typing.NamedTuple):
        a: int
        b: str

    class F(typing.NamedTuple):
        a: int
        b: str

    class G(typing.NamedTuple):
        a: int
        b: str

    class H(typing.NamedTuple):
        a: int
        b: str

    class I(typing.NamedTuple):
        a

# Generated at 2022-06-17 18:00:53.492126
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from typing import List, Optional

    @dataclass
    class A:
        a: int
        b: str
        c: List[int]
        d: Optional[str]

    schema = build_schema(A, None, False, False)
    assert schema.Meta.fields == ('a', 'b', 'c', 'd')
    assert isinstance(schema().fields['a'], fields.Int)
    assert isinstance(schema().fields['b'], fields.Str)
    assert isinstance(schema().fields['c'], fields.List)
    assert isinstance(schema().fields['d'], fields.Str)
    assert schema().fields['d'].allow_none is True



# Generated at 2022-06-17 18:01:03.508270
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int

    @dataclass_json
    @dataclass
    class Test2:
        a: Test
        b: int

    assert schema(Test, dataclass_json.DataClassJsonMixin, False) == {
        'a': fields.Str(default=MISSING, allow_none=False, required=True),
        'b': fields.Int(default=MISSING, allow_none=False, required=True)
    }


# Generated at 2022-06-17 18:01:07.578397
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field._serialize(datetime.now(), None, None) is not None
    assert field._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 18:01:16.577271
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    import typing

    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: typing.Optional[int]
        c: typing.Optional[str] = None
        d: typing.Optional[typing.List[str]] = None
        e: typing.Optional[typing.List[int]] = None
        f: typing.Optional[typing.List[typing.List[int]]] = None
        g: typing.Optional[typing.List[typing.List[str]]] = None
        h: typing.Optional[typing.List[typing.List[typing.List[str]]]] = None

# Generated at 2022-06-17 18:01:24.557122
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from typing import List, Optional, Union
    from enum import Enum

    class MyEnum(Enum):
        a = 1
        b = 2
        c = 3

    @dataclass_json
    @dataclass
    class MyClass:
        a: int
        b: str
        c: float
        d: bool
        e: List[int]
        f: Optional[str]
        g: Union[int, str]
        h: MyEnum

    @dataclass_json
    @dataclass
    class MyClass2:
        a: MyClass


# Generated at 2022-06-17 18:01:59.394973
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
        c: typing.Optional[str]
        d: typing.Optional[int] = None
        e: typing.Optional[typing.List[int]] = None
        f: typing.Optional[typing.List[str]] = None
        g: typing.Optional[typing.List[typing.Optional[str]]] = None
        h: typing.Optional[typing.List[typing.Optional[int]]] = None
        i: typing.Optional[typing.List[typing.Optional[typing.List[int]]]] = None

# Generated at 2022-06-17 18:02:04.229177
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field._serialize(datetime.now(), None, None) is not None
    assert field._deserialize(datetime.now().isoformat(), None, None) is not None


# Generated at 2022-06-17 18:02:07.134649
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Foo:
        a: int

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()

    foo = Foo(1)
    assert FooSchema().load({"a": 1}) == foo
    assert FooSchema().load([{"a": 1}, {"a": 2}]) == [foo, Foo(2)]



# Generated at 2022-06-17 18:02:10.259540
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    assert FooSchema().dumps(Foo(1, 'a')) == '{"a": 1, "b": "a"}'
    assert FooSchema().dumps([Foo(1, 'a'), Foo(2, 'b')]) == '[{"a": 1, "b": "a"}, {"a": 2, "b": "b"}]'



# Generated at 2022-06-17 18:02:21.334828
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.List[str]
        e: typing.Dict[str, int]
        f: typing.Dict[str, str]
        g: typing.Tuple[int, str]
        h: typing.Tuple[str, int]
        i: typing.Optional[int]
        j: typing.Optional[str]
        k: typing.Optional[typing.List[int]]
        l: typing.Optional[typing.List[str]]
        m: typing.Optional[typing.Dict[str, int]]

# Generated at 2022-06-17 18:02:29.170039
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from typing import List, Optional, Union
    from enum import Enum

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: List[int]
        d: Optional[str]
        e: Union[int, str]

    @dataclass_json
    @dataclass
    class Test2:
        a: int
        b: str
        c: List[int]
        d: Optional[str]
        e: Union[int, str]

    @dataclass_json
    @dataclass
    class Test3:
        a: int
        b: str

# Generated at 2022-06-17 18:02:39.136658
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses import dataclass
    from marshmallow import Schema, fields

    @dataclass
    class User:
        name: str
        age: int

    class UserSchema(SchemaF[User]):
        name = fields.Str()
        age = fields.Int()

    user_schema = UserSchema()
    user = user_schema.load({'name': 'John', 'age': 42})
    assert user.name == 'John'
    assert user.age == 42

    users = user_schema.load([{'name': 'John', 'age': 42}, {'name': 'Jane', 'age': 43}])
    assert users[0].name == 'John'
    assert users[0].age == 42
    assert users[1].name == 'Jane'
    assert users[1].age

# Generated at 2022-06-17 18:02:53.699967
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_dataclass import class_schema

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str

    assert class_schema(Test) == build_schema(Test, None, False, False)

    @dataclass_json
    @dataclass
    class Test2:
        a: int
        b: str

    assert class_schema(Test2) == build_schema(Test2, None, False, False)

    @dataclass_json
    @dataclass
    class Test3:
        a: int
        b: str

    assert class_schema(Test3) == build_schema

# Generated at 2022-06-17 18:03:05.026596
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from typing import List, Optional
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from marshmallow.exceptions import ValidationError
    from dataclasses_json import dataclass_json
    from dataclasses_json.mm import Schema

    @dataclass_json
    @dataclass
    class Nested:
        a: int

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: Optional[int]
        c: List[int]
        d: Nested
        e: Nested
        f: str
        g: Optional[str]
        h: List[str]
        i: List[Nested]
        j: Optional[List[Nested]]

# Generated at 2022-06-17 18:03:14.714596
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from dataclasses_json.mm import Schema

    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
        c: typing.Optional[int]
        d: typing.Optional[int] = None
        e: typing.Optional[int] = 1
        f: typing.Optional[int] = None
        g: typing.Optional[int] = 1
        h: typing.Optional[typing.Union[int, str]] = None
        i: typing.Optional[typing.Union[int, str]] = 1

# Generated at 2022-06-17 18:04:38.222582
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.Optional[str]
        d: typing.Optional[int] = None
        e: typing.Optional[typing.List[str]] = None
        f: typing.Optional[typing.List[int]] = None
        g: typing.Optional[typing.List[typing.Optional[str]]] = None
        h: typing.Optional[typing.List[typing.Optional[int]]] = None
        i: typing.Optional[typing.List[typing.Optional[int]]] = None

# Generated at 2022-06-17 18:04:44.834243
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields
    class Foo(Schema):
        a = fields.Int()
    assert SchemaF[Foo].loads('{"a": 1}') == Foo(a=1)
    assert SchemaF[Foo].loads('[{"a": 1}]') == [Foo(a=1)]
    assert SchemaF[Foo].loads(b'{"a": 1}') == Foo(a=1)
    assert SchemaF[Foo].loads(b'[{"a": 1}]') == [Foo(a=1)]
    assert SchemaF[Foo].loads(bytearray('{"a": 1}', 'utf-8')) == Foo(a=1)

# Generated at 2022-06-17 18:04:53.072899
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo = FooSchema().loads({"a": 1, "b": "b"})
    assert foo.a == 1
    assert foo.b == "b"



# Generated at 2022-06-17 18:04:59.743145
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Foo(typing.Generic[A]):
        def __init__(self, a: A):
            self.a = a

    class FooSchema(SchemaF[Foo[int]]):
        a = fields.Int()

    foo = FooSchema().loads('{"a": 1}')
    assert foo.a == 1



# Generated at 2022-06-17 18:05:04.483376
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._serialize(datetime(2020, 1, 1, 0, 0, 0), None, None) == '2020-01-01T00:00:00'
    assert _IsoField()._deserialize('2020-01-01T00:00:00', None, None) == datetime(2020, 1, 1, 0, 0, 0)
    assert _IsoField()._deserialize(None, None, None) == None


# Generated at 2022-06-17 18:05:06.680563
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._serialize(datetime.now(), None, None)
    assert _IsoField()._deserialize(datetime.now().isoformat(), None, None)


# Generated at 2022-06-17 18:05:18.405769
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class A:
        a: str
        b: int

    @dataclass_json
    @dataclass
    class B:
        a: A
        b: typing.List[A]

    assert schema(A, dataclass_json, False) == {
        'a': fields.Str,
        'b': fields.Int
    }

    assert schema(B, dataclass_json, False) == {
        'a': fields.Nested(A.schema()),
        'b': fields.Nested(A.schema(), many=True)
    }



# Generated at 2022-06-17 18:05:22.338528
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 18:05:31.671475
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Foo:
        a: int

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()

    foo_schema = FooSchema()
    foo = Foo(a=1)
    assert foo_schema.dump(foo) == {'a': 1}
    assert foo_schema.dump([foo]) == [{'a': 1}]
    assert foo_schema.dump([foo], many=True) == [{'a': 1}]
    assert foo_schema.dump(foo, many=False) == {'a': 1}
    assert foo_schema.dump(foo, many=None) == {'a': 1}



# Generated at 2022-06-17 18:05:41.183008
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class MySchema(SchemaF[int]):
        pass

    assert MySchema().dumps([1, 2, 3]) == '[1, 2, 3]'
    assert MySchema().dumps(1) == '1'
    assert MySchema().dumps([1, 2, 3], many=True) == '[1, 2, 3]'
    assert MySchema().dumps(1, many=False) == '1'
    assert MySchema().dumps([1, 2, 3], many=False) == '[1, 2, 3]'
    assert MySchema().dumps(1, many=True) == '1'
