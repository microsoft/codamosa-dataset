

# Generated at 2022-06-17 17:56:20.428584
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Foo:
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo = Foo(1, 'b')
    schema = FooSchema()
    assert schema.dump(foo) == {'a': 1, 'b': 'b'}



# Generated at 2022-06-17 17:56:23.837885
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._deserialize('2020-01-01T00:00:00') == datetime(2020, 1, 1, 0, 0, 0)
    assert _IsoField()._serialize(datetime(2020, 1, 1, 0, 0, 0)) == '2020-01-01T00:00:00'


# Generated at 2022-06-17 17:56:33.489450
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from dataclasses_json.mm import Mapping
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str

    @dataclass_json
    @dataclass
    class Test2:
        a: int
        b: str
        c: Test

    @dataclass_json
    @dataclass
    class Test3:
        a: int
        b: str
        c: Test
        d: Mapping[str, Test]

    @dataclass_json
    @dataclass
    class Test4:
        a: int
        b: str
        c: Test
        d: Mapping[str, Test]

# Generated at 2022-06-17 17:56:44.419441
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class A:
        a: int

    @dataclass_json
    @dataclass
    class B:
        b: A

    @dataclass_json
    @dataclass
    class C:
        c: typing.List[A]

    @dataclass_json
    @dataclass
    class D:
        d: typing.List[B]

    @dataclass_json
    @dataclass
    class E:
        e: typing.List[C]

    @dataclass_json
    @dataclass
    class F:
        f: typing.List[D]


# Generated at 2022-06-17 17:56:57.008841
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields

    class TestSchema(Schema):
        a = fields.Str()

    schema = SchemaF[TestSchema]()
    schema.load({"a": "b"})
    schema.load([{"a": "b"}])
    schema.load([{"a": "b"}, {"a": "c"}])
    schema.load({"a": "b"}, many=True)
    schema.load([{"a": "b"}, {"a": "c"}], many=True)
    schema.load([{"a": "b"}, {"a": "c"}], many=False)
    schema.load({"a": "b"}, many=False)
    schema.load({"a": "b"}, many=False, partial=True)

# Generated at 2022-06-17 17:57:00.128298
# Unit test for function build_schema
def test_build_schema():
    class Test:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    class TestSchema(Schema):
        a = fields.Int()
        b = fields.Int()

    assert build_schema(Test, None, False, False) == TestSchema



# Generated at 2022-06-17 17:57:09.237098
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields as mm_fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.List[str]
        e: typing.Dict[str, int]
        f: typing.Dict[str, str]
        g: typing.Optional[int]
        h: typing.Optional[str]
        i: typing.Optional[typing.List[int]]
        j: typing.Optional[typing.List[str]]
        k: typing.Optional[typing.Dict[str, int]]
        l: typing.Optional[typing.Dict[str, str]]

# Generated at 2022-06-17 17:57:12.908230
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field._serialize(datetime.now(), None, None) is not None
    assert field._deserialize(datetime.now().isoformat(), None, None) is not None


# Generated at 2022-06-17 17:57:20.642235
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from typing import Optional, Union, List, Dict
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class A:
        a: int

    @dataclass_json
    @dataclass
    class B:
        b: str

    @dataclass_json
    @dataclass
    class C:
        c: Optional[int]

    @dataclass_json
    @dataclass
    class D:
        d: Union[A, B]

    @dataclass_json
    @dataclass
    class E:
        e: List[int]

    @dataclass_json
    @dataclass
    class F:
        f: Dict

# Generated at 2022-06-17 17:57:27.874890
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo = Foo(a=1, b='b')
    assert FooSchema().dumps(foo) == '{"a": 1, "b": "b"}'
    assert FooSchema().dumps([foo]) == '[{"a": 1, "b": "b"}]'



# Generated at 2022-06-17 17:57:54.752450
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    from dataclasses import dataclass
    from typing import List

    @dataclass
    class Person:
        name: str
        age: int

    class PersonSchema(SchemaF[Person]):
        name = fields.Str()
        age = fields.Int()

    schema = PersonSchema()
    person = schema.load({'name': 'John', 'age': 42})
    assert person.name == 'John'
    assert person.age == 42
    people = schema.load([{'name': 'John', 'age': 42}, {'name': 'Jane', 'age': 43}])
    assert people[0].name == 'John'
    assert people[0].age == 42
    assert people[1].name == 'Jane'
    assert people[1].age == 43


# Generated at 2022-06-17 17:58:05.360011
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field.deserialize(None) is None
    assert field.deserialize(0) == datetime(1970, 1, 1, 0, 0, 0, tzinfo=None)
    assert field.deserialize(1) == datetime(1970, 1, 1, 0, 0, 1, tzinfo=None)
    assert field.deserialize(1.1) == datetime(1970, 1, 1, 0, 0, 1, 100000, tzinfo=None)
    assert field.deserialize(1.123456789) == datetime(1970, 1, 1, 0, 0, 1, 123457, tzinfo=None)

# Generated at 2022-06-17 17:58:15.606237
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str

# Generated at 2022-06-17 17:58:22.326816
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class Test(DataClassJsonMixin):
        a: int
        b: str


# Generated at 2022-06-17 17:58:27.662943
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from typing import Optional

    @dataclass
    class Test:
        a: int
        b: Optional[int]

    schema = build_schema(Test, None, False, False)
    assert schema.__name__ == 'TestSchema'
    assert schema.Meta.fields == ('a', 'b')
    assert schema.__dict__['a'].__class__ == fields.Int
    assert schema.__dict__['b'].__class__ == fields.Int
    assert schema.__dict__['b'].allow_none == True
    assert schema.__dict__['b'].missing == None

    @dataclass
    class Test:
        a: int
        b: Optional[int] = None

    schema = build_schema(Test, None, False, False)


# Generated at 2022-06-17 17:58:39.295521
# Unit test for function build_schema
def test_build_schema():
    import dataclasses
    import typing
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclasses.dataclass
    class TestClass:
        a: int
        b: str

# Generated at 2022-06-17 17:58:54.285092
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class A(typing.Generic[A]):
        def loads(self, json_data: JsonData,
                  many: bool = None, partial: bool = None, unknown: str = None,
                  **kwargs) -> TOneOrMulti:
            pass
    A().loads(b'{"a":1}')
    A().loads([b'{"a":1}'])


# Generated at 2022-06-17 17:58:59.215242
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field._serialize(datetime(2020, 1, 1), "attr", "obj") == "2020-01-01T00:00:00"
    assert field._deserialize("2020-01-01T00:00:00", "attr", "data") == datetime(2020, 1, 1)


# Generated at 2022-06-17 17:59:07.210075
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.List[str]
        e: typing.List[typing.List[int]]
        f: typing.List[typing.List[str]]
        g: typing.List[typing.List[typing.List[int]]]
        h: typing.List[typing.List[typing.List[str]]]
        i: typing.List[typing.List[typing.List[typing.List[int]]]]
        j: typing.List[typing.List[typing.List[typing.List[str]]]]
        k

# Generated at 2022-06-17 17:59:16.386673
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from dataclasses_json.mm import Schema
    from dataclasses_json.utils import _is_new_type
    from dataclasses_json.core import _is_supported_generic, _is_collection
    from typing import List, Optional, Union, Tuple, Dict, Any

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: List[int]
        d: Optional[int]
        e: Union[int, str]
        f: Tuple[int, str]
        g: Dict[str, int]
        h: Any
        i: Test


# Generated at 2022-06-17 17:59:47.976554
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import Schema, fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.Optional[int]
        d: typing.Optional[str]
        e: typing.Optional[typing.List[int]]
        f: typing.Optional[typing.List[str]]
        g: typing.Optional[typing.List[typing.List[int]]]
        h: typing.Optional[typing.List[typing.List[str]]]
        i: typing.Optional[typing.List[typing.List[typing.List[int]]]]

# Generated at 2022-06-17 17:59:50.210185
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 18:00:01.794217
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    import marshmallow
    import marshmallow_enum
    import typing
    import datetime
    import uuid
    import decimal
    import enum

    @dataclass_json
    @dataclass
    class Test:
        a: typing.List[int]
        b: typing.Dict[str, int]
        c: typing.Callable
        d: typing.Any
        e: typing.Union[int, str]
        f: typing.Optional[int]
        g: typing.Optional[typing.Union[int, str]]
        h: typing.Optional[typing.Union[int, str, None]]
        i: typing.Optional[typing.Union[int, str, None, typing.List[int]]]


# Generated at 2022-06-17 18:00:06.532920
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Test:
        a: int
        b: str

    class TestSchema(SchemaF[Test]):
        a = fields.Int()
        b = fields.Str()

    assert TestSchema().dumps(Test(1, 'a')) == '{"a": 1, "b": "a"}'



# Generated at 2022-06-17 18:00:17.013535
# Unit test for function build_type
def test_build_type():
    from typing import Optional, Union
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from dataclasses_json.core import _UnionField
    from dataclasses_json.utils import _is_optional, _is_new_type
    from dataclasses import dataclass
    from enum import Enum
    from dataclasses_json import dataclass_json
    from dataclasses_json.mm_field import build_type

    class MyEnum(Enum):
        A = 1
        B = 2

    @dataclass_json
    @dataclass
    class MyClass:
        a: int
        b: str
        c: MyEnum
        d: Optional[str]
        e: Union[str, int]


# Generated at 2022-06-17 18:00:21.208981
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses import dataclass
    from marshmallow import Schema, fields

    @dataclass
    class User:
        name: str
        age: int

    class UserSchema(SchemaF[User]):
        name = fields.Str()
        age = fields.Int()

    user = User('John', 42)
    schema = UserSchema()
    result = schema.dumps(user)
    assert result == '{"name": "John", "age": 42}'



# Generated at 2022-06-17 18:00:25.913820
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields
    from dataclasses import dataclass
    from typing import List

    @dataclass
    class User:
        name: str
        age: int

    class UserSchema(SchemaF[User]):
        name = fields.Str()
        age = fields.Int()

    user = User('John', 30)
    schema = UserSchema()
    assert schema.dumps(user) == '{"name": "John", "age": 30}'

    users = [User('John', 30), User('Jane', 25)]
    schema = UserSchema(many=True)
    assert schema.dumps(users) == '[{"name": "John", "age": 30}, {"name": "Jane", "age": 25}]'

    @dataclass
    class UserList:
        users: List

# Generated at 2022-06-17 18:00:32.684433
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class A:
        a: int
        b: str

    @dataclass
    class B:
        a: A
        b: str

    @dataclass
    class C:
        a: typing.List[A]
        b: str

    @dataclass
    class D:
        a: typing.List[A]
        b: typing.List[B]

    @dataclass
    class E:
        a: typing.List[A]
        b: typing.List[B]
        c: typing.List[C]

    @dataclass
    class F:
        a: typing.List[A]
        b: typing.List[B]
        c: typing.List[C]
        d: typing.List[D]


# Generated at 2022-06-17 18:00:42.271421
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Foo(typing.Generic[A]):
        def __init__(self, a: A):
            self.a = a

    class FooSchema(SchemaF[Foo[int]]):
        a = fields.Int()

    foo_schema = FooSchema()
    foo = foo_schema.loads('{"a": 1}')
    assert foo.a == 1

    foo_list = foo_schema.loads('[{"a": 1}, {"a": 2}]', many=True)
    assert foo_list[0].a == 1
    assert foo_list[1].a == 2



# Generated at 2022-06-17 18:00:54.330930
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int


# Generated at 2022-06-17 18:01:22.846249
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from typing import List, Optional

    @dataclass_json
    @dataclass
    class Test:
        a: Optional[List[int]]

    assert build_type(Test.__annotations__['a'], {}, None, None, None) == fields.List(fields.Int(), allow_none=True)



# Generated at 2022-06-17 18:01:34.903049
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from dataclasses_json.mixin import JsonMixin
    from marshmallow import Schema, fields

    @dataclass_json
    @dataclass
    class Test(JsonMixin):
        a: int
        b: str


# Generated at 2022-06-17 18:01:40.508053
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class A:
        x: int

    class ASchema(SchemaF[A]):
        x = fields.Int()

    a = A(x=1)
    assert ASchema().dumps(a) == '{"x": 1}'



# Generated at 2022-06-17 18:01:54.063062
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.Optional[str]
        d: typing.Optional[int]
        e: typing.Optional[typing.List[str]]
        f: typing.Optional[typing.List[int]]
        g: typing.Optional[typing.List[typing.Optional[str]]]
        h: typing.Optional[typing.List[typing.Optional[int]]]
        i: typing.Optional[typing.Dict[str, int]]
        j: typing.Optional[typing.Dict[str, str]]

# Generated at 2022-06-17 18:02:02.440786
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import Schema, fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.List[str]
        e: typing.List[int] = field(default_factory=list)
        f: typing.List[str] = field(default_factory=list)
        g: typing.List[int] = field(default_factory=lambda: [1, 2, 3])
        h: typing.List[str] = field(default_factory=lambda: ['a', 'b', 'c'])

    DataClassSchema = build_schema(Test, None, False, False)

# Generated at 2022-06-17 18:02:13.066054
# Unit test for function build_type
def test_build_type():
    assert build_type(int, {}, None, None, None) == fields.Int
    assert build_type(typing.Optional[int], {}, None, None, None) == fields.Int(allow_none=True)
    assert build_type(typing.List[int], {}, None, None, None) == fields.List(fields.Int)
    assert build_type(typing.Optional[typing.List[int]], {}, None, None, None) == fields.List(fields.Int, allow_none=True)
    assert build_type(typing.List[typing.Optional[int]], {}, None, None, None) == fields.List(fields.Int(allow_none=True))

# Generated at 2022-06-17 18:02:20.856580
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Foo(typing.Generic[A]):
        def __init__(self, a: A):
            self.a = a

    class FooSchema(SchemaF[Foo[int]]):
        a = fields.Int()

    foo_schema = FooSchema()
    foo = foo_schema.load({'a': 1})
    assert foo.a == 1
    foo = foo_schema.load([{'a': 1}, {'a': 2}])
    assert foo[0].a == 1
    assert foo[1].a == 2


# Generated at 2022-06-17 18:02:28.920629
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    import marshmallow
    import marshmallow.fields
    import typing
    import dataclasses_json
    import dataclasses_json.api
    import dataclasses_json.mm
    import dataclasses_json.mm.api
    import dataclasses_json.mm.utils
    import dataclasses_json.utils
    import datetime
    import uuid
    import decimal
    import enum
    import sys
    import warnings
    import marshmallow_enum
    import typing_inspect
    import marshmallow.exceptions
    import marshmallow.fields
    import marshmallow.validate
    import marshmallow.validators
    import marshmallow.utils
    import marshmallow.compat
    import marshmallow.class_registry
    import marshmallow.utils
    import marshmallow.exceptions


# Generated at 2022-06-17 18:02:38.955571
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields
    from typing import List

    class MySchema(Schema, typing.Generic[A]):
        pass

    assert MySchema[List[int]].dumps([1, 2, 3]) == '[1, 2, 3]'
    assert MySchema[int].dumps(1) == '1'
    assert MySchema[List[int]].dumps([1, 2, 3], many=True) == '[1, 2, 3]'
    assert MySchema[int].dumps(1, many=False) == '1'
    assert MySchema[int].dumps(1, many=True) == '1'
    assert MySchema[int].dumps(1, many=None) == '1'

# Generated at 2022-06-17 18:02:47.627948
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._deserialize('2020-01-01T00:00:00') == datetime(2020, 1, 1, 0, 0, 0)
    assert _IsoField()._deserialize('2020-01-01T00:00:00+00:00') == datetime(2020, 1, 1, 0, 0, 0)
    assert _IsoField()._deserialize('2020-01-01T00:00:00+01:00') == datetime(2020, 1, 1, 0, 0, 0)
    assert _IsoField()._deserialize('2020-01-01T00:00:00-01:00') == datetime(2020, 1, 1, 0, 0, 0)

# Generated at 2022-06-17 18:03:54.728077
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str


# Generated at 2022-06-17 18:03:56.329477
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._serialize(datetime.now(), None, None) is not None
    assert _IsoField()._deserialize(datetime.now().isoformat(), None, None) is not None


# Generated at 2022-06-17 18:04:06.057844
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.Optional[str]
        d: typing.Optional[int] = None
        e: typing.Optional[typing.List[int]] = None
        f: typing.Optional[typing.List[str]] = None
        g: typing.Optional[typing.List[typing.Optional[str]]] = None
        h: typing.Optional[typing.List[typing.Optional[int]]] = None


# Generated at 2022-06-17 18:04:11.851735
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError
    from dataclasses import dataclass

    @dataclass
    class Person:
        name: str
        age: int

    class PersonSchema(SchemaF[Person]):
        name = fields.Str()
        age = fields.Int()

    person = Person('John', 30)
    schema = PersonSchema()
    result = schema.dump(person)
    assert result == {'name': 'John', 'age': 30}

    result = schema.dump([person])
    assert result == [{'name': 'John', 'age': 30}]

    result = schema.dumps(person)
    assert result == '{"name": "John", "age": 30}'

    result = schema.dumps([person])

# Generated at 2022-06-17 18:04:21.838705
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from dataclasses_json.config import Config
    from typing import Optional

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: Optional[int] = None
        c: Optional[int] = None
        d: Optional[int] = None
        e: Optional[int] = None
        f: Optional[int] = None
        g: Optional[int] = None
        h: Optional[int] = None
        i: Optional[int] = None
        j: Optional[int] = None
        k: Optional[int] = None
        l: Optional[int] = None
        m: Optional[int] = None
        n: Optional[int] = None

# Generated at 2022-06-17 18:04:27.961353
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from typing import List
    from marshmallow import Schema, fields
    class MySchema(Schema):
        name = fields.Str()
    class MySchemaF(SchemaF[MySchema]):
        pass
    assert isinstance(MySchemaF.loads(b'{"name": "foo"}'), MySchema)
    assert isinstance(MySchemaF.loads(b'[{"name": "foo"}]', many=True), List[MySchema])

# Generated at 2022-06-17 18:04:36.457196
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Person:
        name: str
        age: int

    class PersonSchema(SchemaF[Person]):
        name = fields.Str()
        age = fields.Int()

    schema = PersonSchema()
    result = schema.loads('{"name": "foo", "age": 42}')
    assert result.name == "foo"
    assert result.age == 42
    result = schema.loads('[{"name": "foo", "age": 42}]')
    assert result[0].name == "foo"
    assert result[0].age == 42
    result = schema.loads(b'{"name": "foo", "age": 42}')
    assert result.name == "foo"

# Generated at 2022-06-17 18:04:43.085405
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str = 'test'
        c: typing.List[int] = None

    assert schema(Test, None, False) == {
        'a': fields.Int(),
        'b': fields.Str(default='test'),
        'c': fields.List(fields.Int(), default=None, allow_none=True)
    }



# Generated at 2022-06-17 18:04:54.002303
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from typing import Optional
    from marshmallow import fields

    @dataclass
    class A:
        a: int
        b: Optional[int]
        c: str

    DataClassSchema = build_schema(A, None, False, False)
    assert DataClassSchema.Meta.fields == ('a', 'b', 'c')
    assert isinstance(DataClassSchema.a, fields.Int)
    assert isinstance(DataClassSchema.b, fields.Int)
    assert isinstance(DataClassSchema.c, fields.Str)



# Generated at 2022-06-17 18:04:56.642578
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field._serialize(datetime(2020, 1, 1), None, None) == '2020-01-01T00:00:00'
    assert field._deserialize('2020-01-01T00:00:00', None, None) == datetime(2020, 1, 1)
