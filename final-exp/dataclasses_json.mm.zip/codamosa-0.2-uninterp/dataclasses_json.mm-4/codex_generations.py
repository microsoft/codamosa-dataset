

# Generated at 2022-06-17 17:56:14.908473
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo = Foo(a=1, b='b')
    assert FooSchema().dumps(foo) == '{"a": 1, "b": "b"}'
    assert FooSchema().dumps([foo]) == '[{"a": 1, "b": "b"}]'



# Generated at 2022-06-17 17:56:24.809036
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: A

    class ASchema(SchemaF[A]):
        a = fields.Int()

    class BSchema(SchemaF[B]):
        b = fields.Nested(ASchema)

    b = B(A(1))
    assert BSchema().dumps(b) == '{"b": {"a": 1}}'
    assert BSchema().dumps([b]) == '[{"b": {"a": 1}}]'
    assert BSchema().dumps(b, many=False) == '{"b": {"a": 1}}'
    assert BSchema().dumps([b], many=False)

# Generated at 2022-06-17 17:56:30.790071
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from marshmallow.exceptions import ValidationError
    from dataclasses_json.utils import _is_optional, _is_new_type, _get_type_origin
    from dataclasses_json.core import _is_supported_generic, _is_collection
    from typing import Optional, Union, List, Dict, Tuple, Callable, Any, Mapping, MutableMapping
    from datetime import datetime
    from decimal import Decimal
    from uuid import UUID
    from enum import Enum
    from typing_inspect import is_union_type
    from dataclasses_json.utils import CatchAllVar


# Generated at 2022-06-17 17:56:42.221713
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin, config
    from marshmallow import fields

    @dataclass
    class A(DataClassJsonMixin):
        a: int
        b: str

    @dataclass
    class B(DataClassJsonMixin):
        a: A
        b: str

    @dataclass
    class C(DataClassJsonMixin):
        a: typing.List[A]
        b: str

    @dataclass
    class D(DataClassJsonMixin):
        a: typing.List[typing.List[A]]
        b: str

    @dataclass
    class E(DataClassJsonMixin):
        a: typing.List[typing.List[typing.List[A]]]

# Generated at 2022-06-17 17:56:44.847593
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 17:56:57.050438
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import List
    from marshmallow import Schema, fields
    class Foo(Schema):
        bar = fields.Str()
    class FooSchema(SchemaF[Foo]):
        bar = fields.Str()
    assert FooSchema().dump(Foo(bar='baz')) == {'bar': 'baz'}
    assert FooSchema().dump([Foo(bar='baz')]) == [{'bar': 'baz'}]
    assert FooSchema().dump([Foo(bar='baz'), Foo(bar='baz')]) == [{'bar': 'baz'}, {'bar': 'baz'}]
    assert FooSchema().dump(Foo(bar='baz'), many=True) == [{'bar': 'baz'}]
    assert FooSchema().dump

# Generated at 2022-06-17 17:57:03.593812
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str


# Generated at 2022-06-17 17:57:13.805890
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[int]
        f: typing.Optional[typing.List[int]]
        g: typing.Optional[typing.Dict[str, int]]
        h: typing.Optional[typing.Union[int, str]]
        i: typing.Optional[typing.Union[int, typing.List[int]]]
        j: typing.Optional[typing.Union[int, typing.Dict[str, int]]]

# Generated at 2022-06-17 17:57:18.156581
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class A:
        a: str
        b: int
        c: Optional[str]
        d: Optional[int]
        e: Optional[str] = None
        f: Optional[int] = None
        g: Optional[str] = None
        h: Optional[int] = None
        i: Optional[str] = None
        j: Optional[int] = None
        k: Optional[str] = None
        l: Optional[int] = None
        m: Optional[str] = None
        n: Optional[int] = None
        o: Optional[str] = None
        p: Optional[int] = None
        q: Optional[str] = None
        r: Optional[int] = None
        s: Optional[str] = None
        t: Optional

# Generated at 2022-06-17 17:57:29.228147
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    assert FooSchema().loads('{"a": 1, "b": "foo"}') == Foo(a=1, b='foo')
    assert FooSchema().loads('[{"a": 1, "b": "foo"}]') == [Foo(a=1, b='foo')]
    assert FooSchema().loads('[{"a": 1, "b": "foo"}, {"a": 2, "b": "bar"}]') == [Foo(a=1, b='foo'), Foo(a=2, b='bar')]


# Generated at 2022-06-17 17:57:55.695088
# Unit test for function build_type
def test_build_type():
    assert build_type(int, {}, None, None, None) == fields.Int
    assert build_type(str, {}, None, None, None) == fields.Str
    assert build_type(float, {}, None, None, None) == fields.Float
    assert build_type(bool, {}, None, None, None) == fields.Bool
    assert build_type(datetime, {}, None, None, None) == _TimestampField
    assert build_type(UUID, {}, None, None, None) == fields.UUID
    assert build_type(Decimal, {}, None, None, None) == fields.Decimal
    assert build_type(CatchAllVar, {}, None, None, None) == fields.Dict

# Generated at 2022-06-17 17:58:05.913604
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class Test:
        pass

    @dataclass_json
    @dataclass
    class Test2:
        pass

    @dataclass_json
    @dataclass
    class Test3:
        pass

    @dataclass_json
    @dataclass
    class Test4:
        pass

    @dataclass_json
    @dataclass
    class Test5:
        pass

    @dataclass_json
    @dataclass
    class Test6:
        pass

    @dataclass_json
    @dataclass
    class Test7:
        pass


# Generated at 2022-06-17 17:58:15.892670
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Foo:
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo = Foo(1, 'b')
    foo_schema = FooSchema()
    foo_encoded = foo_schema.dump(foo)
    foo_decoded = foo_schema.load(foo_encoded)
    assert foo_decoded == foo

    foos = [foo, foo]
    foos_encoded = foo_schema.dump(foos, many=True)
    foos_decoded = foo_schema.load(foos_encoded, many=True)
    assert foos

# Generated at 2022-06-17 17:58:21.414481
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class Test:
        a: str
        b: int
        c: typing.Optional[str]
        d: typing.Optional[int] = None
        e: typing.Optional[typing.List[str]] = None
        f: typing.Optional[typing.List[int]] = None
        g: typing.Optional[typing.List[typing.Optional[str]]] = None
        h: typing.Optional[typing.List[typing.Optional[int]]] = None
        i: typing.Optional[typing.List[typing.Optional[typing.List[str]]]] = None
        j: typing.Optional[typing.List[typing.Optional[typing.List[int]]]] = None

# Generated at 2022-06-17 17:58:31.756952
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from typing import Optional, Union

    @dataclass_json
    @dataclass
    class Test:
        a: Optional[int]
        b: Union[int, str]
        c: Union[int, str]
        d: Union[int, str]
        e: Union[int, str]
        f: Union[int, str]
        g: Union[int, str]

    assert isinstance(build_type(Test.__annotations__['a'], {}, None, None, Test), fields.Int)
    assert isinstance(build_type(Test.__annotations__['b'], {}, None, None, Test), _UnionField)

# Generated at 2022-06-17 17:58:42.479258
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin
    from marshmallow import Schema, fields

    @dataclass
    class A(DataClassJsonMixin):
        a: int
        b: str

    @dataclass
    class B(DataClassJsonMixin):
        a: A
        b: str

    @dataclass
    class C(DataClassJsonMixin):
        a: typing.List[A]
        b: str

    @dataclass
    class D(DataClassJsonMixin):
        a: typing.Optional[A]
        b: str

    @dataclass
    class E(DataClassJsonMixin):
        a: typing.Optional[typing.List[A]]
        b: str


# Generated at 2022-06-17 17:58:55.692868
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from typing import Optional, Union, List, Dict, Tuple, Callable, Any, Mapping, MutableMapping

    @dataclass_json
    @dataclass
    class A:
        a: int

    @dataclass_json
    @dataclass
    class B:
        b: str

    @dataclass_json
    @dataclass
    class C:
        c: A

    @dataclass_json
    @dataclass
    class D:
        d: B

    @dataclass_json
    @dataclass
    class E:
        e: Optional[int]


# Generated at 2022-06-17 17:59:03.408949
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    @dataclass
    class A:
        a: int
        b: str
    a = build_schema(A, None, False, False)
    assert a.__name__ == 'ASchema'
    assert a.Meta.fields == ('a', 'b')
    assert a.make_a.__name__ == 'make_a'
    assert a.dumps.__name__ == 'dumps'
    assert a.dump.__name__ == 'dump'
    assert a.a.__name__ == 'a'
    assert a.b.__name__ == 'b'


# Generated at 2022-06-17 17:59:09.588569
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Foo:
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo_schema = FooSchema()
    foo = Foo(1, 'a')
    assert foo_schema.dump(foo) == {'a': 1, 'b': 'a'}
    assert foo_schema.dump([foo]) == [{'a': 1, 'b': 'a'}]
    assert foo_schema.dump(foo, many=False) == {'a': 1, 'b': 'a'}

# Generated at 2022-06-17 17:59:17.356035
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    schema = FooSchema()
    assert schema.loads('{"a": 1, "b": "foo"}') == Foo(a=1, b='foo')
    assert schema.loads('[{"a": 1, "b": "foo"}]') == [Foo(a=1, b='foo')]
    assert schema.loads('[{"a": 1, "b": "foo"}, {"a": 2, "b": "bar"}]') == [Foo(a=1, b='foo'), Foo(a=2, b='bar')]

# Generated at 2022-06-17 17:59:56.358596
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    assert SchemaF.loads(None, None, None, None, None) is None
    assert SchemaF.loads(None, None, None, None, None, None) is None
    assert SchemaF.loads(None, None, None, None, None, None, None) is None
    assert SchemaF.loads(None, None, None, None, None, None, None, None) is None
    assert SchemaF.loads(None, None, None, None, None, None, None, None, None) is None
    assert SchemaF.loads(None, None, None, None, None, None, None, None, None, None) is None
    assert SchemaF.loads(None, None, None, None, None, None, None, None, None, None, None) is None

# Generated at 2022-06-17 18:00:03.309750
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Foo(typing.Generic[A]):
        def __init__(self, a: A) -> None:
            self.a = a

    class FooSchema(SchemaF[A]):
        a = fields.Field()

    assert FooSchema().dump(Foo(1)) == {'a': 1}
    assert FooSchema().dump([Foo(1), Foo(2)]) == [{'a': 1}, {'a': 2}]



# Generated at 2022-06-17 18:00:14.820992
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields as mm_fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[int]
        f: typing.Optional[typing.List[int]]
        g: typing.Optional[typing.Dict[str, int]]
        h: typing.Optional[typing.Union[str, int]]
        i: typing.Optional[typing.Union[str, int, None]]
        j: typing.Optional[typing.Union[str, int, typing.List[int]]]

# Generated at 2022-06-17 18:00:27.281759
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[str]
        f: typing.Optional[typing.List[int]]
        g: typing.Optional[typing.Dict[str, int]]


# Generated at 2022-06-17 18:00:39.392949
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class S(SchemaF[int]):
        pass
    assert S().dumps([1, 2, 3]) == '[1, 2, 3]'
    assert S().dumps(1) == '1'
    assert S().dumps([1, 2, 3], many=True) == '[1, 2, 3]'
    assert S().dumps(1, many=False) == '1'
    assert S().dumps([1, 2, 3], many=False) == '[1, 2, 3]'
    assert S().dumps(1, many=True) == '1'
    assert S().dumps([1, 2, 3], many=None) == '[1, 2, 3]'
    assert S().dumps(1, many=None) == '1'

# Generated at 2022-06-17 18:00:53.560515
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Foo(typing.NamedTuple):
        x: int
        y: str

    class FooSchema(SchemaF[Foo]):
        x = fields.Int()
        y = fields.Str()

    assert FooSchema().loads('{"x": 1, "y": "a"}') == Foo(x=1, y='a')
    assert FooSchema().loads('[{"x": 1, "y": "a"}]') == [Foo(x=1, y='a')]
    assert FooSchema().loads(b'{"x": 1, "y": "a"}') == Foo(x=1, y='a')
    assert FooSchema().loads(b'[{"x": 1, "y": "a"}]') == [Foo(x=1, y='a')]
    assert Foo

# Generated at 2022-06-17 18:01:03.540731
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class A:
        a: int

    @dataclass_json
    @dataclass
    class B:
        b: A

    @dataclass_json
    @dataclass
    class C:
        c: typing.List[A]

    @dataclass_json
    @dataclass
    class D:
        d: typing.List[int]

    @dataclass_json
    @dataclass
    class E:
        e: typing.Union[int, str]

    @dataclass_json
    @dataclass
    class F:
        f: typing.Optional[int]


# Generated at 2022-06-17 18:01:14.147555
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses import dataclass
    from marshmallow import Schema, fields

    @dataclass
    class Person:
        name: str
        age: int

    class PersonSchema(SchemaF[Person]):
        name = fields.Str()
        age = fields.Int()

    schema = PersonSchema()
    person = schema.load({'name': 'foo', 'age': 42})
    assert person.name == 'foo'
    assert person.age == 42
    assert isinstance(person, Person)

    people = schema.load([{'name': 'foo', 'age': 42}, {'name': 'bar', 'age': 43}], many=True)
    assert people[0].name == 'foo'
    assert people[0].age == 42
    assert isinstance(people[0], Person)

# Generated at 2022-06-17 18:01:20.195136
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: float
        d: typing.List[int]
        e: typing.List[str]
        f: typing.List[float]
        g: typing.List[typing.List[int]]
        h: typing.List[typing.List[str]]
        i: typing.List[typing.List[float]]
        j: typing.List[typing.List[typing.List[int]]]
        k: typing.List[typing.List[typing.List[str]]]

# Generated at 2022-06-17 18:01:21.940876
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field.__class__.__name__ == "_IsoField"


# Generated at 2022-06-17 18:02:16.903020
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.Optional[int]
        d: typing.Optional[str]
        e: typing.Optional[typing.List[int]]
        f: typing.Optional[typing.List[str]]
        g: typing.Optional[typing.List[typing.Optional[int]]]
        h: typing.Optional[typing.List[typing.Optional[str]]]
        i: typing.Optional[typing.List[typing.Optional[typing.List[int]]]]
        j: typing.Optional[typing.List[typing.Optional[typing.List[str]]]]

# Generated at 2022-06-17 18:02:26.380657
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str

# Generated at 2022-06-17 18:02:31.252801
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field._serialize(datetime.now(), None, None) is not None
    assert field._deserialize(datetime.now().isoformat(), None, None) is not None


# Generated at 2022-06-17 18:02:40.096057
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str

# Generated at 2022-06-17 18:02:46.380265
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from typing import Optional
    @dataclass
    class Test:
        a: Optional[int]
        b: str
        c: Optional[str]
    assert build_schema(Test, None, False, False)


# Generated at 2022-06-17 18:02:54.824762
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields

    class Foo(Schema):
        a = fields.Int()

    class Bar(Schema):
        b = fields.Int()

    class FooBar(SchemaF[typing.Union[Foo, Bar]]):
        pass

    assert FooBar().dump(Foo()) == {'a': None}
    assert FooBar().dump(Bar()) == {'b': None}
    assert FooBar().dump([Foo(), Bar()]) == [{'a': None}, {'b': None}]



# Generated at 2022-06-17 18:03:06.487769
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class A:
        a: str

    @dataclass_json
    @dataclass
    class B:
        b: A

    @dataclass_json
    @dataclass
    class C:
        c: typing.Optional[A]

    @dataclass_json
    @dataclass
    class D:
        d: typing.List[A]

    @dataclass_json
    @dataclass
    class E:
        e: typing.Union[A, B]


# Generated at 2022-06-17 18:03:13.047878
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class A:
        x: int

    class ASchema(SchemaF[A]):
        x = fields.Int()

    assert ASchema().dump(A(1)) == {'x': 1}
    assert ASchema().dump([A(1), A(2)]) == [{'x': 1}, {'x': 2}]



# Generated at 2022-06-17 18:03:23.448847
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    from typing import List, Dict, Any, Union

    class MySchema(SchemaF[Dict[str, Any]]):
        pass

    class MySchema2(SchemaF[Union[List[Dict[str, Any]], Dict[str, Any]]]):
        pass

    class MySchema3(SchemaF[Union[List[Dict[str, Any]], Dict[str, Any]]]):
        pass

    class MySchema4(SchemaF[Union[List[Dict[str, Any]], Dict[str, Any]]]):
        pass

    class MySchema5(SchemaF[Union[List[Dict[str, Any]], Dict[str, Any]]]):
        pass


# Generated at 2022-06-17 18:03:30.070472
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from typing import Optional
    @dataclass_json
    @dataclass
    class A:
        a: int