

# Generated at 2022-06-17 17:56:22.269701
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    schema = FooSchema()
    assert schema.dumps([Foo(1, 'a'), Foo(2, 'b')]) == '[{"a": 1, "b": "a"}, {"a": 2, "b": "b"}]'
    assert schema.dumps(Foo(1, 'a')) == '{"a": 1, "b": "a"}'



# Generated at 2022-06-17 17:56:31.166825
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Foo:
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo = Foo(1, 'bar')
    schema = FooSchema()
    assert schema.dumps(foo) == '{"a": 1, "b": "bar"}'
    assert schema.dumps([foo]) == '[{"a": 1, "b": "bar"}]'
    assert schema.dumps(foo, many=True) == '[{"a": 1, "b": "bar"}]'
    assert schema.dumps([foo], many=False) == '{"a": 1, "b": "bar"}'

# Generated at 2022-06-17 17:56:38.783081
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class TestSchema(SchemaF[A]):
        pass

    TestSchema().load([{'a': 1}], many=True)
    TestSchema().load({'a': 1}, many=False)
    TestSchema().load({'a': 1})
    TestSchema().load([{'a': 1}])
    TestSchema().load({'a': 1}, many=True)
    TestSchema().load([{'a': 1}], many=False)



# Generated at 2022-06-17 17:56:53.589789
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass, field
    from typing import Optional
    from marshmallow import fields as mm_fields
    from marshmallow import Schema as mm_Schema
    from marshmallow import post_load
    from marshmallow import validate
    from marshmallow import ValidationError
    from marshmallow import validates
    from marshmallow import validates_schema
    from marshmallow import validate_schema
    from marshmallow import validates_with
    from marshmallow import validate_with
    from marshmallow import pre_load
    from marshmallow import pre_dump
    from marshmallow import post_dump
    from marshmallow import pre_dump_schema
    from marshmallow import post_dump_schema
    from marshmallow import pre_load_schema
    from marshmallow import post_load_schema
    from marshmallow import pre_dump_

# Generated at 2022-06-17 17:56:55.212026
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 17:57:00.518708
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Foo:
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    assert FooSchema().dumps(Foo(a=1, b='hello')) == '{"a": 1, "b": "hello"}'
    assert FooSchema().dumps([Foo(a=1, b='hello'), Foo(a=2, b='world')], many=True) == '[{"a": 1, "b": "hello"}, {"a": 2, "b": "world"}]'

# Generated at 2022-06-17 17:57:03.594126
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._deserialize("2019-01-01T00:00:00") == datetime(2019, 1, 1, 0, 0, 0)
    assert _IsoField()._serialize(datetime(2019, 1, 1, 0, 0, 0)) == "2019-01-01T00:00:00"


# Generated at 2022-06-17 17:57:13.514528
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    from dataclasses import dataclass
    from typing import List

    @dataclass
    class Person:
        name: str
        age: int

    class PersonSchema(SchemaF[Person]):
        name = fields.Str()
        age = fields.Int()

    schema = PersonSchema()
    person = schema.load({'name': 'Monty', 'age': '42'})
    assert person.name == 'Monty'
    assert person.age == 42

    people = schema.load([{'name': 'Monty', 'age': '42'}, {'name': 'Guido', 'age': '56'}], many=True)
    assert people[0].name == 'Monty'
    assert people[0].age == 42
    assert people[1].name

# Generated at 2022-06-17 17:57:20.983616
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[int]
        f: typing.Optional[str]
        g: typing.Optional[typing.List[int]]
        h: typing.Optional[typing.Dict[str, int]]
        i: typing.Optional[typing.List[typing.Optional[int]]]
        j: typing.Optional[typing.Dict[str, typing.Optional[int]]]
        k: typing.Optional[typing.Union[int, str]]
        l

# Generated at 2022-06-17 17:57:31.551848
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError

    class MySchema(Schema):
        name = fields.Str()

    schema = MySchema()
    schema.loads('{"name": "foo"}')
    schema.loads('{"name": "foo"}', many=False)
    schema.loads('[{"name": "foo"}]', many=True)
    schema.loads('[{"name": "foo"}]', many=False)
    schema.loads(b'{"name": "foo"}')
    schema.loads(b'{"name": "foo"}', many=False)
    schema.loads(b'[{"name": "foo"}]', many=True)
    schema.loads(b'[{"name": "foo"}]', many=False)

# Generated at 2022-06-17 17:57:55.860064
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Foo:
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    schema = FooSchema()
    foo = schema.load({'a': 1, 'b': 'b'})
    assert foo.a == 1
    assert foo.b == 'b'

    foos = schema.load([{'a': 1, 'b': 'b'}, {'a': 2, 'b': 'c'}])
    assert foos[0].a == 1
    assert foos[0].b == 'b'
    assert foos[1].a == 2

# Generated at 2022-06-17 17:58:05.984549
# Unit test for function build_type
def test_build_type():
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from dataclasses_json.mm_field import _UnionField
    from dataclasses_json.utils import _is_optional
    from dataclasses_json.core import _is_new_type
    from typing import Optional, Union
    from enum import Enum
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from dataclasses_json.core import _is_supported_generic
    from dataclasses_json.utils import _is_collection
    from dataclasses_json.core import _is_dataclass_instance
    from dataclasses_json.core import _is_dataclass_instance_with_json_mixin
    from dataclasses_json.core import _is_dataclass_

# Generated at 2022-06-17 17:58:15.934628
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses import dataclass
    from marshmallow import Schema, fields

    @dataclass
    class Foo:
        bar: int

    class FooSchema(SchemaF[Foo]):
        bar = fields.Int()

    foo = Foo(1)
    foo_schema = FooSchema()
    foo_encoded = foo_schema.dump(foo)
    foo_decoded = foo_schema.load(foo_encoded)
    assert foo == foo_decoded

    foo_list = [foo, foo]
    foo_list_encoded = foo_schema.dump(foo_list, many=True)
    foo_list_decoded = foo_schema.load(foo_list_encoded, many=True)
    assert foo_list == foo_list_decoded


#

# Generated at 2022-06-17 17:58:20.583716
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields

    class Foo(Schema):
        bar = fields.Str()

    def test_dump(schema: SchemaF[Foo]):
        schema.dump([Foo(bar='baz')])

    test_dump(SchemaF[Foo])



# Generated at 2022-06-17 17:58:29.040949
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses import dataclass
    from marshmallow import Schema, fields

    @dataclass
    class User:
        name: str
        age: int

    class UserSchema(SchemaF[User]):
        name = fields.Str()
        age = fields.Int()

    user = User('John', 42)
    schema = UserSchema()
    result = schema.dumps(user)
    assert result == '{"name": "John", "age": 42}'



# Generated at 2022-06-17 17:58:34.079748
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field._serialize(datetime.now(), "attr", "obj") is not None
    assert field._deserialize("2020-01-01T00:00:00", "attr", "data") is not None


# Generated at 2022-06-17 17:58:37.348098
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 17:58:46.032255
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.Optional[str]
        d: typing.Optional[int] = None
        e: typing.Optional[typing.Union[str, int]] = None
        f: typing.Optional[typing.Union[str, int]] = None
        g: typing.Optional[typing.Union[str, int]] = None
        h: typing.Optional[typing.Union[str, int]] = None
        i: typing.Optional[typing.Union[str, int]] = None
        j: typing.Optional[typing.Union[str, int]] = None

# Generated at 2022-06-17 17:58:57.141419
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    import typing
    import datetime
    import uuid

    @dataclass_json
    @dataclass
    class Test:
        a: typing.List[int]
        b: typing.Dict[str, int]
        c: typing.Mapping[str, int]
        d: typing.MutableMapping[str, int]
        e: typing.Callable
        f: typing.Any
        g: dict
        h: list
        i: str
        j: int
        k: float
        l: bool
        m: datetime.datetime
        n: uuid.UUID

# Generated at 2022-06-17 17:59:00.749668
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class A:
        a: int
    assert build_schema(A, None, False, False)


# Generated at 2022-06-17 17:59:26.966099
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from typing import List, Optional, Union

    class MyEnum(Enum):
        A = 1
        B = 2

    @dataclass_json
    @dataclass
    class MyClass:
        a: int
        b: Optional[int]
        c: List[int]
        d: Union[int, str]
        e: MyEnum

    assert build_type(MyClass.a.type, {}, dataclass_json.DataClassJsonMixin, MyClass.a, MyClass) == fields.Int()

# Generated at 2022-06-17 17:59:33.477451
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Foo:
        pass
    class FooSchema(SchemaF[Foo]):
        pass
    assert isinstance(FooSchema().loads('{}'), Foo)
    assert isinstance(FooSchema().loads('[{}]'), typing.List[Foo])
    assert isinstance(FooSchema().loads(b'{}'), Foo)
    assert isinstance(FooSchema().loads(b'[{}]'), typing.List[Foo])
    assert isinstance(FooSchema().loads(bytearray('{}', 'utf-8')), Foo)
    assert isinstance(FooSchema().loads(bytearray('[{}]', 'utf-8')), typing.List[Foo])

# Generated at 2022-06-17 17:59:38.182520
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from typing import Optional
    @dataclass
    class Test:
        a: int
        b: Optional[str]
    assert build_schema(Test, None, False, False)


# Generated at 2022-06-17 17:59:48.373181
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from marshmallow_oneofschema import OneOfSchema
    from marshmallow_union import Union

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.Optional[int]
        d: typing.Optional[str]
        e: typing.Optional[typing.Union[int, str]]
        f: typing.Optional[typing.Union[int, str, None]]
        g: typing.Optional[typing.Union[int, str, None]] = None
        h: typing.Optional[typing.Union[int, str, None]] = None
        i: typing.Optional

# Generated at 2022-06-17 17:59:57.829675
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str

    @dataclass_json
    @dataclass
    class B:
        a: A
        b: str

    @dataclass_json
    @dataclass
    class C:
        a: typing.List[A]
        b: str

    @dataclass_json
    @dataclass
    class D:
        a: typing.List[A]
        b: typing.List[str]

    @dataclass_json
    @dataclass
    class E:
        a: typing.List[A]

# Generated at 2022-06-17 18:00:05.133912
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class A:
        a: int
        b: str
    schema = build_schema(A, None, False, False)
    assert schema.Meta.fields == ('a', 'b')
    assert isinstance(schema.a, fields.Int)
    assert isinstance(schema.b, fields.Str)
    assert schema.make_a(dict(a=1, b='2')) == A(1, '2')
    assert schema.dumps(A(1, '2')) == '{"a": 1, "b": "2"}'
    assert schema.dump(A(1, '2')) == dict(a=1, b='2')



# Generated at 2022-06-17 18:00:09.830976
# Unit test for constructor of class _IsoField
def test__IsoField():
    iso_field = _IsoField()
    assert iso_field._serialize(datetime.now(), None, None) is not None
    assert iso_field._deserialize(datetime.now().isoformat(), None, None) is not None


# Generated at 2022-06-17 18:00:14.221425
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
    assert build_schema(Test, None, False, False) == TestSchema


# Generated at 2022-06-17 18:00:20.206987
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    schema = FooSchema()
    assert schema.dumps([Foo(1, 'a'), Foo(2, 'b')]) == '[{"a": 1, "b": "a"}, {"a": 2, "b": "b"}]'
    assert schema.dumps(Foo(1, 'a')) == '{"a": 1, "b": "a"}'



# Generated at 2022-06-17 18:00:26.042859
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields

    class MySchema(SchemaF[int]):
        a = fields.Int()

    s = MySchema()
    assert s.load({'a': 1}) == 1
    assert s.load([{'a': 1}, {'a': 2}]) == [1, 2]



# Generated at 2022-06-17 18:01:17.625776
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
        c: typing.Optional[str]
        d: typing.Optional[int]
        e: typing.Optional[typing.List[int]]
        f: typing.List[int]
        g: typing.Optional[typing.List[typing.Optional[int]]]
        h: typing.Optional[typing.List[typing.Optional[int]]]
        i: typing.Optional[typing.List[typing.Optional[int]]]
        j: typing.Optional[typing.List[typing.Optional[int]]]

# Generated at 2022-06-17 18:01:20.646807
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field._serialize(datetime.now(), None, None) is not None
    assert field._deserialize(datetime.now().isoformat(), None, None) is not None


# Generated at 2022-06-17 18:01:31.008788
# Unit test for function build_type
def test_build_type():
    assert build_type(typing.List[int], {}, None, None, None) == fields.List(fields.Int())
    assert build_type(typing.List[typing.List[int]], {}, None, None, None) == fields.List(fields.List(fields.Int()))
    assert build_type(typing.List[typing.List[typing.List[int]]], {}, None, None, None) == fields.List(fields.List(fields.List(fields.Int())))
    assert build_type(typing.List[typing.List[typing.List[typing.List[int]]]], {}, None, None, None) == fields.List(fields.List(fields.List(fields.List(fields.Int()))))

# Generated at 2022-06-17 18:01:39.375483
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import Schema, fields
    from marshmallow_enum import EnumField
    from typing import Union, List, Optional, Dict, Any
    from dataclasses_json.utils import _is_optional
    from dataclasses_json.core import _is_supported_generic, _is_collection
    from dataclasses_json.mm import build_type
    from dataclasses_json.utils import _issubclass_safe
    from dataclasses_json.core import _is_new_type
    from dataclasses_json.core import _get_type_origin
    from dataclasses_json.core import _is_union_type
    from dataclasses_json.core import _is_dataclass

# Generated at 2022-06-17 18:01:53.679782
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json, config
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[int]
        f: typing.Optional[str]
        g: typing.Optional[typing.List[int]]
        h: typing.Optional[typing.Dict[str, int]]
        i: typing.Optional[typing.Optional[int]]
        j: typing.Optional[typing.Optional[str]]
        k: typing.Optional[typing.Optional[typing.List[int]]]

# Generated at 2022-06-17 18:01:57.181301
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field._serialize(datetime.now(), None, None) is not None
    assert field._deserialize(datetime.now().isoformat(), None, None) is not None


# Generated at 2022-06-17 18:02:09.380501
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_dataclass import class_schema
    from marshmallow_dataclass.schema import SchemaType
    from marshmallow_dataclass.schema import build_schema

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: float
        d: bool
        e: list
        f: dict
        g: set
        h: tuple
        i: typing.List[int]
        j: typing.Dict[str, int]
        k: typing.Set[int]
        l: typing.Tuple[int, str]
        m: typing.Callable
        n: typing.Any
       

# Generated at 2022-06-17 18:02:17.508740
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
        c: typing.List[int]
        d: typing.List[str]
        e: typing.Dict[str, int]
        f: typing.Dict[str, str]
        g: typing.Optional[int]
        h: typing.Optional[str]
        i: typing.Optional[typing.List[int]]
        j: typing.Optional[typing.List[str]]
        k: typing.Optional[typing.Dict[str, int]]
        l: typing.Optional[typing.Dict[str, str]]

# Generated at 2022-06-17 18:02:21.736996
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
    assert build_schema(Test, None, False, False)



# Generated at 2022-06-17 18:02:29.383000
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class A(typing.Generic[A]):
        def loads(self, json_data: JsonData,
                  many: bool = None, partial: bool = None, unknown: str = None,
                  **kwargs) -> TOneOrMulti:
            pass

# Generated at 2022-06-17 18:04:36.382762
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from typing import Optional
    from marshmallow import fields

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: Optional[A]

    @dataclass
    class C:
        c: Optional[B]

    @dataclass
    class D:
        d: Optional[C]

    @dataclass
    class E:
        e: Optional[D]

    @dataclass
    class F:
        f: Optional[E]

    @dataclass
    class G:
        g: Optional[F]

    @dataclass
    class H:
        h: Optional[G]

    @dataclass
    class I:
        i: Optional[H]


# Generated at 2022-06-17 18:04:44.574310
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._deserialize('2020-01-01T00:00:00') == datetime(2020, 1, 1)
    assert _IsoField()._deserialize('2020-01-01T00:00:00.000000') == datetime(2020, 1, 1)
    assert _IsoField()._deserialize('2020-01-01T00:00:00.000000+00:00') == datetime(2020, 1, 1)
    assert _IsoField()._deserialize('2020-01-01T00:00:00.000000-00:00') == datetime(2020, 1, 1)
    assert _IsoField()._deserialize('2020-01-01T00:00:00.000000+00:00:00') == datetime(2020, 1, 1)

# Generated at 2022-06-17 18:04:49.939542
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 18:04:51.617475
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()


# Generated at 2022-06-17 18:05:00.440550
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[str]
        d: typing.Dict[str, str]
        e: typing.Optional[str]
        f: typing.Optional[int]
        g: typing.Optional[typing.List[str]]
        h: typing.Optional[typing.Dict[str, str]]
        i: typing.Optional[typing.Union[str, int]]
        j: typing.Optional[typing.Union[str, int, typing.List[str]]]
        k: typing.Optional[typing.Union[str, int, typing.List[str], typing.Dict[str, str]]]

# Generated at 2022-06-17 18:05:05.590406
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo_schema = FooSchema()
    foo = Foo(a=1, b='b')
    assert foo_schema.dumps(foo) == '{"a": 1, "b": "b"}'
    assert foo_schema.dumps([foo]) == '[{"a": 1, "b": "b"}]'



# Generated at 2022-06-17 18:05:16.044677
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class A(typing.Generic[A]):
        def dump(self, obj: typing.List[A], many: bool = None) -> typing.List[
            TEncoded]:  # type: ignore
            # mm has the wrong return type annotation (dict) so we can ignore the mypy error
            pass

        def dump(self, obj: A, many: bool = None) -> TEncoded:
            pass

        def dump(self, obj: TOneOrMulti,
                 many: bool = None) -> TOneOrMultiEncoded:
            pass

    class B(SchemaF[A]):
        pass

    b = B()
    b.dump([A()])
    b.dump(A())
    b.dump(A())



# Generated at 2022-06-17 18:05:24.207758
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: str

    @dataclass
    class C:
        c: typing.List[A]

    @dataclass
    class D:
        d: typing.List[B]

    @dataclass
    class E:
        e: typing.List[C]

    @dataclass
    class F:
        f: typing.List[D]

    @dataclass
    class G:
        g: typing.List[E]

    @dataclass
    class H:
        h: typing.List[F]

    @dataclass
    class I:
        i: typing.List[G]


# Generated at 2022-06-17 18:05:32.523543
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from dataclasses import dataclass
    from marshmallow import fields
    from dataclasses_json.schema import SchemaF

    @dataclass
    class Foo:
        bar: str

    class FooSchema(SchemaF[Foo]):
        bar = fields.String()

    assert FooSchema().loads('{"bar": "baz"}') == Foo('baz')
    assert FooSchema().loads('[{"bar": "baz"}]') == [Foo('baz')]
    assert FooSchema().loads(b'{"bar": "baz"}') == Foo('baz')
    assert FooSchema().loads(b'[{"bar": "baz"}]') == [Foo('baz')]

# Generated at 2022-06-17 18:05:42.998227
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Foo:
        bar: int

    class FooSchema(SchemaF[Foo]):
        bar = fields.Int()

    foo = Foo(1)
    foo_schema = FooSchema()
    assert foo_schema.load(foo_schema.dump(foo)) == foo

    foos = [foo, foo]
    assert foo_schema.load(foo_schema.dump(foos), many=True) == foos

    assert foo_schema.load(foo_schema.dump(foo), many=False) == foo

    foos = [foo, foo]
    assert foo_schema.load(foo_schema.dump(foos), many=False) == foos


