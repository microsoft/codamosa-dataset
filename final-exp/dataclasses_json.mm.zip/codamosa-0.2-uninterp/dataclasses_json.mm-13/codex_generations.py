

# Generated at 2022-06-17 17:56:17.082305
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from typing import Optional
    @dataclass
    class Test:
        a: int
        b: Optional[str]
        c: Optional[int]
    schema = build_schema(Test, None, False, False)
    assert schema.Meta.fields == ('a', 'b', 'c')
    assert isinstance(schema.a, fields.Int)
    assert isinstance(schema.b, fields.Str)
    assert isinstance(schema.c, fields.Int)
    assert schema.make_test.__name__ == 'make_test'
    assert schema.dumps.__name__ == 'dumps'
    assert schema.dump.__name__ == 'dump'
    assert schema.__name__ == 'TestSchema'

# Generated at 2022-06-17 17:56:25.010168
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses import dataclass
    from marshmallow import Schema, fields

    @dataclass
    class Foo:
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    schema = FooSchema()
    foo = schema.load({'a': 1, 'b': 'b'})
    assert foo.a == 1
    assert foo.b == 'b'


if sys.version_info >= (3, 7):
    class SchemaF(Schema, typing.Generic[A]):
        """Lift Schema into a type constructor"""


# Generated at 2022-06-17 17:56:33.520335
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    from dataclasses import dataclass
    from typing import List

    @dataclass
    class Foo:
        bar: int

    class FooSchema(SchemaF[Foo]):
        bar = fields.Int()

    schema = FooSchema()
    foo = schema.load({'bar': 42})
    assert foo.bar == 42
    foos = schema.load([{'bar': 42}, {'bar': 43}])
    assert foos[0].bar == 42
    assert foos[1].bar == 43
    foos = schema.load([{'bar': 42}, {'bar': 43}], many=True)
    assert foos[0].bar == 42
    assert foos[1].bar == 43

# Generated at 2022-06-17 17:56:44.466194
# Unit test for function build_type
def test_build_type():
    from typing import List, Optional, Union
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from dataclasses_json.mm import Schema
    from dataclasses_json.core import _is_new_type, _is_optional, _is_collection
    from dataclasses_json.utils import _issubclass_safe
    from dataclasses import dataclass
    from enum import Enum as Enum_
    from datetime import datetime
    from decimal import Decimal
    from uuid import UUID
    from dataclasses_json.utils import CatchAllVar

    class TestEnum(Enum_):
        A = 1
        B = 2

    @dataclass
    class TestSchema(Schema):
        pass


# Generated at 2022-06-17 17:56:57.009050
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from typing import Optional, List, Union, Dict, Any
    from dataclasses_json.mm_field import build_type
    from dataclasses_json.utils import _is_optional, _is_collection, _issubclass_safe

    class TestEnum(Enum):
        A = 1
        B = 2

    @dataclass_json
    @dataclass
    class TestClass:
        a: int
        b: Optional[int]
        c: List[int]
        d: Union[int, str]
        e: Dict[str, int]
        f: TestEnum
        g: Any
        h: TestClass

# Generated at 2022-06-17 17:57:05.614288
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[int]
        f: typing.Optional[str]
        g: typing.Optional[typing.List[int]]
        h: typing.Optional[typing.Dict[str, int]]
        i: typing.Optional[typing.Union[int, str]]
        j: typing.Optional[typing.Union[int, str, typing.List[int]]]

# Generated at 2022-06-17 17:57:08.373220
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 17:57:11.880028
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 17:57:20.073941
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from marshmallow.exceptions import ValidationError
    from dataclasses_json.mm_schema import build_type, TYPES
    from dataclasses_json.core import _is_new_type, _get_type_origin
    from dataclasses_json.utils import _is_optional, _is_collection
    from typing import Optional, List, Dict, Union, Any, Tuple, Callable, Mapping, MutableMapping
    from datetime import datetime
    from uuid import UUID
    from decimal import Decimal
    from enum import Enum
    from dataclasses_json.utils import CatchAllVar


# Generated at 2022-06-17 17:57:26.755667
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError
    from marshmallow.validate import OneOf

    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[int]
        f: typing.Optional[int] = None
        g: typing.Optional[int] = None
        h: typing.Optional[int] = None
        i: typing.Optional[int] = None
        j: typing.Optional[int] = None
        k: typing.Optional[int] = None

# Generated at 2022-06-17 17:57:53.900900
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from typing import Optional
    @dataclass
    class Test:
        a: int
        b: Optional[int]
        c: Optional[str]
        d: Optional[float]
        e: Optional[bool]
        f: Optional[dict]
        g: Optional[list]
        h: Optional[tuple]
        i: Optional[set]
        j: Optional[frozenset]
        k: Optional[bytes]
        l: Optional[bytearray]
        m: Optional[Enum]
        n: Optional[UUID]
        o: Optional[Decimal]
        p: Optional[datetime]
        q: Optional[CatchAllVar]
        r: Optional[Union[int, str]]
        s: Optional[Union[int, str, None]]

# Generated at 2022-06-17 17:58:04.706394
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from typing import List, Optional, Union
    from enum import Enum
    from dataclasses_json.utils import _is_optional, _is_new_type
    from dataclasses_json.core import _is_supported_generic, _is_collection
    from dataclasses_json.mm import build_type

    class TestEnum(Enum):
        A = 1
        B = 2

    @dataclass_json
    @dataclass
    class TestClass:
        a: int
        b: str
        c: Optional[str]
        d: Union[str, int]
        e: List[str]
        f: TestEnum

# Generated at 2022-06-17 17:58:15.520989
# Unit test for function schema
def test_schema():
    import marshmallow as mm
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from dataclasses_json.mm import Schema

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: str = 'c'
        d: str = 'd'
        e: str = 'e'
        f: str = 'f'
        g: str = 'g'
        h: str = 'h'
        i: str = 'i'
        j: str = 'j'
        k: str = 'k'
        l: str = 'l'
        m: str = 'm'
        n: str = 'n'
        o: str = 'o'
        p: str = 'p'


# Generated at 2022-06-17 17:58:21.143569
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class A:
        a: int
        b: str
        c: typing.Optional[int]
        d: typing.Optional[str]

    schema = build_schema(A, None, False, False)
    assert schema.Meta.fields == ('a', 'b', 'c', 'd')
    assert isinstance(schema().fields['a'], fields.Int)
    assert isinstance(schema().fields['b'], fields.Str)
    assert isinstance(schema().fields['c'], fields.Int)
    assert isinstance(schema().fields['d'], fields.Str)
    assert schema().fields['c'].allow_none is True
    assert schema().fields['d'].allow_none is True
    assert schema().fields['c'].default is None
    assert schema().fields

# Generated at 2022-06-17 17:58:31.732133
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    from dataclasses import dataclass
    from typing import List

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: List[A]

    class ASchema(SchemaF[A]):
        a = fields.Int()

    class BSchema(SchemaF[B]):
        b = fields.Nested(ASchema, many=True)

    b = B(b=[A(a=1), A(a=2)])
    b_schema = BSchema()
    b_encoded = b_schema.dump(b)
    b_decoded = b_schema.load(b_encoded)
    assert b == b_decoded



# Generated at 2022-06-17 17:58:42.479298
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_dataclass import class_schema

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str

    assert class_schema(Test) == build_schema(Test, None, False, False)

    @dataclass_json
    @dataclass
    class Test2:
        a: int
        b: str
        c: Test

    assert class_schema(Test2) == build_schema(Test2, None, False, False)

    @dataclass_json
    @dataclass
    class Test3:
        a: int
        b: str
        c: Test

# Generated at 2022-06-17 17:58:55.692141
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from dataclasses import dataclass
    from marshmallow import Schema, fields

    @dataclass
    class A:
        a: int

    class ASchema(SchemaF[A]):
        a = fields.Int()

    ASchema().loads('{"a": 1}')
    ASchema().loads('[{"a": 1}]')
    ASchema().loads(b'{"a": 1}')
    ASchema().loads(b'[{"a": 1}]')
    ASchema().loads(bytearray('{"a": 1}', 'utf8'))
    ASchema().loads(bytearray('[{"a": 1}]', 'utf8'))



# Generated at 2022-06-17 17:59:04.928013
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields, post_load
    from dataclasses import dataclass
    from typing import List
    @dataclass
    class User:
        name: str
        age: int
    class UserSchema(SchemaF[User]):
        name = fields.Str()
        age = fields.Int()
        @post_load
        def make_user(self, data, **kwargs):
            return User(**data)
    user_data = {'name': 'Monty', 'age': '42'}
    schema = UserSchema()
    result = schema.loads(user_data)
    assert result.name == 'Monty'
    assert result.age == 42
    result = schema.loads([user_data])
    assert result[0].name == 'Monty'

# Generated at 2022-06-17 17:59:10.578223
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError

    class TestSchema(Schema):
        name = fields.Str()

    schema = TestSchema()
    schema.loads('{"name": "John"}')
    schema.loads('{"name": "John"}', many=False)
    schema.loads(b'{"name": "John"}')
    schema.loads(b'{"name": "John"}', many=False)
    schema.loads(bytearray(b'{"name": "John"}'))
    schema.loads(bytearray(b'{"name": "John"}'), many=False)
    schema.loads([b'{"name": "John"}'])
    schema.loads([b'{"name": "John"}'], many=True)

# Generated at 2022-06-17 17:59:20.682543
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
        c: typing.List[str]
        d: typing.Dict[str, int]
        e: typing.Optional[str]
        f: typing.Optional[int]
        g: typing.Optional[typing.List[str]]
        h: typing.Optional[typing.Dict[str, int]]
        i: typing.Union[str, int]
        j: typing.Union[str, int, None]
        k: typing.Union[str, typing.List[str]]
        l: typing.Union[str, typing.List[str], None]

# Generated at 2022-06-17 17:59:50.484861
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json, config
    from dataclasses_json.mm import Schema

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str

    assert issubclass(build_schema(Test, config.MISSING_TYPE, False, False), Schema)
    assert issubclass(build_schema(Test, config.MISSING_TYPE, False, True), Schema)
    assert issubclass(build_schema(Test, config.MISSING_TYPE, True, False), Schema)
    assert issubclass(build_schema(Test, config.MISSING_TYPE, True, True), Schema)

# Generated at 2022-06-17 17:59:57.727953
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses import dataclass
    from marshmallow import Schema, fields

    @dataclass
    class A:
        a: int

    class ASchema(SchemaF[A]):
        a = fields.Integer()

    assert ASchema().load({'a': 1}) == A(1)
    assert ASchema().load([{'a': 1}, {'a': 2}]) == [A(1), A(2)]


# Generated at 2022-06-17 18:00:07.026669
# Unit test for function build_type
def test_build_type():
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from dataclasses_json.utils import _is_optional
    from dataclasses_json.core import _is_supported_generic, _is_collection
    from dataclasses_json.mm import _UnionField
    from dataclasses_json.mm import build_type
    from dataclasses import dataclass
    from typing import Optional, List, Union, Dict, Any
    from enum import Enum
    from datetime import datetime
    from uuid import UUID
    from decimal import Decimal
    from dataclasses_json.utils import CatchAllVar

    @dataclass
    class Test:
        a: Optional[int]
        b: List[int]
        c: Union[int, str]
        d: Dict[str, int]

# Generated at 2022-06-17 18:00:17.327900
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
        c: typing.Optional[str]
        d: typing.Optional[int]
        e: typing.Optional[typing.List[str]]
        f: typing.List[int]
        g: typing.List[typing.Optional[int]]
        h: typing.List[typing.Optional[str]]
        i: typing.Optional[typing.List[typing.Optional[str]]]
        j: typing.Optional[typing.List[typing.Optional[int]]]
        k: typing.Optional[typing.List[int]]

# Generated at 2022-06-17 18:00:29.428386
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin
    from marshmallow import fields
    @dataclass
    class A(DataClassJsonMixin):
        a: int
        b: str

# Generated at 2022-06-17 18:00:40.569644
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from typing import Optional
    @dataclass
    class A:
        a: int
        b: Optional[int]
    s = build_schema(A, None, False, False)
    assert s.__name__ == 'ASchema'
    assert s.Meta.fields == ('a', 'b')
    assert s.dump(A(1, 2)) == {'a': 1, 'b': 2}
    assert s.dump(A(1, None)) == {'a': 1, 'b': None}
    assert s.dump([A(1, 2), A(3, 4)]) == [{'a': 1, 'b': 2}, {'a': 3, 'b': 4}]

# Generated at 2022-06-17 18:00:41.851097
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._serialize(datetime.now(), None, None) is not None


# Generated at 2022-06-17 18:00:47.241989
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
        c: typing.List[str]
        d: typing.Dict[str, int]
        e: typing.Optional[str]
        f: typing.Optional[int]
        g: typing.Optional[typing.List[str]]
        h: typing.Optional[typing.Dict[str, int]]
        i: typing.Union[str, int]
        j: typing.Union[str, int, typing.List[str]]
        k: typing.Union[str, int, typing.List[str], typing.Dict[str, int]]
        l: typing.Union

# Generated at 2022-06-17 18:00:56.184214
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import Schema
    from marshmallow import fields
    from marshmallow import post_load
    from marshmallow import Schema
    from marshmallow import fields
    from marshmallow import post_load
    from marshmallow import Schema
    from marshmallow import fields
    from marshmallow import post_load
    from marshmallow import Schema
    from marshmallow import fields
    from marshmallow import post_load
    from marshmallow import Schema
    from marshmallow import fields
    from marshmallow import post_load
    from marshmallow import Schema
    from marshmallow import fields
    from marshmallow import post_load
    from marshmallow import Schema
    from marshmallow import fields
    from marshmallow import post_load
    from marshmallow import Schema

# Generated at 2022-06-17 18:01:05.233143
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.List[str]
        e: typing.Dict[str, int]
        f: typing.Dict[str, str]
        g: typing.Optional[int]
        h: typing.Optional[str]
        i: typing.Optional[typing.List[int]]
        j: typing.Optional[typing.List[str]]
        k: typing.Optional[typing.Dict[str, int]]
        l: typing.Optional[typing.Dict[str, str]]

# Generated at 2022-06-17 18:01:59.005762
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Optional[str]
        e: typing.Optional[int] = None
        f: typing.Optional[int] = 1
        g: typing.Optional[int] = 2
        h: typing.Optional[int] = None
        i: typing.Optional[int] = None
        j: typing.Optional[int] = None
        k: typing.Optional[int] = None
        l: typing.Optional[int] = None
        m: typing.Optional[int] = None
        n: typing.Optional[int] = None
        o: typing.Optional[int] = None
        p: typing.Optional[int] = None
        q: typing.Optional[int] = None
        r

# Generated at 2022-06-17 18:02:05.233726
# Unit test for function build_type
def test_build_type():
    from typing import Optional, Union, List, Dict, Tuple, Callable, Any
    from dataclasses import dataclass
    from marshmallow import fields as mm_fields
    from marshmallow_enum import EnumField as mm_EnumField
    from dataclasses_json.mm import Schema
    from dataclasses_json.core import _is_supported_generic, _is_collection
    from dataclasses_json.utils import _is_new_type, _get_type_origin, _issubclass_safe, _is_optional

    class MyEnum(Enum):
        A = 1
        B = 2

    @dataclass
    class MyClass:
        pass

    @dataclass
    class MyClass2:
        pass

    @dataclass
    class MyClass3:
        pass


# Generated at 2022-06-17 18:02:15.320231
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import Schema, fields

    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str

    @dataclass_json
    @dataclass
    class B:
        a: A
        b: str

    @dataclass_json
    @dataclass
    class C:
        a: A
        b: B

    @dataclass_json
    @dataclass
    class D:
        a: typing.List[A]
        b: typing.List[B]

    @dataclass_json
    @dataclass
    class E:
        a: typing.List[A]
        b: typing.List[B]


# Generated at 2022-06-17 18:02:25.035596
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from typing import Optional, List, Union, Dict, Any

    @dataclass_json
    @dataclass
    class Test:
        a: Optional[int]
        b: List[int]
        c: Union[int, str]
        d: Dict[str, int]
        e: Any

    assert build_type(Test.a.type, {}, dataclass_json, Test.a, Test) == fields.Int(allow_none=True)
    assert build_type(Test.b.type, {}, dataclass_json, Test.b, Test) == fields.List(fields.Int())

# Generated at 2022-06-17 18:02:36.212356
# Unit test for function build_schema
def test_build_schema():
    class A:
        pass

    class B:
        pass

    class C:
        pass

    class D:
        pass

    class E:
        pass

    class F:
        pass

    class G:
        pass

    class H:
        pass

    class I:
        pass

    class J:
        pass

    class K:
        pass

    class L:
        pass

    class M:
        pass

    class N:
        pass

    class O:
        pass

    class P:
        pass

    class Q:
        pass

    class R:
        pass

    class S:
        pass

    class T:
        pass

    class U:
        pass

    class V:
        pass

    class W:
        pass

    class X:
        pass

    class Y:
        pass

# Generated at 2022-06-17 18:02:42.961999
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Foo(typing.Generic[A]):
        def __init__(self, a: A):
            self.a = a

    class FooSchema(SchemaF[Foo[int]]):
        a = fields.Int()

    assert FooSchema().dump(Foo(1)) == {'a': 1}
    assert FooSchema().dump([Foo(1), Foo(2)]) == [{'a': 1}, {'a': 2}]
    assert FooSchema().dump(Foo(1), many=False) == {'a': 1}
    assert FooSchema().dump([Foo(1), Foo(2)], many=True) == [{'a': 1}, {'a': 2}]

# Generated at 2022-06-17 18:02:50.042270
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._deserialize('2020-01-01T00:00:00') == datetime(2020, 1, 1, 0, 0, 0)
    assert _IsoField()._serialize(datetime(2020, 1, 1, 0, 0, 0)) == '2020-01-01T00:00:00'


# Generated at 2022-06-17 18:03:00.811121
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError
    from dataclasses import dataclass

    @dataclass
    class Test:
        a: int
        b: str

    class TestSchema(SchemaF[Test]):
        a = fields.Int()
        b = fields.Str()

    schema = TestSchema()
    assert schema.load({'a': 1, 'b': '2'}) == Test(a=1, b='2')
    assert schema.load([{'a': 1, 'b': '2'}, {'a': 3, 'b': '4'}]) == [Test(a=1, b='2'), Test(a=3, b='4')]

# Generated at 2022-06-17 18:03:12.139093
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields

    class MySchema(SchemaF[int]):
        a = fields.Int()

    assert MySchema().dump(1) == {'a': 1}
    assert MySchema().dump([1, 2]) == [{'a': 1}, {'a': 2}]
    assert MySchema().dump([1, 2], many=False) == {'a': 2}
    assert MySchema().dump(1, many=True) == [{'a': 1}]
    assert MySchema().dump([1, 2], many=True) == [{'a': 1}, {'a': 2}]
    assert MySchema().dump([1, 2], many=False) == {'a': 2}

# Generated at 2022-06-17 18:03:23.308199
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import Schema, fields, post_load

    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str
        c: typing.Optional[int] = None

    @dataclass_json
    @dataclass
    class B:
        a: typing.List[A]

    @dataclass_json
    @dataclass
    class C:
        a: typing.List[typing.Optional[A]]

    @dataclass_json
    @dataclass
    class D:
        a: typing.Optional[typing.List[A]]

    @dataclass_json
    @dataclass
    class E:
        a: typing

# Generated at 2022-06-17 18:05:22.790668
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str
        c: typing.List[int]
        d: typing.List[str]
        e: typing.Dict[str, int]
        f: typing.Dict[str, str]
        g: typing.Optional[int]
        h: typing.Optional[str]
        i: typing.Optional[typing.List[int]]
        j: typing.Optional[typing.List[str]]
        k: typing.Optional[typing.Dict[str, int]]
        l: typing.Optional[typing.Dict[str, str]]

# Generated at 2022-06-17 18:05:26.453073
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 18:05:30.735026
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str
    assert schema(A, A, False) == {'a': fields.Int(), 'b': fields.Str()}



# Generated at 2022-06-17 18:05:42.057297
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError
    from dataclasses import dataclass

    @dataclass
    class Person:
        name: str
        age: int

    class PersonSchema(SchemaF[Person]):
        name = fields.Str()
        age = fields.Int()

    schema = PersonSchema()
    person = schema.loads('{"name": "Monty", "age": 42}')
    assert person.name == "Monty"
    assert person.age == 42
    try:
        schema.loads('{"name": "Monty", "age": "42"}')
        assert False
    except ValidationError:
        pass

# Generated at 2022-06-17 18:05:48.902511
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._deserialize('2020-01-01T00:00:00') == datetime(2020, 1, 1, 0, 0, 0)
    assert _IsoField()._serialize(datetime(2020, 1, 1, 0, 0, 0)) == '2020-01-01T00:00:00'
