

# Generated at 2022-06-17 17:56:17.048752
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    assert FooSchema().loads('{"a": 1, "b": "hello"}') == Foo(1, "hello")
    assert FooSchema().loads('[{"a": 1, "b": "hello"}]') == [Foo(1, "hello")]
    assert FooSchema().loads(b'{"a": 1, "b": "hello"}') == Foo(1, "hello")
    assert FooSchema().loads(b'[{"a": 1, "b": "hello"}]') == [Foo(1, "hello")]

# Generated at 2022-06-17 17:56:25.008098
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from dataclasses_json.mm import Schema

    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
        c: typing.Optional[int]
        d: typing.Optional[typing.List[int]]
        e: typing.List[int]
        f: typing.Optional[typing.List[int]]
        g: typing.Optional[typing.List[int]] = None
        h: typing.Optional[typing.List[int]] = []
        i: typing.Optional[typing.List[int]] = [1, 2, 3]

# Generated at 2022-06-17 17:56:32.656396
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class TestSchema(SchemaF[A]):
        pass

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: int

    @dataclass
    class C:
        c: typing.Union[A, B]

    schema = TestSchema()
    assert schema.load({'c': {'a': 1}}, unknown=EXCLUDE) == C(A(1))
    assert schema.load({'c': {'b': 1}}, unknown=EXCLUDE) == C(B(1))



# Generated at 2022-06-17 17:56:39.910118
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import List
    from marshmallow import Schema, fields

    class MySchema(Schema):
        a = fields.Int()

    class MySchemaF(SchemaF[int]):
        pass

    assert MySchemaF(MySchema).dump(1) == {'a': 1}
    assert MySchemaF(MySchema).dump([1, 2]) == [{'a': 1}, {'a': 2}]


# Generated at 2022-06-17 17:56:45.198713
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Foo:
        a: int

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()

    foo = Foo(1)
    assert FooSchema().dump(foo) == {'a': 1}
    assert FooSchema().dump([foo]) == [{'a': 1}]



# Generated at 2022-06-17 17:56:57.049265
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.List[Test]
        e: typing.Optional[int]
        f: typing.Optional[Test]
        g: typing.Union[int, str]
        h: typing.Union[Test, str]
        i: typing.Mapping[str, int]
        j: typing.Mapping[str, Test]
        k: typing.Mapping[str, typing.Union[int, str]]
        l: typing.Mapping[str, typing.Union[Test, str]]

# Generated at 2022-06-17 17:57:05.620717
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import List
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Foo:
        a: int
        b: str

    class FooSchema(Schema):
        a = fields.Int()
        b = fields.Str()

    schema = SchemaF[Foo](FooSchema)
    assert schema.dump(Foo(1, 'a')) == {'a': 1, 'b': 'a'}
    assert schema.dump([Foo(1, 'a')]) == [{'a': 1, 'b': 'a'}]

# Generated at 2022-06-17 17:57:16.199872
# Unit test for function build_type
def test_build_type():
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from dataclasses_json.utils import _is_optional
    from dataclasses_json.core import _is_new_type
    from dataclasses_json.core import _is_supported_generic
    from dataclasses_json.core import _is_collection
    from dataclasses_json.core import _issubclass_safe
    from dataclasses_json.core import _get_type_origin
    from dataclasses_json.core import _is_union_type
    from dataclasses_json.core import _UnionField
    from dataclasses_json.core import _is_dataclass
    from dataclasses_json.core import _is_collection
    from dataclasses_json.core import _is_optional

# Generated at 2022-06-17 17:57:18.530383
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from dataclasses_json.mm import Schema

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str

    assert isinstance(build_schema(Test, None, True, True), Schema)

# Generated at 2022-06-17 17:57:29.637952
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields
    from typing import List

    class Foo(Schema):
        bar = fields.Str()

    class FooF(SchemaF[Foo]):
        pass

    assert FooF().dumps([Foo(bar='baz')]) == '[{"bar": "baz"}]'
    assert FooF().dumps(Foo(bar='baz')) == '{"bar": "baz"}'

    class FooList(Schema):
        bar = fields.List(fields.Str())

    class FooListF(SchemaF[FooList]):
        pass

    assert FooListF().dumps([FooList(bar=['baz'])]) == '[{"bar": ["baz"]}]'

# Generated at 2022-06-17 17:57:48.147760
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.Optional[str]
        d: typing.Optional[int] = None
        e: typing.Optional[int] = field(default=None)
        f: typing.Optional[int] = field(default=None, metadata={'dataclasses_json': {'mm_field': fields.Int()}})
        g: typing.Optional[int] = field(default=None, metadata={'dataclasses_json': {'mm_field': fields.Int()}})
        h: typing.Optional[int] = field(default=None, metadata={'dataclasses_json': {'mm_field': fields.Int()}})

# Generated at 2022-06-17 17:57:59.706329
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields
    from typing import List, Dict, Any
    class Foo(Schema):
        a: int = fields.Int()
        b: str = fields.Str()
    class Bar(Schema):
        c: int = fields.Int()
        d: str = fields.Str()
    class FooBar(Schema):
        foo: Foo = fields.Nested(Foo)
        bar: Bar = fields.Nested(Bar)
    class FooBarList(Schema):
        foobar: List[FooBar] = fields.Nested(FooBar, many=True)
    class FooBarDict(Schema):
        foobar: Dict[str, FooBar] = fields.Nested(FooBar)
    class FooBarAny(Schema):
        foobar: Any = fields

# Generated at 2022-06-17 17:58:07.757531
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class Test:
        a: int
        b: str


# Generated at 2022-06-17 17:58:17.337051
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields
    class Foo(Schema):
        a = fields.Int()
    class Bar(Schema):
        b = fields.Int()
    class FooBar(SchemaF[typing.Union[Foo, Bar]]):
        pass
    fb = FooBar()
    assert fb.dump(Foo()) == {'a': None}
    assert fb.dump(Bar()) == {'b': None}
    assert fb.dump([Foo(), Bar()]) == [{'a': None}, {'b': None}]
    assert fb.dump([Foo(), Bar()], many=True) == [{'a': None}, {'b': None}]
    assert fb.dump(Foo(), many=False) == {'a': None}
    assert fb.dump

# Generated at 2022-06-17 17:58:29.296586
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class MySchema(SchemaF[A]):
        pass

    MySchema().dumps([1, 2, 3])
    MySchema().dumps(1)
    MySchema().dumps([1, 2, 3], many=True)
    MySchema().dumps(1, many=False)
    MySchema().dumps([1, 2, 3], many=False)
    MySchema().dumps(1, many=True)
    MySchema().dumps([1, 2, 3], many=False, foo="bar")
    MySchema().dumps(1, many=True, foo="bar")
    MySchema().dumps([1, 2, 3], foo="bar")
    MySchema().dumps(1, foo="bar")



# Generated at 2022-06-17 17:58:41.047046
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from typing import Optional, Union
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from marshmallow.exceptions import ValidationError
    from dataclasses_json.utils import _is_optional, _issubclass_safe
    from dataclasses_json.core import _is_new_type, _is_supported_generic, _is_collection
    from dataclasses_json.core import _UnionField
    from dataclasses_json.core import _TimestampField
    from dataclasses_json.core import _IsoField
    from dataclasses_json.core import _get_type_origin
    from dataclasses_json.core import _handle_undefined_parameters_safe
    from dataclasses_json.core import CatchAllVar

# Generated at 2022-06-17 17:58:48.383562
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json, config
    from marshmallow import fields as mm_fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Mapping[str, int]
        f: typing.MutableMapping[str, int]
        g: typing.Tuple[int, str]
        h: typing.Callable[[int], str]
        i: typing.Any
        j: dict
        k: list
        l: str
        m: int
        n: float
        o: bool
        p: datetime
        q: UUID
        r: Decimal
       

# Generated at 2022-06-17 17:58:51.215859
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses import dataclass
    from typing import List

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: List[A]

    schema = SchemaF[B]()
    assert schema.dump(B([A(1), A(2)])) == {'b': [{'a': 1}, {'a': 2}]}



# Generated at 2022-06-17 17:59:02.615940
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class MyClass:
        a: str
        b: int
        c: typing.Optional[str]
        d: typing.Optional[int] = None
        e: typing.Optional[typing.List[str]] = None
        f: typing.Optional[typing.List[int]] = None
        g: typing.Optional[typing.List[typing.Optional[str]]] = None
        h: typing.Optional[typing.List[typing.Optional[int]]] = None
        i: typing.Optional[typing.List[typing.Optional[typing.List[str]]]] = None

# Generated at 2022-06-17 17:59:04.992262
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None)
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None)


# Generated at 2022-06-17 17:59:38.802790
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Foo:
        a: int

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()

    foo = Foo(a=1)
    foo_schema = FooSchema()
    assert foo_schema.dumps(foo) == '{"a": 1}'
    assert foo_schema.dumps([foo]) == '[{"a": 1}]'
    assert foo_schema.dumps(foo, many=False) == '{"a": 1}'
    assert foo_schema.dumps([foo], many=False) == '[{"a": 1}]'
    assert foo_schema.dumps(foo, many=True) == '{"a": 1}'

# Generated at 2022-06-17 17:59:48.645428
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str

    @dataclass_json
    @dataclass
    class B:
        a: A
        b: str

    @dataclass_json
    @dataclass
    class C:
        a: typing.List[A]
        b: str

    @dataclass_json
    @dataclass
    class D:
        a: typing.List[A]
        b: typing.List[str]

    @dataclass_json
    @dataclass
    class E:
        a: typing.List[A]

# Generated at 2022-06-17 17:59:53.484092
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class TestSchema(SchemaF[int]):
        pass

    assert TestSchema().dumps(1) == '1'
    assert TestSchema().dumps([1, 2]) == '[1, 2]'
    assert TestSchema().dumps(1, many=True) == '[1]'
    assert TestSchema().dumps([1, 2], many=False) == '1'
    assert TestSchema().dumps(1, many=False) == '1'
    assert TestSchema().dumps([1, 2], many=True) == '[1, 2]'



# Generated at 2022-06-17 18:00:04.418275
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    from dataclasses import dataclass
    from typing import List

    @dataclass
    class Person:
        name: str
        age: int

    class PersonSchema(SchemaF[Person]):
        name = fields.Str()
        age = fields.Int()

    schema = PersonSchema()
    person = schema.load({'name': 'John', 'age': 42})
    assert person.name == 'John'
    assert person.age == 42

    people = schema.load([{'name': 'John', 'age': 42}, {'name': 'Jane', 'age': 43}], many=True)
    assert people[0].name == 'John'
    assert people[0].age == 42
    assert people[1].name == 'Jane'

# Generated at 2022-06-17 18:00:08.805422
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field._serialize(datetime.now(), None, None) is not None
    assert field._deserialize(datetime.now().isoformat(), None, None) is not None


# Generated at 2022-06-17 18:00:18.374554
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Foo:
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    schema = FooSchema()
    foo = Foo(1, 'bar')
    assert schema.dumps(foo) == '{"a": 1, "b": "bar"}'
    assert schema.dumps([foo]) == '[{"a": 1, "b": "bar"}]'
    assert schema.dumps(foo, many=True) == '[{"a": 1, "b": "bar"}]'
    assert schema.dumps([foo], many=False) == '{"a": 1, "b": "bar"}'

# Unit test

# Generated at 2022-06-17 18:00:29.713362
# Unit test for function schema
def test_schema():
    import typing
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class A:
        a: typing.List[int]
        b: typing.Dict[str, int]
        c: typing.Tuple[int, int]
        d: typing.Callable[[int], int]
        e: typing.Any
        f: dict
        g: list
        h: str
        i: int
        j: float
        k: bool
        l: datetime
        m: UUID
        n: Decimal
        o: typing.Optional[int]
        p: typing.Optional[typing.List[int]]

# Generated at 2022-06-17 18:00:40.716009
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Foo:
        a: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Str()

    foo = Foo('bar')
    assert FooSchema().dump(foo) == {'a': 'bar'}
    assert FooSchema().dump([foo]) == [{'a': 'bar'}]
    assert FooSchema().dump(foo, many=False) == {'a': 'bar'}
    assert FooSchema().dump([foo], many=False) == [{'a': 'bar'}]
    assert FooSchema().dump(foo, many=True) == {'a': 'bar'}

# Generated at 2022-06-17 18:00:43.658407
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class Foo:
        a: int

    foo = Foo(1)
    schema = SchemaF[Foo]()
    assert schema.dumps(foo) == '{"a": 1}'
    assert schema.dumps([foo]) == '[{"a": 1}]'


# Generated at 2022-06-17 18:00:48.277934
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    from typing import List
    class Foo(Schema):
        a = fields.Int()
    class Bar(SchemaF[Foo]):
        pass
    assert Bar.load([{'a': 1}, {'a': 2}]) == [Foo(a=1), Foo(a=2)]
    assert Bar.load({'a': 1}) == Foo(a=1)
    assert Bar.load([{'a': 1}]) == [Foo(a=1)]
    assert Bar.load({'a': 1}, many=True) == [Foo(a=1)]
    assert Bar.load([{'a': 1}], many=False) == Foo(a=1)
    assert Bar.load({'a': 1}, many=False) == Foo(a=1)
   

# Generated at 2022-06-17 18:01:52.014143
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # type: () -> None
    class Foo(typing.Generic[A]):
        pass

    class FooSchema(SchemaF[A]):
        pass

    assert isinstance(FooSchema().dumps(Foo()), str)
    assert isinstance(FooSchema().dumps([Foo()]), str)



# Generated at 2022-06-17 18:01:55.173631
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 18:02:03.005490
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from marshmallow.exceptions import ValidationError
    from dataclasses_json.utils import _is_optional

    class MyEnum(Enum):
        A = 1
        B = 2

    @dataclass_json
    @dataclass
    class MyClass:
        a: int
        b: str
        c: MyEnum
        d: typing.Optional[int]
        e: typing.List[int]
        f: typing.Dict[str, int]
        g: typing.Mapping[str, int]
        h: typing.MutableMapping[str, int]
        i: typing.Tuple[int, str]

# Generated at 2022-06-17 18:02:06.836169
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field._serialize(datetime.now(), None, None) is not None
    assert field._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 18:02:11.759387
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int
        b: str

    @dataclass
    class B:
        a: A
        b: str

    assert build_schema(A, None, False, False)
    assert build_schema(B, None, False, False)



# Generated at 2022-06-17 18:02:21.283346
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from typing import Optional, List
    from marshmallow import fields

    @dataclass
    class A:
        a: int
        b: Optional[int]
        c: List[int]
        d: Optional[List[int]]

    schema = build_schema(A, None, False, False)
    assert schema.Meta.fields == ('a', 'b', 'c', 'd')
    assert isinstance(schema.a, fields.Int)
    assert isinstance(schema.b, fields.Int)
    assert isinstance(schema.c, fields.List)
    assert isinstance(schema.d, fields.List)



# Generated at 2022-06-17 18:02:27.788140
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class TestSchema(SchemaF[A]):
        pass
    # TestSchema.load(data: typing.List[TEncoded], many: bool = True, partial: bool = None, unknown: str = None) -> typing.List[A]:
    # TestSchema.load(data: TEncoded, many: None = None, partial: bool = None, unknown: str = None) -> A:
    # TestSchema.load(data: TOneOrMultiEncoded, many: bool = None, partial: bool = None, unknown: str = None) -> TOneOrMulti:
    pass

# Generated at 2022-06-17 18:02:31.825885
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 18:02:37.893948
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo = Foo(a=1, b='b')
    assert FooSchema().dumps(foo) == '{"a": 1, "b": "b"}'
    assert FooSchema().dumps([foo]) == '[{"a": 1, "b": "b"}]'



# Generated at 2022-06-17 18:02:46.769603
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json, config
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.Optional[int]
        d: typing.Optional[str]
        e: typing.Optional[typing.List[int]]
        f: typing.Optional[typing.List[str]]
        g: typing.Optional[typing.List[typing.Optional[int]]]
        h: typing.Optional[typing.List[typing.Optional[str]]]
        i: typing.Optional[typing.List[typing.Optional[typing.List[int]]]]

# Generated at 2022-06-17 18:05:29.690024
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import List
    from marshmallow import Schema, fields

    class Foo(Schema):
        a = fields.Int()

    class Bar(Schema):
        b = fields.Int()

    class FooBar(SchemaF[typing.Union[Foo, Bar]]):
        pass

    f = FooBar()
    assert f.dump(Foo(a=1)) == {'a': 1}
    assert f.dump(Bar(b=2)) == {'b': 2}
    assert f.dump([Foo(a=1), Bar(b=2)]) == [{'a': 1}, {'b': 2}]
    assert f.dump(Foo(a=1), many=False) == {'a': 1}

# Generated at 2022-06-17 18:05:41.651421
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses import dataclass

    @dataclass
    class Foo:
        a: int

    @dataclass
    class Bar:
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()

    class BarSchema(SchemaF[Bar]):
        b = fields.Str()

    foo = Foo(a=1)
    bar = Bar(b='b')

    foo_schema = FooSchema()
    bar_schema = BarSchema()

    assert foo_schema.dump(foo) == {'a': 1}
    assert foo_schema.dump([foo]) == [{'a': 1}]
    assert bar_schema.dump(bar) == {'b': 'b'}

# Generated at 2022-06-17 18:05:43.814639
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._deserialize('2020-01-01T00:00:00') == datetime(2020, 1, 1)
    assert _IsoField()._serialize(datetime(2020, 1, 1)) == '2020-01-01T00:00:00'
