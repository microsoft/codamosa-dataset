

# Generated at 2022-06-17 17:56:11.205005
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime(2020, 1, 1, 0, 0, 0), None, None) == 1577836800.0
    assert _TimestampField()._deserialize(1577836800.0, None, None) == datetime(2020, 1, 1, 0, 0, 0)


# Generated at 2022-06-17 17:56:23.175415
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from typing import Optional
    from dataclasses_json import DataClassJsonMixin
    from marshmallow import fields
    from marshmallow_dataclass import class_schema

    @dataclass
    class Person(DataClassJsonMixin):
        name: str
        age: int
        height: Optional[float] = None

    schema = class_schema(Person)
    assert isinstance(schema.declared_fields['name'], fields.String)
    assert isinstance(schema.declared_fields['age'], fields.Integer)
    assert isinstance(schema.declared_fields['height'], fields.Float)
    assert schema.declared_fields['height'].allow_none



# Generated at 2022-06-17 17:56:29.838818
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.Optional[int] = None
        d: typing.Optional[str] = None
        e: typing.Optional[int] = field(default=None)
        f: typing.Optional[str] = field(default=None)
        g: typing.Optional[int] = field(default=None, metadata={'dataclasses_json': {'mm_field': fields.Int()}})
        h: typing.Optional[str] = field(default=None, metadata={'dataclasses_json': {'mm_field': fields.Str()}})

# Generated at 2022-06-17 17:56:41.644717
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses import dataclass
    from marshmallow import Schema, fields
    from typing import List

    @dataclass
    class A:
        a: int

    class ASchema(SchemaF[A]):
        a = fields.Int()

    assert ASchema().load({'a': 1}) == A(a=1)
    assert ASchema().load([{'a': 1}, {'a': 2}]) == [A(a=1), A(a=2)]
    assert ASchema().load([{'a': 1}, {'a': 2}], many=True) == [A(a=1), A(a=2)]
    assert ASchema().load([{'a': 1}, {'a': 2}], many=False) == A(a=1)
    assert ASchema

# Generated at 2022-06-17 17:56:45.450441
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Foo:
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo = Foo(1, 'bar')
    foo_schema = FooSchema()
    foo_schema.dump(foo)
    foo_schema.dump([foo])
    foo_schema.dump(foo, many=False)
    foo_schema.dump([foo], many=True)



# Generated at 2022-06-17 17:56:51.897670
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.Optional[int] = None
        d: typing.Optional[str] = None
        e: typing.Optional[typing.List[int]] = None
        f: typing.Optional[typing.List[str]] = None
        g: typing.Optional[typing.List[typing.Optional[int]]] = None
        h: typing.Optional[typing.List[typing.Optional[str]]] = None
        i: typing.Optional[typing.List[typing.Optional[typing.List[int]]]] = None
        j: typing.Optional[typing.List[typing.Optional[typing.List[str]]]] = None

# Generated at 2022-06-17 17:57:00.541379
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin, config
    from marshmallow import fields as mm_fields

    @dataclass
    class A(DataClassJsonMixin):
        a: int
        b: str

    @dataclass
    class B(DataClassJsonMixin):
        a: A
        b: typing.List[A]

    @dataclass
    class C(DataClassJsonMixin):
        a: typing.List[A]
        b: typing.Dict[str, A]

    @dataclass
    class D(DataClassJsonMixin):
        a: typing.List[A]
        b: typing.Dict[str, typing.List[A]]


# Generated at 2022-06-17 17:57:10.122529
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses import dataclass
    from marshmallow import Schema, fields

    @dataclass
    class Foo:
        bar: str

    class FooSchema(SchemaF[Foo]):
        bar = fields.Str()

    foo = Foo('baz')
    schema = FooSchema()
    assert schema.dump(foo) == {'bar': 'baz'}
    assert schema.dump([foo]) == [{'bar': 'baz'}]
    assert schema.dump(foo, many=True) == [{'bar': 'baz'}]
    assert schema.dump([foo], many=False) == {'bar': 'baz'}


# Generated at 2022-06-17 17:57:19.133001
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: str

    @dataclass
    class C:
        c: typing.List[A]

    @dataclass
    class D:
        d: typing.List[B]

    @dataclass
    class E:
        e: typing.List[C]

    @dataclass
    class F:
        f: typing.List[D]

    @dataclass
    class G:
        g: typing.List[E]

    @dataclass
    class H:
        h: typing.List[F]

    @dataclass
    class I:
        i: typing.List[G]


# Generated at 2022-06-17 17:57:30.413385
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Foo(typing.Generic[A]):
        def __init__(self, a: A):
            self.a = a

    class FooSchema(SchemaF[Foo[int]]):
        a = fields.Int()

    foo = Foo(1)
    foo_schema = FooSchema()
    foo_schema.dump(foo)
    foo_schema.load({'a': 1})
    foo_schema.load([{'a': 1}])
    foo_schema.load([{'a': 1}], many=True)
    foo_schema.load({'a': 1}, many=False)
    foo_schema.load({'a': 1}, many=None)
    foo_schema.load([{'a': 1}], many=False)
    foo_schema

# Generated at 2022-06-17 17:57:49.120841
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json, config
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
        c: typing.List[str]
        d: typing.Optional[int]
        e: typing.Optional[typing.List[str]]
        f: typing.Optional[typing.List[typing.Optional[str]]]
        g: typing.Optional[typing.List[typing.Optional[int]]]
        h: typing.Optional[typing.List[typing.Optional[typing.List[str]]]]
        i: typing.Optional[typing.List[typing.Optional[typing.List[int]]]]

# Generated at 2022-06-17 17:57:58.164496
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from typing import Optional, List, Dict, Union

    @dataclass_json
    @dataclass
    class Test:
        a: Optional[int]
        b: List[int]
        c: Dict[str, int]
        d: Union[int, str]
        e: Optional[Union[int, str]]
        f: Optional[Union[int, str]] = None

    assert build_type(int, {}, Test, dc_fields(Test)[0], Test) == fields.Int
    assert build_type(List[int], {}, Test, dc_fields(Test)[1], Test) == fields.List

# Generated at 2022-06-17 17:58:07.349192
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Person:
        name: str
        age: int

    class PersonSchema(SchemaF[Person]):
        name = fields.Str()
        age = fields.Int()

    schema = PersonSchema()
    person = schema.load({'name': 'Monty', 'age': 81})
    assert person.name == 'Monty'
    assert person.age == 81
    people = schema.load([{'name': 'Monty', 'age': 81}, {'name': 'Guido', 'age': 56}], many=True)
    assert people[0].name == 'Monty'
    assert people[0].age == 81
    assert people[1].name == 'Guido'

# Generated at 2022-06-17 17:58:17.102179
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class TestSchema(SchemaF[A]):
        pass
    TestSchema().loads(b'{"a": 1}', many=False)
    TestSchema().loads(b'[{"a": 1}]', many=True)
    TestSchema().loads(b'[{"a": 1}]')
    TestSchema().loads(b'{"a": 1}')
    TestSchema().loads(b'{"a": 1}', many=False)
    TestSchema().loads(b'[{"a": 1}]', many=True)
    TestSchema().loads(b'[{"a": 1}]')
    TestSchema().loads(b'{"a": 1}')
    TestSchema().loads(b'{"a": 1}', many=False)

# Generated at 2022-06-17 17:58:29.128398
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[str]
        f: typing.Optional[int]
        g: typing.Optional[typing.List[int]]
        h: typing.Optional[typing.Dict[str, int]]
        i: typing.Optional[typing.Union[str, int]]
        j: typing.Optional[typing.Union[str, int, None]]
        k: typing.Optional[typing.Union[str, None]]

# Generated at 2022-06-17 17:58:40.960178
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from typing import Optional, List, Dict, Union

    @dataclass_json
    @dataclass
    class Nested:
        a: int

    @dataclass_json
    @dataclass
    class Test:
        a: Optional[int]
        b: List[int]
        c: Dict[str, int]
        d: Nested
        e: Union[int, str]

    assert isinstance(build_type(Test.__annotations__['a'], {}, dataclass_json,
                                 dc_fields(Test)[0], Test), fields.Int)

# Generated at 2022-06-17 17:58:55.020580
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
        c: float
        d: bool
        e: typing.List[int]
        f: typing.Dict[str, int]
        g: typing.Tuple[int, str]
        h: typing.Callable
        i: typing.Any
        j: typing.Optional[int]
        k: typing.Optional[typing.List[int]]
        l: typing.Optional[typing.Dict[str, int]]
        m: typing.Optional[typing.Tuple[int, str]]
        n: typing.Optional[typing.Callable]

# Generated at 2022-06-17 17:58:57.436817
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class TestSchema(SchemaF[A]):
        pass
    assert TestSchema().dumps([1, 2, 3]) == '[1, 2, 3]'
    assert TestSchema().dumps(1) == '1'


# Generated at 2022-06-17 17:59:06.048026
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class A:
        a: int
        b: str

    @dataclass
    class B:
        a: A
        b: str

    @dataclass
    class C:
        a: typing.List[A]
        b: str

    @dataclass
    class D:
        a: typing.List[A]
        b: typing.List[B]

    @dataclass
    class E:
        a: typing.List[A]
        b: typing.List[B]
        c: typing.List[C]

    @dataclass
    class F:
        a: typing.List[A]
        b: typing.List[B]
        c: typing.List[C]
        d: typing.List[D]


# Generated at 2022-06-17 17:59:11.273679
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._serialize(datetime(2020, 1, 1), "attr", "obj") == "2020-01-01T00:00:00"
    assert _IsoField()._deserialize("2020-01-01T00:00:00", "attr", "data") == datetime(2020, 1, 1)


# Generated at 2022-06-17 17:59:46.143160
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str
    assert schema(A, A, False) == {'a': fields.Int(), 'b': fields.Str()}
    @dataclass_json
    @dataclass
    class B:
        a: int
        b: typing.Optional[str]
    assert schema(B, B, False) == {'a': fields.Int(), 'b': fields.Str(allow_none=True)}
    @dataclass_json
    @dataclass
    class C:
        a: typing.Optional[int]
        b: typing.Optional[str]

# Generated at 2022-06-17 17:59:49.233476
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # type: () -> None
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo = Foo(a=1, b='b')
    assert FooSchema().dumps(foo) == '{"a": 1, "b": "b"}'



# Generated at 2022-06-17 17:59:53.081904
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int

    class ASchema(SchemaF[A]):
        a = fields.Int()

    assert ASchema().dump(A(1)) == {'a': 1}
    assert ASchema().dump([A(1), A(2)]) == [{'a': 1}, {'a': 2}]


# Generated at 2022-06-17 18:00:04.260419
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from typing import Optional

    @dataclass
    class Test:
        a: int
        b: Optional[int]
        c: str
        d: Optional[str]

    assert build_schema(Test, None, False, False) is not None
    assert build_schema(Test, None, False, False) is not None
    assert build_schema(Test, None, False, False) is not None
    assert build_schema(Test, None, False, False) is not None
    assert build_schema(Test, None, False, False) is not None
    assert build_schema(Test, None, False, False) is not None
    assert build_schema(Test, None, False, False) is not None

# Generated at 2022-06-17 18:00:13.346569
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Person:
        name: str
        age: int

    class PersonSchema(SchemaF[Person]):
        name = fields.Str()
        age = fields.Int()

    schema = PersonSchema()
    person = Person("John", 42)
    result = schema.dump(person)
    assert result == {'name': 'John', 'age': 42}

    result = schema.dump([person])
    assert result == [{'name': 'John', 'age': 42}]



# Generated at 2022-06-17 18:00:21.071112
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str

    @dataclass_json
    @dataclass
    class B:
        a: A
        b: str

    @dataclass_json
    @dataclass
    class C:
        a: typing.List[A]
        b: str

    @dataclass_json
    @dataclass
    class D:
        a: typing.List[A]
        b: typing.List[str]

    @dataclass_json
    @dataclass
    class E:
        a: typing.List[A]

# Generated at 2022-06-17 18:00:27.571011
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Foo:
        pass

    class FooSchema(SchemaF[Foo]):
        pass

    assert isinstance(FooSchema().load([{}], many=True), list)
    assert isinstance(FooSchema().load({}, many=False), Foo)
    assert isinstance(FooSchema().load({}), list)
    assert isinstance(FooSchema().load([{}]), list)



# Generated at 2022-06-17 18:00:39.562081
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    assert FooSchema().loads('{"a": 1, "b": "foo"}') == Foo(a=1, b='foo')
    assert FooSchema().loads('[{"a": 1, "b": "foo"}]') == [Foo(a=1, b='foo')]
    assert FooSchema().loads(b'{"a": 1, "b": "foo"}') == Foo(a=1, b='foo')
    assert FooSchema().loads(b'[{"a": 1, "b": "foo"}]') == [Foo(a=1, b='foo')]
    assert Foo

# Generated at 2022-06-17 18:00:50.158370
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Foo:
        bar: int

    @dataclass_json
    @dataclass
    class Bar:
        foo: Foo

    assert schema(Bar, dataclass_json.DataClassJsonMixin, False) == {'foo': fields.Nested(Foo.schema())}

# Generated at 2022-06-17 18:01:01.156647
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from marshmallow.exceptions import ValidationError
    from dataclasses_json.utils import _is_optional, _is_new_type, _get_type_origin, _issubclass_safe
    from typing import Optional, Union, List, Dict, Any, Tuple, Callable, Mapping, MutableMapping
    from dataclasses_json.utils import CatchAllVar
    import typing
    import warnings
    import sys
    from copy import deepcopy
    from dataclasses import MISSING, is_dataclass, fields as dc_fields
    from datetime import datetime
    from decimal import Decimal
    from uuid import UUID

# Generated at 2022-06-17 18:01:37.377451
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json, config
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: float
        d: typing.Optional[int]
        e: typing.Optional[str]
        f: typing.Optional[float]
        g: typing.Optional[typing.List[int]]
        h: typing.Optional[typing.List[str]]
        i: typing.Optional[typing.List[float]]
        j: typing.Optional[typing.List[typing.Optional[int]]]
        k: typing.Optional[typing.List[typing.Optional[str]]]

# Generated at 2022-06-17 18:01:43.241236
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Optional[str]
        e: typing.Optional[typing.List[int]]
        f: typing.Optional[typing.List[typing.Optional[int]]]
        g: typing.Optional[typing.List[typing.Optional[str]]]
        h: typing.Optional[typing.List[typing.Optional[int]]]
        i: typing.Optional[typing.List[typing.Optional[str]]]
        j: typing.Optional[typing.List[typing.Optional[int]]]

# Generated at 2022-06-17 18:01:54.806377
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from typing import Optional, List, Union, Dict
    from marshmallow import fields

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: str

    @dataclass
    class C:
        c: Optional[A]

    @dataclass
    class D:
        d: List[A]

    @dataclass
    class E:
        e: Union[A, B]

    @dataclass
    class F:
        f: Dict[str, A]

    @dataclass
    class G:
        g: Union[A, B, C]

    @dataclass
    class H:
        h: Union[A, B, C, D]


# Generated at 2022-06-17 18:02:02.825927
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
        c: float
        d: bool
        e: typing.List[int]
        f: typing.Dict[str, int]
        g: typing.Mapping[str, int]
        h: typing.MutableMapping[str, int]
        i: typing.Tuple[int, int]
        j: typing.Callable[[int], int]
        k: typing.Any
        l: dict
        m: list
        n: str
        o: int
        p: float
        q: bool
        r: datetime
        s: UUID

# Generated at 2022-06-17 18:02:08.353504
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field._serialize(datetime(2020, 1, 1), None, None) == '2020-01-01T00:00:00'
    assert field._deserialize('2020-01-01T00:00:00', None, None) == datetime(2020, 1, 1)


# Generated at 2022-06-17 18:02:16.870232
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int

# Generated at 2022-06-17 18:02:21.755583
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class A:
        a: str
        b: int

    @dataclass_json
    @dataclass
    class B:
        a: A
        b: typing.List[A]

    assert schema(A, dataclass_json, False) == {'a': fields.Str, 'b': fields.Int}
    assert schema(B, dataclass_json, False) == {'a': fields.Nested(A.schema()), 'b': fields.Nested(A.schema(), many=True)}



# Generated at 2022-06-17 18:02:25.492649
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Foo:
        pass

    class FooSchema(SchemaF[Foo]):
        pass

    foo_schema = FooSchema()
    foo_schema.load([{}])
    foo_schema.load({})
    foo_schema.load([{}], many=True)
    foo_schema.load({}, many=False)
    foo_schema.load([{}], many=False)
    foo_schema.load({}, many=True)



# Generated at 2022-06-17 18:02:36.513201
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    schema = FooSchema()
    assert schema.dumps(Foo(a=1, b='b')) == '{"a": 1, "b": "b"}'
    assert schema.dumps([Foo(a=1, b='b'), Foo(a=2, b='c')]) == '[{"a": 1, "b": "b"}, {"a": 2, "b": "c"}]'
    assert schema.dumps(Foo(a=1, b='b'), many=False) == '{"a": 1, "b": "b"}'

# Generated at 2022-06-17 18:02:43.147172
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Person:
        name: str
        age: int

    class PersonSchema(SchemaF[Person]):
        name = fields.Str()
        age = fields.Int()

    schema = PersonSchema()
    person = schema.load({'name': 'Monty', 'age': '42'})
    assert person.name == 'Monty'
    assert person.age == 42
    people = schema.load([{'name': 'Monty', 'age': '42'}, {'name': 'Guido', 'age': '56'}], many=True)
    assert people[0].name == 'Monty'
    assert people[0].age == 42
    assert people[1].name == 'Guido'


# Generated at 2022-06-17 18:04:08.952640
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from typing import Optional
    from marshmallow import fields

    @dataclass
    class A:
        a: int
        b: Optional[int]

    DataClassSchema = build_schema(A, None, False, False)
    assert DataClassSchema.Meta.fields == ('a', 'b')
    assert isinstance(DataClassSchema.a, fields.Int)
    assert isinstance(DataClassSchema.b, fields.Int)
    assert DataClassSchema.b.allow_none
    assert DataClassSchema.b.missing is None



# Generated at 2022-06-17 18:04:12.443190
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 18:04:22.163537
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError
    from dataclasses import dataclass

    @dataclass
    class Foo:
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo_schema = FooSchema()

    assert foo_schema.load({'a': 1, 'b': 'b'}) == Foo(1, 'b')
    assert foo_schema.load([{'a': 1, 'b': 'b'}, {'a': 2, 'b': 'c'}]) == [Foo(1, 'b'), Foo(2, 'c')]

# Generated at 2022-06-17 18:04:33.923536
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str

    @dataclass_json
    @dataclass
    class B:
        a: A

    @dataclass_json
    @dataclass
    class C:
        a: typing.Optional[A]

    @dataclass_json
    @dataclass
    class D:
        a: typing.Optional[typing.List[A]]

    @dataclass_json
    @dataclass
    class E:
        a: typing.Optional[typing.List[typing.Optional[A]]]


# Generated at 2022-06-17 18:04:42.933657
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str
        c: typing.Optional[str]
        d: typing.List[int]
        e: typing.Dict[str, int]
        f: typing.Union[str, int]
        g: typing.Union[str, int, None]
        h: typing.Optional[typing.Union[str, int]]
        i: typing.Optional[typing.Union[str, int, None]]
        j: typing.Optional[typing.Union[str, int, None]] = None
        k: typing.Optional[typing.Union[str, int, None]] = None
        l

# Generated at 2022-06-17 18:04:49.087411
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.utcnow(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.utcnow().timestamp(), None, None) is not None


# Generated at 2022-06-17 18:04:52.924667
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 18:04:59.636474
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from typing import Optional, List, Dict, Union, Any
    from marshmallow import fields
    from marshmallow.exceptions import ValidationError
    from marshmallow_enum import EnumField
    from dataclasses_json.core import _is_optional, _is_collection, _is_new_type, _issubclass_safe
    from dataclasses_json.utils import _get_type_origin
    from dataclasses_json.schema import build_type
    from dataclasses_json.schema import _UnionField
    from dataclasses_json.schema import _TimestampField
    from dataclasses_json.schema import _IsoField
    from dataclasses_json.schema import _TimestampField
    from dataclasses_json.schema import _IsoField

# Generated at 2022-06-17 18:05:06.703057
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses import dataclass
    from typing import List

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: List[A]

    schema = SchemaF[B]()
    assert schema.dumps(B([A(1), A(2)])) == '[{"a": 1}, {"a": 2}]'
    assert schema.dumps(B([A(1)])) == '[{"a": 1}]'
    assert schema.dumps(B([])) == '[]'
    assert schema.dumps(B(None)) == 'null'
    assert schema.dumps(B(None), many=False) == 'null'
    assert schema.dumps(B(None), many=True) == '[]'

# Generated at 2022-06-17 18:05:18.791792
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.Optional[int]
        d: typing.Optional[str] = None
        e: typing.Optional[typing.List[int]] = None
        f: typing.Optional[typing.List[str]] = None
        g: typing.Optional[typing.List[typing.Optional[int]]] = None
        h: typing.Optional[typing.List[typing.Optional[str]]] = None
        i: typing.Optional[typing.List[typing.Optional[typing.List[int]]]] = None