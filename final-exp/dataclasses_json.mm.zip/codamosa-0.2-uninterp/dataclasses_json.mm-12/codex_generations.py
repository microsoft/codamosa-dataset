

# Generated at 2022-06-17 17:56:25.931119
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses import dataclass
    from marshmallow import Schema, fields

    @dataclass
    class Foo:
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    schema = FooSchema()
    foo = schema.load({'a': 1, 'b': 'b'})
    assert foo.a == 1
    assert foo.b == 'b'

    foos = schema.load([{'a': 1, 'b': 'b'}, {'a': 2, 'b': 'c'}])
    assert foos[0].a == 1
    assert foos[0].b == 'b'
    assert foos[1].a == 2

# Generated at 2022-06-17 17:56:37.166750
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from typing import Optional, List, Union, Dict, Tuple, Any

    @dataclass_json
    @dataclass
    class Test:
        field: Optional[int]
        field2: List[int]
        field3: Union[int, str]
        field4: Dict[str, int]
        field5: Tuple[int, str]
        field6: Any

    assert isinstance(build_type(Test.field.type, {}, Test, Test.field, Test),
                      fields.Int)

# Generated at 2022-06-17 17:56:40.643818
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 17:56:48.510253
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses import dataclass
    from marshmallow import fields

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: str

    @dataclass
    class C:
        c: typing.List[A]

    @dataclass
    class D:
        d: typing.List[B]

    @dataclass
    class E:
        e: typing.List[C]

    @dataclass
    class F:
        f: typing.List[D]

    @dataclass
    class G:
        g: typing.List[E]

    @dataclass
    class H:
        h: typing.List[F]

    @dataclass
    class I:
        i: typing.List[G]


# Generated at 2022-06-17 17:56:56.342891
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo = Foo(a=1, b='b')
    assert FooSchema().dumps(foo) == '{"a": 1, "b": "b"}'
    assert FooSchema().dumps([foo]) == '[{"a": 1, "b": "b"}]'



# Generated at 2022-06-17 17:56:58.710584
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field._serialize(datetime.now(), None, None) is not None
    assert field._deserialize(datetime.now().timestamp(), None, None) is not None



# Generated at 2022-06-17 17:57:04.023474
# Unit test for function build_type
def test_build_type():
    import marshmallow as mm
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class A:
        a: int

    @dataclass_json
    @dataclass
    class B:
        a: A

    @dataclass_json
    @dataclass
    class C:
        a: typing.List[A]

    @dataclass_json
    @dataclass
    class D:
        a: typing.List[int]

    @dataclass_json
    @dataclass
    class E:
        a: typing.List[typing.List[int]]


# Generated at 2022-06-17 17:57:09.922455
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields

    class Foo(Schema):
        a = fields.Int()

    class FooF(SchemaF[Foo]):
        pass

    assert FooF().dump(Foo(strict=True).load({'a': 1})) == {'a': 1}
    assert FooF().dump([Foo(strict=True).load({'a': 1})]) == [{'a': 1}]



# Generated at 2022-06-17 17:57:10.981934
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()


# Generated at 2022-06-17 17:57:19.657038
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[int]
        f: typing.Optional[typing.List[int]]
        g: typing.Optional[typing.Dict[str, int]]
        h: typing.Optional[typing.Union[str, int]]
        i: typing.Optional[typing.Union[str, int, typing.List[int]]]
        j: typing.Optional[typing.Union[str, int, typing.List[int], typing.Dict[str, int]]]

# Generated at 2022-06-17 17:57:35.105722
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from typing import Optional

    @dataclass
    class A:
        a: int
        b: Optional[int]
        c: Optional[str]

    DataClassSchema = build_schema(A, None, False, False)
    assert DataClassSchema.Meta.fields == ('a', 'b', 'c')
    assert DataClassSchema().dump(A(1, 2, '3')) == {'a': 1, 'b': 2, 'c': '3'}
    assert DataClassSchema().dump(A(1, None, None)) == {'a': 1, 'b': None, 'c': None}

# Generated at 2022-06-17 17:57:40.260446
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Foo(typing.Generic[A]):
        def __init__(self, a: A):
            self.a = a

    class FooSchema(SchemaF[Foo[int]]):
        a = fields.Int()

    foo = FooSchema().load({'a': 1})
    assert foo.a == 1



# Generated at 2022-06-17 17:57:47.673550
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses import dataclass
    from marshmallow import Schema, fields

    @dataclass
    class Foo:
        bar: str

    class FooSchema(SchemaF[Foo]):
        bar = fields.Str()

    foo = Foo('baz')
    schema = FooSchema()
    assert schema.dump(foo) == {'bar': 'baz'}
    assert schema.dump([foo]) == [{'bar': 'baz'}]
    assert schema.dump([foo], many=True) == [{'bar': 'baz'}]
    assert schema.dump([foo], many=False) == {'bar': 'baz'}
    assert schema.dump(foo, many=True) == {'bar': 'baz'}
    assert schema.dump(foo, many=False)

# Generated at 2022-06-17 17:57:58.829333
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import Schema, fields
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str

# Generated at 2022-06-17 17:58:09.100668
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from typing import Optional, List, Dict, Union, Any

    @dataclass_json
    @dataclass
    class Test:
        a: Optional[int]
        b: List[int]
        c: Dict[str, int]
        d: Union[int, str]
        e: Any

    assert build_type(Test.a.type, {}, dataclass_json.DataClassJsonMixin, Test.a, Test) == fields.Int(allow_none=True)

# Generated at 2022-06-17 17:58:13.752650
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # type: () -> None
    class MySchema(SchemaF[A]):
        pass
    MySchema().load([{'a': 1}], many=True)
    MySchema().load({'a': 1}, many=False)
    MySchema().load({'a': 1})
    MySchema().load([{'a': 1}])
    MySchema().load([{'a': 1}], many=False)
    MySchema().load({'a': 1}, many=True)



# Generated at 2022-06-17 17:58:17.377988
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class User(typing.NamedTuple):
        name: str
        age: int

    class UserSchema(SchemaF[User]):
        name = fields.Str()
        age = fields.Int()

    user = User(name='Monty', age=42)
    schema = UserSchema()
    result = schema.dumps(user)
    assert result == '{"name": "Monty", "age": 42}'



# Generated at 2022-06-17 17:58:29.296752
# Unit test for function build_type
def test_build_type():
    from typing import List, Optional
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from dataclasses_json.core import _UnionField
    from dataclasses_json.utils import _is_optional
    from dataclasses import dataclass
    from enum import Enum

    @dataclass
    class Test:
        pass

    @dataclass
    class Test2:
        pass

    class TestEnum(Enum):
        a = 1
        b = 2

    @dataclass
    class Test3:
        a: List[int]
        b: Optional[str]
        c: Test
        d: TestEnum
        e: typing.Union[Test, Test2]

    assert build_type(Test3.a.type, {}, None, Test3.a, Test3)

# Generated at 2022-06-17 17:58:41.047043
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from typing import Optional, List
    from marshmallow import fields as mm_fields

    @dataclass
    class A:
        a: int
        b: str
        c: Optional[str] = None

    @dataclass
    class B:
        a: A
        b: List[A]

    @dataclass
    class C:
        a: int
        b: str
        c: Optional[str] = None

    @dataclass
    class D:
        a: A
        b: List[A]

    assert build_schema(A, None, False, False) == build_schema(C, None, False, False)
    assert build_schema(B, None, False, False) == build_schema(D, None, False, False)



# Generated at 2022-06-17 17:58:55.058967
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
        c: typing.Optional[str]
        d: typing.Optional[int] = None
        e: typing.Optional[int] = 1
        f: typing.Optional[typing.List[str]] = None
        g: typing.Optional[typing.List[int]] = None
        h: typing.Optional[typing.List[int]] = [1]
        i: typing.Optional[typing.List[typing.Optional[str]]] = None
        j: typing.Optional[typing.List[typing.Optional[int]]] = None
        k: typing.Optional

# Generated at 2022-06-17 17:59:18.693034
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class Test:
        a: str
        b: int

    assert build_schema(Test, None, False, False)


# Generated at 2022-06-17 17:59:21.264059
# Unit test for function build_schema
def test_build_schema():
    class Test:
        def __init__(self, a: int, b: str):
            self.a = a
            self.b = b

    class TestSchema(Schema):
        a = fields.Int()
        b = fields.Str()

    assert build_schema(Test, None, None, None) == TestSchema



# Generated at 2022-06-17 17:59:23.265207
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
    assert build_schema(Test, None, False, False)


# Generated at 2022-06-17 17:59:31.044623
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import List
    from marshmallow import Schema, fields

    class Foo(Schema):
        a = fields.Int()

    class Bar(Schema):
        b = fields.Int()

    class FooBar(SchemaF[List[Foo]]):
        pass

    class FooBar2(SchemaF[Foo]):
        pass

    class FooBar3(SchemaF[Bar]):
        pass

    class FooBar4(SchemaF[List[Bar]]):
        pass

    class FooBar5(SchemaF[List[int]]):
        pass

    class FooBar6(SchemaF[int]):
        pass

    class FooBar7(SchemaF[List[str]]):
        pass

    class FooBar8(SchemaF[str]):
        pass


# Generated at 2022-06-17 17:59:35.227735
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._serialize(datetime.now(), None, None) is not None
    assert _IsoField()._deserialize(datetime.now().isoformat(), None, None) is not None


# Generated at 2022-06-17 17:59:39.540875
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses import dataclass
    @dataclass
    class A:
        a: int
    a = A(1)
    s = SchemaF[A]()
    s.dumps(a)
    s.dumps([a])


# Generated at 2022-06-17 17:59:48.387958
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
    assert build_schema(Test, None, False, False)


# Generated at 2022-06-17 17:59:54.338536
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from typing import List, Optional, Union

    class Color(Enum):
        RED = 1
        GREEN = 2
        BLUE = 3

    @dataclass_json
    @dataclass
    class Foo:
        a: List[int]
        b: Optional[int]
        c: Union[int, str]
        d: Color
        e: Color
        f: Color

    assert build_type(List[int], {}, dataclass_json.DataClassJsonMixin,
                      dc_fields(Foo)[0], Foo) == fields.List(fields.Int())

# Generated at 2022-06-17 18:00:05.074619
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields, post_load
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class Foo:
        a: int
        b: str
    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()
        @post_load
        def make_foo(self, data, **kwargs):
            return Foo(**data)
    foo_schema = FooSchema()
    foo = foo_schema.loads('{"a": 1, "b": "b"}')
    assert foo.a == 1
    assert foo.b == "b"

# Generated at 2022-06-17 18:00:16.176836
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class MySchema(SchemaF[int]):
        pass
    assert MySchema().loads('[1,2,3]', many=True) == [1, 2, 3]
    assert MySchema().loads('[1,2,3]', many=False) == [1, 2, 3]
    assert MySchema().loads('[1,2,3]') == [1, 2, 3]
    assert MySchema().loads('1') == 1
    assert MySchema().loads(b'[1,2,3]', many=True) == [1, 2, 3]
    assert MySchema().loads(b'[1,2,3]', many=False) == [1, 2, 3]

# Generated at 2022-06-17 18:01:06.964060
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    schema = FooSchema()
    assert schema.loads(b'{"a": 1, "b": "foo"}') == Foo(a=1, b='foo')
    assert schema.loads(b'[{"a": 1, "b": "foo"}]') == [Foo(a=1, b='foo')]
    assert schema.loads(b'[{"a": 1, "b": "foo"}, {"a": 2, "b": "bar"}]') == [Foo(a=1, b='foo'), Foo(a=2, b='bar')]

# Generated at 2022-06-17 18:01:16.078605
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import Schema

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str

    class TestSchema(SchemaF[Test]):
        pass

    schema = TestSchema()
    assert schema.loads('{"a": 1, "b": "2"}') == Test(1, "2")
    assert schema.loads('[{"a": 1, "b": "2"}]') == [Test(1, "2")]
    assert schema.loads(b'{"a": 1, "b": "2"}') == Test(1, "2")

# Generated at 2022-06-17 18:01:22.915838
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class TestSchema(SchemaF[A]):
        pass
    assert TestSchema().dump([1, 2, 3]) == [1, 2, 3]
    assert TestSchema().dump(1) == 1
    assert TestSchema().dump([1, 2, 3], many=True) == [1, 2, 3]
    assert TestSchema().dump(1, many=True) == 1
    assert TestSchema().dump([1, 2, 3], many=False) == [1, 2, 3]
    assert TestSchema().dump(1, many=False) == 1

# Generated at 2022-06-17 18:01:30.019092
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._serialize(datetime(2020, 1, 1, 0, 0, 0), None, None) == "2020-01-01T00:00:00"
    assert _IsoField()._deserialize("2020-01-01T00:00:00", None, None) == datetime(2020, 1, 1, 0, 0, 0)


# Generated at 2022-06-17 18:01:38.625870
# Unit test for function build_type
def test_build_type():
    from typing import Optional
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from dataclasses_json.core import _UnionField
    from dataclasses_json.utils import _is_optional
    from dataclasses_json.schema import build_type
    from dataclasses import dataclass
    from enum import Enum

    class TestEnum(Enum):
        A = 1
        B = 2

    @dataclass
    class TestClass:
        pass

    @dataclass
    class TestClass2:
        pass

    @dataclass
    class TestClass3:
        pass

    @dataclass
    class TestClass4:
        pass

    @dataclass
    class TestClass5:
        pass

    @dataclass
    class TestClass6:
        pass

# Generated at 2022-06-17 18:01:48.263994
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from typing import List, Optional, Union

    @dataclass_json
    @dataclass
    class A:
        a: int

    @dataclass_json
    @dataclass
    class B:
        b: str

    @dataclass_json
    @dataclass
    class C:
        c: List[int]

    @dataclass_json
    @dataclass
    class D:
        d: Optional[int]

    @dataclass_json
    @dataclass
    class E:
        e: Union[A, B]

    @dataclass_json
    @dataclass
    class F:
        f: Union[A, B, C]


# Generated at 2022-06-17 18:01:58.604551
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from typing import Optional

    @dataclass_json
    @dataclass
    class Test:
        a: Optional[int]
        b: Optional[int] = None
        c: Optional[int] = None
        d: Optional[int] = None
        e: Optional[int] = None
        f: Optional[int] = None
        g: Optional[int] = None
        h: Optional[int] = None
        i: Optional[int] = None
        j: Optional[int] = None
        k: Optional[int] = None
        l: Optional[int] = None
        m: Optional[int] = None
        n: Optional[int] = None

# Generated at 2022-06-17 18:02:01.649953
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
    assert build_schema(Test, None, False, False)


# Generated at 2022-06-17 18:02:12.557406
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, str]
        e: typing.Optional[int]
        f: typing.Optional[str]
        g: typing.Optional[typing.List[int]]
        h: typing.Optional[typing.Dict[str, str]]
        i: typing.Union[int, str]
        j: typing.Union[int, str, typing.List[int]]
        k: typing.Union[int, str, typing.List[int], typing.Dict[str, str]]
        l: typing.Union

# Generated at 2022-06-17 18:02:22.965305
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema
    from dataclasses import dataclass
    from typing import List
    @dataclass
    class Foo:
        bar: int
    class FooSchema(SchemaF[Foo]):
        bar = fields.Int()
    schema = FooSchema()
    schema.loads('{"bar": 1}')
    schema.loads('[{"bar": 1}]')
    schema.loads('[{"bar": 1}]', many=True)
    schema.loads('[{"bar": 1}]', many=False)
    schema.loads(b'{"bar": 1}')
    schema.loads(b'[{"bar": 1}]')
    schema.loads(b'[{"bar": 1}]', many=True)

# Generated at 2022-06-17 18:04:25.398284
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from typing import Optional, List, Union, Dict, Tuple

    @dataclass_json
    @dataclass
    class Nested:
        a: int

    @dataclass_json
    @dataclass
    class Nested2:
        a: int

    @dataclass_json
    @dataclass
    class Nested3:
        a: int

    @dataclass_json
    @dataclass
    class Nested4:
        a: int

    @dataclass_json
    @dataclass
    class Nested5:
        a: int


# Generated at 2022-06-17 18:04:30.816580
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._serialize(datetime(2020, 1, 1, 0, 0, 0), None, None) == '2020-01-01T00:00:00'
    assert _IsoField()._deserialize('2020-01-01T00:00:00', None, None) == datetime(2020, 1, 1, 0, 0, 0)


# Generated at 2022-06-17 18:04:38.383025
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Optional[int]
        e: typing.Optional[typing.List[int]]
        f: typing.Optional[typing.List[typing.Optional[int]]]
        g: typing.Optional[typing.List[typing.Optional[str]]]
        h: typing.Optional[typing.List[typing.Optional[str]]] = None
        i: typing.Optional[typing.List[typing.Optional[str]]] = []

# Generated at 2022-06-17 18:04:40.629221
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 18:04:54.203362
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str
    assert schema(A, None, False) == {'a': fields.Int(), 'b': fields.Str()}
    assert schema(A, None, True) == {'a': fields.Int(missing=None), 'b': fields.Str(missing=None)}
    assert schema(A, None, False) == {'a': fields.Int(), 'b': fields.Str()}
    assert schema(A, None, True) == {'a': fields.Int(missing=None), 'b': fields.Str(missing=None)}


# Generated at 2022-06-17 18:05:02.894328
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields
    from typing import List
    class User(Schema):
        name = fields.Str()
    class UserF(SchemaF[User]):
        pass
    assert UserF.loads('[{"name": "foo"}]') == [User(name='foo')]
    assert UserF.loads('{"name": "foo"}') == User(name='foo')
    assert UserF.loads(b'[{"name": "foo"}]') == [User(name='foo')]
    assert UserF.loads(b'{"name": "foo"}') == User(name='foo')
    assert UserF.loads(bytearray('[{"name": "foo"}]', 'utf-8')) == [User(name='foo')]

# Generated at 2022-06-17 18:05:06.865830
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses import dataclass
    from marshmallow import Schema, fields

    @dataclass
    class A:
        a: int

    class ASchema(SchemaF[A]):
        a = fields.Integer()

    assert ASchema().load({'a': 1}) == A(1)
    assert ASchema().load([{'a': 1}, {'a': 2}]) == [A(1), A(2)]



# Generated at 2022-06-17 18:05:18.996132
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.List[str]
        e: typing.Dict[str, int]
        f: typing.Dict[str, str]
        g: typing.Optional[int]
        h: typing.Optional[str]
        i: typing.Optional[typing.List[int]]
        j: typing.Optional[typing.List[str]]
        k: typing.Optional[typing.Dict[str, int]]
        l: typing.Optional[typing.Dict[str, str]]
        m: typing.Optional[typing.Optional[int]]
        n: typing.Optional[typing.Optional[str]]

# Generated at 2022-06-17 18:05:22.471880
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 18:05:30.582445
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses import dataclass
    from marshmallow import Schema, fields

    @dataclass
    class Foo:
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo = Foo(1, 'bar')
    schema = FooSchema()
    result = schema.dump(foo)
    assert result == {'a': 1, 'b': 'bar'}

    result = schema.dump([foo])
    assert result == [{'a': 1, 'b': 'bar'}]

