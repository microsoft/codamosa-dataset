

# Generated at 2022-06-17 17:56:16.761855
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class A:
        a: str
        b: int

    @dataclass
    class B:
        a: A
        b: int

    @dataclass
    class C:
        a: typing.List[A]
        b: int

    @dataclass
    class D:
        a: typing.List[A]
        b: typing.List[B]

    @dataclass
    class E:
        a: typing.List[A]
        b: typing.List[B]
        c: typing.List[C]

    @dataclass
    class F:
        a: typing.List[A]
        b: typing.List[B]
        c: typing.List[C]
        d: typing.List[D]


# Generated at 2022-06-17 17:56:26.127701
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Mapping[str, int]
        f: typing.MutableMapping[str, int]
        g: typing.Callable
        h: typing.Any
        i: dict
        j: list
        k: str
        l: int
        m: float
        n: bool
        o: datetime
        p: UUID
        q: Decimal
        r: typing.Optional[CatchAllVar]


# Generated at 2022-06-17 17:56:33.636959
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: float = 1.0


# Generated at 2022-06-17 17:56:44.615955
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
        c: typing.Optional[str]
        d: typing.Optional[int]
        e: typing.Optional[typing.List[int]]
        f: typing.Optional[typing.List[str]]
        g: typing.Optional[typing.List[typing.Optional[str]]]
        h: typing.Optional[typing.List[typing.Optional[int]]]
        i: typing.Optional[typing.List[typing.Optional[typing.List[int]]]]

# Generated at 2022-06-17 17:56:57.051085
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    assert SchemaF.dumps(None, None) == Schema.dumps(None, None)
    assert SchemaF.dumps(None, None, None) == Schema.dumps(None, None, None)
    assert SchemaF.dumps(None, None, None, None) == Schema.dumps(None, None, None, None)
    assert SchemaF.dumps(None, None, None, None, None) == Schema.dumps(None, None, None, None, None)
    assert SchemaF.dumps(None, None, None, None, None, None) == Schema.dumps(None, None, None, None, None, None)

# Generated at 2022-06-17 17:57:05.665775
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields

    class Foo(Schema):
        a = fields.Int()

    assert SchemaF[int]().dump(1) == 1
    assert SchemaF[int]().dump([1, 2, 3]) == [1, 2, 3]
    assert SchemaF[Foo]().dump(Foo().load({'a': 1})) == {'a': 1}
    assert SchemaF[Foo]().dump([Foo().load({'a': 1}), Foo().load({'a': 2})]) == [{'a': 1}, {'a': 2}]
    assert SchemaF[Foo]().dump(Foo().load({'a': 1}), many=False) == {'a': 1}

# Generated at 2022-06-17 17:57:11.545928
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int

    class ASchema(SchemaF[A]):
        a = fields.Int()

    schema = ASchema()
    a = A(1)
    assert schema.dump(a) == {'a': 1}
    assert schema.dump([a]) == [{'a': 1}]



# Generated at 2022-06-17 17:57:17.298113
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from typing import List
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int

    class ASchema(SchemaF[A]):
        a = fields.Int()

    assert ASchema().load({'a': 1}) == A(1)
    assert ASchema().load([{'a': 1}, {'a': 2}]) == [A(1), A(2)]



# Generated at 2022-06-17 17:57:28.358051
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
        c: typing.Optional[str]
        d: typing.Optional[int] = None
        e: typing.Optional[int] = 1
        f: typing.Optional[typing.List[int]] = None
        g: typing.Optional[typing.List[int]] = []
        h: typing.Optional[typing.List[int]] = [1]
        i: typing.Optional[typing.List[int]] = [1, 2]
        j: typing.Optional[typing.List[int]] = [1, 2, 3]

# Generated at 2022-06-17 17:57:39.227690
# Unit test for function schema
def test_schema():
    import marshmallow as mm
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class MyClass:
        a: int
        b: str
        c: float
        d: typing.List[int]
        e: typing.Dict[str, int]
        f: typing.Optional[int]
        g: typing.Optional[str]
        h: typing.Optional[float]
        i: typing.Optional[typing.List[int]]
        j: typing.Optional[typing.Dict[str, int]]
        k: typing.Optional[typing.Optional[int]]
        l: typing.Optional[typing.Optional[str]]
        m: typing.Optional[typing.Optional[float]]
        n

# Generated at 2022-06-17 17:58:02.961674
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.Optional[str]
        d: typing.Optional[int] = None
        e: typing.Optional[typing.List[int]] = None
        f: typing.Optional[typing.List[str]] = None
        g: typing.Optional[typing.List[typing.Optional[str]]] = None
        h: typing.Optional[typing.List[typing.Optional[int]]] = None
        i: typing.Optional[typing.List[typing.Optional[int]]] = None

# Generated at 2022-06-17 17:58:14.015867
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json, config
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[int]
        f: typing.Optional[str]
        g: typing.Optional[typing.List[int]]
        h: typing.Optional[typing.Dict[str, int]]
        i: typing.Optional[typing.Union[int, str]]
        j: typing.Optional[typing.Union[int, str, typing.List[int]]]

# Generated at 2022-06-17 17:58:18.461143
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses import dataclass
    from marshmallow import Schema, fields

    @dataclass
    class Data:
        a: int
        b: str

    class DataSchema(SchemaF[Data]):
        a = fields.Int()
        b = fields.Str()

    data = Data(1, 'a')
    schema = DataSchema()
    assert schema.dumps(data) == '{"a": 1, "b": "a"}'
    assert schema.dumps([data]) == '[{"a": 1, "b": "a"}]'



# Generated at 2022-06-17 17:58:30.158933
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Foo(typing.Generic[A]):
        def __init__(self, a: A):
            self.a = a

    class FooSchema(SchemaF[Foo[int]]):
        a = fields.Int()

    foo = FooSchema().loads('{"a": 1}')
    assert foo.a == 1



# Generated at 2022-06-17 17:58:40.836990
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields

    class MySchema(SchemaF[int]):
        value = fields.Int()

    schema = MySchema()
    assert schema.load({'value': 1}) == 1
    assert schema.load([{'value': 1}, {'value': 2}]) == [1, 2]
    assert schema.load({'value': 1}, many=False) == 1
    assert schema.load([{'value': 1}, {'value': 2}], many=False) == [1, 2]
    assert schema.load({'value': 1}, many=True) == 1
    assert schema.load([{'value': 1}, {'value': 2}], many=True) == [1, 2]



# Generated at 2022-06-17 17:58:48.271339
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[int]
        f: typing.Optional[str]
        g: typing.Optional[typing.List[int]]
        h: typing.Optional[typing.Dict[str, int]]
        i: typing.Optional[typing.Union[int, str]]
        j: typing.Optional[typing.Union[int, str, typing.List[int]]]

# Generated at 2022-06-17 17:58:57.887247
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import Schema, fields, post_load

    @dataclass_json
    @dataclass
    class User:
        name: str
        age: int
        email: str = None
        created_at: datetime = None

    @dataclass_json
    @dataclass
    class User2:
        name: str
        age: int
        email: str = None
        created_at: datetime = None

    @dataclass_json
    @dataclass
    class User3:
        name: str
        age: int
        email: str = None
        created_at: datetime = None


# Generated at 2022-06-17 17:59:06.389309
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[int]
        f: typing.Optional[str]
        g: typing.Optional[typing.List[int]]
        h: typing.Optional[typing.Dict[str, int]]
        i: typing.Optional[typing.Union[int, str]]
        j: typing.Optional[typing.Union[int, str, typing.List[int]]]

# Generated at 2022-06-17 17:59:13.578305
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo = Foo(a=1, b='b')
    assert FooSchema().dumps(foo) == '{"a": 1, "b": "b"}'
    assert FooSchema().dumps([foo]) == '[{"a": 1, "b": "b"}]'



# Generated at 2022-06-17 17:59:24.689173
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json, config
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[str]
        f: typing.Optional[typing.List[int]]
        g: typing.Optional[typing.Dict[str, int]]
        h: typing.Optional[typing.Union[str, int]]
        i: typing.Optional[typing.Union[str, int, typing.List[int]]]

# Generated at 2022-06-17 17:59:53.711904
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from marshmallow.exceptions import ValidationError
    from datetime import datetime
    from uuid import UUID
    from decimal import Decimal
    from enum import Enum
    from typing import Optional, Union, List, Dict, Tuple, Callable, Any, Mapping, MutableMapping

    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
        c: float
        d: bool
        e: datetime
        f: UUID
        g: Decimal
        h: Optional[str]
        i: Optional[int]
        j: Optional[float]

# Generated at 2022-06-17 18:00:04.575328
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from marshmallow.exceptions import ValidationError
    from typing import List, Optional, Union
    from enum import Enum
    from datetime import datetime
    from uuid import UUID
    from decimal import Decimal

    class MyEnum(Enum):
        A = 'a'
        B = 'b'

    @dataclass_json
    @dataclass
    class MyClass:
        a: str
        b: int
        c: float
        d: bool
        e: datetime
        f: UUID
        g: Decimal
        h: MyEnum
        i: Optional[str]
        j: List[int]


# Generated at 2022-06-17 18:00:15.700984
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses import dataclass
    from marshmallow import Schema, fields

    @dataclass
    class Foo:
        a: int

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()

    assert FooSchema().load({'a': 1}) == Foo(1)
    assert FooSchema().load([{'a': 1}]) == [Foo(1)]
    assert FooSchema().load([{'a': 1}, {'a': 2}]) == [Foo(1), Foo(2)]
    assert FooSchema().load([{'a': 1}, {'a': 2}], many=True) == [Foo(1), Foo(2)]

# Generated at 2022-06-17 18:00:28.267268
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # type: () -> None
    class MySchema(SchemaF[int]):
        pass

    assert MySchema().dumps([1, 2, 3]) == '[1, 2, 3]'
    assert MySchema().dumps(1) == '1'
    assert MySchema().dumps(1, many=False) == '1'
    assert MySchema().dumps([1, 2, 3], many=False) == '[1, 2, 3]'
    assert MySchema().dumps(1, many=True) == '1'
    assert MySchema().dumps([1, 2, 3], many=True) == '[1, 2, 3]'
    assert MySchema().dumps(1, many=None) == '1'

# Generated at 2022-06-17 18:00:40.321788
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses import dataclass
    from marshmallow import Schema, fields

    @dataclass
    class Foo:
        bar: int

    class FooSchema(SchemaF[Foo]):
        bar = fields.Int()

    foo = Foo(1)
    foo_schema = FooSchema()
    foo_schema.load(foo_schema.dump(foo))



# Generated at 2022-06-17 18:00:47.785897
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin
    @dataclass
    class A(DataClassJsonMixin):
        a: int
        b: str
    assert build_schema(A, DataClassJsonMixin, False, False)


# Generated at 2022-06-17 18:00:51.473614
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._deserialize('2020-01-01T00:00:00.000000') == datetime(2020, 1, 1, 0, 0)


# Generated at 2022-06-17 18:00:58.047903
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo = Foo(a=1, b='b')
    assert FooSchema().dumps(foo) == '{"a": 1, "b": "b"}'
    assert FooSchema().dumps([foo]) == '[{"a": 1, "b": "b"}]'



# Generated at 2022-06-17 18:01:01.642416
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 18:01:13.882491
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class MySchema(SchemaF[int]):
        pass
    assert MySchema().loads('1') == 1
    assert MySchema().loads('[1]') == [1]
    assert MySchema().loads(b'1') == 1
    assert MySchema().loads(b'[1]') == [1]
    assert MySchema().loads(bytearray('1', 'utf-8')) == 1
    assert MySchema().loads(bytearray('[1]', 'utf-8')) == [1]
    assert MySchema().loads(1) == 1
    assert MySchema().loads([1]) == [1]

# Generated at 2022-06-17 18:02:12.408320
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class MySchema(SchemaF[int]):
        pass
    MySchema().loads('[1, 2, 3]')
    MySchema().loads('1')
    MySchema().loads(b'[1, 2, 3]')
    MySchema().loads(b'1')
    MySchema().loads(bytearray('[1, 2, 3]', 'utf-8'))
    MySchema().loads(bytearray('1', 'utf-8'))

# Generated at 2022-06-17 18:02:22.923124
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.Optional[int]
        d: typing.Optional[str]
        e: typing.Optional[typing.List[int]]
        f: typing.Optional[typing.List[str]]
        g: typing.Optional[typing.List[typing.Optional[int]]]
        h: typing.Optional[typing.List[typing.Optional[str]]]
        i: typing.Optional[typing.List[typing.Optional[typing.List[int]]]]

# Generated at 2022-06-17 18:02:30.000335
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from dataclasses_json.mm import MmSchema

    @dataclass_json
    @dataclass
    class Test:
        a: int

    @dataclass_json
    @dataclass
    class Test2:
        a: Test

    @dataclass_json
    @dataclass
    class Test3:
        a: typing.Optional[Test]

    @dataclass_json
    @dataclass
    class Test4:
        a: typing.Union[Test, Test2]

    @dataclass_json
    @dataclass
    class Test5:
        a: typing.List[Test]


# Generated at 2022-06-17 18:02:39.504229
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.Optional[str]
        d: typing.List[int]
        e: typing.Dict[str, int]
        f: typing.Union[str, int]
        g: typing.Union[str, int, None]
        h: typing.Optional[typing.Union[str, int]]
        i: typing.Optional[typing.Union[str, int, None]]
        j: typing.Optional[typing.Union[str, int, None]] = None
        k: typing.Optional[typing.Union[str, int, None]] = None
        l

# Generated at 2022-06-17 18:02:53.739261
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int

    class ASchema(SchemaF[A]):
        a = fields.Int()

    a = A(1)
    a_schema = ASchema()
    assert a_schema.load(a_schema.dump(a)) == a
    assert a_schema.load(a_schema.dump([a])) == [a]
    try:
        a_schema.load(a_schema.dump(a), many=False)
    except ValidationError:
        pass
    else:
        raise AssertionError()

# Generated at 2022-06-17 18:02:58.173748
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class A:
        a: str
        b: int
    assert build_schema(A, None, False, False) is not None


# Generated at 2022-06-17 18:03:05.262327
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class A(typing.Generic[A]):
        pass

    class B(SchemaF[A]):
        pass

    B().dumps(A())
    B().dumps([A()])
    B().dumps(A(), many=False)
    B().dumps([A()], many=True)
    B().dumps(A(), many=False, foo='bar')
    B().dumps([A()], many=True, foo='bar')


# Generated at 2022-06-17 18:03:14.845459
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class A(typing.Generic[A]):
        def __init__(self, value: A):
            self.value = value

    class A_Schema(SchemaF[A]):
        value = fields.Field()

        @post_load
        def make_a(self, data, **kwargs):
            return A(**data)

    a = A(1)
    assert A_Schema().dump(a) == {'value': 1}
    assert A_Schema().dump([a]) == [{'value': 1}]
    assert A_Schema().dump(a, many=False) == {'value': 1}
    assert A_Schema().dump([a], many=True) == [{'value': 1}]

# Generated at 2022-06-17 18:03:24.685201
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from typing import Union, Optional, List, Dict, Tuple, Any, Callable, Mapping, MutableMapping
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from dataclasses_json.core import _is_supported_generic, _is_collection
    from dataclasses_json.utils import _is_new_type, _get_type_origin, _issubclass_safe, _is_optional
    from dataclasses_json.mm import build_type
    from dataclasses_json.api import mm_field
    from dataclasses_json.mm import Schema
    from dataclasses_json.core import _ExtendedEncoder

    @dataclass
    class Test:
        a: str
        b: int
        c: float
       

# Generated at 2022-06-17 18:03:30.962639
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json, config
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: str = 'c'
        d: str = 'd'
        e: str = 'e'
        f: str = 'f'
        g: str = 'g'
        h: str = 'h'
        i: str = 'i'
        j: str = 'j'
        k: str = 'k'
        l: str = 'l'
        m: str = 'm'
        n: str = 'n'
        o: str = 'o'
        p: str = 'p'
        q: str = 'q'
        r

# Generated at 2022-06-17 18:05:45.150168
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field._serialize(datetime.now(), None, None) is not None
    assert field._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 18:05:50.107174
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import DataClassJsonMixin

    @dataclass
    class A(DataClassJsonMixin):
        a: str

    @dataclass
    class B(DataClassJsonMixin):
        b: str

    @dataclass
    class C(DataClassJsonMixin):
        c: str

    @dataclass
    class D(DataClassJsonMixin):
        d: str

    @dataclass
    class E(DataClassJsonMixin):
        e: str

    @dataclass
    class F(DataClassJsonMixin):
        f: str

    @dataclass
    class G(DataClassJsonMixin):
        g: str
