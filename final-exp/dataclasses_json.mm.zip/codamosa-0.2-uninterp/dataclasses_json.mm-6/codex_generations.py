

# Generated at 2022-06-17 17:56:25.423056
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from dataclasses_json.mm import Schema

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Optional[int]
        e: typing.Optional[typing.List[int]]
        f: typing.Optional[typing.List[int]] = None
        g: typing.Optional[typing.List[int]] = []
        h: typing.Optional[typing.List[int]] = [1, 2, 3]
        i: typing.Optional[typing.List[int]] = None
        j: typing.Optional[typing.List[int]] = []


# Generated at 2022-06-17 17:56:36.382306
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[str]
        f: typing.Optional[int]
        g: typing.Optional[typing.List[int]]
        h: typing.Optional[typing.Dict[str, int]]
        i: typing.Optional[typing.List[typing.Optional[int]]]
        j: typing.Optional[typing.Dict[str, typing.Optional[int]]]
        k: typing.Optional[typing.Union[str, int]]
        l: typing.Optional[typing.Union[typing.List[int], int]]

# Generated at 2022-06-17 17:56:46.096700
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Optional[str]
        e: typing.Optional[typing.List[int]]
        f: typing.Optional[typing.List[typing.Optional[int]]]
        g: typing.Optional[typing.List[typing.Optional[str]]]
        h: typing.Optional[typing.List[typing.Optional[int]]]
        i: typing.Optional[typing.List[typing.Optional[str]]]
        j: typing.Optional[typing.List[typing.Optional[int]]]

# Generated at 2022-06-17 17:56:52.366391
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from typing import List, Optional

    @dataclass
    class A:
        a: int
        b: Optional[str]

    @dataclass
    class B:
        a: A
        b: List[A]

    @dataclass
    class C:
        a: List[A]
        b: Optional[A]

    @dataclass
    class D:
        a: str
        b: Optional[str]

    @dataclass
    class E:
        a: Optional[str]
        b: Optional[str]

    @dataclass
    class F:
        a: Optional[str]
        b: str

    @dataclass
    class G:
        a: Optional[str]
        b: Optional[str]


# Generated at 2022-06-17 17:57:00.969736
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Foo(typing.Generic[A]):
        def __init__(self, a: A):
            self.a = a
    class FooSchema(SchemaF[Foo[int]]):
        a = fields.Int()
    assert FooSchema().loads('{"a": 1}') == Foo(1)
    assert FooSchema().loads('[{"a": 1}]') == [Foo(1)]
    assert FooSchema().loads('[{"a": 1}, {"a": 2}]') == [Foo(1), Foo(2)]
    assert FooSchema().loads('{"a": 1}', many=False) == Foo(1)
    assert FooSchema().loads('[{"a": 1}]', many=False) == Foo(1)

# Generated at 2022-06-17 17:57:05.205047
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field._serialize(datetime.now(), 'attr', 'obj') is not None
    assert field._deserialize('2019-01-01T00:00:00', 'attr', 'data') is not None


# Generated at 2022-06-17 17:57:15.079656
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class A(typing.Generic[A]):
        def load(self, data: typing.List[TEncoded],
                 many: bool = True, partial: bool = None,
                 unknown: str = None) -> \
                typing.List[A]:
            pass

        def load(self, data: TEncoded,
                 many: None = None, partial: bool = None,
                 unknown: str = None) -> A:
            pass

        def load(self, data: TOneOrMultiEncoded,
                 many: bool = None, partial: bool = None,
                 unknown: str = None) -> TOneOrMulti:
            pass

# Generated at 2022-06-17 17:57:17.657230
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 17:57:23.013552
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import Schema, fields

    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
        c: float
        d: bool
        e: typing.List[int]
        f: typing.Dict[str, int]
        g: typing.List[str]
        h: typing.Dict[str, str]
        i: typing.List[typing.List[int]]
        j: typing.Dict[str, typing.List[int]]
        k: typing.List[typing.Dict[str, int]]
        l: typing.Dict[str, typing.Dict[str, int]]

# Generated at 2022-06-17 17:57:27.496167
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Person:
        name: str
        age: int

    class PersonSchema(SchemaF[Person]):
        name = fields.Str()
        age = fields.Int()

    person = Person('John', 42)
    schema = PersonSchema()
    result = schema.dumps(person)
    assert result == '{"name": "John", "age": 42}'


# Generated at 2022-06-17 17:57:54.565534
# Unit test for function build_schema
def test_build_schema():
    class TestClass:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    class TestClass2:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    class TestClass3:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    class TestClass4:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    class TestClass5:
        def __init__(self, a, b):
            self.a = a
            self.b = b

    class TestClass6:
        def __init__(self, a, b):
            self.a = a

# Generated at 2022-06-17 17:58:05.241148
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses import dataclass
    from marshmallow import Schema, fields

    @dataclass
    class A:
        a: int

    class ASchema(SchemaF[A]):
        a = fields.Int()

    assert ASchema().dump(A(1)) == {'a': 1}
    assert ASchema().dump([A(1), A(2)]) == [{'a': 1}, {'a': 2}]
    assert ASchema().dump(A(1), many=False) == {'a': 1}
    assert ASchema().dump([A(1), A(2)], many=True) == [{'a': 1}, {'a': 2}]

# Generated at 2022-06-17 17:58:15.563749
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Foo(typing.Generic[A]):
        def __init__(self, a: A):
            self.a = a

    class FooSchema(SchemaF[Foo[int]]):
        a = fields.Int()

    assert FooSchema().loads('{"a": 1}') == Foo(1)
    assert FooSchema().loads('[{"a": 1}]') == [Foo(1)]
    assert FooSchema().loads('[{"a": 1}, {"a": 2}]') == [Foo(1), Foo(2)]
    assert FooSchema().loads('{"a": 1}', many=False) == Foo(1)
    assert FooSchema().loads('[{"a": 1}]', many=False) == Foo(1)

# Generated at 2022-06-17 17:58:22.265358
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_dataclass import class_schema
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
    assert build_schema(Test, None, False, False) == class_schema(Test)
    assert build_schema(Test, None, False, False).__name__ == 'TestSchema'
    assert build_schema(Test, None, False, False).Meta.fields == ('a', 'b')
    assert build_schema(Test, None, False, False).a == fields.Integer()
    assert build_schema(Test, None, False, False).b == fields.String()
    assert build_schema

# Generated at 2022-06-17 17:58:28.472507
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo(typing.Generic[A]):
        def __init__(self, a: A):
            self.a = a

    class FooSchema(SchemaF[Foo[int]]):
        a = fields.Int()

    foo = Foo(1)
    assert FooSchema().dumps(foo) == '{"a": 1}'



# Generated at 2022-06-17 17:58:40.553827
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from typing import Optional, List, Dict, Union, Any

    @dataclass
    class Test:
        a: Optional[int]
        b: List[int]
        c: Dict[str, int]
        d: Union[int, str]
        e: Any

    assert isinstance(build_type(Test.a.type, {}, None, Test.a, Test), fields.Int)
    assert isinstance(build_type(Test.b.type, {}, None, Test.b, Test), fields.List)
    assert isinstance(build_type(Test.c.type, {}, None, Test.c, Test), fields.Dict)
    assert isinstance(build_type(Test.d.type, {}, None, Test.d, Test), _UnionField)


# Generated at 2022-06-17 17:58:54.863130
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int
        b: str

    class ASchema(SchemaF[A]):
        a = fields.Int()
        b = fields.Str()

    a = A(1, 'a')
    schema = ASchema()
    assert schema.dumps(a) == '{"a": 1, "b": "a"}'
    assert schema.dumps([a]) == '[{"a": 1, "b": "a"}]'
    assert schema.dumps([a, a]) == '[{"a": 1, "b": "a"}, {"a": 1, "b": "a"}]'

# Generated at 2022-06-17 17:59:01.099251
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class Test:
        a: str
        b: int
        c: typing.Optional[str]
        d: typing.Optional[int]
        e: typing.Optional[typing.List[int]]
        f: typing.Optional[typing.List[str]]
        g: typing.Optional[typing.List[typing.Optional[int]]]
        h: typing.Optional[typing.List[typing.Optional[str]]]
        i: typing.Optional[typing.List[typing.Optional[typing.List[int]]]]
        j: typing.Optional[typing.List[typing.Optional[typing.List[str]]]]
        k: typing.Optional[typing.List[typing.Optional[typing.List[typing.Optional[int]]]]]
        l

# Generated at 2022-06-17 17:59:05.252223
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field._serialize(datetime.now(), None, None) is not None
    assert field._deserialize(datetime.now().timestamp(), None, None) is not None
    assert field._serialize(None, None, None) is None
    assert field._deserialize(None, None, None) is None


# Generated at 2022-06-17 17:59:08.438134
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 17:59:44.788799
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses import dataclass
    @dataclass
    class A:
        a: int
    @dataclass
    class B:
        b: int
    @dataclass
    class C:
        c: typing.Union[A, B]
    s = SchemaF[C]()
    assert s.dump([C(A(1)), C(B(2))]) == [{'c': {'a': 1}}, {'c': {'b': 2}}]
    assert s.dump(C(A(1))) == {'c': {'a': 1}}
    assert s.dump(C(B(2))) == {'c': {'b': 2}}

# Generated at 2022-06-17 17:59:52.149613
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class A:
        a: int

    @dataclass_json
    @dataclass
    class B:
        b: A

    @dataclass_json
    @dataclass
    class C:
        c: typing.List[A]

    @dataclass_json
    @dataclass
    class D:
        d: typing.List[B]

    @dataclass_json
    @dataclass
    class E:
        e: typing.List[C]

    @dataclass_json
    @dataclass
    class F:
        f: typing.List[D]


# Generated at 2022-06-17 18:00:03.798520
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    from dataclasses import dataclass
    from typing import List
    @dataclass
    class A:
        a: int
    @dataclass
    class B:
        b: List[A]
    class ASchema(SchemaF[A]):
        a = fields.Int()
    class BSchema(SchemaF[B]):
        b = fields.Nested(ASchema, many=True)
    b = B([A(1), A(2)])
    b_schema = BSchema()
    b_encoded = b_schema.dump(b)
    b_decoded = b_schema.load(b_encoded)
    assert b == b_decoded


# Generated at 2022-06-17 18:00:07.924959
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 18:00:14.757633
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Foo:
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo = Foo(1, 'b')
    schema = FooSchema()
    res = schema.dump(foo)
    assert res == {'a': 1, 'b': 'b'}



# Generated at 2022-06-17 18:00:16.295665
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 18:00:21.154164
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[int]
        f: typing.Optional[str]
        g: typing.Optional[typing.List[int]]
        h: typing.Optional[typing.Dict[str, int]]
        i: typing.Optional[typing.Union[str, int]]
        j: typing.Optional[typing.Union[str, int, typing.List[int]]]

# Generated at 2022-06-17 18:00:30.584894
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str

    @dataclass_json
    @dataclass
    class B:
        a: A
        b: typing.List[A]

    assert schema(A, dataclass_json.DataClassJsonMixin, False) == {
        'a': fields.Integer(),
        'b': fields.String()
    }


# Generated at 2022-06-17 18:00:41.095717
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field.deserialize(None) is None
    assert field.deserialize(1579098200) == datetime(2020, 1, 17, 9, 30)
    assert field.serialize(datetime(2020, 1, 17, 9, 30)) == 1579098200
    assert field.serialize(None) is None
    assert field.serialize(datetime(2020, 1, 17, 9, 30), required=True) == 1579098200
    assert field.serialize(None, required=True) is None
    assert field.serialize(None, required=True) is None
    try:
        field.serialize(None, required=True)
    except ValidationError as e:
        assert e.messages == {'required': ['Missing data for required field.']}


# Generated at 2022-06-17 18:00:44.118569
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Foo:
        bar: int

    class FooSchema(SchemaF[Foo]):
        bar = fields.Int()

    schema = FooSchema()
    assert schema.dump(Foo(1)) == {'bar': 1}
    assert schema.dump([Foo(1), Foo(2)]) == [{'bar': 1}, {'bar': 2}]



# Generated at 2022-06-17 18:02:19.031978
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field._serialize(datetime(2020, 1, 1), None, None) == "2020-01-01T00:00:00"
    assert field._deserialize("2020-01-01T00:00:00", None, None) == datetime(2020, 1, 1)


# Generated at 2022-06-17 18:02:27.852149
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Union[str, int]
        f: typing.Optional[int]
        g: typing.Optional[typing.List[int]]
        h: typing.Optional[typing.Dict[str, int]]
        i: typing.Optional[typing.Union[str, int]]
        j: typing.Optional[typing.Optional[int]]
        k: typing.Optional[typing.Optional[typing.List[int]]]

# Generated at 2022-06-17 18:02:38.357396
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses import dataclass
    from marshmallow import fields

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: str

    class A_Schema(SchemaF[A]):
        a = fields.Int()

    class B_Schema(SchemaF[B]):
        b = fields.Str()

    a_schema = A_Schema()
    b_schema = B_Schema()

    assert a_schema.dump(A(1)) == {'a': 1}
    assert b_schema.dump(B('b')) == {'b': 'b'}

    assert a_schema.dump([A(1), A(2)]) == [{'a': 1}, {'a': 2}]
   

# Generated at 2022-06-17 18:02:41.405496
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 18:02:54.747207
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.Optional[str]
        d: typing.Optional[int] = None
        e: typing.Optional[typing.List[int]] = None
        f: typing.Optional[typing.List[str]] = None
        g: typing.Optional[typing.List[typing.Optional[str]]] = None
        h: typing.Optional[typing.List[typing.Optional[int]]] = None
        i: typing.Optional[typing.List[typing.Optional[typing.List[int]]]] = None

# Generated at 2022-06-17 18:03:06.165835
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from dataclasses_json.schema import SchemaF

    @dataclass_json
    @dataclass
    class A:
        a: int

    @dataclass_json
    @dataclass
    class B:
        b: int

    @dataclass_json
    @dataclass
    class C:
        c: typing.Union[A, B]

    class C_Schema(SchemaF[C]):
        c = fields.Nested(SchemaF[typing.Union[A, B]])

    c_schema = C_Schema()


# Generated at 2022-06-17 18:03:15.263816
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    class MySchema(SchemaF[int]):
        a = fields.Int()
    s = MySchema()
    assert s.load({'a': 1}) == 1
    assert s.load([{'a': 1}, {'a': 2}]) == [1, 2]
    assert s.load({'a': 1}, many=False) == 1
    assert s.load([{'a': 1}, {'a': 2}], many=False) == [1, 2]
    assert s.load({'a': 1}, many=True) == 1
    assert s.load([{'a': 1}, {'a': 2}], many=True) == [1, 2]
    assert s.load({'a': 1}, many=None) == 1
    assert s.load

# Generated at 2022-06-17 18:03:18.881524
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._serialize(datetime.now(), None, None) is not None
    assert _IsoField()._deserialize(datetime.now().isoformat(), None, None) is not None


# Generated at 2022-06-17 18:03:27.129254
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from enum import Enum

    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
        c: Enum
        d: typing.Optional[int]
        e: typing.Optional[typing.List[int]]
        f: typing.Optional[typing.List[typing.Optional[int]]]
        g: typing.Optional[typing.Dict[str, int]]
        h: typing.Optional[typing.Dict[str, typing.Optional[int]]]
        i: typing.Optional[typing.Union[int, str]]

# Generated at 2022-06-17 18:03:32.329526
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._deserialize("2020-01-01T00:00:00") == datetime(2020, 1, 1, 0, 0, 0)
    assert _IsoField()._serialize(datetime(2020, 1, 1, 0, 0, 0)) == "2020-01-01T00:00:00"


# Generated at 2022-06-17 18:05:42.349723
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from typing import Optional, Union, List, Dict, Tuple, Callable, Any, Mapping, MutableMapping

    @dataclass
    class A:
        pass

    @dataclass
    class B:
        pass

    @dataclass
    class C:
        pass

    @dataclass
    class D:
        pass

    @dataclass
    class E:
        pass

    @dataclass
    class F:
        pass

    @dataclass
    class G:
        pass

    @dataclass
    class H:
        pass

    @dataclass
    class I:
        pass

    @dataclass
    class J:
        pass

    @dataclass
    class K:
        pass


# Generated at 2022-06-17 18:05:53.965716
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class MyData:
        a: str

    class MySchema(SchemaF[MyData]):
        a = fields.Str()

    s = MySchema()
    s.loads('{"a": "foo"}')
    s.loads(b'{"a": "foo"}')
    s.loads(bytearray(b'{"a": "foo"}'))
    s.loads([b'{"a": "foo"}'])
    s.loads([bytearray(b'{"a": "foo"}')])
    s.loads([{"a": "foo"}])
    s.loads([{"a": "foo"}, {"a": "bar"}])

