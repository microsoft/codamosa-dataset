

# Generated at 2022-06-17 17:56:20.771065
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Foo:
        def __init__(self, x: int):
            self.x = x

    class FooSchema(SchemaF[Foo]):
        x = fields.Int()

        @post_load
        def make_foo(self, data, **kwargs):
            return Foo(**data)

    schema = FooSchema()
    foo = schema.load({'x': 42})
    assert foo.x == 42



# Generated at 2022-06-17 17:56:23.469378
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 17:56:32.992480
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from typing import List, Optional, Union

    class Color(Enum):
        RED = 1
        GREEN = 2
        BLUE = 3

    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
        c: Optional[str]
        d: List[str]
        e: Union[int, str]
        f: Color

    assert build_type(Test, {}, None, None, None) == fields.Nested
    assert build_type(List[Test], {}, None, None, None) == fields.Nested

# Generated at 2022-06-17 17:56:44.004985
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo = Foo(1, 'bar')
    foo_schema = FooSchema()
    assert foo_schema.dump(foo) == {'a': 1, 'b': 'bar'}
    assert foo_schema.dump([foo]) == [{'a': 1, 'b': 'bar'}]
    assert foo_schema.dump(foo, many=False) == {'a': 1, 'b': 'bar'}
    assert foo_schema.dump([foo], many=True) == [{'a': 1, 'b': 'bar'}]

# Generated at 2022-06-17 17:56:50.496819
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: str

    @dataclass
    class C:
        c: typing.List[A]

    @dataclass
    class D:
        d: typing.List[B]

    @dataclass
    class E:
        e: typing.List[C]

    @dataclass
    class F:
        f: typing.List[D]

    @dataclass
    class G:
        g: typing.List[E]

    @dataclass
    class H:
        h: typing.List[F]

    @dataclass
    class I:
        i: typing.List[G]


# Generated at 2022-06-17 17:56:54.463929
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class TestSchema(SchemaF[int]):
        pass

    assert TestSchema().load([1, 2, 3]) == [1, 2, 3]
    assert TestSchema().load(1) == 1



# Generated at 2022-06-17 17:57:02.773427
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class MySchema(SchemaF[A]):
        pass

    assert MySchema().dumps([1, 2, 3]) == '[1, 2, 3]'
    assert MySchema().dumps(1) == '1'
    assert MySchema().dumps([1, 2, 3], many=True) == '[1, 2, 3]'
    assert MySchema().dumps(1, many=False) == '1'
    assert MySchema().dumps([1, 2, 3], many=False) == '[1, 2, 3]'
    assert MySchema().dumps(1, many=True) == '1'
    assert MySchema().dumps([1, 2, 3], many=None) == '[1, 2, 3]'

# Generated at 2022-06-17 17:57:12.621565
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from dataclasses_json.mm import Schema
    from dataclasses_json.utils import _is_new_type

    class MyEnum(Enum):
        ONE = 1
        TWO = 2

    @dataclass_json
    @dataclass
    class MyClass:
        my_field: int

    @dataclass_json
    @dataclass
    class MyClass2:
        my_field: MyClass

    @dataclass_json
    @dataclass
    class MyClass3:
        my_field: typing.Optional[MyClass]


# Generated at 2022-06-17 17:57:18.807733
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class User:
        name: str
        age: int

    class UserSchema(SchemaF[User]):
        name = fields.Str()
        age = fields.Int()

    user_schema = UserSchema()
    user = user_schema.load({'name': 'Monty', 'age': '42'})
    assert user.name == 'Monty'
    assert user.age == 42

# Generated at 2022-06-17 17:57:29.888995
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass, field
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from marshmallow.exceptions import ValidationError
    from dataclasses_json.core import _is_optional, _is_new_type, _is_collection, _get_type_origin
    from dataclasses_json.utils import _issubclass_safe
    from typing import Optional, List, Union, Dict, Any, Tuple, Callable, Mapping, MutableMapping
    from datetime import datetime
    from uuid import UUID
    from decimal import Decimal
    from enum import Enum
    from typing_inspect import is_union_type
    import typing
    import sys
    from dataclasses_json.utils import CatchAll

# Generated at 2022-06-17 17:57:49.142876
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses import dataclass
    from marshmallow import fields
    from typing import List

    @dataclass
    class Foo:
        a: int

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()

    foo = Foo(1)
    assert FooSchema().dump(foo) == {'a': 1}
    assert FooSchema().dump([foo]) == [{'a': 1}]
    assert FooSchema().dump(foo, many=False) == {'a': 1}
    assert FooSchema().dump([foo], many=False) == [{'a': 1}]
    assert FooSchema().dump(foo, many=True) == {'a': 1}
    assert FooSchema().dump([foo], many=True) == [{'a': 1}]

# Generated at 2022-06-17 17:58:01.189781
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError
    from marshmallow.validate import OneOf

    @dataclass_json
    @dataclass
    class Person:
        name: str
        age: int
        gender: str

    @dataclass_json
    @dataclass
    class PersonSchema(Schema):
        name: str
        age: int
        gender: str

    @dataclass_json
    @dataclass
    class PersonSchema2(Schema):
        name: str
        age: int
        gender: str

    @dataclass_json
    @dataclass
    class PersonSchema3(Schema):
        name: str

# Generated at 2022-06-17 17:58:09.095149
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[int]
        f: typing.Optional[str]
        g: typing.Optional[typing.List[int]]
        h: typing.Optional[typing.Dict[str, int]]
        i: typing.Optional[typing.Union[int, str]]
        j: typing.Optional[typing.Union[int, str, typing.List[int]]]

# Generated at 2022-06-17 17:58:18.309049
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from typing import Optional, Union, List, Dict, Tuple
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from dataclasses_json.core import _is_optional, _is_new_type, _is_collection
    from dataclasses_json.utils import _issubclass_safe
    from dataclasses_json.mm import _UnionField

    @dataclass
    class A:
        pass

    @dataclass
    class B:
        pass

    @dataclass
    class C:
        pass

    @dataclass
    class D:
        pass

    @dataclass
    class E:
        pass

    @dataclass
    class F:
        pass

    @dataclass
    class G:
        pass

# Generated at 2022-06-17 17:58:30.016222
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields
    class Foo(Schema):
        a = fields.Int()
    assert SchemaF[Foo]().loads('{"a": 1}') == Foo(a=1)
    assert SchemaF[Foo]().loads('[{"a": 1}]') == [Foo(a=1)]
    assert SchemaF[Foo]().loads(b'{"a": 1}') == Foo(a=1)
    assert SchemaF[Foo]().loads(b'[{"a": 1}]') == [Foo(a=1)]
    assert SchemaF[Foo]().loads(bytearray(b'{"a": 1}')) == Foo(a=1)

# Generated at 2022-06-17 17:58:40.320147
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # type: () -> None
    class Foo:
        pass

    class FooSchema(SchemaF[Foo]):
        pass

    assert FooSchema().dumps([Foo(), Foo()]) == "[{}, {}]"
    assert FooSchema().dumps(Foo()) == "{}"
    assert FooSchema().dumps([Foo(), Foo()], many=True) == "[{}, {}]"
    assert FooSchema().dumps(Foo(), many=False) == "{}"
    assert FooSchema().dumps([Foo(), Foo()], many=False) == "[{}, {}]"
    assert FooSchema().dumps(Foo(), many=True) == "{}"



# Generated at 2022-06-17 17:58:54.740903
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        a: int
        b: str

    @dataclass
    class C:
        a: int
        b: str
        c: A

    @dataclass
    class D:
        a: int
        b: str
        c: A
        d: B

    @dataclass
    class E:
        a: int
        b: str
        c: A
        d: B
        e: C

    @dataclass
    class F:
        a: int
        b: str
        c: A
        d: B
        e: C
        f: D

    @dataclass
    class G:
        a: int
        b

# Generated at 2022-06-17 17:59:04.434595
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str
        c: typing.Optional[str] = None
        d: typing.Optional[int] = None
        e: typing.Optional[typing.List[str]] = None
        f: typing.Optional[typing.List[int]] = None
        g: typing.Optional[typing.List[typing.Optional[str]]] = None
        h: typing.Optional[typing.List[typing.Optional[int]]] = None
        i: typing.Optional[typing.List[typing.Optional[A]]] = None

# Generated at 2022-06-17 17:59:15.219567
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class MySchema(SchemaF[int]):
        pass
    MySchema().loads('[1, 2, 3]')
    MySchema().loads('1')
    MySchema().loads(b'[1, 2, 3]')
    MySchema().loads(b'1')
    MySchema().loads(bytearray('[1, 2, 3]', 'utf-8'))
    MySchema().loads(bytearray('1', 'utf-8'))

# Generated at 2022-06-17 17:59:24.690678
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class TestSchema(SchemaF[A]):
        pass
    assert TestSchema().dump([1, 2, 3]) == [1, 2, 3]
    assert TestSchema().dump(1) == 1
    assert TestSchema().dump([1, 2, 3], many=True) == [1, 2, 3]
    assert TestSchema().dump(1, many=False) == 1
    assert TestSchema().dump([1, 2, 3], many=False) == [1, 2, 3]
    assert TestSchema().dump(1, many=True) == 1


# Generated at 2022-06-17 17:59:54.502849
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class TestSchema(SchemaF[A]):
        pass
    TestSchema().load([{'a': 1}], many=True)
    TestSchema().load({'a': 1}, many=False)
    TestSchema().load({'a': 1})
    TestSchema().load([{'a': 1}])
    TestSchema().load({'a': 1}, many=True)
    TestSchema().load([{'a': 1}], many=False)
    TestSchema().load({'a': 1}, many=None)
    TestSchema().load([{'a': 1}], many=None)
    TestSchema().load({'a': 1}, many=None)
    TestSchema().load([{'a': 1}], many=None)

# Generated at 2022-06-17 18:00:05.187899
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._deserialize("2020-01-01T00:00:00") == datetime(2020, 1, 1, 0, 0, 0)
    assert _IsoField()._deserialize("2020-01-01T00:00:00+00:00") == datetime(2020, 1, 1, 0, 0, 0)
    assert _IsoField()._deserialize("2020-01-01T00:00:00-00:00") == datetime(2020, 1, 1, 0, 0, 0)
    assert _IsoField()._deserialize("2020-01-01T00:00:00+01:00") == datetime(2020, 1, 1, 0, 0, 0)

# Generated at 2022-06-17 18:00:08.224772
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._deserialize('2020-01-01T00:00:00') == datetime(2020, 1, 1)


# Generated at 2022-06-17 18:00:17.991505
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from typing import Optional, List, Dict, Union
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from dataclasses_json.mm_schema import build_type
    from dataclasses_json.utils import _is_optional, _is_collection
    from dataclasses_json.core import _is_new_type
    from dataclasses_json.utils import _issubclass_safe
    from dataclasses_json.core import _is_supported_generic
    from dataclasses_json.core import _is_dataclass
    from dataclasses_json.core import _is_union_type
    from dataclasses_json.core import _get_type_origin
    from dataclasses_json.core import _is_optional

# Generated at 2022-06-17 18:00:26.651800
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo_schema = FooSchema()
    foo = Foo(a=1, b='b')
    foo_encoded = foo_schema.dumps(foo)
    assert foo_encoded == '{"a": 1, "b": "b"}'



# Generated at 2022-06-17 18:00:32.949302
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field._serialize(datetime(2020, 1, 1), None, None) == '2020-01-01T00:00:00'
    assert field._deserialize('2020-01-01T00:00:00', None, None) == datetime(2020, 1, 1)


# Generated at 2022-06-17 18:00:42.441563
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: str

    @dataclass
    class C:
        c: typing.List[A]

    @dataclass
    class D:
        d: typing.List[B]

    @dataclass
    class E:
        e: typing.List[C]

    @dataclass
    class F:
        f: typing.List[D]

    @dataclass
    class G:
        g: typing.List[E]

    @dataclass
    class H:
        h: typing.List[F]

    @dataclass
    class I:
        i: typing.List[G]


# Generated at 2022-06-17 18:00:43.971721
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 18:00:55.112238
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo = Foo(a=1, b='2')
    foo_schema = FooSchema()
    assert foo_schema.dumps(foo) == '{"a": 1, "b": "2"}'
    assert foo_schema.dumps([foo]) == '[{"a": 1, "b": "2"}]'
    assert foo_schema.dumps([foo], many=True) == '[{"a": 1, "b": "2"}]'
    assert foo_schema.dumps(foo, many=False) == '{"a": 1, "b": "2"}'
    assert foo_

# Generated at 2022-06-17 18:01:00.769295
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclass_json
    @dataclass
    class Foo:
        a: int

    schema = SchemaF[Foo]()
    assert schema.dumps(Foo(1)) == '{"a": 1}'
    assert schema.dumps([Foo(1), Foo(2)]) == '[{"a": 1}, {"a": 2}]'


# Generated at 2022-06-17 18:01:59.735293
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import List
    from marshmallow import Schema, fields

    class UserSchema(Schema):
        name = fields.Str()

    class User:
        def __init__(self, name):
            self.name = name

    user = User('John')
    schema = SchemaF[User](UserSchema)
    assert schema.dump(user) == {'name': 'John'}
    assert schema.dump([user]) == [{'name': 'John'}]
    assert schema.dump([user], many=True) == [{'name': 'John'}]
    assert schema.dump(user, many=False) == {'name': 'John'}
    assert schema.dump([user], many=False) == [{'name': 'John'}]



# Generated at 2022-06-17 18:02:11.676509
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Mapping[str, int]
        f: typing.MutableMapping[str, int]
        g: typing.Tuple[int, str]
        h: typing.Callable
        i: typing.Any
        j: dict
        k: list
        l: str
        m: int
        n: float
        o: bool
        p: datetime
        q: UUID
        r: Decimal
        s: typing.Optional[CatchAllVar]

# Generated at 2022-06-17 18:02:18.365693
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses import dataclass
    from marshmallow import Schema, fields

    @dataclass
    class A:
        a: int

    class ASchema(SchemaF[A]):
        a = fields.Int()

    assert ASchema().dumps(A(1)) == '{"a": 1}'
    assert ASchema().dumps([A(1), A(2)]) == '[{"a": 1}, {"a": 2}]'


# Generated at 2022-06-17 18:02:27.476323
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from typing import List, Optional
    from marshmallow import fields
    from marshmallow_dataclass import class_schema

    @dataclass
    class Test:
        a: str
        b: int
        c: List[int]
        d: Optional[int]
        e: Optional[str]
        f: Optional[List[int]]

    schema = class_schema(Test)
    assert isinstance(schema.declared_fields['a'], fields.String)
    assert isinstance(schema.declared_fields['b'], fields.Integer)
    assert isinstance(schema.declared_fields['c'], fields.List)
    assert isinstance(schema.declared_fields['d'], fields.Integer)

# Generated at 2022-06-17 18:02:38.317210
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: float
        d: bool
        e: typing.List[int]
        f: typing.List[str]
        g: typing.List[float]
        h: typing.List[bool]
        i: typing.List[typing.List[int]]
        j: typing.List[typing.List[str]]
        k: typing.List[typing.List[float]]
        l: typing.List[typing.List[bool]]
        m: typing.Optional[int]
        n: typing.Optional[str]
        o: typing.Optional[float]

# Generated at 2022-06-17 18:02:41.676959
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class TestSchema(SchemaF[A]):
        pass

    assert TestSchema().dumps([1, 2, 3]) == '[1, 2, 3]'
    assert TestSchema().dumps(1) == '1'



# Generated at 2022-06-17 18:02:48.095429
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Foo(typing.Generic[A]):
        def __init__(self, a: A):
            self.a = a

    class FooSchema(SchemaF[Foo[int]]):
        a = fields.Int()

    assert FooSchema().loads('{"a": 1}') == Foo(1)
    assert FooSchema().loads('[{"a": 1}]') == [Foo(1)]
    assert FooSchema().loads('[{"a": 1}, {"a": 2}]') == [Foo(1), Foo(2)]



# Generated at 2022-06-17 18:02:57.258428
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields
    from dataclasses import dataclass
    @dataclass
    class User:
        name: str
        age: int
    class UserSchema(SchemaF[User]):
        name = fields.Str()
        age = fields.Int()
    user = User('John', 30)
    schema = UserSchema()
    result = schema.dumps(user)
    assert result == '{"name": "John", "age": 30}'
    result = schema.dumps([user])
    assert result == '[{"name": "John", "age": 30}]'


# Generated at 2022-06-17 18:03:09.241304
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json, config
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from enum import Enum

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[int]
        f: typing.Optional[str]
        g: typing.Optional[typing.List[int]]
        h: typing.Optional[typing.Dict[str, int]]
        i: typing.Union[int, str]
        j: typing.Union[int, str, typing.List[int]]

# Generated at 2022-06-17 18:03:12.358300
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field._serialize(datetime.now(), None, None) is not None
    assert field._deserialize(datetime.now().isoformat(), None, None) is not None


# Generated at 2022-06-17 18:05:31.980991
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields
    from dataclasses import dataclass
    from typing import List

    @dataclass
    class User:
        name: str
        age: int

    class UserSchema(Schema):
        name = fields.Str()
        age = fields.Int()

    class UserListSchema(SchemaF[User]):
        users = fields.Nested(UserSchema, many=True)

    schema = UserListSchema()
    data = schema.loads('{"users": [{"name": "foo", "age": 42}]}')
    assert data.users[0].name == "foo"
    assert data.users[0].age == 42



# Generated at 2022-06-17 18:05:37.074241
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 18:05:44.392253
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Foo:
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo = Foo(a=1, b='b')
    schema = FooSchema()
    assert schema.dumps(foo) == '{"a": 1, "b": "b"}'
    assert schema.dumps([foo]) == '[{"a": 1, "b": "b"}]'
    assert schema.dumps(foo, many=False) == '{"a": 1, "b": "b"}'
    assert schema.dumps([foo], many=False) == '[{"a": 1, "b": "b"}]'
   

# Generated at 2022-06-17 18:05:55.961109
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from typing import List
    from marshmallow import Schema, fields

    class Foo(Schema):
        bar = fields.Str()

    class FooSchema(SchemaF[Foo]):
        pass

    foo_schema = FooSchema()
    foo_schema.load([{'bar': 'baz'}, {'bar': 'baz'}])
    foo_schema.load({'bar': 'baz'})
    foo_schema.load({'bar': 'baz'}, many=True)
    foo_schema.load([{'bar': 'baz'}, {'bar': 'baz'}], many=False)
    foo_schema.load([{'bar': 'baz'}, {'bar': 'baz'}], many=True)