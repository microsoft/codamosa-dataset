

# Generated at 2022-06-17 17:56:18.466396
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str
        c: typing.List[int]
        d: typing.List[str]
        e: typing.Optional[str]
        f: typing.Optional[typing.List[str]]
        g: typing.Optional[typing.List[int]]
        h: typing.Optional[typing.List[int]] = None
        i: typing.Optional[typing.List[int]] = []
        j: typing.Optional[typing.List[int]] = [1, 2, 3]
        k: typing.Optional[typing.List[int]] = [1, 2, 3]

# Generated at 2022-06-17 17:56:19.860944
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 17:56:27.908021
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import Schema, fields
    from marshmallow.validate import OneOf

    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int

    @dataclass_json
    @dataclass
    class Test2(Test):
        c: float

    @dataclass_json
    @dataclass
    class Test3(Test2):
        d: bool

    @dataclass_json
    @dataclass
    class Test4(Test3):
        e: Test

    @dataclass_json
    @dataclass
    class Test5(Test4):
        f: Test2


# Generated at 2022-06-17 17:56:36.534503
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str

    @dataclass_json
    @dataclass
    class B:
        a: A
        b: str

    assert schema(B, dataclass_json.M, False) == {'a': fields.Nested(A.schema()), 'b': fields.Str()}



# Generated at 2022-06-17 17:56:41.665343
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: str

    class ASchema(SchemaF[A]):
        a = fields.Int()

    class BSchema(SchemaF[B]):
        b = fields.Str()

    a = A(a=1)
    b = B(b='b')
    assert ASchema().dump(a) == {'a': 1}
    assert BSchema().dump(b) == {'b': 'b'}
    assert ASchema().dump([a, a]) == [{'a': 1}, {'a': 1}]

# Generated at 2022-06-17 17:56:49.184948
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class A:
        a: str
        b: int
        c: typing.Optional[str]
        d: typing.Optional[int]
        e: typing.Optional[typing.List[int]]
        f: typing.Optional[typing.List[str]]
        g: typing.Optional[typing.List[typing.Optional[str]]]
        h: typing.Optional[typing.List[typing.Optional[int]]]
        i: typing.Optional[typing.List[typing.Optional[typing.List[int]]]]

# Generated at 2022-06-17 17:56:59.701889
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class Foo:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[int]
        f: typing.Optional[typing.List[int]]
        g: typing.Optional[typing.Dict[str, int]]
        h: typing.Optional[typing.Union[int, str]]
        i: typing.Optional[typing.Union[int, typing.List[int]]]
        j: typing.Optional[typing.Union[int, typing.Dict[str, int]]]

# Generated at 2022-06-17 17:57:08.669283
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError
    from dataclasses import dataclass

    @dataclass
    class Foo:
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    @dataclass
    class Bar:
        c: Foo
        d: str

    class BarSchema(SchemaF[Bar]):
        c = fields.Nested(FooSchema)
        d = fields.Str()

    foo = Foo(a=1, b='b')
    bar = Bar(c=foo, d='d')


# Generated at 2022-06-17 17:57:19.478207
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from typing import Optional, Union

    @dataclass_json
    @dataclass
    class A:
        a: int

    @dataclass_json
    @dataclass
    class B:
        a: Optional[int]

    @dataclass_json
    @dataclass
    class C:
        a: Union[int, A]

    @dataclass_json
    @dataclass
    class D:
        a: Union[int, A, B]

    @dataclass_json
    @dataclass
    class E:
        a: Union[int, A, B, C]

    @dataclass_json
    @dataclass
    class F:
        a: Union

# Generated at 2022-06-17 17:57:27.695515
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str

    @dataclass_json
    @dataclass
    class B:
        a: A
        b: str

    assert schema(B, dataclass_json, False) == {
        'a': fields.Nested(A.schema()),
        'b': fields.Str()
    }



# Generated at 2022-06-17 17:57:54.693361
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: str

    class ASchema(SchemaF[A]):
        a = fields.Int()

    class BSchema(SchemaF[B]):
        b = fields.Str()

    assert ASchema().dumps(A(1)) == '{"a": 1}'
    assert ASchema().dumps([A(1), A(2)]) == '[{"a": 1}, {"a": 2}]'
    assert BSchema().dumps(B("a")) == '{"b": "a"}'

# Generated at 2022-06-17 17:58:02.557336
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Foo(typing.NamedTuple):
        a: int
        b: str

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()

    foo = Foo(a=1, b='b')
    schema = FooSchema()
    assert schema.dumps(foo) == '{"a": 1, "b": "b"}'
    assert schema.dumps([foo]) == '[{"a": 1, "b": "b"}]'


# Generated at 2022-06-17 17:58:09.920622
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from typing import List, Optional, Union
    from enum import Enum

    class MyEnum(Enum):
        A = 'a'
        B = 'b'

    @dataclass_json
    @dataclass
    class MyDC:
        a: str

    @dataclass_json
    @dataclass
    class MyDC2:
        a: str

    @dataclass_json
    @dataclass
    class MyDC3:
        a: str

    @dataclass_json
    @dataclass
    class MyDC4:
        a: str


# Generated at 2022-06-17 17:58:16.428236
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import List
    from marshmallow import Schema, fields

    class FooSchema(Schema):
        a = fields.Int()

    class Foo:
        def __init__(self, a: int):
            self.a = a

    class FooListSchema(SchemaF[Foo]):
        pass

    schema = FooListSchema()
    schema.declared_fields = {'a': fields.Int()}
    foo = Foo(1)
    foo_list = [foo]
    assert schema.dump(foo) == {'a': 1}
    assert schema.dump(foo_list) == [{'a': 1}]
    assert schema.dumps(foo) == '{"a": 1}'
    assert schema.dumps(foo_list) == '[{"a": 1}]'

# Unit

# Generated at 2022-06-17 17:58:19.912429
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 17:58:31.116018
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str
        c: typing.Optional[str]
        d: typing.Optional[int] = None
        e: typing.Optional[typing.List[str]] = None
        f: typing.Optional[typing.List[int]] = None
        g: typing.Optional[typing.List[typing.Optional[int]]] = None
        h: typing.Optional[typing.List[typing.Optional[str]]] = None
        i: typing.Optional[typing.List[typing.Optional[A]]] = None
        j: typing.Optional[typing.List[A]]

# Generated at 2022-06-17 17:58:42.209617
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: float
        d: bool
        e: typing.List[int]
        f: typing.List[str]
        g: typing.List[float]
        h: typing.List[bool]
        i: typing.List[Test]
        j: typing.List[typing.List[int]]
        k: typing.List[typing.List[str]]
        l: typing.List[typing.List[float]]
        m: typing.List[typing.List[bool]]
        n: typing.List[typing.List[Test]]

# Generated at 2022-06-17 17:58:55.604210
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Foo(typing.Generic[A]):
        def __init__(self, a: A):
            self.a = a

    class FooSchema(SchemaF[Foo[int]]):
        a = fields.Int()

    foo = FooSchema().loads('{"a": 1}')
    assert foo.a == 1
    assert isinstance(foo, Foo)

    foo = FooSchema().loads('[{"a": 1}, {"a": 2}]')
    assert foo[0].a == 1
    assert foo[1].a == 2
    assert isinstance(foo, list)
    assert isinstance(foo[0], Foo)
    assert isinstance(foo[1], Foo)

    foo = FooSchema().loads(b'{"a": 1}')
    assert foo.a == 1
    assert isinstance

# Generated at 2022-06-17 17:59:04.896122
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.Optional[int]
        d: typing.Optional[str]
        e: typing.List[int]
        f: typing.List[str]
        g: typing.Dict[str, int]
        h: typing.Dict[str, str]
        i: typing.Optional[typing.List[int]]
        j: typing.Optional[typing.List[str]]
        k: typing.Optional[typing.Dict[str, int]]
        l: typing.Optional[typing.Dict[str, str]]

# Generated at 2022-06-17 17:59:10.528181
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Foo(typing.Generic[A]):
        def __init__(self, x: A):
            self.x = x

    class FooSchema(SchemaF[Foo[int]]):
        x = fields.Int()

    foo = FooSchema().load({'x': 1})
    assert foo.x == 1

    foo = FooSchema().load([{'x': 1}, {'x': 2}])
    assert foo[0].x == 1
    assert foo[1].x == 2

    foo = FooSchema().load({'x': 1}, many=False)
    assert foo.x == 1

    foo = FooSchema().load([{'x': 1}, {'x': 2}], many=False)
    assert foo[0].x == 1
    assert foo[1].x == 2

   

# Generated at 2022-06-17 17:59:46.037768
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from typing import Optional, List, Union
    from marshmallow import fields
    from marshmallow_enum import EnumField
    from dataclasses_json.mm import Schema

    class MyEnum(Enum):
        A = 1
        B = 2

    @dataclass
    class MyClass:
        pass

    @dataclass
    class MyClass2:
        pass

    @dataclass
    class MyClass3:
        pass

    @dataclass
    class MyClass4:
        pass

    @dataclass
    class MyClass5:
        pass

    @dataclass
    class MyClass6:
        pass

    @dataclass
    class MyClass7:
        pass

    @dataclass
    class MyClass8:
        pass

   

# Generated at 2022-06-17 17:59:53.038616
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    from marshmallow.exceptions import ValidationError
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int

    class ASchema(SchemaF[A]):
        a = fields.Int()

    assert ASchema().load({'a': 1}) == A(1)
    assert ASchema().load([{'a': 1}]) == [A(1)]
    assert ASchema().load([{'a': 1}, {'a': 2}]) == [A(1), A(2)]
    try:
        ASchema().load({'a': '1'})
        assert False
    except ValidationError:
        pass

# Generated at 2022-06-17 18:00:04.219689
# Unit test for function build_type
def test_build_type():
    from dataclasses import dataclass
    from typing import Optional, Union, List, Dict, Tuple, Any, Callable, Mapping, MutableMapping

    @dataclass
    class Test:
        a: str
        b: int
        c: float
        d: bool
        e: datetime
        f: UUID
        g: Decimal
        h: Optional[str]
        i: Optional[int]
        j: Optional[float]
        k: Optional[bool]
        l: Optional[datetime]
        m: Optional[UUID]
        n: Optional[Decimal]
        o: Union[str, int, float]
        p: Union[str, int, float, None]
        q: Union[str, int, float, None, datetime]

# Generated at 2022-06-17 18:00:15.701434
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses import dataclass

    @dataclass
    class A:
        a: int

    @dataclass
    class B:
        b: str

    @dataclass
    class C:
        c: typing.List[A]

    @dataclass
    class D:
        d: typing.List[B]

    @dataclass
    class E:
        e: typing.List[C]

    @dataclass
    class F:
        f: typing.List[D]

    @dataclass
    class G:
        g: typing.List[E]

    @dataclass
    class H:
        h: typing.List[F]

    @dataclass
    class I:
        i: typing.List[G]


# Generated at 2022-06-17 18:00:28.268112
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: float
        d: typing.List[int]
        e: typing.Optional[str]
        f: typing.Optional[typing.List[int]]
        g: typing.Optional[typing.List[typing.Optional[int]]]
        h: typing.Optional[typing.Union[int, str]]
        i: typing.Optional[typing.Union[int, typing.List[int]]]
        j: typing.Optional[typing.Union[int, typing.List[typing.Optional[int]]]]

# Generated at 2022-06-17 18:00:35.391506
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    assert field._serialize(datetime(2020, 1, 1, 0, 0, 0), None, None) == '2020-01-01T00:00:00'
    assert field._deserialize('2020-01-01T00:00:00', None, None) == datetime(2020, 1, 1, 0, 0, 0)


# Generated at 2022-06-17 18:00:43.338854
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from marshmallow import fields
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
        c: typing.Optional[int]
        d: typing.Optional[typing.List[int]]
        e: typing.Optional[typing.List[int]] = None
        f: typing.Optional[typing.List[int]] = []
        g: typing.Optional[typing.List[int]] = [1, 2, 3]
        h: typing.Optional[typing.List[int]] = None
        i: typing.Optional[typing.List[int]] = []
        j: typing.Optional[typing.List[int]] = [1, 2, 3]


# Generated at 2022-06-17 18:00:47.460675
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from dataclasses_json.mm import Schema

    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str

    @dataclass_json
    @dataclass
    class B:
        a: A
        b: str

    assert issubclass(build_schema(A, None, False, False), Schema)
    assert issubclass(build_schema(B, None, False, False), Schema)



# Generated at 2022-06-17 18:00:59.813305
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[int]
        f: typing.Optional[typing.List[int]]
        g: typing.Optional[typing.Dict[str, int]]
        h: typing.Optional[typing.List[typing.Optional[int]]]
        i: typing.Optional[typing.Dict[str, typing.Optional[int]]]
        j: typing.Optional[typing.Union[int, str]]
        k: typing.Optional[typing.Union[int, typing.List[int]]]
        l: typing.Optional[typing.Union[int, typing.Dict[str, int]]]
        m: typing

# Generated at 2022-06-17 18:01:06.887239
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[int]
        f: typing.Optional[str]
        g: typing.Optional[typing.List[int]]
        h: typing.Optional[typing.Dict[str, int]]
        i: typing.Optional[typing.Union[int, str]]
        j: typing.Optional[typing.Union[typing.List[int], str]]
        k: typing.Optional[typing.Union[typing.Dict[str, int], str]]

# Generated at 2022-06-17 18:01:57.598728
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None


# Generated at 2022-06-17 18:02:09.876347
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str

# Generated at 2022-06-17 18:02:17.772036
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from typing import List
    from marshmallow import Schema, fields, post_load
    from dataclasses import dataclass
    @dataclass
    class User:
        name: str
        email: str
    class UserSchema(SchemaF[User]):
        name = fields.Str()
        email = fields.Email()
        @post_load
        def make_user(self, data, **kwargs):
            return User(**data)
    user = User(name='Monty', email='monty@python.org')
    schema = UserSchema()
    result = schema.dump(user)
    assert result == {'name': 'Monty', 'email': 'monty@python.org'}
    result = schema.dump([user])

# Generated at 2022-06-17 18:02:20.779328
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.now(), None, None) is not None
    assert _TimestampField()._deserialize(datetime.now().timestamp(), None, None) is not None



# Generated at 2022-06-17 18:02:28.893730
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Tuple[int, int]
        f: typing.Callable
        g: typing.Any
        h: typing.Optional[int]
        i: typing.Optional[typing.List[int]]
        j: typing.Optional[typing.Dict[str, int]]
        k: typing.Optional[typing.Tuple[int, int]]
        l: typing.Optional[typing.Callable]
        m: typing.Optional[typing.Any]


# Generated at 2022-06-17 18:02:38.954618
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from typing import Optional
    from marshmallow import fields
    from dataclasses_json import DataClassJsonMixin
    from dataclasses_json.utils import _is_new_type

    @dataclass
    class A(DataClassJsonMixin):
        a: int
        b: Optional[int]

    @dataclass
    class B(DataClassJsonMixin):
        a: A
        b: Optional[A]

    @dataclass
    class C(DataClassJsonMixin):
        a: int
        b: Optional[int] = None

    @dataclass
    class D(DataClassJsonMixin):
        a: int
        b: Optional[int] = None
        c: Optional[int] = None


# Generated at 2022-06-17 18:02:42.471617
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Foo:
        a: int

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()

    assert FooSchema().dumps(Foo(1)) == '{"a": 1}'



# Generated at 2022-06-17 18:02:48.239873
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # type: () -> None
    class MySchema(SchemaF[int]):
        pass

    assert MySchema().dumps([1, 2, 3]) == '[1, 2, 3]'
    assert MySchema().dumps(1) == '1'


# Generated at 2022-06-17 18:02:59.448533
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields as mm_fields

    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str
        c: typing.List[int]

    @dataclass_json
    @dataclass
    class B:
        a: A
        b: typing.List[A]

    @dataclass_json
    @dataclass
    class C:
        a: typing.Optional[A]
        b: typing.Optional[typing.List[A]]

    @dataclass_json
    @dataclass
    class D:
        a: typing.Union[A, str]
        b: typing.Union[typing.List[A], str]

# Generated at 2022-06-17 18:03:11.174532
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: typing.Optional[int]
        d: typing.Optional[str]
        e: typing.Optional[typing.List[int]]
        f: typing.Optional[typing.List[str]]
        g: typing.Optional[typing.List[typing.Optional[int]]]
        h: typing.Optional[typing.List[typing.Optional[str]]]
        i: typing.Optional[typing.List[typing.Optional[typing.List[int]]]]

# Generated at 2022-06-17 18:05:21.061755
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from marshmallow_enum import EnumField

    class Color(Enum):
        RED = 1
        GREEN = 2
        BLUE = 3

    @dataclass_json
    @dataclass
    class Test:
        a: int
        b: str
        c: Color
        d: typing.List[int]
        e: typing.Optional[str]
        f: typing.Optional[typing.List[str]]
        g: typing.Optional[typing.Union[str, int]]
        h: typing.Union[str, int]
        i: typing.Union[str, int, None]
        j: typing.List[typing.Union[str, int]]
        k: typing

# Generated at 2022-06-17 18:05:30.856284
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    @dataclass_json
    @dataclass
    class Test:
        a: str
        b: int
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: typing.Optional[int]
        f: typing.Optional[typing.List[int]]
        g: typing.Optional[typing.Dict[str, int]]
        h: typing.Optional[typing.Union[str, int]]
        i: typing.Optional[typing.Union[str, int, typing.List[int]]]
        j: typing.Optional[typing.Union[str, int, typing.List[int], typing.Dict[str, int]]]

# Generated at 2022-06-17 18:05:37.457592
# Unit test for function build_schema
def test_build_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str
    assert build_schema(A, None, False, False)


# Generated at 2022-06-17 18:05:44.591871
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields
    from dataclasses import dataclass

    @dataclass
    class Foo:
        a: int
        b: str
        c: typing.List[int]

    class FooSchema(SchemaF[Foo]):
        a = fields.Int()
        b = fields.Str()
        c = fields.List(fields.Int())

    foo_schema = FooSchema()

    foo = foo_schema.loads('{"a": 1, "b": "foo", "c": [1, 2, 3]}')
    assert foo.a == 1
    assert foo.b == "foo"
    assert foo.c == [1, 2, 3]


# Generated at 2022-06-17 18:05:56.055049
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    from marshmallow import fields
    from dataclasses_json.mm import Schema

    @dataclass_json
    @dataclass
    class A:
        a: int
        b: str
        c: typing.Optional[str]
        d: typing.Optional[typing.List[str]]
        e: typing.Optional[typing.List[int]]
        f: typing.Optional[typing.List[A]]
        g: typing.Optional[typing.List[typing.List[A]]]
        h: typing.Optional[typing.List[typing.List[int]]]
        i: typing.Optional[typing.List[typing.List[str]]]