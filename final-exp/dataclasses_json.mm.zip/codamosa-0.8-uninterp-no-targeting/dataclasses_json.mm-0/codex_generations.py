

# Generated at 2022-06-21 11:24:18.126629
# Unit test for function build_schema
def test_build_schema():
    import marshmallow.validate
    from marshmallow.exceptions import ValidationError
    from marshmallow import fields
    from marshmallow import Schema

    from dataclasses import dataclass
    from typing import Optional
    from typing import List
    from typing import Dict
    from typing import Union
    from uuid import UUID
    from decimal import Decimal
    import pytz

    @dataclass
    class TestSchema:
        a: str
        b: int
        c: Optional[List[UUID]]
        f: Union[Dict[str, str], List[str]]
        g: Optional[Decimal]

    @dataclass
    class TestSchema2:
        a: str
        b: int
        c: Optional[List[UUID]]

# Generated at 2022-06-21 11:24:20.098856
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Person(SchemaF[A]):
        name = fields.Str()
        age = fields.Int()



# Generated at 2022-06-21 11:24:22.597251
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert str(_IsoField()._serialize(datetime.now(), "attr", "obj")) is not None


# Generated at 2022-06-21 11:24:29.784238
# Unit test for constructor of class _IsoField
def test__IsoField():
    from datetime import datetime
    import unittest

    class _IsoFieldTest(unittest.TestCase):
        def test__IsoField(self):
            field = _IsoField()
            self.assertEqual(field._deserialize(value='2019-09-23T08:40:43.818595+00:00', attr=None, data=None), datetime(2019, 9, 23, 8, 40, 43, 818595))

    unittest.main(verbosity=2)



# Generated at 2022-06-21 11:24:38.678335
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class Schema(SchemaF[A]):
        # type: ignore
        pass

    @dataclass_json
    @dataclass(frozen=True)
    class TestDict(object):
        a: int
        b: int

    Schema().dumps(TestDict(a=1, b=2))

    # This fails, if it is implemented like this
    # Schema().dumps([TestDict(a=1, b=2)])

if sys.version_info < (3, 7):
    SchemaF = Schema  # type: ignore

_overrides = [((list, _get_type_origin(typing.Tuple)), fields.List)]



# Generated at 2022-06-21 11:24:47.478456
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses import dataclass
    from typing import List

    @dataclass
    class Obj:
        a: List[int]

    s = SchemaF[Obj]()  # type: ignore
    obj = Obj([1, 2, 3])
    assert s.dump(obj) == {'a': [1, 2, 3]}
    assert s.dumps(obj) == '{"a": [1, 2, 3]}'

    data = [{"a": [1, 2, 3]}, {"a": [4, 5, 6]}]
    assert s.dump(data, many=True) == data
    assert s.dumps(data, many=True) == '[{"a": [1, 2, 3]}, {"a": [4, 5, 6]}]'


# Generated at 2022-06-21 11:24:53.692935
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert int((datetime.utcnow()).timestamp()) == int(_TimestampField().serialize(datetime.utcnow()))
    assert int((datetime.utcnow()).timestamp()) == int(_TimestampField().serialize(datetime.utcnow(), attr="anything"))
    assert int((datetime.utcnow()).timestamp()) == int(_TimestampField().serialize(datetime.utcnow(), obj=1))
    assert int((datetime.utcnow()).timestamp()) == int(_TimestampField().serialize(datetime.utcnow(), attr="anything",
                                                                                    obj=1))
    assert _TimestampField().serialize(None) is None



# Generated at 2022-06-21 11:24:57.124711
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.fromtimestamp(0), None, None) == 0
    assert _TimestampField()._deserialize(0, None, None) == datetime.fromtimestamp(0)



# Generated at 2022-06-21 11:25:07.312782
# Unit test for method load of class SchemaF
def test_SchemaF_load():  # type: ignore
    _: int = SchemaF({"blub": fields.Int()}).load({"blub": "123"})["blub"]

# Generated at 2022-06-21 11:25:08.965899
# Unit test for function build_schema
def test_build_schema():
    # TODO
    pass



# Generated at 2022-06-21 11:25:27.509164
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    assert SchemaF[int].loads('["1"]', many=True)[0] == 1
    assert SchemaF[int].loads('[1]', many=True)[0] == 1
    assert SchemaF[int].loads('1', many=None) == 1

# Generated at 2022-06-21 11:25:34.211798
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    assert SchemaF[int]().dumps(0) == '0'
    assert SchemaF[int]().dumps([0]) == '[0]'
    assert SchemaF[int]().dumps(0, many=False) == '0'
    assert SchemaF[int]().dumps([0], many=False) == '[0]'
    assert SchemaF[int]().dumps(0, many=True) == '0'
    assert SchemaF[int]().dumps([0], many=True) == '[0]'


# Generated at 2022-06-21 11:25:39.935205
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(None) == None
    assert _TimestampField(required=True)._serialize(None) == None
    assert _TimestampField()._deserialize(None) == None
    assert _TimestampField(required=True)._deserialize(None) == None



# Generated at 2022-06-21 11:25:49.638063
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses import dataclass

    @dataclass
    class A:
        age: int

    class B:
        pass

    schema = SchemaF[A]()
    schema.dump([A(1), A(2)], many=True) == [{'age': 1}, {'age': 2}]
    schema.dump([B()], many=True) == [{}]
    schema.dump(A(1), many=False) == {'age': 1}
    schema.dump(B(), many=False) == {}
    schema.dump([A(1), A(2)]) == [{'age': 1}, {'age': 2}]
    schema.dump(A(1)) == {'age': 1}



# Generated at 2022-06-21 11:25:50.923722
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class _TestSchema:
        pass

    assert build_schema(_TestSchema, mixin=None, infer_missing=None, partial=None)

# Generated at 2022-06-21 11:25:51.960053
# Unit test for function schema
def test_schema():
    assert len(schema) == 0

# Generated at 2022-06-21 11:25:55.334580
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # type: () -> None
    def f() -> None:
        class A(typing.NamedTuple): pass
        class AF(SchemaF[A]): pass
        A(a=1).dumps()
    test_function_that_should_fail(f)



# Generated at 2022-06-21 11:26:00.913984
# Unit test for function schema
def test_schema():
    import marshmallow as mm

    class MySchema(mm.Schema):
        pass

    class MyDataclass():
        pass

    import pytest
    with pytest.raises(NotImplementedError):
        MySchema().dump([], many=True)

    import typing
    from typing import List, Optional

    from dataclasses import dataclass

    from dataclasses_json.mm import MM

    @dataclass
    class Example(MM):
        v: Optional[List[int]] = None

    assert Example.schema().fields['v'].many

    def make_schema(cls):
        class MySchema(mm.Schema):
            class Meta:
                fields = schema(cls, MM, False)
            pass

        return MySchema()

    # Unit test for function build_type

# Generated at 2022-06-21 11:26:13.293591
# Unit test for constructor of class SchemaF
def test_SchemaF():
    @dataclass_json()
    @dataclass
    class A:
        x: int
        y: str
    a = A(1, 'x')
    af = A(1, 'x')
    af_list = [A(1, 'x')]
    schema_f = SchemaF[A]
    assert schema_f.dump(a) == {'x': 1, 'y': 'x'}
    assert schema_f.dump(af_list) == [{'x': 1, 'y': 'x'}]
    assert schema_f.dumps(a) == '{"x": 1, "y": "x"}'
    assert schema_f.dumps(af_list) == '[{"x": 1, "y": "x"}]'

# Generated at 2022-06-21 11:26:15.576490
# Unit test for constructor of class _IsoField
def test__IsoField():
    isoField = _IsoField()
    isoField._deserialize("1946-08-29T20:09:00")


# Generated at 2022-06-21 11:26:43.526852
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # type: () -> None

    class S(SchemaF[A]):
        """A schema that is used to test SchemaF"""

    # test SchemaF[A]
    s = S()
    a = s.load({'a': 1})  # type: ignore
    b = s.load({'b': 2}, many=True)  # type: ignore
    assert {'a': 1} == a
    assert [{'b': 2}] == b



# Generated at 2022-06-21 11:26:54.333611
# Unit test for constructor of class _UnionField
def test__UnionField():
    # type: () -> None
    from typing import Union
    from marshmallow import Schema
    from dataclasses import dataclass
    field = _UnionField(desc={int: Schema()},
                        cls=1,
                        field=1,
                        allow_none=True)
    assert field._serialize(1, None, None) == 1
    assert field._serialize(None, None, None) is None
    assert isinstance(field._deserialize(None, None, None), int)
    assert isinstance(field._deserialize(1, None, None), int)
    assert isinstance(field._deserialize("1", None, None), int)
    @dataclass
    class Test:
        field: Union[int, float]

# Generated at 2022-06-21 11:26:56.826783
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    # schema = SchemaF[List[int]]()
    assert SchemaF.loads.__annotations__.get('json_data') == typing.Union[str, bytes, bytearray]

# Generated at 2022-06-21 11:27:01.178111
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    import marshmallow
    class TestSchema(SchemaF[int]):
        pass

    TestSchema().dump(1)
    TestSchema().dump([1,2,3])
    TestSchema().dump(1, many=True)


# Generated at 2022-06-21 11:27:09.960663
# Unit test for constructor of class _IsoField
def test__IsoField():
    f = _IsoField()

    assert None == f.load_from('date', None)
    assert None == f.load_from('date', '')
    assert datetime.fromisoformat('2020-03-10 12:30:01') == f.load_from('date', '2020-03-10 12:30:01')

    assert None == f.dump('date', None)
    assert '' == f.dump('date', '')
    assert '2020-03-10 12:30:01' == f.dump('date', datetime.fromisoformat('2020-03-10 12:30:01'))

# Test for required/optional behavior

# Generated at 2022-06-21 11:27:13.599004
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    f = _TimestampField()
    assert f._serialize(datetime.fromtimestamp(0), None, None) == 0.0

    assert f._deserialize(0, None, None) == datetime.fromtimestamp(0)



# Generated at 2022-06-21 11:27:19.520778
# Unit test for function schema
def test_schema():

    @dataclass_json
    @dataclass
    class C:
        c: UUID

    # Original code
    #
    # def test_schema(self):
    #     try:
    #         schema(self.C)
    #     except NotImplementedError:
    #         pytest.fail("Could not create a schema")

    # Modified code
    try:
        # FIXME:
        #  TypeError: 'NoneType' object is not callable
        schema(C, dataclasses_json.AST_NODE_CLASS, False)
    except NotImplementedError:
        # FIXME:
        #   pytest.fail("Could not create a schema")
        print("Could not create a schema")
        assert False

test_schema()

from marshmallow import pre_dump

# Generated at 2022-06-21 11:27:31.826661
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    import marshmallow as mm
    from dataclasses import dataclass
    @dataclass
    class Foo:
        bar: int = 3
        baz: str = 'hello world'
    @dataclass
    class FooSchema(SchemaF[Foo]):  # type: ignore
        bar = mm.fields.Int(required=True)
        baz = mm.fields.String(required=True)
        @post_load
        def make_foo(self, data):
            return Foo(**data)
    import json
    dump_str = FooSchema().dump(Foo())  # type: ignore
    assert isinstance(dump_str, dict)
    dump_str = json.dumps(dump_str)
    assert isinstance(dump_str, str)

# Generated at 2022-06-21 11:27:35.736897
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class A(SchemaF):
        pass
    assert isinstance(A().loads(''), typing.List[str])
    assert isinstance(A().loads(''), typing.List[str])
    assert isinstance(A().loads(''), typing.List[str])


# Generated at 2022-06-21 11:27:37.130133
# Unit test for constructor of class SchemaF
def test_SchemaF():
    SchemaF[int]  # type: ignore



# Generated at 2022-06-21 11:28:55.136707
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    data = [{'key': 'value'}]
    json_data = '[{"key": "value"}]'
    assert SchemaF.dumps({'key': 'value'}) == json_data
    assert SchemaF.dumps(data) == json_data



# Generated at 2022-06-21 11:29:01.419118
# Unit test for function build_type
def test_build_type():
    # Setup
    from dataclasses import dataclass
    from dataclasses_json.api import dataclass_json
    from dataclasses_json.mm import MistryMixin

    @dataclass_json
    @dataclass
    class NestedDC(MistryMixin):
        s: str

    @dataclass_json
    @dataclass
    class DC:
        n: NestedDC

    # Exercise
    res = build_type(DC.n.type, {}, MistryMixin, DC.n, DC)

    # Verify
    assert res(DC.n.type, {}).__class__.__name__ == 'Nested'
    assert res(DC.n.type, {}).schema.__class__.__name__ == 'Schema'



# Generated at 2022-06-21 11:29:06.662785
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class A(typing.NamedTuple):
        a: int
    class TestSchema(SchemaF[A]):
        a = fields.Int()
        @post_load
        def load_a(self, data, **kwargs):
            return A(**data)
    result = TestSchema().dump({'a': 1})
    assert isinstance(result, A)


# Generated at 2022-06-21 11:29:15.980105
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses_json.api import dump
    from pydantic import BaseModel, create_model

    class Model(BaseModel):
        x: int
        y: int

    class ModelF(SchemaF[Model]):
        def __init__(self):
            super().__init__()

    test_data = [
        ('{"x": 1, "y": 2}', [Model(x=1, y=2)]),
        ('[{"x": 1, "y": 2}, {"x": 3, "y": 4}]', [Model(x=1, y=2), Model(x=3, y=4)]),
    ]
    for json_data, value in test_data:
        schema = ModelF()
        res: typing.Any = schema.load(json_data)
        assert res == value


# Generated at 2022-06-21 11:29:23.145943
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class TestF(typing.Generic[A]):
        def test(self, schema: SchemaF[A]):
            x = schema.dump([object()])
            assert isinstance(x, list)
            assert all(isinstance(o, dict) for o in x)
            x = schema.dump(object())
            assert isinstance(x, dict)
            x = schema.dump(object())
            assert isinstance(x, dict)
    TestF().test(SchemaF[object]())


#######################
# DATACLASS SERIALIZER #
#######################



# Generated at 2022-06-21 11:29:30.490311
# Unit test for function build_schema
def test_build_schema():
    cls = typing.Type[test_class_with_schema]
    mixin = test_class_with_schema
    infer_missing = False
    partial = True

    Meta = type('Meta',
                (),
                {'fields': tuple(field.name for field in dc_fields(cls)),
                 # TODO #180
                 'render_module': global_config.json_module})
    @post_load
    def make_instance(self, kvs, **kwargs):
        return _decode_dataclass(cls, kvs, partial)

    def dumps(self, *args, **kwargs):
        if 'cls' not in kwargs:
            kwargs['cls'] = _ExtendedEncoder

        return Schema.dumps(self, *args, **kwargs)

   

# Generated at 2022-06-21 11:29:38.974735
# Unit test for function build_type
def test_build_type():

    class Mixin:
        def test_method(self):
            pass

    @dataclass_json
    @dataclass
    class TestDataClass(Mixin):
        id: int
        text: str

    @dataclass
    class TestDataClass2:
        id: int

    @dataclass_json
    @dataclass
    class TestDataClass3:
        id: int

    class TestEnum(Enum):
        ONE = 1
        TWO = 2

    class TestEnum2(Enum):
        ONE = 1
        TWO = 2

    @dataclass_json
    @dataclass
    class TestDataClass4:
        id: int
        optional_text: Optional[TestEnum2]


# Generated at 2022-06-21 11:29:46.089305
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass
    from typing import Union, Optional
    from marshmallow import Schema

    class TestSchema(Schema):
        class TestUnionField0(Union[int, str]):
            pass

        class TestUnionField1(Union[int, str]):
            pass

        class TestUnionField2(Union[int, str]):
            pass

    @dataclass
    class TestClass:
        field0: Optional[_UnionField]
        field1: Optional[_UnionField]
        field2: Optional[_UnionField]
        field3: Optional[_UnionField]

    # do not use static typing,
    # use dynamic types to cover __init__ of _UnionField class
    # in case of using mypy

# Generated at 2022-06-21 11:29:50.742165
# Unit test for constructor of class SchemaF
def test_SchemaF():
    from marshmallow import Schema
    def foo(obj: A) -> A:
        schema = SchemaF[A](schema_class=Schema, strict=True)
        return schema.load(schema.dump(obj))

    foo(None)
    assert foo(1) == 1



# Generated at 2022-06-21 11:29:55.754620
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Dummy(typing.NamedTuple):
        a: int
        b: str

    d = Dummy(1, 'b')
    s = SchemaF[Dummy].from_dict({'a': fields.Int(), 'b': fields.String()})
    assert d == s.dumps(d)



# Generated at 2022-06-21 11:31:27.323833
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField().load(None) is None
    assert _TimestampField().load("123") is not None


# Generated at 2022-06-21 11:31:32.565665
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass

    class User:
        pass

    @dataclass
    class Student:
        name: str

    @dataclass
    class Admin:
        name: str

    class Group:
        def __init__(self, members):
            self.members = members

    class GroupSchema(Schema):
        members = fields.List(_UnionField(
            desc={
                str: fields.Str,
                int: fields.Int,
                float: fields.Float,
                Decimal: fields.Decimal,
                UUID: fields.UUID,
                datetime: _IsoField,
                Admin: 'AdminSchema',
                User: 'UserSchema'
            },
            cls=Group, field=fields['members']))

    class UserSchema(Schema):
        pass

# Generated at 2022-06-21 11:31:38.087343
# Unit test for function build_type
def test_build_type():
    from dataclasses_json.annotations import dataclass_json
    from dataclasses_json.mm import MMLoader
    from dataclasses import dataclass
    from uuid import UUID

    @dataclass
    class A:
        pass

    @dataclass_json
    @dataclass
    class B(A):
        pass

    @dataclass_json
    @dataclass
    class C:
        id: UUID
        name: str = 'x'

    @dataclass_json
    @dataclass
    class D:
        x: typing.List[C]

    @dataclass_json
    @dataclass
    class E:
        y: typing.Optional[typing.List[C]]


# Generated at 2022-06-21 11:31:40.225993
# Unit test for constructor of class SchemaF
def test_SchemaF():
    try:
        SchemaF()
    except NotImplementedError:
        pass
    except:
        assert False



# Generated at 2022-06-21 11:31:48.495399
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from typing import List
    from marshmallow import ValidationError  # type: ignore
    class TestSchema(TypingSchema):
        foo = fields.Integer()
    test_schema = TestSchema()
    test_schema.load({"foo": 1})  # type: ignore

# Generated at 2022-06-21 11:31:51.883909
# Unit test for constructor of class _IsoField
def test__IsoField():
    """
    A test function to test the constructor of Marshmallow's class IsoField.
    """
    field = _IsoField()
    assert field.__class__.__name__ == '_IsoField'


# Generated at 2022-06-21 11:31:58.967986
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime(2020, 1, 2, 3, 4, 5), "a", None) == 1578019045
    assert _TimestampField()._serialize(None, "a", None, required=True) == 1578019045

    assert _TimestampField()._deserialize(1578019045, "a", None) == datetime(2020, 1, 2, 3, 4, 5)
    assert _TimestampField()._deserialize(None, "a", None, required=True) == datetime(2020, 1, 2, 3, 4, 5)


# Generated at 2022-06-21 11:32:00.919301
# Unit test for function build_type
def test_build_type():
    # There are no tests for this function, because it's a private function,
    # and it has no side effects.
    return True



# Generated at 2022-06-21 11:32:02.234402
# Unit test for constructor of class SchemaF
def test_SchemaF():
    with TypeError('This class should not be inherited'):
        SchemaF()



# Generated at 2022-06-21 11:32:10.683090
# Unit test for function build_schema
def test_build_schema():
    @dataclass
    class A:
        a: str
    @dataclass
    class B:
        b: str
    class Mix:
        ...
    DataClassSchema = build_schema(A, Mix, False, False)
    schema = DataClassSchema()
    assert repr(schema.declared_fields['a']) == '<fields.Str(default=<marshmallow.missing>, allow_none=False, error_messages={}, validate=[], required=False, load_only=False, dump_only=False, missing=<marshmallow.missing>)>'