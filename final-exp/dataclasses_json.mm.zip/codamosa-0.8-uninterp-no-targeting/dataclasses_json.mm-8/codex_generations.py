

# Generated at 2022-06-21 11:24:25.108709
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses import dataclass
    @dataclass
    class Person:
        name: str

    class PersonSchema(SchemaF[Person]):
        name = fields.String()

    schema = PersonSchema()
    john = schema.load({'name': 'John'})
    assert isinstance(john, Person)
    assert john.name == 'John'
    jane = schema.load([{'name': 'Jane'}], many=True)[0]
    assert isinstance(jane, Person)
    assert jane.name == 'Jane'
    assert schema.load('', many=False) is None


if sys.version_info < (3, 7):
    SchemaF = Schema



# Generated at 2022-06-21 11:24:33.441668
# Unit test for function build_schema
def test_build_schema():
    @dataclass_json
    @dataclass_json.config(unknown=EXCLUDE)
    @dataclass
    class Foo:
        a: int

    assert issubclass(build_schema(Foo, dataclass_json.DataClassJsonMixin, False, False), Schema)
    assert "a" in build_schema(Foo, dataclass_json.DataClassJsonMixin, False, False)().fields.keys()



# Generated at 2022-06-21 11:24:45.041255
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    @dataclass
    class RawSchema(object):
        a: str
        b: typing.Optional[str]
        c: int
        d: typing.Optional[int]
        e: typing.Tuple[str, int]
        f: typing.Optional[typing.Tuple[str, int]]
        g: typing.Optional[typing.Tuple[str, int, None]]
        h: typing.Union[str, int, None]
        i: typing.Optional[typing.Union[str, int, None]]
        j: datetime
        k: typing.Optional[datetime]
        l: typing.List[int]
        m: typing.Optional[typing.List[int]]
        o: typing.Dict[int, str]

# Generated at 2022-06-21 11:24:48.205227
# Unit test for function build_schema
def test_build_schema():
    import marshmallow
    def test_serialization(cls):
        assert cls.schema().dump({'a': 1}) == {'a': 1}
        assert cls.schema().dumps({'a': 1}).strip() == '{"a": 1}'

    class TestCls(metaclass=DataClassJSON):
        a: int

    assert isinstance(TestCls.schema(), marshmallow.Schema)
    test_serialization(TestCls)



# Generated at 2022-06-21 11:24:54.404935
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    field = _TimestampField()
    assert field.default_error_messages["required"] == "Missing data for required field."

    # Test case for _serialize
    assert field._serialize(datetime(2019,1,1), 'attr', 'obj') == 1546300800.0

    # Test case for _deserialize
    assert field._deserialize(1546300800.0, 'attr', 'data') == datetime(2019,1,1)



# Generated at 2022-06-21 11:25:03.680880
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields
    from typing import List, Union, TypeVar, Literal

    A = TypeVar("A")

    class TestSchema(Schema, typing.Generic[A]):
        nums: List[A] = fields.List(fields.Int())

    # Test OK case
    TestSchema[A].dumps({'nums': [1, 2, 3]})

    # Test failure case
    TestSchema[A].dumps({'nums': [1, 2, "3"]})



# Generated at 2022-06-21 11:25:06.694047
# Unit test for constructor of class SchemaF
def test_SchemaF():
    from dataclasses import dataclass

    @dataclass()
    class Temp:
        i: int

    s = SchemaF[Temp](unknown='EXCLUDE').load([{'i': 1}])



# Generated at 2022-06-21 11:25:17.064037
# Unit test for function build_type
def test_build_type():
    from dataclasses_json.api import mm_field
    from dataclasses_json.api import mm_config
    from dataclasses import dataclass
    import uuid
    p_id = uuid.uuid4()
    @mm_config
    @dataclass
    class DummyUser1:
        name: str
        age: int = 22
    @mm_config
    @dataclass
    class DummyUser2:
        name: str = mm_field(identifier=True)
        age: int = mm_field(default_factory=lambda: 22)
    @mm_config
    @dataclass
    class DummyUserOptional:
        name: typing.Optional[str] = None
    @mm_config
    @dataclass
    class DummyUserMany1:
        name: typing

# Generated at 2022-06-21 11:25:24.510738
# Unit test for constructor of class SchemaF
def test_SchemaF():  # noqa
    class Data(typing.Generic[A]):
        self_: A

    class SchemaClass(SchemaF[Data[str]]):
        self_ = fields.Str()

    obj = Data[str](self_='123')
    schema = SchemaClass()
    assert schema.dump(obj) == {'self_': '123'}
    assert schema.dumps(obj) == '{"self_": "123"}'
    assert schema.load({'self_': '123'}) == obj
    assert schema.loads('{"self_": "123"}') == obj



# Generated at 2022-06-21 11:25:26.357107
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._serialize(datetime.utcnow()) is not None
    assert _TimestampField()._deserialize(0) is not None


# Generated at 2022-06-21 11:25:49.052859
# Unit test for constructor of class _UnionField
def test__UnionField():
    # Test case with fields.Integer()
    uf = _UnionField({type(None): fields.Integer()},
                     typing.Union[int, None],
                     None,
                     allow_none=True)
    assert uf.allow_none is True
    assert uf.desc[type(None)] is fields.Integer()
    assert uf.cls is typing.Union[int, None]
    assert uf.field is None

    # Test case with fields.Integer()
    uf = _UnionField({type(None): fields.Integer(), int: fields.Decimal()},
                     typing.Union[int, None],
                     None,
                     allow_none=True)
    assert uf.allow_none is True
    assert uf.desc[type(None)] is fields.Integer()

# Generated at 2022-06-21 11:25:57.452154
# Unit test for function build_type
def test_build_type():
    import marshmallow_oneofschema

    class Schema(marshmallow_oneofschema.OneOfSchema):
        type_schemas = {'type_one': None, 'type_two': None}

        @post_load
        def make_object(self, data):
            type_ = data.pop('type')
            schema = self.type_schemas[type_]
            return schema.load(data)


    class A:
        b = 1


    class B:
        @dataclass_json
        @dataclass
        class C:
            a: A


    @dataclass_json
    @dataclass
    class Test:
        t: typing.Optional[int] = None
        u: typing.Optional[str] = None
        v: typing.List[str]

# Generated at 2022-06-21 11:26:02.542480
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses_json.marshmallow_schema import SchemaF

    class PersonSchema(SchemaF[Person]):
        name = fields.String()

    schema = PersonSchema()
    p = schema.load({"name": "Chris"})
    assert p == Person(name="Chris")



# Generated at 2022-06-21 11:26:14.392652
# Unit test for function schema
def test_schema():
    from marshmallow import Schema, fields
    from dataclasses_json.mm import MMSchema
    from dataclasses_json.api import load, dump, configure

    @configure(unknown=CatchAllVar)
    class Parent:
        a: int
        b: str
        c: int
        d: str = 'test'
        d2: str = 1
        e: str = 'test'
        f: int = 1
        g: int = (1, 2)
        h: typing.List[int]
        i: typing.List[int]
        j: typing.List[int]
        k: typing.List[int]

        class Config:
            arbitrary_types_allowed = True


# Generated at 2022-06-21 11:26:20.511259
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Foobar:
        ...

    schema = SchemaF[Foobar]()

    if sys.version_info >= (3, 7):
        assert isinstance(schema.loads(b'{}'), dict)  # type: ignore
        assert isinstance(schema.loads([b'{}', b'{}']), list)  # type: ignore



# Generated at 2022-06-21 11:26:28.835715
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class Bar:
        def __init__(self, name, value):
            self.name = name
            self.value = value

    class Foo(typing.Generic[A]):
        def __init__(self, values: typing.List[A]):
            self.values = values

    class FooSc(SchemaF[Bar]):
        name = fields.Str()
        value = fields.Int()

        @post_load
        def make_bar(self, data, **kwargs):
            return Bar(**data)

    foo1 = FooSc(many=True)
    foo2 = FooSc(many=False)

    data = [{'name': 'a', 'value': 1}, {'name': 'b', 'value': 2}]
    foo1.loads(json.dumps(data))
    foo2

# Generated at 2022-06-21 11:26:39.928382
# Unit test for constructor of class _UnionField
def test__UnionField():
    def _test_equal(instance, other):
        return type(other) is _UnionField and \
            instance.desc == other.desc and \
            instance.cls == other.cls and \
            instance.field == other.field and \
            instance.name == other.name and \
            instance.attribute == other.attribute and \
            instance.allow_none == other.allow_none and \
            instance.data_key == other.data_key and \
            instance.default == other.default and \
            instance.required == other.required
    assert _test_equal(
        _UnionField(MISSING, MISSING, MISSING),
        _UnionField(MISSING, MISSING, MISSING))

# Unit tests for deserialize() of class _UnionField

# Generated at 2022-06-21 11:26:42.120739
# Unit test for constructor of class SchemaF
def test_SchemaF():
    with pytest.raises(NotImplementedError):
        SchemaF(None)



# Generated at 2022-06-21 11:26:53.010839
# Unit test for function build_schema
def test_build_schema():
    f = open(os.path.abspath(os.path.join('test_files','_schema_test.py')))
    content = f.read()
    exec(content, globals())
    cls = build_schema(User, mixin, infer_missing, partial)
    # print(cls.__name__)
    # data = cls()
    # # print(data)
    # # print(cls.__dict__)
    # # print(cls.__annotations__)
    # # print(cls._declared_fields)
    # dataclass_json.config(cls,encoder=_ExtendedEncoder)
    # # print(type(cls.__dict__['make_user']))
    # # print(type(cls.__dict__['dumps

# Generated at 2022-06-21 11:26:55.705226
# Unit test for function schema
def test_schema():
    # from dataclasses import dataclass
    from dataclasses_json import dataclass_json
    @dataclass_json
    @dataclass
    class A:
        i: bool

    assert schema(A, dataclass_json, False) == {'i': fields.Bool()}



# Generated at 2022-06-21 11:27:31.139287
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():  # type: ignore
    class UserSchema(SchemaF[User]):
        id = fields.Int()
        name = fields.Str()
        email = fields.Email()

    schema = UserSchema()
    schema.loads(b'{"id": 123, "name": "John Doe", "email": "foo@bar.com", "created_at": "2019-12-29T13:09:28.795357Z"}', many=True)
    schema.loads(b'{"id": 123, "name": "John Doe", "email": "foo@bar.com", "created_at": "2019-12-29T13:09:28.795357Z"}')

# Generated at 2022-06-21 11:27:41.251042
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    import marshmallow as mm
    from marshmallow.exceptions import ValidationError
    from dataclasses import dataclass
    from typing import Optional, Tuple

    @dataclass
    class MyData:
        sum: float
        power: float
        data: float
        result: float

    class MyDataSchema(mm.Schema):
        sum = mm.fields.Float()
        power = mm.fields.Float()
        data = mm.fields.Float()
        result = mm.fields.Float()

        @mm.validates_schema
        def check_result(self, data, **kwargs):
            if data['result'] != data['sum'] ** data['power']:
                raise ValidationError('Invalid result')

    @dataclass
    class MyData2:
        sum: float
        power: float


# Generated at 2022-06-21 11:27:45.274062
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    t = _TimestampField()
    assert t._serialize(datetime.fromtimestamp(1500000000), "", None) == 1500000000
    dt = t._deserialize(1500000000, "", None)
    assert dt.timestamp() == 1500000000



# Generated at 2022-06-21 11:27:50.557791
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class AnnotationTest(SchemaF[str]):
        pass

    assert(isinstance(AnnotationTest.loads('"hello"'), str))
    assert(isinstance(AnnotationTest.loads(b'["hello"]'), list))
    assert(isinstance(AnnotationTest.loads(b'{"hello": "world"}'), dict))



# Generated at 2022-06-21 11:28:02.588002
# Unit test for function build_type
def test_build_type():
    from typing import List, Optional, Union, Tuple, Dict, Mapping, TypeVar, Any
    from dataclasses import dataclass
    from marshmallow import Schema, fields
    from marshmallow_enum import EnumField
    class Color(Enum):
       red = 1
       blue = 2
    ###############################
    #### Simple type
    ###############################
    #### int
    assert build_type(int, {}, Schema, FakeField(int, "x"), None) == fields.Integer
    #### str
    assert build_type(str, {}, Schema, FakeField(str, "x"), None) == fields.String
    #### float
    assert build_type(float, {}, Schema, FakeField(float, "x"), None) == fields.Float
    #### bool

# Generated at 2022-06-21 11:28:09.920435
# Unit test for function build_type
def test_build_type():
    options = {}
    mixin = "a"
    field = "b"
    cls = "c"
    origin = typing.Optional[str]
    type_ = "d"
    args = [2, 3]
    union = typing.Union[int, str]
    union_types = [int, str]
    union_desc = {int: 2, str: 3}
    assert build_type(type_, options, mixin, field, cls)(type_, options)
    assert build_type(origin, options, mixin, field, cls)(origin, options)
    assert build_type(union, options, mixin, field, cls)(union, options)
    assert build_type(origin, options, mixin, field, cls)(origin, options)



# Generated at 2022-06-21 11:28:18.286536
# Unit test for constructor of class _UnionField
def test__UnionField():
    class Test:
        pass
    tf = _UnionField(
        {Test: 'test'},
        Test,
        None,
        required=True,
        allow_none=True,
        missing=MISSING,
        default=MISSING,
        attribute=None,
        load_only=False,
        dump_only=False,
        missing=MISSING,
        validate=None,
        error_messages=None)
    assert tf.label is None



# Generated at 2022-06-21 11:28:26.236991
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses import dataclass, field
    from dataclasses_json.api import DataclassJsonMixin
    from marshmallow import Schema

    @dataclass
    class User(DataclassJsonMixin):
        name: str
        age: int

    class UserSchema(SchemaF[User]):
        pass

    user = User(name="Adam", age=22)
    schema = UserSchema()
    data, errors = schema.dump(user)
    assert data == {"name": "Adam", "age": 22}
    assert errors == {}



# Generated at 2022-06-21 11:28:28.737452
# Unit test for function schema
def test_schema():
    from dataclasses import dataclass
    @dataclass
    class Student:
        name : str
        age  : int
    @dataclass
    class Cls:
        student : Student
        name : str
        age : int
    assert schema(Cls, {}, False) == {'student': {'name': 'name', 'age': 'age'}, 'name': 'name', 'age': 'age'}


# Generated at 2022-06-21 11:28:31.345237
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    a = SchemaF().load({'data': 1}, many=True)
    b = SchemaF().load([{'data': 1}, {'data': 2}], many=True)
    c = SchemaF().load({'data': 1}, many=False)
    d = SchemaF().load([{'data': 1}, {'data': 2}], many=False)
    assert False



# Generated at 2022-06-21 11:29:22.997604
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    schema = SchemaF()
    schema.loads("")


# Generated at 2022-06-21 11:29:25.326008
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    t = fields.DateTime(required=False)
    assert _TimestampField(required=True)
    assert _TimestampField(required=False)
    assert _TimestampField()


# Generated at 2022-06-21 11:29:32.114224
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from marshmallow import Schema, fields
    class InnerSchema(Schema):
        a = fields.Int()

    class TestSchema(InnerSchema): # type: ignore
        b = fields.Int()

    class TestSchemaF(SchemaF[TestSchema]):
        pass

    assert isinstance(TestSchemaF().load({"a": 1, "b": 2}), TestSchema)
    assert isinstance(TestSchemaF().load([{"a": 1, "b": 2}], many=True), list)
    assert isinstance(TestSchemaF().load({}, many=False, partial=True), TestSchema)
    assert isinstance(TestSchemaF().load([{}], many=True, partial=True), list)

# Generated at 2022-06-21 11:29:33.899260
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    # type: () -> typing.NoReturn
    a = SchemaF.dumps(1, 2)
    x = typing.cast(str, a)


# Generated at 2022-06-21 11:29:36.624726
# Unit test for constructor of class _IsoField
def test__IsoField():
  assert _IsoField()._serialize(None, None, None, None) == None
  assert _IsoField(required=True)._serialize(None, None, None, None) == "Field is required."


# Generated at 2022-06-21 11:29:43.623076
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    @_user_overrides_or_exts('__annotations__')
    @post_load
    def make_dataclass(self: 'UnionSchema', data: dict) -> C:
        return C(**data)


    class A(typing.NamedTuple):
        a: str


    class B(typing.NamedTuple):
        a: str
        b: str


    class C(typing.NamedTuple):
        a: str
        b: str
        c: str


    class UnionSchema(SchemaF[typing.Union[A, B, C]]):
        a = fields.Str()
        b = fields.Str()
        c = fields.Str()

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter

# Generated at 2022-06-21 11:29:55.294373
# Unit test for function build_schema
def test_build_schema():
    class Bar:
        x = 44

    class Foo(Bar):
        x = int
        y = str
        z = datetime.utcnow()

    class FooDict(Foo, Generic[int]):
        pass

    class Mixin(Schema):
        class Meta:
            strict = True

    class Mixin2:
        pass

    class MySchema(DataclassSchema):
        class Meta:
            pass

    foo_schema: Type[SchemaType] = build_schema(Foo, Mixin,
                                                infer_missing=False,
                                                partial=False)
    foo_schema2: Type[SchemaType] = build_schema(
        FooDict, Mixin, infer_missing=False, partial=False)

# Generated at 2022-06-21 11:29:59.733653
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class S(Schema):
        foo = fields.Str()

    @dataclass_json
    @dataclass
    class C(object):
        foo: str

    c = C('foo')
    s = SchemaF(S())
    assert s.dump(c) == {'foo': 'foo'}
    assert s.dump([c]) == [{'foo': 'foo'}]
    assert s.dumps([c], many=True) == '[{"foo": "foo"}]'
    assert s.dumps(c) == '{"foo": "foo"}'
    assert s.loads('{"foo": "foo"}') == c
    assert s.loads('[{"foo": "foo"}]', many=True) == [c]



# Generated at 2022-06-21 11:30:10.728719
# Unit test for function build_schema
def test_build_schema():
    def test_OneSchema(Schema):
        class Meta:
            fields = ("one_str",)
        class test_OneSchema(Schema):
            class Meta(Meta):
                pass
    def test_TwoSchema(Schema):
        class Meta:
            fields = ("two_str",)

        class test_TwoSchema(Schema):
            class Meta(Meta):
                pass

    schema_1 = build_schema(test_OneSchema, object(), False, False)
    schema_2 = build_schema(test_TwoSchema, object(), False, False)

    assert schema_1.__name__ == 'test_OneSchema'
    assert schema_2.__name__ == 'test_TwoSchema'

    assert schema_1.Meta.fields == ('one_str',)

# Generated at 2022-06-21 11:30:13.487825
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = fields.DateTime(dump_to='dump_to_name',
                            load_from='load_from_name')
    assert isinstance(field, fields.DateTime)
    return field



# Generated at 2022-06-21 11:32:20.528926
# Unit test for constructor of class _UnionField
def test__UnionField():
    import marshmallow.fields as mf
    """
    Test valid UnionField creation
    """

    # TestUnion takes string argument
    TestUnion = typing.Union['str', 'int']

    res = _UnionField(None, None, None, TestUnion)
    assert isinstance(res.field, mf.Str)

    res = _UnionField(None, None, None, TestUnion)
    assert isinstance(res.field, mf.Str)


# Generated at 2022-06-21 11:32:30.150642
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    @dataclass_json
    @dataclass
    class Foo:
        x: str

    SchemaF[Foo].dumps([Foo('a'), Foo('b')], many=True) == ('[{"x": "a"}, {"x": "b"}]')
    SchemaF[Foo].dumps(Foo('a')) == ('{"x": "a"}')
    SchemaF[Foo].dump([Foo('a'), Foo('b')], many=True) == ([{"x": "a"}, {"x": "b"}])
    SchemaF[Foo].dump(Foo('a')) == ({"x": "a"})

# Generated at 2022-06-21 11:32:35.615852
# Unit test for constructor of class _TimestampField
def test__TimestampField():  # pragma: no cover
    timestamp = _TimestampField()
    assert timestamp._serialize(datetime(2000, 1, 1), None, None) == 946684800.0
    assert timestamp._deserialize(946684800.0, None, None) == datetime(2000, 1, 1)



# Generated at 2022-06-21 11:32:39.340484
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    obj = SchemaF[typing.List[str]].dumps(['str'])
    obj = SchemaF[str].dumps('str')
    obj = SchemaF[typing.List[str]].dumps(['str'])


# Generated at 2022-06-21 11:32:49.803374
# Unit test for function schema
def test_schema():
    import marshmallow
    from dataclasses_json.schema_mixin import SchemaMixin
    from dataclasses import dataclass

    @dataclass
    class Test(SchemaMixin):
        a: int
        b: int = 5
        c: str
        d: typing.Dict[str, float] = {}

    fields = schema(Test, SchemaMixin, True)

    assert isinstance(fields['a'], marshmallow.fields.Integer)
    assert isinstance(fields['b'], marshmallow.fields.Integer)
    assert isinstance(fields['c'], marshmallow.fields.String)
    assert isinstance(fields['d'], marshmallow.fields.Dict)



# Generated at 2022-06-21 11:32:58.066145
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert _IsoField()._deserialize('2018-07-15T19:59:26.193772', '', {}) == datetime(2018, 7, 15, 19, 59, 26, 193772)
    assert _IsoField()._serialize(datetime(2018, 7, 15, 19, 59, 26, 193772), '', {}) == '2018-07-15T19:59:26.193772'
    assert _IsoField(allow_none=True)._deserialize(None, '', {}) == None
    try:
        _IsoField()._deserialize(None, '', {})
    except ValidationError as e:
        assert str(e) == "'required' is a required property"

# Generated at 2022-06-21 11:33:03.706948
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class ExampleType(typing.NamedTuple):
        example_attribute: str

    class ExampleSchema(SchemaF[ExampleType]):
        example_attribute = fields.String()

    schema: ExampleSchema

    schema = ExampleSchema()
    assert schema.loads({"example_attribute": "hello"}) == ExampleType(example_attribute="hello")
    assert schema.loads([{"example_attribute": "hello"}]) == [ExampleType(example_attribute="hello")]

# Generated at 2022-06-21 11:33:10.843392
# Unit test for function schema
def test_schema():
    import pytest
    import dataclasses
    import dataclasses_json

    @dataclasses.dataclass
    class Test(object):
        a = dataclasses.field(default=None)
        # Unknown type should not load
        b = dataclasses.field(default=None, metadata=dict(
            dataclasses_json=dataclasses_json.config(
                mm_field=fields.String(load_only=True))))
    assert True, schema(Test, dataclasses_json.Mutable.schema, True)



# Generated at 2022-06-21 11:33:20.422306
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class A(typing.Generic[T]):
        def __init__(self, x: T):
            self.x = x

    class B:
        def __init__(self, y: str):
            self.y = y

    class C:
        def __init__(self, z: int):
            self.z = z

    class D(typing.Generic[S, T]):
        def __init__(self, x: S, y: T):
            self.x = x
            self.y = y

    class Usage(SchemaF[A[B]]):
        class Meta:
            fields = ['x']

    class Usage2(Schema):
        x = fields.Nested(SchemaF[B])


# Generated at 2022-06-21 11:33:31.613205
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    # Test case 1
    schema = SchemaF.inherit_from(Schema, of=int)
    result = schema.loads('[1, 2, 3]')
    assert isinstance(result, typing.List[int])
    result = schema.loads('5')
    assert isinstance(result, int)
    # Test case 2
    schema = SchemaF.inherit_from(Schema, of=str)
    result = schema.loads('[1, 2, 3]')
    assert isinstance(result, typing.List[str])
    result = schema.loads('5')
    assert isinstance(result, str)
    # Test case 3
    schema = SchemaF.inherit_from(Schema, of=datetime)
    result = schema.loads('[1, 2, 3]')
   