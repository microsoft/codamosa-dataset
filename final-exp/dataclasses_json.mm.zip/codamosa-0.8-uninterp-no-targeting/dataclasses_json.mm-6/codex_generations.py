

# Generated at 2022-06-21 11:24:13.291409
# Unit test for function schema
def test_schema():
    from marshmallow import fields
    from typing import Optional
    from dataclasses import asdict, dataclass
    import dataclasses_json

    @dataclass
    class Person:
        name: str
        age: Optional[int] = None

        class Config:
            arbitrary_types_allowed = True

    assert schema(Person, dataclasses_json.M, infer_missing=True) == {
        "name": fields.Str(
            data_key="name", required=True),
        "age": fields.Int(
            allow_none=True, missing=None)
    }

# Generated at 2022-06-21 11:24:17.109422
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
  # test_SchemaF_dump_1
  dataclass_1 = dict()
  s = SchemaF()
  s.dump(dataclass_1)
  # test_SchemaF_dump_2
  dataclass_1 = dict()
  s = SchemaF()
  s.dump(dataclass_1)



# Generated at 2022-06-21 11:24:26.030911
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    x = SchemaF.dump(SchemaF(), [], many=True)  # type: ignore
    x = SchemaF.dump(SchemaF(), [], many=False)  # type: ignore
    x = SchemaF.dump(SchemaF(), {}, many=True)  # type: ignore
    x = SchemaF.dump(SchemaF(), {}, many=False)  # type: ignore
    # Unit test for method dumps of class SchemaF
    x = SchemaF.dumps(SchemaF(), [], many=True)  # type: ignore
    x = SchemaF.dumps(SchemaF(), [], many=False)  # type: ignore
    x = SchemaF.dumps(SchemaF(), {}, many=True)  # type: ignore
    x = SchemaF.d

# Generated at 2022-06-21 11:24:36.342145
# Unit test for constructor of class _UnionField
def test__UnionField():
    from typing import Union
    from dataclasses import dataclass

    class TestEnum(Enum):
        X = 'x'
        Y = 'y'

    @dataclass
    class TestDataclass:
        test: TestEnum

    @dataclass
    class TestDecodable:
        test: str

    union = Union[TestDataclass, TestDecodable]

    f = _UnionField([
        (TestDataclass, TestDataclass.Schema()),
        (TestDecodable, TestDecodable.Schema())],
        TestDataclass,
        dataclasses.Field(default=None))


# Generated at 2022-06-21 11:24:44.610556
# Unit test for function build_schema
def test_build_schema():
    """
    Just a test to check if build_schema is working
    """
    import dataclasses
    import typing
    @dataclasses.dataclass
    class Register():
        name: str = dataclasses.field(metadata = {
            'dataclasses_json': {
                'letter_case': dataclasses_json.config.LetterCase.CAMEL,
                'mm_field': marshmallow.fields.Str(missing=str('defaultName'))
            }})
        age: int = dataclasses.field(metadata = {
            'dataclasses_json': {
                'letter_case': dataclasses_json.config.LetterCase.CAMEL,
                'mm_field': marshmallow.fields.Integer(missing=int(20))
            }})
        email: str = dataclasses.field

# Generated at 2022-06-21 11:24:48.165725
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert _TimestampField()._deserialize(1) == datetime(1970, 1, 1, 0, 0, 1, tzinfo=timezone.utc)


# Generated at 2022-06-21 11:24:51.862030
# Unit test for constructor of class _IsoField
def test__IsoField():
    assert_statement = "datetime.datetime.fromisoformat(value)"
    field_one_attr = _IsoField()
    assert field_one_attr._deserialize.__code__.co_consts[-2] == assert_statement


# Generated at 2022-06-21 11:24:52.879354
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    assert False


# Generated at 2022-06-21 11:25:02.393755
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from marshmallow import Schema, fields
    from mypy_extensions import TypedDict

    class User(TypedDict, total=False):
        name :str
        email:str
        age  :int

    class UserSchema(SchemaF[User]):
        name = fields.Str()
        email = fields.Email()
        age = fields.Integer()

    schema = UserSchema()
    assert schema.loads('{"name": "Monty", "email": "monty@python.org", "age": 42}', many=False) == {'name': 'Monty', 'email': 'monty@python.org', 'age': 42}

# Generated at 2022-06-21 11:25:09.584870
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from marshmallow import Schema, fields, post_load

    @dataclass
    class User:
        name: str
        surname: str

    @dataclass
    class NewUser(User):
        age: int

    class UserSchema(SchemaF[User]):
        name = fields.Str()
        surname = fields.Str()

        @post_load
        def make_user(self, data):
            return User(**data)

    class NewUserSchema(SchemaF[NewUser]):
        name = fields.Str()
        surname = fields.Str()
        age = fields.Int()

        @post_load
        def make_user(self, data):
            return NewUser(**data)


# Generated at 2022-06-21 11:25:27.777265
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    class TestSchema(SchemaF[str]):
        pass
    TestSchema().dump([], many=None)
    TestSchema().dump('', many=None)
    TestSchema().dump('', many=True)
    TestSchema().dump([])
    TestSchema().dump('')
    TestSchema().dumps([], many=None)
    TestSchema().dumps('', many=None)
    TestSchema().dumps('', many=True)
    TestSchema().dumps([])
    TestSchema().dumps('')

# Generated at 2022-06-21 11:25:39.159596
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from marshmallow.fields import String, Integer
    from marshmallow import Schema

    # Test for base class schema.
    class A(Schema):
        a_value = String(required=True)

    obj = {'a_value': 'a', 'b_value': 1}
    a1 = A()  # type: SchemaF[{'a_value': str, 'b_value': int}]
    a2 = A(unknown='raise')  # type: SchemaF[{'a_value': str}]
    a3 = A()  # type: SchemaF[A]

    a1.dump(obj)
    a2.dump(obj)
    a3.dump(A(obj, unknown='raise'))

    # Test for derived class schema.

# Generated at 2022-06-21 11:25:49.244712
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    # test
    now = datetime.now()
    f1 = _TimestampField()
    f2 = _TimestampField()
    f2.required = False
    assert f1._serialize(now, "now", {}) == now.timestamp()
    deserialized = f1._deserialize(now.timestamp(), "now", {})
    assert deserialized.year == now.year
    assert f2._serialize(None, "", {}) == None
    assert f2._serialize(now, "", {}) == now.timestamp()
    assert f2._deserialize(now.timestamp(), "now", {}) == _timestamp_to_dt_aware(now.timestamp())
    assert f2._deserialize(None, "now", {}) == None


# Generated at 2022-06-21 11:25:55.206881
# Unit test for function build_schema
def test_build_schema():
    import dataclasses
    import marshmallow

    @dataclasses.dataclass
    class Person:
        name: str
        age: int
        gender: str

    class PersonSchema(build_schema(Person, mixin=marshmallow.Schema, infer_missing=True, partial=False)):
        pass

    assert len(PersonSchema.__fields__) == 3
    assert 'name' in PersonSchema.__fields__
    assert 'age' in PersonSchema.__fields__
    assert 'gender' in PersonSchema.__fields__

    assert PersonSchema.__fields__['name'].__class__.__name__ == 'String'
    assert PersonSchema.__fields__['age'].__class__.__name__ == 'Integer'

# Generated at 2022-06-21 11:26:01.976553
# Unit test for constructor of class _UnionField
def test__UnionField():
    from marshmallow import Schema, fields
    class UnitTestSchema(Schema):
        t = fields.Integer()

    class UnitTestDataclass:
        t: int = None

    union_desc = {UnitTestSchema: UnitTestDataclass}
    field = _UnionField(union_desc, 'cls', 'field', required=True)

    assert field.required
    assert field.attribute == 'field'

test__UnionField()



# Generated at 2022-06-21 11:26:09.639151
# Unit test for function schema
def test_schema():
    assert schema({
        'a': fields.Str(missing=None, allow_none=True),
        'b': fields.Int(missing=None, allow_none=True)
    }, None, True) == {
        'a': fields.Str(missing=None, allow_none=True),
        'b': fields.Int(missing=None, allow_none=True)
    }


# Generated at 2022-06-21 11:26:17.822634
# Unit test for constructor of class _UnionField
def test__UnionField():
    # Common set of imports
    from typing import Optional, Union, Any
    import dataclasses
    import marshmallow
    import marshmallow.fields
    import marshmallow.validate

    # Test definition
    @dataclasses.dataclass
    class DummyClass:
        data: Union[Any, int, str]
        name: str = dataclasses.field(default_factory=lambda: 'test')


# Generated at 2022-06-21 11:26:19.410943
# Unit test for constructor of class _IsoField
def test__IsoField():
    _IsoField()


# Generated at 2022-06-21 11:26:28.102537
# Unit test for function schema
def test_schema():
    import typing
    from dataclasses import dataclass
    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class Foo:
        name: str
        thing: typing.Optional[str]
        num: int = 5
        lst: typing.List[str] = None
        dct: typing.Dict[str, bool] = None
        dct2: typing.MutableMapping[str, int] = None
        num2: typing.Optional[int] = None
        num3: typing.Optional[int] = 7
        num4: typing.Union[str, int, typing.Any] = None


# Generated at 2022-06-21 11:26:29.452091
# Unit test for constructor of class _UnionField
def test__UnionField():
    x = _UnionField({}, type(None), None)



# Generated at 2022-06-21 11:26:55.995167
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    output1 = _TimestampField()._serialize(datetime.utcnow(), None, None, None)
    output2 = _TimestampField()._deserialize(output1, None, None, None)
    assert isinstance(output1, float)
    assert isinstance(output2, datetime)
    assert output2.tzinfo is None




# Generated at 2022-06-21 11:27:03.116691
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    @dataclasses.dataclass
    class A1:
        x: str

    s = dataclasses_json.Schema.of(A1)

    @dataclasses.dataclass
    class A2:
        a: typing.List[A1]

    s = dataclasses_json.Schema.of(A2)

    a = A2(a=[A1('1'), A1('2')])
    json.loads(s.dumps(a))



# Generated at 2022-06-21 11:27:07.823260
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    # type: () -> None
    class _Test(SchemaF):
        pass
    assert _Test.load([{'x': 1}], many=True) == [{'x': 1}]
    assert _Test.loads(b'[{"x": 1}]', many=True) == [{'x': 1}]



# Generated at 2022-06-21 11:27:10.521558
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    assert SchemaF[str].loads("") == str

# Generated at 2022-06-21 11:27:18.013617
# Unit test for constructor of class SchemaF
def test_SchemaF():
    class T(typing.Generic[A]):
        pass

    x: T[typing.List[str]] = T()
    y: T[str] = T()

    z: T[typing.Union[typing.List[str], str]] = T()

    a = SchemaF[typing.List[str]]()
    b = SchemaF[str]()
    c = SchemaF[typing.Union[typing.List[str], str]]()

    assert a
    assert b
    assert c



# Generated at 2022-06-21 11:27:27.917193
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    class Foo(typing.NamedTuple):
        bar: str
    class FooSchema(SchemaF[Foo]):
        bar = fields.Str()

    foo = Foo("abc")
    foo_encoded = FooSchema().dump(foo)
    assert foo_encoded == {'bar': 'abc'}
    foo_decoded = FooSchema().load(foo_encoded)
    assert foo == foo_decoded
    foo_encoded2 = FooSchema(many=False).dump(foo)
    assert foo_encoded == foo_encoded2
    foo_decoded2 = FooSchema(many=False).load(foo_encoded2)
    assert foo == foo_decoded2

    foo2 = Foo("def")

# Generated at 2022-06-21 11:27:31.299465
# Unit test for constructor of class SchemaF
def test_SchemaF():
    with pytest.raises(NotImplementedError):
        SchemaF()


# Unit test deserializing of Union field

# Generated at 2022-06-21 11:27:35.744537
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    d = {'a_int': 1, 'a_str': '2', 'a_bool': False, 'a_date': '2020-01-01T01:01:01'}
    s = SchemaF[A]()
    s.load(d)


# Generated at 2022-06-21 11:27:44.294588
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from dataclasses import dataclass
    from marshmallow import Schema, fields
    from dataclasses_json.schema import SchemaF

    @dataclass
    class A:
        a: int = 42

    @dataclass
    class B:
        b: int = 43

    class Inner(Schema):
        b = fields.Int()

    class SchemaA(SchemaF[A]):
        a = fields.Int()

    a = A(a=1)
    a_dump = {'a': 1}
    assert SchemaA().dumps(a) == a_dump

    a_list = [A(1), A(2), A(3)]
    a_list_dump = [{'a': 1}, {'a': 2}, {'a': 3}]
    assert SchemaA

# Generated at 2022-06-21 11:27:50.208162
# Unit test for function build_schema
def test_build_schema():
    """Unit test for function build_schema.
    """
    from dataclasses import dataclass

    from dataclasses_json import dataclass_json

    @dataclass_json
    @dataclass
    class Test:
        a: str

    assert build_schema(Test, dataclass_json, False, False)


# Generated at 2022-06-21 11:28:42.062825
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    # There was an issue with circular imports and
    # dataclasses_json.marshmallow_3_marshmallow.py.
    # Here is a test to make sure the circular imports
    # do not happen again.
    from dataclasses import dataclass

    @dataclass
    class A:
        timestamp: datetime

    class A_Schema(Schema):
        timestamp = _TimestampField()

    A_Schema().dump(A(datetime.now()))



# Generated at 2022-06-21 11:28:51.815872
# Unit test for function build_type
def test_build_type():
    import marshmallow as mm
    from dataclasses_json.mixin import DataclassJsonMixin
    from typing import Optional, List

    class Base(DataclassJsonMixin):
        std: str
        mm_field: str = mm.fields.Field()

    @dataclass
    class Nested(DataclassJsonMixin):
        std: int
        mm_field: int = mm.fields.Int()

    @dataclass
    class Inherited(Base):
        std: int
        mm_field: int = mm.fields.Int()
        nested: Nested
        mm_nested: Nested = mm.fields.Nested('Nested')
        optional: Optional[int]
        mm_optional: Optional[int] = mm.fields.Int()

# Generated at 2022-06-21 11:28:59.083339
# Unit test for function build_type
def test_build_type():
    def_dict = {'field_many': True, 'allow_none': False}
    type1 = build_type(typing.List[int], def_dict, None, None, None)
    assert type1(DefaultOptions)._serialize([1, 2], '', object()) == [1, 2]

    class A(Enum):
        A = 'a'

    type2 = build_type(A, def_dict, None, None, None)
    assert type2(DefaultOptions)._serialize(A.A, '', object()) == 'a'

    class B:
        pass

    type3 = build_type(B, def_dict, None, None, None)
    assert type3(DefaultOptions)._serialize(B(), '', object()) == B()



# Generated at 2022-06-21 11:29:09.803430
# Unit test for constructor of class _UnionField
def test__UnionField():
    @dataclass
    class Foo:
        bar: tuple

    @dataclass
    class Foo2:
        bar: int

    class MyEnum(Enum):
        ONE = 1
        TWO = 2

    @dataclass
    class Foo3:
        bar: typing.Optional[MyEnum]

    class MySchemaFoo(Schema):
        bar = (  # type: ignore
            fields.Nested(  # type: ignore
                "MySchemaFoo2",
                many=True,
                required=True,
                allow_none=False))

        @post_load
        def make_foo(self, data):
            return Foo(**data)

    class MySchemaFoo2(Schema):
        bar = fields.Int(required=False)


# Generated at 2022-06-21 11:29:17.137443
# Unit test for function schema
def test_schema():
    from marshmallow import fields as mm_fields
    from dataclasses import dataclass, field

    @dataclass
    class Dummy:
        f1: typing.List[int] = field(metadata={'dataclasses_json': {'mm_field': mm_fields.Int()}})
        f2: str = field(metadata={'dataclasses_json': {'mm_field': mm_fields.Str()}})

        class Schema(SchemaType):
            pass

    schema = schema(Dummy, object, False)
    assert isinstance(schema['f1'], fields.Int)
    assert isinstance(schema['f2'], fields.Str)



# Generated at 2022-06-21 11:29:25.618549
# Unit test for function schema
def test_schema():
    from dataclasses_json.annotations import mm_field, LetterCase
    class Base:
        pass

    @dataclass_json(letter_case=LetterCase.CAMEL)
    class NestedRef(Base):
        x: int
        y: int

    @dataclass_json()
    class Nested(Base):
        a: NestedRef
        b: str

    @dataclass_json(unknown=EXCLUDE)
    class Data(Base, metaclass=SchemaMeta):
        c: List[Nested]
        d: int = field(metadata={'mm_field': mm_field(fields.Int(required=True))})
        e: int = field(metadata={'mm_field': mm_field(fields.Int(allow_none=False))})

# Generated at 2022-06-21 11:29:34.814746
# Unit test for function build_schema
def test_build_schema():
    import pytest
    from dataclasses import dataclass
    from marshmallow.fields import Str
    from typing_extensions import Literal

    @dataclass
    class A:
        _a: Literal["a"]
        b: int = 0

    @dataclass
    class B(A):
        c: str = "c"

    @dataclass
    class C(A, B):
        pass

    assert A.schema().fields.keys() == {"_a", "b"}
    assert B.schema().fields.keys() == {"_a", "b", "c"}
    assert len(C.schema().fields.keys()) == 3

    @dataclass
    class D:
        a: Literal["a"]
        b: int = 0
        d: str = "d"


# Generated at 2022-06-21 11:29:36.897911
# Unit test for constructor of class _IsoField
def test__IsoField():
    field = _IsoField()
    with pytest.raises(ValidationError):
        field.deserialize(None)



# Generated at 2022-06-21 11:29:38.348623
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    assert(_TimestampField()._deserialize(1585281900) == datetime(2020, 3, 27, 15, 45))



# Generated at 2022-06-21 11:29:45.274329
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    s: SchemaF[int] = SchemaF(unknown='ignore')
    assert False



# Generated at 2022-06-21 11:30:40.495056
# Unit test for constructor of class _UnionField
def test__UnionField():
    from dataclasses import dataclass

    @dataclass
    class Foo:
        pass

    @dataclass
    class Bar:
        a: str
        c: typing.Any = 1

    @dataclass
    class Data:
        a: typing.Union[Foo, Bar]

    schema = DataSchema()

    field = _UnionField(
        desc={
            Foo: _get_dataclass_schema(Foo, 'Data', 'a'),
            Bar: _get_dataclass_schema(Bar, 'Data', 'a')
        },
        cls=Data,
        field=dc_fields(Data)[0],
    )
    data = {'a': {'c': 1}}
    value = field._deserialize(data, 'a', data)
    assert value == Bar

# Generated at 2022-06-21 11:30:43.381290
# Unit test for method dump of class SchemaF
def test_SchemaF_dump():
    from dataclasses import dataclass
    @dataclass
    class User:
        name: str
    schema = SchemaF[User]
    user = User('John')
    obj = schema.dump(user)
    assert obj == {'name': 'John'}

# Generated at 2022-06-21 11:30:53.023245
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    from typing import List
    from marshmallow import fields
    from marshmallow import RAISE, EXCLUDE
    from marshmallow import ValidationError as MarshmallowValidationError
    from marshmallow_oneofschema import OneOfSchema
    from marshmallow_enum import EnumField
    from dataclasses_json.schema import Schema as SchemaJ
    import uuid
    from dataclasses import dataclass, field
    from dataclasses_json.schema import generate_schema
    import warnings

    warnings.warn('warning message')
    class DataClassJsonSchemaL001(SchemaF):
        """Schema for DataClassJsonSchemaL001"""
        __model__: typing.Type[DataClassJsonSchemaL001]

# Generated at 2022-06-21 11:31:00.971983
# Unit test for constructor of class SchemaF
def test_SchemaF():  # type: ignore
    class PersonF:
        def __init__(self, name: str, age: int) -> None:
            self.name = name
            self.age = age

    class PersonFSchema(SchemaF):
        name = fields.Str()
        age = fields.Int()

    res: typing.List[PersonF] = PersonFSchema().loads(
        '''[{"name": "foo", "age": 12}, {"name": "bar", "age": 42}]''')
    assert isinstance(res, typing.List)
    assert isinstance(res[0], PersonF)
    assert res[0].age == 12
    assert isinstance(res[1], PersonF)
    assert res[1].age == 42

# Generated at 2022-06-21 11:31:03.951698
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    from dataclasses_json.tests.test_schemas_marshmallow.test_schema import C
    s = SchemaF.from_dataclass(C)
    assert isinstance(s, SchemaF)
    assert issubclass(s.__class__, SchemaF)
    assert s.__class__ is not SchemaF


# Generated at 2022-06-21 11:31:14.990300
# Unit test for function build_type
def test_build_type():
    assert isinstance(build_type(str, {}, None, None, None), fields.Str)
    assert isinstance(build_type(bytes, {}, None, None, None), fields.Raw)
    assert isinstance(build_type(typing.Optional[str], {}, None, None, None),
                      fields.Str)
    assert isinstance(build_type(typing.List[str], {}, None, None, None),
                      fields.List)
    assert isinstance(build_type(typing.List[typing.Optional[str]], {}, None,
                                 None, None), fields.List)
    assert isinstance(build_type(typing.List[int], {}, None, None, None),
                      fields.List)

# Generated at 2022-06-21 11:31:24.951791
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    with pytest.raises(ValidationError, match=r".*required.*"):
        _TimestampField().output_only = True
        _TimestampField().load(None)
    assert _TimestampField().load(None) is None
    assert _TimestampField(required=True).load(None)
    assert _TimestampField().load(datetime.now().timestamp())
    with pytest.raises(ValidationError, match=r".*required.*"):
        _TimestampField(required=True).load(None)
    with pytest.raises(ValidationError, match=r".*required.*"):
        _TimestampField().dump(None)
    assert _TimestampField().dump(None) is None

# Generated at 2022-06-21 11:31:31.356843
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    import dataclasses
    import typing
    import marshmallow
    from datetime import date

    @dataclasses.dataclass
    class DC1:
        name: str
        age: int

    @dataclasses.dataclass
    class DC2:
        name: str
        age: typing.Optional[int]
        date: date

    @dataclasses.dataclass
    class DC3:
        a: typing.List[DC1]

    @dataclasses.dataclass
    class DC4:
        a: typing.List[typing.Dict[str, int]]

    @dataclasses.dataclass
    class DC5:
        a: typing.List[typing.List[int]]


# Generated at 2022-06-21 11:31:41.735308
# Unit test for method loads of class SchemaF
def test_SchemaF_loads():
    class MySchemaF(SchemaF[int]):
        pass

    MySchemaF.loads('{"a": 1}', many=False)
    #expect error was raised:
    #       MySchemaF.loads('{"a": "1"}', many=False)

    MySchemaF.loads('[{"a": 1}]', many=True)
    #expect error was raised:
    #       MySchemaF.loads('[{"a": "1"}]', many=True)

    MySchemaF.loads(b'[{"a": 1}]', many=False)
    #expect error was raised
    #       MySchemaF.loads(b'[{"a": "1"}]', many=False)

    MySchemaF.loads(b'{"a": 1}', many=True)

# Generated at 2022-06-21 11:31:44.073966
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    schema = SchemaF[str]()
    assert schema.dumps("hello") == '"hello"'


# Generated at 2022-06-21 11:33:28.801503
# Unit test for constructor of class _TimestampField
def test__TimestampField():
    value = 1571966352.5274477
    f = _TimestampField()
    f.deserialize(value)



# Generated at 2022-06-21 11:33:38.364397
# Unit test for method load of class SchemaF
def test_SchemaF_load():
    from dataclasses import dataclass

    def expect(sc: typing.Generic[A], data: TOneOrMultiEncoded, expected: A) -> None:
        actual = sc.load(data)
        assert actual == expected

    @dataclass
    class Student:
        name: str
        age: int
        gpa: float

    @dataclass
    class Class:
        teacher: str
        students: typing.List[Student]


# Generated at 2022-06-21 11:33:44.176967
# Unit test for constructor of class _UnionField
def test__UnionField():
    """ Test_union_field.test__UnionField """
    from dataclasses import dataclass

    @dataclass
    class Aaa:
        x: int

    @dataclass
    class Bbb:
        y: str

    @dataclass
    class TestUnionField:
        t_u = typing.Union[Aaa, Bbb]

    schema = TestUnionFieldSchema()
    test = TestUnionField(t_u=Aaa(x=100))
    deser_test = schema.loads(schema.dumps(test))
    assert test.t_u == deser_test.t_u


# Generated at 2022-06-21 11:33:48.616897
# Unit test for method dumps of class SchemaF
def test_SchemaF_dumps():
    class TestClass:

        def __init__(self, a: int):
            self.a = a

    schema = SchemaF[TestClass]()

    assert schema.dumps(TestClass(1)) == '{"a": 1}'
